# @vibe/engine

The engine a Squidwright game runs on: the ECS, the update loop, input, three.js as a view of the
ECS, the asset runtime, audio, prefabs and scenes, `Game` and `boot()`, the canvas UI and MrDebug.
`three` and `pixi.js` are peers: one copy in a project.

- `@vibe/engine` -- the ECS, prefab tokens, the loop, the view, the asset store, prefabs, scenes and
  data files (loads in node and in a worker: no renderer, no pixi, no `DEBUG_BUILD`; three's core is
  imported by the store, and `sideEffects` lets a worker's bundle drop it)
- `/assets` (`Assets`, `Audio`, `useBundle`), `/boot` (`boot`, `Game`, `liveGame`), `/ui` (the canvas
  UI), `/debug` (`MrDebug`) -- the page's
- `/testing` (`suite`) and `/node` -- tests; `/worker` -- a worker thread; `/rules` and `/case-key` --
  the pipeline; `/hot` -- no importer today

Imported by a project's `src/`, by `@vibe/editor` and (its pure subpaths) by `@vibe/pipeline`; it
imports neither. The docs are the squidwright repository's `Docs/` (`packages.md` §2, `ecs.md`, `loop.md`).
