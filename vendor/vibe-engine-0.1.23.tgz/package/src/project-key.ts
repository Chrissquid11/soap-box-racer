/// <reference path="./env.d.ts" preserve="true" />
/**
 * What a page keeps in browser storage, kept per project (Docs/studio.md, "What the editor remembers").
 * `localStorage` and `sessionStorage` are the **origin's** -- `localhost:<port>` -- and two projects that run
 * on the same port, one after the other (a new project's port is the template's), or in the app's one
 * Electron session, would share every key: one project's Model tab opening the other's script. So what
 * is the project's -- what is open, where, what names a file of it -- is kept under `projectKey(name)`,
 * `<name>@<id>`; what is about how a person likes the editor stays under its bare name, true in every
 * project.
 *
 * - **The id** is `PROJECT_ID`, a literal `vibe()` writes into every module as it does `DEBUG_BUILD`
 *   (`packages/pipeline/src/config.ts`' `projectId`: a short hash of the project's real root): in the
 *   dev server and a debug build. A release's is `''`, the bare name: the game is its origin's alone,
 *   and a key that hung on the folder it was built in would forget a player's settings at each move.
 * - **Pure, and safe in node**: `typeof` asks for the constant, so a node test, with no Vite to write it,
 *   has `''` -- and every key its bare name, as before.
 */

/** This project's id where several may share an origin, or `''`: in node, and in a release. */
export function projectId(): string {
  return typeof PROJECT_ID === 'string' ? PROJECT_ID : '';
}

/** `name` as this project keeps it: `<name>@<id>`; the bare name where there is no id. */
export function projectKey(name: string, id: string = projectId()): string {
  return id === '' ? name : `${name}@${id}`;
}
