/**
 * The three.js world: renderer, scene, camera, and the update loop that drives
 * them. Knows nothing of Pixi or of the page beyond its canvas. The engine's,
 * on `@vibe/engine/boot` and never the index: it loads three and the asset
 * runtime as it loads.
 *
 * Built synchronously from loaded assets: `Assets.preload()` has finished before
 * `new Game(...)` (`boot`), so nothing here ever sees a half-loaded world.
 *
 * ## The loop
 *
 *   Gameplay is systems on `loop` (`loop/`, Docs/loop.md): fixed ticks at
 *   seven rates, input stamped so every rate sees it, seeded randomness. Each
 *   animation frame here runs `loop.frame` -- input, the ticks due, the render
 *   systems -- and then draws: three, then the UI over it. Pausing stops the
 *   animation frame, so no tick runs; resuming tells the loop not to count the
 *   pause.
 *
 * ## The three hooks the UI uses
 *
 *   - `onDrawn(fresh)`: called at the end of every frame on the canvas, drawn
 *     (`fresh`) or shown again (`present`). The canvas UI draws over it: one
 *     loop, no second `requestAnimationFrame` while the game runs.
 *   - `pointerClaim(e)`: asked first by every pointer handler here. True and
 *     the event is the UI's -- a press on a button is never also a drag of the
 *     camera.
 *   - `present()`: for a stopped game. Copies the frame kept when it stopped
 *     (`still.ts`) instead of drawing the world again, then `onDrawn(false)`,
 *     so menus animate over it for the price of a copy.
 *
 * ## The rebuild
 *
 *   `rebuild(next)` swaps changed game code into the running game
 *   (Docs/squidwright-implementation.md 0.3): the world saved, the loop and the
 *   world reset in place -- the same objects, so whoever holds them (the
 *   editor) goes on over them -- the new modules' systems registered, the save
 *   loaded back. Two more hooks around it:
 *
 *   - `onBeforeRebuild()`: before anything is touched -- a pending edit
 *     committed, a playtest ended -- or `false` to refuse: `rebuild` then
 *     answers `'reload'` with nothing touched (the editor, a prefab open with
 *     changes not saved).
 *   - `onRebuilt(change)`: after the save is back, with what it skipped and
 *     brought up to date (`load`'s answer).
 *
 *   In the dev server the rebuild is driven by the game's hot-update boundary,
 *   the project's generated `src/game/live.ts` (`liveGame`, the engine's
 *   `live-game.ts`: step 0.4, said there), through `boot`'s `onRebuild`.
 *
 * The world's entities and systems are the project's (its `src/game/`, the
 * entry handed in). The game itself keeps only the environment, as Unity's
 * skybox and default light: the sky's colour and fog, a hemisphere light and a
 * shadow-casting sun. There is no ground: a floor is the scene's own entity,
 * and a project replaces the rest in its own setup (`BootOptions.setup`).
 *
 * ## The cameras
 *
 *   The game is drawn through its `Camera` entities (Docs/camera.md; the
 *   engine's `cameras` system, `camera.ts`): each, by `depth`, into its
 *   viewport rect, its rect cleared as its `clear` says. A game moves one by
 *   its `Transform`, never by touching a three camera. With none -- a project
 *   or a scene that has no `Camera` -- the **fallback**: `camera`, the built-in
 *   one, on an orbit of its own (`placeCamera`, a drag turns it). `cameraControl`
 *   lends that built-in camera out -- to code that places it itself -- and the
 *   world is drawn through it whatever cameras the game has. The editor borrows
 *   nothing: its own camera is `viewOverride`, drawn through whole while it is
 *   up, and `onDrawWorld` draws its view cube over the world. The UI draws over
 *   all of it.
 *
 * ## The frame
 *
 *   All of that goes into the **frame** (`frame.ts`, Docs/game-view.md §2): a
 *   rect of the canvas, the whole of it unless `setFrame` gave one -- the
 *   editor's scene room. The cameras' viewports are fractions of it, the
 *   pointer is frame-local and the UI is laid out in it; the canvas outside it
 *   is cleared to `outside`. The canvas itself never shrinks.
 *
 *   A **resolution** (`setResolution`, Docs/game-view.md §4: the editor's
 *   preview of one) shapes the frame given into a box of its aspect, the rest
 *   of it bars (`letterbox`); from then on the box is the frame. Pixel and
 *   Stretch draw the world into a target of exactly the resolution's pixels
 *   (`scaled`) and that onto the box with one quad, nearest or linear: the
 *   cameras and the pointer measure the target (`pixels`), the UI the box.
 */
import * as THREE from 'three';
import { attachDevices, Camera, type Cameras, type Devices, type Entity, installAnimation, installCamera, installPhysics, installRender, installView, type AmmoApi, KeptFrame, Loop, onMaterialFiles, Prefabs, rebuildWorld, refreshInstances, type TickFailure, webWorker, WorkerPool, World, type WorldSave } from './index.ts';
import { Assets } from './assets/index.ts';
import { drawPlan, gameCameraOf, newDrawPlan } from './camera.ts';
import { PAGE_SOURCES } from './physics/sources.ts';
import { drawsScaled, fitBox, frameBottom, frameIn, framePoint, isWhole, shotArea, type FrameRect, type GameResolution } from './frame.ts';

/** `Game.gameView`'s answer, written over each call: nothing made per frame. */
const gameViewScratch: { object: THREE.Camera; entity: Entity } = { object: new THREE.PerspectiveCamera(), entity: 0 as Entity };

export interface GameOptions {
  canvas: HTMLCanvasElement;
  /** The game's seed: every system's random stream comes from it (Docs/loop.md §10). */
  seed: number;
  /** The game: its systems, its first entities, its installs (the project's `src/game/index.ts`, through `live.ts`). */
  entry: GameEntry;
  /** Makes one of the game's worker threads (`live.ts`' `worker`, whose folder the worker's URL is). None: no workers. */
  worker?: () => Worker;
  /** Ammo, loaded by `boot()` where the project has physics on (Docs/physics.md D2): the physics stage installed over it. None: no physics, `physicsOf` inert. */
  ammo?: AmmoApi | null;
}

/**
 * What a project's game entry (`src/game/index.ts`) exports: the one shape the engine expects of a
 * game. Its generated `src/game/live.ts` hands the entry to `liveGame`, and `Game` builds its world
 * from it -- and again from the entry evaluated anew, on a swap (`rebuild`).
 */
export interface GameEntry {
  registerSystems(world: World): void;
  /** The first entities on a fresh world (no save, no start scene). */
  populate(world: World): void;
  /**
   * The game's own page-side installs -- a render system of its own that holds three objects, say -- run on every
   * build and rebuild after its systems, each returning its uninstall. The engine's `render` and `animate` are
   * `Game`'s own (`installViews`), not these.
   */
  installs?: readonly ((world: World) => () => void)[];
  /** A save in an older format mapped to the current one: the sandbox's `loadOldKinds`. */
  loadOldKinds?(save: WorldSave): WorldSave;
}

/** What the debug panel (the editor package's `panel.ts`) hands the loop: the stats panel's frame brackets. */
export interface FrameProbe {
  begin(): void;
  end(): void;
}

/** Retina is expensive and phones are most players: never more than this. */
const MAX_PIXEL_RATIO = 2;

/**
 * Every prefab file compiled: a bad file fails here, naming it -- a view's
 * model key among what is loaded. A pack's (`reef:props/coral`) is there only
 * once its pack is mounted: the typecheck holds those. Called by `boot` at
 * boot, before the world is made, and by `rebuild` before it touches the
 * world. (The worker compiles with no models: a project's src/game/worker.ts.)
 */
export function compilePrefabs(): void {
  Prefabs.compile(Assets.prefabChecks);
}

/** The clips of the model a view was made of, by its `assetKey`: none for a view of no model, or one with none. */
const NO_CLIPS: readonly THREE.AnimationClip[] = [];
function clipsOf(view: THREE.Object3D): readonly THREE.AnimationClip[] {
  const key = view.userData.assetKey as string | undefined;
  return key === undefined ? NO_CLIPS : (Assets.modelIfPresent(key)?.animations ?? NO_CLIPS);
}

/** A save handed back as it is: an entry with no `loadOldKinds`. */
const asItIs = (save: WorldSave): WorldSave => save;

export class Game {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  /**
   * The built-in camera: the fallback's, drawn through only while the game has no `Camera` entity to
   * draw through (or lent out, `cameraControl`). Never assign to it, nor move it, from game code: a
   * game's camera is an entity with a `Camera`, moved by its `Transform`.
   */
  readonly camera = new THREE.PerspectiveCamera(50, 1, 0.1, 200);
  /**
   * A camera to draw the whole frame through instead of the game's: the editor's own view (Docs/camera.md
   * §3, 8.2), set while it is up and cleared for a playtest. Null: the game's cameras.
   */
  viewOverride: THREE.Camera | null = null;
  /**
   * Drawn over the world each frame, before the UI: called right after the world is drawn, running and
   * stopped -- into the kept frame then, so a `present` copies it with the world. One function, the
   * editor's (its view cube, Docs/camera.md §3); the engine never knows whose. It may set the viewport
   * and the scissor, into the target bound now if any (`renderer.getRenderTarget()`), and puts them back
   * as it found them: the whole canvas, no scissor. (Its rects are the canvas's: the frame is `frame`.)
   */
  onDrawWorld: ((renderer: THREE.WebGLRenderer) => void) | null = null;
  /** The systems, the ticks, the input every rate sees. */
  readonly loop: Loop;
  /** The entities and their data: the ECS (`ecs/`, Docs/ecs.md). */
  readonly world: World;

  /** Called before a rebuild touches anything: what is pending is settled now, or `false` refuses the swap (`rebuild` answers `'reload'`, nothing touched). */
  onBeforeRebuild: (() => boolean | void) | null = null;
  /** Called once a rebuild has loaded the save back: what it skipped, and what it brought up to date. */
  onRebuilt: ((change: { skipped: string[]; updated?: string[] }) => void) | null = null;
  /** Called with every frame on the canvas, to draw over it. `fresh` when the world was drawn for it. */
  onDrawn: ((fresh: boolean) => void) | null = null;
  /** Asked first by each pointer handler: does this event belong to something drawn over the world? */
  pointerClaim: ((e: PointerEvent) => boolean) | null = null;
  /** The debug build's frame timer, if it is on. */
  debug: FrameProbe | null = null;
  /**
   * A frame's ticks threw (`loop.failure` says in which system and tick): the
   * world is usable -- the tick was ended (Docs/loop.md §6) -- and the frame is
   * drawn as ever. Null: said on the console, the first time, and the game runs on.
   */
  onFrameError: ((failure: TickFailure) => void) | null = null;
  private saidFailure = false;
  /**
   * Who places the built-in camera (the fallback's) instead of its own orbit, or null for nobody.
   * While set, the `camera` render system calls this each frame it runs -- `renderOnce` included --
   * with the frame's seconds, and leaves the camera to it; and the world is drawn through that
   * camera, full canvas, even in a game with `Camera` entities. Kept for code that drives the
   * built-in camera itself -- a cutscene written against it; the editor no longer takes it (its own
   * camera is `viewOverride`, Docs/camera.md §3). A new game's cutscene or photo mode is better a
   * `Camera` entity of its own.
   */
  cameraControl: ((frameDt: number) => void) | null = null;

  private readonly kept = new KeptFrame();
  /** The engine's `cameras` system's answers: the game's cameras (`installViews`, again on a rebuild). */
  private cameras!: Cameras;
  /** The canvas's size in CSS pixels, as `resize` last set it. */
  private readonly whole = { width: 1, height: 1 };
  /** The frame as `setFrame` gave it, or null for the whole canvas. */
  private given: FrameRect | null = null;
  /** `given` cut to the canvas (`frameIn`), else the whole canvas: what a resolution's box is fitted in. */
  private readonly room: FrameRect = { x: 0, y: 0, width: 1, height: 1 };
  /** The frame in effect: the room, or the box a resolution fits in it (`fitBox`). */
  private readonly framed: FrameRect = { x: 0, y: 0, width: 1, height: 1 };
  /** The frame worked out anew (`placeFrame`), to tell whether it moved. */
  private readonly placing: FrameRect = { x: 0, y: 0, width: 1, height: 1 };
  /**
   * The frame's size in the game's pixels: what the cameras' viewports are fractions of (`installCamera`'s
   * `canvasSize`) and what the pointer reports -- the frame's own, or a Pixel or Stretch resolution's target's.
   */
  private readonly size = { width: 1, height: 1 };
  /** The resolution `setResolution` gave, or null: the frame as it is. */
  private resolution: GameResolution | null = null;
  /** The box's width over the game's pixels: 1 but for an exact resolution (Pixel's whole number). */
  private boxScale = 1;
  /** Pixel's and Stretch's target, exactly the resolution's pixels, the world drawn into it each frame; null otherwise. */
  private scaled: THREE.WebGLRenderTarget | null = null;
  /**
   * The quad the scaled target is drawn onto the box with: `KeptFrame`'s copy, finishing the frame as three would. Three
   * tone-maps nothing drawn into a target, so in Pixel and Stretch the whole target is tone-mapped once, here, by the
   * quad -- a material with `toneMapped: false` included, which is tone-mapped after all. `KeptFrame` does the same.
   */
  private readonly blitScene = new THREE.Scene();
  private readonly blitCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private readonly blit = new THREE.ShaderMaterial({
    uniforms: { scaledColor: { value: null as THREE.Texture | null } },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D scaledColor;
      varying vec2 vUv;
      void main() {
        gl_FragColor = texture2D(scaledColor, vUv);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    depthTest: false,
    depthWrite: false,
  });
  /** What the frame given shows round a resolution's box: the bars, black. */
  readonly letterbox = new THREE.Color(0x000000);
  /** A canvas point made frame-local (`framePoint`), written over: nothing made per pointer event. */
  private readonly local = { x: 0, y: 0 };
  /**
   * What the canvas outside the frame is cleared to, each frame, while a frame is set: black unless the
   * page sets another -- the editor, its background.
   */
  readonly outside = new THREE.Color(0x000000);
  /** An empty scene, drawn to clear the canvas outside the frame (`drawWorld`). */
  private readonly nothing = new THREE.Scene();
  /** The renderer's clear colour, kept over the cameras' own clears. */
  private readonly clearWas = new THREE.Color();
  /** The cameras' part of each frame (`drawPlan`), written over each time. */
  private readonly plan = newDrawPlan();
  /** The world, then what is drawn over it (`onDrawWorld`), bound once: what `KeptFrame.draw` paints the stopped frame with. */
  private readonly paint = (): void => {
    this.drawWorld();
    this.onDrawWorld?.(this.renderer);
  };
  private running = false;
  /** The animation frame asked for, to cancel on a pause. */
  private raf = 0;
  private readonly devices: Devices;
  /** The view and animation installs' undoing, for a rebuild: what the world's reset cannot know. */
  private uninstall: (() => void)[];
  /** How a save under old kind names is mapped: the entry's `loadOldKinds`, the newest one a rebuild was handed; none, as it is. */
  private loadOld: (save: WorldSave) => WorldSave;
  /** Ammo, where the project has physics: the physics stage installed over it with the views, again on every rebuild. */
  private readonly ammo: AmmoApi | null;
  /** Makes a worker thread, if the project said how (`GameOptions.worker`). */
  private readonly makeWorker: (() => Worker) | null;

  /** The built-in camera's angle round the scene, radians, and how fast a drag turns it: the fallback's. */
  private orbit = 0.6;
  private orbitSpin = 0;

  constructor({ canvas, seed, entry, worker, ammo }: GameOptions) {
    this.loop = new Loop({ seed });
    this.ammo = ammo ?? null;
    this.loadOld = entry.loadOldKinds ?? asItIs;
    this.makeWorker = worker ?? null;
    // A stencil buffer: the canvas UI draws into this same context after the
    // world, and Pixi's masks are stencil masks. Packed with depth, it is free.
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, stencil: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, MAX_PIXEL_RATIO));
    this.renderer.shadowMap.enabled = true;
    // A shader's compile checked only where someone reads the log: the check
    // makes every link wait to finish.
    this.renderer.debug.checkShaderErrors = import.meta.env.DEV;

    this.scene.background = new THREE.Color('#9fd3e8');
    this.scene.fog = new THREE.Fog('#9fd3e8', 18, 60);

    const sky = new THREE.HemisphereLight('#dff4ff', '#6b5a3f', 1.6);
    const sun = new THREE.DirectionalLight('#fff4e0', 2.4);
    sun.position.set(6, 10, 4);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    const s = sun.shadow.camera;
    s.left = s.bottom = -8;
    s.right = s.top = 8;
    this.scene.add(sky, sun);

    // The devices into the loop's input, and the pads polled once a frame: the
    // Gamepad API has no events for buttons.
    this.devices = attachDevices(this.loop.input, canvas, (e) => this.pointerClaim?.(e) ?? false, () => this.framed, () => this.size);
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.blit);
    quad.frustumCulled = false;
    this.blitScene.add(quad);
    this.installLoopSystems();
    // The ECS on that loop, and the scene's views on it.
    this.world = new World({ loop: this.loop });
    this.uninstall = this.installViews(this.world);
    entry.registerSystems(this.world);
    entry.populate(this.world);
    // The page's own installs after the game's systems: the render systems in the same order on every rebuild.
    for (const install of entry.installs ?? []) this.uninstall.push(install(this.world));
    // Everything checked now: an unknown `after` or a cycle fails at startup, not mid-game.
    this.world.build();
    // What was spawned is in the world, and in the scene, for the first frame.
    this.world.flush();
    // Each pooled prefab's warm instances made and parked, their models on (Docs/prefabs.md §5): after the
    // views are installed, so a take makes nothing. A pack unmounted drains the pools drawing from it first.
    this.world.warmPools();
    Assets.onUnmount((pack) => this.world.drainPools((key) => key.startsWith(`${pack}:`)));

    this.bindCamera(canvas);
    addEventListener('resize', () => this.resize());
    // A lost context: three keeps it restorable and draws nothing until it is
    // back (`WebGLRenderer` handles the loss itself); the loop runs on. On
    // restore three rebuilds its state and re-uploads everything as it is next
    // drawn -- but the kept frame's pixels went with the context, so it goes too.
    // A stopped world is drawn again a frame later, once every restore listener
    // has run: the canvas UI's comes after this one, and Pixi must be back
    // before `onDrawn` reaches it.
    canvas.addEventListener('webglcontextrestored', () => {
      this.kept.drop();
      requestAnimationFrame(() => {
        if (!this.running) this.renderOnce();
      });
    });
    this.resize();
  }

  /** The loop's own systems, the page's: at construction, and again after a rebuild reset the loop. */
  private installLoopSystems(): void {
    // The pads polled once a frame: the Gamepad API has no events for buttons.
    this.loop.addSystem({ name: 'gamepads', phase: 'input', update: () => this.devices.pollGamepads() });
    // The built-in camera: presentation only, in real time -- nothing in the simulation reads it. Lent
    // out, its borrower's; with a `Camera` entity to draw through, still (the fallback's orbit idles).
    this.loop.addSystem({
      name: 'camera',
      phase: 'render',
      update: ({ frameDt }) => {
        if (this.cameraControl) return this.cameraControl(frameDt);
        if (this.cameras.camerasToDraw().length > 0) return;
        this.orbit += this.orbitSpin * frameDt;
        this.orbitSpin *= Math.exp(-4 * frameDt);
        this.placeCamera();
      },
    });
  }

  /**
   * The game's code changed: its entry, evaluated again, swapped into the
   * running game (Docs/squidwright-implementation.md 0.3). The world saved, the
   * loop and the world reset in place (`rebuildWorld`), the views and the new
   * systems installed over the registry's components as they are now, the save
   * loaded back, the pools warmed. `'reload'` when it cannot, and the page is
   * to be reloaded: worker threads running, `onBeforeRebuild` refusing, or a
   * prefab file that no longer compiles -- the world then untouched, and
   * running again if it ran -- or a throw in the rebuild or the load (a bad
   * `after`, a cycle, a stale token in a new system's `read`) -- the world
   * then empty, its views out of the scene, and the game left paused until the
   * reload brings it back. None of these is covered by a test: `Game` needs
   * the renderer, so no node test builds one; the page's swap (0.4) and the
   * editor (0.5) exercise them live.
   */
  rebuild(next: GameEntry): 'swapped' | 'reload' {
    // Worker threads hold the columns: the first version refuses the swap, and Vite reloads the page.
    if (this.pool) return 'reload';
    // The hook may refuse (the editor, a prefab open unsaved): nothing touched, the game as it was. Before the
    // pause is taken: a playtest the hook ends stops the game, and the swap is not to start it again.
    if (this.onBeforeRebuild?.() === false) {
      console.info('[game] onBeforeRebuild refused the swap: reloading instead');
      return 'reload';
    }
    const running = this.running;
    this.pause();
    // A prefab file that will not compile fails here, before the world is touched. The kinds were
    // patched by the generation (ecs/component.ts), so a plain recompile finds them unchanged.
    try {
      compilePrefabs();
    } catch (err) {
      console.error('[game] a rebuild found a prefab that does not compile: reloading instead', err);
      // Nothing touched yet: the game goes on as it was until the reload.
      if (running) this.resume();
      return 'reload';
    }
    for (const u of this.uninstall) u();
    this.uninstall = [];
    let loaded: { skipped: string[]; updated?: string[] };
    try {
      const save = rebuildWorld(
        this.world,
        {
          // The installs after the game's systems, as at construction: the render systems in the same order.
          registerSystems: (world) => {
            next.registerSystems(world);
            for (const install of next.installs ?? []) this.uninstall.push(install(world));
          },
        },
        (world) => {
          // After the loop's reset, which dropped the page's own systems with the rest.
          this.installLoopSystems();
          this.uninstall = this.installViews(world);
        },
      );
      // A swapped entry's mapping maps from now on.
      this.loadOld = next.loadOldKinds ?? asItIs;
      loaded = this.load(save);
      this.world.warmPools();
    } catch (err) {
      // The world is reset by now, half built or half loaded: not resumed -- the reload brings it back.
      console.error('[game] a rebuild failed: reloading instead', err);
      return 'reload';
    }
    this.onRebuilt?.(loaded);
    if (running) this.resume();
    return 'swapped';
  }

  /**
   * The scene's half of an install, what the world's reset cannot know: `View`
   * wired to the scene, so an entity with one is drawn, and the engine's
   * `render` system, so an entity with a `Render` has its model made and
   * dressed -- a key in the data, a model from the assets (Docs/render.md §3),
   * a `Render.material` the store's shared material (§4), its views dressed
   * again when one is made anew (`onMaterialFiles`' `replaced`), a tint's clones
   * when one changes in place (`changed`) -- and, the game
   * stopped (the editor's, a pause), drawn once for any change to one, as an
   * edit the editor made is: a stopped game shows its kept frame otherwise.
   * Then the engine's `animate` system, so an entity with an `Animation` plays
   * its clip by name on its view's model (its `animations`, found by the view's
   * `assetKey`; Docs/render.md §5). And the engine's `cameras` system, so an
   * entity with a `Camera` is a three camera the game is drawn through
   * (`camera.ts`, Docs/camera.md). And, where the project has physics, the physics stage (`installPhysics`,
   * Docs/physics.md). Returns their uninstalls.
   */
  private installViews(world: World): (() => void)[] {
    const view = installView(world, this.scene);
    this.cameras = installCamera(world, { canvasSize: () => this.size });
    return [
      view,
      this.cameras.uninstall,
      installRender(world, {
        instance: (key, part) => Assets.instance(key as AssetKeys.Model, part),
        material: (key) => Assets.materialIfPresent(key),
        onMaterials: (told) => onMaterialFiles((change) => {
          if (change.replaced.length > 0 || change.changed.length > 0) told(change.replaced, change.changed);
          if (!this.running) this.renderOnce();
        }),
      }),
      installAnimation(world, { clips: (view) => clipsOf(view) }),
      // The physics stage (Docs/physics.md §5), over the one Ammo of the page: its bodies made from the components. Behind
      // the literal too, so a build with physics off carries not even the stage.
      ...(PHYSICS_BUILD && this.ammo ? [installPhysics(world, { ammo: this.ammo, ...PAGE_SOURCES })] : []),
    ];
  }

  /** The worker threads, once `startWorkers` has started some. */
  pool: WorkerPool | null = null;

  /**
   * Worker threads for the systems marked `parallel` (Docs/ecs.md §10). Only
   * on a cross-origin isolated page, where memory can be shared: anywhere else
   * this does nothing, and the game runs on one thread as it always can --
   * and none without `GameOptions.worker`, said once. Returns how many started.
   */
  async startWorkers(count: number): Promise<number> {
    if (count <= 0 || this.pool || !globalThis.crossOriginIsolated) return 0;
    const make = this.makeWorker;
    if (!make) {
      console.info('[ecs] no worker threads: the game was given no worker to make (GameOptions.worker)');
      return 0;
    }
    const links = Array.from({ length: count }, () => webWorker(make()));
    this.pool = await WorkerPool.start(this.world, links);
    return count;
  }

  /**
   * A saved game (`world.save()`) in place of the one running: the entities and
   * their data back, and their prefabs' models on them again (`onInstance`). A
   * scene saved before the game was on prefabs names its old kinds: mapped to
   * the prefabs' first (the entry's `loadOldKinds`). What the save mentions that this build
   * no longer has is skipped, and listed. A scene's or a level's save
   * (`sceneSave`, its instances' overrides in it) has every instance brought to
   * its prefab as compiled now (`refreshInstances`, Docs/prefabs.md §6), said in
   * `updated`; a game saved at runtime plays back as it was.
   */
  load(save: WorldSave): { skipped: string[]; updated?: string[] } {
    const mapped = this.loadOld(save);
    const loaded = this.world.load(mapped);
    const updated = refreshInstances(this.world, mapped);
    this.world.flush();
    if (!this.running) this.renderOnce();
    return updated.length > 0 ? { ...loaded, updated } : loaded;
  }

  /**
   * The camera the game is seen through, for picking and the pointer: the main `Camera` entity's
   * (`Camera.main`), else the built-in one -- the fallback's, or lent (`cameraControl`); the editor's
   * own (`viewOverride`) while it is up.
   * Its limit: the main camera's viewport rect is not taken into account -- a ray made from the
   * pointer's place over the whole canvas is right for a main camera drawn full canvas (the usual),
   * not for one drawn into a part of it (a split screen's half), where the caller maps the pointer
   * into its rect (`Camera.x y w h`) first.
   */
  get mainCamera(): THREE.Camera {
    // Each branch its own, nothing made: asked at every pointer event.
    if (this.viewOverride) return this.viewOverride;
    return gameCameraOf(this.cameras, this.camera, this.cameraControl !== null);
  }

  /**
   * The camera the game itself is seen through, whatever the editor draws through -- the built-in one while it is
   * lent (`cameraControl`), else the main `Camera` entity's, else the built-in one -- and that entity (0 for none):
   * what the studio's `view_shot` names as the main camera (Docs/mcp.md M4). One object, written over each call
   * (`gameViewScratch`): read it at once.
   */
  get gameView(): { readonly object: THREE.Camera; readonly entity: Entity } {
    const lent = this.cameraControl !== null;
    const main = lent ? (0 as Entity) : this.cameras.main();
    const object = main !== 0 ? this.cameras.object(main) : null;
    gameViewScratch.object = object ?? this.camera;
    gameViewScratch.entity = object ? main : (0 as Entity);
    return gameViewScratch;
  }

  /** Is the loop running? False while paused. */
  get isRunning(): boolean {
    return this.running;
  }

  resume(): void {
    if (this.running) return;
    this.running = true;
    // The pause is not counted, and what was pressed during it is not an edge.
    this.loop.resume();
    this.raf = requestAnimationFrame(this.tick);
  }

  pause(): void {
    if (!this.running) return;
    this.running = false;
    cancelAnimationFrame(this.raf);
    // The frame the world stops on, kept for `present`.
    this.drawFrame();
  }

  /**
   * One 60 Hz tick while paused (the editor's F10, the pill's Step): every
   * system due at it, the commands applied at its boundary, then drawn with the
   * interpolation at 1 -- the loop's `step`, no real time counted. Nothing while
   * running. A tick that throws goes to `onFrameError` as a frame's would, and
   * the world is drawn as the tick left it.
   */
  step(): void {
    if (this.running) return;
    try {
      this.loop.step();
    } catch (err) {
      this.frameFailed(err);
      this.loop.present();
    }
    this.drawFrame();
  }

  /**
   * One frame without advancing anything: the first frame, a resize while
   * stopped, a change the editor made. The render systems run with no time
   * passed, so what changed while stopped is what is drawn.
   */
  renderOnce(): void {
    this.loop.present();
    this.drawFrame();
  }

  /**
   * The stopped world on the canvas again, without drawing it: one copy of the
   * kept frame, then `onDrawn`. With none kept -- the first call, or after a
   * resize -- the world is drawn once, and kept. Nothing while running: the
   * loop's own frame calls `onDrawn`.
   */
  present(): void {
    if (this.running) return;
    if (this.kept.show(this.renderer)) this.onDrawn?.(false);
    else this.drawFrame();
  }

  /**
   * One frame drawn onto the canvas for an image of it, which `copy` takes off in the same task -- then the
   * frame on the screen put back: drawn again as the loop draws it while running, the kept one shown while stopped,
   * so nobody sees it. The world as a frame draws it (`drawWorld`) through `camera` in place of whatever it is seen
   * through now -- null: the game's own, the built-in camera while lent or each `Camera` by its plan, rects and
   * clears -- then what is drawn over it (`onDrawWorld`) if `over`, and the UI (`onDrawn`) if `ui`. The editor's
   * `view_shot` (Docs/mcp.md M4), which copies the part of the canvas `copy` is given: through the game's own cameras
   * the frame (`frame`), a resolution's box, drawn as the screen draws it; through `camera` the whole room at the
   * screen's sharpness, no box and no Pixel or Stretch target (`shotArea`), drawn over all of it, so its aspect is the
   * image's.
   */
  drawOnce<T>(camera: THREE.Camera | null, over: boolean, ui: boolean, copy: (rect: Readonly<FrameRect>) => T): T {
    const r = this.renderer;
    const override = this.viewOverride;
    const target = r.getRenderTarget();
    const area = shotArea(this.room, this.framed, this.resolution, camera !== null);
    this.viewOverride = camera;
    try {
      r.setRenderTarget(null);
      this.drawInto(0, 0, this.whole.width, this.whole.height, false);
      this.drawWorld(area.rect, area.scaled ? this.scaled : null);
      if (over) this.onDrawWorld?.(r);
      if (ui) this.onDrawn?.(true);
      return copy(area.rect);
    } finally {
      this.viewOverride = override;
      r.setRenderTarget(target);
      if (this.running) this.drawFrame();
      else this.present();
    }
  }

  private tick = (now: number): void => {
    if (!this.running) return;
    this.raf = requestAnimationFrame(this.tick);
    this.debug?.begin();
    try {
      this.loop.frame(now);
    } catch (err) {
      this.frameFailed(err);
    }
    this.drawFrame();
    this.debug?.end();
  };

  private frameFailed(err: unknown): void {
    // A tick's own, or one from the input or render phase: no system named.
    const last = this.loop.failure;
    const failure: TickFailure = last !== null && last.error === err ? last : { system: null, tick: this.loop.tick, error: err };
    if (this.onFrameError) {
      this.onFrameError(failure);
      return;
    }
    if (this.saidFailure) return;
    this.saidFailure = true;
    console.error(`[game] ${failure.system ? `the system '${failure.system}'` : 'a frame'} threw on tick ${failure.tick} (said once; the game runs on)`, err);
  }

  /** The world drawn -- straight to the screen while running, kept while stopped -- then the UI over it. */
  private drawFrame(): void {
    if (this.running) {
      this.kept.drop();
      this.paint();
    } else {
      this.kept.draw(this.renderer, this.paint);
    }
    this.onDrawn?.(true);
  }

  /**
   * The world through whatever it is seen through now: `viewOverride` (the editor's), else the
   * built-in camera while it is lent (`cameraControl`), the whole frame; else each of the game's `Camera`s by
   * depth into its viewport rect of the frame; else the built-in camera, the fallback. What each camera draws
   * where is `drawPlan`'s (`camera.ts`, tested there); this only applies it. A frame that is not the whole
   * canvas: the canvas cleared to `outside` first -- the room round a resolution's box to `letterbox` -- and
   * everything scissored to the frame. A Pixel or Stretch resolution: the world drawn into its target, whole,
   * then the target onto the box. `f` and `into` another rect and target than the frame's: `drawOnce`'s.
   */
  private drawWorld(f: Readonly<FrameRect> = this.framed, into: THREE.WebGLRenderTarget | null = this.scaled): void {
    const r = this.renderer;
    const room = this.room;
    const canvasW = this.whole.width;
    const canvasH = this.whole.height;
    const part = !isWhole(f, canvasW, canvasH);
    const left = f.x;
    const bottom = frameBottom(f, canvasH);
    if (part) {
      // Outside the frame: the page's colour, never last frame's leftovers. Its depth too, cleared with it. Cleared by
      // drawing an empty scene, not by `clear()`: into the kept frame's target, multisampled, only a draw resolves into
      // its texture -- and a draw's resolve is scissored like the draw, so the frame's own would never reach outside it.
      // The room round a resolution's box, its bars, the same way: scissored to the room, so resolved there.
      const roomWhole = isWhole(room, canvasW, canvasH);
      this.fill(roomWhole ? this.letterbox : this.outside, 0, 0, canvasW, canvasH, false);
      if (!roomWhole && (room.width !== f.width || room.height !== f.height)) this.fill(this.letterbox, room.x, frameBottom(room, canvasH), room.width, room.height, true);
    }
    if (into === null) {
      this.drawCameras(left, bottom, f.width, f.height, part);
      return;
    }
    // Pixel, Stretch: the world into the target, all of it, as into a canvas of its size -- then the target onto the box.
    const screen = r.getRenderTarget();
    r.setRenderTarget(into);
    this.drawInto(0, 0, into.width, into.height, false);
    this.drawCameras(0, 0, into.width, into.height, false);
    r.setRenderTarget(screen);
    this.drawInto(left, bottom, f.width, f.height);
    this.blit.uniforms.scaledColor!.value = into.texture;
    const autoClear = r.autoClear;
    r.autoClear = false;
    r.render(this.blitScene, this.blitCamera);
    r.autoClear = autoClear;
    this.drawInto(0, 0, canvasW, canvasH, false);
  }

  /** `color` over the rect (CSS pixels from the canvas's bottom left; `scissor` false: the whole canvas), by an empty draw. */
  private fill(color: THREE.Color, x: number, y: number, w: number, h: number, scissor: boolean): void {
    const r = this.renderer;
    r.getClearColor(this.clearWas);
    const was = r.getClearAlpha();
    const autoClear = r.autoClear;
    this.drawInto(x, y, w, h, scissor);
    r.setClearColor(color, 1);
    r.autoClear = true;
    r.render(this.nothing, this.camera);
    r.autoClear = autoClear;
    r.setClearColor(this.clearWas, was);
    if (scissor) this.drawInto(0, 0, this.whole.width, this.whole.height, false);
  }

  /**
   * The cameras' part of `drawWorld`, into the rect `left`, `bottom`, `width` × `height` of what is bound -- the canvas
   * (or the kept frame's target), scissored to it if `part`; or a resolution's target, all of it.
   */
  private drawCameras(left: number, bottom: number, width: number, height: number, part: boolean): void {
    const r = this.renderer;
    const override = this.viewOverride ?? (this.cameraControl ? this.camera : null);
    const list = override ? null : this.cameras.camerasToDraw();
    if (override || list!.length === 0) {
      if (part) this.drawInto(left, bottom, width, height);
      r.render(this.scene, override ?? this.camera);
      if (part) this.drawInto(0, 0, this.whole.width, this.whole.height, false);
      return;
    }
    const scene = this.scene;
    const plan = drawPlan(list!, this.world.store(Camera), this.size.width, this.size.height, this.plan, left, bottom);
    const background = scene.background;
    const autoClear = r.autoClear;
    r.getClearColor(this.clearWas);
    const alpha = r.getClearAlpha();
    // The shadow maps drawn once a frame, by the first camera: they do not depend on which camera looks.
    const shadowsAuto = r.shadowMap.autoUpdate;
    // What no camera's rect covers: black, never last frame's leftovers -- in the frame.
    if (part) this.drawInto(left, bottom, width, height);
    r.setClearColor(0x000000, 1);
    r.clear();
    for (let i = 0; i < plan.count; i++) {
      const step = plan.steps[i]!;
      const object = this.cameras.object(step.entity);
      if (object === null) continue;
      this.drawInto(step.x, step.y, step.w, step.h);
      const clear = step.clear;
      if (clear === 2) {
        // The scene's own background (sky): three clears to it -- with none, to the clear colour the
        // renderer had, not the black above or an earlier camera's colour.
        scene.background = background;
        r.setClearColor(this.clearWas, alpha);
        r.autoClear = true;
      } else if (clear === 1) {
        scene.background = null;
        r.setClearColor(step.color, 1);
        r.autoClear = true;
      } else {
        // None: drawn over what is there, its depth alone cleared, so it is not hidden behind another camera's.
        scene.background = null;
        r.autoClear = false;
        r.clearDepth();
        r.clearStencil();
      }
      r.render(scene, object);
      if (r.shadowMap.enabled) r.shadowMap.autoUpdate = false;
    }
    r.shadowMap.autoUpdate = shadowsAuto;
    scene.background = background;
    r.autoClear = autoClear;
    r.setClearColor(this.clearWas, alpha);
    this.drawInto(0, 0, this.whole.width, this.whole.height, false);
  }

  /**
   * What is drawn next goes into this rect of the canvas, in CSS pixels from its bottom left, scissored
   * (`scissor` false: the whole of it again, no scissor). On the screen the renderer's own viewport and
   * scissor; into the kept frame's target (`KeptFrame.draw`), the target's -- three puts a target's
   * viewport back from the target itself whenever it binds it again, as the shadow pass does mid-render,
   * so the renderer's would be lost there. Into a resolution's target (`scaled`), the rect is its own pixels.
   */
  private drawInto(x: number, y: number, w: number, h: number, scissor = true): void {
    const r = this.renderer;
    const target = r.getRenderTarget();
    if (target === null) {
      r.setViewport(x, y, w, h);
      r.setScissor(x, y, w, h);
      r.setScissorTest(scissor);
      return;
    }
    const ratio = target === this.scaled ? 1 : r.getPixelRatio();
    if (scissor) target.viewport.set(Math.round(x * ratio), Math.round(y * ratio), Math.round(w * ratio), Math.round(h * ratio));
    else target.viewport.set(0, 0, target.width, target.height);
    target.scissor.copy(target.viewport);
    target.scissorTest = scissor;
    r.setRenderTarget(target);
  }

  private placeCamera(): void {
    const r = 6;
    this.camera.position.set(Math.sin(this.orbit) * r, 3.2, Math.cos(this.orbit) * r);
    this.camera.lookAt(0, 0.5, 0);
  }

  /**
   * Drag to turn the built-in camera: the fallback's alone -- a game with a
   * `Camera` entity moves it by its own systems, and a press is left to them.
   * Presentation, so straight from the events rather than through the loop's
   * stamped input -- which is for what the simulation reads. And the pattern for
   * `pointerClaim`: a press the UI takes is not a drag.
   */
  private bindCamera(canvas: HTMLCanvasElement): void {
    const claimed = (e: PointerEvent): boolean => this.pointerClaim?.(e) ?? false;
    let dragging: { id: number; x: number } | null = null;
    canvas.addEventListener('pointerdown', (e) => {
      if (claimed(e) || !this.running || this.cameras.camerasToDraw().length > 0) return;
      // Outside the frame is not the game's (Docs/game-view.md §2).
      const at = canvas.getBoundingClientRect();
      if (!framePoint(e.clientX - at.left, e.clientY - at.top, this.framed, this.local)) return;
      // A finger on the world is the game's: no scroll, no zoom, no long-press menu.
      e.preventDefault();
      dragging = { id: e.pointerId, x: e.clientX };
      canvas.setPointerCapture(e.pointerId);
    });
    canvas.addEventListener('pointermove', (e) => {
      if (claimed(e) || !dragging || dragging.id !== e.pointerId) return;
      const dx = e.clientX - dragging.x;
      dragging.x = e.clientX;
      this.orbit -= dx * 0.008;
      this.orbitSpin = -dx * 0.5;
    });
    const end = (e: PointerEvent): void => {
      claimed(e);
      if (dragging?.id === e.pointerId) dragging = null;
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
  }

  /**
   * The rect of the canvas the game is drawn in, CSS pixels from its top left: the whole canvas unless
   * `setFrame` gave one (Docs/game-view.md §2). The same object always, written over as it changes: read
   * it when it is needed.
   */
  get frame(): Readonly<FrameRect> {
    return this.framed;
  }

  /**
   * The game drawn into `rect` of the canvas (CSS pixels from its top left), or the whole canvas again for
   * null. Cut to the canvas, in whole pixels (`frameIn`). The cameras' viewports, the built-in camera's
   * aspect, the pointer and the canvas UI all follow it; the canvas outside it is cleared to `outside`. A
   * stopped game is drawn again at once, as on a resize. The editor's scene room; a release build never
   * sets one.
   */
  setFrame(rect: Readonly<FrameRect> | null): void {
    this.given = rect === null ? null : { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
    if (this.placeFrame() && !this.running) this.renderOnce();
  }

  /**
   * The game shaped inside its frame (Docs/game-view.md §4): `r` a resolution -- exactly `width` × `height` drawn
   * Fit, Pixel or Stretch, or an aspect alone, Fit -- or null for the frame as it is. The box it fits in the frame is
   * the frame from then on, for everything `setFrame` says; the rest of the frame is the bars (`letterbox`). Pixel and
   * Stretch draw the world into a target of exactly its pixels -- the cameras' viewports and the pointer measure it
   * (`pixels`) -- the UI the box. A stopped game is drawn again at once. The editor's preview; a release build never
   * sets one.
   */
  setResolution(r: GameResolution | null): void {
    this.resolution = r === null ? null : { ...r };
    if (this.placeFrame() && !this.running) this.renderOnce();
  }

  /**
   * The frame's size in the game's pixels: the frame's own, or a Pixel or Stretch resolution's -- what `Camera`
   * viewport fractions multiply and the loop's pointer is measured in. The same object always.
   */
  get pixels(): Readonly<{ width: number; height: number }> {
    return this.size;
  }

  /**
   * Device pixels (the renderer's) per game pixel for a Pixel or Stretch resolution -- Pixel's whole number (`×3`, at
   * any pixel ratio), Stretch's factor -- and 1 for Fit and for none, drawn at the screen's own sharpness.
   */
  get scale(): number {
    return this.boxScale;
  }

  /**
   * The frame in effect worked out again on the canvas as it is -- the room given, the resolution's box in it -- the
   * game's pixels, a Pixel or Stretch target of their size, and the built-in camera's aspect from them. True if any moved.
   */
  private placeFrame(): boolean {
    frameIn(this.given, this.whole.width, this.whole.height, this.room);
    const p = this.placing;
    const r = this.resolution;
    this.boxScale = fitBox(this.room, r, p, this.renderer.getPixelRatio());
    const f = this.framed;
    const scaled = drawsScaled(r);
    const w = scaled ? r.width : p.width;
    const h = scaled ? r.height : p.height;
    const moved = f.x !== p.x || f.y !== p.y || f.width !== p.width || f.height !== p.height || this.size.width !== w || this.size.height !== h;
    const target = this.targetFor(scaled ? r : null);
    if (!moved && !target) return false;
    f.x = p.x;
    f.y = p.y;
    f.width = p.width;
    f.height = p.height;
    this.size.width = w;
    this.size.height = h;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    return true;
  }

  /**
   * Pixel's or Stretch's target made for `r` -- its size, its filter (Pixel's always nearest) -- or let go for none.
   * True if it changed. Not multisampled: its texture is read as it is, a pixel a pixel.
   */
  private targetFor(r: { readonly width: number; readonly height: number; readonly mode: 'pixel' | 'stretch'; readonly filter: 'nearest' | 'linear' } | null): boolean {
    const now = this.scaled;
    if (r === null) {
      if (now === null) return false;
      now.dispose();
      this.scaled = null;
      return true;
    }
    const filter = r.mode === 'pixel' || r.filter === 'nearest' ? THREE.NearestFilter : THREE.LinearFilter;
    if (now && now.width === r.width && now.height === r.height && now.texture.magFilter === filter) return false;
    now?.dispose();
    // sRGB storage, as the kept frame's: eight bits a channel without banding, decoded on sampling.
    this.scaled = new THREE.WebGLRenderTarget(r.width, r.height, { colorSpace: THREE.SRGBColorSpace, minFilter: filter, magFilter: filter });
    return true;
  }

  /**
   * The drawing buffer to the canvas's size. **The canvas stays full size**:
   * to hold a frame rate, draw the world into a smaller target and stretch it
   * over the canvas -- never shrink the canvas, or the UI goes soft with it.
   * The frame cut to the new size, and the built-in camera's aspect from it;
   * each `Camera`'s from its viewport rect on the frame, by the `cameras`
   * system as the next frame is drawn (now, if stopped: `renderOnce`).
   */
  private resize(): void {
    const canvas = this.renderer.domElement;
    const width = canvas.clientWidth || innerWidth;
    const height = canvas.clientHeight || innerHeight;
    this.whole.width = width;
    this.whole.height = height;
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, MAX_PIXEL_RATIO));
    this.renderer.setSize(width, height, false);
    this.placeFrame();
    if (!this.cameraControl) this.placeCamera();
    if (!this.running) this.renderOnce();
  }
}
