/// <reference path="./env.d.ts" preserve="true" />
/**
 * @vibe/engine: the engine, what a project imports (Docs/squidwright-plan.md §3). Nothing here
 * imports a project's generated globs: the project hands them in from its generated bundles
 * (`src/assets/prefab-bundle.ts` calls `usePrefabFiles` here, `src/assets/uids.ts` `useUids`; `src/assets/bundle.ts` calls
 * `useBundle` of `@vibe/engine/assets` for the registry, the scenes, the levels and the packs).
 *
 *   ecs/index.ts                                   the ECS: components, the world, commands, prefabs, overrides (Docs/ecs.md)
 *   prefab untypedPrefab                           a prefab's token by key: checked against AssetKeys, or any string (the editor's, tests')
 *   WorkerPool webWorker                           parallel systems on worker threads (Docs/ecs.md §10)
 *   Loop TICK_HZ RATES Rng                         the update loop (Docs/loop.md)
 *   attachDevices isTyping                         keyboard, pointer, gamepads -> the loop's input
 *   View attach installView                        three.js as a view of the ECS (`view.ts`)
 *   installRender                                  the engine's `render` system: `Render` drawn (`render.ts`, Docs/render.md)
 *   installCamera CameraState                      the engine's `cameras` system: each `Camera` a three camera (`camera.ts`, Docs/camera.md)
 *   installAnimation                               the engine's `animate` system: `Animation` played (`animation.ts`, Docs/render.md §5)
 *   RigidBody BoxCollider ... physicsOf            physics: its components, settings and handle; `installPhysics` the stage over Ammo (`physics/`, Docs/physics.md)
 *   KeptFrame MusicFades                           the stopped frame; music faded with the pause
 *   FrameRect frameIn framePoint fitBox ...        the game's frame: the rect of the canvas it is drawn in (`frame.ts`, Docs/game-view.md §2)
 *   GameResolution drawsScaled framePixels         a resolution's box in it, drawn Fit or into a target (Pixel, Stretch), the pointer in its pixels (§4)
 *   DebugActions keyLabel keysOf                   debug actions' words, pure (MrDebug itself: `@vibe/engine/debug`)
 *   caseKey sync Atlas resolveBeside unzip ...     the asset store and its pure helpers
 *   Prefabs usePrefabFiles onPrefabFiles ...       the project's prefab files, compiled (`prefabs.ts`)
 *   useUids keyOfUid uidOf resolveRef keyRef ...   every asset's uid -> its kind and key; a file's { uid, key } read and written (`assets/uids.ts`, Docs/asset-ids.md §2)
 *   useMaterialFiles compileMaterials ...          the project's material files, each one shared three material (`assets/materials.ts`)
 *   parseMaterialFile materialDiff ...             a material file's format, pure (`assets/material-file.ts`; also `/material-file`)
 *   clipInfo extrasOntoClips                       a clip's loop, length and rate from Gladius's glTF extras, pure (`assets/clip-info.ts`)
 *   scene startScene useSceneFiles ...             the project's scene files (`scenes.ts`)
 *   data dataKeys useData onDataFiles level ...    the data kinds' files: the levels, a project's own kinds (`data.ts`)
 *   GameEntry LiveGame                             types: a project's game entry, and its swap boundary (`@vibe/engine/boot`)
 *
 * Subpaths, for what this index must not carry: `/testing` (node's), `/rules` (the source checks a
 * project's tests run), `/node` (prefab files from disk, node's), `/worker` (a worker thread's entry),
 * `/hot`, `/case-key` and `/material-file` (pure, for node's side: the pipeline), `/debug` -- MrDebug, which reads
 * `DEBUG_BUILD` and the page's URL as it loads, so a node test that imports this index never loads it
 * -- `/assets`: `Assets`, `Audio`, the registry and `useBundle`, the page's asset runtime, which
 * reads `DEBUG_BUILD` too (`assets/runtime.ts`); `/boot`: `Game` (three at load) and the game's swap
 * boundary's code (`liveGame`); `/ui`: the canvas UI (pixi at load).
 */
export * from './ecs/index.ts';
// The typed token wins over the ECS's untyped `prefab` that `export *` would bring: a game's key is checked.
export { prefab, type ComponentsOf, type Node, type NodeName, type Prefab, type PrefabKey, type PrefabPart, type PrefabRoot, type ViewsAreModels, type MaterialsAreMaterials } from './prefab-token.ts';
export { prefab as untypedPrefab, PREFAB_KEYS, keyProblem, type CompileOptions, type KeyShape } from './ecs/prefab.ts';
export { WorkerPool, webWorker, type PoolOptions, type WorkerInit, type WorkerLink } from './ecs/parallel.ts';

// The loop.
export {
  Loop, CYCLE, RATES, STEP, TICK_HZ, periodOf, InputState, InputView, Rng, Members,
  type InputContext, type InputSink, type InputSystem, type LoopHooks, type LoopOptions, type LoopState, type Phase, type Rate,
  type RenderContext, type RenderSystem, type SimulationContext, type SimulationSystem, type System, type SystemInfo, type TickFailure,
} from './loop/index.ts';

// The input.
export { attachDevices, isTyping, type Devices } from './input/devices.ts';

// The view, the stopped frame, the music's fades.
export { View, ViewState, attach, entityOf, installView, swapView, type ViewOptions, type ViewScene } from './view.ts';
export { installRender, type RenderOptions } from './render.ts';
export { CameraState, installCamera, type CameraOptions, type Cameras, type CanvasSize, type GameCamera } from './camera.ts';
export { installAnimation, type AnimationOptions } from './animation.ts';

// Physics (Docs/physics.md): the components, the project's settings and the handle, pure; the stage over Ammo is
// `installPhysics`, which takes the Ammo the caller loaded (the page's `boot()`, node's `loadAmmo` in `/physics-node`).
export {
  BallJoint, BodyType, BoxCollider, CapsuleCollider, CharacterController, CharacterHit, CharacterLanded, COLLIDERS, CollisionEnter, CollisionExit, CollisionStay, ConeCollider,
  ConeTwistJoint, ContactEvents, CylinderCollider, FixedJoint, Forces, ForceSpace, HeightfieldCollider, HingeJoint, HullCollider, JointBroke, JOINTS, LockAxes, MeshCollider,
  PlaneCollider, physicsLayer, RigidBody, ShapeAxis, SixDofJoint, SliderJoint, SphereCollider, SpringAxes, STILL_ONLY, TriggerEnter, TriggerExit, TriggerStay,
} from './physics/components.ts';
export { COMBINES, combine, combineIndex, parsePhysicsMaterial, PHYSICS_MATERIAL_DEFAULTS, type Combine, type PhysicsMaterialFile } from './physics/material-file.ts';
export { PHYSICS_DEFAULTS, onPhysicsSettings, physicsSettings, usePhysicsSettings, type PhysicsMaterialValues, type PhysicsSettings } from './physics/settings.ts';
export { ALL_LAYERS, boxProbe, capsuleProbe, INERT, impulseAt, physicsOf, RayHit, RayHits, sphereProbe, type Physics, type PhysicsStats, type Probe } from './physics/service.ts';
export { installPhysics, type HeightData, type MeshData, type PhysicsOptions } from './physics/bridge.ts';
export type { AmmoApi } from './physics/ammo-types.ts';
export { KeptFrame } from './still.ts';
export { drawsScaled, fitBox, frameBottom, frameIn, framePixels, framePoint, isWhole, type FrameRect, type GameResolution } from './frame.ts';
export { MusicFades, type FadeClock, type FadeParam } from './music-fade.ts';

// Debug actions' words: pure, no DOM (MrDebug, which is not, is `@vibe/engine/debug`).
export { DebugActions, OFF, chord, isMac, keyLabel, keysOf, modName, pressed, type DebugAction, type DebugRouter, type KeyPress } from './debug/actions.ts';

// The asset store and its helpers.
export { caseKey, type AnyCase } from './assets/case-key.ts';
export { sync, syncMap, type KeysChange, type KeysListener, type Maps } from './assets/hot.ts';
export {
  addAtlas, addModel, addTexture, atlases, decodeModel, decodeTexture, disposeModel, drop, finishTexture, forget, models, mountedPacks,
  onModelReplaced, refill, replaceModel, replaceTexture, sizeOf, textures, urlForBytes, useRenderer, type Resolve, type Source, type TextureUse,
} from './assets/store.ts';
export { Atlas, type Frame } from './assets/atlas.ts';
export { fileName, folderOf, resolveBeside, type Lookup } from './assets/beside.ts';
export { unzip, type ZipFiles } from './assets/zip.ts';
export {
  addPackMaterials, compileMaterials, dropMaterials, hasMaterialFile, materialFile, materialFiles, materialIfPresent, materialKeys, materialName,
  materialProblems, materialsStamp, onMaterialFiles, showMaterial, useMaterialFiles, type MaterialsChange,
} from './assets/materials.ts';
export {
  FIELD_KIND, FIELDS_OF, MATERIAL_DEFAULTS, MATERIAL_FIELDS, MATERIAL_MAPS, MATERIAL_SIDES, MATERIAL_TYPES, NUMBER_RANGE, PHYSICAL_FIELDS, colourText,
  materialDiff, materialMaps, materialSet, materialText, newMaterial, parseMaterialFile, usesField,
  type FieldKind, type MaterialDiff, type MaterialField, type MaterialFile, type MaterialMap, type MaterialSide, type MaterialType, type ParsedMaterial, type PhysicalFields,
} from './assets/material-file.ts';
export { Generations, Unmounted, staleZips } from './assets/pack-mounts.ts';
export { clipInfo, DEFAULT_FPS, extrasLoop, extrasOntoClips, type ClipExtras, type ClipInfo } from './assets/clip-info.ts';

// The project's data files, handed in by its generated bundles: pure, no glob, no three.js.
export { Prefabs, onPrefabFiles, prefabFiles, prefabName, usePrefabFiles } from './prefabs.ts';
export { keyKinds, soundKind, useKeyTypes } from './assets/kind-keys.ts';
export { dropUids, isKeyRef, keyOfUid, keyRef, meshRef, mountUids, ofKind, refText, resolveRef, staleRef, uidKeys, uidOf, useUids, type KeyRef, type UidRow } from './assets/uids.ts';
export { onSceneFiles, scene, sceneIfPresent, sceneKeys, sceneName, startScene, useSceneFiles, type SceneFile } from './scenes.ts';
export { data, dataIfPresent, dataKeys, level, levelKeys, onDataFiles, useData, useLevels } from './data.ts';

// The game's entry, the one shape a project's `src/game/index.ts` exports; its boundary's code is `@vibe/engine/boot`.
export type { GameEntry } from './game.ts';
export { NOT_FETCHED, type LiveGame } from './live-game.ts';
