---
skill: engine
title: Audio
when: Before playing a sound or music, adding audio files, or touching mute and volumes
covers:
  modules: [audio.ts, music-fade.ts]
order: 80
---
# Audio: sounds, music, one mute

Every sound goes through **`Audio`** from `@vibe/engine/assets` -- never `new Audio()`, never an `AudioContext` of
the game's own. One context, three buses (music, sfx, ui) under a master, and one switch that silences them all.
The code is `node_modules/@vibe/engine/src/audio.ts`.

## The files

| Folder | Key | Played with | How |
|---|---|---|---|
| `src/assets/audio/sfx/` | `pickup` | `Audio.sfx('pickup')` | short game sounds, decoded into memory at the loading bar: they land on the frame asked |
| `src/assets/audio/ui/` | `click` | `Audio.ui('click')` | clicks and menu sounds, on the ui bus |
| `src/assets/audio/music/` | `beach` | `Audio.music('beach')` | long tracks, streamed, looping |

The masters (`.wav`, `.flac`, `.aif`) go in `AssetsSource/audio/sfx/`, `ui/` or `music/` and are exported as
`.ogg` -- a sound made mono when its two channels are the same and its leading silence trimmed, music kept as it
is ([the assets page](assets.md) has the options). An `.ogg`, `.opus`, `.mp3` or `.m4a` delivered as it is may
go straight into `src/assets/audio/`. A pack's are `'reef:bubble'`.

## Playing

```ts
import { Audio } from '@vibe/engine/assets';

export function playTheme(track: AssetKeys.Music, hit: AssetKeys.Sfx, hum: AssetKeys.Sfx): void {
  Audio.music(track);                                  // cross-faded from what was playing; Audio.music(null) fades out
  Audio.sfx(hit, { volume: 0.8, rate: 0.95 });         // a rate a little off 1 keeps a repeated sound alive
  const engine = Audio.loop(hum, 0.5);                 // round and round; null before the first gesture
  engine?.stop(0.3);                                   // faded out over 0.3 s
}
```

- **Nothing sounds before the first gesture**: browsers refuse to start audio until a tap, click or key, which
  `boot()` waits for (`Audio.unlock()`). Until then every `play` is a silent no-op, never an error; music asked for
  starts once it can. `Audio.running` says whether it has.
- **Volumes** are `Audio.setVolumes({ master, music, sfx })`, 0 to 1 -- fed from the player's settings.
- A key is checked by the typecheck (`AssetKeys.Sfx`, `UiSfx`, `Music`), in any case.

## From the game: a render system, on events

Audio is presentation, not simulation: a sound never changes what the game decides, and a simulation system
takes its chance and time from the loop -- a sound picked or pitched there would be a side effect of the tick.
So **a simulation system emits an event, and a render system plays it** -- installed page-side through the game
entry's `installs`, in a module of its own that `systems.ts` does not import (a game's worker threads, which run
only its `parallel: true` systems -- and those cannot emit events -- import `systems.ts`, and have no audio):

```ts
// src/game/sounds.ts
import type { World } from '@vibe/engine';
import { Audio, type PlayOptions } from '@vibe/engine/assets';
import { Hopped } from './components.ts';

/** Reused for every play: a system allocates nothing. */
const PLAY: PlayOptions = { volume: 1, rate: 1 };

/** A hop's sound for each `Hopped`: a page-side install (the entry's `installs`), never in the worker. */
export function hopSounds(sound: AssetKeys.Sfx): (world: World) => () => void {
  return (world) => {
    const hops = world.events(Hopped);
    world.system({
      name: 'hop-sounds',
      phase: 'render',
      update(ctx) {
        for (let i = hops.begin(ctx); i < hops.end; i++) {
          PLAY.rate = 0.9 + Math.random() * 0.2;       // render code may use Math.random
          Audio.sfx(sound, PLAY);
        }
      },
    });
    return () => {};                                   // a rebuild drops the system itself
  };
}
```

and in `src/game/index.ts`, `export const installs = [hopSounds('hop')];` beside `registerSystems` and `populate`. A
render system reads the events of every tick since the last frame, each once.

## Mute

**`updateMute()` in the engine's `boot()` is the one place that decides whether the game makes sound**: the tab
hidden, or the player's own mute (the HUD's sound button, `actions.toggleSound()`). It pauses the music as well as
zeroing the master, so a background tab streams nothing. Never call `Audio.setMuted` from the game: a new reason
for silence (a portal's ad break) is a condition added to that one place, never a second switch. `Audio.isMuted`
reads it.

## The rules that bite

- Never `new Audio()`, never a Web Audio graph of the game's own.
- Never play a sound from a simulation system: an event, then a render system.
- Short sounds in `sfx/` or `ui/`, long ones in `music/`: a two-minute track decoded into memory costs tens of
  megabytes.
- A node test imports `@vibe/engine/assets` as types only.
