---
skill: engine
title: Debug keys and debug code
when: Before adding a debug key or button, writing code only debug builds should have, or a module with a top-level side effect
covers:
  modules: [debug/, boot-steps.ts, env.d.ts]
order: 90
---
# Debug keys and debug code: MrDebug, `DEBUG`, `probing()`

Debug tools live in debug builds only -- the dev server, and `npm run build:debug` -- and a release build carries
none of them: not hidden, gone. Three things keep it so: every debug key and button goes through **MrDebug**,
debug code is gated by a **literal `DEBUG`** in its own module, and the build fails if any of the editor reaches a
release. The code is `node_modules/@vibe/engine/src/debug/` (`mr-debug.ts`, `actions.ts`).

## A debug key: `MrDebug.add`

```ts
import type { Game } from '@vibe/engine/boot';
import { MrDebug } from '@vibe/engine/debug';

const DEBUG = DEBUG_BUILD && MrDebug.on;

/** The game's own debug keys: called from main.ts's boot({ setup }). */
export function addCheats(game: Game): void {
  if (DEBUG) {
    MrDebug.add({
      name: 'slow motion',
      key: 'KeyO',
      help: 'Game time at a quarter, or back to normal',
      run: () => {
        game.loop.timeScale = game.loop.timeScale === 1 ? 0.25 : 1;
      },
    });
  }
}
```

One registration gives the key **and** its button in the debug panel, under one switch (`MrDebug.enabled`, the
panel's top checkbox) that turns every debug key and button off at once.

- **`key`** is a `KeyboardEvent.code` (`'KeyO'`, `'F2'`) or a chord -- `'Mod+KeyZ'`, `'Mod+Shift+KeyZ'`,
  `'Shift+KeyD'`, `Mod` being Cmd on a Mac and Ctrl elsewhere -- or a list of them. `'Ctrl+...'` is the Ctrl key
  itself on a Mac and the same as `Mod` elsewhere (`['Mod+Numpad1', 'Ctrl+Numpad1']`: Cmd or Ctrl on a Mac, one key
  elsewhere). A chord matches only its exact modifiers. Leave `key` out for a button alone.
- **A key MrDebug takes goes nowhere else**: not into the game's input, not to the browser. With debug off -- or no
  action on it -- it falls through to the game as if MrDebug were not there (`P` is then the pause key).
- **`when: () => boolean`**: live only while it says so. **`hold: true`**: `run` as the key goes down, `release` as it
  comes up or the window loses the focus (a key's repeat runs neither); `MrDebug.held(code)` says what is down now.
  **`field: '<name>'`**: a key only while typing into an element marked `data-keys-field="<name>"` (or inside one),
  and nowhere else; every other action ignores keys typed into a field. **`anywhere: true`**: an action of no field
  taken while typing too -- for a key no field may have (F5); a field's own action on that key still comes first in
  its field.
- `MrDebug.add` returns its removal (a function that takes the action off again), and throws on a name taken, on a
  key that is no `KeyboardEvent.code` or chord, or on a key another action always shares in the same place -- two
  actions on one key need a `when` each, and the first live one wins. `MrDebug.clashes(action)` says, without adding,
  each key `add` would refuse it for, and whose action holds it.
- **The editor's keys** (studio mode) are actions too, each with a `when`, registered after the game's. A game's key with
  no `when` on one of them -- Shift+A, the editor's walk -- never stops the editor: its action gives up that key (it keeps
  its others) and a notice says so, naming both and the key. `npm test`'s `keys` check fails on such a key first; give it another key, or a
  `when`. A game's key with a `when` keeps it while that holds, in the editor too (the check notes it).
- **Never** `addEventListener('keydown')` for a debug key, never a `DEBUG && e.code === ...` check, never a lil-gui
  button of your own, never a `keyup` of your own. `npm test`'s `routes` check fails on each.

## Debug code: a literal `DEBUG` in each module

```ts
import { MrDebug } from '@vibe/engine/debug';

const DEBUG = DEBUG_BUILD && MrDebug.on;     // at the top of every module that has debug code

if (DEBUG) console.info('[game] debug tools on');
```

`DEBUG_BUILD` is a constant the build writes into every module as `true` or `false`; `MrDebug.on` is whether this
page has debug tools (always on the dev server; `?debug` in a debug build). The bundler folds `if (false)` away --
but **only for a constant written in the same module**: a `DEBUG` exported from one module and imported by
another keeps its branch, and a release would download the debug code. So:

- **Never import a `DEBUG` flag** (the `routes` check fails on one); write the line in each module.
- **Never `DEBUG_BUILD` in code a node test imports**: node has no build to write it.
- Build switches are `--mode` words (`vibe build --debug`), never environment variables.
- **The editor is `@vibe/editor`, and the game never refers to it** -- no import, not even `import type` -- but
  `main.ts`'s `DEBUG`-gated `import('@vibe/editor')`, `import('@vibe/editor/panel')` and `import('./tools/index.ts')`.
  A release build that carries any module of the editor, the tool folders or the engine's `debug/` (but
  `mr-debug.ts`, inert there) fails, naming each file.

## A top-level side effect: `probing()`

Studio mode checks a changed module before it reloads the page: it evaluates `main.ts` and the graph under it
**for real** in a hidden page of the same origin. Its storage, its fetches, its sound are the page's. `boot()`
does nothing there; any other module of the project with a side effect at its top level checks first:

```ts
import { probing } from '@vibe/engine/boot';

if (!probing()) localStorage.setItem('my-game.last-run', new Date().toISOString());
```

-- for storage written, a fetch, an `AudioContext`, a listener. Code inside functions `boot()` calls is never run
there, so it needs no check.

## What a debug build gives you

- **The debug panel**: `?debug` on the plain page (or the studio's) -- every MrDebug action as a button (its
  `actions` folder lists the keys), stats, and the switch.
- **The console**: `game`, `world`, `ui`, `Assets`, `Audio`, `MrDebug`. `world.describe()` prints every prefab,
  component and system with rates, data and member counts.
- **Keys of the engine's own**: `U` hides the UI and the debug overlays for clean footage; "lose context" (a button
  only) tests recovery from a lost WebGL context -- the game must go on drawing, UI and all, with no reload.
- **`?seed=1234`** replays a seed (the console says the seed of each run); **`?workers=2`** runs `parallel` systems
  on threads (with `npm run dev:isolated`).
- **A system that throws** pauses the game there in a debug build and names the system and the tick; a release says
  it once on the console and runs on.
- **Studio mode** (`?studio`): the editor as the whole page. In it `P` pauses a playtest rather than opening the
  pause menu; `?` lists every editor key live just now. Driving it is the studio skill
  ([working in the studio](../studio/studio.md) to start, [a playtest](../studio/play.md)).
