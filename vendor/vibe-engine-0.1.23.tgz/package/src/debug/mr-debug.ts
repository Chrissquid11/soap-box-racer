/// <reference path="../env.d.ts" preserve="true" />
/**
 * **MrDebug: every debug key and every debug button goes through here.** One
 * list (`actions.ts`), one key listener, one switch -- so all of them can be
 * turned off at once, and a release build has none of them.
 *
 * ```ts
 * if (DEBUG) {
 *   MrDebug.add({ name: 'hide UI', key: 'KeyU', help: 'Hide the UI for clean footage', run: () => toggle() });
 * }
 * ```
 *
 * - **A key** is a `KeyboardEvent.code` pressed alone, or a chord with its
 *   modifiers: `'Mod+KeyZ'`, `'Mod+Shift+KeyZ'`, `'Shift+KeyD'` -- `Mod` is Cmd
 *   on a Mac and Ctrl elsewhere (`actions.ts`). A press matches only with
 *   exactly its modifiers, and an action may take several (`['KeyZ',
 *   'Mod+KeyZ']`). MrDebug hears every key first (the window, capturing) and a
 *   key it takes goes nowhere else: not into the game's input, not to the
 *   page's own keys, not to the browser -- Cmd+D bookmarks nothing while an
 *   action has it. A key it does not take -- no action on it, debug switched
 *   off, typing in a field, a chord nobody has -- goes on as if MrDebug were
 *   not there, so with the switch off `P` is the game's pause key again, and
 *   Cmd+R reloads.
 * - **A field's own keys** are actions too, scoped to it: `field: 'agent'`
 *   takes a key only while typing into an element marked
 *   `data-keys-field="agent"` (or inside one), and nothing anywhere else --
 *   the editor's prompt box sends with Enter and walks its history with ↑ ↓
 *   so (`packages/editor/src/agent/prompt-box.ts`). The listener reads that mark off
 *   the event's target, and an IME composing (`isComposing`), which no action
 *   takes. A field never listens for a key of its own.
 * - **A button** is the same action: the debug panel (`panel.ts`) lists every
 *   one, each running through `MrDebug.run`. Never a button of its own.
 * - **A key held** -- `hold: true` on an action: `run` as it goes down, `release`
 *   as it comes up or the window loses the focus -- and `MrDebug.held(code)`,
 *   whether a key is down now: the Model tab's flying (Docs/modeler.md M8),
 *   from this one listener's `keyup` and `blur`, never one of a tool's own.
 * - **The switch** is `MrDebug.enabled`, a checkbox at the top of the panel.
 * - **A release build** gets `OFF`: `DEBUG` is a literal `false` there, so this
 *   module's real half -- the registry, the listener -- is dropped, and every
 *   `if (DEBUG) { MrDebug.add(...) }` with it. `vite.config.ts`'s `debugGuard`
 *   fails a release build that carries any of `src/debug/` but this file.
 *
 * **Gating debug code**: in each module that has some, a module-local
 * `const DEBUG = DEBUG_BUILD && MrDebug.on;` -- the build-time literal in the
 * same module, because the bundler does not fold a constant across an import.
 *
 * Nothing else may listen for a debug key or make a debug button; `vibe test`
 * fails if anything does (the pipeline's `checks/routes.ts`). CLAUDE.md has the rule.
 */
import { isTyping } from '../input/devices.ts';
import { DebugActions, OFF, type DebugRouter } from './actions.ts';

export type { DebugAction, DebugRouter } from './actions.ts';
export { isMac, keyLabel, keysOf, modName } from './actions.ts';

/**
 * Are debug tools on: always on the dev server, and with `?debug` in a debug
 * build. `DEBUG_BUILD` is a literal (vite.config.ts `modeDefines`), so in a
 * release build this is `false` here and everything it guards is dropped.
 */
const on = DEBUG_BUILD && (import.meta.env.DEV || new URLSearchParams(location.search).has('debug'));

export const MrDebug: DebugRouter = on ? new DebugActions() : OFF;

if (on) {
  addEventListener(
    'keydown',
    (e) => {
      const taken = MrDebug.handle({
        code: e.code,
        repeat: e.repeat,
        ctrl: e.ctrlKey,
        alt: e.altKey,
        meta: e.metaKey,
        shift: e.shiftKey,
        typing: isTyping(e.target),
        // The field typed into, if it has keys of its own: its nearest element marked so.
        field: (e.target as Element | null)?.closest?.('[data-keys-field]')?.getAttribute('data-keys-field') ?? undefined,
        composing: e.isComposing,
      });
      if (!taken) return;
      e.preventDefault();
      e.stopImmediatePropagation();
    },
    true,
  );
  // The same one listener's other half: a key going up, and every key let go as the window loses the focus --
  // what a `hold` action (`actions.ts`) is released by and `held` reads. Nothing is taken: the game's input hears them too.
  addEventListener('keyup', (e) => MrDebug.up(e.code), true);
  addEventListener('blur', () => MrDebug.blur());
}
