/**
 * The registry behind MrDebug (`mr-debug.ts`): every debug action, with its key
 * and its button, in one list -- so one switch turns them all off.
 *
 * Pure: no DOM, no `import.meta.env`, so node tests it directly. `mr-debug.ts`
 * owns the instance, the build flags and the one key listener.
 *
 * **Keys and chords.** A key is a `KeyboardEvent.code` (`'KeyU'`, `'F2'`). A
 * chord is modifiers and a code joined by `+`: `'Mod+KeyZ'`, `'Mod+Shift+KeyZ'`,
 * `'Shift+KeyD'`, `'Alt+F2'`. `Mod` is Cmd on a Mac and Ctrl everywhere else --
 * what people press for Undo on each -- so one chord is right on both. A press
 * matches only with exactly its modifiers: a plain key never with one held,
 * `Mod+KeyZ` never with Mod and Alt. Ctrl on a Mac and the Windows key elsewhere
 * are no `Mod`: a press with one held is no debug key at all, and stays the
 * browser's.
 *
 * **A field's own keys.** A key typed into a field is the field's, never a
 * debug key -- but for an action with a `field`, which takes keys only typed
 * into that field: an element marked `data-keys-field="<name>"`, or inside one
 * (`KeyPress.field`, which `mr-debug.ts`'s listener reads off the event). The
 * editor's prompt box sends with Enter and walks its history with ↑ ↓ this
 * way, so no field ever listens for a key of its own: every key stays in one
 * list, under one switch. Nothing is taken while an IME composes
 * (`composing`): the Enter that confirms a word is the word's. A repeat runs
 * nothing; one a field action has is taken all the same, so a held Enter puts
 * no newline in after it sent. An action of no field marked `anywhere` is
 * taken typed into any field too -- F5, F6, which no field may have: the
 * browser would reload the page, or go to its address bar.
 *
 * **Keys held** (the Model tab's flying, Docs/modeler.md M8). An action marked
 * `hold` runs as its key goes down and has `release` called as that key comes
 * up -- or as the window loses the focus, or Cmd comes up on a Mac (which sends
 * no keyup for a key let go of while it was held). `held(code)` says whether a
 * key is down just now, as the one listener heard it -- Shift for a boost, the
 * others of a set held together. Both are fed by `mr-debug.ts`' one listener
 * (`up`, `blur`): nothing else listens for a key going up either.
 */

export interface DebugAction {
  /** Unique: the button's label in the debug panel. */
  readonly name: string;
  /**
   * The key that runs it -- a `KeyboardEvent.code` (`'KeyU'`, `'F2'`), pressed
   * alone, or a chord (`'Mod+KeyZ'`, `'Shift+KeyD'`) -- or several that each
   * do (`['KeyZ', 'Mod+KeyZ']`). Leave it out for a panel button only.
   */
  readonly key?: string | readonly string[];
  /** One line: what it does. On the button, and in the list of keys. */
  readonly help: string;
  /** Only while this says so -- the editor's own keys while it is open. Default: always. */
  when?(): boolean;
  /**
   * A key only while typing into this field -- an element marked
   * `data-keys-field="<field>"`, or inside one -- and never anywhere else. An
   * action without one ignores every key typed into a field, as ever.
   */
  readonly field?: string;
  /**
   * Taken while typing too, for a key no field may have: F5, which would
   * otherwise reload the page out of a focused field. Only for an action of
   * no field; a field's own action on the key still comes first in its field.
   */
  readonly anywhere?: true;
  /** A key held, not pressed: `run` as it goes down, `release` as it comes up (or the window loses the focus). A repeat runs neither. */
  readonly hold?: true;
  release?(): void;
  run(): void;
}

/** What the game sees of MrDebug: the real one in a debug build, `OFF` in a release. */
export interface DebugRouter {
  /** Are debug tools on in this build and page at all? False in a release, always. */
  readonly on: boolean;
  /** The one switch: every debug key and button off at once while false. */
  enabled: boolean;
  /** Register an action. Returns the undo. Throws on a name taken, a chord it cannot read, or a key two actions always take. */
  add(action: DebugAction): () => void;
  /**
   * Every key `add` would refuse `action` for -- one an action already there takes, in its field, where either has no
   * `when` -- each as written in `action.key` (`declared`), in `chord`'s form (`key`), and that action's `name`; none
   * when there is none. Asked first by one that would rather go without a key than throw: the editor, whose keys give
   * way to a game's (Docs/studio.md, "Keys").
   */
  clashes(action: Pick<DebugAction, 'key' | 'field' | 'when'>): { key: string; declared: string; name: string }[];
  /**
   * The action called `name` given other keys, in its place: its place in the order kept, so which of two actions on a
   * key is live first never changes -- the editor's keymap switched (Docs/navigation.md §8). Throws, nothing changed, on
   * a name not there, a chord it cannot read, or a key another action always takes with it (as `add`).
   */
  rekey(name: string, key: string | readonly string[]): void;
  /** Run an action by name, as its button does. False if there is none, or debug is off. */
  run(name: string): boolean;
  /**
   * A key pressed: runs the action bound to it, if any is live. True if it was
   * taken -- the key then goes nowhere else. The modifiers held must be the
   * chord's exactly; a repeat or a key typed into a field is never a debug key
   * -- but for the field's own actions (`DebugAction.field`) and those taken
   * `anywhere`.
   */
  handle(press: KeyPress): boolean;
  /** A key come up (`KeyboardEvent.code`): no longer `held`, and the `hold` action its press ran released. */
  up(code: string): void;
  /** The window lost the focus: every key let go, every `hold` action released. */
  blur(): void;
  /** Is this key down just now, as the listener heard it? */
  held(code: string): boolean;
  /** Every action, in registration order: what the panel shows. */
  list(): readonly DebugAction[];
  /** Told when the list or the switch changes. Returns the undo. */
  onChange(listener: () => void): () => void;
}

export interface KeyPress {
  code: string;
  repeat: boolean;
  /** The modifiers held, as the event has them. */
  ctrl: boolean;
  alt: boolean;
  meta: boolean;
  shift: boolean;
  /** The key is going into a text field. */
  typing: boolean;
  /** The `data-keys-field` of the nearest element that has one, from the event's target: whose field actions it may reach. */
  field?: string;
  /** An IME is composing (`isComposing`): no action takes the press. */
  composing?: boolean;
}

/** The answer `isMac` gave, once asked. */
let mac: boolean | undefined;

/**
 * Is this a Mac -- or an iPad or an iPhone with a keyboard: Cmd is its `Mod`.
 * Read through `globalThis`, forgiven where there is no `navigator`; and read
 * when first asked, not as the module loads -- a module that does something as
 * it loads cannot be dropped from a release build, and this one must be.
 */
export const isMac = (): boolean => (mac ??= /Mac|iPhone|iPad/.test(globalThis.navigator?.platform ?? ''));

/** `Mod` as a person names it here: `Cmd` on a Mac, `Ctrl` everywhere else. For words; `keyLabel` for a key. */
export const modName = (): 'Cmd' | 'Ctrl' => (isMac() ? 'Cmd' : 'Ctrl');

/**
 * The modifiers a chord may name, in the order its canonical form puts them. `Ctrl` is the Ctrl key itself on a Mac,
 * where `Mod` is Cmd -- Blender's keys, Ctrl on every machine (the editor's numpad, Docs/navigation.md D4); elsewhere
 * it is `Mod` (`keysOf`).
 */
const MODIFIERS = ['Mod', 'Ctrl', 'Alt', 'Shift'] as const;
type Modifier = (typeof MODIFIERS)[number];

/** A key or chord as one string, its modifiers in `MODIFIERS`' order: `'Shift+Mod+KeyZ'` is `'Mod+Shift+KeyZ'`. Throws on one it cannot read. */
export function chord(key: string): string {
  const parts = key.split('+');
  const code = parts.pop()!;
  const held = new Set<Modifier>();
  for (const part of parts) {
    if (!(MODIFIERS as readonly string[]).includes(part)) throw new Error(`[MrDebug] '${key}' is no key: a chord is ${MODIFIERS.join(', ')} and a KeyboardEvent.code, joined by '+' ('Mod+KeyZ')`);
    held.add(part as Modifier);
  }
  if (!code || (MODIFIERS as readonly string[]).includes(code)) throw new Error(`[MrDebug] '${key}' is no key: it ends in a modifier, not a KeyboardEvent.code`);
  return [...MODIFIERS.filter((m) => held.has(m)), code].join('+');
}

/**
 * A press as the chord it is, in `chord`'s form; null when it holds a modifier
 * no action takes -- the Windows key elsewhere, Cmd and Ctrl both on a Mac. Ctrl
 * on a Mac is `Ctrl` (an action names it so, or no action takes it).
 */
export function pressed({ code, ctrl, alt, meta, shift }: Pick<KeyPress, 'code' | 'ctrl' | 'alt' | 'meta' | 'shift'>, mac = isMac()): string | null {
  if (mac ? ctrl && meta : meta) return null;
  const mod = mac ? meta : ctrl;
  return `${mod ? 'Mod+' : ''}${mac && ctrl ? 'Ctrl+' : ''}${alt ? 'Alt+' : ''}${shift ? 'Shift+' : ''}${code}`;
}

/** An action's keys, each in `chord`'s form -- `Ctrl` read as `Mod` but on a Mac -- each once. */
export const keysOf = (action: Pick<DebugAction, 'key'>, mac = isMac()): string[] => {
  const keys = action.key === undefined ? [] : (typeof action.key === 'string' ? [action.key] : [...action.key]).map(chord);
  return [...new Set(mac ? keys : keys.map((key) => (key.includes('Ctrl+') ? chord(key.replace('Ctrl+', key.startsWith('Mod+') ? '' : 'Mod+')) : key)))];
};

export class DebugActions implements DebugRouter {
  readonly on = true;
  private switchedOn = true;
  private readonly actions: DebugAction[] = [];
  /** Each action's keys in `chord`'s form, worked out once as it is added. */
  private readonly keys = new Map<DebugAction, string[]>();
  private readonly listeners = new Set<() => void>();
  private readonly mac: boolean;
  /** Keys down just now, by code. */
  private readonly down = new Set<string>();
  /** Each action's place for its undo, by the object there now (`rekey` replaces it). */
  private readonly slots = new Map<DebugAction, { action: DebugAction }>();
  /** The `hold` actions a press ran, by the code still down. */
  private readonly holding = new Map<string, DebugAction>();

  /** `mac`: whether `Mod` is Cmd (a Mac) or Ctrl. This machine's, unless a test says otherwise. */
  constructor({ mac = isMac() }: { mac?: boolean } = {}) {
    this.mac = mac;
  }

  get enabled(): boolean {
    return this.switchedOn;
  }

  set enabled(value: boolean) {
    if (value === this.switchedOn) return;
    this.switchedOn = value;
    this.changed();
  }

  add(action: DebugAction): () => void {
    if (this.actions.some((a) => a.name === action.name)) throw new Error(`[MrDebug] there is already a debug action called '${action.name}'`);
    const keys = keysOf(action, this.mac);
    const clash = this.clashes(action)[0];
    if (clash) throw new Error(`[MrDebug] '${action.name}' and '${clash.name}' both take ${clash.key}${action.field !== undefined ? ` in the field '${action.field}'` : ''}; give one a different key, or both a \`when\``);
    this.actions.push(action);
    this.keys.set(action, keys);
    // Where the action is now: `rekey` puts another object in its place, which this undo then takes out.
    const slot = { action };
    this.slots.set(action, slot);
    this.changed();
    return () => {
      const i = this.actions.indexOf(slot.action);
      if (i < 0) return;
      this.actions.splice(i, 1);
      this.keys.delete(slot.action);
      this.slots.delete(slot.action);
      this.changed();
    };
  }

  clashes(action: Pick<DebugAction, 'key' | 'field' | 'when'>): { key: string; declared: string; name: string }[] {
    const out: { key: string; declared: string; name: string }[] = [];
    const declared = action.key === undefined ? [] : typeof action.key === 'string' ? [action.key] : action.key;
    for (const written of declared) {
      for (const key of keysOf({ key: written }, this.mac)) {
        // Two actions on one key are fine only if both say when they apply: the
        // first live one wins. Two that always apply is a key that does one of
        // two things depending on registration order -- a bug, so `add` fails on it.
        // Only in one place, though: a field's key and the page's never meet.
        const other = this.actions.find((a) => a.field === action.field && this.keys.get(a)!.includes(key) && (!a.when || !action.when));
        if (other) out.push({ key, declared: written, name: other.name });
      }
    }
    return out;
  }

  rekey(name: string, key: string | readonly string[]): void {
    const i = this.actions.findIndex((a) => a.name === name);
    if (i < 0) throw new Error(`[MrDebug] there is no debug action called '${name}'`);
    const was = this.actions[i]!;
    const next: DebugAction = { ...was, key };
    const keys = keysOf(next, this.mac);
    // Its own keys are no clash: it is itself, about to be replaced.
    const clash = this.clashes(next).find((c) => c.name !== name);
    if (clash) throw new Error(`[MrDebug] '${name}' and '${clash.name}' both take ${clash.key}${next.field !== undefined ? ` in the field '${next.field}'` : ''}; give one a different key, or both a \`when\``);
    this.actions[i] = next;
    this.keys.delete(was);
    this.keys.set(next, keys);
    const slot = this.slots.get(was);
    this.slots.delete(was);
    if (slot) {
      slot.action = next;
      this.slots.set(next, slot);
    }
    // A key of its held just now: released as ever by the action that ran it.
    this.changed();
  }

  run(name: string): boolean {
    if (!this.switchedOn) return false;
    const action = this.actions.find((a) => a.name === name);
    if (!action || (action.when && !action.when())) return false;
    action.run();
    return true;
  }

  handle(press: KeyPress): boolean {
    this.down.add(press.code);
    if (!this.switchedOn || press.composing) return false;
    const key = pressed(press, this.mac);
    // Typed into a field: only that field's own actions; anywhere else, only those of no field --
    // and, typed into any field, those of no field marked `anywhere` (a field's own on the key first).
    const field = press.typing ? press.field : undefined;
    const action =
      key === null ? undefined : ((press.typing && field === undefined ? undefined : this.live(field, key)) ?? (press.typing ? this.live(undefined, key, true) : undefined));
    // A repeat is no debug key -- but one of a field's own keys, or an `anywhere` one, is taken all the same, so
    // the field (or the browser: a held F5) does not do its own with it. A held action's own repeats are taken, as
    // its key is: they go nowhere else while it is held.
    if (press.repeat) return action !== undefined && (action.field !== undefined || action.anywhere === true) ? true : field === undefined && this.holding.has(press.code);
    if (!action) return false;
    if (action.hold) this.holding.set(press.code, action);
    action.run();
    return true;
  }

  /** The first live action of this field (`undefined`: of none) on this key -- only one marked `anywhere`, if asked. */
  private live(field: string | undefined, key: string, anywhere = false): DebugAction | undefined {
    return this.actions.find((a) => a.field === field && (!anywhere || a.anywhere === true) && this.keys.get(a)!.includes(key) && (!a.when || a.when()));
  }

  up(code: string): void {
    this.down.delete(code);
    // Cmd up on a Mac: the keys let go of while it was held sent no keyup of their own.
    if (code === 'MetaLeft' || code === 'MetaRight') return this.blur();
    const action = this.holding.get(code);
    if (!action) return;
    this.holding.delete(code);
    action.release?.();
  }

  blur(): void {
    this.down.clear();
    const released = [...this.holding.values()];
    this.holding.clear();
    for (const action of released) action.release?.();
  }

  held(code: string): boolean {
    return this.down.has(code);
  }

  list(): readonly DebugAction[] {
    return this.actions;
  }

  onChange(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private changed(): void {
    for (const listener of this.listeners) listener();
  }
}

/** MrDebug in a release build: nothing registers, nothing runs, no key is taken. */
export const OFF: DebugRouter = {
  on: false,
  enabled: false,
  add: () => () => {},
  clashes: () => [],
  rekey: () => {},
  run: () => false,
  handle: () => false,
  up: () => {},
  blur: () => {},
  held: () => false,
  list: () => [],
  onChange: () => () => {},
};

/** Keys whose code says less than the mark on them. */
const MARKS: Record<string, string> = {
  Slash: '/', Backslash: '\\', Comma: ',', Period: '.', Semicolon: ';', Quote: "'", Backquote: '`', IntlBackslash: '§',
  Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']',
  ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', ContextMenu: 'Menu',
};

/** What Shift makes of a key, where a person names the chord by that: `?`, not `Shift+/`. */
const SHIFTED: Record<string, string> = { Slash: '?' };

/**
 * A key or chord as a person reads it: `'KeyU'` is `U`, `'Digit1'` is `1`,
 * `'F2'` stays; `'Mod+KeyZ'` is `⌘Z` on a Mac and `Ctrl+Z` elsewhere, `'Ctrl+Numpad1'` `⌃Numpad1` and `Ctrl+Numpad1`,
 * `'Mod+Shift+KeyZ'` `⇧⌘Z` and `Ctrl+Shift+Z`, `'Shift+Slash'` `?`.
 */
export function keyLabel(key: string, mac = isMac()): string {
  const parts = chord(key).split('+');
  const code = parts.pop()!;
  const held = new Set(parts);
  if (held.size === 1 && held.has('Shift') && SHIFTED[code]) return SHIFTED[code];
  const mark = MARKS[code] ?? code.replace(/^Key/, '').replace(/^Digit/, '');
  // A Mac's glyphs in its own order -- Option, Shift, Command -- run together; elsewhere words and pluses.
  if (mac) return `${held.has('Ctrl') ? '⌃' : ''}${held.has('Alt') ? '⌥' : ''}${held.has('Shift') ? '⇧' : ''}${held.has('Mod') ? '⌘' : ''}${mark}`;
  return [held.has('Mod') || held.has('Ctrl') ? 'Ctrl' : '', held.has('Alt') ? 'Alt' : '', held.has('Shift') ? 'Shift' : '', mark].filter(Boolean).join('+');
}
