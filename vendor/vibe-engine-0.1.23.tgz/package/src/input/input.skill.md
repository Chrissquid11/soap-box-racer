---
skill: engine
title: Input
when: Before reading keys, the mouse or touch, or a gamepad in the game -- the codes, what a system sees, what the UI takes first
covers:
  modules: [input/, loop/input.ts]
order: 60
---
# Input: keys, pointers and pads, stamped

The game reads input in its systems, through `ctx.input`, never through a listener of its own. The engine's
`Game` listens to the devices (`node_modules/@vibe/engine/src/input/devices.ts`) and turns every event into an
edge the loop stamps with the tick it came in on; each system then reads the edges over its own window, so a
1 Hz system misses no press and no system uses one up for another ([the loop page](loop.md)).

## The codes

| Device | Codes |
|---|---|
| keyboard | the key's `KeyboardEvent.code`: `'Space'`, `'KeyW'`, `'ArrowLeft'`, `'ShiftLeft'`, `'Digit1'` -- its place on the keyboard, whatever the layout prints on it |
| mouse, touch, pen | `'Pointer0'` the main button (every finger is `'Pointer0'`), `'Pointer1'` the middle, `'Pointer2'` the right, `'Pointer3'` and `'Pointer4'` the back and forward buttons |
| gamepad | `'Pad0'` to `'Pad16'` in the standard mapping (`Pad0` the bottom face button), held if any pad holds it; polled once a frame, from the first press a pad makes (the browser announces none before) |

## In a system

```ts
const jump = input.pressed('Space') || input.pressed('Pad0');   // went down since this system last ran
const fire = input.down('Pointer0');                            // held now, as of this tick
const taps = input.presses('KeyE');                             // how many times it went down in the window
const letGo = input.released('ShiftLeft');                     // went up in the window
const { x, y } = input.pointer;                                 // from the game frame's top left, in game.pixels: CSS pixels (the canvas's, but in the studio)
const stickX = input.axis(0);                                   // the first pad's sticks, -1 to 1: 0, 1 left; 2, 3 right
```

(Here `input` is `ctx.input`, inside a simulation system's `update`.)

The pointer is measured in the game's own pixels, `game.pixels` -- the frame's size in a release build. In the
studio a Pixel or Stretch preview preset draws the world at exactly its resolution and scales it up, and the pointer
comes in that resolution's pixels, as the cameras see it: divide by `game.pixels.width` and `height`, never by the
canvas's or the window's size. A press outside the frame is not the game's; a drag the game holds a button of goes on
past its edge, the pointer then negative or past `game.pixels` -- clamp it where that matters.

- **A press is seen once by every system**, at every rate: no "consumed" flag, nothing to reset. A game that
  wants only one thing to answer a press decides it in its own logic.
- **A tap within one tick still counts**: `pressed` and `released` true, `down` false.
- **Nothing stays stuck**: the window losing the focus, the tab hidden, or Cmd let go on a Mac releases
  everything held.
- **Paused, presses are dropped** on resume: the press that closed the menu does not also jump. What is held
  stays held.
- **Simulation code reads only `ctx.input`.** An input-phase system (`phase: 'input'`, once a frame) may turn
  something into input -- a gesture recognised, stamped as an edge -- but never changes the simulation itself.
- There is no action map yet: a game that wants `'jump'` on Space and `Pad0` checks both, or keeps its own
  table of codes at module level.

## Who comes first

1. **MrDebug**: a key a debug action has (in a debug build, with debug on) goes nowhere else
   ([the debug page](debug.md)). With debug off, it falls through to the game.
2. **The canvas UI**: every pointer press is asked of the UI first (`Game.pointerClaim`); one the UI takes -- a
   button, a menu -- never reaches the game's input, nor does its release. So a press on a HUD button is never
   also a shot ([the UI page](ui.md)).
3. **A field**: a key typed into a text field (an input, a text area) is the field's, not the game's.
4. **The game**: `P` and Esc are the pause menu's on the plain page (`boot()` has them), the rest is yours.

## The rules that bite

- **Never `addEventListener('keydown')`** in the game for gameplay -- read `ctx.input` in a system. For a debug
  key, `MrDebug.add` (the `routes` check fails on a stray key listener).
- **Never read input in a render system to change the simulation**: input that changes the game is read in a
  simulation system, where it is stamped and replayable.
- **A slow system reads input as well as a fast one**: its window is its period, so a press is never missed.
  An event to other systems is the way to tell them about it ([the ECS page](ecs.md)).
- Pointer position is state, not an edge: the latest one, as of the tick. Into the world through the main
  camera: [the camera page](camera.md).
