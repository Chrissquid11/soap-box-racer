/**
 * The devices, into the loop's input queue (Docs/loop.md §7): the DOM side of
 * input, and all of it. Nothing here decides anything; it turns events into
 * edges and state, and the loop stamps them with a tick.
 *
 * Codes: a key is its `KeyboardEvent.code` (`'Space'`, `'KeyW'`) -- the key's
 * place, whatever the layout prints on it. A pointer button is `'Pointer0'`
 * (main), `'Pointer1'`, `'Pointer2'`; every finger is `'Pointer0'`. A pad button
 * is `'Pad0'` to `'Pad16'` in the standard mapping (0 is the bottom face button),
 * held if any connected pad holds it.
 *
 * - **The UI comes first.** A pointer press the canvas UI claims
 *   (`Game.pointerClaim`) never reaches the game's input, nor does its release.
 * - **Nothing stays stuck.** Losing focus -- the window blurs, the tab hides --
 *   releases everything held. So does letting go of Cmd: macOS sends no keyup
 *   for keys let go of while it was held.
 * - **The pointer is the frame's** (`frame.ts`, Docs/game-view.md §2): its place
 *   frame-local, and a pointer outside the frame -- the editor's cards' side of
 *   the canvas -- not the game's: no place, and a press there is not passed in.
 *   Through a Pixel or Stretch resolution (Docs/game-view.md §4) the place is
 *   in the game's own pixels, the target's -- what its cameras see.
 * - **A key typed into a field is the field's**: the debug panel's inputs.
 * - **Pads are polled**, once a frame, by the input-phase system that calls
 *   `pollGamepads` -- the Gamepad API has no events for buttons.
 */
import type { InputSink } from '../loop/input.ts';
import { framePixels, framePoint, type FrameRect } from '../frame.ts';

export interface Devices {
  /** Pad buttons diffed into edges, and the first pad's sticks: once a frame, in the input phase. */
  pollGamepads(): void;
  /** Every listener off. */
  detach(): void;
}

/**
 * Is this key going into a field, rather than at the game or an editor?
 *
 * **Only somewhere text actually goes.** A range, a colour swatch, a checkbox
 * is not: clicking one leaves it focused, and a filter of "any input" then
 * treats every key after that as typing -- one click on a slider and every
 * shortcut seems broken until the canvas is clicked again (CrabParty found it
 * twice). One rule, shared by the game's input and the page's own keys.
 */
export function isTyping(target: EventTarget | null): boolean {
  const node = target as HTMLElement | null;
  // `closest?.` because a key event's target can be the window, which has none.
  const field = node?.closest?.('input, textarea, select, [contenteditable]');
  if (!field) return false;
  if (field instanceof HTMLInputElement) return !NOT_TEXT.includes(field.type);
  return true;
}

/** Inputs that take a click, not a keystroke. */
const NOT_TEXT = ['range', 'color', 'checkbox', 'radio', 'file', 'button'];

/** No pad connected: every axis at rest. */
const NO_STICKS: readonly number[] = [];

/** A pad button's code, by its index in the standard mapping: made once, not a string a frame. */
const PAD_CODES = Array.from({ length: 17 }, (_, i) => `Pad${i}`);

/** A mouse button's code by `PointerEvent.button`, and its bit in `PointerEvent.buttons` -- middle and right swap there. */
const POINTER_CODES = ['Pointer0', 'Pointer1', 'Pointer2', 'Pointer3', 'Pointer4'];
const BUTTON_BITS = [1, 4, 2, 8, 16];

/** The whole canvas: the frame of a game that was given none. */
const WHOLE: FrameRect = { x: 0, y: 0, width: Infinity, height: Infinity };
const wholeCanvas = (): FrameRect => WHOLE;

/**
 * The devices on `canvas`, into `input`. `claims`: is a pointer event the UI's (`Game.pointerClaim`). `frame`: the
 * game's frame now (`Game.frame`), the whole canvas if not given. `pixels`: the frame's size in the game's pixels
 * (`Game.pixels`), the pointer scaled into them (`framePixels`); none, CSS pixels.
 */
export function attachDevices(input: InputSink, canvas: HTMLCanvasElement, claims: (e: PointerEvent) => boolean, frame: () => Readonly<FrameRect> = wholeCanvas, pixels?: () => { readonly width: number; readonly height: number }): Devices {
  const keys = new Set<string>();
  /** Pointer ids holding each pointer code down: a code goes up when its last pointer does. */
  const pointers = new Map<string, Set<number>>();
  /** Pad buttons held at the last poll, as bits; and whether any pad has connected at all. */
  let padsHeld = 0;
  let padsSeen = 0;
  const off: Array<() => void> = [];

  const listen = <K extends keyof WindowEventMap>(target: Window | HTMLElement, type: K, handler: (e: WindowEventMap[K]) => void, capture = false): void => {
    target.addEventListener(type, handler as EventListener, capture);
    off.push(() => target.removeEventListener(type, handler as EventListener, capture));
  };

  const releaseAll = (): void => {
    for (const code of keys) input.edge(code, false);
    keys.clear();
    for (const code of pointers.keys()) input.edge(code, false);
    pointers.clear();
    for (let i = 0; padsHeld >>> i !== 0; i++) if (padsHeld & (1 << i)) input.edge(PAD_CODES[i]!, false);
    padsHeld = 0;
  };

  // A pad announces itself on its first button press: until one has, there is nothing to poll.
  listen(window, 'gamepadconnected', () => {
    padsSeen++;
  });

  /** A pointer's place, frame-local, written over. */
  const local = { x: 0, y: 0 };
  /**
   * The pointer's place into the input, frame-local: false, and nothing told, outside the frame -- but for a pointer
   * the game holds a button of (`held`), whose drag goes on past the frame's edge, and the window's: its place still
   * told, negative or past the frame's size, as a whole-canvas game was told it before there was a frame.
   */
  const at = (e: PointerEvent, held = false): boolean => {
    const rect = canvas.getBoundingClientRect();
    const f = frame();
    if (!framePoint(e.clientX - rect.left, e.clientY - rect.top, f, local) && !held) return false;
    if (pixels) framePixels(local, f, pixels());
    input.pointerAt(local.x, local.y);
    return true;
  };

  listen(window, 'keydown', (e) => {
    if (e.repeat || isTyping(e.target)) return;
    keys.add(e.code);
    input.edge(e.code, true);
  });
  listen(window, 'keyup', (e) => {
    if (e.key === 'Meta') {
      // macOS sends no keyup for a key let go of while Cmd was held.
      releaseAll();
      return;
    }
    if (!keys.delete(e.code)) return;
    input.edge(e.code, false);
  });

  const press = (code: string, id: number): void => {
    let ids = pointers.get(code);
    if (!ids) pointers.set(code, (ids = new Set()));
    if (ids.size === 0) input.edge(code, true);
    ids.add(id);
  };
  const release = (code: string, id: number): void => {
    const ids = pointers.get(code);
    if (!ids?.delete(id) || ids.size > 0) return;
    pointers.delete(code);
    input.edge(code, false);
  };

  listen(canvas, 'pointerdown', (e) => {
    if (claims(e) || !at(e)) return;
    press(POINTER_CODES[e.button] ?? `Pointer${e.button}`, e.pointerId);
  });
  // A second mouse button pressed or let go while one is held is no pointerdown or pointerup -- the
  // Pointer Events spec fires a pointermove, its `buttons` changed. Diffed here into edges, for a
  // pointer the game already has a button of (a press that began on the canvas, unclaimed).
  // On the window, and capturing, as the release is: off the canvas too.
  // And the place of a pointer the game holds, moved off the canvas's own rect -- past the window's edge, or round a
  // canvas smaller than the page: its drag goes on (a move on the canvas is the canvas's). Not one over another element
  // on the canvas (the `?debug` panel, a card): the game was never told those, and is not now.
  listen(window, 'pointermove', (e) => {
    if (!holds(e.pointerId)) return;
    if (e.target !== canvas && offCanvas(e)) at(e, true);
    if (e.pointerType !== 'mouse') return;
    for (let b = 0; b < POINTER_CODES.length; b++) {
      const code = POINTER_CODES[b]!;
      const down = (e.buttons & BUTTON_BITS[b]!) !== 0;
      const was = pointers.get(code)?.has(e.pointerId) === true;
      if (down && !was) press(code, e.pointerId);
      else if (!down && was) release(code, e.pointerId);
    }
  }, true);
  const offCanvas = (e: PointerEvent): boolean => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    return x < 0 || y < 0 || x >= rect.width || y >= rect.height;
  };
  const holds = (id: number): boolean => {
    for (const ids of pointers.values()) if (ids.has(id)) return true;
    return false;
  };
  listen(canvas, 'pointermove', (e) => {
    if (!claims(e)) at(e, holds(e.pointerId));
  });
  // On the window, and capturing: a release off the canvas still lets go.
  const up = (e: PointerEvent): void => {
    for (const [code, ids] of pointers) {
      if (!ids.delete(e.pointerId)) continue;
      if (ids.size === 0) {
        pointers.delete(code);
        input.edge(code, false);
      }
    }
  };
  listen(window, 'pointerup', up, true);
  listen(window, 'pointercancel', up, true);

  listen(window, 'blur', releaseAll);
  const hidden = (): void => {
    if (document.hidden) releaseAll();
  };
  document.addEventListener('visibilitychange', hidden);
  off.push(() => document.removeEventListener('visibilitychange', hidden));

  return {
    pollGamepads(): void {
      // No pad has ever connected: nothing to ask, and asking allocates.
      if (padsSeen === 0 || typeof navigator.getGamepads !== 'function') return;
      // Buttons held on any pad, as bits; the first connected pad's sticks.
      let held = 0;
      let sticks: readonly number[] = NO_STICKS;
      const list = navigator.getGamepads();
      for (let p = 0; p < list.length; p++) {
        const pad = list[p];
        if (!pad?.connected) continue;
        const buttons = pad.buttons;
        for (let i = 0; i < buttons.length && i < PAD_CODES.length; i++) if (buttons[i]!.pressed) held |= 1 << i;
        if (sticks === NO_STICKS) sticks = pad.axes;
      }
      const changed = held ^ padsHeld;
      for (let i = 0; changed >>> i !== 0; i++) if (changed & (1 << i)) input.edge(PAD_CODES[i]!, (held & (1 << i)) !== 0);
      padsHeld = held;
      input.axes(sticks);
    },
    detach(): void {
      for (const fn of off) fn();
      off.length = 0;
    },
  };
}
