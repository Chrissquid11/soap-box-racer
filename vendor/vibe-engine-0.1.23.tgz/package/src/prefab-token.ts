/**
 * `prefab(key)` for game code: the engine's token (`src/ecs/prefab.ts`), typed
 * by the key generator's shapes (Docs/prefabs.md §4).
 *
 *   export const Turret = prefab('props/turret');      // AssetKeys.Prefab
 *   export const Muzzle = Turret.node('muzzle');       // AssetKeys.PrefabNodes['props/turret']
 *
 *   const e = cmd.instantiate(Turret);                 // the root, as the compiler knows it
 *   cmd.init(e, Aim).speed[e] = 2;                     // Aim: on the turret's root in its file
 *   cmd.init(e, Shield);                               // a compile error: the file has no Shield there
 *   const m = cmd.part(e, Muzzle);                     // the muzzle, and what it is made of
 *
 * The rules:
 *   - **A misspelt key or node name is a compile error**: `keys.d.ts` has every
 *     prefab key (the path lowercased: any case is taken, `Lowercase<K>` checked)
 *     and each one's node names, worked out from the files as the
 *     compile does (`packages/pipeline/src/assets/prefab-names.ts`).
 *   - **So is `init` with a component the entity is not made with**: `keys.d.ts`
 *     has what the root and each named entity of every prefab is made of
 *     (`AssetKeys.PrefabComponents`), and `instantiate` and `part` hand back an
 *     entity that carries it -- `Made<components, 'crates/big · rider'>`
 *     (`src/ecs/prefab.ts`), an `Entity` to everything else, a brand to the
 *     compiler alone. `cmd.init` and `world.init` read it (`MadeWith`) and
 *     print `crates/big · rider is not made with Shield: ...`.
 *   - **Why the brand on the entity, and not a helper on the token**
 *     (`BigCrate.init(cmd, e, Shield)`): the check is in the call game code
 *     writes anyway, `cmd.init(e, C)`, so nothing new is learnt and nothing can
 *     be forgotten. A plain `Entity` -- a bare `spawn()`, an entity kept in a
 *     variable typed `Entity`, the engine's untyped token -- is not checked,
 *     and nor is a component whose type has no literal name (`objectComponent<T>`
 *     names it only when given `<T, 'Name'>`): unchecked, never wrongly refused.
 *   - **So is a `Render.model` no model has** (a reference read as the key its uid has now): `keys.d.ts`
 *     lists the model each prefab's entities draw (`AssetKeys.PrefabViews`, a part
 *     after `#` left to the compile), and `ViewsAreModels`
 *     below holds each to `AssetKeys.Model`. A `.d.ts` is not checked itself
 *     (`skipLibCheck`), so the check is here, where `tsc` reads it, and prints
 *     `src/assets/prefabs/crates/big.prefab at rider: Render.model "props/crat" is no
 *     AssetKeys.Model ...`, at `ViewsAreModels`' line, where tsc reports a type's error.
 *     `Prefabs.compile()` checks again at boot, against what was loaded.
 *   - **So is a `Render.material` no material file has**: `AssetKeys.PrefabMaterials`
 *     lists each entity's, and `MaterialsAreMaterials` holds each to
 *     `AssetKeys.Material` the same way (Docs/render.md §4).
 *   - **Glob-free**: node tests import game code, and nothing a test imports may
 *     reach `import.meta.glob`. The files are `prefabs.ts`', handed in by the project's
 *     generated `src/assets/prefab-bundle.ts`.
 *   - **The same token** as the engine's `prefab(key: string)`, which stays for
 *     the engine's own tests: one per key, made at module level, resolved by the
 *     compile. The types above are all there is to this file.
 */
import { prefab as untyped, type Made, type Makes, type PrefabNode, type PrefabToken } from './ecs/prefab.ts';

/** The names `node()` takes for a prefab key: never for a key whose file has a problem (the generator printed it). */
export type NodeName<K extends AssetKeys.Prefab> = K extends keyof AssetKeys.PrefabNodes ? AssetKeys.PrefabNodes[K] : never;

/** What the entity of prefab `K` named `N` is made of, `''` for its root: the components' names. */
export type ComponentsOf<K extends AssetKeys.Prefab, N extends string> = K extends keyof AssetKeys.PrefabComponents
  ? N extends keyof AssetKeys.PrefabComponents[K] ? AssetKeys.PrefabComponents[K][N] : never
  : never;

/** An instance's root, as `instantiate` gives it for prefab `K`. */
export type PrefabRoot<K extends AssetKeys.Prefab> = Made<ComponentsOf<K, ''>, K>;

/** The entity named `N` of an instance of `K`, as `part` gives it. */
export type PrefabPart<K extends AssetKeys.Prefab, N extends string> = Made<ComponentsOf<K, N>, `${K} · ${N}`>;

/** A named entity of prefab `K`, for `cmd.part(root, node)`. */
export interface Node<K extends AssetKeys.Prefab, N extends string> extends PrefabNode, Makes<PrefabPart<K, N>> {}

/** A prefab's token, its key, node names and what each is made of checked. */
export interface Prefab<K extends AssetKeys.Prefab> extends PrefabToken, Makes<PrefabRoot<K>> {
  readonly key: K;
  /** A named entity of this prefab, for `cmd.part(root, node)`: take it at module level. */
  node<const N extends NodeName<K>>(name: N): Node<K, N>;
}

/** Each `Render.model` in a prefab file that is no model key: why, in words, as a union; never if there is none. */
type BadViews = {
  [K in keyof AssetKeys.PrefabViews]: {
    [P in keyof AssetKeys.PrefabViews[K] & string]: AssetKeys.PrefabViews[K][P] extends AssetKeys.Model
      ? never
      : `src/assets/prefabs/${K & string}.prefab at ${P extends '' ? 'its root' : P}: Render.model "${AssetKeys.PrefabViews[K][P] & string}" is no AssetKeys.Model -- a file under src/assets/models/, its path without the extension`;
  }[keyof AssetKeys.PrefabViews[K] & string];
}[keyof AssetKeys.PrefabViews];
type Holds<T extends true> = T;
/** Every prefab file's views are models, or the typecheck fails here, printing which (Docs/prefabs.md §4).
 * Reported at this line, not in the JSON: tsc reports a type's error where the type is, and a `.d.ts`
 * (`keys.d.ts`, where the views are) is not checked -- so the message names the file and the entity. */
export type ViewsAreModels = Holds<[BadViews] extends [never] ? true : BadViews>;

/** Each `Render.material` in a prefab file that is no material key: why, in words, as a union; never if there is none. */
type BadMaterials = {
  [K in keyof AssetKeys.PrefabMaterials]: {
    [P in keyof AssetKeys.PrefabMaterials[K] & string]: AssetKeys.PrefabMaterials[K][P] extends AssetKeys.Material
      ? never
      : `src/assets/prefabs/${K & string}.prefab at ${P extends '' ? 'its root' : P}: Render.material "${AssetKeys.PrefabMaterials[K][P] & string}" is no AssetKeys.Material -- a file under src/assets/materials/, its path without .material`;
  }[keyof AssetKeys.PrefabMaterials[K] & string];
}[keyof AssetKeys.PrefabMaterials];
/** Every prefab file's materials are material files, or the typecheck fails here, printing which -- as `ViewsAreModels`. */
export type MaterialsAreMaterials = Holds<[BadMaterials] extends [never] ? true : BadMaterials>;

/**
 * A prefab key in any case, or why it is none: the parameter of `prefab()`, so
 * a misspelt key's error says where keys come from, not only "not assignable
 * to 'Prefab'". A key is the file's path lowercased (`caseKey`), so
 * `prefab('Crates/Big')` is `crates/big`'s token, typed as `crates/big`.
 */
export type PrefabKey<K extends string> = Lowercase<K> extends AssetKeys.Prefab ? K : `'${K}' is no prefab key: AssetKeys.Prefab, a file under src/assets/prefabs/, its path without .prefab, lowercased`;

/** A prefab by key, in any case, for `cmd.instantiate`: at module level, before the compile. */
export function prefab<const K extends string>(key: PrefabKey<K>): Prefab<Lowercase<K> & AssetKeys.Prefab> {
  return untyped(key) as Prefab<Lowercase<K> & AssetKeys.Prefab>;
}
