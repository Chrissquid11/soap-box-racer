/// <reference path="./env.d.ts" preserve="true" />
/**
 * `@vibe/engine/boot`: a project's page booted -- the loading bar, the preload, the `Game`, the canvas
 * UI, and the few page-wide rules (sound, a hidden tab, the pause key). A project's `main.ts` is its
 * hooks (`BootOptions`), handed to `boot()`; this is everything else it did. Also here: `Game`
 * (`game.ts`) and the game's hot-update boundary's code (`liveGame`, `live-game.ts`), which the
 * project's generated `src/game/live.ts` calls. A subpath, never the index: this module reads
 * `DEBUG_BUILD` as it loads and `game.ts` loads three and the asset runtime, so no node test imports
 * it but as types -- its pure parts are `boot-steps.ts`, tested.
 *
 * **Load first, then build the world.** `Assets.preload()` finishes before `new Game(...)`, so
 * gameplay code is synchronous and never sees a half-loaded world. The bar, which players notice:
 *
 *   0.0 -> 0.1   page booted
 *   0.1 -> 0.2   a portal SDK's init, if the game has one (it goes here, first: `portal`)
 *   0.2 -> 0.8   Assets.preload()                 <- the long part; Ammo beside it, where physics is on
 *   0.8 -> 0.9   new Game(...), built from loaded assets, synchronously
 *   0.9 -> 1.0   CanvasUi.create(game), the first frame
 *
 * The steps' order is `BOOT_STEPS` (`boot-steps.ts`), each marked as it is reached.
 *
 * **Recovery, in studio mode** (`?studio`, Docs/studio.md §1): the editor is the whole page, so it must come up
 * whatever fails. A throw from the preload's end through the game's making -- the preload, the game's entry
 * (`game` handed as a function: a syntax error under `src/game/` is its import's rejection), the project's UI (`ui`
 * handed as its import, the same), the prefabs' compile,
 * `new Game`, `setup` -- is caught there: the loader's error is not shown, boot goes on over a stand-in game (an
 * empty world, `RECOVERY_ENTRY`), skips the editor's resume and the start scene, and the editor opens with the error
 * as its first notice (`createEditor({ recovery })`) and reloads the page itself when the fix lands. The tools'
 * modules failing, a system throwing, the start scene failing are notices too (`EditorHandle.notice`). A release
 * build, or a dev page not in studio mode, fails as ever: the loader's words.
 *
 * **A cold start that never reaches `boot`, in studio mode** (Docs/studio.md §1, "Recovery"): a link error or a
 * top-level throw in `main.ts`' own static imports means `main.ts` never runs. The dev server's guard -- an inline
 * script before it (the pipeline's `studio/cold-start.ts`) -- sees the page's error and no `BOOT_STARTED`, and calls
 * this same `boot` itself with the error as the game's import's rejection: the recovery above, nothing of its own.
 *
 * **Mid-session, in studio mode** (Docs/studio.md §1): the game booted, then a saved module breaks. A changed game
 * module that threw as it was evaluated is a failed swap (`live.onFailed`): a `swap` notice, the world on the last
 * good code; a good swap clears it, and a `frame` notice too (`clearNotice`). A system that throws during a playtest
 * pauses the playtest, the editor over it. What the dev server cannot serve is its own list, said by the editor.
 *
 * **The project's assets are handed in first**: its generated `src/assets/bundle.ts` gives the engine
 * the project's globs (`useBundle`) before anything looks a key up -- so it is `main.ts`' first import,
 * before this one is called.
 *
 * **The editor is studio mode's alone** (`?studio`, Docs/squidwright-plan.md D14): there it is the whole page, opened as
 * boot ends and never closed. The plain page is the game -- MrDebug's keys, `?debug`'s panel, `P` the pause menu's as in
 * a release -- and never loads the editor's module.
 *
 * **The editor and the debug panel are the project's to load, and only ever dynamic imports** it writes
 * behind its own `DEBUG` (`editor`, `panel`: the editor package's entry and its panel's): a release build
 * folds that to false where it is written, drops both imports, and the editor package goes with them --
 * `debugGuard` (the pipeline's `config.ts`) fails a build that carries them. Nothing here refers to
 * either: what boot asks of them is written below as a contract (`EditorModule`, `PanelModule`), which
 * they implement and may import as types.
 */
import { compileMaterials, isTyping, scene, startScene, type AmmoApi } from './index.ts';
import { Assets, Audio } from './assets/runtime.ts';
import { MrDebug } from './debug/mr-debug.ts';
import { compilePrefabs, Game, type FrameProbe, type GameEntry } from './game.ts';
import { type LiveGame } from './live-game.ts';
import { CanvasUi } from './ui/layer.ts';
import { loadFonts } from './ui/text.ts';
import { editorFailedText, errorWords, inOrder, loadGame, loadUi, onSecondBoot, pickSeed, probing, readSettings, readStudio, refuseSecond, saveSettings, SECOND_BOOT_TEXT, type BootStep, type UiImport } from './boot-steps.ts';

// The subpath's surface: what a project's main.ts, its generated live.ts, the editor and the panel import --
// `boot`, `liveGame`, `Game` and the contract types. The pure parts (boot-steps.ts, BOUNDARY) are the
// engine's own, reached by their tests relatively.
export { compilePrefabs, Game, type FrameProbe, type GameEntry, type GameOptions } from './game.ts';
export { liveGame, type LiveGame } from './live-game.ts';
/** Studio mode's probe page (Docs/studio.md §1): a project module with a top-level side effect checks it first. */
export { probing, type UiImport } from './boot-steps.ts';

/**
 * Are the debug tools on? `DEBUG_BUILD` is a literal (the project's `vite.config.ts`), so in a
 * release build this is `false` right here and every branch it guards -- the panel, the editor,
 * every MrDebug action -- is dropped. Module-local on purpose: the bundler does not fold a constant
 * imported from another module.
 */
const DEBUG = DEBUG_BUILD && MrDebug.on;

/**
 * What boot needs of the editor, written here rather than imported: the engine never imports the editor (CLAUDE.md).
 * The editor's own module implements it. Studio mode's (`?studio`): open from the moment `createEditor` makes it, and
 * never closed -- the page is the editor's.
 */
export interface EditorHandle {
  /** Something went wrong that the person should see, on the editor's notices strip under its top bar (studio mode's recovery, Docs/studio.md §1). */
  notice(kind: NoticeKind, text: string, error?: unknown): void;
  /** Every notice of `kind` put away: what it said is over -- a good swap after a failed one, or after a system that threw. */
  clearNotice(kind: NoticeKind): void;
  /** The editor's playtest: none, running (the game the player's, the editor hidden), or paused with the editor over its world. */
  readonly playtestState: 'none' | 'running' | 'paused';
  /** The playtest running, paused: the editor over its world as it is now (studio mode's `P`). Told back as `onPlaytest(false)`. */
  pausePlaytest(): void;
  /** The paused playtest run on, the edits made meanwhile in it (`P` again). Told back as `onPlaytest(true)`. */
  resumePlaytest(): void;
}

/**
 * What a notice is about: `boot` the game could not load (the page is in recovery), `tools` a project's tool module
 * or tool that failed, `frame` a system that threw, `scene` the start scene not opened, `swap` a changed game module
 * that threw as it was evaluated (not swapped: the game runs on the last good code).
 */
export type NoticeKind = 'boot' | 'tools' | 'frame' | 'scene' | 'swap' | 'physics';

/** A notice boot had before the editor was made: handed to it as it is (`createEditor({ notices })`). */
export interface BootNotice {
  kind: NoticeKind;
  text: string;
  error?: unknown;
}

/** What boot asks of the editor's module (`BootOptions.editor`), written here for the same reason. */
export interface EditorModule {
  /**
   * The editor made over the game, and open as it is made: the page is the editor's (`?studio`) -- no Close on its top
   * bar, Playtest at its end; nothing closes it. `extensions` is the project's own (`BootOptions.tools`): its tools after
   * the editor's, its Config pages, inspector blocks and turn facts -- not the editor's `tools`, which replaces its own
   * list. `recovery`: the game could not load, `game` is a stand-in (studio mode's
   * recovery) -- the error the first notice, the Studio tab up on its Console, the page reloaded when the fix lands.
   * `notices`: what boot had to say before the editor was made.
   */
  createEditor(options: {
    name(): string;
    game: Game;
    onPlaytest(playing: boolean): void;
    extensions?: ProjectTools;
    recovery?: { error: unknown };
    notices?: readonly BootNotice[];
  }): EditorHandle;
  /** The start scene was opened at boot (below): the editor calls it the open scene, as saved, when it is first made. */
  openedOnStart(game: Game, key: string): void;
  /** The dev server's re-exports swapped into the running game, and its browser conversions done here (Docs/assets.md §8). Nothing without one. */
  watchAssets(game: Game): void;
  /**
   * Back from a reload the editor survived (Docs/agent.md §4): its record read and deleted, its
   * world loaded in place of the game's. True if there was one: boot then skips the start scene.
   */
  resume(game: Game): boolean;
}

/**
 * A project's own editor tools (its `src/tools/index.ts`, `BootOptions.tools`), as the editor takes them:
 * `tools` (`EditorTool`s, a tab each or a panel within one; each answers a Claude turn's facts as its
 * `context()`), `pages` (`ConfigPage`s) and `blocks` (the inspector's `BlockItem`s) -- typed by
 * `@vibe/editor`, which the engine never imports, so `unknown` here. Debug code: loaded only behind the
 * project's `DEBUG`, as the editor first opens.
 */
export interface ProjectTools {
  tools?: readonly unknown[];
  pages?: readonly unknown[];
  blocks?: readonly unknown[];
  /** The project's own MCP tools (`ProjectMcpTool`, `@vibe/editor`; Docs/mcp.md M7): Claude's, and an outside client's. */
  mcpTools?: readonly unknown[];
}

/** The debug panel and the stats, made by the project's panel module (`BootOptions.panel`). */
export interface DebugTools extends FrameProbe {
  /** The panel (lil-gui): hidden under the editor, shown while its playtest runs. */
  gui: { show(on: boolean): void };
  /** The panel and the stats shown or hidden: HTML over the canvas, so a screen recording would catch them. */
  showOverlays(on: boolean): void;
  /** The editor up over the game (studio mode, no playtest running), or not: the FPS box is the game's, so it is hidden meanwhile. */
  setEditing(on: boolean): void;
}

/** What boot asks of the debug panel's module: the panel over the game, its folders its own. */
export interface PanelModule {
  createDebugTools(game: Game): DebugTools;
}

/** What the HUD must answer to: the sound button drawn on or off. */
export interface HudHandle {
  setMuted(muted: boolean): void;
}

/** What the pause menu must answer to: up or down. */
export interface MenuHandle {
  readonly isOpen: boolean;
  show(on: boolean): void;
}

/** What the HUD and the menu are handed: the pause, the way back, the sound. */
export interface UiActions {
  pause(): void;
  resume(): void;
  toggleSound(): void;
}

/** The project's UI, made over the game: its HUD and pause menu added to the canvas UI (`ui.add`), handed back. */
export type UiHook = (game: Game, ui: CanvasUi, actions: UiActions) => { hud?: HudHandle; menu?: MenuHandle };

export interface BootOptions {
  /** The game's canvas, or its selector: `'#game'`. */
  canvas: string | HTMLCanvasElement;
  /** The loader's elements by selector, in the project's `index.html`: `'#loader'`, `'#loader-bar'`, `'#loader-error'` unless said. */
  loader?: { root?: string; bar?: string; error?: string };
  /** The project's name: its settings' key (`<name>.settings`), and the editor's title unless `title` says. */
  name: string;
  /** The game's name as shown (the editor's top bar). Default: `name`. */
  title?: string;
  /** The game's seed. Default: random (`pickSeed`), or `?seed=` in a debug build. */
  seed?: number;
  /** Worker threads for systems marked `parallel`. Default 0; `?workers=N` in a debug build overrides. */
  workers?: number;
  /**
   * The game: the generated `live.ts`' export (in a build, the same object with nothing registered), or a bare entry --
   * or a function that imports it (`() => import('./game/live.ts').then((m) => m.live)`): then a game module that does
   * not load (a syntax error under `src/game/`) is boot's to catch, and in studio mode the editor still comes up.
   */
  game: LiveGame | GameEntry | (() => Promise<LiveGame | GameEntry>);
  /** Called after `new Game`: the project's scene -- lights, ground, camera. Nothing in the workspace sets one up yet: `Game` builds its lights, ground and orbit camera until a project does. */
  setup?(game: Game): void;
  /**
   * The project's HUD and pause menu, added to the UI here: the hook (`UiHook`) -- or its module's import,
   * `{ import: () => import('./ui/index.ts') }` (its `ui` export the hook), as `game` is a function that imports it: then
   * a UI module that does not load is boot's to catch, and in studio mode the editor still comes up (Docs/studio.md §1,
   * "Recovery").
   */
  ui?: UiHook | UiImport<UiHook>;
  /**
   * Debug builds only, each a dynamic import the project writes behind its own `DEBUG` so a release drops it. `editor`
   * is called in studio mode alone (`?studio`): the plain page never loads it.
   */
  editor?: () => Promise<EditorModule>;
  panel?: () => Promise<PanelModule>;
  /**
   * The project's own editor tools, pages and blocks (`ProjectTools`): its `src/tools/index.ts`, a dynamic import
   * behind its `DEBUG` as the editor's, loaded as the editor is first made and handed to it.
   */
  tools?: () => Promise<ProjectTools>;
  /**
   * The components the project's tools define (a tile layer's): its `src/tools/components.ts`, which imports
   * `@vibe/engine` alone -- never the editor -- a dynamic import behind `DEBUG_BUILD` (not `DEBUG`: the game's worker
   * imports the same module behind the same literal, so page and worker hold one list of components). Awaited before
   * the prefabs compile and the world is made, which copies the registry as it is: after the game's components, as
   * the worker has them.
   */
  components?: () => Promise<unknown>;
  /** A portal SDK's init, awaited first, its progress the bar's 0.1 -> 0.2. */
  portal?(progress: (fraction: number) => void): Promise<void>;
}

export interface Booted {
  game: Game;
  ui: CanvasUi;
  /** The editor, in studio mode: loading, then loaded. Null before, on the plain page, and always in a release. */
  editor: () => Promise<EditorHandle> | null;
  /** Studio mode (`?studio`, a debug build with an editor): the editor opened as boot ended and is never closed. */
  studio: boolean;
}

/** The page owns the little DOM there is; this only finds it. */
function find<T extends HTMLElement>(selector: string): T {
  const el = document.querySelector<T>(selector);
  if (!el) throw new Error(`index.html has no ${selector}`);
  return el;
}

/** The stand-in game's entry in recovery: no systems, no entities -- an empty world for the editor to stand on. */
const RECOVERY_ENTRY: GameEntry = { registerSystems() {}, populate() {} };

/** A task of its own: the loading bar is painted between two long pieces of work. */
const nextTask = (): Promise<void> => new Promise((resolve) => setTimeout(resolve, 0));

/**
 * Boots the page. A failure says so in the loader, in place of its bar, and rejects with it -- left
 * unhandled by a `main.ts` that only `void`s it, so the browser's console says it, once.
 * In studio mode's probe page (`ENTRY_PROBE`) it does nothing and never settles; so, in a debug build, does a second
 * call on a page boot already started on (`BOOT_STARTED`: the cold-start guard's recovery first, main.ts late).
 */
export async function boot(options: BootOptions): Promise<Booted> {
  // Studio mode's probe page evaluating the entry (`ENTRY_PROBE`, boot-steps.ts): nothing booted, never settled.
  if (probing()) return new Promise<Booted>(() => {});
  // Started: studio mode's cold-start guard (Docs/studio.md §1, "Recovery") leaves the page to this from now on. A second
  // boot on this page -- main.ts late, after the guard's recovery booted the editor -- is refused, never settled, and the
  // first boot's editor says so with Reload (`refuseSecond`, `onSecondBoot`).
  if (DEBUG_BUILD && refuseSecond()) {
    console.warn("[boot] boot() called a second time on this page (studio mode's cold-start recovery booted it first): refused -- reload to boot the game");
    return new Promise<Booted>(() => {});
  }
  const loader = find(options.loader?.root ?? '#loader');
  const loaderBar = find(options.loader?.bar ?? '#loader-bar');
  const loaderError = find(options.loader?.error ?? '#loader-error');
  try {
    return await run(options, loader, loaderBar, loaderError);
  } catch (err) {
    // Shown again: recovery's editor that did not load fails here after the loader was put away.
    loader.hidden = false;
    showLoadError(err, loaderBar, loaderError);
    throw err;
  }
}

/** No pause menu from the project: up or down all the same, nothing drawn. */
function noMenu(): MenuHandle {
  let open = false;
  return {
    get isOpen() {
      return open;
    },
    show(on) {
      open = on;
    },
  };
}

async function run(options: BootOptions, loader: HTMLElement, loaderBar: HTMLElement, loaderError: HTMLElement): Promise<Booted> {
  const canvas = typeof options.canvas === 'string' ? find<HTMLCanvasElement>(options.canvas) : options.canvas;
  /** The game's boundary (`live.ts`) once its module is in, or null for a bare entry. */
  let live: LiveGame | null = null;
  const storage = (): Storage => localStorage;
  const settings = readSettings(options.name, storage);
  const step = inOrder();
  const reached = (name: BootStep): void => {
    if (!step(name) && DEBUG) console.warn(`[boot] the step '${name}' came out of BOOT_STEPS' order, or was marked twice (boot-steps.ts): the list and boot have parted`);
  };
  const setProgress = (fraction: number): void => loaderBar.style.setProperty('--progress', `${Math.round(fraction * 100)}%`);

  let game: Game;
  let ui: CanvasUi;
  /** The debug panel and stats, in a debug build with `?debug`. */
  let debugTools: DebugTools | null = null;
  let hud: HudHandle | null = null;
  /** The project's pause menu; none, the pause is kept all the same, with nothing drawn for it. */
  let pauseMenu = noMenu();

  /**
   * **Studio mode** (`?studio`, read beside `?seed` and `?workers`): the editor is the whole page -- open as boot
   * ends (`openStudio`), and kept open: nothing closes it, and its top bar has Playtest at its end. The only page
   * that loads the editor's module. Nothing new in the editor's resume record: the URL keeps it.
   */
  const studio = DEBUG && !!options.editor && readStudio(location.search);
  /** The editor's module, in studio mode: loading, then loaded. */
  let editorLoading: Promise<EditorModule> | null = null;
  /** The editor, in studio mode: loading, then loaded. */
  let editor: Promise<EditorHandle> | null = null;
  /** The same, once loaded: what a key, which cannot wait, asks. */
  let loadedEditor: EditorHandle | null = null;
  /** The editor's playtest is running: the game is the player's again, the editor hidden under it. */
  let playtesting = false;
  /** Boot is done: the game and its UI are there to open the editor over. */
  let booted = false;
  /** The game could not load (studio mode alone): what failed. Boot goes on over a stand-in game, the editor saying it. */
  let recovery: { error: unknown } | null = null;
  /** Notices said before the editor was made: handed to it as it is. */
  const early: BootNotice[] = [];
  /** A notice on the editor's strip, in studio mode -- now, or as the editor is made. Elsewhere the console has said it. */
  const notice = (kind: NoticeKind, text: string, error?: unknown): void => {
    if (!studio) return;
    if (loadedEditor) loadedEditor.notice(kind, text, error);
    else early.push({ kind, text, ...(error !== undefined ? { error } : {}) });
  };
  /** Every notice of `kind` put away, in studio mode: what it said is over. */
  const clearNotice = (kind: NoticeKind): void => {
    if (!studio) return;
    if (loadedEditor) loadedEditor.clearNotice(kind);
    else early.splice(0, early.length, ...early.filter((n) => n.kind !== kind));
  };
  // A second boot refused on this page (`refuseSecond`): main.ts came after all -- said, the notice's Reload the way on.
  if (studio) onSecondBoot(() => notice('boot', SECOND_BOOT_TEXT));
  /** Said once, the first time P would have closed the editor. */
  let studioSaid = false;
  /** P with no playtest: nothing closes, and the first time the console says why. */
  const staysOpen = (): void => {
    if (studioSaid) return;
    studioSaid = true;
    console.info('[editor] studio mode: the editor stays open; Playtest runs the game');
  };

  /**
   * **The editor's module, its one way in**: studio mode's alone, behind `DEBUG` and the project's own gated import --
   * null on the plain page, in a release build, and with no editor. Boot's resume, start scene and asset watch, and
   * `openStudio`, all come through here; a load that failed is tried again by the next.
   */
  const editorModule = (): Promise<EditorModule> | null => (studio ? (editorLoading ??= options.editor!()) : null);

  /** P in studio mode, the editor open: a playtest running paused under the editor, a paused one resumed; else nothing closes. */
  const studioP = (): void => {
    const state = loadedEditor?.playtestState ?? 'none';
    if (state === 'running') loadedEditor!.pausePlaytest();
    else if (state === 'paused') loadedEditor!.resumePlaytest();
    else staysOpen();
  };

  /** Is the game stopped for the editor: studio mode, and no playtest running? */
  const editorHolds = (): boolean => studio && !playtesting;

  /**
   * **The single place that decides whether the game makes sound.** A hidden tab, the player's own
   * mute -- and, for a game with ads, an ad playing, which outranks everything: a tab hidden and
   * shown again mid-ad must not undo it. Whatever changes one of these calls this; nothing else calls
   * `setMuted`.
   */
  const updateMute = (): void => Audio.setMuted(document.hidden || settings.muted);

  /** The pause menu up or down, and the world stopped or running under it. */
  const setPaused = (paused: boolean): void => {
    if (paused === pauseMenu.isOpen) return;
    pauseMenu.show(paused);
    if (paused) game.pause();
    else if (!document.hidden && !editorHolds()) game.resume();
  };

  /** The editor did not load, and the loader says so (`openStudio`): put away when one does. */
  let editorFailed = false;
  /**
   * **Studio mode's one open**, as boot ends: the editor made over the game -- open as it is made, and never closed --
   * the game paused under it, the HUD, the debug panel and its FPS box out of its way. Once: a module that failed to
   * load (a syntax error mid-edit, the dev server gone) leaves nothing open, and `P` tries again.
   */
  const openStudio = async (): Promise<void> => {
    const loading = editorModule();
    if (!loading || editor) return;
    editor = loading.then(async ({ createEditor }) => {
      let extensions: ProjectTools | undefined;
      try {
        extensions = options.tools ? await options.tools() : undefined;
      } catch (err) {
        console.error("[editor] the project's own tools did not load (src/tools/index.ts): the editor opens without them", err);
        notice('tools', `The project's own tools did not load (src/tools/index.ts): the editor is without them -- ${errorWords(err)}`, err);
      }
      ui.layers.hud.visible = false;
      debugTools?.gui.show(false);
      // The FPS box is the game's: not in the editor.
      debugTools?.setEditing(true);
      pauseMenu.show(false);
      game.pause();
      // Boot's notices handed over, and let go of only once the editor is made: one that throws keeps them for the next try.
      const made = createEditor({
        name: () => options.title ?? options.name,
        game,
        onPlaytest: setPlaytest,
        extensions,
        ...(recovery ? { recovery } : {}),
        notices: [...early],
      });
      early.length = 0;
      return (loadedEditor = made);
    });
    try {
      await editor;
      // Loaded after one that did not: the loader's words put away again.
      if (editorFailed) {
        editorFailed = false;
        loader.hidden = true;
        loaderError.hidden = true;
        loaderBar.hidden = false;
      }
    } catch (err) {
      console.error('[editor] the editor did not load', err);
      // Nothing to say it on but the page's own loader: up again over the paused game, its bar away, the error in its
      // place -- never a page that looks as though it is still loading. P tries again.
      editorFailed = true;
      loaderBar.hidden = true;
      loaderError.textContent = editorFailedText(err);
      loaderError.hidden = false;
      loader.hidden = false;
      editor = null;
      editorLoading = null;
      loadedEditor = null;
    }
  };

  /**
   * The editor's playtest on or off: the game running with its HUD -- the editor open under it, hidden,
   * and what ends it. A pause menu opened from the HUD in
   * the meantime goes either way. A playtest paused under the editor (studio mode's `P`) is told as
   * off, its resume as on: `playtesting` is all `editorHolds` reads, so no third state is needed here.
   */
  const setPlaytest = (on: boolean): void => {
    playtesting = on;
    pauseMenu.show(false);
    ui.layers.hud.visible = on;
    debugTools?.gui.show(on);
    // A playtest is the game: its FPS box with it.
    debugTools?.setEditing(!on);
    if (!on) game.pause();
    else if (!document.hidden) game.resume();
  };

  /**
   * The UI on or off, for clean footage: the canvas UI, and the debug overlays with it (HTML, so a
   * screen recording would catch them). `U` in a debug build.
   */
  const setUiVisible = (on: boolean): void => {
    ui.visible = on;
    debugTools?.showOverlays(on);
  };

  const toggleSound = (): void => {
    settings.muted = !settings.muted;
    saveSettings(options.name, settings, storage);
    hud?.setMuted(settings.muted);
    updateMute();
  };

  reached('progress');
  setProgress(0.1);
  if (studio) {
    // Every debug key and button is a MrDebug action: one list, one switch. Studio mode's P, and only there -- on the
    // plain page P is the game's pause key, as in a release (the keydown listener below). It closes nothing: during a
    // playtest it pauses it with the editor over the world as it is, and resumes it (`EditorHandle.pausePlaytest`,
    // `resumePlaytest`); after boot, an editor that did not load is tried again.
    MrDebug.add({ name: 'editor', key: 'KeyP', help: 'Studio mode: the editor stays open; P pauses a playtest with the editor over it, and resumes it (T or the bar\'s Playtest runs one)', run: () => (loadedEditor ? studioP() : booted ? void openStudio() : undefined) });
  }
  // A portal SDK's init goes here, awaited, before anything else.
  reached('portal');
  if (options.portal) await options.portal((fraction) => setProgress(0.1 + fraction * 0.1));
  setProgress(0.2);

  // The game's modules, beside the preload: handed in, or imported now -- a syntax error under src/game/ is this
  // import's rejection, awaited (and caught, in studio mode) where the game is made below.
  // The components the project's tools define (debug builds only), beside the preload: registered before the world is
  // made -- `new Game` below copies the registry as it is -- and after the game's own, as the worker has them: so once
  // the game's modules are in, or failed (`loadGame`, boot-steps.ts). Engine-only modules: nothing of the editor loads
  // here. In studio mode a module that fails is a notice and boot goes on without its components.
  const loading = loadGame<LiveGame | GameEntry>(options.game, DEBUG_BUILD ? options.components : undefined);
  const gameModule = loading.game;
  let toolComponents: Promise<unknown> = loading.components;
  // The project's UI, handed in or imported now beside the game (`loadUi`): an import that fails is caught with it below.
  const uiLoading = loadUi(options.ui);
  /** The project's UI hook, once its module is in. */
  let uiHook: UiHook | undefined;
  if (studio) {
    toolComponents = toolComponents.catch((err: unknown) => {
      console.error("[boot] the project's tool components did not load (src/tools/components.ts): booting without them", err);
      notice('tools', `The project's tool components did not load (src/tools/components.ts): the game boots without them -- ${errorWords(err)}`, err);
    });
  }
  // Ammo beside the preload (Docs/physics.md D2), in a build with physics alone: behind the literal, so a build with it
  // off folds this away and ships none of it. Failing to load is not failing to boot: the game runs with physics
  // inert (`physicsOf` answers nothing), said.
  const ammo: Promise<AmmoApi | null> = PHYSICS_BUILD
    ? import('./physics/ammo.page.ts')
        .then((m) => m.loadAmmo())
        .catch((err: unknown) => {
          console.error('[physics] Ammo did not load: the game runs without physics', err);
          notice('physics', `Ammo did not load: the game runs without physics -- ${errorWords(err)}`, err);
          return null;
        })
    : Promise.resolve(null);
  // The UI's font beside the preload, so its download hides inside the bar;
  // the canvas UI waits for it before it measures a word.
  reached('preload');
  void loadFonts();
  let seed = options.seed;
  if (seed === undefined) {
    seed = pickSeed(DEBUG ? location.search : '');
    if (DEBUG) console.info(`[loop] seed ${seed} (replay it with ?seed=${seed})`);
  }
  /** The real game, once made (only `setup` may throw after): recovery keeps it rather than make a stand-in. */
  let real: Game | null = null;
  /** The step `game` marked (inside `makeGame`): a throw after it is not marked again by the catch. */
  let gameMarked = false;
  /** The preload's end through the game's making: what studio mode's recovery catches. */
  const makeGame = async (): Promise<Game> => {
    // The tools' components in before the prefabs compile and the world is made; awaited beside the preload, so a
    // module that fails to load fails boot here (the loader says so) and never as an unhandled rejection first.
    const [, , physics] = await Promise.all([Assets.preload({ onProgress: (fraction) => setProgress(0.2 + fraction * 0.6) }), toolComponents, ammo]);
    const given = await gameModule;
    uiHook = await uiLoading;
    live = 'arrived' in given ? given : null;
    const entry = live ? live.entry : (given as GameEntry);
    // Every prefab compiled before the world is made: a bad file fails here, naming it (game.ts says how).
    reached('compile');
    // The materials first (Docs/render.md §4): their maps are the registry's textures, loaded by now; a prefab's
    // `Render.material` is checked against them; and the first frame wears them.
    compileMaterials();
    compilePrefabs();
    gameMarked = true;
    reached('game');
    const made = (real = new Game({ canvas, seed, entry, ammo: physics, ...(live ? { worker: live.worker } : {}) }));
    // A change under src/game/ swaps into this game from now on (the project's live.ts, Docs/ecs.md §22). A good swap
    // ends what a failed one said, and what a system that threw said: the code is new (Docs/studio.md §1, "Mid-session").
    if (live) {
      live.onRebuild = (next) => {
        const result = made.rebuild(next);
        if (result === 'swapped') {
          clearNotice('swap');
          clearNotice('frame');
        }
        return result;
      };
      // A changed game module that threw as it was evaluated: not swapped, the world on the last good code -- said.
      live.onFailed = (error) => {
        if (DEBUG) console.error('[game] a changed game module threw as it was evaluated: not swapped -- the game runs on the last good code', error);
        notice('swap', `A changed game module threw as it was evaluated: not swapped, the game runs on the last good code -- ${errorWords(error)}`, error);
      };
    }
    options.setup?.(made);
    return made;
  };
  try {
    game = await makeGame();
  } catch (err) {
    // Recovery is studio mode's alone: a release, or a dev page without `?studio`, fails as ever -- the loader's words.
    if (!studio) throw err;
    recovery = { error: err };
    console.error('[boot] the game could not load: studio mode goes on over a stand-in game, the editor saying what failed', err);
    // Marked here only if the throw came before it (the preload, the game's import, the compile): once, never twice.
    if (!gameMarked) reached('game');
    // A stand-in, unless the game was made and only `setup` threw: an empty world for the editor to stand on.
    game = (real as Game | null) ?? new Game({ canvas, seed, entry: RECOVERY_ENTRY });
    // The game's code arriving is the fix landing: a reload, which boots the game for real.
    if (live) (live as LiveGame).onRebuild = () => 'reload';
  }
  if (DEBUG) {
    // A system that threw: the game stops there, saying which, so the world can be looked at as it was. The tick
    // was ended, so the world is usable. A release says it once on the console and runs on. In studio mode the
    // editor says it too.
    game.onFrameError = ({ system, tick, error }) => {
      const words = `${system ? `The system '${system}'` : 'A frame'} threw on tick ${tick}: the game is paused`;
      console.error(`[game] ${words}`, error);
      // A playtest running is paused as the editor's F6 pauses it -- the editor over the world as the tick left it, the
      // playtest's own state saying so -- never stopped under a pill that still says PLAYING.
      if (loadedEditor?.playtestState === 'running') loadedEditor.pausePlaytest();
      else game.pause();
      notice('frame', `${words} -- ${errorWords(error)}`, error);
    };
  }
  /** Back from a reload the editor survived (studio mode): its world, not the start scene. */
  let resumed = false;
  reached('resume');
  const studioModule = editorModule();
  // Not in recovery: the record stays where it is for the real boot, and nothing is loaded into the stand-in.
  if (studioModule && !recovery) {
    // First, a reload the editor survived -- the agent's code arriving, an index.html edit, a dev-server
    // restart (the editor's resume.ts): its world in place of the game's, before anything else sees it.
    try {
      resumed = (await studioModule).resume(game);
    } catch (err) {
      console.warn('[editor] the editor was not brought back from the reload', err);
    }
  }
  // The start scene (scenes.ts: the scene file that says `"start": true`, chosen in the editor's Config ▸ Game ▸
  // Scenes, committed with it), in place of the world the game built -- in every build, before anything else sees
  // that world. Not over a world a reload brought back. None chosen: the game's own world, as it built it.
  reached('startScene');
  const start = resumed || recovery ? null : startScene();
  if (start) {
    try {
      game.load(scene(start));
      if (DEBUG) console.info(`[game] opened the scene '${start}' on start`);
      if (studioModule) (await studioModule).openedOnStart(game, start);
    } catch (err) {
      console.warn(`[game] the start scene '${start}' was not opened`, err);
      notice('scene', `The start scene '${start}' was not opened: this is the game's own world -- ${errorWords(err)}`, err);
    }
  }
  reached('watchAssets');
  if (studioModule) {
    // From now on, an asset exported again is swapped into what is drawn -- a playtest's frames too.
    try {
      (await studioModule).watchAssets(game);
    } catch (err) {
      console.warn('[editor] re-exported assets will not be swapped in', err);
    }
  }
  // Worker threads for the parallel systems, where the page allows shared memory
  // (`npm run dev:isolated`, or a host that sends the isolation headers). None by
  // default: `?workers=2` in a debug build tries them.
  reached('workers');
  const asked = options.workers ?? 0;
  const workers = DEBUG ? Number(new URLSearchParams(location.search).get('workers') ?? asked) : asked;
  const started = await game.startWorkers(workers);
  if (DEBUG && workers > 0) console.info(started ? `[ecs] ${started} worker threads` : '[ecs] no worker threads: the page is not cross-origin isolated (npm run dev:isolated)');
  // Now that there is a renderer, packs mounted later can ask it what texture
  // compression the GPU supports instead of opening a context of their own.
  reached('renderer');
  Assets.useRenderer(game.renderer);
  setProgress(0.9);
  await nextTask();

  // On the Game's own context, hooked into its frames; before its first frame,
  // so that one has the UI on it too.
  reached('ui');
  ui = await CanvasUi.create(game);
  // Not over a stand-in: the project's HUD and menu are the game's, and may ask it for what it never made.
  const made = (recovery ? undefined : uiHook?.(game, ui, { pause: () => setPaused(true), resume: () => setPaused(false), toggleSound })) ?? {};
  hud = made.hud ?? null;
  hud?.setMuted(settings.muted);
  if (made.menu) pauseMenu = made.menu;

  reached('debug');
  if (DEBUG) {
    MrDebug.add({ name: 'hide UI', key: 'KeyU', help: 'Hide the UI and the debug overlays for clean footage; U again brings them back', run: () => setUiVisible(!ui.visible) });

    if (options.panel) {
      // The panel's folders -- the loop's, the ECS's counters -- are its own (`createDebugTools`).
      const { createDebugTools } = await options.panel();
      debugTools = createDebugTools(game);
      game.debug = debugTools;
    }
    // The console's handles: `game.pause()`, `world.describe()`, `ui.find('hud')`, `MrDebug.enabled = false`.
    Object.assign(window, { game, world: game.world, ui, Assets, Audio, MrDebug });
  }

  reached('first frame');
  game.renderOnce();
  setProgress(1);
  loader.hidden = true;

  reached('listeners');
  updateMute();
  unlockOnFirstGesture();

  // A hidden tab: silent, and stopped -- nothing should run a clock nobody sees.
  // Back again, it runs only if the player had not paused it.
  document.addEventListener('visibilitychange', () => {
    updateMute();
    if (document.hidden) game.pause();
    else if (!pauseMenu.isOpen && !editorHolds()) game.resume();
  });

  // The game's own keys. Debug keys are never here: they are MrDebug actions,
  // and MrDebug takes them before this hears them -- so in studio mode `P` is
  // the playtest's, and on the plain page, in a release or with debug off
  // (MrDebug switched off) it falls through to here and is the pause key.
  addEventListener('keydown', (e) => {
    if (e.repeat || e.metaKey || e.ctrlKey || e.altKey || isTyping(e.target)) return;
    // P and Esc: the pause menu -- never under studio mode's editor, which is a pause of its own (but for its playtest, which is the game).
    if ((e.code === 'KeyP' || e.code === 'Escape') && !editorHolds()) setPaused(!pauseMenu.isOpen);
  });

  // Studio mode: the editor, the game kept paused under it. The plain page: the game, running.
  reached('run');
  if (studio) booted = true;
  if (studio && recovery) {
    // Recovery is the editor's: one that does not load leaves nothing to fix the game with -- the loader's error, as ever.
    await openStudio();
    if (!loadedEditor) throw recovery.error;
  } else if (studio) void openStudio();
  else if (!document.hidden) game.resume();

  return { game, ui, editor: () => editor, studio };
}

/**
 * Audio's gesture: every tap, click or key tries until the context is running. Not the first press
 * alone -- a finger's `pointerdown` does not count as a gesture, its `pointerup` does.
 */
function unlockOnFirstGesture(): void {
  const kinds = ['pointerdown', 'pointerup', 'touchend', 'keydown'] as const;
  const unlock = (): void => {
    if (!Audio.running) {
      Audio.unlock();
      return;
    }
    for (const kind of kinds) removeEventListener(kind, unlock, true);
  };
  for (const kind of kinds) addEventListener(kind, unlock, true);
}

/**
 * The game could not load: the loader says so, in place of its bar. It is HTML, so it needs nothing
 * that failed. In a debug build what failed says itself under the line a player sees -- an LFS
 * pointer, a key with no file -- and a release keeps its one line.
 */
function showLoadError(err: unknown, loaderBar: HTMLElement, loaderError: HTMLElement): void {
  loaderBar.hidden = true;
  let text = 'The game could not load. Check your connection and reload the page.';
  if (DEBUG) text += `\n${err instanceof Error ? err.message : String(err)}`;
  loaderError.textContent = text;
  loaderError.hidden = false;
}
