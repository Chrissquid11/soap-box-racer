/**
 * The mixer: one AudioContext, three buses, and one mute switch.
 *
 * Short sounds are decoded into memory during the loading bar and played from
 * an AudioBuffer, which is the only way to get a pickup sound that lands on
 * the frame it was asked for. Music is streamed from an <audio> element and
 * routed into the same graph, because decoding a two-minute track would cost
 * tens of megabytes of RAM for no benefit.
 *
 * Two rules this file exists to keep:
 *
 *  - **Browsers refuse to start audio without a gesture.** `unlock()` is wired
 *    to the first tap, click or key in `boot` (a finger's `pointerdown` does
 *    not count, its `pointerup` does); until then the context is suspended and
 *    every `play` call is a silent no-op rather than an error.
 *  - **One switch silences everything.** `setMuted()` -- driven by `updateMute()`
 *    in `boot`, the one place that decides (an ad, a hidden tab, the player's
 *    own mute) -- pauses the music element as well as zeroing the master gain,
 *    so a background tab does not keep a stream running.
 *
 * A track forgotten -- every one a pack had, by `drop` when `Packs.unmount`
 * takes it out, or one key by `forget` (a hot update's removed key) -- is
 * stopped if it plays, its element emptied (no `src`, then `load()`: the media
 * released), its node taken off the music bus and its blob URL revoked. (Until
 * the asset pipeline's phase 2 `drop` forgot only the maps, and each unmounted
 * track's element and node stayed on the bus for the session.)
 *
 * Never `new Audio()` in game code: everything goes through here. No page DOM
 * beyond the music elements it makes: `game.ts` may import this directly.
 *
 * Three members are the dev server's and the editor's, in debug builds
 * (Docs/assets.md §5, §7, §8): `forget`, a hot update's removed key;
 * `preview`, a sound played on the ui bus for the Assets tool; and
 * `replaceTrack`, a music file re-exported while the game runs. Each is always
 * there, its body behind `DEBUG` -- a literal `false` in a release, so the stub
 * that throws is all a release keeps. No node test imports this module: a
 * project reaches it through `@vibe/engine/assets`, never the index.
 */
import { type AnyCase, caseKey } from './assets/case-key.ts';
import { entries } from './assets/registry.ts';
import { MrDebug } from './debug/mr-debug.ts';
import { MusicFades } from './music-fade.ts';

/** The debug tools: a literal in a release build, so what it guards is dropped right here (CLAUDE.md). */
const DEBUG = DEBUG_BUILD && MrDebug.on;

/** Fade applied to music changes, in seconds. Long enough not to click. */
const FADE = 0.4;
/**
 * The music's place in the mix, under the player's own volume. A level of the
 * mix rather than the setting's default, so it reaches every player, whatever
 * they have the slider at.
 */
const MUSIC_MIX = 1;

let context: AudioContext | null = null;
let master: GainNode;
let musicBus: GainNode;
let sfxBus: GainNode;
let uiBus: GainNode;

const buffers = new Map<string, AudioBuffer>();
const tracks = new Map<string, HTMLAudioElement>();
/** Each track's node on the music bus, so forgetting a track takes it off the bus. */
const trackNodes = new Map<string, MediaElementAudioSourceNode>();
/** Each track's own gain, between its node and the bus: what the cross-fade moves (`music-fade.ts`). */
const trackGains = new Map<string, GainNode>();
const fades = new MusicFades(FADE, { later: (run, ms) => setTimeout(run, ms), cancel: (handle) => clearTimeout(handle as ReturnType<typeof setTimeout>) });
/** Blob URLs backing pack tracks, so `drop` can revoke them. */
const trackUrls = new Map<string, string>();

let muted = false;
let unlocked = false;
let playing: { key: string; element: HTMLAudioElement } | null = null;
/** The one sound `preview` is playing, if any. */
let previewing: AudioPreview | null = null;
const volumes = { master: 1, music: 1, sfx: 1 };

/**
 * Creates the graph on first use.
 *
 * Constructing an AudioContext before a gesture is allowed -- it just starts
 * suspended -- so this can safely run during loading. Only `resume()` needs
 * the gesture.
 */
function ensure(): AudioContext {
  if (context) return context;
  context = new AudioContext();
  master = context.createGain();
  musicBus = context.createGain();
  sfxBus = context.createGain();
  uiBus = context.createGain();
  master.connect(context.destination);
  for (const bus of [musicBus, sfxBus, uiBus]) bus.connect(master);
  applyVolumes();
  return context;
}

function applyVolumes(): void {
  if (!context) return;
  master.gain.value = muted ? 0 : volumes.master;
  musicBus.gain.value = volumes.music * MUSIC_MIX;
  sfxBus.gain.value = volumes.sfx;
  uiBus.gain.value = volumes.sfx;
}

function playBuffer(key: string, bus: () => GainNode, volume: number, rate: number): void {
  const buffer = buffers.get(key);
  // Missing sound, or audio not unlocked yet. Neither is worth throwing over
  // mid-gameplay -- a silent pickup is better than a dead frame.
  if (!buffer || !unlocked || !context) return;

  const source = context.createBufferSource();
  source.buffer = buffer;
  source.playbackRate.value = rate;
  if (volume === 1) {
    source.connect(bus());
  } else {
    const gain = context.createGain();
    gain.gain.value = volume;
    source.connect(gain).connect(bus());
  }
  source.start();
}

/** A sound going round (`Audio.loop`): its loudness, and the way to end it. */
export interface SoundLoop {
  volume: number;
  stop(fade?: number): void;
}

/** A sound `Audio.preview` is playing: where it is, its level, and the way to end it. */
export interface AudioPreview {
  /** Seconds into the sound. */
  readonly at: number;
  /** 0..1, on top of the ui bus: set as it plays, eased over a few milliseconds so a drag does not click. */
  gain: number;
  stop(): void;
}

export interface PreviewOptions {
  /** Seconds into the sound to start from. Default 0. */
  from?: number;
  /** Round and round until stopped. */
  loop?: boolean;
  /** 0..1, on top of the ui bus. Default 1. */
  gain?: number;
}

export interface PlayOptions {
  /** 0..1, on top of the bus volume. */
  volume?: number;
  /** Playback rate. Randomise slightly (0.9-1.1) so a repeated sound stays alive. */
  rate?: number;
}

/** Attaches a streamed track to the music bus. Shared by preload and packs. */
function addTrack(key: string, src: string): void {
  const element = new window.Audio();
  element.src = src;
  element.loop = true;
  element.preload = 'auto';
  // Routed through the graph so one mute switch covers music too.
  const ctx = ensure();
  const node = ctx.createMediaElementSource(element);
  const gain = ctx.createGain();
  gain.gain.value = 0;
  node.connect(gain).connect(musicBus);
  trackNodes.set(key, node);
  trackGains.set(key, gain);
  tracks.set(key, element);
}

/**
 * A track gone for good: stopped if it is the one playing, its element emptied
 * (no `src`, then `load()`: the media is released, nothing fetched), its node
 * off the music bus, its blob URL revoked.
 */
function forgetTrack(key: string): void {
  const element = tracks.get(key);
  if (element) {
    if (playing?.key === key) playing = null;
    element.pause();
    element.removeAttribute('src');
    element.load();
  }
  fades.forget(key);
  trackNodes.get(key)?.disconnect();
  trackNodes.delete(key);
  trackGains.get(key)?.disconnect();
  trackGains.delete(key);
  tracks.delete(key);
  const url = trackUrls.get(key);
  if (url) {
    URL.revokeObjectURL(url);
    trackUrls.delete(key);
  }
}

export const Audio = {
  /** How many files `preload` will fetch. `Assets` needs it to size the bar. */
  pending(): number {
    return entries('sfx').length + entries('uiSfx').length + entries('music').length;
  },

  /** Decodes every sound and prepares every track. Called by `Assets.preload`. */
  async preload(onStep?: () => void): Promise<void> {
    // No sound listed yet: don't hold an AudioContext the game will never use.
    if (this.pending() === 0) return;
    const ctx = ensure();

    const decode = async ([key, href]: [string, string]): Promise<void> => {
      const data = await fetch(href).then((r) => r.arrayBuffer());
      buffers.set(key, await ctx.decodeAudioData(data));
      onStep?.();
    };

    await Promise.all([
      ...entries('sfx').map(decode),
      ...entries('uiSfx').map(decode),
      ...entries('music').map(async ([key, href]) => {
        addTrack(key, href);
        onStep?.();
      }),
    ]);
  },

  /**
   * Adds a short sound from a mounted pack. Decoded now, played from memory.
   * @internal used by Packs.mount
   */
  async addSound(key: string, bytes: ArrayBuffer): Promise<void> {
    buffers.set(key, await ensure().decodeAudioData(bytes));
  },

  /**
   * Adds a streamed track from a mounted pack.
   * @internal used by Packs.mount
   */
  addPackTrack(key: string, bytes: Uint8Array, type: string): void {
    const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type }));
    trackUrls.set(key, url);
    addTrack(key, url);
  },

  /**
   * Forgets everything a pack added: its buffers, and its tracks stopped,
   * emptied and taken off the music bus (`forgetTrack`), as `forget` does one.
   * @internal used by Packs.unmount
   */
  drop(prefix: string): void {
    for (const key of [...buffers.keys()]) if (key.startsWith(prefix)) buffers.delete(key);
    for (const key of [...tracks.keys()]) if (key.startsWith(prefix)) forgetTrack(key);
  },

  /**
   * One key out, exactly -- not `drop`'s prefix, which would take `crate-2`
   * with `crate`: its buffer, or its track stopped, emptied and taken off the
   * music bus. A loop already playing finishes. Debug builds: a hot update's
   * removed key (`index.ts`, in the dev server).
   */
  forget(key: string): void {
    if (DEBUG) {
      buffers.delete(key);
      forgetTrack(key);
    } else {
      throw new Error('forget is a debug tool');
    }
  },

  /**
   * Debug builds: a music file re-exported, in place of the track under `key`
   * -- the old one forgotten (`forget`: its element, its node on the bus, its
   * URL), the new one added as a pack's is. Not while that track plays: false,
   * and nothing done (the editor says so; it changes when next started).
   */
  replaceTrack(key: string, bytes: Uint8Array, type: string): boolean {
    if (DEBUG) {
      if (playing?.key === key) return false;
      forgetTrack(key);
      this.addPackTrack(key, bytes, type);
      return true;
    } else {
      throw new Error('replaceTrack is a debug tool');
    }
  },

  /**
   * Debug builds: a short sound decoded now -- a sfx's or a ui sound's, a mounted pack's too -- by its key in any
   * case, or null (a music track is streamed, never decoded here): for a tool to `preview` it (the editor's key
   * picker's play button, Docs/properties.md D6).
   */
  buffer(key: string): AudioBuffer | null {
    if (DEBUG) {
      return buffers.get(caseKey(key)) ?? null;
    } else {
      throw new Error('buffer is a debug tool');
    }
  },

  /**
   * Debug builds: a sound played for the editor's Assets tool, on the ui bus --
   * so the mute and `updateMute()` cover it as any other -- one at a time, a
   * second stopping the first. Before the first gesture the context is
   * suspended and it is silent (`running` says so).
   */
  preview(buffer: AudioBuffer, { from = 0, loop = false, gain = 1 }: PreviewOptions = {}): AudioPreview {
    if (DEBUG) {
      previewing?.stop();
      const ctx = ensure();
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.loop = loop;
      const level = ctx.createGain();
      level.gain.value = gain;
      source.connect(level).connect(uiBus);
      const start = Math.max(0, Math.min(from, buffer.duration));
      const began = ctx.currentTime - start;
      source.start(0, start);
      let stopped = false;
      let level01 = gain;
      const handle: AudioPreview = {
        get at() {
          const t = ctx.currentTime - began;
          return loop && buffer.duration > 0 ? t % buffer.duration : Math.min(t, buffer.duration);
        },
        get gain() {
          return level01;
        },
        set gain(to: number) {
          level01 = Math.min(1, Math.max(0, to));
          level.gain.setTargetAtTime(level01, ctx.currentTime, 0.015);
        },
        stop() {
          if (stopped) return;
          stopped = true;
          source.stop();
          level.disconnect();
          if (previewing === handle) previewing = null;
        },
      };
      source.onended = () => {
        stopped = true;
        level.disconnect();
        if (previewing === handle) previewing = null;
      };
      previewing = handle;
      return handle;
    } else {
      throw new Error('preview is a debug tool');
    }
  },

  /**
   * Starts the context. Must be called from a real user gesture -- the click
   * that starts the first round is the natural place.
   */
  unlock(): void {
    const ctx = ensure();
    unlocked = true;
    if (ctx.state === 'suspended') void ctx.resume();
    // A track asked for before the unlock is still waiting to start.
    if (playing && !muted) void playing.element.play().catch(() => {});
  },

  /** Silence, for ad breaks and hidden tabs. Called by `updateMute()` in `boot`, and nothing else. */
  setMuted(value: boolean): void {
    muted = value;
    applyVolumes();
    if (!playing) return;
    if (value) playing.element.pause();
    else if (unlocked) void playing.element.play().catch(() => {});
  },

  get isMuted(): boolean {
    return muted;
  },

  /** The context has started: a gesture let `unlock` through. False until then, and after, if the browser suspends it. */
  get running(): boolean {
    return context?.state === 'running';
  },

  /** Bus volumes, 0..1. The page feeds these from the player's settings. */
  setVolumes(next: Partial<typeof volumes>): void {
    Object.assign(volumes, next);
    applyVolumes();
  },

  /** A game sound by key, in any case (`caseKey`). */
  sfx<const K extends string>(key: AnyCase<K, AssetKeys.Sfx>, { volume = 1, rate = 1 }: PlayOptions = {}): void {
    playBuffer(caseKey(key), () => sfxBus, volume, rate);
  },

  ui<const K extends string>(key: AnyCase<K, AssetKeys.UiSfx>, { volume = 1, rate = 1 }: PlayOptions = {}): void {
    playBuffer(caseKey(key), () => uiBus, volume, rate);
  },

  /**
   * A game sound played round and round until it is stopped: an engine's hum
   * for as long as it runs. `trim` seconds are left off each
   * end of the loop -- an MP3 carries a sliver of silence there, and looping it
   * would put a gap in the sound every time round. Null before audio is
   * unlocked, or for a sound that is not loaded. On the sfx bus, so the mute
   * and the volume slider cover it like any other.
   */
  loop<const K extends string>(key: AnyCase<K, AssetKeys.Sfx>, volume = 1, trim = 0.03): SoundLoop | null {
    const buffer = buffers.get(caseKey(key));
    if (!buffer || !unlocked || !context) return null;
    const ctx = context;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    source.loopStart = Math.min(trim, buffer.duration / 4);
    source.loopEnd = Math.max(source.loopStart + 0.05, buffer.duration - trim);
    const gain = ctx.createGain();
    gain.gain.value = volume;
    source.connect(gain).connect(sfxBus);
    source.start(0, source.loopStart);
    let stopped = false;
    return {
      set volume(v: number) {
        gain.gain.setTargetAtTime(v, ctx.currentTime, 0.03);
      },
      stop(fade = 0.1): void {
        if (stopped) return;
        stopped = true;
        gain.gain.setTargetAtTime(0, ctx.currentTime, fade / 3);
        source.stop(ctx.currentTime + fade);
      },
    };
  },

  /**
   * Cross-fades to a track, or fades the current one out when passed `null`:
   * each track has its own gain (`music-fade.ts`), so one fades down while the
   * other fades up. Back to a track still fading out, it fades up from where
   * it is, never paused by that fade's end.
   */
  music<const K extends string>(asked: AnyCase<K, AssetKeys.Music> | null): void {
    const key = asked === null ? null : caseKey(asked);
    if (playing?.key === key) return;
    const now = context?.currentTime ?? 0;

    if (playing) {
      const previous = playing.element;
      fades.out(playing.key, trackGains.get(playing.key)?.gain ?? null, now, () => previous.pause());
      playing = null;
    }

    if (key === null) return;

    const element = tracks.get(key);
    if (!element) return;
    playing = { key, element };
    if (fades.in(key, trackGains.get(key)?.gain ?? null, now)) return;
    element.currentTime = 0;
    if (unlocked && !muted) void element.play().catch(() => {});
  },

};
