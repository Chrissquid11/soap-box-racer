---
skill: engine
title: Render and animation
when: Before giving an entity a model, a part, a material, a tint or shadows, writing a .material file, or playing a clip from a system
covers:
  modules: [render.ts, animation.ts, view.ts, ecs/render-components.ts, assets/materials.ts, assets/material-file.ts]
order: 40
---
# Render and animation: what an entity looks like, and how it moves

A look is data. An entity is drawn because it has a **`Render`** -- a model, a part of it, a material, a tint,
the shadows -- and moves its model's bones because it has an **`Animation`** -- a clip by name, a speed, a fade.
The engine's own `render` and `animate` systems do the drawing and the playing; a game writes numbers. The code
is `node_modules/@vibe/engine/src/render.ts`, `animation.ts`, and the two components in
`ecs/render-components.ts`.

## `Render`

| Field | What it is |
|---|---|
| `model` | a model's key (`'props/crate'`); `'props/robot#arm'` is the object named `arm` in that model; none: nothing drawn |
| `material` | a material file's key (`'props/rust'`); none: the model's own materials, as authored |
| `tint` | `0xRRGGBB` multiplied into every material of this entity's view; white (`0xffffff`) is none |
| `castShadow`, `receiveShadow` | yes or no, on every mesh of it |

In a prefab file, keys as text (the pipeline adds each one's uid):

```json
"components": ["Transform", "Render", "Animation"],
"data": {
  "Render": { "model": "props/parrot", "material": "props/feathers", "castShadow": false },
  "Animation": { "clip": "fly" }
}
```

- **The engine attaches the view**: when `Render` is added (an instance made, a scene loaded, the inspector's
  Add Component), the model is cloned and put in the scene; a model or part changed makes a new one; a
  material, tint or shadow changed is applied in place; `Render` removed or the entity destroyed takes it away.
  An inspector edit, an override, a prefab recompiled and a system's write all reach the screen the same way.
- **Never `attach` an entity's look by hand**, never `Assets.instance` for a game entity, never a three object
  in a component: `attach` and `Assets.instance` are for a tool's own object. Only render systems touch a
  three.js object, and the engine's cover models, materials, tints and clips.
- **The three scene stays flat**: the tree a game edits is the ECS's (`cmd.setParent`), drawn through
  `WorldTransform`. A part is placed where the whole model draws it.
- A model key and a material key written in a prefab are checked by the typecheck (the generated `keys.d.ts`)
  and by the compile at boot, so a typo fails before the game runs; a part's name is the compile's check.

## Materials: a file each

`src/assets/materials/props/rust.material` is the key `props/rust`: JSON, only what differs from the defaults.

```json
{
  "is": "vibebase.material",
  "version": 1,
  "type": "standard",
  "color": "#8a4b2a",
  "roughness": 0.85,
  "metalness": 0.2,
  "map": "props/rust"
}
```

- `type` is `standard`, `physical`, `basic` or `toon`. The rest: `color`, `roughness`, `metalness`,
  `emissive`, `emissiveIntensity`, `opacity`, `transparent`, `alphaTest`, `side` (`front`, `back`, `double`),
  `flatShading`, `wireframe`, `depthWrite`; the maps (`map`, `normalMap`, `roughnessMap`, `metalnessMap`,
  `aoMap`, `emissiveMap`, `alphaMap`) are texture keys; a `physical` one has `physical: { clearcoat, ... }`.
  `node_modules/@vibe/engine/src/assets/material-file.ts` has every field and its default.
- **One shared three material per file**, compiled after the preload: every entity wearing `props/rust` wears
  the same one. Saved in the dev server, it changes on screen at once.
- A texture key no texture has, or a field the type does not use, is said; `npm test`'s `materials` check reads
  every file. The studio's Assets panel makes and edits them (New material, a Material inspector).

## A per-entity look: a tint, or another material

**A model's materials are the asset store's, shared by every instance.** So never clone one, never write into
one (`mesh.material.color.set(...)` would recolour every crate in the game). A per-entity look is:

- **a tint** -- `Render.tint`, the one per-entity colour (a flash on a hit, a team's colour). The engine clones
  that entity's materials once and frees the clones when it is white again;
- **another material file** -- `Render.material` switched to another key.

A system that writes `tint` writes a designed field: it writes on the edges only (the flash beginning, its end)
and puts back the tint it found, kept in a runtime field of its own -- the sandbox's `flash` system:

```ts
// src/game/systems/flash.ts
import { Render, type World } from '@vibe/engine';
import { Wander, Wanderer } from '../components.ts';
import { FLASH } from './startle.ts';

const STARTLED = 0xff9a6a;

export function flash(world: World): void {
  world.system({
    name: 'flash',
    rate: 60,
    after: ['startle'],
    write: [Wander, Render],
    with: [Wanderer],
    update({ members, count, time }, _read, [target, look]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const until = target.startled[e];
        if (until === 0) continue;
        if (time < until) {
          if (until === time + FLASH) look.tint[e] = STARTLED;   // startled this very tick: warm, once
        } else {
          look.tint[e] = target.rest[e];                         // its own tint back, kept by startle
          target.startled[e] = 0;
        }
      }
    },
  });
}
```

## `Animation`

| Field | What it is |
|---|---|
| `clip` | a clip's name among the clips of the model the entity draws (`'fly'`); none: the rest pose |
| `speed` | 1 as authored; negative plays backwards |
| `fade` | seconds of crossfade when `clip` changes (0.2) |
| `loop` | 0 as the clip says, 1 repeat, 2 once (holds its last pose) |
| `time` | where it is, seconds: runtime and saved, so a loaded game resumes mid-stride |

The clips are the model's own -- a Gladius script's `action{}`s, with the loop and frame rate it wrote. A name
the model lacks is said once, and the rest pose shown. A clip's key is its name alone, so `'fly'` means the
`fly` of whatever model the entity draws.

**In a system, a clip is a number**: intern the name at module level, then compare and write numbers.

```ts
import { Animation, AnimationEnded, internKey, NONE, type World } from '@vibe/engine';
import { Fly } from '../components.ts';

const FLY = internKey('Clip', 'fly');
const WALK = internKey('Clip', 'walk');
const LAND = internKey('Clip', 'land');

export function perch(world: World): void {
  const ended = world.events(AnimationEnded);
  world.system({
    name: 'perch',
    rate: 60,
    write: [Animation],
    with: [Fly],
    update(ctx, _read, [anim]) {
      for (let i = ended.begin(ctx); i < ended.end; i++) {
        const who = ctx.deref(ended.who[i]);
        if (who === NONE || ended.clip[i] !== LAND || !ctx.has(who, Animation)) continue;
        anim.clip[who] = WALK;                         // landed: walk, crossfaded over its fade
        anim.loop[who] = 0;                            // ...looped as the clip says
      }
      for (let n = 0; n < ctx.count; n++) {
        const e = ctx.members[n];
        if (anim.clip[e] === WALK && ctx.rng.chance(0.002)) anim.clip[e] = FLY;
        else if (anim.clip[e] === FLY && ctx.rng.chance(0.004)) {
          anim.clip[e] = LAND;                         // tired: land --
          anim.loop[e] = 2;                            // played once, so its end is said
        }
      }
    },
  });
}
```

- **A clip played once says so**: `AnimationEnded { who, clip }`, read the tick after by any system, as any
  event ([the ECS page](ecs.md)). Only a clip played once: `loop` 2, or `loop` 0 on a clip authored to play
  once (its Gladius `action{ … loop=false }`). A repeating clip never ends, and never says so.
- **Never a mixer of the game's own**, never `THREE.AnimationMixer` in game code: the engine keeps one player per
  view. A pooled instance reused plays its prefab's clip from 0.
- One clip at a time, crossfaded: blending a walk with an aim is not there yet.

## Seeing it

`npm run dev`, then the studio (`?studio`): pick an entity and its Render and Animation blocks show the model,
part, material, tint, shadows and clip as pickers; drag a model from the Assets panel into the scene, a material
onto an entity. A model is made with Gladius (the `gladius` skill), its clips with it; the Model tab is
[the studio's model page](../studio/model.md). The camera it is seen
through is [the camera page](camera.md).
