---
skill: engine
title: A game's shape
when: First, in a project new to you -- what each folder and file is, main.ts and boot(), the scripts, the checks, and which page next
covers:
  modules: [boot.ts, boot-steps.ts, game.ts, live-game.ts, index.ts]
order: 1
---
# A game's shape: the project, `boot()`, the scripts

A Squidwright game is a project on three packages. **`@vibe/engine`** is what the game runs on: the ECS, the
loop, the view, the asset runtime, the canvas UI, `boot()`. **`@vibe/editor`** is the editor -- studio mode,
`?studio` -- in debug builds only. **`@vibe/pipeline`** is the `vibe` command every script runs: the dev server,
the asset pipeline, the tests and the checks, Claude's host. The engine's code is always there to read, in
`node_modules/@vibe/engine/src/` (`index.ts` lists everything it exports).

## The folders

| Where | What it is |
|---|---|
| `src/main.ts` | the page: the project's hooks handed to `boot()` |
| `src/game/` | the gameplay: `components.ts`, `prefabs.ts`, `systems/` (one a file), `systems.ts` (their order), `populate.ts`, `index.ts` (the entry), `worker.ts` -- the [ECS page](ecs.md) |
| `src/ui/` | the HUD and the pause menu, Pixi widgets on the one canvas -- the [UI page](ui.md) |
| `src/assets/` | what ships, each file its key: `models/`, `prefabs/`, `scenes/`, `materials/`, `audio/`, `textures/`, ... -- the [assets page](assets.md) |
| `src/tools/` | the project's own editor tools, debug code -- the [tools page](tools.md) |
| `AssetsSource/` | the originals (Gladius scripts, art, audio masters), exported into `src/assets/` |
| `packs/` | content loaded later, mounted between rounds |
| `public/` | files served as they are (a favicon); never an asset the game looks up |
| `vite.config.ts` | `vibe({ port })` -- and the project's own kinds, routes and tool folders |
| `index.html` | the canvas (`#game`) and the loader (`#loader`, `#loader-bar`, `#loader-error`) |

**Generated, never edited, gitignored**: `src/assets/keys.d.ts` (every key, so a wrong one is a type error),
the globs beside it, `src/assets/bundle.ts`, `prefab-bundle.ts`, `material-bundle.ts`, `uids.ts` and
`src/game/live.ts`. `vibe assets` writes them, and so do `vibe dev`, `vibe typecheck`, `vibe build` and install.

## `main.ts`: the game handed to `boot()`

```ts
// src/main.ts
import './assets/bundle.ts';                       // the project's assets handed to the engine: first, always
import { boot } from '@vibe/engine/boot';
import { MrDebug } from '@vibe/engine/debug';

const DEBUG = DEBUG_BUILD && MrDebug.on;

void boot({
  canvas: '#game',
  name: 'my-game',                                 // its settings' key in the browser's storage
  title: 'My Game',
  game: () => import('./game/live.ts').then((m) => m.live),
  ui: { import: () => import('./ui/index.ts') },   // its HUD and menu: `export const ui: UiHook = (_game, ui, actions) => ({ hud, menu })`
  ...(DEBUG
    ? { editor: () => import('@vibe/editor'), panel: () => import('@vibe/editor/panel'), tools: () => import('./tools/index.ts') }
    : {}),
  ...(DEBUG_BUILD ? { components: () => import('./tools/components.ts') } : {}),
});
```

`boot()` does everything else, in order: the loading bar, `Assets.preload()` (every asset of the boot set
loaded before anything is built), the prefabs compiled, the `Game` made (renderer, scene, loop, world), the
start scene opened, the canvas UI, sound and mute, the pause key, the debug tools, the first frame.

- **The game is a function that imports it**, never a static import: a game module that fails to load (a
  syntax error under `src/game/` mid-edit) is then `boot()`'s to catch, and in studio mode the editor still
  comes up to fix it. **The UI the same**: `ui` is `{ import }`, its module's import (`src/ui/index.ts` exports
  the hook as `ui`, typed `UiHook` from `@vibe/engine/boot`) -- a function there is the hook itself, as before, so `main.ts` imports nothing of the project but the bundle. And
  should `main.ts`' own imports still fail (a bad named import in the bundle's reach), studio mode's dev server boots
  the editor in recovery all the same, saying the file and line.
- **The editor, the panel and the tools are each a `DEBUG`-gated `import()`**: a release folds `DEBUG` to
  `false` and drops them, and the build fails if any of the editor reaches a release. Nothing else in the
  game refers to `@vibe/editor` -- not even `import type`.
- **The other options**: `seed` (the game's; random when not said, `?seed=` in a debug build), `workers`
  (threads for `parallel` systems; `?workers=2` in a debug build, with `npm run dev:isolated`), `setup(game)`
  (after the `Game` is made), `portal(progress)` (a portal SDK's init, awaited first), `loader` (other
  selectors). `boot()` answers `{ game, ui, editor, studio }`.
- **A top-level side effect of the project's own** (storage written, a fetch, an `AudioContext`, a listener)
  checks `probing()` from `@vibe/engine/boot` first: studio mode evaluates a changed module in a hidden page
  before it reloads -- the [debug page](debug.md).

## The game's entry: `src/game/index.ts`

```ts
// src/game/index.ts
export { registerSystems } from './systems.ts';    // every system, in order
export { populate } from './populate.ts';          // the first entities of a fresh world
```

That is a `GameEntry`: `registerSystems(world)`, `populate(world)`, and optionally `installs` (page-side
render code of the game's own that holds three objects, each returning its uninstall) and `loadOldKinds(save)`
(a save of an older format mapped to this one). The generated `live.ts` is the entry's one importer: a change
anywhere under `src/game/` swaps into the running game with no reload -- which is why the world is never kept
in a module variable there.

```ts
import type { World } from '@vibe/engine';
import { BigCrate } from './prefabs.ts';

export function populate(world: World): void {
  world.instantiate(BigCrate);                     // as its file makes it; a Camera prefab too, to see it
}
```

A **start scene** (a scene file with `"start": true`, chosen in the editor's Config ▸ Scenes) is loaded in place
of what `populate` made, in every build.

**The `Game` gives the environment and nothing else**: the sky's colour, fog, a hemisphere light and a sun --
as Unity's skybox and default light. There is no ground: a floor is an entity of the scene's own, as the
template's `Floor` prefab (`prefab('floor')`, a flat box with a `BoxCollider`) in its start scene and
`populate`. A new scene made in the editor is empty but for its `Main Camera`. `src/game/worker.ts` is the worker thread's entry for `parallel`
systems: it registers the same systems and serves them; leave it as the template wrote it.

## The scripts

Each an npm script running `vibe <command>` in the project's folder:

| Script | What it does |
|---|---|
| `npm run dev` | the generated files, then the dev server on the project's port: `/` the game as a player has it (debug keys on), `/?studio` the editor, `/?debug` the debug panel |
| `npm run dev:isolated` | the same, cross-origin isolated: what worker threads need (`?workers=2`) |
| `npm run typecheck` | strict `tsc` over the project: after every edit |
| `npm test` | every `*.test.ts` under `src/`, run by node, then the checks |
| `npm run build` | typecheck, packs, then the release build into `dist/` (no debug tools) |
| `npm run build:debug` | the same with sourcemaps and the debug tools kept |
| `npm run preview` | serve `dist/` |
| `npm run export` | every stale or missing source in `AssetsSource/` exported (`-- --check`: fail if any is) |
| `npm run assets` | every asset given its uid, then the generated files |
| `npm run packs` | every pack zipped into `public/packs/` |
| `npm run sync` | the Claude files into `.claude/`: the `vibe` and `gladius` skills, these pages, the critic |

`npx vibe mcp` prints the line that gives a terminal Claude Code the studio's tools.

## The checks

`npm test` runs the project's tests, then the checks over its source -- each finding its file, its line and
the fix:

| Check | What it holds |
|---|---|
| `ecs` | the system rules (one loop shape, no allocation, rates, `Transform` at 60 Hz), no world kept in a module, no `kind()` in game code |
| `routes` | every debug key and button through MrDebug, no imported `DEBUG`, no browser dialog in the editor |
| `ui` | theme names and units in a widget, never a colour or a size written out |
| `case` | git and the disk agree on the case of every asset path |
| `materials` | every material file reads, and names textures that are there |
| `uids` | every asset has its uid, no uid is two assets' |
| `skills` | these pages read and link; every MCP tool has a studio page |
| `mcp` | every action of a project tool names its MCP tool |

## In the browser

In a dev or `?debug` build the console has `game`, `world`, `ui`, `Assets`, `Audio` and `MrDebug`.
`world.describe()` prints every prefab, component and system, with rates, data and member counts: read it before
changing gameplay. `P` and Esc are the game's pause menu on the plain page.

## Which page next

- Gameplay: [the ECS](ecs.md), then [the loop](loop.md) for rates and time, [prefabs](prefabs.md) for what
  things are made of.
- What is drawn: [render](render.md) (models, materials, tint, animation), [cameras](camera.md).
- Files: [assets](assets.md); sound: [audio](audio.md); the HUD and menus: [UI](ui.md); keys and pads:
  [input](input.md).
- Debug keys and debug code: [debug](debug.md); tests: [testing](testing.md); editor tools of the project's
  own: [tools](tools.md).
- Driving the editors through their MCP tools: the studio skill -- [working in the studio](../studio/studio.md) first,
  then [the scene](../studio/scene.md), [the assets](../studio/assets.md), [a playtest](../studio/play.md), [the code](../studio/code.md).
