/**
 * A relation's links in one world (Docs/ecs.md §16).
 *
 * A link is a row: its two ends, its data, and its place in two lists -- the
 * links out of its source and the links into its target. Both lists run through
 * the rows themselves (`nextOut`, `nextIn`), starting from a column per entity
 * (`firstOut`, `firstIn`), so following them allocates nothing and finding who
 * points at an entity is as cheap as finding whom it points at.
 *
 * - **Row 0 is "no link"**: the end of a list, and what `relate` returns when
 *   the table is full.
 * - **A row is taken at once and linked at the boundary**, like an entity's id:
 *   the caller can fill in its data, and no list changes during a tick.
 * - **Rows are reused**; the table doubles at a boundary when half full.
 *
 * Pure: no DOM, no three.
 */
import { ARRAY_OF, shaped, type Alloc } from './alloc.ts';
import type { Relation } from './component.ts';

/** What a table needs of the world: the bit that says "has a link out". */
export interface RelationHost {
  /** `e` has its first link out of `relation`, or has lost its last. */
  relationBit(e: number, relation: Relation, on: boolean): void;
  /** Is a tick running? Outside one nothing holds a column, so a full table may grow on the spot. */
  midTick(): boolean;
}

interface Rows {
  source: Uint32Array;
  target: Uint32Array;
  nextOut: Uint32Array;
  prevOut: Uint32Array;
  nextIn: Uint32Array;
  prevIn: Uint32Array;
  firstOut: Uint32Array;
  firstIn: Uint32Array;
}

const START = 256;
/** A row's state, kept in `prevOut` of a row that is in no list: taken and waiting for its boundary. */
const PENDING = 0xffffffff;

export class RelationTable {
  readonly relation: Relation;
  /** The store a system is handed: the fields, the ends, the lists. */
  readonly store: Record<string, unknown>;
  /** Links that exist. */
  live = 0;
  /** `relate` calls refused because the table was full. */
  refused = 0;
  private readonly rows: Rows;
  private readonly host: RelationHost;
  private capacity = 0;
  /** The next row never used, and the first of the rows given back (linked through `nextOut`). */
  private fresh = 1;
  private free = 0;
  /** Rows taken, linked or waiting. */
  private taken = 0;
  private warned = false;

  constructor(relation: Relation, alloc: Alloc, host: RelationHost) {
    this.relation = relation;
    this.host = host;
    this.store = shaped([...relation.fields.map((f) => f.name), 'source', 'target', 'firstOut', 'nextOut', 'prevOut', 'firstIn', 'nextIn', 'prevIn']);
    this.rows = this.store as unknown as Rows;
    // An entity's first link each way: per entity, so from the world's allocator.
    alloc.column(this.store, 'firstOut', 'u32');
    alloc.column(this.store, 'firstIn', 'u32');
    this.allocate(START);
  }

  private allocate(rows: number): void {
    const store = this.store as Record<string, { set(from: unknown): void } | null>;
    const column = (name: string, type: keyof typeof ARRAY_OF): void => {
      const next = new ARRAY_OF[type](rows);
      const old = store[name];
      if (old) next.set(old as never);
      store[name] = next as never;
    };
    for (const field of this.relation.fields) column(field.name, field.type);
    for (const name of ['source', 'target', 'nextOut', 'prevOut', 'nextIn', 'prevIn']) column(name, 'u32');
    this.capacity = rows;
  }

  /** A row for a link from `source` to `target`, its data at its defaults: linked at the boundary. 0 if the table is full. */
  reserve(source: number, target: number): number {
    const r = this.rows;
    let p = this.free;
    if (p !== 0) this.free = r.nextOut[p]!;
    else if (this.fresh < this.capacity) p = this.fresh++;
    else if (!this.host.midTick()) {
      // Setup, a load, the editor: no system is running, so there is room to be had now.
      this.allocate(this.capacity * 2);
      p = this.fresh++;
    } else {
      this.refused++;
      if (!this.warned) {
        this.warned = true;
        console.warn(`[ecs] relation '${this.relation.name}' is full at ${this.capacity} links: more than half its room was taken in one tick. relate() returned 0; the table grows at the boundary`);
      }
      return 0;
    }
    this.taken++;
    r.source[p] = source;
    r.target[p] = target;
    r.nextOut[p] = r.nextIn[p] = r.prevIn[p] = 0;
    r.prevOut[p] = PENDING;
    const fields = this.relation.fields;
    const store = this.store as Record<string, number[]>;
    for (let f = 0; f < fields.length; f++) store[fields[f]!.name]![p] = fields[f]!.initial;
    return p;
  }

  /** The link from `source` to `target`, or 0. */
  find(source: number, target: number): number {
    const r = this.rows;
    for (let p = r.firstOut[source]!; p !== 0; p = r.nextOut[p]!) if (r.target[p] === target) return p;
    return 0;
  }

  /** A reserved row into its two lists. A second link between the same two is dropped: the first stands. */
  link(p: number, alive: boolean): void {
    const r = this.rows;
    if (r.prevOut[p] !== PENDING) return;
    const source = r.source[p]!;
    const target = r.target[p]!;
    if (!alive || this.find(source, target) !== 0) {
      this.release(p);
      return;
    }
    if (this.relation.exclusive) while (r.firstOut[source] !== 0) this.unlink(r.firstOut[source]!);
    const out = r.firstOut[source]!;
    r.prevOut[p] = 0;
    r.nextOut[p] = out;
    if (out !== 0) r.prevOut[out] = p;
    else this.host.relationBit(source, this.relation, true);
    r.firstOut[source] = p;
    const into = r.firstIn[target]!;
    r.nextIn[p] = into;
    if (into !== 0) r.prevIn[into] = p;
    r.firstIn[target] = p;
    this.live++;
  }

  /** A link out of its two lists, its row given back. */
  unlink(p: number): void {
    const r = this.rows;
    const source = r.source[p]!;
    const target = r.target[p]!;
    const nextOut = r.nextOut[p]!;
    const prevOut = r.prevOut[p]!;
    if (prevOut !== 0) r.nextOut[prevOut] = nextOut;
    else r.firstOut[source] = nextOut;
    if (nextOut !== 0) r.prevOut[nextOut] = prevOut;
    const nextIn = r.nextIn[p]!;
    const prevIn = r.prevIn[p]!;
    if (prevIn !== 0) r.nextIn[prevIn] = nextIn;
    else r.firstIn[target] = nextIn;
    if (nextIn !== 0) r.prevIn[nextIn] = prevIn;
    if (r.firstOut[source] === 0) this.host.relationBit(source, this.relation, false);
    this.live--;
    this.release(p);
  }

  /** The link from `source` to `target` gone; every link out of `source` if `target` is 0. */
  unrelate(source: number, target: number): void {
    const r = this.rows;
    if (target !== 0) {
      const p = this.find(source, target);
      if (p !== 0) this.unlink(p);
      return;
    }
    while (r.firstOut[source] !== 0) this.unlink(r.firstOut[source]!);
  }

  /** Every link out of and into `e`: it is dying. */
  drop(e: number): void {
    const r = this.rows;
    while (r.firstOut[e] !== 0) this.unlink(r.firstOut[e]!);
    while (r.firstIn[e] !== 0) this.unlink(r.firstIn[e]!);
  }

  /** At a boundary: twice the room once half is taken. */
  roll(): void {
    if (this.taken * 2 <= this.capacity) return;
    this.allocate(this.capacity * 2);
    this.warned = false;
  }

  private release(p: number): void {
    const r = this.rows;
    r.source[p] = r.target[p] = r.prevOut[p] = r.nextIn[p] = r.prevIn[p] = 0;
    r.nextOut[p] = this.free;
    this.free = p;
    this.taken--;
  }
}
