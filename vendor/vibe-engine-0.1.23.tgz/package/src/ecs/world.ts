/**
 * The world: entities, their components' storage, the systems over them, and the
 * tick boundary where everything structural happens (Docs/ecs.md).
 *
 * ```ts
 * const world = new World({ loop });
 *
 * world.system({
 *   name: 'move', rate: 60,
 *   read: [Velocity], write: [Transform],
 *   update({ members, count, dt }, [vel], [at]) {
 *     for (let n = 0; n < count; n++) {
 *       const e = members[n];
 *       at.px[e] += vel.x[e] * dt;
 *     }
 *   },
 * });
 *
 * const e = world.instantiate(Bullet);   // Bullet = prefab('shots/bullet'): Docs/prefabs.md
 * world.init(e, Velocity).x[e] = 3;
 * world.build();
 * ```
 *
 * - **An entity is an index** into every column. Index 0 is nobody (`NONE`).
 * - **A system declares its data** and is handed stores for exactly that. Its
 *   members are the entities with every component in `read`, `write` and `with` and
 *   none in `without`, kept up to date at tick boundaries.
 * - **Structure changes at the boundary**: spawn, destroy, add, remove and
 *   re-parent are commands (`commands.ts`), applied between ticks.
 * - **The id decides the slot**, `index % period`, and a spawn takes an id whose
 *   phase (`index % 60`) is the least used by its kind.
 *
 * Pure: no DOM, no three. `src/view.ts` is the three.js side.
 */
import { CYCLE, Members, TICK_HZ, type Loop, type LoopHooks, type LoopState, type Rate, type RenderContext, type SimulationContext, type SystemInfo } from '../loop/index.ts';
import { Alloc, shaped } from './alloc.ts';
import { ADD, ANNOUNCE, Commands, DESTROY, ENABLE, INSTANTIATE, LAYER, PARENT, PARK, RELATE, REMOVE, SPAWN, STRIDE, TAKE, UNRELATE, type CommandHost } from './commands.ts';
import { makeChannel, type ChannelControl, type EventHost } from './events.ts';
import { fieldIsText, fieldProblem, fieldText, fieldValue } from './keys.ts';
import { fileFields } from './fields.ts';
import { DataError, fillFrom, isData, strayFields } from './data.ts';
import { caseKey } from '../assets/case-key.ts';
import { keyRef, refText, resolveRef, type KeyRef } from '../assets/uids.ts';
import { compiledPrefab, compiledPrefabs, refindNodes, type CompiledPrefab, type EntityOf, type MadeWith, type Override, type PrefabNode, type PrefabToken } from './prefab.ts';
import { RelationTable, type RelationHost } from './relation.ts';
import { MAX_DEPTH, Transforms } from './transform.ts';
import {
  allKinds, allComponents, Bare, Disabled, NO_REF, Hidden, Hierarchy, Instance, Layer, maskBits, Transform, WorldTransform,
  type Access, type AnyComponent, type Channel, type Component, type DataComponent, type Entity, type EntityRef, type EventType, type Field, type Kind, type ObjectComponent,
  type Reads, type Relation, type Schema, type Store, type StoreOf, type Writes,
} from './component.ts';

/** Bits of an `EntityRef` that are the index: 262,143 entities. The other 12 are the generation. */
/** The bits of an `EntityRef` that are its entity's index (the rest its generation): what keys of entity pairs are sized by. */
export const INDEX_BITS = 18;
const INDEX_MASK = (1 << INDEX_BITS) - 1;
const GENERATION_MASK = 0xfff;
/** The most entities any world can hold: what a ref's index can say. */
export const ENTITY_LIMIT = 1 << INDEX_BITS;

/** An entity's state. */
const FREE = 0;
/** Spawned this tick: has its id and its rows, is in no system yet. */
const UNBORN = 1;
const ALIVE = 2;
/** Destroyed at this boundary, its index not yet handed back. */
const DEAD = 3;

/** Flags on an entity during a boundary. */
const DIRTY = 1;
const MOVED = 2;
/** A pooled prefab's instance given back: parked, or resting a tick before it is (Docs/prefabs.md §5). Not alive, in no system. */
const PARKED = 8;
/** Every system looks at it again, not only those on the bits that changed: play, layer or a switch changed. */
const FULL = 4;

/** Bits of `inactive`: out of play, out of sight. */
const OFF = 1;
const UNSEEN = 2;

export interface WorldOptions {
  /** The loop its systems run on. */
  loop: Loop;
  /** Room for this many entities to start with: the world grows when half is in use. Default 16,384. */
  entities?: number;
  /** The most it may grow to: at most 262,144. Default 131,072. At the ceiling a spawn returns `NONE`. */
  maxEntities?: number;
  /** Make two systems of one level that share written data a startup error, instead of running them in registration order. Default false. */
  strictOrder?: boolean;
  /** Put every column in shared memory, for workers. Default: whether the page is cross-origin isolated. */
  shared?: boolean;
  /** In a worker: the main thread's world to be a second view of (`World.sharing()`). `worker.ts` passes it. */
  attach?: WorldSharing;
}

/** What a worker needs to see the same data: the columns' buffers, and enough to check both sides agree. */
export interface WorldSharing {
  /** Every column's buffer, in the order the columns were made. */
  buffers: SharedArrayBuffer[];
  rows: number;
  maxRows: number;
  /** Component names in definition order, and parallel systems' names in registration order. */
  components: string[];
  jobs: string[];
}

/**
 * What runs a parallel system's members on other threads (`parallel.ts`). The
 * world hands it the members past the first share, runs that share itself,
 * then waits.
 */
export interface ParallelRunner {
  /** Fewer members than this and the system runs here, whole: handing it out would cost more. */
  readonly threshold: number;
  /** Members from `mine` on to the workers, in equal shares; returns `mine`, how many are left for this thread. */
  dispatch(job: number, stage: number, members: Uint32Array, count: number, tick: number, rows: number): number;
  /** Until every worker is done. Throws what a worker threw. */
  wait(system: string): void;
}

/** A parallel system as both threads keep it: its two stages and its stores. */
interface Job {
  readonly name: string;
  readonly stages: readonly [((ctx: any, read: any, write: any) => void) | undefined, ((ctx: any, read: any, write: any) => void) | undefined];
  readonly read: unknown;
  readonly write: unknown;
  /** The one context it is ever handed, on this thread: no commands, no random numbers, no input. */
  readonly ctx: ParallelContext;
}

/** An object component's store: its slots, and `get(e)` -- a method on the prototype, so a read allocates nothing. */
class ObjectSlots {
  readonly value: unknown[];
  constructor(rows: number) {
    this.value = new Array<unknown>(rows).fill(null);
  }
  get(e: number): unknown {
    return this.value[e];
  }
}

/**
 * A parallel system's context: the members, the time, `ref`, `deref` and `has`.
 * What only the main thread has -- commands, the random stream, input -- throws
 * when touched, here as on a worker, so a system behaves the same on both.
 *
 * A class, with the refusals on its prototype: an object literal with getters
 * in it is a hash table to V8, and storing the time in one boxed it every tick.
 */
class ParallelContext {
  members: Uint32Array = new Uint32Array(0);
  count = 0;
  tick = 0;
  /** Starts as a fraction so the field holds fractions from the first. */
  time = 0.5;
  readonly dt: number;
  readonly period: number;
  readonly staggered: boolean;
  readonly ref: Extras['ref'];
  readonly deref: Extras['deref'];
  readonly has: Extras['has'];
  readonly enabled: Extras['enabled'];
  readonly active: Extras['active'];
  readonly changed: Extras['changed'];
  readonly world: World;
  private readonly system: string;

  constructor(system: string, period: number, staggered: boolean, extras: Extras) {
    this.system = system;
    this.dt = period / TICK_HZ;
    this.period = period;
    this.staggered = staggered;
    this.ref = extras.ref;
    this.deref = extras.deref;
    this.has = extras.has;
    this.enabled = extras.enabled;
    this.active = extras.active;
    this.changed = extras.changed;
    this.world = extras.world;
  }

  get cmd(): never {
    return this.deny('cmd');
  }

  get rng(): never {
    return this.deny('rng');
  }

  get input(): never {
    return this.deny('input');
  }

  private deny(what: string): never {
    throw new Error(`[ecs] system '${this.system}' is parallel and used ctx.${what}: a parallel system may run on a worker thread, where there is none. Take parallel off, or move that part to another system`);
  }
}

/** The members a system is handed: entity indices. Read `count` of them. */
export interface EntityList {
  readonly [n: number]: Entity;
  readonly length: number;
}

/** What the ECS adds to a system's context. */
interface Extras {
  /** A reference to `e` that can be kept across ticks. */
  ref(e: Entity): EntityRef;
  /** The entity a reference points to, or `NONE` if it has died. */
  deref(r: EntityRef): Entity;
  /** Does `e` have `component`? As of the last boundary. Switched off still counts as had. */
  has(e: Entity, component: AnyComponent): boolean;
  /** Does `e` have `component`, switched on? What membership goes by. */
  enabled(e: Entity, component: AnyComponent): boolean;
  /** Is `e` in play: neither it nor any ancestor `Disabled`? */
  active(e: Entity): boolean;
  /**
   * Has `component`'s data on `e` changed since this system last ran (or been
   * added)? Only for components the system lists in `changed`.
   */
  changed(e: Entity, component: Component<any>): boolean;
  readonly world: World;
}

/** A simulation system's context: the loop's, with the ECS's own. One object a system: read it during the call. */
export interface SystemContext extends Omit<SimulationContext, 'members'>, Extras {
  /** The entities due now. Loop `for (let n = 0; n < count; n++) { const e = members[n]; ... }`. */
  readonly members: EntityList;
  /** This system's commands: spawn, destroy, add, remove, setParent. Applied at the boundary. */
  readonly cmd: Commands;
}

/** A render system's context. */
export interface RenderSystemContext extends RenderContext, Extras {
  /** Every entity that matches, each frame. */
  readonly members: EntityList;
  readonly count: number;
}

interface Declares<R extends readonly Access[], W extends readonly Access[]> {
  /** Unique among all systems. */
  name: string;
  /** Components it reads: on the entity, handed over read-only. */
  read?: R;
  /** Components it writes: on the entity, handed over writable. */
  write?: W;
  /** Components (usually tags) an entity must have, with no data wanted. */
  with?: readonly AnyComponent[];
  /** Components an entity must not have. */
  without?: readonly AnyComponent[];
  /**
   * Components of which an entity must have at least one: "or". For their
   * data, list them in `read` or `write` as `optional(...)` and check `has`.
   */
  any?: readonly AnyComponent[];
  /** Systems of the same phase this one runs after. */
  after?: readonly string[];
  /**
   * Numeric components whose changes it asks about with `ctx.changed(e, C)`.
   * The world then compares each one's data against a copy once a tick: nobody
   * marks anything, and it costs only for the components listed somewhere.
   */
  changed?: readonly Component<any>[];
  /** Layers an entity must be on, 0 to 31. Default: any. */
  layers?: readonly number[];
  /** Members even when `Disabled`, or under something that is. Default false: the switched-off are in no system. */
  includeDisabled?: boolean;
}

export interface SimulationDef<R extends readonly Access[], W extends readonly Access[]> extends Declares<R, W> {
  phase?: 'simulation';
  /** Hz, from the closed list. 60 for anything drawn that moves; slower for what decides. */
  rate: Rate;
  /** A whole number: cost per member, for the load readout. Default 1. */
  weight?: number;
  /** Spread members over the period's slots (default), or run them all on one tick. */
  stagger?: boolean;
  /**
   * A promise that `update` and `lateUpdate` touch only their own members'
   * rows: read and write numeric components, and nothing else -- no `cmd`, no
   * `rng`, no `input`, no events, no other entity's rows written. Its members
   * may then be split across worker threads (Docs/ecs.md §10). With no workers
   * it runs here as usual, under the same restrictions, so it behaves the same
   * either way.
   */
  parallel?: boolean;
  /** New members, once, the tick after they joined: "added". */
  onJoin?(ctx: SystemContext, read: Reads<R>, write: Writes<W>): void;
  /**
   * Those that stopped being members at the last boundary, once, the tick
   * after: "removed". They may be dead, but their rows are still as they were:
   * an index is not reused for a tick.
   */
  onLeave?(ctx: SystemContext, read: Reads<R>, write: Writes<W>): void;
  /** The first stage: things move. Sees world transforms from the end of the last tick. */
  update?(ctx: SystemContext, read: Reads<R>, write: Writes<W>): void;
  /** The second stage, after propagation: things follow. Sees this tick's world transforms. */
  lateUpdate?(ctx: SystemContext, read: Reads<R>, write: Writes<W>): void;
}

export interface RenderDef<R extends readonly Access[], W extends readonly Access[]> extends Declares<R, W> {
  phase: 'render';
  update(ctx: RenderSystemContext, read: Reads<R>, write: Writes<W>): void;
}

/** A standing query: `world.query({ with: [Enemy] })`, made once and kept. */
export interface Query {
  /** The entities that match, as of the last boundary. Read `count` of them. */
  readonly members: EntityList;
  readonly count: number;
}

/** One system as the world knows it. */
interface Sys {
  readonly name: string;
  readonly phase: 'simulation' | 'render' | 'query';
  readonly rate: number;
  /** Mask words an entity must have, and must not. */
  readonly need: Uint32Array;
  readonly not: Uint32Array;
  /** Mask words of which it must have at least one bit; null for no such condition. */
  readonly some: Uint32Array | null;
  /** The layers it takes, a bit each; all 32 by default. */
  readonly layers: number;
  readonly includeDisabled: boolean;
  /** False for a system that declared no component: it has no members. */
  readonly selective: boolean;
  /** Its number in the loop, for a simulation system; -1 otherwise. */
  readonly handle: number;
  /** Its own member list, for a render system or a query. */
  readonly own: Members | null;
  readonly reads: readonly AnyComponent[];
  readonly writes: readonly AnyComponent[];
  readonly cmd: Commands | null;
  /** Which stages it has: systems with none in common never run interleaved. */
  readonly stages: string;
}

/** A component whose changes someone asked about: its data as last seen, and the tick each row last changed on. */
interface Tracked {
  readonly component: Component<any>;
  stamp: Int32Array;
  readonly shadow: Record<string, ArrayLike<number>>;
  readonly members: Members;
}

/** `world.save()`: plain data, safe to turn into JSON. */
export interface WorldSave {
  version: 1;
  /** The tick and the random streams. */
  loop: LoopState;
  /** One past the highest entity index, and every index's generation up to there: refs survive a save. */
  extent: number;
  generations: number[];
  /** The living, by index, and the kind each began as. */
  entities: number[];
  kinds: string[];
  /** child, parent, child, parent: in each parent's own order. */
  parents: number[];
  /** The roots in their order (Docs/ecs.md §8); none in a save from before it was kept, whose roots load by index. */
  roots?: number[];
  /** Each living entity's layer, in `entities` order. */
  layers: number[];
  /**
   * The `Instance` column, in `entities` order: `prefab` indexes `keys` (0: none), so a save survives
   * prefabs added or reordered. A load finds each entity's node again by its kind's name, not by
   * `node` (`refindNodes`, Docs/prefabs.md §6), and chains each instance anew, not by `next`: both
   * are kept for a reader of the file. `nodes[k]`, the kinds of `keys[k]`'s nodes when saved, in node
   * order: what tells a node added to the prefab since (absent in a save from before it); `names[k]`
   * their names, what finds a node whose id was renamed since.
   */
  instances?: {
    /** Each prefab's reference (Docs/asset-ids.md §3): `{ uid, key }`, or its key alone; `''` first, for none. */
    keys: (string | KeyRef)[]; prefab: number[]; node: number[]; root: number[]; next: number[]; nodes?: string[][]; names?: (string | null)[][];
    /**
     * A scene's or a level's (`sceneSave`, Docs/prefabs.md §6): each instance's overrides, by its root's index, as a
     * prefab file's (§2). There, a load brings every instance up to its prefab as compiled now (`refreshInstances`);
     * a save without them -- a game saved at runtime -- plays back as it was.
     */
    overrides?: Record<string, Override[]>;
  };
  /** By component name: who has it, its data by field (numbers) or by value (objects), and on whom it is switched off. */
  /** Each component's entities and data: a numeric one's by field, a key field's as its reference (`{ uid, key }` or the key: `key()`, `ecs/keys.ts`). */
  components: Record<string, { entities: number[]; fields?: Record<string, (number | string | KeyRef | string[] | number[])[]>; values?: unknown[]; disabled?: number[] }>;
  /** By relation name: each link's two ends and its data. */
  relations: Record<string, { source: number[]; target: number[]; fields: Record<string, number[]> }>;
  /**
   * `'index'`: a component's `ref()` fields hold the entity's index, 0 for nobody -- a scene's (`sceneSave`,
   * Docs/prefabs.md §2), whose entities keep their indices on load. Absent: an `EntityRef` as the column held it -- a
   * game saved at runtime, an undo step, a scene from before.
   */
  refs?: 'index';
  /**
   * A live swap's own save (`rebuildWorld`): loaded into the game's code defined again, so a data component's field
   * the new code no longer has is left out without a word. Any other save says each one in `load()`'s `skipped`.
   */
  swap?: true;
}

/** A kind's name with prefab `from`'s key as `to`'s: `crates/big/rider` is `crates/huge/rider`; any other as it is. */
const renamedKind = (kind: string, from: string, to: string): string => (kind === from ? to : kind.startsWith(`${from}/`) ? `${to}${kind.slice(from.length)}` : kind);

/**
 * The kind prefab `k`'s root was saved as -- its key when the save was written -- for a save with no `nodes` (from
 * before they were kept): the kind of an entity with that prefab at node 0. Never the reference's key, which the
 * repair pass may have rewritten since. Undefined when no root of it was saved.
 */
function rootKind(save: WorldSave, k: number): string | undefined {
  const inst = save.instances!;
  for (let i = 0; i < save.entities.length; i++) if (inst.prefab[i] === k && inst.node[i] === 0) return save.kinds[i];
  return undefined;
}

/**
 * A save with each prefab's reference resolved (Docs/asset-ids.md §1, rule 4): `instances.keys` the keys now, by uid
 * first; and where a prefab has moved since the save was written -- its key then, its root's kind as saved (`nodes`),
 * not its key now -- its entities' kinds and its saved nodes named after it now, so a load finds each node again.
 * The kind, not the reference's key, says where it was -- the root's kind as saved (`nodes`, else the kind of its
 * root entity in the save): the pipeline's repair pass rewrites the key, never the kinds.
 * A save already resolved comes back as it is; the one given is never changed.
 */
export function followSavedPrefabs(save: WorldSave): WorldSave {
  const inst = save.instances;
  if (!inst) return save;
  let keys: (string | KeyRef)[] | undefined;
  let kinds: string[] | undefined;
  let nodes: string[][] | undefined;
  inst.keys.forEach((ref, k) => {
    if (k === 0) return;
    const now = resolveRef('prefabs', ref);
    if (now === null) return;
    if (typeof ref !== 'string' || ref !== now) (keys ??= [...inst.keys])[k] = now;
    const was = inst.nodes?.[k]?.[0] ?? rootKind(save, k) ?? refText(ref);
    if (caseKey(was) === caseKey(now)) return;
    const from = caseKey(was);
    const to = caseKey(now);
    kinds ??= [...save.kinds];
    save.entities.forEach((_e, i) => {
      if (inst.prefab[i] === k) kinds![i] = renamedKind(caseKey(kinds![i]!), from, to);
    });
    if (inst.nodes?.[k]) (nodes ??= inst.nodes.map((n) => [...n]))[k] = inst.nodes[k]!.map((kind) => renamedKind(caseKey(kind), from, to));
  });
  if (!keys && !kinds) return save;
  return { ...save, ...(kinds ? { kinds } : {}), instances: { ...inst, ...(keys ? { keys } : {}), ...(nodes ? { nodes } : {}) } };
}

/** One system, for a readout: the loop's `SystemInfo` and the ECS's side of it. */
export interface SystemReport extends SystemInfo {
  /** False for a system registered on the loop directly, without the world. */
  ecs: boolean;
  /** An engine stage (`world.stage`), not a system: the physics' step. */
  stage?: boolean;
  members: number;
  reads: string[];
  writes: string[];
}

/** What an engine stage says of itself for `systemInfo()` and `describe()`: the components it reads and writes, and how many entities it has. */
export interface StageInfo {
  readonly reads: readonly string[];
  readonly writes: readonly string[];
  members(): number;
}

/** Counters worth watching: the places that can still allocate, and how full the world is. */
/**
 * A pooled prefab's pool in one world (Docs/prefabs.md §5): `world.pool(P)`.
 * Parked instances wait `Disabled` in no system; `instantiate` takes one, and
 * `destroy` on an instance's root gives it back. Its numbers are the world's
 * to keep: read-only here.
 */
export interface Pool {
  /** The compiled prefab's id. */
  readonly id: number;
  /** Its prefab as compiled now. */
  readonly prefab: CompiledPrefab;
  /**
   * The `i`th parked root, from 0 to `parked - 1`: a queue, the one parked
   * longest first, and the first taken -- so wear (a generation a cycle) is
   * spread over every parked root, not put on a few (Docs/prefabs.md §5).
   */
  parkedAt(i: number): Entity;
  /** Instances parked, ready to be taken. */
  readonly parked: number;
  /** Given back since the last tick: parked once `onLeave` has read them, at the next boundary. */
  readonly resting: number;
  /** Instances out: taken or made, and not given back. */
  readonly out: number;
  /** The most ever out at once. */
  readonly mostOut: number;
  /**
   * Every instance parked or resting destroyed for real, its slots and models
   * freed -- a `destroy` still waiting for the boundary included: between
   * rounds. Instances out are left alone. Outside a tick.
   */
  drain(): void;
  /** As `drain`, but `keep` are left parked. Outside a tick. */
  trim(keep: number): void;
}

/** A `Pool` as the world keeps it: its counters written by the world alone. */
class PoolRows implements Pool {
  readonly id: number;
  /** The parked roots, a ring: `parked` of them from `head` on, wrapping. */
  private roots: Uint32Array;
  private head = 0;
  parked = 0;
  resting = 0;
  out = 0;
  mostOut = 0;
  /** Said once that it is at its `max`; said again only once it has had none out (a burst over), or after a drain or a load. */
  warned = false;
  private readonly drop: (pool: PoolRows, keep: number) => void;
  constructor(id: number, room: number, drop: (pool: PoolRows, keep: number) => void) {
    this.id = id;
    this.roots = new Uint32Array(Math.max(room, 4));
    this.drop = drop;
  }
  get prefab(): CompiledPrefab {
    return compiledPrefabs()[this.id]!;
  }
  parkedAt(i: number): Entity {
    return (i >= 0 && i < this.parked ? this.roots[(this.head + i) % this.roots.length]! : 0) as Entity;
  }
  /** `root` parked, at the back of the queue. */
  push(root: number): void {
    if (this.parked === this.roots.length) {
      // alloc-ok: grows by doubling, up to `max`; laid out from 0 again
      const next = new Uint32Array(this.roots.length * 2);
      for (let i = 0; i < this.parked; i++) next[i] = this.roots[(this.head + i) % this.roots.length]!;
      this.roots = next;
      this.head = 0;
    }
    this.roots[(this.head + this.parked++) % this.roots.length] = root;
  }
  /** The one parked longest, off the queue: the next taken. */
  shift(): number {
    const root = this.roots[this.head]!;
    this.head = (this.head + 1) % this.roots.length;
    this.parked--;
    return root;
  }
  /** The one parked last, off the queue: the first let go by a trim. */
  pop(): number {
    return this.roots[(this.head + --this.parked) % this.roots.length]!;
  }
  /** Nothing parked, resting or out: after a load drained it. */
  clear(): void {
    this.parked = this.resting = this.out = this.head = 0;
    this.warned = false;
  }
  drain(): void {
    this.drop(this, 0);
  }
  trim(keep: number): void {
    this.drop(this, Math.max(0, keep));
  }
}

export interface WorldStats {
  /** Entities alive, the unborn and the parked included. */
  entities: number;
  /** Of those, entities of pooled prefabs' parked instances (Docs/prefabs.md §5): not alive to the game, waiting to be taken. */
  parked: number;
  /** Rows allocated. */
  capacity: number;
  /** Times the storage grew. */
  growths: number;
  /** Times an object component's pool was empty and `create` ran. */
  poolMisses: number;
  /** Times a command buffer had to grow. */
  commandGrowths: number;
  /** Spawns refused because the world was full. */
  refused: number;
}

/** What a system does instead of a `world.x()` that only works between ticks. */
const OUTSIDE_HINT: Record<string, string> = {
  flush: 'inside a system use ctx.cmd.spawn and the rest; the boundary comes by itself',
  spawn: 'inside a system use ctx.cmd.spawn()',
  instantiate: 'inside a system use ctx.cmd.instantiate()',
  destroy: 'inside a system use ctx.cmd.destroy()',
  add: 'inside a system use ctx.cmd.add()',
  remove: 'inside a system use ctx.cmd.remove()',
  setParent: 'inside a system use ctx.cmd.setParent()',
  relate: 'inside a system use ctx.cmd.relate()',
  unrelate: 'inside a system use ctx.cmd.unrelate()',
  enable: 'inside a system use ctx.cmd.enable()',
  setLayer: 'inside a system use ctx.cmd.setLayer()',
};

/** A world's options as the constructor defaulted them, kept for `reset` to allocate again: defaulted once, there. */
type WorldSetup = Required<Pick<WorldOptions, 'entities' | 'maxEntities' | 'strictOrder'>> & Pick<WorldOptions, 'shared' | 'attach'>;

export class World implements CommandHost, RelationHost, EventHost {
  readonly loop: Loop;
  /** Kept from construction, for `reset` (the world made again from them). */
  private readonly options: WorldSetup;
  readonly stats: WorldStats = { entities: 0, parked: 0, capacity: 0, growths: 0, poolMisses: 0, commandGrowths: 0, refused: 0 };
  /** Mask words per entity: `wordCount`, read-only to everyone but `allocate`. */
  get words(): number {
    return this.wordCount;
  }
  /** An entity's components, `words` each. As of the last boundary. */
  mask!: Uint32Array;

  // Every field below is given its first value by `allocate`, never at its
  // declaration: `reset` calls it again, so a field it did not set would carry
  // the old world over (src/ecs/reset.test.ts compares the two field by field).
  private alloc!: Alloc;
  private strictOrder!: boolean;
  private components!: readonly AnyComponent[];
  /** This world's hooks on the loop: taken off it again by `reset`. */
  private loopHooks!: LoopHooks;

  // ── entities ──
  private gen!: Uint16Array;
  private state!: Uint8Array;
  private kindOf!: Uint16Array;
  private flags!: Uint8Array;
  /** The next free id of the same phase: the free rings are linked through here. */
  private nextFree!: Uint32Array;
  /** `mask` as the systems last saw it: what changed is the difference. */
  private seen!: Uint32Array;
  /** Components switched off, a bit each like `mask`: had, but not counted. */
  private off!: Uint32Array;
  /** Out of play (`OFF`) or out of sight (`UNSEEN`), itself or by an ancestor: derived from `Disabled` and `Hidden` down the tree. */
  private inactive!: Uint8Array;
  /** Free ids by phase, first in first out: the oldest and the newest of each ring. */
  private head!: Uint32Array;
  private tail!: Uint32Array;
  /** The next id of each phase that has never been used. */
  private fresh!: Uint32Array;
  /** One past the highest id ever handed out. */
  private high!: number;
  /** Living entities of each kind, by phase; and where each kind's search starts, and its lowest count. */
  private kindCount!: Int32Array[];
  private kindCursor!: number[];
  private kindLow!: number[];

  // ── storage ──
  private stores!: unknown[];
  /** A numeric component's columns and defaults, in field order: for writing a new row. */
  private columns!: ArrayLike<number>[][];
  private initials!: number[][];
  private pools!: unknown[][];
  /** Each component's `onAdd` hooks in registration order, null for none: a list replaced, never changed, so one running sees the one it began. */
  private addHooks!: (readonly ((e: Entity) => void)[] | null)[];
  private toggleHooks!: (((e: Entity, on: boolean) => void) | null)[];
  private activeHooks!: ((e: Entity, active: boolean, seen: boolean) => void)[];
  private layerHooks!: ((e: Entity, layer: number) => void)[];
  /** `onLoad`'s: told after every load. */
  private loadHooks!: (() => void)[];
  /** Each component's `onRemove` hooks, as `addHooks`. */
  private removeHooks!: (readonly ((e: Entity, value: unknown) => void)[] | null)[];
  private links!: Store<typeof Hierarchy.schema>;
  /**
   * The roots' order (Docs/ecs.md §8): every living root -- no parent, not
   * parked -- in a sibling chain through its `prevSibling`/`nextSibling`, as a
   * parent's children are; its ends here, not in row 0, which nobody reads.
   */
  private headRoot!: number;
  private tailRoot!: number;
  private layerStore!: Store<typeof Layer.schema>;
  private instanceStore!: Store<typeof Instance.schema>;
  /** An instance's entities by node while it is made: grown, never shrunk. */
  private parts!: Uint32Array;
  /** An instance's link rows of one relation while they are made, by the prefab's link index: grown, never shrunk. */
  private linkRows!: Uint32Array;
  /** The last `reserveInstance` ran out of ids part way. */
  instanceRefused!: boolean;
  /** The entity a `kill` under way began from: what an instance's part asks of its root, is it dying too. */
  private killing!: number;
  private instanceHooks!: ((root: Entity, prefab: CompiledPrefab, loaded: boolean) => void)[];
  /** The last `reserveInstance` took a parked instance: `Commands.instantiate` queues `TAKE`, not `INSTANTIATE`. */
  instanceTaken!: boolean;
  /** Each pooled prefab's pool here, by prefab id: made the first time it is needed. */
  private prefabPools!: (PoolRows | undefined)[];
  private pooling!: boolean;
  /** Instances given back since the last tick's end: reset and parked at the next (`park`). */
  private back!: Uint32Array;
  private backCount!: number;
  /** `world.load` emptying the world: a destroy is for real, pooled or parked. */
  private draining!: boolean;
  /** Pooled roots under an entity being destroyed, gathered before it goes: given back, not killed. */
  private under!: Uint32Array;
  private underTop!: number;
  /** Each node's parts' last child while a parked instance's tree is checked: by node. */
  private lastPart!: Uint32Array;
  /** Per prefab id: each node's kind and its switched-off components as masks (`words` each), for the reset. */
  private prefabMasks!: ({ of: CompiledPrefab; kinds: Uint32Array; off: Uint32Array } | undefined)[];
  /** The component on each mask bit (WorldTransform aside, which shares Transform's). */
  private onBit!: (AnyComponent | null)[];
  /** What may stay on a parked instance though its prefab does not list it (`keepParked`), by component id. */
  private keepers!: (((e: Entity) => boolean) | null)[];
  /** Each entity's layer: the `Layer` store's one column. */
  private get layerOf(): Store<typeof Layer.schema>['id'] {
    return this.layerStore.id;
  }
  private transforms!: Transforms;

  // ── systems ──
  private systems!: Sys[];
  /** For each mask bit, the systems that mention it. */
  private interested!: number[][];
  private stamp!: Uint32Array;
  private stampNo!: number;
  /** The buffers, in the order the boundary applies them. */
  private buffers!: Commands[];
  private built!: boolean;
  private commands!: Commands;

  // ── the boundary ──
  private ticking!: boolean;
  private flushing!: boolean;
  /** What `allocate` sets from the registry's bits; read as `words`. */
  private wordCount!: number;
  private dirty!: Uint32Array;
  private dirtyCount!: number;
  private shifted!: Uint32Array;
  private movedCount!: number;
  private dead!: Uint32Array;
  private deadCount!: number;
  /** Destroyed a boundary ago: their indices rest one tick, so `onLeave` can still read their rows. */
  private limbo!: Uint32Array;
  private limboCount!: number;
  /** A relation's table, by the relation's component id; and the same as a list. */
  private tables!: (RelationTable | null)[];
  private tableList!: RelationTable[];
  /** An event type's channel, by the event's id; and the same as a list. */
  private channels!: (ChannelControl<any> | undefined)[];
  private channelList!: ChannelControl<any>[];
  /** Change tracking, by component id; and the same as a list. */
  private tracked!: (Tracked | undefined)[];
  private trackedList!: Tracked[];
  /** The tick being run. */
  private currentTick!: number;
  /** Parallel systems, in registration order; and what runs them on other threads, if anything does. */
  private jobs!: Job[];
  private runner!: ParallelRunner | null;
  /** The last tick that ran: what a boundary stamps a change with. */
  private lastTick!: number;
  private warnedFull!: boolean;
  /** What the boundary has warned of, so a mistake made every tick is said once. */
  private warned!: Set<string>;

  /** `ref`, `deref` and `has` as plain functions, shared by every context: `const { deref } = ctx` works. */
  private extras!: Extras;
  /** In a `parallel` system's call (`runJob`). */
  private inParallel = false;
  /** The engine's stages (`stage()`): each run once a tick, after propagation, in the order added. */
  private stageList!: { readonly name: string; readonly run: (tick: number) => void; readonly info: StageInfo }[];

  constructor({ loop, entities = 16384, maxEntities = 131072, strictOrder = false, shared, attach }: WorldOptions) {
    this.loop = loop;
    this.options = { entities, maxEntities, strictOrder, shared, attach };
    this.allocate(this.options);
  }

  /**
   * Every field at its first value, the columns made for the registry's
   * components as they are now, and this world's hooks added to its loop: the
   * constructor's body, and `reset`'s second half.
   */
  private allocate({ entities, maxEntities, strictOrder, shared, attach }: WorldSetup): void {
    const loop = this.loop;
    this.strictOrder = strictOrder;
    const ceiling = attach ? attach.maxRows : Math.min(ENTITY_LIMIT, Math.max(maxEntities, CYCLE * 2));
    const rows = attach ? attach.rows : Math.min(ceiling, Math.max(entities, CYCLE * 2));
    const isolated = (globalThis as { crossOriginIsolated?: boolean }).crossOriginIsolated === true;
    this.alloc = new Alloc(rows, ceiling, shared ?? isolated, attach ? attach.buffers : null);
    this.components = [...allComponents()];
    this.wordCount = Math.max(1, Math.ceil(maskBits() / 32));
    const alloc = this.alloc;

    const stats = this.stats;
    stats.entities = stats.parked = stats.capacity = stats.growths = stats.poolMisses = stats.commandGrowths = stats.refused = 0;
    this.head = new Uint32Array(CYCLE);
    this.tail = new Uint32Array(CYCLE);
    this.fresh = new Uint32Array(CYCLE);
    this.high = 1;
    this.kindCount = [];
    this.kindCursor = [];
    this.kindLow = [];
    this.stores = [];
    this.columns = [];
    this.initials = [];
    this.pools = [];
    this.addHooks = [];
    this.toggleHooks = [];
    this.activeHooks = [];
    this.layerHooks = [];
    this.loadHooks = [];
    this.removeHooks = [];
    this.headRoot = 0;
    this.tailRoot = 0;
    this.parts = new Uint32Array(64);
    this.linkRows = new Uint32Array(64);
    this.instanceRefused = false;
    this.killing = 0;
    this.instanceHooks = [];
    this.instanceTaken = false;
    this.prefabPools = [];
    this.pooling = false;
    this.back = new Uint32Array(16);
    this.backCount = 0;
    this.draining = false;
    this.under = new Uint32Array(16);
    this.underTop = 0;
    this.lastPart = new Uint32Array(64);
    this.prefabMasks = [];
    this.onBit = [];
    this.keepers = [];
    this.systems = [];
    this.interested = [];
    this.stamp = new Uint32Array(0);
    this.stampNo = 0;
    this.stageList = [];
    this.buffers = [];
    this.built = false;
    this.ticking = false;
    this.flushing = false;
    this.dirty = new Uint32Array(256);
    this.dirtyCount = 0;
    this.shifted = new Uint32Array(64);
    this.movedCount = 0;
    this.dead = new Uint32Array(64);
    this.deadCount = 0;
    this.limbo = new Uint32Array(64);
    this.limboCount = 0;
    this.tables = [];
    this.tableList = [];
    this.channels = [];
    this.channelList = [];
    this.tracked = [];
    this.trackedList = [];
    this.currentTick = 0;
    this.jobs = [];
    this.runner = null;
    this.lastTick = -1;
    this.warnedFull = false;
    this.warned = new Set<string>();

    alloc.column(this, 'gen', 'u16');
    alloc.column(this, 'state', 'u8');
    alloc.column(this, 'kindOf', 'u16');
    alloc.column(this, 'flags', 'u8');
    alloc.column(this, 'nextFree', 'u32');
    alloc.column(this, 'mask', 'u32', this.words);
    alloc.column(this, 'seen', 'u32', this.words);
    alloc.column(this, 'off', 'u32', this.words);
    alloc.column(this, 'inactive', 'u8');
    // Id 0 is nobody, so phase 0 starts a cycle on.
    for (let p = 0; p < CYCLE; p++) this.fresh[p] = p === 0 ? CYCLE : p;

    for (const component of this.components) {
      this.addHooks.push(null);
      this.removeHooks.push(null);
      this.toggleHooks.push(null);
      this.keepers.push(null);
      this.pools.push([]);
      if (component.kind === 'data') {
        const store = shaped(component.fields.map((field) => field.name));
        for (const field of component.fields) alloc.column(store, field.name, field.type);
        this.stores.push(store);
        this.initials.push(component.fields.map((field) => field.initial));
      } else if (component.kind === 'object') {
        this.stores.push(new ObjectSlots(rows));
        this.initials.push([]);
        if (component.create) for (let i = 0; i < component.pool; i++) this.pools[component.id]!.push(component.create());
      } else if (component.kind === 'relation') {
        const table = new RelationTable(component, alloc, this);
        this.tables[component.id] = table;
        this.tableList.push(table);
        this.stores.push(table.store);
        this.initials.push([]);
      } else {
        this.stores.push(undefined);
        this.initials.push([]);
      }
      if (component.kind !== 'relation') this.tables.push(null);
      this.columns.push([]);
    }
    this.pointColumns();
    for (let bit = 0; bit < this.words * 32; bit++) this.interested.push([]);
    for (let bit = 0; bit < this.words * 32; bit++) this.onBit.push(this.components.find((c) => c.bit === bit && c !== WorldTransform) ?? null);

    this.links = this.stores[Hierarchy.id] as Store<typeof Hierarchy.schema>;
    this.layerStore = this.stores[Layer.id] as Store<typeof Layer.schema>;
    this.instanceStore = this.stores[Instance.id] as Store<typeof Instance.schema>;
    this.transforms = new Transforms(
      this,
      alloc,
      this.stores[Transform.id] as Store<typeof Transform.schema>,
      this.stores[WorldTransform.id] as Store<typeof WorldTransform.schema>,
      this.links,
    );

    this.extras = {
      // A parked instance's entity is no one's (Docs/prefabs.md §5): no ref is minted to it, and one held derefs to `NONE`.
      // So a cycle of the pool needs one new generation, at the give-back, and none at the take.
      ref: (e) => (((this.flags[e]! & PARKED) !== 0 ? 0 : (this.gen[e]! << INDEX_BITS) | e) as EntityRef),
      deref: (r) => {
        const e = r & INDEX_MASK;
        return (this.gen[e] === r >>> INDEX_BITS && (this.flags[e]! & PARKED) === 0 ? e : 0) as Entity;
      },
      has: (e, component) => component.bit < 0 || (this.mask[e * this.words + (component.bit >>> 5)]! & (1 << (component.bit & 31))) !== 0,
      enabled: (e, component) => {
        if (component.bit < 0) return true;
        const at = e * this.words + (component.bit >>> 5);
        const bit = 1 << (component.bit & 31);
        return (this.mask[at]! & bit) !== 0 && (this.off[at]! & bit) === 0;
      },
      active: (e) => (this.inactive[e]! & OFF) === 0,
      changed: (_e, component) => {
        throw new Error(`[ecs] ctx.changed(e, ${component.name}) in a system that does not list it: add changed: [${component.name}] to the system`);
      },
      world: this,
    };
    this.commands = new Commands(this);
    this.stats.capacity = rows;

    // Several worlds may share a loop: each adds its hooks, and they run in that order.
    this.loopHooks = {
      beforeTick: (tick) => {
        if (this.pending()) this.boundary(false);
        this.currentTick = tick;
        this.ticking = true;
      },
      betweenStages: (tick) => {
        this.transforms.propagate(tick);
        // The engine's stages after the one full pass: the physics' step (Docs/physics.md D5).
        const stages = this.stageList;
        for (let i = 0; i < stages.length; i++) stages[i]!.run(tick);
      },
      afterTick: (tick) => {
        this.ticking = false;
        this.lastTick = tick;
        if (this.trackedList.length > 0) this.scanChanges(tick);
        this.boundary(true);
      },
    };
    loop.hooks.push(this.loopHooks);
  }

  // ── the reset ───────────────────────────────────────────────────────────

  /**
   * The world made again in place, empty, from the options it was made with:
   * no entity, no system, no query, no hook, no channel, no pool, every column
   * new -- one for each component the registry holds now, so a generation's
   * redefinitions (component.ts) get theirs. The same `World` object, for
   * whoever holds it: the running game rebuilt after a code change
   * (`rebuildWorld`, Docs/squidwright-implementation.md 0.3), its editor going
   * on over the same world. Reset the loop first (`Loop.reset`), then this,
   * then register the systems and `build()`, then load the save taken before.
   *
   * Refuses a world attached to another's shared memory (a worker's view) or
   * running parallel systems on workers: they hold columns this would replace.
   * And refuses during a tick, and during a flush -- a hook it runs (`onRemove`,
   * an instance's) is outside any tick, but the boundary is walking the columns
   * `allocate` would replace.
   */
  reset(): void {
    if (this.options.attach) throw new Error('[ecs] world.reset() on a world attached to shared memory: a worker\'s world is made again with its pool, not reset');
    if (this.runner) throw new Error('[ecs] world.reset() with parallel systems on workers: they hold the columns; stop the workers first');
    if (this.ticking || this.flushing) throw new Error(`[ecs] world.reset() during a ${this.ticking ? 'tick' : 'flush (from a hook the boundary ran)'}: reset between ticks, outside the loop and its boundaries`);
    // A render or input system reaching here is the loop's to refuse: `Loop.reset()` throws during a frame, and
    // `rebuildWorld` calls it first; this world's own guards are the tick and the boundary, which the loop does not see.
    const hooks = this.loop.hooks;
    const at = hooks.indexOf(this.loopHooks);
    if (at >= 0) hooks.splice(at, 1);
    this.allocate(this.options);
  }

  // ── systems and queries ─────────────────────────────────────────────────

  /**
   * A system: one object with everything about it. Its members are the
   * entities with every component in `read`, `write` and `with`, and none in
   * `without`; `update` gets a store for each component of `read`, then of `write`,
   * in the order declared.
   */
  system<const R extends readonly Access[] = readonly [], const W extends readonly Access[] = readonly []>(def: SimulationDef<R, W> | RenderDef<R, W>): void {
    const reads = (def.read ?? []).map(componentOf);
    const writes = (def.write ?? []).map(componentOf);
    const where = `[ecs] system '${def.name}'`;
    for (const component of [...reads, ...writes, ...(def.with ?? []), ...(def.without ?? [])]) this.known(component, where);
    for (const component of writes) {
      if (component === Hierarchy) throw new Error(`${where} lists Hierarchy in write: the tree changes only through cmd.setParent(child, parent); list it in read`);
      if (component === WorldTransform) throw new Error(`${where} lists WorldTransform in write: it is worked out from Transform once a tick; write Transform, read WorldTransform`);
      if (reads.includes(component)) throw new Error(`${where} lists ${component.name} in both read and write: write is enough, a writable store can be read`);
    }
    if (def.phase !== 'render' && def.rate !== TICK_HZ && writes.includes(Transform)) {
      throw new Error(`${where} writes Transform at ${def.rate} Hz: only 60 Hz systems write what is drawn. Let it decide (write a target component) and a 60 Hz system move`);
    }

    const need = new Uint32Array(this.words);
    const not = new Uint32Array(this.words);
    const required = [...(def.read ?? []), ...(def.write ?? [])].filter((a) => !('optional' in a)) as AnyComponent[];
    for (const component of [...required, ...(def.with ?? [])]) if (component.bit >= 0) need[component.bit >>> 5]! |= 1 << (component.bit & 31);
    for (const component of def.without ?? []) {
      if (component.bit < 0) throw new Error(`${where} lists ${component.name} in without: every entity has it`);
      not[component.bit >>> 5]! |= 1 << (component.bit & 31);
    }
    const some = this.anyOf(def.any, where);
    const layers = layerMask(def.layers, where);
    const selective = some !== null || need.some((word) => word !== 0);
    if (!selective && not.some((word) => word !== 0)) throw new Error(`${where} has without but nothing an entity must have: add a component to read, write, with or any`);

    for (const component of [...(def.with ?? []), ...(def.without ?? [])]) this.known(component, where);
    // What it asks `changed` about, and since when: the wrappers below move `since` before each call.
    const watched = def.changed ?? [];
    for (const component of watched) this.track(component, where);
    const window = { since: 0 };
    const changed = (e: Entity, component: Component<any>): boolean => {
      const tracked = this.tracked[component.id];
      if (!tracked || !watched.includes(component)) return this.extras.changed(e, component);
      return tracked.stamp[e]! >= window.since;
    };
    const extras = watched.length > 0 ? { ...this.extras, changed } : this.extras;

    const readStores = reads.map((component) => this.stores[component.id]) as unknown as Reads<R>;
    const writeStores = writes.map((component) => this.stores[component.id]) as unknown as Writes<W>;

    let sys: Sys;
    if (def.phase === 'render') {
      const own = new Members(1);
      const ctx = { frameDt: 0, alpha: 0, tick: 0, since: 0, members: own.lists[0]! as unknown as EntityList, count: 0, ...extras };
      const update = def.update;
      this.loop.addSystem({
        name: def.name,
        phase: 'render',
        after: def.after,
        update: (frame) => {
          ctx.frameDt = frame.frameDt;
          ctx.alpha = frame.alpha;
          ctx.tick = frame.tick;
          ctx.since = frame.since;
          // Changes are stamped with the tick they happened on: those of the ticks since the last frame.
          window.since = frame.since;
          ctx.members = own.lists[0]! as unknown as EntityList;
          ctx.count = own.counts[0]!;
          update(ctx, readStores, writeStores);
        },
      });
      sys = { name: def.name, phase: 'render', rate: 0, need, not, some, layers, includeDisabled: def.includeDisabled ?? false, selective, handle: -1, own, reads, writes, cmd: null, stages: 'render' };
    } else {
      const cmd = new Commands(this);
      const { onJoin, onLeave, update, lateUpdate } = def;
      const transforms = this.transforms;
      // A follower: what its lateUpdate writes is propagated again at once, so
      // the next system's lateUpdate sees it where it now is (Docs/ecs.md §8).
      const follows = lateUpdate !== undefined && writes.includes(Transform);
      const watches = watched.length > 0;
      /** The loop's context as the system's, and `changed`'s window moved to the ticks since this slot last ran. */
      const as = (ctx: SimulationContext): SystemContext => {
        if (watches) window.since = ctx.tick - ctx.period;
        return ctx as unknown as SystemContext;
      };
      let runUpdate = update && ((ctx: SimulationContext) => update(as(ctx), readStores, writeStores));
      let runLate = lateUpdate && ((ctx: SimulationContext) => lateUpdate(as(ctx), readStores, writeStores));
      if (def.parallel) {
        for (const component of [...reads, ...writes]) {
          if (component.kind !== 'data') throw new Error(`${where} is parallel and lists ${component.name}, ${isData(component) ? 'a data component (its lists, strings and records are objects on the main thread)' : component.kind === 'object' ? 'an object component' : 'a relation'}: only numeric components are in shared memory. Take parallel off, or split the system`);
        }
        if (watches) throw new Error(`${where} is parallel and lists \`changed\`: ask about changes in a system of its own, and leave the parallel one to the arithmetic`);
        const job = this.jobs.length;
        const period = TICK_HZ / def.rate;
        this.jobs.push({
          name: def.name,
          stages: [update, lateUpdate],
          read: readStores,
          write: writeStores,
          ctx: new ParallelContext(def.name, period, (def.stagger ?? true) && period > 1, extras),
        });
        const stage = (which: number) => (ctx: SimulationContext): void => {
          const runner = this.runner;
          if (!runner || ctx.count < runner.threshold) {
            this.runJob(job, which, ctx.members, ctx.count, ctx.tick);
            return;
          }
          const mine = runner.dispatch(job, which, ctx.members, ctx.count, ctx.tick, this.alloc.rows);
          this.runJob(job, which, ctx.members, mine, ctx.tick);
          runner.wait(def.name);
        };
        runUpdate = update && stage(0);
        runLate = lateUpdate && stage(1);
      }
      const late = runLate;
      this.loop.addSystem({
        name: def.name,
        rate: def.rate,
        after: def.after,
        weight: def.weight,
        stagger: def.stagger,
        context: { cmd, ...extras },
        onJoin: onJoin && ((ctx) => onJoin(as(ctx), readStores, writeStores)),
        onLeave: onLeave && ((ctx) => onLeave(as(ctx), readStores, writeStores)),
        update: runUpdate,
        lateUpdate:
          late &&
          (follows
            ? (ctx) => {
                late(ctx);
                transforms.late(ctx.members, ctx.count, ctx.tick);
              }
            : late),
      });
      const stages = [update || onJoin || onLeave ? 'update' : '', lateUpdate ? 'late' : ''].join('+');
      sys = { name: def.name, phase: 'simulation', rate: def.rate, need, not, some, layers, includeDisabled: def.includeDisabled ?? false, selective, handle: this.loop.handle(def.name), own: null, reads, writes, cmd, stages };
    }
    this.enrol(sys);
  }

  /**
   * A standing query, for code outside a system: made once at setup and kept,
   * never per tick. Its members are as of the last boundary.
   */
  query(where: { with?: readonly AnyComponent[]; any?: readonly AnyComponent[]; without?: readonly AnyComponent[]; layers?: readonly number[]; includeDisabled?: boolean }): Query {
    if (this.ticking) throw new Error('[ecs] world.query() during a tick: make a query once at setup and keep it, or declare the components on the system');
    const need = new Uint32Array(this.words);
    const not = new Uint32Array(this.words);
    for (const component of where.with ?? []) {
      this.known(component, '[ecs] query');
      if (component.bit >= 0) need[component.bit >>> 5]! |= 1 << (component.bit & 31);
    }
    for (const component of where.without ?? []) not[component.bit >>> 5]! |= 1 << (component.bit & 31);
    const some = this.anyOf(where.any, '[ecs] query');
    if (some === null && !need.some((word) => word !== 0)) throw new Error('[ecs] a query needs at least one component in `with` or `any`');
    const own = new Members(1);
    this.enrol({ name: `query ${this.systems.length}`, phase: 'query', rate: 0, need, not, some, layers: layerMask(where.layers, '[ecs] query'), includeDisabled: where.includeDisabled ?? false, selective: true, handle: -1, own, reads: [], writes: [], cmd: null, stages: '' });
    return {
      get members() {
        return own.lists[0]! as unknown as EntityList;
      },
      get count() {
        return own.counts[0]!;
      },
    };
  }

  /** The mask of an `any` list, or null for none: at least one of its bits must be on an entity. */
  private anyOf(list: readonly AnyComponent[] | undefined, where: string): Uint32Array | null {
    if (!list || list.length === 0) return null;
    const some = new Uint32Array(this.words);
    for (const component of list) {
      this.known(component, where);
      if (component.bit < 0) throw new Error(`${where} lists ${component.name} in any: every entity has it, so it would match everything`);
      some[component.bit >>> 5]! |= 1 << (component.bit & 31);
    }
    return some;
  }

  private enrol(sys: Sys): void {
    const index = this.systems.length;
    this.systems.push(sys);
    for (let w = 0; w < this.words; w++) {
      const word = sys.need[w]! | sys.not[w]! | (sys.some ? sys.some[w]! : 0);
      for (let b = 0; b < 32; b++) if (word & (1 << b)) this.interested[w * 32 + b]!.push(index);
    }
    this.stamp = new Uint32Array(this.systems.length);
    this.built = false;
    // Registered after entities exist: they are looked at now.
    if (sys.selective) for (let e = 1; e < this.high; e++) if (this.state[e] === ALIVE) this.place(sys, e);
    if (!this.ticking) this.loop.applyPending();
  }

  /**
   * Checks everything that can be checked before the first tick: the loop's
   * order (an unknown `after`, a cycle) and, under `strictOrder`, systems of one
   * level that share written data. Call it once every system is registered.
   */
  build(): void {
    this.loop.build();
    const info = this.loop.info();
    const byName = new Map(this.systems.map((sys) => [sys.name, sys]));
    this.buffers = [this.commands];
    for (const { name } of info) {
      const cmd = byName.get(name)?.cmd;
      if (cmd) this.buffers.push(cmd);
    }
    this.built = true;
    if (!this.strictOrder) return;
    const conflicts = this.conflicts();
    if (conflicts.length === 0) return;
    const [a, b, component] = conflicts[0]!;
    throw new Error(
      `[ecs] '${a}' and '${b}' are in the same dependency level and share ${component}, which one of them writes: ` +
        `add after: ['${a}'] to '${b}' (or the other way round) so their order is written down` +
        (conflicts.length > 1 ? ` (${conflicts.length - 1} more such pairs: world.describe() lists them)` : ''),
    );
  }

  /**
   * Pairs of systems in one dependency level where one writes a component the other
   * reads or writes: they run in registration order. `[first, second, component]`.
   */
  conflicts(): [string, string, string][] {
    const info = this.loop.info();
    const levelOf = new Map(info.map((i) => [i.name, `${i.phase}:${i.level}`]));
    const systems = this.systems.filter((sys) => sys.phase !== 'query');
    const out: [string, string, string][] = [];
    for (let i = 0; i < systems.length; i++) {
      for (let j = i + 1; j < systems.length; j++) {
        const a = systems[i]!;
        const b = systems[j]!;
        if (levelOf.get(a.name) !== levelOf.get(b.name)) continue;
        // One only in `update`, the other only in `lateUpdate`: every update runs before any lateUpdate.
        if (!a.stages.split('+').some((stage) => stage !== '' && b.stages.split('+').includes(stage))) continue;
        const shared = a.writes.find((t) => b.writes.includes(t) || b.reads.includes(t)) ?? b.writes.find((t) => a.reads.includes(t));
        if (shared) out.push([a.name, b.name, shared.name]);
      }
    }
    return out;
  }

  // ── threads ─────────────────────────────────────────────────────────────

  /**
   * One stage of a parallel system over `count` of `members`: what the main
   * thread calls for its own share, and a worker for the share it was handed.
   */
  runJob(job: number, stage: number, members: Uint32Array, count: number, tick: number): void {
    const entry = this.jobs[job]!;
    const ctx = entry.ctx;
    ctx.members = members;
    ctx.count = count;
    ctx.tick = tick;
    ctx.time = tick / TICK_HZ;
    this.inParallel = true;
    try {
      entry.stages[stage]!(ctx, entry.read, entry.write);
    } finally {
      this.inParallel = false;
    }
  }

  /** A worker thread's view of a world (made `attach`ed to another's shared memory): it has no physics of its own. */
  get onWorker(): boolean {
    return this.options.attach !== undefined;
  }

  /** A `parallel` system is running here now: what may run on a worker thread may not reach the main thread's (the physics' queries throw). */
  get parallelRunning(): boolean {
    return this.inParallel;
  }

  /**
   * What a worker needs to be a second view of this world. From then on no new
   * column may be made: every system must be registered first. Needs
   * `shared: true`.
   */
  sharing(): WorldSharing {
    if (!this.alloc.shared) throw new Error('[ecs] workers need the columns in shared memory: new World({ shared: true }), on a cross-origin isolated page');
    if (!this.built) this.build();
    this.alloc.freeze();
    return { buffers: this.alloc.buffers(), rows: this.alloc.rows, maxRows: this.alloc.maxRows, components: this.components.map((c) => c.name), jobs: this.jobs.map((job) => job.name) };
  }

  /** In a worker: do this world and the main thread's agree? Returns what differs, or null. */
  mismatch(main: WorldSharing): string | null {
    const mine = this.components.map((c) => c.name);
    if (mine.join() !== main.components.join()) return `components differ: the main thread has [${main.components.join(', ')}], the worker [${mine.join(', ')}]. Both must import the same component modules in the same order`;
    const jobs = this.jobs.map((job) => job.name);
    if (jobs.join() !== main.jobs.join()) return `parallel systems differ: the main thread has [${main.jobs.join(', ')}], the worker [${jobs.join(', ')}]. Both must register the same systems in the same order`;
    if (this.alloc.spare() !== 0) return `the main thread made ${this.alloc.spare()} more columns than the worker: both must register the same systems, with the same \`changed\` lists`;
    return null;
  }

  /** In a worker: the main thread's storage is now `rows` long. */
  follow(rows: number): void {
    if (rows === this.alloc.rows) return;
    this.alloc.follow(rows);
    this.pointColumns();
    this.stats.capacity = rows;
  }

  /** Parallel systems' members go through `runner` from now on; null to run them all here again. */
  useRunner(runner: ParallelRunner | null): void {
    this.runner = runner;
  }

  // ── stores ──────────────────────────────────────────────────────────────

  /**
   * A component's writable store, for code outside a system: setup, tests, the
   * editor. Inside a system, declare the component in `read` or `write` instead.
   * Do not keep its columns across a tick: the world may grow.
   */
  store<T extends DataComponent>(component: T): StoreOf<T> {
    if (this.ticking) throw new Error(`[ecs] world.store(${component.name}) during a tick: inside a system, list ${component.name} in its read or write and use the store it is handed`);
    this.known(component, '[ecs] world.store');
    return this.stores[component.id] as StoreOf<T>;
  }

  /**
   * Called when `component` lands on an entity at a boundary: how `View` puts its object in the scene,
   * and how the `render` system draws a `Render`. Several may listen to one component, each run in the
   * order they were registered. Returns the undo: that hook alone taken off.
   */
  onAdd(component: AnyComponent, hook: (e: Entity) => void): () => void {
    return listen(this.addHooks, component.id, hook);
  }

  /**
   * Called when `component` leaves an entity at a boundary, removed or destroyed, with an object
   * component's value before it is reset. Several may listen, in registration order, as `onAdd`;
   * returns the undo.
   */
  onRemove<T>(component: ObjectComponent<T> | AnyComponent, hook: (e: Entity, value: T) => void): () => void {
    return listen(this.removeHooks, component.id, hook as (e: Entity, value: unknown) => void);
  }

  /** Called when `component` is switched off or on again on an entity (`enable`), with which. */
  onToggle(component: AnyComponent, hook: (e: Entity, on: boolean) => void): void {
    this.toggleHooks[component.id] = hook;
  }

  /** Called when an entity goes in or out of play (`Disabled`, on it or above it) or in or out of sight (`Hidden`). Returns the undo. */
  onActive(hook: (e: Entity, active: boolean, seen: boolean) => void): () => void {
    this.activeHooks.push(hook);
    return () => unlisten(this.activeHooks, hook);
  }

  /** Called when an entity's layer changes. Returns the undo. */
  onLayer(hook: (e: Entity, layer: number) => void): () => void {
    this.layerHooks.push(hook);
    return () => unlisten(this.layerHooks, hook);
  }

  /** `component` on `e` switched off, or on again; its data stays. Outside a system: inside one, `ctx.cmd.enable`. */
  enable(e: Entity, component: AnyComponent, on = true): void {
    this.outside('enable');
    this.commands.enable(e, component, on);
  }

  /** `e` onto a layer, 0 to 31. */
  setLayer(e: Entity, layer: number): void {
    this.outside('setLayer');
    this.commands.setLayer(e, layer);
  }

  /** `e`'s layer, 0 to 31. */
  layerOfEntity(e: Entity): number {
    return this.layerOf[e]!;
  }

  /** Does `e` have `component`, switched on? */
  enabled(e: Entity, component: AnyComponent): boolean {
    return this.extras.enabled(e, component);
  }

  /** Is `e` in play: neither it nor any ancestor `Disabled`? */
  active(e: Entity): boolean {
    return this.extras.active(e);
  }

  /** Is `e` in sight: neither it nor any ancestor `Hidden`? */
  seenEntity(e: Entity): boolean {
    return (this.inactive[e]! & UNSEEN) === 0;
  }

  // ── entities, from outside a system ─────────────────────────────────────

  /** A new entity of `kind`. Outside a system only: inside one, `ctx.cmd.spawn`. In the world from the next boundary, or `flush()`. */
  spawn(kind: Kind = Bare): Entity {
    this.outside('spawn');
    return this.commands.spawn(kind);
  }

  /** `e` and everything under it, gone at the next boundary. */
  destroy(e: Entity): void {
    this.outside('destroy');
    this.commands.destroy(e);
  }

  /** One more component on `e`; returns its writable store. */
  add<T extends AnyComponent>(e: Entity, component: T): StoreOf<T> {
    this.outside('add');
    return this.commands.add(e, component);
  }

  /** The writable store of a component of an entity spawned since the last boundary; on a typed prefab's entity, only one it is made with (`Commands.init`). */
  init<E extends Entity, T extends AnyComponent>(e: E, component: T & MadeWith<E, T>): StoreOf<T> {
    return this.commands.init(e, component);
  }

  remove(e: Entity, component: AnyComponent): void {
    this.outside('remove');
    this.commands.remove(e, component);
  }

  /**
   * `child` under `parent`, last; `NONE` for no parent -- a root, last of the
   * roots. With `before`, a child of `parent` (a root, for `NONE`), in front of
   * that one instead (`Commands.setParent`).
   */
  setParent(child: Entity, parent: Entity, before: Entity = 0 as Entity): void {
    this.outside('setParent');
    this.commands.setParent(child, parent, before);
  }

  /** A link from `source` to `target`; returns its row, to fill in its data through `world.store(Relation)`. */
  relate(source: Entity, relation: Relation<any>, target: Entity): number {
    this.outside('relate');
    return this.commands.relate(source, relation, target);
  }

  /** The link from `source` to `target` gone; every link out of `source` if `target` is `NONE`. */
  unrelate(source: Entity, relation: Relation<any>, target: Entity): void {
    this.outside('unrelate');
    this.commands.unrelate(source, relation, target);
  }

  /**
   * An event type's channel in this world: get it once, where a system is
   * registered, and use it in the system. Writers `emit()`, readers loop from
   * `begin(ctx)` to `end`.
   */
  events<S extends Schema>(type: EventType<S>): Channel<S> {
    let made = this.channels[type.id];
    if (!made) {
      if (this.ticking) throw new Error(`[ecs] world.events(${type.name}) during a tick: get the channel once, where the system is registered, and keep it`);
      made = makeChannel(type, this);
      this.channels[type.id] = made;
      this.channelList.push(made);
    }
    return made.channel as Channel<S>;
  }

  /** The boundary, now: for when no tick is running -- setup that wants to read back what it made, the editor, tests. */
  flush(): void {
    this.outside('flush');
    this.boundary(true);
    this.loop.applyPending();
  }

  /** A reference to `e` that can be kept. */
  ref(e: Entity): EntityRef {
    return this.extras.ref(e);
  }

  /** The entity a reference points to, or `NONE` if it has died. */
  deref(r: EntityRef): Entity {
    return this.extras.deref(r);
  }

  /** Does `e` have `component`, as of the last boundary? */
  has(e: Entity, component: AnyComponent): boolean {
    return this.extras.has(e, component);
  }

  /** Is `e` in the world: spawned, past its first boundary, not destroyed? */
  alive(e: Entity): boolean {
    return e > 0 && e < this.high && this.state[e] === ALIVE && (this.flags[e]! & PARKED) === 0;
  }

  /** Is `e` part of a pooled prefab's parked instance (Docs/prefabs.md §5)? Not alive, in no system, waiting to be taken. For tools. */
  parked(e: Entity): boolean {
    return e > 0 && e < this.high && this.state[e] === ALIVE && (this.flags[e]! & PARKED) !== 0;
  }

  /**
   * The first root -- an entity alive with no parent -- in the roots' order
   * (Docs/ecs.md §8); `NONE` for none. The rest follow through the hierarchy's
   * `nextSibling`, allocating nothing:
   * `for (let r = world.firstRoot; r !== NONE; r = links.nextSibling[r])`.
   * As of the last boundary.
   */
  get firstRoot(): Entity {
    return this.headRoot as Entity;
  }

  /** The last root in the roots' order; `NONE` for none. */
  get lastRoot(): Entity {
    return this.tailRoot as Entity;
  }

  /** Every root in order, into `out` (emptied first): for tools -- a loop over `firstRoot` allocates nothing. */
  roots(out: Entity[] = []): Entity[] {
    out.length = 0;
    const next = this.links.nextSibling;
    for (let r = this.headRoot; r !== 0; r = next[r]!) out.push(r as Entity);
    return out;
  }

  /** One past the highest entity index in use: `for (let e = 1; e < world.extent; e++) if (world.alive(e)) ...`, for tools. */
  get extent(): number {
    return this.high;
  }

  /**
   * `e`'s world transform as a 4x4 matrix, column-major (three.js's layout),
   * into `out`: `alpha` of the way from where it was a tick ago to where it is
   * now; 1 is now. For render systems: it is how `present` places a view.
   */
  writeMatrix(e: Entity, alpha: number, out: number[] | Float32Array): void {
    this.transforms.writeMatrix(e, alpha, out);
  }

  /** The kind `e` was spawned as -- or given since (`rekind`). */
  kindOfEntity(e: Entity): Kind {
    return allKinds()[this.kindOf[e]!]!;
  }

  /**
   * `e` counted, and saved, as `kind` from now on. What the editor's Unpack
   * (one level) gives a nested instance's entities -- their own prefab's node
   * kinds -- so a load finds their nodes in it by name (`refindNodes`), as it
   * does for an instance made of that prefab. Outside a tick; nothing else of
   * `e` changes.
   */
  rekind(e: Entity, kind: Kind): void {
    const from = this.kindOf[e]!;
    const k = kind.id;
    if (from === k || this.state[e] !== ALIVE) return;
    const phase = e % CYCLE;
    // As a destroy counts it out of its kind, and a spawn into the other: `kindLow` only ever a bound from below.
    const left = --this.kindCount[from]![phase]!;
    if (left < this.kindLow[from]!) this.kindLow[from] = left;
    (this.kindCount[k] ?? this.newKind(k))[phase]!++;
    this.kindOf[e] = k;
  }

  /** Every component this world has storage for. */
  get allComponents(): readonly AnyComponent[] {
    return this.components;
  }

  /** A component's store without the checks `store()` makes: for `inspect.ts`, which reads while paused. */
  rawStore(component: AnyComponent): unknown {
    return this.stores[component.id];
  }

  /** The systems `e` is a member of, by name. For tools: it allocates. */
  systemsOf(e: Entity): string[] {
    return this.systems.filter((sys) => sys.phase !== 'query' && this.isMember(sys, e)).map((sys) => sys.name);
  }

  /**
   * The systems `e` would be in but for components switched off on it, each
   * with those components (`enable(e, C, false)`): for tools, to say why it
   * left them. In play and on the right layer only -- out of play it is in
   * none anyway. It allocates.
   */
  outOf(e: Entity): { system: string; off: AnyComponent[] }[] {
    const out: { system: string; off: AnyComponent[] }[] = [];
    if (!this.alive(e)) return out;
    const words = this.words;
    for (const sys of this.systems) {
      if (sys.phase === 'query' || !sys.selective || this.isMember(sys, e)) continue;
      if (!(sys.includeDisabled || (this.inactive[e]! & OFF) === 0) || (sys.layers & (1 << this.layerOf[e]!)) === 0) continue;
      // Would it match with everything it has switched on?
      let matches = true;
      let one = sys.some === null;
      for (let w = 0; w < words; w++) {
        const have = this.mask[e * words + w]!;
        // `>>> 0`: a word with its top bit set is a negative number, its Uint32Array copy is not (ecs/high-bit.test.ts).
        if (((have & sys.need[w]!) >>> 0) !== sys.need[w] || (have & sys.not[w]!) !== 0) {
          matches = false;
          break;
        }
        if (!one && (have & sys.some![w]!) !== 0) one = true;
      }
      if (!matches || !one) continue;
      const wanted = (c: AnyComponent): boolean => {
        const bit = 1 << (c.bit & 31);
        return (sys.need[c.bit >>> 5]! & bit) !== 0 || (sys.some !== null && (sys.some[c.bit >>> 5]! & bit) !== 0);
      };
      const off = this.components.filter((c) => c.bit >= 0 && this.extras.has(e, c) && !this.extras.enabled(e, c) && wanted(c));
      if (off.length > 0) out.push({ system: sys.name, off });
    }
    return out;
  }

  /**
   * Every system with what the world knows of it: the loop's `info()`, with
   * the components it reads and writes and how many members it has. For
   * `describe()` and the editor: it allocates.
   */
  systemInfo(): SystemReport[] {
    const byName = new Map(this.systems.map((sys) => [sys.name, sys]));
    return this.loop.info().map((info) => {
      const sys = byName.get(info.name);
      return {
        ...info,
        ecs: sys !== undefined,
        members: sys?.own ? sys.own.total : info.slots.reduce((a, b) => a + b, 0),
        reads: sys ? sys.reads.map((t) => t.name) : [],
        writes: sys ? sys.writes.map((t) => t.name) : [],
      };
    }).concat(
      // The engine's stages (`stage()`): 60 Hz, every tick, between every `update` and every `lateUpdate`.
      this.stageList.map(({ name, info }) => {
        const members = info.members();
        return { name, phase: 'simulation' as const, rate: TICK_HZ, level: 0, stagger: false, stages: 'engine stage, between update and lateUpdate', slots: [members], ecs: true, members, reads: [...info.reads], writes: [...info.writes], stage: true };
      }),
    );
  }

  /**
   * `e`'s `Transform` was written from outside a tick -- the editor, a
   * teleport in setup: its world transform, and those under it, are worked out
   * at the next `flush()`. Inside a system nothing needs saying: propagation
   * notices by itself.
   */
  moved(e: Entity): void {
    this.outside('moved');
    if (this.alive(e)) this.shift(e);
  }

  /**
   * An engine stage (Docs/physics.md D5): `run` once every tick, after the world's propagation and
   * before every `lateUpdate`, so what every `update` did is in `WorldTransform` and what the stage
   * moves is seen by every `lateUpdate`. Not a game's tool: a game writes systems. The stage's own
   * `Transform` writes are worked out again through `settle()`. Returns its removal; a reset drops
   * every stage, and the install that added it adds it again.
   */
  stage(name: string, run: (tick: number) => void, info: StageInfo = { reads: [], writes: [], members: () => 0 }): () => void {
    if (this.stageList.some((s) => s.name === name)) throw new Error(`[ecs] stage '${name}' is added twice`);
    const entry = { name, run, info };
    this.stageList.push(entry);
    return () => unlisten(this.stageList, entry);
  }

  /** The stages' names, in the order they run. */
  stages(): readonly string[] {
    return this.stageList.map((s) => s.name);
  }

  /**
   * From a stage: `count` entities of `list` whose `Transform` it wrote, and everything under them,
   * worked out again now -- as a `lateUpdate` that writes `Transform` has its members' -- so the
   * render phase interpolates them and every `lateUpdate` sees them where they now are.
   */
  settle(list: Uint32Array, count: number): void {
    if (!this.ticking) throw new Error('[ecs] world.settle() outside a tick: it is for a stage, between the two stages of one');
    this.transforms.late(list, count, this.currentTick);
  }

  /** Bytes of typed-array storage. */
  get bytes(): number {
    return this.alloc.bytes();
  }

  // ── save and load ───────────────────────────────────────────────────────

  /**
   * The world as plain data: every entity, its components' data, the tree, the
   * links, and where the loop had got to. `JSON.stringify` takes it as it is.
   *
   * Entities keep their indices and generations, so every `ref()` field and
   * every kept `EntityRef` still points where it did after `load`. Components
   * are saved by name and fields by name, so a save survives components being
   * added, reordered or given new fields.
   *
   * Not saved: a component made `transient`, an object component without `save`
   * and `load` (a `View`: the game attaches views again after loading), and
   * events.
   */
  save(): WorldSave {
    this.outside('save');
    this.boundary(true);
    this.loop.applyPending();
    const entities: number[] = [];
    // A parked instance is no part of the game: a save holds the instances out, and a load warms its own.
    for (let e = 1; e < this.high; e++) if (this.state[e] === ALIVE && (this.flags[e]! & PARKED) === 0) entities.push(e);
    const out: WorldSave = {
      version: 1,
      loop: this.loop.saveState(),
      extent: this.high,
      generations: Array.from(this.gen.subarray(0, this.high)),
      entities,
      kinds: entities.map((e) => allKinds()[this.kindOf[e]!]!.name),
      parents: [],
      roots: this.roots() as number[],
      layers: entities.map((e) => this.layerOf[e]!),
      instances: this.saveInstances(entities),
      components: {},
      relations: {},
    };
    const l = this.links;
    for (const e of entities) for (let c = l.firstChild[e]!; c !== 0; c = l.nextSibling[c]!) out.parents.push(c, e);
    for (const component of this.components) {
      if (component.bit < 0 || (component.kind === 'data' && component.transient) || (isData(component) && component.transient)) continue;
      if (component.kind === 'relation') {
        const rows = this.stores[component.id] as Record<string, ArrayLike<number>>;
        const saved = { source: [] as number[], target: [] as number[], fields: {} as Record<string, number[]> };
        for (const field of component.fields) saved.fields[field.name] = [];
        for (const e of entities) {
          for (let p = rows.firstOut![e]!; p !== 0; p = rows.nextOut![p]!) {
            saved.source.push(e);
            saved.target.push(rows.target![p]!);
            for (const field of component.fields) saved.fields[field.name]!.push(rows[field.name]![p]!);
          }
        }
        if (saved.source.length > 0) out.relations[component.name] = saved;
        continue;
      }
      const having = entities.filter((e) => this.extras.has(e as Entity, component));
      if (having.length === 0) continue;
      const disabled = having.filter((e) => !this.extras.enabled(e as Entity, component));
      const switched = (entry: WorldSave['components'][string]): WorldSave['components'][string] => (disabled.length > 0 ? { ...entry, disabled } : entry);
      if (component.kind === 'tag') out.components[component.name] = switched({ entities: having });
      else if (component.kind === 'data') {
        const store = this.stores[component.id] as Record<string, ArrayLike<number>>;
        const fields: Record<string, (number | string | KeyRef | string[] | number[])[]> = {};
        // A key field as its reference (`ecs/keys.ts`): an id is this session's, the uid and the key are the asset's. An
        // enum as its name, flags as their names, a `colorA` as `#rrggbbaa`; a vector as `[x, y, z]` an entity (`fields.ts`).
        for (const f of fileFields(component)) {
          if (f.field.vec !== undefined) fields[f.name] = having.map((e) => f.columns.map((x) => store[x.name]![e]!));
          else fields[f.name] = fieldIsText(component, f.name) ? having.map((e) => fieldText(component, f.name, store[f.name]![e]!)) : having.map((e) => store[f.name]![e]!);
        }
        out.components[component.name] = switched({ entities: having, fields });
      } else {
        const value = (this.stores[component.id] as { value: unknown[] }).value;
        // An object goes through its own `save`; a bare slot only if what it holds is plain already.
        const plain = (v: unknown): boolean => v === null || ['string', 'number', 'boolean'].includes(typeof v);
        if (component.save && component.load) out.components[component.name] = switched({ entities: having, values: having.map((e) => component.save!(value[e])) });
        else if (!component.create && having.every((e) => plain(value[e]))) out.components[component.name] = switched({ entities: having, values: having.map((e) => value[e]) });
      }
    }
    return out;
  }

  /** A scene's ref by an entity's index (`WorldSave.refs` 'index'): a ref to it as loaded, nobody for one not alive. */
  private indexRef(json: unknown): EntityRef {
    const to = typeof json === 'number' ? json : 0;
    return (to > 0 && to < this.high && this.state[to] === ALIVE ? ((this.gen[to]! << INDEX_BITS) | to) : 0) as EntityRef;
  }

  /**
   * A saved world put back in place of whatever is here: everything now alive
   * is destroyed first. The world must have the same components defined, by
   * name; what a save mentions that no longer exists is skipped, and returned
   * so the caller can say so. The loop carries on from the saved tick, with the
   * saved random streams: the same save always plays out the same way. (Not
   * necessarily as the world it was saved from would have: the order of a
   * system's members is not part of a save.) A scene's save has no streams:
   * they start from the loop's seed. The tick may go back, so the events and
   * the input history are dropped: neither is saved.
   */
  load(given: WorldSave): { skipped: string[] } {
    this.outside('load');
    if (given.version !== 1) throw new Error(`[ecs] world.load: a save of version ${String(given.version)}, and this build reads version 1`);
    // Each prefab by its uid first: one moved since is loaded from where it is, its entities' kinds named after it now.
    const data = followSavedPrefabs(given);
    const skipped: string[] = [];
    // Every name an enum or flags field is given checked before anything is destroyed: a save that names one its field
    // no longer has is refused whole, named, and the world left as it was. A data component's every element too.
    for (const [name, saved] of Object.entries(data.components)) {
      const component = this.components.find((c) => c.name === name);
      if (isData(component) && saved.values) {
        // A field its schema has not -- a misspelt one in a file, one the code dropped -- left out, and said, as a
        // component this build has not is: the next save would not have it (but a live swap's, which drops it quietly).
        if (data.swap !== true) for (const v of saved.values) for (const f of strayFields(component.data, v)) if (!skipped.includes(`${name}.${f}: no such field`)) skipped.push(`${name}.${f}: no such field`);
        for (let i = 0; i < saved.values.length; i++) {
          try {
            fillFrom(component.data, saved.values[i], {}, { ref: () => NO_REF, lenient: true }, name);
          } catch (error) {
            if (error instanceof DataError) throw new Error(`[ecs] world.load: entity ${saved.entities[i]}'s ${error.message}`);
            throw error;
          }
        }
      }
      if (component?.kind !== 'data' || !saved.fields) continue;
      for (const f of fileFields(component)) {
        if (!f.field.enum && !f.field.flags && !f.field.color) continue;
        const values = saved.fields[f.name] ?? [];
        for (let i = 0; i < values.length; i++) {
          const why = fieldProblem(component, f.name, values[i]);
          if (why !== null) throw new Error(`[ecs] world.load: entity ${saved.entities[i]}'s ${why}`);
        }
      }
    }

    // Everything out, through the usual way, so hooks run and systems empty.
    // What was spawned and not yet in the world comes in first, to go out with the rest.
    // The loop's queue is emptied after each boundary, as it is in a tick: a
    // join left waiting would land after the leave that should have undone it.
    // Pools drained with the rest: a destroy here is for real, a pooled instance and a parked one too.
    this.boundary(true);
    this.loop.applyPending();
    this.draining = true;
    for (let e = 1; e < this.high; e++) if (this.state[e] === ALIVE && this.links.parent[e] === 0) this.commands.destroy(e as Entity);
    this.boundary(true);
    this.loop.applyPending();
    this.boundary(true);
    this.loop.applyPending();
    this.draining = false;
    for (const pool of this.prefabPools) {
      if (pool) pool.clear();
    }

    // Room for it, with the usual half to spare.
    while ((data.extent > this.alloc.rows || data.entities.length * 2 > this.alloc.rows) && this.alloc.rows < this.alloc.maxRows) this.grow();
    if (data.extent > this.alloc.rows) throw new Error(`[ecs] world.load: the save has entities up to index ${data.extent}, and this world's maxEntities is ${this.alloc.maxRows}`);

    // The id allocator, as the save left it: every generation, nobody alive yet.
    this.head.fill(0);
    this.tail.fill(0);
    this.state.fill(FREE, 0, Math.max(this.high, data.extent));
    this.gen.fill(0, 0, this.high);
    this.gen.set(data.generations);
    this.high = Math.max(1, data.extent);
    for (const counts of this.kindCount) counts.fill(0);
    this.kindLow.fill(0);
    this.stats.entities = 0;

    const kindByName = new Map(allKinds().map((kind) => [kind.name, kind]));
    const rows = this.refindInstances(data, skipped);
    const inst = this.instanceStore;
    data.entities.forEach((e, i) => {
      const kind = kindByName.get(data.kinds[i]!);
      // An entity a prefab made: what is gone of it was said as the prefab, never as a kind.
      const ofPrefab = (data.instances?.prefab[i] ?? 0) !== 0;
      if (!kind && !ofPrefab && !skipped.includes(`kind ${data.kinds[i]}`)) skipped.push(`kind ${data.kinds[i]}`);
      const k = (kind ?? Bare).id;
      this.state[e] = ALIVE;
      this.kindOf[e] = k;
      this.layerOf[e] = (data.layers?.[i] ?? 0) & 31;
      inst.prefab[e] = rows.prefab[i]!;
      inst.node[e] = rows.node[i]!;
      inst.root[e] = rows.root[i]!;
      inst.next[e] = rows.next[i]!;
      (this.kindCount[k] ?? this.newKind(k))[e % CYCLE]!++;
      this.stats.entities++;
    });
    for (const counts of this.kindCount) this.kindLow[this.kindCount.indexOf(counts)] = Math.min(...counts);

    const byName = new Map(this.components.map((component) => [component.name, component]));
    const byIndex = data.refs === 'index';
    for (const [name, saved] of Object.entries(data.components)) {
      const component = byName.get(name);
      if (!component || component.kind === 'relation' || component.bit < 0) {
        skipped.push(`component ${name}`);
        continue;
      }
      const store = this.stores[component.id] as Record<string, number[]> & { value: unknown[] };
      saved.entities.forEach((e, i) => {
        this.defaults(e, component);
        if (component.kind === 'data' && saved.fields) {
          for (const field of component.fields) {
            // A vector's axis from its `[x, y, z]`, or its own column (a save from before it was a vector).
            const given = field.name in saved.fields ? saved.fields[field.name]![i] : field.of !== undefined ? (saved.fields[field.of]?.[i] as number[] | undefined)?.[field.axis!] : undefined;
            if (given === undefined) continue;
            // A scene's ref by the entity's index: made a ref to it as loaded, nobody for one the save has not alive.
            if (byIndex && (component.schema as Record<string, Field>)[field.name]?.ref) {
              const to = typeof given === 'number' ? given : 0;
              store[field.name]![e] = to > 0 && to < this.high && this.state[to] === ALIVE ? ((this.gen[to]! << INDEX_BITS) | to) : 0;
              continue;
            }
            // A key field's text interned; a number as it was (a save from before the field was a key).
            store[field.name]![e] = fieldValue(component, field.name, given) ?? field.initial;
          }
        } else if (isData(component) && byIndex && saved.values) {
          // A scene's refs inside it by the entity's index, as its columns' (`sceneSave`).
          fillFrom(component.data, saved.values[i], store.value[e] as Record<string, unknown>, { ref: (json) => this.indexRef(json), lenient: true });
        } else if (component.kind === 'object' && saved.values) {
          const load = (component as ObjectComponent<unknown>).load;
          store.value[e] = load ? (load(saved.values[i], store.value[e]) ?? store.value[e]) : saved.values[i];
        }
        this.attach(e, component);
      });
      // Switched off as saved: the bit, and whoever listens told, as `enable` would.
      for (const e of saved.disabled ?? []) {
        if (!this.extras.has(e as Entity, component)) continue;
        this.off[e * this.words + (component.bit >>> 5)]! |= 1 << (component.bit & 31);
        const hook = this.toggleHooks[component.id];
        if (hook) hook(e as Entity, false);
      }
    }
    for (let i = 0; i < data.parents.length; i += 2) this.reparent(data.parents[i]!, data.parents[i + 1]!);
    // The roots in their saved order; any the save does not order -- all of one from before it kept one -- after, by index.
    this.headRoot = this.tailRoot = 0;
    for (const e of data.roots ?? []) if (this.state[e] === ALIVE && this.links.parent[e] === 0 && !this.isRoot(e)) this.linkRoot(e);
    for (const e of data.entities) if (this.links.parent[e] === 0 && !this.isRoot(e)) this.linkRoot(e);
    for (const [name, saved] of Object.entries(data.relations)) {
      const relation = byName.get(name);
      const table = relation ? this.tables[relation.id] : null;
      if (!relation || !table) {
        skipped.push(`relation ${name}`);
        continue;
      }
      // Newest link first in a list, so the save has them newest first: put back
      // oldest first and the lists read as they did.
      for (let i = saved.source.length - 1; i >= 0; i--) {
        const source = saved.source[i]!;
        let p = table.reserve(source, saved.target[i]!);
        if (p === 0) {
          table.roll();
          p = table.reserve(source, saved.target[i]!);
        }
        const store = table.store as Record<string, number[]>;
        for (const field of (relation as Relation).fields) {
          const values = saved.fields[field.name];
          if (values) store[field.name]![p] = values[i]!;
        }
        table.link(p, true);
        table.roll();
      }
    }

    // The free indices back in their rings, lowest first; the never-used start past the save.
    // No `Instance` row on one: nothing may walk into it from a chain (`reserve` clears it again).
    for (let e = 1; e < this.high; e++) {
      if (this.state[e] !== FREE) continue;
      inst.prefab[e] = inst.node[e] = inst.root[e] = inst.next[e] = 0;
      this.nextFree[e] = 0;
      const p = e % CYCLE;
      const last = this.tail[p]!;
      if (last === 0) this.head[p] = e;
      else this.nextFree[last] = e;
      this.tail[p] = e;
    }
    for (let p = 0; p < CYCLE; p++) {
      let first = p === 0 ? CYCLE : p;
      while (first < this.high) first += CYCLE;
      this.fresh[p] = first;
    }

    // Lowest index first into every system, whatever order the components came in: the same
    // save always gives the same members in the same order, and so the same run.
    for (let i = 0; i < this.dirtyCount; i++) this.flags[this.dirty[i]!]! &= ~DIRTY;
    this.dirtyCount = 0;
    for (const e of data.entities) this.touch(e);

    // Events are not saved, and the tick may go back: every channel starts empty.
    for (let i = 0; i < this.channelList.length; i++) this.channelList[i]!.clear();
    this.loop.loadState(data.loop);
    this.lastTick = data.loop.tick - 1;
    // Everyone into their systems, and every world transform worked out. No
    // onJoin, no onLeave: they were members already when the game was saved.
    this.boundary(true);
    this.announceInstances();
    this.loop.applyPending();
    this.loop.forgetNotices();
    // Each pool counts what is out of it again, and is warmed afresh: a save holds no parked instance.
    for (let e = 1; e < this.high; e++) {
      if (this.state[e] !== ALIVE || inst.prefab[e] === 0 || inst.root[e] !== e) continue;
      const p = compiledPrefabs()[inst.prefab[e]!]!;
      if (p.pool) this.lent(this.poolOf(p));
    }
    if (this.pooling) this.warmPools();
    for (let i = 0; i < this.loadHooks.length; i++) this.loadHooks[i]!();
    return { skipped };
  }

  /**
   * Told after every `load` -- a saved game, a scene, a playtest put back, a live swap's save: the world is the save's
   * now, made again entity by entity. How the physics stage knows to make Bullet's world afresh (Docs/physics.md D18)
   * rather than take a load for a game that removed its bodies. Returns the undo; a reset drops every hook.
   */
  onLoad(hook: () => void): () => void {
    this.loadHooks.push(hook);
    return () => unlisten(this.loadHooks, hook);
  }

  private saveInstances(entities: number[]): WorldSave['instances'] {
    const inst = this.instanceStore;
    // Each prefab by its reference (Docs/asset-ids.md §3): its uid, so a scene or a save loads it moved.
    const keys: (string | KeyRef)[] = [''];
    const seen: string[] = [''];
    const nodes: string[][] = [[]];
    const names: (string | null)[][] = [[]];
    const prefab = entities.map((e) => {
      const p = compiledPrefabs()[inst.prefab[e]!];
      if (!p) return 0;
      const at = seen.indexOf(p.key);
      if (at >= 0) return at;
      nodes.push(p.kinds.map((k) => k.name));
      names.push([...p.names]);
      seen.push(p.key);
      return keys.push(keyRef('prefabs', p.key)) - 1;
    });
    return { keys, prefab, node: entities.map((e) => inst.node[e]!), root: entities.map((e) => inst.root[e]!), next: entities.map((e) => inst.next[e]!), nodes, names };
  }

  /**
   * Each saved entity's `Instance` row, in `entities` order, as the prefabs are
   * compiled now (Docs/prefabs.md §6). A prefab gone: its entities plain, `prefab
   * <key>` in `skipped`. Otherwise each entity is the node of its kind's name
   * (`refindNodes`, which says what changed): one whose node is gone is plain,
   * where the instance left it, and the rest are chained again in node order
   * from their root. An instance whose root is not its node 0 is plain whole.
   * Nothing is trusted that the prefab's changes could have moved: not `node`,
   * not `next`.
   */
  private refindInstances(data: WorldSave, skipped: string[]): { prefab: number[]; node: number[]; root: number[]; next: number[] } {
    const n = data.entities.length;
    const out = { prefab: new Array<number>(n).fill(0), node: new Array<number>(n).fill(0), root: new Array<number>(n).fill(0), next: new Array<number>(n).fill(0) };
    const saved = data.instances;
    if (!saved) return out;
    const say = (what: string): void => void (skipped.includes(what) || skipped.push(what));
    // Each prefab's saved entities found again in it.
    const node = new Array<number>(n).fill(-1);
    const ofKey = new Map<number, number[]>();
    for (let i = 0; i < n; i++) {
      const k = saved.prefab[i]!;
      if (k === 0) continue;
      const list = ofKey.get(k) ?? [];
      list.push(i);
      ofKey.set(k, list);
    }
    for (const [k, list] of ofKey) {
      const p = compiledPrefab(refText(saved.keys[k]));
      if (!p) {
        say(`prefab ${refText(saved.keys[k])}`);
        continue;
      }
      const kinds = saved.nodes?.[k];
      const found = refindNodes(p, list.map((i) => data.kinds[i]!), kinds ? { kinds, names: saved.names?.[k] } : undefined, say);
      list.forEach((i, j) => (node[i] = found[j]!));
    }
    // Each instance chained again from its root, in node order; a node twice, the second plain.
    const rowOf = new Map(data.entities.map((e, i) => [e, i]));
    const members = new Map<number, number[]>();
    for (let i = 0; i < n; i++) {
      if (node[i]! < 0) continue;
      const list = members.get(saved.root[i]!) ?? [];
      list.push(i);
      members.set(saved.root[i]!, list);
    }
    for (const [root, list] of members) {
      const r = rowOf.get(root);
      if (r === undefined || node[r] !== 0 || saved.prefab[r] !== saved.prefab[list[0]!]) continue;
      const id = compiledPrefab(refText(saved.keys[saved.prefab[r]!]))!.id;
      list.sort((a, b) => node[a]! - node[b]! || (a === r ? -1 : b === r ? 1 : 0));
      let last = -1;
      for (const i of list) {
        if (saved.prefab[i] !== saved.prefab[r] || (last >= 0 && node[i] === node[last])) continue;
        out.prefab[i] = id;
        out.node[i] = node[i]!;
        out.root[i] = root;
        if (last >= 0) out.next[last] = data.entities[i]!;
        last = i;
      }
    }
    return out;
  }

  /** Every instance root in the world, to the `onInstance` hooks: after a load. */
  private announceInstances(): void {
    if (this.instanceHooks.length === 0) return;
    const inst = this.instanceStore;
    for (let e = 1; e < this.high; e++) {
      if (this.state[e] !== ALIVE || inst.prefab[e] === 0 || inst.root[e] !== e) continue;
      for (const hook of this.instanceHooks) hook(e as Entity, compiledPrefabs()[inst.prefab[e]!]!, true);
    }
  }

  // ── what a command does at once (CommandHost) ───────────────────────────

  reserve(kind: Kind): Entity {
    const k = kind.id;
    const counts = this.kindCount[k] ?? this.newKind(k);
    // The phase where this kind has the fewest, from a cursor that moves on, so
    // ties go round in order. `low` is the least any phase holds: reaching it
    // ends the search.
    const low = this.kindLow[k]!;
    const start = this.kindCursor[k]!;
    const rows = this.alloc.rows;
    let best = -1;
    let bestCount = 0x7fffffff;
    for (let i = 0; i < CYCLE; i++) {
      const p = start + i < CYCLE ? start + i : start + i - CYCLE;
      if (this.head[p] === 0 && this.fresh[p]! >= rows) continue;
      const c = counts[p]!;
      if (c < bestCount) {
        best = p;
        bestCount = c;
        if (c <= low) break;
      }
    }
    if (best < 0 && !this.ticking && rows < this.alloc.maxRows) {
      // Setup, a load, the editor: no system is running and holding a column, so the world grows now.
      this.grow();
      return this.reserve(kind);
    }
    if (best < 0) {
      this.stats.refused++;
      if (!this.warnedFull) {
        this.warnedFull = true;
        console.warn(
          rows < this.alloc.maxRows
            ? `[ecs] out of entity ids mid-tick at ${rows}: more than half the world was spawned in one tick. The spawn returned NONE; the world grows at the boundary. Start larger: new World({ entities: ${rows * 2} })`
            : `[ecs] the world is full at maxEntities (${rows}): spawn returned NONE. Raise it: new World({ maxEntities: ... }), at most ${ENTITY_LIMIT}`,
        );
      }
      return 0 as Entity;
    }
    if (bestCount > low) this.kindLow[k] = bestCount;
    this.kindCursor[k] = best + 1 === CYCLE ? 0 : best + 1;
    counts[best] = bestCount + 1;

    let e = this.head[best]!;
    if (e !== 0) {
      const next = this.nextFree[e]!;
      this.head[best] = next;
      if (next === 0) this.tail[best] = 0;
    } else {
      e = this.fresh[best]!;
      this.fresh[best] = e + CYCLE;
      if (e >= this.high) this.high = e + 1;
    }
    this.state[e] = UNBORN;
    this.kindOf[e] = k;
    this.stats.entities++;
    const inst = this.instanceStore;
    inst.prefab[e] = 0;
    inst.node[e] = 0;
    inst.root[e] = 0;
    inst.next[e] = 0;
    const components = kind.components;
    for (let i = 0; i < components.length; i++) this.defaults(e, components[i]!);
    return e as Entity;
  }

  reserveInstance(token: PrefabToken): Entity {
    const p = compiledPrefabs()[token.id];
    if (!p) throw new Error(`[ecs] instantiate(${token.made}): prefabs are not compiled yet (Prefabs.compile() runs before the world is made)`);
    this.instanceTaken = false;
    return p.pool ? this.take(p) : this.make(p);
  }

  /**
   * A pooled prefab's instance: a parked one taken -- its entities its own
   * again until the boundary, as a new one's are, so `init` and `part` work on
   * it; `TAKE` switches it on there -- or, the pool empty, a new one made, up
   * to `max` alive (parked and out). At `max`, `NONE` and one warning.
   */
  private take(p: CompiledPrefab): Entity {
    const pool = this.poolOf(p);
    this.instanceRefused = false;
    if (pool.parked > 0) {
      // The one parked longest: each root goes round in turn.
      const root = pool.shift();
      const inst = this.instanceStore;
      // Its generation as its give-back left it: no ref could be minted to it since (`ref` of a parked entity is `NONE`).
      for (let x = root; x !== 0; x = inst.next[x]!) {
        this.state[x] = UNBORN;
        this.flags[x]! &= ~PARKED;
        this.stats.parked--;
      }
      // Its own refs, `NONE` while it was parked, to its own entities now.
      this.ownRefs(p, root);
      this.lent(pool);
      this.instanceTaken = true;
      return root as Entity;
    }
    const max = p.pool!.max;
    if (pool.parked + pool.resting + pool.out >= max) {
      this.stats.refused++;
      if (!pool.warned) {
        pool.warned = true;
        console.warn(`[ecs] the pool of ${p.key} is empty at its max: ${pool.parked + pool.resting + pool.out} held of max ${max}, ${pool.out} out and ${pool.resting} resting: instantiate returned NONE. Raise its "max" (Docs/prefabs.md §5), or give instances back sooner`);
      }
      return 0 as Entity;
    }
    const root = this.make(p);
    // Counted even refused part way: the destroy that follows it counts it back.
    if (root !== 0) this.lent(pool);
    return root;
  }

  /** One more instance of `pool` out. */
  private lent(pool: PoolRows): void {
    pool.out++;
    if (pool.out > pool.mostOut) pool.mostOut = pool.out;
  }

  /**
   * The refs inside the instance `root` heads, each to its own entity as
   * `ref` mints it now: `NONE` while it is parked, so nothing read off a
   * parked instance reaches its next life; the real ones at the take.
   */
  private ownRefs(p: CompiledPrefab, root: number): void {
    const refs = p.refs;
    if (refs.length === 0) return;
    const inst = this.instanceStore;
    if (this.parts.length < p.count) this.parts = new Uint32Array(p.count * 2); // alloc-ok: grows once to the largest prefab
    const parts = this.parts;
    let n = 0;
    for (let x = root; x !== 0 && n < p.count; x = inst.next[x]!) parts[n++] = x;
    for (let r = 0; r < refs.length; r++) {
      const run = refs[r]!;
      const column = this.columns[run.component]![run.field] as number[];
      for (let j = 0; j < run.node.length; j++) column[parts[run.node[j]!]!] = this.extras.ref(parts[run.target[j]!]! as Entity);
    }
  }

  /** A prefab's instance made: every entity reserved and its rows written (`reserveInstance`). */
  private make(p: CompiledPrefab): Entity {
    const n = p.count;
    this.instanceRefused = false;
    if (this.parts.length < n) this.parts = new Uint32Array(n * 2); // alloc-ok: grows once to the largest prefab
    const parts = this.parts;
    const inst = this.instanceStore;
    for (let i = 0; i < n; i++) {
      const e = this.reserve(p.kinds[i]!);
      if (e === 0) {
        // Full mid-tick: what was reserved is born and let go at the boundary (`Commands.instantiate`).
        this.instanceRefused = true;
        return parts[0]! === 0 || i === 0 ? (0 as Entity) : (parts[0]! as Entity);
      }
      parts[i] = e;
      inst.prefab[e] = p.id;
      inst.node[e] = i;
      inst.root[e] = parts[0]!;
      if (i > 0) inst.next[parts[i - 1]!] = e;
    }
    const writes = p.writes;
    for (let w = 0; w < writes.length; w++) {
      const run = writes[w]!;
      const column = this.columns[run.component]![run.field] as number[];
      const nodes = run.node;
      const values = run.value;
      for (let j = 0; j < nodes.length; j++) column[parts[nodes[j]!]!] = values[j]!;
    }
    const refs = p.refs;
    for (let r = 0; r < refs.length; r++) {
      const run = refs[r]!;
      const column = this.columns[run.component]![run.field] as number[];
      for (let j = 0; j < run.node.length; j++) column[parts[run.node[j]!]!] = this.extras.ref(parts[run.target[j]!]! as Entity);
    }
    // Object components as `load` puts back a saved one: into this entity's own object, or its replacement.
    // The compile allowed no data without a `load` but a plain value, which every instance may share.
    // What `load` allocates is the instance's cost: `Labels`' and `Name`'s nothing.
    this.loadObjects(p, parts);
    return parts[0]! as Entity;
  }

  /** Each object component the prefab gives data, into its node's entity of `parts`: as `load` puts back a saved one. */
  private loadObjects(p: CompiledPrefab, parts: Uint32Array): void {
    const objects = p.objects;
    for (let o = 0; o < objects.length; o++) {
      const { component, node, data } = objects[o]!;
      const store = this.stores[component.id] as { value: unknown[] };
      const e = parts[node]!;
      // A data component's compiled data names nodes by index (`prefab.ts`' `build`): each this instance's entity.
      if (isData(component)) fillFrom(component.data, data, store.value[e] as Record<string, unknown>, { ref: (n) => (typeof n === 'number' && n < parts.length && parts[n] !== 0 ? this.extras.ref(parts[n]! as Entity) : NO_REF) });
      else if (component.kind === 'object' && component.load) store.value[e] = component.load(data, store.value[e]) ?? store.value[e];
      else store.value[e] = data;
    }
  }

  /** The entity of `node` in the instance `root` heads, `NONE` if it has none: `world.part(big, RiderOfBig)`, `ctx.cmd.part` in a system. */
  part<N extends PrefabNode>(root: Entity, node: N): EntityOf<N> {
    const inst = this.instanceStore;
    if (root === 0 || inst.prefab[root] !== node.prefab.id || inst.root[root] !== root) return 0 as EntityOf<N>;
    // Only through entities whose row still names this root: a link can never lead into another instance.
    for (let e = root as number; e !== 0 && inst.root[e] === root; e = inst.next[e]!) if (inst.node[e] === node.index) return e as EntityOf<N>;
    return 0 as EntityOf<N>;
  }

  /**
   * Made at the boundary its instance joins the world -- one `instantiate`
   * made, or one `restoreInstance` wrote back -- and for every instance `load`
   * brings back: where views are attached (the `render` system, `src/render.ts`).
   * `loaded` is true for one a load brought back: made earlier, perhaps from
   * a compile since replaced, which `prefab` (the one now) is not.
   */
  onInstance(hook: (root: Entity, prefab: CompiledPrefab, loaded: boolean) => void): void {
    this.instanceHooks.push(hook);
  }

  /**
   * The `onInstance` hooks for `root` at the next boundary, as for an instance
   * `instantiate` made: an instance written back by hand, its `Instance` rows
   * filled in since the last boundary -- a paste or a duplicate of one (the
   * editor's `restoreInstance`, `packages/editor/src/clip.ts`). Nothing happens if `root`
   * is then no living instance's root.
   */
  announceInstance(root: Entity): void {
    this.outside('announceInstance');
    this.commands.announce(root);
  }

  /** An instance of `prefab`, from the next boundary; its root now. Outside a system: inside one, `ctx.cmd.instantiate`. */
  instantiate<P extends PrefabToken>(prefab: P): EntityOf<P> {
    this.outside('instantiate');
    return this.commands.instantiate(prefab);
  }

  /** The prefab `e` was made from, or null. */
  prefabOf(e: Entity): CompiledPrefab | null {
    return compiledPrefabs()[this.instanceStore.prefab[e]!] ?? null;
  }

  /** The root of the instance `e` belongs to; `NONE` if a prefab did not make it. */
  instanceRoot(e: Entity): Entity {
    return (this.instanceStore.prefab[e] === 0 ? 0 : this.instanceStore.root[e]!) as Entity;
  }

  /** Which entity of its prefab `e` is (an index into `prefabOf(e).paths`); -1 if a prefab did not make it. */
  nodeOf(e: Entity): number {
    return this.instanceStore.prefab[e] === 0 ? -1 : this.instanceStore.node[e]!;
  }

  prepare(e: Entity, component: AnyComponent): unknown {
    this.known(component, '[ecs] add');
    if (component.bit < 0 || component === WorldTransform) throw new Error(`[ecs] add(${component.name}): ${component === WorldTransform ? 'it comes with Transform' : 'every entity has it'}`);
    if (component.kind === 'relation') throw new Error(`[ecs] add(${component.name}): a relation needs a target. Use relate(e, ${component.name}, target)`);
    if (this.extras.has(e, component)) throw new Error(`[ecs] add(${component.name}) on entity ${e}, which has it already: to change its data, list ${component.name} in a system's write`);
    this.defaults(e, component);
    return this.stores[component.id];
  }

  ownStore(e: Entity, component: AnyComponent): unknown {
    if (this.state[e] !== UNBORN) throw new Error(`[ecs] init(${component.name}) on entity ${e}, which was not spawned since the last boundary: init is for filling in a new entity. To change a living one, list ${component.name} in a system's write`);
    return this.stores[component.id];
  }

  grew(): void {
    this.stats.commandGrowths++;
  }

  pair(source: Entity, relation: Relation, target: Entity): number {
    this.known(relation, '[ecs] relate');
    return this.tables[relation.id]!.reserve(source, target);
  }

  relationBit(e: number, relation: Relation, on: boolean): void {
    const at = e * this.words + (relation.bit >>> 5);
    if (on) this.mask[at]! |= 1 << (relation.bit & 31);
    else this.mask[at]! &= ~(1 << (relation.bit & 31));
    this.touch(e);
  }

  midTick(): boolean {
    return this.ticking;
  }

  eventTick(): number {
    // Outside a tick an event belongs to the last one, so the next tick's readers see it.
    return this.ticking ? this.currentTick : this.lastTick;
  }

  // ── change tracking ─────────────────────────────────────────────────────

  /** Starts watching a component's data for changes, the first time a system lists it in `changed`. */
  private track(component: Component<any>, where: string): void {
    this.known(component, where);
    if (component.kind !== 'data') throw new Error(`${where} lists ${(component as AnyComponent).name} in changed: only numeric components can be compared. For a tag or a relation, onJoin and onLeave say when it came and went`);
    if (component === Hierarchy || component === WorldTransform) throw new Error(`${where} lists ${component.name} in changed: ${component === WorldTransform ? 'WorldTransform has its own stamp, `changed[e]`, the tick it last moved on' : 'the tree changes only at a boundary'}`);
    if (this.tracked[component.id]) return;
    const names = component.fields.map((field) => field.name);
    const tracked: Tracked = { component, stamp: null!, shadow: shaped(names), members: new Members(1) };
    this.alloc.column(tracked, 'stamp', 'i32');
    for (const field of component.fields) this.alloc.column(tracked.shadow, field.name, field.type);
    this.tracked[component.id] = tracked;
    this.trackedList.push(tracked);
    // Who has it is a standing query like any other.
    const need = new Uint32Array(this.words);
    need[component.bit >>> 5]! |= 1 << (component.bit & 31);
    this.enrol({ name: `changes of ${component.name}`, phase: 'query', rate: 0, need, not: new Uint32Array(this.words), some: null, layers: ALL_LAYERS, includeDisabled: true, selective: true, handle: -1, own: tracked.members, reads: [], writes: [], cmd: null, stages: '' });
    const list = tracked.members.lists[0]!;
    for (let n = 0; n < tracked.members.counts[0]!; n++) this.noteChange(tracked, list[n]!);
  }

  /** `e`'s row of a tracked component, taken as seen and stamped as changed now. */
  private noteChange(tracked: Tracked, e: number): void {
    const columns = this.columns[tracked.component.id]!;
    const fields = tracked.component.fields;
    for (let f = 0; f < fields.length; f++) (tracked.shadow[fields[f]!.name] as number[])[e] = columns[f]![e]!;
    tracked.stamp[e] = this.lastTick;
  }

  /** After a tick's systems: every tracked component's rows against their copies, the changed ones stamped `tick`. */
  private scanChanges(tick: number): void {
    const all = this.trackedList;
    for (let t = 0; t < all.length; t++) {
      const tracked = all[t]!;
      const columns = this.columns[tracked.component.id]!;
      const stamp = tracked.stamp;
      const list = tracked.members.lists[0]!;
      const count = tracked.members.counts[0]!;
      const fields = tracked.component.fields;
      for (let f = 0; f < fields.length; f++) {
        // A field at a time: one column against its copy, both typed arrays of one kind.
        const now = columns[f]!;
        const was = tracked.shadow[fields[f]!.name] as number[];
        for (let n = 0; n < count; n++) {
          const e = list[n]!;
          const value = now[e]!;
          const old = was[e]!;
          // Two NaNs are no change (NaN !== NaN): a float field left NaN is not "changed" every tick.
          if (value !== old && (value === value || old === old)) {
            was[e] = value;
            stamp[e] = tick;
          }
        }
      }
    }
  }

  // ── the boundary ────────────────────────────────────────────────────────

  private pending(): boolean {
    // Events emitted outside a tick become readable at a boundary too.
    if (!this.built || this.movedCount > 0 || this.channelList.length > 0) return true;
    const buffers = this.buffers;
    for (let i = 0; i < buffers.length; i++) if (buffers[i]!.length > 0) return true;
    return false;
  }

  /**
   * Between two ticks: every buffer applied in the order its system ran, then
   * every entity that changed placed in its systems, world transforms set for
   * what was spawned or re-parented, and the dead handed back.
   */
  private boundary(end: boolean): void {
    if (this.flushing) return;
    if (!this.built) this.build();
    this.flushing = true;
    let done = false;
    try {
      this.applyBoundary(end);
      done = true;
    } finally {
      // A throw (a hook's, a bug's) must not stop every boundary after it: what was
      // left of the buffers is dropped -- the rest of this boundary's work is kept
      // in its counts for the next one -- and the next boundary runs as ever.
      if (!done) for (let i = 0; i < this.buffers.length; i++) this.buffers[i]!.length = 0;
      this.flushing = false;
    }
  }

  private applyBoundary(end: boolean): void {
    // Given back before the tick that just ended: `onLeave` has read them, so now they are reset and parked.
    // First, so what they need again (a view a hook attaches) is applied with this boundary's commands.
    if (end && this.backCount > 0) {
      const n = this.backCount;
      this.backCount = 0;
      for (let i = 0; i < n; i++) this.park(this.back[i]!);
    }
    const buffers = this.buffers;
    for (let i = 0; i < buffers.length; i++) {
      const buffer = buffers[i]!;
      // A hook may queue more on the world's own buffer: the length is read each time.
      for (let at = 0; at < buffer.length; at += STRIDE) this.apply(buffer.data[at]!, buffer.data[at + 1]!, buffer.data[at + 2]!, buffer.data[at + 3]!);
      buffer.length = 0;
    }

    // Membership: only the entities that changed, only the systems that care.
    const dirty = this.dirty;
    for (let i = 0; i < this.dirtyCount; i++) {
      const e = dirty[i]!;
      const full = (this.flags[e]! & FULL) !== 0;
      this.flags[e]! &= ~(DIRTY | FULL);
      this.sort(e, full);
    }
    this.dirtyCount = 0;

    const moved = this.shifted;
    for (let i = 0; i < this.movedCount; i++) {
      const e = moved[i]!;
      this.flags[e]! &= ~MOVED;
      if (this.state[e] === ALIVE) this.transforms.settle(e, this.lastTick, true);
    }
    this.movedCount = 0;

    // Those that died before the tick that just ended go back in their rings.
    // A tick's rest in between, so a system's `onLeave` reads their rows before
    // anyone reuses them.
    if (end) {
      const limbo = this.limbo;
      for (let i = 0; i < this.limboCount; i++) {
        const e = limbo[i]!;
        this.state[e] = FREE;
        this.nextFree[e] = 0;
        const p = e % CYCLE;
        const last = this.tail[p]!;
        if (last === 0) this.head[p] = e;
        else this.nextFree[last] = e;
        this.tail[p] = e;
      }
      this.limboCount = 0;
    }
    // Those that died now: a generation on at once, so every ref to them is stale.
    const dead = this.dead;
    for (let i = 0; i < this.deadCount; i++) {
      const e = dead[i]!;
      this.gen[e] = (this.gen[e]! + 1) & GENERATION_MASK;
      if (this.limboCount === this.limbo.length) this.limbo = grown(this.limbo);
      this.limbo[this.limboCount++] = e;
    }
    this.deadCount = 0;

    // Events emitted since the last boundary become readable; links and channels make room.
    const channels = this.channelList;
    for (let i = 0; i < channels.length; i++) channels[i]!.roll(this.lastTick);
    const tables = this.tableList;
    for (let i = 0; i < tables.length; i++) tables[i]!.roll();

    // Room for the next tick: never less than half the world free.
    if (this.stats.entities * 2 > this.alloc.rows && this.alloc.rows < this.alloc.maxRows) this.grow();
  }

  private apply(op: number, e: number, arg: number, extra: number): void {
    switch (op) {
      case SPAWN: {
        if (this.state[e] !== UNBORN) return;
        this.state[e] = ALIVE;
        // A root, last of the roots: an instance's other entities leave the order again as they go under it.
        this.linkRoot(e);
        const components = allKinds()[arg]!.components;
        for (let i = 0; i < components.length; i++) this.attach(e, components[i]!);
        return;
      }
      case ADD: {
        const component = this.components[arg]!;
        if (this.state[e] !== ALIVE) {
          // Its entity died first: the object it was given goes back.
          this.release(e, component);
          return;
        }
        // Given twice in one tick (two systems, unaware of each other): the first stands,
        // as a second relate does; its row holds whatever was written into it last.
        if (this.extras.has(e as Entity, component)) {
          this.warnOnce(`twice:${component.name}`, `[ecs] entity ${e} was given ${component.name} twice in one tick (cmd.add from two places): the second add did nothing (said once). Give it from one system, or let one decide`);
          return;
        }
        this.attach(e, component);
        return;
      }
      case REMOVE: {
        const component = this.components[arg]!;
        if (this.state[e] !== ALIVE || component.bit < 0 || !this.extras.has(e as Entity, component)) return;
        // A relation is on an entity while it has a link out: taking it off is cutting them all.
        if (component.kind === 'relation') this.tables[arg]!.unrelate(e, 0);
        else this.detach(e, component);
        return;
      }
      case RELATE: {
        // `e` is the link's row here. Both ends must have lived to the boundary.
        const table = this.tables[arg]!;
        const rows = table.store as { source: Uint32Array; target: Uint32Array };
        table.link(e, this.state[rows.source[e]!] === ALIVE && this.state[rows.target[e]!] === ALIVE);
        return;
      }
      case UNRELATE:
        if (this.state[e] === ALIVE) this.tables[arg]!.unrelate(e, extra);
        return;
      case PARENT:
        if (this.state[e] === ALIVE && (arg === 0 || this.state[arg] === ALIVE)) this.reparent(e, arg, extra);
        return;
      case ENABLE: {
        const component = this.components[arg]!;
        if (this.state[e] !== ALIVE || component.bit < 0 || !this.extras.has(e as Entity, component)) return;
        const at = e * this.words + (component.bit >>> 5);
        const bit = 1 << (component.bit & 31);
        const was = (this.off[at]! & bit) === 0;
        if (was === (extra === 1)) return;
        if (extra === 1) this.off[at]! &= ~bit;
        else this.off[at]! |= bit;
        this.touch(e, true);
        const hook = this.toggleHooks[arg];
        if (hook) hook(e as Entity, extra === 1);
        return;
      }
      case LAYER:
        if (this.state[e] !== ALIVE || this.layerOf[e] === arg) return;
        this.layerOf[e] = arg;
        this.touch(e, true);
        for (let i = 0; i < this.layerHooks.length; i++) this.layerHooks[i]!(e as Entity, arg);
        return;
      case DESTROY: {
        if (this.state[e] !== ALIVE) return;
        // `arg` 1: for real (`pool.drain()`); so is everything while `load` empties the world.
        const real = arg === 1 || this.draining;
        // Parked, or given back already this boundary: only a drain takes it.
        if ((this.flags[e]! & PARKED) !== 0) {
          if (!real) return;
          this.unrest(e);
          this.kill(e, true);
          return;
        }
        if (!real && this.pooledRoot(e)) this.giveBack(e);
        else this.kill(e, real);
        return;
      }
      case INSTANTIATE: {
        const p = compiledPrefabs()[arg]!;
        const inst = this.instanceStore;
        const parts = this.parts;
        let i = 0;
        for (let x = e; x !== 0; x = inst.next[x]!) {
          parts[i++] = x;
          this.apply(SPAWN, x, p.kinds[inst.node[x]!]!.id, 0);
        }
        if (this.state[e] !== ALIVE) return;
        for (let j = 1; j < i; j++) this.apply(PARENT, parts[j]!, parts[p.parents[j]!]!, 0);
        for (let j = 0; j < i; j++) if (p.layers[j] !== 0) this.apply(LAYER, parts[j]!, p.layers[j]!, 0);
        // `i` short of `p.count` only for an instance refused part way, destroyed straight after.
        for (let o = 0; o < p.off.length; o++) if (p.off[o]!.node < i) this.apply(ENABLE, parts[p.off[o]!.node]!, p.off[o]!.component, 0);
        this.makeLinks(p, parts, i);
        // Refused part way: destroyed by the next command, so no hook makes it a view.
        if (i < p.count) return;
        for (let h = 0; h < this.instanceHooks.length; h++) this.instanceHooks[h]!(e as Entity, p, false);
        return;
      }
      case ANNOUNCE: {
        // An instance written back by hand (`restoreInstance`), its tree and links made by the commands before this one.
        const inst = this.instanceStore;
        if (this.state[e] !== ALIVE || inst.prefab[e] === 0 || inst.root[e] !== e) return;
        const p = compiledPrefabs()[inst.prefab[e]!]!;
        // A pooled prefab's instance written back by hand is out of its pool, as one made is.
        if (p.pool) this.lent(this.poolOf(p));
        for (let h = 0; h < this.instanceHooks.length; h++) this.instanceHooks[h]!(e as Entity, p, false);
        return;
      }
      case TAKE: {
        // A parked instance taken (`take`): its own again since, and now switched on -- every system sees it
        // join, as a new one; nothing written, nothing made. Its world transform as `init` left it.
        const inst = this.instanceStore;
        for (let x = e; x !== 0; x = inst.next[x]!) {
          if (this.state[x] === UNBORN) this.state[x] = ALIVE;
          this.touch(x, true);
          for (let t = 0; t < this.trackedList.length; t++) if (this.extras.has(x as Entity, this.trackedList[t]!.component)) this.noteChange(this.trackedList[t]!, x);
        }
        if (this.extras.has(e as Entity, Disabled)) this.detach(e, Disabled);
        // Taken, a root again: last of the roots, as one made is.
        if (this.links.parent[e] === 0 && !this.isRoot(e)) this.linkRoot(e);
        this.shift(e);
        return;
      }
      case PARK: {
        // Made this boundary by `warmPools`, and parked before any system could see it.
        if (this.state[e] !== ALIVE) return;
        const p = compiledPrefabs()[arg]!;
        if (!this.extras.has(e as Entity, Disabled)) this.attach(e, Disabled);
        this.flag(e);
        // Its own refs `NONE` while parked, as a reset leaves them: the take writes them.
        this.ownRefs(p, e);
        this.poolOf(p).push(e);
        return;
      }
    }
  }

  /** A prefab's links among `parts` (its first `count` nodes): each made, its data written before it is linked, as `relate` hands back a row to fill. */
  private makeLinks(p: CompiledPrefab, parts: Uint32Array, count: number): void {
    for (let l = 0; l < p.links.length; l++) {
      const run = p.links[l]!;
      if (this.linkRows.length < run.source.length) this.linkRows = new Uint32Array(run.source.length * 2); // alloc-ok: grows once to the most links
      const rows = this.linkRows;
      for (let j = 0; j < run.source.length; j++) {
        rows[j] = run.source[j]! >= count || run.target[j]! >= count ? 0 : this.pair(parts[run.source[j]!]! as Entity, run.relation, parts[run.target[j]!]! as Entity);
      }
      const fields = run.relation.fields;
      const store = this.tables[run.relation.id]!.store as Record<string, number[]>;
      for (let w = 0; w < run.writes.length; w++) {
        const write = run.writes[w]!;
        const column = store[fields[write.field]!.name]!;
        for (let k = 0; k < write.link.length; k++) {
          const row = rows[write.link[k]!]!;
          if (row !== 0) column[row] = write.value[k]!;
        }
      }
      for (let j = 0; j < run.source.length; j++) if (rows[j] !== 0) this.apply(RELATE, rows[j]!, run.relation.id, 0);
    }
  }

  /** A component's row at its defaults; an object component's object from its pool. */
  private defaults(e: number, component: AnyComponent): void {
    if (component.kind === 'data') {
      const columns = this.columns[component.id]!;
      const initials = this.initials[component.id]!;
      for (let i = 0; i < columns.length; i++) (columns[i] as number[])[e] = initials[i]!;
      if (component === Transform) this.defaults(e, WorldTransform);
    } else if (component.kind === 'object') {
      let value: unknown = null;
      if (component.create) {
        const pool = this.pools[component.id]!;
        if (pool.length > 0) value = pool.pop();
        else {
          value = component.create();
          this.stats.poolMisses++;
        }
      }
      (this.stores[component.id] as { value: unknown[] }).value[e] = value;
    }
  }

  /** An object component's object back to its pool, its slot emptied. */
  private release(e: number, component: AnyComponent): void {
    if (component.kind !== 'object') return;
    const store = this.stores[component.id] as { value: unknown[] };
    const value = store.value[e];
    store.value[e] = null;
    if (!component.create || value === null || value === undefined) return;
    if (component.reset) component.reset(value);
    this.pools[component.id]!.push(value);
  }

  /** `component` onto a living entity. */
  private attach(e: number, component: AnyComponent): void {
    this.mask[e * this.words + (component.bit >>> 5)]! |= 1 << (component.bit & 31);
    this.touch(e);
    if (component === Transform) {
      this.transforms.byDepth.add(e, this.links.depth[e]!);
      this.shift(e);
    }
    const tracked = this.tracked[component.id];
    if (tracked) this.noteChange(tracked, e);
    if (component === Disabled || component === Hidden) this.settleActive(e);
    const hooks = this.addHooks[component.id];
    if (hooks) for (let i = 0; i < hooks.length; i++) hooks[i]!(e as Entity);
  }

  /** `component` off a living entity that has it. */
  private detach(e: number, component: AnyComponent): void {
    const hooks = this.removeHooks[component.id];
    if (hooks) {
      const value = component.kind === 'object' ? (this.stores[component.id] as { value: unknown[] }).value[e] : undefined;
      for (let i = 0; i < hooks.length; i++) hooks[i]!(e as Entity, value);
    }
    this.mask[e * this.words + (component.bit >>> 5)]! &= ~(1 << (component.bit & 31));
    this.touch(e);
    this.release(e, component);
    if (component === Transform) {
      this.transforms.byDepth.remove(e, this.links.depth[e]!);
      // Its children hung from it: they are placed afresh.
      this.shift(e);
    }
    if (component === Disabled || component === Hidden) this.settleActive(e);
  }

  /**
   * `e` and everything under it: out of play if it or an ancestor is
   * `Disabled`, out of sight if `Hidden`. Each that changes is placed afresh
   * and told to the `onActive` hooks.
   */
  private settleActive(e: number): void {
    const l = this.links;
    const inactive = this.inactive;
    let n = e;
    for (;;) {
      const p = l.parent[n]!;
      const above = p === 0 ? 0 : inactive[p]!;
      const now =
        ((above & OFF) !== 0 || this.extras.has(n as Entity, Disabled) ? OFF : 0) |
        ((above & UNSEEN) !== 0 || this.extras.has(n as Entity, Hidden) ? UNSEEN : 0);
      if (now !== inactive[n]) {
        inactive[n] = now;
        this.touch(n, true);
        for (let i = 0; i < this.activeHooks.length; i++) this.activeHooks[i]!(n as Entity, (now & OFF) === 0, (now & UNSEEN) === 0);
      }
      const child = l.firstChild[n]!;
      if (child !== 0) {
        n = child;
        continue;
      }
      while (n !== e && l.nextSibling[n] === 0) n = l.parent[n]!;
      if (n === e) return;
      n = l.nextSibling[n]!;
    }
  }

  /**
   * `e` changed components: its systems are looked at when the commands are
   * done. `full` for a change that is not in the mask -- play, a switch, the
   * layer -- which every system has to see.
   */
  private touch(e: number, full = false): void {
    if (full) this.flags[e]! |= FULL;
    if (this.flags[e]! & DIRTY) return;
    this.flags[e]! |= DIRTY;
    if (this.dirtyCount === this.dirty.length) this.dirty = grown(this.dirty);
    this.dirty[this.dirtyCount++] = e;
  }

  /** `e`'s world transform, and those under it, need working out at this boundary. */
  private shift(e: number): void {
    if (this.flags[e]! & MOVED) return;
    this.flags[e]! |= MOVED;
    if (this.movedCount === this.shifted.length) this.shifted = grown(this.shifted);
    this.shifted[this.movedCount++] = e;
  }

  /** `e` in or out of every system its change concerns; of every system, when `full`. */
  private sort(e: number, full: boolean): void {
    const words = this.words;
    if (full) {
      for (let w = 0; w < words; w++) this.seen[e * words + w] = this.mask[e * words + w]!;
      for (let s = 0; s < this.systems.length; s++) this.place(this.systems[s]!, e);
      return;
    }
    const stamp = this.stamp;
    const no = ++this.stampNo;
    for (let w = 0; w < words; w++) {
      const now = this.mask[e * words + w]!;
      let diff = now ^ this.seen[e * words + w]!;
      this.seen[e * words + w] = now;
      while (diff !== 0) {
        const lowest = diff & -diff;
        diff ^= lowest;
        const systems = this.interested[w * 32 + (31 - Math.clz32(lowest))]!;
        for (let i = 0; i < systems.length; i++) {
          const s = systems[i]!;
          if (stamp[s] === no) continue;
          stamp[s] = no;
          this.place(this.systems[s]!, e);
        }
      }
    }
  }

  private isMember(sys: Sys, e: number): boolean {
    return sys.own ? sys.own.has(e) : this.loop.isMemberAt(sys.handle, e);
  }

  /** `e` into `sys` if it matches and is not in, out if it is in and does not. */
  private place(sys: Sys, e: number): void {
    if (!sys.selective) return;
    const words = this.words;
    // Switched off, or on the wrong layer: in no system but one that asked. Parked: in none at all, not even those.
    let matches = (this.flags[e]! & PARKED) === 0 && (sys.includeDisabled || (this.inactive[e]! & OFF) === 0) && (sys.layers & (1 << this.layerOf[e]!)) !== 0;
    // With an `any` list, one of its bits has to turn up in some word.
    let one = sys.some === null;
    for (let w = 0; matches && w < words; w++) {
      // A component switched off is, for this, not had.
      const have = this.mask[e * words + w]! & ~this.off[e * words + w]!;
      // `>>> 0`: a word with its top bit set is a negative number, its Uint32Array copy is not (ecs/high-bit.test.ts).
      if (((have & sys.need[w]!) >>> 0) !== sys.need[w] || (have & sys.not[w]!) !== 0) {
        matches = false;
        break;
      }
      if (!one && (have & sys.some![w]!) !== 0) one = true;
    }
    if (!one) matches = false;
    if (matches === this.isMember(sys, e)) return;
    if (sys.own) {
      if (matches) sys.own.add(e, 0);
      else sys.own.remove(e, 0);
    } else if (matches) this.loop.joinAt(sys.handle, e);
    else this.loop.leaveAt(sys.handle, e);
  }

  // ── the tree ────────────────────────────────────────────────────────────

  private unlink(e: number): void {
    const l = this.links;
    const p = l.parent[e]!;
    if (p === 0) return this.unlinkRoot(e);
    const prev = l.prevSibling[e]!;
    const next = l.nextSibling[e]!;
    if (prev !== 0) l.nextSibling[prev] = next as Entity;
    else l.firstChild[p] = next as Entity;
    if (next !== 0) l.prevSibling[next] = prev as Entity;
    else l.lastChild[p] = prev as Entity;
    l.parent[e] = l.prevSibling[e] = l.nextSibling[e] = 0 as Entity;
  }

  /** Is `e` in the roots' chain: a living root, not parked? */
  private isRoot(e: number): boolean {
    const l = this.links;
    return l.parent[e] === 0 && (l.prevSibling[e] !== 0 || l.nextSibling[e] !== 0 || this.headRoot === e);
  }

  /** `e`, a root in no chain, into the roots' order: in front of `before` (a root in it), else last. */
  private linkRoot(e: number, before = 0): void {
    const l = this.links;
    if (before !== 0) {
      const prev = l.prevSibling[before]!;
      l.prevSibling[e] = prev;
      l.nextSibling[e] = before as Entity;
      l.prevSibling[before] = e as Entity;
      if (prev !== 0) l.nextSibling[prev] = e as Entity;
      else this.headRoot = e;
      return;
    }
    const last = this.tailRoot;
    l.prevSibling[e] = last as Entity;
    l.nextSibling[e] = 0 as Entity;
    if (last !== 0) l.nextSibling[last] = e as Entity;
    else this.headRoot = e;
    this.tailRoot = e;
  }

  /** `e` out of the roots' order, if it is in it. */
  private unlinkRoot(e: number): void {
    if (!this.isRoot(e)) return;
    const l = this.links;
    const prev = l.prevSibling[e]!;
    const next = l.nextSibling[e]!;
    if (prev !== 0) l.nextSibling[prev] = next;
    else this.headRoot = next;
    if (next !== 0) l.prevSibling[next] = prev;
    else this.tailRoot = prev;
    l.prevSibling[e] = l.nextSibling[e] = 0 as Entity;
  }

  /** The greatest depth in `e`'s subtree, `e` included: pre-order through the links. */
  private deepestUnder(e: number): number {
    const l = this.links;
    let deepest = l.depth[e]!;
    let n = e;
    for (;;) {
      const child = l.firstChild[n]!;
      if (child !== 0) {
        n = child;
        if (l.depth[n]! > deepest) deepest = l.depth[n]!;
        continue;
      }
      while (n !== e && l.nextSibling[n] === 0) n = l.parent[n]!;
      if (n === e) return deepest;
      n = l.nextSibling[n]!;
      if (l.depth[n]! > deepest) deepest = l.depth[n]!;
    }
  }

  /**
   * `e` under `p`: last of its children, or in front of `before` if that is one
   * of them -- other than `e`. Under no one, a root: last of the roots, or in
   * front of `before` among them; a parked one in no order.
   */
  private reparent(e: number, p: number, before = 0): void {
    const l = this.links;
    const parked = (this.flags[e]! & PARKED) !== 0;
    if (l.parent[e] === 0 && p === 0 && before === e) return;
    if (before !== 0 && (before === e || l.parent[before] !== p || (p === 0 && !this.isRoot(before)))) before = 0;
    if (l.parent[e] === 0 && p === 0) {
      // A root moved among the roots -- or a parked one, which has no place: nothing under it changes.
      if (parked || (before === 0 ? this.tailRoot === e : l.nextSibling[e] === before)) return;
      this.unlinkRoot(e);
      this.linkRoot(e, before);
      return;
    }
    // Where it is already: under `p`, and last or in front of `before`.
    if (l.parent[e] === p && (before === 0 || l.nextSibling[e] === before)) return;
    // A cycle, or a tree too deep, is refused here, at the boundary: two systems may
    // each have set a parent that was fine alone. That command is dropped, with a warning.
    for (let a = p; a !== 0; a = l.parent[a]!) {
      if (a === e) {
        this.warnOnce('cycle', `[ecs] setParent(${e}, ${p}) dropped: it would make a cycle (${p} is ${e} itself or under it)`);
        return;
      }
    }
    const deepest = this.deepestUnder(e) - l.depth[e]! + (p === 0 ? 0 : l.depth[p]! + 1);
    if (deepest > MAX_DEPTH) {
      this.warnOnce('depth', `[ecs] setParent(${e}, ${p}) dropped: it would put an entity ${deepest} deep, and the tree is at most ${MAX_DEPTH} deep`);
      return;
    }
    this.unlink(e);
    if (p === 0) {
      if (!parked) this.linkRoot(e, before);
    } else if (before !== 0) {
      // Read after the unlink: `e` may have been the one in front of it.
      const prev = l.prevSibling[before]!;
      l.parent[e] = p as Entity;
      l.prevSibling[e] = prev;
      l.nextSibling[e] = before as Entity;
      l.prevSibling[before] = e as Entity;
      if (prev !== 0) l.nextSibling[prev] = e as Entity;
      else l.firstChild[p] = e as Entity;
    } else {
      const last = l.lastChild[p]!;
      l.parent[e] = p as Entity;
      l.prevSibling[e] = last;
      if (last !== 0) l.nextSibling[last] = e as Entity;
      else l.firstChild[p] = e as Entity;
      l.lastChild[p] = e as Entity;
    }
    // New depths for everything under it, pre-order through the links.
    let n = e;
    for (;;) {
      const up = l.parent[n]!;
      const depth = up === 0 ? 0 : l.depth[up]! + 1;
      if (depth !== l.depth[n]) {
        if (this.transforms.has(n)) {
          this.transforms.byDepth.remove(n, l.depth[n]!);
          this.transforms.byDepth.add(n, depth);
        }
        l.depth[n] = depth;
      }
      const child = l.firstChild[n]!;
      if (child !== 0) {
        n = child;
        continue;
      }
      while (n !== e && l.nextSibling[n] === 0) n = l.parent[n]!;
      if (n === e) break;
      n = l.nextSibling[n]!;
    }
    this.shift(e);
    // Under a new parent, what it inherits may differ.
    this.settleActive(e);
  }

  /**
   * `e` and everything under it: components off, out of the tree, on the dead
   * list. Children first. A pooled prefab's instance under it goes back to its
   * pool, as a destroy of its root would send it -- unless `real` (a drain, a
   * load): game code is the same pooled or not.
   */
  private kill(e: number, real = false): void {
    const l = this.links;
    if (this.pooling && !real) this.giveBackUnder(e);
    this.unlink(e);
    this.killing = e;
    let n = e;
    for (;;) {
      while (l.firstChild[n] !== 0) n = l.firstChild[n]!;
      for (;;) {
        const up = l.parent[n]!;
        const next = l.nextSibling[n]!;
        this.bury(n);
        if (n === e) return;
        if (next !== 0) {
          n = next;
          break;
        }
        // The last of its siblings: their parent has no children left, and is next.
        l.firstChild[up] = 0 as Entity;
        n = up;
      }
    }
  }

  /** One entity's end: every component off it, its links cleared, its index on the dead list. */
  private bury(e: number): void {
    if (this.instanceStore.prefab[e] !== 0) this.leaveInstance(e);
    if ((this.flags[e]! & PARKED) !== 0) {
      this.flags[e]! &= ~PARKED;
      this.stats.parked--;
    }
    // A link dies with either end.
    const tables = this.tableList;
    for (let i = 0; i < tables.length; i++) tables[i]!.drop(e);
    const words = this.words;
    for (let w = 0; w < words; w++) {
      let have = this.mask[e * words + w]!;
      while (have !== 0) {
        const lowest = have & -have;
        have ^= lowest;
        const bit = w * 32 + (31 - Math.clz32(lowest));
        // The components on this bit: one, but for Transform and the WorldTransform that shares its bit.
        for (let id = 0; id < this.components.length; id++) {
          const component = this.components[id]!;
          if (component.bit === bit && component !== WorldTransform) this.detach(e, component);
        }
      }
    }
    const l = this.links;
    l.parent[e] = l.firstChild[e] = l.lastChild[e] = l.nextSibling[e] = l.prevSibling[e] = 0 as Entity;
    l.depth[e] = 0;
    for (let w = 0; w < words; w++) this.off[e * words + w] = 0;
    this.inactive[e] = 0;
    this.layerOf[e] = 0;
    this.touch(e);
    this.state[e] = DEAD;
    const counts = this.kindCount[this.kindOf[e]!]!;
    const p = e % CYCLE;
    const left = --counts[p]!;
    if (left < this.kindLow[this.kindOf[e]!]!) this.kindLow[this.kindOf[e]!] = left;
    this.stats.entities--;
    if (this.deadCount === this.dead.length) this.dead = grown(this.dead);
    this.dead[this.deadCount++] = e;
  }

  /**
   * An entity of an instance dying (Docs/prefabs.md §9, the runtime): out of its instance's
   * chain, its `Instance` row cleared, so `part()` never finds the dead -- or,
   * once the index is reused, another instance's entity.
   *
   * - **A part dying alone** (a barrel shot off, Delete on a rider): its
   *   predecessor takes its `next`. A walk from the root, a handful of nodes.
   * - **The root**: the whole chain is cleared at once, every row of it. A part
   *   reparented out of the instance outlives it as a plain entity.
   * - **A part whose root dies in the same `kill`** is left to the root's turn,
   *   which clears the chain whole: no walk per part when a whole instance goes.
   *   Children are buried first, so that root is still alive here.
   */
  private leaveInstance(e: number): void {
    const inst = this.instanceStore;
    const root = inst.root[e]!;
    if (root === e) {
      // A pooled prefab's instance gone for real while out: one fewer out. A parked one's drain counts its own.
      if ((this.flags[e]! & PARKED) === 0) {
        const pool = this.prefabPools[inst.prefab[e]!];
        if (pool && --pool.out === 0) pool.warned = false;
      }
      for (let x = e; x !== 0; ) {
        const next = inst.next[x]!;
        inst.prefab[x] = inst.node[x] = inst.root[x] = inst.next[x] = 0;
        x = next;
      }
      return;
    }
    if (this.state[root] === ALIVE && inst.root[root] === root) {
      // The root under what is being killed: it goes too, and clears this row with the rest.
      const l = this.links;
      for (let x = root; x !== 0; x = l.parent[x]!) if (x === this.killing) return;
      for (let x = root; x !== 0; x = inst.next[x]!) {
        if (inst.next[x] !== e) continue;
        inst.next[x] = inst.next[e]!;
        break;
      }
    }
    inst.prefab[e] = inst.node[e] = inst.root[e] = inst.next[e] = 0;
  }

  // ── pools (Docs/prefabs.md §5) ──────────────────────────────────────────

  /** `prefab`'s pool in this world: its numbers, `drain()` and `trim(n)`. Throws for a prefab with no pool. */
  pool(prefab: PrefabToken): Pool {
    const p = compiledPrefabs()[prefab.id];
    if (!p) throw new Error(`[ecs] world.pool(${prefab.made}): prefabs are not compiled yet (Prefabs.compile() runs before the world is made)`);
    if (!p.pool) throw new Error(`[ecs] world.pool(${prefab.made}): ${p.key} has no pool -- give its file "pool": { "warm": n, "max": n }, or call pool(${prefab.made}, { warm, max }) at module level`);
    return this.poolOf(p);
  }

  /**
   * Each pooled prefab's `warm` instances made and parked (Docs/prefabs.md
   * §5), in no system at any time: once the world exists and the hooks that
   * dress an instance are installed (`installRender`), so each is parked
   * with its models on. `Game` calls it after building the game, and `load`
   * after loading. A pool with `warm` parked already is left as it is; none
   * goes past `max`. Outside a tick: the boundary runs now.
   */
  warmPools(): void {
    this.outside('warmPools');
    for (const p of compiledPrefabs()) {
      if (!p?.pool) continue;
      const pool = this.poolOf(p);
      for (let have = pool.parked + pool.resting; have < p.pool.warm && have + pool.out < p.pool.max; have++) {
        const root = this.make(p);
        if (root === 0) break;
        this.commands.park(root, p.id, !this.instanceRefused);
        if (this.instanceRefused) break;
      }
    }
    this.boundary(true);
    this.loop.applyPending();
  }

  /**
   * A component no prefab file lists that a hook gives an instance -- the
   * `View` the `render` system attaches (`installRender`) -- kept on an instance given back
   * while `keep(e)` says it is still the hook's own (its data, if numeric, at
   * its defaults). Anything else an instance picked up while out is removed
   * when it is reset, through its hooks, and then the `onInstance` hooks are
   * asked again for what is missing: a view swapped at runtime goes, and the
   * prefab's own is back.
   */
  keepParked(component: AnyComponent, keep: (e: Entity) => boolean): void {
    this.known(component, '[ecs] keepParked');
    this.keepers[component.id] = keep;
  }

  /**
   * The pools of every prefab with an entity drawing a model `match` takes,
   * drained: `Assets.unmount` frees a pack's models, so nothing parked may hold
   * one (`Game`, `game.ts`, wires it). Outside a tick.
   */
  drainPools(match: (model: string) => boolean): void {
    if (this.ticking) throw new Error('[ecs] drainPools during a tick: a pack is unmounted between rounds, outside the loop\'s tick');
    const prefabs = compiledPrefabs();
    const drained = prefabs.map((p) => !!p?.pool && p.views.some((v) => v !== null && match(v)));
    if (!drained.includes(true)) return;
    // The instances out too: their models are about to be freed under them, so they go for real, not back.
    const inst = this.instanceStore;
    for (let e = 1; e < this.high; e++) {
      if (this.state[e] === ALIVE && (this.flags[e]! & PARKED) === 0 && inst.root[e] === e && drained[inst.prefab[e]!]) this.commands.letGo(e as Entity);
    }
    for (const p of prefabs) if (p && drained[p.id]) this.letGo(this.poolOf(p), 0);
  }

  /**
   * `pool.drain()` and `pool.trim(keep)`: all but `keep` of what is parked or
   * resting destroyed for real, now -- a give-back still in a buffer at the
   * call too, applied first and then let go with the rest, before any parked.
   */
  private letGo(pool: PoolRows, keep: number): void {
    if (this.ticking) throw new Error('[ecs] a pool drained or trimmed during a tick: do it between rounds, outside the loop\'s tick');
    this.boundary(true);
    this.loop.applyPending();
    // Resting (its `onLeave` delivered just now): let go instead of parked at the next boundary, so it is never reset to go.
    const inst = this.instanceStore;
    let kept = 0;
    for (let i = 0; i < this.backCount; i++) {
      const root = this.back[i]!;
      const ours = this.state[root] === ALIVE && inst.prefab[root] === pool.id;
      if (ours && pool.parked + pool.resting > keep) {
        pool.resting--;
        this.commands.letGo(root as Entity);
      } else this.back[kept++] = root;
    }
    this.backCount = kept;
    while (pool.parked > 0 && pool.parked + pool.resting > keep) this.commands.letGo(pool.pop() as Entity);
    this.boundary(true);
    this.loop.applyPending();
    pool.warned = false;
  }

  /** `p`'s pool here, made the first time it is asked for. */
  private poolOf(p: CompiledPrefab): PoolRows {
    return this.prefabPools[p.id] ?? this.newPool(p);
  }

  /** Apart from `poolOf`, which every take and give-back calls: a closure in it would cost a context each call. */
  private newPool(p: CompiledPrefab): PoolRows {
    const pool = new PoolRows(p.id, p.pool ? p.pool.max : 4, (which, keep) => this.letGo(which, keep));
    this.prefabPools[p.id] = pool;
    this.pooling = true;
    return pool;
  }

  /** A resting instance about to die for real: off the list of those to park, one fewer resting. */
  private unrest(root: number): void {
    if (!this.pooledRoot(root)) return;
    for (let i = 0; i < this.backCount; i++) {
      if (this.back[i] !== root) continue;
      this.back.copyWithin(i, i + 1, this.backCount--);
      this.poolOf(compiledPrefabs()[this.instanceStore.prefab[root]!]!).resting--;
      return;
    }
  }

  /** Is `e` the root of a pooled prefab's instance? */
  private pooledRoot(e: number): boolean {
    const inst = this.instanceStore;
    const id = inst.prefab[e]!;
    return id !== 0 && inst.root[e] === e && compiledPrefabs()[id]!.pool !== null;
  }

  /** Every entity of the instance `root` heads marked parked: not alive, in no system, its root out of the roots' order. */
  private flag(root: number): void {
    const inst = this.instanceStore;
    this.unlinkRoot(root);
    for (let x = root; x !== 0; x = inst.next[x]!) {
      this.flags[x]! |= PARKED;
      this.stats.parked++;
      this.touch(x, true);
    }
  }

  /** The pooled instances under `e`, outermost first, given back before `e` and the rest of what is under it die. */
  private giveBackUnder(e: number): void {
    const l = this.links;
    // A stack, shared with the calls below this one: each takes what it pushed off again.
    const base = this.underTop;
    let n = l.firstChild[e]!;
    while (n !== 0) {
      if (this.pooledRoot(n) && (this.flags[n]! & PARKED) === 0) {
        if (this.underTop === this.under.length) this.under = grown(this.under);
        this.under[this.underTop++] = n;
      } else if (l.firstChild[n] !== 0) {
        n = l.firstChild[n]!;
        continue;
      }
      while (n !== e && l.nextSibling[n] === 0) n = l.parent[n]!;
      if (n === e) break;
      n = l.nextSibling[n]!;
    }
    for (let i = base; i < this.underTop; i++) this.giveBack(this.under[i]!);
    this.underTop = base;
  }

  /**
   * `destroy` on a pooled instance's root (Docs/prefabs.md §5). What was put
   * under it since dies, as under anything destroyed (a pooled instance there
   * goes back to its own pool). It leaves the tree it was put in; every system
   * (`Disabled` on its root, every entity of it `PARKED`); its links; and every
   * ref to it -- **retired**: each entity a new generation, its index and rows
   * kept. Then it rests until the end of the next tick, when `onLeave` has read
   * it, to be reset and parked (`park`). An instance missing a part -- one
   * destroyed alone, or reparented out of it -- is destroyed for real instead:
   * its pool makes a new one when it next runs short.
   */
  private giveBack(root: number): void {
    const inst = this.instanceStore;
    const l = this.links;
    const p = compiledPrefabs()[inst.prefab[root]!]!;
    // Whole: every node there, each under the root through parts of its own.
    let n = 0;
    for (let x = root; x !== 0 && n >= 0; x = inst.next[x]!) {
      let up = x;
      while (up !== root && up !== 0 && inst.root[up] === root) up = l.parent[up]!;
      n = up === root ? n + 1 : -1;
    }
    const pool = this.poolOf(p);
    // Missing a part; or more alive than `max`, as a paste, a Duplicate or a load can leave (they never refuse): for real.
    if (n !== p.count || pool.parked + pool.resting + pool.out > p.pool!.max) {
      this.kill(root);
      return;
    }
    if (--pool.out === 0) pool.warned = false;
    pool.resting++;
    for (let x = root; x !== 0; x = inst.next[x]!) {
      for (let c = l.firstChild[x]!; c !== 0; ) {
        const next = l.nextSibling[c]!;
        if (inst.root[c] !== root) {
          if (this.pooledRoot(c) && (this.flags[c]! & PARKED) === 0) this.giveBack(c);
          else this.kill(c);
        }
        c = next;
      }
    }
    if (l.parent[root] !== 0) this.reparent(root, 0);
    if (!this.extras.has(root as Entity, Disabled)) this.attach(root, Disabled);
    this.flag(root);
    const tables = this.tableList;
    for (let x = root; x !== 0; x = inst.next[x]!) {
      for (let t = 0; t < tables.length; t++) tables[t]!.drop(x);
      this.gen[x] = (this.gen[x]! + 1) & GENERATION_MASK;
    }
    if (this.backCount === this.back.length) this.back = grown(this.back);
    this.back[this.backCount++] = root;
  }

  /**
   * An instance given back, put back exactly as a new one is made, and parked
   * (Docs/prefabs.md §5): the tree as its prefab has it, what it is made of and
   * what is switched off, its layer; every object component through the hooks
   * a removed one gets, then loaded from the prefab; every number from `full`;
   * the refs inside it `NONE`, as a warmed one's, written at the take; the
   * prefab's own links made again. Then at the back of its pool's queue. A component its prefab does not list goes,
   * unless its keeper keeps it (`keepParked`), and the `onInstance` hooks then
   * dress what is missing. `Disabled` stays on its root. At the start of the
   * boundary after a tick, so `onLeave` has read it first.
   */
  private park(root: number): void {
    const inst = this.instanceStore;
    const l = this.links;
    const p = compiledPrefabs()[inst.prefab[root]!]!;
    const pool = this.poolOf(p);
    pool.resting--;
    if (this.state[root] !== ALIVE) return;
    const count = p.count;
    if (this.parts.length < count) this.parts = new Uint32Array(count * 2); // alloc-ok: grows once to the largest prefab
    const parts = this.parts;
    let n = 0;
    for (let x = root; x !== 0 && n < count; x = inst.next[x]!) parts[n++] = x;
    // Made from a compile before a live one (the dev server, Docs/prefabs.md §7) that changed its nodes: let go
    // whole, as one missing a part is, and the pool makes a new one when it runs short.
    let same = n === count;
    for (let j = 0; same && j < count; j++) same = this.kindOf[parts[j]!] === p.kinds[j]!.id;
    if (!same) {
      // Nothing takes a part of a parked instance; should something have, it is let go whole.
      this.kill(root, true);
      return;
    }
    const words = this.words;
    const masks = this.masksOf(p);
    const tables = this.tableList;
    // Links made to or from it while it rested; the prefab's own are made again below.
    for (let j = 0; j < count; j++) for (let t = 0; t < tables.length; t++) tables[t]!.drop(parts[j]!);
    // The tree: the root on top, nothing under it but its own, each part under its node's parent in node order.
    if (l.parent[root] !== 0) this.reparent(root, 0);
    for (let j = 0; j < count; j++) {
      for (let c = l.firstChild[parts[j]!]!; c !== 0; ) {
        const next = l.nextSibling[c]!;
        if (inst.root[c] !== root) this.kill(c, true);
        c = next;
      }
    }
    if (!this.inOrder(p, parts)) {
      for (let j = 1; j < count; j++) this.unlink(parts[j]!);
      for (let j = 1; j < count; j++) this.reparent(parts[j]!, parts[p.parents[j]!]!);
    }
    // What each entity is made of, and what is switched off on it, as its node's; its layer.
    const disabledWord = Disabled.bit >>> 5;
    const disabledBit = 1 << (Disabled.bit & 31);
    for (let j = 0; j < count; j++) {
      const x = parts[j]!;
      for (let w = 0; w < words; w++) {
        const at = x * words + w;
        const want = masks.kinds[j * words + w]! | (j === 0 && w === disabledWord ? disabledBit : 0);
        for (let extra = this.mask[at]! & ~want; extra !== 0; ) {
          const lowest = extra & -extra;
          extra ^= lowest;
          const c = this.onBit[w * 32 + (31 - Math.clz32(lowest))];
          if (!c || c.kind === 'relation') continue;
          const keep = this.keepers[c.id];
          if (!keep || !keep(x as Entity)) this.detach(x, c);
          else if (c.kind === 'data') this.defaults(x, c);
        }
        for (let missing = want & ~this.mask[at]!; missing !== 0; ) {
          const lowest = missing & -missing;
          missing ^= lowest;
          const c = this.onBit[w * 32 + (31 - Math.clz32(lowest))]!;
          this.defaults(x, c);
          this.attach(x, c);
        }
        const off = masks.off[j * words + w]!;
        if (this.off[at] === off) continue;
        // Told only of the components it has now: one removed just above went with its bit, and no toggle.
        let flipped = (this.off[at]! ^ off) & this.mask[at]!;
        this.off[at] = off;
        this.touch(x, true);
        while (flipped !== 0) {
          const lowest = flipped & -flipped;
          flipped ^= lowest;
          const c = this.onBit[w * 32 + (31 - Math.clz32(lowest))];
          const hook = c ? this.toggleHooks[c.id] : null;
          if (hook) hook(x as Entity, (off & lowest) === 0);
        }
      }
      if (this.layerOf[x] !== p.layers[j]) {
        this.layerOf[x] = p.layers[j]!;
        this.touch(x, true);
        for (let h = 0; h < this.layerHooks.length; h++) this.layerHooks[h]!(x as Entity, p.layers[j]!);
      }
    }
    // Object components: each back to the prefab's own data, through the hooks a removed and an added one get.
    for (let j = 0; j < count; j++) {
      const x = parts[j]!;
      const list = p.kinds[j]!.components;
      for (let i = 0; i < list.length; i++) {
        const c = list[i]!;
        if (c.kind !== 'object') continue;
        const hooks = this.removeHooks[c.id];
        if (hooks) for (let h = 0; h < hooks.length; h++) hooks[h]!(x as Entity, (this.stores[c.id] as { value: unknown[] }).value[x]);
        this.release(x, c);
        this.defaults(x, c);
      }
    }
    this.loadObjects(p, parts);
    for (let j = 0; j < count; j++) {
      const list = p.kinds[j]!.components;
      for (let i = 0; i < list.length; i++) {
        const hooks = list[i]!.kind === 'object' ? this.addHooks[list[i]!.id] : null;
        if (hooks) for (let h = 0; h < hooks.length; h++) hooks[h]!(parts[j]! as Entity);
      }
    }
    // Every number as the prefab makes it, defaults included; the refs inside it `NONE`, as a warmed one's, until the take.
    const full = p.full;
    for (let w = 0; w < full.length; w++) {
      const run = full[w]!;
      const column = this.columns[run.component]![run.field] as number[];
      for (let j = 0; j < run.node.length; j++) column[parts[run.node[j]!]!] = run.value[j]!;
    }
    this.ownRefs(p, root);
    for (let j = 0; j < count; j++) if (this.extras.has(parts[j]! as Entity, Transform)) this.defaults(parts[j]!, WorldTransform);
    this.shift(root);
    this.makeLinks(p, parts, count);
    this.settleActive(root);
    // What a hook dresses an instance in, back where it was let go: a view swapped while it was out.
    for (let h = 0; h < this.instanceHooks.length; h++) this.instanceHooks[h]!(root as Entity, p, false);
    pool.push(root);
  }

  /** Is the tree under `parts[0]` its prefab's, node for node and in order? */
  private inOrder(p: CompiledPrefab, parts: Uint32Array): boolean {
    const l = this.links;
    const count = p.count;
    if (this.lastPart.length < count) this.lastPart = new Uint32Array(count * 2); // alloc-ok: grows once to the largest prefab
    const last = this.lastPart;
    last.fill(0, 0, count);
    for (let j = 1; j < count; j++) {
      const x = parts[j]!;
      const up = p.parents[j]!;
      if (l.parent[x] !== parts[up] || l.prevSibling[x] !== last[up]) return false;
      last[up] = x;
    }
    for (let j = 0; j < count; j++) if (l.lastChild[parts[j]!] !== last[j]) return false;
    return true;
  }

  /** Each node's kind and its switched-off components as masks, `words` a node: made once a compiled prefab. */
  private masksOf(p: CompiledPrefab): { kinds: Uint32Array; off: Uint32Array } {
    const had = this.prefabMasks[p.id];
    return had && had.of === p ? had : this.newMasks(p);
  }

  /** Apart from `masksOf`, which every reset calls, as `newPool` is. */
  private newMasks(p: CompiledPrefab): { kinds: Uint32Array; off: Uint32Array } {
    const words = this.words;
    const made = { of: p, kinds: new Uint32Array(p.count * words), off: new Uint32Array(p.count * words) };
    p.kinds.forEach((k, j) => {
      for (const c of k.components) if (c.bit >= 0) made.kinds[j * words + (c.bit >>> 5)]! |= 1 << (c.bit & 31);
    });
    for (const o of p.off) {
      const c = this.components[o.component]!;
      made.off[o.node * words + (c.bit >>> 5)]! |= 1 << (c.bit & 31);
    }
    this.prefabMasks[p.id] = made;
    return made;
  }

  // ── storage ─────────────────────────────────────────────────────────────

  private newKind(k: number): Int32Array {
    while (this.kindCount.length <= k) {
      this.kindCount.push(new Int32Array(CYCLE));
      // Each kind starts its round somewhere else, so one-of-a-kind entities do not all share a phase.
      this.kindCursor.push((1 + this.kindCursor.length * 37) % CYCLE);
      this.kindLow.push(0);
    }
    return this.kindCount[k]!;
  }

  /** Each numeric component's columns, in field order: again after every growth, which replaces them. */
  private pointColumns(): void {
    for (const component of this.components) {
      if (component.kind !== 'data') continue;
      const store = this.stores[component.id] as Record<string, ArrayLike<number>>;
      const columns = this.columns[component.id]!;
      columns.length = 0;
      for (const field of component.fields) columns.push(store[field.name]!);
    }
  }

  /** Twice the room, at a boundary: no system holds a column now. */
  private grow(): void {
    const rows = Math.min(this.alloc.maxRows, this.alloc.rows * 2);
    this.alloc.grow(rows, this.high);
    this.pointColumns();
    for (const component of this.components) {
      if (component.kind !== 'object') continue;
      const value = (this.stores[component.id] as { value: unknown[] }).value;
      while (value.length < rows) value.push(null);
    }
    this.stats.capacity = rows;
    this.stats.growths = this.alloc.growths;
    this.warnedFull = false;
  }

  private known(component: AnyComponent, where: string): void {
    if (this.components[component.id] !== component) throw new Error(`${where}: component ${component.name} is not this world's: defined after it was made, or defined again by a generation since -- the old token is the old world's. Define every component at module level, before new World()`);
  }

  private warnOnce(key: string, message: string): void {
    if (this.warned.has(key)) return;
    this.warned.add(key);
    console.warn(message);
  }

  private outside(what: string): void {
    if (this.ticking) throw new Error(`[ecs] world.${what}() during a tick: ${OUTSIDE_HINT[what] ?? 'do it between ticks, outside the loop'}`);
  }

  // ── describe ────────────────────────────────────────────────────────────

  /**
   * The whole machine as text: every component with its fields, every kind, every
   * system with its rate, level, data and member count, and the pairs of systems
   * that share written data. For a person at the console, or a model reading
   * the game's structure in one call.
   */
  describe(): string {
    const lines: string[] = [];
    const s = this.stats;
    // Alive is what a game and its tools see: a parked entity is counted apart, everywhere below too.
    lines.push(`world: ${s.entities - s.parked} entities alive${s.parked > 0 ? `, and ${s.parked} parked in pools` : ''}, room for ${s.capacity} (max ${this.alloc.maxRows}), ${(this.bytes / 1024 / 1024).toFixed(1)} MB of columns${this.alloc.shared ? ', shared' : ''}`);
    lines.push(`       grew ${s.growths}x, pool misses ${s.poolMisses}, command buffer growths ${s.commandGrowths}, spawns refused ${s.refused}`);
    const prefabs = compiledPrefabs();
    if (prefabs.length > 1) {
      const alive = new Array<number>(prefabs.length).fill(0);
      const inst = this.instanceStore;
      for (let e = 1; e < this.high; e++) if (this.alive(e as Entity) && inst.prefab[e] !== 0 && inst.root[e] === e) alive[inst.prefab[e]!]!++;
      lines.push('', 'prefabs:');
      for (const p of prefabs) {
        if (!p) continue;
        // A prefab whose file went (a live recompile, Docs/prefabs.md §7): listed only while instances of it are out.
        if (alive[p.id] === 0 && compiledPrefab(p.key) !== p) continue;
        const pool = this.prefabPools[p.id];
        const resting = pool && pool.resting > 0 ? `, ${pool.resting} given back and resting` : '';
        const pooled = p.pool ? `; pool: ${pool?.parked ?? 0} parked${resting}, ${pool?.out ?? 0} out, at most ${pool?.mostOut ?? 0} out (warm ${p.pool.warm}, max ${p.pool.max})` : '';
        lines.push(`  ${p.key}: ${p.count} ${p.count === 1 ? 'entity' : 'entities'}${p.names.some((n) => n) ? ` (${p.names.filter((n) => n).join(', ')})` : ''}, ${alive[p.id]} alive${pooled}`);
      }
    }
    lines.push('', 'components:');
    for (const component of this.components) {
      // Where the inspector's Add Component menu lists it, when it says (`{ menu }`): `· Physics/Colliders`.
      const menu = component.menu ? ` · ${component.menu}` : '';
      if (component.kind === 'data') lines.push(`  ${component.name} { ${component.fields.map((f) => `${f.name}: ${f.type}${f.initial ? ` = ${f.initial}` : ''}`).join(', ')} }${menu}`);
      else if (component.kind === 'tag') lines.push(`  ${component.name} (tag)`);
      else if (component.kind === 'relation') {
        const data = component.fields.length ? ` { ${component.fields.map((f) => `${f.name}: ${f.type}`).join(', ')} }` : '';
        lines.push(`  ${component.name} (relation${component.exclusive ? ', exclusive' : ''}, ${this.tables[component.id]!.live} links)${data}`);
      }
      else lines.push(`  ${component.name} (object${component.create ? `, ${this.pools[component.id]!.length} pooled` : ''})${menu}`);
    }
    lines.push('', 'kinds:');
    const parkedOf: number[] = [];
    if (s.parked > 0) for (let e = 1; e < this.high; e++) if (this.state[e] === ALIVE && (this.flags[e]! & PARKED) !== 0) parkedOf[this.kindOf[e]!] = (parkedOf[this.kindOf[e]!] ?? 0) + 1;
    const kinds = allKinds();
    // Kinds prefabs made: those of a prefab compiled now, and of any ever (a deleted one's stay, as kinds do).
    const ever = new Set<string>();
    const now = new Set<string>();
    for (const p of prefabs) {
      if (!p) continue;
      for (const k of p.kinds) {
        ever.add(k.name);
        if (compiledPrefab(p.key) === p) now.add(k.name);
      }
    }
    // An entity of a prefab's kind that is no instance: unpacked (Docs/prefabs.md §7), its kind kept, its prefab's count not.
    const unpacked: number[] = [];
    for (let e = 1; e < this.high; e++) {
      if (this.alive(e as Entity) && this.instanceStore.prefab[e] === 0 && ever.has(kinds[this.kindOf[e]!]?.name ?? '')) unpacked[this.kindOf[e]!] = (unpacked[this.kindOf[e]!] ?? 0) + 1;
    }
    for (const kind of kinds) {
      const counts = this.kindCount[kind.id];
      const parked = parkedOf[kind.id] ?? 0;
      const living = (counts ? counts.reduce((a, b) => a + b, 0) : 0) - parked;
      // One a live recompile has made again (`kindAgain`), once nothing is of it: the newer is the kind.
      if (living + parked === 0 && kinds.some((k) => k.id > kind.id && k.name === kind.name)) continue;
      // One of a prefab deleted or no longer having that entity, once nothing is of it: no kind a game has.
      if (living + parked === 0 && ever.has(kind.name) && !now.has(kind.name)) continue;
      const plain = unpacked[kind.id] ?? 0;
      const note = plain > 0 ? ` (${plain === living ? (plain === 1 ? 'it' : 'all') : plain} unpacked: no instance, so not counted as its prefab's)` : '';
      lines.push(`  ${kind.name} [${kind.components.map((t) => t.name).join(', ')}]: ${living} alive${note}${parked > 0 ? `, ${parked} parked` : ''}`);
    }
    if (this.channelList.length > 0) {
      lines.push('', 'events:');
      for (const { type, channel } of this.channelList) lines.push(`  ${type.name} { ${type.fields.map((f) => `${f.name}: ${f.type}`).join(', ')} }: ${(channel.end as number) - 1} in the last second`);
    }
    if (this.trackedList.length > 0) lines.push('', `watched for changes: ${this.trackedList.map((t) => t.component.name).join(', ')}`);
    lines.push('', 'systems, in the order they run:');
    for (const info of this.systemInfo()) {
      const head = info.phase === 'simulation' ? `${info.rate} Hz${info.stagger ? '' : ' unstaggered'}, ${info.stages}` : info.phase;
      const data = info.ecs ? [info.reads.length ? `reads ${info.reads.join(', ')}` : '', info.writes.length ? `writes ${info.writes.join(', ')}` : ''].filter(Boolean).join('; ') : 'not an ECS system';
      lines.push(`  ${info.name} (${head}, level ${info.level}): ${info.members} members${data ? `; ${data}` : ''}`);
    }
    const conflicts = this.conflicts();
    if (conflicts.length > 0) {
      lines.push('', 'systems of one level that share written data (they run in registration order):');
      for (const [a, b, component] of conflicts) lines.push(`  ${a} then ${b}: ${component}`);
    }
    return lines.join('\n');
  }
}

/** Every layer: what a system takes when it names none. */
const ALL_LAYERS = -1;

/** A `layers` list as bits; every layer for none. */
function layerMask(list: readonly number[] | undefined, where: string): number {
  if (!list || list.length === 0) return ALL_LAYERS;
  let mask = 0;
  for (const layer of list) {
    if (!Number.isInteger(layer) || layer < 0 || layer > 31) throw new Error(`${where} lists layer ${layer}: a layer is a whole number from 0 to 31`);
    mask |= 1 << layer;
  }
  return mask;
}

function componentOf(access: Access): DataComponent {
  return 'optional' in access ? access.optional : access;
}

function grown(list: Uint32Array): Uint32Array {
  const next = new Uint32Array(list.length * 2);
  next.set(list);
  return next;
}

/**
 * `hook` added to `lists[id]`, after any there: a new list, so one being run goes on as it began.
 * Returns the undo, which takes that one hook off the same way.
 */
function listen<H>(lists: (readonly H[] | null)[], id: number, hook: H): () => void {
  const now = lists[id];
  lists[id] = now ? [...now, hook] : [hook];
  return () => {
    const list = lists[id];
    if (!list) return;
    const at = list.indexOf(hook);
    if (at < 0) return;
    lists[id] = list.length === 1 ? null : list.filter((_, i) => i !== at);
  };
}

/** `hook` taken off a list of hooks, in place: the first of it, if it is there. */
function unlisten<H>(list: H[], hook: H): void {
  const at = list.indexOf(hook);
  if (at >= 0) list.splice(at, 1);
}
