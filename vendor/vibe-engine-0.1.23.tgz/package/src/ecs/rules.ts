/**
 * The rules a system's source has to keep, checked by pattern (Docs/ecs.md
 * §11, §12): `vibe test` runs this over a project's `src/game/systems/` and
 * fails on a hit.
 *
 * Two kinds of rule:
 *
 *   anywhere in the file   chance and time from outside the loop
 *   inside world.system()  the forms that allocate, and loops that ignore `count`
 *
 * And one over every module of the game, systems or not (`checkModuleState`):
 * no world, store or channel kept at module level, since a swap rebuilds the
 * world in place (Docs/ecs.md §22).
 *
 * A tripwire, not a proof: it catches the usual ways, by pattern, and says what
 * to write instead. A line that must break a rule says why, on the line:
 * `// alloc-ok: <reason>`.
 *
 * Pure: text in, findings out. The pipeline's `checks/ecs.ts` runs it over a
 * project's `src/game/` for `vibe test` (Docs/squidwright-implementation.md 1.7).
 */

export interface Finding {
  /** 1-based. */
  line: number;
  rule: string;
  /** What to do instead. */
  fix: string;
  text: string;
}

interface Rule {
  rule: string;
  pattern: RegExp;
  fix: string;
}

/** Anywhere in a system's file: the simulation takes chance and time from the loop. */
const EVERYWHERE: Rule[] = [
  { rule: 'Math.random', pattern: /\bMath\.random\b/, fix: "use the system's seeded stream: ctx.rng.next(), .range(lo, hi), .chance(p), .int(lo, hi)" },
  { rule: 'Date.now', pattern: /\bDate\.now\b|\bnew Date\b/, fix: "use the system's time: ctx.time and ctx.dt" },
  { rule: 'performance.now', pattern: /\bperformance\.now\b/, fix: "use the system's time: ctx.time and ctx.dt" },
];

/** Inside `world.system({ ... })`: what runs every tick allocates nothing. */
const IN_SYSTEM: Rule[] = [
  { rule: 'new', pattern: /\bnew\s+[A-Za-z_$]/, fix: 'make it once at module level and reuse it' },
  { rule: 'closure', pattern: /=>|\bfunction\b/, fix: 'hoist the helper to module level: a closure made in a system is an allocation a call' },
  { rule: 'array method', pattern: /\.(map|filter|forEach|reduce|slice|concat|flat|flatMap|find|some|every|includes|indexOf|sort|push|splice)\(/, fix: 'loop by index over the members, and keep numbers in a component, not in an array' },
  { rule: 'spread', pattern: /\.\.\./, fix: 'pass the values themselves: spread and rest build an array' },
  // An empty one too (`const v = []`): a new array every call all the same.
  { rule: 'array literal', pattern: /(=|return|\(|,)\s*\[/, fix: 'no array literals in a system: keep the values in a component, or in an array made once at module level' },
  { rule: 'object literal', pattern: /(=|return|\()\s*\{\s*[A-Za-z_$][\w$]*\s*[:,}]/, fix: 'no object literals in a system: keep the values in a component' },
  { rule: 'template string', pattern: /`/, fix: 'no string building in a system: precompute the strings at module level' },
  { rule: 'for...of', pattern: /\bfor\s*\(\s*(const|let|var)\s+[^;]*\sof\s/, fix: 'the one loop shape: for (let n = 0; n < count; n++) { const e = members[n]; ... }' },
  { rule: 'members.length', pattern: /\bmembers\.length\b/, fix: 'the array is longer than what is due: loop to `count`' },
  { rule: 'prefab node', pattern: /\.node\(\s*['"`]/, fix: "take the node once at module level (const Muzzle = Turret.node('muzzle')) and pass it to cmd.part(root, Muzzle)" },
  { rule: 'Map or Set', pattern: /\bnew (Map|Set|WeakMap|WeakSet)\b/, fix: 'a tag for a set of entities, a component field for a value an entity: no Map, no Set' },
];

const WAIVER = /\/\/\s*alloc-ok:\s*\S/;

/** Code only: a line's `//` comment and the text of its strings blanked, so prose and quoted text trip nothing. */
function code(line: string): string {
  return line
    .replace(/'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"/g, "''")
    .replace(/\/\/.*$/, '')
    .replace(/^\s*\*.*$/, '');
}

/**
 * The lines inside each `world.system(` call's parentheses, the parameter
 * lists of its own methods excepted (their `[vel]` and `{ members }` are
 * destructuring, not literals).
 */
function systemLines(lines: string[]): Set<number> {
  const inside = new Set<number>();
  let depth = 0;
  let open = false;
  for (let i = 0; i < lines.length; i++) {
    const text = code(lines[i]!);
    if (!open && /\.system\s*\(/.test(text)) {
      open = true;
      depth = 0;
    }
    if (!open) continue;
    inside.add(i);
    for (const ch of text) {
      if (ch === '(' || ch === '{' || ch === '[') depth++;
      else if (ch === ')' || ch === '}' || ch === ']') depth--;
    }
    if (depth <= 0) open = false;
  }
  return inside;
}

/** A method's opening line: `update({ members }, [vel], [pos]) {`, `onJoin: (ctx) => {`. Its parameters are not checked. */
const METHOD = /^\s*(async\s+)?(onJoin|update|lateUpdate)\s*(\(|:)/;

/** Everything in `source` that breaks a rule. */
export function checkSystemSource(source: string): Finding[] {
  const lines = source.split('\n');
  const inside = systemLines(lines);
  const findings: Finding[] = [];
  let block = false;
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i]!;
    // Block comments say what they like.
    if (/^\s*\/\*/.test(raw)) block = true;
    const commented = block;
    if (/\*\//.test(raw)) block = false;
    if (commented || WAIVER.test(raw)) continue;
    const text = code(raw);
    for (const { rule, pattern, fix } of EVERYWHERE) if (pattern.test(text)) findings.push({ line: i + 1, rule, fix, text: raw.trim() });
    if (!inside.has(i)) continue;
    // A method's own line: only what follows its parameter list is a body.
    const body = METHOD.test(text) ? text.slice(text.lastIndexOf(')') + 1).replace(/^\s*=>/, '') : text;
    for (const { rule, pattern, fix } of IN_SYSTEM) if (pattern.test(body)) findings.push({ line: i + 1, rule, fix, text: raw.trim() });
  }
  return findings;
}

/**
 * A module variable holding what a swap makes stale (Docs/ecs.md §22): a
 * change under `src/game/` rebuilds the world in place, its stores, columns and
 * channels made again, and a module the change did not touch is not evaluated
 * again -- so a `const hits = world.events(Hit)` at module level would go on
 * pointing at the old one. Tokens are fine there (components, events, prefabs,
 * nodes: redefined in place), and so are scratch objects and helpers.
 *
 * A heuristic, by line: a statement at column 0 -- `const`, `let` or `var`,
 * exported or not -- whose initializer names `world` anywhere (`world.`, a bare
 * `world`, `game.world`, `findCrates(world)`: a query result kept is as stale
 * as the world) or calls `.store(` or `.events(`; the type `World` is another
 * word, so `let kept: World | null = null` passes. An initializer that is a
 * function (`=>`, `function`) is a helper and passes. Indented lines are
 * inside a function and fine. It misses a module variable declared empty and
 * assigned in a function (that `kept`, then `kept = world`), an initializer
 * that starts on a later line, and destructuring (`const { world } = game`).
 * No waiver: a game module has no reason to keep one.
 */
const MODULE_STATE = {
  rule: 'the world, a store or a channel kept at module level',
  fix: 'take it from the world or the store each call: a swap rebuilds the world in place and this would be stale (CLAUDE.md, Docs/ecs.md §22)',
};
/** A module-level declaration, and its initializer (after the first `=` that is no `==` or `=>`). */
const DECLARATION = /^(?:export\s+)?(?:const|let|var)\s[^=]*=(?![=>])(.*)$/;
/** What the initializer must not reach. */
const KEEPS = /\bworld\b|\.store\(|\.events\(/;
/** A helper, not a value: its body runs at each call. */
const FUNCTION = /=>|\bfunction\b/;

/** Every module-level line of a game module (`src/game/**`) that keeps the world, a store or a channel. */
export function checkModuleState(source: string): Finding[] {
  const lines = source.split('\n');
  const findings: Finding[] = [];
  let block = false;
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i]!;
    if (/^\s*\/\*/.test(raw)) block = true;
    const commented = block;
    if (/\*\//.test(raw)) block = false;
    if (commented) continue;
    const init = DECLARATION.exec(code(raw))?.[1];
    if (init === undefined || FUNCTION.test(init) || !KEEPS.test(init)) continue;
    findings.push({ line: i + 1, rule: MODULE_STATE.rule, fix: MODULE_STATE.fix, text: raw.trim() });
  }
  return findings;
}

/** The data components a module declares (`export const Patrol = dataComponent('Patrol', …)`): their names in code. */
export function dataComponentsIn(source: string): string[] {
  const out: string[] = [];
  for (const m of source.matchAll(/^(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*=\s*dataComponent\s*[<(]/gm)) out.push(m[1]!);
  return out;
}

/**
 * A `parallel: true` system that reads or writes a data component (Docs/ecs.md §3, §10): its lists, strings and
 * records are objects on the main thread, never in the shared memory a worker sees -- the world refuses it at
 * registration too; this says so before the game runs. `data` is every data component's name in code
 * (`dataComponentsIn` over the game's modules).
 */
export function checkParallelData(source: string, data: ReadonlySet<string>): Finding[] {
  if (data.size === 0) return [];
  const lines = source.split('\n');
  const inside = systemLines(lines);
  const findings: Finding[] = [];
  // One system at a time: a run of lines inside a `.system(` call.
  let block: number[] = [];
  const flush = (): void => {
    const text = block.map((i) => code(lines[i]!)).join('\n');
    if (/\bparallel\s*:\s*true\b/.test(text)) {
      for (const i of block) {
        const line = code(lines[i]!);
        if (!/\b(read|write)\s*:/.test(line)) continue;
        for (const name of data) {
          if (new RegExp(`\\b${name}\\b`).test(line)) findings.push({ line: i + 1, rule: 'data component in a parallel system', fix: `${name} is a data component -- its lists, strings and records live on the main thread: take parallel off, or keep what the system needs in a numeric component`, text: lines[i]!.trim() });
        }
      }
    }
    block = [];
  };
  for (let i = 0; i < lines.length; i++) {
    if (inside.has(i) && /\.system\s*\(/.test(code(lines[i]!)) && block.length > 0) flush();
    if (inside.has(i)) block.push(i);
    else if (block.length > 0) flush();
  }
  if (block.length > 0) flush();
  return findings;
}
