/**
 * Commands: every change to what exists, queued until the tick boundary
 * (Docs/ecs.md §7).
 *
 * Each system has a buffer of its own (`ctx.cmd`), and the world has one for
 * code outside a system (`world.spawn` and the rest). A buffer is opcodes in an
 * `Int32Array`, four numbers a command: no objects, no closures. At the
 * boundary the world applies the buffers in the order their systems ran.
 *
 * Two things happen at once rather than at the boundary, because nobody else
 * can be looking: `spawn` takes its id, and the rows of a component being added get
 * their defaults -- so the caller can fill them in through the store that
 * `init` and `add` hand back.
 */
import type { AnyComponent, Entity, Kind, Relation, StoreOf } from './component.ts';
import { Bare } from './component.ts';
import type { EntityOf, MadeWith, PrefabNode, PrefabToken } from './prefab.ts';

export const SPAWN = 1;
export const DESTROY = 2;
export const ADD = 3;
export const REMOVE = 4;
export const PARENT = 5;
export const RELATE = 6;
export const UNRELATE = 7;
export const ENABLE = 8;
export const LAYER = 9;
export const INSTANTIATE = 10;
export const ANNOUNCE = 11;
/** A parked instance of a pooled prefab taken: `Disabled` off its root at the boundary, nothing else (Docs/prefabs.md §5). */
export const TAKE = 12;
/** An instance just made put in its prefab's pool, at the boundary it is made: `world.warmPools`. */
export const PARK = 13;

/** Numbers a command takes in a buffer: the opcode and three arguments. */
export const STRIDE = 4;

/** What a buffer needs of the world: the parts of a command that cannot wait. */
export interface CommandHost {
  /** An id for a new entity of `kind`, its components' rows at their defaults. `NONE` if the world is full. */
  reserve(kind: Kind): Entity;
  /** `component`'s row for `e` at its defaults, ahead of an `add`; returns its store. Throws if `e` has it already. */
  prepare(e: Entity, component: AnyComponent): unknown;
  /** The store of a component `e` was spawned with this tick. Throws for an entity that is already in the world. */
  ownStore(e: Entity, component: AnyComponent): unknown;
  /** A row for a link from `source` to `target`, its data at its defaults. 0 if the relation's table is full. */
  pair(source: Entity, relation: Relation, target: Entity): number;
  /** Counts a buffer that had to grow. */
  grew(): void;
  /** The whole tree of a compiled prefab reserved and its rows written; returns the root, `NONE` if the world is full. */
  reserveInstance(prefab: PrefabToken): Entity;
  /** The last `reserveInstance` ran out of ids part way: what it returned is to be made and destroyed. */
  readonly instanceRefused: boolean;
  /** The last `reserveInstance` took a parked instance from its prefab's pool: it is switched on, not made. */
  readonly instanceTaken: boolean;
  /** The entity of `node` in the instance whose root is `root`; `NONE` if it has none. */
  part(root: Entity, node: PrefabNode): Entity;
}

export class Commands {
  /** Opcodes: (op, a, b, c) each. */
  data = new Int32Array(STRIDE * 64);
  length = 0;
  private readonly host: CommandHost;

  constructor(host: CommandHost) {
    this.host = host;
  }

  /**
   * The engine's: prefabs make kinds (Docs/prefabs.md), and the ECS's own tests
   * and fixtures spawn them; a game writes a prefab and `instantiate`s it.
   * A new entity of `kind`: every component of the kind added, its rows at their
   * defaults. The id is good at once; the entity is in no system until the
   * boundary. Returns `NONE` if the world is at its ceiling.
   */
  spawn(kind: Kind = Bare): Entity {
    const e = this.host.reserve(kind);
    if (e !== 0) this.push(SPAWN, e, kind.id, 0);
    return e;
  }

  /**
   * An instance of a prefab (Docs/prefabs.md §4): the root's id at once, every
   * entity of it reserved and its rows written now, `cmd.init` good on each,
   * the tree, refs and links made and membership begun at the boundary. One
   * opcode. `NONE` if the world is full.
   */
  instantiate<P extends PrefabToken>(prefab: P): EntityOf<P> {
    const e = this.host.reserveInstance(prefab);
    if (e === 0) return e as EntityOf<P>;
    if (this.host.instanceTaken) {
      this.push(TAKE, e, prefab.id, 0);
      return e as EntityOf<P>;
    }
    this.push(INSTANTIATE, e, prefab.id, 0);
    if (!this.host.instanceRefused) return e as EntityOf<P>;
    this.push(DESTROY, e, 0, 0);
    return 0 as EntityOf<P>;
  }

  /** The entity of `node` in the instance `root` heads: good from `instantiate` on, allocating nothing. */
  part<N extends PrefabNode>(root: Entity, node: N): EntityOf<N> {
    return this.host.part(root, node) as EntityOf<N>;
  }

  /**
   * The engine's (`world.announceInstance`): the world's `onInstance` hooks for
   * `root` at the boundary, an instance whose rows were written one by one.
   */
  announce(root: Entity): void {
    if (root !== 0) this.push(ANNOUNCE, root, 0, 0);
  }

  /**
   * `e` and everything under it, gone at the boundary. Until then it is still in
   * its systems. A pooled prefab's instance, destroyed at its root, goes back
   * to its pool instead (Docs/prefabs.md §5).
   */
  destroy(e: Entity): void {
    if (e !== 0) this.push(DESTROY, e, 0, 0);
  }

  /** The engine's: `e` and everything under it gone for real at the boundary, a pooled or a parked instance too (`pool.drain()`). */
  letGo(e: Entity): void {
    if (e !== 0) this.push(DESTROY, e, 1, 0);
  }

  /**
   * The engine's (`world.warmPools`): an instance whose rows `reserveInstance`
   * wrote made at the boundary and put straight in its pool, in no system at
   * any time; one the world had no room for, made and let go.
   */
  park(root: Entity, prefab: number, whole: boolean): void {
    if (root === 0) return;
    this.push(INSTANTIATE, root, prefab, 0);
    this.push(whole ? PARK : DESTROY, root, whole ? prefab : 1, 0);
  }

  /**
   * One more component on `e`, from the boundary on. Its row has its defaults now,
   * and its writable store comes back to fill it in. Throws if `e` has it.
   */
  add<T extends AnyComponent>(e: Entity, component: T): StoreOf<T> {
    if (e === 0) return undefined as StoreOf<T>;
    const store = this.host.prepare(e, component);
    this.push(ADD, e, component.id, 0);
    return store as StoreOf<T>;
  }

  /**
   * The writable store of a component of an entity spawned this tick, to set what
   * its defaults do not: `cmd.init(e, Transform).px[e] = 3`. Its rows are
   * nobody else's until the boundary. Throws for an entity already in the world.
   * On an entity a typed prefab token made, a component its prefab file does not
   * make it with is a compile error (`MadeWith`, `src/prefab-token.ts`).
   */
  init<E extends Entity, T extends AnyComponent>(e: E, component: T & MadeWith<E, T>): StoreOf<T> {
    return this.host.ownStore(e, component) as StoreOf<T>;
  }

  /** `component` off `e` at the boundary. Nothing happens if it does not have it. */
  remove(e: Entity, component: AnyComponent): void {
    if (e !== 0) this.push(REMOVE, e, component.id, 0);
  }

  /**
   * `child` under `parent` at the boundary, last of its children; `NONE` for no
   * parent: a root, last of the roots (one already, moved there). With
   * `before`, a child of `parent` -- a root, for `NONE` -- it goes in front of
   * that one instead: under the parent it has already, that only moves it
   * among its siblings. A `before` that is no child of `parent` by the
   * boundary is as if it were not given (Docs/ecs.md §8).
   */
  setParent(child: Entity, parent: Entity, before: Entity = 0 as Entity): void {
    if (child !== 0) this.push(PARENT, child, parent, before);
  }

  /**
   * A link from `source` to `target`, from the boundary on. Returns the link's
   * row at once, to fill in its data through the relation's store
   * (`likes.much[p] = 3`); 0 if either end is `NONE` or the table is full. A
   * second link between the same two changes nothing: the first stands.
   */
  relate(source: Entity, relation: Relation<any>, target: Entity): number {
    if (source === 0 || target === 0) return 0;
    const p = this.host.pair(source, relation, target);
    if (p !== 0) this.push(RELATE, p, relation.id, 0);
    return p;
  }

  /**
   * A component on `e` switched off, or on again, from the boundary: off, the
   * entity is in no system that needs it, and its data stays. `world.enabled`
   * says which it is.
   */
  enable(e: Entity, component: AnyComponent, on = true): void {
    if (e !== 0) this.push(ENABLE, e, component.id, on ? 1 : 0);
  }

  /** `enable(e, component, false)`. */
  disable(e: Entity, component: AnyComponent): void {
    this.enable(e, component, false);
  }

  /** `e` onto layer 0 to 31, from the boundary. */
  setLayer(e: Entity, layer: number): void {
    if (e !== 0) this.push(LAYER, e, layer & 31, 0);
  }

  /** The link from `source` to `target` gone at the boundary; every link out of `source` if `target` is `NONE`. */
  unrelate(source: Entity, relation: Relation<any>, target: Entity): void {
    if (source !== 0) this.push(UNRELATE, source, relation.id, target);
  }

  private push(op: number, a: number, b: number, c: number): void {
    if (this.length + STRIDE > this.data.length) {
      const grown = new Int32Array(this.data.length * 2);
      grown.set(this.data);
      this.data = grown;
      this.host.grew();
    }
    const data = this.data;
    data[this.length] = op;
    data[this.length + 1] = a;
    data[this.length + 2] = b;
    data[this.length + 3] = c;
    this.length += STRIDE;
  }
}
