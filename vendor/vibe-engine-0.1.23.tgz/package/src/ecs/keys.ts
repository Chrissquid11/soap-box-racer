/**
 * The intern table for asset keys held in columns (Docs/render.md §2): a
 * `key(kind)` field holds a number, and this is the one place a number and a
 * key's text are matched, per kind (`Model`, `Material`, `Clip`, a game's own).
 *
 * - **A reference in every file, an id in a column.** A prefab's `data`, an
 *   override and a save write `{ "uid": "uid://…", "key": "props/crate" }`
 *   (`fieldText`, Docs/asset-ids.md §3) -- the bare key where the asset has no
 *   uid (a clip's name, an asset not loaded) -- and read either, the uid first
 *   (`fieldValue` through `resolveRef`); the compile, a load and a paste intern
 *   the key (`internKey`) and a column holds the id. `keyText` gives the text
 *   back, `fieldPlain` a field's value as text for a tool to show.
 * - **Ids are a session's**: given in order of first sight, from 1 (`0` is
 *   none, and so is `''`), never written anywhere. The worker compiles the same
 *   prefab files in the same order, their references read through the same uid
 *   index (the generated `prefab-bundle.ts` hands it the boot set's), so a column
 *   it shares reads the same -- a stale key too; it never resolves an id back.
 * - **A key's one spelling**: lowercased as every key is (`caseKey`), so
 *   `Props/Crate` and `props/crate` are one id.
 *
 * Pure: no DOM, no three. Node tests import it.
 */
import { caseKey } from '../assets/case-key.ts';
import { isKeyRef, keyRef, meshRef, resolveRef, type KeyRef } from '../assets/uids.ts';

interface Table {
  /** By text: its id. */
  readonly ids: Map<string, number>;
  /** By id: its text; index 0 is none. */
  readonly texts: string[];
}

const tables = new Map<string, Table>();

function tableOf(kind: string): Table {
  let t = tables.get(kind);
  if (!t) {
    t = { ids: new Map(), texts: [''] };
    tables.set(kind, t);
  }
  return t;
}

/** The id of `text` among `kind`'s keys, assigning the next on a first sight; 0 for none (`''`, null, undefined). */
export function internKey(kind: string, text: string | null | undefined): number {
  if (text === null || text === undefined || text === '') return 0;
  const key = caseKey(text);
  const t = tableOf(kind);
  let id = t.ids.get(key);
  if (id === undefined) {
    id = t.texts.length;
    t.texts.push(key);
    t.ids.set(key, id);
  }
  return id;
}

/** The text of `kind`'s key `id`: null for 0, or for an id never given. */
export function keyText(kind: string, id: number): string | null {
  if (id === 0) return null;
  return tables.get(kind)?.texts[id] ?? null;
}

/** Every kind something has interned a key of, sorted: for a tool. */
export function keyKinds(): string[] {
  return [...tables.keys()].sort();
}

/** The key kind of `field` of a component, relation or event (`key('Model')`'s `'Model'`), or null for a field that is no key. */
export function keyKindOf(c: { readonly schema: object }, field: string): string | null {
  return (c.schema as Record<string, { key?: string } | undefined>)[field]?.key ?? null;
}

/** What a field of a component, relation or event says of itself, by its column's name -- undefined for a vector's axis or none. */
type Said = { key?: string; mesh?: true; enum?: readonly string[]; flags?: readonly string[]; color?: true; alpha?: true };
const saidOf = (c: { readonly schema: object }, field: string): Said | undefined => (c.schema as Record<string, Said | undefined>)[field];

/** `0xRRGGBBAA` as a file writes it: `#rrggbbaa`. */
export const hexA = (value: number): string => `#${(value >>> 0).toString(16).padStart(8, '0')}`;
/** `0xRRGGBB` as a swatch's value: `#rrggbb`. */
export const hex = (value: number): string => `#${((value >>> 0) & 0xffffff).toString(16).padStart(6, '0')}`;

/** A colour's text as the column holds it -- `#rrggbb`, or `#rrggbbaa` where `alpha` (an `#rrggbb` there opaque) -- or null. */
export function colourValue(text: string, alpha: boolean): number | null {
  const m = /^#?([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(text.trim());
  if (!m) return null;
  if (!alpha) return m[2] === undefined ? parseInt(m[1]!, 16) : null;
  return parseInt(m[1]! + (m[2] ?? 'ff'), 16) >>> 0;
}

/** A flags column's names set, in the field's order; a bit no name has is dropped. */
export function flagNames(names: readonly string[], value: number): string[] {
  const out: string[] = [];
  for (let i = 0; i < names.length; i++) if ((Math.floor((value >>> 0) / 2 ** i) & 1) === 1) out.push(names[i]!);
  return out;
}

/** Names as a flags column holds them: a list, or text with commas (`"fire, ice"`); null where one is none of `names`. */
function flagBits(names: readonly string[], given: readonly unknown[] | string): number | null {
  const list = typeof given === 'string' ? given.split(/[,|]/).map((n) => n.trim()).filter((n) => n !== '') : given;
  let bits = 0;
  for (const n of list) {
    const at = typeof n === 'string' ? names.indexOf(n) : -1;
    if (at < 0) return null;
    bits += (Math.floor(bits / 2 ** at) & 1) === 1 ? 0 : 2 ** at;
  }
  return bits;
}

/**
 * A field's value as a file writes it: a key field's reference -- `{ uid, key }` when its asset has a uid, else the
 * key's text (`keyRef`; `''` for none), a `mesh()`'s `{ uid, key, part }` (`meshRef`) -- an `enumOf`'s name, a `flagsOf`'s names, a `colorA`'s `#rrggbbaa`, any
 * other its number. The one way out of a column into a file. (A vector's axis is a number here: the file's
 * `[x, y, z]` is `foldVectors`'.)
 */
export function fieldText(c: { readonly schema: object }, field: string, value: number): number | string | string[] | KeyRef {
  const said = saidOf(c, field);
  // An index no name has (code wrote it): the number it is, which a load takes back as that index.
  if (said?.enum) return said.enum[value] ?? value;
  // A bit no name has (code set it): the number it is, so nothing is lost on the way back.
  if (said?.flags) return (value >>> 0) < 2 ** said.flags.length ? flagNames(said.flags, value) : value;
  if (said?.alpha) return hexA(value);
  const kind = said?.key ?? null;
  if (kind === null) return value;
  // A `mesh()`: the model's reference with its part on its own, `{ uid, key, part }`.
  return said?.mesh ? meshRef(keyText(kind, value) ?? '') : keyRef(kind, keyText(kind, value) ?? '');
}

/** Whether a field's file value is anything but its number: a key, an enum's name, flags' names, a `colorA`'s text. */
export function fieldIsText(c: { readonly schema: object }, field: string): boolean {
  const said = saidOf(c, field);
  return said !== undefined && (said.key !== undefined || said.enum !== undefined || said.flags !== undefined || said.alpha === true);
}

/**
 * A field's value as text a person reads: a key field's key (`''` for none), an enum's name, flags' names with
 * commas (`fire, ice`; `''` for none), a `colorA`'s `#rrggbbaa`, any other its number -- what a tool shows or
 * compares, never what a file holds. `fieldValue` reads each back.
 */
export function fieldPlain(c: { readonly schema: object }, field: string, value: number): number | string {
  const said = saidOf(c, field);
  if (said?.enum) return said.enum[value] ?? value;
  if (said?.flags) return flagNames(said.flags, value).join(', ');
  if (said?.alpha) return hexA(value);
  const kind = said?.key ?? null;
  return kind === null ? value : (keyText(kind, value) ?? '');
}

/**
 * A value a file wrote back as the column holds it: a key field's reference resolved (`resolveRef`: a `{ uid, key }`
 * by its uid first, a bare key as it is) and interned (a number is taken as an id, as a file from before the field
 * was a key wrote it), an enum's name its index, flags' names their bits, a colour's `#rrggbb` (`#rrggbbaa`) its
 * number, any other field's number as it is; a boolean is 1 or 0. Null for what the field cannot hold -- text on a
 * field that is no key, a name none of an enum's -- for the caller to say (`fieldProblem` says why).
 */
export function fieldValue(c: { readonly schema: object }, field: string, value: unknown): number | null {
  if (typeof value === 'number') return value;
  if (typeof value === 'boolean') return value ? 1 : 0;
  const said = saidOf(c, field);
  if (said?.enum) {
    const at = typeof value === 'string' ? said.enum.indexOf(value) : -1;
    return at < 0 ? null : at;
  }
  if (said?.flags) return Array.isArray(value) || typeof value === 'string' ? flagBits(said.flags, value as readonly unknown[] | string) : null;
  if (said?.color && typeof value === 'string') return colourValue(value, said.alpha === true);
  const kind = said?.key ?? null;
  if (kind !== null && (typeof value === 'string' || value === null || isKeyRef(value))) return internKey(kind, resolveRef(kind, value));
  return null;
}

/**
 * Why `value` is nothing `field` holds, where a file reader must refuse it rather than take the default: a name
 * none of an enum's or a flags', a colour that is no colour -- with the names there are. Null where it fits, or for
 * a mistake of another kind (text on a number), which the reader says its own way.
 */
export function fieldProblem(c: { readonly name?: string; readonly schema: object }, field: string, value: unknown): string | null {
  const said = saidOf(c, field);
  const at = `${c.name ?? '?'}.${field}`;
  // A number is the index it is, any: code is not held to an enum's names (`mood[e] = 7` saves 7, and loads back),
  // and a file from before the field was an enum holds one. Only a name none of its names is refused.
  if (said?.enum && typeof value !== 'number' && fieldValue(c, field, value) === null) return `${at}: no name ${JSON.stringify(value)} -- its names are ${said.enum.join(', ')}`;
  if (said?.flags && typeof value !== 'number' && fieldValue(c, field, value) === null) {
    const list = Array.isArray(value) ? value : typeof value === 'string' ? value.split(/[,|]/).map((n) => n.trim()) : [value];
    const bad = list.filter((n) => typeof n !== 'string' || !said.flags!.includes(n));
    return `${at}: no name ${bad.map((n) => JSON.stringify(n)).join(', ')} -- its names are ${said.flags.join(', ')} (a list of them: ["${said.flags[0]}"])`;
  }
  if (said?.color && typeof value === 'string' && fieldValue(c, field, value) === null) return `${at}: ${JSON.stringify(value)} is no colour -- "${said.alpha ? '#rrggbbaa' : '#rrggbb'}"`;
  return null;
}
