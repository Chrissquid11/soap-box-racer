---
skill: engine
title: Field kinds and options
when: Declaring fields -- which kind for what (a number, a slider, an enum, flags, a vector, a colour, a ref, an asset key, a mesh; a data component's lists, dictionaries, text, records) -- and what the inspector, files and scene_set do with each
covers:
  modules: [ecs/fields.ts, ecs/component.ts, ecs/data.ts]
order: 11
---
# Field kinds and options

A field says what it holds and how it shows: the inspector draws each kind its own way, a file writes it in its own
form, and Claude's `scene_set` checks a value against it -- all from the one declaration, with no code of your own.

## Which kind for what

| You want | Declare | Code reads | The inspector | A file writes |
|---|---|---|---|---|
| a number | `f32(1)` … `u32()`, `{ min, max, step }` | `move.speed[e]` | a scrub field, clamped | `1.5` |
| a number in a range | `f32(0.5, { min: 0, max: 1, slider: true })` | the same | a slider and its number | `0.5` |
| yes or no, a value | `bool(true)` | `look.castShadow[e] !== 0` | a checkbox | `true` |
| yes or no, a kind of thing | `tag('Stunned')` (a component, not a field) | `with: [Stunned]`, `ctx.has(e, Stunned)` | its header | `"tags": ["Stunned"]` |
| one of several | `enumOf(['idle', 'walk'], 'idle')` | `=== Gait.walk` | a drop-down | `"walk"` |
| several of several | `flagsOf(['fire', 'ice'])` | `& Element.ice` | ticks under a button | `["fire", "ice"]` |
| a colour | `color(0xffffff)`; with alpha `colorA(0x66ccff80)` | the number | a swatch (and an alpha slider) | its number, `16777215` (`"#ffffff"` by hand reads too); `"#66ccff80"` |
| a direction, a point | `vec3([0, 0, 1], { min: -1, max: 1 })` | `aim.dirX[e]`, `dirY`, `dirZ` | one row of three | `[0, 0, 1]` |
| another entity | `ref(Transform)`, `ref(Health, Collider)`; anyone: `ref()` | `deref(follow.who[e])` | "→ Health on goblin 3", Pick…, × | an id or path in a prefab, an index in a scene |
| an asset | `key('Sfx')`, `key('Prefab')`, any kind | `keyText('Sfx', id)`, `prefabOfKey(id)` | a picker, each key with its look | `{ "uid": "…", "key": "hop" }` |
| a model's part | `mesh()` | `meshOf(id)`: `{ model, part }` | the model's picker, then its part's | `{ "uid", "key", "part": "tail" }` |
| text | `string('', { maxLength: 80 })`, in a data component | `patrol.get(e).motto` | a text field (`multiline`: an area) | `"Pieces of eight!"` |
| a list | `list(ref(Transform), { max: 16 })`, in a data component | an array | rows with grips, ×, + | `[…]` |
| a dictionary | `dict(Luck, key('Prefab'))`, in a data component | a `Map` | rows of key and value, + | `{ "rare": … }` |
| a group of fields | `record({ speed: f32(), laps: u16() })`, in a data component | an object | a folded group | `{ "speed": 3 }` |
| a handle (a three.js object) | `objectComponent` | your own object | read-only | only with `save`/`load` |

## The rules

- **What a hot loop reads goes in columns** (`component`): every kind down to a model's part is a number in a typed
  array, read as fast as any, and fine in a `parallel` system.
- **A list, a dictionary, text or a record is a `dataComponent`**: one object an entity, its shape declared.
  `read: [Patrol]` (or `write`) in a system, then `patrol.get(e)` -- the entity's own object, the same one each call,
  no allocation; change it in place. **Never in a `parallel` system**: its objects are the main thread's, and the
  world and the `ecs` check both refuse it. A handful of entities with an object each is fine; for thousands, keep
  the numbers they are read by in a `component` beside it.
- **`runtime`**: a field the systems set as the game runs (`{ runtime: ['leg', 'until'] }`) -- kept in a saved game,
  never in a prefab or scene file (one written there is a compile error), dimmed on an opened prefab. **`transient`**
  (the component's option): in no save at all, scratch.
- **`menu` and `help`** (the component's options, beside `runtime`; `objectComponent` and `dataComponent` take them
  too): where the inspector's Add Component lists it -- a path, `'Combat'`, `'Combat/Weapons'` -- and its row's
  hover -- `component('Health', { hp: f32(100) }, { menu: 'Combat', help: 'Hit points; 0 is dead' })`. Left out,
  it is under `Game`. Metadata only: no file or save says either.
- **Only what differs from the default** is written in a file, and an instance's override of a data component's
  field is that field whole (a list replaced, never merged).

## The options

Every maker takes them last: `f32(1, { ... })`, `bool(true, { ... })`, `ref(Transform, { ... })`,
`key('Model', { ... })`, `enumOf(names, initial, { ... })`, `list(of, { ... })`.

| Option | What it does |
|---|---|
| `label` | The name shown. By default the field's own, spaced: `castShadow` is "Cast shadow". |
| `help` | The tooltip on its name and its control. |
| `min`, `max` | What the inspector and `scene_set` write is clamped to (`scene_set` says so); a list's count. Your code is never held to them. |
| `step` | An arrow key's step and a scrub's rate (default 1 for a whole number, 0.1 for a float). |
| `slider` | A slider beside the number, from `min` to `max`: both must be given. |
| `hidden` | Left out of the inspector; still in files, saves and `scene_entity`. |
| `readonly` | Shown, never edited; `scene_set` refuses it. For a value code sets. |
| `group` | A sub-heading. Every field naming it sits under its one heading, where the first is; a field with no group after a group ends it (a line). |
| `multiline`, `maxLength` | A string's: a text area, and its longest. |

## Examples, as a game writes them

The sandbox's game has one of each idea -- a hop with a power and a sound, a parrot's mood, a loot table, a patrol --
declared so in its `components.ts`:

```ts
import { color, component, dataComponent, dict, enumOf, f32, f64, flagsOf, key, list, ref, Transform, u16 } from '@vibe/engine';

/** A slider, held to 1-8, and a sound: the picker lists the project's sounds, each with a play button. */
export const Hop = component('Hop', {
  vy: f32(),
  power: f32(4.2, { min: 1, max: 8, slider: true, step: 0.1, help: 'Its speed leaving the ground, metres a second' }),
  sound: key('Sfx', { help: 'What it plays as it leaves the ground' }),
}, { runtime: ['vy'] });

/** An enum and flags: each the field and its constants in one declaration. */
export const Feeling = enumOf(['calm', 'curious', 'grumpy'], 'calm');
export const Riles = flagsOf(['hops', 'loot'], ['hops']);
export const Mood = component('Mood', {
  feeling: Feeling.as('calm', { help: 'How it feels now' }),           // .as(): the same names, its own start and options
  riledBy: Riles.as(['hops', 'loot']),
  calmsIn: f32(3, { min: 0.5, max: 10, slider: true, step: 0.5 }),
  until: f64(),
  calm: color(0xffffff, { group: 'Tints' }),                            // under a "Tints" heading
  grumpy: color(0xff7a5c, { group: 'Tints' }),
}, { runtime: ['until'] });

/** A dictionary from an enum to a prefab, and a list of typed refs: data components. */
export const Luck = enumOf(['common', 'rare']);
export const Loot = dataComponent('Loot', {
  table: dict(Luck, key('Prefab'), { help: 'What it drops, by luck' }),
  rare: f32(0.25, { min: 0, max: 1, slider: true }),
  toss: f32(3, { min: 0, max: 8 }),
});
export const Patrol = dataComponent('Patrol', {
  waypoints: list(ref(Transform), { max: 16 }),                         // only entities with a Transform: drop tree rows
  speed: f32(0.4, { min: 0, max: 3, slider: true }),
  pause: f32(0.5, { min: 0 }),
  leg: u16(),
  until: f64(),
}, { runtime: ['leg', 'until'] });
```

Read in a system -- the sandbox's `loot`, short: on a hop, a luck rolled, the table's entry for it (an enum's index
is the dict's key) made a token by `prefabOfKey`, and an instance of it placed:

```ts
import { NONE, prefabOfKey, Transform, WorldTransform, type World } from '@vibe/engine';
import { Hopped, Loot, Luck } from '../components.ts';

export function loot(world: World): void {
  const hops = world.events(Hopped);
  world.system({
    name: 'loot',
    rate: 60,
    read: [Loot, WorldTransform],
    update(ctx, [loot, at]) {
      if (hops.begin(ctx) === hops.end) return;
      const { members, count, cmd, rng, deref } = ctx;
      for (let n = 0; n < count; n++) {
        const e = members[n];
        for (let i = hops.begin(ctx); i < hops.end; i++) {
          if (deref(hops.who[i]) !== e) continue;
          const drops = loot.get(e);                                    // its own object: no allocation
          const what = prefabOfKey(drops.table.get(rng.chance(drops.rare) ? Luck.rare : Luck.common) ?? 0);
          if (what === null) continue;                                  // no entry, or a prefab gone
          const item = cmd.instantiate(what);
          if (item === NONE) continue;                                  // its pool at its max
          const place = cmd.init(item, Transform);
          place.px[item] = at.px[e];
          place.pz[item] = at.pz[e];
        }
      }
    },
  });
}
```

(The sandbox's own also throws a drop whose prefab carries a `Chip` and sets any other down beside the crate:
`src/game/systems/loot.ts`. Its `patrol` walks `waypoints`, each deref'd as it is used and a gone one, `NONE`, skipped.)

In a prefab file, only what differs from the defaults -- under `data` for a component, `objects` for a data
component; refs by an entity's id or path, keys `{ uid, key }` (write the key alone by hand: the pipeline adds the
uid), a colour by hand as `"#rrggbb"` (the editor writes it back as its number):

```json
"data": { "Hop": { "sound": { "uid": "uid://jazr367jj6a6i", "key": "hop" } }, "Mood": { "feeling": "curious", "riledBy": ["hops", "loot"], "grumpy": "#ff7a5c" } },
"objects": { "Loot": { "table": { "common": "crates/chip", "rare": "crates/gem" } }, "Patrol": { "waypoints": ["post1", "post2", ["rider", "seat"]] } }
```

The compile checks every value and names its path: `Mood.feeling: no name "grumpi"`, `Loot.table.rare: no prefab
"crates/gme"`, `Patrol.waypoints[1]: lid has no Transform: needs an entity with Transform`.

## Each kind, what to know

- **Enum** (`enumOf(names, initial, options?)`): a `u8` (a `u16` past 256 names) holding an index. Compare with the
  constants -- `Feeling.grumpyy` is a compile error. Files and saves write the name, so reordering or adding names
  never changes what a file means; a name not in the list is an error naming it, where the file is read. Your code may
  write an index no name has: it saves and loads back as its number. No name may be one of a field's own properties
  (`as`, `type`, `initial`, `min`, `label` …) or every object's (`toString`, `constructor` …): the maker refuses it.
- **Flags** (`flagsOf(names, initial?)`): a `u32`, the first name the lowest bit, at most 32. Test with
  `(mood.riledBy[e] & Riles.loot) !== 0`, set with `|=`. Files write the names set (`[]` for none).
- **Vector** (`vec2`, `vec3`, `vec4(initial?, options?)`): a column an axis after its name -- `gazeX`, `gazeY`,
  `gazeZ`, `gazeW` -- plain columns, so `parallel` and the no-allocation rule hold. `f32` unless `{ f64: true }`;
  `min`/`max` hold each axis. Don't also name a field `gazeX`.
- **Colour**: `color()` is `0xRRGGBB`: the editor writes its number (so no file written before changes), and
  `"#rrggbb"` written by hand is read too -- the sandbox's prefabs write their tints so; `colorA()` is
  `0xRRGGBBAA`, written `"#rrggbbaa"`.
- **A typed ref** (`ref(Health)`, `ref(Health, Collider)`, then options): a reference to a component is a reference to
  an entity that has it. Code reads it as any ref -- `deref`, then check `NONE` -- and is never held to the type (the
  entity may have lost `Health` since: `has` where it matters). The inspector, a drop, a pick and `scene_set` take only
  an entity with every one, and a prefab pointing one at a node without them does not compile, each saying why (`rock
  has no Health: needs an entity with Health`). A plain `ref()` takes anyone. Inside a prefab a ref points inside it;
  in a scene at any entity -- an instance's ref pointed outside it is an override (`{ "entity": 52 }`, or `null` for
  nobody, which Apply takes into the prefab; one outside it refuses).
- **An asset key** (`key(kind)`): `Model`, `Texture`, `Material`, `Prefab`, `Scene`, `Level`, `Sfx`, `UiSfx`,
  `Music`, `Atlas`, `Icon`, `Font`, your project's own data kinds, and `Clip` (a name among the entity's model's
  clips) -- a kind your project has not is a type error listing the ones it has. The column holds the key's id:
  `keyText('Sfx', id)` is its text (null for none) for `Audio.sfx(...)` and the rest; `prefabOfKey(id)` is a
  `key('Prefab')`'s token for `cmd.instantiate` (null for none, or a prefab gone); compare ids against
  `internKey('Sfx', 'hop')` kept at module level. Declare it in its `component(...)` call as `key('Sfx')`, not through
  a variable: the pipeline reads it there to give a key written by hand its uid. The picker lists what the project
  has of that kind, each with its look -- a thumbnail, a material's swatch, a font in its face, a play button for a
  sound -- and takes a file of that kind dragged from the Assets panel.
- **A model's part** (`mesh()`): a model and one of its parts, as `Render.model` holds it (`props/parrot#tail`; the
  whole model with no part). `meshOf(id)` gives `{ model, part }`. A model dropped on it asks for the part next.
- **A data component's elements**: every kind above is an element, nested to any depth --
  `list(record({ to: ref(Transform), wait: f32(1) }))`, `dict(string(), u16())`. A dictionary's key is a `string()`,
  a number maker, an `enumOf` or a `ref()` (an entity's own entry); a file writes `{ "k": v }` where its keys are
  names or text, `[[k, v], …]` otherwise. Code sees a list as an array, a dict a `Map` in the order written, a
  record an object, a `bool` a boolean, a vector `[x, y, z]`, every other kind the number its column would hold (an
  enum's index, a key's id, an `EntityRef`).

## In the studio

- **The inspector** draws each kind its way, labelled, its help on hover, grouped; a list's rows each its element's
  widget with a grip to drag it, × and + (greyed at `min`/`max`), tree rows or assets dropped on the list append, on a
  row insert before it, several at once; a dictionary's + takes the first free key, and a key typed twice is refused
  where it is typed. While anything is dragged, each field that would take it lights and the rest dim, saying why. On
  a prefab instance an edited field is marked as overridden, Revert and Apply as ever.
- **Claude** reads each component's `schema` with `scene_entity` -- every field's kind, names, bounds, a ref's
  `needs`, a key's `keyKind`, a list's element all the way down -- and sets any kind with `scene_set` (a path into a
  data component: `waypoints[2]`, `table.rare`) and a list's or a dictionary's +, × and grip with
  `scene_list_insert`, `scene_list_remove` and `scene_list_move`: the `studio` skill's `scene` page.
