/**
 * The running game's world built again in place after its code changed
 * (Docs/squidwright-implementation.md 0.3): the save taken, the loop and the
 * world reset -- the same objects, for everyone who holds them -- the caller's
 * hooks installed again, the new modules' systems registered over the
 * registry's components as they are now, the world built.
 *
 * The load is the caller's, as a load always is (`Game.load`, `world.load`):
 * what it maps an old save through, and what it does after, is the page's.
 *
 * Pure: no DOM, no three. `Game.rebuild` calls it with the page's own hooks.
 */
import type { World, WorldSave } from './world.ts';

/** What a rebuild takes of the new modules. */
export interface Rebuild {
  registerSystems(world: World): void;
}

/** The world's save taken, the loop and the world reset, `install` run (the caller's hooks), the systems registered, the world built. Returns the save, for the caller to load as it loads anything (`Game.load`, `world.load`). */
export function rebuildWorld(world: World, next: Rebuild, install: (world: World) => void): WorldSave {
  const save = world.save();
  // The game's own code defined again: a data component's field it dropped is left out without a word (`WorldSave.swap`).
  save.swap = true;
  world.loop.reset();
  world.reset();
  install(world);
  next.registerSystems(world);
  world.build();
  return save;
}
