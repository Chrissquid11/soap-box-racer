/**
 * Introspection: the world read as a tool wants it -- names, trees, fields by
 * name (Docs/ecs.md §13). For the editor, `world.describe()` and the console.
 *
 * Everything here allocates and looks things up by name: never for a system,
 * never during a tick. It reads the stores directly, so it works on a paused
 * world.
 */
import { TICK_HZ } from '../loop/index.ts';
import { Hierarchy, layerName, Name, type AnyComponent, type Component, type Entity, type FieldType, type Relation, type Store } from './component.ts';
import type { World } from './world.ts';

type Links = Store<typeof Hierarchy.schema>;
const links = (world: World): Links => world.rawStore(Hierarchy) as Links;

/** What to call `e`: its `Name` if it has one, else what made it (`madeFromText`) and its index. */
export function label(world: World, e: Entity): string {
  const name = world.has(e, Name) ? (world.rawStore(Name) as { value: (string | null)[] }).value[e] : null;
  return name ?? `${madeFromText(world, e)} ${e}`;
}

/**
 * The prefab that made `e`, by key, and which entity of it `e` is -- its name
 * in the file, else its path there; null for the instance's root. Null for an
 * entity no prefab made. What a person is told an entity is: the kind the ECS
 * groups it by is its own business (Docs/prefabs.md §1).
 */
export function madeFrom(world: World, e: Entity): { prefab: string; node: string | null } | null {
  const p = world.prefabOf(e);
  if (!p) return null;
  const n = world.nodeOf(e);
  return { prefab: p.key, node: n <= 0 ? null : (p.names[n] ?? p.paths[n] ?? String(n)) };
}

/** `madeFrom` in words: `crates/big`, `crates/big · rider` for an entity inside one, `entity` for one no prefab made. */
export function madeFromText(world: World, e: Entity): string {
  const made = madeFrom(world, e);
  return made ? prefabText(made.prefab, made.node) : 'entity';
}

/** A prefab key and a node of it, as `madeFromText` says them; `entity` for no prefab. */
export const prefabText = (prefab: string | null, node: string | null): string => (prefab === null ? 'entity' : node === null ? prefab : `${prefab} · ${node}`);

/** Every living entity with no parent, in the roots' order (Docs/ecs.md §8). */
export function rootsOf(world: World): Entity[] {
  return world.roots();
}

/** Those of `es` alive, in the tree's order: down from each root in the roots' order, children in theirs, a parent before what is under it. */
export function inTreeOrder(world: World, es: readonly Entity[]): Entity[] {
  const l = links(world);
  const wanted = new Set(es);
  const out: Entity[] = [];
  for (let r = world.firstRoot as number; r !== 0 && out.length < wanted.size; r = l.nextSibling[r]!) {
    // Pre-order through the links, as the world walks a subtree.
    let n = r;
    for (;;) {
      if (wanted.has(n as Entity)) out.push(n as Entity);
      const child = l.firstChild[n]!;
      if (child !== 0) {
        n = child;
        continue;
      }
      while (n !== r && l.nextSibling[n] === 0) n = l.parent[n]!;
      if (n === r) break;
      n = l.nextSibling[n]!;
    }
  }
  return out;
}

/** `e`'s children, in order. */
export function childrenOf(world: World, e: Entity): Entity[] {
  const l = links(world);
  const out: Entity[] = [];
  for (let c = l.firstChild[e]!; c !== 0; c = l.nextSibling[c]!) out.push(c);
  return out;
}

/** `e`'s layer, named. */
export function layerOf(world: World, e: Entity): { layer: number; name: string } {
  const layer = world.layerOfEntity(e);
  return { layer, name: layerName(layer) };
}

/** The components on `e`, in the order they were defined; `Hierarchy`, which every entity has, left out. */
export function componentsOn(world: World, e: Entity): AnyComponent[] {
  return world.allComponents.filter((component) => component.bit >= 0 && world.has(e, component));
}

/** One field of a numeric component on one entity. */
export interface FieldValue {
  name: string;
  type: FieldType;
  value: number;
}

/** A numeric component's fields on `e`, with their values now. */
export function fieldsOf(world: World, e: Entity, component: Component): FieldValue[] {
  const store = world.rawStore(component) as Record<string, ArrayLike<number>>;
  return component.fields.map((field) => ({ name: field.name, type: field.type, value: store[field.name]![e]! }));
}

/** Sets one field of a numeric component on `e`. For a `Transform`, follow with `world.moved(e)` and `world.flush()`. */
export function writeField(world: World, e: Entity, component: Component, field: string, value: number): void {
  const column = (world.rawStore(component) as Record<string, number[]>)[field];
  if (!column) throw new Error(`[ecs] ${component.name} has no field '${field}': it has ${component.fields.map((f) => f.name).join(', ')}`);
  column[e] = value;
}

/** One end of a link, and the link's own data by field. */
export interface Link {
  /** The entity at the other end. */
  other: Entity;
  /** The link's row in the relation's store: where its data is written. */
  row: number;
  data: Record<string, number>;
}

/** `e`'s links of one relation: those going out of it, and those coming in. */
export function linksOf(world: World, e: Entity, relation: Relation<any>): { out: Link[]; into: Link[] } {
  const rows = world.rawStore(relation) as Record<string, ArrayLike<number>>;
  const data = (p: number): Record<string, number> => Object.fromEntries(relation.fields.map((field) => [field.name, rows[field.name]![p]!]));
  const out: Link[] = [];
  const into: Link[] = [];
  for (let p = rows.firstOut![e]!; p !== 0; p = rows.nextOut![p]!) out.push({ other: rows.target![p] as Entity, row: p, data: data(p) });
  for (let p = rows.firstIn![e]!; p !== 0; p = rows.nextIn![p]!) into.push({ other: rows.source![p] as Entity, row: p, data: data(p) });
  return { out, into };
}

/** Every relation `e` is at either end of. */
export function relationsOf(world: World, e: Entity): Relation<any>[] {
  return world.allComponents.filter((c): c is Relation<any> => c.kind === 'relation' && (linksOf(world, e, c).out.length > 0 || linksOf(world, e, c).into.length > 0));
}

/** A system `e` is in, and when it runs there. */
export interface Membership {
  system: string;
  /** Hz; 0 for a render system. */
  rate: number;
  /** Its slot: it runs on the ticks where `tick % period` is this. -1 for a render system. */
  slot: number;
  period: number;
}

/** The systems `e` is a member of, with its slot in each. */
export function membership(world: World, e: Entity): Membership[] {
  const mine = new Set(world.systemsOf(e));
  const out: Membership[] = [];
  for (const info of world.loop.info()) {
    if (!mine.has(info.name)) continue;
    if (info.phase !== 'simulation') out.push({ system: info.name, rate: 0, slot: -1, period: 0 });
    else {
      const period = TICK_HZ / info.rate;
      out.push({ system: info.name, rate: info.rate, slot: world.loop.slotOf(info.name, e) ?? -1, period });
    }
  }
  return out;
}
