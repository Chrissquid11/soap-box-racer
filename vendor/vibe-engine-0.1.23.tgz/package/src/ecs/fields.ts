/**
 * A component's fields as a file, the inspector and MCP see them (Docs/ecs.md §3, Docs/properties.md P1): each
 * field of its schema once -- a vector one name over its columns -- with what it says of itself (D8's label,
 * help, bounds, step, slider, hidden, readonly, group; an enum's names, flags' names, a key's kind).
 *
 * - **`fileFields(c)`**: the fields in order, a vector (`dir: vec3()`) one `FileField` over its three columns.
 * - **Vectors in files** (`foldVectors`, `fileEntry`, `unfoldEntry`): a file writes `"dir": [x, y, z]`; a column
 *   (`dirX`) is how code and the world hold it. A record of a file -- a prefab's `data`, an override's `set` -- is
 *   folded on the way out and read either way: `dirX` alone is still the column.
 * - **`clampTo(field, v)`**: a value the inspector or MCP writes, held to the field's `min`/`max` (never code's).
 * - **`fieldSchema(c)`**: each field's schema as MCP's `scene_entity` answers it.
 * - **`refMisfit(field, has)`**: why a typed ref (`ref(Health)`) cannot hold an entity, or null -- the inspector's,
 *   a drop's, MCP's and the prefab compile's one wording.
 *
 * Pure: no DOM, no three. Node tests import it.
 */
import type { ColumnSpec, Field } from './component.ts';

/** What a component, a relation or an event has that this reads. */
interface Fielded {
  readonly name: string;
  readonly schema: object;
  readonly fields: readonly ColumnSpec[];
}

/** One field as a file names it: a vector's one entry over its columns. */
export interface FileField {
  readonly name: string;
  readonly field: Field;
  /** Its columns in order: itself, or a vector's one an axis. */
  readonly columns: readonly ColumnSpec[];
  /** Set by systems as the game runs: never a prefab's, never an override. */
  readonly runtime: boolean;
}

const made = new WeakMap<object, readonly FileField[]>();

/** `c`'s fields as a file has them, in order: a vector field one, over its columns. */
export function fileFields(c: Fielded): readonly FileField[] {
  let out = made.get(c);
  if (out) return out;
  const list: FileField[] = [];
  const schema = c.schema as Record<string, Field>;
  for (const column of c.fields) {
    if (column.of !== undefined) {
      if (column.axis !== 0) continue;
      list.push({ name: column.of, field: schema[column.of]!, columns: c.fields.filter((x) => x.of === column.of), runtime: column.runtime === true });
    } else list.push({ name: column.name, field: schema[column.name] ?? { type: column.type, initial: column.initial }, columns: [column], runtime: column.runtime === true });
  }
  out = list;
  made.set(c, out);
  return out;
}

/** The field `name` names in `c` -- a field's name, or a vector's column (`dirX` is `dir`'s) -- or undefined. */
export function fileFieldOf(c: Fielded, name: string): FileField | undefined {
  const column = c.fields.find((x) => x.name === name);
  const of = column?.of ?? name;
  return fileFields(c).find((f) => f.name === of);
}

/** A name as a person reads it: `castShadow` is "Cast shadow", `clear_color` "Clear color", `fov` "Fov". */
export function spaced(name: string): string {
  const words = name.replace(/[_-]+/g, ' ').replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2').trim().toLowerCase();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

/** What the inspector calls a field: its `label`, else its name spaced. */
export const labelOf = (f: Pick<FileField, 'name' | 'field'>): string => f.field.label ?? spaced(f.name);

/** Each integer type's range. */
export const INT_RANGE: Partial<Record<string, readonly [number, number]>> = {
  i8: [-128, 127], u8: [0, 255], i16: [-32768, 32767], u16: [0, 65535],
  i32: [-2147483648, 2147483647], u32: [0, 4294967295],
};

/** A value the inspector or MCP writes into `field`, held to its `min` and `max` (code is never held to them). */
export function clampTo(field: Pick<Field, 'min' | 'max'>, v: number): number {
  if (field.min !== undefined && v < field.min) return field.min;
  if (field.max !== undefined && v > field.max) return field.max;
  return v;
}

/** A vector's axes as a file's text says them: `[x, y, z]`. */
const axesSaid = (n: number): string => `[${['x', 'y', 'z', 'w'].slice(0, n).join(', ')}]`;

/**
 * `record` -- a file's entries of `c`, by column (`{ dirX: 1, speed: 2 }`) -- with each vector whose any column is in
 * it written as one entry, every axis from `full` (`{ dir: [1, 0, 0], speed: 2 }`): an override of one axis is the
 * vector's, whole. In place; returns it.
 */
export function foldVectors<V>(c: Fielded, record: Record<string, V | number[]>, full: (column: string) => number): Record<string, V | number[]> {
  for (const f of fileFields(c)) {
    if (f.field.vec === undefined || !f.columns.some((x) => x.name in record)) continue;
    for (const x of f.columns) delete record[x.name];
    record[f.name] = f.columns.map((x) => full(x.name));
  }
  return record;
}

/** A file record's value for one column: its own entry, or its vector's (`dir: [x, y, z]`'s axis); undefined for none. */
export function fileEntry(c: Fielded, record: Readonly<Record<string, unknown>> | undefined, column: string): unknown {
  if (!record) return undefined;
  if (column in record) return record[column];
  const spec = c.fields.find((x) => x.name === column);
  if (spec?.of === undefined) return undefined;
  const v = record[spec.of];
  return Array.isArray(v) ? v[spec.axis!] : undefined;
}

/**
 * A file's entry `name: value` of `c` as the columns it sets: a field's own, or a vector's `[x, y, z]` an axis each
 * -- or why it does not fit (a vector given anything but its numbers). Null for no field of that name.
 */
export function unfoldEntry(c: Fielded, name: string, value: unknown): { column: string; value: unknown }[] | { error: string } | null {
  const f = fileFieldOf(c, name);
  if (!f) return null;
  if (f.field.vec === undefined || f.name !== name) return [{ column: name, value }];
  const n = f.field.vec;
  if (!Array.isArray(value) || value.length !== n || value.some((x) => typeof x !== 'number' || !Number.isFinite(x))) {
    return { error: `${c.name}.${name} is a vector, ${axesSaid(n)}: ${n} numbers, not ${JSON.stringify(value)}` };
  }
  return f.columns.map((x, i) => ({ column: x.name, value: value[i] }));
}

/** One field's schema, as `scene_entity` answers it beside the values. */
export interface FieldSchema {
  /** What it holds: a `number`, a yes or no, a name of `names`, names of `names`, a colour, a vector, an entity, an asset key, a model and its part (`mesh()`). */
  kind: 'number' | 'bool' | 'enum' | 'flags' | 'color' | 'colorA' | 'vector' | 'ref' | 'key' | 'mesh' | 'string' | 'list' | 'dict' | 'record';
  /** Its column type: `f32`, `u8` … */
  type: string;
  label: string;
  help?: string;
  /** An enum's or flags' names. */
  names?: string[];
  /** A vector's size. */
  size?: number;
  /** A key's kind: `Model`, `Material`, `Sfx`, `Prefab`, `Clip` … (a `mesh()`'s, `Model`). */
  keyKind?: string;
  /** A typed ref's components (`ref(Health, Collider)`): what an entity must have to be held. */
  needs?: string[];
  min?: number;
  max?: number;
  step?: number;
  slider?: true;
  hidden?: true;
  readonly?: true;
  runtime?: true;
  group?: string;
  /** A data component's (`ecs/data.ts`): a string's most characters, and whether it is a text area. */
  maxLength?: number;
  multiline?: true;
  /** A list's element (its `min` and `max` are its count's). */
  of?: FieldSchema;
  /** A dictionary's key and value. */
  key?: FieldSchema;
  value?: FieldSchema;
  /** A record's fields. */
  fields?: Record<string, FieldSchema>;
}

/** `c`'s fields' schemas, by the name a file and `scene_set` use (a vector's, not its columns'). */
export function fieldSchema(c: Fielded): Record<string, FieldSchema> {
  const out: Record<string, FieldSchema> = {};
  for (const f of fileFields(c)) {
    const d = f.field;
    const kind: FieldSchema['kind'] = d.ref ? 'ref' : d.mesh ? 'mesh' : d.key !== undefined ? 'key' : d.enum ? 'enum' : d.flags ? 'flags' : d.alpha ? 'colorA' : d.color ? 'color' : d.bool ? 'bool' : d.vec !== undefined ? 'vector' : 'number';
    const range = kind === 'number' || kind === 'vector' ? INT_RANGE[d.type] : undefined;
    const s: FieldSchema = { kind, type: d.type, label: labelOf(f) };
    if (d.help !== undefined) s.help = d.help;
    if (d.enum) s.names = [...d.enum];
    if (d.flags) s.names = [...d.flags];
    if (d.vec !== undefined) s.size = d.vec;
    if (d.key !== undefined) s.keyKind = d.key;
    if (d.needs) s.needs = [...d.needs];
    const min = d.min ?? range?.[0];
    const max = d.max ?? range?.[1];
    if (min !== undefined && (kind === 'number' || kind === 'vector')) s.min = min;
    if (max !== undefined && (kind === 'number' || kind === 'vector')) s.max = max;
    if (d.step !== undefined) s.step = d.step;
    if (d.slider) s.slider = true;
    if (d.hidden) s.hidden = true;
    if (d.readonly) s.readonly = true;
    if (f.runtime) s.runtime = true;
    if (d.group !== undefined) s.group = d.group;
    out[f.name] = s;
  }
  return out;
}


/** Names said as a list: `Health`, `Health and Collider`, `Health, Collider and Speed`. */
export const andList = (names: readonly string[]): string => (names.length < 2 ? (names[0] ?? '') : `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`);

/** What a ref of `field` takes, said: "an entity with Health", or "an entity" for an untyped one. */
export const refTakes = (field: Pick<Field, 'needs'>): string => (field.needs && field.needs.length > 0 ? `an entity with ${andList(field.needs)}` : 'an entity');

/**
 * Why a ref of `field` cannot point at an entity that has what `has` says (by component name) -- `"goblin 3 has no
 * Health: needs an entity with Health"`, `who` its name -- or null: it can. An untyped ref takes anyone.
 */
export function refMisfit(field: Pick<Field, 'needs'>, has: (component: string) => boolean, who = 'it'): string | null {
  const missing = (field.needs ?? []).filter((n) => !has(n));
  return missing.length === 0 ? null : `${who} has no ${andList(missing)}: needs ${refTakes(field)}`;
}
