/**
 * Components: what an entity's data is made of (Docs/ecs.md §2, §3).
 *
 *   component()        numbers, one typed array per field, indexed by entity (SoA). The default.
 *   tag()          no data: one bit.
 *   objectComponent()  one pooled JavaScript object per entity (AoS), for what is not a number.
 *   kind()         a named set of components to spawn together.
 *   relation()     a link from one entity to another, many to many, with data on the link.
 *   event()        something that happened: a row of numbers, read once by whoever listens.
 *   beginGeneration() / endGeneration()   a game module evaluated again: a name defined again takes its slot.
 *
 * All of them are module-level tokens, defined before the world is made: the
 * world allocates storage for every component defined so far. A token holds no
 * data; a system reaches data through the stores it is handed for the components it
 * declared, and everything else through `world.store(Component)`.
 *
 * Pure: no DOM, no three.
 */

import type { DataSchema } from './data.ts';

/** An entity: an index into every column, valid until the next tick boundary. Keep an `EntityRef` for longer. */
export type Entity = number & { readonly __entity: never };

/** A reference to an entity that can be kept: index and generation. `deref` gives the entity back, or `NONE` if it died. */
export type EntityRef = number & { readonly __ref: never };

/** Nobody: no entity has index 0, so an unset reference, a missing parent and a dead `deref` are all this. */
export const NONE = 0 as Entity;

/** No reference: what a `ref()` field holds until it is set. */
export const NO_REF = 0 as EntityRef;

export type FieldType = 'f32' | 'f64' | 'i8' | 'u8' | 'i16' | 'u16' | 'i32' | 'u32';

/**
 * How a field shows in the editor, and what the inspector and MCP's `scene_set` may write into it -- Unity's
 * attributes, in the maker (Docs/ecs.md §3): `f32(1, { min: 0, max: 10, slider: true, label: 'Speed' })`. Code
 * is never held to it: a system writes what it likes.
 */
export interface FieldOptions {
  /** The name shown; by default the field's own, spaced (`castShadow` is "Cast shadow"). */
  readonly label?: string;
  /** The tooltip: what it is, in a sentence. */
  readonly help?: string;
  /** The least the inspector and MCP write: a value under it is clamped to it (a vector's each number). */
  readonly min?: number;
  /** The most the inspector and MCP write: a value over it is clamped to it. */
  readonly max?: number;
  /** One press of an arrow key, and a scrub's rate: by default 1 for a whole number, 0.1 for a float. */
  readonly step?: number;
  /** A slider beside the number, from `min` to `max`: both must be given. */
  readonly slider?: boolean;
  /** Left out of the inspector (still in files, saves and MCP). */
  readonly hidden?: boolean;
  /** Shown in the inspector, never edited there; refused by MCP's `scene_set`. */
  readonly readonly?: boolean;
  /** A sub-heading the inspector shows it under, shared by every field after it that names the same group. */
  readonly group?: string;
}

/** One field of a numeric component: its storage type and the value a new row gets. `N` is what the column holds, to the compiler. */
export interface Field<N extends number = number> extends FieldOptions {
  readonly type: FieldType;
  readonly initial: number;
  /** Set by `ref()`: the column holds an `EntityRef`, not a count -- so a tool can show the entity, where a `u32` looks the same. */
  readonly ref?: true;
  /**
   * Set by `ref(Health, Collider)`: the components, by name, an entity must have for the inspector, a drop, MCP and a
   * prefab's file to point the ref at it (Docs/ecs.md §3). Code is never held to it: `deref` is as any ref's.
   */
  readonly needs?: readonly string[];
  /**
   * Set by `key(kind)`: the column holds an asset key of that kind (`'Model'`, `'Material'`, `'Clip'`)
   * as its id in the engine's intern table (`ecs/keys.ts`), 0 for none. Every file -- a prefab, a
   * save, an override, a clip -- writes the key's text, never the id (Docs/render.md §2).
   */
  readonly key?: string;
  /**
   * Set by `mesh()`: the key is a model's and may name one of its parts -- the column holds the interned `key#part`
   * (kind `Model`), as `Render.model` does; a file writes `{ "uid", "key", "part" }` (Docs/render.md §2).
   */
  readonly mesh?: true;
  /** Set by `color()` and `colorA()`: the column holds a colour, `0xRRGGBB` -- a tool shows a swatch. */
  readonly color?: true;
  /** Set by `colorA()`: the colour has alpha too, `0xRRGGBBAA` -- a file writes `"#rrggbbaa"`, a tool a swatch and a slider. */
  readonly alpha?: true;
  /** Set by `bool()`: the column holds a yes or no, 0 or 1 -- a tool shows a tick. Saved and written as the number. */
  readonly bool?: true;
  /** Set by `enumOf()`: the column holds an index into these names; every file writes the name. */
  readonly enum?: readonly string[];
  /** Set by `flagsOf()`: the column holds a bit for each of these names, the first the lowest; every file writes the names set. */
  readonly flags?: readonly string[];
  /** Set by `vec2/3/4()`: the field is this many columns, `<name>X`, `<name>Y` …; every file writes `[x, y, z]`. */
  readonly vec?: 2 | 3 | 4;
  /** A vector's starting numbers, one an axis. */
  readonly initials?: readonly number[];
  /** Never set: carries `N`. */
  readonly __holds?: N;
}

/** A field's options checked: a slider needs both bounds, and the bounds their order. Returns them as given. */
function checked(o: FieldOptions | undefined): FieldOptions {
  if (!o) return {};
  if (o.min !== undefined && o.max !== undefined && o.min > o.max) throw new Error(`[ecs] a field with min ${o.min} over its max ${o.max}`);
  if (o.slider && (o.min === undefined || o.max === undefined)) throw new Error('[ecs] a field with slider: true needs both min and max: { min: 0, max: 1, slider: true }');
  if (o.step !== undefined && !(o.step > 0)) throw new Error(`[ecs] a field's step is more than 0, not ${o.step}`);
  return o;
}

const field =
  (type: FieldType) =>
  (initial = 0, options?: FieldOptions): Field => ({ ...checked(options), type, initial });

/** A 32-bit float: the default for anything measured. */
export const f32 = field('f32');
/** A 64-bit float: for sums that must not lose precision. */
export const f64 = field('f64');
export const i8 = field('i8');
export const u8 = field('u8');
export const i16 = field('i16');
export const u16 = field('u16');
export const i32 = field('i32');
export const u32 = field('u32');
/** A yes or no, stored as 0 or 1. */
export const bool = (initial = false, options?: FieldOptions): Field & { readonly bool: true } => ({ ...checked(options), type: 'u8', initial: initial ? 1 : 0, bool: true });
/** What `ref()` is handed: the components an entity must have, then its options -- told apart by a token's `bit`. */
const isToken = (x: unknown): x is AnyComponent => typeof x === 'object' && x !== null && 'bit' in x && 'name' in x && 'kind' in x;

/**
 * A reference to another entity: holds an `EntityRef`, `NO_REF` until set. Read it through `deref`.
 *
 * Typed (Docs/ecs.md §3, Docs/properties.md D4): `ref(Health)` -- a reference to a component is a reference to an
 * entity that has it -- or `ref(Health, Collider)` for one with both, then the options as ever. The inspector shows
 * it as "Health on goblin 3", and the inspector, a drop, MCP's `scene_set` and a prefab's file take only an entity
 * with every one of them. Code reads it as any ref: `health.hp[deref(r)]`, the entity checked for `NONE`.
 *
 * ```ts
 * export const Aim = component('Aim', { at: ref(Health, { help: 'Whom it shoots at' }) });
 * ```
 */
export function ref(options?: FieldOptions): Field<EntityRef>;
export function ref(a: AnyComponent, options?: FieldOptions): Field<EntityRef>;
export function ref(a: AnyComponent, b: AnyComponent, options?: FieldOptions): Field<EntityRef>;
export function ref(a: AnyComponent, b: AnyComponent, c: AnyComponent, options?: FieldOptions): Field<EntityRef>;
export function ref(a: AnyComponent, b: AnyComponent, c: AnyComponent, d: AnyComponent, options?: FieldOptions): Field<EntityRef>;
export function ref(...given: readonly (AnyComponent | FieldOptions | undefined)[]): Field<EntityRef> {
  const needs: string[] = [];
  let options: FieldOptions | undefined;
  given.forEach((x, i) => {
    if (isToken(x)) {
      if (options !== undefined) throw new Error('[ecs] ref(): its options come last, after the components it needs: ref(Health, { label })');
      if (x.bit < 0) throw new Error(`[ecs] ref(): every entity has ${x.name}, so it needs saying of none`);
      if (!needs.includes(x.name)) needs.push(x.name);
    } else if (x !== undefined) {
      if (i !== given.length - 1) throw new Error('[ecs] ref(): its options come last, after the components it needs: ref(Health, { label })');
      options = x;
    }
  });
  return { ...checked(options), type: 'u32', initial: 0, ref: true, ...(needs.length > 0 ? { needs } : {}) };
}
/**
 * The kinds a `key()` field may hold: every kind of asset the project's pipeline has (`AssetKeys.KeyKind`, the
 * generated `keys.d.ts`: `Model`, `Texture`, `Material`, `Prefab`, `Scene`, `Level`, `Sfx`, `UiSfx`, `Music`, `Atlas`,
 * `Icon`, `Font` and the project's own data kinds), and `Clip` -- a name among a model's clips. Any other is a type
 * error naming these (`key()` takes it mapped, `{ [K in KeyKind]: K }[KeyKind]`, which the compiler spells out rather than naming the alias).
 */
export type KeyKind = AssetKeys.KeyKind | 'Clip';

/**
 * An asset key of `kind` (`'Model'`, `'Sfx'`, `'Prefab'`, `'Clip'` …: `KeyKind`): an `i32` holding the key's id in
 * the engine's intern table (`internKey`, `ecs/keys.ts`), 0 for none. A file writes `{ "uid", "key" }` (the key
 * alone where the asset has no uid), the compile and a load intern it; a system compares ids, or reads the text
 * with `keyText(kind, id)`. Docs/render.md §2.
 */
export const key = (kind: { [K in KeyKind]: K }[KeyKind], options?: FieldOptions): Field => ({ ...checked(options), type: 'i32', initial: 0, key: kind });

/**
 * A model and, if it says one, one of its parts (Docs/properties.md D6): the column holds the interned `key#part` --
 * kind `Model`, as `Render.model` holds it -- 0 for none, the whole model where no part is given. A file writes
 * `{ "uid", "key", "part" }` (and reads `"key#part"` too); the inspector is the model's picker and its part's; code
 * reads it with `meshOf(id)`: `{ model, part }`, or null for none.
 */
export const mesh = (options?: FieldOptions): Field => ({ ...checked(options), type: 'i32', initial: 0, key: 'Model', mesh: true });
/** A colour, `0xRRGGBB` (`u32`): white, `0xffffff`, by default. A tool shows it as a swatch. */
export const color = (initial = 0xffffff, options?: FieldOptions): Field => ({ ...checked(options), type: 'u32', initial, color: true });
/** A colour with alpha, `0xRRGGBBAA` (`u32`): opaque white, `0xffffffff`, by default. A file writes `"#rrggbbaa"`; a tool shows a swatch and an alpha slider. */
export const colorA = (initial = 0xffffffff, options?: FieldOptions): Field => ({ ...checked(options), type: 'u32', initial: initial >>> 0, color: true, alpha: true });

/** What a field's own properties are called: no name of an `enumOf` or a `flagsOf` may be one, since its constant sits beside them. */
const FIELD_PROPS = new Set(['as', 'type', 'initial', 'ref', 'needs', 'key', 'mesh', 'color', 'alpha', 'bool', 'enum', 'flags', 'vec', 'initials', '__holds', 'label', 'help', 'min', 'max', 'step', 'slider', 'hidden', 'readonly', 'group']);

function checkNames(what: string, names: readonly string[], most: number): void {
  if (names.length === 0) throw new Error(`[ecs] ${what} with no names`);
  if (names.length > most) throw new Error(`[ecs] ${what} with ${names.length} names: at most ${most}`);
  const seen = new Set<string>();
  for (const n of names) {
    if (typeof n !== 'string' || n === '') throw new Error(`[ecs] ${what}: a name is a word, not ${JSON.stringify(n)}`);
    if (seen.has(n)) throw new Error(`[ecs] ${what}: '${n}' named twice`);
    if (FIELD_PROPS.has(n)) throw new Error(`[ecs] ${what}: '${n}' is a field's own property, so it cannot be a name's constant -- call it something else`);
    // `__proto__` would be dropped, `toString`, `constructor` and the rest of an object's own would be shadowed.
    if (n in Object.prototype) throw new Error(`[ecs] ${what}: '${n}' is every object's own (${n === '__proto__' ? 'the prototype' : 'Object.prototype'}), so it cannot be a name's constant -- call it something else`);
    seen.add(n);
  }
}

/**
 * An enum field and its constants in one: a `u8` column (a `u16` past 256 names) holding an index into `names`,
 * and each name a property holding its index, for code to compare. A file and a save write the name.
 *
 * ```ts
 * export const Mood = enumOf(['idle', 'walk', 'run'], 'idle');
 * export const Brain = component('Brain', { mood: Mood });           // the field
 * if (brain.mood[e] === Mood.walk) { ... }                          // the constant: Mood.wlak is a compile error
 * export const Pet = component('Pet', { mood: Mood.as('run', { label: 'Feeling' }) });   // the same names, its own start
 * ```
 */
export type EnumField<N extends string> = Field & { readonly [K in N]: number } & {
  readonly enum: readonly N[];
  /** The same names as another field: its own initial and options. */
  as(initial?: NoInfer<N>, options?: FieldOptions): EnumField<N>;
};

export function enumOf<const N extends string>(names: readonly N[], initial: NoInfer<N> = names[0]!, options?: FieldOptions): EnumField<N> {
  checkNames('enumOf()', names, 65536);
  const at = names.indexOf(initial);
  if (at < 0) throw new Error(`[ecs] enumOf(): its initial '${String(initial)}' is none of its names (${names.join(', ')})`);
  const made: Record<string, unknown> = { ...checked(options), type: names.length > 256 ? 'u16' : 'u8', initial: at, enum: names };
  names.forEach((n, i) => void (made[n] = i));
  Object.defineProperty(made, 'as', { value: (again: N = initial, o?: FieldOptions) => enumOf(names, again, o ?? options), enumerable: false });
  return made as EnumField<N>;
}

/**
 * A set of yes-or-nos by name: a `u32` with a bit for each of `names` (at most 32), the first the lowest, and
 * each name a property holding its bit. A file writes the names set, `["fire", "ice"]`.
 *
 * ```ts
 * export const Element = flagsOf(['fire', 'ice', 'poison']);
 * export const Resist = component('Resist', { against: Element.as(['ice']) });
 * if ((resist.against[e] & Element.fire) !== 0) { ... }
 * ```
 */
export type FlagsField<N extends string> = Field & { readonly [K in N]: number } & {
  readonly flags: readonly N[];
  /** The same names as another field: its own set to start with, and options. */
  as(initial?: readonly NoInfer<N>[], options?: FieldOptions): FlagsField<N>;
};

export function flagsOf<const N extends string>(names: readonly N[], initial: readonly NoInfer<N>[] = [], options?: FieldOptions): FlagsField<N> {
  checkNames('flagsOf()', names, 32);
  let bits = 0;
  for (const n of initial) {
    const at = names.indexOf(n);
    if (at < 0) throw new Error(`[ecs] flagsOf(): its initial '${String(n)}' is none of its names (${names.join(', ')})`);
    bits = (bits | (2 ** at)) >>> 0;
  }
  const made: Record<string, unknown> = { ...checked(options), type: 'u32', initial: bits, flags: names };
  names.forEach((n, i) => void (made[n] = 2 ** i));
  Object.defineProperty(made, 'as', { value: (again: readonly N[] = initial, o?: FieldOptions) => flagsOf(names, again, o ?? options), enumerable: false });
  return made as FlagsField<N>;
}

/** A vector's options: a field's, and `f64` for 64-bit columns. */
export interface VecOptions extends FieldOptions {
  readonly f64?: boolean;
}

/** A vector field: `size` columns of one name, `<name>X`, `<name>Y`, `<name>Z`, `<name>W`. */
export interface VecField<V extends 2 | 3 | 4 = 2 | 3 | 4> extends Field {
  readonly vec: V;
  readonly initials: readonly number[];
}

/** What a vector's columns are called after its name: `dirX`, `dirY` … */
export const AXES = ['X', 'Y', 'Z', 'W'] as const;

const vec =
  <V extends 2 | 3 | 4>(size: V) =>
  (initial: number | readonly number[] = 0, options?: VecOptions): VecField<V> => {
    const initials = typeof initial === 'number' ? Array.from({ length: size }, () => initial) : [...initial];
    if (initials.length !== size || initials.some((n) => typeof n !== 'number' || !Number.isFinite(n))) throw new Error(`[ecs] vec${size}(): its initial is one number or ${size}, not ${JSON.stringify(initial)}`);
    const { f64: wide, ...rest } = options ?? {};
    return { ...checked(rest), type: wide ? 'f64' : 'f32', initial: initials[0]!, vec: size, initials };
  };

/**
 * Two, three or four numbers under one name (Docs/ecs.md §3): a column an axis, `<name>X`, `<name>Y`, `<name>Z`,
 * `<name>W` -- read `move.dirX[e]`, as every column is, so a system's loop and `parallel` are as ever. A file writes
 * `[x, y, z]`; the inspector shows one row. `f32` columns, or `{ f64: true }`.
 *
 * ```ts
 * export const Move = component('Move', { dir: vec3([0, 0, 1]), speed: f32(2) });
 * pos.px[e] += move.dirX[e] * move.speed[e] * dt;
 * ```
 */
export const vec2 = vec(2);
export const vec3 = vec(3);
export const vec4 = vec(4);

/** An entity index, for the hierarchy's own links: fixed up when an entity dies, so safe to hold there and nowhere else. */
const link = (): Field<Entity> => ({ type: 'u32', initial: 0 });

export type Schema = Readonly<Record<string, Field>>;

/** A writable column: a typed array, indexed by entity. */
export interface Column<N extends number = number> {
  [entity: number]: N;
  readonly length: number;
}

/** A column a system declared in `read`: the same array, with no way to assign through it. */
export interface ReadColumn<N extends number = number> {
  readonly [entity: number]: N;
  readonly length: number;
}

type Holds<F> = F extends Field<infer N> ? N : number;

/** A vector's axes, as its columns are suffixed. */
type Axes<V> = V extends 2 ? 'X' | 'Y' : V extends 3 ? 'X' | 'Y' | 'Z' : 'X' | 'Y' | 'Z' | 'W';
/** A field's columns: its own name, or a vector's one an axis (`dirX`, `dirY`, `dirZ`). */
type ColumnKey<K, F> = F extends { readonly vec: infer V } ? `${K & string}${Axes<V>}` : K;

/** A numeric component's store, writable: `store.x[e]` -- a vector field `dir` as `store.dirX[e]`, `store.dirY[e]` … */
export type Store<S extends Schema> = { readonly [K in keyof S as ColumnKey<K, S[K]>]: Column<Holds<S[K]>> };
/** A numeric component's store, read-only. */
export type ReadStore<S extends Schema> = { readonly [K in keyof S as ColumnKey<K, S[K]>]: ReadColumn<Holds<S[K]>> };
/** An object component's store: `store.value[e]`. */
export interface ObjectStore<T> {
  readonly value: T[];
  /** `e`'s object: `value[e]`, the same one each call -- a data component's, its entity's own. */
  get(e: Entity): T;
}
/** An object component's store in `read`: the object can still be changed, the slot cannot. */
export interface ReadObjectStore<T> {
  readonly value: readonly T[];
  /** `e`'s object: `value[e]`, never allocated by the read. */
  get(e: Entity): T;
}

interface Token<N extends string = string> {
  /** Its number among all components: its place in the world's tables. */
  readonly id: number;
  /** Unique. Its type is the literal the token was made with, so the compiler can check it against a prefab's entity (`init`). */
  readonly name: N;
  /** Its bit in an entity's mask; -1 for a component every entity has (`Hierarchy`). */
  readonly bit: number;
  /**
   * Where the inspector's Add Component menu lists it (`{ menu: 'Physics/Colliders' }`): a path of categories, `/`
   * between them. Left out, a game's component is under `Game`. Metadata only: no file or save says it.
   */
  readonly menu?: string;
  /** One line on what it is for: the Add Component menu's hover on its row. */
  readonly help?: string;
}

/** What every component maker takes besides its own options: where the Add Component menu lists it, and its line of help. */
export interface MenuOptions {
  /** A path of categories, `'Physics/Colliders'`: the inspector's Add Component menu. Left out, `Game`. */
  menu?: string;
  /** One line on what the component is for, shown on its row's hover. */
  help?: string;
}

/** `menu` and `help` as a token keeps them: only those said, a path's parts trimmed and empty ones dropped. */
export function menuOf(what: string, options: MenuOptions | undefined): { menu?: string; help?: string } {
  const out: { menu?: string; help?: string } = {};
  if (options?.menu !== undefined) {
    if (typeof options.menu !== 'string') throw new Error(`[ecs] ${what}: menu is a path of categories, 'Physics/Colliders'`);
    const path = options.menu.split('/').map((p) => p.trim()).filter((p) => p !== '');
    if (path.length > 0) out.menu = path.join('/');
  }
  if (options?.help !== undefined && options.help !== '') out.help = String(options.help);
  return out;
}

/**
 * One column of a numeric component, a relation or an event: what the world allocates. A field is one column, a
 * vector field (`vec3`) one an axis -- `of` its field's name, `axis` 0 for X.
 */
export interface ColumnSpec {
  readonly name: string;
  readonly type: FieldType;
  readonly initial: number;
  /** Set by systems as the game runs (`{ runtime: [...] }`): never written to a prefab, never an override. */
  readonly runtime?: true;
  /** A vector's column: the field it is an axis of. */
  readonly of?: string;
  readonly axis?: number;
}

/** A schema's columns, in order: a vector field's one an axis, after its name (`dirX`); `runtime` the fields systems set. */
function columnsOf(what: string, schema: Schema, runtime: readonly string[] = []): ColumnSpec[] {
  const out: ColumnSpec[] = [];
  for (const [name, f] of Object.entries(schema)) {
    const live = runtime.includes(name) ? { runtime: true as const } : {};
    if (f.vec === undefined) {
      out.push({ name, type: f.type, initial: f.initial, ...live });
      continue;
    }
    for (let axis = 0; axis < f.vec; axis++) {
      const column = `${name}${AXES[axis]}`;
      if (column in schema) throw new Error(`[ecs] ${what}: the vector '${name}' has a column '${column}', and so does a field of that name -- call one something else`);
      out.push({ name: column, type: f.type, initial: f.initials?.[axis] ?? f.initial, of: name, axis, ...live });
    }
  }
  return out;
}

/** A numeric component (SoA). */
export interface Component<S extends Schema = Schema, N extends string = string> extends Token<N> {
  readonly kind: 'data';
  /** Left out of a saved game: scratch data that is worked out again. */
  readonly transient: boolean;
  readonly schema: S;
  /**
   * Each column, in order -- a field's, or a vector field's one an axis (`dirX`: `of` 'dir', `axis` 0); `runtime` on
   * one systems set as the game runs (`{ runtime: [...] }`): never written to a prefab, never an override.
   */
  readonly fields: readonly ColumnSpec[];
}

/** A tag: a bit and nothing else. */
export interface Tag<N extends string = string> extends Token<N> {
  readonly kind: 'tag';
}

/** An object component (AoS): one object per entity, from a pool. */
export interface ObjectComponent<T = unknown, N extends string = string> extends Token<N> {
  readonly kind: 'object';
  /** Makes one. The only place this component allocates; without it the slot is `null` until something is put there. */
  readonly create: (() => T) | null;
  /** Called on an object on its way back to the pool. */
  readonly reset: ((value: T) => void) | null;
  /** How many to make up front. */
  readonly pool: number;
  /** An object as plain data for a saved game, and a saved one put back. Without both, the component is not saved. */
  readonly save: ((value: T) => unknown) | null;
  readonly load: ((data: any, value: T) => T | void) | null;
  /** A data component's schema (`dataComponent`, `ecs/data.ts`): its value's shape, which every file, tool and save reads. */
  readonly data?: DataSchema;
}

/**
 * A relation: links from one entity to others, each with its own data. An
 * entity "has" the relation, for `with` and `read`, while it has at least one
 * link going out.
 */
export interface Relation<S extends Schema = Schema> extends Token {
  readonly kind: 'relation';
  readonly schema: S;
  readonly fields: readonly ColumnSpec[];
  /** At most one link out of each entity: a new one replaces the old. */
  readonly exclusive: boolean;
}

/** An event type: `world.events(Hit)` is its channel in a world. */
export interface EventType<S extends Schema = Schema> {
  readonly id: number;
  readonly name: string;
  readonly schema: S;
  readonly fields: readonly ColumnSpec[];
}

export type AnyComponent = Component<any> | Tag | ObjectComponent<any> | Relation<any>;
/** A component with a store: what `read` and `write` take. */
export type DataComponent = Component<any> | ObjectComponent<any> | Relation<any>;

/** The links of a relation, as every store of one has them. Index 0 is "no link". */
interface Links {
  /** A link's two ends. */
  readonly source: ReadColumn<Entity>;
  readonly target: ReadColumn<Entity>;
  /** An entity's first link out, and the next after a link: `for (let p = r.firstOut[e]; p !== 0; p = r.nextOut[p])`. */
  readonly firstOut: ReadColumn;
  readonly nextOut: ReadColumn;
  /** An entity's first link in, and the next: who points at `e`. */
  readonly firstIn: ReadColumn;
  readonly nextIn: ReadColumn;
}

/** A relation's store, its links' data writable: `likes.weight[p]`. */
export type RelationStore<S extends Schema> = Store<S> & Links;
/** A relation's store, read-only. */
export type ReadRelationStore<S extends Schema> = ReadStore<S> & Links;

/** `optional(Component)`: the store without requiring the component on the entity. */
export interface Optional<T extends DataComponent = DataComponent> {
  readonly optional: T;
}

/** What `read` and `write` list. */
export type Access = DataComponent | Optional;

/**
 * In `read` or `write`: hand over the store without requiring the component on the
 * entity. It is how a system reaches another entity's data -- `read: [Aim,
 * optional(Health)]`, then `health.hp[target]`.
 */
export function optional<T extends DataComponent>(component: T): Optional<T> {
  return { optional: component };
}

type WriteOf<A> =
  A extends Optional<infer T> ? WriteOf<T>
  : A extends Component<infer S> ? Store<S>
  : A extends ObjectComponent<infer T> ? ObjectStore<T>
  : A extends Relation<infer S> ? RelationStore<S>
  : never;
type ReadOf<A> =
  A extends Optional<infer T> ? ReadOf<T>
  : A extends Component<infer S> ? ReadStore<S>
  : A extends ObjectComponent<infer T> ? ReadObjectStore<T>
  : A extends Relation<infer S> ? ReadRelationStore<S>
  : never;

/** The stores for a `write` list, in its order. */
export type Writes<L extends readonly Access[]> = { readonly [I in keyof L]: WriteOf<L[I]> };
/** The stores for a `read` list, in its order. */
export type Reads<L extends readonly Access[]> = { readonly [I in keyof L]: ReadOf<L[I]> };
/** The writable store of one component: what `world.store`, `add` and `init` return. */
export type StoreOf<T> =
  T extends Component<infer S> ? Store<S>
  : T extends ObjectComponent<infer V> ? ObjectStore<V>
  : T extends Relation<infer S> ? RelationStore<S>
  : undefined;

/**
 * An event type's channel in one world: its fields as columns, indexed by event.
 *
 * ```ts
 * const i = hits.emit();                 // a writer
 * hits.target[i] = ref(e);
 *
 * for (let i = hits.begin(ctx); i < hits.end; i++) { ... hits.target[i] ... }   // a reader
 * ```
 */
export type Channel<S extends Schema> = Store<S> & {
  /** The tick each event was emitted on. */
  readonly tick: ReadColumn;
  /** One past the last event a reader may see: those emitted before this tick. */
  readonly end: number;
  /** A new event, its fields at their defaults; returns its index to fill them in. 0, a scratch row, if the channel is full. */
  emit(): number;
  /** The first event the calling system has not seen: pass its context. Loop from here to `end`. */
  begin(ctx: { readonly tick: number; readonly period?: number; readonly staggered?: boolean; readonly since?: number }): number;
};

/** A named set of components to spawn together, and the unit ids are balanced by (Docs/ecs.md §4). */
export interface Kind {
  readonly id: number;
  readonly name: string;
  readonly components: readonly AnyComponent[];
}

// ── the registry ────────────────────────────────────────────────────────

const components: AnyComponent[] = [];
const kinds: Kind[] = [];
let bits = 0;

// ── generations ─────────────────────────────────────────────────────────
//
// A game module evaluated again (its file changed in the dev server) runs its
// `component('Spin', …)` once more. Between `beginGeneration()` and
// `endGeneration()` that is no duplicate: the new definition takes the old
// one's slot -- same id, same bit -- so a world made afterwards has the same
// layout with the new schema, and a world made before keeps its own copy of
// the list. Vite evaluates the new modules before its accept callback runs, so
// the generation is opened ahead of them (`vite:beforeUpdate`) and closed on
// `vite:afterUpdate`, once per batch, before the one rebuild (the header of
// `live-game.ts`, the game's hot-update boundary's code, says the order).

/**
 * What a generation did: names defined again, names new in it, and names an
 * earlier generation defined that this one did not. A name is listed once for
 * each registry it was registered in: a component and an event may share a
 * name, and such a name defined again appears twice in `redefined`.
 */
export interface GenerationChange {
  readonly redefined: readonly string[];
  readonly added: readonly string[];
  readonly kept: readonly string[];
}

type Registry = 'component' | 'event';

/** An open generation: the names registered in it, a set a registry (an event may share a component's name), and the tokens it replaced, by id. */
interface Generation {
  names: Record<Registry, Set<string>>;
  redefined: string[];
  added: string[];
  replaced: Map<number, AnyComponent>;
}

/** The open generation, null while none is. */
let generation: Generation | null = null;
/**
 * Every name ever registered inside a generation, a set a registry: what `kept`
 * is worked out from. A name in it that the open generation did not register
 * was dropped from the game's code, or sits in a module Vite did not evaluate
 * again (an update re-evaluates only the changed module's chain): the registry
 * cannot tell which.
 */
const generationNames: Record<Registry, Set<string>> = { component: new Set(), event: new Set() };

/** Opens a generation: until `endGeneration()`, a component or event defined again takes its old slot. */
export function beginGeneration(): void {
  if (generation) throw new Error('[ecs] beginGeneration() while a generation is open');
  generation = { names: { component: new Set(), event: new Set() }, redefined: [], added: [], replaced: new Map() };
}

/** Whether a generation is open: `pool()` and `prefab()` ask. */
export const generationOpen = (): boolean => generation !== null;

/**
 * Closes the generation: every kind that listed a token defined again lists
 * the new one (the prefab compile compares tokens by identity), and says what
 * changed. `kept` is the names earlier generations registered that this one did
 * not: a component the game's code dropped, or one in a module that was not
 * evaluated again -- a Vite update re-evaluates only the changed module's chain
 * up to its boundary, so an edit to one system lists `components.ts`'s names
 * here though nothing dropped them. The registry cannot tell the two apart, so
 * a swap reports only `redefined` and `added`; a name dropped stays defined (its
 * column in the next world, harmless) until a reload. The caller decides what
 * to say of `kept`.
 */
export function endGeneration(): GenerationChange {
  const open = generation;
  if (!open) throw new Error('[ecs] endGeneration() with no generation open');
  generation = null;
  if (open.replaced.size > 0) {
    for (const k of kinds) {
      // A kind's list is read-only to everyone else; the registry that made it is the one place that swaps a token in it.
      // A kind made inside the generation already lists the new tokens: the swap leaves it as it is.
      const list = k.components as AnyComponent[];
      for (let i = 0; i < list.length; i++) list[i] = open.replaced.get(list[i]!.id) ?? list[i]!;
    }
  }
  const kept: string[] = [];
  for (const r of ['component', 'event'] as const) {
    for (const n of generationNames[r]) if (!open.names[r].has(n)) kept.push(n);
    for (const n of open.names[r]) generationNames[r].add(n);
  }
  return { redefined: open.redefined, added: open.added, kept };
}

/** A name defined in the open generation: a second definition in it is a real duplicate. */
function noteInGeneration(name: string, registry: Registry, existed: boolean): void {
  const open = generation!;
  if (open.names[registry].has(name)) throw new Error(`[ecs] ${registry === 'event' ? 'an event' : 'a component'} called '${name}' is defined twice in one generation: ${registry} names are unique`);
  open.names[registry].add(name);
  (existed ? open.redefined : open.added).push(name);
}

function register<T extends AnyComponent>(make: (id: number, bit: number) => T, name: string, bit?: number): T {
  if (!name) throw new Error('[ecs] a component needs a name: component(\'Velocity\', { ... })');
  const old = components.find((t) => t.name === name);
  if (old && !generation) throw new Error(`[ecs] a component called '${name}' is already defined: component names are unique`);
  if (generation) noteInGeneration(name, 'component', old !== undefined);
  if (old) {
    // Its slot and its bit: a redefinition takes no new bit.
    const again = make(old.id, old.bit);
    components[old.id] = again;
    generation!.replaced.set(old.id, again);
    return again;
  }
  const made = make(components.length, bit ?? bits++);
  components.push(made);
  return made;
}

/**
 * A numeric component: one typed array per field, indexed by entity.
 *
 * ```ts
 * export const Velocity = component('Velocity', { x: f32(), y: f32(), z: f32() });
 * export const Health = component('Health', { hp: f32(100), max: f32(100) });
 * ```
 *
 * `{ transient: true }` leaves it out of a saved game: for scratch data a system
 * works out again.
 *
 * `{ runtime: ['tx', 'tz'] }` (or `true`, every field) marks what systems set as
 * the game runs -- where a wanderer is heading, a spin's angle -- rather than
 * what a designer authors: kept in a saved game, but never written to a prefab
 * and never an override, and shown dimmed in the editor on an opened prefab
 * (Docs/ecs.md §3).
 *
 * `{ menu: 'Physics/Colliders', help: 'A box-shaped collider' }` says where the inspector's Add Component menu lists
 * it, and its row's hover; left out, a game's component is under `Game`. `objectComponent` and `dataComponent` take
 * the same two. Metadata only: no file or save says either.
 */
export function component<const S extends Schema, const N extends string = string>(
  name: N,
  schema: S,
  options: { transient?: boolean; runtime?: true | readonly (keyof S & string)[] } & MenuOptions = {},
): Component<S, N> {
  const runtime = options.runtime === true ? Object.keys(schema) : (options.runtime ?? []);
  for (const f of runtime) if (!(f in schema)) throw new Error(`[ecs] component '${name}': runtime names '${f}', which is none of its fields`);
  const fields = columnsOf(`component '${name}'`, schema, runtime as readonly string[]);
  if (fields.length === 0) throw new Error(`[ecs] component '${name}' has no fields: a component with no data is a tag('${name}')`);
  const listed = menuOf(`component '${name}'`, options);
  return register((id, bit) => ({ kind: 'data', id, bit, name, transient: options.transient ?? false, schema, fields, ...listed }), name);
}

/** A tag: `with: [Enemy]`, `without: [Frozen]`, `ctx.has(e, Enemy)`. */
export function tag<const N extends string>(name: N): Tag<N> {
  return register((id, bit) => ({ kind: 'tag', id, bit, name }), name);
}

export interface ObjectComponentOptions<T> extends MenuOptions {
  /** Makes one. Called when the pool is dry: the only place this component allocates. */
  create: () => T;
  /** Clears one on its way back to the pool. */
  reset?: (value: T) => void;
  /** How many to make up front. Default 0. */
  pool?: number;
  /** For a saved game: an object as plain data (what `JSON.stringify` takes). With `load`, the component is saved. */
  save?: (value: T) => unknown;
  /** A saved one put back into `value`, a fresh object from the pool; or return a replacement. */
  load?: (data: any, value: T) => T | void;
  /** Set by `dataComponent` alone: the schema it was made from, the fields systems fill, and whether it is saved at all. */
  data?: DataSchema;
  runtime?: readonly string[];
  transient?: boolean;
}

/**
 * An object component: one object per entity, pooled. For what is not a number --
 * text, a list, a handle to something outside the ECS.
 *
 * ```ts
 * export const Inventory = objectComponent('Inventory', {
 *   create: () => ({ items: [] as string[] }),
 *   reset: (inv) => { inv.items.length = 0; },
 *   pool: 32,
 * });
 * ```
 *
 * Without options the slot holds whatever is put there, `null` until then: for
 * an object made elsewhere (`View` holds a three.js object this way).
 */
export function objectComponent<T, const N extends string = string>(name: N, options: ObjectComponentOptions<T>): ObjectComponent<T, N>;
export function objectComponent<T, const N extends string = string>(name: N, options?: MenuOptions): ObjectComponent<T | null, N>;
export function objectComponent<T, const N extends string = string>(name: N, options?: ObjectComponentOptions<T> | MenuOptions): ObjectComponent<T, N> {
  const listed = menuOf(`objectComponent '${name}'`, options);
  const o = options as Partial<ObjectComponentOptions<T>> | undefined;
  return register(
    (id, bit) => ({ ...listed, kind: 'object', id, bit, name, create: o?.create ?? null, reset: o?.reset ?? null, pool: o?.pool ?? 0, save: o?.save ?? null, load: o?.load ?? null, ...(o?.data ? { data: o.data, runtime: o.runtime ?? [], transient: o.transient ?? false } : {}) }),
    name,
  );
}

/** Names a relation's own columns use: a field may not take one. */
const LINK_NAMES = ['source', 'target', 'firstOut', 'nextOut', 'prevOut', 'firstIn', 'nextIn', 'prevIn'];

/**
 * A relation: links from one entity to others, many to many, each link with
 * its own data. For "who likes whom", "what is carrying what", "which squad":
 * anything a single `ref()` field cannot say because there are several, or
 * because the other end needs to find them too.
 *
 * ```ts
 * export const Likes = relation('Likes', { much: f32(1) });
 * export const Carries = relation('Carries', {}, { exclusive: true });   // one target at most
 *
 * const p = cmd.relate(a, Likes, b);              // a link, from the boundary on; its data now
 * likes.much[p] = 3;
 * cmd.unrelate(a, Likes, b);
 *
 * for (let p = likes.firstOut[a]; p !== 0; p = likes.nextOut[p]) { const whom = likes.target[p]; }
 * for (let p = likes.firstIn[b]; p !== 0; p = likes.nextIn[p]) { const who = likes.source[p]; }
 * ```
 *
 * A link dies with either end. `with: [Likes]` is "has at least one link out".
 */
export function relation<const S extends Schema>(name: string, schema: S = {} as S, options: { exclusive?: boolean } = {}): Relation<S> {
  const fields = columnsOf(`relation '${name}'`, schema);
  for (const field of fields) if (LINK_NAMES.includes(field.name)) throw new Error(`[ecs] relation '${name}' has a field called '${field.name}', which is one of its own columns: call it something else`);
  return register((id, bit) => ({ kind: 'relation', id, bit, name, schema, fields, exclusive: options.exclusive ?? false }), name);
}

const events: EventType<any>[] = [];

/**
 * An event type: something that happened, as a row of numbers. Emitted by one
 * system, read by any number, each seeing every event once.
 *
 * ```ts
 * export const Hit = event('Hit', { target: ref(), damage: f32() });
 *
 * const hits = world.events(Hit);        // once, where the system is registered
 * ```
 *
 * Events emitted on a tick are seen from the next one on, whatever order the
 * systems run in. Docs/ecs.md §18.
 */
export function event<const S extends Schema>(name: string, schema: S = {} as S): EventType<S> {
  const old = events.find((e) => e.name === name);
  if (old && !generation) throw new Error(`[ecs] an event called '${name}' is already defined: event names are unique`);
  const fields = columnsOf(`event '${name}'`, schema);
  for (const field of fields) if (['tick', 'end', 'emit', 'begin'].includes(field.name)) throw new Error(`[ecs] event '${name}' has a field called '${field.name}', which every channel has already: call it something else`);
  if (generation) noteInGeneration(name, 'event', old !== undefined);
  const made: EventType<S> = { id: old ? old.id : events.length, name, schema, fields };
  if (old) events[old.id] = made;
  else events.push(made);
  return made;
}

/**
 * A kind: the components an entity starts with, under a name. The engine's:
 * prefabs make them (Docs/prefabs.md §3), and the ECS's own tests and fixtures
 * define them; a game writes a prefab file instead.
 *
 * ```ts
 * export const Bullet = kind('Bullet', [Transform, Velocity]);
 * const e = cmd.spawn(Bullet);
 * ```
 */
export function kind(name: string, list: readonly AnyComponent[]): Kind {
  // In a generation, a kind made again is a newer one of the name, as `kindAgain` makes.
  if (!generation && kinds.some((k) => k.name === name)) throw new Error(`[ecs] a kind called '${name}' is already defined: kind names are unique`);
  return makeKind(name, list);
}

/**
 * A kind of a name already made, with other components: debug builds' live
 * recompile of a prefab whose node changed what it is made of
 * (Docs/prefabs.md §7, §8) -- the editor's alone, so a release has none of it.
 * The name stays the node's path, which is what a save and a paste find a node
 * by; the newest kind of a name is the one a load and the next compile take
 * (`kindNamed`), and entities of the one before keep it until they die.
 */
export function kindAgain(name: string, list: readonly AnyComponent[]): Kind {
  if (!kinds.some((k) => k.name === name)) throw new Error(`[ecs] kindAgain('${name}'): no kind of that name yet -- kind() makes the first`);
  return makeKind(name, list);
}

/** The newest kind called `name`: `kindAgain` may have made more than one. */
export function kindNamed(name: string): Kind | undefined {
  for (let k = kinds.length - 1; k >= 0; k--) if (kinds[k]!.name === name) return kinds[k];
  return undefined;
}

function makeKind(name: string, list: readonly AnyComponent[]): Kind {
  for (const t of list) {
    if (t.bit < 0) throw new Error(`[ecs] kind '${name}' lists ${t.name}, which every entity has already: leave it out`);
    if (t.kind === 'relation') throw new Error(`[ecs] kind '${name}' lists the relation ${t.name}: a relation needs a target, so it is made with relate(e, ${t.name}, target) after spawning`);
    if (t.name === 'WorldTransform') throw new Error(`[ecs] kind '${name}' lists WorldTransform: it comes with Transform, list that`);
  }
  const made: Kind = { id: kinds.length, name, components: [...new Set(list)] };
  kinds.push(made);
  return made;
}

/** Every component defined so far, by id. */
export const allComponents = (): readonly AnyComponent[] => components;
/** Every kind defined so far, by id. */
export const allKinds = (): readonly Kind[] => kinds;
/** How many mask bits the components defined so far use. */
export const maskBits = (): number => bits;

// ── built in ────────────────────────────────────────────────────────────

/** What a bare `spawn()` makes: an entity with no components yet. */
export const Bare = kind('Bare', []);

/**
 * An entity's place in the tree: every entity has it. Read it by declaring
 * `read: [Hierarchy]`; it changes only through `setParent`.
 *
 * ```ts
 * for (let c = hier.firstChild[e]; c !== NONE; c = hier.nextSibling[c]) { ... }
 * ```
 */
export const Hierarchy = register(
  (id, bit) => {
    const schema = { parent: link(), firstChild: link(), lastChild: link(), nextSibling: link(), prevSibling: link(), depth: u8() };
    const fields = Object.entries(schema).map(([name, { type, initial }]) => ({ name, type, initial }));
    return { kind: 'data', id, bit, name: 'Hierarchy', transient: true, schema, fields } satisfies Component<typeof schema>;
  },
  'Hierarchy',
  -1,
);

/** Where an entity is, relative to its parent: position, rotation (a quaternion), scale. Written by 60 Hz systems. */
export const Transform = component('Transform', {
  px: f32(), py: f32(), pz: f32(),
  qx: f32(), qy: f32(), qz: f32(), qw: f32(1),
  sx: f32(1), sy: f32(1), sz: f32(1),
}, { menu: 'General', help: 'Where it is, relative to its parent: position, rotation, scale' });

/**
 * Where an entity is in the world, worked out from `Transform` and the
 * hierarchy once a tick (Docs/ecs.md §8). Every entity with a `Transform` has
 * it; nothing but propagation writes it. `changed` is the last tick it moved
 * on. Where it was a tick ago is the world's own business: `world.writeMatrix`
 * blends the two for drawing.
 */
export const WorldTransform = register(
  (id, bit) => {
    const schema = {
      px: f32(), py: f32(), pz: f32(),
      qx: f32(), qy: f32(), qz: f32(), qw: f32(1),
      sx: f32(1), sy: f32(1), sz: f32(1),
      changed: i32(-9),
    };
    const fields = Object.entries(schema).map(([name, { type, initial }]) => ({ name, type, initial }));
    return { kind: 'data', id, bit, name: 'WorldTransform', transient: true, schema, fields } satisfies Component<typeof schema>;
  },
  'WorldTransform',
  Transform.bit,
);

/** A name for the editor's tree and `world.describe()`. Optional: an entity without one shows its id. */
export const Name = objectComponent<string, 'Name'>('Name', { menu: 'General', help: 'A name for the tree: the inspector\'s title renames it' });

/**
 * Switched off: the entity and everything under it are in no system, and not
 * drawn, until it is taken off again. Data stays. A system that wants the
 * switched-off too says `includeDisabled: true`.
 */
export const Disabled = tag('Disabled');

/** Not drawn, the entity and everything under it; still simulated. */
export const Hidden = tag('Hidden');

/**
 * Not picked in the editor's scene -- a click or a box goes through it to what
 * is behind -- the entity and everything under it; still drawn and simulated,
 * and selected from the tree as ever. The editor's alone: the game never reads
 * it, and a scene keeps it.
 */
export const Unpickable = tag('Unpickable');

/**
 * Every entity's layer, 0 to 31: a number a system or a query can filter by
 * (`layers: [2, 3]`), and what three's object layers are set from. Names for
 * the editor come from `layers([...])`.
 */
export const Layer = register(
  (id, bit) => {
    const schema = { id: u8() };
    const fields = Object.entries(schema).map(([name, { type, initial }]) => ({ name, type, initial }));
    return { kind: 'data', id, bit, name: 'Layer', transient: true, schema, fields } satisfies Component<typeof schema>;
  },
  'Layer',
  -1,
);

/**
 * Where an entity came from (Docs/prefabs.md §4): every entity has the column,
 * as it has `Layer`. `prefab` is the compiled prefab's id (0: none), `node` its
 * entity of it, `root` the instance's root; `next` chains an instance's
 * entities from the root, which is how `part()` finds one without a table.
 * Saved by prefab key (`world.save`), not by id.
 */
export const Instance = register(
  (id, bit) => {
    const schema = { prefab: u32(), node: u16(), root: u32(), next: u32() };
    const fields = Object.entries(schema).map(([name, { type, initial }]) => ({ name, type, initial }));
    return { kind: 'data', id, bit, name: 'Instance', transient: true, schema, fields } satisfies Component<typeof schema>;
  },
  'Instance',
  -1,
);

/** Free text on an entity, any number of them, for the editor's filter and a game's own tools: saved. Systems query by `tag()`s, not these. */
export const Labels = objectComponent<string[], 'Labels'>('Labels', {
  create: () => [],
  // Emptied by `pop`, which keeps the list's room: `length = 0` hands V8's backing store back, and the next
  // load would allocate a new one. A prefab's labels are loaded on every instance, so neither may allocate.
  reset: (list) => {
    while (list.length > 0) list.pop();
  },
  save: (list) => list.slice(),
  // Into the pooled list, by index: no spread, nothing made.
  load: (saved: string[], list) => {
    while (list.length > saved.length) list.pop();
    for (let i = 0; i < saved.length; i++) list[i] = saved[i]!;
  },
});

let layerNames: string[] = ['Default'];

/** Names for the layers, in order from 0: what the editor shows. `layers(['Default', 'Ground', 'Enemies'])`. */
export function layers(names: readonly string[]): void {
  if (names.length > 32) throw new Error(`[ecs] layers(): ${names.length} names, and there are 32 layers`);
  layerNames = [...names];
}

/** A layer's name, or its number as text if it has none. */
export function layerName(layer: number): string {
  return layerNames[layer] ?? String(layer);
}

/** Every named layer, in order. */
export const allLayers = (): readonly string[] => layerNames;
