/**
 * What an instance changed from its prefab, and an instance brought to its
 * prefab as compiled now (Docs/prefabs.md §6, §7, §9).
 *
 * - **`overridesOf(world, root)`**: every difference of a live instance from
 *   the prefab it was made from, per entity (by its node's id path, through
 *   nesting), in the override format of the file (§2) -- fields (`set`,
 *   compared by type as the writer compares: an `f32` as the 32-bit float, any
 *   other exactly), components added and removed, switched off and on, the
 *   layer, the name, objects, refs inside the instance, an inner entity under
 *   another of it, a link's data -- with entities of the prefab gone
 *   (`removed`) and entities put under it that are none of it (`added`).
 *   Runtime fields never count. Each difference says which prefabs could
 *   hold it (`owners`): the innermost whose file makes the entity, and every
 *   one out that nests it -- what Apply offers. What no override can say (a
 *   new link, a ref out of the instance or cleared, a name taken off, an
 *   entity moved out) is said in `notes`, never guessed. Worked out, never
 *   tracked; one table a compiled prefab, built at its first call, so a call
 *   on an instance that changed nothing allocates only its answer.
 * - **`fitInstance`**: an instance brought to `now` wherever it holds no
 *   override -- values, components gained and lost, switches, layer, name,
 *   refs and parents inside it, objects, links -- and the entities `now` has
 *   that it lacks made (not those an override removed). The one rule behind
 *   both of the next two.
 * - **The live update** (`pendingUpdates`, then `applyUpdates` after the
 *   compile): every instance of a prefab compiled anew, out in the world --
 *   its overrides worked out against the compile it was made from, then each
 *   entity found again in the new one by its node's path (`refindNodes`: an
 *   id renamed under the same name is one node), the lost destroyed (what of
 *   the world is under one moved up to what stays; an override on one dropped
 *   and said), a link the prefab no longer makes let go of, the rest fitted. The editor's alone (a release never
 *   recompiles).
 * - **A scene or a level** (`sceneSave`): `world.save()` with each instance's
 *   overrides (`instances.overrides`), and its load (`refreshInstances`, after
 *   `world.load`): every instance fitted to its prefab as compiled now, so a
 *   prefab edit reaches every level without opening it. A save without them
 *   -- a game saved at runtime, an undo step -- plays back as it was.
 *
 * No glob, no three, no DOM: node tests it (`overrides.test.ts`).
 */
import { allComponents, Hierarchy, Instance, Name, NO_REF, NONE, Transform, type AnyComponent, type Component, type Entity, type EntityRef, type FieldType, type Relation } from './component.ts';
import { compiledPrefab, isOutsideRef, pathInOwner, refindNodes, type CompiledPrefab, type FileValue, type OutsideRef, type Override, type PrefabOwner } from './prefab.ts';
import { fileEntry, foldVectors } from './fields.ts';
import { fieldText } from './keys.ts';
import { dataDefault, dataPlain, eachRef, fromPlain, isData, mapFields, mapRefs, rawOut, type DataComponentOf, type Element } from './data.ts';
import { followSavedPrefabs, type World, type WorldSave } from './world.ts';

/** A component by its name, among every one defined. */
const componentNamed = (name: string): AnyComponent | undefined => allComponents().find((c) => c.name === name);

/** Equal as the column holds them: an `f32` as 32-bit floats, an integer or an `f64` exactly. */
export const same = (a: number, b: number, type: FieldType | string): boolean => (type === 'f32' ? Math.fround(a) === Math.fround(b) : a === b);

/** A rotation's four, as `Transform` names them. */
const TURN = ['qx', 'qy', 'qz', 'qw'] as const;
/** Four of 32 bits' steps: a unit quaternion's numbers this close are one rotation (the gizmo's `settledRotation`). */
const TURN_STEP = 4 * 2 ** -23;

/**
 * `Transform`'s rotation taken out of `set` where it is the one the prefab
 * gives (`then`, by field index) as a rotation -- the same numbers, or all
 * four negated (q and -q turn alike: a full turn of the gizmo comes back so),
 * to a few 32-bit steps. Compared by the numbers alone, a turn back to where
 * it began would list as `x 0 → 0°, y 0 → 0°, z 0 → 0°`.
 */
function sameTurnDropped(set: NonNullable<Override['set']>, columns: Record<string, { [i: number]: number }>, e: number, then: (field: number) => number | null): void {
  const own = set.Transform!;
  if (!TURN.some((f) => f in own)) return;
  const fields = Transform.fields.map((f) => f.name);
  const a = TURN.map((f) => columns[f]![e]!);
  const b = TURN.map((f) => then(fields.indexOf(f)) ?? Transform.fields[fields.indexOf(f)]!.initial);
  const s = a[0]! * b[0]! + a[1]! * b[1]! + a[2]! * b[2]! + a[3]! * b[3]! < 0 ? -1 : 1;
  if (!a.every((v, i) => Math.abs(v - s * b[i]!) <= TURN_STEP)) return;
  for (const f of TURN) delete own[f];
  if (Object.keys(own).length === 0) delete set.Transform;
}

/**
 * Compared between an entity and its prefab node: numeric components the
 * world saves, tags, and object components with their own `save` and `load`.
 * `Name` is the entity's `name`; anything else of an object's is the game's
 * (a `View`, which the prefab's `view` makes).
 */
export function carried(c: AnyComponent | undefined): c is AnyComponent {
  if (!c || c.bit < 0 || c.name === Name.name) return false;
  if (c.kind === 'tag') return true;
  if (c.kind === 'data') return !c.transient;
  if (c.kind === 'object') return c.save !== null && c.load !== null && !(isData(c) && c.transient);
  return false;
}

/** One entity's difference from its prefab node. */
export interface Difference {
  /** The entity, and which entity of the prefab it is: its node's id path (`''` the root). */
  entity: Entity;
  path: string;
  /** What it changed, as a file's override says it (`at`, the path as a list). */
  override: Override;
  /**
   * The prefabs whose file could hold it, innermost first: the one that makes
   * the entity (its own data), then each nesting it (an override), out to the
   * instance's own. A ref or a parent pointing past an inner prefab's
   * instance is a difference of its own, without that prefab.
   */
  owners: readonly string[];
  /** Why no prefab can hold it, where `owners` is empty: a ref to an entity outside the instance. */
  why?: string;
}

/** What an instance changed from its prefab. */
export interface InstanceOverrides {
  root: Entity;
  /** The compile it was compared with. */
  prefab: CompiledPrefab;
  /** Per entity that differs, in node order. */
  differences: Difference[];
  /** Entities of the prefab gone from the instance, the top of each: their paths (an override's `removed`). */
  removed: string[];
  /** Entities under the instance that are none of it -- children added -- the top of each. */
  added: Entity[];
  /** What no override can say, said: kept out of the overrides. */
  notes: string[];
}

// ---------------------------------------------------------------- the tables

/** A compiled prefab's values and refs by node, field by field: what a comparison reads without a search. */
interface Table {
  /** Each numeric component of the prefab, by id, to where its fields start in a node's row. */
  base: Map<number, number>;
  width: number;
  /** `node * width + base + field`: the node's value, defaults included; NaN where the node has not the component. */
  values: Float64Array;
  /** The same places: the node a ref field points at, or -1. */
  refs: Int32Array;
}

const tables = new WeakMap<CompiledPrefab, Table>();

function tableOf(p: CompiledPrefab): Table {
  const had = tables.get(p);
  if (had) return had;
  const base = new Map<number, number>();
  let width = 0;
  for (const k of p.kinds) {
    for (const c of k.components) {
      if (c.kind !== 'data' || base.has(c.id)) continue;
      base.set(c.id, width);
      width += c.fields.length;
    }
  }
  const values = new Float64Array(p.count * width).fill(NaN);
  const refs = new Int32Array(p.count * width).fill(-1);
  for (const run of p.full) {
    const b = base.get(run.component);
    if (b === undefined) continue;
    for (let j = 0; j < run.node.length; j++) values[run.node[j]! * width + b + run.field] = run.value[j]!;
  }
  for (const run of p.refs) {
    const b = base.get(run.component);
    if (b === undefined) continue;
    for (let j = 0; j < run.node.length; j++) refs[run.node[j]! * width + b + run.field] = run.target[j]!;
  }
  const made: Table = { base, width, values, refs };
  tables.set(p, made);
  return made;
}

/** A node's value of a field: the prefab's, its default if the node has the component and does not set it, null if the node has it not. */
function valueAt(t: Table, c: Component, field: number, node: number): number | null {
  const b = t.base.get(c.id);
  if (b === undefined) return null;
  const v = t.values[node * t.width + b + field]!;
  return Number.isNaN(v) ? null : v;
}

/** The node a node's ref field points at in the prefab, or -1. */
function refAt(t: Table, c: Component, field: number, node: number): number {
  const b = t.base.get(c.id);
  return b === undefined ? -1 : t.refs[node * t.width + b + field]!;
}

/** What an instance has in an object component at `node` as made: the file's data, or a new one's as `save` says it. */
function objectThen(p: CompiledPrefab, c: AnyComponent, node: number): unknown {
  for (const o of p.objects) if (o.component === c && o.node === node) return o.data;
  return c.kind === 'object' && c.create && c.save ? c.save(c.create()) : undefined;
}

/** Is `node` switched off at `c` in the prefab? */
function offAt(p: CompiledPrefab, c: AnyComponent, node: number): boolean {
  for (const o of p.off) if (o.node === node && o.component === c.id) return true;
  return false;
}

/** The data of the prefab's `relation` link from `from` to `to`, a field's value by index -- or null for no such link. Allocates only for one found. */
function linkThen(p: CompiledPrefab, relation: Relation<any>, from: number, to: number): number[] | null {
  for (const run of p.links) {
    if (run.relation !== relation) continue;
    for (let j = 0; j < run.source.length; j++) {
      if (run.source[j] !== from || run.target[j] !== to) continue;
      const data = relation.fields.map((f) => f.initial);
      for (const w of run.writes) for (let k = 0; k < w.link.length; k++) if (w.link[k] === j) data[w.field] = w.value[k]!;
      return data;
    }
  }
  return null;
}

/** A path of ids as a file writes it: `''` is `[]`. */
export const pathList = (path: string): string[] => (path === '' ? [] : path.split('/'));

/** Can `owner` hold a ref or a parent to `target` (a path of `p`): is it a node of that owner's own instance? */
function holds(p: CompiledPrefab, owner: PrefabOwner, target: string): boolean {
  if (owner.key === p.key && owner.at === '') return true;
  const inner = pathInOwner(owner, target);
  return inner !== null && (compiledPrefab(owner.key)?.paths.includes(inner) ?? false);
}

// ---------------------------------------------------------------- the members

type Rows = Record<'prefab' | 'node' | 'root' | 'next', { [i: number]: number }>;
type Tree = Record<'parent' | 'firstChild' | 'nextSibling', { [i: number]: number }>;

/** Each node's entity of the instance, by node (0 for none): scratch, grown as needed, read before the next call. */
let byNode = new Int32Array(256);

/** `root`'s instance of `p`, by node: its chain walked. */
function membersOf(world: World, root: Entity, p: CompiledPrefab): Int32Array {
  if (byNode.length < p.count) byNode = new Int32Array(p.count * 2);
  byNode.fill(0, 0, p.count);
  const inst = world.rawStore(Instance) as Rows;
  for (let e = root as number; e !== 0; e = inst.next[e]!) {
    if (inst.root[e] !== root || inst.prefab[e] !== p.id) break;
    const n = inst.node[e]!;
    if (n < p.count && world.alive(e as Entity)) byNode[n] = e;
  }
  return byNode;
}

/** Is `e` an entity of `root`'s instance of `p`? */
const isMember = (inst: Rows, e: number, root: Entity, p: CompiledPrefab): boolean => e !== 0 && inst.root[e] === root && inst.prefab[e] === p.id;

// ---------------------------------------------------------------- what an instance changed

/** The override being worked out for one entity, made at its first difference (`own`): none for an entity that changed nothing. */
let open: Override | null = null;
let openAt = '';
const own = (): Override => (open ??= { at: pathList(openAt) });
/** The entity's refs to entities outside its instance: a difference of their own, which no prefab can hold. */
let outside: Override | null = null;

/** Does a data field's plain form point outside the instance (`{ entity }`) anywhere in it? */
function pointsOut(el: Element, json: unknown): boolean {
  let out = false;
  eachRef(el, json, (r) => void (out ||= isOutsideRef(r)));
  return out;
}

/**
 * Each top-level field of data component `c` on `e` that differs from the prefab's (`then`, `canonical`'s
 * form; the default where it gives none): an override of that field whole (D9), its refs paths inside the instance
 * -- or, where one points outside it, a difference only the scene can hold (`outside`). Compared by the plain form,
 * refs as the instance's nodes.
 */
function dataDiffers(world: World, c: DataComponentOf, e: Entity, then: Record<string, unknown> | undefined, ref: (r: EntityRef) => unknown, p: CompiledPrefab): void {
  const value = (world.rawStore(c) as { value: Record<string, unknown>[] }).value[e]!;
  for (const [f, el] of Object.entries(c.data)) {
    // A field systems fill as the game runs: never an override.
    if (c.runtime.includes(f)) continue;
    const now = dataPlain(el, value[f], ref);
    const was = then && f in then ? then[f] : dataPlain(el, dataDefault(el), () => null);
    if (JSON.stringify(now) === JSON.stringify(was)) continue;
    const written = mapRefs(el, now, (r) => (typeof r === 'number' ? pathList(p.paths[r]!) : r));
    const into = pointsOut(el, now) ? (outside ??= { at: pathList(openAt) }) : own();
    const objects = (into.objects ??= {});
    ((objects[c.name] ??= {}) as Record<string, unknown>)[f] = written;
  }
}

/**
 * What instance `root` changed from `p` -- the compile its entities were made
 * from, its prefab as compiled now by default. Null if `root` is no live
 * instance's root.
 */
export function overridesOf(world: World, root: Entity, p: CompiledPrefab | null = world.prefabOf(root)): InstanceOverrides | null {
  if (!p || !world.alive(root) || world.instanceRoot(root) !== root) return null;
  const t = tableOf(p);
  const inst = world.rawStore(Instance) as Rows;
  const tree = world.rawStore(Hierarchy) as Tree;
  const names = world.rawStore(Name) as { value: (string | null)[] };
  const members = membersOf(world, root, p);
  const out: InstanceOverrides = { root, prefab: p, differences: [], removed: [], added: [], notes: [] };
  const components = world.allComponents;
  const said = (n: number): string => p.paths[n] || 'its root';
  for (let n = 0; n < p.count; n++) {
    const e = members[n]! as Entity;
    if (e === 0) {
      // Gone, the top of what went: its parent still here.
      if (n > 0 && members[p.parents[n]!] !== 0) out.removed.push(p.paths[n]!);
      continue;
    }
    const made = p.kinds[n]!.components;
    open = null;
    outside = null;
    openAt = p.paths[n]!;
    /** Refs and a parent: the targets' nodes, to tell which owners can hold them. */
    let pointsAt: number[] | null = null;
    for (let ci = 0; ci < components.length; ci++) {
      const c = components[ci]!;
      if (!carried(c)) continue;
      const has = world.has(e, c);
      const was = made.includes(c);
      if (has !== was) {
        const list = has ? (own().add ??= []) : (own().remove ??= []);
        list.push(c.name);
      }
      if (!has) continue;
      // Switched off or on against the prefab.
      const off = !world.enabled(e, c);
      if (off !== (was && offAt(p, c, n))) {
        const list = off ? (own().off ??= []) : (own().on ??= []);
        list.push(c.name);
      }
      if (isData(c)) {
        dataDiffers(world, c, e, was ? (objectThen(p, c, n) as Record<string, unknown> | undefined) : undefined, (r) => {
          const to = world.deref(r);
          return to === NONE ? null : isMember(inst, to, root, p) ? inst.node[to]! : { entity: to };
        }, p);
        continue;
      }
      if (c.kind === 'object') {
        const value = (world.rawStore(c) as { value: unknown[] }).value[e];
        const now = JSON.stringify(c.save!(value));
        if (now !== JSON.stringify(was ? objectThen(p, c, n) : undefined)) (own().objects ??= {})[c.name] = JSON.parse(now) as unknown;
        continue;
      }
      if (c.kind !== 'data') continue;
      const columns = world.rawStore(c) as Record<string, { [i: number]: number }>;
      for (let fi = 0; fi < c.fields.length; fi++) {
        const f = c.fields[fi]!;
        if (f.runtime) continue;
        const v = columns[f.name]![e]!;
        if ((c.schema as Record<string, { ref?: true }>)[f.name]?.ref) {
          const then = was ? refAt(t, c, fi, n) : -1;
          const to = world.deref(v as EntityRef);
          if (to !== NONE && isMember(inst, to, root, p)) {
            const at = inst.node[to]!;
            if (at !== then) {
              ((own().refs ??= {})[c.name] ??= {})[f.name] = pathList(p.paths[at]!);
              (pointsAt ??= []).push(at);
            }
          } else if (to !== NONE) {
            // Outside the instance: the scene's entity by its index (a scene keeps its entities' indices on load), a
            // difference only the scene holds -- no prefab file can point out of itself (Docs/prefabs.md §2).
            ((outside ??= { at: pathList(openAt) }).refs ??= {})[c.name] = { ...outside.refs?.[c.name], [f.name]: { entity: to } };
          } else if (then >= 0) ((own().refs ??= {})[c.name] ??= {})[f.name] = null;
          continue;
        }
        const then = was ? valueAt(t, c, fi, n) : null;
        // A key field as its text, as every file writes one (`ecs/keys.ts`): compared as ids, written as text.
        if (!same(v, then ?? f.initial, f.type)) ((own().set ??= {})[c.name] ??= {})[f.name] = fieldText(c, f.name, v);
      }
      // A vector any axis of which differs is written whole, `[x, y, z]`, as a file writes it (`fields.ts`).
      const mine = (open as Override | null)?.set?.[c.name];
      if (mine) foldVectors(c, mine as Record<string, FileValue>, (column) => columns[column]![e]!);
      // A rotation compared as one: q and -q, or a turn all the way round, are the rotation the prefab gives.
      const so = (open as Override | null)?.set; // set by `own()`, which the compiler does not follow
      if (c === Transform && was && so?.Transform) {
        sameTurnDropped(so, columns, e, (fi) => valueAt(t, c as Component, fi, n));
        // Nothing else of it differs: no override at all.
        if (Object.keys(so).length === 0) delete open!.set;
        if (Object.keys(open!).length === 1) open = null;
      }
    }
    if (world.layerOfEntity(e) !== p.layers[n]) own().layer = world.layerOfEntity(e);
    const name = world.has(e, Name) ? (names.value[e] ?? null) : null;
    if (name !== null && name !== p.names[n]) own().name = name;
    else if (name === null && p.names[n] !== null) out.notes.push(`${said(n)}: its name ${p.names[n]} taken off -- an override names, never unnames: not kept`);
    if (n > 0) {
      const parent = tree.parent[e]!;
      if (isMember(inst, parent, root, p)) {
        const at = inst.node[parent]!;
        if (at !== p.parents[n]) {
          own().parent = pathList(p.paths[at]!);
          (pointsAt ??= []).push(at);
        }
      } else out.notes.push(`${said(n)}: moved out of its instance -- an override moves an entity within it: not kept`);
    }
    // Links out of it: a link's data the prefab makes, changed; a new one said.
    for (let ci = 0; ci < components.length; ci++) {
      const r = components[ci]!;
      if (r.kind !== 'relation') continue;
      const rows = world.rawStore(r) as Record<string, { [i: number]: number }>;
      for (let row = rows.firstOut![e]!; row !== 0; row = rows.nextOut![row]!) {
        const to = rows.target![row]!;
        const at = isMember(inst, to, root, p) ? inst.node[to]! : -1;
        const then = at >= 0 ? linkThen(p, r, n, at) : null;
        if (!then) {
          out.notes.push(`${said(n)}: its ${r.name} link to ${at >= 0 ? said(at) : 'an entity outside its instance'} -- an override sets a link's data, not a new link: not kept`);
          continue;
        }
        let set: Record<string, number> | null = null;
        for (let fi = 0; fi < r.fields.length; fi++) {
          const f = r.fields[fi]!;
          const v = rows[f.name]![row]!;
          if (!same(v, then[fi]!, f.type)) (set ??= {})[f.name] = v;
        }
        if (set) (own().links ??= []).push({ relation: r.name, to: pathList(p.paths[at]!), set });
      }
    }
    const diff = open as Override | null;
    const out_ = outside as Override | null;
    if (out_ !== null) out.differences.push({ entity: e, path: p.paths[n]!, override: out_, owners: [], why: 'it points outside the instance: only the scene can hold that, never a prefab' });
    if (diff === null) continue;
    const all = p.owners[n]!;
    const owners = all.map((x) => x.key);
    // A ref or a parent past an inner prefab's own instance: a difference of its own, which only the prefabs holding both ends can hold.
    if (pointsAt !== null) {
      const targets = pointsAt.map((at) => p.paths[at]!);
      const narrow = all.filter((x) => targets.every((path) => holds(p, x, path))).map((x) => x.key);
      if (narrow.length !== owners.length) {
        const apart: Override = { at: diff.at };
        if (diff.refs) apart.refs = diff.refs;
        if (diff.parent) apart.parent = diff.parent;
        delete diff.refs;
        delete diff.parent;
        if (Object.keys(diff).length > 1) out.differences.push({ entity: e, path: p.paths[n]!, override: diff, owners });
        out.differences.push({ entity: e, path: p.paths[n]!, override: apart, owners: narrow });
        continue;
      }
    }
    out.differences.push({ entity: e, path: p.paths[n]!, override: diff, owners });
  }
  // Children added: what is under an entity of it and is none of it -- the top of each.
  for (let n = 0; n < p.count; n++) {
    const e = members[n]!;
    if (e === 0) continue;
    for (let c = tree.firstChild[e]!; c !== 0; c = tree.nextSibling[c]!) if (!isMember(inst, c, root, p)) out.added.push(c as Entity);
  }
  return out;
}

/** Every difference of `found` as the file's overrides say them: one entry an entity, its `removed`s after. */
export function overrideList(found: InstanceOverrides): Override[] {
  const list: Override[] = [];
  for (const d of found.differences) {
    const had = list.find((o) => o.at.join('/') === d.path);
    // Refs by component, field by field: a ref inside the instance and one outside it are two differences of one entity.
    if (had) {
      const refs = had.refs;
      const objects = had.objects;
      Object.assign(had, structuredClone(d.override), { at: had.at });
      if (refs && d.override.refs) {
        had.refs = refs;
        for (const [c, fields] of Object.entries(d.override.refs)) refs[c] = { ...refs[c], ...structuredClone(fields) };
      }
      // A data component's fields, one by one: some inside the instance, some pointing out of it.
      if (objects && d.override.objects) {
        had.objects = objects;
        for (const [c, data] of Object.entries(d.override.objects)) {
          const both = typeof objects[c] === 'object' && objects[c] !== null && typeof data === 'object' && data !== null;
          objects[c] = both ? { ...(objects[c] as object), ...structuredClone(data as object) } : structuredClone(data);
        }
      }
    } else list.push(structuredClone(d.override));
  }
  for (const path of found.removed) list.push({ at: pathList(path), removed: true });
  return list;
}

// ---------------------------------------------------------------- an instance fitted to its prefab

/** What `fitInstance` is told. */
export interface FitOptions {
  /** Lines to say, pushed as they come. */
  say?: (line: string) => void;
}

/** The overrides at each path, merged: what an entity holds of its own. */
function byPath(overrides: readonly Override[]): Map<string, Override[]> {
  const out = new Map<string, Override[]>();
  for (const o of overrides) {
    if (!o || !Array.isArray(o.at)) continue;
    const key = o.at.join('/');
    const list = out.get(key) ?? [];
    list.push(o);
    out.set(key, list);
  }
  return out;
}

const anyOf = (list: readonly Override[] | undefined, test: (o: Override) => boolean): boolean => list !== undefined && list.some(test);

/**
 * Data component `c` on `e` brought to the prefab (`then`, `canonical`'s form, refs nodes) field by field (D9): a
 * field an override holds is the instance's and stays; every other set as the prefab gives it (its default where it
 * gives none), its refs this instance's entities -- written only where it differs, so code keeping a list keeps it.
 */
function fitData(world: World, c: DataComponentOf, e: Entity, list: readonly Override[] | undefined, then: Record<string, unknown> | undefined, members: readonly number[]): void {
  const value = (world.rawStore(c) as { value: Record<string, unknown>[] }).value[e]!;
  const toRef = (n: unknown): EntityRef => (typeof n === 'number' && (members[n] ?? 0) !== 0 ? world.ref(members[n]! as Entity) : NO_REF);
  for (const [f, el] of Object.entries(c.data)) {
    if (c.runtime.includes(f)) continue;
    if (anyOf(list, (o) => (o.objects?.[c.name] as Record<string, unknown> | undefined)?.[f] !== undefined)) continue;
    const next = then && f in then ? fromPlain(el, then[f], f, { ref: toRef }) : dataDefault(el);
    if (JSON.stringify(dataPlain(el, next, rawOut)) !== JSON.stringify(dataPlain(el, value[f], rawOut))) value[f] = next;
  }
}

/**
 * Instance `root` brought to `now` wherever it holds no override of its own
 * (`overrides`, the file's format, paths in `now`): what it is made of, every
 * field, what is switched off, its layer and name, refs and parents inside
 * it, its objects, the data of its prefab's links -- and each entity `now`
 * has that it lacks, made where `now` puts it (one an override removed, and
 * what is under it, left out). Its entities' `Instance` rows must name
 * nodes of `now` already. The instance's root is announced again if anything
 * was made (`world.announceInstance`: the hooks draw the new). Outside a
 * tick; flushed.
 */
export function fitInstance(world: World, root: Entity, now: CompiledPrefab, overrides: readonly Override[], options: FitOptions = {}): void {
  const t = tableOf(now);
  const own = byPath(overrides);
  const inst = world.rawStore(Instance) as Rows;
  const names = world.rawStore(Name) as { value: (string | null)[] };
  const tree = world.rawStore(Hierarchy) as Tree;
  const members = Array.from(membersOf(world, root, now).subarray(0, now.count));
  // What an override took away, and everything under it.
  const removed = new Array<boolean>(now.count).fill(false);
  for (let n = 1; n < now.count; n++) removed[n] = removed[now.parents[n]!]! || anyOf(own.get(now.paths[n]!), (o) => o.removed === true);
  // Gained: each node it lacks whose parent it has (or gains), made bare of the node's kind.
  const gained: number[] = [];
  for (let n = 1; n < now.count; n++) {
    if (members[n] !== 0 || removed[n] || members[now.parents[n]!] === 0) continue;
    members[n] = world.spawn(now.kinds[n]!);
    gained.push(n);
  }
  if (gained.length > 0) {
    world.flush();
    for (const n of gained) world.setParent(members[n]! as Entity, members[now.parents[n]!]! as Entity);
  }
  // What it is made of: as the prefab says, but for what an override adds or removes.
  for (let n = 0; n < now.count; n++) {
    const e = members[n]! as Entity;
    if (e === 0) continue;
    const list = own.get(now.paths[n]!);
    const made = now.kinds[n]!.components;
    for (const c of world.allComponents) {
      if (!carried(c)) continue;
      const should = (made.includes(c) && !anyOf(list, (o) => o.remove?.includes(c.name) === true)) || anyOf(list, (o) => o.add?.includes(c.name) === true);
      if (should && !world.has(e, c)) world.add(e, c);
      else if (!should && world.has(e, c)) world.remove(e, c);
    }
    // A value it sets of a component it has not -- the prefab took it off, and no override adds it: said, not kept.
    for (const o of list ?? []) {
      for (const cn of Object.keys(o.set ?? {})) {
        const c = world.allComponents.find((x) => x.name === cn);
        const kept = c !== undefined && ((made.includes(c) && !anyOf(list, (x) => x.remove?.includes(cn) === true)) || anyOf(list, (x) => x.add?.includes(cn) === true));
        if (!kept) options.say?.(`${now.key}: ${Object.keys(o.set![cn]!).map((f) => `${cn}.${f}`).join(', ')} at ${now.paths[n] || 'its root'} dropped -- it has no ${cn} now`);
      }
    }
    if (now.names[n] !== null && !world.has(e, Name)) world.add(e, Name);
    // Under its node's parent, unless an override puts it elsewhere in the instance.
    if (n > 0) {
      const moved = list?.find((o) => o.parent !== undefined)?.parent;
      const to = moved !== undefined ? members[now.paths.indexOf(moved.join('/'))] : members[now.parents[n]!];
      if (to !== undefined && to !== 0 && tree.parent[e] !== to) world.setParent(e, to as Entity);
    }
  }
  world.flush();
  // Every value it holds no override of.
  for (let n = 0; n < now.count; n++) {
    const e = members[n]! as Entity;
    if (e === 0) continue;
    const list = own.get(now.paths[n]!);
    let moved = false;
    for (const c of world.allComponents) {
      if (!carried(c) || !world.has(e, c)) continue;
      const mine = (pick: (o: Override) => Record<string, unknown> | undefined): boolean => anyOf(list, (o) => pick(o)?.[c.name] !== undefined);
      const off = (offAt(now, c, n) && !anyOf(list, (o) => o.on?.includes(c.name) === true)) || anyOf(list, (o) => o.off?.includes(c.name) === true);
      if (world.enabled(e, c) === off) world.enable(e, c, !off);
      if (isData(c)) {
        fitData(world, c, e, list, now.kinds[n]!.components.includes(c) ? (objectThen(now, c, n) as Record<string, unknown> | undefined) : undefined, members);
        continue;
      }
      if (c.kind === 'object') {
        if (mine((o) => o.objects) || !now.kinds[n]!.components.includes(c)) continue;
        const store = (world.rawStore(c) as { value: unknown[] }).value;
        const data = objectThen(now, c, n);
        if (data === undefined || JSON.stringify(c.save!(store[e])) === JSON.stringify(data)) continue;
        store[e] = c.load!(data, store[e]) ?? store[e];
        continue;
      }
      if (c.kind !== 'data') continue;
      const columns = world.rawStore(c) as Record<string, { [i: number]: number }>;
      for (let fi = 0; fi < c.fields.length; fi++) {
        const f = c.fields[fi]!;
        if (f.runtime) continue;
        if ((c.schema as Record<string, { ref?: true }>)[f.name]?.ref) {
          // An override's own: a path inside the instance, nobody (null), or a scene's entity outside it by index.
          let given: string[] | OutsideRef | null | undefined;
          for (const o of list ?? []) if (o.refs?.[c.name]?.[f.name] !== undefined) given = o.refs[c.name]![f.name];
          if (given !== undefined) {
            const to = given === null ? 0
              : isOutsideRef(given) ? (world.alive(given.entity as Entity) && !isMember(inst, given.entity, root, now) ? given.entity : 0)
                : Array.isArray(given) ? (members[now.paths.indexOf(given.join('/'))] ?? 0) : world.deref(columns[f.name]![e]! as EntityRef);
            columns[f.name]![e] = to !== 0 ? world.ref(to as Entity) : NO_REF;
            continue;
          }
          const at = refAt(t, c, fi, n);
          const to = at >= 0 ? members[at]! : 0;
          const held = world.deref(columns[f.name]![e]! as EntityRef);
          // Only a ref the prefab gives, or one into the instance it no longer gives: one out of it is the world's.
          if (to !== 0 ? held !== to : held !== NONE && isMember(inst, held, root, now)) columns[f.name]![e] = to !== 0 ? world.ref(to as Entity) : NO_REF;
          continue;
        }
        if (anyOf(list, (o) => fileEntry(c, o.set?.[c.name], f.name) !== undefined)) continue;
        const v = valueAt(t, c, fi, n);
        if (v === null || same(columns[f.name]![e]!, v, f.type)) continue;
        columns[f.name]![e] = v;
        if (c === Transform) moved = true;
      }
    }
    if (moved) world.moved(e);
    const layer = list?.find((o) => o.layer !== undefined)?.layer ?? now.layers[n]!;
    if (world.layerOfEntity(e) !== layer) world.setLayer(e, layer);
    const name = list?.find((o) => o.name !== undefined)?.name ?? now.names[n];
    if (name !== null && name !== undefined && world.has(e, Name) && names.value[e] !== name) names.value[e] = name;
    // The prefab's links from it: made if missing, their data as the prefab says but for what an override sets.
    for (const run of now.links) {
      const columns = world.rawStore(run.relation) as Record<string, { [i: number]: number }>;
      for (let j = 0; j < run.source.length; j++) {
        if (run.source[j] !== n) continue;
        const target = members[run.target[j]!]!;
        if (target === 0) continue;
        let row = 0;
        for (let r = columns.firstOut![e]!; r !== 0 && row === 0; r = columns.nextOut![r]!) if (columns.target![r] === target) row = r;
        if (row === 0) row = world.relate(e, run.relation, target as Entity);
        if (row === 0) continue;
        const to = now.paths[run.target[j]!]!;
        const data = linkThen(now, run.relation, n, run.target[j]!)!;
        run.relation.fields.forEach((f, fi) => {
          if (!anyOf(list, (o) => o.links?.some((l) => l.relation === run.relation.name && l.to.join('/') === to && l.set[f.name] !== undefined) === true)) columns[f.name]![row] = data[fi]!;
        });
      }
    }
  }
  // Chained again in node order, the made among them: each an entity of this instance.
  let last = 0;
  for (let n = 0; n < now.count; n++) {
    const e = members[n]!;
    if (e === 0) continue;
    inst.prefab[e] = now.id;
    inst.node[e] = n;
    inst.root[e] = root;
    if (last !== 0) inst.next[last] = e;
    last = e;
  }
  if (last !== 0) inst.next[last] = 0;
  if (gained.length > 0) {
    options.say?.(`${now.key}: ${gained.map((n) => now.paths[n]).join(', ')} made`);
    world.announceInstance(root);
  }
  world.flush();
}

/**
 * The entities `lost` (of instance `root`, no node of its prefab now)
 * destroyed, and what of the world is under one -- the instance's own, or
 * anything put there -- moved up to the nearest that stays.
 */
function letGo(world: World, root: Entity, lost: ReadonlySet<number>): void {
  const tree = world.rawStore(Hierarchy) as Tree;
  for (const e of lost) {
    for (let c = tree.firstChild[e]!; c !== 0; c = tree.nextSibling[c]!) {
      if (lost.has(c)) continue;
      let up = tree.parent[e]!;
      while (up !== 0 && lost.has(up)) up = tree.parent[up]!;
      world.setParent(c as Entity, (up === 0 ? root : up) as Entity);
    }
  }
  world.flush();
  for (const e of lost) if (!lost.has(tree.parent[e]!)) world.destroy(e as Entity);
  world.flush();
}

// ---------------------------------------------------------------- the live update

const digests = new WeakMap<CompiledPrefab, string>();

/** Everything a compile gives an instance, as text: what tells two compiles of a prefab apart. */
function digestOf(p: CompiledPrefab): string {
  let made = digests.get(p);
  if (made !== undefined) return made;
  made = JSON.stringify([
    p.paths, p.names, Array.from(p.parents), p.kinds.map((k) => k.components.map((c) => c.name)),
    p.full.map((r) => [r.component, r.field, Array.from(r.node), Array.from(r.value)]),
    p.refs.map((r) => [r.component, r.field, Array.from(r.node), Array.from(r.target)]),
    p.links.map((l) => [l.relation.name, Array.from(l.source), Array.from(l.target), l.writes.map((x) => [x.field, Array.from(x.link), Array.from(x.value)])]),
    p.objects.map((o) => [o.component.name, o.node, o.data]), Array.from(p.layers), p.off, p.views,
  ]);
  digests.set(p, made);
  return made;
}

/**
 * Do two compiles of a prefab give an instance the same -- every compile
 * makes every prefab it compiles afresh, a prefab only nesting a changed one
 * included -- so one brought from one to the other changes nothing?
 */
export const sameCompile = (a: CompiledPrefab, b: CompiledPrefab): boolean => a === b || digestOf(a) === digestOf(b);

/** An instance to bring up once its prefab is compiled anew: its root, the compile it was made from, and its overrides against that. */
export interface Pending {
  root: Entity;
  old: CompiledPrefab;
  overrides: Override[];
}

/** Every live instance root in the world, lowest index first. */
export function instanceRoots(world: World): Entity[] {
  const out: Entity[] = [];
  for (let e = 1; e < world.extent; e++) if (world.alive(e as Entity) && world.instanceRoot(e as Entity) === e) out.push(e as Entity);
  return out;
}

/** Before a compile: every live instance of `keys` (a prefab nesting a changed one is changed too) with its overrides against the compile now. */
export function pendingUpdates(world: World, keys: readonly string[]): Pending[] {
  const out: Pending[] = [];
  if (keys.length === 0) return out;
  for (const root of instanceRoots(world)) {
    const old = world.prefabOf(root);
    if (!old || !keys.includes(old.key)) continue;
    const found = overridesOf(world, root, old);
    if (found) out.push({ root, old, overrides: overrideList(found) });
  }
  return out;
}

/** An instance's entities as its prefab was and as it is now: what `followPaths` carries its overrides through. */
export interface PathMap {
  /** Each entity's path in the prefab as it was, to its path now: an id renamed under its name is the same entity. */
  moved: ReadonlyMap<string, string>;
  /** The paths, as it was, of its entities the prefab has no node for now. */
  gone: ReadonlySet<string>;
  now: CompiledPrefab;
}

/**
 * Every node of a prefab as it was -- its kinds' names and node names, in node
 * order -- to its path in the prefab as compiled now (`moved`), or `gone`:
 * found as `refindNodes` finds a saved entity (an id renamed under its name is
 * the same node), so a node no entity of the instance has -- one it removed --
 * follows a rename too. Paths `moved` or `gone` has already (its living
 * entities, as found) are kept. Said nothing: the finding is said where it is
 * done.
 */
function mapNodes(now: CompiledPrefab, kinds: readonly string[], names: readonly (string | null)[] | undefined, moved: Map<string, string>, gone: Set<string>): void {
  const found = refindNodes(now, kinds, { kinds, names }, () => {});
  kinds.forEach((kind, i) => {
    const was = kind === now.key ? '' : kind.startsWith(`${now.key}/`) ? kind.slice(now.key.length + 1) : null;
    if (was === null || moved.has(was) || gone.has(was)) return;
    if (found[i]! >= 0) moved.set(was, now.paths[found[i]!]!);
    else gone.add(was);
  });
}

/**
 * An instance's overrides (paths in its prefab as it was) carried to its
 * prefab as compiled now -- `at`, `parent` and every ref's path -- through
 * `map`: the live update's and the load pass's one rule (Docs/prefabs.md §6,
 * §7). `map` has every node of the prefab as it was, living or removed in the
 * instance (`mapNodes`); a path it lacks (a save from before nodes were kept)
 * follows its nearest ancestor that moved, else stays as it is while the
 * prefab still has it. One on an entity gone is dropped and said -- a removal
 * too; a parent or a ref that is gone goes back to the prefab's.
 */
export function followPaths(overrides: readonly Override[], map: PathMap, say: (line: string) => void): Override[] {
  const paths = new Set(map.now.paths);
  const to = (path: string): string | null => {
    const m = map.moved.get(path);
    if (m !== undefined) return m;
    if (map.gone.has(path)) return null;
    // Under an entity whose id was renamed: at the new id's path.
    for (let cut = path.lastIndexOf('/'); cut > 0; cut = path.lastIndexOf('/', cut - 1)) {
      const up = map.moved.get(path.slice(0, cut));
      if (up === undefined) continue;
      const there = `${up}${path.slice(cut)}`;
      return paths.has(there) ? there : null;
    }
    return paths.has(path) ? path : null;
  };
  const list = (path: string[]): string[] | null => {
    const m = to(path.join('/'));
    return m === null ? null : pathList(m);
  };
  const kept: Override[] = [];
  for (const o of overrides) {
    if (!o || !Array.isArray(o.at)) continue;
    const at = list(o.at);
    if (at === null) {
      say(o.removed
        ? `${map.now.key}: ${o.at.join('/')} was removed from this instance, and the prefab no longer has it either`
        : `${map.now.key}: an override at ${o.at.join('/') || 'its root'} dropped -- ${o.at.join('/')} is no longer in it`);
      continue;
    }
    const copy: Override = { ...o, at };
    if (o.parent) {
      const p = list(o.parent);
      if (p) copy.parent = p;
      else delete copy.parent;
    }
    if (o.refs) {
      const refs: NonNullable<Override['refs']> = {};
      for (const [c, fields] of Object.entries(o.refs)) for (const [f, path] of Object.entries(fields)) {
        // Nobody, or an entity outside the instance: no path of the prefab's, kept as it is.
        if (path === null || isOutsideRef(path)) {
          (refs[c] ??= {})[f] = path;
          continue;
        }
        const p = Array.isArray(path) ? list(path) : null;
        if (p) (refs[c] ??= {})[f] = p;
      }
      copy.refs = refs;
    }
    if (o.objects) {
      // A data component's refs, paths inside the instance: followed as a ref field's, one gone nobody.
      const objects: Record<string, unknown> = {};
      for (const [cn, data] of Object.entries(o.objects)) {
        const c = componentNamed(cn);
        objects[cn] = isData(c) ? mapFields(c.data, data, (r) => (Array.isArray(r) ? list(r as string[]) : r)) : data;
      }
      copy.objects = objects;
    }
    kept.push(copy);
  }
  return kept;
}

/** What `applyUpdates` is told. */
export interface UpdateOptions {
  /** An entity whose node draws another model now: its view let go of, so the `onInstance` hooks draw the new one. */
  view?: (e: Entity) => void;
}

/**
 * After the compile: each pending instance brought to its prefab as compiled
 * now. Its entities found again by their node's path (an id renamed under the
 * same name is one node), the lost destroyed -- an override on one dropped and
 * said -- each view the prefab changed let go of, then fitted. A prefab gone,
 * or not compiled anew, leaves its instances as they are. What to say.
 */
export function applyUpdates(world: World, pending: readonly Pending[], options: UpdateOptions = {}): { updated: number; lines: string[] } {
  const lines: string[] = [];
  const say = (line: string): void => void (lines.includes(line) || lines.push(line));
  let updated = 0;
  for (const { root, old, overrides } of pending) {
    const now = compiledPrefab(old.key);
    if (!now || sameCompile(now, old) || !world.alive(root) || world.instanceRoot(root) !== root) continue;
    const inst = world.rawStore(Instance) as Rows;
    const list: number[] = [];
    for (let e = root as number; e !== 0; e = inst.next[e]!) {
      if (inst.root[e] !== root) break;
      if (world.alive(e as Entity)) list.push(e);
    }
    const found = refindNodes(now, list.map((e) => world.kindOfEntity(e as Entity).name), { kinds: old.kinds.map((k) => k.name), names: old.names }, say);
    if (found[0] !== 0) continue;
    const lost = new Set<number>();
    /** Each old path to its new one, and the old paths of the entities lost: an override follows its entity. */
    const moved = new Map<string, string>();
    const gone = new Set<string>();
    list.forEach((e, i) => {
      const was = old.paths[inst.node[e]!]!;
      if (found[i]! < 0) {
        lost.add(e);
        gone.add(was);
      } else moved.set(was, now.paths[found[i]!]!);
    });
    // The nodes it has no entity of (one it removed) found too: a removal follows a rename.
    mapNodes(now, old.kinds.map((k) => k.name), old.names, moved, gone);
    const kept = followPaths(overrides, { moved, gone, now }, say);
    if (lost.size > 0) letGo(world, root, lost);
    // A link the old compile made between two that stay, which the new one makes no more: let go of -- an override
    // never makes a link, so it is the prefab's.
    const at = new Map<number, number>();
    list.forEach((e, i) => void (lost.has(e) || at.set(inst.node[e]!, i)));
    let unlinked = false;
    for (const run of old.links) {
      for (let j = 0; j < run.source.length; j++) {
        const s = at.get(run.source[j]!);
        const d = at.get(run.target[j]!);
        if (s === undefined || d === undefined || linkThen(now, run.relation, found[s]!, found[d]!) !== null) continue;
        world.unrelate(list[s]! as Entity, run.relation, list[d]! as Entity);
        unlinked = true;
      }
    }
    if (unlinked) world.flush();
    // The rows: the node each is now, the views the prefab changed let go of.
    list.forEach((e, i) => {
      if (lost.has(e)) return;
      const was = inst.node[e]!;
      inst.prefab[e] = now.id;
      inst.node[e] = found[i]!;
      if (options.view && (old.views[was] ?? null) !== (now.views[found[i]!] ?? null)) options.view(e as Entity);
    });
    fitInstance(world, root, now, kept, { say });
    world.announceInstance(root);
    world.flush();
    updated++;
  }
  return { updated, lines };
}

// ---------------------------------------------------------------- scenes and levels

/**
 * The world as a scene or a level keeps it: `world.save()`, its instances'
 * overrides with it (`instances.overrides`, by root), so a load brings every
 * instance up to its prefab as compiled then (`refreshInstances`); and no
 * random streams, so a load starts them from the run's own seed.
 */
export function sceneSave(world: World): WorldSave {
  const save = world.save();
  // Content, not a saved game: no random streams, so a load keeps the run's seed (`Loop.loadState`).
  save.loop = { tick: save.loop.tick, streams: {} };
  // Refs by the entity's index, as `entities`, `parents` and the links name an entity -- a scene keeps its entities'
  // indices on load -- and one to nobody, or to one gone, 0: the file names nothing dangling (Docs/prefabs.md §2).
  const kept = new Set(save.entities);
  for (const [name, saved] of Object.entries(save.components)) {
    const c = world.allComponents.find((x) => x.name === name);
    // A data component's refs, wherever they are in it (a list's, a dict's key), the same way.
    if (isData(c) && saved.values) {
      saved.values = saved.values.map((v) => {
        const mapped = mapFields(c.data, v, (r) => {
          const to = typeof r === 'number' ? world.deref(r as EntityRef) : NONE;
          return to !== NONE && kept.has(to) ? to : null;
        }) as Record<string, unknown>;
        // What systems fill as the game runs is the game's, never the scene's: a load starts it at its default.
        for (const f of c.runtime) delete mapped[f];
        return mapped;
      });
      continue;
    }
    if (c?.kind !== 'data' || !saved.fields) continue;
    for (const f of c.fields) {
      if (!(c.schema as Record<string, { ref?: true }>)[f.name]?.ref) continue;
      const values = saved.fields[f.name];
      if (!values) continue;
      for (let i = 0; i < values.length; i++) {
        const to = world.deref(values[i] as EntityRef);
        values[i] = to !== NONE && kept.has(to) ? to : 0;
      }
    }
  }
  save.refs = 'index';
  const inst = save.instances;
  if (!inst) return save;
  const overrides: Record<string, Override[]> = {};
  for (let i = 0; i < save.entities.length; i++) {
    const e = save.entities[i]! as Entity;
    if (inst.prefab[i] === 0 || inst.root[i] !== e) continue;
    const found = overridesOf(world, e);
    if (found) overrides[String(e)] = overrideList(found);
  }
  inst.overrides = overrides;
  return save;
}

/** `save` without its instances' overrides: loaded, it plays back as it was -- for a caller that brings it up itself, as a step (`refreshInstances`). */
export function plainSave(save: WorldSave): WorldSave {
  if (!save.instances?.overrides) return save;
  const { overrides: _overrides, ...rows } = save.instances;
  return { ...save, instances: rows };
}

/**
 * After `world.load(save)`: a scene's or a level's instances (`save.instances.overrides`)
 * brought to their prefabs as compiled now -- every field, component,
 * switch, layer, name, ref, object and link they hold no override of, and the
 * entities the prefab gained made. What the prefab lost the load made plain;
 * those are destroyed here, an override on one dropped and said. A save
 * without overrides (a game saved at runtime, an undo step) is left as it
 * loaded. What to say, a line each.
 */
export function refreshInstances(world: World, given: WorldSave): string[] {
  // Its prefabs by uid first, as the load read them (a prefab moved since: its kinds named after it now).
  const save = followSavedPrefabs(given);
  const saved = save.instances;
  const table = saved?.overrides;
  if (!saved || !table) return [];
  const lines: string[] = [];
  const say = (line: string): void => void (lines.includes(line) || lines.push(line));
  const inst = world.rawStore(Instance) as Rows;
  // Each instance's entities the load let go of: its prefab has their node no more.
  const plain = new Map<number, Set<number>>();
  save.entities.forEach((e, i) => {
    if (saved.prefab[i] === 0 || inst.prefab[e] !== 0 || !world.alive(e as Entity)) return;
    const root = saved.root[i]!;
    const set = plain.get(root) ?? new Set<number>();
    set.add(e);
    plain.set(root, set);
  });
  for (const [key, overrides] of Object.entries(table)) {
    const root = Number(key) as Entity;
    const now = world.alive(root) && world.instanceRoot(root) === root ? world.prefabOf(root) : null;
    if (!now || !Array.isArray(overrides)) continue;
    // Each saved entity of it by its path as saved (its kind's name) to its path now, as the load found its node.
    const moved = new Map<string, string>();
    const gone = new Set<string>();
    save.entities.forEach((e, i) => {
      if (saved.prefab[i] === 0 || saved.root[i] !== root || saved.keys[saved.prefab[i]!] !== now.key) return;
      const kind = save.kinds[i] ?? '';
      const was = kind === now.key ? '' : kind.startsWith(`${now.key}/`) ? kind.slice(now.key.length + 1) : null;
      if (was === null) return;
      if (world.alive(e as Entity) && inst.root[e] === root && inst.prefab[e] === now.id) moved.set(was, now.paths[inst.node[e]!]!);
      else gone.add(was);
    });
    // The nodes of the prefab as saved it has no entity of (one it removed), found too: a removal follows a rename.
    const k = saved.keys.indexOf(now.key);
    const nodes = k >= 0 ? saved.nodes?.[k] : undefined;
    if (nodes) mapNodes(now, nodes, saved.names?.[k], moved, gone);
    const lost = plain.get(root);
    if (lost && lost.size > 0) letGo(world, root, lost);
    fitInstance(world, root, now, followPaths(overrides, { moved, gone, now }, say), { say });
  }
  return lines;
}
