/**
 * Prefabs, the pure half (Docs/prefabs.md §2-§4): the file format, checked; the
 * compiler that flattens nesting and overrides into one kind per node and flat
 * typed arrays; and `prefab(key)`, the module-level token code instantiates.
 *
 * The rules:
 *   - Compiled once (`compilePrefabs`), before the world is made: it makes the
 *     kinds, and a world sizes itself by them. A second compile of the same
 *     files reuses the kinds it made (same names, same components).
 *   - Nothing here is used at instantiate but typed arrays and component ids:
 *     `World.instantiate` reads `CompiledPrefab` and writes columns.
 *   - A problem is an error naming the prefab's key and the path of ids to it.
 *   - Every key is one its shape takes (`PREFAB_KEYS`): a misplaced or misspelt
 *     one is an error saying where it belongs, never dropped.
 *   - **Two flatteners, one answer**: `packages/pipeline/src/assets/prefab-names.ts` mirrors
 *     `flattenFile` from the files alone (it cannot see components) to write the
 *     node names and components into `keys.d.ts`. A change to how nesting,
 *     overrides, paths or ids work here is a change there too;
 *     `src/prefab-names.test.ts` compares the two and is all that holds them.
 *
 * No glob, no three, no DOM: node tests import it. `prefabs.ts` is the
 * game's side (the files, by glob; views by asset key).
 */
import type { AnyComponent, Component, Entity, EntityRef, Field, Kind, Relation } from './component.ts';
import { allComponents, Disabled, generationOpen, kind, kindNamed, Name, NO_REF } from './component.ts';
import { fieldProblem, fieldValue, internKey, keyKindOf, keyText } from './keys.ts';
import { refMisfit, unfoldEntry } from './fields.ts';
import { DataError, dataPlain, eachRef, fillFrom, isData, mapFields, record, type DataComponentOf, type Element } from './data.ts';
import { Render, splitModel } from './render-components.ts';
import { caseKey } from '../assets/case-key.ts';
import { isKeyRef, resolveRef, type KeyRef } from '../assets/uids.ts';

/** A prefab file as written (`src/assets/prefabs/<key>.prefab`, JSON inside). */
export interface PrefabFile {
  /** The file's own uid (Docs/asset-ids.md §1), stamped by the pipeline: first in the file, never changed. */
  uid?: string;
  is: 'vibebase.prefab';
  version: 1;
  /** Instances kept for reuse (Docs/prefabs.md §5): `warm` made at boot and parked, at most `max` alive. */
  pool?: PoolSize;
  entities: PrefabEntity[];
}
/** A pool's numbers: how many are parked at boot, and how many may be alive at once, parked and out. */
export interface PoolSize {
  warm: number;
  max: number;
}
export type Path = string[];
export interface PrefabEntity {
  id: string;
  /** An id of this file, a path into a nested instance (`["b7", "m3"]`), or null for the root. */
  parent: string | Path | null;
  /** A nested instance: the other prefab -- `{ uid, key }`, or its key alone (Docs/asset-ids.md §3) -- and what this one changes in it. */
  prefab?: string | KeyRef;
  overrides?: Override[];
  name?: string;
  components?: string[];
  /** Each numeric component's fields that differ from its defaults: a number, a yes or no, or a key field's reference (`"Render": { "model": { "uid": "uid://…", "key": "props/crate" } }`, or the key alone). */
  data?: Record<string, Record<string, FileValue>>;
  tags?: string[];
  objects?: Record<string, unknown>;
  /** `ref()` fields pointing at another entity of the prefab, by id or path. */
  refs?: Record<string, Record<string, string | Path>>;
  /** Relations to other entities of the prefab, each with the link's own fields where they differ from the defaults. */
  links?: PrefabLink[];
  layer?: number;
  off?: string[];
}
/** The key a nested instance's `"prefab"` names now -- by its uid first (Docs/asset-ids.md §1, rule 4) -- lowercased; null for an entity that nests none. */
export function nestedKey(ent: Pick<PrefabEntity, 'prefab'>): string | null {
  if (ent.prefab === undefined) return null;
  const key = resolveRef('prefabs', ent.prefab);
  return key === null ? null : caseKey(key);
}

/**
 * A field's value in a file: a number, a yes or no, a key field's reference -- `{ uid, key }` or the key alone (`key()`,
 * `ecs/keys.ts`) -- an enum's name, flags' names, a colour's `#rrggbbaa`, or a vector's `[x, y, z]` (`fields.ts`).
 */
export type FileValue = number | boolean | string | KeyRef | readonly string[] | readonly number[];
export interface PrefabLink {
  relation: string;
  to: string | Path;
  data?: Record<string, number | boolean>;
}
export interface Override {
  at: Path;
  set?: Record<string, Record<string, FileValue>>;
  add?: string[];
  remove?: string[];
  off?: string[];
  layer?: number;
  name?: string;
  removed?: true;
  /** The data of links the nested instance makes: the `relation` link from `at` to `to` (a path inside it, as `at` is). */
  links?: { relation: string; to: Path; set: Record<string, number | boolean> }[];
  /** Components the inner prefab switches off, switched on again. */
  on?: string[];
  /**
   * `ref()` fields pointing elsewhere: each at an entity of the nested instance, by a path inside it as `at` is; `null`
   * at nobody. A scene's override may also point outside the instance, at `{ "entity": 12 }` -- an entity of the scene
   * by its index, which a scene keeps on load (`OutsideRef`, Docs/prefabs.md §2); a prefab's never.
   */
  refs?: Record<string, Record<string, Path | OutsideRef | null>>;
  /** Object components' data, as their `save` gives it -- loaded through `load`, as an entity's `objects` are. The entity has the component (or `add` gives it). */
  objects?: Record<string, unknown>;
  /** Under another entity of the nested instance, by a path inside it (`[]` its root). Not on its root, which the entity's own `parent` places. */
  parent?: Path;
}

/** A scene's ref to an entity outside an instance: the scene's entity by its index (a scene's entities keep theirs on load). */
export interface OutsideRef {
  entity: number;
}

/** Is an override's ref one to an entity outside the instance (`{ "entity": 12 }`)? */
export const isOutsideRef = (v: unknown): v is OutsideRef => typeof v === 'object' && v !== null && !Array.isArray(v) && typeof (v as OutsideRef).entity === 'number';

/** One numeric field some nodes set: the column is `columns[component][field]` of the world. */
export interface FieldWrites {
  readonly component: number;
  readonly field: number;
  readonly node: Uint16Array;
  readonly value: Float64Array;
}

/** A prefab's links of one relation: link `j` goes from node `source[j]` to node `target[j]`. */
export interface LinkRun {
  readonly relation: Relation<any>;
  readonly source: Uint16Array;
  readonly target: Uint16Array;
  /** Per field of the relation some link sets: which links (indices `j`), and the values. The rest keep their defaults. */
  readonly writes: readonly { readonly field: number; readonly link: Uint16Array; readonly value: Float64Array }[];
}

/** A prefab that holds a node: its key, and where in the outer prefab its instance is (`''`: the outer prefab itself). */
export interface PrefabOwner {
  readonly key: string;
  readonly at: string;
}

/**
 * `path` (a path of the outer prefab) as a path of `owner`'s own instance in
 * it: `''` its root, `seat` for `rider/seat` under an owner at `rider` -- or
 * null for one outside that instance. The one rule every reader of owners
 * goes by.
 */
export function pathInOwner(owner: PrefabOwner, path: string): string | null {
  if (owner.at === '') return path;
  if (path === owner.at) return '';
  return path.startsWith(`${owner.at}/`) ? path.slice(owner.at.length + 1) : null;
}

/** A prefab, flattened: node 0 is the root, a parent always before its children. */
export interface CompiledPrefab {
  /** 1 and up; 0 is "no prefab" in the `Instance` column. */
  readonly id: number;
  readonly key: string;
  readonly count: number;
  readonly kinds: readonly Kind[];
  /** Each node's id path in the file, joined by '/' ('' for the root). */
  readonly paths: readonly string[];
  readonly names: readonly (string | null)[];
  /** Each node's parent node, -1 for the root. */
  readonly parents: Int16Array;
  /** What differs from the defaults. */
  readonly writes: readonly FieldWrites[];
  /** Every field of every node, defaults included (what a pool resets from: Docs/prefabs.md §5). */
  readonly full: readonly FieldWrites[];
  /** `ref()` fields: the node, and the node it points at. */
  readonly refs: readonly { readonly component: number; readonly field: number; readonly node: Uint16Array; readonly target: Uint16Array }[];
  /** One run per relation: each link's two nodes, and its fields that differ from the relation's defaults. */
  readonly links: readonly LinkRun[];
  /** Object components' data, as their `save` gives it: loaded through `load`, or set as is. */
  readonly objects: readonly { readonly component: AnyComponent; readonly node: number; readonly data: unknown }[];
  readonly layers: Uint8Array;
  readonly off: readonly { readonly node: number; readonly component: number }[];
  /**
   * Each node's `Render.model` as text (`'props/crate'`, a part `'props/robot#arm'`), null for a node
   * that has no `Render` or no model: what the editor's previews, `keys.d.ts`'s check and a pool's drain read.
   */
  readonly views: readonly (string | null)[];
  /**
   * Each node's prefabs, innermost first: the one whose file makes the entity,
   * then each that nests it, out to this one -- each with `at`, the path inside
   * this prefab of the instance it nests (`''` for this prefab itself). Which
   * prefab a difference on an instance can be applied to (Docs/prefabs.md §7, Apply).
   */
  readonly owners: readonly (readonly PrefabOwner[])[];
  /** Its pool's numbers, from the file or `pool()` in code; null for none (Docs/prefabs.md §5). */
  readonly pool: Readonly<PoolSize> | null;
}

// ── what the compiler knows of an instance (src/prefab-token.ts fills it in) ───

declare const made: unique symbol;
declare const makes: unique symbol;

/**
 * An entity a typed prefab token made, to the compiler alone: an `Entity`
 * everywhere, which `init` holds to `C`, the names of the components that
 * entity of the prefab is made with. `W` is what an error calls it
 * (`crates/big · rider`). Nothing at run time carries it.
 */
export type Made<C extends string, W extends string> = Entity & { readonly [made]: { readonly with: C; readonly is: W } };

/** What a typed token or node says it makes (`instantiate`, `part`), to the compiler alone. */
export interface Makes<E extends Entity> {
  readonly [makes]?: E;
}

/** The entity `instantiate(p)` or `part(root, p)` gives: `Made<...>` from a typed token, a plain `Entity` from the engine's own. */
export type EntityOf<P> = P extends Makes<infer E> ? (Entity extends E ? Entity : E) : Entity;

/**
 * `unknown` if `init(e, T)` is right for `e`, else the reason, as a string the
 * compiler prints: `e` is `Made` and `T`'s name is not among what it is made
 * with. A plain `Entity`, and a component whose type has no literal name, pass.
 */
export type MadeWith<E, T> = E extends { readonly [made]: { readonly with: infer C; readonly is: infer W extends string } }
  ? T extends { readonly name: infer N extends string }
    ? string extends N ? unknown
      : N extends C ? unknown
      : `${W} is not made with ${N}: init fills in what its prefab file lists -- list ${N} there, or add() it`
    : unknown
  : unknown;

/** A node of a prefab, by name: `Turret.node('muzzle')`. Resolved by the compile. */
export class PrefabNode {
  readonly prefab: PrefabToken;
  readonly name: string;
  index = -1;
  readonly made: string;
  constructor(prefab: PrefabToken, name: string, made: string) {
    this.prefab = prefab;
    this.name = name;
    this.made = made;
  }
}

/** `prefab(key)`: made at module level, before the files are compiled; `id` is set by the compile. */
export class PrefabToken {
  readonly key: string;
  id = 0;
  readonly made: string;
  constructor(key: string, made: string) {
    this.key = key;
    this.made = made;
  }
  /** A named entity of this prefab, for `cmd.part(root, node)`. */
  node(name: string): PrefabNode {
    const made = new PrefabNode(this, name, `${this.key}.node('${name}')`);
    if (this.id !== 0) resolveNode(made);
    nodeTokens.push(made);
    return made;
  }
}

const table: (CompiledPrefab | null)[] = [null];
const byKey = new Map<string, CompiledPrefab>();
const tokens = new Map<string, PrefabToken>();
/** Every node token made: resolved again by each compile, as a recompiled file may move its nodes. */
const nodeTokens: PrefabNode[] = [];
/** Pools declared in code, by key (`pool()`), and the call as written, for an error. */
const codePools = new Map<string, { size: PoolSize; made: string }>();

/** Every compiled prefab by id; index 0 is null (no prefab). */
export const compiledPrefabs = (): readonly (CompiledPrefab | null)[] => table;
export const compiledPrefab = (key: string): CompiledPrefab | undefined => byKey.get(caseKey(key));

/** What a save or a clip says of a prefab as it was: its nodes' kinds, in node order, and their names. */
export interface PrefabThen {
  readonly kinds: readonly string[];
  readonly names?: readonly (string | null)[];
}

/**
 * Saved entities of a prefab's instances found again in it as compiled now
 * (Docs/prefabs.md §6): one rule for `world.load` and the editor's paste.
 *
 * - **By its kind's name**, the node's id path (`crates/big/rider`), wherever
 *   that node is now: an entity put before it, or one added, moves its index,
 *   never its name. Returned per entity: its node now, or -1 for one the prefab
 *   no longer has -- a plain entity, where the instance left it.
 * - **An id renamed** (`rider` to `passenger`, its `name` kept): a node gone and
 *   a node added that share a `name` are one, the saved entity found as the
 *   added node. Each gone node takes the first added one of its name, in node
 *   order; `then.names` is the names as saved (a save from before them has
 *   none: a rename there reads as one gone and one added). What was under it
 *   moves with it: `arm/tail` is `limb/tail` after `arm` became `limb`.
 * - **A node new in the prefab** is not made for older instances.
 * - **Said once per prefab, by id path**, through `say`: `prefab crates/big:
 *   rider no longer in it; flag, passenger added since`, a rename `prefab
 *   crates/big: rider is passenger now (the same name)`. `then` is the prefab
 *   when it was saved or copied, where that says (else what its entities were,
 *   which misses a node every instance had lost).
 */
export function refindNodes(p: CompiledPrefab, kinds: readonly string[], then: PrefabThen | undefined, say: (what: string) => void): number[] {
  const now = new Map(p.kinds.map((k, i) => [k.name, i]));
  const before = new Set([...(then?.kinds ?? []), ...kinds]);
  const pathOf = (kind: string): string => (kind.startsWith(`${p.key}/`) ? kind.slice(p.key.length + 1) : kind);
  const added: number[] = [];
  p.kinds.forEach((k, i) => {
    if (!before.has(k.name)) added.push(i);
  });
  // A gone node and an added one of the same name: an id renamed, the one node -- and what was under it
  // is under it still, at the new id's path. Parents come first in `then`, so a rename is known before its subtree.
  const renamed = new Map<string, number>();
  const moved: [string, string][] = [];
  const gone: string[] = [];
  for (const k of before) {
    if (now.has(k)) continue;
    const path = pathOf(k);
    const under = moved.find(([from]) => path.startsWith(`${from}/`));
    let match = under ? added.findIndex((i) => p.paths[i] === `${under[1]}${path.slice(under[0].length)}`) : -1;
    if (match < 0) {
      const at = then ? then.kinds.indexOf(k) : -1;
      const name = at >= 0 ? (then?.names?.[at] ?? null) : null;
      match = name === null ? -1 : added.findIndex((i) => p.names[i] === name);
      if (match >= 0) moved.push([path, p.paths[added[match]!]!]);
    }
    if (match < 0) {
      gone.push(k);
      continue;
    }
    renamed.set(k, added[match]!);
    added.splice(match, 1);
  }
  const said: string[] = [];
  for (const [from, to] of moved) said.push(`${from} is ${to} now (the same name)`);
  if (gone.length > 0) said.push(`${gone.map(pathOf).join(', ')} no longer in it`);
  if (added.length > 0) said.push(`${added.map((i) => p.paths[i]).join(', ')} added since`);
  if (said.length > 0) say(`prefab ${p.key}: ${said.join('; ')}`);
  return kinds.map((k) => now.get(k) ?? renamed.get(k) ?? -1);
}

/**
 * A pool for a prefab, in code (Docs/prefabs.md §5): `pool(Turret, { warm: 32,
 * max: 256 })` at module level, before `Prefabs.compile()`, which checks it. The
 * same as `"pool"` in the file, and one or the other: both is an error naming
 * both. Returns the token.
 */
export function pool<P extends PrefabToken>(token: P, size: PoolSize): P {
  // A game module evaluated again (a generation, `component.ts`) declares its pool again: the next compile takes the new numbers.
  if (byKey.has(token.key) && !generationOpen()) throw new Error(`[prefab] pool(${token.made}) after the prefabs were compiled: declare a pool at module level, before Prefabs.compile()`);
  codePools.set(token.key, { size: { warm: size.warm, max: size.max }, made: `pool(${token.made}, { warm: ${size.warm}, max: ${size.max} })` });
  return token;
}

/**
 * A prefab by key, in any case (a key is the path lowercased, `caseKey`), for
 * `cmd.instantiate`. One token per key; usable at module level, before the compile.
 */
export function prefab(asked: string): PrefabToken {
  const key = caseKey(asked);
  let made = tokens.get(key);
  if (!made) {
    made = new PrefabToken(key, `prefab('${asked}')`);
    tokens.set(key, made);
    const compiled = byKey.get(key);
    if (compiled) made.id = compiled.id;
  }
  // Named by a game module evaluated again, not by the editor: game code's, as the ones `markGameTokens` saw --
  // found or made, so a key the editor's Spawn list made a token for first becomes the game's once its code names it.
  if (gameTokens && generationOpen()) gameTokens.add(made);
  return made;
}

/** The tokens `prefabOfKey` has handed out, by the key's id: one each, so a system asking again allocates nothing. */
const byKeyId = new Map<number, PrefabToken>();

/**
 * The prefab a `key('Prefab')` field holds -- its column's or a data component's id (a loot table's entry) -- as
 * a token for `cmd.instantiate`: what a file names, spawned by a system. Null for none (0), for an id that is no
 * prefab's key, and for a prefab not compiled (its file gone). The token is made the first time, then the same one:
 * a system may call it each tick, allocating nothing.
 */
export function prefabOfKey(id: number): PrefabToken | null {
  if (id === 0) return null;
  let made = byKeyId.get(id);
  if (!made) {
    const text = keyText('Prefab', id);
    // Only a compiled prefab's: a token made for a key no file has would be one the next compile refuses.
    if (text === null || !compiledPrefab(text)) return null;
    made = prefab(text);
    byKeyId.set(id, made);
  }
  return made.id !== 0 ? made : null;
}

function resolveNode(n: PrefabNode): void {
  n.index = nodeIndex(n, byKey);
}

/** Where a node token is in `prefabs`, or why it is nowhere. */
function nodeIndex(n: PrefabNode, prefabs: ReadonlyMap<string, CompiledPrefab>): number {
  const p = prefabs.get(n.prefab.key)!;
  const index = p.names.indexOf(n.name);
  if (index < 0) throw new Error(`[prefab] ${n.made}: ${n.prefab.key} has no entity named '${n.name}' (it has ${p.names.filter((x) => x).join(', ') || 'none named'})`);
  return index;
}

// ── the compile ───────────────────────────────────────────────────────────

interface Flat {
  path: string;
  parent: number;
  name: string | null;
  components: AnyComponent[];
  data: Map<AnyComponent, Map<number, number>>;
  refs: Map<AnyComponent, Map<number, string>>;
  objects: Map<AnyComponent, unknown>;
  /** `to` a path; `data` the link's fields by index, where set. */
  links: { relation: Relation<any>; to: string; data: Map<number, number> }[];
  layer: number;
  off: Set<AnyComponent>;
  /** The prefabs that hold it, innermost first (`CompiledPrefab.owners`). */
  owners: PrefabOwner[];
}

const join = (path: readonly string[]): string => path.join('/');

/** An entity of a prefab as a compile check sees it: its components, and a numeric field's value where the file set one. */
export interface PrefabNodeView {
  readonly components: readonly AnyComponent[];
  value(component: AnyComponent, field: string): number | undefined;
  /** Its parent in the file (a nested prefab's entities included), or null for the root. */
  parent(): PrefabNodeView | null;
}

/** What `checkPrefabNodes` was handed: each run over every entity of every prefab compiled. */
const nodeChecks: ((node: PrefabNodeView) => string | null)[] = [];

/**
 * A rule the compile holds every prefab entity to, beyond its own (the engine's physics: a still-only shape on a dynamic
 * body, Docs/physics.md §4.2): `check` answers why an entity is wrong, or null. Said as a compile error at the entity.
 * At module level, as a component is defined.
 */
export function checkPrefabNodes(check: (node: PrefabNodeView) => string | null): void {
  nodeChecks.push(check);
}

/** What the compile is told of the world outside the ECS. */
export interface CompileOptions {
  /**
   * Whether a `Render.model` key names a model
   * (`Assets.prefabChecks` asks the assets). Given, an unknown key is an error
   * naming the prefab and the entity, so a typo fails at boot, never the first
   * time the prefab is made. Left out (the engine's tests, the worker), a model
   * key is not looked at.
   */
  model?: (key: string) => boolean;
  /**
   * The named objects of a model's glb (`Assets.partsOf`), for a key with a
   * part (`props/robot#arm`): given, a part the glb lacks is an error naming
   * the ones it has. Null for a model whose parts are not known here (a pack's).
   */
  parts?: (key: string) => readonly string[] | null;
  /**
   * Whether a `Render.material` key names a material file (`Assets.prefabChecks`). Given, an unknown
   * key is an error naming the prefab and the entity, as a model's is; left out, not looked at.
   */
  material?: (key: string) => boolean;
  /**
   * A kind for a node whose components changed since its kind was made: debug
   * builds' live recompile passes `kindAgain` (`compileLive`); without it, that
   * is an error.
   */
  remake?: (name: string, list: readonly AnyComponent[]) => Kind;
  /** Whether a key names a prefab file of this compile: a data component's `key('Prefab')` checked against it (given by the compile itself). */
  prefab?: (key: string) => boolean;
}

/**
 * `files` by key in its one spelling (`caseKey`): a file's own key, as a glob
 * or a test spells it, lowercased -- the same record when every key already is.
 */
function casedFiles(files: Record<string, PrefabFile>): Record<string, PrefabFile> {
  const keys = Object.keys(files);
  if (keys.every((k) => k === caseKey(k))) return files;
  const out: Record<string, PrefabFile> = {};
  for (const k of keys) out[caseKey(k)] = files[k]!;
  return out;
}

/**
 * `flatten(key, from)` over `files`: each key flattened once, innermost first
 * as nesting asks, a cycle an error naming the chain; `flat` what is done.
 */
function flattener(files: Record<string, PrefabFile>, options: CompileOptions): { flat: Map<string, Flat[]>; flatten: (key: string, from: string) => Flat[] } {
  const flat = new Map<string, Flat[]>();
  const doing: string[] = [];
  const flatten = (key: string, from: string): Flat[] => {
    const done = flat.get(key);
    if (done) return done;
    if (doing.includes(key)) throw new Error(`[prefab] a cycle: ${[...doing.slice(doing.indexOf(key)), key].join(' -> ')}`);
    const file = files[key];
    if (!file) throw new Error(`[prefab] ${from}: no prefab '${key}'`);
    doing.push(key);
    const made = flattenFile(key, file, flatten, { prefab: (k) => files[caseKey(k)] !== undefined, ...options });
    doing.pop();
    flat.set(key, made);
    return made;
  };
  return { flat, flatten };
}

/**
 * Every prefab file compiled, by key: innermost first, each nesting and override
 * flattened. Replaces what an earlier compile of the same keys made (a kind is
 * reused when its name and components match). Throws on the first problem --
 * and then changes nothing: every prefab is built and every node token placed
 * before the tables are touched, so what an earlier compile made stands whole
 * (a recompile in the dev server, which pools depend on). Only kinds outlive a
 * throw, and a kind made is the same one next time, by its name.
 */
export function compilePrefabs(asked: Record<string, PrefabFile>, options: CompileOptions = {}): readonly CompiledPrefab[] {
  const files = casedFiles(asked);
  const { flat, flatten } = flattener(files, options);
  for (const key of Object.keys(files).sort()) flatten(key, key);
  for (const [key, t] of tokens) if (!files[key]) throw new Error(`[prefab] ${t.made} at module level: no prefab file has the key '${key}'`);

  for (const [key, p] of codePools) if (!files[key]) throw new Error(`[prefab] ${p.made} at module level: no prefab file has the key '${key}'`);

  // Everything resolved first...
  const out: CompiledPrefab[] = [];
  const next = new Map(byKey);
  let fresh = table.length;
  for (const key of Object.keys(files).sort()) {
    const old = byKey.get(key);
    const nodes = flat.get(key)!;
    const made = build(key, old ? old.id : fresh++, nodes, poolOf(key, files[key]!, nodes), options);
    next.set(key, made);
    out.push(made);
  }
  const indices = nodeTokens.map((n) => nodeIndex(n, next));
  // ...then committed, where nothing can throw.
  for (const made of out) {
    table[made.id] = made;
    byKey.set(made.key, made);
    const t = tokens.get(made.key);
    if (t) t.id = made.id;
  }
  nodeTokens.forEach((n, i) => (n.index = indices[i]!));
  return out;
}

/**
 * `key` as `files` say it, put through every check of the compile -- its
 * nesting (a cycle), its overrides' paths, its components, fields and refs,
 * its pool, and each node game code names (`BigCrate.node('rider')`) of it
 * or of a prefab nesting it still there -- and nothing made: no kind, no
 * table touched. Its error, or null.
 * What the editor runs on a file before it writes it (Docs/prefabs.md §7), so
 * a Save never leaves a file that does not compile.
 */
export function checkPrefab(asked: string, given: Record<string, PrefabFile>, options: Pick<CompileOptions, 'model' | 'parts' | 'material'> = {}): string | null {
  const key = caseKey(asked);
  const files = casedFiles(given);
  const { flatten } = flattener(files, options);
  try {
    const nodes = flatten(key, key);
    poolOf(key, files[key]!, nodes);
    // A node game code names (`BigCrate.node('rider')`) of this prefab, or of one nesting it: still there, or the
    // compile fails on it -- refused before anything is written, as a rename of a prefab game code names is.
    const lost: string[] = [];
    for (const n of nodeTokens) {
      const k = n.prefab.key;
      if (lost.includes(n.made) || !files[k]) continue;
      const of = k === key ? nodes : flatten(k, k);
      if (k !== key && !of.some((x) => x.owners.some((o) => o.key === key))) continue;
      if (!of.some((x) => x.name === n.name)) lost.push(n.made);
    }
    if (lost.length > 0) return `game code names ${lost.join(', ')}: ${key} would leave ${lost.length === 1 ? 'it' : 'them'} no entity -- change it there first`;
    return null;
  } catch (err) {
    return err instanceof Error ? err.message : String(err);
  }
}

/** The tokens game code made, at module level: what `markGameTokens` saw. Null until it is called. */
let gameTokens: Set<PrefabToken> | null = null;

/**
 * The tokens that exist now are game code's (made at module level, before the
 * first compile): any made later is the editor's (its Spawn list, by key).
 * Debug builds' boot calls it once, before the editor makes any
 * (`packages/editor/src/assets/boot.ts`); `compileLive` tells the two apart by it.
 */
export function markGameTokens(): void {
  gameTokens ??= new Set(tokens.values());
}

/**
 * Debug builds' live recompile (Docs/prefabs.md §7), the editor's alone
 * (`packages/editor/src/prefabs-live.ts`) -- a separate function, so a release, which
 * never recompiles, has none of it. `compilePrefabs`, with `remake` (a node
 * whose components changed gets a new kind of the same name, `kindAgain`),
 * and a prefab whose file is gone forgotten by key: `compiledPrefab(key)`
 * none, its table row kept for the instances still out, and a token the
 * editor made of it set to none. One game code made, or with a node or a pool
 * taken, is still an error: game code names it. Atomic as the compile is.
 */
export function compileLive(given: Record<string, PrefabFile>, options: CompileOptions, remake: NonNullable<CompileOptions['remake']>): readonly CompiledPrefab[] {
  const files = casedFiles(given);
  const orphans = [...tokens].filter(([key, t]) => !files[key] && !gameTokens?.has(t) && !codePools.has(key) && !nodeTokens.some((n) => n.prefab === t));
  for (const [key] of orphans) tokens.delete(key);
  try {
    const out = compilePrefabs(files, { ...options, remake });
    for (const key of [...byKey.keys()]) if (!files[key]) byKey.delete(key);
    for (const [, t] of orphans) t.id = 0;
    return out;
  } finally {
    // Kept as tokens: `prefab(key)` gives the same one if the file comes back.
    for (const [key, t] of orphans) tokens.set(key, t);
  }
}

/** A prefab's pool, from its file or from `pool()` in code -- one, never both -- checked; null for none. */
function poolOf(key: string, file: PrefabFile, nodes: readonly Flat[]): PoolSize | null {
  const code = codePools.get(key);
  if (file.pool !== undefined && code) throw new Error(`[prefab] ${key}: a pool in its file and ${code.made} in code -- keep one`);
  const size: unknown = code ? code.size : file.pool;
  if (size === undefined) return null;
  const where = code ? code.made : `${key}: its "pool"`;
  const whole = (n: unknown): n is number => typeof n === 'number' && Number.isInteger(n);
  const { warm, max } = (size ?? {}) as Partial<PoolSize>;
  if (typeof size !== 'object' || size === null || !whole(warm) || !whole(max)) throw new Error(`[prefab] ${where}: a pool is { "warm": n, "max": n }, both whole numbers`);
  if (max < 1 || warm < 0 || warm > max) throw new Error(`[prefab] ${where}: warm ${warm} and max ${max} -- max is at least 1, and warm from 0 to max`);
  // Parked is Disabled at the root and taken is Disabled off: a root its file switches off could not be both.
  if (nodes[0]!.components.includes(Disabled)) throw new Error(`[prefab] ${where}: its root is Disabled in the file, and a pooled root is switched off while parked and on when taken -- switch it off in code`);
  return { warm, max };
}

const componentByName = (name: string): AnyComponent | undefined => allComponents().find((c) => c.name === name);

// ── the keys a file may write ─────────────────────────────────────────────

/**
 * The keys each shape of a prefab file takes (Docs/prefabs.md §2): anything
 * else is an error, never dropped without a word -- `"name"` on a nested
 * instance's line, `"dta"` on an entity. Mirrored in
 * `packages/pipeline/src/assets/prefab-names.ts` (`PREFAB_KEYS`, as it cannot import this);
 * `src/prefab-names.test.ts` holds the two tables, and their words, equal.
 */
export const PREFAB_KEYS = {
  file: ['uid', 'is', 'version', 'pool', 'entities'],
  entity: ['id', 'parent', 'name', 'components', 'data', 'tags', 'objects', 'refs', 'links', 'layer', 'off'],
  nested: ['id', 'parent', 'prefab', 'overrides'],
  override: ['at', 'set', 'add', 'remove', 'off', 'on', 'layer', 'name', 'removed', 'links', 'refs', 'objects', 'parent'],
  link: ['relation', 'to', 'data'],
  linkOverride: ['relation', 'to', 'set'],
} as const;
export type KeyShape = keyof typeof PREFAB_KEYS;

/** How many single-letter edits turn `a` into `b` (for "did you mean"). */
function editDistance(a: string, b: string): number {
  let row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const next = [i];
    for (let j = 1; j <= b.length; j++) next.push(Math.min(row[j]! + 1, next[j - 1]! + 1, row[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1)));
    row = next;
  }
  return row[b.length]!;
}

/**
 * What is wrong with `key` on a `shape` of the file, or null for a key it
 * takes: its proper home where it has one (`"name" on a nested instance is an
 * override -- { "at": [], "name": … }`), else "no key" with the nearest it
 * takes. The same words as `prefab-names.ts`' `keyProblem`.
 */
export function keyProblem(shape: KeyShape, key: string): string | null {
  const allowed: readonly string[] = PREFAB_KEYS[shape];
  if (allowed.includes(key)) return null;
  const q = `"${key}"`;
  // The old form of Render (Docs/render.md §1), gone: no backwards compatibility (Docs/asset-ids.md).
  if (key === 'view' && (shape === 'entity' || shape === 'override' || shape === 'nested')) return `${q} is gone: a model is Render's -- ${shape === 'entity' ? '"data"' : 'an override\'s "set"'}: { "Render": { "model": … } }`;
  if (shape === 'nested') {
    const as = key === 'data' ? 'set' : key === 'components' || key === 'tags' ? 'add' : key;
    if ((PREFAB_KEYS.override as readonly string[]).includes(as) && as !== 'at') {
      return `${q} on a nested instance is an override${as === key ? '' : `'s "${as}"`} -- { "at": [], "${as}": … }`;
    }
  }
  if (shape === 'entity') {
    if (key === 'overrides') return `${q} go with "prefab", on a nested instance's line`;
    if (key === 'set' || key === 'add' || key === 'remove' || key === 'on' || key === 'removed' || key === 'at') return `${q} is an override's, in a nested instance's "overrides"`;
  }
  if (shape === 'override') {
    if (key === 'data') return `${q} in an override is "set"`;
    if (key === 'components' || key === 'tags') return `${q} in an override is "add"`;
    if (key === 'id' || key === 'prefab' || key === 'overrides') return `${q} belongs on the nested instance's own line, not in an override`;
  }
  if (shape === 'link' && key === 'set') return `a link's fields are its "data"`;
  if (shape === 'linkOverride' && key === 'data') return `a link override's fields are its "set"`;
  let near = '';
  let best = 3;
  for (const k of allowed) {
    const d = editDistance(key, k);
    if (d < best) [near, best] = [k, d];
  }
  return `no key ${q}${near ? ` (did you mean "${near}"?)` : ''}`;
}

/** Each key of `value` checked against `shape`'s; the first problem thrown, prefixed by `where`. */
function checkKeys(value: unknown, shape: KeyShape, where: string): void {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return;
  for (const k of Object.keys(value)) {
    const problem = keyProblem(shape, k);
    if (problem) throw new Error(`${where}: ${problem}`);
  }
}

function flattenFile(key: string, file: PrefabFile, flatten: (key: string, from: string) => Flat[], options: CompileOptions): Flat[] {
  const where = (path: string) => `[prefab] ${key}: ${path === '' ? 'its root' : `at ${path}`}`;
  /**
   * A key field's text from the file, checked and interned: a `Model` key against the models
   * (`options.model`), its part after `#` against the glb's named objects (`options.parts`); a
   * `Material` key against the material files (`options.material`).
   */
  const keyOf = (kind: string, text: string, what: string, from: string): number => {
    if (kind === 'Material' && text !== '' && options.material && !options.material(caseKey(text))) {
      throw new Error(`${where(from)}: ${what} '${text}' is no material -- a key is a file's path under src/assets/materials/ without .material, lowercased (AssetKeys.Material)`);
    }
    if (kind === 'Model' && text !== '') {
      const { model, part } = splitModel(caseKey(text));
      if (options.model && !options.model(model)) throw new Error(`${where(from)}: ${what} '${text}' is no model -- a key is a file's path under src/assets/models/ without its extension, lowercased (AssetKeys.Model)`);
      const parts = part !== null && options.parts ? options.parts(model) : null;
      if (parts && !parts.some((p) => caseKey(p) === part)) {
        throw new Error(`${where(from)}: ${what} '${text}': ${model} has no part '${part}' -- ${parts.length > 0 ? `its named objects are ${parts.join(', ')}` : 'it has no named objects'}`);
      }
    }
    return internKey(kind, text);
  };
  if (!file || file.is !== 'vibebase.prefab') throw new Error(`[prefab] ${key}: not a prefab file ("is" should be "vibebase.prefab")`);
  if (file.version !== 1) throw new Error(`[prefab] ${key}: version ${String(file.version)}, and this reads version 1`);
  checkKeys(file, 'file', `[prefab] ${key}`);
  if (!Array.isArray(file.entities) || file.entities.length === 0) throw new Error(`[prefab] ${key}: no entities`);
  const nodes: Flat[] = [];
  const at = new Map<string, number>();
  const pathOf = (p: string | Path | null, from: string): number => {
    if (p === null) return -1;
    const k = typeof p === 'string' ? p : join(p);
    const n = at.get(k);
    if (n === undefined) throw new Error(`${where(from)}: no entity '${k}' in the prefab`);
    return n;
  };
  const component = (name: string, from: string): AnyComponent => {
    const c = componentByName(name);
    if (!c) throw new Error(`${where(from)}: no component '${name}'`);
    if (c.kind === 'relation') throw new Error(`${where(from)}: '${name}' is a relation: put it in links`);
    if (c.bit < 0) throw new Error(`${where(from)}: every entity has ${name} already`);
    return c;
  };
  /** A field systems set as the game runs (`component(..., { runtime })`, Docs/ecs.md §3): never the file's to give -- refused, so the file says what the game does. */
  const runtime = (c: AnyComponent, f: number, cname: string, from: string): void => {
    const field = (c as Component).fields[f]!;
    if (field.runtime) throw new Error(`${where(from)}: ${cname}.${field.name} is set by systems as the game runs (a runtime field): a prefab cannot give it -- take it out of the file`);
  };
  const set = (node: Flat, data: Record<string, Record<string, FileValue>>, from: string) => {
    for (const [cname, fields] of Object.entries(data)) {
      const c = component(cname, from);
      if (c.kind !== 'data') throw new Error(`${where(from)}: ${cname} has no numeric fields to set`);
      if (!node.components.includes(c)) throw new Error(`${where(from)}: data for ${cname}, which the entity does not have`);
      const row = node.data.get(c) ?? new Map<number, number>();
      for (const [entry, given] of Object.entries(fields)) {
        // A vector's `[x, y, z]` is its columns, an axis each (`fields.ts`); any other entry its own column.
        const each = unfoldEntry(c, entry, given);
        if (each === null) throw new Error(`${where(from)}: ${cname} has no field '${entry}'`);
        if ('error' in each) throw new Error(`${where(from)}: ${each.error}`);
        for (const { column: fname, value: v } of each) {
          const f = c.fields.findIndex((x) => x.name === fname);
          runtime(c, f, cname, from);
          const kind = keyKindOf(c, fname);
          // A reference by uid first, its key as written else (Docs/asset-ids.md §1, rule 4): a moved asset's stale key read right.
          if (kind !== null && (typeof v === 'string' || isKeyRef(v))) {
            row.set(f, keyOf(kind, resolveRef(kind, v) ?? '', `${cname}.${fname}`, from));
            continue;
          }
          // An enum's name, flags' names, a colour's text: a name none of its names is refused, named.
          const why = fieldProblem(c, fname, v);
          if (why !== null) throw new Error(`${where(from)}: ${why}`);
          const n = fieldValue(c, fname, v);
          if (n === null) throw new Error(`${where(from)}: ${cname}.${fname} is not a number${kind === null ? '' : ` or a ${kind} key`}`);
          row.set(f, n);
        }
      }
      node.data.set(c, row);
    }
  };
  /** A link's fields set from the file: by index, each a number. */
  const setLink = (data: Map<number, number>, r: Relation<any>, fields: Record<string, number | boolean>, from: string) => {
    for (const [fname, v] of Object.entries(fields)) {
      const f = r.fields.findIndex((x) => x.name === fname);
      if (f < 0) throw new Error(`${where(from)}: the relation ${r.name} has no field '${fname}'`);
      if (typeof v !== 'number' && typeof v !== 'boolean') throw new Error(`${where(from)}: ${r.name}.${fname} is not a number`);
      data.set(f, typeof v === 'boolean' ? (v ? 1 : 0) : v);
    }
  };
  /**
   * A key in a data component, checked as far as the compile can: a prefab against the files, a model and a material
   * against the assets where it is told of them.
   */
  const dataKey = (kind: string, text: string): string | null => {
    const k = caseKey(text);
    if (kind === 'Prefab' && options.prefab && !options.prefab(k)) return `no prefab "${text}"`;
    if (kind === 'Model' && options.model && !options.model(splitModel(k).model)) return `no model "${text}"`;
    if (kind === 'Material' && options.material && !options.material(k)) return `no material "${text}"`;
    return null;
  };
  /**
   * A data component's fields from the file, checked against its schema at every step (`ecs/data.ts`), its refs as
   * paths of this file's flattening -- `inside` the nested instance an override is of, or the file's own -- and its
   * fields over what `was` there (an override of a nested one: each field it gives replaces that field whole, D9).
   */
  const dataObject = (c: DataComponentOf, cname: string, value: unknown, from: string, inside: string | null, was: unknown): Record<string, unknown> => {
    if (typeof value !== 'object' || value === null || Array.isArray(value)) throw new Error(`${where(from)}: ${cname} is a data component: its fields, { … }`);
    for (const f of Object.keys(value)) if (c.runtime.includes(f)) throw new Error(`${where(from)}: ${cname}.${f} is set by systems as the game runs (a runtime field): a prefab cannot give it -- take it out of the file`);
    const check = { ref: () => NO_REF, key: (kind: string, text: string) => dataKey(kind, text) };
    try {
      fillFrom(c.data, value, {}, check);
    } catch (error) {
      if (error instanceof DataError) throw new Error(`${where(from)}: ${cname}.${error.message}`);
      throw error;
    }
    const pathed = mapFields(c.data, value, (r, at) => {
      if (r === null) return null;
      if (inside === null) {
        if (typeof r === 'string' && r !== '') return r;
        if (Array.isArray(r) && r.every((x) => typeof x === 'string')) return join(r);
      } else {
        if (Array.isArray(r) && r.every((x) => typeof x === 'string')) return join([inside, ...r]);
        if (typeof r === 'string' && r !== '') return `${inside}/${r}`;
      }
      throw new Error(`${where(from)}: ${cname}.${at}: a ref in a prefab is ${inside === null ? 'an entity\'s id or a path ["b7", "m3"]' : `a path inside '${inside}'`}, or null${isOutsideRef(r) ? ' -- a ref to an entity outside the instance is a scene\'s alone' : ''}, not ${JSON.stringify(r)}`);
    }) as Record<string, unknown>;
    return { ...((was ?? {}) as Record<string, unknown>), ...pathed };
  };
  /** An object component's data from the file, checked: each instance its own object, never the file's. */
  const objectData = (c: AnyComponent, cname: string, value: unknown, from: string): void => {
    if (c.kind !== 'object') throw new Error(`${where(from)}: ${cname} is no object component`);
    if (isData(c)) return;
    // Through `load`, as a saved game is. Only a plain value (a string, a number, a yes or no) can be the same on
    // every instance, and only in a slot no pool owns.
    const plain = value === null || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean';
    if (!c.load && (!plain || c.create)) {
      throw new Error(`${where(from)}: ${cname} has no load, so a prefab cannot give it data -- every instance would share the file's one object. Give ${cname} save and load, or leave it out of the file and set it in code`);
    }
  };
  /** A ref field's index in `c`, checked to be a `ref()`. */
  const refField = (c: AnyComponent, cname: string, fname: string, from: string): number => {
    const f = c.kind === 'data' ? c.fields.findIndex((x) => x.name === fname) : -1;
    if (f < 0 || !((c as Component).schema as Record<string, { ref?: true }>)[fname]!.ref) throw new Error(`${where(from)}: ${cname} has no ref() field '${fname}'`);
    runtime(c, f, cname, from);
    return f;
  };
  /** Inner entities an override put under another, and where it says so: checked for a loop once all are read. */
  const moved: { node: number; from: string }[] = [];
  /** The override that removed each node it removed, as `at <path>`: what a ref or link to what it took is told. */
  const removedBy = new Map<number, string>();
  /** What this file changes or puts inside a nested instance -- an override's entity, an entity of its own under one -- and where it says so. */
  const touched: { node: number; from: string }[] = [];
  const ids = new Set<string>();
  // Plain entities and nested roots in file order; a parent may come later, so two passes.
  const pending: { node: number; parent: string | Path | null; from: string }[] = [];
  const later: (() => void)[] = [];
  for (const ent of file.entities) {
    if (!ent || typeof ent.id !== 'string' || ent.id === '') throw new Error(`[prefab] ${key}: an entity without an id`);
    // A path joins ids with '/': an id 'gun1/m' would be the path into a nested 'gun1', and one would overwrite the other.
    if (ent.id.includes('/')) throw new Error(`${where(ent.id)}: an id with '/' in it, which joins the ids of a path -- rename it ('${ent.id.replaceAll('/', '-')}')`);
    if (ids.has(ent.id)) throw new Error(`${where(ent.id)}: the id '${ent.id}' twice`);
    ids.add(ent.id);
    if (ent.parent === undefined) throw new Error(`${where(ent.id)}: no parent (null for the root)`);
    checkKeys(ent, ent.prefab !== undefined ? 'nested' : 'entity', where(ent.id));
    for (const l of ent.links ?? []) checkKeys(l, 'link', `${where(ent.id)}: a link`);
    if (ent.prefab !== undefined) {
      const nests = nestedKey(ent);
      if (nests === null) throw new Error(`${where(ent.id)}: "prefab" is the nested prefab -- { "uid": …, "key": … }, or its key`);
      const inner = flatten(nests, `${key} at ${ent.id}`);
      const base = nodes.length;
      for (const n of inner) {
        const copy: Flat = {
          ...n,
          path: n.path === '' ? ent.id : `${ent.id}/${n.path}`,
          parent: n.parent < 0 ? -1 : n.parent + base,
          components: [...n.components],
          data: new Map([...n.data].map(([c, m]) => [c, new Map(m)])),
          refs: new Map([...n.refs].map(([c, m]) => [c, new Map([...m].map(([f, p]) => [f, p === '' ? ent.id : `${ent.id}/${p}`]))])),
          objects: new Map([...n.objects].map(([c, v]) => [c, isData(c) ? mapFields(c.data, v, (p) => (typeof p === 'string' ? (p === '' ? ent.id : `${ent.id}/${p}`) : p)) : v])),
          links: n.links.map((l) => ({ relation: l.relation, to: l.to === '' ? ent.id : `${ent.id}/${l.to}`, data: new Map(l.data) })),
          off: new Set(n.off),
          owners: [...n.owners.map((o) => ({ key: o.key, at: o.at === '' ? ent.id : `${ent.id}/${o.at}` })), { key, at: '' }],
        };
        at.set(copy.path, nodes.length);
        nodes.push(copy);
      }
      pending.push({ node: base, parent: ent.parent, from: ent.id });
      for (const o of ent.overrides ?? []) {
        later.push(() => {
          if (!Array.isArray(o.at)) throw new Error(`${where(ent.id)}: an override without "at"`);
          const from = join([ent.id, ...o.at]);
          checkKeys(o, 'override', where(from));
          for (const l of o.links ?? []) checkKeys(l, 'linkOverride', `${where(from)}: a link override`);
          const n = pathOf([ent.id, ...o.at], from);
          const node = nodes[n]!;
          if (o.removed) {
            if (o.at.length === 0) throw new Error(`${where(from)}: the root of a nested instance cannot be removed: remove the entity '${ent.id}' itself`);
            node.parent = -2;
            removedBy.set(n, `at ${from}`);
            return;
          }
          touched.push({ node: n, from });
          for (const name of o.add ?? []) {
            const c = component(name, from);
            if (!node.components.includes(c)) node.components.push(c);
          }
          const drop = (c: AnyComponent): void => {
            node.components = node.components.filter((x) => x !== c);
            node.data.delete(c);
            node.refs.delete(c);
            node.objects.delete(c);
            node.off.delete(c);
          };
          for (const name of o.remove ?? []) drop(component(name, from));
          if (o.set) set(node, o.set, from);
          for (const name of o.off ?? []) node.off.add(component(name, from));
          for (const name of o.on ?? []) node.off.delete(component(name, from));
          for (const [cname, value] of Object.entries(o.objects ?? {})) {
            const c = component(cname, from);
            if (c === Name) throw new Error(`${where(from)}: an entity's Name is the override's "name"`);
            objectData(c, cname, value, from);
            if (!node.components.includes(c)) throw new Error(`${where(from)}: data for ${cname}, which the entity does not have -- "add" it in the same override`);
            node.objects.set(c, isData(c) ? dataObject(c, cname, value, from, ent.id, node.objects.get(c)) : value);
          }
          for (const [cname, fields] of Object.entries(o.refs ?? {})) {
            const c = component(cname, from);
            if (c.kind !== 'data' || !node.components.includes(c)) throw new Error(`${where(from)}: refs for ${cname}, which the entity does not have`);
            const row = node.refs.get(c) ?? new Map<number, string>();
            for (const [fname, to] of Object.entries(fields)) {
              const f = refField(c, cname, fname, from);
              // null: the nested prefab's ref cleared -- it points at nobody here (Docs/prefabs.md §2).
              if (to === null) {
                row.delete(f);
                continue;
              }
              if (!Array.isArray(to)) throw new Error(`${where(from)}: the ref ${cname}.${fname} is not a path inside '${ent.id}', nor null${typeof to === 'object' ? ' -- a ref to an entity outside the instance is a scene\'s alone' : ''}`);
              row.set(f, nodes[pathOf([ent.id, ...to], from)]!.path);
            }
            node.refs.set(c, row);
          }
          if (o.parent !== undefined) {
            if (!Array.isArray(o.parent)) throw new Error(`${where(from)}: a parent override is a path inside '${ent.id}'`);
            if (o.at.length === 0) throw new Error(`${where(from)}: the root of a nested instance is placed by the entity's own "parent", not an override`);
            node.parent = pathOf([ent.id, ...o.parent], from);
            moved.push({ node: n, from });
          }
          if (o.layer !== undefined) node.layer = o.layer & 31;
          if (o.name !== undefined) node.name = o.name;
          for (const l of o.links ?? []) {
            if (!l || !Array.isArray(l.to)) throw new Error(`${where(from)}: a link override without "to", a path inside '${ent.id}'`);
            const to = join([ent.id, ...l.to]);
            const link = node.links.find((x) => x.relation.name === l.relation && x.to === to);
            if (!link) throw new Error(`${where(from)}: no ${l.relation} link to ${to} to set`);
            setLink(link.data, link.relation, l.set ?? {}, from);
          }
        });
      }
      continue;
    }
    const node: Flat = { path: ent.id, parent: -1, name: ent.name ?? null, components: [], data: new Map(), refs: new Map(), objects: new Map(), links: [], layer: (ent.layer ?? 0) & 31, off: new Set(), owners: [{ key, at: '' }] };
    for (const name of [...(ent.components ?? []), ...(ent.tags ?? [])]) {
      const c = component(name, ent.id);
      if (!node.components.includes(c)) node.components.push(c);
    }
    if (ent.data) set(node, ent.data, ent.id);
    for (const [cname, value] of Object.entries(ent.objects ?? {})) {
      const c = component(cname, ent.id);
      objectData(c, cname, value, ent.id);
      if (!node.components.includes(c)) node.components.push(c);
      node.objects.set(c, isData(c) ? dataObject(c, cname, value, ent.id, null, undefined) : value);
    }
    for (const name of ent.off ?? []) node.off.add(component(name, ent.id));
    for (const l of ent.links ?? []) {
      const r = componentByName(l.relation);
      if (!r || r.kind !== 'relation') throw new Error(`${where(ent.id)}: no relation '${l.relation}'`);
      const data = new Map<number, number>();
      setLink(data, r, l.data ?? {}, ent.id);
      later.push(() => node.links.push({ relation: r, to: nodes[pathOf(l.to, ent.id)]!.path, data }));
    }
    for (const [cname, fields] of Object.entries(ent.refs ?? {})) {
      const c = component(cname, ent.id);
      if (c.kind !== 'data' || !node.components.includes(c)) throw new Error(`${where(ent.id)}: refs for ${cname}, which the entity does not have`);
      const row = new Map<number, string>();
      for (const [fname, to] of Object.entries(fields)) {
        const f = refField(c, cname, fname, ent.id);
        later.push(() => row.set(f, nodes[pathOf(to, ent.id)]!.path));
      }
      node.refs.set(c, row);
    }
    at.set(node.path, nodes.length);
    pending.push({ node: nodes.length, parent: ent.parent, from: ent.id });
    if (ent.parent !== null) touched.push({ node: nodes.length, from: ent.id });
    nodes.push(node);
  }
  for (const p of pending) nodes[p.node]!.parent = pathOf(p.parent, p.from);
  for (const f of later) f();
  // An inner entity put under one of its own descendants: in no tree under the root, so nobody would see it.
  for (const { node, from } of moved) {
    for (let n = nodes[node]!.parent, steps = 0; n >= 0 && steps <= nodes.length; n = nodes[n]!.parent, steps++) {
      if (n === node) throw new Error(`${where(from)}: its parent override puts it under itself`);
    }
  }
  // A change to, or an entity under, what another override removed: nobody would ever see it, so the file is wrong.
  for (const { node, from } of touched) {
    // At most one step a node: parents that go round in a loop are the walk below's to say.
    for (let n = node, steps = 0; n >= 0 && steps <= nodes.length; n = nodes[n]!.parent, steps++) {
      const by = removedBy.get(n);
      if (by) throw new Error(`${where(from)}: inside ${nodes[n]!.path}, which the override ${by} removes: drop one or the other`);
    }
  }
  if (nodes[0]!.parent !== -1 || pending.filter((p) => p.parent === null).length !== 1) throw new Error(`[prefab] ${key}: the first entity is the root, and the only one with parent null`);
  if (nodeChecks.length > 0) {
    const views: PrefabNodeView[] = nodes.map((node) => ({
      components: node.components,
      value: (c, field) => {
        const index = c.kind === 'data' ? c.fields.findIndex((f) => f.name === field) : -1;
        return index < 0 ? undefined : node.data.get(c)?.get(index);
      },
      parent: () => (node.parent >= 0 ? views[node.parent]! : null),
    }));
    for (let i = 0; i < nodes.length; i++) {
      for (const check of nodeChecks) {
        const why = check(views[i]!);
        if (why !== null) throw new Error(`${where(nodes[i]!.path)}: ${why}`);
      }
    }
  }
  // In tree order from the root, so a parent comes before its children; removed subtrees left out.
  const order: number[] = [];
  const visit = (n: number, depth: number) => {
    if (depth > nodes.length) throw new Error(`${where(nodes[n]!.path)}: its parents go round in a loop`);
    order.push(n);
    for (let c = 0; c < nodes.length; c++) if (nodes[c]!.parent === n) visit(c, depth + 1);
  };
  visit(0, 0);
  const index = new Map(order.map((n, i) => [n, i]));
  const kept = new Set(order.map((n) => nodes[n]!.path));
  // A ref or link from what stays to what an override took: the file points at nothing, and says which override did it.
  const gone = (path: string): string => {
    for (let n = at.get(path)!; n >= 0; n = nodes[n]!.parent) {
      const by = removedBy.get(n);
      if (by) return `the override ${by} removes`;
    }
    return 'is in no tree under the root';
  };
  for (const n of order) {
    const node = nodes[n]!;
    for (const [c, m] of node.refs) {
      for (const [f, p] of m) {
        const fname = (c as Component).fields[f]!.name;
        if (!kept.has(p)) throw new Error(`${where(node.path)}: the ref ${c.name}.${fname} points at ${p}, which ${gone(p)}`);
        // A typed ref (`ref(Health)`) points only at a node with what it needs (Docs/properties.md D4).
        const field = ((c as Component).schema as Record<string, Field>)[fname]!;
        const target = nodes[at.get(p)!]!;
        const why = refMisfit(field, (name) => target.components.some((x) => x.name === name), p);
        if (why !== null) throw new Error(`${where(node.path)}: the ref ${c.name}.${fname} points at ${why}`);
      }
    }
    for (const l of node.links) if (!kept.has(l.to)) throw new Error(`${where(node.path)}: the link ${l.relation.name} to ${l.to}, which ${gone(l.to)}`);
    // A data component's refs, wherever they are in it: at an entity there is, which has what a typed one needs.
    for (const [c, v] of node.objects) {
      if (!isData(c)) continue;
      for (const [fname, el] of Object.entries(c.data)) {
        eachRef(el, (v as Record<string, unknown>)[fname], (p, path) => {
          if (typeof p !== 'string') return;
          const n = at.get(p);
          if (n === undefined) throw new Error(`${where(node.path)}: ${c.name}.${path}: no entity '${p}' in the prefab`);
          if (!kept.has(p)) throw new Error(`${where(node.path)}: ${c.name}.${path} points at ${p}, which ${gone(p)}`);
          const target = nodes[n]!;
          const field = refElementAt(el, path.slice(fname.length));
          const why = field ? refMisfit(field, (name) => target.components.some((x) => x.name === name), p) : null;
          if (why !== null) throw new Error(`${where(node.path)}: ${c.name}.${path}: ${why}`);
        }, fname);
      }
    }
  }
  // Paths are relative to the prefab: its root is '' and the root's own id leaves every path.
  const top = nodes[0]!.path;
  const rel = (p: string) => (p === top ? '' : p.startsWith(`${top}/`) ? p.slice(top.length + 1) : p);
  // So a variant's own entity and one of its base's may not share an id: both paths would be that id. Ids in
  // a prefab are unique, what it nests included (`prefab-names.ts` refuses the same).
  const nested = file.entities[0]!.prefab;
  const base = nested === undefined ? null : resolveRef('prefabs', nested);
  if (base !== null) {
    const own = new Set<string>();
    for (const node of nodes) if (!node.path.startsWith(`${top}/`) && node.path !== top) own.add(node.path);
    for (const node of nodes) {
      const r = rel(node.path);
      if (node.path.startsWith(`${top}/`) && own.has(r)) throw new Error(`[prefab] ${key}: the id '${r}' is also ${base}'s '${r}': ids in a prefab are unique, what its root nests included -- rename this one`);
    }
  }
  return order.map((n) => {
    const node = nodes[n]!;
    return {
      ...node,
      path: rel(node.path),
      parent: node.parent < 0 ? -1 : index.get(node.parent)!,
      refs: new Map([...node.refs].map(([c, m]) => [c, new Map([...m].map(([f, p]) => [f, rel(p)]))])),
      objects: new Map([...node.objects].map(([c, v]) => [c, isData(c) ? mapFields(c.data, v, (p) => (typeof p === 'string' ? rel(p) : p)) : v])),
      links: node.links.map((l) => ({ relation: l.relation, to: rel(l.to), data: l.data })),
      owners: node.owners.map((o) => ({ key: o.key, at: o.at === '' ? '' : rel(o.at) })),
    };
  });
}

/**
 * A data component's file data, its refs node indices (or null), in its one form: read and written again, so a key
 * is `{ uid, key }`, a dict whichever form it writes, every field there (at its default where the file left it out).
 * What an instance's own is compared with (`overridesOf`, `fitInstance`). A node index is carried as `n + 1`, 0 nobody.
 */
export function canonical(c: DataComponentOf, data: unknown): Record<string, unknown> {
  const value = fillFrom(c.data, data, {}, { ref: (n) => (typeof n === 'number' ? n + 1 : 0) as EntityRef });
  return dataPlain(record(c.data), value, (r) => (r === 0 ? null : r - 1)) as Record<string, unknown>;
}

/** The `ref()` field at `rest` (a path's steps after its field: `[2]`, `.sword`, `[0].who`) inside `el`, for its `needs`; null if none there. */
function refElementAt(el: Element, rest: string): Field | null {
  let at: Element = el;
  let tail = rest;
  while (tail !== '') {
    if (!('shape' in at)) return null;
    const m = /^(\[[^\]]*\]|\.[^.[]+)/.exec(tail);
    if (!m) return null;
    tail = tail.slice(m[0].length);
    if (at.shape === 'list') at = at.of;
    else if (at.shape === 'dict') at = at.valueOf;
    else if (at.shape === 'record') {
      const f = (at.fields as Record<string, Element>)[m[0].slice(1)];
      if (!f) return null;
      at = f;
    } else return null;
  }
  return 'shape' in at || !at.ref ? null : at;
}

/** A node's `Render.model` as text, or null: what `CompiledPrefab.views` holds. */
function viewText(n: Flat): string | null {
  if (!n.components.includes(Render)) return null;
  const model = n.data.get(Render)?.get(Render.fields.findIndex((f) => f.name === 'model'));
  return model === undefined ? null : keyText('Model', model);
}

function build(key: string, id: number, nodes: Flat[], pool: PoolSize | null, options: CompileOptions): CompiledPrefab {
  const pathIndex = new Map(nodes.map((n, i) => [n.path, i]));
  const kinds = nodes.map((n) => {
    const name = n.path === '' ? key : `${key}/${n.path}`;
    const list = n.name !== null && !n.components.includes(Name) ? [...n.components, Name] : n.components;
    const old = kindNamed(name);
    if (old) {
      if (old.components.length === list.length && list.every((c) => old.components.includes(c))) return old;
      if (options.remake) return options.remake(name, list);
      throw new Error(`[prefab] ${key}: the kind '${name}' was made before with other components; a reload makes it anew`);
    }
    return kind(name, list);
  });
  const fieldRuns = (all: boolean): FieldWrites[] => {
    const runs = new Map<string, { component: number; field: number; node: number[]; value: number[] }>();
    nodes.forEach((n, i) => {
      for (const c of n.components) {
        if (c.kind !== 'data') continue;
        const set = n.data.get(c);
        c.fields.forEach((f, fi) => {
          const v = set?.get(fi);
          if (!all && (v === undefined || v === f.initial)) return;
          const k = `${c.id}.${fi}`;
          const run = runs.get(k) ?? { component: c.id, field: fi, node: [], value: [] };
          run.node.push(i);
          run.value.push(v ?? f.initial);
          runs.set(k, run);
        });
      }
    });
    return [...runs.values()].map((r) => ({ component: r.component, field: r.field, node: Uint16Array.from(r.node), value: Float64Array.from(r.value) }));
  };
  const refs = new Map<string, { component: number; field: number; node: number[]; target: number[] }>();
  const links = new Map<Relation<any>, { source: number[]; target: number[]; data: Map<number, number>[] }>();
  const objects: { component: AnyComponent; node: number; data: unknown }[] = [];
  nodes.forEach((n, i) => {
    for (const [c, m] of n.refs)
      for (const [f, p] of m) {
        const k = `${c.id}.${f}`;
        const r = refs.get(k) ?? { component: c.id, field: f, node: [], target: [] };
        r.node.push(i);
        r.target.push(pathIndex.get(p)!);
        refs.set(k, r);
      }
    for (const l of n.links) {
      const r = links.get(l.relation) ?? { source: [], target: [], data: [] };
      r.source.push(i);
      r.target.push(pathIndex.get(l.to)!);
      r.data.push(l.data);
      links.set(l.relation, r);
    }
    if (n.name !== null) objects.push({ component: Name, node: i, data: n.name });
    // A data component's in one form (`canonical`): its refs the nodes' indices, so an instance and an override compare by it.
    for (const [c, data] of n.objects) if (c !== Name || n.name === null) objects.push({ component: c, node: i, data: isData(c) ? canonical(c, mapFields(c.data, data, (p) => (typeof p === 'string' ? (pathIndex.get(p) ?? null) : p))) : data });
  });
  return {
    id,
    key,
    count: nodes.length,
    kinds,
    paths: nodes.map((n) => n.path),
    names: nodes.map((n) => n.name),
    parents: Int16Array.from(nodes.map((n) => n.parent)),
    writes: fieldRuns(false),
    full: fieldRuns(true),
    refs: [...refs.values()].map((r) => ({ component: r.component, field: r.field, node: Uint16Array.from(r.node), target: Uint16Array.from(r.target) })),
    links: [...links].map(([relation, r]) => ({
      relation,
      source: Uint16Array.from(r.source),
      target: Uint16Array.from(r.target),
      // Like `writes`: per field, the links that set it apart from its default.
      writes: relation.fields.flatMap((f, fi) => {
        const link = r.data.flatMap((d, j) => (d.has(fi) && d.get(fi) !== f.initial ? [j] : []));
        return link.length ? [{ field: fi, link: Uint16Array.from(link), value: Float64Array.from(link.map((j) => r.data[j]!.get(fi)!)) }] : [];
      }),
    })),
    objects,
    layers: Uint8Array.from(nodes.map((n) => n.layer)),
    off: nodes.flatMap((n, i) => [...n.off].map((c) => ({ node: i, component: c.id }))),
    views: nodes.map(viewText),
    owners: nodes.map((n) => n.owners),
    pool,
  };
}
