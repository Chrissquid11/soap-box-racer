/**
 * The one allocator: every per-entity array in the world comes from here
 * (Docs/ecs.md §3, storage).
 *
 * An array is `rows` long (times a width), and lives in a property of some
 * owner: `store.x`, `entities.gen`. Growing makes each one longer and puts the
 * longer array back in that property. So nothing may keep a column across a
 * tick boundary; within a tick they never change, which is when systems run.
 *
 * **Fixed-length arrays, on purpose.** A length-tracking array over a
 * resizable buffer would grow without being replaced, but V8 runs a loop over
 * one four times slower (measured: 1.1 ns an entity against 4.7), and over a
 * growable shared buffer forty times. A fixed-length view has no such cost,
 * even over a growable shared buffer -- which is what `shared` uses, so there
 * growing copies nothing: the buffer grows in place and gets a new view.
 *
 * `shared` puts every array in a `SharedArrayBuffer`, for workers (§10). It
 * needs a cross-origin isolated page; without one, plain arrays.
 */

type TypedArray = Float32Array | Float64Array | Int8Array | Uint8Array | Int16Array | Uint16Array | Int32Array | Uint32Array;
type TypedArrayConstructor = { new (length: number): TypedArray; new (buffer: ArrayBufferLike, byteOffset: number, length: number): TypedArray; readonly BYTES_PER_ELEMENT: number };

export const ARRAY_OF = {
  f32: Float32Array,
  f64: Float64Array,
  i8: Int8Array,
  u8: Uint8Array,
  i16: Int16Array,
  u16: Uint16Array,
  i32: Int32Array,
  u32: Uint32Array,
} as const satisfies Record<string, TypedArrayConstructor>;

interface Entry {
  owner: Record<string, unknown>;
  key: string;
  ctor: TypedArrayConstructor;
  /** Elements per row. */
  width: number;
  array: TypedArray;
  buffer: GrowableShared | null;
}

/** A `SharedArrayBuffer` made with `maxByteLength`: ES2024, not in this project's `lib`. */
interface GrowableShared extends SharedArrayBuffer {
  grow(bytes: number): void;
}

export class Alloc {
  /** Rows every array has now. */
  rows: number;
  /** Rows they may grow to. */
  readonly maxRows: number;
  readonly shared: boolean;
  /** How many times it has grown: a game that always grows should start larger. */
  growths = 0;
  private readonly entries: Entry[] = [];
  /** In a worker: the main thread's buffers, to be taken one a column in the order it made them. */
  private readonly given: SharedArrayBuffer[] | null;
  private taken = 0;
  /** Set once workers hold the buffers: a column made after that is one they would not have. */
  private frozen = false;

  constructor(rows: number, maxRows: number, shared: boolean, given: SharedArrayBuffer[] | null = null) {
    this.rows = rows;
    this.maxRows = Math.max(rows, maxRows);
    this.shared = shared || given !== null;
    this.given = given;
  }

  /** A zero-filled array of `rows * width` elements, put in `owner[key]`, and kept there through every growth. */
  column(owner: object, key: string, type: keyof typeof ARRAY_OF, width = 1): void {
    const ctor: TypedArrayConstructor = ARRAY_OF[type];
    const entry: Entry = { owner: owner as Record<string, unknown>, key, ctor, width, array: null!, buffer: null };
    const length = this.rows * width;
    if (this.frozen) {
      throw new Error(`[ecs] a column for '${key}' was asked for after workers were started: register every system, and list every component in \`changed\`, before startWorkers()`);
    }
    if (this.given) {
      const buffer = this.given[this.taken++];
      if (!buffer) throw new Error(`[ecs] this worker needs a column ('${key}') the main thread never made: both must define the same components and register the same systems, in the same order`);
      entry.buffer = buffer as GrowableShared;
      entry.array = new ctor(buffer, 0, length);
    } else if (this.shared) {
      const options = { maxByteLength: this.maxRows * width * ctor.BYTES_PER_ELEMENT };
      entry.buffer = new (SharedArrayBuffer as unknown as new (bytes: number, options: object) => GrowableShared)(length * ctor.BYTES_PER_ELEMENT, options);
      entry.array = new ctor(entry.buffer, 0, length);
    } else {
      entry.array = new ctor(length);
    }
    entry.owner[key] = entry.array;
    this.entries.push(entry);
  }

  /**
   * Every array to `rows`. Only the first `used` rows are carried over: the
   * rest was never written, and copying zeros would make the system commit
   * memory nothing uses.
   */
  grow(rows: number, used: number): void {
    if (rows <= this.rows) return;
    if (rows > this.maxRows) throw new Error(`[ecs] cannot grow to ${rows} rows: the ceiling is ${this.maxRows}`);
    for (const entry of this.entries) {
      const length = rows * entry.width;
      if (entry.buffer) {
        // In place: the old view stays valid over the same memory.
        entry.buffer.grow(length * entry.ctor.BYTES_PER_ELEMENT);
        entry.array = new entry.ctor(entry.buffer, 0, length);
      } else {
        const grown = new entry.ctor(length);
        grown.set(entry.array.subarray(0, used * entry.width));
        entry.array = grown;
      }
      entry.owner[entry.key] = entry.array;
    }
    this.rows = rows;
    this.growths++;
  }

  /** In a worker: the main thread grew the buffers to `rows`, so every view is made again at that length. */
  follow(rows: number): void {
    for (const entry of this.entries) {
      entry.array = new entry.ctor(entry.buffer!, 0, rows * entry.width);
      entry.owner[entry.key] = entry.array;
    }
    this.rows = rows;
  }

  /** No more columns: workers have the list. */
  freeze(): void {
    this.frozen = true;
  }

  /** In a worker: how many of the main thread's buffers were not taken. Not 0 means the two differ. */
  spare(): number {
    return this.given ? this.given.length - this.taken : 0;
  }

  /** Bytes allocated, all arrays together. */
  bytes(): number {
    let total = 0;
    for (const entry of this.entries) total += entry.array.byteLength;
    return total;
  }

  /** The shared buffers, in the order their columns were made: what a worker is handed. Empty unless `shared`. */
  buffers(): SharedArrayBuffer[] {
    const out: SharedArrayBuffer[] = [];
    for (const entry of this.entries) if (entry.buffer) out.push(entry.buffer);
    return out;
  }
}

/**
 * An object with these properties, all null, for columns to be put in.
 *
 * **Not `{}` filled in a loop.** V8 turns an object into a hash table once
 * more than a dozen properties have been added to it by computed key
 * (`store[name] = ...`), and every `store.px[e]` after that is a hash lookup:
 * a component with ten fields ran eight times slower than one with three. An
 * object that `JSON.parse` makes has its properties as ordinary fields however
 * many there are; assigning to a property that already exists keeps it so.
 */
export function shaped<T extends object>(names: readonly string[]): T {
  return JSON.parse(`{${names.map((name) => `${JSON.stringify(name)}:null`).join(',')}}`) as T;
}
