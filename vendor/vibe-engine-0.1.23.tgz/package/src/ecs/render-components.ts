/**
 * What an entity is drawn as, as data (Docs/render.md §1, §2): `Render`, a
 * numeric component the engine defines and its `render` system draws
 * (`src/render.ts`). In a prefab's `components` and `data` like any other --
 * `"data": { "Render": { "model": "props/crate" } }` -- saved, overridden,
 * shown in the inspector; the three object it becomes is `View`, the engine's
 * own slot. And how it moves: `Animation`, a clip of its model's by name,
 * played by the engine's `animate` system (`src/animation.ts`, Docs/render.md
 * §5), which says when a clip played once has ended (`AnimationEnded`).
 * And what it is seen through: `Camera` (Docs/camera.md §2), made a three
 * camera by the engine's `camera` system (`src/camera.ts`), which `Game` draws
 * through.
 *
 * Pure: no DOM, no three. A node test imports it, and so does the worker.
 */
import { bool, color, component, enumOf, event, f32, i32, key, ref, u32 } from './component.ts';
import { keyText } from './keys.ts';

/**
 * The look of an entity. `model` a model's key (`'props/crate'`; `'props/robot#arm'`
 * the object named `arm` in that glb), `material` a material's (0: the model's own,
 * as authored), `tint` multiplied into every material of the view (white: none),
 * and the shadows. Keys are text in every file and ids in the column (`key()`).
 */
export const Render = component('Render', {
  model: key('Model', { help: 'The model drawn: a model\'s key, or one part of it (props/robot#arm)' }),
  material: key('Material', { help: 'A material file drawn in place of the model\'s own (none: as authored)' }),
  tint: color(0xffffff, { help: 'Multiplied into every material of the view: white is none' }),
  castShadow: bool(true),
  receiveShadow: bool(true),
}, { menu: 'Rendering', help: 'What it is drawn as: a model, a material, a tint, shadows' });

/** How a clip repeats: `auto` as the clip's extras say (Gladius writes `loop`), `repeat`, or `once`, holding its last pose. */
export const AnimationLoop = enumOf(['auto', 'repeat', 'once'], 'auto');

/**
 * The clip it plays, by its name among the model's own clips (`'fly'`: a
 * Gladius `action{}`'s, interned under `Clip` by name alone, so `'fly'` is
 * whatever model's `fly` the entity wears; 0: none, the rest pose). `speed` 1
 * as authored, negative backwards; `fade` the seconds of crossfade when `clip`
 * changes; `loop` (`AnimationLoop`) 0 `auto`, as the clip's extras say (Gladius writes
 * `loop`), 1 `repeat`, 2 `once`, holding its last pose; `time` where it is, seconds --
 * written by the `animate` system each frame, saved, never authored, so a
 * loaded game resumes mid-stride, and set by anyone to seek.
 */
export const Animation = component('Animation', {
  clip: key('Clip', { help: 'The clip played, by its name among the model\'s own (none: the rest pose)' }),
  speed: f32(1, { help: '1 as authored, negative backwards' }),
  fade: f32(0.2, { min: 0, help: 'Seconds of crossfade when the clip changes' }),
  loop: AnimationLoop.as('auto', { help: 'auto: as the clip says; repeat; once, holding its last pose' }),
  time: f32(),
}, { menu: 'Animation', help: 'The clip its model plays', runtime: ['time'] });

/**
 * A clip played once came to its end: `who` played it, `clip` which (a `Clip`
 * key). Emitted by the `animate` render system as it ends -- outside a tick,
 * so it belongs to the last tick and is read on the next, by any system
 * (`world.events(AnimationEnded)`, Docs/ecs.md §18); once a play.
 */
export const AnimationEnded = event('AnimationEnded', { who: ref(), clip: key('Clip') });

/** A camera's projection: `perspective` through its `fov`, or `orthographic` through its `size`. */
export const CameraProjection = enumOf(['perspective', 'orthographic'], 'perspective');
/** What a camera's rect is cleared to first: `none` (drawn over what is under it), its `colour` (`clearColor`), or the scene's `sky`. */
export const CameraClear = enumOf(['none', 'colour', 'sky'], 'sky');

/**
 * A camera: what the game sees from where the entity's `Transform` puts it
 * (looking down its -Z, its scale ignored), Docs/camera.md. `projection` 0
 * perspective, 1 orthographic (`CameraProjection`, an enum: a file writes the name); `fov` the vertical degrees of a perspective one,
 * `size` half the view's height in metres of an orthographic one; `near` and
 * `far` both's. `main` the camera the game is seen through (picking, the
 * pointer); `depth` the order several draw in, lowest first, each into its
 * `viewport` rect (`x`, `y`, `w`, `h`: fractions of the canvas from its bottom
 * left) -- split screen, a minimap, a picture in picture. `clear` how its rect
 * is cleared first (`CameraClear`): 0 not at all (depth alone: it draws over what is under it),
 * 1 to `clearColor`, 2 to the scene's own background (sky) -- the default, so a
 * new camera keeps the sky. `layers` the layers it
 * sees, a mask (every one by default) -- never the entity's own layer.
 */
export const Camera = component('Camera', {
  projection: CameraProjection,
  fov: f32(50, { label: 'Field of view', min: 1, max: 179, help: 'The vertical degrees a perspective camera sees' }),
  size: f32(5, { min: 0.001, help: 'Half the view\'s height in metres, of an orthographic camera' }),
  near: f32(0.1, { min: 0.0001, help: 'The nearest it draws, metres' }),
  far: f32(200, { min: 0.001, help: 'The farthest it draws, metres' }),
  main: bool(false, { help: 'The camera the game is seen through' }),
  depth: i32(0, { help: 'The order several draw in, lowest first' }),
  x: f32(0, { group: 'Viewport', min: 0, max: 1, help: 'Its rect\'s left, a fraction of the canvas from its left' }),
  y: f32(0, { group: 'Viewport', min: 0, max: 1, help: 'Its rect\'s bottom, a fraction of the canvas from its bottom' }),
  w: f32(1, { group: 'Viewport', label: 'Width', min: 0, max: 1, help: 'Its rect\'s width, a fraction of the canvas' }),
  h: f32(1, { group: 'Viewport', label: 'Height', min: 0, max: 1, help: 'Its rect\'s height, a fraction of the canvas' }),
  clear: CameraClear,
  clearColor: color(0x0b0d12, { label: 'Clear colour' }),
  layers: u32(0xffffffff, { help: 'The layers it sees, a mask: bit n is layer n' }),
}, { menu: 'Rendering', help: 'A camera the game is drawn through' });

/** A `Render.model` key's two halves: the model's key, and the part after `#` (null for the whole model). */
export function splitModel(text: string): { model: string; part: string | null } {
  const at = text.indexOf('#');
  return at < 0 ? { model: text, part: null } : { model: text.slice(0, at), part: text.slice(at + 1) || null };
}

/**
 * A `mesh()` field's (or `Render.model`'s) id as its two halves -- `{ model, part }`, the part null for the whole
 * model -- or null for none: `meshOf(store.body[e])`. The column holds the interned `key#part` (kind `Model`).
 */
export function meshOf(id: number): { model: string; part: string | null } | null {
  const text = keyText('Model', id);
  return text === null ? null : splitModel(text);
}
