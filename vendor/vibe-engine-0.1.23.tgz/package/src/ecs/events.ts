/**
 * Events: things that happened, as rows of numbers (Docs/ecs.md §18).
 *
 * A channel is one event type's storage in one world: a column a field, indexed
 * by event, oldest first. A writer appends (`emit`); a reader walks from the
 * first event it has not seen to `end` (`begin`).
 *
 * - **Seen from the next tick on.** `end` moves only at a tick boundary, so what
 *   a system emits on a tick no system reads on that tick, whatever order they
 *   run in. Deterministic, and one tick of delay.
 * - **Every reader sees every event once**, at any rate: a system reads the
 *   events of the ticks since it last ran, as it reads input (Docs/loop.md §7).
 *   Nothing is consumed; any number of systems read the same events.
 * - **Kept for 60 ticks**, the longest window, then dropped at a boundary.
 * - **No allocation**: columns are typed arrays that double at a boundary when
 *   half full. Row 0 is a scratch row: `emit` on a full channel returns it, and
 *   the event is lost with a warning rather than the game.
 *
 * Pure: no DOM, no three.
 */
import { CYCLE } from '../loop/index.ts';
import { ARRAY_OF, shaped } from './alloc.ts';
import type { Channel, EventType, Schema } from './component.ts';

/** What a channel needs of the world. */
export interface EventHost {
  /** The tick an event emitted now belongs to: the one running, or the last that ran. */
  eventTick(): number;
  /** Is a tick running? Outside one nothing holds a column, so a full channel may grow on the spot. */
  midTick(): boolean;
}

/** A channel, and the world's side of it. */
export interface ChannelControl<S extends Schema = Schema> {
  readonly type: EventType<S>;
  readonly channel: Channel<S>;
  /** At a tick boundary, `tick` being the last that ran: old events dropped, new ones made visible, room made. */
  roll(tick: number): void;
  /** Events dropped because the channel was full. */
  lost(): number;
  /** Every event dropped: for `world.load`, which may move the tick back. Events are not saved (Docs/ecs.md §19). */
  clear(): void;
}

type Columns = Record<string, { [i: number]: number; length: number; copyWithin(target: number, start: number, end: number): unknown }>;

const START = 256;

export function makeChannel<S extends Schema>(type: EventType<S>, host: EventHost): ChannelControl<S> {
  const names = type.fields.map((field) => field.name);
  const channel = shaped<Record<string, unknown>>([...names, 'tick', 'end', 'emit', 'begin']);
  const columns = channel as unknown as Columns;
  let capacity = START;
  /** The next free row. Row 0 is the scratch row. */
  let count = 1;
  let lost = 0;
  let warned = false;

  const allocate = (rows: number): void => {
    for (const field of type.fields) {
      const next = new ARRAY_OF[field.type](rows);
      if (columns[field.name]) next.set(columns[field.name] as never);
      columns[field.name] = next;
    }
    const tick = new Int32Array(rows);
    if (columns.tick) tick.set(columns.tick as unknown as Int32Array);
    columns.tick = tick;
    capacity = rows;
  };
  allocate(capacity);
  channel.end = 1;

  channel.emit = (): number => {
    if (count === capacity && !host.midTick()) allocate(capacity * 2);
    if (count === capacity) {
      lost++;
      if (!warned) {
        warned = true;
        console.warn(`[ecs] event channel '${type.name}' is full at ${capacity}: more than half its room was emitted in one tick. The event is lost; the channel grows at the boundary`);
      }
      return 0;
    }
    const i = count++;
    for (let f = 0; f < type.fields.length; f++) columns[names[f]!]![i] = type.fields[f]!.initial;
    columns.tick![i] = host.eventTick();
    return i;
  };

  channel.begin = (ctx: { tick: number; period?: number; staggered?: boolean; since?: number }): number => {
    if (ctx.staggered) {
      throw new Error(`[ecs] events of '${type.name}' read in a staggered system below 60 Hz: each of its slots would see every event again. Give the system stagger: false, or read the events at 60 Hz`);
    }
    // The ticks since the reader last ran: a render system's since the last frame.
    const from = ctx.since ?? ctx.tick - (ctx.period ?? 1);
    const tick = columns.tick!;
    const end = channel.end as number;
    // Events are in tick order: the first at or after `from`, by halving.
    let lo = 1;
    let hi = end;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (tick[mid]! < from) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  };

  return {
    type,
    channel: channel as unknown as Channel<S>,
    roll(now: number): void {
      // Older than the longest window: nobody will ask for them again.
      const tick = columns.tick!;
      let keep = 1;
      while (keep < count && tick[keep]! <= now - CYCLE) keep++;
      if (keep > 1) {
        for (const name of names) columns[name]!.copyWithin(1, keep, count);
        tick.copyWithin(1, keep, count);
        count -= keep - 1;
      }
      channel.end = count;
      if (count * 2 > capacity) {
        allocate(capacity * 2);
        warned = false;
      }
    },
    lost: () => lost,
    clear(): void {
      // The ticks may go back: events of the old ones would sit in front of the new, out of order, never pruned.
      count = 1;
      channel.end = 1;
    },
  };
}
