/**
 * World transforms from local ones and the hierarchy (Docs/ecs.md §8).
 *
 *   every update        things move: systems write `Transform`
 *   propagate           here, once a tick: world transforms for everything that changed
 *   every lateUpdate    things follow; after each that writes `Transform`, `late` for its members
 *   the boundary        `settle` for what a command spawned or re-parented
 *
 * **Nobody marks anything dirty.** Each pass compares an entity's local
 * transform with the copy taken the last time its world transform was worked
 * out -- ten float compares -- and recomputes on a difference, or when its
 * parent moved this tick. Entities are walked a depth at a time, so a parent is
 * always done before its children.
 *
 * **Previous and current.** `WorldTransform` is where an entity is; where it was
 * a tick ago is kept here, for the render phase to interpolate (`writeMatrix`).
 * After a tick, previous is where the entity was at the end of the tick before
 * if it moved on this one, and equal to the current values if not.
 *
 * World transforms are position, rotation and scale, not matrices: those three
 * interpolate correctly. Scale composes per axis, so a child rotated under a
 * non-uniformly scaled parent is not skewed. A parent without a `Transform`
 * passes nothing on: its children are placed as if they had no parent.
 *
 * Pure: no three.
 */
import type { Alloc } from './alloc.ts';
import { Members } from '../loop/members.ts';
import type { Store } from './component.ts';
import { Transform, WorldTransform, type Hierarchy } from './component.ts';

type Local = Store<typeof Transform.schema>;
type Global = Store<typeof WorldTransform.schema>;
type Links = Store<typeof Hierarchy.schema>;

/** The deepest an entity may sit in the tree. */
export const MAX_DEPTH = 32;

/** What propagation needs of the world: the masks, to know who has a `Transform`. */
export interface TransformHost {
  mask: Uint32Array;
  readonly words: number;
}

/** Numbers a transform is: position, rotation, scale. */
const STRIDE = 10;

const WORD = Transform.bit >>> 5;
const BIT = 1 << (Transform.bit & 31);

export class Transforms {
  /** Entities with a `Transform`, by depth in the tree. */
  readonly byDepth = new Members(MAX_DEPTH + 1);
  /**
   * Each entity's local transform as it was when its world transform was last
   * worked out, and its world transform a tick ago: ten numbers an entity, side
   * by side in one array each. Not columns, on purpose: both are only ever read
   * or written a whole row at a time, and ten numbers from one place are far
   * cheaper to reach than one from each of ten (measured: 4 ns against 16).
   */
  shadow!: Float32Array;
  prev!: Float32Array;
  private readonly host: TransformHost;
  private readonly local: Local;
  private readonly world: Global;
  private readonly links: Links;

  constructor(host: TransformHost, alloc: Alloc, local: Local, world: Global, links: Links) {
    this.host = host;
    this.local = local;
    this.world = world;
    this.links = links;
    alloc.column(this, 'shadow', 'f32', STRIDE);
    alloc.column(this, 'prev', 'f32', STRIDE);
  }

  /** Does `e` have a `Transform`? */
  has(e: number): boolean {
    return (this.host.mask[e * this.host.words + WORD]! & BIT) !== 0;
  }

  /** The parent whose world transform `e` hangs from: its parent if that has a `Transform`, else 0. */
  private anchor(e: number): number {
    const p = this.links.parent[e]!;
    return p !== 0 && this.has(p) ? p : 0;
  }

  /** Has `e`'s local transform changed since its world transform was worked out? */
  private differs(e: number): boolean {
    const l = this.local;
    const s = this.shadow;
    const i = e * STRIDE;
    return (
      l.px[e] !== s[i] || l.py[e] !== s[i + 1] || l.pz[e] !== s[i + 2] ||
      l.qx[e] !== s[i + 3] || l.qy[e] !== s[i + 4] || l.qz[e] !== s[i + 5] || l.qw[e] !== s[i + 6] ||
      l.sx[e] !== s[i + 7] || l.sy[e] !== s[i + 8] || l.sz[e] !== s[i + 9]
    );
  }

  /** Previous = current: the entity is where it is, with nothing to interpolate. */
  private rest(e: number): void {
    const w = this.world;
    const prev = this.prev;
    const i = e * STRIDE;
    prev[i] = w.px[e]!; prev[i + 1] = w.py[e]!; prev[i + 2] = w.pz[e]!;
    prev[i + 3] = w.qx[e]!; prev[i + 4] = w.qy[e]!; prev[i + 5] = w.qz[e]!; prev[i + 6] = w.qw[e]!;
    prev[i + 7] = w.sx[e]!; prev[i + 8] = w.sy[e]!; prev[i + 9] = w.sz[e]!;
  }

  /** The world transform of `e` from its local one and its parent `p`'s world (0 for none), and the shadow copy taken. */
  private compose(e: number, p: number): void {
    const l = this.local;
    const w = this.world;
    const s = this.shadow;
    const i = e * STRIDE;
    const px = l.px[e]!, py = l.py[e]!, pz = l.pz[e]!;
    const qx = l.qx[e]!, qy = l.qy[e]!, qz = l.qz[e]!, qw = l.qw[e]!;
    const sx = l.sx[e]!, sy = l.sy[e]!, sz = l.sz[e]!;
    s[i] = px; s[i + 1] = py; s[i + 2] = pz;
    s[i + 3] = qx; s[i + 4] = qy; s[i + 5] = qz; s[i + 6] = qw;
    s[i + 7] = sx; s[i + 8] = sy; s[i + 9] = sz;
    if (p === 0) {
      w.px[e] = px; w.py[e] = py; w.pz[e] = pz;
      w.qx[e] = qx; w.qy[e] = qy; w.qz[e] = qz; w.qw[e] = qw;
      w.sx[e] = sx; w.sy[e] = sy; w.sz[e] = sz;
      return;
    }
    const ax = w.qx[p]!, ay = w.qy[p]!, az = w.qz[p]!, aw = w.qw[p]!;
    const psx = w.sx[p]!, psy = w.sy[p]!, psz = w.sz[p]!;
    // The local position, scaled by the parent, turned by the parent, moved by the parent.
    const vx = px * psx, vy = py * psy, vz = pz * psz;
    const tx = 2 * (ay * vz - az * vy), ty = 2 * (az * vx - ax * vz), tz = 2 * (ax * vy - ay * vx);
    w.px[e] = w.px[p]! + vx + aw * tx + (ay * tz - az * ty);
    w.py[e] = w.py[p]! + vy + aw * ty + (az * tx - ax * tz);
    w.pz[e] = w.pz[p]! + vz + aw * tz + (ax * ty - ay * tx);
    w.qx[e] = aw * qx + ax * qw + ay * qz - az * qy;
    w.qy[e] = aw * qy - ax * qz + ay * qw + az * qx;
    w.qz[e] = aw * qz + ax * qy - ay * qx + az * qw;
    w.qw[e] = aw * qw - ax * qx - ay * qy - az * qz;
    w.sx[e] = sx * psx; w.sy[e] = sy * psy; w.sz[e] = sz * psz;
  }

  /** The tick's one full pass, between `update` and `lateUpdate`. */
  propagate(tick: number): void {
    const byDepth = this.byDepth;
    const mask = this.host.mask;
    const words = this.host.words;
    const changed = this.world.changed;
    const parent = this.links.parent;
    const s = this.shadow;
    // The columns in locals for the compare, which every entity gets every tick.
    const { px, py, pz, qx, qy, qz, qw, sx, sy, sz } = this.local;
    for (let depth = 0; depth <= MAX_DEPTH; depth++) {
      const count = byDepth.counts[depth]!;
      if (count === 0) continue;
      const list = byDepth.lists[depth]!;
      for (let n = 0; n < count; n++) {
        const e = list[n]!;
        const i = e * STRIDE;
        let p: number = parent[e]!;
        if (p !== 0 && (mask[p * words + WORD]! & BIT) === 0) p = 0;
        if (
          px[e] !== s[i] || py[e] !== s[i + 1] || pz[e] !== s[i + 2] ||
          qx[e] !== s[i + 3] || qy[e] !== s[i + 4] || qz[e] !== s[i + 5] || qw[e] !== s[i + 6] ||
          sx[e] !== s[i + 7] || sy[e] !== s[i + 8] || sz[e] !== s[i + 9] ||
          (p !== 0 && changed[p] === tick)
        ) {
          if (changed[e] !== tick) this.rest(e);
          this.compose(e, p);
          changed[e] = tick;
        } else if (changed[e] === tick - 1) {
          // It moved last tick and not on this one: nothing left to interpolate.
          this.rest(e);
        }
      }
    }
  }

  /** After a `lateUpdate` that writes `Transform`: its members that moved, and everything under them, again. */
  late(members: Uint32Array, count: number, tick: number): void {
    for (let n = 0; n < count; n++) {
      const e = members[n]!;
      if (this.has(e) && this.differs(e)) this.settle(e, tick, false);
    }
  }

  /**
   * `e` and everything under it, worked out again, stamped as changed on `tick`.
   * `snap` for a change that is not movement -- spawned, re-parented: previous
   * becomes current, so it does not slide there from wherever it was.
   */
  settle(e: number, tick: number, snap: boolean): void {
    const { world, links } = this;
    let n = e;
    for (;;) {
      if (this.has(n)) {
        if (!snap && world.changed[n] !== tick) this.rest(n);
        this.compose(n, this.anchor(n));
        if (snap) this.rest(n);
        world.changed[n] = tick;
      }
      // Pre-order through the links: down, else across, else up and across.
      const child = links.firstChild[n]!;
      if (child !== 0) {
        n = child;
        continue;
      }
      while (n !== e && links.nextSibling[n] === 0) n = links.parent[n]!;
      if (n === e) return;
      n = links.nextSibling[n]!;
    }
  }

  /**
   * `e`'s world transform as a 4x4 matrix, column-major (three.js's layout),
   * into `out`: `alpha` of the way from where it was a tick ago to where it is.
   * Position and scale go straight between the two; the rotation takes the
   * short way round and is made unit length again. `alpha` 1 is where it is now.
   */
  writeMatrix(e: number, alpha: number, out: number[] | Float32Array): void {
    const w = this.world;
    let px = w.px[e]!, py = w.py[e]!, pz = w.pz[e]!;
    let x = w.qx[e]!, y = w.qy[e]!, z = w.qz[e]!, q = w.qw[e]!;
    let sx = w.sx[e]!, sy = w.sy[e]!, sz = w.sz[e]!;
    if (alpha < 1) {
      const prev = this.prev;
      const i = e * STRIDE;
      const beta = 1 - alpha;
      px = prev[i]! * beta + px * alpha;
      py = prev[i + 1]! * beta + py * alpha;
      pz = prev[i + 2]! * beta + pz * alpha;
      sx = prev[i + 7]! * beta + sx * alpha;
      sy = prev[i + 8]! * beta + sy * alpha;
      sz = prev[i + 9]! * beta + sz * alpha;
      const ax = prev[i + 3]!, ay = prev[i + 4]!, az = prev[i + 5]!, aw = prev[i + 6]!;
      // The same rotation has two quaternions: blend toward the nearer.
      const toward = ax * x + ay * y + az * z + aw * q < 0 ? -alpha : alpha;
      x = ax * beta + x * toward;
      y = ay * beta + y * toward;
      z = az * beta + z * toward;
      q = aw * beta + q * toward;
      const length = Math.sqrt(x * x + y * y + z * z + q * q);
      if (length > 0) {
        x /= length;
        y /= length;
        z /= length;
        q /= length;
      }
    }
    const x2 = x + x, y2 = y + y, z2 = z + z;
    const xx = x * x2, xy = x * y2, xz = x * z2;
    const yy = y * y2, yz = y * z2, zz = z * z2;
    const wx = q * x2, wy = q * y2, wz = q * z2;
    out[0] = (1 - (yy + zz)) * sx;
    out[1] = (xy + wz) * sx;
    out[2] = (xz - wy) * sx;
    out[3] = 0;
    out[4] = (xy - wz) * sy;
    out[5] = (1 - (xx + zz)) * sy;
    out[6] = (yz + wx) * sy;
    out[7] = 0;
    out[8] = (xz + wy) * sz;
    out[9] = (yz - wx) * sz;
    out[10] = (1 - (xx + yy)) * sz;
    out[11] = 0;
    out[12] = px;
    out[13] = py;
    out[14] = pz;
    out[15] = 1;
  }
}
