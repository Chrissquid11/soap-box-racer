/**
 * Parallel systems on worker threads: the worker's side (Docs/ecs.md §10).
 *
 * A game's worker entry is three lines:
 *
 * ```ts
 * import { serve, webPort } from '../ecs/worker.ts';
 * import { registerSystems } from './systems.ts';
 * serve(registerSystems, webPort());
 * ```
 *
 * It must import the same component modules as the main thread, in the same
 * order, and register the same systems: `serve` checks, and says what differs.
 * It builds a world over the main thread's buffers, answers `ready`, and then
 * sleeps on its slot of the control array until a job arrives: a parallel
 * system's stage, over the share of members copied into its region.
 *
 * Nothing of the page is here, and nothing should be imported that needs it:
 * a worker has no DOM, no three.js scene, no assets.
 */
import { Loop } from '../loop/index.ts';
import { COUNT, ERROR_LENGTH, JOB, ROWS, SLOT, STAGE, STATE, TICK, type WorkerInit } from './parallel.ts';
import { World } from './world.ts';

/** The worker's line to the main thread. */
export interface WorkerPort {
  post(message: unknown): void;
  listen(handler: (message: any) => void): void;
}

/** A browser worker's own global as a `WorkerPort`. */
export function webPort(): WorkerPort {
  const scope = globalThis as unknown as { postMessage(message: unknown): void; onmessage: ((event: { data: any }) => void) | null };
  // Heard from the moment the port is taken, and kept until `listen`: a worker that awaits something first (a
  // project's tools' components, `import()`ed behind DEBUG_BUILD) would otherwise lose the page's `init`, which
  // comes while it waits -- a message to a worker with no listener is dropped.
  const early: unknown[] = [];
  let handler: ((message: any) => void) | null = null;
  scope.onmessage = (event) => (handler ? handler(event.data) : void early.push(event.data));
  return {
    post: (message) => scope.postMessage(message),
    listen: (next) => {
      handler = next;
      for (const message of early.splice(0)) next(message);
    },
  };
}

/**
 * Waits for `init`, builds the world's second view with `build` (the same
 * registration the main thread ran), and runs jobs for ever.
 */
export function serve(build: (world: World) => void, port: WorkerPort): void {
  port.listen((message: WorkerInit) => {
    if (message.type !== 'init') return;
    let world: World;
    try {
      world = new World({ loop: new Loop(), attach: message.sharing });
      build(world);
      world.build();
      const differs = world.mismatch(message.sharing);
      if (differs) throw new Error(differs);
    } catch (err) {
      port.post({ type: 'error', message: err instanceof Error ? err.message : String(err) });
      return;
    }
    port.post({ type: 'ready' });

    const control = new Int32Array(message.control);
    const slot = message.index * SLOT;
    const region = message.sharing.maxRows;
    const members = new Uint32Array(message.members, message.index * region * 4, region);
    const errors = new Uint16Array(message.errors, message.index * ERROR_LENGTH * 2, ERROR_LENGTH);
    for (;;) {
      // Asleep until the main thread sets a job and wakes this slot.
      Atomics.wait(control, slot + STATE, 0);
      if (Atomics.load(control, slot + STATE) !== 1) continue;
      try {
        world.follow(control[slot + ROWS]!);
        world.runJob(control[slot + JOB]!, control[slot + STAGE]!, members, control[slot + COUNT]!, control[slot + TICK]!);
        Atomics.store(control, slot + STATE, 0);
      } catch (err) {
        const text = err instanceof Error ? err.message : String(err);
        for (let i = 0; i < ERROR_LENGTH; i++) errors[i] = i < text.length ? text.charCodeAt(i) : 0;
        Atomics.store(control, slot + STATE, 2);
      }
    }
  });
}
