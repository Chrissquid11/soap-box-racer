/**
 * Parallel systems on worker threads: the main thread's side (Docs/ecs.md §10).
 *
 * ```ts
 * const world = new World({ loop, shared: true });
 * registerSystems(world);
 * const pool = await WorkerPool.start(world, [webWorker(new Worker(url, { type: 'module' })), ...]);
 * ```
 *
 * Each worker builds a second view of the same world over the same shared
 * buffers (`worker.ts`), and then sleeps. When a system marked `parallel` has
 * enough members, its member list is cut into equal shares: the first runs
 * here, the others are copied into each worker's region of a shared list and
 * the workers woken; then this thread waits for them.
 *
 * - **The same result with any number of workers.** A parallel system writes
 *   only its own members' rows, so it does not matter which thread ran which
 *   member, or in what order.
 * - **The main thread cannot sleep** in a browser, so it waits by spinning on
 *   an atomic. The wait is as long as the slowest share: short.
 * - **No allocation per job**: the shares are copied by a loop into memory that
 *   is already there, and a job is six numbers in a shared array.
 *
 * A worker's reply protocol is three messages: `ready`, or `error` with text,
 * after `init`; nothing after that, since jobs go through shared memory.
 *
 * Pure: no DOM, no node. A worker is whatever `WorkerLink` wraps.
 */
import type { ParallelRunner, World, WorldSharing } from './world.ts';

/** A worker, as the pool needs it: `webWorker()` wraps a browser's, a test wraps node's. */
export interface WorkerLink {
  post(message: unknown): void;
  /** Called once: the handler for every message from the worker. */
  listen(handler: (message: any) => void): void;
  stop(): void;
}

/** A browser `Worker` as a `WorkerLink`. */
export function webWorker(worker: { postMessage(message: unknown): void; terminate(): void; onmessage: ((event: any) => void) | null }): WorkerLink {
  return {
    post: (message) => worker.postMessage(message),
    listen: (handler) => {
      worker.onmessage = (event: { data: unknown }) => handler(event.data);
    },
    stop: () => worker.terminate(),
  };
}

/** What `init` hands a worker. */
export interface WorkerInit {
  type: 'init';
  sharing: WorldSharing;
  /** This worker's number, from 0. */
  index: number;
  control: SharedArrayBuffer;
  members: SharedArrayBuffer;
  errors: SharedArrayBuffer;
}

/** A worker's numbers in the control array, `SLOT` each. */
export const SLOT = 8;
/** 0 idle, 1 a job to run, 2 the job threw. */
export const STATE = 0;
export const JOB = 1;
export const STAGE = 2;
export const COUNT = 3;
export const TICK = 4;
export const ROWS = 5;
/** Characters of a worker's error message kept for the main thread. */
export const ERROR_LENGTH = 512;

export interface PoolOptions {
  /** A parallel system with fewer members than this runs on the main thread, whole. Default 2048. */
  threshold?: number;
}

export class WorkerPool implements ParallelRunner {
  threshold: number;
  private readonly links: WorkerLink[];
  private readonly control: Int32Array;
  /** Each worker's share of a job's members: `region` ids each. */
  private readonly members: Uint32Array;
  private readonly errors: Uint16Array;
  private readonly region: number;
  /** Workers given a share of the job being run. */
  private busy = 0;

  private constructor(links: WorkerLink[], region: number, threshold: number) {
    this.links = links;
    this.region = region;
    this.threshold = threshold;
    this.control = new Int32Array(new SharedArrayBuffer(links.length * SLOT * 4));
    this.members = new Uint32Array(new SharedArrayBuffer(links.length * region * 4));
    this.errors = new Uint16Array(new SharedArrayBuffer(links.length * ERROR_LENGTH * 2));
  }

  /**
   * A pool of these workers over `world`, each having built its own view and
   * said so. Register every system first: nothing can be added afterwards. The
   * world's parallel systems run through the pool from here on.
   */
  static async start(world: World, links: WorkerLink[], { threshold = 2048 }: PoolOptions = {}): Promise<WorkerPool> {
    const sharing = world.sharing();
    const pool = new WorkerPool(links, sharing.maxRows, threshold);
    try {
      await Promise.all(
        links.map(
          (link, index) =>
            new Promise<void>((resolve, reject) => {
              link.listen((message) => {
                if (message.type === 'ready') resolve();
                else reject(new Error(`[ecs] worker ${index} could not start: ${String(message.message)}`));
              });
              const init: WorkerInit = { type: 'init', sharing, index, control: pool.control.buffer as SharedArrayBuffer, members: pool.members.buffer as SharedArrayBuffer, errors: pool.errors.buffer as SharedArrayBuffer };
              link.post(init);
            }),
        ),
      );
    } catch (err) {
      // One could not start: none is left running.
      for (const link of links) link.stop();
      throw err;
    }
    world.useRunner(pool);
    return pool;
  }

  /** How many workers. */
  get size(): number {
    return this.links.length;
  }

  dispatch(job: number, stage: number, members: Uint32Array, count: number, tick: number, rows: number): number {
    const workers = this.links.length;
    // Equal shares, this thread's first: it reads its own straight from the list.
    const share = Math.ceil(count / (workers + 1));
    const control = this.control;
    const shared = this.members;
    let busy = 0;
    for (let w = 0; w < workers; w++) {
      const from = share * (w + 1);
      const n = Math.min(share, count - from);
      if (n <= 0) break;
      const at = w * this.region;
      for (let i = 0; i < n; i++) shared[at + i] = members[from + i]!;
      const slot = w * SLOT;
      control[slot + JOB] = job;
      control[slot + STAGE] = stage;
      control[slot + COUNT] = n;
      control[slot + TICK] = tick;
      control[slot + ROWS] = rows;
      Atomics.store(control, slot + STATE, 1);
      Atomics.notify(control, slot + STATE);
      busy++;
    }
    this.busy = busy;
    return Math.min(share, count);
  }

  wait(system: string): void {
    const control = this.control;
    let failed = -1;
    for (let w = 0; w < this.busy; w++) {
      const state = w * SLOT + STATE;
      // The main thread may not sleep in a browser: it spins, for as long as the slowest share takes.
      while (Atomics.load(control, state) === 1) {
        /* waiting */
      }
      if (Atomics.load(control, state) === 2) {
        failed = w;
        Atomics.store(control, state, 0);
      }
    }
    this.busy = 0;
    if (failed < 0) return;
    let text = '';
    for (let i = 0; i < ERROR_LENGTH; i++) {
      const code = this.errors[failed * ERROR_LENGTH + i]!;
      if (code === 0) break;
      text += String.fromCharCode(code);
    }
    throw new Error(`[ecs] parallel system '${system}' threw on worker ${failed}: ${text}`);
  }

  /** The workers stopped, and the world running its parallel systems itself again. */
  stop(world: World): void {
    world.useRunner(null);
    for (const link of this.links) link.stop();
  }
}
