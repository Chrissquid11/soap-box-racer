---
skill: engine
title: The ECS
when: Before writing or changing gameplay -- a component, a system, an event, a relation, a save -- under src/game/
covers:
  modules: [ecs/, game.ts, live-game.ts]
order: 10
---
# The ECS: making gameplay

Gameplay is data and systems. A component is data on an entity, a system is code that runs over every entity
with the components it names, at a rate. Nothing else holds game state: no class per thing, no object graph.
The code is in `node_modules/@vibe/engine/src/ecs/`; `world.ts` and `component.ts` say every option in their
comments.

Where things go in a project:

| File | What is in it |
|---|---|
| `src/game/components.ts` | every component, tag, event and relation: the game's data model, read first |
| `src/game/prefabs.ts` | a token per prefab (`prefab('crates/big')`): what a thing is made of is its file |
| `src/game/systems/<name>.ts` | one system a file, a function that registers it |
| `src/game/systems.ts` | `registerSystems(world)`: every system, in order |

Before changing gameplay, read `world.describe()` in the console (a dev or `?debug` build): every prefab,
component and system, with rates, data and member counts. In the studio, `scene_describe` answers the same.

## Components

```ts
import { component, dataComponent, event, f32, f64, key, list, ref, relation, tag, Transform, u32 } from '@vibe/engine';

/** Turns about its own y axis: `angle` in radians, `speed` in radians a second -- a slider in the inspector. */
export const Spin = component('Spin', { angle: f32(), speed: f32(0.6, { min: 0, max: 6, slider: true }) }, { runtime: ['angle'] });
/** Stays above another entity, one with a Transform: `who`, and how far above. */
export const Follow = component('Follow', { who: ref(Transform), height: f32(1) });
/** Wanders: a yes or no. */
export const Wanderer = tag('Wanderer');
/** What it carries: a list, so a data component -- saved, inspected and set with no code of its own. */
export const Inventory = dataComponent('Inventory', {
  items: list(key('Prefab'), { max: 8 }),
});
```

- **Numbers go in a `component`** (typed-array columns, one per field: `spin.angle[e]`). Field types: `f32 f64
  i8 u8 i16 u16 i32 u32 bool ref`, each taking its default and options (bounds, a slider, a label); an enum,
  flags, a vector, a colour, a typed ref and an asset's key are numbers too. What a hot loop reads goes here.
- **A yes or no is a `tag`**: a bit, read through `with`, `without` and `ctx.has(e, Wanderer)`.
- **A list, a dictionary, text or a record is a `dataComponent`**: read with `inventory.get(e)`, never in a
  `parallel` system. Only a handle -- a three.js object -- is an `objectComponent`, saved only with `save`/`load`.
- **Every component is defined at module level, before the world is made.** Defining one later throws.
- **`runtime`** marks the fields the systems set as the game runs (`{ runtime: ['angle'] }`, or `true` for
  all): a save keeps them, a prefab file never says them -- one that does is a compile error. Mark a field so
  when its value in the scene is the game's, not the design's.
- **`{ transient: true }`** is scratch: a save leaves it out.
- **Never a `visible`, `enabled` or `dead` field of your own** (below: switches, pools).

- **Which kind for what** -- every kind's line of code, its widget in the inspector, its form in a file, and the
  options (a label, help, bounds, a slider, a group): the table on [the fields page](fields.md).

## Systems

```ts
import { Transform, type World } from '@vibe/engine';
import { Wander } from '../components.ts';

const DRIFT_SPEED = 1.1;

export function drift(world: World): void {
  world.system({
    name: 'drift',
    rate: 60,
    after: ['startle'],
    read: [Wander],
    write: [Transform],
    update({ members, count, dt }, [target], [at]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const dx = target.tx[e] - at.px[e];
        const dz = target.tz[e] - at.pz[e];
        const distance = Math.sqrt(dx * dx + dz * dz);
        if (distance === 0) continue;
        const step = Math.min(distance, DRIFT_SPEED * dt) / distance;
        at.px[e] += dx * step;
        at.pz[e] += dz * step;
      }
    },
  });
}
```

Then `drift(world)` in `registerSystems`, in its place in the order.

- **The declaration is the query.** Members are the entities with every component of `read`, `write` and
  `with`, and none of `without`. The stores come in the order declared: `update(ctx, [reads], [writes])`. A
  read store is read-only to the typecheck; a component not declared cannot be reached at all.
- **`any: [A, B]` is "or"**: at least one of them. Their data through `optional(A)` in `read` or `write`,
  checked with `ctx.has(e, A)`. `optional(C)` is also how a system reads another entity's data: `read:
  [Follow, optional(WorldTransform)]`, then `where.px[who]` after a `deref`.
- **The rate is one of 1, 5, 10, 15, 20, 30 or 60 Hz.** Slow systems decide (a target, a state); only 60 Hz
  systems write `Transform`, so motion is smooth, and the renderer draws it interpolated. A slow system is
  staggered: its members are spread over its period, a few each tick, never all at once (`stagger: false` to
  run them all on its one tick).
- **`after: ['name']`** orders systems of the same phase; otherwise registration order.
- **`update` sees world transforms from the end of the last tick; `lateUpdate` sees this tick's.** Whatever
  follows something else (a marker over a rider) reads `WorldTransform` in `lateUpdate`.
- **The context** (`ctx`), all of it:

  ```ts
  const { members, count, dt, time, tick, input, rng, cmd, ref, deref, has, enabled, active, changed, world } = ctx;
  if (input.pressed('Space') && rng.chance(0.5)) at.py[e] += rng.range(0.5, 1.5);
  ```

- **Chance and time come from the loop**: `ctx.rng` (seeded: `rng.range(lo, hi)` a number, `rng.int(lo, hi)` a
  whole one, `rng.chance(p)` true that often, `rng.next()` 0 to 1) and `ctx.time` / `ctx.dt` in seconds. Never
  `Math.random`, `Date.now()` or `performance.now()` in simulation code: the same seed must play the same game.
- **Input is `ctx.input`**, by `KeyboardEvent.code` (or a pad's `Pad0`...): `input.pressed('Space')` went down
  since this system last ran, `input.down('Space')` is held -- stamped with the tick it came in on, so a slow
  system misses no press.

### The one loop shape

```ts
for (let n = 0; n < count; n++) {
  const e = members[n];
  pos.x[e] += vel.x[e] * dt;
}
```

`members` is longer than what is due now: never `for...of`, never `members.length`.

### A system allocates nothing

No `new`, no `{}` or `[]` literal, no closure, no `map` / `filter` / `forEach` / spread, no string building
inside `world.system(...)`. A tick at 60 Hz that allocates makes garbage the collector stops the game for.
Scratch objects and helpers go at module level. `vibe test` fails on each and says what to write instead;
`// alloc-ok: <reason>` on a line is the way out, for a line that runs once. In a test, `t.noAlloc(name, run)`
measures a call for real.

### parallel

`parallel: true` only on a system that is pure arithmetic over its own members' rows: numeric components, no
`cmd`, `rng`, `input`, events, relations or `changed`. It may then run on worker threads; those things throw in
it even with no workers.

## What exists changes through commands

Structure changes at the tick boundary, never during a tick. In a system, `ctx.cmd`; outside one (setup, a
test), the same verbs on `world`.

```ts
const chip = cmd.instantiate(ChipOfCrate);     // the prefab's whole tree; its root's id at once
if (chip === NONE) continue;                   // its pool at its max, or the world full (said once)
const place = cmd.init(chip, Transform);       // the writable store, for an entity made this tick
place.px[chip] = at.px[e];
const big = cmd.instantiate(BigCrate);
const rider = cmd.part(big, RiderOfBig);       // an entity of an instance, by its node
const health = cmd.add(e, Health);             // its writable store back: the row has its defaults now
health.hp[e] = 100;
cmd.remove(e, Frozen);
cmd.setParent(chip, e);
cmd.destroy(e);                                // an instance's root takes the instance
const marker = cmd.spawn();                    // bare: an entity code fills itself
```

(Here inside a loop over `members`, `e` the member, `at` the `Transform` store; `ChipOfCrate`, `BigCrate` and
`RiderOfBig` tokens from `src/game/prefabs.ts`; `Health` and `Frozen` components of the game's.)

- **What a thing is made of is a prefab**, never a list of components in code: a `.prefab` file under
  `src/assets/prefabs/` and its token in `src/game/prefabs.ts` (`prefab('crates/big')`, a node
  `BigCrate.node('rider')`), both at module level. Never a `kind()` in game code.
- **`init` only on an instance just made**, and only for a component its file makes it with (the typecheck
  says so otherwise).
- **Nothing structural shows until the boundary**: an entity spawned this tick is not `alive` and in no system
  yet; `has` is false for a component added this tick. Its id and rows are good at once.
- **A pool is declared once, on the prefab** (`"pool": { "warm": 16, "max": 64 }` in its file): then the same
  `instantiate` and `destroy`. The root's destroy gives it back, every ref to it goes `NONE`. Never a free list
  of your own.

## Keeping an entity: refs

An `Entity` is good only during the call. One kept across ticks -- in a field, a module, an event -- is an
`EntityRef`: `ctx.ref(e)` to keep, `ctx.deref(r)` each time it is used, and a check for `NONE`, since it may
have died.

```ts
const who = deref(follows.who[e]);             // follows: the Follow store, who a ref() field
if (who === NONE) continue;
```

A `ref()` field holds one; a save keeps it pointing where it did.

## Events: systems talk through them

```ts
import { event, NONE, ref, Transform, type World } from '@vibe/engine';
import { Hop, Wander } from '../components.ts';

export const Hopped = event('Hopped', { who: ref() });      // in components.ts

export function crate(world: World): void {
  const hops = world.events(Hopped);                         // the channel: where the system is registered
  world.system({
    name: 'crate',
    rate: 60,
    write: [Hop, Transform],
    update({ members, count, input, ref }, _read, [hop, at]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        if (!input.pressed('Space') || at.py[e] !== 0) continue;
        hop.vy[e] = 6;
        hops.who[hops.emit()] = ref(e);                      // emit() gives the event's row: fill it in
      }
    },
  });
}

export function startle(world: World): void {
  const hops = world.events(Hopped);
  world.system({
    name: 'startle',
    rate: 60,
    write: [Wander],
    update(ctx, _read, [target]) {
      for (let i = hops.begin(ctx); i < hops.end; i++) {
        const who = ctx.deref(hops.who[i]);
        if (who === NONE) continue;
        // ... each wanderer startled by who
      }
    },
  });
}
```

- **Read on the tick after, by every reader, once**: the answer does not depend on registration order.
- **A reader below 60 Hz needs `stagger: false`**: `begin` throws otherwise and says so.
- **Never a shared flag** between systems: an event, or data on an entity.
- An entity in an event is a `ref()`, `deref`ed by the reader.

## Relations: more than one target, or data on the link

```ts
import { f32, relation, type World } from '@vibe/engine';

export const Likes = relation('Likes', { much: f32(1) });   // in components.ts

export function gossip(world: World): void {
  world.system({
    name: 'gossip',
    rate: 10,
    write: [Likes],             // members: every entity with a link out; `likes`, the store, links' data writable
    update({ members, count, cmd }, _read, [likes]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        for (let p = likes.firstOut[e]; p !== 0; p = likes.nextOut[p]) {
          const whom = likes.target[p];                      // good now: a link dies with either end
          likes.much[p] *= 0.99;
          if (likes.much[p] < 0.1) cmd.unrelate(e, Likes, whom);
        }
        for (let p = likes.firstIn[e]; p !== 0; p = likes.nextIn[p]) {
          const who = likes.source[p];                       // who likes e
          const back = cmd.relate(e, Likes, who);            // the link's row at once, linked at the boundary
          if (back !== 0) likes.much[back] = 3;              // 0: an end NONE, or no room this tick
        }
      }
    },
  });
}
```

- **A relation is a component for everything else**: an entity has it while it has a link out, so `read`,
  `write`, `with`, `without`, `optional(Likes)` (to reach links into entities with none out), `onJoin` and
  `onLeave` all work on it. Its store comes in `update` as any component's does; `world.store(Likes)` outside a
  system. In `write` the links' data is writable; the links change only through `relate` and `unrelate`.
- **`relate` returns the link's row** to fill its data in now, linked at the boundary; a second link between the
  same two changes nothing. `unrelate(a, Likes, NONE)` cuts every link out of `a`.
- **A link dies with either end**: no ref to check, no cleanup. `relation(name, schema, { exclusive: true })`
  keeps one link out at most -- a new one replaces the old. One target and no data is a `ref()` field instead.

## Added, removed, changed

- **Added is `onJoin`**, beside `update`: the new members, once, the tick after they joined.
- **Removed is `onLeave`**: those that stopped matching, for any reason, once -- their rows still as they died
  (check `ctx.world.alive(e)` before a command).
- **Changed is `changed: [Health]`** in the declaration, then `ctx.changed(e, Health)` in the loop: numeric
  components only, being added counts. Nobody marks anything: never a dirty flag of your own.

## Switched off, hidden, layers, labels

Every entity has them; never a field of your own for any.

```ts
cmd.add(e, Disabled);              // out of play: in no system, not drawn -- it and everything under it
cmd.add(e, Hidden);                // out of sight, still simulated -- it and everything under it
cmd.enable(e, Health, false);      // one component switched off: data kept, out of the systems that need it
cmd.setLayer(e, 2);                // 0 to 31; a system takes `layers: [2]`
```

`Disabled` and `Hidden` are tags like any other (`cmd.remove` puts it back); `cmd.enable(e, Health)` switches a
component on again, and `ctx.enabled(e, Health)` says which it is.

`Labels` is free text for tools and filters; systems query by tags. A system that wants the switched-off says
`includeDisabled: true`.

## Saving

`world.save()` is plain JSON, matched by component name, so a save survives a component added or reordered;
`game.load(save)` puts one in place of the world. Entities keep their ids, so refs and links still point where
they did. An object component is in it only with `save` and `load`; a `transient` component and events never.
A scene file is the same save with its instances' overrides: `game.load(scene('forest/camp'))`.

## The swap: never keep the world in a module

In the dev server a change under `src/game/` swaps into the running game with no reload: the modules evaluated
again, the world saved, rebuilt and loaded back. So:

- **Tokens and scratch at module level, yes**: components, tags, events, relations, prefab tokens and nodes, a
  reused `Float32Array`, a helper function.
- **The world, a store, a column or a channel at module level, never**: `const hits = world.events(Hit)` goes
  inside the function that registers the system, as above. A column is never kept across ticks either (`const
  xs = pos.x` outside the loop's call): the world may grow at a boundary and replace it. `vibe test` fails on
  one.

## A system to copy

A slow system that decides, with a 60 Hz one moving (as `drift` above):

```ts
/**
 * wander, 1 Hz: each wanderer picks a new spot on a ring. Staggered, so a few decide each tick;
 * `onJoin`, so a new one does not wait a second for its first.
 */
import type { World } from '@vibe/engine';
import { Wander, Wanderer } from '../components.ts';

const RING = { inner: 1.6, outer: 4.5 };

export function wander(world: World): void {
  world.system({
    name: 'wander',
    rate: 1,
    write: [Wander],
    with: [Wanderer],
    onJoin({ members, count, rng }, _read, [target]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const angle = rng.range(0, Math.PI * 2);
        const radius = rng.range(RING.inner, RING.outer);
        target.tx[e] = Math.cos(angle) * radius;
        target.tz[e] = Math.sin(angle) * radius;
      }
    },
    update({ members, count, rng }, _read, [target]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const angle = rng.range(0, Math.PI * 2);
        const radius = rng.range(RING.inner, RING.outer);
        target.tx[e] = Math.cos(angle) * radius;
        target.tz[e] = Math.sin(angle) * radius;
      }
    },
  });
}
```

`Wander`'s fields are `runtime` (the system sets them); `Wanderer` is a tag the prefab file puts on.

## Checking it

`npm run typecheck` after every edit; `npm test` runs the project's tests and the checks (the `ecs` check reads
every system for the rules above and names the file, the line and the fix). A test is `<thing>.test.ts` beside
what it tests -- here `src/game/crate.test.ts`:

```ts
import { compilePrefabs, Loop, Transform, World } from '@vibe/engine';
import { prefabFilesFromDisk } from '@vibe/engine/node';
import { suite } from '@vibe/engine/testing';
import { BigCrate } from './prefabs.ts';
import { registerSystems } from './systems.ts';

const t = suite('game: the big crate');
compilePrefabs(prefabFilesFromDisk(new URL('../assets/prefabs/', import.meta.url)));   // the files, from disk
const world = new World({ loop: new Loop({ seed: 1 }) });                              // seeded: the same each run
registerSystems(world);
const big = world.instantiate(BigCrate);
world.flush();                                         // the boundary: the instance in its systems
for (let i = 0; i < 60; i++) world.loop.runTick();     // a second at 60 Hz
t.ok('it stays on the ground with nothing pressed', world.store(Transform).py[big] === 0);
t.done();
```

A test imports nothing of the DOM, three's renderer or `@vibe/engine/assets` (but as types). The game's own
tests under `src/game/` are more examples.

To place, edit and save what these systems run over in the studio, the [scene page](../studio/scene.md).
