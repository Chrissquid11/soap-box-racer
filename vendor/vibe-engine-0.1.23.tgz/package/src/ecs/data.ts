/**
 * Data components (Docs/ecs.md §3, Docs/properties.md D1, D2, D9): an object component whose shape is a declared
 * schema -- strings, lists, dictionaries, records, and every numeric field kind as an element -- so it is saved,
 * loaded, overridden, inspected and set by MCP with no code of its own.
 *
 * ```ts
 * export const Slot = enumOf(['head', 'hand', 'feet']);
 * export const Patrol = dataComponent('Patrol', {
 *   waypoints: list(ref(Transform)),                            // EntityRef[]
 *   loot: dict(Slot, key('Prefab')),                            // Map<number, number>: an enum's index to a key's id
 *   stats: record({ speed: f32(2, { min: 0 }), wary: bool() }),  // { speed: number; wary: boolean }
 *   motto: string('', { maxLength: 40 }),                       // string
 * });
 * const p = store.get(e);          // the entity's own object, the same one each time
 * ```
 *
 * - **The value** is plain: an object of its fields, a `list` an array, a `dict` a `Map`, a `record` an object, a
 *   `string` a string, a vector `[x, y, z]`, a `bool` a boolean, every other kind the number its column would hold
 *   (an enum's index, flags' bits, a colour, a key's interned id, an `EntityRef`). Made from the schema, fresh per
 *   entity (`dataDefault`): never shared.
 * - **One plain form for every file** (`dataPlain`, `fromPlain`): enums by name, flags by names, a `colorA` as
 *   `#rrggbbaa`, keys as `{ uid, key }`, a dict as `{ "k": v }` where its keys are text (a string's, an enum's names)
 *   and `[[k, v], …]` otherwise. Only a ref differs by where it is written -- a raw `EntityRef` in a saved game, an
 *   entity's index in a scene, a node's id or path in a prefab, a path inside the instance (or `{ entity }`) in an
 *   override -- so each writer hands its own ref in and out, and `mapRefs` turns one into another.
 * - **Paths** (`waypoints[2]`, `loot.sword`, `stats.speed`): what an error names (`DataError`), what MCP's
 *   `scene_set` and the list tools take (`parsePath`, `elementAt`, `setAt`, `listInsert`, `listRemove`, `listMove`).
 *
 * Pure: no DOM, no three. Node tests import it.
 */
import { NO_REF, objectComponent, type EntityRef, type Field, type FieldOptions, type MenuOptions, type ObjectComponent, type ObjectComponentOptions } from './component.ts';
import { fieldProblem, fieldText, fieldValue, internKey } from './keys.ts';
import { andList, fieldSchema, spaced, type FieldSchema } from './fields.ts';
import { isKeyRef, resolveRef } from '../assets/uids.ts';

// ── the makers ──────────────────────────────────────────────────────────

/** A string's options: a field's, a text area for `multiline`, and the most characters the inspector and MCP write. */
export interface StringOptions extends FieldOptions {
  readonly multiline?: boolean;
  readonly maxLength?: number;
}

/** A `string()` element: text. */
export interface StringElement extends FieldOptions {
  readonly shape: 'string';
  readonly initial: string;
  readonly multiline?: boolean;
  readonly maxLength?: number;
}

/** A list's options: its label, help and group, and the fewest and most elements the inspector and MCP leave it with. */
export interface ListOptions extends Pick<FieldOptions, 'label' | 'help' | 'hidden' | 'readonly' | 'group'> {
  readonly min?: number;
  readonly max?: number;
}

/** A `list(of)` element: an array of `of`. */
export interface ListElement<O extends Element = Element> extends ListOptions {
  readonly shape: 'list';
  readonly of: O;
}

/** A dictionary's options: its label, help and group. */
export type DictOptions = Pick<FieldOptions, 'label' | 'help' | 'hidden' | 'readonly' | 'group'>;

/** A `dict(keyOf, valueOf)` element: a `Map`. */
export interface DictElement<K extends Element = Element, V extends Element = Element> extends DictOptions {
  readonly shape: 'dict';
  readonly keyOf: K;
  readonly valueOf: V;
}

/** A `record({ … })` element: an object of its fields. */
export interface RecordElement<S extends DataSchema = DataSchema> extends DictOptions {
  readonly shape: 'record';
  readonly fields: S;
}

/** What a data component's field, or an element of one, may be: any numeric field's maker, or a string, list, dict or record. */
export type Element = Field | StringElement | ListElement<any> | DictElement<any, any> | RecordElement<any>;
export type DataSchema = Readonly<Record<string, Element>>;

/** A field maker's yes or no: `bool()`'s type, which a data component holds as a boolean. */
export type BoolField = Field & { readonly bool: true };

/** What an element holds in the value code sees. */
export type ValueOf<E> =
  E extends StringElement ? string
  : E extends ListElement<infer O> ? ValueOf<O>[]
  : E extends DictElement<infer K, infer V> ? Map<ValueOf<K>, ValueOf<V>>
  : E extends RecordElement<infer S> ? DataValue<S>
  : E extends { readonly vec: 2 | 3 | 4 } ? number[]
  : E extends { readonly bool: true } ? boolean
  : E extends Field<infer N> ? N
  : never;

/** A data component's value, or a record's: its fields, each as `ValueOf` says. */
export type DataValue<S> = { -readonly [K in keyof S]: ValueOf<S[K]> };

/** Fields of a record or a data component checked: no name a value's own, each an element. */
function checkSchema(what: string, schema: DataSchema): void {
  if (typeof schema !== 'object' || schema === null) throw new Error(`[ecs] ${what}: its fields are an object, { name: maker }`);
  const names = Object.keys(schema);
  if (names.length === 0) throw new Error(`[ecs] ${what} has no fields`);
  for (const n of names) {
    if (n in Object.prototype) throw new Error(`[ecs] ${what}: '${n}' is every object's own, so it cannot be a field -- call it something else`);
    if (!isElement(schema[n])) throw new Error(`[ecs] ${what}: '${n}' is no field -- a maker's: f32(), string(), list(…), dict(…, …), record({ … }), ref(), key('Prefab') …`);
  }
}

const isElement = (x: unknown): x is Element => typeof x === 'object' && x !== null && ('shape' in x || 'type' in x);

/**
 * Text, in a data component (a column holds only numbers): `''` by default. `{ multiline: true }` is a text area in
 * the inspector, `{ maxLength }` the most characters the inspector and MCP write.
 */
export function string(initial = '', options: StringOptions = {}): StringElement {
  if (typeof initial !== 'string') throw new Error(`[ecs] string(): its initial is text, not ${JSON.stringify(initial)}`);
  if (options.maxLength !== undefined && !(options.maxLength > 0)) throw new Error(`[ecs] string(): its maxLength is more than 0, not ${options.maxLength}`);
  return { ...options, shape: 'string', initial };
}

/**
 * A list of `of` -- any element: `list(ref(Transform))`, `list(record({ item: key('Prefab'), count: u16(1) }))`. An
 * empty array by default (`min` of `of`'s default where `min` is given). `{ min, max }` are the fewest and most the
 * inspector and MCP leave it with; code is never held to them.
 */
export function list<const O extends Element>(of: O, options: ListOptions = {}): ListElement<O> {
  if (!isElement(of)) throw new Error('[ecs] list(of): `of` is a field maker: list(f32()), list(ref(Health)), list(string())');
  if (options.min !== undefined && !(options.min >= 0)) throw new Error(`[ecs] list(): its min is 0 or more, not ${options.min}`);
  if (options.min !== undefined && options.max !== undefined && options.min > options.max) throw new Error(`[ecs] list(): its min ${options.min} is over its max ${options.max}`);
  return { ...options, shape: 'list', of };
}

/** Can `k` be a dictionary's key: a string, a whole or float number, an enum's name, an entity? */
function keyable(k: Element): boolean {
  if ('shape' in k) return k.shape === 'string';
  return !k.bool && k.vec === undefined && k.key === undefined && !k.color && !k.flags;
}

/**
 * A dictionary from `keyOf` -- a `string()`, a number maker, an `enumOf`, a `ref()` (an entity's own entry) -- to
 * `valueOf`, any element: a `Map`, kept in the order written. `dict(Slot, key('Prefab'))` is `Map<number, number>`,
 * an enum's index to a key's id.
 */
export function dict<const K extends Element, const V extends Element>(keyOf: K, valueOf: V, options: DictOptions = {}): DictElement<K, V> {
  if (!isElement(keyOf) || !isElement(valueOf)) throw new Error('[ecs] dict(keyOf, valueOf): both are field makers: dict(string(), f32()), dict(Slot, key(\'Prefab\'))');
  if (!keyable(keyOf)) throw new Error('[ecs] dict(): its key is a string(), a number, an enumOf() or a ref() -- not a list, a dict, a record, a key, a vector, a colour, flags or a yes or no');
  return { ...options, shape: 'dict', keyOf, valueOf };
}

/** A group of named fields: an object, each field any element -- `record({ speed: f32(2), wary: bool() })`. */
export function record<const S extends DataSchema>(fields: S, options: DictOptions = {}): RecordElement<S> {
  checkSchema('record()', fields);
  return { ...options, shape: 'record', fields };
}

/** A data component's token: an object component (`store.value[e]`, `store.get(e)`) with its schema. */
export interface DataComponentOf<S extends DataSchema = DataSchema, N extends string = string> extends ObjectComponent<DataValue<S>, N> {
  readonly data: S;
  /** The fields systems fill as the game runs (`{ runtime }`): kept in a saved game, never in a scene, a prefab or an override. */
  readonly runtime: readonly string[];
  /** Left out of every save (`{ transient: true }`): scratch a system works out again. */
  readonly transient: boolean;
}

/** Is `c` a data component? */
export const isData = (c: unknown): c is DataComponentOf => typeof c === 'object' && c !== null && (c as { kind?: unknown }).kind === 'object' && typeof (c as { data?: unknown }).data === 'object' && (c as { data?: unknown }).data !== null;

/**
 * A data component (Docs/ecs.md §3): lists, dictionaries, strings and records, and every numeric kind inside them,
 * in a shape declared once -- saved, loaded, written to prefab and scene files, overridden by an instance, shown in
 * the inspector and set by MCP, with no `save`, `load` or block of its own. An object per entity (pooled, `pool`
 * made up front), made from the schema's defaults: `store.get(e)`. A system may read it, never a `parallel` one.
 *
 * ```ts
 * export const Patrol = dataComponent('Patrol', { waypoints: list(ref(Transform)), pause: f32(1) });
 * ```
 */
export function dataComponent<const S extends DataSchema, const N extends string = string>(
  name: N,
  schema: S,
  given: { pool?: number; transient?: boolean; runtime?: true | readonly (keyof S & string)[] } & MenuOptions = {},
): DataComponentOf<S, N> {
  checkSchema(`dataComponent('${name}')`, schema);
  const runtime = given.runtime === true ? Object.keys(schema) : [...(given.runtime ?? [])];
  for (const f of runtime) if (!(f in schema)) throw new Error(`[ecs] dataComponent('${name}'): runtime names '${f}', which is none of its fields`);
  const top = record(schema);
  const options_: ObjectComponentOptions<DataValue<S>> = {
    create: () => dataDefault(top) as DataValue<S>,
    reset: (value: DataValue<S>) => {
      for (const f of Object.keys(schema)) (value as Record<string, unknown>)[f] = dataDefault(schema[f]!);
    },
    pool: given.pool ?? 0,
    // A saved game: refs as they are (it is loaded into the same world), everything else as a file writes it.
    save: (value: DataValue<S>) => dataPlain(top, value, rawOut),
    // A field the schema has not is left out here; `world.load` says each one (`strayFields`), but for a live swap's own save.
    load: (data: unknown, value: DataValue<S>) => void fillFrom(schema, data, value as Record<string, unknown>, { ref: rawIn, lenient: true }),
    data: schema,
    runtime,
    transient: given.transient === true,
    ...(given.menu !== undefined ? { menu: given.menu } : {}),
    ...(given.help !== undefined ? { help: given.help } : {}),
  };
  return objectComponent<DataValue<S>, N>(name, options_) as DataComponentOf<S, N>;
}

/**
 * The fields `json` (a data component's plain value) names that its schema has not, anywhere in it -- a record's
 * inside a list, a dict's values -- each by its path (`waypionts`, `crew[0].mod`): what a load leaves out, said.
 */
export function strayFields(schema: DataSchema, json: unknown, path = ''): string[] {
  const out: string[] = [];
  const walk = (el: Element, v: unknown, at: string): void => {
    if (!('shape' in el) || el.shape === 'string') return;
    if (el.shape === 'list') {
      if (Array.isArray(v)) v.forEach((x, i) => walk(el.of, x, `${at}[${i}]`));
    } else if (el.shape === 'dict') {
      if (Array.isArray(v)) v.forEach((pair, i) => Array.isArray(pair) && walk(el.valueOf, pair[1], `${at}[${i}]`));
      else if (typeof v === 'object' && v !== null) for (const [k, x] of Object.entries(v)) walk(el.valueOf, x, `${at}${keyStep(el.keyOf, k)}`);
    } else out.push(...strayFields(el.fields as DataSchema, v, at));
  };
  if (typeof json !== 'object' || json === null || Array.isArray(json)) return out;
  for (const [k, v] of Object.entries(json)) {
    const at = path === '' ? k : `${path}.${k}`;
    if (!(k in schema) || k in Object.prototype) out.push(at);
    else walk(schema[k]!, v, at);
  }
  return out;
}

/** A saved game's ref: the `EntityRef` as it is, null for nobody. */
export const rawOut = (r: EntityRef): unknown => (r === NO_REF ? null : r);
/** A saved game's ref back: a number as the `EntityRef` it is; anything else nobody. */
export const rawIn = (json: unknown): EntityRef => (typeof json === 'number' && json > 0 ? (json as EntityRef) : NO_REF);

// ── values ──────────────────────────────────────────────────────────────

/** An element's default, made afresh: never shared between two entities. */
export function dataDefault(el: Element): unknown {
  if ('shape' in el) {
    if (el.shape === 'string') return el.initial;
    if (el.shape === 'list') return Array.from({ length: el.min ?? 0 }, () => dataDefault(el.of));
    if (el.shape === 'dict') return new Map();
    const out: Record<string, unknown> = {};
    for (const [f, sub] of Object.entries(el.fields as DataSchema)) out[f] = dataDefault(sub);
    return out;
  }
  if (el.vec !== undefined) return [...(el.initials ?? [])];
  if (el.bool) return el.initial !== 0;
  if (el.ref) return NO_REF;
  return el.initial;
}

/** A field as `keys.ts` reads one: a schema of the one element. */
const wrapped = new WeakMap<Field, { readonly name: string; readonly schema: { readonly v: Field } }>();
function wrap(f: Field, name = ''): { readonly name: string; readonly schema: { readonly v: Field } } {
  let w = wrapped.get(f);
  if (!w) {
    w = { name, schema: { v: f } };
    wrapped.set(f, w);
  }
  return w;
}

/** Does a dict of this key write `{ "k": v }` (its keys are text) rather than `[[k, v], …]`? */
const textKeys = (k: Element): boolean => ('shape' in k ? k.shape === 'string' : k.enum !== undefined);

/** A key that a JavaScript object would reorder (`"2"` before `"b"`): such a dict is written as pairs, its order kept. */
const indexLike = (k: string): boolean => /^(0|[1-9]\d*)$/.test(k);

/**
 * An element's value as a file writes it (the module's header): `ref` says each ref, as the place it is written
 * wants it. Allocates the plain copy.
 */
export function dataPlain(el: Element, value: unknown, ref: (r: EntityRef) => unknown): unknown {
  if ('shape' in el) {
    if (el.shape === 'string') return typeof value === 'string' ? value : String(value ?? '');
    if (el.shape === 'list') return Array.isArray(value) ? value.map((v) => dataPlain(el.of, v, ref)) : [];
    if (el.shape === 'dict') {
      const map = value instanceof Map ? value : new Map();
      const pairs = [...map].map(([k, v]) => [dataPlain(el.keyOf, k, ref), dataPlain(el.valueOf, v, ref)] as const);
      if (textKeys(el.keyOf) && pairs.every(([k]) => typeof k === 'string' && !indexLike(k))) {
        const out: Record<string, unknown> = {};
        for (const [k, v] of pairs) out[k as string] = v;
        return out;
      }
      return pairs.map(([k, v]) => [k, v]);
    }
    const out: Record<string, unknown> = {};
    const obj = (value ?? {}) as Record<string, unknown>;
    for (const [f, sub] of Object.entries(el.fields as DataSchema)) out[f] = dataPlain(sub, obj[f], ref);
    return out;
  }
  if (el.ref) return ref((typeof value === 'number' ? value : NO_REF) as EntityRef);
  if (el.vec !== undefined) return Array.isArray(value) ? value.map(Number) : [...(el.initials ?? [])];
  if (el.bool) return value === true || value === 1;
  return fieldText(wrap(el), 'v', typeof value === 'number' ? value : el.initial);
}

/** What `fromPlain` is told: how a ref is read where the file was written, and what to check of a key. */
export interface ReadOptions {
  /** A ref as the file wrote it, back as an `EntityRef` -- or a `DataError` thrown at `path`. `field` is the ref's maker (its `needs`). */
  ref(json: unknown, path: string, field: Field): EntityRef;
  /** A plain number read (no enum, flags, colour or key), as it is kept: a tool's clamp to `min`/`max`. Left out, as given. */
  number?(n: number, field: Field, path: string): number;
  /** Text read, as it is kept: a tool's hold to `maxLength`. Left out, as given. */
  text?(s: string, el: StringElement, path: string): string;
  /** Why the key `text` of `kind` is none there is (`no prefab "weapons/swrod"`), or null: the compile's, which knows the files. */
  key?(kind: string, text: string, path: string): string | null;
  /**
   * A field a record or the component has not, in a save: left out (a save from before the field was dropped, a live
   * swap's), where a file a person writes -- a prefab, MCP's value -- refuses it. Left out, refused.
   */
  lenient?: boolean;
}

/** Something a file holds that its schema cannot: where (`loot.sword`, `waypoints[3]`), and why. */
export class DataError extends Error {
  readonly path: string;
  readonly why: string;
  constructor(path: string, why: string) {
    super(`${path}: ${why}`);
    this.path = path;
    this.why = why;
  }
}

/**
 * A dict's entry as a path's step, by its key as the `Map` holds it: text and an enum's index by name (`.sword`,
 * `["a.b"]` written as `pathText` quotes it), a number or an entity by index (`[3]`).
 */
export function entryStep(el: DictElement, k: unknown): Step {
  const kf = el.keyOf;
  if ('shape' in kf) return { name: String(k) };
  if (kf.enum) return { name: kf.enum[k as number] ?? String(k) };
  return { index: k as number };
}

/** A dict's key as a path says it, by its key as a file writes it: `.sword` (`["a.b"]`) for text, `[3]` for a number or an entity. */
const keyStep = (keyEl: Element, k: unknown): string => (textKeys(keyEl) ? pathText([{ name: '' }, { name: String(k) }]) : `[${String(k)}]`);

/** What an element is, said: for an error. */
export function elementSaid(el: Element): string {
  if ('shape' in el) {
    if (el.shape === 'string') return 'text';
    if (el.shape === 'list') return `a list of ${elementSaid(el.of)}`;
    if (el.shape === 'dict') return `a dictionary (${textKeys(el.keyOf) ? '{ "key": value }' : '[[key, value], …]'})`;
    return `a record of ${Object.keys(el.fields as DataSchema).join(', ')}`;
  }
  if (el.ref) return el.needs?.length ? `an entity with ${andList(el.needs)}` : 'an entity';
  if (el.vec !== undefined) return `a vector, ${el.vec} numbers`;
  if (el.bool) return 'true or false';
  if (el.enum) return `one of ${el.enum.join(', ')}`;
  if (el.flags) return `a list of ${el.flags.join(', ')}`;
  if (el.key !== undefined) return el.mesh ? 'a model and its part' : `a ${el.key} key`;
  if (el.color) return el.alpha ? 'a colour, "#rrggbbaa"' : 'a colour, "#rrggbb"';
  return 'a number';
}

/** A dict's key read from a file: `{ "k": … }`'s text, or a pair's first. */
function keyFrom(el: Element, json: unknown, path: string, options: ReadOptions): unknown {
  if ('shape' in el) {
    if (typeof json !== 'string') throw new DataError(path, `a key is text, not ${JSON.stringify(json)}`);
    return json;
  }
  if (el.ref) return options.ref(json, path, el);
  if (el.enum) {
    const at = typeof json === 'string' ? el.enum.indexOf(json) : typeof json === 'number' ? json : -1;
    if (at < 0) throw new DataError(path, `no name ${JSON.stringify(json)} -- its names are ${el.enum.join(', ')}`);
    return at;
  }
  const n = typeof json === 'string' && json.trim() !== '' ? Number(json) : json;
  if (typeof n !== 'number' || !Number.isFinite(n)) throw new DataError(path, `a key is a number, not ${JSON.stringify(json)}`);
  return n;
}

/**
 * An element read back from its plain form (`dataPlain`'s), checked against its schema at every step: what does
 * not fit is a `DataError` naming its path. Refs through `options.ref`, keys interned. Allocates the value.
 */
export function fromPlain(el: Element, json: unknown, path: string, options: ReadOptions): unknown {
  if ('shape' in el) {
    if (el.shape === 'string') {
      if (typeof json !== 'string') throw new DataError(path, `text, not ${JSON.stringify(json)}`);
      return options.text ? options.text(json, el, path) : json;
    }
    if (el.shape === 'list') {
      if (!Array.isArray(json)) throw new DataError(path, `${elementSaid(el)}: [ … ], not ${JSON.stringify(json)}`);
      return json.map((v, i) => fromPlain(el.of, v, `${path}[${i}]`, options));
    }
    if (el.shape === 'dict') {
      const out = new Map<unknown, unknown>();
      const put = (kj: unknown, vj: unknown, step: string): void => {
        const k = keyFrom(el.keyOf, kj, `${path}${step}`, options);
        const at = `${path}${keyStep(el.keyOf, typeof kj === 'string' || typeof kj === 'number' ? kj : k)}`;
        if (out.has(k)) throw new DataError(at, `the key ${JSON.stringify(kj)} twice`);
        out.set(k, fromPlain(el.valueOf, vj, at, options));
      };
      if (Array.isArray(json)) {
        json.forEach((pair, i) => {
          if (!Array.isArray(pair) || pair.length !== 2) throw new DataError(`${path}[${i}]`, `a pair is [key, value], not ${JSON.stringify(pair)}`);
          put(pair[0], pair[1], `[${i}]`);
        });
      } else if (typeof json === 'object' && json !== null) {
        if (!textKeys(el.keyOf) && !('shape' in el.keyOf) && el.keyOf.ref) throw new DataError(path, 'a dictionary of entities is written as pairs: [[entity, value], …]');
        for (const [k, v] of Object.entries(json)) put(k, v, keyStep(el.keyOf, k));
      } else throw new DataError(path, `${elementSaid(el)}, not ${JSON.stringify(json)}`);
      return out;
    }
    if (typeof json !== 'object' || json === null || Array.isArray(json)) throw new DataError(path, `${elementSaid(el)}: { … }, not ${JSON.stringify(json)}`);
    return fillFrom(el.fields as DataSchema, json, {}, options, path);
  }
  if (el.ref) return options.ref(json, path, el);
  if (el.vec !== undefined) {
    if (!Array.isArray(json) || json.length !== el.vec || json.some((x) => typeof x !== 'number' || !Number.isFinite(x))) throw new DataError(path, `a vector, [${['x', 'y', 'z', 'w'].slice(0, el.vec).join(', ')}]: ${el.vec} numbers, not ${JSON.stringify(json)}`);
    return options.number ? (json as number[]).map((n) => options.number!(n, el, path)) : [...(json as number[])];
  }
  if (el.bool) {
    if (typeof json === 'boolean') return json;
    if (json === 0 || json === 1) return json === 1;
    throw new DataError(path, `true or false, not ${JSON.stringify(json)}`);
  }
  if (el.key !== undefined) {
    if (typeof json === 'number') return json;
    if (json !== null && typeof json !== 'string' && !isKeyRef(json)) throw new DataError(path, `${elementSaid(el)} -- { "uid", "key" } or the key -- not ${JSON.stringify(json)}`);
    const text = resolveRef(el.key, json);
    if (text !== null && options.key) {
      const why = options.key(el.key, text, path);
      if (why !== null) throw new DataError(path, why);
    }
    return internKey(el.key, text);
  }
  const w = wrap(el);
  const problem = fieldProblem({ name: '', schema: w.schema }, 'v', json);
  if (problem !== null) throw new DataError(path, problem.replace(/^\.v: /, ''));
  const n = typeof json === 'number' ? (Number.isFinite(json) ? json : null) : el.enum || el.flags || el.color ? fieldValue(w, 'v', json) : null;
  if (n === null) throw new DataError(path, `${elementSaid(el)}, not ${JSON.stringify(json)}`);
  return options.number && !el.enum && !el.flags && !el.color ? options.number(n, el, path) : n;
}

/**
 * A record's fields (a data component's, or a `record`'s) read from `json` into `into`, each field it names in its
 * place, every other at its default: the same object back. A name the schema has not is a `DataError`.
 */
export function fillFrom(schema: DataSchema, json: unknown, into: Record<string, unknown>, options: ReadOptions, path = ''): Record<string, unknown> {
  const given = (typeof json === 'object' && json !== null && !Array.isArray(json) ? json : {}) as Record<string, unknown>;
  if (!options.lenient) for (const k of Object.keys(given)) if (!(k in schema) || k in Object.prototype) throw new DataError(path === '' ? k : `${path}.${k}`, `no field '${k}' -- its fields are ${Object.keys(schema).join(', ')}`);
  for (const [f, el] of Object.entries(schema)) into[f] = f in given ? fromPlain(el, given[f], path === '' ? f : `${path}.${f}`, options) : dataDefault(el);
  return into;
}

/**
 * `json` (an element's plain form, any writer's) with each ref in it -- a value, or a dict's key -- put through
 * `fn` (its path beside it): how one writer's refs become another's. What is malformed is left as it is, for
 * `fromPlain` to say. Allocates the copy.
 */
export function mapRefs(el: Element, json: unknown, fn: (ref: unknown, path: string) => unknown, path = ''): unknown {
  if ('shape' in el) {
    if (el.shape === 'string') return json;
    if (el.shape === 'list') return Array.isArray(json) ? json.map((v, i) => mapRefs(el.of, v, fn, `${path}[${i}]`)) : json;
    if (el.shape === 'dict') {
      const keyRef = !('shape' in el.keyOf) && el.keyOf.ref === true;
      if (Array.isArray(json)) {
        return json.map((pair, i) => {
          if (!Array.isArray(pair) || pair.length !== 2) return pair;
          const at = `${path}[${i}]`;
          return [keyRef ? fn(pair[0], at) : pair[0], mapRefs(el.valueOf, pair[1], fn, at)];
        });
      }
      if (typeof json !== 'object' || json === null) return json;
      const out: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(json)) out[k] = mapRefs(el.valueOf, v, fn, `${path}${keyStep(el.keyOf, k)}`);
      return out;
    }
    return mapFields(el.fields as DataSchema, json, fn, path);
  }
  return el.ref ? fn(json, path) : json;
}

/** `mapRefs` over a record's fields (a data component's top level): each field the schema has, the rest as they are. */
export function mapFields(schema: DataSchema, json: unknown, fn: (ref: unknown, path: string) => unknown, path = ''): unknown {
  if (typeof json !== 'object' || json === null || Array.isArray(json)) return json;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(json)) out[k] = k in schema ? mapRefs(schema[k]!, v, fn, path === '' ? k : `${path}.${k}`) : v;
  return out;
}

/** Each ref in `json`, with its path: `mapRefs` for its walk alone. */
export function eachRef(el: Element, json: unknown, visit: (ref: unknown, path: string) => void, path = ''): void {
  mapRefs(el, json, (r, at) => {
    visit(r, at);
    return r;
  }, path);
}

/** Is an element's value at its default, as a file would write it -- so a file need not? */
export const atDefault = (el: Element, value: unknown): boolean => JSON.stringify(dataPlain(el, value, rawOut)) === JSON.stringify(dataPlain(el, dataDefault(el), rawOut));

// ── paths ───────────────────────────────────────────────────────────────

/** One step of a path: a field or a dict's text key (`.sword`), or a list's index or a dict's number key (`[3]`). */
export type Step = { name: string } | { index: number };

/** `waypoints[2]`, `loot.sword`, `stats.speed`, `grid[1][0]` as its steps; null for what is no path. */
export function parsePath(text: string): Step[] | null {
  const out: Step[] = [];
  const re = /\.?([^.[\]]+)|\[(-?\d+)\]|\["((?:[^"\\]|\\.)*)"\]/gy;
  let at = 0;
  while (at < text.length) {
    re.lastIndex = at;
    const m = re.exec(text);
    if (!m || m.index !== at) return null;
    if (m[1] !== undefined) out.push({ name: m[1] });
    else if (m[2] !== undefined) out.push({ index: Number(m[2]) });
    else out.push({ name: JSON.parse(`"${m[3]}"`) as string });
    at = re.lastIndex;
  }
  return out.length > 0 && 'name' in out[0]! ? out : null;
}

/** A path as text: the steps written back. */
export const pathText = (steps: readonly Step[]): string => steps.map((s, i) => ('index' in s ? `[${s.index}]` : i === 0 ? s.name : /^[^.[\]"]+$/.test(s.name) ? `.${s.name}` : `["${s.name}"]`)).join('');

/** Where a path leads: the element there, the container holding it and how it is held there, and its value now. */
export interface At {
  el: Element;
  /** The element of what holds it -- null for a data component's own field. */
  parent: Element | null;
  /** The object, array or Map it is in. */
  holder: Record<string, unknown> | unknown[] | Map<unknown, unknown>;
  /** Its place there: a field's name, an index, a dict's key as the Map holds it. */
  slot: string | number | unknown;
  value: unknown;
  /** The path to it, as text. */
  path: string;
}

/**
 * The element at `steps` of a data component's value: what a path names, or a `DataError` saying why not -- a field
 * there is not, an index past the end, a key a dict has not (`loot.swrod: no key "swrod" -- its keys are …`).
 * `ref` reads a dict's entity key, as the place asking writes one.
 */
export function elementAt(schema: DataSchema, value: Record<string, unknown>, steps: readonly Step[], ref: (json: unknown, path: string, field: Field) => EntityRef = rawIn): At {
  let el: Element = { shape: 'record', fields: schema };
  let parent: Element | null = null;
  let holder: At['holder'] = value;
  let slot: unknown = '';
  let now: unknown = value;
  let path = '';
  for (const [i, s] of steps.entries()) {
    const step = 'index' in s ? `[${s.index}]` : i === 0 ? s.name : `.${s.name}`;
    const here = path + step;
    if (!('shape' in el)) throw new DataError(path, `${elementSaid(el)} has nothing inside: no ${step}`);
    if (el.shape === 'string') throw new DataError(path, `text has nothing inside: no ${step}`);
    if (el.shape === 'record') {
      const fields = el.fields as DataSchema;
      const name = 'name' in s ? s.name : String(s.index);
      if (!(name in fields)) throw new DataError(here, `no field '${name}' -- ${path === '' ? 'the fields are' : `${path}'s fields are`} ${Object.keys(fields).join(', ')}`);
      parent = el;
      holder = now as Record<string, unknown>;
      slot = name;
      el = fields[name]!;
      now = (holder as Record<string, unknown>)[name];
    } else if (el.shape === 'list') {
      const arr = now as unknown[];
      if (!('index' in s)) throw new DataError(here, `${path} is a list: an element is [index]`);
      const at = s.index < 0 ? arr.length + s.index : s.index;
      if (at < 0 || at >= arr.length) throw new DataError(here, `no element ${s.index} -- ${path} has ${arr.length}${arr.length > 0 ? `, [0] to [${arr.length - 1}]` : ''}`);
      parent = el;
      holder = arr;
      slot = at;
      el = el.of;
      now = arr[at];
    } else {
      const map = now as Map<unknown, unknown>;
      const k = keyFrom(el.keyOf, 'index' in s ? s.index : s.name, here, { ref });
      if (!map.has(k)) {
        const keyEl = el.keyOf;
        const keys = [...map.keys()].map((x) => JSON.stringify(!('shape' in keyEl) && keyEl.enum ? (keyEl.enum[x as number] ?? x) : x));
        throw new DataError(here, `no key ${JSON.stringify('index' in s ? s.index : s.name)} -- ${keys.length > 0 ? `its keys are ${keys.join(', ')}` : `${path} is empty`}`);
      }
      parent = el;
      holder = map;
      slot = k;
      el = el.valueOf;
      now = map.get(k);
    }
    path = here;
  }
  return { el, parent, holder, slot, value: now, path };
}

/** `at`'s value replaced by `next` in its holder: the object, array or Map. */
export function putAt(at: At, next: unknown): void {
  if (at.holder instanceof Map) at.holder.set(at.slot, next);
  else if (Array.isArray(at.holder)) at.holder[at.slot as number] = next;
  else (at.holder as Record<string, unknown>)[at.slot as string] = next;
}

/** How many a list may have, by its `min` and `max`: why `n` more (or fewer) is refused, or null. */
export function countMisfit(el: ListElement, length: number): string | null {
  if (el.max !== undefined && length > el.max) return `at most ${el.max} -- it would have ${length}`;
  if (el.min !== undefined && length < el.min) return `at least ${el.min} -- it would have ${length}`;
  return null;
}

/** A Map's entries again in a new order: `from`'s entry moved to `to`, the rest in order. In place. */
export function moveEntry<K, V>(map: Map<K, V>, from: number, to: number): void {
  const entries = [...map];
  const [moved] = entries.splice(from, 1);
  if (moved === undefined) return;
  entries.splice(Math.max(0, Math.min(to, entries.length)), 0, moved);
  map.clear();
  for (const [k, v] of entries) map.set(k, v);
}

/** An array's element moved from `from` to `to` (the rest shifted), in place. */
export function moveItem<T>(list: T[], from: number, to: number): void {
  if (from < 0 || from >= list.length) return;
  const [moved] = list.splice(from, 1);
  list.splice(Math.max(0, Math.min(to, list.length)), 0, moved!);
}

/**
 * The first key a dict has not, for its + (Docs/properties.md §3): an enum's next name unused, `"key 2"` for text
 * (`"key"` first), the next whole number for a number; null when every name of an enum is taken, or for an entity.
 */
export function freeKey(el: DictElement, map: ReadonlyMap<unknown, unknown>): unknown {
  const k = el.keyOf;
  if ('shape' in k) {
    if (!map.has('key')) return 'key';
    for (let n = 2; ; n++) if (!map.has(`key ${n}`)) return `key ${n}`;
  }
  if (k.ref) return null;
  if (k.enum) {
    for (let i = 0; i < k.enum.length; i++) if (!map.has(i)) return i;
    return null;
  }
  let n = 0;
  for (const x of map.keys()) if (typeof x === 'number' && x >= n) n = Math.floor(x) + 1;
  return n;
}

// ── the schema, as MCP's scene_entity answers it ────────────────────────

/** An element's schema, all the way down: a field's as `fieldSchema` says it, a string's, a list's, a dict's, a record's. */
export function elementSchema(el: Element, name: string): FieldSchema {
  if (!('shape' in el)) {
    const one = fieldSchema({ name: '', schema: { [name]: el }, fields: [{ name, type: el.type, initial: el.initial }] })[name]!;
    if (el.vec !== undefined) {
      one.kind = 'vector';
      one.size = el.vec;
    }
    return one;
  }
  const base: FieldSchema = { kind: el.shape, type: el.shape === 'string' ? 'string' : 'object', label: el.label ?? spaced(name) };
  if (el.help !== undefined) base.help = el.help;
  if (el.readonly) base.readonly = true;
  if (el.hidden) base.hidden = true;
  if (el.group !== undefined) base.group = el.group;
  if (el.shape === 'string') {
    if (el.maxLength !== undefined) base.maxLength = el.maxLength;
    if (el.multiline) base.multiline = true;
  } else if (el.shape === 'list') {
    base.of = elementSchema(el.of, 'element');
    if (el.min !== undefined) base.min = el.min;
    if (el.max !== undefined) base.max = el.max;
  } else if (el.shape === 'dict') {
    base.key = elementSchema(el.keyOf, 'key');
    base.value = elementSchema(el.valueOf, 'value');
  } else {
    base.fields = {};
    for (const [f, sub] of Object.entries(el.fields as DataSchema)) base.fields[f] = elementSchema(sub, f);
  }
  return base;
}

/** A data component's fields' schemas, by name: what `scene_set` takes at each, all the way down. */
export function dataSchema(c: DataComponentOf): Record<string, FieldSchema> {
  const out: Record<string, FieldSchema> = {};
  for (const [f, el] of Object.entries(c.data)) out[f] = elementSchema(el, f);
  return out;
}
