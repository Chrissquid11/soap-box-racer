/**
 * The ECS: components in columns, systems on the loop. Docs/ecs.md is the design.
 *
 *   component tag objectComponent optional        what data there is (`component.ts`)
 *   kind allKinds                                  the component sets entities are grouped by: the engine's, made by prefabs
 *   relation event                                links between entities; things that happened
 *   f32 f64 i8 u8 i16 u16 i32 u32 bool ref         a numeric component's fields, each with its options (label, min, max, slider …)
 *   enumOf flagsOf vec2 vec3 vec4 colorA           names, sets of names, vectors, a colour with alpha (`fields.ts`: as files and tools see them)
 *   dataComponent string list dict record          a component of lists, dictionaries, text and records, its shape declared (`data.ts`)
 *   key mesh color internKey keyText meshOf        an asset key's field of any kind, a model's part (its id interned, `keys.ts`) and a colour's
 *   Render Animation AnimationEnded Camera         what an entity is drawn as, how it moves, and what it is seen through, as data (`render-components.ts`, Docs/render.md, Docs/camera.md)
 *   prefab compilePrefabs prefabOfKey              prefabs: what a game spawns (`prefab.ts`, Docs/prefabs.md); a key('Prefab') field's
 *   World                                          system, query, store, spawn and the rest (`world.ts`)
 *   Transform WorldTransform Hierarchy Name        built in
 *   Disabled Hidden Layer Labels                   every entity: switched off, unseen, its layer, its labels
 *   beginGeneration endGeneration generationOpen   game modules evaluated again: a name defined again takes its slot
 *   rebuildWorld                                   the world saved, reset in place and built again by new modules (`rebuild.ts`)
 */
export {
  component, tag, objectComponent, kind, kindAgain, optional, relation, event, allKinds, allComponents, beginGeneration, endGeneration, generationOpen,
  f32, f64, i8, u8, i16, u16, i32, u32, bool, ref, key, mesh, color, colorA, enumOf, flagsOf, vec2, vec3, vec4, AXES,
  type ColumnSpec, type EnumField, type FieldOptions, type FlagsField, type MenuOptions, type VecField, type VecOptions,
  NONE, NO_REF, Bare, Hierarchy, Transform, WorldTransform, Name, Disabled, Hidden, Unpickable, Layer, Instance, Labels, layers, layerName, allLayers,
  type Access, type AnyComponent, type Channel, type Component, type DataComponent, type Entity, type EntityRef, type EventType, type Field, type FieldType, type GenerationChange, type Kind, type KeyKind,
  type ObjectComponent, type ObjectStore, type Optional, type ReadObjectStore, type ReadRelationStore, type ReadStore, type Reads, type Relation,
  type RelationStore, type Schema, type Store, type StoreOf, type Tag, type Writes,
} from './component.ts';
export {
  dataComponent, string, list, dict, record, isData, dataDefault, dataPlain, fromPlain, fillFrom, mapRefs, mapFields, eachRef, atDefault, DataError, elementSaid,
  dataSchema, elementSchema, entryStep, strayFields, parsePath, pathText, elementAt, putAt, countMisfit, moveItem, moveEntry, freeKey, rawIn, rawOut,
  type At, type BoolField, type DataComponentOf, type DataSchema, type DataValue, type DictElement, type DictOptions, type Element, type ListElement, type ListOptions,
  type ReadOptions, type RecordElement, type Step, type StringElement, type StringOptions, type ValueOf,
} from './data.ts';
export { colourValue, fieldIsText, fieldPlain, fieldProblem, fieldText, fieldValue, flagNames, hex, hexA, internKey, keyKindOf, keyKinds, keyText } from './keys.ts';
export { andList, clampTo, fieldSchema, fileEntry, fileFieldOf, fileFields, foldVectors, INT_RANGE, labelOf, refMisfit, refTakes, spaced, unfoldEntry, type FieldSchema, type FileField } from './fields.ts';
export { Animation, AnimationEnded, AnimationLoop, Camera, CameraClear, CameraProjection, meshOf, Render, splitModel } from './render-components.ts';
export { World, ENTITY_LIMIT, INDEX_BITS, followSavedPrefabs, type Pool, type EntityList, type Query, type RenderDef, type RenderSystemContext, type SimulationDef, type SystemContext, type StageInfo, type SystemReport, type WorldOptions, type WorldSave, type WorldStats } from './world.ts';
export { Commands } from './commands.ts';
export { canonical, checkPrefab, compileLive, compilePrefabs, compiledPrefab, markGameTokens, compiledPrefabs, isOutsideRef, nestedKey, pathInOwner, pool, prefab, prefabOfKey, refindNodes, PrefabNode, PrefabToken, type CompiledPrefab, type Override, type OutsideRef, type PoolSize, type PrefabOwner, type PrefabEntity, type PrefabFile, type PrefabThen, type FileValue } from './prefab.ts';
export { MAX_DEPTH } from './transform.ts';
export { rebuildWorld, type Rebuild } from './rebuild.ts';
export { applyUpdates, carried, fitInstance, instanceRoots, overrideList, overridesOf, pathList, pendingUpdates, plainSave, refreshInstances, same, sameCompile, sceneSave, type Difference, type InstanceOverrides, type Pending } from './overrides.ts';
export { childrenOf, componentsOn, fieldsOf, inTreeOrder, label, layerOf, linksOf, madeFrom, madeFromText, membership, prefabText, relationsOf, rootsOf, writeField, type FieldValue, type Link, type Membership } from './inspect.ts';
