---
skill: engine
title: Prefabs
when: Before making a new kind of thing, spawning or destroying one in code, nesting, pooling or overriding a prefab, or writing a .prefab file
covers:
  modules: [prefabs.ts, prefab-token.ts, prefab-files.node.ts, ecs/prefab.ts, ecs/overrides.ts]
order: 30
---
# Prefabs: what a thing is made of

A prefab is a small tree of entities saved as an asset: their components and numbers, their tags, their
links, what each one draws. The game stamps out **instances** of it, which stay linked to it: change the file
and every instance follows, but for what an instance changed itself (an **override**). Everything the game
spawns is a prefab -- a bullet as much as a boss; the only other spawn is a bare `cmd.spawn()`, an empty
entity code fills in. The code is `node_modules/@vibe/engine/src/ecs/prefab.ts` (the file, the compile,
`instantiate`) and `prefab-token.ts` (the typed token).

## The file

`src/assets/prefabs/<key>.prefab`, JSON inside: `crates/chip.prefab` is the key `crates/chip`. A `.json` there
is no prefab (the editor and the key generator say so), and a `.prefab` anywhere else is a problem.

```json
{
  "is": "vibebase.prefab",
  "version": 1,
  "pool": { "warm": 16, "max": 64 },
  "entities": [
    {
      "id": "chip",
      "name": "chip",
      "parent": null,
      "components": ["Transform", "Chip", "Render"],
      "data": {
        "Transform": { "sx": 0.07, "sy": 0.07, "sz": 0.07 },
        "Render": { "model": "props/crate" }
      },
      "tags": ["Wanderer"]
    }
  ]
}
```

- **`id`** is the entity's within the file, stable for its life (no `/` in it); `name` is what the editor shows;
  `parent` another entity's `id`, or `null` for the root -- the first entity, and the only one with `null`.
- **`components`** is what it is made of; **`data`** only what differs from each component's defaults.
  `tags` (`"Disabled"` and `"Hidden"` among them), `layer`, `off` (components switched off), `objects` (an object
  component's data), `refs` (a `ref()` field pointing at another entity of the file) and `links` (a relation's:
  `{ "relation": "Likes", "to": ["b7"], "data": { "much": 2 } }`) as needed.
- **A field systems set** (`component(..., { runtime: [...] })`) is never written in a file: one that is fails the
  compile, naming the prefab, the entity and the field. Here `Chip`'s fields are all runtime: the file only
  says the entity has one.
- **An asset is named by its key** (`"props/crate"`); the pipeline turns it into `{ "uid": "uid://…", "key":
  "props/crate" }` when it next passes, and from then the uid finds the asset wherever it moves. Keep a uid a file
  has; never make one up ([the assets page](assets.md)).
- **What it draws is its `Render`**, a component like any: `model` (a part of a model is `"props/robot#arm"`),
  `material`, `tint`, the shadows ([the render page](render.md)). A camera is a `Camera` component the same way
  ([the camera page](camera.md)).
- **Every key on every object is checked**: an unknown one is a compile error with the nearest real one
  (`no key "dta" (did you mean "data"?)`) -- never silently ignored.

**Nesting**: an entity line `{ "id": "rider", "parent": "crate", "prefab": "crates/rider", "overrides": [...] }`
is an instance of another prefab inside this one, to any depth. **A variant** is a prefab whose root is an
instance of another. An override, by the path of ids inside the nested instance (`[]` its root):

```json
{ "at": [], "set": { "Transform": { "px": 0.9, "py": 1.6, "sx": 0.3 } } }
```

and also `add` / `remove` (components or tags), `off` / `on`, `layer`, `name`, `removed` (an inner entity taken
out), `links`, `refs`, `objects`, `parent`. The
editor writes overrides for you (an instance's changed field is marked, with Apply and Revert): to change a
prefab, edit its file or open it in the studio ([the scene page](../studio/scene.md)).

## The token

```ts
import { prefab } from '@vibe/engine';

export const BigCrate = prefab('crates/big');        // in src/game/prefabs.ts, at module level
export const RiderOfBig = BigCrate.node('rider');    // a named entity of it, by its id
```

The key, the node's name, a `Render.model` in the file and every `cmd.init` on an instance are checked by the
typecheck (through the generated `keys.d.ts`): `prefab('crates/bgi')` and `BigCrate.node('ridr')` do not build.
A key takes any case (`prefab('Crates/Big')`), and is the path lowercased. Never a `kind()` in game code: kinds
are what the compile makes of the files.

## Making and ending one

```ts
import { NONE, Transform, WorldTransform, type World } from '@vibe/engine';
import { Chip, Spin } from '../components.ts';
import { ChipOfCrate } from '../prefabs.ts';

export function shed(world: World): void {
  world.system({
    name: 'shed',
    rate: 10,
    read: [WorldTransform],
    with: [Spin],
    update({ members, count, cmd, rng, time }, [at]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        if (!rng.chance(0.35)) continue;
        const chip = cmd.instantiate(ChipOfCrate);   // the whole tree; its root's id at once
        if (chip === NONE) continue;                  // its pool at its max: no chip this time
        const place = cmd.init(chip, Transform);      // a component its file makes it with
        place.px[chip] = at.px[e];
        place.py[chip] = at.py[e] + 0.3;
        place.pz[chip] = at.pz[e];
        const fly = cmd.init(chip, Chip);
        fly.vy[chip] = rng.range(2, 3.5);
        fly.until[chip] = time + rng.range(1.2, 2.4);
      }
    },
  });
}
```

and another system ends it, `if (time >= chip.until[e]) cmd.destroy(e);` -- the root's `destroy` takes the
whole instance. Outside a system (setup, `populate`, a test), the same on `world`: `world.instantiate(BigCrate)`.

- **A prefab a file names** -- a `key('Prefab')` field, a loot table's entry -- holds the key's id:
  `prefabOfKey(id)` is the token for `cmd.instantiate`, made once a key and the same after (no allocation), null
  for none or for a prefab gone; check it (the [fields page](fields.md) has a loot system doing so).

- **`cmd.init(e, C)`** gives the writable store, to fill in an instance made this tick -- only for a component
  its file makes it with (the typecheck says so otherwise). Its rows are good at once; it joins the systems at
  the boundary.
- **`cmd.part(root, RiderOfBig)`** is an entity of an instance, by its node.
- **`Instance`** is on every entity a prefab made: `world.prefabOf(e)` and `world.instanceRoot(e)` read it.

## Pools

```json
"pool": { "warm": 16, "max": 64 }
```

in the file (the studio's Assets panel edits it) -- or `pool(ChipOfCrate, { warm: 16, max: 64 })` at module level
when the numbers are the code's; never both (a compile error). Then the game code is the same: `instantiate`
takes a parked instance, `destroy` gives it back.

- **A parked instance is a new one**: reset at the give-back to exactly what the file makes, every ref to it
  `NONE` at once (a missile never follows its target into its next life). It is not `alive`, in no system,
  in no save.
- **At `max`, `instantiate` answers `NONE`** and warns once: always check it.
- `world.pool(ChipOfCrate)` reads `parked`, `out`, `mostOut`; `drain()` between rounds frees what is parked,
  `trim(n)` leaves `n`. Its numbers are read-only.
- **Never a free list or a `dead` flag of your own**, never a pool in code beside one in the file.
- Nested in another prefab, a pooled prefab is a plain part of the outer one's instances.

## Scenes and saves

A scene file (`src/assets/scenes/*.scene`) holds each instance by its prefab and its overrides: loaded, every
instance is brought to its prefab as it is now, so a prefab edited reaches every scene without opening it.
`world.save()` -- a saved game -- keeps full data and plays back as it was. A prefab that is gone loads its
instances as plain entities, and says so; a node renamed in the file is found again by its `name`.

## Live

In studio mode a saved prefab recompiles at once, and every instance in the world follows it where it holds
no override of its own; the plain page sees it after a reload. A file that fails to compile names the prefab,
the entity and the key, and the last good compile stays.

## The rules that bite

- What a thing is made of is its file -- never a list of components in code, never a `kind()`.
- Write only what differs from the defaults; never a runtime field; a key, never a URL or a path.
- A per-instance look is `Render.tint` or another material file, never a material cloned in code.
- In a test, the prefabs are compiled from disk: `compilePrefabs(prefabFilesFromDisk(...))` ([the testing
  page](testing.md)).
