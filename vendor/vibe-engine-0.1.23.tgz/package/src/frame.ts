/**
 * The game's frame (Docs/game-view.md §2): the rect of the canvas, in CSS pixels from its top left, that the game is
 * drawn in. The world's viewport and scissor, every `Camera`'s viewport fractions and aspect, the built-in camera's
 * aspect, the pointer and the canvas UI all measure the frame, never the canvas. **The canvas never shrinks**: the
 * frame only says where in it the game goes. None given (`Game.setFrame(null)`), the frame is the whole canvas -- what
 * a release build and the plain page always have. The editor gives its scene's room (studio mode).
 *
 * Pure: `Game`, `attachDevices` and the canvas UI ask these, and node tests them (`frame.test.ts`).
 */

/** A rect of the canvas in CSS pixels, from its top left. */
export interface FrameRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * The frame in effect on a canvas of `width` by `height` CSS pixels, written into `out`: `given` cut to the canvas,
 * in whole pixels -- the whole canvas for none, or for one that leaves less than a pixel each way. True when `out`
 * changed.
 */
export function frameIn(given: Readonly<FrameRect> | null, width: number, height: number, out: FrameRect): boolean {
  let x = 0;
  let y = 0;
  let w = width;
  let h = height;
  if (given !== null) {
    const left = Math.max(0, Math.min(width, Math.round(given.x)));
    const top = Math.max(0, Math.min(height, Math.round(given.y)));
    const right = Math.max(0, Math.min(width, Math.round(given.x + given.width)));
    const bottom = Math.max(0, Math.min(height, Math.round(given.y + given.height)));
    if (right - left >= 1 && bottom - top >= 1) {
      x = left;
      y = top;
      w = right - left;
      h = bottom - top;
    }
  }
  if (out.x === x && out.y === y && out.width === w && out.height === h) return false;
  out.x = x;
  out.y = y;
  out.width = w;
  out.height = h;
  return true;
}

/** Is `frame` the whole of a canvas of `width` by `height`. */
export function isWhole(frame: Readonly<FrameRect>, width: number, height: number): boolean {
  return frame.x === 0 && frame.y === 0 && frame.width === width && frame.height === height;
}

/** The frame's bottom edge measured from the canvas's bottom, as three's viewports are: CSS pixels. */
export function frameBottom(frame: Readonly<FrameRect>, canvasHeight: number): number {
  return canvasHeight - frame.y - frame.height;
}

/**
 * A point of the canvas (CSS pixels from its top left) made frame-local, into `out`: true if it is in the frame --
 * the game's -- false outside it, where the pointer is not the game's.
 */
export function framePoint(x: number, y: number, frame: Readonly<FrameRect>, out: { x: number; y: number }): boolean {
  out.x = x - frame.x;
  out.y = y - frame.y;
  return out.x >= 0 && out.y >= 0 && out.x < frame.width && out.y < frame.height;
}

// ---------------------------------------------------------------- the resolution (Docs/game-view.md §4, V3)

/**
 * How the game is shaped inside its frame (`Game.setResolution`): exactly `width` × `height` pixels, or only an
 * aspect (`aspect`, width over height). **Fit** draws the world at the screen's own sharpness in the largest box of
 * that aspect; **Pixel** draws it at exactly `width` × `height` into a target scaled by the largest whole number that
 * fits, nearest-neighbour; **Stretch** draws it at exactly `width` × `height` and scales that to the largest box of its
 * aspect by any factor, `nearest` or `linear`. An editor preview (D4): a release build never sets one.
 */
export type GameResolution =
  | { readonly width: number; readonly height: number; readonly mode: 'fit' | 'pixel' | 'stretch'; readonly filter: 'nearest' | 'linear' }
  | { readonly aspect: number; readonly mode: 'fit' };

/** Does `r` draw the world into a target of its own size (Pixel, Stretch), rather than straight into the box (Fit)? */
export function drawsScaled(r: Readonly<GameResolution> | null): r is { readonly width: number; readonly height: number; readonly mode: 'pixel' | 'stretch'; readonly filter: 'nearest' | 'linear' } {
  return r !== null && r.mode !== 'fit' && 'width' in r;
}

/**
 * Where a one-off frame (`Game.drawOnce`, the editor's `view_shot`) draws the world, and whether into the resolution's
 * target: through the game's own cameras (`explicit` false), as the screen does -- the box, scaled if the resolution
 * draws scaled; through a camera given (the editor's, a camera entity's), the whole room at the screen's sharpness --
 * no box, no bars, no target: a preview's preset shapes the game's picture, not a shot of the scene.
 */
export function shotArea(room: Readonly<FrameRect>, box: Readonly<FrameRect>, r: Readonly<GameResolution> | null, explicit: boolean): { rect: Readonly<FrameRect>; scaled: boolean } {
  return explicit ? { rect: room, scaled: false } : { rect: box, scaled: drawsScaled(r) };
}

/**
 * The box the game is drawn in, inside `room` (the frame given, CSS pixels), written into `out`, and its scale: the
 * resolution's pixel over the screen's -- device pixels (`ratio` of them to a CSS pixel, the renderer's pixel ratio)
 * per game pixel -- 1 for none and for Fit, exact size or aspect alone (drawn at the screen's sharpness). None: the room itself. Otherwise the largest box of the
 * resolution's aspect, centred, in whole CSS pixels; for Pixel the resolution times the largest whole number of
 * *device* pixels that fits, so every game pixel is exactly that many of the screen's at any ratio (at 1.5, ×3 is two
 * CSS pixels; ×4 is 2⅔, and the box's CSS size and corner are then fractions, its corner on a device pixel) -- or, in
 * a room smaller than the resolution, the largest box of its aspect after all, under 1.
 */
export function fitBox(room: Readonly<FrameRect>, r: Readonly<GameResolution> | null, out: FrameRect, ratio = 1): number {
  if (r === null) {
    out.x = room.x;
    out.y = room.y;
    out.width = room.width;
    out.height = room.height;
    return 1;
  }
  const exact = 'width' in r;
  const aspect = exact ? r.width / r.height : r.aspect;
  let w: number;
  let h: number;
  const whole = exact && r.mode === 'pixel' ? Math.floor(Math.min((room.width * ratio) / r.width, (room.height * ratio) / r.height)) : 0;
  if (whole >= 1 && exact) {
    w = (r.width * whole) / ratio;
    h = (r.height * whole) / ratio;
    // Centred, its corner on a device pixel: CSS pixels are whole only at a whole ratio.
    out.x = Math.floor((room.x + (room.width - w) / 2) * ratio) / ratio;
    out.y = Math.floor((room.y + (room.height - h) / 2) * ratio) / ratio;
    out.width = w;
    out.height = h;
    return whole;
  }
  if (room.width / room.height > aspect) {
    h = room.height;
    w = Math.max(1, Math.round(h * aspect));
  } else {
    w = room.width;
    h = Math.max(1, Math.round(w / aspect));
  }
  out.x = room.x + Math.floor((room.width - w) / 2);
  out.y = room.y + Math.floor((room.height - h) / 2);
  out.width = w;
  out.height = h;
  return drawsScaled(r) ? (w * ratio) / r.width : 1;
}

/**
 * A frame-local point (CSS pixels) into the game's own pixels, in place: the same for a box drawn at the screen's
 * sharpness (`pixels` its own size), scaled for one drawn into a target (Pixel, Stretch) -- what the game's cameras see.
 */
export function framePixels(local: { x: number; y: number }, frame: Readonly<FrameRect>, pixels: { readonly width: number; readonly height: number }): void {
  if (pixels.width === frame.width && pixels.height === frame.height) return;
  local.x = (local.x * pixels.width) / frame.width;
  local.y = (local.y * pixels.height) / frame.height;
}
