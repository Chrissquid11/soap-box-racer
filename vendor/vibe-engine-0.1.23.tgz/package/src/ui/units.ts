/**
 * The canvas UI's units: `u` for the HUD, `m` for the menus. **Every length the
 * UI lays out is a multiple of one** -- `34 * units.u`, never a bare pixel -- so
 * the layout shrinks as a whole on a small or narrow screen and cannot overlap
 * itself.
 *
 * ## `u`, the HUD's
 *
 *   One CSS pixel when the window is at least the size the HUD was laid out
 *   for (`HUD_REFERENCE`), and proportionally less when it is smaller either
 *   way. Portrait has its own reference: a phone held upright is narrow, and
 *   a HUD fitted to a landscape width would be tiny on it.
 *
 *   The reference sizes are not taste: they are where the pieces touch. When
 *   a game's HUD is laid out, set them to the smallest window it fits whole.
 *
 * ## `m`, the menus'
 *
 *   `min(1, h / MENU_REFERENCE_HEIGHT)`: one CSS pixel from that height, less
 *   below, so a centred menu shrinks as a whole on a short window instead of
 *   spilling off it. Widths can follow the window between limits: `menu()`.
 *
 * ## CSS pixels, not drawing-buffer ones
 *
 *   Everything the UI lays out is in CSS pixels, the stage's own: the renderer
 *   is at the game's pixel ratio, so a widget sized 34u is 34u on screen and
 *   crisp at every ratio.
 *
 * ## The safe area
 *
 *   A canvas cannot read `env(safe-area-inset-*)`, so `readSafeArea` asks a
 *   hidden element padded by them what they came to -- once a resize, not once
 *   a frame.
 *
 * Pure but for `readSafeArea`: `measureUnits` runs in node (`units.test.ts`).
 */

/** Pixels each side a notch or a home bar takes, CSS pixels. */
export interface Insets {
  readonly top: number;
  readonly right: number;
  readonly bottom: number;
  readonly left: number;
}

export const NO_INSETS: Insets = { top: 0, right: 0, bottom: 0, left: 0 };

/** The window's size -- the game's frame's, in the editor (Docs/game-view.md §2) -- its shape and the two units, all in CSS pixels. */
export interface Units {
  /** The window (`100vw` and `100vh`), or the game's frame in it. */
  readonly width: number;
  readonly height: number;
  /** Taller than wide, or square. */
  readonly portrait: boolean;
  /** The HUD's unit, CSS pixels. */
  readonly u: number;
  /** The menus' unit, CSS pixels. */
  readonly m: number;
  /** The safe area's insets (`env(safe-area-inset-*)`). */
  readonly safe: Insets;
}

/** The smallest window the full HUD fits at one CSS pixel a unit, each way up. */
export const HUD_REFERENCE = {
  landscape: { width: 960, height: 640 },
  portrait: { width: 600, height: 1000 },
} as const;

/** The height a menu is laid out for at one CSS pixel a unit. */
export const MENU_REFERENCE_HEIGHT = 720;

/** The HUD's unit for a window. */
export function hudUnit(width: number, height: number): number {
  const ref = width <= height ? HUD_REFERENCE.portrait : HUD_REFERENCE.landscape;
  return Math.min(1, width / ref.width, height / ref.height);
}

/** The menus' unit for a window. */
export function menuUnit(height: number): number {
  return Math.min(1, height / MENU_REFERENCE_HEIGHT);
}

/** Every unit for a window of this size. */
export function measureUnits(width: number, height: number, safe: Insets = NO_INSETS): Units {
  return { width, height, portrait: width <= height, u: hudUnit(width, height), m: menuUnit(height), safe };
}

/**
 * The safe area's insets that reach a frame: each side's only where the frame touches that edge of a canvas of
 * `width` by `height` (the window's) -- a frame inside the editor's cards is clear of the notch.
 */
export function insetsIn(safe: Insets, frame: { x: number; y: number; width: number; height: number }, width: number, height: number): Insets {
  const top = frame.y <= 0 ? safe.top : 0;
  const left = frame.x <= 0 ? safe.left : 0;
  const right = frame.x + frame.width >= width ? safe.right : 0;
  const bottom = frame.y + frame.height >= height ? safe.bottom : 0;
  if (top === safe.top && left === safe.left && right === safe.right && bottom === safe.bottom) return safe;
  return { top, right, bottom, left };
}

/** `n` percent of the window's width, CSS pixels: a `vw`. */
export const vw = (units: Units, n: number): number => (units.width * n) / 100;

/** `n` percent of the window's height, CSS pixels: a `vh`. */
export const vh = (units: Units, n: number): number => (units.height * n) / 100;

/**
 * A size that follows the window's width between two limits and shrinks with a
 * short window as the rest of the menu does: `min(clamp(lo, vwPct vw, hi), hi * m)`.
 */
export function menu(units: Units, lo: number, vwPct: number, hi: number): number {
  return Math.min(Math.min(Math.max(lo, vw(units, vwPct)), hi), hi * units.m);
}

let probe: HTMLElement | null = null;

/**
 * The safe area's insets, read off a hidden element padded by
 * `env(safe-area-inset-*)`: the only way to learn them outside CSS. Cheap, but
 * it forces a style recalculation -- once a resize, not once a frame.
 */
export function readSafeArea(): Insets {
  if (typeof document === 'undefined') return NO_INSETS;
  if (!probe) {
    probe = document.createElement('div');
    probe.setAttribute('aria-hidden', 'true');
    probe.style.cssText =
      'position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;' +
      'padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)';
    document.body.appendChild(probe);
  }
  const style = getComputedStyle(probe);
  const px = (v: string): number => parseFloat(v) || 0;
  return { top: px(style.paddingTop), right: px(style.paddingRight), bottom: px(style.paddingBottom), left: px(style.paddingLeft) };
}
