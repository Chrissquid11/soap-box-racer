/**
 * The canvas UI: Pixi, drawing the HUD and the menus into the game's own
 * canvas, after the world, every frame. A recorder or capture that films the
 * canvas sees no HTML, so everything a player reads belongs in it; the page
 * holds only the canvas and a loading bar.
 *
 * ## One context, two renderers
 *
 *   Pixi's `WebGLRenderer` is made on three's WebGL2 context
 *   (`renderer.getContext()`), not a context of its own: one canvas, one
 *   drawing buffer, and the UI lands on the frame the world just finished. It
 *   never clears (`clearBeforeRender: false`), is transparent where it draws
 *   nothing, and is at the game's pixel ratio.
 *
 *   The two share GL state, and each caches what it believes is bound. So
 *   every piece of Pixi work is, in order (`onPixiSide`):
 *
 *   1. `three.resetState()`, which puts the context itself back to GL's
 *      defaults -- a scissor or stencil test left on by the world's last
 *      material clips or hides the UI otherwise.
 *   2. `pixi.resetState()`, then the work: a draw, but also a layout or a text
 *      change, because Pixi uploads a texture the moment its source changes.
 *   3. `three.resetState()` again, so three re-reads everything rather than
 *      trust a cache Pixi has made stale.
 *
 *   Pixi's masks are why three's context has a stencil buffer (`Game`).
 *   **Never `pixi.destroy()`**: Pixi's context system would lose the context
 *   on the way out, and it is three's.
 *
 *   Pixi's own loop is off. Its housekeeping ticker (`Ticker.system` -- texture
 *   collection, hover checks under a still pointer) is stopped and stepped from
 *   the UI's own draw, so the page has no second loop of Pixi's.
 *
 * ## When it draws
 *
 *   - **While the game runs**, from the game's frame: `Game.onDrawn` is called
 *     at the end of every frame it draws. One frame, one UI draw.
 *   - **While the game is stopped** -- a menu over it -- the UI's own loop calls
 *     `Game.present` once a displayed frame, which copies the frame kept when
 *     the game stopped (`still.ts`) and then calls `onDrawn`. The UI
 *     animates at the display's rate; the world stands, for the price of a copy.
 *   - **Nothing to draw, nothing drawn**: with every layer empty or hidden the
 *     UI skips Pixi altogether, and a stopped game is not presented again.
 *
 *   Widgets animate in **real seconds** (`frame(dt)`), whatever the game's time
 *   is doing.
 *
 * ## Sizes
 *
 *   The stage is in CSS pixels: the drawing buffer over the pixel ratio. Each
 *   draw checks the canvas's size first and, if it changed, resizes Pixi and
 *   lays every widget out again (`units.ts`) before drawing -- so a resize is
 *   never drawn at the old size, whichever listener heard of it first.
 *
 *   **In the game's frame** (`Game.frame`, Docs/game-view.md §2): the units are
 *   measured from the frame's size, the stage sits at its corner and, while the
 *   frame is not the whole canvas, is clipped to it -- and a pointer outside it
 *   is never the UI's. The frame moved is a resize like any other.
 *
 * ## Layers
 *
 *   `LAYERS`, bottom to top. Add one where a game needs it -- a fade between
 *   the HUD and the menus, confetti over everything. `visible` hides them all
 *   at once, for clean footage: the world alone on the canvas.
 *
 * ## Losing the context
 *
 *   The context is three's, so losing it takes down both renderers at once.
 *   three handles its own side (it keeps the context restorable and rebuilds
 *   its state on restore). **Pixi never hears of either event**: it listens on
 *   the canvas it made for itself, which nothing loses. So while the context is
 *   lost the UI draws nothing, and on restore it does what Pixi's own handler
 *   would -- re-read the extensions, tell every system the context changed, so
 *   textures re-upload from their sources -- and lays every widget out again.
 *   Test it with `?debug`'s "lose context" button.
 */
// Before any renderer is made: Pixi's event system (the UI's buttons). The rest
// of what `pixi.js` would load for a browser -- accessibility's DOM shadow, the
// DOM container, filters, layout -- is left out (`skipExtensionImports`).
import 'pixi.js/events';
import { Container, Graphics, Ticker, WebGLRenderer } from 'pixi.js';
import type * as THREE from 'three';
import type { FrameRect } from '../frame.ts';
import { cancelPointer } from './button.ts';
import { sweepPictures } from './images.ts';
import { PointerRouter } from './input.ts';
import { loadFonts } from './text.ts';
import { insetsIn, measureUnits, readSafeArea, type Units } from './units.ts';
import { shown, type Widget } from './widget.ts';

/**
 * The layers, bottom to top.
 *
 *   hud      what is up during play
 *   menu     the menus: title, pause, results
 *   prompt   over the menus: a dialog, a confirmation
 */
export const LAYERS = ['hud', 'menu', 'prompt'] as const;
export type LayerName = (typeof LAYERS)[number];

/** What the canvas UI needs of the game: its renderer and its hooks. `Game` is one. */
export interface UiHost {
  readonly renderer: THREE.WebGLRenderer;
  /** Called with every frame on the canvas: the UI draws over it. */
  onDrawn: ((fresh: boolean) => void) | null;
  /** Asked by the game's pointer handlers whether an event is the UI's. */
  pointerClaim: ((e: PointerEvent) => boolean) | null;
  /** Is the game's own loop drawing frames? */
  readonly isRunning: boolean;
  /** The rect of the canvas the game is drawn in, CSS pixels from its top left (`Game.frame`): what the UI is laid out in. */
  readonly frame: Readonly<FrameRect>;
  /** The stopped world on the canvas again -- drawn, if there is no frame kept to show -- then `onDrawn`. */
  present(): void;
}

/**
 * Milliseconds after the last resize that the pictures nothing shows any more
 * are let go of (`sweepPictures`): time for the ones asked for then to have
 * decoded and gone up in place of the old.
 */
const SWEEP_AFTER = 1000;

/** A widget the UI holds, and the layer it is in. */
interface Held {
  widget: Widget;
  layer: LayerName;
}

export class CanvasUi {
  /** Pixi's renderer, on the game's context. */
  readonly pixi: WebGLRenderer;
  /** Everything drawn, in CSS pixels of the canvas. Its one child is `framed`, whose children are the layers. */
  readonly stage = new Container({ label: 'stage' });
  /**
   * The layers' parent, at the game's frame's corner and clipped to it while the frame is a part of the canvas: Pixi
   * draws the root it is given (`stage`) without its own transform or mask, so they go on this child.
   */
  private readonly framed = new Container({ label: 'frame' });
  /** The layers by name (`LAYERS`). */
  readonly layers: Record<LayerName, Container>;
  /** Who a pointer belongs to: the UI or the game. */
  readonly input: PointerRouter;

  private readonly widgets: Held[] = [];
  private readonly resizeListeners = new Set<(units: Units) => void>();
  private currentUnits: Units;
  /** The drawing buffer, window, pixel ratio and frame the layout was last made for. */
  private laidOut = { ...UNLAID };
  /** The stage's clip to the frame, its mask while the frame is not the whole canvas. */
  private readonly clip = new Graphics({ label: 'frame clip' });
  /** `performance.now()` of the last draw, for `frame`'s seconds and the stopped loop. */
  private lastDraw = 0;
  /** Did the last draw have anything to show? A stopped world is shown once more when that goes. */
  private drewContent = false;
  /** When the pictures nothing shows are next let go of; 0 for no sweep due. */
  private sweepAt = 0;
  /** Pixi's render of the stage, as it is always asked for: one object, not one a frame. */
  private readonly renderOptions: { container: Container; clear: boolean };
  /** The shared context, asked whether it is lost before any Pixi work. */
  private readonly gl: WebGL2RenderingContext;
  private readonly host: UiHost;

  private constructor(host: UiHost, pixi: WebGLRenderer) {
    this.host = host;
    this.pixi = pixi;
    this.gl = host.renderer.getContext() as WebGL2RenderingContext;
    this.renderOptions = { container: this.stage, clear: false };
    this.layers = Object.fromEntries(
      LAYERS.map((name) => {
        const layer = new Container({ label: name });
        this.framed.addChild(layer);
        return [name, layer];
      }),
    ) as Record<LayerName, Container>;
    const at = host.frame;
    this.currentUnits = measureUnits(at.width, at.height, insetsIn(readSafeArea(), at, innerWidth, innerHeight));

    const canvas = host.renderer.domElement;
    const events = pixi.events;
    // Pixi's events from the game's canvas, not the detached one it made for
    // itself; and nothing written to that canvas: no preventDefault on every
    // press (the game decides that for its own), and no cursor style over the
    // whole canvas (`input.ts` sets one only over the UI).
    events.setTargetElement(canvas);
    events.autoPreventDefault = false;
    events.cursorStyles.default = '';
    events.cursorStyles.pointer = '';
    this.stage.addChild(this.framed);
    this.input = new PointerRouter(canvas, events, this.stage, () => host.frame);
    host.pointerClaim = (e) => this.input.claims(e);

    // A pointer the browser took back lets go of any button it held: Pixi's
    // events never hear a `pointercancel` (`cancelPointer`).
    addEventListener('pointercancel', (e) => cancelPointer(e.pointerId), true);
    // The context given back: three has rebuilt its own state by now (its
    // listener was added first), and Pixi hears of it here, by its own handler
    // -- protected, because Pixi expects to own the canvas it listens on. The
    // next draw resizes Pixi and lays every widget out again.
    canvas.addEventListener('webglcontextrestored', () => {
      (pixi.context as unknown as { handleContextRestored(): void }).handleContextRestored();
      this.laidOut = { ...UNLAID };
    });

    host.onDrawn = () => this.draw();
    requestAnimationFrame(this.loop);
  }

  /**
   * The canvas UI, ready to draw: fonts loaded, Pixi made on the game's
   * context, hooked into the game's frames. Once, after the Game exists.
   */
  static async create(host: UiHost): Promise<CanvasUi> {
    await loadFonts();
    // No loop of Pixi's own: its housekeeping is stepped from `draw`.
    Ticker.system.autoStart = false;
    Ticker.system.stop();
    const renderer = host.renderer;
    const ratio = renderer.getPixelRatio();
    const canvas = renderer.domElement;
    const pixi = new WebGLRenderer();
    await pixi.init({
      context: renderer.getContext() as WebGL2RenderingContext,
      width: Math.max(1, canvas.width / ratio),
      height: Math.max(1, canvas.height / ratio),
      resolution: ratio,
      autoDensity: false,
      clearBeforeRender: false,
      backgroundAlpha: 0,
      skipExtensionImports: true,
      eventMode: 'passive',
      eventFeatures: { move: true, globalMove: false, click: true, wheel: true },
    });
    // Making Pixi bound and set things three believes it knows.
    renderer.resetState();
    return new CanvasUi(host, pixi);
  }

  /** The window's units now (`units.ts`): the game's frame's, where it has one. */
  get units(): Units {
    return this.currentUnits;
  }

  /** The game's canvas: what the UI draws into. */
  get canvas(): HTMLCanvasElement {
    return this.host.renderer.domElement;
  }

  /** The renderer's resolution: the game's pixel ratio. What `images.ts` rasterises at. */
  get resolution(): number {
    return this.pixi.resolution;
  }

  /**
   * Is the UI drawn at all? Off for clean footage -- trailers, thumbnails -- and
   * every pointer is then the game's: a hidden stage hit-tests as nothing.
   * Widgets keep their own state, so turning it back on shows what was up.
   */
  get visible(): boolean {
    return this.stage.visible;
  }

  set visible(on: boolean) {
    this.stage.visible = on;
  }

  /** Is anything in the menu or prompt layers up? */
  get menuUp(): boolean {
    return anyShown(this.layers.menu) || anyShown(this.layers.prompt);
  }

  /**
   * Put a widget in a layer: its view added, laid out and synced once. The
   * widget is returned, for `const score = ui.add(new ScoreBox(), 'hud')`.
   */
  add<W extends Widget>(widget: W, layer: LayerName): W {
    this.layers[layer].addChild(widget.view);
    this.widgets.push({ widget, layer });
    this.onPixiSide(() => widget.layout?.(this.currentUnits));
    widget.sync?.();
    return widget;
  }

  /** Take a widget out, and destroy it. */
  remove(widget: Widget): void {
    const i = this.widgets.findIndex((h) => h.widget === widget);
    if (i < 0) return;
    this.widgets.splice(i, 1);
    this.onPixiSide(() => {
      widget.destroy?.();
      widget.view.destroy({ children: true });
    });
  }

  /** A widget by its id, if it is here. */
  find(id: string): Widget | null {
    return this.widgets.find((h) => h.widget.id === id)?.widget ?? null;
  }

  /** Called after every resize, with the new units, after every widget's own `layout`. Returns the unsubscribe. */
  onResize(listener: (units: Units) => void): () => void {
    this.resizeListeners.add(listener);
    return () => this.resizeListeners.delete(listener);
  }

  /**
   * Draw the UI over whatever is on the canvas now. The game calls it
   * (`onDrawn`) with each frame it draws or presents; nothing else should.
   */
  private draw(): void {
    // Nothing of Pixi's on a lost context: the restore handler sets it up again.
    if (this.gl.isContextLost()) return;
    const now = performance.now();
    const dt = this.lastDraw > 0 ? Math.min(0.1, (now - this.lastDraw) / 1000) : 0;
    this.lastDraw = now;
    const resize = this.resizePending();
    this.sync();
    const content = this.hasContent();
    this.drewContent = content;
    const sweep = this.sweepAt > 0 && now >= this.sweepAt;
    if (sweep) this.sweepAt = 0;
    if (!content && !resize && !sweep) return;
    this.onPixiSide(() => {
      if (resize) this.fitToCanvas();
      if (sweep) sweepPictures(this.stage);
      if (!content) return;
      Ticker.system.update(now);
      for (const { widget } of this.widgets) {
        if (widget.frame && shown(widget.view)) widget.frame(dt, now);
      }
      this.pixi.render(this.renderOptions);
    });
  }

  /**
   * `work` -- anything of Pixi's -- with the context handed over to Pixi and
   * back (see the header). Not only the render: Pixi uploads a texture the
   * moment its source changes, so a widget's `layout` and `frame` run in here
   * too -- outside, an upload would meet whatever three's last draw left and
   * leave three's caches wrong for its next.
   */
  onPixiSide(work: () => void): void {
    const three = this.host.renderer;
    three.resetState();
    this.pixi.resetState();
    try {
      work();
    } finally {
      three.resetState();
    }
  }

  /**
   * The UI's own loop, for a stopped game: the stopped world shown again, and
   * the UI over it, once a displayed frame. Nothing while the game's loop is
   * drawing, and nothing when there is no UI to draw.
   *
   * It presents every frame while something is up. A UI that sits still for
   * long -- a menu with nothing moving -- can skip the frames where nothing
   * changed: CrabParty's `layer.ts` (`holdsStill`) hashes what the stage draws
   * and draws only when that moves.
   */
  private loop = (frameTime: number): void => {
    requestAnimationFrame(this.loop);
    // The game's loop draws the UI itself; and a frame already drawn this
    // animation frame -- a resize, a `renderOnce` -- is not drawn twice.
    if (this.host.isRunning || this.lastDraw >= frameTime || this.gl.isContextLost()) return;
    this.sync();
    // Nothing up, and nothing was: the canvas keeps what it last showed. Once
    // the last thing goes, one more present shows the world bare.
    if (!this.hasContent() && !this.drewContent) return;
    this.host.present();
  };

  /** Every widget that follows state no event announces, shown or hidden to match it (`Widget.sync`). */
  private sync(): void {
    for (const { widget } of this.widgets) widget.sync?.();
  }

  /** Is anything in the UI shown? */
  private hasContent(): boolean {
    if (!this.stage.visible) return false;
    for (const name of LAYERS) {
      const layer = this.layers[name];
      if (layer.visible && anyShown(layer)) return true;
    }
    return false;
  }

  /**
   * Pixi at the canvas's size, the stage at the frame's corner and clipped to it, and every widget laid out
   * for the frame's size, if any of them changed since the last draw. Checked at every draw rather than on
   * `resize`, so a frame drawn in a resize's wake is never drawn at the old size.
   */
  private fitToCanvas(): void {
    const canvas = this.host.renderer.domElement;
    const ratio = this.host.renderer.getPixelRatio();
    const at = this.host.frame;
    const was = this.laidOut;
    this.laidOut = { w: canvas.width, h: canvas.height, iw: innerWidth, ih: innerHeight, ratio, fx: at.x, fy: at.y, fw: at.width, fh: at.height };
    if (canvas.width !== was.w || canvas.height !== was.h || ratio !== was.ratio) {
      this.pixi.resize(Math.max(1, canvas.width / ratio), Math.max(1, canvas.height / ratio), ratio);
    }
    const cssW = canvas.width / ratio;
    const cssH = canvas.height / ratio;
    this.framed.position.set(at.x, at.y);
    // Clipped only while the frame is a part of the canvas: the whole of it needs no mask, and draws as it always did.
    const part = at.x > 0 || at.y > 0 || at.width < Math.floor(cssW) || at.height < Math.floor(cssH);
    if (part) {
      if (this.clip.parent !== this.framed) this.framed.addChild(this.clip);
      this.clip.clear().rect(0, 0, at.width, at.height).fill(0xffffff);
      this.framed.mask = this.clip;
    } else if (this.framed.mask !== null) {
      this.framed.mask = null;
      this.framed.removeChild(this.clip);
    }
    this.currentUnits = measureUnits(at.width, at.height, insetsIn(readSafeArea(), at, cssW, cssH));
    // The pictures the last sizes were baked at, let go of once nothing shows
    // them: every widget is about to ask for its icons at the new size.
    sweepPictures(this.stage);
    this.sweepAt = performance.now() + SWEEP_AFTER;
    for (const { widget } of this.widgets) widget.layout?.(this.currentUnits);
    for (const listener of this.resizeListeners) listener(this.currentUnits);
  }

  /** Has the canvas, the window, the pixel ratio or the frame changed since the layout was made? */
  private resizePending(): boolean {
    const canvas = this.host.renderer.domElement;
    const was = this.laidOut;
    const at = this.host.frame;
    return (
      canvas.width !== was.w || canvas.height !== was.h || innerWidth !== was.iw || innerHeight !== was.ih || this.host.renderer.getPixelRatio() !== was.ratio ||
      at.x !== was.fx || at.y !== was.fy || at.width !== was.fw || at.height !== was.fh
    );
  }
}

/** A layout made for nothing: the next draw lays out. */
const UNLAID = { w: 0, h: 0, iw: 0, ih: 0, ratio: 0, fx: 0, fy: 0, fw: 0, fh: 0 };

/** Is any view in this layer shown? */
function anyShown(layer: Container): boolean {
  for (const view of layer.children) if (view.visible) return true;
  return false;
}
