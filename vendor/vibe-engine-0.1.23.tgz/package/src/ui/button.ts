/**
 * A button in the canvas: any container made pressable by a tap or a click.
 *
 * What it is is the widget's business: a `Pressable` only tracks the states a
 * `<button>` had -- hovered, held down, disabled -- and tells the widget when
 * one changes (`onState`), so the widget redraws its look for that state. No
 * look of its own, so a pill, a card and an icon can all be one (`pill.ts` is
 * the stock look).
 *
 * ## Pointer
 *
 *   The view gets `eventMode: 'static'` and `cursor: 'pointer'`, so it is hit
 *   by Pixi's events and claimed from the game (`input.ts`): a press on it is
 *   never also a drag of the world. A click presses it -- down and up on it,
 *   Pixi's `pointertap`. Pressed synchronously inside the browser's own event,
 *   so what it does counts as a user gesture (`Audio.unlock`, a rewarded ad).
 *
 *   **A finger presses it by a tap**: down and up without wandering past
 *   `SLOP`. A finger that slides further -- a thumb dragged off to take it back,
 *   a scroll that started on it -- presses nothing and lets the button up. A
 *   touch the system takes back (an edge swipe, a call) lets it up too: Pixi's
 *   events have no `pointercancel`, so the canvas UI hands it on
 *   (`cancelPointer`).
 *
 * ## Keys and pads
 *
 *   Not here yet. A game with menus driven by keys or a pad adds a selection
 *   that `Pressable`s register with -- CrabParty's `src/ui/canvas/focus.ts` is
 *   the worked version, with Tab order, arrow stepping and focus rings.
 */
import type { Container, FederatedPointerEvent } from 'pixi.js';

/** How far a finger may wander, CSS pixels, and still be a tap. */
export const SLOP = 12;

/** The states a `<button>` could be in: what its look is drawn for. */
export interface ButtonState {
  /** A mouse is over it. */
  hover: boolean;
  /** Held down by a pointer that went down on it. */
  down: boolean;
  /** It cannot be pressed now. */
  disabled: boolean;
}

export interface PressableOptions {
  /** Its name, for tests. */
  id: string;
  /** What pressing it does. */
  onPress: () => void;
  /** A state changed: draw it. Called once at the start. */
  onState?: (state: Readonly<ButtonState>) => void;
}

/** A pointer that went down on a button: which, where (CSS pixels), a finger or not, and whether its release would still be a tap. */
interface Hold {
  id: number;
  x: number;
  y: number;
  finger: boolean;
  tap: boolean;
}

/** Every button a pointer is holding down now: what a cancel lets go of. */
const held = new Set<Pressable>();

/**
 * The browser took a pointer back (`pointercancel`): every button it was
 * holding lets go, pressed by nothing. The canvas UI calls it from its own
 * listener.
 */
export function cancelPointer(pointerId: number): void {
  for (const button of held) button.letGo(pointerId);
}

export class Pressable {
  readonly id: string;
  private readonly state: ButtonState = { hover: false, down: false, disabled: false };
  /** The pointer that went down on it last, until its tap is heard or another goes down. */
  private hold: Hold | null = null;
  readonly view: Container;
  private readonly options: PressableOptions;

  constructor(view: Container, options: PressableOptions) {
    this.view = view;
    this.options = options;
    this.id = options.id;
    view.eventMode = 'static';
    view.cursor = 'pointer';
    view.on('pointerover', () => this.set({ hover: true }));
    view.on('pointerout', (e: FederatedPointerEvent) => {
      this.set({ hover: false });
      this.wandered(e);
    });
    view.on('pointerdown', (e: FederatedPointerEvent) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (this.state.disabled) return;
      this.hold = { id: e.pointerId, x: e.global.x, y: e.global.y, finger: e.pointerType !== 'mouse', tap: true };
      held.add(this);
      this.set({ down: true });
    });
    view.on('pointermove', (e: FederatedPointerEvent) => this.wandered(e));
    // Up, but `hold` kept: Pixi's tap for the same release comes after.
    const up = (): void => {
      held.delete(this);
      this.set({ down: false });
    };
    view.on('pointerup', up);
    view.on('pointerupoutside', up);
    view.on('pointertap', (e: FederatedPointerEvent) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      const hold = this.hold;
      this.hold = null;
      // A finger that wandered is a slide, not a tap.
      if (hold && hold.id === e.pointerId && !hold.tap) return;
      if (this.state.disabled) return;
      this.options.onPress();
    });
    view.once('destroyed', () => held.delete(this));
    options.onState?.(this.state);
  }

  /** Whether it can be pressed. A disabled button ignores presses; how it looks is the widget's (`onState`). */
  get disabled(): boolean {
    return this.state.disabled;
  }

  set disabled(on: boolean) {
    this.set({ disabled: on, down: on ? false : this.state.down });
    // Still hit while disabled: it sits over the world, and a tap on it must
    // not reach the game. Only the pointer's look says it cannot be pressed.
    this.view.cursor = on ? 'default' : 'pointer';
  }

  /** The states it is in now. */
  get states(): Readonly<ButtonState> {
    return this.state;
  }

  /** Press it from code: a key bound to it, a test. */
  press(): void {
    if (!this.state.disabled) this.options.onPress();
  }

  /** A pointer the browser took back (`cancelPointer`): up, pressed by nothing. */
  letGo(pointerId: number): void {
    const hold = this.hold;
    if (!hold || hold.id !== pointerId) return;
    this.hold = null;
    held.delete(this);
    this.set({ down: false, hover: hold.finger ? false : this.state.hover });
  }

  /** A finger past `SLOP` from where it went down is no longer a tap, and lets the button up. A mouse is left alone. */
  private wandered(e: FederatedPointerEvent): void {
    const hold = this.hold;
    if (!hold?.finger || !hold.tap || hold.id !== e.pointerId) return;
    if (Math.hypot(e.global.x - hold.x, e.global.y - hold.y) <= SLOP) return;
    hold.tap = false;
    held.delete(this);
    this.set({ down: false });
  }

  private set(changes: Partial<ButtonState>): void {
    let changed = false;
    for (const key of Object.keys(changes) as (keyof ButtonState)[]) {
      if (this.state[key] !== changes[key]) {
        this.state[key] = changes[key]!;
        changed = true;
      }
    }
    if (changed) this.options.onState?.(this.state);
  }
}
