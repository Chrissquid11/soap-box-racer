/**
 * The shape of a canvas widget: one piece of HUD or one menu, drawn by Pixi in
 * the game's canvas. What `CanvasUi.add` takes.
 *
 * ## The lifecycle
 *
 *   1. **Made** by its module (`new ScoreBox()`), then handed to the UI with
 *      `ui.add(widget, 'hud')`, which puts `view` in that layer and calls
 *      `layout` once.
 *   2. **Told** what to show by the page (`boot`, the project's hooks), through its own methods --
 *      `score.set(v)` -- which change what is drawn only when something
 *      differs. That is where state changes: on change, not every frame.
 *   3. **Laid out** again (`layout`) after every resize, from the new units: a
 *      size is `n * units.u` (HUD) or `n * units.m` (menus), never a bare pixel.
 *   4. **Animated** (`frame`) once a displayed frame, in real seconds, only
 *      while it is shown -- and the world may be stopped under it.
 *   5. **Shown and hidden** with `view.visible`; **removed** with `ui.remove`,
 *      which destroys it. A widget whose showing follows state no event
 *      announces reads that state itself, in `sync`, asked before every draw.
 *
 * Everything a widget does to its Pixi objects -- `layout`, `frame` -- runs with
 * the GL context handed over to Pixi (`CanvasUi.onPixiSide`): Pixi uploads a
 * texture the moment it changes, not when it next draws. A widget changed from
 * outside those (an event handler setting a label) is fine too: the upload is
 * then deferred to the next draw.
 */
import type { Container } from 'pixi.js';
import type { Units } from './units.ts';

/** A rectangle, CSS pixels. */
export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Widget {
  /** Its name, for tests and `CanvasUi.find`. */
  readonly id: string;
  /** Everything it draws. Hidden is `view.visible = false`. */
  readonly view: Container;
  /** Size and place everything from the units: when added, and after every resize. */
  layout?(units: Units): void;
  /**
   * Before every draw, shown or not: show or hide the view from state no event
   * announces. A predicate or two, no drawing -- it runs every frame.
   */
  sync?(): void;
  /** A displayed frame while shown: `dt` real seconds since the last. Animation only. */
  frame?(dt: number, now: number): void;
  /** Free what it made beyond `view` -- textures it owns, listeners. `view` is destroyed for it. */
  destroy?(): void;
}

/**
 * Is `view` drawn at all: it and every container above it visible? The
 * canvas's version of "no `hidden` ancestor". A few parent hops -- the UI is
 * shallow -- so cheap enough for a key press, not for a hot loop over hundreds.
 */
export function shown(view: Container): boolean {
  for (let node: Container | null = view; node; node = node.parent) {
    if (!node.visible || !node.renderable) return false;
  }
  return true;
}

/** A container's bounds on screen as a `Rect`, CSS pixels (the stage's own). */
export function boundsOf(view: Container): Rect {
  const b = view.getBounds();
  return { x: b.x, y: b.y, width: b.width, height: b.height };
}
