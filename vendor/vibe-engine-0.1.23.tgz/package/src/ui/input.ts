/**
 * Who a pointer belongs to: the canvas UI or the game.
 *
 * ## One canvas, two listeners, an explicit order
 *
 *   The UI and the world share `#game`, and both listen to it: Pixi's event
 *   system, which delivers presses to the UI's buttons, and the Game's own
 *   handlers (`bindInput`). **The Game asks first**: each of its pointer
 *   handlers calls `Game.pointerClaim`, which the canvas UI points at `claims`
 *   here, and does nothing with an event the UI claims. The answer comes from a
 *   hit test, made when it is asked -- not from whichever listener happened to
 *   run first -- so the order is written down, not an accident of registration.
 *
 * ## The rules
 *
 *   - **A press belongs to what it lands on.** Down on something interactive
 *     in the UI -- a button, a menu's veil (a full-screen shield with
 *     `eventMode: 'static'`) -- and it is the UI's; anywhere else it is the
 *     game's.
 *   - **Until it is released.** Every move and the release of that pointer go
 *     to whoever took the press: a drag that starts on the world and crosses a
 *     button stays a drag, and a press on a button that slides off onto the
 *     world does not become a drag.
 *   - **A hovering mouse** belongs to whatever is under it. Over a button the
 *     game sees the pointer as gone.
 *
 * ## The pointer's look
 *
 *   Pixi would write `canvas.style.cursor` itself, over the whole canvas.
 *   `CanvasUi` turns that off; `cursor` here says what the thing under the
 *   mouse asks for (`'pointer'` over a button), set only while over the UI.
 */
import { Point, type Container, type EventSystem } from 'pixi.js';
import type { FrameRect } from '../frame.ts';

export class PointerRouter {
  /** Pointers pressed on the UI (true) or the game (false), until released. */
  private readonly owner = new Map<number, boolean>();
  /** Each event's answer, so the Game's handlers and the UI's agree however often they ask. */
  private readonly answered = new WeakMap<Event, boolean>();
  /** What each event landed on, hit-tested once. */
  private readonly landed = new WeakMap<Event, Container | null>();
  private readonly point = new Point();
  /** What the mouse is over, if it is part of the UI; null over the world. */
  private over: Container | null = null;
  private readonly canvas: HTMLCanvasElement;
  private readonly events: EventSystem;
  private readonly stage: Container;
  /** The game's frame now: the UI is in it, and a pointer outside it is never the UI's. */
  private readonly frame: () => Readonly<FrameRect>;

  constructor(canvas: HTMLCanvasElement, events: EventSystem, stage: Container, frame: () => Readonly<FrameRect>) {
    this.canvas = canvas;
    this.events = events;
    this.stage = stage;
    this.frame = frame;
    // Our own record of every press and release on the canvas, made as the
    // event passes the window on its way down -- before any listener on the
    // canvas runs, though no answer depends on that.
    const note = (e: PointerEvent): void => {
      if (e.target === canvas) this.claims(e);
      else if (e.type !== 'pointerdown') this.owner.delete(e.pointerId);
    };
    addEventListener('pointerdown', note, true);
    addEventListener('pointerup', note, true);
    addEventListener('pointercancel', note, true);
    addEventListener(
      'pointermove',
      (e) => {
        // Pixi dispatches moves of its own on the document, to refresh hover
        // under a still pointer: they are not a pointer leaving the canvas.
        if (!e.isTrusted) return;
        if (e.target === canvas) this.claims(e);
        else this.setOver(null);
      },
      { capture: true, passive: true },
    );
    canvas.addEventListener('pointerleave', () => this.setOver(null));
  }

  /**
   * Is this pointer event the UI's? Asked by the Game before it acts on one
   * (`Game.pointerClaim`). The same event always gets the same answer.
   */
  claims(e: PointerEvent): boolean {
    const known = this.answered.get(e);
    if (known !== undefined) return known;
    let mine: boolean;
    switch (e.type) {
      case 'pointerdown':
        mine = this.target(e) !== null;
        this.owner.set(e.pointerId, mine);
        break;
      case 'pointerup':
      case 'pointercancel':
        mine = this.owner.get(e.pointerId) ?? this.hit(e) !== null;
        this.owner.delete(e.pointerId);
        break;
      default: {
        const pressed = this.owner.get(e.pointerId);
        if (pressed !== undefined) mine = pressed;
        else {
          const target = this.hit(e);
          if (e.pointerType === 'mouse') this.setOver(target);
          mine = target !== null;
        }
      }
    }
    this.answered.set(e, mine);
    return mine;
  }

  /** The topmost interactive thing in the UI under this event -- a button, a menu's veil -- or null over the world. The same event always gets the same answer. */
  target(e: PointerEvent): Container | null {
    if (this.landed.has(e)) return this.landed.get(e)!;
    const hit = this.hit(e);
    this.landed.set(e, hit);
    return hit;
  }

  /** Is the mouse over something of the UI's -- a button -- rather than the world? */
  get hovering(): boolean {
    return this.over !== null;
  }

  /** The CSS cursor what is under the mouse asks for (`'pointer'`), or '' for none. */
  get cursor(): string {
    let node: Container | null = this.over;
    while (node) {
      if (node.cursor) return node.cursor;
      node = node.parent;
    }
    return '';
  }

  /** The topmost interactive thing in the UI under this event, or null -- null outside the game's frame. */
  private hit(e: PointerEvent): Container | null {
    const boundary = this.events.rootBoundary;
    this.events.mapPositionToPoint(this.point, e.clientX, e.clientY);
    const at = this.frame();
    const x = this.point.x - at.x;
    const y = this.point.y - at.y;
    if (x < 0 || y < 0 || x >= at.width || y >= at.height) return null;
    boundary.rootTarget = this.stage;
    // Typed as always finding something; it finds null over nothing interactive.
    return (boundary.hitTest(this.point.x, this.point.y) as Container | null) ?? null;
  }

  private setOver(target: Container | null): void {
    if (target === this.over) return;
    this.over = target;
    // The native pointer's look, set on the canvas only while over the UI:
    // cleared, the stylesheet's own rule is back in charge.
    this.canvas.style.cursor = target ? this.cursor || 'default' : '';
  }
}
