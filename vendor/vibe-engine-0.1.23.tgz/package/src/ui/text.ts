/**
 * Text in the canvas UI: two faces, sized in units and crisp at the pixel ratio.
 *
 * ## One way to make text: `Label`
 *
 *   A `Label` is a Pixi `Text` that knows its `Look` -- size, face, colour,
 *   caps, tracking, outline, shadow, wrap -- and is drawn again only when
 *   something differs: a `Text` redraws a canvas and uploads a texture each
 *   time its text or style changes, so `set` and `restyle` touch them only on a
 *   change. A number that changes every frame is still a redraw a frame --
 *   count it up at most once a frame, and only while it moves.
 *
 *   Crisp: the renderer's resolution is the game's pixel ratio, and a `Text`
 *   rasterises at it. A size that changes with a resize is a new `restyle`,
 *   not a scale.
 *
 * ## Fonts before anything measures
 *
 *   Pixi caches a font's measurements the first time it meets it, and a
 *   measurement taken before the font loaded is of the fallback, for good.
 *   `loadFonts` loads the display face from its hashed URL (`Assets.fontUrl`)
 *   before the canvas UI makes anything, and drops whatever was measured before.
 *
 * ## Outlines and shadows
 *
 *   An outline is a stroke twice `outline` wide, round-joined, half of it under
 *   the fill: a ring of `outline` pixels outside the glyphs. The drop under it
 *   is the canvas's own shadow, baked into the text's texture -- no filter,
 *   nothing per frame. Both in CSS pixels, not units.
 *
 *   A Pixi `Text` is as big as its ink, outline included. A `Label` puts its
 *   origin back where a CSS box's would be -- `pivot` set in by the outline --
 *   so `label.x = 28 * u` puts the glyphs at 28u, and `lineBox` is the box's size.
 *
 * ## Tagged runs
 *
 *   `look.tags` styles `<name>...</name>` runs inside one `Label` (Pixi's
 *   `tagStyles`): `label.set(\`Best: <num>${best}</num>\`)` with
 *   `tags: { num: { fill: COLOUR.accent } }`.
 *
 * A game in more than one language wants more here -- per-script fonts, caps in
 * the language's rules, line breaking for scripts without spaces. CrabParty's
 * `src/ui/canvas/text.ts` is that version.
 */
import { CanvasTextMetrics, Text, TextStyle, type FillInput, type TextStyleOptions } from 'pixi.js';
import { Assets } from '../assets/index.ts';
import { COLOUR, SHADOW } from './theme.ts';

/** The display face (titles, the HUD) or the plainer UI face (body text). */
export type Face = 'display' | 'ui';

/** The font stacks, first choice first. The display face is loaded by `loadFonts`. */
const FAMILIES: Record<Face, string[]> = {
  display: ['Fredoka', 'Trebuchet MS', 'Segoe UI', 'sans-serif'],
  ui: ['Trebuchet MS', 'Segoe UI', 'Roboto', 'sans-serif'],
};

/** How a piece of text looks. Sizes in CSS pixels: a widget multiplies its units in. */
export interface Look {
  /** The font's size, CSS pixels -- `34 * u`, say. */
  size: number;
  /** Default: display. */
  face?: Face;
  /** Default: 700. The display face ships only its bold. */
  weight?: 400 | 700;
  /** Any Pixi fill: a CSS colour from `COLOUR`, a gradient. Default: white. */
  fill?: FillInput;
  /** Uppercase, as `text-transform: uppercase` did. */
  caps?: boolean;
  /** Letter-spacing, in em (`0.08`). */
  tracking?: number;
  /** A dark outline: how far it reaches outside the glyphs, CSS pixels. */
  outline?: number;
  /** The outline's colour. Default: `COLOUR.outline`. */
  outlineColour?: string;
  /** A shadow under it all: one of `SHADOW`'s, or one of its own. */
  shadow?: keyof typeof SHADOW | Drop;
  /** Wrap at this width, CSS pixels. */
  wrap?: number;
  /** How wrapped lines line up. */
  align?: 'left' | 'center' | 'right';
  /** Line height, as a multiple of the size. Default: 1.2. */
  lineHeight?: number;
  /** Styles for `<name>...</name>` runs inside the text. */
  tags?: Record<string, TextStyleOptions>;
}

/** A text-shadow, CSS pixels: `0 <distance> <blur>` in black at `alpha`, or in `colour`. */
export interface Drop {
  distance: number;
  blur: number;
  alpha: number;
  colour?: string;
}

function dropOf(shadow: Look['shadow']): Drop | null {
  if (shadow === undefined) return null;
  return typeof shadow === 'string' ? SHADOW[shadow] : shadow;
}

function sameDrop(a: Look['shadow'], b: Look['shadow']): boolean {
  if (a === b) return true;
  if (typeof a !== 'object' || typeof b !== 'object') return false;
  return a.distance === b.distance && a.blur === b.blur && a.alpha === b.alpha && a.colour === b.colour;
}

// ── fonts ───────────────────────────────────────────────────────────────

let fontsLoaded: Promise<void> | null = null;

/**
 * The display face, loaded and ready to measure: awaited once, before the
 * canvas UI makes its first `Label`. Call it early -- beside the preload -- so
 * the download hides inside the loading bar. A font that fails to load is
 * reported and the fallback used: a UI in Trebuchet beats no UI.
 */
export function loadFonts(): Promise<void> {
  fontsLoaded ??= (async () => {
    try {
      const face = new FontFace('Fredoka', `url(${Assets.fontUrl('fredoka-700')}) format('woff2')`, { weight: '700', display: 'swap' });
      document.fonts.add(face);
      await face.load();
    } catch (err) {
      console.warn('[ui] the display font did not load; the UI face stands in', err);
    }
    // Anything measured before the face was here was measured in the fallback.
    CanvasTextMetrics.clearMetrics();
  })();
  return fontsLoaded;
}

// ── styles ──────────────────────────────────────────────────────────────

/** The Pixi style a look comes to. */
export function styleOf(look: Look): TextStyleOptions {
  const outline = look.outline ?? 0;
  const shadow = dropOf(look.shadow);
  const style: TextStyleOptions = {
    fontFamily: FAMILIES[look.face ?? 'display'],
    fontSize: look.size,
    fontWeight: `${look.weight ?? 700}` as const,
    fill: look.fill ?? COLOUR.text,
    letterSpacing: (look.tracking ?? 0) * look.size,
    align: look.align ?? 'left',
    lineHeight: (look.lineHeight ?? 1.2) * look.size,
    // The blur spreads past the ink the text is measured by: room for it.
    padding: shadow ? Math.ceil(shadow.blur) : 0,
  };
  if (outline > 0) style.stroke = { color: look.outlineColour ?? COLOUR.outline, width: outline * 2, join: 'round' };
  if (shadow) style.dropShadow = { color: shadow.colour ?? '#000000', alpha: shadow.alpha, blur: shadow.blur, distance: shadow.distance, angle: Math.PI / 2 };
  if (look.tags) style.tagStyles = look.tags;
  if (look.wrap !== undefined) {
    style.wordWrap = true;
    style.wordWrapWidth = look.wrap;
    // A word longer than a line breaks rather than running off the screen.
    style.breakWords = true;
  }
  return style;
}

function sameLook(a: Look, b: Look): boolean {
  return (
    a.size === b.size &&
    a.face === b.face &&
    a.weight === b.weight &&
    a.fill === b.fill &&
    a.caps === b.caps &&
    a.tracking === b.tracking &&
    a.outline === b.outline &&
    a.outlineColour === b.outlineColour &&
    sameDrop(a.shadow, b.shadow) &&
    a.wrap === b.wrap &&
    a.align === b.align &&
    a.lineHeight === b.lineHeight &&
    a.tags === b.tags
  );
}

// ── Label ───────────────────────────────────────────────────────────────

/**
 * Text with a `Look`: the one way the canvas UI makes text. See the header.
 *
 * ```ts
 * const title = new Label({ size: 18 * u, caps: true, tracking: 0.08, outline: 2, shadow: 'hud' });
 * title.set('Score');              // when it changes
 * title.restyle({ size: 18 * u }); // in layout(), after a resize
 * ```
 */
export class Label extends Text {
  private shownLook: Look;
  /** The words as given, before caps. */
  private words = '';

  constructor(look: Look, words = '') {
    super({ text: '', style: styleOf(look) });
    this.shownLook = { ...look };
    this.placeOrigin();
    this.set(words);
  }

  /** The look it is drawn in. */
  get look(): Readonly<Look> {
    return this.shownLook;
  }

  /** New words, uppercased if the look says. Drawn again only if what shows would change. */
  set(words: string | number): this {
    this.words = String(words);
    this.show();
    return this;
  }

  /** A changed look -- a new size after a resize, a new colour for a state -- merged over the current one. */
  restyle(changes: Partial<Look>): this {
    const next = { ...this.shownLook, ...changes };
    if (sameLook(next, this.shownLook)) return this;
    this.shownLook = next;
    this.style = new TextStyle(styleOf(next));
    this.placeOrigin();
    this.show();
    return this;
  }

  /**
   * The size of the box the words take, without the outline and shadow a Pixi
   * `Text` counts in: its lines at its line height, as wide as its widest.
   */
  get lineBox(): { width: number; height: number } {
    if (this.text === '') return { width: 0, height: 0 };
    const outline = this.shownLook.outline ?? 0;
    const shadow = dropOf(this.shownLook.shadow)?.distance ?? 0;
    const lines = CanvasTextMetrics.measureText(this.text, this.style).lines.length;
    return { width: Math.max(0, this.width - outline * 2 - shadow), height: lines * this.style.lineHeight };
  }

  /** The origin back where a CSS box's would be: in by the outline, which a Pixi `Text` counts in its size. */
  private placeOrigin(): void {
    const outline = this.shownLook.outline ?? 0;
    this.pivot.set(outline, outline);
  }

  private show(): void {
    // Caps on the words only, never on a tag's name: `<num>` must stay `<num>`.
    const shown = this.shownLook.caps ? this.words.replace(/(<[^>]*>)|([^<]+)/g, (_, tag?: string, words?: string) => tag ?? words!.toLocaleUpperCase()) : this.words;
    if (this.text !== shown) this.text = shown;
  }
}
