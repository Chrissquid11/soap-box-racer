/**
 * `@vibe/engine/ui`: the canvas UI -- Pixi drawing the HUD and the menus into the game's own WebGL2
 * context (`layer.ts` says how) -- and what a project's widgets are made with. A subpath, never the
 * index: it loads pixi as it loads, and `text.ts` reads the fonts from the asset runtime
 * (`@vibe/engine/assets`), so no node test imports it but as types (`imports.test.ts` holds it).
 * What is here is what a project's widgets and its page use; the rest stays the files' own.
 */
// The layer: one per page, on the game's context, the widgets in its layers.
export { CanvasUi, LAYERS, type LayerName, type UiHost } from './layer.ts';
// A widget's contract.
export type { Widget } from './widget.ts';
// The units every size is in (CLAUDE.md: never bare pixels).
export { menu, type Units } from './units.ts';
// The palette and the sizes: a widget's colours and sizes, never a literal of its own.
export { ALPHA, COLOUR, ICON_SHADOW, SIZE_M, SIZE_U } from './theme.ts';
// Text: a label, its look, and the fonts loaded before a word is measured.
export { Label, loadFonts, styleOf, type Look } from './text.ts';
// Pictures: an icon rasterised at its on-screen size and tinted.
export { bakedMargin, icon } from './images.ts';
// Buttons: the pressable every button is, and the stock menu pill.
export { Pressable, type ButtonState } from './button.ts';
export { PillButton } from './pill.ts';
