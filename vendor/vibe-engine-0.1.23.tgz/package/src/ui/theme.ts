/**
 * The canvas UI's palette and sizes. **The one source for the canvas UI** -- a
 * widget reads its colours and sizes here, never a hex literal of its own, so a
 * colour is changed once.
 *
 * Colours are CSS strings: Pixi reads any CSS colour (`fill: COLOUR.veil`).
 * Sizes are in units -- `SIZE_U` in `u`, `SIZE_M` in `m` (`units.ts`) -- and
 * multiplied by the unit where they are used: `SIZE_U.inset * units.u`.
 *
 * As a game grows, give each package of widgets its own group under its name,
 * so two people working on two screens never add lines at the same place.
 */

export const COLOUR = {
  // Brand
  ink: '#10182a',
  veil: 'rgba(8, 14, 28, 0.72)',
  panel: '#1b2740',
  panelEdge: 'rgba(0, 0, 0, 0.45)',
  accent: '#ffb300',
  accentDark: '#c98b00',
  go: '#4fc23a',
  goDark: '#2f8a26',
  text: '#fff',
  textDim: 'rgba(255, 255, 255, 0.8)',
  outline: '#13202c',
  /** A selected or focused button's ring. */
  ring: '#fff',
  /** A button that cannot be pressed now. */
  off: '#6b7280',
  /** The sound button's slash. */
  soundOff: '#ff3b30',
  /** What an icon is painted before its tint: white, so a tint is its colour. */
  icon: '#fff',
  /** Over a pill button the pointer is on. */
  hoverWash: 'rgba(255, 255, 255, 0.15)',
} as const;

/** How opaque a piece is, 0..1. */
export const ALPHA = {
  /** A HUD icon button's round plate, at rest and with the pointer on it. */
  plate: 0.35,
  plateHover: 0.6,
  /** An icon held down. */
  held: 0.7,
} as const;

export type ColourName = keyof typeof COLOUR;

/** The HUD's sizes, in `u`. */
export const SIZE_U = {
  /** Between the screen's edges and every HUD piece in a corner or along an edge. */
  inset: 18,
  /** The HUD's body text. */
  hud: 26,
  /** A round icon button (sound, pause). */
  button: 46,
  /** Between two HUD buttons side by side. */
  gap: 10,
  /** The hint under the title: its words, and the space between them. */
  hint: 14,
  hintGap: 2,
  /** The HUD title's outline. */
  outline: 3,
} as const;

/** The menus' sizes, in `m`. */
export const SIZE_M = {
  body: 18,
  title: 44,
  gap: 16,
  padScreen: 24,
  /** A pill button's height and its words. */
  button: 56,
  buttonText: 22,
  /** How far a button sinks when held. */
  press: 4,
  /** A selected button's ring: width and gap. */
  ring: 3,
  ringGap: 3,
  /** A pill button's words' outline. */
  buttonOutline: 2,
  /** A menu title's outline, and how far it rises and falls as it breathes. */
  titleOutline: 3,
  titleBob: 3,
  /** A menu panel: its width (`menu()`: at least, its share of the window's width in %, at most), its corners, the edge under it. */
  panelMin: 260,
  panelVw: 60,
  panelMax: 420,
  panelRadius: 20,
  panelDrop: 6,
} as const;

/** Text shadows, in CSS pixels, black unless a `colour` says. */
export const SHADOW = {
  /** A soft drop under body text: `0 2px 6px rgba(0,0,0,.6)`. */
  soft: { distance: 2, blur: 6, alpha: 0.6 },
  /** Under outlined HUD words: `0 4px 8px rgba(0,0,0,.45)`. */
  hud: { distance: 4, blur: 8, alpha: 0.45 },
  /** A hard drop in the outline's colour, for titles. */
  hard: { distance: 3, blur: 0, alpha: 1, colour: COLOUR.outline },
} as const;

/** The shadow baked under a HUD icon (`icon()`'s `shadow`), CSS pixels: `drop-shadow(0 2px 2px rgba(0,0,0,.45))`. */
export const ICON_SHADOW = { y: 2, blur: 2, alpha: 0.45 } as const;
