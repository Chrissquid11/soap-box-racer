---
skill: engine
title: The canvas UI
when: Before making or changing the HUD, a menu or any widget under src/ui/ -- the one canvas, units, the theme, buttons, text, icons
covers:
  modules: [ui/]
order: 70
---
# The canvas UI: the HUD and the menus, on the one canvas

Everything a player reads is drawn into the game's own canvas: the HUD and every menu are **Pixi widgets**
drawn into three's WebGL2 context after the world, every frame -- so a recorder filming the canvas sees it all,
and the page holds only the canvas and the loading bar. No HTML UI. The code is
`node_modules/@vibe/engine/src/ui/` (`@vibe/engine/ui`): `layer.ts` the layer, `widget.ts` the contract,
`theme.ts` the palette and sizes, `text.ts` labels, `button.ts` and `pill.ts` buttons, `images.ts` icons. The
template's `src/ui/hud.ts` and `pause-menu.ts` are whole examples to copy.

## A widget

```ts
import { Container } from 'pixi.js';
import { COLOUR, Label, SIZE_U, type Units, type Widget } from '@vibe/engine/ui';

/** The score, top left. Told what to show through `set`, which draws again only on a change. */
export class ScoreBox implements Widget {
  readonly id = 'score';
  readonly view = new Container({ label: 'score' });
  private readonly words = new Label({ size: SIZE_U.hud, fill: COLOUR.text, outline: SIZE_U.outline, shadow: 'hud' }, '0');

  constructor() {
    this.view.addChild(this.words);
  }

  set(score: number): void {
    this.words.set(score);
  }

  layout(units: Units): void {
    const { u, safe } = units;
    this.words.restyle({ size: SIZE_U.hud * u, outline: SIZE_U.outline * u });
    this.words.position.set(Math.max(SIZE_U.inset * u, safe.left), Math.max(SIZE_U.inset * u, safe.top));
  }
}
```

and in `main.ts`'s `ui` hook, `ui.add(new ScoreBox(), 'hud')` -- which answers the widget, to keep and tell.

The lifecycle: **made**, then `ui.add(widget, layer)` puts its `view` in the layer and calls `layout`; **told**
what to show through its own methods, on change, never every frame; **laid out** again after every resize;
**animated** in `frame(dt)` (real seconds, only while shown, even with the game paused under it); shown and
hidden with `view.visible`; `sync()` (before every draw) for showing or hiding from state no event announces;
`ui.remove(widget)` destroys it. The layers, bottom to top: `hud`, `menu`, `prompt`.

`boot()` hands the `ui` hook `(game, ui, actions)`: `actions.pause()`, `actions.resume()`, `actions.toggleSound()`,
and expects back `{ hud, menu }` -- the HUD with `setMuted(muted)`, the pause menu with `isOpen` and `show(on)`.

## Sizes are units

- **Every size is `n * units.u` (the HUD) or `n * units.m` (the menus)**, never bare pixels: the units follow the
  window, so the UI shrinks as a whole and never overlaps itself on a small or narrow screen. `units.safe` is the
  safe area (a notch); `menu(units, lo, vwPct, hi)` a width between two limits.
- **The UI lives in the game's frame** (`game.frame`): the window in a release build and on the plain page, the
  room between the studio's cards in the editor, or a preview preset's box in it (16:9, 320×180 Pixel...).
  `units.width` and `units.height` are the frame's, `(0, 0)` is its top left corner, and nothing is drawn outside
  it -- lay out from the units and it fits any of them. The UI is always drawn at the screen's sharpness, even while
  a Pixel preset draws the world at 320×180.
- **Colours and sizes come from the theme**: `COLOUR`, `SIZE_U`, `SIZE_M`, `ALPHA` from `@vibe/engine/ui` --
  never `'#ff0000'`, never `14 * u`, never `size: 14` in a widget. `npm test`'s `ui` check names each literal and
  where it belongs. The theme is the engine's for now.

## Pixi work runs on the Pixi side

Three and Pixi share one GL context, so **every piece of Pixi work -- a draw, a layout, a text change -- runs
inside `CanvasUi.onPixiSide`**. `layout` and `frame` already do; work that arrives later (an icon's texture
coming back from a promise) is wrapped:

```ts
import { Sprite } from 'pixi.js';
import { Assets } from '@vibe/engine/assets';
import { COLOUR, ICON_SHADOW, icon, type CanvasUi } from '@vibe/engine/ui';

export function showIcon(ui: CanvasUi, glyph: Sprite, size: number): void {
  void icon(Assets.iconUrl('pause'), size, size, ui.resolution, { paint: COLOUR.icon, shadow: ICON_SHADOW }).then((texture) => {
    ui.onPixiSide(() => {
      glyph.texture = texture;
    });
  });
}
```

- **Never `pixi.destroy()`**: the context is three's. **Never shrink the canvas** (for speed, render the world
  smaller and stretch it): the UI would go soft with it.
- An icon is rasterised at the size it is drawn (`icon(url, width, height, resolution, ...)`), asked again on a
  resize; a font is a key under `src/assets/fonts/`, loaded before the first word.

## Buttons and the pointer

- **`Pressable`** makes any container a button: `new Pressable(view, { id, onPress, onState })`, `onState` drawing
  hover and down. **`PillButton`** is the stock menu button: `new PillButton(id, words, onPress)`, `layout(m)`.
- **The game asks the UI first** about every pointer event (`Game.pointerClaim`, wired by the layer): a press on a
  button, or on a menu's full-screen veil (`eventMode = 'static'`), is the UI's and never reaches the game's input
  ([the input page](input.md)). Nothing else to do -- just never listen for pointer events on the canvas yourself.

## Pausing, and what the HUD sees

`P` and Esc open the pause menu (`boot()`'s): the game stops ticking, the menu animates over the kept frame.

A widget that shows game state -- a score, a count -- is told it by **a render system of the page's**, which reads
the world each frame and calls the widget's `set` (which redraws only when what shows changes). Not `frame`
(animation only) and not `sync` (showing and hiding, no drawing). The system is one of the game entry's
`installs`, made again on every rebuild, so it always reads the world as it is now; the widget is the page's, in
`src/ui/`, which a change under `src/game/` never swaps -- so the module holding it outlives a rebuild:

```ts
// src/ui/wanderers.ts
import { Container } from 'pixi.js';
import type { World } from '@vibe/engine';
import { COLOUR, Label, SIZE_U, type Units, type Widget } from '@vibe/engine/ui';
import { Wanderer } from '../game/components.ts';

/** How many wander, top right: told by its render system, redrawn only on a change. */
export class Wanderers implements Widget {
  readonly id = 'wanderers';
  readonly view = new Container({ label: 'wanderers' });
  private readonly words = new Label({ size: SIZE_U.hud, fill: COLOUR.text, outline: SIZE_U.outline, shadow: 'hud' }, '0');

  constructor() {
    this.view.addChild(this.words);
  }

  set(n: number): void {
    this.words.set(n);
  }

  layout(units: Units): void {
    const { u, safe, width } = units;
    this.words.restyle({ size: SIZE_U.hud * u, outline: SIZE_U.outline * u });
    this.words.position.set(width - Math.max(SIZE_U.inset * u, safe.right) - this.words.lineBox.width, Math.max(SIZE_U.inset * u, safe.top));
  }
}

/** The one on show, put here by `main.ts`'s `ui` hook: the page's, kept across a rebuild of the game. */
let shown: Wanderers | null = null;

export function showWanderers(widget: Wanderers): Wanderers {
  shown = widget;
  return widget;
}

/** The game entry's install: each frame, how many `Wanderer`s there are, told to the widget. */
export function wanderersHud(world: World): () => void {
  world.system({
    name: 'wanderers-hud',
    phase: 'render',
    with: [Wanderer],
    update(ctx) {
      shown?.set(ctx.count);
    },
  });
  return () => {};                                     // a rebuild drops the system itself
}
```

and `showWanderers(ui.add(new Wanderers(), 'hud'))` in `main.ts`'s `ui` hook, `export const installs =
[wanderersHud];` in `src/game/index.ts`. A label set outside the Pixi side is fine: its upload waits for the next
draw.

The count of a component's entities is the system's `ctx.count`, as above. The whole world's is
`world.stats.entities - world.stats.parked`, with no `with`: `stats` is an object the world keeps and updates
(no allocation to read it), and `entities` counts pooled instances parked out of play too -- the alive ones are
what `world.describe()`'s first line says.

## The rules that bite

- One canvas: no HTML overlay for the game's UI (the loading bar is the only HTML).
- Units and the theme, never literals; every Pixi change on the Pixi side; never `pixi.destroy()`.
- Audio for a click goes through `Audio` ([the audio page](audio.md)); a debug button through MrDebug, never a
  widget of its own ([the debug page](debug.md)).
- `U` (a debug key) hides the whole UI for clean footage (`ui.visible`).
- A node test imports nothing of `@vibe/engine/ui` but types: it loads Pixi.
