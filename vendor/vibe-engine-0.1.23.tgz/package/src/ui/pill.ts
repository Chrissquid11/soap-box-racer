/**
 * The stock menu button: a rounded pill on a raised edge that it sinks into
 * when held, its words centred. A `Pressable` (`button.ts`) with a look -- the
 * pattern every canvas button follows: draw for each state in `onState`, size
 * from the units in `layout`.
 *
 * ```ts
 * const play = new PillButton('play', 'Play', () => startRound());
 * view.addChild(play.view);
 * play.layout(units.m);           // in the widget's own layout
 * ```
 */
import { Container, Graphics } from 'pixi.js';
import { Pressable, type ButtonState } from './button.ts';
import { Label } from './text.ts';
import { COLOUR, SIZE_M } from './theme.ts';

export interface PillColours {
  face: string;
  edge: string;
  ink?: string;
}

export class PillButton {
  readonly view: Container;
  readonly press: Pressable;
  private readonly bg = new Graphics();
  private readonly label: Label;
  private readonly colours: PillColours;
  /** The menus' unit it was last laid out at. */
  private m = 1;

  constructor(id: string, words: string, onPress: () => void, colours: PillColours = { face: COLOUR.go, edge: COLOUR.goDark }) {
    this.view = new Container({ label: id });
    this.colours = colours;
    this.label = new Label({ size: SIZE_M.buttonText, caps: true, tracking: 0.04, fill: colours.ink ?? COLOUR.text, outline: SIZE_M.buttonOutline, outlineColour: colours.edge }, words);
    this.view.addChild(this.bg, this.label);
    this.press = new Pressable(this.view, { id, onPress, onState: (state) => this.draw(state) });
  }

  /** Its size: the pill's own, without the raised edge under it. */
  get width(): number {
    return Math.max(SIZE_M.button * 3, this.label.lineBox.width + 2 * SIZE_M.button * 0.6) * this.m;
  }

  get height(): number {
    return SIZE_M.button * this.m;
  }

  /** New words. Call `layout` after, if they change its width. */
  set(words: string): void {
    this.label.set(words);
  }

  /** Sized from the menus' unit (`units.m`). */
  layout(m: number): void {
    this.m = m;
    this.label.restyle({ size: SIZE_M.buttonText * m, outline: SIZE_M.buttonOutline * m });
    this.draw(this.press.states);
  }

  private draw(state: Readonly<ButtonState>): void {
    const m = this.m;
    const w = this.width;
    const h = this.height;
    const r = h / 2;
    const press = state.down ? SIZE_M.press * m : 0;
    const g = this.bg.clear();
    // The raised edge under it, which the press sinks into.
    g.roundRect(0, SIZE_M.press * m, w, h, r).fill(state.disabled ? COLOUR.panelEdge : this.colours.edge);
    g.roundRect(0, press, w, h, r).fill(state.disabled ? COLOUR.off : this.colours.face);
    if (state.hover && !state.disabled) g.roundRect(0, press, w, h, r).fill(COLOUR.hoverWash);
    const box = this.label.lineBox;
    this.label.position.set((w - box.width) / 2, (h - box.height) / 2 + press);
  }
}
