/**
 * Pictures for the canvas UI, as Pixi textures: icons, bitmaps, and the soft
 * shapes CSS would have drawn with `box-shadow`.
 *
 * ## Always through a URL Vite made
 *
 *   An icon is `Assets.iconUrl('speaker')` (the engine's `assets/registry.ts`): a hashed
 *   URL, never a string built from a path, which after hashing points at
 *   nothing. A picture the game renders at run time (a data URL) goes through
 *   the same door.
 *
 * ## Sharp at the size it is drawn
 *
 *   `icon` draws a picture into a canvas at the size it will be shown, times
 *   the pixel ratio, and makes the texture from that: an SVG is rasterised at
 *   exactly its on-screen pixels, not at its own nominal size and scaled. A
 *   resize that changes the size asks again, and gets a new texture; the same
 *   size gets the one it already had, and the old size's goes once nothing
 *   shows it (below). A texture's `resolution` is the pixel ratio, so a sprite
 *   of it is its CSS size with no scaling.
 *
 * ## One colour, then tinted
 *
 *   An SVG in `currentColor` loaded as an image comes out black. `paint` fills
 *   whatever the picture covers with one colour; paint it white and set the
 *   sprite's `tint` to colour it, which costs nothing a frame and lets one
 *   texture be every state's colour.
 *
 * ## Shadows baked in
 *
 *   A drop shadow under an icon is `shadow`, drawn into the same canvas by the
 *   2D context's own shadow -- paid once when the texture is made, not by a
 *   Pixi filter every frame. A glow round a box, or a shadow under an opaque
 *   one, is `softRect`: a blurred rounded rectangle, white, to tint. A
 *   `box-shadow` exactly as CSS draws it -- offset, spread, and only outside
 *   the box -- is `boxShadow`. Each reaches past the box it was asked for;
 *   `bakedMargin` says how far, to place it by its box.
 *
 * ## A picture drawn by the 2D context, redrawn
 *
 *   Something still painted with Canvas2D (a mini map) is a texture of its
 *   canvas: `new Texture({ source: new CanvasSource({ resource: canvas,
 *   resolution }), dynamic: true })`, then `source.update()` after each
 *   redraw, which uploads it again. Redraw it as seldom as it changes, and only
 *   in a widget's `layout` or `frame`, which run on Pixi's side of the context.
 *
 * Loading is asynchronous: a widget shows nothing until the promise resolves,
 * as an `<img>` showed nothing until it decoded. `peek` answers synchronously
 * from the cache, for code that runs every frame.
 *
 * ## Kept while shown, and let go of
 *
 *   Every picture is cached by what it was baked for -- its size in device
 *   pixels, mostly. A size that follows the window is a new picture for every
 *   window size, and a window dragged by its edge is a new size every frame:
 *   kept for ever, those pile up by the gigabyte. So the caches are
 *   `PictureCache`s, and `sweepPictures` -- which the canvas UI calls after
 *   every resize -- destroys every picture no sprite in the stage shows and
 *   nobody has asked for since the sweep before. A texture from here is never
 *   destroyed by the widget: it may be another's too.
 */
import { CanvasSource, ImageSource, Texture, type Container, type TextureSource } from 'pixi.js';

/** How `icon` draws a picture. */
export interface IconOptions {
  /** Every covered pixel this one colour, keeping its alpha: a mask, ready to tint. */
  paint?: string;
  /** A drop shadow baked into the texture, CSS pixels, as `drop-shadow(0 y blur rgba(0,0,0,alpha))`: `blur` the CSS's, a standard deviation. */
  shadow?: { y: number; blur: number; alpha: number };
  /** How the picture fits the box when their shapes differ: `contain` (default) or `cover`. */
  fit?: 'contain' | 'cover';
}

// ── The caches ──────────────────────────────────────────────────────────

/**
 * How many sweeps there have been: a picture is stamped with it when it is
 * made and whenever it is asked for, so a sweep can tell what was wanted
 * since the one before.
 */
let sweeps = 0;

/** Every `PictureCache`, for `sweepPictures`. */
const caches: PictureCache[] = [];

/**
 * Baked pictures by what they were baked for, kept while they are wanted:
 * shown by a sprite in the stage, or asked for since the last sweep. What
 * neither is goes at the next `sweepPictures`, destroyed with its canvas.
 * Every cache of baked textures the canvas UI keeps is one of these --
 * `icon`'s, `softRect`'s, `boxShadow`'s, and any a widget keeps for pictures
 * it bakes itself.
 */
export class PictureCache {
  private readonly entries = new Map<string, { texture: Texture; asked: number }>();

  constructor() {
    caches.push(this);
  }

  /** The picture baked for `key`, if there is one: asked for, so kept through the next sweep. */
  get(key: string): Texture | undefined {
    const entry = this.entries.get(key);
    if (!entry) return undefined;
    entry.asked = sweeps;
    return entry.texture;
  }

  /** `texture`, baked for `key`, kept. Returned, for `return cache.set(key, texture)`. */
  set(key: string, texture: Texture): Texture {
    this.entries.set(key, { texture, asked: sweeps });
    return texture;
  }

  /** How many pictures it holds. */
  get size(): number {
    return this.entries.size;
  }

  /** Every picture whose key `drop` says to, destroyed now, shown or not (`release`). */
  forget(drop: (key: string) => boolean): void {
    for (const [key, { texture }] of this.entries) {
      if (!drop(key)) continue;
      texture.destroy(true);
      this.entries.delete(key);
    }
  }

  /** The sweep's share (`sweepPictures`): every picture not shown and not asked for since the last sweep, destroyed. */
  sweep(shown: ReadonlySet<TextureSource>): void {
    for (const [key, { texture, asked }] of this.entries) {
      if (asked >= sweeps || shown.has(texture.source)) continue;
      texture.destroy(true);
      this.entries.delete(key);
    }
  }
}

/**
 * Every baked picture nothing wants any more, destroyed with its canvas: not
 * shown by any sprite in `stage` -- hidden ones count, a closed menu's too --
 * and not asked for since the sweep before, which keeps what a widget has
 * asked for and not yet put up (a picture decoding, a glow for a later
 * frame). Called by the canvas UI after every resize and language change,
 * on Pixi's side of the context: destroying a texture deletes it on the GPU.
 */
export function sweepPictures(stage: Container): void {
  const shown = new Set<TextureSource>();
  const visit = (node: Container): void => {
    // A sprite's, or anything else's that draws a texture (a mesh, a tiling sprite): by its source, as one picture may be framed twice (the logo).
    const texture = (node as { texture?: unknown }).texture;
    if (texture instanceof Texture) shown.add(texture.source);
    for (const child of node.children) visit(child);
  };
  visit(stage);
  for (const cache of caches) cache.sweep(shown);
  sweeps++;
}

/** How many baked pictures are kept now, in every cache: for the tests. */
export function picturesKept(): number {
  let n = 0;
  for (const cache of caches) n += cache.size;
  return n;
}

// ── Icons and bitmaps ────────────────────────────────────────────────────

const images = new Map<string, Promise<HTMLImageElement>>();
/** How far each texture `icon` or `softRect` made reaches past its box, CSS pixels: its shadow's room. */
const margins = new WeakMap<Texture, number>();
const textures = new PictureCache();
const pending = new Map<string, Promise<Texture>>();

/** The image at a URL, decoded; shared by every size drawn from it. */
function image(url: string): Promise<HTMLImageElement> {
  let loading = images.get(url);
  if (!loading) {
    loading = (async () => {
      const img = new Image();
      img.decoding = 'async';
      img.src = url;
      try {
        await img.decode();
      } catch (error) {
        // **`decode()` can fail on a picture that loads**: Chrome
        // rejects it now and then -- an `EncodingError` -- for an image it then
        // draws perfectly well. A data URL made at run time can go missing
        // for good that way, the error swallowed by its widget. Waited for as `load` instead, and only
        // a picture that really will not load fails.
        if (!(img.complete && img.naturalWidth > 0)) {
          await new Promise<void>((resolve, reject) => {
            img.addEventListener('load', () => resolve(), { once: true });
            img.addEventListener('error', () => reject(error), { once: true });
          });
        }
      }
      return img;
    })();
    // Said, in a dev build: a widget that asked for it has no way to.
    if (import.meta.env.DEV) loading.catch((error) => console.warn(`[ui] picture failed to load: ${url.slice(0, 60)}${url.length > 60 ? '…' : ''}`, error));
    // A failure is not cached: the next ask tries again.
    loading.catch(() => images.delete(url));
    images.set(url, loading);
  }
  return loading;
}

const keyOf = (url: string, w: number, h: number, ratio: number, options: IconOptions): string =>
  `${url}|${Math.round(w * ratio)}x${Math.round(h * ratio)}|${options.paint ?? ''}|${options.shadow ? `${options.shadow.y},${options.shadow.blur},${options.shadow.alpha}` : ''}|${options.fit ?? 'contain'}|${ratio}`;

/**
 * A picture drawn at `w`×`h` CSS pixels, times `ratio` (the renderer's
 * resolution), as a texture of that CSS size. Cached by all of that: the same
 * ask twice is the same texture.
 */
export function icon(url: string, w: number, h: number, ratio: number, options: IconOptions = {}): Promise<Texture> {
  const key = keyOf(url, w, h, ratio, options);
  const done = textures.get(key);
  if (done) return Promise.resolve(done);
  let loading = pending.get(key);
  if (!loading) {
    loading = image(url).then((img) => {
      pending.delete(key);
      return textures.set(key, rasterise(img, w, h, ratio, options));
    });
    loading.catch(() => pending.delete(key));
    pending.set(key, loading);
  }
  return loading;
}

/** What `icon` would give, if it is already made; null if not (yet). For per-frame code. */
export function peek(url: string, w: number, h: number, ratio: number, options: IconOptions = {}): Texture | null {
  return textures.get(keyOf(url, w, h, ratio, options)) ?? null;
}

/**
 * A bitmap -- a hashed `.webp`, a data URL -- at its own size, `ratio` of its
 * pixels to a CSS pixel. For a picture a widget scales itself (a card's art
 * inside a box laid out by flex); `icon` is better when the size is known.
 */
export function bitmap(url: string, ratio = 1): Promise<Texture> {
  const key = `${url}|bitmap|${ratio}`;
  const done = textures.get(key);
  if (done) return Promise.resolve(done);
  let loading = pending.get(key);
  if (!loading) {
    loading = image(url).then((img) => {
      pending.delete(key);
      return textures.set(key, new Texture({ source: new ImageSource({ resource: img, resolution: ratio, autoGenerateMipmaps: true }) }));
    });
    loading.catch(() => pending.delete(key));
    pending.set(key, loading);
  }
  return loading;
}

/**
 * Forget every texture made from `url`, and free them: a thumbnail the game
 * will not show again. Anything still drawing one of them draws nothing.
 */
export function release(url: string): void {
  images.delete(url);
  textures.forget((key) => key.startsWith(`${url}|`));
}

function rasterise(img: HTMLImageElement, w: number, h: number, ratio: number, options: IconOptions): Texture {
  const shadow = options.shadow;
  // Room round the picture for its shadow, in whole device pixels: three
  // deviations, where the Gaussian is down to a hundredth of its middle.
  const margin = shadow ? Math.ceil((3 * shadow.blur + Math.abs(shadow.y)) * ratio) : 0;
  const pw = Math.max(1, Math.round(w * ratio));
  const ph = Math.max(1, Math.round(h * ratio));
  const canvas = document.createElement('canvas');
  canvas.width = pw + margin * 2;
  canvas.height = ph + margin * 2;
  const context = canvas.getContext('2d')!;

  // The picture fitted into its box, as `object-fit` would.
  const iw = img.naturalWidth || pw;
  const ih = img.naturalHeight || ph;
  const scale = options.fit === 'cover' ? Math.max(pw / iw, ph / ih) : Math.min(pw / iw, ph / ih);
  const dw = iw * scale;
  const dh = ih * scale;
  const dx = margin + (pw - dw) / 2;
  const dy = margin + (ph - dh) / 2;

  // Painted one colour first, on a canvas of its own, so the shadow below is
  // cast by the painted shape rather than by the picture's own colours.
  let source: CanvasImageSource = img;
  let sw = iw;
  let sh = ih;
  if (options.paint) {
    const painted = document.createElement('canvas');
    painted.width = Math.max(1, Math.ceil(dw));
    painted.height = Math.max(1, Math.ceil(dh));
    const p = painted.getContext('2d')!;
    p.drawImage(img, 0, 0, dw, dh);
    p.globalCompositeOperation = 'source-in';
    p.fillStyle = options.paint;
    p.fillRect(0, 0, painted.width, painted.height);
    source = painted;
    sw = painted.width;
    sh = painted.height;
  }
  if (options.fit === 'cover') {
    context.beginPath();
    context.rect(margin, margin, pw, ph);
    context.clip();
  }
  if (shadow) {
    // `drop-shadow`'s blur is a deviation; `shadowBlur` is two.
    context.shadowColor = `rgba(0, 0, 0, ${shadow.alpha})`;
    context.shadowBlur = 2 * shadow.blur * ratio;
    context.shadowOffsetY = shadow.y * ratio;
  }
  context.drawImage(source, 0, 0, sw, sh, dx, dy, dw, dh);

  const texture = new Texture({ source: new CanvasSource({ resource: canvas, resolution: ratio }) });
  // The shadow's margin is outside the box: the texture's frame is the whole
  // canvas, and a sprite of it is offset by `margin` so the box lands where asked.
  margins.set(texture, margin / ratio);
  return texture;
}

/**
 * How far a texture from `icon` or `softRect` reaches past its box on each
 * side -- the room its baked shadow needs -- in CSS pixels. A sprite of it
 * goes at `x - bakedMargin(texture)` to put the picture's box at `x`.
 */
export function bakedMargin(texture: Texture): number {
  return margins.get(texture) ?? 0;
}

const plates = new PictureCache();

/**
 * A rounded rectangle blurred by `blur` CSS pixels, white, as a texture: a
 * CSS `box-shadow` or a glow, baked once rather than drawn by a filter every
 * frame. Tint the sprite for its colour and set its alpha for the shadow's.
 * The texture reaches `blur` past the rectangle on every side
 * (`bakedMargin`), as the CSS blur did; a sprite of it goes at
 * `x - bakedMargin(texture)`.
 *
 * ```ts
 * // A bar's glow: box-shadow 0 0 12px #4fd8b4
 * const glow = new Sprite(softRect(barW, barH, barH / 2, 12, ui.resolution));
 * glow.tint = '#4fd8b4';
 * glow.position.set(-bakedMargin(glow.texture), -bakedMargin(glow.texture));
 * ```
 */
export function softRect(w: number, h: number, radius: number, blur: number, ratio: number): Texture {
  const key = `${Math.round(w * ratio)}x${Math.round(h * ratio)}|${Math.round(radius * ratio)}|${Math.round(blur * ratio)}|${ratio}`;
  const done = plates.get(key);
  if (done) return done;
  const pad = Math.ceil(blur * ratio);
  const pw = Math.max(1, Math.round(w * ratio));
  const ph = Math.max(1, Math.round(h * ratio));
  const canvas = document.createElement('canvas');
  canvas.width = pw + pad * 2;
  canvas.height = ph + pad * 2;
  const context = canvas.getContext('2d')!;
  // Only the shadow is wanted: the shape is drawn far off the canvas and its
  // shadow thrown back onto it. `shadowBlur` is the CSS blur radius, both
  // being a Gaussian of half that sigma.
  const away = canvas.width + 1000;
  context.shadowColor = '#ffffff';
  context.shadowBlur = blur * ratio;
  context.shadowOffsetX = away;
  context.fillStyle = '#ffffff';
  context.beginPath();
  context.roundRect(pad - away, pad, pw, ph, Math.min(radius * ratio, pw / 2, ph / 2));
  context.fill();
  const texture = new Texture({ source: new CanvasSource({ resource: canvas, resolution: ratio }) });
  margins.set(texture, pad / ratio);
  return plates.set(key, texture);
}

/** A CSS outer `box-shadow`, CSS pixels: `x y blur spread`. */
export interface BoxShadow {
  x?: number;
  y?: number;
  blur: number;
  spread?: number;
}

const shadows = new PictureCache();

/**
 * A CSS outer `box-shadow` as a texture, white, to tint: the box's shape
 * grown by `spread`, moved by `x`/`y`, blurred by `blur` -- and **cut out
 * where the box itself is**, as CSS paints an outer shadow only outside its
 * box. `softRect` is the shadow uncut, which is the same thing under an
 * opaque box; under a see-through one (a translucent plate) the uncut
 * shadow would darken what shows through it.
 *
 * The texture reaches `bakedMargin(texture)` past the box on every side; a
 * sprite of it goes at `x - bakedMargin(texture)`, `y - bakedMargin(texture)`.
 * Cached by all of its sizes.
 *
 * ```ts
 * // A round plate's: box-shadow 0 4px 10px rgba(0, 0, 0, 0.4)
 * const shadow = new Sprite(boxShadow(size, size, size / 2, { y: 4, blur: 10 }, ui.resolution));
 * shadow.tint = '#000000';
 * shadow.alpha = 0.4;
 * ```
 */
export function boxShadow(w: number, h: number, radius: number, shadow: BoxShadow, ratio: number): Texture {
  const { x = 0, y = 0, blur, spread = 0 } = shadow;
  const px = (n: number): number => Math.round(n * ratio);
  const key = `${px(w)}x${px(h)}|${px(radius)}|${px(x)},${px(y)},${px(blur)},${px(spread)}|${ratio}`;
  const done = shadows.get(key);
  if (done) return done;
  // Room for the blur, the spread and the offset on every side: one margin,
  // so the box is always at the same place in the texture.
  const pad = Math.ceil((blur + Math.max(0, spread) + Math.max(Math.abs(x), Math.abs(y))) * ratio);
  const pw = Math.max(1, px(w));
  const ph = Math.max(1, px(h));
  const canvas = document.createElement('canvas');
  canvas.width = pw + pad * 2;
  canvas.height = ph + pad * 2;
  const context = canvas.getContext('2d')!;
  // The shadow alone, as `softRect` makes it: the shape drawn far off the
  // canvas and its shadow thrown back, offset as the CSS offsets it.
  const away = canvas.width + 1000;
  const grow = spread * ratio;
  context.shadowColor = '#ffffff';
  context.shadowBlur = blur * ratio;
  context.shadowOffsetX = away + x * ratio;
  context.shadowOffsetY = y * ratio;
  context.fillStyle = '#ffffff';
  context.beginPath();
  context.roundRect(pad - grow - away, pad - grow, pw + grow * 2, ph + grow * 2, Math.max(0, Math.min(radius * ratio + grow, (pw + grow * 2) / 2, (ph + grow * 2) / 2)));
  context.fill();
  // And the box taken out of it.
  context.shadowColor = 'transparent';
  context.globalCompositeOperation = 'destination-out';
  context.beginPath();
  context.roundRect(pad, pad, pw, ph, Math.min(radius * ratio, pw / 2, ph / 2));
  context.fill();
  const texture = new Texture({ source: new CanvasSource({ resource: canvas, resolution: ratio }) });
  margins.set(texture, pad / ratio);
  return shadows.set(key, texture);
}
