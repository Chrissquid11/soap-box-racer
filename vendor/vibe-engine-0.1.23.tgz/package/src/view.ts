/**
 * The three.js side of the ECS: an entity with a `View` is drawn
 * (Docs/ecs.md §9). `View` is the engine's slot: an entity's look is its
 * `Render` (data, Docs/render.md), and the engine's `render` system
 * (`render.ts`, `installRender`) makes the object and attaches it here.
 *
 * ```ts
 * const e = world.spawn();                             // a look as data: the render system draws it
 * world.add(e, Transform);
 * world.add(e, Render).model[e] = internKey('Model', 'props/crate');
 * attach(world, e, myObject);                          // a tool's or a test's own object, by hand
 * ```
 *
 * - **three's scene stays flat.** Every view is a child of the scene, whatever
 *   our hierarchy says: ours is the only tree a game edits.
 * - **One render system, `present`**, writes each object's matrix from the
 *   entity's world transform, interpolated between the last two ticks. three
 *   then updates the object's own subtree as usual, so a rigged model works.
 * - **What did not move is not touched**: one integer compare an object a frame.
 * - **The view comes and goes with the component**: in the scene when `View` lands
 *   on the entity at a boundary, out of it when the component is removed or the
 *   entity destroyed, and then handed to `release`.
 *
 * Render systems are the only code that touches a three object after setup:
 * the engine's `render` attaches and dresses each `Render`'s, and a game's own
 * (`read: [DiffuseColor, View]`, write the material) follow this one. A
 * model's materials are the asset store's, shared by every instance: a
 * per-entity look is a tint (`Render.tint`, the engine's own clone) or another
 * material file -- never a clone of, or a write into, a shared material in
 * game code. On a pooled instance the reset notices a clone and frees it with
 * the view (`installRender`).
 * The one exception is `swapView`, the editor's: a model re-exported while the
 * game runs, put in place of the old one between frames (Docs/assets.md §8) --
 * dressed by the render system as its own first (`dressViews`).
 *
 * - **`installView` and `installRender` each return an uninstall**, for
 *   the running game rebuilt in place (`Game.rebuild`,
 *   Docs/squidwright-implementation.md 0.3): the hooks and the system they
 *   registered die with `world.reset()`, so an uninstall is what the reset
 *   cannot know -- every view out of three's scene, and the per-install maps.
 *
 * Imports three's types alone, so it lives outside `src/ecs/` -- and a node
 * test can install it on a stand-in scene (`packages/editor/src/assets/swap.test.ts`).
 */
import type * as THREE from 'three';
import { bool, i32, objectComponent, component, u8, u32, WorldTransform, type Commands, type Entity, type World } from './ecs/index.ts';

/** The three.js object an entity is drawn as. Put it there with `attach`, never `add(e, View)` alone. */
export const View = objectComponent<THREE.Object3D, 'View'>('View');

/**
 * The engine's own notes per view, a row beside each `View`: `drawn`, `present`'s -- the change it
 * last drew, so a still object is written once and then left -- and the rest the `render` system's
 * (`render.ts`): `ours` set on a view it made, and `Render`'s numbers as it last applied them
 * (`stored`: a material from the store is on its meshes), so its per-frame compare is column reads.
 * A view attached by hand (`attach`) starts with `ours` 0, and is left alone by it.
 */
export const ViewState = component(
  'ViewState',
  {
    drawn: i32(-99),
    ours: bool(),
    model: i32(),
    material: i32(),
    tint: u32(0xffffff),
    castShadow: u8(),
    receiveShadow: u8(),
    stored: bool(),
  },
  { transient: true },
);

export interface ViewOptions {
  /** Given each object as it leaves the scene: back to a pool, or disposed of. Default: left for the garbage collector. */
  release?(object: THREE.Object3D): void;
}

/** What a view is put into: the game's `THREE.Scene`, or a test's stand-in. */
export interface ViewScene {
  add(object: THREE.Object3D): unknown;
  remove(object: THREE.Object3D): unknown;
}

/** What `installView` wired each world to, for `swapView`: its scene, how an object is made a view, and who dresses one. */
interface Installed {
  scene: ViewScene;
  wear(e: Entity, object: THREE.Object3D): void;
  release: ((object: THREE.Object3D) => void) | undefined;
  /** The render system's: an object about to be `e`'s view, given `e`'s `Render` and kept as its own (`dressViews`). */
  dress: ((e: Entity, object: THREE.Object3D) => void) | null;
}

const installed = new WeakMap<World, Installed>();

/**
 * Wires `View` to a scene, once per world: objects in and out of the scene as
 * the component comes and goes, and the `present` render system. An object's
 * `userData.entity` is its entity, for picking.
 *
 * Returns the uninstall, for a world about to be reset (`Game.rebuild`): every
 * entity's view, alive or parked, out of the scene and handed to `release`, as
 * a remove does, and the world no longer wired here. The hooks and `present`
 * go with the reset.
 */
export function installView(world: World, scene: ViewScene, { release }: ViewOptions = {}): () => void {
  const views = world.store(View);
  /** Drawn while in sight (no `Hidden` on it or above), in play (no `Disabled`) and the View switched on. */
  const seen = (e: Entity): boolean => world.seenEntity(e) && world.active(e) && world.enabled(e, View);
  /** `object` made `e`'s view: its matrix ours, picked as `e`, on `e`'s layer, shown as `e` is. Not yet in the scene. */
  const wear = (e: Entity, object: THREE.Object3D): void => {
    // Its matrix is ours to write: three composes none from position, rotation and scale.
    object.matrixAutoUpdate = false;
    object.userData.entity = e;
    // A camera's `layers` is what it sees (`Camera.layers`, the `camera` system's to set), never the layer it is on.
    if (!isCamera(object)) object.layers.set(world.layerOfEntity(e));
    object.visible = seen(e);
  };
  installed.set(world, { scene, wear, release, dress: null });
  world.onAdd(View, (e) => {
    const object = views.value[e];
    if (!object) throw new Error(`[view] entity ${e} has a View with no object: use attach(world, e, object)`);
    wear(e, object);
    scene.add(object);
  });
  world.onRemove(View, (_e, object) => {
    if (!object) return;
    scene.remove(object);
    object.userData.entity = 0;
    release?.(object);
  });
  const shown = (e: Entity): void => {
    const object = views.value[e];
    if (object) object.visible = seen(e);
  };
  world.onActive((e) => shown(e));
  world.onToggle(View, (e) => shown(e));
  // The entity's layer is the object's three.js layer: cameras and raycasts can go by it. A camera's is what it
  // sees instead (Docs/camera.md §1 rule 5): left alone.
  world.onLayer((e, layer) => {
    const object = views.value[e];
    if (object && !isCamera(object)) object.layers.set(layer);
  });

  world.system({
    name: 'present',
    phase: 'render',
    read: [View, WorldTransform],
    write: [ViewState],
    // The switched-off too: not drawn, but placed -- an editor moving one sees where it is, and it is
    // there the moment it is switched on. A still one costs one compare, as any other.
    includeDisabled: true,
    update({ members, count, alpha, tick }, [view, at], [state]) {
      // The last tick that ran: what moved on it is between two places.
      const last = tick - 1;
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const changed = at.changed[e];
        if (changed === last) {
          const object = view.value[e]!;
          world.writeMatrix(e, alpha, object.matrix.elements);
          object.matrixWorldNeedsUpdate = true;
          // Still on its way: whatever it settles on has not been drawn.
          state.drawn[e] = -99;
        } else if (state.drawn[e] !== changed) {
          const object = view.value[e]!;
          world.writeMatrix(e, 1, object.matrix.elements);
          object.matrixWorldNeedsUpdate = true;
          state.drawn[e] = changed;
        }
      }
    },
  });

  return () => {
    // The store as it is now: the world may have grown since, which replaced it.
    const value = world.store(View).value;
    for (let e = 1; e < world.extent; e++) {
      const object = value[e];
      if (!object || !(world.alive(e as Entity) || world.parked(e as Entity))) continue;
      scene.remove(object);
      object.userData.entity = 0;
      release?.(object);
    }
    if (installed.get(world)?.scene === scene) installed.delete(world);
  };
}

/**
 * `object` as what entity `e` is drawn as, from the next boundary. The entity
 * needs a `Transform` to be placed. Pass the world outside a system, `ctx.cmd`
 * inside one.
 */
export function attach(host: World | Commands, e: Entity, object: THREE.Object3D): void {
  if (e === 0) return;
  host.add(e, View).value[e] = object;
  host.add(e, ViewState);
}

/**
 * `object` drawn as `e` in place of what is, where it was -- now, not at a
 * boundary. Returns the old one, out of the scene, no longer `e`'s; undefined,
 * and nothing done, for an entity with no View.
 *
 * The editor's, for a model re-exported while the game runs (Docs/assets.md
 * §8): between frames, from a dev-only notice, the ECS's data untouched. Not
 * `attach`, which is `add(e, View)` and throws on an entity that has one; and a
 * remove and an attach would take two boundaries and hand the old object to
 * the game's `release`, which may pool it with geometry about to be disposed.
 */
export function swapView(world: World, e: Entity, object: THREE.Object3D): THREE.Object3D | undefined {
  const view = installed.get(world);
  if (!view) throw new Error('[view] swapView on a world installView never wired');
  const views = world.store(View);
  if (!views.value[e]) return undefined;
  // The entity's look on it first -- its shadows, its material -- and the render system's own from now on.
  view.dress?.(e, object);
  return putView(world, e, object, views, world.store(ViewState).drawn);
}

/**
 * `object` in place of `e`'s view now, where the old one was: the old out of
 * the scene and no longer `e`'s, returned. `swapView`'s, and the `render`
 * system's on a model changed (`render.ts`), which hands in the stores it
 * declared. Not the engine's surface: `index.ts` leaves it out.
 */
export function putView(world: World, e: Entity, object: THREE.Object3D, views: { value: (THREE.Object3D | null)[] }, drawn: { [e: number]: number }): THREE.Object3D | undefined {
  const view = installed.get(world)!;
  const old = views.value[e];
  if (!old) return undefined;
  // Where the old one was drawn, until `present` writes the matrix again next frame.
  object.matrix.copy(old.matrix);
  object.matrixWorld.copy(old.matrixWorld);
  object.matrixWorldNeedsUpdate = true;
  view.wear(e, object);
  view.scene.remove(old);
  view.scene.add(object);
  views.value[e] = object;
  drawn[e] = -99;
  old.userData.entity = 0;
  return old;
}

/** An object out of the scene for good, as a removed `View`'s is: to `installView`'s `release`. */
export function releaseView(world: World, object: THREE.Object3D): void {
  installed.get(world)?.release?.(object);
}

/**
 * Who dresses an object about to be a view by `swapView` -- the `render`
 * system (`installRender`), which applies the entity's `Render` to it and keeps
 * it as its own -- or null to stop. Once per world, after `installView`.
 */
export function dressViews(world: World, dress: ((e: Entity, object: THREE.Object3D) => void) | null): void {
  const view = installed.get(world);
  // Letting go after installView's own uninstall (`Game.rebuild` runs them in order): nothing left to unwire.
  if (!view && dress === null) return;
  if (!view) throw new Error('[view] dressViews on a world installView never wired');
  view.dress = dress;
}

/** Is `object` a three camera: its `layers` the layers it sees, not the one it is on. */
function isCamera(object: THREE.Object3D): boolean {
  return (object as THREE.Object3D & { isCamera?: boolean }).isCamera === true;
}

/** The entity an object (or one of its ancestors) is the view of, or 0: for picking in the scene. */
export function entityOf(object: THREE.Object3D | null): Entity {
  for (let o = object; o; o = o.parent) {
    const e = o.userData.entity as Entity | undefined;
    if (e) return e;
  }
  return 0 as Entity;
}
