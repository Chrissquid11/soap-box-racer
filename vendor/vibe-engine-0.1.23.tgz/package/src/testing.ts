/**
 * The whole test framework: a suite that counts checks and exits non-zero on a
 * failure. Node runs each `*.test.ts` directly (`npm test` finds them all:
 * `vibe test`, @vibe/pipeline's test-runner.ts), so there is no runner to install.
 *
 * ```ts
 * const t = suite('loop: rates');
 * t.ok('60 Hz is every tick', periodOf(60) === 1);
 * t.throws('a typo is an error', () => loop.join('wnader', 1), /no system called/);
 * t.noAlloc('a tick allocates nothing', () => world.loop.runTick());
 * if (!ffmpeg) t.skip('the ffmpeg step', 'ffmpeg not found', 'ffmpeg');
 * t.done();
 * ```
 *
 * Only tests import this: `noAlloc` uses node's own modules to watch the heap.
 */
import { Session } from 'node:inspector';
import { setFlagsFromString } from 'node:v8';
import { runInNewContext } from 'node:vm';
export interface Suite {
  /** One check: passes when `cond` is true. */
  ok(name: string, cond: boolean): void;
  /** Passes when the two are deep-equal (as JSON); prints both when not. */
  same(name: string, actual: unknown, expected: unknown): void;
  /** Passes when `fn` throws, with a message matching `match` if given. */
  throws(name: string, fn: () => unknown, match?: RegExp): void;
  /**
   * Passes when `run`, called `ticks` times after a warm-up, allocates no more
   * than `budget` bytes in all (default 4096: nothing per call). Over budget, it
   * is measured again, up to three times more, each after a longer warm-up
   * (`measureNoAlloc`): the engine can still be compiling -- or compiling again
   * after a deoptimisation -- through a whole measurement, while what `run`
   * allocates is there in every one. On a failure it prints each measurement's
   * bytes and the functions that allocated, most first, with their line.
   */
  noAlloc(name: string, run: () => void, options?: AllocOptions): void;
  /**
   * A check that cannot run here, and why -- a step whose tool this machine
   * lacks. Printed at once as `skipped: <name> -- <why>`, counted, never a
   * failure -- unless `tool` names what it lacks and `ASSETS_TESTS_REQUIRE`
   * (comma-separated: `gladius,ffmpeg,lfs`) lists it: then it fails, so a CI
   * job that forgot to install a tool is red, not quietly green.
   */
  skip(name: string, why: string, tool?: string): void;
  /** Prints the count and exits 1 if anything failed. Call it last. */
  done(): void;
}

export interface AllocOptions {
  /** Calls before measuring: long enough for the engine to finish optimising. Default 20,000. */
  warm?: number;
  /** Calls measured. Default 10,000. */
  ticks?: number;
  /** Bytes all of them together may allocate. Default 4096. */
  budget?: number;
}

/** One place that was seen allocating: bytes sampled there, and the function and line, innermost first. */
export interface Allocation {
  bytes: number;
  where: string;
}

/**
 * V8's own `gc()`, switched on from here so `npm test` needs no flag. A minor
 * collection: it empties the young generation, where everything new is, and
 * leaves compiled code alone -- a full one throws optimised code away, and the
 * next thousand calls would allocate in the interpreter.
 */
function collector(): () => void {
  setFlagsFromString('--expose-gc');
  const gc = runInNewContext('gc') as (options: { type: 'minor' }) => void;
  return () => gc({ type: 'minor' });
}

const heapUsed = (): number => process.memoryUsage().heapUsed;

/** Calls in one measured run. */
const RUN = 1000;

/**
 * What `ticks` calls of `run` allocate on the JavaScript heap, after `warm`
 * calls to let the engine finish optimising: bytes in all, and some of the
 * places.
 *
 * **The bytes are measured, not sampled**: the heap's size after a thousand
 * calls, less its size before, with a collection first. What reading the heap's
 * size itself costs is measured and taken off.
 *
 * **The places are a sample**: V8's sampling profiler misses most allocations
 * in optimised code, so they say where to look first, not everything.
 *
 * Typed-array storage is not on this heap; a typed array made inside `run` is
 * seen all the same, by its wrapper object.
 */
export function allocations(run: () => void, { warm = 20000, ticks = 10000 }: AllocOptions = {}): { bytes: number; places: Allocation[] } {
  const gc = collector();
  for (let i = 0; i < warm; i++) run();

  // What two readings cost with nothing between them.
  let overhead = Infinity;
  for (let i = 0; i < 5; i++) {
    gc();
    const before = heapUsed();
    overhead = Math.min(overhead, heapUsed() - before);
  }
  // In runs of a thousand, and the quietest run counts for all of them. The
  // engine allocates too -- compiled code lives on this heap -- in bursts, when
  // it decides to; what `run` allocates is there in every run. Each run starts
  // from an empty young generation, so a run cannot come out low by being
  // collected in the middle: what is left is at least what it made since.
  const runs = Math.max(1, Math.round(ticks / RUN));
  let quietest = Infinity;
  for (let r = 0; r < runs; r++) {
    gc();
    const before = heapUsed();
    for (let i = 0; i < RUN; i++) run();
    quietest = Math.min(quietest, Math.max(0, heapUsed() - before - overhead));
  }
  const bytes = quietest * runs;
  return { bytes, places: bytes > 0 ? sample(run, Math.min(ticks, 2000)) : [] };
}

/**
 * `noAlloc`'s verdict: `run` measured (`allocations`), and over `budget` measured again, up to three times more,
 * each after a warm-up twice the last (20,000 calls, then 40,000, 80,000, 160,000 by default) -- the engine can
 * still be compiling `run`'s path through a whole measurement on a slow, loaded runner, or compiling it again after
 * a deoptimisation, and unoptimised code boxes every number it hands on (a system's `rng.range()` stored into a
 * column: 16 bytes each). Any measurement within budget passes; what `run` itself allocates is there in every run of
 * every one, however long the warm-up, so it fails all four.
 */
export function measureNoAlloc(run: () => void, options: AllocOptions = {}): { ok: boolean; bytes: number; places: Allocation[]; measured: number[] } {
  const budget = options.budget ?? 4096;
  const warm = options.warm ?? 20000;
  let { bytes, places } = allocations(run, options);
  const measured = [bytes];
  for (let again = 1; bytes > budget && again <= 3; again++) {
    ({ bytes, places } = allocations(run, { ...options, warm: warm * 2 ** again }));
    measured.push(bytes);
  }
  return { ok: bytes <= budget, bytes, places, measured };
}

/** Where `run` allocates, as far as the sampling profiler sees. */
function sample(run: () => void, ticks: number): Allocation[] {
  interface Node {
    callFrame: { functionName: string; url: string; lineNumber: number };
    selfSize: number;
    children: Node[];
  }
  const session = new Session();
  session.connect();
  let head: Node | null = null;
  session.post('HeapProfiler.startSampling', { samplingInterval: 1 });
  for (let i = 0; i < ticks; i++) run();
  // A session in the same thread answers before `post` returns.
  session.post('HeapProfiler.stopSampling', (_err, result) => void (head = result.profile.head as Node));
  session.disconnect();
  if (!head) return [];

  const places = new Map<string, number>();
  // Allocations under no frame of the project's -- node's, V8's, the profiler's own bookkeeping --
  // named only when nothing of the project's was seen: then they are the clue there is.
  const elsewhere = new Map<string, number>();
  const walk = (node: Node, path: string[]): void => {
    const { functionName, url, lineNumber } = node.callFrame;
    const mine = url.startsWith('file:') && !url.endsWith('/testing.ts');
    const frame = `${functionName || '(anonymous)'} ${url === '' ? '(native)' : url.slice(url.lastIndexOf('/') + 1)}:${lineNumber + 1}`;
    const here = mine ? [frame, ...path] : path;
    if (node.selfSize > 0) {
      const into = mine ? places : elsewhere;
      const where = (mine ? here : [`outside the project: ${frame}`, ...path]).slice(0, 3).join(' < ');
      into.set(where, (into.get(where) ?? 0) + node.selfSize);
    }
    for (const child of node.children) walk(child, here);
  };
  walk(head, []);
  const seen = places.size > 0 ? places : elsewhere;
  return [...seen].map(([where, bytes]) => ({ where, bytes })).sort((x, y) => y.bytes - x.bytes);
}

/** The tools a run may not skip for: `ASSETS_TESTS_REQUIRE=gladius,ffmpeg,lfs`, as a CI job sets it. */
function required(): Set<string> {
  return new Set((process.env.ASSETS_TESTS_REQUIRE ?? '').split(',').map((s) => s.trim()).filter((s) => s !== ''));
}

/**
 * How a test removes its scratch folder: `rm`'s and `rmSync`'s options -- recursive, nothing there no error, and
 * Node's own retries (EBUSY, ENOTEMPTY, EPERM), which Windows needs: a file there is deleted only once the last
 * handle on it closes (a watcher's, the virus scan's), so its folder may not be empty yet when the removal asks.
 */
export const SCRATCH_RM = { recursive: true, force: true, maxRetries: 10, retryDelay: 50 } as const;

export function suite(title: string): Suite {
  let passed = 0;
  let skipped = 0;
  const failures: string[] = [];
  console.log(`${title}\n`);
  return {
    ok(name, cond) {
      if (cond) passed++;
      else failures.push(name);
    },
    same(name, actual, expected) {
      const a = JSON.stringify(actual);
      const e = JSON.stringify(expected);
      if (a === e) passed++;
      else failures.push(`${name}\n      got      ${a}\n      expected ${e}`);
    },
    throws(name, fn, match) {
      try {
        fn();
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        if (!match || match.test(message)) passed++;
        else failures.push(`${name}\n      threw    ${message}\n      expected ${String(match)}`);
        return;
      }
      failures.push(`${name}\n      did not throw`);
    },
    noAlloc(name, run, options = {}) {
      const { ok, bytes, places, measured } = measureNoAlloc(run, options);
      if (ok) passed++;
      else {
        const ticks = options.ticks ?? 10000;
        const seen = places.slice(0, 6).map((place) => `\n        ${place.where}`);
        failures.push(`${name}\n      allocated ${bytes} bytes over ${ticks} calls (${(bytes / ticks).toFixed(1)} a call; each measurement ${measured.join(', ')})${seen.length ? `; seen allocating:${seen.join('')}` : ''}`);
      }
    },
    skip(name, why, tool) {
      if (tool !== undefined && required().has(tool)) {
        failures.push(`${name}\n      ${tool} is required here (ASSETS_TESTS_REQUIRE), and: ${why}`);
        return;
      }
      skipped++;
      console.log(`skipped: ${name} -- ${why}`);
    },
    done() {
      console.log(`${passed} passed, ${failures.length} failed${skipped ? `, ${skipped} skipped` : ''}`);
      if (failures.length > 0) {
        for (const f of failures) console.log(`  FAIL ${f}`);
        process.exit(1);
      }
    },
  };
}
