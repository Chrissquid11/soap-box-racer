/**
 * The game's hot-update boundary, its half that is code (Docs/ecs.md §22, Docs/packages.md §4):
 * what the project's generated `src/game/live.ts` hands its game entry and `import.meta.hot` to. Dev
 * only in effect: `hot` is undefined in a build, nothing is registered, and the entry is the one
 * evaluated at load for good.
 *
 * `live.ts` is the one importer of the game's entry (`src/game/index.ts`), and accepts it -- spelled
 * out there as the literal `import.meta.hot.accept(['./index.ts'], ...)`, since Vite's server finds a
 * boundary's deps by that text as it transforms the module. So a change anywhere under `src/game/`
 * walks up to `index.ts` and stops at `live.ts`, accepted: no page reload, the running game rebuilt
 * over the new modules (`onRebuild`, which `boot` points at `Game.rebuild`). `main.ts` accepts
 * nothing, so whatever is not accepted there -- a change to `live.ts` itself, or to anything outside
 * `src/game/` -- reloads the page as ever. `live.ts` is never evaluated again without a reload, so
 * this closure's variables (`current`, the counts) are the ones every update sees: no `hot.data`.
 *
 * The order Vite's client keeps: `vite:beforeUpdate`, then every new module fetched and evaluated,
 * then each boundary's accept callback, then `vite:afterUpdate`. So:
 *
 *   - The generation (`ecs/component.ts`) is opened on `beforeUpdate` when the batch holds an update
 *     whose boundary is `live.ts` (an update's `path` is its boundary, its `acceptedPath` the dep it
 *     came through: `index.ts`), before the new modules run, so their `component()` calls take their
 *     old slots instead of throwing as duplicates.
 *   - The accept callback (`arrived`) only records the newest entry.
 *   - The rebuild is on `afterUpdate`, once per batch: the generation closed, then `onRebuild(current)`.
 *
 * A new module that throws as it is evaluated (a syntax error mid-edit): Vite warns and keeps the old
 * one, and hands the callback `undefined` for it. The generation is closed and nothing rebuilt -- the
 * world goes on over the old code -- and the next good save swaps. What was thrown is told to
 * `onFailed` (boot's: studio mode's notice, Docs/studio.md §1 "Mid-session"): Vite's client keeps it to
 * its console, so the entry's update is imported again (`load`, the url Vite's client fetched: the
 * browser's module map answers a module that threw with what it threw). One it could not fetch -- a
 * syntax error, an import of no file: the dev server could not serve it -- is not told: the browser's
 * words name no file, and the dev server's own list has it (`NOT_FETCHED`). A generation somehow still open
 * when the next update begins -- any update, the game's or not -- or on `vite:error` is closed first,
 * so a stale one never makes a later batch rebuild.
 *
 * `'reload'` from the rebuild -- worker threads running, `onBeforeRebuild` refusing, a prefab file
 * that will not compile, or a throw in the rebuild (`Game.rebuild` says each) -- or a throw out of
 * `onRebuild` itself (its pause, an `onBeforeRebuild` hook: Vite's client swallows a listener's throw
 * without a word, so it is caught and said here) asks the dev server for a reload:
 * `vibebase:swap:reload`, which the pipeline's `swap/vite.ts` answers with a `full-reload` to this page
 * alone. Sent after the generation is closed. Not `hot.invalidate()`: Vite's server honours that only
 * from a module that accepts itself, and `live.ts` accepts its dep, so it is dropped. Not
 * `location.reload()`: the editor keeps its state across a reload on `vite:beforeFullReload` (the
 * editor's `resume.ts`), which only the server's `full-reload` brings. `src/game/worker.ts` is no
 * import of anybody's (a worker's own entry, made by `live.ts`' `worker`): a change to it is a reload
 * with a pool, nothing without.
 *
 * Pure -- no DOM, no Vite: `hot` is handed in -- so a node test drives it with a stand-in.
 */
import { beginGeneration, endGeneration, generationOpen } from './ecs/index.ts';
import type { GameEntry } from './game.ts';

/** Where the boundary is in a project, relative to its root: the generated file (`vibe assets`). */
export const BOUNDARY = '/src/game/live.ts';

/** The browser's words for a module it could not fetch, whichever browser: no file, no line -- not what it threw. */
export const NOT_FETCHED = /Failed to fetch dynamically imported module|error loading dynamically imported module|Importing a module script failed/i;

/** One update of Vite's `vite:beforeUpdate`: its boundary, the dep it came through, and what Vite's client fetches it as. */
export interface BoundaryUpdate {
  path: string;
  acceptedPath: string;
  timestamp?: number;
  explicitImportRequired?: boolean;
}

/**
 * The url Vite's client imports an update's dep at (its `importUpdatedModule`): under the dev server's `base`
 * (`import.meta.env.BASE_URL`, `/` by default), a bare id as `/@id/`.
 */
export function updateUrl(update: BoundaryUpdate, base = '/'): string {
  const [bare = '', query] = update.acceptedPath.split('?');
  const path = bare.startsWith('/') || bare.startsWith('.') ? bare : `/@id/${bare}`;
  return `${base.endsWith('/') ? base : `${base}/`}${path.replace(/^\//, '')}?${update.explicitImportRequired ? 'import&' : ''}t=${update.timestamp ?? 0}${query ? `&${query}` : ''}`;
}

/** The dev server's base as the page has it (Vite's `import.meta.env.BASE_URL`); none (a node test), `/`. */
const pageBase = (): string => (import.meta as { env?: { BASE_URL?: string } }).env?.BASE_URL ?? '/';

/** What `liveGame` needs of `import.meta.hot`: Vite's `ViteHotContext` is one. */
export interface HotChannel {
  on(event: 'vite:beforeUpdate', listener: (payload: { updates: readonly BoundaryUpdate[] }) => void): void;
  on(event: 'vite:afterUpdate' | 'vite:error', listener: () => void): void;
  send(event: 'vibebase:swap:reload', data: { why: string }): void;
}

/** The game's entry as last evaluated, and the hook a swap goes through. */
export interface LiveGame {
  /** The entry as last evaluated: what a rebuild registers. */
  readonly entry: GameEntry;
  /** Makes one of the game's worker threads: `new Worker(new URL('./worker.ts', import.meta.url))`, spelled in `live.ts` whose folder it is. */
  readonly worker: () => Worker;
  /** `live.ts`' accept callback: the entry evaluated again, or undefined when it threw as it was. */
  arrived(next: unknown): void;
  /** Swaps the entry into the running game: `boot` sets it to `Game.rebuild`. Null: nothing to swap into yet, and an update is let be. */
  onRebuild: ((entry: GameEntry) => 'swapped' | 'reload') | null;
  /** A changed game module did not evaluate, and this is what it threw: told once a batch, the game kept on the last good code. */
  onFailed: ((error: unknown) => void) | null;
}

/**
 * The boundary's bookkeeping over `hot`'s events; `hot` undefined (a build) registers nothing. `load` imports a url
 * again to learn what a failed update threw (a test's stand-in), under `base`, the dev server's (`BASE_URL`).
 */
export function liveGame(entry: GameEntry, hot: HotChannel | undefined, worker: () => Worker, load: (url: string) => Promise<unknown> = (url) => import(/* @vite-ignore */ url), base: string = pageBase()): LiveGame {
  /** The entry as last evaluated. */
  let current = entry;
  /** A batch's updates through this boundary: how many began, and how many arrived evaluated. */
  let expected = 0;
  let arrived = 0;
  /** The batch's updates through this boundary: imported again when one did not evaluate. */
  let through: BoundaryUpdate[] = [];
  const live: LiveGame = {
    get entry() {
      return current;
    },
    worker,
    arrived(next) {
      if (next === undefined) return;
      // Vite types each new module as a bare `ModuleNamespace`: it is the entry, evaluated again.
      current = next as GameEntry;
      arrived++;
    },
    onRebuild: null,
    onFailed: null,
  };
  if (!hot) return live;

  const close = (): void => {
    if (generationOpen()) endGeneration();
  };
  /** The page reloaded by the dev server (the pipeline's `swap/vite.ts`), so the editor's resume record is written first. */
  const reload = (why: string): void => hot.send('vibebase:swap:reload', { why });

  hot.on('vite:beforeUpdate', (payload) => {
    through = payload.updates.filter((u) => u.path.endsWith(BOUNDARY));
    expected = through.length;
    arrived = 0;
    close();
    if (expected === 0) return;
    beginGeneration();
  });
  hot.on('vite:error', close);
  hot.on('vite:afterUpdate', () => {
    if (!generationOpen()) return;
    const change = endGeneration();
    if (arrived < expected) {
      console.warn('[game] a changed game module did not evaluate: not swapped -- the next good save swaps');
      const failed = through[0];
      // What it threw, from the browser's module map: Vite's client said it on its console alone.
      if (failed && live.onFailed) {
        void load(updateUrl(failed, base)).then(
          () => {},
          (err: unknown) => {
            if (!(err instanceof Error && NOT_FETCHED.test(err.message))) live.onFailed?.(err);
          },
        );
      }
      return;
    }
    if (!live.onRebuild) return;
    let result: 'swapped' | 'reload';
    try {
      result = live.onRebuild(current);
    } catch (err) {
      // Vite's client would swallow this throw without a word: said here, and the page reloaded.
      console.error('[game] a rebuild threw: reloading instead', err);
      reload('a rebuild threw');
      return;
    }
    if (result === 'reload') reload('Game.rebuild refused the swap (the page\'s console says which: worker threads, onBeforeRebuild refusing, a prefab that will not compile, a rebuild that failed)');
    // `kept` is not said: a module not evaluated again looks the same as one dropped (ecs/component.ts).
    else console.info(`[game] swapped: ${change.redefined.length} redefined, ${change.added.length} added`);
  });
  return live;
}
