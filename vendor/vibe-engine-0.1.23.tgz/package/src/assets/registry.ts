/**
 * Every shipped asset, discovered from the folder structure.
 *
 * There is no list to maintain. `import.meta.glob` matches the asset folders
 * at build time, so Rollup sees each file, fingerprints it and copies it into
 * `dist/assets/`; the key is simply the file's path under its kind's folder
 * with the extension dropped, lowercased (`caseKey`) -- every lookup takes any
 * case, and the URL keeps the file's own (it is Vite's, never built from a key):
 *
 *     src/assets/models/characters/Crab.glb  ->  'characters/crab'
 *     src/assets/audio/sfx/pickup.ogg        ->  'pickup'
 *
 * Those keys are compiler-checked through the project's generated `keys.d.ts`,
 * and the globs themselves come from its generated `globs.ts`: both written by
 * `packages/pipeline/src/assets/keys.ts` from `kinds.ts`, where the extension
 * lists live, once (Vite rewrites `import.meta.glob` only for literal
 * arguments, so they are spelled out there). Generated and gitignored: adding
 * a model touches no shared file, so two people adding one on the same day
 * cannot conflict. **The engine imports none of it**: the project's generated
 * `src/assets/bundle.ts` hands the globs in (`useBundle`, `bundle.ts` here),
 * which calls `useGlobs` below.
 *
 * **In the dev server a file added, removed or re-exported never reloads the
 * page**: the project's `bundle.ts` accepts its own hot updates, so only it is
 * evaluated again and hands the fresh globs in once more. This module is never
 * evaluated again, so its maps are the live ones every importer holds; the
 * fresh ones are copied into them in place (`sync`, `hot.ts`), and
 * `onKeysChanged` tells `index.ts` the keys that came and went. In a build the
 * globs are handed in once, and nobody is ever told anything.
 *
 * Nothing here builds a URL by string concatenation. A path assembled at
 * runtime would point at a name that no longer exists after hashing, and would
 * 404 only in production.
 *
 * The globs are the *shipping* formats on purpose. Source art (`.blend`,
 * `.aseprite`, `.psd`) lives in `AssetsSource/` outside `src/`, so it can never be
 * pulled into the bundle by accident. Every pattern carries two negations, so
 * anything whose name -- or whose folder's name -- starts with an underscore is
 * skipped: a work-in-progress asset stays beside its siblings without shipping.
 */
import { caseKey } from './case-key.ts';
import { sync, type KeysListener, type Maps } from './hot.ts';

/** Which set of assets. Each one has its own folder and its own key type: the project's `AssetKeys.Kind` (`kinds.ts`' registry kinds). */
export type Kind = AssetKeys.Kind;

/** One kind's glob, as the project's generated `globs.ts` has it: its folder, what under it is not a key, its files by hashed URL. */
export interface Glob {
  prefix: string;
  /**
   * Bundled, but not addressable by a key of its own.
   *
   * An atlas's `.json` is reached through its image (see `sibling`), so letting
   * it be a key too would offer `Assets.atlas('fx')` twice over. An image beside
   * a `.glb` is one of its own textures -- a `.glb` may keep them outside itself:
   * globbed so the build hashes it, found again by name when its model is loaded
   * (`beside.ts`), but not a model.
   */
  notKey: RegExp | null;
  files: Record<string, string>;
}

/** Every registry kind's glob: what `useBundle` takes as `globs`. */
export type Globs = Record<Kind, Glob>;

/** key -> hashed URL, e.g. 'characters/crab' -> '/assets/crab-a3f9c1.glb'. */
const KEYS = {} as Record<Kind, Map<string, string>>;
/** relative path, as on disk -> hashed URL, keeping the extension: what `files` lists. */
const PATHS = {} as Record<Kind, Map<string, string>>;
/** The same, the path lowercased (`caseKey`): what `sibling` and `pathUrl` look up, in any case. */
const CASED = {} as Record<Kind, Map<string, string>>;
/** Where each kind's files sit, for error messages. */
const DIRS = {} as Record<Kind, string>;
/** Who is told what a later `useGlobs` added and removed. */
const listeners = new Set<KeysListener<Kind>>();
/** Whether the globs were handed in yet: the first time fills, every later one syncs and tells. */
let filled = false;

/** The maps one set of globs makes. */
function mapsOf(globs: Globs): Maps<Kind> {
  const maps: Maps<Kind> = { KEYS: {} as Record<Kind, Map<string, string>>, PATHS: {} as Record<Kind, Map<string, string>>, CASED: {} as Record<Kind, Map<string, string>> };
  for (const kind of Object.keys(globs) as Kind[]) {
    const { prefix, notKey, files } = globs[kind];
    const keys = new Map<string, string>();
    const paths = new Map<string, string>();
    const cased = new Map<string, string>();

    for (const [globbed, url] of Object.entries<string>(files)) {
      const path = globbed.replace('./', '').replace(`${prefix}/`, '');
      paths.set(path, url);
      cased.set(caseKey(path), url);
      if (notKey?.test(path)) continue;

      const key = caseKey(path.replace(/\.[^.]+$/, ''));
      // Two files with the same name and different extensions would silently
      // shadow each other. The generator refuses to emit types for this, so it
      // is already a failed build -- but say so here too, for the dev server.
      // Unreachable in a build, which the generator's throw stops first: no `import.meta.env.DEV` gate needed.
      if (keys.has(key)) console.error(`[assets] duplicate key '${key}' in src/assets/${prefix} -- rename one of the files.`);
      keys.set(key, url);
    }

    maps.KEYS[kind] = keys;
    maps.PATHS[kind] = paths;
    maps.CASED[kind] = cased;
  }
  return maps;
}

/**
 * The project's globs taken in (`useBundle` calls this): the first time they
 * fill the maps; every later time -- a hot update of the project's `bundle.ts`,
 * dev only -- they are copied into the same maps in place, and whoever listens
 * (`onKeysChanged`) is told the keys that came and went.
 */
export function useGlobs(globs: Globs): void {
  for (const kind of Object.keys(globs) as Kind[]) DIRS[kind] = `src/assets/${globs[kind].prefix}`;
  const change = sync({ KEYS, PATHS, CASED }, mapsOf(globs));
  if (!filled) {
    filled = true;
    return;
  }
  if (change.added.length + change.removed.length > 0) for (const listener of listeners) listener(change);
}

/**
 * Told the keys each later `useGlobs` added and removed -- `index.ts` decodes
 * the new and forgets the gone. Only the dev server hands the globs in twice:
 * in a build nobody is ever told anything.
 */
export function onKeysChanged(listener: KeysListener<Kind>): void {
  listeners.add(listener);
}

/** One kind's map. Throws, saying so, before the project's `bundle.ts` has handed the globs in. */
function of(maps: Record<Kind, Map<string, string>>, kind: Kind): Map<string, string> {
  const map = maps[kind];
  if (map) return map;
  throw new Error(filled ? `asset kind '${kind}' is not one the project's globs have` : "assets used before the project's src/assets/bundle.ts handed them in (main.ts imports it first)");
}

/** The hashed URL for a key, in any case. Throws rather than 404 at load time. */
export function url(kind: Kind, key: string): string {
  const resolved = of(KEYS, kind).get(caseKey(key));
  if (!resolved) {
    throw new Error(
      `asset missing: no '${key}' under ${DIRS[kind]}. ` +
        'Check the spelling, and that neither the file nor a folder above it starts with "_". ' +
        'A file just added has its key a moment later in the dev server; elsewhere, run `vibe assets`.',
    );
  }
  return resolved;
}

/** Every asset of one kind, as `[key, url]`. This is what `preload` walks. */
export function entries(kind: Kind): Array<[string, string]> {
  return [...of(KEYS, kind)];
}

/**
 * Every file of one kind, keyed or not, as `[path under its folder, url]`: what
 * the editor's Assets tool lists with no dev server (its bundle view).
 */
export function files(kind: Kind): Array<[string, string]> {
  return [...of(PATHS, kind)];
}

/**
 * A built file by its path under a kind's folder, in any case, or undefined.
 *
 * Everything globbed is in here, keyed or not -- which is what lets a model's
 * own texture be found by name. See `beside.ts`.
 */
export function pathUrl(kind: Kind, path: string): string | undefined {
  return of(CASED, kind).get(caseKey(path));
}

/** A file sitting beside an asset -- an atlas's `.json` next to its image. */
export function sibling(kind: Kind, key: string, extension: string): string {
  const resolved = of(CASED, kind).get(caseKey(key + extension));
  if (!resolved) throw new Error(`asset missing: ${DIRS[kind]}/${key}${extension}`);
  return resolved;
}
