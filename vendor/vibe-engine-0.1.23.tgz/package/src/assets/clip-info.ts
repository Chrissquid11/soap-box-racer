/**
 * What a clip is in Gladius's words (Docs/modeler.md M31): its name (the
 * `action{}`'s), its length, its rate and whether it loops, read from the
 * `extras` Gladius writes on each glTF animation. The engine's `animate`
 * system reads the loop from it (Docs/render.md §5: `Animation.loop` 0 is as
 * the clip says), and the editor's Model tab the rest (its `model/clips.ts`).
 *
 * GLTFLoader leaves an animation's `extras` out, so the store puts them on the
 * clip's `userData` as it loads a model (`extrasOntoClips`), as three does for
 * a node's.
 *
 * Pure: no three, no DOM (`clip-info.test.ts`).
 */

/** What Gladius assumes when an action does not say. */
export const DEFAULT_FPS = 30;

/** A glTF animation's `extras`, as Gladius writes them -- any field may be missing (an imported GLB). */
export interface ClipExtras {
  loop?: unknown;
  duration?: unknown;
  fps?: unknown;
}

/** One clip, as the Model tab shows it. */
export interface ClipInfo {
  /** The action's name: what the script calls it, and three's clip. */
  name: string;
  /** Seconds: the file's `duration`, else the clip's own. */
  duration: number;
  /** Frames a second: the file's, else Gladius's default. */
  fps: number;
  /** As the file says; undefined from a GLB that does not (looped then, as a viewer is expected to). */
  loop: boolean | undefined;
  /** The nodes it moves, in its tracks' order: `Hips.quaternion` is `Hips`. */
  joints: string[];
  /** Samples summed over every track. */
  samples: number;
}

const positive = (v: unknown): number | undefined => (typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : undefined);

/** Whether the extras say the clip loops: undefined where they do not say (an imported GLB, or no extras). */
export const extrasLoop = (extras: ClipExtras | undefined | null): boolean | undefined => (typeof extras?.loop === 'boolean' ? extras.loop : undefined);

/** A clip read: its tracks' names (`node.property`), their samples, three's length, the file's extras. */
export function clipInfo(name: string, tracks: readonly { name: string; samples: number }[], duration: number, extras: ClipExtras | undefined): ClipInfo {
  const joints: string[] = [];
  let samples = 0;
  for (const track of tracks) {
    // `Hips.quaternion` → `Hips`: a node's name may hold dots, so only the property after the last goes.
    const dot = track.name.lastIndexOf('.');
    const joint = dot > 0 ? track.name.slice(0, dot) : track.name;
    if (!joints.includes(joint)) joints.push(joint);
    samples += track.samples;
  }
  return {
    name,
    duration: positive(extras?.duration) ?? Math.max(0, duration),
    fps: positive(extras?.fps) ?? DEFAULT_FPS,
    loop: extrasLoop(extras),
    joints,
    samples,
  };
}

/**
 * Each glTF animation's `extras` onto its clip's `userData`, as three does for
 * a node's: Gladius writes an action's `loop`, `duration` and `fps` there, and
 * GLTFLoader leaves an animation's out. The store does it for every model it
 * loads; the editor's previews for theirs.
 */
export function extrasOntoClips(gltf: { animations: readonly { userData: Record<string, unknown> }[]; parser?: { json?: { animations?: { extras?: unknown }[] } } }): void {
  const defs = gltf.parser?.json?.animations ?? [];
  gltf.animations.forEach((clip, i) => {
    const extras = defs[i]?.extras;
    if (typeof extras === 'object' && extras !== null) Object.assign(clip.userData, extras);
  });
}
