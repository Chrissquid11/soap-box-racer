/**
 * The material files, compiled (Docs/render.md §4): every
 * `src/assets/materials/**\/*.material` (JSON inside, read as JSON by the
 * pipeline's `prefabJson`), by key (`./materials/props/rust.material` is
 * `props/rust`), each made one shared three material -- `Assets.material(key)`,
 * what a `Render.material` puts on every mesh of a view.
 *
 * The rules:
 *   - **Bundled, not fetched**, as prefabs are: the project's generated
 *     `src/assets/material-bundle.ts` hands the files in (`useMaterialFiles`).
 *     A pack's come with its mount (`addPackMaterials`, `packs.ts`).
 *   - **Compiled once, after the preload** (`compileMaterials`, called by `boot`
 *     before the game is made, as `Prefabs.compile()` is): each file read whole
 *     (`material-file.ts`: a problem a line, the default in its place) into one
 *     `MeshStandardMaterial`, `MeshPhysicalMaterial`, `MeshBasicMaterial` or
 *     `MeshToonMaterial`, its maps the registry's textures by key -- `map` and
 *     `emissiveMap` sRGB, the rest linear -- a key the registry lacks said once,
 *     the material compiled without it. `userData.materialKey` is its key.
 *   - **Shared, never cloned by a game**: every view wearing a key wears the one
 *     object. One entity's own look is another material file, or a tint
 *     (`Render.tint`: the `render` system's clone for that view, which a file
 *     saved reaches too -- `changed` is told).
 *   - **Live** (the dev server alone hands the files in twice): a file saved
 *     re-evaluates the material bundle, and the changed file is compiled and its
 *     values set into the existing material (`setValues`, `needsUpdate`) -- the
 *     same object, so every view wearing it changes with no reattach. A `type`
 *     changed makes a new object (three has no way from one class to another);
 *     a file added, removed or so replaced is told to `onMaterialFiles`'
 *     listeners as `replaced`, and the engine's `render` system dresses the views
 *     wearing it again. A file removed: its views back to as authored (the
 *     `render` system says so as it dresses them), its material disposed a
 *     second later (`disposeLater`), once every view has let it go. Should a view
 *     still wear it then, three re-initialises a disposed material on its next
 *     draw: that view loses a frame of program cache and nothing else.
 *   - **A map's texture arriving late** (an export landing, a hot update adding
 *     it, a pack mounted after) is put on as it is stored (`onTextureStored`):
 *     each material whose last compile lacked that key is compiled again and
 *     told as changed and `replaced`, so the `render` system dresses its views
 *     again (`textureStored`).
 *
 * Page-side (three). `material-file.ts` is the pure half: the parse, the defaults.
 */
import * as THREE from 'three';
import { caseKey } from './case-key.ts';
import { syncMap, unchanged } from './hot.ts';
import { materialMaps, parseMaterialFile, usesField, type MaterialFile, type MaterialType } from './material-file.ts';
import { onTextureStored, textures } from './store.ts';

/** The boot set's files as handed in, by key: the path under `materials/` without `.material`, lowercased. */
const FILES = new Map<string, unknown>();
/** Each key's path under `materials/` as on disk, without `.material`. */
const NAMES = new Map<string, string>();
/** Every material compiled, the boot set's and the packs' (`reef:props/rust`), by key. */
const COMPILED = new Map<string, THREE.Material>();
/** What each was compiled from, read whole: what a live change is compared against. */
const READ = new Map<string, MaterialFile>();
/** Each key's problems at its last compile: its file's, and each map no texture has. */
const PROBLEMS = new Map<string, string[]>();
/** Each key's file as compiled and its pack's prefix (`''` the boot set's): what a late texture compiles again. */
const SOURCES = new Map<string, { json: unknown; prefix: string }>();
/** Each key's map keys no texture had at its last compile, as the file names them: what a late texture is looked for in. */
const MISSING = new Map<string, string[]>();
/** What a live change says, once: the problems already printed. */
const said = new Set<string>();
/** Whether `compileMaterials` has run: before it, a hot update only fills the map. */
let compiled = false;
let filled = false;
/** How many times the materials changed: a preview's key, so it is made again for a new object. */
let stamp = 0;

/** What a change to the materials was: the keys that came, went, changed in place, and those whose object is another now (or none). */
export interface MaterialsChange {
  added: string[];
  removed: string[];
  changed: string[];
  /** Added, removed, changed to another type, or a map's texture arrived late: what a view wearing it must be dressed again for. */
  replaced: string[];
}
const heard = new Set<(change: MaterialsChange) => void>();

/** Said once, on the console: a material's problem, a map no texture has. */
function sayOnce(line: string): void {
  if (said.has(line)) return;
  said.add(line);
  console.warn(`[materials] ${line}`);
}

/**
 * The project's material files taken in, by their path under `src/assets/`
 * (`./materials/props/rust.material`), and the ending a key is its path
 * without: the first time they fill the map; every later time -- a hot update
 * of the project's `material-bundle.ts`, dev only -- they are copied into it in
 * place, what changed is compiled again, and whoever listens is told.
 */
export function useMaterialFiles({ files, suffix }: { files: Record<string, unknown>; suffix: string }): void {
  const fresh = new Map<string, unknown>();
  const names = new Map<string, string>();
  for (const [path, file] of Object.entries(files)) {
    const name = path.replace('./materials/', '').slice(0, -suffix.length);
    fresh.set(caseKey(name), file);
    names.set(caseKey(name), name);
  }
  const change = syncMap(FILES, fresh);
  const renamed = syncMap(NAMES, names);
  if (!filled) {
    filled = true;
    return;
  }
  if (unchanged(change, renamed) || !compiled) return;
  const replaced: string[] = [];
  for (const key of change.removed) {
    retire(key);
    replaced.push(key);
  }
  for (const key of [...change.added, ...change.changed]) if (compileOne(key, FILES.get(key), '')) replaced.push(key);
  tell({ added: change.added, removed: change.removed, changed: change.changed, replaced });
}

/** Every listener told of a change, after the store holds it. */
function tell(change: MaterialsChange): void {
  stamp++;
  for (const listener of heard) listener(change);
}

/**
 * Told each time the materials change -- a file added, saved or removed in the
 * dev server, a pack's mounted or unmounted -- after the store holds them. The
 * engine's `render` system listens for `replaced`; the editor for the rest.
 * Returns the undo.
 */
export function onMaterialFiles(listener: (change: MaterialsChange) => void): () => void {
  heard.add(listener);
  return () => void heard.delete(listener);
}

/**
 * `material` disposed a second later: every view wearing it has been dressed again by then (and one
 * that has not costs a frame of program cache: three re-initialises it on its next draw). The timer
 * never holds node open (`unref`).
 */
function disposeLater(material: THREE.Material): void {
  const timer = setTimeout(() => material.dispose(), 1000) as { unref?: () => void };
  timer.unref?.();
}

/** `key`'s material taken out of the store, disposed a second later (`disposeLater`). */
function retire(key: string): void {
  const old = COMPILED.get(key);
  COMPILED.delete(key);
  READ.delete(key);
  PROBLEMS.delete(key);
  SOURCES.delete(key);
  MISSING.delete(key);
  if (old) disposeLater(old);
}

/** A new three material of `type`. */
function make(type: MaterialType): THREE.Material {
  switch (type) {
    case 'physical':
      return new THREE.MeshPhysicalMaterial();
    case 'basic':
      return new THREE.MeshBasicMaterial();
    case 'toon':
      return new THREE.MeshToonMaterial();
    default:
      return new THREE.MeshStandardMaterial();
  }
}

const SIDES = { front: THREE.FrontSide, back: THREE.BackSide, double: THREE.DoubleSide } as const;

/** The maps three reads as colour: sRGB. Every other map is data, linear. */
const COLOUR_MAPS: ReadonlySet<string> = new Set(['map', 'emissiveMap']);

/**
 * A texture by key for a material of `prefix` (`''` the boot set's, `reef:` a pack's): a pack's own
 * first, then the boot set's; null for none.
 */
function textureOf(key: string, prefix: string): THREE.Texture | null {
  if (prefix !== '' && !key.includes(':')) {
    const own = textures.get(`${prefix}${key}`);
    if (own) return own;
  }
  return textures.get(key) ?? null;
}

/**
 * What `setValues` is handed for `file`: every field its type draws with, the
 * default where the file says nothing -- so a field taken out of the file goes
 * back -- its maps the textures, each in its colour space. The maps no texture
 * has are pushed onto `missing` (`field 'key'`) and their keys onto `lacking`.
 */
function valuesOf(file: MaterialFile, prefix: string, missing: string[], lacking: string[]): Record<string, unknown> {
  const type = file.type;
  const v: Record<string, unknown> = {
    color: file.color,
    opacity: file.opacity,
    transparent: file.transparent,
    alphaTest: file.alphaTest,
    side: SIDES[file.side],
    wireframe: file.wireframe,
    depthWrite: file.depthWrite,
  };
  if (usesField(type, 'emissive')) {
    v.emissive = file.emissive;
    v.emissiveIntensity = file.emissiveIntensity;
  }
  if (usesField(type, 'roughness')) {
    v.roughness = file.roughness;
    v.metalness = file.metalness;
    v.flatShading = file.flatShading;
  }
  if (type === 'physical') Object.assign(v, file.physical);
  for (const field of ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'emissiveMap', 'alphaMap'] as const) {
    if (!usesField(type, field)) continue;
    v[field] = null;
  }
  for (const { field, key } of materialMaps(file)) {
    const texture = textureOf(key, prefix);
    if (!texture) {
      missing.push(`${field} '${key}'`);
      lacking.push(key);
      continue;
    }
    const space = COLOUR_MAPS.has(field) ? THREE.SRGBColorSpace : THREE.LinearSRGBColorSpace;
    if (texture.colorSpace !== space) {
      texture.colorSpace = space;
      texture.needsUpdate = true;
    }
    v[field] = texture;
  }
  return v;
}

/**
 * `json` compiled under `key` (with its pack's `prefix`): into the material it has if its type is the
 * same -- `setValues`, the same object -- else a new one. True if the key's object is another now
 * (made, or replaced for a type).
 */
function compileOne(key: string, json: unknown, prefix: string): boolean {
  const { file, problems } = parseMaterialFile(json);
  const missing: string[] = [];
  const lacking: string[] = [];
  const values = valuesOf(file, prefix, missing, lacking);
  SOURCES.set(key, { json, prefix });
  if (lacking.length > 0) MISSING.set(key, lacking);
  else MISSING.delete(key);
  const all = [...problems, ...missing.map((m) => `${m}: no such texture -- compiled without it (a file under src/assets/textures/, its path without the extension)`)];
  PROBLEMS.set(key, all);
  for (const p of all) sayOnce(`${key}: ${p}`);
  const had = COMPILED.get(key);
  const same = had !== undefined && READ.get(key)?.type === file.type;
  const material = same ? had : make(file.type);
  material.setValues(values);
  material.name = key;
  material.userData.materialKey = key;
  material.needsUpdate = true;
  READ.set(key, file);
  if (!same) {
    COMPILED.set(key, material);
    if (had) disposeLater(had);
  }
  return !same;
}

/** Does a map key `named` in a material of `prefix` resolve to texture `key` -- `textureOf`'s order: the pack's own, then the boot set's? */
const resolvesTo = (named: string, prefix: string, key: string): boolean => key === named || (prefix !== '' && !named.includes(':') && key === `${prefix}${named}`);

/**
 * A texture stored under `key` where none was (`onTextureStored`): each compiled material whose last
 * compile lacked it compiled again -- its map on now -- and told as changed and `replaced`, so the
 * `render` system dresses the views wearing it again. Nothing before the compile: it reads the
 * textures as they are then.
 */
function textureStored(key: string): void {
  if (!compiled || MISSING.size === 0) return;
  const again: string[] = [];
  for (const [material, lacking] of MISSING) {
    const source = SOURCES.get(material);
    if (source && lacking.some((named) => resolvesTo(named, source.prefix, key))) again.push(material);
  }
  if (again.length === 0) return;
  for (const material of again) {
    const source = SOURCES.get(material)!;
    compileOne(material, source.json, source.prefix);
  }
  tell({ added: [], removed: [], changed: again, replaced: again });
}
onTextureStored(textureStored);

/**
 * Every material file compiled into its shared three material: after
 * `Assets.preload()` (its textures are the registry's), before the game is
 * made. A problem is said once and the material compiled without what it
 * spoils. A second call compiles each again in place.
 */
export function compileMaterials(): void {
  for (const [key, json] of FILES) compileOne(key, json, '');
  compiled = true;
}

/**
 * `json` shown as `key`'s material now, its file untouched: the editor's Material block while a number
 * is scrubbed or a swatch dragged -- the file is written as it lets go, and compiles the same. Nothing
 * for a key not compiled.
 */
export function showMaterial(key: string, json: unknown): void {
  const k = caseKey(key);
  if (!compiled || !COMPILED.has(k)) return;
  // Told, a change in place too: a stopped game draws once for it (`Game`), as for a file saved.
  tell({ added: [], removed: [], changed: [k], replaced: compileOne(k, json, '') ? [k] : [] });
}

/** A pack's material files (`packs.ts`, after its textures are in), by key without the pack: compiled under `<pack>:<key>`. */
export function addPackMaterials(pack: string, files: ReadonlyMap<string, unknown>): void {
  const added: string[] = [];
  for (const [key, json] of files) {
    const full = caseKey(`${pack}:${key}`);
    compileOne(full, json, `${caseKey(pack)}:`);
    added.push(full);
  }
  if (added.length > 0) tell({ added, removed: [], changed: [], replaced: added });
}

/** Every material whose key starts with `prefix` -- a pack's, `reef:`; `''` all -- taken out and disposed. */
export function dropMaterials(prefix: string): void {
  const removed: string[] = [];
  for (const key of [...COMPILED.keys()]) {
    if (!key.startsWith(prefix)) continue;
    retire(key);
    removed.push(key);
  }
  if (removed.length > 0) tell({ added: [], removed, changed: [], replaced: removed });
}

/** The shared material of a key in any case, or null for none: what the `render` system puts on a view. */
export function materialIfPresent(key: string): THREE.Material | null {
  return COMPILED.get(caseKey(key)) ?? null;
}

/** Every material key compiled now, sorted: the boot set's and a mounted pack's. */
export function materialKeys(): string[] {
  return [...COMPILED.keys()].sort();
}

/** Is `key` (any case) a material file of the boot set: what a prefab compile checks a `Render.material` against. */
export function hasMaterialFile(key: string): boolean {
  return FILES.has(caseKey(key));
}

/** A material file as handed in (its parsed JSON), by key; undefined for none. The editor's way to what is on disk. */
export function materialFile(key: string): unknown {
  return FILES.get(caseKey(key));
}

/** A key's path under `materials/` as on disk, without `.material`: the editor's way from a key to its file. */
export function materialName(key: string): string | undefined {
  return NAMES.get(caseKey(key));
}

/** Every material file of the boot set as handed in, by key. */
export function materialFiles(): Record<string, unknown> {
  return Object.fromEntries(FILES);
}

/** `key`'s problems at its last compile -- its file's, and each map no texture has -- none for a clean one or no key. */
export function materialProblems(key: string): readonly string[] {
  return PROBLEMS.get(caseKey(key)) ?? [];
}

/** How many times the materials changed: a preview's key, so a new object is shown. */
export function materialsStamp(): number {
  return stamp;
}
