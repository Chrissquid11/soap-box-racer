/**
 * Finding a model's own textures.
 *
 * A `.glb` may keep its images outside itself, named by a URI the exporter
 * wrote -- `browncrab2-stylized-diffuse.png`, or `textures/shell.png`, or
 * something with a path from the artist's own disk in it. None of those mean
 * anything to a bundled build, where every asset has been hashed:
 * `browncrab2-stylized-diffuse-mKjq7A12.png`, in `dist/assets/`, next to
 * nothing in particular.
 *
 * So a URI is resolved by **name**, in the order a person would look:
 *
 *   1. the model's own folder -- `models/characters/` for `characters/crab`
 *   2. `textures/`, the folder that exists for exactly this
 *   3. the URI as written, which is what a data: URI or an absolute URL wants
 *
 * The model's folder wins because that is where an exporter puts an image it
 * wrote beside the file, and because two crabs may each have a `diffuse.png`.
 *
 * Its own module, and pure: the registry's lookup is handed in (`pathUrl`), so
 * this one is tested without the project's globs.
 */

/** What a lookup needs to know: a path under a kind's folder -> its built URL. */
export type Lookup = (kind: 'models' | 'textures', path: string) => string | undefined;

/**
 * The file's own name, with any folders, query and fragment taken off.
 *
 * glTF URIs are percent-encoded, and an exporter writing a Windows path leaves
 * backslashes in -- `..\textures\shell.png` is one file called `shell.png`.
 */
export function fileName(uri: string): string {
  let name = uri;
  try {
    name = decodeURIComponent(name);
  } catch {
    // A malformed escape is not worth failing a load over; use it as written.
  }
  // A fragment is how an exporter points inside another file
  // (`other.glb#image0`). There is no such file here, so the name before it is
  // the best guess, and a miss is the honest answer.
  const hash = name.indexOf('#');
  if (hash >= 0) name = name.slice(0, hash);
  const query = name.indexOf('?');
  if (query >= 0) name = name.slice(0, query);
  name = name.split('\\').join('/');
  return name.slice(name.lastIndexOf('/') + 1);
}

/** The folder a model key sits in: `characters/crab` -> `characters/`, `crab` -> ``. */
export function folderOf(modelKey: string): string {
  const slash = modelKey.lastIndexOf('/');
  return slash < 0 ? '' : modelKey.slice(0, slash + 1);
}

/**
 * Where a model's image really lives, or null to leave the URI alone.
 *
 * `modelKey` is the model being loaded (`characters/crab`), `uri` what its glTF
 * asked for. A `data:`, `blob:` or `http:` URI is left alone: it carries its own
 * bytes or its own host, and a name lookup would be guessing at something that
 * already works.
 *
 * **Except an absolute URL in the model's own folder**, given `modelUrl`. A
 * production build names every asset `new URL('crab-x.glb', import.meta.url)`,
 * so a model is loaded from `https://host/game/assets/crab-x.glb` and its image
 * URI is resolved against that before it arrives here:
 * `https://host/game/assets/browncrab2-stylized-diffuse.png`, which is exactly
 * the rooted case below with a host in front -- and was left alone, so the
 * crab loaded white in every build and never on the dev server, whose URLs are
 * rooted. A URL somewhere else is still somebody else's.
 *
 * **A rooted path is not left alone**, which looks wrong and is not: a model
 * loaded by URL has its image URIs resolved against the build's own asset folder
 * before anything sees them, so `browncrab2-stylized-diffuse.png` arrives here as
 * `/assets/browncrab2-stylized-diffuse.png` -- a file that does not exist,
 * because the built one is hashed. The name is the only part worth trusting, and
 * a rooted path that is nothing of ours matches nothing and is returned
 * unchanged anyway.
 */
export function resolveBeside(modelKey: string, uri: string, lookup: Lookup, modelUrl?: string): string | null {
  if (/^(data:|blob:)/i.test(uri)) return null;
  if (/^(https?:|\/\/)/i.test(uri)) {
    const folder = modelUrl ? modelUrl.slice(0, modelUrl.lastIndexOf('/') + 1) : '';
    if (!folder || !/^(https?:|\/\/)/i.test(folder) || !uri.startsWith(folder)) return null;
  }

  const name = fileName(uri);
  if (!name) return null;

  // 1. Beside the model.
  const beside = lookup('models', folderOf(modelKey) + name);
  if (beside) return beside;

  // 2. The textures folder: first where the URI pointed, then by name alone, so
  //    `textures/shell.png` and `shell.png` both find `textures/shell.png`.
  const asWritten = fileName(uri) === uri ? null : lookup('textures', uri.split('\\').join('/'));
  if (asWritten) return asWritten;
  const byName = lookup('textures', name);
  if (byName) return byName;

  // 3. Nothing of ours. Let the loader try the URI, and fail on its own terms.
  return null;
}
