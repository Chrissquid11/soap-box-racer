/**
 * A key's one spelling (CLAUDE.md, "Keys are the path lowercased"): a file
 * keeps its name on disk -- `models/props/Big Crate.glb` -- and its key is its
 * path under the kind's folder, without the extension, **lowercased**:
 * `props/big crate`. Spaces stay spaces. Unicode is normalized to NFC first,
 * since macOS may hand a name back decomposed (NFD), and `é` must be one key
 * however it was typed.
 *
 * - **Every key stored is this form**: the generated `keys.d.ts`, the
 *   registry's maps, levels, prefabs, scenes, packs, a prefab file's model and
 *   nested refs as the compile reads them, scene saves.
 * - **Every lookup lowercases at the door** (`caseKey(key)`), so
 *   `Assets.instance('Props/CRATE')` finds `props/crate`; and its type
 *   (`AnyCase`) takes any spelling whose `Lowercase<>` is a known key.
 * - **Two names one key are refused** -- `Crate.glb` beside `crate.glb` -- by
 *   the key generator, the index and the editor (`packages/pipeline/src/assets/paths.ts`'
 *   `validName`).
 * - **URLs keep the real case**: they come from Vite's globs, never from a key.
 *
 * Pure and import-free: the game, the editor, the pipeline and node tests share it.
 */

/** A key (or a path) in its one spelling: NFC, lowercase. */
export function caseKey(key: string): string {
  return key.normalize('NFC').toLowerCase();
}

/**
 * A key parameter that takes any spelling of a known key: `K` itself when
 * `Lowercase<K>` is one of `Known`, else `Known` -- so a typo's error lists
 * the keys there are: `Argument of type '"props/crat"' is not assignable to
 * parameter of type '"props/crate" | "props/parrot"'`. Used as
 * `<const K extends string>(key: AnyCase<K, AssetKeys.Model>)`; a key typed as
 * the union itself passes as ever.
 */
export type AnyCase<K extends string, Known extends string> = Lowercase<K> extends Known ? K : Known;
