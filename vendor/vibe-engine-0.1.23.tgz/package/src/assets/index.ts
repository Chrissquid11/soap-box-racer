/**
 * Loading and lookup for game media.
 *
 * Two sources, one API. `preload()` loads what shipped in the build -- the
 * boot set, kept small so the game is playable in a second or two -- and
 * `mount()` fetches a pack later for a new level. Both end up in the same
 * store, so nothing downstream knows or cares which an asset came from.
 *
 * Keys for built-in assets come from the folder structure --
 * `models/characters/crab.glb` is `Assets.instance('characters/crab')` -- and
 * pack assets carry their pack as a prefix: `'reef:props/coral'`. A key is the
 * path lowercased (`caseKey`), and every lookup here takes any case:
 * `Assets.instance('Characters/Crab')` is the same model. Both are
 * checked by the compiler through the generated `keys.d.ts` (`AnyCase`: any
 * spelling whose lowercase is a key), so a key from an unmounted pack still
 * typechecks and fails loudly at runtime.
 *
 * Nothing in here touches the page's DOM, so `game.ts` may import it.
 */
import * as THREE from 'three';
import { clone as cloneSkinned } from 'three/addons/utils/SkeletonUtils.js';
import type { GLTF } from 'three/addons/loaders/GLTFLoader.js';
import { Audio } from '../audio.ts';
import type { Atlas } from './atlas.ts';
import { resolveBeside } from './beside.ts';
import { type AnyCase, caseKey } from './case-key.ts';
import { dropMaterials, hasMaterialFile, materialIfPresent, materialKeys } from './materials.ts';
import { keyKinds, kindKeys } from './kind-keys.ts';
import { instancePart, partNames } from './parts.ts';
import { data, dataKeys } from '../data.ts';
import type { MountOptions } from './packs.ts';
import { entries, onKeysChanged, pathUrl, sibling, url, type Kind } from './registry.ts';
import { addAtlas, addModel, addTexture, atlases, drop, forget, models, textures, useRenderer } from './store.ts';

let ready = false;
/** Told of a pack about to be unmounted, before its assets are freed (`Assets.onUnmount`). */
const unmounting: ((pack: AssetKeys.Pack) => void)[] = [];

/** A key's value, the key taken in any case (`caseKey`). */
function get<T>(store: Map<string, T>, key: string, what: string): T {
  const value = store.get(caseKey(key));
  if (value) return value;

  const pack = key.includes(':') ? key.slice(0, key.indexOf(':')) : null;
  throw new Error(
    pack
      ? `${what} '${key}' needs its pack -- await Assets.mount('${pack}') first`
      : ready
        ? `no ${what} '${key}' -- nothing under src/assets matches that key`
        : `${what} '${key}' used before Assets.preload() finished`,
  );
}

export interface PreloadOptions {
  /** 0..1, called as each file lands. Wire it to the loading bar. */
  onProgress?: (fraction: number) => void;
  /**
   * The game's renderer, if it exists yet. Only matters for `.ktx2` textures.
   *
   * Usually it does not: the Game builds its world in its constructor, so
   * `preload()` has to finish before there is a renderer to pass. Call
   * `Assets.useRenderer()` once the Game exists instead -- packs mounted later
   * are the case that benefits.
   */
  renderer?: THREE.WebGLRenderer;
}

export const Assets = {
  /**
   * Loads everything under `src/assets/`. Call once, before the game builds
   * its world.
   *
   * This is the boot set and it gates the first frame, so keep it to what the
   * menu and the first round actually need. Anything else belongs in a pack.
   */
  async preload({ onProgress, renderer }: PreloadOptions = {}): Promise<void> {
    if (ready) return;
    useRenderer(renderer);

    const modelEntries = entries('models');
    const textureEntries = entries('textures');
    const atlasEntries = entries('atlases');

    let done = 0;
    const total = modelEntries.length + textureEntries.length + atlasEntries.length + Audio.pending();
    // Nothing to load yet: report a finished bar rather than dividing by zero.
    const step = (): void => onProgress?.(total === 0 ? 1 : ++done / total);

    await Promise.all([
      ...modelEntries.map(async ([key, href]) => {
        // A model's own textures, by name: its folder first, then `textures/`.
        await addModel(key, { url: href }, (uri) => resolveBeside(key, uri, pathUrl, href));
        step();
      }),
      ...textureEntries.map(async ([key, href]) => {
        await addTexture(key, { url: href });
        step();
      }),
      ...atlasEntries.map(async ([key, href]) => {
        const json = await fetch(sibling('atlases', key, '.json')).then((r) => r.json());
        await addAtlas(key, { url: href }, json);
        step();
      }),
      Audio.preload(step),
    ]);

    ready = true;
    onProgress?.(1);
  },

  /**
   * A data file's parsed contents, by its kind and its key in any case: a level (`'levels'`), or a
   * file of the project's own kind (`vibe({ kinds })` in its vite.config.ts: `Assets.data('tilemaps',
   * 'town')`). Bundled, so synchronous; the key checked against the kind's union (`AssetKeys.DataKinds`).
   * Throws for a key that is not there.
   */
  data<K extends keyof AssetKeys.DataKinds & string, const Key extends string>(kind: K, key: AnyCase<Key, AssetKeys.DataKinds[K]>): unknown {
    return data(kind, key);
  },

  /** Every key of a data kind, sorted: for a picker. */
  dataKeys<K extends keyof AssetKeys.DataKinds & string>(kind: K): AssetKeys.DataKinds[K][] {
    return dataKeys(kind);
  },

  /**
   * Downloads and mounts an asset pack, making `'<pack>:...'` keys usable.
   *
   * Imported dynamically so the zip reader and pack plumbing stay out of the
   * bundle every player downloads -- a game that never mounts a pack never
   * pays for the ability to.
   *
   * Decoding a large pack will drop frames: mount between rounds, with
   * gameplay stopped, not mid-round.
   */
  async mount<const K extends string>(name: AnyCase<K, AssetKeys.Pack>, options?: MountOptions): Promise<void> {
    const { Packs } = await import('./packs.ts');
    return Packs.mount(caseKey(name), options);
  },

  /**
   * Frees everything a pack added, GPU memory included. Whoever asked
   * (`onUnmount`) lets go of its models first: the game drains the pools of
   * every prefab drawing one, and destroys their instances out for real
   * (Docs/prefabs.md §5), so no pooled instance is left holding a disposed
   * geometry. An unpooled instance out is the game's to destroy first.
   */
  async unmount<const K extends string>(name: AnyCase<K, AssetKeys.Pack>): Promise<void> {
    const { Packs } = await import('./packs.ts');
    const pack = caseKey(name) as AssetKeys.Pack;
    for (const before of unmounting) before(pack);
    Packs.unmount(pack);
  },

  /** `before(pack)` called each time a pack is unmounted, before its assets are freed: `Game` (`game.ts`) drains its pools there, instances out included. */
  onUnmount(before: (pack: AssetKeys.Pack) => void): void {
    unmounting.push(before);
  },

  /**
   * Forgets every downloaded pack zip, so the next mount re-downloads.
   *
   * Only needed when testing a pack you have just rebuilt under the same name,
   * or to reclaim storage. Pack URLs are content-hashed, so a *changed* pack
   * gets a new URL and never needs this to be seen.
   */
  async clearPackCache(): Promise<void> {
    const { Packs } = await import('./packs.ts');
    await Packs.clearCache();
  },

  /** Pack names the server is currently offering -- including any added since this build. */
  async availablePacks(): Promise<string[]> {
    const { Packs } = await import('./packs.ts');
    return Packs.available();
  },

  /** The parsed glTF, shared. Use `instance()` unless you mean to mutate it. */
  model: <const K extends string>(key: AnyCase<K, AssetKeys.Model>): GLTF => get(models, key, 'model'),

  /**
   * The parsed glTF for a key only known at runtime, or null.
   *
   * For data that names a model the compiler cannot check -- a preset,
   * level data, eventually a player's save. Returning null rather than
   * throwing is the point: content can name a part before the art exists, and a
   * renamed or unmounted file degrades to whatever the caller falls back to
   * instead of taking the frame down.
   *
   * Everything with a key it can name at build time should use `model()` or
   * `instance()` and get its typo caught by `tsc`.
   */
  modelIfPresent: (key: string): GLTF | null => models.get(caseKey(key)) ?? null,

  /**
   * Every model key currently loaded, sorted.
   *
   * For a picker that has to show what is actually on disk. Nothing in the game
   * should need this -- code that knows which model it wants names it and gets
   * the typo caught -- but a tool offering a choice cannot know the list ahead
   * of time, and enumerating beats hardcoding one that goes stale.
   */
  modelKeys: (): string[] => [...models.keys()].sort(),

  /**
   * Every model key sitting under a folder, sorted.
   *
   * The folder *is* the category. `parts('characters')` is every model in that
   * folder, and adding one is copying a file in -- the same bargain the rest of
   * the asset system makes, one level deeper. A folder with nothing in it
   * returns nothing.
   *
   * Pack keys carry their pack as a prefix (`reef:characters/x`), so the match is
   * made on the path after the colon. A part that ships in a pack therefore
   * turns up here the moment the pack is mounted, with nothing else to change --
   * which is the escape hatch for the boot-set budget, since everything in
   * `src/assets/` downloads before the first frame.
   */
  parts: (folder: string): string[] => {
    const under = `${caseKey(folder)}/`;
    return [...models.keys()]
      .filter((key) => {
        const path = key.includes(':') ? key.slice(key.indexOf(':') + 1) : key;
        return path.startsWith(under);
      })
      .sort();
  },

  /**
   * A fresh copy of a model's scene, safe to place and animate on its own --
   * or, given `part`, of the object of that name in it (a Gladius `part{ name }`
   * is a node of that name; any case), with what is under it, inside a group at
   * the model's origin and placed as the model places it, however deep
   * (`parts.ts`; a skinned part whose bones are outside it throws). Uses SkeletonUtils
   * so a rigged mesh keeps a working skeleton -- a plain `.clone()` leaves every
   * copy bound to the original's bones. Shadows are as the file has them: the
   * engine's `render` system sets them from `Render` (Docs/render.md §3). A part
   * the model lacks throws, naming the parts it has (`partsOf`). The copy's
   * `userData.assetKey` is the model's key, and a part's `assetPart` its name,
   * so a re-export finds it (`swap`, the editor's).
   */
  instance<const K extends string>(key: AnyCase<K, AssetKeys.Model>, part?: string | null): THREE.Object3D {
    const scene = get(models, key, 'model').scene;
    if (part === undefined || part === null || part === '') return cloneSkinned(scene);
    // Placed as the glb places it under the model's root: parts drawn by entities at one place put the model together again.
    return instancePart(scene, key, part);
  },

  /** The named objects of a model's scene (what a `Render.model` part names), sorted; none for a key that is not loaded. */
  partsOf: (key: string): string[] => {
    const gltf = models.get(caseKey(key));
    return gltf ? partNames(gltf.scene) : [];
  },

  /**
   * Every key of an asset kind the project has, sorted, by its key type -- for a `key(kind)` field's picker (the
   * editor's, Docs/properties.md D6): `'Model'`, `'Texture'`, `'Material'`, `'Prefab'`, `'Scene'`, `'Level'`,
   * `'Sfx'`, `'UiSfx'`, `'Music'`, `'Atlas'`, `'Icon'`, `'Font'`, a project's own data kind (`'Tilemap'`): what is
   * loaded, what the bundle has, and every asset the uid index knows -- a mounted pack's under its prefix
   * (`kind-keys.ts`). A pack not mounted has none listed. `'Clip'` none: a clip is a name among one model's clips
   * (`Assets.model(key).animations`), which the editor's clip picker lists per entity.
   */
  /** Every key type the project's pipeline has (`Sfx`, `Prefab`, its own `Tilemap` …), as its bundle handed them in: what a `key(kind)` field may hold, `Clip` aside. */
  keyKinds: (): string[] => keyKinds(),

  keysOf: (kind: string): string[] => (kind === 'Clip' ? [] : kindKeys(kind, kind === 'Model' ? models.keys() : kind === 'Texture' ? textures.keys() : kind === 'Material' ? materialKeys() : kind === 'Atlas' ? atlases.keys() : [])),

  /**
   * A material file's shared three material (Docs/render.md §4: `src/assets/materials/<key>.material`,
   * compiled after the preload). Shared by every view wearing it: never write into it -- one entity's
   * own look is another material file. Throws for a key that is not there.
   */
  material: <const K extends string>(key: AnyCase<K, AssetKeys.Material>): THREE.Material => {
    const found = materialIfPresent(key);
    if (found) return found;
    const pack = key.includes(':') ? key.slice(0, key.indexOf(':')) : null;
    throw new Error(pack ? `material '${key}' needs its pack -- await Assets.mount('${pack}') first` : `no material '${key}' -- nothing under src/assets/materials matches that key (or the materials are not compiled yet: boot compiles them after the preload)`);
  },

  /** A material for a key only known at runtime, or null: what the `render` system's `Render.material` resolves through. */
  materialIfPresent: (key: string): THREE.Material | null => materialIfPresent(key),

  /**
   * What a prefab compile asks of the assets (`CompileOptions`): is a key a model loaded now -- a pack's
   * (`reef:props/coral`) passes, as its pack may not be mounted -- and a model's parts, for a `#part`;
   * is a key a material file (a pack's passes the same way).
   */
  prefabChecks: {
    material: (key: string): boolean => key.includes(':') || hasMaterialFile(key),
    model: (key: string): boolean => key.includes(':') || models.has(caseKey(key)),
    parts: (key: string): readonly string[] | null => {
      if (key.includes(':')) return null;
      const gltf = models.get(caseKey(key));
      return gltf ? partNames(gltf.scene) : null;
    },
  },

  texture: <const K extends string>(key: AnyCase<K, AssetKeys.Texture>): THREE.Texture => get(textures, key, 'texture'),
  atlas: <const K extends string>(key: AnyCase<K, AssetKeys.Atlas>): Atlas => get(atlases, key, 'atlas'),

  /** Icons and fonts are not decoded -- these are hashed URLs for CSS or FontLoader. */
  iconUrl: <const K extends string>(key: AnyCase<K, AssetKeys.Icon>): string => url('icons', key),
  fontUrl: <const K extends string>(key: AnyCase<K, AssetKeys.Font>): string => url('fonts', key),

  /**
   * Hands over the game's renderer, so a pack mounted later can decode `.ktx2`.
   *
   * Without it the KTX2 loader has to spin up a throwaway WebGL context just to
   * read the GPU's list of supported compression formats, which on a mobile
   * browser holding one context already is a real cost. Call it once, as soon
   * as the Game exists.
   */
  useRenderer(renderer: THREE.WebGLRenderer): void {
    useRenderer(renderer);
  },

  /**
   * Frees everything, packs included. Rarely needed -- assets live for the session.
   *
   * Audio goes too, and so does the record of which packs were mounted: leaving
   * that behind would make the next `mount()` of a disposed pack a no-op, and
   * every key from it would throw for the rest of the session.
   */
  dispose(): void {
    dropMaterials('');
    drop('');
    Audio.drop('');
    ready = false;
  },
};

/** A key that arrived with a hot update, decoded into the store as `preload` would have. Icons and fonts are URLs: nothing to do. */
async function decodeAdded(kind: Kind, key: string, href: string): Promise<void> {
  switch (kind) {
    case 'models':
      return addModel(key, { url: href }, (uri) => resolveBeside(key, uri, pathUrl, href));
    case 'textures':
      return addTexture(key, { url: href });
    case 'atlases':
      return addAtlas(key, { url: href }, await fetch(sibling('atlases', key, '.json')).then((r) => r.json()));
    case 'sfx':
    case 'uiSfx':
      return Audio.addSound(key, await fetch(href).then((r) => r.arrayBuffer()));
    case 'music': {
      const response = await fetch(href);
      return Audio.addPackTrack(key, new Uint8Array(await response.arrayBuffer()), response.headers.get('content-type') ?? 'audio/ogg');
    }
    case 'icons':
    case 'fonts':
      return;
  }
}

// A file dropped into src/assets/ has a working key a moment later, and one removed is forgotten -- no page
// reload (Docs/assets.md §5). Only the dev server hands the globs in twice (`useBundle`, `bundle.ts`). This
// listener and `decodeAdded` ship in a release too -- the engine holds no `import.meta.hot` to fold them away
// by -- and are never called there: some thirty lines, every method they call shipping anyway.
onKeysChanged(({ added, removed }) => {
  for (const { kind, key } of removed) {
    if (kind === 'sfx' || kind === 'uiSfx' || kind === 'music') Audio.forget(key);
    else forget(key);
  }
  for (const { kind, key, url: href } of added) {
    decodeAdded(kind, key, href).catch((err: unknown) => console.error(`[assets] the new ${kind} '${key}' could not be loaded:`, err));
  }
});
// An export written again over the last (`reload`) is not heard here: the page keeps running, and the
// editor's `watchAssets` (Docs/assets.md §8), installed at boot on the dev server, swaps it into what is
// drawn and logs the one line that says what it did.

export type { GLTF };
