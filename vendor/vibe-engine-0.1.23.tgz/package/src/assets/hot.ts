/**
 * Hot updates of the project's generated globs, copied into the maps everyone
 * holds (Docs/assets.md §5): what `useBundle` and `usePrefabFiles` do on every
 * call but the first.
 *
 * A file dropped into `src/assets/`, removed, or re-exported changes what a glob
 * takes, so Vite updates `globs.ts` (or another glob file) and walks to its one
 * importer, the project's generated `bundle.ts` (or `prefab-bundle.ts`), which
 * accepts the update itself -- no page reload. That bundle alone is evaluated
 * again and hands the fresh globs in once more; the engine's modules are not,
 * so their maps are the live ones every importer has held all session. The
 * fresh maps are copied into them **in place** (`sync`, `syncMap`), saying which
 * keys came and went -- and, `syncMap`, which kept keys hold another object now.
 *
 * Pure and free of `import.meta.glob`, so a node test covers it (`hot.test.ts`).
 */

/** Keys a hot update added (with their URLs) and removed, by kind. */
export interface KeysChange<K extends string> {
  added: Array<{ kind: K; key: string; url: string }>;
  removed: Array<{ kind: K; key: string }>;
}

export type KeysListener<K extends string> = (change: KeysChange<K>) => void;

/** The registry's maps, by kind: key -> URL, path -> URL (keys and what goes beside them), and the same path lowercased (`caseKey`) -> URL, for a lookup in any case. */
export interface Maps<K extends string> {
  KEYS: Record<K, Map<string, string>>;
  PATHS: Record<K, Map<string, string>>;
  CASED: Record<K, Map<string, string>>;
}

/**
 * `fresh` copied into `live`, in place: every entry set, none left that `fresh` lacks. The keys that came
 * and went, and those kept whose value is another object (`changed`: an edited file is a new module object,
 * an untouched one the same) -- all three empty when nothing differs.
 */
/** What `syncMap` says: the keys that came, went, and kept their key with another value. */
export interface MapChange {
  added: string[];
  removed: string[];
  changed: string[];
}

/** Nothing came, went or changed: the same files handed in again. */
export const unchanged = (...changes: MapChange[]): boolean => changes.every((c) => c.added.length + c.removed.length + c.changed.length === 0);

export function syncMap<V>(live: Map<string, V>, fresh: ReadonlyMap<string, V>): MapChange {
  const added: string[] = [];
  const removed: string[] = [];
  const changed: string[] = [];
  for (const key of [...live.keys()]) {
    if (fresh.has(key)) continue;
    live.delete(key);
    removed.push(key);
  }
  for (const [key, value] of fresh) {
    if (!live.has(key)) added.push(key);
    else if (live.get(key) !== value) changed.push(key);
    live.set(key, value);
  }
  return { added, removed, changed };
}

/** The fresh maps copied into the live ones, kind by kind, in place: the keys added and removed. */
export function sync<K extends string>(live: Maps<K>, fresh: Maps<K>): KeysChange<K> {
  const change: KeysChange<K> = { added: [], removed: [] };
  for (const kind of Object.keys(fresh.KEYS) as K[]) {
    live.KEYS[kind] ??= new Map();
    live.PATHS[kind] ??= new Map();
    live.CASED ??= {} as Record<K, Map<string, string>>;
    live.CASED[kind] ??= new Map();
    const keys = syncMap(live.KEYS[kind], fresh.KEYS[kind]);
    syncMap(live.PATHS[kind], fresh.PATHS[kind]);
    syncMap(live.CASED[kind], fresh.CASED[kind]);
    for (const key of keys.removed) change.removed.push({ kind, key });
    for (const key of keys.added) change.added.push({ kind, key, url: fresh.KEYS[kind].get(key)! });
  }
  return change;
}
