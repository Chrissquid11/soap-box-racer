/**
 * A material file (Docs/render.md §4): `src/assets/materials/<key>.material`,
 * JSON inside -- its type, its colours, its numbers, its maps as texture keys --
 * read here into one shape, every field there, with what is wrong with it said.
 *
 *   {
 *     "is": "vibebase.material", "version": 1,
 *     "type": "standard",                       // standard | physical | basic | toon
 *     "color": "#c8a060", "roughness": 0.7, "metalness": 0,
 *     "emissive": "#000000", "emissiveIntensity": 1,
 *     "map": { "uid": "uid://…", "key": "crate/wood" }, "normalMap": null,   // textures: { uid, key } or the key alone, null or absent for none
 *     "opacity": 1, "transparent": false, "alphaTest": 0, "side": "front",
 *     "flatShading": false, "wireframe": false, "depthWrite": true,
 *     "physical": { "clearcoat": 0, "clearcoatRoughness": 0, "transmission": 0, "ior": 1.5, "thickness": 0 }
 *   }
 *
 * The rules:
 *   - **Only what differs from the defaults is written** (`MATERIAL_DEFAULTS`,
 *     `materialDiff`, `materialText`): a file is its changes, as a prefab's is.
 *   - **A problem is a line, never a throw** (`parseMaterialFile`): it names the
 *     field and why, and the default stands in its place -- a colour that is no
 *     `#rrggbb`, a number that is none, a type there is not. A field the type
 *     has no use for (`roughness` on a `basic`) is said once and ignored; a key
 *     the format lacks is said with its nearest. The engine compiles what is
 *     left (`assets/materials.ts`); the pipeline's `materials` check fails on any.
 *   - **A map is a reference to a texture** (Docs/asset-ids.md §3): `{ uid, key }`,
 *     or the key alone, read by its uid first (`resolveRef`: a moved texture's
 *     stale key read right) and lowercased (`caseKey`) as every key is; written
 *     with its uid where the index knows one (`materialDiff`, `keyRef`). That it
 *     names a texture is the compile's and the check's to say -- this module
 *     knows no assets but the uid index.
 *
 * Pure: imports `case-key.ts` and the uid index (`uids.ts`, itself `case-key`'s alone), so node, the pipeline's
 * check (`@vibe/engine/material-file`) and the editor share it (`material-file.test.ts`).
 */
import { caseKey } from './case-key.ts';
import { isKeyRef, keyRef, resolveRef, type KeyRef } from './uids.ts';

/** The kinds of three material a file can be. */
export const MATERIAL_TYPES = ['standard', 'physical', 'basic', 'toon'] as const;
export type MaterialType = (typeof MATERIAL_TYPES)[number];

/** Which faces are drawn. */
export const MATERIAL_SIDES = ['front', 'back', 'double'] as const;
export type MaterialSide = (typeof MATERIAL_SIDES)[number];

/** The map fields, each a texture key or null. */
export const MATERIAL_MAPS = ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'emissiveMap', 'alphaMap'] as const;
export type MaterialMap = (typeof MATERIAL_MAPS)[number];

/** A `physical` material's own numbers. */
export interface PhysicalFields {
  clearcoat: number;
  clearcoatRoughness: number;
  transmission: number;
  ior: number;
  thickness: number;
}

/** A material file read whole: every field, the defaults where it says nothing. */
export interface MaterialFile {
  is: 'vibebase.material';
  version: 1;
  type: MaterialType;
  /** `#rrggbb`, lowercase. */
  color: string;
  roughness: number;
  metalness: number;
  emissive: string;
  emissiveIntensity: number;
  map: string | null;
  normalMap: string | null;
  roughnessMap: string | null;
  metalnessMap: string | null;
  aoMap: string | null;
  emissiveMap: string | null;
  alphaMap: string | null;
  opacity: number;
  transparent: boolean;
  alphaTest: number;
  side: MaterialSide;
  flatShading: boolean;
  wireframe: boolean;
  depthWrite: boolean;
  physical: PhysicalFields;
}

/** A field of the file but `is`, `version` and `physical`: what the editor draws a line of. */
export type MaterialField = Exclude<keyof MaterialFile, 'is' | 'version' | 'physical'>;

/** What a file says when it says nothing: three's own defaults, a white `standard`. */
export const MATERIAL_DEFAULTS: Readonly<MaterialFile> = Object.freeze({
  is: 'vibebase.material',
  version: 1,
  type: 'standard',
  color: '#ffffff',
  roughness: 1,
  metalness: 0,
  emissive: '#000000',
  emissiveIntensity: 1,
  map: null,
  normalMap: null,
  roughnessMap: null,
  metalnessMap: null,
  aoMap: null,
  emissiveMap: null,
  alphaMap: null,
  opacity: 1,
  transparent: false,
  alphaTest: 0,
  side: 'front',
  flatShading: false,
  wireframe: false,
  depthWrite: true,
  physical: Object.freeze({ clearcoat: 0, clearcoatRoughness: 0, transmission: 0, ior: 1.5, thickness: 0 }),
}) as Readonly<MaterialFile>;

/** The fields in the file's order, after `is`, `version` and `type`: what `materialDiff` writes them in. */
export const MATERIAL_FIELDS: readonly MaterialField[] = [
  'type', 'color', 'roughness', 'metalness', 'emissive', 'emissiveIntensity',
  ...MATERIAL_MAPS,
  'opacity', 'transparent', 'alphaTest', 'side', 'flatShading', 'wireframe', 'depthWrite',
];

/** A `physical` block's fields, in order. */
export const PHYSICAL_FIELDS: readonly (keyof PhysicalFields)[] = ['clearcoat', 'clearcoatRoughness', 'transmission', 'ior', 'thickness'];

/** What every type draws with: the base `Material`'s and the mesh's own. */
const COMMON: readonly MaterialField[] = ['type', 'color', 'map', 'aoMap', 'alphaMap', 'opacity', 'transparent', 'alphaTest', 'side', 'wireframe', 'depthWrite'];
/** What a lit material adds: its glow and its normals. */
const LIT: readonly MaterialField[] = ['emissive', 'emissiveIntensity', 'emissiveMap', 'normalMap'];
/** What a physically based one adds: its surface, and flat shading. */
const PBR: readonly MaterialField[] = ['roughness', 'metalness', 'roughnessMap', 'metalnessMap', 'flatShading'];

/** Each type's fields: what three's material of that type has (`MeshBasicMaterial` no light, `MeshToonMaterial` no surface). */
export const FIELDS_OF: Readonly<Record<MaterialType, ReadonlySet<MaterialField>>> = {
  standard: new Set([...COMMON, ...LIT, ...PBR]),
  physical: new Set([...COMMON, ...LIT, ...PBR]),
  basic: new Set(COMMON),
  toon: new Set([...COMMON, ...LIT]),
};

/** Does a material of `type` draw with `field` (`physical`: the block, on a `physical` alone)? */
export const usesField = (type: MaterialType, field: MaterialField | 'physical'): boolean => (field === 'physical' ? type === 'physical' : FIELDS_OF[type].has(field));

/** What kind of value each field takes: what the parse checks and the editor draws. */
export type FieldKind = 'type' | 'colour' | 'number' | 'map' | 'bool' | 'side';
export const FIELD_KIND: Readonly<Record<MaterialField, FieldKind>> = {
  type: 'type',
  color: 'colour',
  emissive: 'colour',
  roughness: 'number',
  metalness: 'number',
  emissiveIntensity: 'number',
  opacity: 'number',
  alphaTest: 'number',
  map: 'map',
  normalMap: 'map',
  roughnessMap: 'map',
  metalnessMap: 'map',
  aoMap: 'map',
  emissiveMap: 'map',
  alphaMap: 'map',
  transparent: 'bool',
  flatShading: 'bool',
  wireframe: 'bool',
  depthWrite: 'bool',
  side: 'side',
};

/** The numbers' ranges, for the editor's scrub and the parse's word: none unbounded. */
export const NUMBER_RANGE: Readonly<Record<string, { min: number; max: number }>> = {
  roughness: { min: 0, max: 1 },
  metalness: { min: 0, max: 1 },
  emissiveIntensity: { min: 0, max: 100 },
  opacity: { min: 0, max: 1 },
  alphaTest: { min: 0, max: 1 },
  clearcoat: { min: 0, max: 1 },
  clearcoatRoughness: { min: 0, max: 1 },
  transmission: { min: 0, max: 1 },
  ior: { min: 1, max: 2.333 },
  thickness: { min: 0, max: 100 },
};

/** `#rrggbb` lowercase, or null for what is no colour (`#abc` and names are not taken: one spelling). */
export function colourText(value: unknown): string | null {
  return typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : null;
}

/** How many single-letter edits turn `a` into `b`: for "did you mean". */
function editDistance(a: string, b: string): number {
  let row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const next = [i];
    for (let j = 1; j <= b.length; j++) next.push(Math.min(row[j]! + 1, next[j - 1]! + 1, row[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1)));
    row = next;
  }
  return row[b.length]!;
}

/** `no field "x"`, with the nearest of `allowed` if one is near. */
function unknownKey(key: string, allowed: readonly string[], where: string): string {
  let near = '';
  let best = 3;
  for (const k of allowed) {
    const d = editDistance(key.toLowerCase(), k.toLowerCase());
    if (d < best) [near, best] = [k, d];
  }
  return `${where}"${key}": no such field${near ? ` (did you mean "${near}"?)` : ''} -- ignored`;
}

/** A material file read: every field (the default where it is missing or wrong), and each problem as a line. */
export interface ParsedMaterial {
  file: MaterialFile;
  problems: string[];
}

/**
 * `json` -- a material file's parsed contents -- read whole: the defaults
 * under what it says, each thing wrong a line in `problems` naming the field
 * and why, and the default kept in its place. Never throws.
 */
export function parseMaterialFile(json: unknown): ParsedMaterial {
  const problems: string[] = [];
  const file: MaterialFile = { ...MATERIAL_DEFAULTS, physical: { ...MATERIAL_DEFAULTS.physical } };
  if (json === null || typeof json !== 'object' || Array.isArray(json)) {
    problems.push('not a material file: a JSON object, { "is": "vibebase.material", "version": 1, ... }');
    return { file, problems };
  }
  const raw = json as Record<string, unknown>;
  if (raw.is !== 'vibebase.material') problems.push(`"is": ${JSON.stringify(raw.is ?? null)} -- a material file says "is": "vibebase.material"`);
  if (raw.version !== 1) problems.push(`"version": ${JSON.stringify(raw.version ?? null)} -- this reads version 1`);
  if (raw.type !== undefined) {
    if ((MATERIAL_TYPES as readonly unknown[]).includes(raw.type)) file.type = raw.type as MaterialType;
    else problems.push(`"type": ${JSON.stringify(raw.type)} is no type -- ${MATERIAL_TYPES.join(', ')}; drawn as a standard`);
  }
  const allowed = ['uid', 'is', 'version', 'physical', ...MATERIAL_FIELDS];
  for (const [key, value] of Object.entries(raw)) {
    // `uid`: the file's own id, the pipeline's (Docs/asset-ids.md §1) -- nothing a material draws with.
    if (key === 'is' || key === 'version' || key === 'type' || key === 'uid') continue;
    if (key === 'physical') {
      if (!usesField(file.type, 'physical')) {
        problems.push(`"physical": a ${file.type} material has no use for it -- ignored`);
        continue;
      }
      if (value === null || typeof value !== 'object' || Array.isArray(value)) {
        problems.push(`"physical": an object of numbers, { "clearcoat": 0.5, ... } -- ignored`);
        continue;
      }
      for (const [pk, pv] of Object.entries(value as Record<string, unknown>)) {
        if (!(PHYSICAL_FIELDS as readonly string[]).includes(pk)) {
          problems.push(unknownKey(pk, PHYSICAL_FIELDS, 'physical: '));
          continue;
        }
        if (typeof pv !== 'number' || !Number.isFinite(pv)) problems.push(`"physical.${pk}": ${JSON.stringify(pv)} is not a number -- ${MATERIAL_DEFAULTS.physical[pk as keyof PhysicalFields]} used`);
        else file.physical[pk as keyof PhysicalFields] = pv;
      }
      continue;
    }
    if (!(MATERIAL_FIELDS as readonly string[]).includes(key)) {
      problems.push(unknownKey(key, allowed, ''));
      continue;
    }
    const field = key as MaterialField;
    // A field the type draws without: said once, and left out of the material.
    if (!usesField(file.type, field)) {
      problems.push(`"${field}": a ${file.type} material has no use for it -- ignored`);
      continue;
    }
    const set = file as unknown as Record<string, unknown>;
    switch (FIELD_KIND[field]) {
      case 'colour': {
        const hex = colourText(value);
        if (hex === null) problems.push(`"${field}": ${JSON.stringify(value)} is no colour -- "#rrggbb"; ${MATERIAL_DEFAULTS[field]} used`);
        else set[field] = hex;
        break;
      }
      case 'number':
        if (typeof value !== 'number' || !Number.isFinite(value)) problems.push(`"${field}": ${JSON.stringify(value)} is not a number -- ${String(MATERIAL_DEFAULTS[field])} used`);
        else set[field] = value;
        break;
      case 'bool':
        if (typeof value !== 'boolean') problems.push(`"${field}": ${JSON.stringify(value)} is not true or false -- ${String(MATERIAL_DEFAULTS[field])} used`);
        else set[field] = value;
        break;
      case 'map': {
        const key = typeof value === 'string' || isKeyRef(value) ? resolveRef('textures', value) : undefined;
        if (value === null || key === null) set[field] = null;
        else if (key === undefined) problems.push(`"${field}": ${JSON.stringify(value)} is no texture -- { "uid": …, "key": … }, or a key: a file under src/assets/textures/, its path without the extension; none used`);
        else set[field] = caseKey(key);
        break;
      }
      case 'side':
        if ((MATERIAL_SIDES as readonly unknown[]).includes(value)) file.side = value as MaterialSide;
        else problems.push(`"side": ${JSON.stringify(value)} is no side -- ${MATERIAL_SIDES.join(', ')}; front used`);
        break;
      case 'type':
        break;
    }
  }
  return { file, problems };
}

/** The texture keys a material names, each once, by the field naming it: what the compile and the check look up. */
export function materialMaps(file: MaterialFile): { field: MaterialMap; key: string }[] {
  const out: { field: MaterialMap; key: string }[] = [];
  for (const field of MATERIAL_MAPS) {
    const key = file[field];
    if (key !== null && usesField(file.type, field)) out.push({ field, key });
  }
  return out;
}

/** A material file as written: `is`, `version`, then the fields that differ from the defaults -- each map a texture's reference (`{ uid, key }`, or its key). */
export type MaterialDiff = { is: 'vibebase.material'; version: 1 } & Partial<Omit<MaterialFile, 'is' | 'version' | 'physical' | MaterialMap>> & Partial<Record<MaterialMap, string | KeyRef | null>> & { physical?: Partial<PhysicalFields> };

/**
 * `file` as the editor writes it: `is`, `version` and `type` (always: it says
 * what the rest is), then only what differs from the defaults and the type
 * draws with, in the file's order --
 * `physical` only on a `physical`, and only its own that differ.
 */
export function materialDiff(file: MaterialFile): MaterialDiff {
  const out: Record<string, unknown> = { is: 'vibebase.material', version: 1 };
  for (const field of MATERIAL_FIELDS) {
    if (!usesField(file.type, field)) continue;
    if (field !== 'type' && file[field] === MATERIAL_DEFAULTS[field]) continue;
    const v = file[field];
    // A map by its texture's uid where the index knows one (rule 3), so the material follows the texture when it moves.
    out[field] = FIELD_KIND[field] === 'map' && typeof v === 'string' ? keyRef('textures', v) : v;
  }
  if (file.type === 'physical') {
    const physical: Partial<PhysicalFields> = {};
    for (const k of PHYSICAL_FIELDS) if (file.physical[k] !== MATERIAL_DEFAULTS.physical[k]) physical[k] = file.physical[k];
    if (Object.keys(physical).length > 0) out.physical = physical;
  }
  return out as MaterialDiff;
}

/**
 * A material file's text, as the editor writes every one: two spaces, a line a
 * field, `physical` on one line; a newline at the end. So a field changed is a
 * line changed in git.
 */
export function materialText(diff: MaterialDiff): string {
  const lines = Object.entries(diff).map(([k, v]) => {
    const said = v !== null && typeof v === 'object'
      ? `{ ${Object.entries(v as Record<string, unknown>).map(([pk, pv]) => `${JSON.stringify(pk)}: ${JSON.stringify(pv)}`).join(', ')} }`
      : JSON.stringify(v);
    return `  ${JSON.stringify(k)}: ${said}`;
  });
  return `{\n${lines.join(',\n')}\n}\n`;
}

/**
 * `json` -- a material file's contents -- with `set`'s fields written (each as a file says it: a colour `#rrggbb`, a
 * map by its texture's key or `{ uid, key }`, `physical` merged field by field), as the editor writes every file
 * (`materialDiff`, `materialText`): the Material block's write, and the studio's `material_set` (Docs/mcp.md M3).
 * A field `set` gets wrong -- no such field, the wrong kind of value, one the type draws without -- is a line in
 * `problems`, and then nothing is written; a problem the file had before is not `set`'s.
 */
export function materialSet(json: unknown, set: Readonly<Record<string, unknown>>): { text: string } | { problems: string[] } {
  const base = json !== null && typeof json === 'object' && !Array.isArray(json) ? (json as Record<string, unknown>) : {};
  const merged: Record<string, unknown> = { ...base, ...set };
  if (set.physical !== undefined && base.physical !== null && typeof base.physical === 'object' && set.physical !== null && typeof set.physical === 'object') {
    merged.physical = { ...(base.physical as Record<string, unknown>), ...(set.physical as Record<string, unknown>) };
  }
  const before = new Set(parseMaterialFile(base).problems);
  const parsed = parseMaterialFile(merged);
  const problems = parsed.problems.filter((p) => !before.has(p));
  if (problems.length > 0) return { problems };
  return { text: materialText(materialDiff(parsed.file)) };
}

/** A new material: a `standard` with the defaults, as New material writes it. */
export function newMaterial(): MaterialDiff {
  return { is: 'vibebase.material', version: 1, type: 'standard' };
}
