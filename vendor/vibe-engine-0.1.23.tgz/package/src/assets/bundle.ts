/**
 * The project's assets handed to the engine: `useBundle`, which the project's
 * generated `src/assets/bundle.ts` calls once as it loads -- `main.ts`'s first
 * import -- with the globs `vibe assets` wrote (`packages/pipeline/src/assets/keys.ts`).
 * The prefab files come apart, through `usePrefabFiles` (`../prefabs.ts`), from
 * the generated `prefab-bundle.ts`, which the game's worker imports too.
 *
 * **No `import.meta.hot` here, nor anywhere in the engine's asset runtime.** In
 * the dev server a file added, removed or re-exported under `src/assets/`
 * changes a generated glob file, whose one importer is a generated bundle that
 * accepts its own updates: only that bundle is evaluated again, and it calls
 * `useBundle` (or `usePrefabFiles`) a second time. The engine's modules are
 * never evaluated again, so their maps are the live ones every importer holds by
 * construction; each later call copies the fresh maps into them in place
 * (`sync`, `syncMap`: `hot.ts`) and tells who listens (`onKeysChanged`,
 * `onSceneFiles`, `onPrefabFiles`). A build calls it once, and nobody is told.
 *
 * Pure: no three.js, no glob, no `DEBUG_BUILD` -- a node test calls it
 * (`bundle.test.ts`). A project reaches it through `@vibe/engine/assets`.
 */
import { useData, useLevels } from '../data.ts';
import { useSceneFiles } from '../scenes.ts';
import { useKeyTypes } from './kind-keys.ts';
import { type Globs, useGlobs } from './registry.ts';

/** What a pack's zip is decoded by (the project's generated `pack-kinds.ts`, from `kinds.ts`). */
export interface PackKinds {
  /** A file in a pack's zip: its kind's folder (the first group) and its path under it, without the extension (the second). */
  PACK_FOLDER: RegExp;
  /** An image under `models/`: a model's own texture, found by name, not a key of its own. */
  MODEL_IMAGE: RegExp;
  /** Content types of what a pack carries, by extension. */
  MIME: Readonly<Record<string, string>>;
}

/** Everything the project's `bundle.ts` hands in: the registry's globs, the level and scene files, the pack kinds, and the project's own data kinds. */
export interface Bundle {
  /** Every registry kind's glob (`globs.ts`' `GLOBS`). */
  globs: Globs;
  /** The level files, parsed, by path under `src/assets/` (`level-globs.ts`' `LEVELS`). */
  levels: Record<string, unknown>;
  /** The scene files, parsed, by path, and the ending a key is its path without (`scene-globs.ts`). */
  scenes: { files: Record<string, unknown>; suffix: string };
  /** What `packs.ts` decodes a zip by (`pack-kinds.ts`). */
  packs: PackKinds;
  /**
   * The project's own data kinds (`vibe({ kinds })`), by name: each its files, parsed, by path under
   * `src/assets/`, and its folder (`<name>-globs.ts`). None for a project with none.
   */
  data?: Readonly<Record<string, { dir: string; files: Record<string, unknown> }>>;
  /**
   * Every key type to its kind's name -- `Sfx: 'sfx'`, `Prefab: 'prefabs'`, a project's `Tilemap: 'tilemaps'` -- as the
   * pipeline's `kinds.ts` and `vibe({ kinds })` have them: what `Assets.keysOf` lists a kind by (`kind-keys.ts`).
   */
  types?: Readonly<Record<string, string>>;
}

let packKinds: PackKinds | null = null;

/**
 * The project's assets taken in. The first call fills the registry, the levels
 * and the scenes; every later one -- the dev server's, as the project's
 * `bundle.ts` takes a hot update -- copies the fresh maps into the same ones in
 * place and tells who listens.
 */
export function useBundle(bundle: Bundle): void {
  useGlobs(bundle.globs);
  if (bundle.types) useKeyTypes(bundle.types);
  useLevels(bundle.levels);
  for (const [kind, { dir, files }] of Object.entries(bundle.data ?? {})) useData(kind, files, dir);
  useSceneFiles(bundle.scenes);
  packKinds = bundle.packs;
}

/** The pack kinds the project handed in: what `packs.ts` decodes a zip by. Throws before `useBundle`. */
export function packKindsOf(): PackKinds {
  if (!packKinds) throw new Error("asset packs used before the project's src/assets/bundle.ts handed the pack kinds in (main.ts imports it first)");
  return packKinds;
}
