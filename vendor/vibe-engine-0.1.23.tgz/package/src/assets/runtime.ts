/// <reference path="../env.d.ts" preserve="true" />
/**
 * `@vibe/engine/assets`: the asset runtime, what a project's page, UI and editor import to load and
 * play its media -- `Assets` (preload, packs, lookup), `Audio` (the mixer), the registry's lookups, and
 * `useBundle`, which the project's generated `src/assets/bundle.ts` calls to hand its globs in
 * (`bundle.ts` here; Docs/squidwright-implementation.md 1.5).
 *
 * A subpath, not the index: `audio.ts` reads `DEBUG_BUILD` as it loads (CLAUDE.md's debug
 * pattern: a ReferenceError in node, where no Vite writes it) and `index.ts` and `packs.ts` call
 * `Audio`, so a node test that imports the index must never load these. **No test imports this
 * subpath** but as types (`imports.test.ts` holds it): the pure halves -- the prefabs, scenes and
 * levels, `caseKey`, `sync` -- are in the index.
 *
 * `Packs` itself is not here: `Assets.mount` imports `packs.ts` dynamically so the zip reader stays
 * out of the bundle every player downloads, and a static export would pull it in. Its options are.
 * `Atlas` is the index's; `onKeysChanged` is the engine's own (`index.ts` listens).
 */
export { Assets, type GLTF, type PreloadOptions } from './index.ts';
export { Audio, type AudioPreview, type PlayOptions, type PreviewOptions, type SoundLoop } from '../audio.ts';
export type { MountOptions } from './packs.ts';
export { entries, files, pathUrl, sibling, url, type Glob, type Globs, type Kind } from './registry.ts';
export { useBundle, type Bundle, type PackKinds } from './bundle.ts';
