/**
 * Every key of an asset kind the project has, for a `key(kind)` field's picker (`Assets.keysOf`, Docs/properties.md
 * D6) -- by the kind's key type: `Model`, `Texture`, `Material`, `Prefab`, `Scene`, `Level`, `Sfx`, `UiSfx`, `Music`,
 * `Atlas`, `Icon`, `Font`, a project's own data kind (`Tilemap`).
 *
 * **The kinds are the pipeline's**, handed in by the project's generated `bundle.ts` (`useKeyTypes`, `Bundle.types`):
 * each key type to its kind's name (`Sfx` is `sfx`, `Tilemap` `tilemaps`), from `kinds.ts` and `vibe({ kinds })` -- so
 * the engine keeps no list of its own, and a project's data kind is known whether or not any file of it is stamped.
 * `keyKinds()` is that list.
 *
 * What a kind lists, each key once:
 * - **what is loaded** -- handed in by `Assets` for the kinds the store decodes (a model, a texture, a material
 *   compiled, an atlas), a mounted pack's under its prefix (`reef:props/coral`);
 * - **what the bundle has** -- the registry's keys of its kind (`entries`: every sound, icon, font, atlas of the boot
 *   set, loaded or not), every prefab and scene file handed in (a prefab is in the project whether or not anything
 *   spawned it), a data kind's files (`dataKeys`, a level's too);
 * - **the uid index** (`uidKeys`): every asset the pipeline stamped, the boot set's and each mounted pack's.
 *
 * A pack not mounted is in none of them: its keys are not listed until it is (its rows come with its `uids.json`).
 *
 * Pure: no DOM, no three, no glob -- a node test fills the maps and asks (`kind-keys.test.ts`).
 */
import { dataKeys } from '../data.ts';
import { prefabFiles } from '../prefabs.ts';
import { sceneKeys } from '../scenes.ts';
import { entries, type Kind } from './registry.ts';
import { uidKeys } from './uids.ts';

/** Each key type's kind name, as the project's bundle handed it in. */
const TYPES = new Map<string, string>();

/** The project's key types and their kinds' names taken in (`useBundle`): replaced whole, the dev server's later ones too. */
export function useKeyTypes(types: Readonly<Record<string, string>>): void {
  TYPES.clear();
  for (const [type, name] of Object.entries(types)) TYPES.set(type, name);
}

/** Every key type the project's pipeline has, as handed in: what a `key(kind)` field may hold (but `Clip`). */
export const keyKinds = (): string[] => [...TYPES.keys()];

/** The kinds `Audio` decodes and streams (`audio.ts`: `entries('sfx')`, `'uiSfx'`, `'music'`): a sound's. */
const SOUNDS: readonly string[] = ['sfx', 'uiSfx', 'music'];

/** The kind's name of a sound key type (`Sfx` is `sfx`) as handed in, or undefined for a type that is no sound's: a picker's play button. */
export function soundKind(type: string): string | undefined {
  const name = TYPES.get(type);
  return name !== undefined && SOUNDS.includes(name) ? name : undefined;
}

/** A registry kind's keys, or none: a kind that is no registry kind, or one before the globs are handed in. */
function registryKeys(kind: string): string[] {
  try {
    return entries(kind as Kind).map(([key]) => key);
  } catch {
    return [];
  }
}

/** Every key of the kind whose key type is `type`, sorted, each once: `loaded` (what the store holds of it) and the rest above. */
export function kindKeys(type: string, loaded: Iterable<string> = []): string[] {
  const out = new Set<string>(loaded);
  for (const key of uidKeys(type)) out.add(key);
  const name = TYPES.get(type);
  if (name === 'prefabs') for (const key of Object.keys(prefabFiles())) out.add(key);
  else if (name === 'scenes') for (const key of sceneKeys()) out.add(key);
  else if (name !== undefined) {
    // A registry kind's keys, or a data kind's files (`levels`, a project's `tilemaps`): whichever it is, the other none.
    for (const key of registryKeys(name)) out.add(key);
    for (const key of dataKeys(name as never) as readonly string[]) out.add(key);
  }
  return [...out].sort();
}
