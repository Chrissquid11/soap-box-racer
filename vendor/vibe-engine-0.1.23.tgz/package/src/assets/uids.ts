/**
 * The uid index (Docs/asset-ids.md §2): every asset's uid -> its kind and key,
 * as the pipeline's key generator found them. The project's generated
 * `src/assets/uids.ts` hands the boot set's in (`useUids`); a pack carries its
 * own (`uids.json` in its zip), merged under its prefix when it mounts
 * (`mountUids`) and let go when it unmounts (`dropUids`).
 *
 * What it answers: `keyOfUid(uid)` -- the asset a uid is now, wherever it moved
 * -- and `uidOf(kind, key)`; and for a file's reference (Docs/asset-ids.md §1
 * rules 3 and 4), `resolveRef(kind, ref)` -- a `{ uid, key }` or a bare key to
 * the key now: by the uid when it is known (a stale key read right), else the
 * key as written -- and `keyRef(kind, key)`, the reference a file writes. The
 * prefab compile, a load, a scene, an override and a material's maps all read
 * their references through it.
 *
 * **Live in the dev server** as the other bundles are: the generated `uids.ts`
 * accepts its own hot updates, so a stamp or a move re-evaluates it alone, and
 * it hands the fresh rows in again -- copied into the live map in place.
 *
 * A kind here is the pipeline's name for it (`models`, `prefabs`, `materials`,
 * a project's own `tilemaps`) or its type (`Model`, `Material`, a key field's
 * `key('Model')`: a row carries both); a key is the asset's key, a pack's with
 * its prefix (`reef:props/coral`). Pure: no glob, no DOM -- a node test and a
 * game's worker import it. The worker holds the boot set's rows as the page does
 * (the generated `uids.ts` is imported by `prefab-bundle.ts`, which the worker
 * imports to compile the prefabs), so a stale key resolves alike on both threads
 * and the ids interned there match; packs mount on the page alone, after the
 * compile, and the worker compiles nothing of them.
 */
import { caseKey } from './case-key.ts';

/** A pack's uids, at the top of its zip: written by the pipeline's `assets/packs.ts`, which takes this name from here (`@vibe/engine/uids`). */
export const PACK_UIDS = 'uids.json';

/** One asset as the index has it: its kind (the pipeline's name for it), its key, and its kind's type (`Model`) when the pipeline wrote it. */
export interface UidRow {
  kind: string;
  key: string;
  type?: string;
}

/**
 * A reference in a file (Docs/asset-ids.md §1, rule 3): the uid that finds the asset, the key a person reads (a
 * `Render.model`'s `#part` kept in it) -- and, for a `mesh()` field, the model's part on its own (`part`).
 */
export interface KeyRef {
  uid: string;
  key: string;
  part?: string;
}

/** A reference's own `part` (a `mesh()` field's), as the `#part` it adds to the key: `''` for none. */
const partOf = (ref: KeyRef): string => (typeof ref.part === 'string' && ref.part !== '' ? `#${ref.part}` : '');

/** The boot set's, by uid. */
const BOOT = new Map<string, UidRow>();
/** Each mounted pack's, by its name (lowercased), each by uid, keys prefixed. */
const PACKS = new Map<string, Map<string, UidRow>>();
/** `kind\0key` (the key lowercased) -> uid: every row above, rebuilt on each change. */
const BY_KEY = new Map<string, string>();

const slot = (kind: string, key: string): string => `${kind}\0${caseKey(key)}`;

function rebuild(): void {
  BY_KEY.clear();
  for (const rows of [BOOT, ...PACKS.values()]) {
    for (const [uid, row] of rows) {
      if (!BY_KEY.has(slot(row.kind, row.key))) BY_KEY.set(slot(row.kind, row.key), uid);
      if (row.type !== undefined && !BY_KEY.has(slot(row.type, row.key))) BY_KEY.set(slot(row.type, row.key), uid);
    }
  }
}

/** A row taken in: its key lowercased, under `prefix` (a pack's `<name>:`), its type when it has one. */
const rowOf = (row: UidRow, prefix = ''): UidRow => ({ kind: row.kind, key: `${prefix}${caseKey(row.key)}`, ...(typeof row.type === 'string' ? { type: row.type } : {}) });

/**
 * The boot set's uids taken in, by uid -- the first time, and every later time a hot update of the generated
 * `uids.ts` hands them in again (dev only): the map is replaced in place, so whoever holds it sees the new one.
 */
export function useUids(rows: Readonly<Record<string, UidRow>>): void {
  BOOT.clear();
  for (const [uid, row] of Object.entries(rows)) BOOT.set(uid, rowOf(row));
  rebuild();
}

/** A pack's `uids.json` merged as it mounts: its keys (written without the prefix) under `<pack>:`. */
export function mountUids(pack: string, rows: Readonly<Record<string, UidRow>>): void {
  const name = caseKey(pack);
  const own = new Map<string, UidRow>();
  for (const [uid, row] of Object.entries(rows)) own.set(uid, rowOf(row, `${name}:`));
  PACKS.set(name, own);
  rebuild();
}

/** A pack's uids let go as it unmounts. */
export function dropUids(pack: string): void {
  if (PACKS.delete(caseKey(pack))) rebuild();
}

/** The asset a uid is now -- its kind and key -- or undefined for a uid nobody has (or a pack's, not mounted). */
export function keyOfUid(uid: string): UidRow | undefined {
  const boot = BOOT.get(uid);
  if (boot) return boot;
  for (const rows of PACKS.values()) {
    const row = rows.get(uid);
    if (row) return row;
  }
  return undefined;
}

/** The uid of the asset of `kind` at `key` (any case), or undefined for one with none. */
export function uidOf(kind: string, key: string): string | undefined {
  return BY_KEY.get(slot(kind, key));
}

/** Is `value` a reference as a file writes it: `{ "uid": "…", "key": "…" }`? */
export function isKeyRef(value: unknown): value is KeyRef {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const v = value as { uid?: unknown; key?: unknown };
  return typeof v.uid === 'string' && typeof v.key === 'string';
}

/** Is `row` of `kind` -- by the pipeline's name for it, or by its type? */
export const ofKind = (row: UidRow, kind: string): boolean => row.kind === kind || row.type === kind;

/**
 * A file's reference to an asset of `kind` (Docs/asset-ids.md §1, rules 3 and 4) as the key now: a `{ uid, key }`
 * whose uid the index knows, as a key of that kind, is its asset's key wherever it is now (its `#part` kept) -- a
 * stale key read right; else the key as written; a bare string is a key as written. Null for none (`''`, `null`)
 * and for what is no reference. Never says the asset is there: the caller looks the key up as ever.
 */
export function resolveRef(kind: string, ref: unknown): string | null {
  if (typeof ref === 'string') return ref === '' ? null : ref;
  if (!isKeyRef(ref)) return null;
  const row = keyOfUid(ref.uid);
  if (row !== undefined && ofKind(row, kind)) {
    const hash = ref.key.indexOf('#');
    return row.key + (hash < 0 ? partOf(ref) : ref.key.slice(hash));
  }
  return ref.key === '' ? null : ref.key + (ref.key.includes('#') ? '' : partOf(ref));
}

/** Does `ref` name its asset by a key the uid says is no longer its own (moved since it was written)? For a tool's word; the repair pass rewrites it. */
export function staleRef(kind: string, ref: unknown): boolean {
  if (!isKeyRef(ref)) return false;
  const now = resolveRef(kind, ref);
  return now !== null && caseKey(now) !== caseKey(refText(ref));
}

/**
 * The reference a file writes for the asset of `kind` at `key` (rule 3): `{ uid, key }` when the asset has a uid --
 * a `#part`'s the uid of its model, the part kept in the key -- else the key alone (an asset not loaded, a pack not
 * mounted, a kind with no uids: a clip's name). `''` for none.
 */
export function keyRef(kind: string, key: string): KeyRef | string {
  if (key === '') return '';
  const hash = key.indexOf('#');
  const uid = uidOf(kind, hash < 0 ? key : key.slice(0, hash));
  return uid === undefined ? key : { uid, key };
}

/** The key a file's value names, as written -- a reference's `key`, a bare string -- for a tool to show; `''` for none. */
export function refText(value: unknown): string {
  if (typeof value === 'string') return value;
  return isKeyRef(value) ? value.key + (value.key.includes('#') ? '' : partOf(value)) : '';
}

/**
 * The reference a `mesh()` field writes for `key` (`model#part`, any case): `{ uid, key, part }` -- the model's uid,
 * its key, the part on its own (left out for the whole model) -- or, for a model with no uid, the text as it is
 * (`"props/robot#arm"`, which a load reads as well). `''` for none.
 */
export function meshRef(key: string): KeyRef | string {
  if (key === '') return '';
  const hash = key.indexOf('#');
  const model = hash < 0 ? key : key.slice(0, hash);
  const part = hash < 0 ? '' : key.slice(hash + 1);
  const uid = uidOf('Model', model);
  if (uid === undefined) return key;
  return part === '' ? { uid, key: model } : { uid, key: model, part };
}

/**
 * Every key the index has of `kind` -- by the pipeline's name for it or its type (`Sfx`, `Prefab`, `Tilemap`) --
 * the boot set's and each mounted pack's (prefixed `reef:`), sorted, each once: what a `key(kind)` field's
 * picker lists beside what is loaded (`Assets.keysOf`). With `names`, the pipeline's names of the kinds those
 * rows are of (`tilemaps` for `Tilemap`) are added to it.
 */
export function uidKeys(kind: string, names?: Set<string>): string[] {
  const out = new Set<string>();
  for (const rows of [BOOT, ...PACKS.values()]) {
    for (const row of rows.values()) {
      if (!ofKind(row, kind)) continue;
      out.add(row.key);
      names?.add(row.kind);
    }
  }
  return [...out].sort();
}
