/**
 * Sprite atlases: one image, many frames, one GPU upload.
 *
 * The JSON is the TexturePacker / Aseprite "hash" layout (`--format json-hash`),
 * which both tools export and which stays readable in a diff. Array exports
 * (`json-array`) work too -- the frame name is then the `filename` field.
 *
 * **Read again in place** (`reread`), when the dev server re-exports the sheet
 * (Docs/assets.md §8): the frames parsed anew, and every sprite this atlas
 * handed out cut again from its frame -- so a sprite already on a material
 * shows the new sheet next frame. The atlas keeps them for that, one entry per
 * `sprite()` call. On a sheet of another size every one of them is disposed
 * first, whether or not its frame survived: they share one GL texture.
 */
import * as THREE from 'three';

/** One packed frame, in pixels, with the origin at the image's top-left. */
export interface Frame {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface RawFrame {
  frame: Frame;
  filename?: string;
}

interface RawAtlas {
  frames: Record<string, RawFrame> | RawFrame[];
  meta?: { size?: { w: number; h: number } };
}

export class Atlas {
  /** The sheet's size in pixels: the JSON's `meta.size`, else the image's. Changes only with `reread`. */
  width = 0;
  height = 0;
  private frames = new Map<string, Frame>();
  /** Every sprite handed out, by its frame's name: cut again by `reread`. */
  private readonly sprites = new Map<THREE.Texture, string>();
  /** The packed image, already loaded. */
  readonly texture: THREE.Texture;
  /** The image's URL -- CSS needs it, since `Atlas` hands out style values too. */
  readonly url: string;

  constructor(texture: THREE.Texture, url: string, json: unknown) {
    this.texture = texture;
    this.url = url;
    this.parse(json);
  }

  /** The frames and the sheet's size, from the packer's JSON. */
  private parse(json: unknown): void {
    const raw = json as RawAtlas;
    const frames = new Map<string, Frame>();
    const list = Array.isArray(raw.frames) ? raw.frames : Object.entries(raw.frames ?? {});
    for (const item of list) {
      const [name, entry] = Array.isArray(item) ? item : [item.filename ?? '', item];
      // Strip the extension the packer kept: 'crab-walk-0.png' -> 'crab-walk-0'.
      if (entry?.frame) frames.set(name.replace(/\.[^.]+$/, ''), entry.frame);
    }
    this.frames = frames;

    // three types `image` as {} -- it can be an ImageBitmap, a canvas or an
    // <img> depending on the loader. All three carry the dimensions.
    const image = this.texture.image as { width?: number; height?: number } | undefined;
    const size = raw.meta?.size;
    this.width = size?.w ?? image?.width ?? 1;
    this.height = size?.h ?? image?.height ?? 1;
  }

  /**
   * Dev only: the sheet re-exported -- its texture already holding the new
   * image (`store.ts`'s `refill`) -- and `json` its new frames. Every sprite
   * handed out is cut again from its frame and marked for upload (a clone has
   * its own `version`, so the sheet's alone would not reach it).
   *
   * **If the sheet's size changed, every sprite is disposed first**, its frame
   * there or not: their shared GL texture is freed only when the last lets go,
   * and one sprite left holding it keeps the old storage, into which every
   * other sprite's bigger upload then fails. A sprite whose frame is gone keeps
   * its old crop -- of the new image, marked for upload like the rest, never
   * left on a deleted GL texture: their names are returned, once each.
   */
  reread(json: unknown): string[] {
    const was = { width: this.width, height: this.height };
    this.parse(json);
    const resized = this.width !== was.width || this.height !== was.height;
    const gone = new Set<string>();
    for (const [sprite, name] of this.sprites) {
      if (resized) sprite.dispose();
      const frame = this.frames.get(name);
      if (frame) this.crop(sprite, frame);
      else gone.add(name);
      sprite.needsUpdate = true;
    }
    return [...gone];
  }

  /** `texture` cut to `frame` of this sheet. */
  private crop(texture: THREE.Texture, { x, y, w, h }: Frame): void {
    texture.repeat.set(w / this.width, h / this.height);
    // Atlas coordinates run down from the top-left; UVs run up from bottom-left.
    texture.offset.set(x / this.width, 1 - (y + h) / this.height);
  }

  /** Frame names, in pack order -- handy for building an animation. */
  get names(): string[] {
    return [...this.frames.keys()];
  }

  frame(name: string): Frame {
    const frame = this.frames.get(name);
    if (!frame) throw new Error(`frame '${name}' not in atlas (have: ${this.names.join(', ')})`);
    return frame;
  }

  /**
   * A texture cropped to one frame, for a material or a `THREE.Sprite`.
   *
   * The clone shares the same GPU image, so this is cheap -- but it is still a
   * new object per call, and the atlas keeps each one it hands out (for
   * `reread`). Make it once and keep it, don't call it per frame.
   */
  sprite(name: string): THREE.Texture {
    const frame = this.frame(name);
    const texture = this.texture.clone();
    this.crop(texture, frame);
    texture.needsUpdate = true;
    this.sprites.set(texture, name);
    return texture;
  }

  /**
   * The same frame as CSS, for HUD and overlay elements.
   *
   *     Object.assign(icon.style, atlas.css('shell'), { width: '32px', height: '32px' });
   *
   * A style is a copy: one already painted keeps the old pixels when the sheet
   * is re-exported (`reread`), until it is set again or the page reloads.
   */
  css(name: string): Partial<CSSStyleDeclaration> {
    const { x, y } = this.frame(name);
    return {
      backgroundImage: `url("${this.url}")`,
      backgroundPosition: `${-x}px ${-y}px`,
      backgroundSize: `${this.width}px ${this.height}px`,
      backgroundRepeat: 'no-repeat',
    };
  }
}
