/**
 * Where decoded assets live, and the decoding itself.
 *
 * Two things put assets in here: `Assets.preload()`, which loads what shipped
 * in the build from a URL, and `Packs.mount()`, which loads a downloaded pack
 * from bytes. They share this module so a model behaves identically whichever
 * way it arrived -- same sRGB handling, same filtering, same shadow flags.
 *
 * Pack assets are stored under a prefixed key (`beach:props/shell`), which is
 * what makes `unmount` a matter of dropping one prefix. The set of mounted
 * packs lives here rather than in `packs.ts` for the same reason: `packs.ts` is
 * imported dynamically and may never load, but `Assets.dispose()` has to be
 * able to forget a mount, and a `mounted` flag that outlived the assets it
 * described would make every later `mount()` a silent no-op.
 *
 * **Decoding is apart from storing** (`decodeModel`, `decodeTexture`), so the
 * editor decodes an export as the game would without registering it -- a
 * preview, or a re-export on its way in (Docs/assets.md §7, §8). The dev
 * server's re-exports come in through `replaceModel` and `replaceTexture`,
 * reached only from `packages/editor/src/`, so a release build has neither.
 */
import * as THREE from 'three';
import { GLTFLoader, type GLTF } from 'three/addons/loaders/GLTFLoader.js';
import type { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { Atlas } from './atlas.ts';
import { extrasOntoClips } from './clip-info.ts';

/** An asset to decode: either a URL the browser can fetch, or bytes we hold. */
export type Source = { url: string; bytes?: undefined } | { bytes: Uint8Array; name: string; url?: undefined };

export const models = new Map<string, GLTF>();
export const textures = new Map<string, THREE.Texture>();
export const atlases = new Map<string, Atlas>();

/** Told each key a texture is newly stored under (`storeTexture`): the material store's way to a map that arrived late. */
const textureHeard = new Set<(key: string) => void>();

/**
 * Told the key of each texture stored where none was -- the preload's, a pack's, one a hot update
 * added (`addTexture`), one a re-export brought for a key the store lacked (`replaceTexture`) --
 * after the store holds it. A texture refilled in place is not told: whoever holds it draws it
 * already. Returns the undo.
 */
export function onTextureStored(listener: (key: string) => void): () => void {
  textureHeard.add(listener);
  return () => void textureHeard.delete(listener);
}

/** `texture` stored under `key`, and every listener told. */
function storeTexture(key: string, texture: THREE.Texture): void {
  textures.set(key, texture);
  for (const listener of textureHeard) listener(key);
}

/** Blob URLs handed out for pack assets, so `drop` can revoke them. */
const objectUrls = new Map<string, string>();

/** Packs whose assets are in the maps above. Cleared by `drop`, so the two cannot drift. */
export const mountedPacks = new Set<string>();

let renderer: THREE.WebGLRenderer | undefined;
let ktx2: Promise<THREE.Loader> | undefined;
let draco: Promise<DRACOLoader> | undefined;

/** Remembered so a pack mounted mid-game can still decode `.ktx2`. */
export function useRenderer(value: THREE.WebGLRenderer | undefined): void {
  if (value) renderer = value;
}

/** A `Uint8Array` view may sit inside a larger buffer; three's parsers want its own. */
function ownBuffer(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

function isCompressed(name: string): boolean {
  return /\.ktx2$/i.test(name);
}

/**
 * The KTX2 loader, created once and only if something actually needs it.
 *
 * The transcoder is a 530 kB WASM bundle. Rollup emits it as its own chunk
 * because the import is dynamic, so it sits in `dist/` regardless -- but no
 * player downloads it unless a compressed texture is loaded. Keep the import
 * dynamic: a static one would fold it into the main bundle, which every player
 * *does* download.
 */
function ktx2Loader(): Promise<THREE.Loader> {
  ktx2 ??= (async () => {
    // No setTranscoderPath: left empty, the loader fetches the transcoder that
    // Vite bundled and hashed, so there is nothing to copy into public/.
    const { KTX2Loader } = await import('three/addons/loaders/KTX2Loader.js');
    const loader = new KTX2Loader();
    // detectSupport only reads the GL extension list. Borrow the game's
    // renderer when there is one; otherwise a throwaway context answers the
    // same question and is disposed immediately rather than held for the session.
    const probe = renderer ?? new THREE.WebGLRenderer();
    loader.detectSupport(probe);
    if (!renderer) probe.dispose();
    return loader;
  })();
  return ktx2;
}

/**
 * The optional glTF decoders, wired without being downloaded.
 *
 * A `.glb` may carry Draco-compressed geometry (Blender's "Compression"
 * checkbox), meshopt buffers, or KTX2 textures, and GLTFLoader wants the
 * matching decoder *attached before the parse* -- without one it refuses the
 * file outright ("No DRACOLoader instance provided", "setKTX2Loader must be
 * called before loading KTX2 textures"). Since `preload()` awaits every model
 * through one `Promise.all`, such a file would not fail an asset, it would fail
 * boot: the loading bar never finishes and the player gets the loading
 * error overlay.
 *
 * They also must not be imported eagerly: between them these are close to a
 * megabyte, and most models need none of them. So each is a shim that satisfies
 * GLTFLoader's synchronous check and imports the real decoder on first use --
 * which only ever happens for a file that actually uses that extension. Keep
 * every import in here dynamic.
 */
function dracoLoader(): Promise<DRACOLoader> {
  draco ??= import('three/addons/loaders/DRACOLoader.js').then(({ DRACOLoader, DRACO_GLTF_CONFIG }) =>
    // three ships two Draco builds and defaults to the larger one, which also
    // decodes standalone `.drc`. We only ever meet Draco embedded in a `.glb`
    // -- `.drc` is not in the globs and carries no materials, textures or
    // animation to make it worth adding -- so the glTF-only build is the right
    // one: 64 kB gzipped on the wire instead of 90 kB.
    //
    // The trade is that a custom decoder path has no pure-JS fallback, so this
    // needs WebAssembly and throws without it rather than fetching a 719 kB JS
    // decoder. Every browser worth shipping to has had WebAssembly since 2017, and
    // `meshoptShim` above already assumes exactly the same.
    new DRACOLoader().setDecoderPath(DRACO_GLTF_CONFIG),
  );
  return draco;
}

/** Implements the two methods GLTFLoader calls on a DRACOLoader. */
const dracoShim = {
  preload(): void {
    void dracoLoader();
  },
  decodeDracoFile(
    buffer: ArrayBuffer,
    callback: (geometry: THREE.BufferGeometry) => void,
    attributeIDs?: Record<string, string> | null,
    attributeTypes?: Record<string, string> | null,
    vertexColorSpace?: string,
    onError?: (error: unknown) => void,
  ): void {
    const fail = onError ?? ((error: unknown): void => console.error(error));
    dracoLoader()
      .then((loader) =>
        (loader as unknown as { decodeDracoFile: (...args: unknown[]) => unknown }).decodeDracoFile(
          buffer,
          callback,
          attributeIDs,
          attributeTypes,
          vertexColorSpace,
          fail,
        ),
      )
      .catch(fail);
  },
};

/** Implements the one method GLTFLoader calls on a KTX2Loader, plus its brand check. */
const ktx2Shim = {
  isKTX2Loader: true,
  load(url: string, onLoad: (texture: THREE.Texture) => void, _onProgress: unknown, onError: (error: unknown) => void): void {
    ktx2Loader()
      .then((loader) => (loader as THREE.Loader & { load: typeof ktx2Shim.load }).load(url, onLoad, undefined, onError))
      .catch(onError);
  },
};

/** Implements the meshopt decoder interface GLTFLoader probes for. */
const meshoptShim = {
  // Meshopt is WASM-only; claiming support without it would turn a file that
  // has an uncompressed fallback into a hard failure.
  supported: typeof WebAssembly === 'object',
  async decodeGltfBufferAsync(
    count: number,
    size: number,
    source: Uint8Array,
    mode: string,
    filter?: string,
  ): Promise<Uint8Array> {
    const { MeshoptDecoder } = await import('three/addons/libs/meshopt_decoder.module.js');
    return MeshoptDecoder.decodeGltfBufferAsync(count, size, source, mode, filter);
  },
};

const gltfLoader = new GLTFLoader();
// The shims are structural stand-ins, not subclasses, so the casts are the
// point: each implements exactly what GLTFLoader calls and nothing else.
gltfLoader.setDRACOLoader(dracoShim as unknown as Parameters<GLTFLoader['setDRACOLoader']>[0]);
gltfLoader.setKTX2Loader(ktx2Shim as unknown as Parameters<GLTFLoader['setKTX2Loader']>[0]);
gltfLoader.setMeshoptDecoder(meshoptShim as unknown as Parameters<GLTFLoader['setMeshoptDecoder']>[0]);

/** Turns a URI a glTF asked for into the built asset it means, or null for "as written". */
export type Resolve = (uri: string) => string | null;

/**
 * A loader that knows where one model's own textures went.
 *
 * **One per model, not one shared.** The hook is a `LoadingManager`'s URL
 * modifier, which is global to the loader, and `preload` parses every model at
 * once -- a shared one would answer for whichever model asked last. A
 * `GLTFLoader` is a handful of objects, so one per model costs nothing.
 *
 * The KTX2 shim is rebuilt per loader for the same reason and one more: that
 * path never reaches the manager. `GLTFLoader` hands a KTX2 image straight to
 * the loader it was given, so the URL has to be resolved on the way in.
 */
function loaderFor(resolve: Resolve): GLTFLoader {
  const manager = new THREE.LoadingManager();
  manager.setURLModifier((url) => resolve(url) ?? url);
  const loader = new GLTFLoader(manager);
  loader.setDRACOLoader(dracoShim as unknown as Parameters<GLTFLoader['setDRACOLoader']>[0]);
  loader.setKTX2Loader({
    ...ktx2Shim,
    load(url: string, onLoad: (texture: THREE.Texture) => void, onProgress: unknown, onError: (error: unknown) => void): void {
      ktx2Shim.load(resolve(url) ?? url, onLoad, onProgress, onError);
    },
  } as unknown as Parameters<GLTFLoader['setKTX2Loader']>[0]);
  loader.setMeshoptDecoder(meshoptShim as unknown as Parameters<GLTFLoader['setMeshoptDecoder']>[0]);
  return loader;
}

/** What a texture is for: a colour map, or an atlas's sheet -- each finished as `finishTexture` says. */
export type TextureUse = 'texture' | 'atlas';

/**
 * A decoded texture made ready for its use, in place: authored in sRGB (three
 * assumes linear unless told); a colour map filtered with anisotropy 4; an
 * atlas's sheet nearest and with no mipmaps, so its frames do not bleed into
 * each other at their edges.
 */
export function finishTexture(texture: THREE.Texture, use: TextureUse): THREE.Texture {
  texture.colorSpace = THREE.SRGBColorSpace;
  if (use === 'texture') {
    texture.anisotropy = 4;
  } else {
    texture.magFilter = THREE.NearestFilter;
    texture.generateMipmaps = false;
  }
  return texture;
}

/**
 * A texture from a URL or from bytes, finished for its use (`finishTexture`)
 * -- in no store. A `.ktx2` is told by its URL or its `name`: a blob URL ends
 * in a UUID, so bytes of one come as `{ bytes, name: key + '.ktx2' }`.
 */
export async function decodeTexture(source: Source, use: TextureUse = 'texture'): Promise<THREE.Texture> {
  return finishTexture(await decodeRaw(source), use);
}

async function decodeRaw(source: Source): Promise<THREE.Texture> {
  const name = source.url ?? source.name;

  if (isCompressed(name)) {
    const loader = (await ktx2Loader()) as THREE.Loader & {
      parse(buffer: ArrayBuffer, onLoad: (t: THREE.Texture) => void, onError: (e: unknown) => void): void;
    };
    if (source.bytes) {
      return new Promise((resolve, reject) => loader.parse(ownBuffer(source.bytes), resolve, reject));
    }
    return (await loader.loadAsync(source.url)) as THREE.Texture;
  }

  if (source.url) return new THREE.TextureLoader().loadAsync(source.url);

  // From bytes: pre-flip the bitmap and turn flipY off, rather than asking the
  // renderer to flip on upload -- WebGL cannot do that for an ImageBitmap.
  const bitmap = await createImageBitmap(new Blob([source.bytes as BlobPart]), { imageOrientation: 'flipY' });
  const texture = new THREE.Texture(bitmap);
  texture.flipY = false;
  texture.needsUpdate = true;
  return texture;
}

/**
 * A URL for bytes that have none, freed with everything else under `key`.
 *
 * A pack arrives as one zip, so a model's own texture inside it has no address
 * a loader can fetch -- and a blob URL that nothing revokes is a leak that
 * outlives the pack. Registering it here puts it under `drop`'s prefix sweep,
 * beside the atlas URLs that already work this way.
 */
export function urlForBytes(key: string, bytes: Uint8Array): string {
  const existing = objectUrls.get(key);
  if (existing) return existing;
  const url = URL.createObjectURL(new Blob([bytes as BlobPart]));
  objectUrls.set(key, url);
  return url;
}

/**
 * A model from a URL or from bytes, through the game's own loader -- the Draco,
 * KTX2 and meshopt shims, its own images found by `resolve` -- in no store.
 */
export async function decodeModel(source: Source, resolve?: Resolve): Promise<GLTF> {
  const loader = resolve ? loaderFor(resolve) : gltfLoader;
  return source.bytes ? await loader.parseAsync(ownBuffer(source.bytes), '') : await loader.loadAsync(source.url);
}

/**
 * A model's scene marked with its key, which every instance carries
 * (`SkeletonUtils.clone` copies `userData`): how the editor finds what is drawn
 * with a model when its file is exported again (Docs/assets.md §8). Its clips
 * carry their glTF `extras` -- Gladius's `loop`, `duration`, `fps` -- on
 * `userData` (`extrasOntoClips`): what the `animate` system's loop reads.
 */
function tag(gltf: GLTF, key: string): GLTF {
  gltf.scene.userData.assetKey = key;
  extrasOntoClips(gltf);
  return gltf;
}

export async function addModel(key: string, source: Source, resolve?: Resolve): Promise<void> {
  models.set(key, tag(await decodeModel(source, resolve), key));
  // Told as a re-export is: a collider that asked for it before it came (a pack mounted later) is made now.
  for (const listener of replacedListeners) listener(key);
}

/**
 * Dev only: a model decoded again put in the store under its key, tagged; the
 * old one returned, still whole -- instances share its geometry and materials,
 * so it is disposed once nothing draws it any more (`disposeModel`).
 */
export function replaceModel(key: string, gltf: GLTF): GLTF | undefined {
  const old = models.get(key);
  models.set(key, tag(gltf, key));
  for (const listener of replacedListeners) listener(key);
  return old;
}

const replacedListeners = new Set<(key: string) => void>();

/**
 * Told of each model put in the store after boot's -- `replaceModel`'s re-export in the dev server, `addModel`'s
 * (a pack mounted): the physics' hulls and meshes made again, or made at last. Returns the undo.
 */
export function onModelReplaced(listener: (key: string) => void): () => void {
  replacedListeners.add(listener);
  return () => void replacedListeners.delete(listener);
}

export async function addTexture(key: string, source: Source): Promise<void> {
  storeTexture(key, await decodeTexture(source, 'texture'));
}

/** A texture's size, as its image says it: an image, a bitmap, a canvas, a compressed texture's `{ width, height }`. */
export function sizeOf(texture: THREE.Texture): { width: number; height: number } {
  const image = texture.image as { width?: number; height?: number } | null | undefined;
  return { width: image?.width ?? 0, height: image?.height ?? 0 };
}

/**
 * `fresh`'s image put into `old`, in place, so every holder of `old` -- a
 * material, a uniform, an atlas's sprites, which share its `Source` -- draws
 * the new image next frame; `fresh`, a wrapper, disposed. The image (the
 * `Source`'s data), its mipmaps and, compressed, its format and type.
 *
 * **A size change disposes `old` first.** three allocates a texture's storage
 * (`texStorage2D`) only on its first upload or a new cache key, and the key has
 * no size: a bigger image would go by `texSubImage2D` into the old storage and
 * fail. Disposed, the next bind allocates anew -- once every texture sharing
 * the GL texture has let go, which is why `Atlas.reread` disposes its sprites
 * too (checked in three 0.186.1's `WebGLTextures`). Answers whether it did.
 */
export function refill(old: THREE.Texture, fresh: THREE.Texture): { resized: boolean } {
  const was = sizeOf(old);
  const now = sizeOf(fresh);
  const resized = was.width !== now.width || was.height !== now.height;
  if (resized) old.dispose();
  old.image = fresh.image;
  old.mipmaps = fresh.mipmaps;
  if ((fresh as THREE.CompressedTexture).isCompressedTexture) {
    old.format = fresh.format;
    old.type = fresh.type;
  }
  old.needsUpdate = true;
  fresh.dispose();
  return { resized };
}

/**
 * Dev only: a texture decoded again put into the stored one in place
 * (`refill`); a key not there yet is stored as it is. Answers whether its size
 * changed, and what it was.
 */
export function replaceTexture(key: string, fresh: THREE.Texture): { resized: boolean; was: { width: number; height: number } } {
  const old = textures.get(key);
  if (!old) {
    storeTexture(key, fresh);
    return { resized: false, was: sizeOf(fresh) };
  }
  const was = sizeOf(old);
  return { ...refill(old, fresh), was };
}

export async function addAtlas(key: string, image: Source, json: unknown): Promise<void> {
  const texture = await decodeTexture(image, 'atlas');

  // Atlas.css() needs a URL for `background-image`, which a pack has to invent.
  let url = image.url;
  if (!url) {
    url = URL.createObjectURL(new Blob([image.bytes as BlobPart]));
    objectUrls.set(key, url);
  }
  atlases.set(key, new Atlas(texture, url, json));
}

/**
 * Releases a model's GPU memory.
 *
 * Dropping the `GLTF` is not enough: three uploads geometry, materials and the
 * textures they reference to the GPU, and none of that is reachable by the
 * garbage collector -- it lives in WebGL objects that only `dispose()` frees.
 * A level that mounts and unmounts a pack each round would otherwise grow VRAM
 * until the context is lost, which on mobile is a black screen, not a stutter.
 *
 * A `Set` because a glTF shares one material or geometry across many meshes,
 * and disposing the same resource twice is wasted work. A skinned mesh's
 * skeleton too: three makes its bone texture the first time it is drawn, and
 * only `Skeleton.dispose()` frees it.
 */
export function disposeModel(gltf: GLTF): void {
  const seen = new Set<unknown>();

  gltf.scene.traverse((object) => {
    const mesh = object as Partial<THREE.Mesh>;

    if (mesh.geometry && !seen.has(mesh.geometry)) {
      seen.add(mesh.geometry);
      mesh.geometry.dispose();
    }

    const skeleton = (object as Partial<THREE.SkinnedMesh>).isSkinnedMesh ? (object as THREE.SkinnedMesh).skeleton : undefined;
    if (skeleton && !seen.has(skeleton)) {
      seen.add(skeleton);
      skeleton.dispose();
    }

    if (!mesh.material) return;
    for (const material of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
      if (seen.has(material)) continue;
      seen.add(material);
      // Every map (`map`, `normalMap`, `aoMap`, ...) is a texture property, so
      // walking the material catches them without naming each one -- and keeps
      // catching them when three adds another.
      for (const value of Object.values(material)) {
        const texture = value as THREE.Texture | null;
        if (texture?.isTexture && !seen.has(texture)) {
          seen.add(texture);
          texture.dispose();
        }
      }
      material.dispose();
    }
  });
}

/**
 * Dev only: one key out of the store, exactly -- a hot update's removed key
 * (`index.ts`). Not `drop`, which takes a prefix: `drop('props/crate')` would
 * take `props/crate-2` with it. Its GPU memory is left as it is: an entity
 * may still be drawing it.
 */
export function forget(key: string): void {
  models.delete(key);
  textures.delete(key);
  atlases.delete(key);
}

/**
 * Frees everything whose key starts with `prefix`. `''` frees the lot.
 *
 * Anything still holding an `Assets.instance()` of a dropped model is left with
 * disposed geometry, so unmount a pack only once its level is gone.
 */
export function drop(prefix: string): void {
  for (const [key, texture] of textures) {
    if (key.startsWith(prefix)) {
      texture.dispose();
      textures.delete(key);
    }
  }
  for (const [key, atlas] of atlases) {
    if (key.startsWith(prefix)) {
      atlas.texture.dispose();
      atlases.delete(key);
    }
  }
  for (const [key, gltf] of models) {
    if (key.startsWith(prefix)) {
      disposeModel(gltf);
      models.delete(key);
    }
  }
  for (const [key, url] of objectUrls) {
    if (key.startsWith(prefix)) {
      URL.revokeObjectURL(url);
      objectUrls.delete(key);
    }
  }

  // Keep the mount bookkeeping in step with what is actually loaded. A pack
  // still marked mounted after its assets went would make `mount()` a no-op
  // and every one of its keys throw for the rest of the session.
  if (prefix === '') mountedPacks.clear();
  else if (prefix.endsWith(':')) mountedPacks.delete(prefix.slice(0, -1));
}
