/**
 * What `packs.ts` keeps about its mounts that is plain bookkeeping, apart from
 * the DOM, the Cache API and three -- so a node test reaches it.
 *
 * - **A mount called off.** `Packs.unmount()` while the same pack's mount is
 *   still downloading or decoding drops what was added so far -- and then the
 *   mount carries on, adding the rest and marking the pack mounted: half its
 *   assets gone, half back. Each pack has a generation; an unmount moves it on,
 *   and a mount that finds it moved after any wait drops what it added and
 *   rejects (`Unmounted`) instead of marking anything.
 * - **The zips cached for a pack before this one.** A pack's URL carries its
 *   content hash, so every rebuild is a new cache entry and the old ones are
 *   never asked for again: after a mount, the others of the same pack go.
 */

/** Each pack's mount generation, by its key: an unmount moves it on. */
export class Generations {
  private readonly at = new Map<string, number>();

  of(name: string): number {
    return this.at.get(name) ?? 0;
  }

  bump(name: string): void {
    this.at.set(name, this.of(name) + 1);
  }
}

/** A mount the pack's unmount called off while it ran. */
export class Unmounted extends Error {
  constructor(name: string) {
    super(`pack '${name}' was unmounted while it was mounting`);
    this.name = 'Unmounted';
  }
}

/**
 * Of these cached URLs, the zips of the pack whose file is `keep` (`reef-a3f9c1e2.zip`)
 * that are not it: the same pack name, another hash. Another pack's (`reef-deep-…`) is not.
 */
export function staleZips(cached: readonly string[], keep: string): string[] {
  const m = /^(.*)-[0-9a-f]{8}\.zip$/.exec(keep);
  if (!m) return [];
  const pack = m[1]!;
  return cached.filter((url) => {
    const file = url.slice(url.lastIndexOf('/') + 1).split(/[?#]/)[0]!;
    const other = /^(.*)-[0-9a-f]{8}\.zip$/.exec(file);
    return other !== null && other[1] === pack && file !== keep;
  });
}
