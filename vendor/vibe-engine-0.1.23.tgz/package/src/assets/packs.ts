/**
 * Downloadable asset packs.
 *
 * The build ships only what the menu and the first round need, so the game is
 * playable in a second or two. Everything else -- new levels, seasonal props,
 * a second biome -- is a `.zip` fetched when it is wanted, decoded through the
 * same code path as built-in assets, and mounted under a prefixed key:
 *
 *     await Assets.mount('reef');
 *     Assets.instance('reef:props/coral');
 *     Assets.unmount('reef');            // frees the GPU memory again
 *
 * A pack is authored as a folder under `packs/` and zipped by
 * `npm run packs`, which content-hashes the filename. URLs are therefore
 * immutable, which is what lets a downloaded pack be cached forever and a
 * replacement never be served stale.
 *
 * **Where packs are fetched from is one setting.** By default it is
 * `packs/`, relative to the page -- so packs ride along in the build's upload and
 * there is no second host, no CORS and no third-party request in the build.
 * Point `VITE_PACK_BASE_URL` at a CDN to serve them from elsewhere instead;
 * everything below is identical either way, and that host then needs
 * `Access-Control-Allow-Origin` for the game's domain.
 *
 * This module is only ever reached through `Assets.mount()`, which imports it
 * dynamically -- the zip reader stays out of the bundle every player downloads.
 */
import { Audio } from '../audio.ts';
import { caseKey } from './case-key.ts';
import { dropMaterials } from './materials.ts';
import { classify, decode } from './pack-decode.ts';
import { Generations, staleZips, Unmounted } from './pack-mounts.ts';
import { drop, mountedPacks } from './store.ts';
import { PACK_UIDS, dropUids, mountUids, type UidRow } from './uids.ts';
import { unzip, type ZipFiles } from './zip.ts';

/** Trailing slash required. Relative resolves against the page, not this chunk. Read as asked, so node can import the module (`packs.test.ts`). */
const base = (): string => import.meta.env.VITE_PACK_BASE_URL ?? 'packs/';

/** Downloaded zips live here, keyed by their immutable URL. */
const CACHE = 'packs-v1';

interface IndexEntry {
  /** Content-hashed filename, e.g. `reef-a3f9c1.zip`. */
  file: string;
  /** Uncompressed download size, for a progress bar before headers arrive. */
  bytes: number;
}

type PackIndex = Record<string, IndexEntry>;

let index: Promise<PackIndex> | undefined;
/** Mounts already in flight, so two callers share one download rather than racing. */
const mounting = new Map<string, Promise<void>>();
/** Each pack's generation: an unmount moves it on, and a mount in flight that sees it moved is called off. */
const generations = new Generations();

/**
 * `packs/index.json`, fetched once per session. Small, and must not go stale.
 *
 * Only a *successful* fetch is remembered. Memoising the promise itself would
 * mean one dropped connection -- a phone changing cell, a tab woken with no
 * network -- poisoned every later `mount()` for as long as the game was open.
 */
function packIndex(): Promise<PackIndex> {
  index ??= fetch(`${base()}index.json`, { cache: 'no-cache' })
    .then((response) => {
      if (!response.ok) throw new Error(`no pack index at ${base()}index.json (${response.status})`);
      return response.json() as Promise<PackIndex>;
    })
    .catch((error: unknown) => {
      index = undefined;
      throw error;
    });
  return index;
}

/** Cache API is unavailable over plain http and in some private modes. */
async function cache(): Promise<Cache | null> {
  try {
    return await caches.open(CACHE);
  } catch {
    return null;
  }
}

/** The zip at `url`, from the cache or the network. `fresh` skips the cache (a cached copy that would not unzip). */
async function download(url: string, expected: number, onProgress?: (f: number) => void, fresh = false): Promise<{ buffer: ArrayBuffer; cached: boolean }> {
  const store = await cache();
  const hit = fresh ? undefined : await store?.match(url);
  if (hit) {
    onProgress?.(1);
    return { buffer: await hit.arrayBuffer(), cached: true };
  }

  const response = await fetch(url);
  if (!response.ok) throw new Error(`pack download failed: ${url} (${response.status})`);

  // Keep a copy for the cache before the body is consumed by the reader.
  const forCache = store ? response.clone() : null;

  const total = Number(response.headers.get('content-length')) || expected;
  const reader = response.body?.getReader();
  let buffer: ArrayBuffer;

  if (!reader || !total) {
    buffer = await response.arrayBuffer();
  } else {
    const chunks: Uint8Array[] = [];
    let received = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.length;
      onProgress?.(Math.min(received / total, 1));
    }
    const joined = new Uint8Array(received);
    let at = 0;
    for (const chunk of chunks) {
      joined.set(chunk, at);
      at += chunk.length;
    }
    buffer = joined.buffer as ArrayBuffer;
  }

  // Best effort: a full cache or a private window must not fail the mount.
  if (forCache) await store?.put(url, forCache).catch(() => {});
  onProgress?.(1);
  return { buffer, cached: false };
}

/** Best effort: the cached zips of this pack but `keep` -- every rebuild a new URL, never asked for again -- deleted. */
async function forgetOlder(keep: string): Promise<void> {
  try {
    const store = await cache();
    if (!store) return;
    for (const url of staleZips((await store.keys()).map((r) => r.url), keep)) await store.delete(url);
  } catch {
    // A cache that cannot be listed costs only disk.
  }
}

export interface MountOptions {
  /** 0..1 across download and decode. Wire it to a progress bar. */
  onProgress?: (fraction: number) => void;
}

async function fetchAndDecode(name: string, onProgress?: (fraction: number) => void): Promise<void> {
  // An unmount while this runs moves the generation on: looked at after every wait, this is then called off.
  const mine = generations.of(name);
  const still = (): void => {
    if (generations.of(name) !== mine) throw new Unmounted(name);
  };
  // The index by the pack's folder as written; `name` is its key, lowercased.
  const packs = await packIndex();
  still();
  const entry = Object.entries(packs).find(([pack]) => caseKey(pack) === name)?.[1];
  if (!entry) throw new Error(`no pack '${name}' in ${base()}index.json`);

  // The download is most of the wait; decoding is the tail.
  const url = `${base()}${entry.file}`;
  const got = await download(url, entry.bytes, (f) => onProgress?.(f * 0.8));
  still();
  let files: ZipFiles;
  try {
    files = await unzip(got.buffer);
  } catch (error) {
    if (!got.cached) throw error;
    // A cached copy that does not unzip (cut short, corrupt) would fail every mount from now on: fetched again.
    files = await unzip((await download(url, entry.bytes, (f) => onProgress?.(f * 0.8), true)).buffer);
  }
  still();

  let done = 0;
  const total = [...files.keys()].filter((p) => classify(p) && !p.endsWith('.json')).length || 1;

  try {
    await decode(name, files, Audio, () => onProgress?.(0.8 + (++done / total) * 0.2));
    still();
  } catch (error) {
    // A pack that failed part-way through -- or was unmounted while it decoded, its decodes landing after
    // the drop -- has assets in the store under a prefix nothing will ever unmount, because it was never
    // marked mounted. Undone, so a retry is a clean mount rather than a half-mount on top of a half-mount.
    // Not through `Packs.unmount`: that would move the generation of a mount started since.
    dropMaterials(`${name}:`);
    drop(`${name}:`);
    Audio.drop(`${name}:`);
    throw error;
  }

  // Its uids (Docs/asset-ids.md §2): the pack's keys, written without its prefix, merged under it. One that does not
  // parse costs the pack its uids, never its assets: nothing resolves by uid yet (9.2).
  const uids = files.get(PACK_UIDS);
  if (uids) {
    try {
      mountUids(name, JSON.parse(new TextDecoder().decode(uids)) as Record<string, UidRow>);
    } catch (error) {
      console.error(`[packs] ${name}: its ${PACK_UIDS} does not parse -- ${(error as Error).message}`);
    }
  }
  mountedPacks.add(name);
  onProgress?.(1);
  void forgetOlder(entry.file);
}

export const Packs = {
  /** Pack names the server is currently offering. */
  async available(): Promise<string[]> {
    return Object.keys(await packIndex());
  },

  isMounted: (name: string): boolean => mountedPacks.has(caseKey(name)),

  mounted: (): string[] => [...mountedPacks],

  /**
   * Downloads, unzips and mounts a pack. Idempotent, and safe to call while
   * gameplay is stopped -- decoding a large pack will drop frames, so do it
   * between rounds rather than during one.
   *
   * Overlapping calls for the same pack share one download. The pack is not
   * marked mounted until it is decoded, so without this a second caller
   * arriving mid-decode would fetch and decode the whole thing again -- and the
   * second copy of a music track would strand the first one's blob URL and its
   * audio node. `onProgress` is only reported to the call that started the
   * mount; a later one simply waits.
   */
  mount(asked: string, { onProgress }: MountOptions = {}): Promise<void> {
    const name = caseKey(asked);
    if (mountedPacks.has(name)) return Promise.resolve();

    const existing = mounting.get(name);
    if (existing) return existing;

    const job = fetchAndDecode(name, onProgress).finally(() => {
      if (mounting.get(name) === job) mounting.delete(name);
    });
    mounting.set(name, job);
    return job;
  },

  /**
   * Frees everything a pack added, GPU memory included. A mount of it still in
   * flight is called off: it drops what it added and rejects (`Unmounted`).
   */
  unmount(asked: string): void {
    const name = caseKey(asked);
    generations.bump(name);
    // A mount asked for from here on starts afresh, not by joining the one called off.
    mounting.delete(name);
    // `drop` clears the mounted flag itself -- it owns both, so they cannot drift.
    dropMaterials(`${name}:`);
    drop(`${name}:`);
    Audio.drop(`${name}:`);
    dropUids(name);
  },

  /** Forgets every downloaded zip. The next mount re-downloads. */
  async clearCache(): Promise<void> {
    await caches.delete(CACHE).catch(() => {});
  },
};
