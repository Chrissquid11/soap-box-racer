/**
 * A part of a model (Docs/render.md §3): the object of a name in a glb's scene
 * -- a Gladius `part{ name }` is a node of that name -- copied on its own, for
 * `Assets.instance(key, part)`, `partsOf` and the prefab compile's
 * `prefabChecks.parts`.
 *
 * - **Placed as in the model.** The copy comes back inside a group at the
 *   model's origin, itself carrying every transform between the scene and it
 *   (its ancestors' and its own, composed): a view's root is the entity's to
 *   place (`present` writes its matrix), so a part placed at the entity sits
 *   where it sits in the whole model, however deep it is.
 * - **A skinned part needs its skeleton inside it.** A `SkinnedMesh` under the
 *   part whose bones are not all under the part too would copy bound to bones
 *   the copy lacks: refused, naming the part and the mesh. Name the node that
 *   holds both the mesh and its armature, or draw the whole model.
 *
 * three and SkeletonUtils alone, no DOM and no registry: a node test imports
 * it (`parts.test.ts`), which `assets/index.ts` cannot be.
 */
import * as THREE from 'three';
import { clone as cloneSkinned } from 'three/addons/utils/SkeletonUtils.js';
import { caseKey } from './case-key.ts';

/** The first object below `scene` (itself left out) whose name is `part`, in any case. */
export function namedIn(scene: THREE.Object3D, part: string): THREE.Object3D | null {
  const want = caseKey(part);
  let found: THREE.Object3D | null = null;
  scene.traverse((o) => {
    if (found === null && o !== scene && o.name !== '' && caseKey(o.name) === want) found = o;
  });
  return found;
}

/** Every named object below `scene`, each name once, sorted: what a `Render.model` part may name. */
export function partNames(scene: THREE.Object3D): string[] {
  const names = new Set<string>();
  scene.traverse((o) => {
    if (o !== scene && o.name !== '') names.add(o.name);
  });
  return [...names].sort();
}

/**
 * A copy of the part `part` of `scene` (the model `key`'s), placed as in the model: a group at the
 * model's origin with the copy inside, at the transform between the scene and the part. The group's
 * `userData.assetKey` is the scene's, its `assetPart` the part's name. Throws for a part the model
 * lacks (naming the ones it has) and for a skinned mesh in the part whose bones are not all in it.
 */
export function instancePart(scene: THREE.Object3D, key: string, part: string): THREE.Object3D {
  const node = namedIn(scene, part);
  if (!node) throw new Error(`model '${caseKey(key)}' has no part '${part}': its named objects are ${partNames(scene).join(', ') || 'none'}`);
  const loose = looseSkin(node);
  if (loose !== null) {
    throw new Error(`model '${caseKey(key)}' part '${node.name}': the skinned mesh '${loose.name || '(unnamed)'}' in it has bones outside it -- name the node that holds the mesh and its armature both, or draw the whole model`);
  }
  // The placement from the scene down to the part, the part's own included: each local transform composed.
  const placed = new THREE.Matrix4().compose(node.position, node.quaternion, node.scale);
  const local = new THREE.Matrix4();
  for (let p = node.parent; p !== null && p !== scene; p = p.parent) placed.premultiply(local.compose(p.position, p.quaternion, p.scale));
  const copy = cloneSkinned(node);
  placed.decompose(copy.position, copy.quaternion, copy.scale);
  copy.updateMatrix();
  const root = new THREE.Group();
  root.name = node.name;
  root.userData.assetKey = scene.userData.assetKey;
  root.userData.assetPart = node.name;
  root.add(copy);
  return root;
}

/** A skinned mesh under `node` (itself included) bound to a bone that is not under `node`, or null. */
function looseSkin(node: THREE.Object3D): THREE.SkinnedMesh | null {
  let loose: THREE.SkinnedMesh | null = null;
  node.traverse((o) => {
    if (loose !== null || !(o as THREE.SkinnedMesh).isSkinnedMesh) return;
    const mesh = o as THREE.SkinnedMesh;
    const bones = mesh.skeleton ? mesh.skeleton.bones : [];
    for (const bone of bones) {
      if (!under(bone, node)) {
        loose = mesh;
        return;
      }
    }
  });
  return loose;
}

/** `o` is `node` or below it. */
function under(o: THREE.Object3D, node: THREE.Object3D): boolean {
  for (let p: THREE.Object3D | null = o; p !== null; p = p.parent) if (p === node) return true;
  return false;
}
