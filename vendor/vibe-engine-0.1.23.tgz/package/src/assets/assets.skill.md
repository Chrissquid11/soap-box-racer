---
skill: engine
title: Assets
when: Before adding, naming, moving or loading an asset -- keys, uids, Assets and its accessors, preload, packs, AssetsSource/ and export options
covers:
  modules: [assets/, data.ts, scenes.ts, prefabs.ts]
order: 50
---
# Assets: files are keys

There is no manifest. **A file under `src/assets/<kind>/` is its key**: its path under the kind's folder,
lowercased, without the extension. The generated `src/assets/keys.d.ts` knows every key, so a wrong one is a type
error, and every URL comes from a glob Vite rewrote -- never one built from a string. The runtime is
`@vibe/engine/assets` (`node_modules/@vibe/engine/src/assets/`: `index.ts` is `Assets`, `registry.ts` the URLs);
the pipeline that makes the files is `@vibe/pipeline`'s.

## Three folders

| Folder | What it is |
|---|---|
| `AssetsSource/` | the originals -- Gladius scripts (`.lua`), `.blend`, `.fbx`, `.psd`, `.wav` masters -- never in a build. The `gladius` skill makes models here |
| `src/assets/` | **the boot set**: shipped, hashed, all of it loaded before the first frame. A budget, not a bucket |
| `packs/<name>/` | shipped later, zipped, loaded on demand between rounds |

A source and its export have the same path: `AssetsSource/models/props/crate.lua` ships as
`src/assets/models/props/crate.glb`; `AssetsSource/packs/reef/audio/sfx/bubble.wav` as
`packs/reef/audio/sfx/bubble.ogg`. A file that already ships as it is (a `.woff2`, an icon `.svg`, an `.ogg`)
may go straight into `src/assets/`. `AssetsSource/reference/` holds what nothing is made from.

## Keys

| File | Key | In code |
|---|---|---|
| `models/props/crate.glb` | `props/crate` | `Assets.instance('props/crate')` (a tool's object), `Render.model` (an entity's) |
| `textures/environment/sand.webp` | `environment/sand` | `Assets.texture('environment/sand')`, a material's `"map"` |
| `sprites/fx.png` + `fx.json` | `fx` | `Assets.atlas('fx')` |
| `icons/coin.svg` | `coin` | `Assets.iconUrl('coin')` |
| `fonts/fredoka-700.woff2` | `fredoka-700` | `Assets.fontUrl('fredoka-700')` |
| `audio/sfx/pickup.ogg` | `pickup` | `Audio.sfx('pickup')` -- [the audio page](audio.md) |
| `prefabs/crates/big.prefab` | `crates/big` | `prefab('crates/big')` -- [the prefabs page](prefabs.md) |
| `scenes/forest/camp.scene` | `forest/camp` | `game.load(scene('forest/camp'))` |
| `materials/props/rust.material` | `props/rust` | `"material": "props/rust"` in a `Render` -- [the render page](render.md) |
| `levels/one.json` | `one` | `level('one')` |
| `<kind>/...` of a project's own data kind | its path | `Assets.data('tilemaps', key)`, `Assets.dataKeys('tilemaps')` |

- **A key is the path lowercased; lookups take any case**: `models/props/Big Crate.glb` is `props/big crate`,
  and `Assets.instance('Props/Big Crate')` finds it. Never two names that differ only by case (one key): the
  key generator and the editor refuse it. A case-only rename goes through the editor or `git mv` -- macOS's git
  would not see it, and the live host, which is case-sensitive, would 404.
- **A leading `_` leaves a file or folder out of the build** (`_crab-v2.glb`, `_wip/`).
- Two files that differ only by extension want one key: rename one. A model ships as `.glb`, never `.gltf` with a
  `.bin`.
- A key appears the moment a file does: in the dev server the generated files are written again and the page
  syncs without a reload. By hand, `npm run assets`.

## Uids: a key in code, `{ "uid", "key" }` in files

Every asset has a uid the pipeline stamps once: a data file's top-level `"uid"`, a source's in its record
(`<stem>.export.json`), a loose file's in a `<file>.uid` beside it. A file (a prefab, a scene, a material, a
level) names an asset by both:

```json
"Render": { "model": { "uid": "uid://my6h25vyerffh", "key": "props/crate" } }
```

- **Write the key alone** (`"model": "props/crate"`): the pipeline adds the uid when it next passes. Keep a uid a
  file has; **never make one up**.
- **A file moved or renamed** -- in the editor, the Finder, git -- needs no edit of a file naming it: its uid still
  finds it, and the pipeline rewrites the keys in files. Code names assets by key, so **code naming a key changes
  first**; the editor refuses to move an asset code names. A loose file and its `.uid` move together.
- `npm test`'s `uids` check fails on an asset with no uid or a uid that is two assets'.

## Load first, then build

`Assets.preload()` loads the whole boot set before the `Game` is made -- `boot()` does it, behind the loading bar.
So gameplay code is synchronous: every accessor answers at once, and throws (naming the key) for one that is not
there. Keep the boot set to what the menu and the first round need.

```ts
import { Assets } from '@vibe/engine/assets';

/** Between rounds: a pack's keys work once it is mounted (`'reef'` is an `AssetKeys.Pack`, a folder under packs/). */
export async function nextRound(pack: AssetKeys.Pack, bar: (fraction: number) => void): Promise<void> {
  await Assets.mount(pack, { onProgress: bar });
}
```

- **A pack** is `packs/<name>/`, the same folders as `src/assets/` (but `icons/` and `fonts/`). `Assets.mount(name)`
  between rounds -- decoding drops frames -- and its keys carry its name: `'reef:props/coral'` (a `Render.model`, or
  `Assets.instance` for a tool's object), `Audio.sfx('reef:bubble')`. A pack's key used before it is mounted throws
  `needs its pack`.
  `Assets.unmount(name)` frees it (pooled instances drawing it are drained first; an unpooled instance out is the
  game's to destroy before).
- `npm run packs` (and every build, and the dev server) zips each into `public/packs/`; `Assets.availablePacks()`
  lists what the server offers.

## Exporting: `AssetsSource/` into `src/assets/`

Every source ships through the pipeline. **In the dev server a saved source is exported by itself** (and the new
file swapped into every entity drawing it, where it stands); otherwise `npm run export`, or the studio's Assets
panel. How a source is converted is its recipe, by its folder and extension:

| Source | Becomes |
|---|---|
| `models/**.lua` (Gladius) | `.glb`: built by Gladius, normals, WebP textures, Draco |
| `models/**.gltf`, `.glb` | `.glb`, the same finishing steps |
| `models/**.fbx`, `.obj`, `.dae`, `.stl` | `.glb`, converted in a game tab (the studio open on this machine) into `_<stem>.glb` beside the source, committed, then the same finishing steps |
| `models/**.blend` | `.glb` by Blender where it is installed; elsewhere a person exports `_<stem>.glb` from Blender by hand, beside the `.blend`, committed -- the finishing steps run from it, and a changed `.blend` needs exporting again |
| `textures/**.png`, `.jpg`, `.tif`, `.psd`, `.kra` | `.webp` |
| `sprites/**.aseprite` | `.png` and its `.json` |
| `audio/sfx/**.wav`, `.flac`, `.aif` (and `ui/`, `music/`) | `.ogg` (sounds mono when the channels match, lead silence trimmed; music as it is) |
| an `.ogg`, `.png`, `.woff2`, `.svg`, ... | copied as it is |

**Options** go in `<stem>.export.json` beside the source (`"options"`, only what differs) and a folder's defaults in
its `export.json` -- `{ "options": { "lossless": true } }` in `AssetsSource/textures/ui/` -- the nearest winning.
The studio's Assets panel writes both (its Options block). The ones a game reaches for:

| Option | For | What it does |
|---|---|---|
| `angle`, `keepNormals` | models | smooth below this angle; or keep the model's own normals |
| `draco`, `textureMax`, `textureQuality` | models | geometry compression; the embedded textures' size and quality |
| `anim`, `merge`, `cull`, `params` | `.lua` | animation samples dropped; draw calls merged; hidden surfaces removed; the script's parameters |
| `max`, `quality`, `lossless`, `pow2` | textures | the longer side; WebP quality, or lossless (UI art); power-of-two sides |
| `quality`, `mono`, `trim` | audio | Vorbis quality; mono `auto`/`always`/`never`; silence cut |

- The record's `built` is the pipeline's: never edited. **Out of the build** is `"include": false` at the top of a
  source's record (or a loose file renamed with a leading `_`); the Assets panel's tick does either.
- `npm run export -- --check` fails when an export is stale, missing, or not what was built (CI's gate).
- A tool an export needs (Gladius, ffmpeg with libvorbis, Blender) and lacks is said on the source, with what to
  install.
- Binary files go through Git LFS (`.gitattributes`): a fresh clone needs `git lfs install` first.

## The rules that bite

- Never a URL built from a path (`'models/' + name + '.glb'` 404s once hashed): everything through `Assets`,
  `Audio` and the files' keys.
- Never edit a generated file (`keys.d.ts`, the globs, the bundles, `uids.ts`, `src/game/live.ts`), and never import
  a glob file anywhere: each has its one importer.
- Never an original in `src/assets/` or `public/` that needs converting: it goes in `AssetsSource/`.
- Code that a node test imports takes nothing from `@vibe/engine/assets` but types.
- A model's materials are shared by every instance: a per-entity look is `Render.tint` or another material file.

In the studio, files are made, moved, renamed and exported with the asset tools, never `mv`, `rm` or `cp`: [the
studio's assets page](../studio/assets.md).
