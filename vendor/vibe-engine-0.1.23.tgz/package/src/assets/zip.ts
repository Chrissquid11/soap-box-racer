/**
 * A minimal ZIP reader, for downloaded asset packs.
 *
 * No dependency: deflate is handled by the platform's `DecompressionStream`,
 * which every browser worth shipping to has had for years. That keeps the pack
 * loader at a few hundred bytes of chunk instead of pulling in an inflate
 * implementation for something the browser already does.
 *
 * Only what a pack needs is supported -- store (0) and deflate (8), no
 * encryption, no Zip64, no spanning. Anything else throws by name rather than
 * decoding to garbage.
 *
 * Every entry's CRC is checked. A pack arrives over a phone network from a CDN,
 * and a silently truncated model is far harder to diagnose later than a loud
 * failure here.
 */

const EOCD_SIG = 0x06054b50;
const CENTRAL_SIG = 0x02014b50;
const LOCAL_SIG = 0x04034b50;

/** Max size of the end-of-central-directory record plus its comment. */
const EOCD_MAX = 22 + 0xffff;

const CRC_TABLE = /* @__PURE__ */ (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let bit = 0; bit < 8; bit++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]!) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

async function inflateRaw(bytes: Uint8Array): Promise<Uint8Array> {
  const stream = new Blob([bytes as BlobPart]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

interface Entry {
  name: string;
  method: number;
  crc: number;
  compressedSize: number;
  size: number;
  localOffset: number;
}

/** One file out of an archive, decompressed and verified. */
export type ZipFiles = Map<string, Uint8Array>;

/**
 * Reads every file out of a ZIP.
 *
 * Directory entries and macOS's `__MACOSX` noise are dropped, so a pack zipped
 * in Finder behaves the same as one from the build script.
 */
export async function unzip(archive: ArrayBuffer): Promise<ZipFiles> {
  const view = new DataView(archive);
  const bytes = new Uint8Array(archive);

  // The EOCD is at the end, after a variable-length comment, so scan back.
  let eocd = -1;
  for (let i = view.byteLength - 22; i >= Math.max(0, view.byteLength - EOCD_MAX); i--) {
    if (view.getUint32(i, true) === EOCD_SIG) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error('not a zip file (no end-of-central-directory record)');

  const count = view.getUint16(eocd + 10, true);
  let offset = view.getUint32(eocd + 16, true);
  if (count === 0xffff || offset === 0xffffffff) throw new Error('zip64 archives are not supported');

  const entries: Entry[] = [];
  for (let i = 0; i < count; i++) {
    if (view.getUint32(offset, true) !== CENTRAL_SIG) throw new Error('corrupt zip (bad central directory entry)');

    const nameLength = view.getUint16(offset + 28, true);
    const extraLength = view.getUint16(offset + 30, true);
    const commentLength = view.getUint16(offset + 32, true);
    const name = new TextDecoder().decode(bytes.subarray(offset + 46, offset + 46 + nameLength));

    entries.push({
      name,
      method: view.getUint16(offset + 10, true),
      crc: view.getUint32(offset + 16, true),
      compressedSize: view.getUint32(offset + 20, true),
      size: view.getUint32(offset + 24, true),
      localOffset: view.getUint32(offset + 42, true),
    });

    offset += 46 + nameLength + extraLength + commentLength;
  }

  const files: ZipFiles = new Map();
  for (const entry of entries) {
    if (entry.name.endsWith('/') || entry.name.startsWith('__MACOSX/') || entry.name.includes('/.')) continue;
    if (view.getUint32(entry.localOffset, true) !== LOCAL_SIG) {
      throw new Error(`corrupt zip (bad local header for ${entry.name})`);
    }

    // The local header repeats the name and may carry different extra data,
    // so its lengths -- not the central directory's -- locate the payload.
    const nameLength = view.getUint16(entry.localOffset + 26, true);
    const extraLength = view.getUint16(entry.localOffset + 28, true);
    const start = entry.localOffset + 30 + nameLength + extraLength;
    const raw = bytes.subarray(start, start + entry.compressedSize);

    let data: Uint8Array;
    if (entry.method === 0) data = raw;
    else if (entry.method === 8) data = await inflateRaw(raw);
    else throw new Error(`${entry.name}: unsupported zip compression method ${entry.method}`);

    if (data.length !== entry.size) {
      throw new Error(`${entry.name}: expected ${entry.size} bytes, got ${data.length} -- truncated download?`);
    }
    if (crc32(data) !== entry.crc) throw new Error(`${entry.name}: CRC mismatch -- corrupt download`);

    files.set(entry.name, data);
  }

  return files;
}
