/**
 * The engine's `animate` system (Docs/render.md §5): every entity with an
 * `Animation` and a `View` plays the clip its `Animation` names, by name, on
 * its view's model -- crossfaded when it changes, looped as it says or as the
 * clip's extras say, at its speed, `time` written back each frame -- and a
 * clip played once says so when it ends (`AnimationEnded`).
 *
 * - **A player per view object** (a mixer, an action per clip by name, made as
 *   asked), kept in a `WeakMap` by the object, so it goes with it: a model
 *   re-picked or re-exported is a new object (the `render` system's `putView`,
 *   `swapView`) and gets a new player, resuming at `time`; a pooled instance's
 *   parked view keeps its own. Made the first time an `Animation` meets a view
 *   whose model has clips (`options.clips`: `Game` hands in the model's
 *   `animations`, found by the view's `userData.assetKey`); a view with none is
 *   noted so, and asked nothing again. Skinned meshes are drawn whatever their
 *   rest-pose bounds say (`frustumCulled` off): a pose is the bones'.
 * - **Each frame**, per member: `clip` changed -- the named action reset and
 *   played from 0 (from its end at a negative `speed`), crossfaded from the
 *   last over `fade`, looped by `loop` (1 repeat, 2 once and held, 0 as the
 *   clip's extras say: `loop: false` once);
 *   a name the model lacks said once and the rest pose shown (the last faded
 *   out over `fade`), as for none (0). `time` other than what this wrote last
 *   -- a save loaded, a pooled instance reset to its prefab's 0, a tool's seek
 *   -- moves the action there. Then `mixer.update(frameDt * |speed|)`, the
 *   action's `timeScale` -1 for a negative `speed` (backwards is the
 *   action's: the mixer's own clock times the fades), and `time` written
 *   back from the action; no time passed and nothing begun (a
 *   stopped game's frame, a speed of 0), nothing.
 * - **A once clip at its end** emits `AnimationEnded { who, clip }`, once a
 *   play. From the render phase, outside a tick: it belongs to the last tick
 *   and the next tick's readers see it (`world.eventTick`, Docs/ecs.md §18).
 *   A new player that finds it already at its end (`time` at the clip's
 *   length: a save loaded, `Game.rebuild`, a model re-exported) says nothing:
 *   that play ended, and was said, before.
 * - **A pooled instance** keeps its view parked (Docs/prefabs.md §5), and so
 *   its player: at the reset (`onInstance`) the player is begun again, so a
 *   reused instance plays the prefab's `clip` from 0 -- what the reset put back
 *   -- with no crossfade from what it played before it was given back.
 * - **`Animation` removed** (or the entity destroyed): its player's actions
 *   stopped -- the model back to its rest pose -- and the player dropped.
 *
 * The page's: it imports three (its `AnimationMixer`, which node can make on a
 * plain `Object3D`: `animation.test.ts`). Returns its uninstall, for
 * `Game.rebuild`: every player let go.
 */
import * as THREE from 'three';
import { Animation, AnimationEnded, AnimationLoop, Instance, keyText, type Entity, type Store, type World } from './ecs/index.ts';
import { extrasLoop } from './assets/clip-info.ts';
import { View } from './view.ts';

/** What the animate system is handed: the page's assets, or a test's. */
export interface AnimationOptions {
  /** The clips of the model `view` was made of (`Assets.model(key).animations`); none for a model with none. */
  clips(view: THREE.Object3D): readonly THREE.AnimationClip[];
}

/** One view object's clips, played. */
class Player {
  readonly mixer: THREE.AnimationMixer;
  readonly clips: readonly THREE.AnimationClip[];
  /** By clip name, made the first time it is played. */
  readonly actions = new Map<string, THREE.AnimationAction>();
  /** The `Clip` id it plays now (-1: none yet, a new player), and its action (null: the rest pose). */
  clip = -1;
  action: THREE.AnimationAction | null = null;
  /** Plays once: says `AnimationEnded` at its end, once (`ended`). */
  once = false;
  ended = false;
  /** The `time` this wrote last, as the column holds it: anything else there is a seek. */
  wrote = 0;

  constructor(object: THREE.Object3D, clips: readonly THREE.AnimationClip[]) {
    this.mixer = new THREE.AnimationMixer(object);
    this.clips = clips;
    // A pose is the bones', so the rest-pose bounds are wrong the moment it moves.
    object.traverse((o) => {
      if ((o as THREE.SkinnedMesh).isSkinnedMesh) o.frustumCulled = false;
    });
  }

  /** The action of the clip named `name`, or null for a name the model lacks. */
  actionOf(name: string): THREE.AnimationAction | null {
    let action = this.actions.get(name);
    if (action === undefined) {
      const clip = this.clips.find((c) => c.name.toLowerCase() === name);
      if (clip === undefined) return null;
      action = this.mixer.clipAction(clip);
      this.actions.set(name, action);
    }
    return action;
  }

  /** Every action stopped: the model back to its rest pose. */
  stop(): void {
    this.mixer.stopAllAction();
    this.action = null;
  }
}

/** The frame's seconds, for `step`: a fraction handed to a call is boxed, one kept in a typed array is not. */
const frameSeconds = new Float64Array(1);

/** No clips on this view's model: noted, so it is asked nothing again. */
const NONE = null;

/** `Animation`'s columns, as the system reads and writes them. */
type Anims = Store<typeof Animation.schema>;

/** The loop a play takes: `loop` 1 repeat, 2 once, 0 as the clip says (Gladius's extras; unsaid, repeat). */
function playsOnce(loop: number, clip: THREE.AnimationClip): boolean {
  if (loop === AnimationLoop.repeat) return false;
  if (loop === AnimationLoop.once) return true;
  return extrasLoop(clip.userData) === false;
}

/**
 * The `animate` system on `world`, after `installView` and `installRender`.
 * Returns the uninstall: every player let go (the system and the hooks go with
 * the world's reset).
 */
export function installAnimation(world: World, { clips }: AnimationOptions): () => void {
  let players = new WeakMap<THREE.Object3D, Player | typeof NONE>();
  const views = world.store(View);
  const ended = world.events(AnimationEnded);
  /** The clip names said missing, by model: each said once, its words built only then. */
  const said = new Map<string, Set<string>>();
  const sayMissing = (model: string, name: string, player: Player): void => {
    let names = said.get(model);
    if (names === undefined) said.set(model, (names = new Set()));
    if (names.has(name)) return;
    names.add(name);
    console.warn(`[animate] Animation.clip '${name}': ${model} has no clip of that name (it has ${player.clips.map((c) => c.name).join(', ')}) -- the rest pose shown`);
  };

  /** `object`'s player, made the first time; null for a model with no clips. */
  const playerOf = (object: THREE.Object3D): Player | null => {
    const known = players.get(object);
    if (known !== undefined) return known;
    const list = clips(object);
    const made = list.length === 0 ? NONE : new Player(object, list);
    players.set(object, made);
    return made;
  };

  /**
   * `e`'s `clip` begun on `player`: crossfaded from what played, or the rest pose for none or a name the model
   * lacks. A new player resumes where `time` says (a loaded save, a view made anew); a clip changed starts at 0,
   * or at its end when `speed` is negative (it plays backwards).
   */
  const play = (e: Entity, player: Player, a: Anims): void => {
    const id = a.clip[e]!;
    const was = player.action;
    const fresh = player.clip === -1;
    player.clip = id;
    player.ended = false;
    player.once = false;
    const name = id === 0 ? null : keyText('Clip', id);
    const next = name === null ? null : player.actionOf(name);
    if (name !== null && next === null) sayMissing((views.value[e]?.userData.assetKey as string | undefined) ?? 'its model', name, player);
    const fade = Math.max(0, a.fade[e]!);
    if (next === null) {
      // The rest pose: what played faded out, or stopped at once.
      if (was !== null && fade > 0 && !fresh) was.fadeOut(fade);
      else player.stop();
      player.action = null;
      a.time[e] = 0;
      player.wrote = a.time[e]!;
      return;
    }
    const from = fresh ? a.time[e]! : a.speed[e]! < 0 ? next.getClip().duration : 0;
    next.reset();
    player.once = playsOnce(a.loop[e]!, next.getClip());
    next.setLoop(player.once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity);
    next.clampWhenFinished = player.once;
    next.time = from;
    if (was !== null && was !== next && fade > 0) next.crossFadeFrom(was, fade, false);
    else if (was !== null && was !== next) was.stop();
    next.play();
    // A new player on a once clip held at its end (a save loaded, a world rebuilt, a view made anew): it ended
    // before this player was made, and said so then. Without this the next update finishes it again.
    if (fresh && player.once && a.speed[e]! >= 0 && from >= next.getClip().duration - 1e-4) player.ended = true;
    player.action = next;
    a.time[e] = from;
    player.wrote = a.time[e]!;
  };

  /** The action moved to `time`, as a load or a seek asks: its fades and its end said again. */
  const seek = (player: Player, action: THREE.AnimationAction, time: number): void => {
    action.reset();
    action.time = time;
    action.play();
    player.ended = false;
  };

  // An instance made, loaded or reset into its pool: its players begun again, as new ones are -- the clip its
  // `Animation` says (a reset puts the prefab's back) from its `time` (0 after a reset), no crossfade from what
  // played before. A parked instance keeps its view, so its player is kept too: this is what makes it play anew.
  world.onInstance((root) => {
    const inst = world.rawStore(Instance) as { next: ArrayLike<number> };
    for (let e = root as number; e !== 0; e = inst.next[e]!) {
      const object = views.value[e];
      const player = object ? players.get(object) : undefined;
      if (!player) continue;
      player.stop();
      player.clip = -1;
    }
  });

  world.onRemove(Animation, (e) => {
    const object = views.value[e];
    if (object === null || object === undefined) return;
    const player = players.get(object);
    if (player) player.stop();
    players.delete(object);
  });

  world.system({
    name: 'animate',
    phase: 'render',
    read: [View],
    write: [Animation],
    update({ members, count, frameDt, ref }, [view], [a]) {
      frameSeconds[0] = frameDt;
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const object = view.value[e];
        if (object === null || object === undefined) continue;
        const player = playerOf(object);
        if (player === null) continue;
        step(e, player, a);
        if (player.once && !player.ended && player.action !== null && !player.action.isRunning()) {
          player.ended = true;
          const i = ended.emit();
          ended.who[i] = ref(e);
          ended.clip[i] = player.clip;
        }
      }
    },
  });

  /** One member's frame: a change of clip played, a seek done, the mixer moved on and `time` written back. */
  const step = (e: Entity, player: Player, a: Anims): void => {
    let moved = false;
    if (player.clip !== a.clip[e]) {
      play(e, player, a);
      moved = true;
    } else if (player.action !== null && a.time[e] !== player.wrote) {
      seek(player, player.action, a.time[e]!);
      moved = true;
    }
    const speed = a.speed[e]!;
    const dt = frameSeconds[0]! * (speed < 0 ? -speed : speed);
    // No time passed (a stopped game's frame, a speed of 0) and nothing begun: the pose is as it was.
    if (dt === 0 && !moved) return;
    // Backwards is the action's direction, never the mixer's: the mixer's clock times the crossfades, and run
    // backwards a fade would never finish. Written only when it turns, a whole number.
    const action = player.action;
    if (action !== null && action.timeScale !== (speed < 0 ? -1 : 1)) action.timeScale = speed < 0 ? -1 : 1;
    player.mixer.update(dt);
    if (player.action !== null) a.time[e] = player.action.time;
    player.wrote = a.time[e]!;
  };

  return () => {
    players = new WeakMap();
  };
}
