/**
 * The prefab files for node tests: what a project's generated `prefab-bundle.ts` hands `prefabs.ts` by glob, read
 * from disk -- the same keys, lowercased (`crates/big` for `src/assets/prefabs/Crates/Big.prefab`),
 * the same files left out (a leading `_` on a file or folder). The project's folder is
 * the caller's to name: `prefabFilesFromDisk(new URL('../assets/prefabs/', import.meta.url))`.
 *
 * Node only (`node:fs`): nothing the browser imports may import this, and
 * nothing here may reach `import.meta.glob`.
 */
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { PrefabFile } from './ecs/prefab.ts';
import { caseKey } from './assets/case-key.ts';

/** A prefab file's ending, JSON inside: `packages/pipeline/src/assets/kinds.ts`' `PREFAB_SUFFIX` (nothing here may import the pipeline). */
const PREFAB_SUFFIX = '.prefab';

/** Every prefab file (`.prefab`, JSON inside) under `folder` (a project's `src/assets/prefabs/`), parsed, by key. A stray `.json` is none. */
export function prefabFilesFromDisk(folder: string | URL): Record<string, PrefabFile> {
  const dir = typeof folder === 'string' ? folder : fileURLToPath(folder);
  const out: Record<string, PrefabFile> = {};
  const walk = (sub: string): void => {
    for (const entry of readdirSync(join(dir, sub), { withFileTypes: true })) {
      if (entry.name.startsWith('_') || entry.name.startsWith('.')) continue;
      if (entry.isDirectory()) walk(`${sub}${entry.name}/`);
      else if (entry.name.endsWith(PREFAB_SUFFIX)) out[caseKey(`${sub}${entry.name.slice(0, -PREFAB_SUFFIX.length)}`)] = JSON.parse(readFileSync(join(dir, sub, entry.name), 'utf8')) as PrefabFile;
    }
  };
  walk('');
  return out;
}
