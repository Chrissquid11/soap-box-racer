/**
 * The music's cross-fade (`Audio.music`, `audio.ts`): each track has a
 * gain of its own between its element and the music bus, so the track going
 * out fades down while the one coming in fades up -- the bus itself holds
 * only the player's volume. A track going out is paused once its fade is
 * over, unless it is chosen again first: then that pause is called off and it
 * fades back up from where it is, never stopped by a fade-out it outlived.
 *
 * Pure: no Web Audio, no DOM -- the gains and the timer are handed in, so a
 * node test drives it with fakes (`music-fade.test.ts`).
 */

/** What of an `AudioParam` a fade uses. */
export interface FadeParam {
  value: number;
  cancelScheduledValues(at: number): unknown;
  setValueAtTime(value: number, at: number): unknown;
  linearRampToValueAtTime(value: number, at: number): unknown;
}

/** The timer: `setTimeout` and `clearTimeout` in a page. */
export interface FadeClock {
  later(run: () => void, ms: number): unknown;
  cancel(handle: unknown): void;
}

export class MusicFades {
  private readonly seconds: number;
  private readonly clock: FadeClock;
  /** A track fading out: the pause waiting for its fade to end, by key. */
  private readonly pending = new Map<string, unknown>();

  constructor(seconds: number, clock: FadeClock) {
    this.seconds = seconds;
    this.clock = clock;
  }

  /** `key` faded down to silence from where it is, from `now` (seconds, the context's clock), and paused at the end. */
  out(key: string, gain: FadeParam | null, now: number, pause: () => void): void {
    this.callOff(key);
    if (gain) ramp(gain, 0, now, this.seconds);
    this.pending.set(key, this.clock.later(() => {
      this.pending.delete(key);
      pause();
    }, this.seconds * 1000));
  }

  /**
   * `key` faded up to full from where it is. True when it was still fading
   * out -- still playing, its pause called off -- so the caller lets it carry
   * on rather than start it from the top.
   */
  in(key: string, gain: FadeParam | null, now: number): boolean {
    const sounding = this.callOff(key);
    if (gain && sounding) ramp(gain, 1, now, this.seconds);
    else if (gain) {
      gain.cancelScheduledValues(now);
      gain.setValueAtTime(0, now);
      gain.linearRampToValueAtTime(1, now + this.seconds);
    }
    return sounding;
  }

  /** A track gone for good: its waiting pause called off. */
  forget(key: string): void {
    this.callOff(key);
  }

  /** Is `key` fading out just now? */
  fadingOut(key: string): boolean {
    return this.pending.has(key);
  }

  private callOff(key: string): boolean {
    if (!this.pending.has(key)) return false;
    this.clock.cancel(this.pending.get(key));
    this.pending.delete(key);
    return true;
  }
}

/** From the value it has now -- mid-ramp or not -- to `to`, over `seconds`. */
function ramp(gain: FadeParam, to: number, now: number, seconds: number): void {
  const from = gain.value;
  gain.cancelScheduledValues(now);
  gain.setValueAtTime(from, now);
  gain.linearRampToValueAtTime(to, now + seconds);
}
