/**
 * The data kinds' files, read by Vite: every `src/assets/levels/**\/*.json`, and every file of a
 * project's own data kind (`vibe({ kinds })`: `src/assets/tilemaps/**\/*.tilemap`), by kind and by key.
 *
 * Data is not in the asset registry: a level or a tilemap is data the game reads, not media it
 * decodes. Bundled rather than fetched -- a few kilobytes each, and loading one is then as
 * synchronous as building the world, which `new Game(...)` relies on. A leading `_` keeps a file
 * out, as everywhere in `src/assets/`. The keys are compiler-checked like any other: each kind's
 * key type is its row in `AssetKeys.DataKinds` (`levels: Level`, `tilemaps: Tilemap`), which the
 * project's generated `keys.d.ts` writes.
 *
 * The globs are the project's generated `src/assets/level-globs.ts` and `<name>-globs.ts`, written
 * by `packages/pipeline/src/assets/keys.ts`; the engine imports none of them -- the project's
 * generated `bundle.ts` hands them in (`useBundle`, which calls `useData` once a kind). In the dev
 * server a file saved re-evaluates that bundle alone and hands the files in again: they are copied
 * into this module's map for the kind in place (`syncMap`), so `Assets.data(kind, key)` returns the
 * new file next and the page never reloads; nothing rebuilds a running world, and whoever listens
 * (`onDataFiles`: a tool showing a tilemap) is told -- only when something came, went or changed.
 * `level(key)` and `levelKeys()` are the `levels` kind's accessors over the same store. Pure, no
 * glob: a node test imports it.
 */
import { type AnyCase, caseKey } from './assets/case-key.ts';
import { syncMap, unchanged } from './assets/hot.ts';

/** Each kind's files by key: the path under its folder without the extension, lowercased (`caseKey`). One map a kind, kept for good. */
const KINDS = new Map<string, Map<string, unknown>>();
/** Who is told of a later `useData`, with the kind it changed. */
const heard = new Set<(kind: string) => void>();

/**
 * A kind's files taken in, by their path under `src/assets/` (`./levels/beach.json`), its folder
 * `dir` (the kind's name unless said: a project kind's glob file says it): the first time they fill
 * the kind's map, every later time they are copied into it in place, and whoever listens is told
 * if anything changed.
 */
export function useData(kind: string, files: Record<string, unknown>, dir: string = kind): void {
  const prefix = `./${dir}/`;
  const fresh = new Map<string, unknown>();
  for (const [path, value] of Object.entries(files)) {
    const under = path.startsWith(prefix) ? path.slice(prefix.length) : path;
    fresh.set(caseKey(under.replace(/\.[^./]+$/, '')), value);
  }
  const live = KINDS.get(kind);
  if (!live) {
    KINDS.set(kind, fresh);
    return;
  }
  if (unchanged(syncMap(live, fresh))) return;
  for (const listener of heard) listener(kind);
}

/** Told each time a data kind's files change -- one added, written or removed -- after its map holds them: in the dev server alone. Returns the undo. */
export function onDataFiles(listener: (kind: string) => void): () => void {
  heard.add(listener);
  return () => void heard.delete(listener);
}

/** A data file's parsed contents, by its kind and its key in any case. Throws for a kind or a key that is not there. */
export function data<K extends keyof AssetKeys.DataKinds & string, const Key extends string>(kind: K, asked: AnyCase<Key, AssetKeys.DataKinds[K]>): unknown {
  const key = caseKey(asked);
  const files = KINDS.get(kind);
  if (!files?.has(key)) {
    throw new Error(
      `${kind} missing: no '${key}'${files ? '' : ` -- no ${kind} handed in at all (a project's own kind is vibe({ kinds }) in its vite.config.ts)`}. A file just added is there a moment later in the dev server; elsewhere, run \`vibe assets\`.`,
    );
  }
  return files.get(key);
}

/**
 * A data file's parsed contents by its kind and key, or null where there is none: for the engine's own reading of a kind
 * by a key it was handed as text (the physics stage's materials), which no game's key type checks.
 */
export function dataIfPresent(kind: string, key: string): unknown {
  return KINDS.get(kind)?.get(caseKey(key)) ?? null;
}

/** Every key of a data kind, sorted: for a picker. None for a kind not handed in. */
export function dataKeys<K extends keyof AssetKeys.DataKinds & string>(kind: K): AssetKeys.DataKinds[K][] {
  return [...(KINDS.get(kind)?.keys() ?? [])].sort() as AssetKeys.DataKinds[K][];
}

/** The project's level files taken in (the `levels` kind's `useData`). */
export function useLevels(files: Record<string, unknown>): void {
  useData('levels', files);
}

/** A level file's parsed contents, by its key in any case. Throws for a key that is not there. */
export function level<const K extends string>(asked: AnyCase<K, AssetKeys.Level>): unknown {
  return data<'levels', K>('levels', asked);
}

/** Every level key, sorted: for a level picker. */
export function levelKeys(): AssetKeys.Level[] {
  return dataKeys('levels') as AssetKeys.Level[];
}
