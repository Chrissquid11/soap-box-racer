/**
 * The engine's `render` system (Docs/render.md §3): every entity with a
 * `Render` drawn as it says -- the model or a part of it, the material, the
 * shadows -- through `View`, which it attaches, replaces and takes off. A look
 * is data; this is the one place it becomes a three object.
 *
 * - **On `Render` added** (`onAdd`, at the boundary: an instance made or
 *   loaded, a paste, Add Component) and **for every instance** (`onInstance`:
 *   made, loaded, a pooled one reset): its model made (`instance(model, part)`),
 *   dressed and attached. No model (`0`): nothing drawn, nothing attached.
 * - **Each frame** (the `render` render-phase system): each member's `Render`
 *   against what its view was made with, noted in its `ViewState` row (`ours`,
 *   then `Render`'s five numbers as applied) -- a model or a part changed, the
 *   view replaced where it stands (`putView`); a model gone to none, `View`
 *   taken off (once: the row noted, so the frames until the boundary ask
 *   nothing again); a material or a shadow changed, applied in place. An
 *   inspector edit, an override, a system's write, a prefab recompiled and an
 *   instance refreshed all reach the screen this one way. It compares its own
 *   record rather than listing `changed: [Render]`: a stamp is taken after a
 *   tick, and an edit while the game is paused, or an instance fitted after a
 *   load, comes between ticks. Per member per frame, a view drawn: its `View`
 *   slot read, `ViewState.ours` read, and five integer compares of `Render`'s
 *   columns against `ViewState`'s -- column reads, no lookup, as `present`'s.
 *   A member with no view: one slot read and the model compared to 0.
 * - **On `Render` removed** (or the entity destroyed): `View` taken off with
 *   it, its object to `installView`'s `release`.
 * - **A view it did not make is left alone** (`ViewState.ours` 0, as `attach`
 *   leaves it): one a game or a tool attached by hand on an entity with no
 *   `Render`, or before its `Render` came.
 * - **Materials**: `material` a key -- the store's shared material put on every
 *   mesh of the view (`options.material`: `Game` hands in `Assets.materialIfPresent`,
 *   `assets/materials.ts`); a key with no material drawn as authored, said once;
 *   `0` the model's own. A material file saved changes the shared object in
 *   place, so nothing here runs for it; one added, removed or remade for a new
 *   type is told (`options.onMaterials`), and the members wearing that key are
 *   dressed again the next frame -- their row's material marked stale, so the
 *   compare sees a change.
 * - **Tint**: a `tint` other than white (`0xffffff`) -- each mesh's material,
 *   the model's own or the store's, cloned once for this view, its `color`
 *   multiplied by the tint (`emissive` left alone), the clones kept by view (a
 *   `WeakMap`). A tint changed while tinted writes the clones' colours in place;
 *   back to white, the material changed, the model changed or the view gone, the
 *   clones are disposed and the meshes wear what they were cloned from again. A
 *   material with no `color` is left as it is, said once. A store material
 *   changed in place (`setValues`: a file saved, a swatch dragged) is told too
 *   (`onMaterials`' second list): the tinted views wearing it take its new
 *   values into their clones the next frame (their row's tint marked stale).
 * - **Shadows** on every mesh from `castShadow` and `receiveShadow`
 *   (`Assets.instance` no longer forces them on).
 * - **A pooled instance keeps its view parked** (Docs/prefabs.md §5): the
 *   shape of each object it made (a `WeakMap` by object, read at a reset alone) -- for each node its material (or materials),
 *   its geometry and its number of children -- is recorded **after** it is
 *   dressed, so what this put there -- a tint's clones too -- is its own. At the reset an object whose
 *   shape differs (a material cloned onto it, a geometry replaced, a child
 *   added or taken off) is not, and goes through `release`; the reset puts
 *   `Render` back to the prefab's, and this draws it again. A kept view's
 *   `ViewState` row is carried over the reset's defaults (`kept`), so its
 *   record still says what the object wears. What it neither
 *   notices nor puts back: a node's pose (the animation's to set), `visible`
 *   and `renderOrder` (whoever sets them sets them again), anything in a
 *   node's `userData` or `onBeforeRender` -- never keep per-entity state there
 *   -- and a change written into a shared material, which is every instance's.
 * - **Hot swap** (`swapView`, Docs/assets.md §8): a model re-exported is
 *   dressed with the entity's `Render` before it is put in place
 *   (`dressViews`), and kept as this system's own.
 *
 * Imports three's types alone, as `view.ts` does: a node test installs it on a
 * stand-in scene (`render.test.ts`). Returns its uninstall, for `Game.rebuild`.
 */
import type * as THREE from 'three';
import { Instance, internKey, keyText, optional, Render, splitModel, type Entity, type ReadStore, type Store, type World } from './ecs/index.ts';
import { attach, dressViews, putView, releaseView, View, ViewState } from './view.ts';

/** What the render system is handed: the page's assets, or a test's. */
export interface RenderOptions {
  /** A new object for a model's key, or the part of that name in it (`Assets.instance`). Throws for one there is not. */
  instance(model: string, part: string | null): THREE.Object3D;
  /** The shared material of a material's key, or null for none. */
  material(key: string): THREE.Material | null;
  /**
   * Told the material keys whose object is another now -- a file added, removed, or remade for a new
   * type (`onMaterialFiles`' `replaced`): the views wearing one are dressed again -- and those changed
   * in place (`changed`: `setValues` into the same object), which a tint's clones take in again.
   * Returns the undo.
   */
  onMaterials?(listener: (replaced: readonly string[], changed?: readonly string[]) => void): () => void;
}

/** `Render`'s columns, as the system and the hooks read them. */
type Looks = ReadStore<typeof Render.schema>;
/** `ViewState`'s columns: the record of what was applied, written by the system and the hooks. */
type Notes = Store<typeof ViewState.schema>;

/** A tint of none. */
const WHITE = 0xffffff;
/** A tint no `Render` holds (a colour is 24 bits): a row's tint marked so is dressed again by the compare. */
const STALE_TINT = 0xffffffff;

/**
 * A tinted view's own materials: each mesh slot it cloned (the mesh, the slot in its list or -1 for
 * one material), what the clone was made from, the clone (null: a material with no `color`, left as
 * it is), and the base's `version` when last copied -- a base changed since is copied again.
 */
interface Tinted {
  meshes: Drawn[];
  slots: number[];
  bases: THREE.Material[];
  clones: (THREE.Material | null)[];
  versions: number[];
}

/**
 * The `render` system and its hooks on `world`, after `installView`. Returns
 * the uninstall: the swap's dresser let go; the hooks and the system go with
 * the world's reset, and the views with `installView`'s uninstall.
 */
export function installRender(world: World, { instance, material, onMaterials }: RenderOptions): () => void {
  const views = world.store(View);
  /** The shape of each object this made, after its dressing: weakly, so a view let go keeps nothing here. Read at a pooled reset alone. */
  const shapes = new WeakMap<THREE.Object3D, unknown[]>();
  /** Entities whose model would not make, by the model id that failed: not tried again until it changes. */
  const failed = new Map<number, number>();
  const said = new Set<string>();
  const say = (what: string): void => {
    if (said.has(what)) return;
    said.add(what);
    console.warn(`[render] ${what}`);
  };

  /** Each tinted view's clones, by view: weakly, and freed by `untint` on every way out. */
  const tints = new WeakMap<THREE.Object3D, Tinted>();
  /** The tint as a three colour, for `multiply`: made from the first colour met (this module imports three's types alone). */
  let tintColour: THREE.Color | null = null;

  /** `object`'s tint taken off: its meshes back on what they were cloned from, the clones disposed. */
  const untint = (object: THREE.Object3D): void => {
    const had = tints.get(object);
    if (had === undefined) return;
    tints.delete(object);
    for (let i = 0; i < had.meshes.length; i++) {
      const clone = had.clones[i];
      if (clone === null || clone === undefined) continue;
      if (wornAt(had.meshes[i]!, had.slots[i]!) === clone) wear(had.meshes[i]!, had.slots[i]!, had.bases[i]!);
      clone.dispose();
    }
  };

  /**
   * `tint` on `object`'s meshes, as they are dressed now: each slot's material cloned once and its
   * colour the base's times the tint; the same bases as last time, the same clones written in place.
   * White: none, the clones freed. Runs on a change alone, never a frame with none.
   */
  const stain = (object: THREE.Object3D, tint: number): void => {
    const had = tints.get(object);
    if (tint === WHITE) {
      if (had !== undefined) untint(object);
      return;
    }
    // The slots as dressed now, walked into the scratch lists: a tint changed in place allocates nothing.
    // Written by index, never emptied (`length = 0` lets V8 drop the lists' storage): the first `count` are this walk's.
    const meshes = scratch.meshes;
    const slots = scratch.slots;
    const bases = scratch.bases;
    const count = slotsOf(object, meshes, slots, bases, 0);
    let t = had;
    if (t !== undefined && !sameSlots(t, meshes, slots, bases, count)) {
      untint(object);
      t = undefined;
    }
    if (t === undefined) {
      // alloc-ok: new clones for this view -- a tint applied, or its meshes changed -- not a tint changed in place
      t = { meshes: meshes.slice(0, count), slots: slots.slice(0, count), bases: bases.slice(0, count), clones: [], versions: [] };
      for (let i = 0; i < count; i++) {
        const base = bases[i]!;
        if (!hasColour(base)) {
          say(`Render.tint: material '${base.name || base.type}' has no colour -- left untinted`);
          t.clones.push(null);
          t.versions.push(0);
          continue;
        }
        t.clones.push(base.clone());
        t.versions.push(base.version);
      }
      tints.set(object, t);
    }
    for (let i = 0; i < t.bases.length; i++) {
      const clone = t.clones[i];
      if (clone === null || clone === undefined) continue;
      const base = t.bases[i]!;
      // A base changed in place since (a material file saved): its values taken in again.
      if (t.versions[i] !== base.version) {
        clone.copy(base);
        clone.needsUpdate = true;
        t.versions[i] = base.version;
      }
      const colour = (clone as unknown as Coloured).color;
      tintColour ??= colour.clone();
      tintColour.setHex(tint);
      colour.copy((base as unknown as Coloured).color).multiply(tintColour);
      wear(t.meshes[i]!, t.slots[i]!, clone);
    }
  };

  /** `e`'s `Render` applied to `object` -- shadows, the material, the tint -- and its shape recorded after. True if a store material is on it. */
  const dress = (e: Entity, object: THREE.Object3D, r: Looks): boolean => {
    const id = r.material[e]!;
    let shared: THREE.Material | null = null;
    if (id !== 0) {
      const text = keyText('Material', id) ?? String(id);
      shared = material(text);
      if (shared === null) say(`Render.material '${text}': no such material yet -- drawn as the model's own`);
    }
    // A tint's clones off first: the meshes as dressed before, so the material and the tint go on afresh.
    const had = tints.get(object);
    if (had !== undefined) unstain(had);
    dressMeshes(object, shared, r.castShadow[e] !== 0, r.receiveShadow[e] !== 0);
    stain(object, r.tint[e]!);
    let shape = shapes.get(object);
    if (shape === undefined) {
      shape = [];
      shapes.set(object, shape);
    }
    // Written over by index, cut to what was written: emptied first (`length = 0`), V8 would drop its storage and a
    // tint changed in place would allocate it again.
    const size = record(object, shape, 0);
    if (shape.length !== size) shape.length = size;
    return shared !== null;
  };

  /** `e`'s `Render` as applied, into its `ViewState` row: what the per-frame compare reads. */
  const note = (e: Entity, s: Notes, r: Looks, stored: boolean): void => {
    s.ours[e] = 1;
    s.model[e] = r.model[e]!;
    s.material[e] = r.material[e]!;
    s.tint[e] = r.tint[e]!;
    s.castShadow[e] = r.castShadow[e]!;
    s.receiveShadow[e] = r.receiveShadow[e]!;
    s.stored[e] = stored ? 1 : 0;
  };

  /** The rows of views a pooled reset keeps, seven numbers each (the entity, then what was applied): carried over the reset's defaults. */
  const kept: number[] = [];

  /** Whether the last object `make` made wears a store material: `make` returns the object alone. */
  let madeStored = false;
  /** `e`'s model made and dressed, or null: none, or one that will not make (said once, not tried again until it changes). */
  const make = (e: Entity, r: Looks): THREE.Object3D | null => {
    const id = r.model[e]!;
    if (id === 0 || failed.get(e) === id) return null;
    const text = keyText('Model', id);
    if (text === null) return null;
    const { model, part } = splitModel(text);
    let object: THREE.Object3D;
    try {
      object = instance(model, part);
    } catch (err) {
      failed.set(e, id);
      say(`Render.model '${text}': ${err instanceof Error ? err.message : String(err)} -- nothing drawn`);
      return null;
    }
    failed.delete(e);
    madeStored = dress(e, object, r);
    return object;
  };

  /** `e` drawn, if it has no view yet: attached at the next boundary, its row noted now. */
  const draw = (e: Entity, r: Looks): void => {
    const now = views.value[e];
    if ((now !== null && now !== undefined) || world.has(e, View)) return;
    const object = make(e, r);
    if (object === null) return;
    attach(world, e, object);
    // `attach` gave the row its defaults; the store as it is now (the add may have grown the world).
    note(e, world.store(ViewState), r, madeStored);
  };

  /** `e`'s view taken off at the boundary, its row noted as `Render` says so the frames until then ask nothing again. */
  const takeOff = (e: Entity, s: Notes, r: Looks): void => {
    note(e, s, r, false);
    world.remove(e, View);
    world.remove(e, ViewState);
  };

  /** `e`'s view against its `Render`, changed: made again, taken off, or dressed in place. In the frame, with the system's stores. */
  const update = (e: Entity, object: THREE.Object3D, r: Looks, view: { value: (THREE.Object3D | null)[] }, s: Notes): void => {
    const model = r.model[e]!;
    // To none, or to a model that will not make (said): nothing drawn, as for one added.
    if (model === 0) return takeOff(e, s, r);
    if (s.model[e] !== model || (s.stored[e] === 1 && s.material[e] !== r.material[e])) {
      const next = make(e, r);
      if (next === null) return takeOff(e, s, r);
      const old = putView(world, e, next, view, s.drawn);
      note(e, s, r, madeStored);
      if (old) {
        untint(old);
        releaseView(world, old);
      }
      return;
    }
    note(e, s, r, dress(e, object, r));
  };

  world.onAdd(Render, (e) => draw(e, world.store(Render)));
  // A view going, however it goes (Render removed, the entity destroyed, a model to none, a pooled reset
  // that does not keep it): its tint's clones freed.
  world.onRemove(View, (_e, object) => {
    if (object) untint(object);
  });
  world.onRemove(Render, (e) => {
    failed.delete(e);
    const object = views.value[e];
    if (object && world.alive(e) && world.store(ViewState).ours[e] === 1) {
      world.remove(e, View);
      world.remove(e, ViewState);
    }
  });
  // An instance made, loaded or reset into its pool: the rows of the views it kept noted again, and each entity
  // of it with a model and no view drawn.
  world.onInstance((root) => {
    if (kept.length > 0) {
      const s = world.store(ViewState);
      for (let i = 0; i < kept.length; i += 7) {
        const e = kept[i]!;
        s.ours[e] = 1;
        s.model[e] = kept[i + 1]!;
        s.material[e] = kept[i + 2]!;
        s.tint[e] = kept[i + 3]!;
        s.castShadow[e] = kept[i + 4]!;
        s.receiveShadow[e] = kept[i + 5]!;
        s.stored[e] = kept[i + 6]!;
      }
      kept.length = 0;
    }
    const inst = world.rawStore(Instance) as { next: ArrayLike<number> };
    const r = world.store(Render);
    for (let e = root as number; e !== 0; e = inst.next[e]!) {
      if (!(world.alive(e as Entity) || world.parked(e as Entity)) || !world.has(e as Entity, Render)) continue;
      draw(e as Entity, r);
    }
  });
  // A model re-exported (`swapView`): the new object dressed as the entity's `Render` says, and this system's own.
  dressViews(world, (e, object) => {
    if (!world.has(e, Render)) return;
    const r = world.store(Render);
    const old = views.value[e];
    note(e, world.store(ViewState), r, dress(e, object, r));
    // The object it replaces is let go by `swapView`: its tint's clones with it.
    if (old && old !== object) untint(old);
  });

  /** The view on `e` is one this made, as it made it. Asked at the reset of every pooled entity with one: allocates nothing. */
  const ours = (e: Entity): boolean => {
    const object = views.value[e];
    if (object === null || object === undefined) return false;
    const shape = shapes.get(object);
    if (shape === undefined) return false;
    cursor = 0;
    return unchanged(object, shape) && cursor === shape.length;
  };
  // One walk a reset: `View`'s bit comes before `ViewState`'s (registered in that order), so the reset asks
  // `View`'s keeper first and `ViewState`'s takes its answer, once; asked alone, it walks.
  let answeredFor = 0;
  let answer = false;
  world.keepParked(View, (e) => {
    answer = ours(e);
    answeredFor = e;
    return answer;
  });
  world.keepParked(ViewState, (e) => {
    const keep = answeredFor === e ? answer : ours(e);
    answeredFor = 0;
    // A kept row goes back to its defaults (`drawn` -99, which `present` wants): what was applied is carried
    // over it, to the `onInstance` hook the same reset runs last. Reused, so a reset allocates nothing once grown.
    if (keep) {
      const s = world.store(ViewState);
      kept.push(e, s.model[e]!, s.material[e]!, s.tint[e]!, s.castShadow[e]!, s.receiveShadow[e]!, s.stored[e]!);
    }
    return keep;
  });

  // The material ids whose object is another now: the members wearing one dressed again, the next frame.
  const stale: number[] = [];
  // The material ids changed in place: the tinted members wearing one take its values into their clones, the next frame.
  const restain: number[] = [];
  const unhear = onMaterials?.((replaced, changed) => {
    for (const key of replaced) {
      const id = internKey('Material', key);
      if (!stale.includes(id)) stale.push(id);
    }
    if (changed === undefined) return;
    for (const key of changed) {
      const id = internKey('Material', key);
      if (!restain.includes(id)) restain.push(id);
    }
  });

  world.system({
    name: 'render',
    phase: 'render',
    read: [Render],
    write: [optional(View), optional(ViewState)],
    update({ members, count, has }, [r], [view, s]) {
      const restale = stale.length > 0;
      const retint = restain.length > 0;
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const object = view.value[e];
        if (object === null || object === undefined) {
          if (r.model[e] !== 0 && !has(e, View)) draw(e, r);
          continue;
        }
        // A view a game or a tool attached: theirs.
        if (s.ours[e] !== 1) continue;
        // A material made anew, come or gone: noted as none applied, so the compare below dresses it again.
        if (restale && r.material[e] !== 0 && stale.includes(r.material[e]!)) s.material[e] = -1;
        // A material changed in place under a tint: noted as another tint, so the compare stains it again.
        if (retint && s.tint[e] !== WHITE && r.material[e] !== 0 && restain.includes(r.material[e]!)) s.tint[e] = STALE_TINT;
        if (s.model[e] === r.model[e] && s.material[e] === r.material[e] && s.tint[e] === r.tint[e] && s.castShadow[e] === r.castShadow[e] && s.receiveShadow[e] === r.receiveShadow[e]) continue;
        update(e, object, r, view, s);
      }
      if (restale) stale.length = 0;
      if (retint) restain.length = 0;
    },
  });

  return () => {
    unhear?.();
    dressViews(world, null);
    // Every tint's clones freed: the views themselves are `installView`'s uninstall's.
    const value = world.store(View).value;
    for (let e = 1; e < world.extent; e++) {
      const object = value[e];
      if (object) untint(object);
    }
  };
}

/** The slots `stain` walks into, every time: copied only when it makes new clones. One page, one frame at a time. */
const scratch = { meshes: [] as Drawn[], slots: [] as number[], bases: [] as THREE.Material[] };

/** A material with a colour to tint: three's `color`, a `Color`. */
interface Coloured {
  color: THREE.Color;
}
const hasColour = (material: THREE.Material): boolean => (material as unknown as { color?: { isColor?: boolean } }).color?.isColor === true;

/** The material in `mesh`'s slot (-1: its one material). */
function wornAt(mesh: Drawn, slot: number): unknown {
  return slot < 0 ? mesh.material : (mesh.material as unknown[] | undefined)?.[slot];
}

/** `material` into `mesh`'s slot (-1: its one material). A list is the instance's own (three's `Mesh.copy` slices it). */
function wear(mesh: Drawn, slot: number, material: THREE.Material): void {
  if (slot < 0) mesh.material = material;
  else (mesh.material as THREE.Material[])[slot] = material;
}

/** A tinted view's meshes back on their bases, the clones kept: before it is dressed again. */
function unstain(t: Tinted): void {
  for (let i = 0; i < t.meshes.length; i++) {
    const clone = t.clones[i];
    if (clone !== null && clone !== undefined && wornAt(t.meshes[i]!, t.slots[i]!) === clone) wear(t.meshes[i]!, t.slots[i]!, t.bases[i]!);
  }
}

/**
 * Every material slot of every mesh under `object`, depth first: what a tint clones. Written into the lists from
 * index `n` on, by index; returns the index after the last written.
 */
function slotsOf(object: THREE.Object3D, meshes: Drawn[], slots: number[], bases: THREE.Material[], n: number): number {
  const drawn = object as unknown as Drawn;
  if (drawn.isMesh === true || drawn.material !== undefined) {
    const material = drawn.material;
    if (Array.isArray(material)) {
      for (let i = 0; i < material.length; i++) {
        meshes[n] = drawn;
        slots[n] = i;
        bases[n] = material[i] as THREE.Material;
        n++;
      }
    } else if (material) {
      meshes[n] = drawn;
      slots[n] = -1;
      bases[n] = material as THREE.Material;
      n++;
    }
  }
  const children = drawn.children;
  const kids = children ? children.length : 0;
  for (let i = 0; i < kids; i++) n = slotsOf(children![i]!, meshes, slots, bases, n);
  return n;
}

/** The slots a tint was cloned for are those found now -- the first `count` of the lists -- wearing the same bases. */
function sameSlots(t: Tinted, meshes: Drawn[], slots: number[], bases: THREE.Material[], count: number): boolean {
  if (t.meshes.length !== count) return false;
  for (let i = 0; i < count; i++) if (t.meshes[i] !== meshes[i] || t.slots[i] !== slots[i] || t.bases[i] !== bases[i]) return false;
  return true;
}

/** A node as dressing and recording read it: a mesh's material and geometry, if it is one. */
interface Drawn {
  isMesh?: boolean;
  material?: unknown;
  geometry?: unknown;
  castShadow: boolean;
  receiveShadow: boolean;
  children?: readonly THREE.Object3D[];
}

/** Every mesh under `object` (itself included): its shadows, and `shared` on it where given. Recursion, no closure. */
function dressMeshes(object: THREE.Object3D, shared: THREE.Material | null, cast: boolean, receive: boolean): void {
  const drawn = object as unknown as Drawn;
  if (drawn.isMesh === true || drawn.material !== undefined) {
    drawn.castShadow = cast;
    drawn.receiveShadow = receive;
    if (shared !== null) drawn.material = shared;
  }
  const children = drawn.children;
  const n = children ? children.length : 0;
  for (let i = 0; i < n; i++) dressMeshes(children![i]!, shared, cast, receive);
}

/**
 * `object`'s shape, depth first: for each node, the node, its material, the
 * materials in it if it is a list (their count, then each), its geometry, and
 * its number of children. Written into `into` by index from `n` on; returns the index after the last written.
 */
function record(object: THREE.Object3D, into: unknown[], n: number): number {
  const drawn = object as unknown as Drawn;
  const material = drawn.material;
  into[n++] = object;
  into[n++] = material;
  if (Array.isArray(material)) {
    into[n++] = material.length;
    for (let i = 0; i < material.length; i++) into[n++] = material[i];
  }
  into[n++] = drawn.geometry;
  const children = drawn.children;
  const kids = children ? children.length : 0;
  into[n++] = kids;
  for (let i = 0; i < kids; i++) n = record(children![i]!, into, n);
  return n;
}

/** Where `unchanged` is in a shape: module level, so the walk allocates nothing. */
let cursor = 0;

/** `object` still has the shape `record` wrote, from `cursor` on. */
function unchanged(object: THREE.Object3D, shape: unknown[]): boolean {
  const drawn = object as unknown as Drawn;
  const material = drawn.material;
  if (shape[cursor++] !== object || shape[cursor++] !== material) return false;
  if (Array.isArray(material)) {
    if (shape[cursor++] !== material.length) return false;
    for (let i = 0; i < material.length; i++) if (shape[cursor++] !== material[i]) return false;
  }
  if (shape[cursor++] !== drawn.geometry) return false;
  const children = drawn.children;
  const n = children ? children.length : 0;
  if (shape[cursor++] !== n) return false;
  for (let i = 0; i < n; i++) if (!unchanged(children![i]!, shape)) return false;
  return true;
}
