/**
 * The global constants a project's `vite.config.ts` (`modeDefines`) writes into
 * every module as literals -- the engine's too. A project's program gets this
 * file through the `/// <reference>` in `index.ts`, `debug/mr-debug.ts` and `project-key.ts`.
 */

/**
 * The debug tools are allowed in this build: the dev server, or
 * `npm run build:debug`. A literal `false` in a release build, so a branch it
 * guards is dropped right where it is written. Never in code a node test runs:
 * there is no Vite there to write it.
 */
declare const DEBUG_BUILD: boolean;

/**
 * The project's id (`projectId` in the pipeline's `config.ts`: a short hash of its real root folder), so
 * what a page keeps in browser storage is the project's even where two share an origin
 * (`project-key.ts`' `projectKey`). `''` in a release build. Never read bare in code a node test runs:
 * `projectId()` asks with `typeof`.
 */
declare const PROJECT_ID: string;

/**
 * Physics is in this project's builds (Docs/physics.md §3): the project's `physics.json` `"enabled"` (true with no
 * file), written by `vibe()`'s `physics` plugin, in the dev server and every build. `boot()` imports Ammo only behind
 * it, so a build with it `false` ships none. Never in code a node test runs: there is no Vite there to write it.
 */
declare const PHYSICS_BUILD: boolean;

/** The project's physics settings, its `physics.json` checked and filled in, served by `vibe()` (the generated `bundle.ts`' import). */
declare module 'virtual:vibe/physics' {
  const settings: import('./physics/settings.ts').PhysicsSettings;
  export default settings;
}
