/**
 * The stopped world, kept: a frame drawn while the game is stopped goes through
 * a target and is copied to the screen, so `show` can copy it again without
 * drawing the world.
 *
 * **Why.** The canvas UI animates over a stopped world -- a pause menu, a
 * results screen -- and the canvas is not preserved between frames: whatever
 * the UI draws each frame has to go over a fresh copy of the world. Drawing the
 * world again for that, sixty times a second, would cost a stopped game what a
 * running one costs. One full-size copy is the price instead.
 *
 * A running game draws straight to the screen and keeps nothing: the target is
 * freed by the first frame drawn without `keep`.
 *
 * **The copy finishes the frame.** three applies tone mapping and the output
 * colour space only when it draws to the screen, never into a target, so the
 * copy does both (`tonemapping_fragment`, `colorspace_fragment`), the way
 * three's own OutputPass does -- a stopped frame looks like a running one
 * whatever the renderer's settings.
 */
import * as THREE from 'three';

export class KeptFrame {
  private target: THREE.WebGLRenderTarget | null = null;
  /** The drawing buffer: the canvas's own size, which the copy fills. */
  private readonly size = new THREE.Vector2();
  private readonly quadScene = new THREE.Scene();
  private readonly quadCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  private readonly copy = new THREE.ShaderMaterial({
    uniforms: { keptColor: { value: null as THREE.Texture | null } },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main() {
        vUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      uniform sampler2D keptColor;
      varying vec2 vUv;
      void main() {
        gl_FragColor = texture2D(keptColor, vUv);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
    depthTest: false,
    depthWrite: false,
  });

  constructor() {
    const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), this.copy);
    quad.frustumCulled = false;
    this.quadScene.add(quad);
  }

  /**
   * The world drawn into the kept target by `paint` -- through one camera or several, each into its
   * viewport rect (`Game`'s cameras): the target is the drawing buffer's size, so a rect lands where
   * it would on the screen -- then copied to the screen.
   */
  draw(renderer: THREE.WebGLRenderer, paint: () => void): void {
    const target = this.targetFor(renderer);
    renderer.setRenderTarget(target);
    paint();
    renderer.setRenderTarget(null);
    this.copyToScreen(renderer, target.texture);
  }

  /**
   * The kept frame on the screen again. False when there is none to show --
   * nothing kept, or the canvas has changed size since -- and the caller has to
   * draw the frame instead.
   */
  show(renderer: THREE.WebGLRenderer): boolean {
    const target = this.target;
    if (!target) return false;
    renderer.getDrawingBufferSize(this.size);
    if (target.width !== this.size.x || target.height !== this.size.y) return false;
    this.copyToScreen(renderer, target.texture);
    return true;
  }

  /** Nothing kept: the game is running again. */
  drop(): void {
    this.target?.dispose();
    this.target = null;
  }

  private copyToScreen(renderer: THREE.WebGLRenderer, texture: THREE.Texture): void {
    this.copy.uniforms.keptColor!.value = texture;
    renderer.render(this.quadScene, this.quadCamera);
  }

  /** The target, made for this drawing buffer if it is not already the size of it. */
  private targetFor(renderer: THREE.WebGLRenderer): THREE.WebGLRenderTarget {
    renderer.getDrawingBufferSize(this.size);
    const kept = this.target;
    if (kept && kept.width === this.size.x && kept.height === this.size.y) return kept;
    kept?.dispose();
    // sRGB storage: eight bits a channel without banding, decoded on sampling.
    // Multisampled, as the canvas is (`antialias: true`).
    this.target = new THREE.WebGLRenderTarget(this.size.x, this.size.y, {
      colorSpace: THREE.SRGBColorSpace,
      samples: 4,
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
    });
    return this.target;
  }
}
