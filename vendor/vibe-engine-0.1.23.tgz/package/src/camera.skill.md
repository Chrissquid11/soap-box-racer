---
skill: engine
title: Cameras
when: Before changing what the game is seen through -- a main camera, a follow or orbit camera, orthographic or isometric, split screen, layers
covers:
  modules: [camera.ts, ecs/render-components.ts]
order: 45
---
# Cameras: the game sees through an entity

A camera is an entity with a **`Camera`** component, placed by its `Transform` like anything else. The game
draws through its **main** camera (`main` on); several cameras draw in `depth` order, each into its own
rectangle of the canvas. The engine's `cameras` system makes and updates the three camera behind each; a game
writes numbers and moves the entity. The code is `node_modules/@vibe/engine/src/camera.ts`.

## `Camera`

| Field | What it is |
|---|---|
| `projection` | 0 perspective, 1 orthographic |
| `fov` | perspective: vertical degrees (50) |
| `size` | orthographic: half the view's height, metres (5) |
| `near`, `far` | the clip planes (0.1, 200) |
| `main` | the camera the game draws through, and picks with |
| `depth` | drawn lowest first (0) |
| `x`, `y`, `w`, `h` | the viewport, fractions of the game's frame from its bottom left (0, 0, 1, 1) -- the frame is the canvas, but in the studio, where it is the room between the cards, or a preview preset's box in it; a Pixel or Stretch preset's resolution is what the fractions multiply then (`game.pixels`) |
| `clear` | 0 none (draws over what is under it), 1 its `clearColor`, 2 the scene's own background (the default) |
| `clearColor` | `0xRRGGBB` |
| `layers` | a mask of the layers 0-31 it sees (every one by default) -- never the camera entity's own layer |

The template's camera is a prefab, `camera/main`, instantiated in `populate` -- and its start scene has an instance
of it too. Never two at once: `populate` makes a fresh world's first entities, and a start scene is loaded in their
place (a load destroys everything first), so the game draws through the start scene's camera when one is set (the
template's `start.scene` is) and through `populate`'s only with none. The prefab:

```json
{
  "is": "vibebase.prefab",
  "version": 1,
  "entities": [
    {
      "id": "camera",
      "name": "main camera",
      "parent": null,
      "components": ["Transform", "Camera"],
      "data": {
        "Transform": { "px": 3.4, "py": 3.2, "pz": 5, "qx": -0.2, "qy": 0.29, "qz": 0.06, "qw": 0.93 },
        "Camera": { "main": true }
      }
    }
  ]
}
```

- **One `main`**: with several, the first by entity is taken, and that is said once. With none at all, the
  engine's fallback camera draws -- the editor's Scene tab says so and offers to add one.
- **Isometric** is an orthographic camera turned 45° about y and 35.264° down: the Camera block's Isometric
  button sets both. **Split screen** is two cameras, `x: 0, w: 0.5` and `x: 0.5, w: 0.5`; a **minimap** a second
  camera with a small rect, a higher `depth`, `clear: 1` and its own `layers`.
- A camera's scale is ignored. Its three camera is the engine's: never made, moved or changed by game code.

## Moving one

A camera moves as anything does: a 60 Hz system writes its `Transform`. The sandbox's orbit:

```ts
import { Transform, type World } from '@vibe/engine';
import { Orbit } from '../components.ts';

const TWO_TURNS = 4 * Math.PI;

export function orbit(world: World): void {
  world.system({
    name: 'orbit',
    rate: 60,
    write: [Orbit, Transform],
    update({ members, count, dt }, _read, [o, at]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const angle = (o.angle[e] + o.speed[e] * dt) % TWO_TURNS;   // kept small: an f32 that only grows loses its fraction
        o.angle[e] = angle;
        at.px[e] = Math.sin(angle) * o.radius[e];
        at.py[e] = o.height[e];
        at.pz[e] = Math.cos(angle) * o.radius[e];
        // Yaw by the angle, then pitch down at the target: q = yaw * pitch.
        const pitch = -Math.atan2(o.height[e] - o.look[e], o.radius[e]) / 2;
        const sy = Math.sin(angle / 2);
        const cy = Math.cos(angle / 2);
        const sx = Math.sin(pitch);
        const cx = Math.cos(pitch);
        at.qx[e] = cy * sx;
        at.qy[e] = sy * cx;
        at.qz[e] = -sy * sx;
        at.qw[e] = cy * cx;
      }
    },
  });
}
```

- **A follow camera** reads its target's `WorldTransform` in `lateUpdate` (this tick's, after the target moved)
  through `optional(WorldTransform)` and a `ref()` field -- the sandbox's `follow` system is the shape -- or is
  simply parented under the target (`cmd.setParent(camera, player)`), its `Transform` then the offset.
- **A shake** is a render system nudging the view after it is placed, or a 60 Hz offset the game adds and takes
  away; never the three camera itself.
- **Never assign or move `Game.camera`**: it is the fallback's, drawn through only while no `Camera` is.

## The pointer and the camera

Page-side code (a render system of the game's own, a tool) asks `game.mainCamera` for the three camera the game
is seen through now -- the main `Camera`'s, else the fallback -- for a raycast from the pointer.
Simulation code reads `ctx.input.pointer` ([the input page](input.md)) and the camera entity's own numbers
(`Camera` and `WorldTransform` through `optional(...)`), so what it decides stays replayable.

## In the studio

The editor's view is its own camera, never the game's: moving around the Scene tab changes nothing in the game.
A playtest draws through the game's main camera. Every camera entity shows its shape (a pyramid to where it looks, a triangle for up), the selected one its
frustum and a preview of what it sees; Create ▸ Camera makes one; the Camera block has Isometric, Align with view and Align view with camera. The
studio's `view_*` tools move the editor's camera, not the game's ([the scene page](../studio/scene.md)).
