/**
 * The physics stage (Docs/physics.md §5): Bullet, through Ammo, as a cache of the ECS (D6). `installPhysics`
 * adds the stage `physics` to a world -- once every tick, after the world's propagation and before every
 * `lateUpdate` (D5) -- and makes the world's `physicsOf` this. Each tick:
 *
 *   reconcile  who has a body: `RigidBody`s (a query, so `Disabled`, a component switched off, a parked pooled
 *              instance and a destroy all take one out the ECS's own way), and every collider's owner -- its own
 *              entity's body, else the nearest ancestor's, else a static body of its own. A body's shape is built
 *              again when what its colliders say, or where they sit on it, changed; a body made again when its
 *              `RigidBody`'s settings did. A parked instance's body is kept out of the world, for its next take.
 *   pull       what someone else wrote since the last push: a dynamic body's `Transform` other than the one
 *              the stage wrote is a teleport (its velocity kept); a kinematic or static one's `WorldTransform` is
 *              where it is driven; a `velocity`, `angularVelocity` or `sleeping` other than the stage's is set;
 *              `Forces` are taken (the impulses cleared).
 *   step       `substeps` steps of 1/(60 × substeps) s: the tick is the step, so pause, F10 and a load hold.
 *   push       each dynamic body's pose into its `Transform` (through its parent's world transform, so a moving
 *              parent does not drag it: D10), its velocities and sleep into `RigidBody`, and the moved worked out
 *              again (`world.settle`) for the render phase and every `lateUpdate`.
 *
 * Scratch Ammo objects and typed arrays are made once and grown at need; a tick of bodies at rest, falling or
 * pushed allocates nothing (`physics.test.ts`' `noAlloc`). Bodies are added in entity order, so the same calls
 * come in the same order every run: the same seed and input give the same simulation (D18).
 *
 * The page's: `Game` installs it with the Ammo `boot()` loaded; a node test with `loadAmmo()` from
 * `@vibe/engine/physics-node`. Returns its uninstall: every Bullet object destroyed, the stage gone, the world's physics
 * the inert handle again.
 */
import type { Entity, EntityRef, StoreOf } from '../ecs/component.ts';
import { Hierarchy, Instance, Transform, WorldTransform } from '../ecs/component.ts';
import { ENTITY_LIMIT, INDEX_BITS, type World } from '../ecs/world.ts';
import type { AmmoApi } from './ammo-types.ts';
import { keyText } from '../ecs/keys.ts';
import { meshOf, Render } from '../ecs/render-components.ts';
import {
  BallJoint, CharacterController, CharacterHit, CharacterLanded, CollisionEnter, CollisionExit, CollisionStay, ConeTwistJoint, ContactEvents, FixedJoint, HingeJoint, JointBroke, JOINTS, SliderJoint,
  TriggerEnter, TriggerExit, TriggerStay,
} from './components.ts';
import { BodyType, BoxCollider, CapsuleCollider, COLLIDERS, ConeCollider, CylinderCollider, Forces, ForceSpace, HeightfieldCollider, HullCollider, MeshCollider, PlaneCollider, RigidBody, ShapeAxis, SphereCollider } from './components.ts';
import { combine, combineIndex, parsePhysicsMaterial, PHYSICS_MATERIAL_DEFAULTS } from './material-file.ts';
import { onPhysicsSettings, physicsSettings, type PhysicsSettings } from './settings.ts';
import { ALL_LAYERS, bindPhysics, newStats, RayHit, type Physics, type PhysicsStats, type Probe, type RayHits } from './service.ts';

/** What `installPhysics` is handed. */
export interface PhysicsOptions {
  /** Ammo, loaded. */
  ammo: AmmoApi;
  /** The settings to use, kept; none: the project's (`physicsSettings()`), followed as they change. */
  settings?: PhysicsSettings;
  /**
   * A model's triangles, or one part's (`#part`), in its own space: what a `HullCollider` and a `MeshCollider` are made
   * of. `Game` reads `Assets.model`; a test hands in arrays. None (or null): those colliders are left out, said once.
   */
  mesh?(model: string, part: string | null): MeshData | null;
  /** A height map's samples, 0 to 1 (`Game`: a texture's red channel): what a `HeightfieldCollider` is made of. */
  heights?(texture: string): HeightData | null;
  /** A physics material file's JSON by its key (`Game`: `data('physicsMaterials', key)`); none: every collider the default. */
  material?(key: string): unknown;
  /**
   * Told of a model re-exported or added (`Game`: the asset store's `onModelReplaced`): its hulls and meshes made again
   * from the new triangles, or made at last where they found none before. Returns the undo.
   */
  onModels?(told: (model: string) => void): () => void;
  /** Told when the physics material files change (`Game`: `onDataFiles`): every body takes its materials again. Returns the undo. */
  onMaterials?(told: () => void): () => void;
}

/** Triangles: `positions` three numbers a vertex, `indices` three a triangle (null: every three vertices one). */
export interface MeshData {
  readonly positions: ArrayLike<number>;
  readonly indices: ArrayLike<number> | null;
}

/** A height map: `width` samples along x by `depth` along z, row by row (z outer), each 0 to 1. */
export interface HeightData {
  readonly width: number;
  readonly depth: number;
  readonly values: ArrayLike<number>;
}

type Ammo = AmmoApi;
type BtBody = InstanceType<Ammo['btRigidBody']>;
type BtShape = InstanceType<Ammo['btCollisionShape']>;
type BtMotion = InstanceType<Ammo['btDefaultMotionState']>;

/** Bullet's activation states and collision flags (btCollisionObject.h). */
const SLEEPING = 2;
const NEVER_SLEEP = 4;
const CF_STATIC = 1;
const CF_KINEMATIC = 2;
const CF_NO_CONTACT = 4;
/** The filter's last bit, no layer's: every body's mask has it and no trigger's, so a query asking as it meets no trigger. */
const QUERY_BIT = 1 << 15;

/** Bullet's default collision margin, capped for a small box (Docs/physics.md §4.2). */
const MARGIN = 0.04;
/** The margin of the shapes whose margin lies outside them (a cone, a hull) or that rock on a big one (a cylinder): 1 cm at most. */
const SMALL_MARGIN = 0.01;

/**
 * A collider's numbers, a row a shape kind of an entity: 0 present; 1-4 the kind's own (a size, a radius and height and
 * axis, a mesh's id and points, a height map's id, size and scale; a plane's normal and offset); 5-7 center; 8-10 turn;
 * 11-17 where its entity sits on its body; 18-20 its entity's world scale; 21 its material's key id; 22 a trigger;
 * 23 its physics layer; 24 the contact events it asks for.
 */
const KIND_STRIDE = 25;
/** Bullet's flag that has the contact-added callback run for a body's contacts: the combine modes (D8). */
const CF_CUSTOM_MATERIAL = 8;
/** Bullet 2.82's btManifoldPoint: the combined friction, rolling friction and restitution, bytes in (pinned by physics.test.ts). */
const COMBINED_FRICTION = 84;
const COMBINED_ROLLING = 88;
const COMBINED_RESTITUTION = 92;
/** btManifoldPoint: its distance (m_distance1), bytes in -- before the combined values. */
const CONTACT_DISTANCE = 80;
/** Contacts within this, metres, are touching: said as a collision (Bullet keeps a point a little apart too). */
const TOUCHING = 0.001;
/** btCollisionObjectWrapper: its collision object's pointer, bytes in (m_parent, m_shape, then it; wasm32). */
const WRAPPED_OBJECT = 8;
/** A child's material row: friction, rolling friction, restitution, and their two combine modes. */
const MAT = 5;
const COL_STRIDE = KIND_STRIDE * COLLIDERS.length;
/** A body's settings as last applied: type, mass, damping ×2, gravity scale, locks ×2, can sleep, ccd, ccd radius. */
const CONFIG = 10;

/** One body: a `RigidBody`'s, or a lone collider's static one. */
class Rec {
  e: number;
  ref: number;
  /** A `RigidBody`'s (false: a collider's with no body above it, static). */
  readonly rigid: boolean;
  /** `BodyType`'s number; a lone collider's is static. */
  type = 0;
  body: BtBody | null = null;
  motion: BtMotion | null = null;
  /** The shape the body has, and every shape made for it (children, then a compound last). */
  shape: BtShape | null = null;
  readonly shapes: BtShape[] = [];
  /** The colliders' rows the shape was built from, and how many numbers of it. */
  desc = new Float32Array(COL_STRIDE);
  descLength = -1;
  /** The smallest extent of its shape, metres: the swept collision's measure. */
  smallest = 0;
  /** A compound (its children's materials by child index), or one shape (the first row). */
  compound = false;
  /** Each child's material (`MAT` numbers a child, in the compound's order), and their key ids. */
  mats = new Float32Array(MAT);
  matKeys: number[] = [];
  /** Its centre of mass, in its entity's space (its body's origin is there), and its inertia: worked out from its colliders. */
  readonly com = new Float64Array(3);
  readonly inertia = new Float64Array(3);
  /** Memory the heap holds for it (a height map's samples), where and how big: given back with its shapes. */
  readonly heap: number[] = [];
  /** Bullet's pointer to its body: what the contact callback looks it up by. */
  pointer = 0;
  /** The shared BVHs its `MeshCollider`s' wrappers hold: let go with its shapes. */
  readonly bvhs: MeshEntry[] = [];
  /** The joints whose constraints hold its body: taken out before its body leaves the world (`detach`). */
  readonly joints: JointRec[] = [];
  inWorld = false;
  /** Out of the world in its pool, kept for the instance's next take. */
  parked = false;
  /** Destroyed (a load, a destroy): made again at the next reconcile even if its ref is the same. */
  stale = false;
  readonly config = new Float32Array(CONFIG);
  /** The colliders it owns this tick, as a chain: the first, by `nextCol`. */
  first = 0;
  last = 0;
  /** A trigger's own collision object (its entity's colliders: D12), following its entity; never a body's part. */
  readonly trigger: boolean;
  /** Its physics layer (its first collider's), and the contact events its colliders ask for (`ContactEvents`' bits). */
  layer = 0;
  events = 0;
  constructor(e: number, ref: number, rigid: boolean, trigger = false) {
    this.e = e;
    this.ref = ref;
    this.rigid = rigid;
    this.trigger = trigger;
  }
}

/** One joint: a joint component of an entity, and its Bullet constraint while both its bodies are in the world. */
class JointRec {
  readonly e: number;
  /** Its component's place in `JOINTS`. */
  readonly kind: number;
  ref: number;
  constraint: InstanceType<AmmoApi['btTypedConstraint']> | null = null;
  pointer = 0;
  /** The bodies it holds, as they were when it was made: another (a body made again) and it is made again. */
  a: Rec | null = null;
  b: Rec | null = null;
  aBody = 0;
  bBody = 0;
  /** Its component's numbers as it was made from them. */
  readonly shadow: Float32Array;
  /** Its btJointFeedback on the wasm heap (0: none -- it cannot break), and its anchor in body A's frame. */
  feedback = 0;
  readonly pivot = new Float64Array(3);
  seen = 0;
  constructor(e: number, kind: number, ref: number, columns: number) {
    this.e = e;
    this.kind = kind;
    this.ref = ref;
    this.shadow = new Float32Array(columns);
  }
}

/** One character (D17): its kinematic capsule in the world, the shape it sweeps, where its feet are, what it stands on. */
class CharRec {
  readonly e: number;
  ref: number;
  body: BtBody | null = null;
  motion: BtMotion | null = null;
  shape: BtShape | null = null;
  pointer = 0;
  /** Its feet, world space, and the capsule's numbers it was made with (radius, height, skin). */
  readonly at = new Float64Array(3);
  readonly made = new Float32Array(3);
  /** What it stands on, if a body (its velocity carries it), and the layer it collides as. */
  ground: Rec | null = null;
  /** The record that stands for it where a body's would (`shared.bodies`: a raycast's hit, a contact). */
  stand: Rec | null = null;
  layer = 0;
  seen = 0;
  /** Said once: it is under a parent (a character is a root entity). */
  parented = false;
  constructor(e: number, ref: number) {
    this.e = e;
    this.ref = ref;
  }
}

/** btBroadphaseProxy (Bullet 2.82, wasm32): its filter group, a short 4 bytes in -- set to none while a character sweeps itself out of the way. */
const PROXY_GROUP = 4;

/**
 * btTypedConstraint (Bullet 2.82, wasm32): its `m_needsFeedback` byte and its `m_jointFeedback` pointer -- a
 * btJointFeedback (the force and torque on body A, then on B, four btVector3s of 16 bytes) the solver writes each
 * substep. This build binds neither, so the stage writes them: a joint that can break reads what it carried.
 */
const CONSTRAINT_NEEDS_FEEDBACK = 21;
const CONSTRAINT_FEEDBACK = 44;
const FEEDBACK_BYTES = 64;

/** Scratch numbers for the pose maths: a quaternion and a vector at a time. */
const q = new Float64Array(4);
const p = new Float64Array(3);
const rel = new Float64Array(10);
const row = new Float32Array(COL_STRIDE);

/** `q` = the rotation of `x`, `y`, `z` degrees, as three's default 'XYZ' Euler. */
function eulerDegrees(x: number, y: number, z: number, out: Float64Array, at: number): void {
  const h = Math.PI / 360;
  const c1 = Math.cos(x * h), c2 = Math.cos(y * h), c3 = Math.cos(z * h);
  const s1 = Math.sin(x * h), s2 = Math.sin(y * h), s3 = Math.sin(z * h);
  out[at] = s1 * c2 * c3 + c1 * s2 * s3;
  out[at + 1] = c1 * s2 * c3 - s1 * c2 * s3;
  out[at + 2] = c1 * c2 * s3 + s1 * s2 * c3;
  out[at + 3] = c1 * c2 * c3 - s1 * s2 * s3;
}

/** `(x, y, z)` turned by the unit quaternion `(qx, qy, qz, qw)`, into `p`. */
function rotate(qx: number, qy: number, qz: number, qw: number, x: number, y: number, z: number): void {
  const tx = 2 * (qy * z - qz * y), ty = 2 * (qz * x - qx * z), tz = 2 * (qx * y - qy * x);
  p[0] = x + qw * tx + (qy * tz - qz * ty);
  p[1] = y + qw * ty + (qz * tx - qx * tz);
  p[2] = z + qw * tz + (qx * ty - qy * tx);
}

/** `a × b`, quaternions as four numbers each, into `q`. */
function mul(ax: number, ay: number, az: number, aw: number, bx: number, by: number, bz: number, bw: number): void {
  q[0] = aw * bx + ax * bw + ay * bz - az * by;
  q[1] = aw * by - ax * bz + ay * bw + az * bx;
  q[2] = aw * bz + ax * by - ay * bx + az * bw;
  q[3] = aw * bw - ax * bx - ay * by - az * bz;
}

/** `old` in a longer array of `rows` rows of `stride`: at module level, so the grow that rarely runs makes no context every tick. */
function u32(rows: number, old: Uint32Array, stride = 1): Uint32Array<ArrayBuffer> {
  const made = new Uint32Array(rows * stride);
  made.set(old);
  return made;
}
function f32(rows: number, old: Float32Array, stride = 1): Float32Array<ArrayBuffer> {
  const made = new Float32Array(rows * stride);
  made.set(old);
  return made;
}
function f64(rows: number, old: Float64Array): Float64Array<ArrayBuffer> {
  const made = new Float64Array(rows);
  made.set(old);
  return made;
}
function u8(rows: number, old: Uint8Array): Uint8Array<ArrayBuffer> {
  const made = new Uint8Array(rows);
  made.set(old);
  return made;
}

/** What every world on one Ammo shares: the contact callback and what it looks bodies up by, and the shapes cooked once. */
interface AmmoShared {
  /** Every body by its Bullet pointer, whichever world it is in: the contact callback's way to its materials. */
  readonly bodies: Map<number, Rec>;
  /** A model's (or part's) BVH, cooked once and wrapped scaled by every `MeshCollider` of it; never destroyed. */
  readonly meshes: Map<string, MeshEntry>;
  /** A model's (or part's) hull, simplified, by its points: each `HullCollider` makes its own shape of them. */
  readonly hulls: Map<string, Float32Array>;
  /** The contact-added callback's pointer (`Ammo.addFunction`): one an Ammo, given to every world on it. */
  readonly callback: number;
  /**
   * Heap blocks given back, by their size in bytes: this Ammo's glue exports `_malloc` and no `_free`, so a height
   * map's samples are a block taken from here (or made) and given back here with its shape -- the heap stops growing.
   */
  readonly blocks: Map<number, number[]>;
}

/** A model's BVH, and how many `MeshCollider`s' scaled wrappers hold it: destroyed once it is replaced and none do. */
interface MeshEntry {
  readonly triangles: InstanceType<Ammo['btTriangleMesh']>;
  readonly shape: InstanceType<Ammo['btBvhTriangleMeshShape']>;
  users: number;
  /** Its model re-exported: out of the cache, destroyed when its last user lets go. */
  retired: boolean;
}

const sharing = new WeakMap<Ammo, AmmoShared>();

/** btCollisionObjectWrapper (Bullet 2.82, wasm32): its parent wrapper's pointer first, its child index 20 bytes in. */
const WRAPPED_PARENT = 0;
const WRAPPED_INDEX = 20;

/**
 * The compound child a contact is with: up `wrap`'s parents to the wrapper just under the body's own (whose parent is
 * none), and that one's index; -1 for a contact with the body's own shape. Pinned by shapes.test.ts (a box and a mesh
 * of one compound, two materials).
 */
function childOf(u32: Uint32Array, wrap: number): number {
  let w = wrap;
  let up = u32[(w + WRAPPED_PARENT) >> 2]!;
  if (up === 0) return -1;
  // At most a few wrappers deep (a compound's child, a triangle of it): more is no chain of Bullet's -- the first row.
  let steps = 0;
  for (let above = u32[(up + WRAPPED_PARENT) >> 2]!; above !== 0; above = u32[(up + WRAPPED_PARENT) >> 2]!) {
    if (++steps > 8) return -1;
    w = up;
    up = above;
  }
  return u32[(w + WRAPPED_INDEX) >> 2]! | 0;
}

/** What the glue has and its types do not say. */
interface AmmoRuntime {
  addFunction(f: (...args: number[]) => number, signature: string): number;
  CONTACT_ADDED_CALLBACK_SIGNATURE: string;
  HEAPU32: Uint32Array;
  HEAPF32: Float32Array;
}

function sharedOf(ammo: Ammo): AmmoShared {
  const known = sharing.get(ammo);
  if (known) return known;
  const glue = ammo as unknown as AmmoRuntime;
  const bodies = new Map<number, Rec>();
  // Each contact point Bullet makes or refreshes, between bodies flagged CF_CUSTOM_MATERIAL: its combined friction,
  // rolling friction and bounce by the two colliders' materials and modes (D8), written into the point itself.
  const callback = glue.addFunction((point: number, wrap0: number, _part0: number, _index0: number, wrap1: number, _part1: number, _index1: number): number => {
    const u32 = glue.HEAPU32;
    const a = bodies.get(u32[(wrap0 + WRAPPED_OBJECT) >> 2]!);
    const b = bodies.get(u32[(wrap1 + WRAPPED_OBJECT) >> 2]!);
    if (a === undefined || b === undefined) return 0;
    // Which child of a compound: the index of the wrapper just under the body's own -- never the point's own index,
    // which a concave child (a mesh, a height field) has made its triangle's.
    const ca = a.compound ? childOf(u32, wrap0) : -1;
    const cb = b.compound ? childOf(u32, wrap1) : -1;
    const ia = ca >= 0 && (ca + 1) * MAT <= a.mats.length ? ca * MAT : 0;
    const ib = cb >= 0 && (cb + 1) * MAT <= b.mats.length ? cb * MAT : 0;
    const am = a.mats, bm = b.mats;
    const f32 = glue.HEAPF32;
    f32[(point + COMBINED_FRICTION) >> 2] = combine(am[ia]!, am[ia + 3]!, bm[ib]!, bm[ib + 3]!);
    f32[(point + COMBINED_ROLLING) >> 2] = combine(am[ia + 1]!, am[ia + 3]!, bm[ib + 1]!, bm[ib + 3]!);
    f32[(point + COMBINED_RESTITUTION) >> 2] = combine(am[ia + 2]!, am[ia + 4]!, bm[ib + 2]!, bm[ib + 4]!);
    return 0;
  }, glue.CONTACT_ADDED_CALLBACK_SIGNATURE);
  const made: AmmoShared = { bodies, meshes: new Map(), hulls: new Map(), callback, blocks: new Map() };
  sharing.set(ammo, made);
  return made;
}

/** Child shapes as `build` gathers them, before the compound is made: reused, grown at need. */
interface Part {
  shape: BtShape;
  /** Where it sits on the body (before the centre of mass is taken off), and its turn. */
  x: number; y: number; z: number;
  /** Where its own mass is centred, on the body: its middle but for a cone (a quarter up from its base) and a hull. */
  mx: number; my: number; mz: number;
  qx: number; qy: number; qz: number; qw: number;
  /** Its volume, cubic metres: its share of the body's mass. */
  volume: number;
  /** Its material's key id (0: the default). */
  material: number;
}
const parts: Part[] = [];

/**
 * A pair's key is its two entity indices, `lo * ENTITY_LIMIT + hi`, exact in a double up to 26 bits an index; the rows'
 * radix sort takes an index in two digits of `DIGIT_BITS`. A wider index than that is said here, at load, not by a
 * wrong sort.
 */
if (INDEX_BITS > 26) throw new Error(`[physics] an entity index of ${INDEX_BITS} bits: the contact report's keys hold 26 -- widen them (bridge.ts)`);
const DIGIT_BITS = Math.ceil(INDEX_BITS / 2);
const DIGITS = 1 << DIGIT_BITS;

/** The engine's physics stage on `world`, over `ammo`. Returns its uninstall. */
export function installPhysics(world: World, options: PhysicsOptions): () => void {
  const bridge = new Bridge(world, options);
  bindPhysics(world, bridge);
  const unstage = world.stage('physics', (tick) => bridge.tick(tick), {
    reads: ['WorldTransform', 'Hierarchy', ...COLLIDERS.map((c) => c.name)],
    writes: ['Transform', 'RigidBody', 'Forces'],
    members: () => bridge.inWorld(),
  });
  return () => {
    unstage();
    bridge.destroy();
    bindPhysics(world, null);
  };
}

class Bridge implements Physics {
  readonly ready = true;
  /** Installed still: the instance hook, which a world keeps, does nothing once this is uninstalled. */
  private live = true;
  private readonly world: World;
  private readonly ammo: Ammo;
  private settings: PhysicsSettings;
  private readonly unfollow: (() => void) | null;
  private readonly undo: (() => void)[] = [];
  private readonly counted: PhysicsStats = newStats();
  private readonly lastMs = new Float64Array(60);
  private msAt = 0;
  /** Ticks left to time: a stats read times the next 60. */
  private timing = 0;

  // Bullet.
  private config!: InstanceType<Ammo['btDefaultCollisionConfiguration']>;
  private dispatcher!: InstanceType<Ammo['btCollisionDispatcher']>;
  private broadphase!: InstanceType<Ammo['btDbvtBroadphase']>;
  private solver!: InstanceType<Ammo['btSequentialImpulseConstraintSolver']>;
  private dynamics!: InstanceType<Ammo['btDiscreteDynamicsWorld']>;
  private readonly v: InstanceType<Ammo['btVector3']>;
  private readonly v2: InstanceType<Ammo['btVector3']>;
  private readonly bq: InstanceType<Ammo['btQuaternion']>;
  private readonly tr: InstanceType<Ammo['btTransform']>;

  private readonly T: StoreOf<typeof Transform>;
  private readonly W: StoreOf<typeof WorldTransform>;
  private readonly RB: StoreOf<typeof RigidBody>;
  private readonly F: StoreOf<typeof Forces>;
  private readonly BOX: StoreOf<typeof BoxCollider>;
  private readonly SPHERE: StoreOf<typeof SphereCollider>;
  private readonly PLANE: StoreOf<typeof PlaneCollider>;
  private readonly CAPSULE: StoreOf<typeof CapsuleCollider>;
  private readonly CYLINDER: StoreOf<typeof CylinderCollider>;
  private readonly CONE: StoreOf<typeof ConeCollider>;
  private readonly HULL: StoreOf<typeof HullCollider>;
  private readonly MESH: StoreOf<typeof MeshCollider>;
  private readonly HEIGHTS: StoreOf<typeof HeightfieldCollider>;
  private readonly RENDER: StoreOf<typeof Render>;
  private readonly H: { parent: ArrayLike<number> };

  // Who has a body.
  private readonly bodies;
  private readonly colliders;
  private stamp = 0;
  /** By entity: a body's record (a parked one's too). */
  private readonly at: (Rec | undefined)[] = [];
  /** Every record, in entity order: the order bodies are added, stepped and written. */
  private readonly recs: Rec[] = [];
  private readonly joins: number[] = [];
  private readonly tjoins: number[] = [];
  // Joints: by kind (`JOINTS`' order) and entity, every one in entity order, their query, and the static body a joint to
  // the world holds to (never in the world: a mass of 0 is Bullet's fixed body).
  private readonly jointAt: (JointRec | undefined)[][] = JOINTS.map(() => []);
  private readonly jointList: JointRec[] = [];
  private readonly jointQuery;
  private readonly jointStores: Record<string, ArrayLike<number> & { [i: number]: number }>[];
  private readonly jointColumns: string[][];
  private worldBody!: BtBody;
  private worldMotion!: BtMotion;
  private jointStamp = 0;
  // Characters: by entity, every one in entity order, their query and store, and a sweep's answer (`castCharacter`).
  private readonly charAt: (CharRec | undefined)[] = [];
  private readonly charList: CharRec[] = [];
  private readonly charQuery;
  private readonly CC: StoreOf<typeof CharacterController>;
  private charStamp = 0;
  /** A character sweep's answer: the share of the way, the normal, the point; and the way it sweeps (`castCharacter`, `travel`). */
  private readonly charHit = new Float64Array(7);
  private readonly way = new Float64Array(3);
  /** The walking character's skin, its slope's cosine and the highest ground it may stand on, for `travel` and `edgeGround`. */
  private readonly charNums = new Float64Array(3);
  private charHitRec: Rec | null = null;
  private charHitEntity = 0;
  private charMoved = new Uint32Array(16);
  /** A joint's frames into its two bodies (`jointLocal`): anchor, axis, the frame's turn. */
  private readonly frameA = new Float64Array(10);
  private readonly frameB = new Float64Array(10);
  /** By collider entity: a trigger's record, apart from `at` (an entity may be a body and a trigger). */
  private readonly trigAt: (Rec | undefined)[] = [];
  /** The colliders' stores in `COLLIDERS`' order: their `trigger` read in `isTrigger`. */
  private readonly colStores: { readonly trigger: ArrayLike<number> }[];

  // By entity, grown with the world.
  private rows = 0;
  private member = new Uint32Array(0);
  private colSeen = new Uint32Array(0);
  private colRef = new Uint32Array(0);
  private colOwner = new Uint32Array(0);
  private colShadow = new Float32Array(0);
  private nextCol = new Uint32Array(0);
  private dirty = new Uint32Array(0);
  private trigDirty = new Uint32Array(0);
  /** By collider entity: its colliders are a trigger (1), as of the last reconcile. */
  private colTrigger = new Uint8Array(0);
  /** By trigger entity: the body it is on or under (0: none), which it is never said to touch. */
  private trigBody = new Uint32Array(0);
  /** A dynamic body's local pose as the stage wrote it; a kinematic or static one's world pose as it was given. */
  private poseShadow = new Float32Array(0);
  private velShadow = new Float32Array(0);
  private sleepShadow = new Uint8Array(0);
  /** The colliders seen last tick, to find those gone. */
  private colList = new Uint32Array(64);
  private colCount = 0;
  private moved = new Uint32Array(64);
  /** Each dynamic body's world pose as Bullet has it after the step (seven a row), and the push it was read in. */
  private bodyPose = new Float64Array(0);
  private dynamic = new Uint32Array(0);
  private pushStamp = 0;
  /** A parent's world pose after the step, worked out by `anchorPose`: position, rotation, scale. */
  private readonly anchor = new Float64Array(10);
  /** The entities from a body's parent up to where its pose is known: grown if a tree is ever deeper. */
  private chain = new Uint32Array(64);
  /** Each parented body's anchor pose (`anchorPose`) as last placed against: unchanged and asleep, nothing to write. */
  private anchorShadow = new Float64Array(0);
  /** Kinematic bodies driven this tick, and the pose each had: what the substeps move it from (`substeps` > 1). */
  private kinematicFrom = new Float32Array(0);
  private driven = new Uint32Array(16);
  private drivenCount = 0;
  /** A load since the last reconcile: Bullet's world made afresh (`world.onLoad`). */
  private loaded = false;

  private readonly options: PhysicsOptions;
  private readonly shared: AmmoShared;
  /** Each physics material's row by key id, as last read: emptied when the files change. */
  private readonly materials = new Map<number, Float32Array>();
  private materialsChanged = false;
  // Contacts, as the last report found them (sorted by pair), and this one's: a pair's key (the two entities), the
  // refs it was reported with, whether it is a trigger's, and the events it asks for; this one's point, normal, push.
  private pairKey = new Float64Array(64);
  private pairA = new Uint32Array(64);
  private pairB = new Uint32Array(64);
  private pairTrigger = new Uint8Array(64);
  private pairEvents = new Uint8Array(64);
  private pairData = new Float32Array(64 * 8);
  private speeds = new Float32Array(64);
  private order = new Uint32Array(64);
  private sorting = new Uint32Array(64);
  private readonly digits = new Uint32Array(DIGITS);
  /** Each row's two entities. */
  private pairLo = new Uint32Array(64);
  private pairHi = new Uint32Array(64);
  /** `rowOf`'s table: a slot's pair key, its row, and the report it was filled in (a power of two, at least twice the rows). */
  private slotKey = new Float64Array(128);
  private slotRow = new Int32Array(128);
  private slotStamp = new Uint32Array(128);
  private reportStamp = 0;
  private lastKey = new Float64Array(64);
  private lastA = new Uint32Array(64);
  private lastB = new Uint32Array(64);
  private lastTrigger = new Uint8Array(64);
  private lastEvents = new Uint8Array(64);
  private lastCount = 0;
  private readonly channels;
  /** The binding's own functions, by pointer (`report`): a manifold's count and points, a point's impulse. */
  private readonly raw: {
    numManifolds(dispatcher: number): number;
    manifold(dispatcher: number, i: number): number;
    numContacts(manifold: number): number;
    body0(manifold: number): number;
    body1(manifold: number): number;
    contact(manifold: number, k: number): number;
    impulse(point: number): number;
  };
  private dispatcherPointer = 0;
  // The queries' scratch: Bullet's callbacks and objects made once, reused every call.
  private readonly rayCallback: InstanceType<Ammo['ClosestRayResultCallback']>;
  private readonly sweepCallback: InstanceType<Ammo['ClosestConvexResultCallback']>;
  private readonly contactCallback: InstanceType<Ammo['ConcreteContactResultCallback']>;
  private readonly probeObject: InstanceType<Ammo['btGhostObject']>;
  private readonly probes = new Map<Probe, InstanceType<Ammo['btConvexShape']>>();
  private readonly from: InstanceType<Ammo['btTransform']>;
  private readonly v3: InstanceType<Ammo['btVector3']>;
  private readonly v4: InstanceType<Ammo['btVector3']>;
  private worldShape!: BtShape;
  private overlapOut: Uint32Array = new Uint32Array(0);
  private overlapCount = 0;
  private overlapMask = 0;
  private overlapTriggers = false;
  private readonly probePointer: number;
  /** By physics layer: the layers it collides with (`matrix`). */
  private readonly collides = new Uint16Array(16);
  /** The matrix before a settings edit: a re-add only where it changed. */
  private readonly lastMatrix = new Uint16Array(16);
  /** Each mesh id a hull or mesh was made of, to its model's key; and each id's version, bumped by a re-export. */
  private readonly idModel = new Map<number, string>();
  private readonly versions = new Map<number, number>();

  constructor(world: World, options: PhysicsOptions) {
    const { ammo, settings } = options;
    this.options = options;
    this.shared = sharedOf(ammo);
    this.world = world;
    this.ammo = ammo;
    this.settings = settings ?? physicsSettings();
    this.makeDynamics();
    this.v = new ammo.btVector3(0, 0, 0);
    this.v2 = new ammo.btVector3(0, 0, 0);
    this.bq = new ammo.btQuaternion(0, 0, 0, 1);
    this.tr = new ammo.btTransform();
    this.from = new ammo.btTransform();
    this.v3 = new ammo.btVector3(0, 0, 0);
    this.v4 = new ammo.btVector3(0, 0, 0);
    {
      // The world, for a joint with no other body: a fixed body (mass 0), never added.
      this.tr.setIdentity();
      this.worldMotion = new ammo.btDefaultMotionState(this.tr);
      this.v.setValue(0, 0, 0);
      const empty = new ammo.btCompoundShape(true);
      const info = new ammo.btRigidBodyConstructionInfo(0, this.worldMotion, empty, this.v);
      this.worldBody = new ammo.btRigidBody(info);
      ammo.destroy(info);
      this.worldShape = empty;
    }
    this.rayCallback = new ammo.ClosestRayResultCallback(this.v, this.v2);
    this.sweepCallback = new ammo.ClosestConvexResultCallback(this.v, this.v2);
    this.probeObject = new ammo.btGhostObject();
    this.contactCallback = new ammo.ConcreteContactResultCallback();
    // Each contact `overlap`'s probe makes: the other object's entity, once, if on the mask (and not a trigger, unless asked).
    (this.contactCallback as unknown as { addSingleResult: (...args: number[]) => number }).addSingleResult = (point: number, wrap0: number, _p0: number, _i0: number, wrap1: number): number => {
      const glue = this.ammo as unknown as AmmoRuntime;
      const u32 = glue.HEAPU32;
      const o0 = u32[(wrap0 + WRAPPED_OBJECT) >> 2]!, o1 = u32[(wrap1 + WRAPPED_OBJECT) >> 2]!;
      const rec = this.shared.bodies.get(o0 === this.probePointer ? o1 : o0);
      // Touching or inside: its distance (the point's, 80 bytes in) not past the surface.
      if (rec === undefined || glue.HEAPF32[(point + CONTACT_DISTANCE) >> 2]! > 0) return 0;
      if ((this.overlapMask & (1 << rec.layer)) === 0 || (rec.trigger && !this.overlapTriggers)) return 0;
      for (let i = 0; i < this.overlapCount; i++) if (this.overlapOut[i] === rec.e) return 0;
      if (this.overlapCount < this.overlapOut.length) this.overlapOut[this.overlapCount++] = rec.e;
      return 0;
    };
    this.probePointer = (ammo as unknown as { getPointer(o: unknown): number }).getPointer(this.probeObject);
    // Read through the module's property each call: the glue binds each lazily, replacing its first stub (which calls
    // `apply`, allocating) with the wasm export itself.
    const glue = ammo as unknown as Record<string, (...args: number[]) => number>;
    for (const name of ['btDispatcher_getNumManifolds_0', 'btDispatcher_getManifoldByIndexInternal_1', 'btPersistentManifold_getNumContacts_0', 'btPersistentManifold_getBody0_0', 'btPersistentManifold_getBody1_0', 'btPersistentManifold_getContactPoint_1', 'btManifoldPoint_getAppliedImpulse_0']) {
      if (typeof glue[`_emscripten_bind_${name}`] !== 'function') throw new Error(`[physics] this Ammo has no ${name}: the physics stage needs ammojs-typed 1.1.0`);
    }
    this.raw = {
      numManifolds: (d) => glue._emscripten_bind_btDispatcher_getNumManifolds_0!(d),
      manifold: (d, i) => glue._emscripten_bind_btDispatcher_getManifoldByIndexInternal_1!(d, i),
      numContacts: (m) => glue._emscripten_bind_btPersistentManifold_getNumContacts_0!(m),
      body0: (m) => glue._emscripten_bind_btPersistentManifold_getBody0_0!(m),
      body1: (m) => glue._emscripten_bind_btPersistentManifold_getBody1_0!(m),
      contact: (m, k) => glue._emscripten_bind_btPersistentManifold_getContactPoint_1!(m, k),
      impulse: (p) => glue._emscripten_bind_btManifoldPoint_getAppliedImpulse_0!(p),
    };
    this.dispatcherPointer = (ammo as unknown as { getPointer(o: unknown): number }).getPointer(this.dispatcher);
    this.channels = {
      enter: world.events(CollisionEnter), stay: world.events(CollisionStay), exit: world.events(CollisionExit),
      tenter: world.events(TriggerEnter), tstay: world.events(TriggerStay), texit: world.events(TriggerExit),
      broke: world.events(JointBroke),
      landed: world.events(CharacterLanded), hit: world.events(CharacterHit),
    };
    // The stores, taken once: a store is the world's for good (its columns are replaced in it as it grows), and
    // `world.store` is refused during a tick, where the stage runs.
    this.T = world.store(Transform);
    this.W = world.store(WorldTransform);
    this.RB = world.store(RigidBody);
    this.F = world.store(Forces);
    this.BOX = world.store(BoxCollider);
    this.SPHERE = world.store(SphereCollider);
    this.PLANE = world.store(PlaneCollider);
    this.CAPSULE = world.store(CapsuleCollider);
    this.CYLINDER = world.store(CylinderCollider);
    this.CONE = world.store(ConeCollider);
    this.HULL = world.store(HullCollider);
    this.MESH = world.store(MeshCollider);
    this.HEIGHTS = world.store(HeightfieldCollider);
    this.RENDER = world.store(Render);
    this.colStores = [this.BOX, this.SPHERE, this.PLANE, this.CAPSULE, this.CYLINDER, this.CONE, this.HULL, this.MESH, this.HEIGHTS];
    this.H = world.rawStore(Hierarchy) as { parent: ArrayLike<number> };
    this.bodies = world.query({ with: [RigidBody] });
    this.jointQuery = world.query({ any: JOINTS });
    this.charQuery = world.query({ with: [CharacterController] });
    this.CC = world.store(CharacterController);
    this.jointStores = JOINTS.map((j) => world.store(j) as unknown as Record<string, ArrayLike<number> & { [i: number]: number }>);
    this.jointColumns = JOINTS.map((j) => j.fields.map((f) => f.name).filter((name) => name !== 'broken'));
    this.colliders = world.query({ any: COLLIDERS });
    this.applyWorldSettings();
    // The project's settings edited (its physics.json): taken live, disturbing nothing that did not change -- a sleeping
    // body stays asleep, a contact stays made. Only a changed matrix puts the bodies back into the world on it.
    this.unfollow = settings ? null : onPhysicsSettings((next) => {
      const before = this.settings;
      this.settings = next;
      // The substeps changed: every joint made again, its motor's impulse a step taken from the step's length.
      if (before.substeps !== next.substeps) for (let i = 0; i < this.jointList.length; i++) this.unjoint(this.jointList[i]!);
      this.lastMatrix.set(this.collides);
      this.applyWorldSettings();
      for (let ri = 0; ri < this.recs.length; ri++) {
        const rec = this.recs[ri]!;
        if (rec.body && !rec.trigger) this.applyBodySettings(rec);
      }
      // Gravity itself changed: every dynamic body woken to fall the new way (any other edit wakes nothing).
      const g0 = before.gravity, g1 = next.gravity;
      if (g0[0] !== g1[0] || g0[1] !== g1[1] || g0[2] !== g1[2]) {
        for (let ri = 0; ri < this.recs.length; ri++) {
          const rec = this.recs[ri]!;
          if (rec.inWorld && rec.type === BodyType.dynamic) rec.body!.activate(true);
        }
      }
      let matrix = false;
      for (let i = 0; i < 16; i++) if (this.collides[i] !== this.lastMatrix[i]) matrix = true;
      if (matrix) {
        for (let ri = 0; ri < this.recs.length; ri++) {
          const rec = this.recs[ri]!;
          if (!rec.inWorld || !rec.body) continue;
          this.remove(rec);
          this.add(rec);
          if (!rec.trigger) rec.body.activate(true);
        }
      }
      // The default material changed: every collider without one of its own takes it.
      const was = before.defaultMaterial, now = next.defaultMaterial;
      if (was.friction !== now.friction || was.restitution !== now.restitution) {
        this.materials.clear();
        for (let ri = 0; ri < this.recs.length; ri++) {
          const rec = this.recs[ri]!;
          if (rec.body) this.remat(rec);
        }
      }
    });
    // A prefab's instance made (not loaded): each body of it starts as its RigidBody says -- `startVelocity`, `startSpin`
    // (degrees a second, the velocity in radians), `startAsleep` -- before its body is made at the next tick.
    world.onInstance((root, _prefab, loaded) => {
      if (loaded || !this.live) return;
      const inst = world.rawStore(Instance) as { next: ArrayLike<number> };
      const rb = this.RB;
      const toRadians = Math.PI / 180;
      for (let e = root as number; e !== 0; e = inst.next[e]!) {
        if (!world.has(e as Entity, RigidBody)) continue;
        rb.velocityX[e] = rb.startVelocityX[e]!;
        rb.velocityY[e] = rb.startVelocityY[e]!;
        rb.velocityZ[e] = rb.startVelocityZ[e]!;
        rb.angularVelocityX[e] = rb.startSpinX[e]! * toRadians;
        rb.angularVelocityY[e] = rb.startSpinY[e]! * toRadians;
        rb.angularVelocityZ[e] = rb.startSpinZ[e]! * toRadians;
        rb.sleeping[e] = rb.startAsleep[e]!;
      }
    });
    // Gone for real -- a destroy, a load (which destroys everything, then makes it again with the same refs): made
    // again at the next reconcile, never taken for the same body.
    const stale = (e: Entity): void => {
      const rec = this.at[e];
      if (rec) rec.stale = true;
      const trigger = this.trigAt[e];
      if (trigger) trigger.stale = true;
    };
    this.undo.push(world.onRemove(RigidBody, stale));
    this.undo.push(world.onLoad(() => {
      this.loaded = true;
    }));
    // A model re-exported (the dev server): its hulls and BVHs out of the cache -- a BVH destroyed once nothing holds it
    // -- and every collider made of it built again at the next reconcile (its row's version differs).
    if (options.onModels) this.undo.push(options.onModels((model) => this.remodel(model)));
    // A physics material file changed: every body takes its materials again at the next reconcile.
    if (options.onMaterials) this.undo.push(options.onMaterials(() => {
      this.materialsChanged = true;
    }));
    for (const c of COLLIDERS) {
      this.undo.push(world.onRemove(c, (e) => {
        if (e < this.rows) this.colRef[e] = 0;
        stale(e);
      }));
    }
  }

  // ── the Physics handle ────────────────────────────────────────────────────

  /** Bodies in the simulation now: the stage's members, for `systemInfo()`. */
  inWorld(): number {
    let n = 0;
    for (let ri = 0; ri < this.recs.length; ri++) if (this.recs[ri]!.inWorld) n++;
    return n;
  }

  sync(): void {
    if (this.world.midTick()) throw new Error('[physics] sync() during a tick: the stage keeps the bodies up to date there');
    this.reconcile();
    this.joints();
    this.pull(false);
  }

  stats(): PhysicsStats {
    this.timing = 60;
    const s = this.counted;
    s.dynamic = s.kinematic = s.static = s.awake = s.shapes = s.triggers = 0;
    for (let ri = 0; ri < this.recs.length; ri++) {
      const rec = this.recs[ri]!;
      if (!rec.inWorld || !rec.body) continue;
      if (rec.trigger) {
        s.triggers++;
        s.shapes += rec.shapes.length;
        continue;
      }
      if (rec.type === BodyType.dynamic) s.dynamic++;
      else if (rec.type === BodyType.kinematic) s.kinematic++;
      else s.static++;
      if (rec.body.isActive() && rec.type !== BodyType.static) s.awake++;
      s.shapes += rec.shapes.length;
    }
    s.contacts = this.contacts();
    let most = 0;
    for (let i = 0; i < 60; i++) if (this.lastMs[i]! > most) most = this.lastMs[i]!;
    s.maxStepMs = most;
    return s;
  }

  // ── the tick ──────────────────────────────────────────────────────────────

  tick(_tick: number): void {
    // Timed only while someone reads the stats (a second after each read): reading the wall clock allocates.
    const timed = this.timing > 0;
    const began = timed ? performance.now() : 0;
    this.reconcile();
    this.joints();
    this.pull(true);
    this.characters();
    const substeps = this.settings.substeps;
    const h = 1 / (60 * substeps);
    for (let k = 0; k < substeps; k++) {
      if (k > 0) this.heldForces();
      if (this.drivenCount > 0) this.drive((k + 1) / substeps);
      this.dynamics.stepSimulation(h, 0);
      // Broken in this substep: out at once, before the next one carries on with it (an impact lasts a substep).
      if (this.breakable > 0) this.breaks();
    }
    this.drivenCount = 0;
    this.push();
    this.report();
    if (!timed) return;
    this.timing--;
    const ms = performance.now() - began;
    this.counted.stepMs = ms;
    this.lastMs[this.msAt] = ms;
    this.msAt = (this.msAt + 1) % 60;
  }

  /** Each kinematic body driven this tick, `share` of the way from where it was to where its world transform is. */
  private drive(share: number): void {
    const from = this.kinematicFrom;
    const to = this.poseShadow;
    const back = 1 - share;
    for (let n = 0; n < this.drivenCount; n++) {
      const e = this.driven[n]!;
      const rec = this.at[e];
      if (!rec || !rec.motion) continue;
      const i = e * 7;
      this.v2.setValue(from[i]! * back + to[i]! * share, from[i + 1]! * back + to[i + 1]! * share, from[i + 2]! * back + to[i + 2]! * share);
      // The rotation the short way round, made unit length again (as the render phase blends a tick).
      const toward = from[i + 3]! * to[i + 3]! + from[i + 4]! * to[i + 4]! + from[i + 5]! * to[i + 5]! + from[i + 6]! * to[i + 6]! < 0 ? -share : share;
      let x = from[i + 3]! * back + to[i + 3]! * toward, y = from[i + 4]! * back + to[i + 4]! * toward;
      let z = from[i + 5]! * back + to[i + 5]! * toward, w = from[i + 6]! * back + to[i + 6]! * toward;
      const length = Math.hypot(x, y, z, w) || 1;
      x /= length; y /= length; z /= length; w /= length;
      this.bq.setValue(x, y, z, w);
      this.tr.setIdentity();
      this.tr.setOrigin(this.v2);
      this.tr.setRotation(this.bq);
      rec.motion.setWorldTransform(this.tr);
    }
  }

  // ── characters (D17) ──────────────────────────────────────────────────────

  /** `c`'s capsule out of the world and destroyed (its record kept: made again at the next tick it is wanted). */
  private uncharacter(c: CharRec): void {
    if (!c.body) return;
    if (this.shared.bodies.get(c.pointer) === c.stand) this.shared.bodies.delete(c.pointer);
    this.dynamics.removeRigidBody(c.body);
    this.ammo.destroy(c.body);
    this.ammo.destroy(c.motion);
    this.ammo.destroy(c.shape);
    c.body = null;
    c.motion = null;
    c.shape = null;
  }

  /** `c`'s capsule made: a kinematic body on its layer, at its feet plus half its height, never asleep. */
  private encharacter(c: CharRec): void {
    const ammo = this.ammo;
    const cc = this.CC;
    const e = c.e;
    const r = cc.radius[e]!, h = Math.max(cc.height[e]!, 2 * r);
    c.made[0] = cc.radius[e]!; c.made[1] = cc.height[e]!; c.made[2] = cc.skin[e]!;
    c.shape = new ammo.btCapsuleShape(r, h - 2 * r);
    this.place3(c);
    c.motion = new ammo.btDefaultMotionState(this.tr);
    this.v.setValue(0, 0, 0);
    const info = new ammo.btRigidBodyConstructionInfo(0, c.motion, c.shape, this.v);
    c.body = new ammo.btRigidBody(info);
    ammo.destroy(info);
    c.body.setCollisionFlags(CF_KINEMATIC);
    c.body.setActivationState(NEVER_SLEEP);
    c.layer = cc.layer[e]! & 15;
    const group = 1 << c.layer, mask = this.collides[c.layer]! | QUERY_BIT;
    this.dynamics.addRigidBody(c.body, (group << 16) >> 16, (mask << 16) >> 16);
    c.pointer = (ammo as unknown as { getPointer(o: unknown): number }).getPointer(c.body);
    // Found by its pointer as a body is -- by a raycast, a contact -- as a kinematic one of its layer, its own entity.
    const stand = new Rec(e, c.ref, false);
    stand.type = BodyType.kinematic;
    stand.body = c.body;
    stand.inWorld = true;
    stand.layer = c.layer;
    stand.events = ContactEvents.enter | ContactEvents.exit;
    stand.pointer = c.pointer;
    c.stand = stand;
    this.shared.bodies.set(c.pointer, stand);
    this.counted.made += 3;
  }

  /** `tr` = `c`'s capsule's pose: its feet plus half its height, upright. */
  private place3(c: CharRec): void {
    const h = Math.max(this.CC.height[c.e]!, 2 * this.CC.radius[c.e]!);
    this.tr.setIdentity();
    this.v2.setValue(c.at[0]!, c.at[1]! + h / 2, c.at[2]!);
    this.tr.setOrigin(this.v2);
  }

  /**
   * `c`'s capsule swept from its feet at `(fx, fy, fz)` along `(dx, dy, dz)`, itself out of the way (its proxy's group
   * none while it does): true if it meets something first, `charHit` the share of the way (0), the normal (1-3), and
   * `charHitRec` / `charHitEntity` what. Allocates nothing.
   */
  private castCharacter(c: CharRec): boolean {
    // From its feet along `way`: numbers in arrays, not arguments (a call with many numbers boxes them).
    const fx = c.at[0]!, fy = c.at[1]!, fz = c.at[2]!;
    const dx = this.way[0]!, dy = this.way[1]!, dz = this.way[2]!;
    const cb = this.sweepCallback;
    const h = Math.max(this.CC.height[c.e]!, 2 * this.CC.radius[c.e]!) / 2;
    this.from.setIdentity();
    this.v.setValue(fx, fy + h, fz);
    this.from.setOrigin(this.v);
    this.tr.setIdentity();
    this.v2.setValue(fx + dx, fy + h + dy, fz + dz);
    this.tr.setOrigin(this.v2);
    cb.set_m_convexFromWorld(this.v);
    cb.set_m_convexToWorld(this.v2);
    cb.set_m_closestHitFraction(1);
    cb.set_m_hitCollisionObject(null as never);
    cb.set_m_collisionFilterGroup((QUERY_BIT << 16) >> 16);
    cb.set_m_collisionFilterMask((this.collides[c.layer]! << 16) >> 16);
    const glue = this.ammo as unknown as { getPointer(o: unknown): number; HEAP16: Int16Array };
    const proxy = glue.getPointer(c.body!.getBroadphaseHandle()) + PROXY_GROUP;
    const group = glue.HEAP16[proxy >> 1]!;
    glue.HEAP16[proxy >> 1] = 0;
    this.dynamics.convexSweepTest(c.shape as never, this.from, this.tr, cb, 0);
    glue.HEAP16[proxy >> 1] = group;
    if (!cb.hasHit()) return false;
    const n = cb.get_m_hitNormalWorld();
    const hp = cb.get_m_hitPointWorld();
    this.charHit[0] = cb.get_m_closestHitFraction();
    this.charHit[1] = n.x(); this.charHit[2] = n.y(); this.charHit[3] = n.z();
    this.charHit[4] = hp.x(); this.charHit[5] = hp.y(); this.charHit[6] = hp.z();
    const rec = this.shared.bodies.get(glue.getPointer(cb.get_m_hitCollisionObject())) ?? null;
    this.charHitRec = rec;
    this.charHitEntity = rec ? rec.e : 0;
    return true;
  }

  /** `c`'s feet moved along `way` until it meets something, `skin` short of it: the share of the way it went (1: all). */
  private travel(c: CharRec): number {
    const skin = this.charNums[0]!;
    const dx = this.way[0]!, dy = this.way[1]!, dz = this.way[2]!;
    const length = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (length < 1e-9) return 1;
    const a = c.at;
    if (!this.castCharacter(c)) {
      a[0] = a[0]! + dx; a[1] = a[1]! + dy; a[2] = a[2]! + dz;
      return 1;
    }
    const share = Math.max(0, this.charHit[0]! - skin / length);
    a[0] = a[0]! + dx * share; a[1] = a[1]! + dy * share; a[2] = a[2]! + dz * share;
    return share;
  }

  /**
   * Every character moved this tick (D17), before the step, against the world as the last step left it: up a step,
   * across -- sliding along what it meets, at most four times, pushing dynamic bodies -- then down to the ground within a
   * step (or falling), standing where the slope is under its limit and sliding where it is not; carried by what it
   * stands on; its capsule then driven there, its `Transform` and state written. Allocates nothing.
   */
  private characters(): void {
    const world = this.world;
    const stamp = ++this.charStamp;
    const cc = this.CC;
    const t = this.T;
    const q = this.charQuery;
    let moved = 0;
    if (this.charMoved.length < q.count) this.charMoved = new Uint32Array(q.count * 2);
    for (let n = 0; n < q.count; n++) {
      const e = q.members[n]! as number;
      const ref = world.ref(e as Entity) as number;
      let c = this.charAt[e];
      if (c && c.ref !== ref) {
        this.uncharacter(c);
        this.charList.splice(this.charList.indexOf(c), 1);
        c = undefined;
      }
      if (!c) {
        c = new CharRec(e, ref);
        this.charAt[e] = c;
        let at = this.charList.length;
        while (at > 0 && this.charList[at - 1]!.e > e) at--;
        this.charList.splice(at, 0, c);
        c.at[0] = NaN;
      }
      c.seen = stamp;
      if (this.H.parent[e] !== 0 && !c.parented) {
        c.parented = true;
        console.warn(`[physics] entity ${e}'s CharacterController is under a parent: a character is a root entity -- its Transform is written as a world pose`);
      }
      // Its feet where its Transform says, when that is not where the stage left it (made, teleported, loaded).
      if (t.px[e] !== Math.fround(c.at[0]!) || t.py[e] !== Math.fround(c.at[1]!) || t.pz[e] !== Math.fround(c.at[2]!)) {
        c.at[0] = t.px[e]!; c.at[1] = t.py[e]!; c.at[2] = t.pz[e]!;
        c.ground = null;
      }
      if (c.body && (c.made[0] !== cc.radius[e] || c.made[1] !== cc.height[e] || c.made[2] !== cc.skin[e] || c.layer !== (cc.layer[e]! & 15))) this.uncharacter(c);
      if (!c.body) this.encharacter(c);
      this.walk(c);
      // Its capsule driven to where it now is; its Transform and its state written.
      this.place3(c);
      c.motion!.setWorldTransform(this.tr);
      t.px[e] = c.at[0]!; t.py[e] = c.at[1]!; t.pz[e] = c.at[2]!;
      this.charMoved[moved++] = e;
    }
    for (let i = this.charList.length - 1; i >= 0; i--) {
      const c = this.charList[i]!;
      if (c.seen === stamp) continue;
      this.uncharacter(c);
      if (this.charAt[c.e] === c) this.charAt[c.e] = undefined;
      this.charList.splice(i, 1);
    }
    if (moved > 0) world.settle(this.charMoved, moved);
  }

  /** One character's tick of movement (`characters`). */
  private walk(c: CharRec): void {
    const cc = this.CC;
    const e = c.e;
    const dt = 1 / 60;
    const skin = cc.skin[e]!;
    const step = cc.stepHeight[e]!;
    const walkable = Math.cos((cc.slopeLimit[e]! * Math.PI) / 180);
    // For `travel` and `edgeGround`, in fields: a number passed to a call that is not inlined is boxed (and so is each
    // of Math.hypot's: lengths here are Math.sqrt).
    this.charNums[0] = skin;
    this.charNums[1] = walkable;
    const wasGrounded = cc.grounded[e] === 1;
    let fall = cc.fall[e]!;
    let jumping = false;
    if (wasGrounded && cc.jump[e]! > 0) {
      fall = cc.jump[e]!;
      jumping = true;
    }
    cc.jump[e] = 0;
    if (!wasGrounded || jumping) fall += this.settings.gravity[1] * cc.gravityScale[e]! * dt;
    else fall = 0;
    // Carried by what it stands on: that body's velocity this step.
    let cx = 0, cy = 0, cz = 0;
    const ground = wasGrounded ? c.ground : null;
    if (ground && ground.body && ground.inWorld && ground.type !== BodyType.static) {
      const v = ground.body.getLinearVelocity();
      cx = v.x() * dt; cy = v.y() * dt; cz = v.z() * dt;
    }
    const dx = cc.moveX[e]! * dt + cx, dz = cc.moveZ[e]! * dt + cz;
    const dy = fall * dt + cc.moveY[e]! * dt + cy;
    const pushing = cc.pushForce[e]!;
    // The highest ground it can come to stand on this tick: a step above where it is, if it walks on the ground.
    this.charNums[2] = c.at[1]! + (wasGrounded && !jumping ? step : 0) + 0.01;
    // 1. Up a step, where it walks on the ground.
    let up = 0;
    const way = this.way;
    if (wasGrounded && !jumping && step > 0 && (dx !== 0 || dz !== 0)) {
      way[0] = 0; way[1] = step; way[2] = 0;
      up = step * this.travel(c);
    }
    // 2. Across: slide along what it meets, at most four times.
    let rx = dx, rz = dz, ry = 0;
    for (let i = 0; i < 4; i++) {
      if (rx * rx + ry * ry + rz * rz < 1e-14) break;
      way[0] = rx; way[1] = ry; way[2] = rz;
      const went = this.travel(c);
      if (went >= 1) break;
      const nx = this.charHit[1]!, ny = this.charHit[2]!, nz = this.charHit[3]!;
      const other = this.charHitRec;
      if (other && other.type === BodyType.dynamic && other.body && pushing > 0) {
        // A dynamic body walked into: pushed along the way it went, `pushForce` newtons for this tick.
        const l = Math.sqrt(rx * rx + rz * rz) || 1;
        this.v.setValue((rx / l) * pushing * dt, 0, (rz / l) * pushing * dt);
        other.body.applyCentralImpulse(this.v);
        other.body.activate(true);
      }
      if (this.charHitEntity !== 0) this.sayHit(c);
      // What is left of the way, along the surface met (a wall: across it; a slope it can stand on: up it).
      const left = 1 - went;
      rx *= left; ry *= left; rz *= left;
      const into = rx * nx + ry * ny + rz * nz;
      rx -= nx * into; ry -= ny * into; rz -= nz * into;
      // A steep face is a wall: never climbed by sliding up it.
      if (ny < walkable && ry > 0) ry = 0;
    }
    // 3. Up when it jumps or is thrown; down to the ground: what it rose for the step, its fall, and a step more to stay
    //    on the ground as it walks down (unless it is in the air).
    if (dy > 0) {
      way[0] = 0; way[1] = dy; way[2] = 0;
      const went = this.travel(c);
      if (went < 1) fall = 0;
    }
    const snap = wasGrounded && !jumping ? step : 0;
    const down = up + (dy < 0 ? -dy : 0) + snap;
    let grounded = false;
    let gx = 0, gy = 1, gz = 0;
    c.ground = null;
    if (down > 0) {
      const a = c.at;
      way[0] = 0; way[1] = -down; way[2] = 0;
      if (this.castCharacter(c)) {
        const share = Math.max(0, this.charHit[0]! - skin / down);
        a[1] = a[1]! - down * share;
        gx = this.charHit[1]!; gy = this.charHit[2]!; gz = this.charHit[3]!;
        // A steep normal at an edge -- a step's corner under the capsule's round bottom -- is ground if what is under
        // the point is: a short ray down there, just past the edge, away from the capsule's axis.
        if (gy < walkable && this.edgeGround(c)) {
          gx = this.ray[3]!; gy = this.ray[4]!; gz = this.ray[5]!;
        }
        if (gy >= walkable) {
          grounded = true;
          fall = 0;
          c.ground = this.charHitRec;
        } else {
          // Too steep: it slides down it, the rest of its fall along the slope.
          const left = down * (1 - share);
          let sx = 0, sy = -left, sz = 0;
          const into = sy * gy;
          sx -= gx * into; sy -= gy * into; sz -= gz * into;
          way[0] = sx; way[1] = sy; way[2] = sz;
          this.travel(c);
        }
      } else a[1] = a[1]! - (down - snap);
    }
    if (grounded && !wasGrounded) {
      const ch = this.channels.landed;
      const x = ch.emit();
      ch.who[x] = this.world.ref(e as Entity);
      ch.ground[x] = this.charHitEntity === 0 ? (0 as EntityRef) : this.world.ref(this.charHitEntity as Entity);
    }
    cc.grounded[e] = grounded ? 1 : 0;
    cc.fall[e] = fall;
    cc.groundNormalX[e] = grounded ? gx : 0; cc.groundNormalY[e] = grounded ? gy : 1; cc.groundNormalZ[e] = grounded ? gz : 0;
  }

  /**
   * Under the point a down sweep met something steep at (`charHit` 4-6): is there ground a character stands on? A ray
   * from 10 cm above it to 10 cm below, a centimetre past it away from the capsule's axis -- true and the normal in `ray`
   * 3-5 (the ray's own scratch) if it meets something walkable no higher than a step up from where it was (`charNums`
   * 2). `charHitRec` and `charHitEntity` are left as they were.
   */
  private edgeGround(c: CharRec): boolean {
    const walkable = this.charNums[1]!;
    const hx = this.charHit[4]!, hy = this.charHit[5]!, hz = this.charHit[6]!;
    let ox = hx - c.at[0]!, oz = hz - c.at[2]!;
    const l = Math.sqrt(ox * ox + oz * oz);
    if (l > 1e-6) {
      ox = (ox / l) * 0.01;
      oz = (oz / l) * 0.01;
    }
    const ray = this.ray;
    // From 10 cm above: a ray starting within a shape's margin (Bullet's 4 cm) of its face passes through it.
    ray[0] = hx + ox; ray[1] = hy + 0.1; ray[2] = hz + oz;
    ray[3] = 0; ray[4] = -1; ray[5] = 0;
    ray[6] = 0;
    ray[7] = 0.2;
    const hit = this.edgeHit;
    if (!this.cast(this.collides[c.layer]!, hit, false, c.e)) return false;
    // Ground higher than a step up from where it was is a ledge it reached with its round bottom, not ground.
    if (hit.normalY < walkable || hit.y > this.charNums[2]!) return false;
    ray[3] = hit.normalX; ray[4] = hit.normalY; ray[5] = hit.normalZ;
    return true;
  }

  /** `CharacterHit`: `c` walked into the body (or static collider) `charHitEntity`, the surface's normal `(nx, ny, nz)`. */
  private sayHit(c: CharRec): void {
    const nx = this.charHit[1]!, ny = this.charHit[2]!, nz = this.charHit[3]!;
    const ch = this.channels.hit;
    const x = ch.emit();
    const a = c.at;
    const r = this.CC.radius[c.e]!;
    ch.who[x] = this.world.ref(c.e as Entity);
    ch.other[x] = this.world.ref(this.charHitEntity as Entity);
    ch.pointX[x] = a[0]! - nx * r; ch.pointY[x] = a[1]! + this.CC.height[c.e]! / 2 - ny * r; ch.pointZ[x] = a[2]! - nz * r;
    ch.normalX[x] = nx; ch.normalY[x] = ny; ch.normalZ[x] = nz;
  }

  // ── joints (D16) ──────────────────────────────────────────────────────────

  /** Every joint's constraint taken out that holds `rec`'s body: before the body leaves the world or is destroyed. */
  private detach(rec: Rec): void {
    for (let i = 0; i < rec.joints.length; i++) this.unjoint(rec.joints[i]!);
    rec.joints.length = 0;
  }

  /** `joint`'s constraint out of the world and destroyed (its record kept: it is made again when it can be). */
  private unjoint(joint: JointRec): void {
    if (!joint.constraint) return;
    this.dynamics.removeConstraint(joint.constraint);
    this.ammo.destroy(joint.constraint);
    joint.constraint = null;
    if (joint.feedback !== 0) {
      // Its feedback block given back to this Ammo's for the next breakable joint, of any world on it (a live swap's
      // too): this build exports `_malloc` but no `_free`.
      let spare = this.shared.blocks.get(FEEDBACK_BYTES);
      if (!spare) this.shared.blocks.set(FEEDBACK_BYTES, (spare = []));
      spare.push(joint.feedback);
      joint.feedback = 0;
      this.breakable--;
    }
    const a = joint.a, b = joint.b;
    if (a) {
      const at = a.joints.indexOf(joint);
      if (at >= 0) a.joints.splice(at, 1);
    }
    if (b) {
      const at = b.joints.indexOf(joint);
      if (at >= 0) b.joints.splice(at, 1);
    }
    joint.a = joint.b = null;
  }

  /** The rigid body in the world that the entity `e` is, or is under (its nearest ancestor's), or null. */
  private bodyAt(e: number): Rec | null {
    const parent = this.H.parent;
    for (let x = e; x !== 0; x = parent[x]!) {
      const rec = this.at[x];
      if (rec && rec.rigid && rec.inWorld && !rec.parked) return rec;
    }
    return null;
  }

  /**
   * Every joint against the components: made where both its bodies are in the world (a joint to none, to the world),
   * made again where a body was made again or its numbers changed, taken out where it went, broke, was switched off or
   * a body left. In entity order, the order constraints are added in (D18). Allocates only when a joint is made.
   */
  private joints(): void {
    const world = this.world;
    const stamp = ++this.jointStamp;
    const q = this.jointQuery;
    for (let n = 0; n < q.count; n++) {
      const e = q.members[n]! as number;
      for (let k = 0; k < JOINTS.length; k++) {
        const C = JOINTS[k]!;
        const store = this.jointStores[k]!;
        if (!world.enabled(e as Entity, C) || store.broken![e] === 1) continue;
        const ref = world.ref(e as Entity) as number;
        let joint = this.jointAt[k]![e];
        if (joint && joint.ref !== ref) {
          this.unjoint(joint);
          this.jointList.splice(this.jointList.indexOf(joint), 1);
          joint = undefined;
        }
        if (!joint) {
          joint = new JointRec(e, k, ref, this.jointColumns[k]!.length);
          joint.shadow.fill(NaN);
          this.jointAt[k]![e] = joint;
          let at = this.jointList.length;
          while (at > 0 && (this.jointList[at - 1]!.e > e || (this.jointList[at - 1]!.e === e && this.jointList[at - 1]!.kind > k))) at--;
          this.jointList.splice(at, 0, joint);
        }
        joint.seen = stamp;
        // Its bodies now: its own (or above it), and the other's (none: the world; one gone: nothing to hold to).
        const a = this.bodyAt(e);
        const otherRef = store.other![e]!;
        const otherEntity = otherRef === 0 ? 0 : (world.deref(otherRef as EntityRef) as number);
        // The other's body out of the world (Disabled, parked, its RigidBody switched off): waiting for it, never the world.
        const b = otherRef === 0 ? null : otherEntity === 0 ? undefined : (this.bodyAt(otherEntity) ?? undefined);
        // Its numbers, against what it was made from.
        const columns = this.jointColumns[k]!;
        let changed = false;
        for (let c = 0; c < columns.length; c++) {
          const v = store[columns[c]!]![e]!;
          if (joint.shadow[c] !== v) {
            changed = true;
            joint.shadow[c] = v;
          }
        }
        const ready = a !== null && b !== undefined && a !== b;
        if (joint.constraint && (!ready || changed || joint.a !== a || joint.b !== b || joint.aBody !== a!.pointer || (b !== null && joint.bBody !== b!.pointer))) this.unjoint(joint);
        if (!joint.constraint && ready) this.join2(joint, a!, b!);
        // A motor turning keeps its bodies awake: Bullet sleeps a body slower than its threshold, motor or none.
        const motor = store.motor;
        if (joint.constraint && motor !== undefined && motor[e] === 1) {
          a!.body!.activate();
          if (b) b.body?.activate();
        }
      }
    }
    // Gone: its entity, its component switched off or broken.
    for (let i = this.jointList.length - 1; i >= 0; i--) {
      const joint = this.jointList[i]!;
      if (joint.seen === stamp) continue;
      this.unjoint(joint);
      if (this.jointAt[joint.kind]![joint.e] === joint) this.jointAt[joint.kind]![joint.e] = undefined;
      this.jointList.splice(i, 1);
    }
  }

  /**
   * `joint`'s constraint made between `a`'s body and `b`'s (null: the world): its anchor and axis from its entity's
   * world pose into each body's frame -- the other's worked out from where the two are now (`autoAnchor`) or given.
   */
  private join2(joint: JointRec, a: Rec, b: Rec | null): void {
    const ammo = this.ammo;
    const e = joint.e;
    const store = this.jointStores[joint.kind]!;
    const w = this.W;
    const C = JOINTS[joint.kind]!;
    // The anchor and the axis in the world, from the joint's entity.
    const sx = w.sx[e]!, sy = w.sy[e]!, sz = w.sz[e]!;
    const ex = w.qx[e]!, ey = w.qy[e]!, ez = w.qz[e]!, ew = w.qw[e]!;
    rotate(ex, ey, ez, ew, store.anchorX![e]! * sx, store.anchorY![e]! * sy, store.anchorZ![e]! * sz);
    const px = w.px[e]! + p[0]!, py = w.py[e]! + p[1]!, pz = w.pz[e]! + p[2]!;
    let ax = store.axisX![e]!, ay = store.axisY![e]!, az = store.axisZ![e]!;
    const al = Math.hypot(ax, ay, az) || 1;
    rotate(ex, ey, ez, ew, ax / al, ay / al, az / al);
    ax = p[0]!; ay = p[1]!; az = p[2]!;
    const bodyA = a.body!;
    const bodyB = b ? b.body! : this.worldBody;
    // Into a body's frame (Bullet's: its centre of mass): `jointLocal` writes the anchor into `local` (0-2), the axis (3-5), the frame's turn (6-9).
    const auto = store.autoAnchor![e] === 1;
    this.jointLocal(bodyA, px, py, pz, ax, ay, az, this.frameA);
    if (b === null || auto) this.jointLocal(bodyB, px, py, pz, ax, ay, az, this.frameB);
    else {
      // Given in the other's entity's space: into the world through its entity, then into its body's frame.
      const o = b.e;
      rotate(w.qx[o]!, w.qy[o]!, w.qz[o]!, w.qw[o]!, store.otherAnchorX![e]! * w.sx[o]!, store.otherAnchorY![e]! * w.sy[o]!, store.otherAnchorZ![e]! * w.sz[o]!);
      const bx = w.px[o]! + p[0]!, by = w.py[o]! + p[1]!, bz = w.pz[o]! + p[2]!;
      let cx = store.otherAxisX![e]!, cy = store.otherAxisY![e]!, cz = store.otherAxisZ![e]!;
      const cl = Math.hypot(cx, cy, cz) || 1;
      rotate(w.qx[o]!, w.qy[o]!, w.qz[o]!, w.qw[o]!, cx / cl, cy / cl, cz / cl);
      cx = p[0]!; cy = p[1]!; cz = p[2]!;
      this.jointLocal(bodyB, bx, by, bz, cx, cy, cz, this.frameB);
    }
    const fa = this.frameA, fb = this.frameB;
    const frame = (t: InstanceType<Ammo['btTransform']>, f: Float64Array): void => {
      t.setIdentity();
      this.v.setValue(f[0]!, f[1]!, f[2]!);
      t.setOrigin(this.v);
      this.bq.setValue(f[6]!, f[7]!, f[8]!, f[9]!);
      t.setRotation(this.bq);
    };
    let made: InstanceType<Ammo['btTypedConstraint']>;
    const deg = Math.PI / 180;
    const h = 1 / (60 * this.settings.substeps);
    if (C === BallJoint) {
      this.v.setValue(fa[0]!, fa[1]!, fa[2]!);
      this.v2.setValue(fb[0]!, fb[1]!, fb[2]!);
      made = new ammo.btPoint2PointConstraint(bodyA, bodyB, this.v, this.v2);
    } else if (C === HingeJoint) {
      this.v.setValue(fa[0]!, fa[1]!, fa[2]!);
      this.v2.setValue(fb[0]!, fb[1]!, fb[2]!);
      this.v3.setValue(fa[3]!, fa[4]!, fa[5]!);
      this.v4.setValue(fb[3]!, fb[4]!, fb[5]!);
      const hinge = new ammo.btHingeConstraint(bodyA, bodyB, this.v, this.v2, this.v3, this.v4, false);
      if (store.limit![e] === 1) hinge.setLimit(store.lower![e]! * deg, store.upper![e]! * deg, 0.9, 0.3, 1);
      if (store.motor![e] === 1) hinge.enableAngularMotor(true, store.motorSpeed![e]! * deg, store.motorForce![e]! * h);
      made = hinge;
    } else {
      frame(this.from, fa);
      frame(this.tr, fb);
      if (C === FixedJoint) made = new ammo.btFixedConstraint(bodyA, bodyB, this.from, this.tr);
      else if (C === SliderJoint) {
        const slider = new ammo.btSliderConstraint(bodyA, bodyB, this.from, this.tr, true);
        slider.setLowerLinLimit(store.lower![e]!);
        slider.setUpperLinLimit(store.upper![e]!);
        slider.setLowerAngLimit(0);
        slider.setUpperAngLimit(0);
        if (store.motor![e] === 1) {
          slider.setPoweredLinMotor(true);
          slider.setTargetLinMotorVelocity(store.motorSpeed![e]!);
          slider.setMaxLinMotorForce(store.motorForce![e]!);
        }
        made = slider;
      } else if (C === ConeTwistJoint) {
        const cone = new ammo.btConeTwistConstraint(bodyA, bodyB, this.from, this.tr);
        cone.setLimit(3, store.twist![e]! * deg);
        cone.setLimit(4, store.swing2![e]! * deg);
        cone.setLimit(5, store.swing1![e]! * deg);
        made = cone;
      } else {
        const six = new ammo.btGeneric6DofSpringConstraint(bodyA, bodyB, this.from, this.tr, true);
        this.v.setValue(store.linearLowerX![e]!, store.linearLowerY![e]!, store.linearLowerZ![e]!);
        six.setLinearLowerLimit(this.v);
        this.v.setValue(store.linearUpperX![e]!, store.linearUpperY![e]!, store.linearUpperZ![e]!);
        six.setLinearUpperLimit(this.v);
        this.v.setValue(store.angularLowerX![e]! * deg, store.angularLowerY![e]! * deg, store.angularLowerZ![e]! * deg);
        six.setAngularLowerLimit(this.v);
        this.v.setValue(store.angularUpperX![e]! * deg, store.angularUpperY![e]! * deg, store.angularUpperZ![e]! * deg);
        six.setAngularUpperLimit(this.v);
        const springs = store.spring![e]!;
        const axes = ['X', 'Y', 'Z'];
        for (let i = 0; i < 6; i++) {
          if ((springs & (1 << i)) === 0) continue;
          const name = axes[i % 3]!;
          six.enableSpring(i, true);
          six.setStiffness(i, (i < 3 ? store[`stiffness${name}`] : store[`angularStiffness${name}`])![e]!);
          six.setDamping(i, (i < 3 ? store[`damping${name}`] : store[`angularDamping${name}`])![e]!);
        }
        six.setEquilibriumPoint();
        made = six;
      }
    }
    this.dynamics.addConstraint(made, store.collide![e] !== 1);
    this.counted.made++;
    joint.constraint = made;
    const glue = ammo as unknown as { getPointer(o: unknown): number; _malloc(bytes: number): number; HEAPU8: Uint8Array; HEAP32: Int32Array };
    joint.pointer = glue.getPointer(made);
    // One that can break carries a feedback block, its force and torque read after each step (`breaks`) -- not Bullet's
    // own threshold, which is one number for every row, so a torque limit would break under force alone and the reverse.
    joint.pivot[0] = fa[0]!; joint.pivot[1] = fa[1]!; joint.pivot[2] = fa[2]!;
    if (store.breakForce![e]! > 0 || store.breakTorque![e]! > 0) {
      joint.feedback = this.shared.blocks.get(FEEDBACK_BYTES)?.pop() ?? glue._malloc(FEEDBACK_BYTES);
      this.breakable++;
      (glue as unknown as { HEAPF32: Float32Array }).HEAPF32.fill(0, joint.feedback >> 2, (joint.feedback >> 2) + FEEDBACK_BYTES / 4);
      glue.HEAP32[(joint.pointer + CONSTRAINT_FEEDBACK) >> 2] = joint.feedback;
      glue.HEAPU8[joint.pointer + CONSTRAINT_NEEDS_FEEDBACK] = 1;
    }
    joint.a = a;
    joint.b = b;
    joint.aBody = a.pointer;
    joint.bBody = b ? b.pointer : 0;
    a.joints.push(joint);
    if (b) b.joints.push(joint);
    // A body held by a joint is woken: it may be pulled now.
    bodyA.activate(true);
    if (b) bodyB.activate(true);
  }

  /** A world anchor (`px…`) and axis (`ax…`) into `body`'s frame: `out` the anchor (0-2), the axis (3-5), the frame's turn with its x along the axis (6-9). */
  private jointLocal(body: BtBody, px: number, py: number, pz: number, ax: number, ay: number, az: number, out: Float64Array): void {
    const t = body.getWorldTransform();
    const o = t.getOrigin();
    const r = t.getRotation();
    const qx = r.x(), qy = r.y(), qz = r.z(), qw = r.w();
    rotate(-qx, -qy, -qz, qw, px - o.x(), py - o.y(), pz - o.z());
    out[0] = p[0]!; out[1] = p[1]!; out[2] = p[2]!;
    rotate(-qx, -qy, -qz, qw, ax, ay, az);
    const lx = p[0]!, ly = p[1]!, lz = p[2]!;
    out[3] = lx; out[4] = ly; out[5] = lz;
    // The shortest turn from x to the axis: the frame a slider, a cone twist and a six-way joint take their x from.
    const dot = lx;
    if (dot < -0.999999) {
      out[6] = 0; out[7] = 0; out[8] = 1; out[9] = 0;
    } else {
      let x = 0, y = -lz, z = ly, w2 = 1 + dot;
      const l = Math.hypot(x, y, z, w2) || 1;
      x /= l; y /= l; z /= l; w2 /= l;
      out[6] = x; out[7] = y; out[8] = z; out[9] = w2;
    }
  }

  /** Joints with a feedback block now: `breaks` runs after each substep only while there are any. */
  private breakable = 0;

  /**
   * Joints that broke this substep: the force it carried (on its body, in this substep) past `breakForce`, or
   * the torque about its anchor -- the torque on the body less the force's moment about its centre of mass -- past
   * `breakTorque`. Taken out, marked `broken` and said.
   */
  private breaks(): void {
    const heap = (this.ammo as unknown as { HEAPF32: Float32Array }).HEAPF32;
    for (let i = 0; i < this.jointList.length; i++) {
      const joint = this.jointList[i]!;
      if (!joint.constraint || joint.feedback === 0) continue;
      const store = this.jointStores[joint.kind]!;
      const e = joint.e;
      const maxForce = store.breakForce![e]!, maxTorque = store.breakTorque![e]!;
      const at = joint.feedback >> 2;
      const fx = heap[at]!, fy = heap[at + 1]!, fz = heap[at + 2]!;
      const tx0 = heap[at + 4]!, ty0 = heap[at + 5]!, tz0 = heap[at + 6]!;
      let broke = maxForce > 0 && fx * fx + fy * fy + fz * fz > maxForce * maxForce;
      if (!broke && maxTorque > 0) {
        const r = joint.a!.body!.getWorldTransform().getRotation();
        const pv = joint.pivot;
        rotate(r.x(), r.y(), r.z(), r.w(), pv[0]!, pv[1]!, pv[2]!);
        const rx = p[0]!, ry = p[1]!, rz = p[2]!;
        const tx = tx0 - (ry * fz - rz * fy);
        const ty = ty0 - (rz * fx - rx * fz);
        const tz = tz0 - (rx * fy - ry * fx);
        broke = tx * tx + ty * ty + tz * tz > maxTorque * maxTorque;
      }
      if (!broke) continue;
      const a = joint.a, b = joint.b;
      this.unjoint(joint);
      store.broken![e] = 1;
      const ch = this.channels.broke;
      const x = ch.emit();
      ch.joint[x] = this.world.ref(e as Entity);
      ch.body[x] = a ? this.world.ref(a.e as Entity) : (0 as EntityRef);
      ch.other[x] = b ? this.world.ref(b.e as Entity) : (0 as EntityRef);
    }
  }

  // ── report: contacts and triggers as events (D12) ───────────────────────────

  /** Room for `n` pairs in this report's rows (grown, never shrunk: a report allocates only when the world grows). */
  private room(n: number): void {
    if (n <= this.pairKey.length) return;
    let size = this.pairKey.length;
    while (size < n) size *= 2;
    this.pairKey = f64(size, this.pairKey); this.pairA = u32(size, this.pairA); this.pairB = u32(size, this.pairB);
    this.pairLo = u32(size, this.pairLo); this.pairHi = u32(size, this.pairHi);
    // The pairs' table at least twice their number, a power of two: a fresh one (its stamps 0 are no report's).
    let slots = this.slotRow.length;
    while (slots < size * 2) slots *= 2;
    if (slots !== this.slotRow.length) {
      this.slotKey = new Float64Array(slots);
      this.slotRow = new Int32Array(slots);
      this.slotStamp = new Uint32Array(slots);
    }
    this.pairTrigger = u8(size, this.pairTrigger); this.pairEvents = u8(size, this.pairEvents);
    this.order = u32(size, this.order); this.sorting = u32(size, this.sorting);
    this.pairData = f32(size, this.pairData, 8);
    this.lastKey = f64(size, this.lastKey); this.lastA = u32(size, this.lastA); this.lastB = u32(size, this.lastB);
    this.lastTrigger = u8(size, this.lastTrigger); this.lastEvents = u8(size, this.lastEvents);
    this.speeds = f32(size, this.speeds);
  }

  /**
   * This report's row of the pair (`lo`, `hi`), or where to put one: an open-addressed table of the pairs' keys, stamped
   * a report (nothing cleared), probed from their hash -- O(1) a pair, a ground's thousand pairs included. Returns the
   * row (`>= 0`), or `-1 - slot` for a free slot.
   */
  private rowOf(lo: number, hi: number): number {
    const mask = this.slotRow.length - 1;
    const key = lo * ENTITY_LIMIT + hi;
    let slot = (Math.imul(lo, 73856093) ^ Math.imul(hi, 19349663)) & mask;
    for (;;) {
      if (this.slotStamp[slot] !== this.reportStamp) return -1 - slot;
      if (this.slotKey[slot] === key) return this.slotRow[slot]!;
      slot = (slot + 1) & mask;
    }
  }

  /**
   * `order` the rows `0 … count` sorted by their pair (`lo`, then `hi`): a radix sort, four passes of half an index's bits
   * over the two entity indices (`INDEX_BITS` each), through `sorting` -- O(n), and nothing allocated.
   */
  private sortRows(count: number): void {
    let from = this.order, to = this.sorting;
    for (let i = 0; i < count; i++) from[i] = i;
    const counts = this.digits;
    for (let pass = 0; pass < 4; pass++) {
      const of = pass < 2 ? this.pairHi : this.pairLo;
      const shift = (pass & 1) * DIGIT_BITS;
      counts.fill(0);
      for (let i = 0; i < count; i++) counts[(of[from[i]!]! >>> shift) & (DIGITS - 1)]!++;
      let sum = 0;
      for (let d = 0; d < DIGITS; d++) {
        const c = counts[d]!;
        counts[d] = sum;
        sum += c;
      }
      for (let i = 0; i < count; i++) {
        const j = from[i]!;
        to[counts[(of[j]! >>> shift) & (DIGITS - 1)]!++] = j;
      }
      const swap = from;
      from = to;
      to = swap;
    }
    // Four passes: the sorted index is back in `order`.
  }

  /**
   * The pairs touching after the step -- one a pair of entities (the deepest point of their manifolds), the lower entity
   * first -- sorted, and diffed with the last report's: what began said `Enter`, what goes on `Stay` (asked for), what
   * ended `Exit` (with the refs it was said with, so a destroyed one is still named); a pair whose entity is another now
   * (an index reused) ended and began. Allocates nothing; O(n) in the pairs (a hash table finds a pair's row, a radix
   * sort orders them).
   */
  private report(): void {
    const world = this.world;
    // Bullet read by its pointers through the binding's own functions and the heap: no wrapper object a manifold or a
    // point (the binding keeps one for every pointer it ever saw, in a table that grows with the contacts).
    const raw = this.raw;
    const f32 = (this.ammo as unknown as AmmoRuntime).HEAPF32;
    const dispatcher = this.dispatcherPointer;
    const manifolds = raw.numManifolds(dispatcher);
    this.room(manifolds + 1);
    const stamp = ++this.reportStamp;
    let count = 0;
    for (let i = 0; i < manifolds; i++) {
      const m = raw.manifold(dispatcher, i);
      const points = raw.numContacts(m);
      if (points === 0) continue;
      const r0 = this.shared.bodies.get(raw.body0(m));
      const r1 = this.shared.bodies.get(raw.body1(m));
      if (r0 === undefined || r1 === undefined || (r0.trigger && r1.trigger) || r0.e === r1.e) continue;
      if ((r0.trigger && this.trigBody[r0.e] === r1.e) || (r1.trigger && this.trigBody[r1.e] === r0.e)) continue;
      let best = 0, deepest = Infinity, impulse = 0;
      for (let k = 0; k < points; k++) {
        const cp = raw.contact(m, k);
        const distance = f32[(cp + CONTACT_DISTANCE) >> 2]!;
        impulse += raw.impulse(cp);
        if (distance < deepest) {
          deepest = distance;
          best = raw.contact(m, k);
        }
      }
      if (deepest > TOUCHING) continue;
      // The lower entity first: its normal Bullet's (from body 1 to body 0) when it is body 0, else turned round.
      const flip = r0.e > r1.e;
      const a = flip ? r1 : r0, b = flip ? r0 : r1;
      // The point's position on b and its normal: 32 and 64 bytes in (Bullet 2.82's btManifoldPoint, after the two
      // local points), pinned by events.test.ts' normals and points.
      const sign = flip ? -1 : 1;
      const q = best >> 2;
      const px = f32[q + 8]!, py = f32[q + 9]!, pz = f32[q + 10]!;
      const nx = f32[q + 16]! * sign, ny = f32[q + 17]! * sign, nz = f32[q + 18]! * sign;
      // How fast they closed along it: a's velocity less b's, against the normal (from b to a).
      let speed = 0;
      if (a.body && b.body && !a.trigger && !b.trigger) {
        const va = a.body.getLinearVelocity();
        const ax = va.x(), ay = va.y(), az = va.z();
        const vb = b.body.getLinearVelocity();
        speed = -((ax - vb.x()) * nx + (ay - vb.y()) * ny + (az - vb.z()) * nz);
      }
      // Two manifolds of one pair (a compound's children): one row, the deeper's.
      let j = this.rowOf(a.e, b.e);
      if (j < 0) {
        const slot = -1 - j;
        j = -1;
        this.slotStamp[slot] = stamp;
        this.slotKey[slot] = a.e * ENTITY_LIMIT + b.e;
        this.slotRow[slot] = count;
      }
      if (j >= 0) {
        const o = j * 8;
        this.pairData[o + 6] = this.pairData[o + 6]! + impulse;
        if (deepest >= this.pairData[o + 7]!) continue;
      } else {
        j = count++;
        this.pairLo[j] = a.e;
        this.pairHi[j] = b.e;
        this.pairKey[j] = a.e * ENTITY_LIMIT + b.e;
        // A trigger is named first in its events: `trigger`, `other`.
        const first = b.trigger ? b.e : a.e, second = b.trigger ? a.e : b.e;
        this.pairA[j] = world.ref(first as Entity) as number;
        this.pairB[j] = world.ref(second as Entity) as number;
        this.pairTrigger[j] = a.trigger || b.trigger ? 1 : 0;
        this.pairEvents[j] = a.events | b.events;
        this.pairData[j * 8 + 6] = impulse;
      }
      const o = j * 8;
      this.pairData[o] = px; this.pairData[o + 1] = py; this.pairData[o + 2] = pz;
      this.pairData[o + 3] = nx; this.pairData[o + 4] = ny; this.pairData[o + 5] = nz;
      this.pairData[o + 7] = deepest;
      this.speeds[j] = speed;
    }
    this.sortRows(count);
    const order = this.order;
    const keys = this.pairKey;
    // The diff: a merge of this report's sorted keys with the last's.
    let i = 0, l = 0;
    while (i < count || l < this.lastCount) {
      const j = i < count ? order[i]! : 0;
      const now = i < count ? keys[j]! : Infinity;
      const was = l < this.lastCount ? this.lastKey[l]! : Infinity;
      if (now < was) {
        if ((this.pairEvents[j]! & ContactEvents.enter) !== 0) this.say(true, j);
        i++;
      } else if (now > was) {
        this.ended(l);
        l++;
      } else if (this.pairA[j] !== this.lastA[l] || this.pairB[j] !== this.lastB[l]) {
        // The same two indices, but another entity at one of them (a generation on): the old pair ended, a new began.
        this.ended(l);
        if ((this.pairEvents[j]! & ContactEvents.enter) !== 0) this.say(true, j);
        i++;
        l++;
      } else {
        if ((this.pairEvents[j]! & ContactEvents.stay) !== 0) this.say(false, j);
        i++;
        l++;
      }
    }
    // This report the last, in its sorted order.
    for (let k = 0; k < count; k++) {
      const j = order[k]!;
      this.lastKey[k] = keys[j]!;
      this.lastA[k] = this.pairA[j]!;
      this.lastB[k] = this.pairB[j]!;
      this.lastTrigger[k] = this.pairTrigger[j]!;
      this.lastEvents[k] = this.pairEvents[j]!;
    }
    this.lastCount = count;
  }

  /** The last report's row `l` ended: its `Exit`, with the refs it began with, if asked for. */
  private ended(l: number): void {
    if ((this.lastEvents[l]! & ContactEvents.exit) === 0) return;
    const ch = this.channels;
    if (this.lastTrigger[l]) {
      const x = ch.texit.emit();
      ch.texit.trigger[x] = this.lastA[l] as EntityRef;
      ch.texit.other[x] = this.lastB[l] as EntityRef;
    } else {
      const x = ch.exit.emit();
      ch.exit.a[x] = this.lastA[l] as EntityRef;
      ch.exit.b[x] = this.lastB[l] as EntityRef;
    }
  }

  /** Row `j` said as an `Enter` or a `Stay`, a collision's or a trigger's. */
  private say(enter: boolean, j: number): void {
    const ch = this.channels;
    const o = j * 8;
    if (this.pairTrigger[j]) {
      const c = enter ? ch.tenter : ch.tstay;
      const x = c.emit();
      c.trigger[x] = this.pairA[j] as EntityRef;
      c.other[x] = this.pairB[j] as EntityRef;
      return;
    }
    const c = enter ? ch.enter : ch.stay;
    const x = c.emit();
    c.a[x] = this.pairA[j] as EntityRef;
    c.b[x] = this.pairB[j] as EntityRef;
    c.pointX[x] = this.pairData[o]!; c.pointY[x] = this.pairData[o + 1]!; c.pointZ[x] = this.pairData[o + 2]!;
    c.normalX[x] = this.pairData[o + 3]!; c.normalY[x] = this.pairData[o + 4]!; c.normalZ[x] = this.pairData[o + 5]!;
    c.impulse[x] = this.pairData[o + 6]!;
    c.speed[x] = this.speeds[j]!;
  }

  // ── queries (§6) ──────────────────────────────────────────────────────────

  layers(...names: string[]): number {
    if (names.length === 0) return ALL_LAYERS;
    const all = this.settings.layers;
    let mask = 0;
    for (const name of names) {
      const at = all.indexOf(name);
      if (at < 0) throw new Error(`[physics] no physics layer '${name}' (physics.json's layers: ${all.join(', ')})`);
      mask |= 1 << at;
    }
    return mask;
  }

  /** Queries are the main thread's: a `parallel` system may run on a worker, where there is no physics (D19). */
  private refuseParallel(what: string): void {
    if (this.world.parallelRunning) throw new Error(`[physics] ${what} from a parallel system: a parallel system may run on a worker thread, where there is no physics. Take parallel off, or ask from another system`);
  }

  raycast(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number, mask: number, hit: RayHit, triggers = false): boolean {
    this.refuseParallel('raycast');
    const length = Math.hypot(dx, dy, dz);
    if (length === 0 || !(max > 0)) return false;
    const ray = this.ray;
    ray[0] = ox; ray[1] = oy; ray[2] = oz;
    ray[3] = dx / length; ray[4] = dy / length; ray[5] = dz / length;
    ray[6] = 0;
    ray[7] = max;
    return this.cast(mask, hit, triggers, 0);
  }

  /**
   * The nearest hit from `start` metres along the ray to `max`, skipping the entity `skip` (0: none) and, unless asked,
   * triggers -- each skipped by casting again from just past it, at most 16 times -- into `hit`, its distance from the origin.
   */
  private cast(mask: number, hit: RayHit, triggers: boolean, skip: number): boolean {
    // Its numbers from `ray`, not arguments: a call with a dozen numbers boxes them, where this is not inlined.
    const ray = this.ray;
    const ox = ray[0]!, oy = ray[1]!, oz = ray[2]!, dx = ray[3]!, dy = ray[4]!, dz = ray[5]!, max = ray[7]!;
    const cb = this.rayCallback;
    const ammo = this.ammo as unknown as { getPointer(o: unknown): number };
    let from = ray[6]!;
    for (let tries = 0; tries < 16 && from < max; tries++) {
      this.v.setValue(ox + dx * from, oy + dy * from, oz + dz * from);
      this.v2.setValue(ox + dx * max, oy + dy * max, oz + dz * max);
      cb.set_m_rayFromWorld(this.v);
      cb.set_m_rayToWorld(this.v2);
      cb.set_m_closestHitFraction(1);
      cb.set_m_collisionObject(null as never);
      cb.set_m_collisionFilterGroup(triggers ? -1 : (QUERY_BIT << 16) >> 16);
      cb.set_m_collisionFilterMask((mask << 16) >> 16);
      this.dynamics.rayTest(this.v, this.v2, cb);
      if (!cb.hasHit()) return false;
      const rec = this.shared.bodies.get(ammo.getPointer(cb.get_m_collisionObject()));
      const at = from + (max - from) * cb.get_m_closestHitFraction();
      if (rec === undefined || (rec.trigger && !triggers) || rec.e === skip) {
        from = at + 1e-4;
        continue;
      }
      const p = cb.get_m_hitPointWorld();
      const n = cb.get_m_hitNormalWorld();
      hit.entity = rec.e;
      hit.x = p.x(); hit.y = p.y(); hit.z = p.z();
      hit.normalX = n.x(); hit.normalY = n.y(); hit.normalZ = n.z();
      hit.distance = at;
      hit.fraction = at / max;
      return true;
    }
    return false;
  }

  private readonly scratchHit = new RayHit();
  private readonly edgeHit = new RayHit();
  /** A cast's ray: origin, direction (unit), the metres it starts at, and its length. */
  private readonly ray = new Float64Array(8);

  raycastAll(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number, mask: number, hits: RayHits, triggers = false): number {
    this.refuseParallel('raycastAll');
    hits.count = 0;
    const length = Math.hypot(dx, dy, dz);
    if (length === 0 || !(max > 0)) return 0;
    const ray = this.ray;
    ray[0] = ox; ray[1] = oy; ray[2] = oz;
    ray[3] = dx / length; ray[4] = dy / length; ray[5] = dz / length;
    ray[7] = max;
    const h = this.scratchHit;
    let from = 0;
    let last = 0;
    // Each hit, then on from just past it -- out through the far side of what it went into, as a ray from inside a
    // convex shape does not meet it -- never the same entity twice in a row.
    for (let tries = 0; hits.count < hits.capacity && tries < hits.capacity * 4; tries++) {
      ray[6] = from;
      if (!this.cast(mask, h, triggers, last)) break;
      from = h.distance + 1e-3;
      if (h.entity === last) continue;
      let seen = false;
      for (let k = 0; k < hits.count; k++) if (hits.entity[k] === h.entity) seen = true;
      last = h.entity;
      if (seen) continue;
      const k = hits.count++;
      hits.entity[k] = h.entity;
      hits.point[k * 3] = h.x; hits.point[k * 3 + 1] = h.y; hits.point[k * 3 + 2] = h.z;
      hits.normal[k * 3] = h.normalX; hits.normal[k * 3 + 1] = h.normalY; hits.normal[k * 3 + 2] = h.normalZ;
      hits.distance[k] = h.distance;
    }
    return hits.count;
  }

  /** `probe`'s Bullet shape, made the first time it is asked for. */
  private probeShape(probe: Probe): InstanceType<Ammo['btConvexShape']> {
    let shape = this.probes.get(probe);
    if (shape) return shape;
    const ammo = this.ammo;
    if (probe.kind === 'sphere') shape = new ammo.btSphereShape(probe.a);
    else if (probe.kind === 'box') {
      this.v.setValue(probe.a, probe.b, probe.c);
      shape = new ammo.btBoxShape(this.v);
    } else shape = new ammo.btCapsuleShape(probe.a, Math.max(0, probe.b - 2 * probe.a));
    this.probes.set(probe, shape);
    return shape;
  }

  sweep(probe: Probe, fx: number, fy: number, fz: number, tx: number, ty: number, tz: number, mask: number, hit: RayHit, triggers = false): boolean {
    this.refuseParallel('sweep');
    const shape = this.probeShape(probe);
    const cb = this.sweepCallback;
    const ammo = this.ammo as unknown as { getPointer(o: unknown): number };
    const lx = tx - fx, ly = ty - fy, lz = tz - fz;
    const length = Math.hypot(lx, ly, lz);
    if (length === 0) return false;
    let from = 0;
    for (let tries = 0; tries < 16 && from < 1; tries++) {
      this.from.setIdentity();
      this.v.setValue(fx + lx * from, fy + ly * from, fz + lz * from);
      this.from.setOrigin(this.v);
      this.tr.setIdentity();
      this.v2.setValue(tx, ty, tz);
      this.tr.setOrigin(this.v2);
      cb.set_m_convexFromWorld(this.v);
      cb.set_m_convexToWorld(this.v2);
      cb.set_m_closestHitFraction(1);
      cb.set_m_hitCollisionObject(null as never);
      cb.set_m_collisionFilterGroup(triggers ? -1 : (QUERY_BIT << 16) >> 16);
      cb.set_m_collisionFilterMask((mask << 16) >> 16);
      this.dynamics.convexSweepTest(shape, this.from, this.tr, cb, 0);
      if (!cb.hasHit()) return false;
      const at = from + (1 - from) * cb.get_m_closestHitFraction();
      const rec = this.shared.bodies.get(ammo.getPointer(cb.get_m_hitCollisionObject()));
      if (rec === undefined || (rec.trigger && !triggers)) {
        from = at + 1e-4 / length;
        continue;
      }
      const n = cb.get_m_hitNormalWorld();
      hit.entity = rec.e;
      hit.x = fx + lx * at; hit.y = fy + ly * at; hit.z = fz + lz * at;
      hit.normalX = n.x(); hit.normalY = n.y(); hit.normalZ = n.z();
      hit.distance = at * length;
      hit.fraction = at;
      return true;
    }
    return false;
  }

  overlap(probe: Probe, x: number, y: number, z: number, mask: number, out: Uint32Array, triggers = false): number {
    this.refuseParallel('overlap');
    const object = this.probeObject;
    object.setCollisionShape(this.probeShape(probe));
    this.tr.setIdentity();
    this.v.setValue(x, y, z);
    this.tr.setOrigin(this.v);
    object.setWorldTransform(this.tr);
    this.overlapOut = out;
    this.overlapCount = 0;
    this.overlapMask = mask;
    this.overlapTriggers = triggers;
    // Its own filter as every bit (its group and mask, shorts 4 and 6 bytes in: not in this build's binding), so it
    // meets every layer -- the mask and triggers are said above, in JS.
    const at = (this.ammo as unknown as { getPointer(o: unknown): number }).getPointer(this.contactCallback);
    const i16 = (this.ammo as unknown as { HEAP16: Int16Array }).HEAP16;
    i16[(at + 4) >> 1] = -1;
    i16[(at + 6) >> 1] = -1;
    this.dynamics.contactTest(object, this.contactCallback as unknown as InstanceType<Ammo['ContactResultCallback']>);
    return this.overlapCount;
  }

  /** Contacts touching now: manifolds with a point. */
  private contacts(): number {
    const d = this.dispatcher;
    let n = 0;
    const count = d.getNumManifolds();
    for (let i = 0; i < count; i++) if (d.getManifoldByIndexInternal(i).getNumContacts() > 0) n++;
    return n;
  }

  // ── reconcile: who has a body, and its shape ──────────────────────────────

  private grow(): void {
    const need = this.world.stats.capacity + 1;
    if (need <= this.rows) return;
    let rows = Math.max(64, this.rows);
    while (rows < need) rows *= 2;
    this.member = u32(rows, this.member);
    this.colSeen = u32(rows, this.colSeen);
    this.colRef = u32(rows, this.colRef);
    this.colOwner = u32(rows, this.colOwner);
    this.colShadow = f32(rows, this.colShadow, COL_STRIDE);
    this.nextCol = u32(rows, this.nextCol);
    this.dirty = u32(rows, this.dirty);
    this.trigDirty = u32(rows, this.trigDirty);
    this.trigBody = u32(rows, this.trigBody);

    const trig = new Uint8Array(rows);
    trig.set(this.colTrigger);
    this.colTrigger = trig;
    this.poseShadow = f32(rows, this.poseShadow, 7);
    this.velShadow = f32(rows, this.velShadow, 6);
    this.kinematicFrom = f32(rows, this.kinematicFrom, 7);
    this.dynamic = u32(rows, this.dynamic);
    const anchors = new Float64Array(rows * 10);
    anchors.set(this.anchorShadow);
    this.anchorShadow = anchors;
    const poses = new Float64Array(rows * 7);
    poses.set(this.bodyPose);
    this.bodyPose = poses;
    const sleep = new Uint8Array(rows);
    sleep.set(this.sleepShadow);
    this.sleepShadow = sleep;
    this.rows = rows;
  }

  private reconcile(): void {
    const world = this.world;
    this.grow();
    const stamp = ++this.stamp;
    const member = this.member;

    // A load (`world.onLoad`: a saved game, a scene, a playtest put back): every body made again, in Bullet's world made
    // afresh -- its broadphase and pair cache as a new one's -- so a save loaded here plays as one loaded anywhere (D18).
    // A game that removed its every body is no load: its world goes on.
    if (this.loaded) {
      this.loaded = false;
      for (let ri = this.recs.length - 1; ri >= 0; ri--) this.drop(this.recs[ri]!, ri);
      for (const c of this.charList) this.uncharacter(c);
      this.unmakeDynamics();
      this.makeDynamics();
      this.applyWorldSettings();
      this.counted.worlds++;
      // No pair carried over: the load's world says its contacts afresh, as a fresh one would (no Exit of what was).
      this.lastCount = 0;
    }

    // Bodies: the members of the query now, against the records.
    const joins = this.joins;
    joins.length = 0;
    const bodies = this.bodies;
    for (let n = 0; n < bodies.count; n++) {
      const e = bodies.members[n]!;
      member[e] = stamp;
      const rec = this.at[e];
      if (!rec || !rec.rigid || rec.stale || rec.ref !== world.ref(e)) joins.push(e);
    }
    // Gone: out of the query, its entity made again (another ref), or destroyed. A parked one waits for its take,
    // until its entity is no longer parked (a pool drained: destroyed for real).
    for (let i = this.recs.length - 1; i >= 0; i--) {
      const rec = this.recs[i]!;
      if (!rec.rigid) continue;
      if (rec.parked) {
        // Taken (a member again: `join` puts it back), still parked, or gone for real (a pool drained, a load).
        if (rec.stale || (member[rec.e] !== stamp && !world.parked(rec.e as Entity))) this.drop(rec, i);
        continue;
      }
      if (member[rec.e] === stamp && !rec.stale && rec.ref === world.ref(rec.e as Entity)) continue;
      if (!rec.stale && member[rec.e] !== stamp && world.parked(rec.e as Entity)) this.park(rec);
      else this.drop(rec, i);
    }

    // Colliders: each one's owner, and what it says, against what its owner's shape was built from.
    const dirty = this.dirty;
    const cols = this.colliders;
    const parent = this.H.parent;
    if (this.colList.length < cols.count) {
      let size = this.colList.length;
      while (size < cols.count) size *= 2;
      const old = this.colList;
      this.colList = new Uint32Array(size);
      this.colList.set(old.subarray(0, this.colCount));
    }
    const tjoins = this.tjoins;
    tjoins.length = 0;
    for (let n = 0; n < cols.count; n++) {
      const c: number = cols.members[n]!;
      this.colSeen[c] = stamp;
      // A trigger's colliders are its own collision object, never a body's part (D12); any other's, the body above it's.
      const trigger = this.isTrigger(c);
      let above = 0;
      for (let x = c; x !== 0; x = parent[x]!) {
        if (member[x] === stamp) {
          above = x;
          break;
        }
      }
      const owner: number = trigger || above === 0 ? c : above;
      // A trigger's body (on it or above it): the two are one thing, and never said to touch.
      this.trigBody[c] = trigger ? above : 0;
      const ref = world.ref(c as Entity) as number;
      const was = this.colRef[c] === ref ? this.colOwner[c]! : 0;
      const wasTrigger = this.colTrigger[c] === 1;
      if (this.colRef[c] !== ref) {
        this.colRef[c] = ref;
        this.colShadow.fill(0, c * COL_STRIDE, (c + 1) * COL_STRIDE);
      }
      if (was !== owner || wasTrigger !== trigger) {
        if (was !== 0) this.markDirty(was, wasTrigger, stamp);
        this.markDirty(owner, trigger, stamp);
        this.colOwner[c] = owner;
        this.colTrigger[c] = trigger ? 1 : 0;
      }
      if (this.describe(c, owner, parent)) this.markDirty(owner, trigger, stamp);
      if (trigger) {
        const rec = this.trigAt[c];
        if (!rec || rec.stale || rec.ref !== ref) tjoins.push(c);
      } else if (owner === c && member[c] !== stamp) {
        // A collider with no body above it is a static body of its own.
        const rec = this.at[c];
        if (!rec || rec.rigid || rec.stale || rec.ref !== ref) joins.push(c);
      }
    }
    // Colliders gone since last tick: their owners' shapes again.
    for (let n = 0; n < this.colCount; n++) {
      const c = this.colList[n]!;
      if (this.colSeen[c] === stamp) continue;
      const owner = this.colOwner[c]!;
      if (owner !== 0) this.markDirty(owner, this.colTrigger[c] === 1, stamp);
      this.colOwner[c] = 0;
      this.colRef[c] = 0;
      this.colTrigger[c] = 0;
    }
    for (let n = 0; n < cols.count; n++) this.colList[n] = cols.members[n]!;
    this.colCount = cols.count;
    // Lone static bodies whose collider went, or is now under a body or a trigger; triggers whose colliders went or are not one.
    for (let i = this.recs.length - 1; i >= 0; i--) {
      const rec = this.recs[i]!;
      if (rec.rigid) continue;
      const c = rec.e;
      const same = this.colSeen[c] === stamp && !rec.stale && rec.ref === world.ref(c as Entity);
      if (rec.trigger ? same && this.colTrigger[c] === 1 : same && this.colTrigger[c] === 0 && this.colOwner[c] === c && member[c] !== stamp) continue;
      this.drop(rec, i);
    }

    if (this.materialsChanged) {
      this.materialsChanged = false;
      this.materials.clear();
      for (let ri = 0; ri < this.recs.length; ri++) if (this.recs[ri]!.body) this.remat(this.recs[ri]!);
    }

    // The joins, in entity order: made, or a parked one taken.
    if (joins.length > 1) joins.sort((a, b) => a - b);
    for (let i = 0; i < joins.length; i++) this.join(joins[i]!);
    for (let i = 0; i < tjoins.length; i++) this.joinTrigger(tjoins[i]!);

    // Shapes built again where their colliders changed: each dirty owner's colliders chained, then built.
    let any = false;
    const trigDirty = this.trigDirty;
    for (let ri = 0; ri < this.recs.length; ri++) {
      const rec = this.recs[ri]!;
      if ((rec.trigger ? trigDirty : dirty)[rec.e] === stamp && !rec.parked) {
        rec.first = rec.last = 0;
        any = true;
      }
    }
    if (any) {
      for (let n = 0; n < this.colCount; n++) {
        const c = this.colList[n]!;
        const trigger = this.colTrigger[c] === 1;
        const rec = trigger ? this.trigAt[c] : this.at[this.colOwner[c]!];
        if (!rec || rec.parked || (trigger ? trigDirty : dirty)[rec.e] !== stamp) continue;
        this.nextCol[c] = 0;
        if (rec.first === 0) rec.first = c;
        else this.nextCol[rec.last] = c;
        rec.last = c;
      }
      for (let ri = 0; ri < this.recs.length; ri++) {
        const rec = this.recs[ri]!;
        if ((rec.trigger ? trigDirty : dirty)[rec.e] === stamp && !rec.parked) this.reshape(rec);
      }
    }

    // Settings changed on a `RigidBody`: the body made again over its shape.
    const rb = this.RB;
    for (let ri = 0; ri < this.recs.length; ri++) {
      const rec = this.recs[ri]!;
      if (!rec.rigid || rec.parked || !rec.body) continue;
      const c = rec.config;
      const e = rec.e;
      if (
        c[0] !== rb.type[e] || c[1] !== rb.mass[e] || c[2] !== rb.linearDamping[e] || c[3] !== rb.angularDamping[e] ||
        c[4] !== rb.gravityScale[e] || c[5] !== rb.lockPosition[e] || c[6] !== rb.lockRotation[e] || c[7] !== rb.canSleep[e] ||
        c[8] !== rb.ccd[e] || c[9] !== rb.ccdRadius[e]
      ) {
        this.unbody(rec);
        this.embody(rec, true);
      }
    }
  }

  /**
   * `c`'s colliders' numbers, and where it sits on `owner`, into its shadow row: true when they differ from what
   * the row held (its owner's shape is to be built again).
   */
  private describe(c: number, owner: number, parent: ArrayLike<number>): boolean {
    const world = this.world;
    // Where `c` sits on its owner: its locals composed up to (not including) the owner, then the owner's scale.
    const t = this.T;
    const w = this.W;
    rel[0] = rel[1] = rel[2] = 0;
    rel[3] = rel[4] = rel[5] = 0;
    rel[6] = 1;
    for (let n = c; n !== owner && n !== 0; n = parent[n]!) {
      if (!world.has(n as Entity, Transform)) continue;
      const sx = t.sx[n]!, sy = t.sy[n]!, sz = t.sz[n]!;
      const lx = t.qx[n]!, ly = t.qy[n]!, lz = t.qz[n]!, lw = t.qw[n]!;
      rotate(lx, ly, lz, lw, rel[0]! * sx, rel[1]! * sy, rel[2]! * sz);
      rel[0] = t.px[n]! + p[0]!;
      rel[1] = t.py[n]! + p[1]!;
      rel[2] = t.pz[n]! + p[2]!;
      mul(lx, ly, lz, lw, rel[3]!, rel[4]!, rel[5]!, rel[6]!);
      rel[3] = q[0]!;
      rel[4] = q[1]!;
      rel[5] = q[2]!;
      rel[6] = q[3]!;
    }
    if (owner !== c && world.has(owner as Entity, Transform)) {
      rel[0] = rel[0]! * w.sx[owner]!;
      rel[1] = rel[1]! * w.sy[owner]!;
      rel[2] = rel[2]! * w.sz[owner]!;
    }
    const hasT = world.has(c as Entity, Transform);
    const scx = hasT ? w.sx[c]! : 1, scy = hasT ? w.sy[c]! : 1, scz = hasT ? w.sz[c]! : 1;
    row.fill(0);
    for (let k = 0; k < COLLIDERS.length; k++) {
      const C = COLLIDERS[k]!;
      if (!world.enabled(c as Entity, C)) continue;
      const o = k * KIND_STRIDE;
      row[o] = 1;
      // Each kind's own numbers (1-4), and the fields every collider has (center, turn, material).
      let common: {
        centerX: ArrayLike<number>; centerY: ArrayLike<number>; centerZ: ArrayLike<number>; turnX: ArrayLike<number>; turnY: ArrayLike<number>; turnZ: ArrayLike<number>;
        material: ArrayLike<number>; trigger: ArrayLike<number>; layer: ArrayLike<number>; events: ArrayLike<number>;
      };
      if (C === BoxCollider) {
        const s = (common = this.BOX);
        row[o + 1] = s.sizeX[c]!; row[o + 2] = s.sizeY[c]!; row[o + 3] = s.sizeZ[c]!;
      } else if (C === SphereCollider) {
        const s = (common = this.SPHERE);
        row[o + 1] = s.radius[c]!;
      } else if (C === PlaneCollider) {
        const s = (common = this.PLANE);
        row[o + 1] = s.normalX[c]!; row[o + 2] = s.normalY[c]!; row[o + 3] = s.normalZ[c]!;
        row[o + 4] = s.offset[c]!;
      } else if (C === CapsuleCollider || C === CylinderCollider || C === ConeCollider) {
        const s = (common = C === CapsuleCollider ? this.CAPSULE : C === CylinderCollider ? this.CYLINDER : this.CONE);
        row[o + 1] = s.radius[c]!; row[o + 2] = s.height[c]!; row[o + 3] = s.axis[c]!;
      } else if (C === HullCollider) {
        const s = (common = this.HULL);
        // None named: the model its Render draws.
        row[o + 1] = s.mesh[c]! !== 0 ? s.mesh[c]! : world.has(c as Entity, Render) ? this.RENDER.model[c]! : 0;
        row[o + 2] = s.maxPoints[c]!;
        // Its model's version: a re-export (`onModels`) builds it again.
        row[o + 3] = this.versions.get(row[o + 1]!) ?? 0;
      } else if (C === MeshCollider) {
        const s = (common = this.MESH);
        row[o + 1] = s.mesh[c]! !== 0 ? s.mesh[c]! : world.has(c as Entity, Render) ? this.RENDER.model[c]! : 0;
        row[o + 2] = this.versions.get(row[o + 1]!) ?? 0;
      } else {
        const s = (common = this.HEIGHTS);
        row[o + 1] = s.heights[c]!; row[o + 2] = s.sizeX[c]!; row[o + 3] = s.sizeY[c]!; row[o + 4] = s.heightScale[c]!;
      }
      row[o + 5] = common.centerX[c]!; row[o + 6] = common.centerY[c]!; row[o + 7] = common.centerZ[c]!;
      row[o + 8] = common.turnX[c]!; row[o + 9] = common.turnY[c]!; row[o + 10] = common.turnZ[c]!;
      for (let j = 0; j < 7; j++) row[o + 11 + j] = rel[j]!;
      row[o + 18] = scx; row[o + 19] = scy; row[o + 20] = scz;
      row[o + 21] = common.material[c]!;
      row[o + 22] = common.trigger[c]!;
      row[o + 23] = common.layer[c]!;
      row[o + 24] = common.events[c]!;
    }
    const shadow = this.colShadow;
    const base = c * COL_STRIDE;
    let differs = false;
    for (let j = 0; j < COL_STRIDE; j++) {
      if (shadow[base + j] !== row[j]) {
        differs = true;
        shadow[base + j] = row[j]!;
      }
    }
    return differs;
  }


  /** Is any collider of `c`'s, switched on, a trigger: then its colliders are one trigger, its own. */
  private isTrigger(c: number): boolean {
    for (let k = 0; k < this.colStores.length; k++) {
      if (this.colStores[k]!.trigger[c] === 1 && this.world.enabled(c as Entity, COLLIDERS[k]!)) return true;
    }
    return false;
  }

  /** `owner`'s shape to be built again this reconcile: a body's (or a lone static collider's), or a trigger's. */
  private markDirty(owner: number, trigger: boolean, stamp: number): void {
    (trigger ? this.trigDirty : this.dirty)[owner] = stamp;
  }

  /** A trigger record for the collider entity `c`, in entity order after any body of the same entity. */
  private joinTrigger(c: number): void {
    const old = this.trigAt[c];
    if (old) this.drop(old, this.recs.indexOf(old));
    const rec = new Rec(c, this.world.ref(c as Entity) as number, false, true);
    this.trigAt[c] = rec;
    let at = this.recs.length;
    while (at > 0 && this.recs[at - 1]!.e > c) at--;
    this.recs.splice(at, 0, rec);
    this.trigDirty[c] = this.stamp;
  }

  /** A record for `e` made (or a parked one taken), its shape built and its body added. */
  private join(e: number): void {
    const world = this.world;
    const rigid = this.member[e] === this.stamp;
    const ref = world.ref(e as Entity) as number;
    let rec = this.at[e];
    if (rec && rec.parked && rigid && !rec.stale) {
      // A pooled instance taken: its kept body back, at the pose and velocities the reset gave it.
      rec.parked = false;
      rec.ref = ref;
      this.dirty[e] = this.stamp;
      this.place(rec);
      this.add(rec);
      rec.inWorld = true;
      this.applyBodySettings(rec);
      this.startMoving(rec);
      return;
    }
    if (rec) this.drop(rec, this.recs.indexOf(rec));
    rec = new Rec(e, ref, rigid);
    this.at[e] = rec;
    // In entity order: the order bodies are added and stepped.
    let at = this.recs.length;
    while (at > 0 && this.recs[at - 1]!.e > e) at--;
    this.recs.splice(at, 0, rec);
    this.dirty[e] = this.stamp;
  }

  /** `rec`'s shape built from its colliders' rows (its chain), if they differ from what it was built from; its body made or given it. */
  private reshape(rec: Rec): void {
    // What it would be built from, against what it was.
    let length = 0;
    let differs = false;
    for (let c = rec.first; c !== 0; c = this.nextCol[c]!) {
      if (rec.desc.length < length + COL_STRIDE) {
        const grown = new Float32Array(rec.desc.length * 2);
        grown.set(rec.desc);
        rec.desc = grown;
      }
      const base = c * COL_STRIDE;
      for (let j = 0; j < COL_STRIDE; j++) {
        const value = this.colShadow[base + j]!;
        if (rec.desc[length + j] !== value) {
          differs = true;
          rec.desc[length + j] = value;
        }
      }
      length += COL_STRIDE;
    }
    if (length !== rec.descLength) differs = true;
    rec.descLength = length;
    if (!differs && rec.body) return;
    const had = rec.body !== null;
    if (had) this.unbody(rec);
    this.unshape(rec);
    this.build(rec);
    this.embody(rec, had);
  }

  /**
   * The shapes of `rec` from its `desc`: each collider's shape where it sits on the body, then one shape as it is when
   * it is the only one and sits plain on the body, else a compound. A dynamic body's centre of mass and inertia from
   * them, its mass shared by volume (a compound's children moved so the centre of mass is the body's origin). Allocates
   * (a shape is made): only when the colliders changed.
   */
  private build(rec: Rec): void {
    const ammo = this.ammo;
    const d = rec.desc;
    const type = rec.trigger ? BodyType.kinematic : rec.rigid ? this.RB.type[rec.e]! : BodyType.static;
    let count = 0;
    let smallest = Infinity;
    let plane = -1;
    let offset = false;
    for (let at = 0; at < rec.descLength; at += KIND_STRIDE) {
      if (d[at] !== 1) continue;
      const kind = COLLIDERS[(at % COL_STRIDE) / KIND_STRIDE]!;
      const sx = Math.abs(d[at + 18]!), sy = Math.abs(d[at + 19]!), sz = Math.abs(d[at + 20]!);
      // Where it sits on the body: its place on its entity (center, scaled; turn) after its entity's place on the body.
      const rx = d[at + 11]!, ry = d[at + 12]!, rz = d[at + 13]!;
      const qx = d[at + 14]!, qy = d[at + 15]!, qz = d[at + 16]!, qw = d[at + 17]!;
      rotate(qx, qy, qz, qw, d[at + 5]! * d[at + 18]!, d[at + 6]! * d[at + 19]!, d[at + 7]! * d[at + 20]!);
      let cx = rx + p[0]!, cy = ry + p[1]!, cz = rz + p[2]!;
      eulerDegrees(d[at + 8]!, d[at + 9]!, d[at + 10]!, rel, 0);
      mul(qx, qy, qz, qw, rel[0]!, rel[1]!, rel[2]!, rel[3]!);
      const turned = q[0]! !== 0 || q[1]! !== 0 || q[2]! !== 0 || q[3]! !== 1;
      let shape: BtShape | null = null;
      let volume = 0;
      // Its own centre of mass from its middle, in its own frame: a cone's is a quarter of its height up from its base.
      let ox = 0, oy = 0, oz = 0;
      if (kind === MeshCollider || kind === PlaneCollider || kind === HeightfieldCollider) {
        // What does not move: never a dynamic body's (the compile says so in a file; here, once, and left out).
        if (type === BodyType.dynamic || (type === BodyType.kinematic && kind !== MeshCollider)) {
          this.warn(rec, kind.name, `on a ${type === BodyType.dynamic ? 'dynamic' : 'kinematic'} body: a ${kind.name.replace('Collider', '').toLowerCase()} is for what does not move -- left out (a HullCollider, or primitives as a compound, for a body that moves)`);
          continue;
        }
      }
      if (kind === BoxCollider) {
        const hx = Math.max(1e-4, (d[at + 1]! * sx) / 2), hy = Math.max(1e-4, (d[at + 2]! * sy) / 2), hz = Math.max(1e-4, (d[at + 3]! * sz) / 2);
        this.v.setValue(hx, hy, hz);
        const box = new ammo.btBoxShape(this.v);
        box.setMargin(Math.min(MARGIN, 0.2 * Math.min(hx, hy, hz)));
        shape = box;
        volume = 8 * hx * hy * hz;
        smallest = Math.min(smallest, 2 * hx, 2 * hy, 2 * hz);
      } else if (kind === SphereCollider) {
        const r = Math.max(1e-4, d[at + 1]! * Math.max(sx, sy, sz));
        shape = new ammo.btSphereShape(r);
        volume = (4 / 3) * Math.PI * r * r * r;
        smallest = Math.min(smallest, 2 * r);
      } else if (kind === CapsuleCollider || kind === CylinderCollider || kind === ConeCollider) {
        // Along its axis: the radius scaled by the larger of the two scales across it, the length by the one along it (D11).
        const axis = d[at + 3]!;
        const along = axis === ShapeAxis.x ? sx : axis === ShapeAxis.z ? sz : sy;
        const across = axis === ShapeAxis.x ? Math.max(sy, sz) : axis === ShapeAxis.z ? Math.max(sx, sy) : Math.max(sx, sz);
        const r = Math.max(1e-4, d[at + 1]! * across);
        const h = Math.max(1e-4, d[at + 2]! * along);
        if (kind === CapsuleCollider) {
          // Bullet's height is the cylinder's between the two half spheres; ours is end to end.
          const between = Math.max(0, h - 2 * r);
          shape = axis === ShapeAxis.x ? new ammo.btCapsuleShapeX(r, between) : axis === ShapeAxis.z ? new ammo.btCapsuleShapeZ(r, between) : new ammo.btCapsuleShape(r, between);
          volume = Math.PI * r * r * between + (4 / 3) * Math.PI * r * r * r;
          smallest = Math.min(smallest, 2 * r);
        } else if (kind === CylinderCollider) {
          if (axis === ShapeAxis.x) this.v.setValue(h / 2, r, r);
          else if (axis === ShapeAxis.z) this.v.setValue(r, r, h / 2);
          else this.v.setValue(r, h / 2, r);
          const cylinder = axis === ShapeAxis.x ? new ammo.btCylinderShapeX(this.v) : axis === ShapeAxis.z ? new ammo.btCylinderShapeZ(this.v) : new ammo.btCylinderShape(this.v);
          // At most 1 cm: Bullet's cylinder rocks over onto its side from a 4 cm margin when stood on a face.
          cylinder.setMargin(Math.min(SMALL_MARGIN, 0.1 * Math.min(2 * r, h)));
          shape = cylinder;
          volume = Math.PI * r * r * h;
          smallest = Math.min(smallest, 2 * r, h);
        } else {
          // A cone's margin lies outside it: made that much smaller, so it stands at its own height.
          const m = Math.min(SMALL_MARGIN, 0.1 * Math.min(2 * r, h));
          const cone = axis === ShapeAxis.x ? new ammo.btConeShapeX(r - m, h - 2 * m) : axis === ShapeAxis.z ? new ammo.btConeShapeZ(r - m, h - 2 * m) : new ammo.btConeShape(r - m, h - 2 * m);
          cone.setMargin(m);
          shape = cone;
          volume = (Math.PI * r * r * h) / 3;
          // Bullet's cone is centred half way up; its mass a quarter up from its base, a quarter of its height lower.
          if (axis === ShapeAxis.x) ox = -h / 4;
          else if (axis === ShapeAxis.z) oz = -h / 4;
          else oy = -h / 4;
          smallest = Math.min(smallest, 2 * r, h);
        }
      } else if (kind === HullCollider) {
        const points = this.hullPoints(rec, d[at + 1]!, d[at + 2]!);
        if (points === null) continue;
        const hull = new ammo.btConvexHullShape();
        // Its points about their bounds' centre, so the shape is centred (its margin shrunk about it, its middle its
        // own), and that centre where the model has it: moved into place, scaled and turned as the model is.
        let ux = Infinity, uy = Infinity, uz = Infinity, vx = -Infinity, vy = -Infinity, vz = -Infinity;
        for (let i = 0; i < points.length; i += 3) {
          ux = Math.min(ux, points[i]!); vx = Math.max(vx, points[i]!);
          uy = Math.min(uy, points[i + 1]!); vy = Math.max(vy, points[i + 1]!);
          uz = Math.min(uz, points[i + 2]!); vz = Math.max(vz, points[i + 2]!);
        }
        const mx = (ux + vx) / 2, my = (uy + vy) / 2, mz = (uz + vz) / 2;
        for (let i = 0; i < points.length; i += 3) {
          this.v.setValue(points[i]! - mx, points[i + 1]! - my, points[i + 2]! - mz);
          hull.addPoint(this.v, false);
        }
        const lx = (ux - mx) * sx, hx = (vx - mx) * sx, ly = (uy - my) * sy, hy = (vy - my) * sy, lz = (uz - mz) * sz, hz = (vz - mz) * sz;
        rotate(q[0]!, q[1]!, q[2]!, q[3]!, mx * d[at + 18]!, my * d[at + 19]!, mz * d[at + 20]!);
        cx += p[0]!; cy += p[1]!; cz += p[2]!;
        // A hull's margin lies outside it: its scale made that much smaller each way, so it stands at its own size.
        const least = Math.max(1e-4, Math.min(hx - lx, hy - ly, hz - lz));
        const m = Math.min(SMALL_MARGIN, 0.1 * least);
        const ex = Math.max(1e-4, hx - lx), ey = Math.max(1e-4, hy - ly), ez = Math.max(1e-4, hz - lz);
        this.v.setValue(sx * Math.max(0.01, (ex - 2 * m) / ex), sy * Math.max(0.01, (ey - 2 * m) / ey), sz * Math.max(0.01, (ez - 2 * m) / ez));
        hull.setLocalScaling(this.v);
        hull.recalcLocalAabb();
        hull.setMargin(m);
        shape = hull;
        // Its share of the mass by its bounds: a hull fills about half of them (a box all, a sphere 52%).
        volume = (hx - lx) * (hy - ly) * (hz - lz) * 0.5;
        smallest = Math.min(smallest, least);
      } else if (kind === MeshCollider) {
        const bvh = this.meshShape(rec, d[at + 1]!);
        if (bvh === null) continue;
        this.v.setValue(sx, sy, sz);
        shape = new ammo.btScaledBvhTriangleMeshShape(bvh.shape, this.v);
        bvh.users++;
        rec.bvhs.push(bvh);
        smallest = Math.min(smallest, 1);
      } else if (kind === HeightfieldCollider) {
        const field = this.heightShape(rec, d[at + 1]!, d[at + 2]!, d[at + 3]!, d[at + 4]!, sx, sy, sz);
        if (field === null) continue;
        shape = field.shape;
        // Bullet centres a height field on its bounds: moved up by their middle, so heights are from the entity.
        rotate(q[0]!, q[1]!, q[2]!, q[3]!, 0, field.middle, 0);
        cx += p[0]!; cy += p[1]!; cz += p[2]!;
        offset = true;
        smallest = Math.min(smallest, 1);
      } else {
        // A plane: static only, never in a compound (its bounds are infinite). Its normal and constant in the body's space.
        rotate(q[0]!, q[1]!, q[2]!, q[3]!, d[at + 1]!, d[at + 2]!, d[at + 3]!);
        const length = Math.hypot(p[0]!, p[1]!, p[2]!) || 1;
        const nx = p[0]! / length, ny = p[1]! / length, nz = p[2]! / length;
        this.v.setValue(nx, ny, nz);
        shape = new ammo.btStaticPlaneShape(this.v, d[at + 4]! + nx * cx + ny * cy + nz * cz);
        plane = count;
        cx = cy = cz = 0;
        q[0] = q[1] = q[2] = 0;
        q[3] = 1;
        smallest = Math.min(smallest, 1);
      }
      this.counted.made++;
      rec.shapes.push(shape);
      if (parts.length === count) parts.push({ shape, x: 0, y: 0, z: 0, mx: 0, my: 0, mz: 0, qx: 0, qy: 0, qz: 0, qw: 1, volume: 0, material: 0 });
      const part = parts[count++]!;
      part.shape = shape;
      part.x = cx; part.y = cy; part.z = cz;
      rotate(q[0]!, q[1]!, q[2]!, q[3]!, ox, oy, oz);
      part.mx = cx + p[0]!; part.my = cy + p[1]!; part.mz = cz + p[2]!;
      // A dynamic body whose mass is not at its entity's origin: a compound, moved so its centre of mass is Bullet's.
      if (type === BodyType.dynamic && (part.mx !== 0 || part.my !== 0 || part.mz !== 0)) offset = true;
      part.qx = q[0]!; part.qy = q[1]!; part.qz = q[2]!; part.qw = q[3]!;
      part.volume = volume;
      part.material = d[at + 21]!;
      if (kind !== PlaneCollider && (cx !== 0 || cy !== 0 || cz !== 0 || turned)) offset = true;
    }
    if (plane >= 0 && count > 1) {
      // A plane beside other colliders: left out (its bounds would swallow the compound's), said once.
      this.warn(rec, 'PlaneCollider', 'beside other colliders: a plane is the one collider of a static body or of its own -- left out');
      const shape = parts[plane]!.shape;
      rec.shapes.splice(rec.shapes.indexOf(shape), 1);
      this.ammo.destroy(shape);
      for (let i = plane; i < count - 1; i++) {
        const next = parts[i + 1]!;
        parts[i + 1] = parts[i]!;
        parts[i] = next;
      }
      count--;
    }
    // The centre of mass and inertia of a dynamic body: its mass shared by its colliders' volumes, each one's inertia
    // about its own centre (as Bullet works it out, axis-aligned in its own frame) moved to the centre of mass.
    rec.com.fill(0);
    rec.inertia.fill(0);
    const mass = type === BodyType.dynamic && rec.rigid ? this.RB.mass[rec.e]! : 0;
    if (mass > 0 && count > 0) {
      let total = 0;
      for (let i = 0; i < count; i++) total += parts[i]!.volume;
      const share = (i: number): number => (total > 0 ? parts[i]!.volume / total : 1 / count);
      if (count > 1 || offset) {
        for (let i = 0; i < count; i++) {
          // Its share at its own centre of mass.
          const m = share(i);
          rec.com[0] = rec.com[0]! + parts[i]!.mx * m;
          rec.com[1] = rec.com[1]! + parts[i]!.my * m;
          rec.com[2] = rec.com[2]! + parts[i]!.mz * m;
        }
      }
      for (let i = 0; i < count; i++) {
        const part = parts[i]!;
        const m = mass * share(i);
        // Bullet's, about the shape's middle; taken to its own centre of mass (less m d²), then to the body's (plus).
        part.shape.calculateLocalInertia(m, this.v);
        const ax = part.mx - part.x, ay = part.my - part.y, az = part.mz - part.z;
        const dx = part.mx - rec.com[0]!, dy = part.my - rec.com[1]!, dz = part.mz - rec.com[2]!;
        rec.inertia[0] = rec.inertia[0]! + this.v.x() - m * (ay * ay + az * az) + m * (dy * dy + dz * dz);
        rec.inertia[1] = rec.inertia[1]! + this.v.y() - m * (ax * ax + az * az) + m * (dx * dx + dz * dz);
        rec.inertia[2] = rec.inertia[2]! + this.v.z() - m * (ax * ax + ay * ay) + m * (dx * dx + dy * dy);
      }
    } else if (mass > 0) {
      // A body with no collider: a point mass that touches nothing, turned as a small ball would be.
      rec.inertia.fill(mass * 0.1);
    }
    const compound = count !== 1 || offset;
    rec.compound = compound;
    if (compound) {
      const made = new ammo.btCompoundShape(true);
      this.counted.made++;
      for (let i = 0; i < count; i++) {
        const part = parts[i]!;
        this.tr.setIdentity();
        this.v.setValue(part.x - rec.com[0]!, part.y - rec.com[1]!, part.z - rec.com[2]!);
        this.tr.setOrigin(this.v);
        this.bq.setValue(part.qx, part.qy, part.qz, part.qw);
        this.tr.setRotation(this.bq);
        made.addChildShape(this.tr, part.shape);
      }
      rec.shapes.push(made);
      rec.shape = made;
    } else {
      rec.shape = parts[0]!.shape;
    }
    // Its layer, its first collider's; the events its colliders ask for, all of theirs.
    rec.layer = 0;
    rec.events = 0;
    let first = true;
    for (let at = 0; at < rec.descLength; at += KIND_STRIDE) {
      if (d[at] !== 1) continue;
      if (first) rec.layer = d[at + 23]! & 15;
      first = false;
      rec.events |= d[at + 24]!;
    }
    rec.matKeys.length = 0;
    for (let i = 0; i < count; i++) rec.matKeys.push(parts[i]!.material);
    if (rec.matKeys.length === 0) rec.matKeys.push(0);
    rec.smallest = smallest === Infinity ? 0 : smallest;
    for (let i = 0; i < count; i++) parts[i]!.shape = null as unknown as BtShape;
  }

  /** A hull's points for the mesh id `id` (`key#part`), simplified to `most`, by key, cooked once an Ammo; null where it cannot be. */
  private hullPoints(rec: Rec, id: number, most: number): Float32Array | null {
    const mesh = meshOf(id);
    if (mesh === null) {
      this.warn(rec, 'HullCollider', 'has no mesh, and no Render.model to take one from -- left out');
      return null;
    }
    this.idModel.set(id, mesh.model);
    const name = `${mesh.model}#${mesh.part ?? ''}@${most}`;
    const known = this.shared.hulls.get(name);
    if (known) return known;
    const data = this.options.mesh?.(mesh.model, mesh.part) ?? null;
    if (data === null || data.positions.length < 12) {
      this.warn(rec, 'HullCollider', `found no triangles in ${mesh.model}${mesh.part ? `#${mesh.part}` : ''} -- left out`);
      return null;
    }
    const ammo = this.ammo;
    const all = new ammo.btConvexHullShape();
    for (let i = 0; i < data.positions.length; i += 3) {
      this.v.setValue(data.positions[i]!, data.positions[i + 1]!, data.positions[i + 2]!);
      all.addPoint(this.v, false);
    }
    all.recalcLocalAabb();
    let points: Float32Array;
    const n = data.positions.length / 3;
    if (n <= most) points = Float32Array.from(data.positions);
    else {
      // More than it may keep: Bullet's simplified hull, then every so many of those if there are still too many.
      const simple = new ammo.btShapeHull(all);
      simple.buildHull(0);
      const kept = simple.numVertices();
      const at = (ammo as unknown as { getPointer(o: unknown): number }).getPointer(simple.getVertexPointer()) >> 2;
      const f32 = (ammo as unknown as AmmoRuntime).HEAPF32;
      const take = Math.min(kept, most);
      points = new Float32Array(take * 3);
      for (let i = 0; i < take; i++) {
        const from = at + Math.floor((i * kept) / take) * 4;
        points[i * 3] = f32[from]!;
        points[i * 3 + 1] = f32[from + 1]!;
        points[i * 3 + 2] = f32[from + 2]!;
      }
      ammo.destroy(simple);
    }
    ammo.destroy(all);
    this.shared.hulls.set(name, points);
    return points;
  }

  /** The BVH of the mesh id `id`, cooked once an Ammo and shared by every `MeshCollider` of it; null where it cannot be. */
  private meshShape(rec: Rec, id: number): MeshEntry | null {
    const mesh = meshOf(id);
    if (mesh === null) {
      this.warn(rec, 'MeshCollider', 'has no mesh, and no Render.model to take one from -- left out');
      return null;
    }
    const name = `${mesh.model}#${mesh.part ?? ''}`;
    this.idModel.set(id, mesh.model);
    const known = this.shared.meshes.get(name);
    if (known) return known;
    const data = this.options.mesh?.(mesh.model, mesh.part) ?? null;
    if (data === null || data.positions.length < 9) {
      this.warn(rec, 'MeshCollider', `found no triangles in ${name} -- left out`);
      return null;
    }
    const ammo = this.ammo;
    const triangles = new ammo.btTriangleMesh(true, false);
    const a = new ammo.btVector3(0, 0, 0), b = new ammo.btVector3(0, 0, 0), c = new ammo.btVector3(0, 0, 0);
    const pos = data.positions;
    const corner = (v: InstanceType<Ammo['btVector3']>, i: number): void => v.setValue(pos[i * 3]!, pos[i * 3 + 1]!, pos[i * 3 + 2]!);
    const count = data.indices ? data.indices.length : pos.length / 3;
    for (let i = 0; i + 2 < count; i += 3) {
      const i0 = data.indices ? data.indices[i]! : i, i1 = data.indices ? data.indices[i + 1]! : i + 1, i2 = data.indices ? data.indices[i + 2]! : i + 2;
      corner(a, i0);
      corner(b, i1);
      corner(c, i2);
      triangles.addTriangle(a, b, c, false);
    }
    ammo.destroy(a);
    ammo.destroy(b);
    ammo.destroy(c);
    const shape = new ammo.btBvhTriangleMeshShape(triangles, true, true);
    const entry: MeshEntry = { triangles, shape, users: 0, retired: false };
    this.shared.meshes.set(name, entry);
    return entry;
  }

  /**
   * A height field of the texture id `id` over `width` × `depth` metres, `scale` metres at full red, scaled by the entity's
   * world scale: its shape, and how far up the middle of its heights is (Bullet centres it there). Its samples are the
   * heap's, freed with its shapes. Null where it cannot be.
   */
  private heightShape(rec: Rec, id: number, width: number, depth: number, scale: number, sx: number, sy: number, sz: number): { shape: BtShape; middle: number } | null {
    const key = keyText('Texture', id);
    const data = key === null ? null : (this.options.heights?.(key) ?? null);
    if (data === null || data.width < 2 || data.depth < 2 || data.values.length < data.width * data.depth) {
      this.warn(rec, 'HeightfieldCollider', key === null ? 'has no height map -- left out' : `found no heights in ${key} -- left out`);
      return null;
    }
    const ammo = this.ammo;
    const glue = ammo as unknown as AmmoRuntime & { _malloc(bytes: number): number };
    const n = data.width * data.depth;
    const spare = this.shared.blocks.get(n * 4);
    const at = spare && spare.length > 0 ? spare.pop()! : glue._malloc(n * 4);
    rec.heap.push(at, n * 4);
    let low = Infinity, high = -Infinity;
    const f32 = glue.HEAPF32;
    for (let i = 0; i < n; i++) {
      const h = data.values[i]! * scale;
      f32[(at >> 2) + i] = h;
      low = Math.min(low, h);
      high = Math.max(high, h);
    }
    if (high - low < 1e-6) high = low + 1e-6;
    const shape = new ammo.btHeightfieldTerrainShape(data.width, data.depth, at, 1, low, high, 1, ammo.PHY_FLOAT, false);
    this.v.setValue((width / (data.width - 1)) * sx, sy, (depth / (data.depth - 1)) * sz);
    shape.setLocalScaling(this.v);
    return { shape, middle: ((low + high) / 2) * sy };
  }

  /** `model` re-exported: its cooked shapes forgotten, each id made of it a version on. */
  private remodel(model: string): void {
    const prefix = `${model}#`;
    for (const name of [...this.shared.hulls.keys()]) if (name.startsWith(prefix)) this.shared.hulls.delete(name);
    for (const [name, entry] of [...this.shared.meshes]) {
      if (!name.startsWith(prefix)) continue;
      this.shared.meshes.delete(name);
      entry.retired = true;
      if (entry.users === 0) {
        this.ammo.destroy(entry.shape);
        this.ammo.destroy(entry.triangles);
      }
    }
    for (const [id, of] of this.idModel) if (of === model) this.versions.set(id, (this.versions.get(id) ?? 0) + 1);
  }

  /** `rec`'s children's materials, from their key ids: friction, rolling friction, bounce and their modes, a row each. */
  private remat(rec: Rec): void {
    if (rec.trigger) return;
    const count = rec.matKeys.length;
    if (rec.mats.length !== count * MAT) rec.mats = new Float32Array(count * MAT);
    for (let i = 0; i < count; i++) rec.mats.set(this.materialRow(rec, rec.matKeys[i]!), i * MAT);
    const body = rec.body;
    if (!body) return;
    // Bullet's own, for a pair the callback does not see: the first collider's.
    body.setFriction(rec.mats[0]!);
    body.setRollingFriction(rec.mats[1]!);
    body.setRestitution(rec.mats[2]!);
  }

  /** The material row of the key id `id` (0: the project's default), read once until the files change. */
  private materialRow(rec: Rec, id: number): Float32Array {
    const known = this.materials.get(id);
    if (known) return known;
    const row = new Float32Array(MAT);
    let values = { ...PHYSICS_MATERIAL_DEFAULTS, ...this.settings.defaultMaterial };
    if (id !== 0) {
      const key = keyText('PhysicsMaterial', id);
      const json = key === null ? undefined : this.options.material?.(key);
      const read = json === undefined || json === null ? `${key ?? `#${id}`}: no such physics material` : parsePhysicsMaterial(json);
      if (typeof read === 'string') this.warn(rec, 'material', `${read} -- the default taken`);
      else values = read;
    }
    row[0] = values.friction;
    row[1] = values.rollingFriction;
    row[2] = values.restitution;
    row[3] = combineIndex(values.frictionCombine);
    row[4] = combineIndex(values.restitutionCombine);
    this.materials.set(id, row);
    return row;
  }


  /** `rec`'s body made over its shape, at its entity's pose, and added; `again` keeps the velocities the stage last had. */
  private embody(rec: Rec, again: boolean): void {
    const ammo = this.ammo;
    const e = rec.e;
    const rb = this.RB;
    if (rec.trigger) {
      this.enghost(rec);
      return;
    }
    const type = rec.rigid ? rb.type[e]! : BodyType.static;
    rec.type = type;
    const mass = type === BodyType.dynamic ? rb.mass[e]! : 0;
    this.v.setValue(rec.inertia[0]!, rec.inertia[1]!, rec.inertia[2]!);
    this.bodyPoseOf(rec);
    rec.motion = new ammo.btDefaultMotionState(this.tr);
    const info = new ammo.btRigidBodyConstructionInfo(mass, rec.motion, rec.shape!, this.v);
    rec.body = new ammo.btRigidBody(info);
    ammo.destroy(info);
    this.counted.made += 2;
    rec.body.setUserIndex(e);
    rec.body.setCollisionFlags((type === BodyType.static ? CF_STATIC : type === BodyType.kinematic ? CF_KINEMATIC : 0) | CF_CUSTOM_MATERIAL);
    if (type === BodyType.kinematic) rec.body.setActivationState(NEVER_SLEEP);
    rec.pointer = (ammo as unknown as { getPointer(o: unknown): number }).getPointer(rec.body);
    this.shared.bodies.set(rec.pointer, rec);
    this.remat(rec);
    this.add(rec);
    rec.inWorld = true;
    this.applyBodySettings(rec);
    this.notePose(rec);
    if (type === BodyType.dynamic) {
      // Its velocities from the components: a set start's, a load's, or -- made again over a changed shape -- the last.
      if (!again) this.startMoving(rec);
      else this.setVelocities(rec);
    }
  }


  /**
   * A trigger's collision object: a plain one (a ghost), not a body -- neither static nor kinematic to Bullet, so it meets
   * static colliders too (Bullet pairs no two that are both) -- pushing nothing (CF_NO_CONTACT_RESPONSE), set where its
   * entity is each tick as a moved static is (`pull`).
   */
  private enghost(rec: Rec): void {
    const ammo = this.ammo;
    rec.type = BodyType.static;
    const ghost = new ammo.btGhostObject();
    ghost.setCollisionShape(rec.shape!);
    this.poseOf(rec.e);
    ghost.setWorldTransform(this.tr);
    ghost.setCollisionFlags(CF_NO_CONTACT);
    rec.body = ghost as unknown as BtBody;
    this.counted.made++;
    rec.pointer = (ammo as unknown as { getPointer(o: unknown): number }).getPointer(ghost);
    this.shared.bodies.set(rec.pointer, rec);
    this.add(rec);
    rec.inWorld = true;
    this.notePose(rec);
  }

  /** `rec`'s body (or a trigger's ghost) out of Bullet's world. */
  private remove(rec: Rec): void {
    if (rec.trigger) this.dynamics.removeCollisionObject(rec.body!);
    else this.dynamics.removeRigidBody(rec.body!);
  }

  /** `tr` = `e`'s world pose (position, rotation; its scale is its shape's). */
  private poseOf(e: number): void {
    const w = this.W;
    this.tr.setIdentity();
    if (!this.world.has(e as Entity, Transform)) return;
    this.v2.setValue(w.px[e]!, w.py[e]!, w.pz[e]!);
    this.tr.setOrigin(this.v2);
    this.bq.setValue(w.qx[e]!, w.qy[e]!, w.qz[e]!, w.qw[e]!);
    this.tr.setRotation(this.bq);
  }

  /** The pose the stage now holds `rec` at, as the components say it: what the next pull compares with. */
  private notePose(rec: Rec): void {
    const e = rec.e;
    const s = this.poseShadow;
    const i = e * 7;
    if (rec.type === BodyType.dynamic) {
      const t = this.T;
      s[i] = t.px[e]!; s[i + 1] = t.py[e]!; s[i + 2] = t.pz[e]!;
      s[i + 3] = t.qx[e]!; s[i + 4] = t.qy[e]!; s[i + 5] = t.qz[e]!; s[i + 6] = t.qw[e]!;
    } else {
      const w = this.W;
      s[i] = w.px[e]!; s[i + 1] = w.py[e]!; s[i + 2] = w.pz[e]!;
      s[i + 3] = w.qx[e]!; s[i + 4] = w.qy[e]!; s[i + 5] = w.qz[e]!; s[i + 6] = w.qw[e]!;
    }
  }

  /** A dynamic body's velocities and sleep from its `RigidBody`, as a new one starts. */
  private startMoving(rec: Rec): void {
    const e = rec.e;
    if (rec.type !== BodyType.dynamic) return;
    this.setVelocities(rec);
    const rb = this.RB;
    if (rb.sleeping[e]) rec.body!.forceActivationState(SLEEPING);
    else rec.body!.activate(true);
    this.sleepShadow[e] = rb.sleeping[e]!;
  }

  /** A dynamic body's velocities from its `RigidBody` -- but along or about an axis it is locked on, none. */
  private setVelocities(rec: Rec): void {
    const e = rec.e;
    const rb = this.RB;
    const body = rec.body!;
    const lp = rb.lockPosition[e]!, lr = rb.lockRotation[e]!;
    this.v.setValue(lp & 1 ? 0 : rb.velocityX[e]!, lp & 2 ? 0 : rb.velocityY[e]!, lp & 4 ? 0 : rb.velocityZ[e]!);
    body.setLinearVelocity(this.v);
    this.v.setValue(lr & 1 ? 0 : rb.angularVelocityX[e]!, lr & 2 ? 0 : rb.angularVelocityY[e]!, lr & 4 ? 0 : rb.angularVelocityZ[e]!);
    body.setAngularVelocity(this.v);
    const s = this.velShadow;
    const i = e * 6;
    s[i] = rb.velocityX[e]!; s[i + 1] = rb.velocityY[e]!; s[i + 2] = rb.velocityZ[e]!;
    s[i + 3] = rb.angularVelocityX[e]!; s[i + 4] = rb.angularVelocityY[e]!; s[i + 5] = rb.angularVelocityZ[e]!;
  }

  /** Damping, gravity, locks, sleep and swept collision from `RigidBody` and the settings; noted in `config`. */
  private applyBodySettings(rec: Rec): void {
    const body = rec.body!;
    const e = rec.e;
    const settings = this.settings;
    body.setSleepingThresholds(settings.sleep.linear, settings.sleep.angular);
    if (!rec.rigid) return;
    const rb = this.RB;
    const c = rec.config;
    c[0] = rb.type[e]!; c[1] = rb.mass[e]!; c[2] = rb.linearDamping[e]!; c[3] = rb.angularDamping[e]!; c[4] = rb.gravityScale[e]!;
    c[5] = rb.lockPosition[e]!; c[6] = rb.lockRotation[e]!; c[7] = rb.canSleep[e]!; c[8] = rb.ccd[e]!; c[9] = rb.ccdRadius[e]!;
    if (rec.type !== BodyType.dynamic) return;
    body.setDamping(c[2]!, c[3]!);
    const g = settings.gravity;
    const scale = c[4]!;
    this.v.setValue(g[0] * scale, g[1] * scale, g[2] * scale);
    body.setGravity(this.v);
    const lp = c[5]!, lr = c[6]!;
    this.v.setValue(lp & 1 ? 0 : 1, lp & 2 ? 0 : 1, lp & 4 ? 0 : 1);
    body.setLinearFactor(this.v);
    this.v.setValue(lr & 1 ? 0 : 1, lr & 2 ? 0 : 1, lr & 4 ? 0 : 1);
    body.setAngularFactor(this.v);
    if (!c[7]) body.setActivationState(NEVER_SLEEP);
    // Swept: moving more than half its smallest extent in a step sweeps a sphere of 0.4 of it (or the radius given).
    if (c[8]) {
      body.setCcdMotionThreshold(Math.max(1e-4, rec.smallest * 0.5));
      body.setCcdSweptSphereRadius(c[9]! > 0 ? c[9]! : Math.max(1e-4, rec.smallest * 0.4));
    } else {
      body.setCcdMotionThreshold(0);
      body.setCcdSweptSphereRadius(0);
    }
  }

  /** Bullet's world, made afresh: at the install, and when every body went at once (a load: D18). */
  private makeDynamics(): void {
    const ammo = this.ammo;
    this.config = new ammo.btDefaultCollisionConfiguration();
    this.dispatcher = new ammo.btCollisionDispatcher(this.config);
    this.broadphase = new ammo.btDbvtBroadphase();
    this.solver = new ammo.btSequentialImpulseConstraintSolver();
    this.dynamics = new ammo.btDiscreteDynamicsWorld(this.dispatcher, this.broadphase, this.solver, this.config);
    this.dynamics.setContactAddedCallback(this.shared.callback);
    this.dispatcherPointer = (ammo as unknown as { getPointer(o: unknown): number }).getPointer(this.dispatcher);
  }

  private unmakeDynamics(): void {
    const ammo = this.ammo;
    ammo.destroy(this.dynamics);
    ammo.destroy(this.solver);
    ammo.destroy(this.broadphase);
    ammo.destroy(this.dispatcher);
    ammo.destroy(this.config);
  }

  /** `rec`'s body into Bullet's world on its layer, colliding with the layers the project's matrix says. */
  private add(rec: Rec): void {
    const group = 1 << rec.layer;
    // A body's mask has the queries' bit, a trigger's not: a query asks as that bit, so it meets triggers only when it
    // asks as every bit. Shorts, as this build's binding takes them: bit 15 is the sign.
    const mask = this.collides[rec.layer]! | (rec.trigger ? 0 : QUERY_BIT);
    if (rec.trigger) this.dynamics.addCollisionObject(rec.body!, (group << 16) >> 16, (mask << 16) >> 16);
    else this.dynamics.addRigidBody(rec.body!, (group << 16) >> 16, (mask << 16) >> 16);
  }

  /** Each layer's mask of the layers it collides with: every one but the pairs `ignore` names, each way (symmetric). */
  private matrix(): void {
    const names = this.settings.layers;
    this.collides.fill(ALL_LAYERS);
    for (const [a, b] of this.settings.ignore) {
      const i = names.indexOf(a), j = names.indexOf(b);
      if (i < 0 || j < 0) continue;
      this.collides[i] = this.collides[i]! & ~(1 << j);
      this.collides[j] = this.collides[j]! & ~(1 << i);
    }
  }

  private applyWorldSettings(): void {
    const s = this.settings;
    this.matrix();
    this.v.setValue(s.gravity[0], s.gravity[1], s.gravity[2]);
    this.dynamics.setGravity(this.v);
    this.dynamics.getSolverInfo().set_m_numIterations(s.iterations);
  }

  /** Out of the world, its body kept: a pooled instance given back. */
  private park(rec: Rec): void {
    this.detach(rec);
    if (rec.inWorld) this.remove(rec);
    rec.inWorld = false;
    rec.parked = true;
  }

  /** `tr` = `rec`'s body's pose: its entity's world pose, moved to its centre of mass. */
  private bodyPoseOf(rec: Rec): void {
    this.poseOf(rec.e);
    const c = rec.com;
    if (c[0] === 0 && c[1] === 0 && c[2] === 0) return;
    const w = this.W;
    const e = rec.e;
    rotate(w.qx[e]!, w.qy[e]!, w.qz[e]!, w.qw[e]!, c[0]!, c[1]!, c[2]!);
    this.v2.setValue(w.px[e]! + p[0]!, w.py[e]! + p[1]!, w.pz[e]! + p[2]!);
    this.tr.setOrigin(this.v2);
  }

  /** `tr` at `rec`'s body's pose, given to its body and motion state: a teleport, or a taken instance placed. */
  private place(rec: Rec): void {
    this.bodyPoseOf(rec);
    rec.body!.setWorldTransform(this.tr);
    rec.motion!.setWorldTransform(this.tr);
    rec.body!.setInterpolationWorldTransform(this.tr);
    this.notePose(rec);
  }

  private unbody(rec: Rec): void {
    this.detach(rec);
    if (!rec.body) return;
    if (this.shared.bodies.get(rec.pointer) === rec) this.shared.bodies.delete(rec.pointer);
    if (rec.inWorld) this.remove(rec);
    rec.inWorld = false;
    this.ammo.destroy(rec.body);
    if (rec.motion) this.ammo.destroy(rec.motion);
    rec.body = null;
    rec.motion = null;
  }

  private unshape(rec: Rec): void {
    for (let i = rec.shapes.length - 1; i >= 0; i--) this.ammo.destroy(rec.shapes[i]);
    rec.shapes.length = 0;
    rec.shape = null;
    // Its hold on shared BVHs let go: a re-exported model's, held by none now, destroyed.
    for (const entry of rec.bvhs) {
      entry.users--;
      if (entry.retired && entry.users === 0) {
        this.ammo.destroy(entry.shape);
        this.ammo.destroy(entry.triangles);
      }
    }
    rec.bvhs.length = 0;
    // Its heap blocks given back for the next to take (the glue has no `_free`): pairs of where and how big.
    for (let i = 0; i < rec.heap.length; i += 2) {
      const size = rec.heap[i + 1]!;
      let spare = this.shared.blocks.get(size);
      if (!spare) this.shared.blocks.set(size, (spare = []));
      spare.push(rec.heap[i]!);
    }
    rec.heap.length = 0;
  }

  /** `rec` gone: its body and shapes destroyed, its record dropped (`i`: its place in `recs`). */
  private drop(rec: Rec, i: number): void {
    this.unbody(rec);
    this.unshape(rec);
    if (this.at[rec.e] === rec) this.at[rec.e] = undefined;
    if (this.trigAt[rec.e] === rec) this.trigAt[rec.e] = undefined;
    if (i >= 0) this.recs.splice(i, 1);
  }

  private readonly warned = new Set<string>();
  private warn(rec: Rec, what: string, why: string): void {
    const key = `${rec.e}:${what}`;
    if (this.warned.has(key)) return;
    this.warned.add(key);
    console.warn(`[physics] entity ${rec.e}'s ${what} ${why}`);
  }

  // ── pull: what was written since the last push ────────────────────────────

  private pull(forces: boolean): void {
    const world = this.world;
    const t = this.T;
    const w = this.W;
    const rb = this.RB;
    const pose = this.poseShadow;
    const vel = this.velShadow;
    for (let ri = 0; ri < this.recs.length; ri++) {
      const rec = this.recs[ri]!;
      if (!rec.inWorld) continue;
      const e = rec.e;
      const body = rec.body!;
      const i = e * 7;
      if (rec.type === BodyType.dynamic) {
        // Its Transform other than the stage wrote: a teleport, its velocity kept.
        if (
          t.px[e] !== pose[i] || t.py[e] !== pose[i + 1] || t.pz[e] !== pose[i + 2] ||
          t.qx[e] !== pose[i + 3] || t.qy[e] !== pose[i + 4] || t.qz[e] !== pose[i + 5] || t.qw[e] !== pose[i + 6]
        ) {
          this.place(rec);
          body.activate(true);
        }
        const j = e * 6;
        if (
          rb.velocityX[e] !== vel[j] || rb.velocityY[e] !== vel[j + 1] || rb.velocityZ[e] !== vel[j + 2] ||
          rb.angularVelocityX[e] !== vel[j + 3] || rb.angularVelocityY[e] !== vel[j + 4] || rb.angularVelocityZ[e] !== vel[j + 5]
        ) {
          this.setVelocities(rec);
          body.activate(true);
        }
        const sleeping = rb.sleeping[e]!;
        if (sleeping !== this.sleepShadow[e]) {
          if (sleeping) {
            this.v.setValue(0, 0, 0);
            body.setLinearVelocity(this.v);
            body.setAngularVelocity(this.v);
            body.forceActivationState(SLEEPING);
          } else body.activate(true);
          this.sleepShadow[e] = sleeping;
        }
        if (forces && world.enabled(e as Entity, Forces)) this.takeForces(rec);
      } else if (
        w.px[e] !== pose[i] || w.py[e] !== pose[i + 1] || w.pz[e] !== pose[i + 2] ||
        w.qx[e] !== pose[i + 3] || w.qy[e] !== pose[i + 4] || w.qz[e] !== pose[i + 5] || w.qw[e] !== pose[i + 6]
      ) {
        // A kinematic body driven, or a static one moved: where its world transform now is.
        this.poseOf(e);
        if (rec.type === BodyType.kinematic) {
          if (forces && this.settings.substeps > 1) {
            // Moved through the substeps, a share each, from where it was: so what it carries is carried evenly.
            const from = this.kinematicFrom;
            for (let j = 0; j < 7; j++) from[i + j] = pose[i + j]!;
            if (this.drivenCount === this.driven.length) {
              const grown = new Uint32Array(this.driven.length * 2);
              grown.set(this.driven);
              this.driven = grown;
            }
            this.driven[this.drivenCount++] = e;
          } else rec.motion!.setWorldTransform(this.tr);
        } else {
          body.setWorldTransform(this.tr);
          this.dynamics.updateSingleAabb(body);
        }
        this.notePose(rec);
      }
    }
  }

  /** `rec`'s `Forces`: the held ones for this step, the impulses once (cleared). */
  private takeForces(rec: Rec): void {
    const e = rec.e;
    const f = this.F;
    const body = rec.body!;
    const local = f.space[e] === ForceSpace.local;
    if (local) {
      const r = body.getWorldTransform().getRotation();
      q[0] = r.x(); q[1] = r.y(); q[2] = r.z(); q[3] = r.w();
    }
    const fx = f.impulseX[e]!, fy = f.impulseY[e]!, fz = f.impulseZ[e]!;
    if (fx !== 0 || fy !== 0 || fz !== 0) {
      this.vector(local, fx, fy, fz);
      body.applyCentralImpulse(this.v);
      f.impulseX[e] = f.impulseY[e] = f.impulseZ[e] = 0;
      body.activate(true);
    }
    const ax = f.angularImpulseX[e]!, ay = f.angularImpulseY[e]!, az = f.angularImpulseZ[e]!;
    if (ax !== 0 || ay !== 0 || az !== 0) {
      this.vector(local, ax, ay, az);
      body.applyTorqueImpulse(this.v);
      f.angularImpulseX[e] = f.angularImpulseY[e] = f.angularImpulseZ[e] = 0;
      body.activate(true);
    }
    this.held(rec, local);
  }

  /** Each body's held forces again, for a substep past the first (Bullet clears them after each step). */
  private heldForces(): void {
    const world = this.world;
    const f = this.F;
    for (let ri = 0; ri < this.recs.length; ri++) {
      const rec = this.recs[ri]!;
      if (!rec.inWorld || rec.type !== BodyType.dynamic || !world.enabled(rec.e as Entity, Forces)) continue;
      const local = f.space[rec.e] === ForceSpace.local;
      if (local) {
        const r = rec.body!.getWorldTransform().getRotation();
        q[0] = r.x(); q[1] = r.y(); q[2] = r.z(); q[3] = r.w();
      }
      this.held(rec, local);
    }
  }

  private held(rec: Rec, local: boolean): void {
    const e = rec.e;
    const f = this.F;
    const body = rec.body!;
    const fx = f.forceX[e]!, fy = f.forceY[e]!, fz = f.forceZ[e]!;
    if (fx !== 0 || fy !== 0 || fz !== 0) {
      this.vector(local, fx, fy, fz);
      body.applyCentralForce(this.v);
      body.activate(false);
    }
    const tx = f.torqueX[e]!, ty = f.torqueY[e]!, tz = f.torqueZ[e]!;
    if (tx !== 0 || ty !== 0 || tz !== 0) {
      this.vector(local, tx, ty, tz);
      body.applyTorque(this.v);
      body.activate(false);
    }
  }

  /** `this.v` = `(x, y, z)`, turned by the body's rotation in `q` when `local`. */
  private vector(local: boolean, x: number, y: number, z: number): void {
    if (local) {
      rotate(q[0]!, q[1]!, q[2]!, q[3]!, x, y, z);
      this.v.setValue(p[0]!, p[1]!, p[2]!);
    } else this.v.setValue(x, y, z);
  }

  // ── push: the step's poses and velocities into the components ─────────────

  private push(): void {
    const world = this.world;
    const t = this.T;
    const rb = this.RB;
    const pose = this.poseShadow;
    const vel = this.velShadow;
    const bp = this.bodyPose;
    const dyn = this.dynamic;
    const stamp = ++this.pushStamp;
    if (this.moved.length < this.recs.length) this.moved = new Uint32Array(this.recs.length * 2);
    const moved = this.moved;
    // First every dynamic body's pose as Bullet has it after the step, asleep or not: what a body under another is
    // placed against, in the parent's space, below.
    for (let ri = 0; ri < this.recs.length; ri++) {
      const rec = this.recs[ri]!;
      if (!rec.inWorld || rec.type !== BodyType.dynamic) continue;
      const e = rec.e;
      const body = rec.body!;
      dyn[e] = stamp;
      const tr = body.getWorldTransform();
      const o = tr.getOrigin();
      const r = tr.getRotation();
      const i = e * 7;
      const rx = r.x(), ry = r.y(), rz = r.z(), rw = r.w();
      bp[i] = o.x(); bp[i + 1] = o.y(); bp[i + 2] = o.z();
      bp[i + 3] = rx; bp[i + 4] = ry; bp[i + 5] = rz; bp[i + 6] = rw;
      // Bullet's pose is its centre of mass's: the entity's is that less the centre turned with it.
      const c = rec.com;
      if (c[0] !== 0 || c[1] !== 0 || c[2] !== 0) {
        // Written out, not `rotate()`: a call this hot with seven numbers boxes them (measured, 80 bytes a body a tick).
        const x = c[0]!, y = c[1]!, z = c[2]!;
        const tx = 2 * (ry * z - rz * y), ty = 2 * (rz * x - rx * z), tz = 2 * (rx * y - ry * x);
        bp[i] = bp[i]! - (x + rw * tx + (ry * tz - rz * ty));
        bp[i + 1] = bp[i + 1]! - (y + rw * ty + (rz * tx - rx * tz));
        bp[i + 2] = bp[i + 2]! - (z + rw * tz + (rx * ty - ry * tx));
      }
      const sleeping = body.isActive() ? 0 : 1;
      if (rb.sleeping[e] !== sleeping) rb.sleeping[e] = sleeping;
      this.sleepShadow[e] = sleeping;
      const lv = body.getLinearVelocity();
      const av = body.getAngularVelocity();
      rb.velocityX[e] = lv.x(); rb.velocityY[e] = lv.y(); rb.velocityZ[e] = lv.z();
      rb.angularVelocityX[e] = av.x(); rb.angularVelocityY[e] = av.y(); rb.angularVelocityZ[e] = av.z();
      const j = e * 6;
      vel[j] = rb.velocityX[e]!; vel[j + 1] = rb.velocityY[e]!; vel[j + 2] = rb.velocityZ[e]!;
      vel[j + 3] = rb.angularVelocityX[e]!; vel[j + 4] = rb.angularVelocityY[e]!; vel[j + 5] = rb.angularVelocityZ[e]!;
    }
    // Then each one's Transform: its world pose in its parent's space as the parent is after this step -- a parent
    // body's pose from Bullet, anything else composed down from there or from a root -- so a body is where Bullet
    // has it whatever moved above it (D10). One asleep with a parent is written too: the parent may have moved.
    let count = 0;
    for (let ri = 0; ri < this.recs.length; ri++) {
      const rec = this.recs[ri]!;
      if (!rec.inWorld || rec.type !== BodyType.dynamic) continue;
      const e = rec.e;
      const i = e * 7;
      let px = bp[i]!, py = bp[i + 1]!, pz = bp[i + 2]!;
      let rx = bp[i + 3]!, ry = bp[i + 4]!, rz = bp[i + 5]!, rw = bp[i + 6]!;
      if (this.anchorPose(e, stamp)) {
        const a = this.anchor;
        // Asleep, and its parent where it was last tick: its Transform is what it was, nothing to write or settle.
        const shadow = this.anchorShadow;
        const k = e * 10;
        let same = true;
        for (let j = 0; j < 10; j++) {
          if (shadow[k + j] !== a[j]) {
            same = false;
            shadow[k + j] = a[j]!;
          }
        }
        if (same && this.sleepShadow[e]) continue;
        // Into its parent's space: the parent's world pose (in `anchor`) undone.
        rotate(-a[3]!, -a[4]!, -a[5]!, a[6]!, px - a[0]!, py - a[1]!, pz - a[2]!);
        px = p[0]! / (a[7]! || 1);
        py = p[1]! / (a[8]! || 1);
        pz = p[2]! / (a[9]! || 1);
        mul(-a[3]!, -a[4]!, -a[5]!, a[6]!, rx, ry, rz, rw);
        rx = q[0]!; ry = q[1]!; rz = q[2]!; rw = q[3]!;
      } else if (this.sleepShadow[e]) continue;
      t.px[e] = px; t.py[e] = py; t.pz[e] = pz;
      t.qx[e] = rx; t.qy[e] = ry; t.qz[e] = rz; t.qw[e] = rw;
      pose[i] = t.px[e]!; pose[i + 1] = t.py[e]!; pose[i + 2] = t.pz[e]!;
      pose[i + 3] = t.qx[e]!; pose[i + 4] = t.qy[e]!; pose[i + 5] = t.qz[e]!; pose[i + 6] = t.qw[e]!;
      moved[count++] = e;
    }
    if (count > 0) world.settle(moved, count);
  }

  /**
   * The world pose -- position, rotation, scale, into `anchor` -- of the parent `e` hangs from, as it is after this
   * tick's step: false when `e` hangs from nothing (no parent, or one without a `Transform`, which passes nothing on).
   * Walked up to the first dynamic body (its pose Bullet's, just read) or a root, then composed down through the
   * locals between, as propagation composes them. Allocates nothing.
   */
  private anchorPose(e: number, stamp: number): boolean {
    const parent = this.H.parent;
    const world = this.world;
    const up = parent[e]!;
    if (up === 0 || !world.has(up as Entity, Transform)) return false;
    let chain = this.chain;
    let depth = 0;
    let top = up;
    for (;;) {
      if (depth === chain.length) {
        const grown = new Uint32Array(chain.length * 2);
        grown.set(chain);
        this.chain = chain = grown;
      }
      chain[depth++] = top;
      if (this.dynamic[top] === stamp) break;
      const next = parent[top]!;
      if (next === 0 || !world.has(next as Entity, Transform)) break;
      top = next;
    }
    const a = this.anchor;
    const t = this.T;
    let from = depth - 1;
    if (this.dynamic[top] === stamp) {
      const i = top * 7;
      const w = this.W;
      for (let j = 0; j < 7; j++) a[j] = this.bodyPose[i + j]!;
      a[7] = w.sx[top]!; a[8] = w.sy[top]!; a[9] = w.sz[top]!;
    } else {
      a[0] = t.px[top]!; a[1] = t.py[top]!; a[2] = t.pz[top]!;
      a[3] = t.qx[top]!; a[4] = t.qy[top]!; a[5] = t.qz[top]!; a[6] = t.qw[top]!;
      a[7] = t.sx[top]!; a[8] = t.sy[top]!; a[9] = t.sz[top]!;
    }
    // Down from below the top: each local after its parent's world, as `Transforms.compose` does.
    for (from = from - 1; from >= 0; from--) {
      const n = chain[from]!;
      rotate(a[3]!, a[4]!, a[5]!, a[6]!, t.px[n]! * a[7]!, t.py[n]! * a[8]!, t.pz[n]! * a[9]!);
      a[0] = a[0]! + p[0]!; a[1] = a[1]! + p[1]!; a[2] = a[2]! + p[2]!;
      mul(a[3]!, a[4]!, a[5]!, a[6]!, t.qx[n]!, t.qy[n]!, t.qz[n]!, t.qw[n]!);
      a[3] = q[0]!; a[4] = q[1]!; a[5] = q[2]!; a[6] = q[3]!;
      a[7] = a[7]! * t.sx[n]!; a[8] = a[8]! * t.sy[n]!; a[9] = a[9]! * t.sz[n]!;
    }
    return true;
  }

  // ── the end ───────────────────────────────────────────────────────────────

  destroy(): void {
    this.live = false;
    this.unfollow?.();
    for (const u of this.undo) u();
    for (let i = this.recs.length - 1; i >= 0; i--) this.drop(this.recs[i]!, i);
    for (const joint of this.jointList) this.unjoint(joint);
    for (const c of this.charList) this.uncharacter(c);
    const ammo = this.ammo;
    this.unmakeDynamics();
    ammo.destroy(this.worldBody);
    ammo.destroy(this.worldMotion);
    ammo.destroy(this.worldShape);
    ammo.destroy(this.v3);
    ammo.destroy(this.v4);
    for (const shape of this.probes.values()) ammo.destroy(shape);
    ammo.destroy(this.probeObject);
    ammo.destroy(this.rayCallback);
    ammo.destroy(this.sweepCallback);
    ammo.destroy(this.from);
    ammo.destroy(this.v);
    ammo.destroy(this.v2);
    ammo.destroy(this.bq);
    ammo.destroy(this.tr);
  }
}

