/**
 * A physics material file (Docs/physics.md §4.3, D8): `src/assets/physics-materials/<key>.physmat`, JSON -- what a
 * collider is made of. Only what differs from the defaults is written; the pipeline stamps its `"uid"` first.
 *
 * ```json
 * { "uid": "uid://…", "friction": 0.05, "restitution": 0.2, "frictionCombine": "min" }
 * ```
 *
 * And how two meet (Unity's rule): each value combined by the two colliders' modes -- the one of higher priority of the
 * two, `average` < `min` < `multiply` < `max` -- so ice on anything is slippery (`min`) and a ball on anything bounces
 * (`max`). The physics stage writes the combined values into each contact Bullet makes (`bridge.ts`).
 *
 * Pure: no Ammo, no DOM. A node test, the pipeline and the page read it alike.
 */

/** How a value of two colliders is combined: by priority, the higher of the two modes wins. */
export const COMBINES = ['average', 'min', 'multiply', 'max'] as const;
export type Combine = (typeof COMBINES)[number];

/** A physics material, filled in. */
export interface PhysicsMaterialFile {
  /** Sliding friction, 0 (ice) up. */
  friction: number;
  /** Friction against rolling, 0 (a ball rolls on forever) up. */
  rollingFriction: number;
  /** Bounce: 0 dead, 1 back as high. */
  restitution: number;
  frictionCombine: Combine;
  restitutionCombine: Combine;
}

/** A file's fields with nothing written: the default material's own combine modes, `average`. */
export const PHYSICS_MATERIAL_DEFAULTS: PhysicsMaterialFile = { friction: 0.5, rollingFriction: 0, restitution: 0, frictionCombine: 'average', restitutionCombine: 'average' };

const FIELDS = ['uid', 'friction', 'rollingFriction', 'restitution', 'frictionCombine', 'restitutionCombine'] as const;

/**
 * A `.physmat` file's JSON checked and filled in: the values, or the first thing wrong with it (`friction: a number,
 * 0 or more`), never a throw -- the stage says it once and the collider takes the default.
 */
export function parsePhysicsMaterial(json: unknown): PhysicsMaterialFile | string {
  if (typeof json !== 'object' || json === null || Array.isArray(json)) return 'not an object: { "friction": 0.5, ... }';
  const o = json as Record<string, unknown>;
  for (const k of Object.keys(o)) if (!(FIELDS as readonly string[]).includes(k)) return `"${k}" is no field (${FIELDS.slice(1).join(', ')})`;
  const out = { ...PHYSICS_MATERIAL_DEFAULTS };
  for (const k of ['friction', 'rollingFriction', 'restitution'] as const) {
    const v = o[k];
    if (v === undefined) continue;
    if (typeof v !== 'number' || !Number.isFinite(v) || v < 0) return `"${k}": a number, 0 or more`;
    out[k] = v;
  }
  for (const k of ['frictionCombine', 'restitutionCombine'] as const) {
    const v = o[k];
    if (v === undefined) continue;
    if (!(COMBINES as readonly unknown[]).includes(v)) return `"${k}": one of ${COMBINES.join(', ')}`;
    out[k] = v as Combine;
  }
  return out;
}

/** A combine mode's number, its priority: what a `Float32Array` row holds. */
export const combineIndex = (c: Combine): number => COMBINES.indexOf(c);

/** `a` and `b` combined by the higher-priority of their modes (`ma`, `mb`: `combineIndex`'s numbers). Allocates nothing. */
export function combine(a: number, ma: number, b: number, mb: number): number {
  const mode = ma > mb ? ma : mb;
  if (mode === 0) return (a + b) / 2;
  if (mode === 1) return a < b ? a : b;
  if (mode === 2) return a * b;
  return a > b ? a : b;
}
