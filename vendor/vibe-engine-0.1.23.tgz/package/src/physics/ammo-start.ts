/**
 * How Ammo is started, page and node alike (Docs/physics.md D18, §5): Emscripten's `instantiateWasm`, so the
 * module is made from bytes the caller has, and with its one clock stopped. Bullet's profiler reads the wall clock
 * (`Date.now()`, an import of the glue) dozens of times a step: a number a call on the JavaScript heap, a step's
 * allocation, and the wall clock read inside the simulation. Nothing Bullet simulates reads it -- its sleep timers
 * count the steps' own time -- so the import is found by what it does, not by its minified name, and answers 0.
 *
 * **It fails, never hangs**: with `instantiateWasm` given, Emscripten leaves the instantiation to it and waits for it
 * forever -- so bytes that never come (a 404) or that are no wasm (a corrupt file) reject the promise `startWith`
 * returns, and `boot()` says so and goes on without physics.
 *
 * Pure: no DOM, no node.
 */
import type { AmmoApi } from './ammo-types.ts';

/** Ammo's init, as `ammojs-typed/wasm` exports it. */
type Init = (options?: object) => Promise<unknown>;

/** The `instantiateWasm` option: `bytes` instantiated with the clock import answering 0, `fail` told if they cannot be. */
export function startAmmo(bytes: BufferSource | Promise<BufferSource>, fail: (error: unknown) => void): (imports: WebAssembly.Imports, receive: (instance: WebAssembly.Instance) => void) => object {
  return (imports, receive) => {
    for (const functions of Object.values(imports)) {
      const record = functions as Record<string, unknown>;
      for (const [name, f] of Object.entries(record)) {
        if (typeof f === 'function' && /Date\.now\(\)/.test(String(f))) record[name] = () => 0;
      }
    }
    void Promise.resolve(bytes)
      .then((b) => WebAssembly.instantiate(b, imports))
      .then((made) => receive(made.instance), fail);
    return {};
  };
}

/**
 * Ammo initialised from `bytes` by `init`: resolved with it, or rejected -- bytes that do not come, are not wasm, or a
 * module that aborts. Called on an object of its own: the glue ends `this.Ammo = …`, and a bundled module is strict,
 * its `this` undefined (in node it would be a global).
 */
export function startWith(init: Init, bytes: BufferSource | Promise<BufferSource>): Promise<AmmoApi> {
  return new Promise<AmmoApi>((resolve, reject) => {
    const options = { instantiateWasm: startAmmo(bytes, reject), onAbort: reject };
    init.call({}, options).then((ammo) => resolve(ammo as AmmoApi), reject);
  });
}
