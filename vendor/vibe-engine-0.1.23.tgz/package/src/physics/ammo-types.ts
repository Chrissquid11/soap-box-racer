/**
 * Ammo's type, and no more (Docs/physics.md §2): the module `ammojs-typed/wasm` resolves to once initialised.
 * A type-only import, so nothing that imports this loads the glue -- the bridge takes the instance as an argument,
 * from the page's loader (`ammo.page.ts`, behind `PHYSICS_BUILD` in `boot.ts`) or node's (`ammo.node.ts`).
 */
import type Ammo from 'ammojs-typed/wasm';

/** An initialised Ammo: its classes and helpers (`new ammo.btVector3(...)`, `ammo.destroy(o)`). */
export type AmmoApi = typeof Ammo;
