/**
 * Ammo on the page (Docs/physics.md D2): the WebAssembly build's glue imported lazily, its `.wasm` by the URL Vite
 * rewrote (`?url`, never a string built from a path), fetched and handed to Emscripten's `instantiateWasm`
 * (`ammo-start.ts`, its clock stopped; a fetch that fails rejects). Imported only by `boot.ts`, behind the literal
 * `PHYSICS_BUILD`, so a build with physics off has none of it (the guard in `vibe()` fails one that does). Never
 * imported by a node test: node has `ammo.node.ts`.
 */
import wasmUrl from 'ammojs-typed/ammo.wasm.wasm?url';
import type { AmmoApi } from './ammo-types.ts';
import { startWith } from './ammo-start.ts';

/** Ammo, loaded and initialised: once a page. Rejects if it cannot be (the wasm not served, not wasm). */
export async function loadAmmo(): Promise<AmmoApi> {
  const { default: init } = await import('ammojs-typed/wasm');
  const bytes = fetch(wasmUrl).then((answer) => {
    if (!answer.ok) throw new Error(`[physics] Ammo's wasm: ${answer.status} ${answer.statusText}`);
    return answer.arrayBuffer();
  });
  return startWith(init as unknown as (options?: object) => Promise<unknown>, bytes);
}
