/**
 * Ammo in node (Docs/physics.md §2), for tests: the wasm's bytes read from the package (its `exports` map names
 * the file) and instantiated from them (`ammo-start.ts`, its clock stopped), so Emscripten fetches nothing. One
 * instance a process. Node only (`node:fs`): `@vibe/engine/physics-node` exports it; nothing the browser imports
 * may import this.
 */
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import type { AmmoApi } from './ammo-types.ts';
import { startWith } from './ammo-start.ts';

let loading: Promise<AmmoApi> | null = null;

/** Ammo, loaded and initialised, the same instance every call. */
export function loadAmmo(): Promise<AmmoApi> {
  if (loading) return loading;
  const require = createRequire(import.meta.url);
  loading = (async () => {
    const { default: init } = await import('ammojs-typed/wasm');
    return startWith(init as unknown as (options?: object) => Promise<unknown>, readFileSync(require.resolve('ammojs-typed/ammo.wasm.wasm')));
  })();
  return loading;
}
