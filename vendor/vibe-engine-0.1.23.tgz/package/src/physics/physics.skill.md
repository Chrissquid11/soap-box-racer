---
skill: engine
title: Physics
when: Before making something fall, collide, rest, roll or be pushed -- a RigidBody, a collider, a force, an impulse, a velocity -- or turning physics off
covers:
  modules: [physics/, ecs/world.ts]
order: 47
---
# Physics: bodies, colliders, forces

Physics is Bullet, through Ammo.js (WebAssembly), as a **stage of every tick**: after every system's `update`
and before every `lateUpdate`, the engine steps the simulation once (1/60 s) and writes each moving body's
`Transform`. A game says what things are -- a `RigidBody`, a collider -- and pushes them with numbers; it never
moves a simulated body by hand every tick. The code is `node_modules/@vibe/engine/src/physics/`.

It is **on by default**. The project's `physics.json` (beside `vite.config.ts`) holds the settings, and
`"enabled": false` takes Ammo out of the builds altogether (the components still load, and do nothing).

## A body and its colliders

```json
"components": ["Transform", "Render", "RigidBody", "BoxCollider"],
"data": {
  "Render": { "model": "props/crate" },
  "RigidBody": { "mass": 2, "startVelocity": [0, 4, 0] },
  "BoxCollider": { "size": [1, 1, 1] }
}
```

| Component | What it is |
|---|---|
| `RigidBody` | `type` (`dynamic` simulated, `kinematic` moved by its `Transform` and pushing what it meets, `static` never moves), `mass` (kg), `linearDamping`, `angularDamping`, `gravityScale`, `lockPosition` / `lockRotation` (axes), `canSleep`, `startAsleep`, `ccd` (swept: a fast thing never passes through a thin one), `ccdRadius` (0: from the shape), `startVelocity` / `startSpin` (an instance is made moving); runtime, written each tick: `velocity`, `angularVelocity` (rad/s), `sleeping` |
| `BoxCollider` | `size` (full extents, metres) |
| `SphereCollider` | `radius` |
| `CapsuleCollider` | `radius`, `height` (end to end), `axis` (`y`, `x`, `z`) |
| `CylinderCollider` | `radius`, `height`, `axis` |
| `ConeCollider` | `radius` (of its base), `height`, `axis` (its point up it); it rests on its base at `height / 2` |
| `HullCollider` | `mesh` (a model, or `model#part`; none: its `Render.model`), `maxPoints` (64): the convex wrap of a model -- for a model that rolls or tumbles |
| `MeshCollider` | `mesh` (as a hull's): a model's triangles as they are -- static or kinematic only |
| `HeightfieldCollider` | `heights` (a texture: its red channel), `size` (x by z metres), `heightScale` (metres at full red); static only |
| `PlaneCollider` | an infinite ground: `normal`, `offset`; static only |
| every collider | `center` and `turn` (degrees) on its entity; `material`: a physics material (none: the project's `defaultMaterial`); `trigger`: reports what enters it, pushes nothing; `layer`: its physics layer, by name in a file; `events`: which contacts are said (`enter`, `stay`, `exit`; `stay` opt-in) |
| `Forces` | `force`, `torque` (applied every tick until changed), `impulse`, `angularImpulse` (applied once, then cleared), `space` (`world` or `local`) |

- **A collider belongs to the body on its entity, or else the nearest ancestor's**: a body with colliders on
  several children is one compound shape. A collider with no body above it is a static body of its own -- a wall,
  a floor.
- **Its mass is where its colliders are**: shared among them by volume, so a body whose collider sits to one side
  balances on it, and spins about its centre of mass, not about its entity's origin. A hull's mass is centred on its model's
  middle and a cone's a quarter up from its base. Such a shape off its body's origin is a one-child compound
  inside, a small cost: export a model that rolls with its origin at its middle to keep it a plain shape.
- **Scale counts** (non-uniform too): a box, a hull, a mesh and a height field scale exactly per axis; a sphere takes
  its largest axis; a capsule, cylinder or cone its two scales across it for the radius and the one along it for
  the length.
- **What does not move only**: a `MeshCollider` (or kinematic), a `PlaneCollider`, a `HeightfieldCollider`. A
  prefab giving one to a dynamic body does not compile, and says to use a `HullCollider` or several primitives.
- Joints hold bodies together, and a character controller walks: both below.

## Physics materials: friction and bounce

`src/assets/physics-materials/ice.physmat` is the key `ice`: JSON, only what differs from the defaults (the
pipeline adds its uid).

```json
{ "friction": 0.02, "frictionCombine": "min" }
```

- `friction` (0.5), `rollingFriction` (0), `restitution` (bounce, 0), and how two colliders' values combine:
  `frictionCombine` and `restitutionCombine`, each `average` (the default), `min`, `multiply` or `max`. Of two
  colliders' modes the higher wins (`average` < `min` < `multiply` < `max`): ice (`min`) is slippery on anything, a
  ball with `max` bounces off a dead floor.
- A collider names one in `material` (`"BoxCollider": { "material": "ice" }`); with none, `physics.json`'s
  `defaultMaterial`. A file saved in the dev server applies at once.

## Moving bodies: write numbers

```ts
// src/game/systems/kick.ts
import { Forces, RigidBody, type World } from '@vibe/engine';

/** kick, 60 Hz: Space pushes every body with a Forces up, once. */
export function kick(world: World): void {
  world.system({
    name: 'kick',
    rate: 60,
    write: [Forces],
    with: [RigidBody],
    update({ members, count, input }, _read, [forces]) {
      if (!input.pressed('Space')) return;
      for (let n = 0; n < count; n++) {
        const e = members[n];
        forces.impulseY[e] = 5;
      }
    },
  });
}
```

- **A push**: `Forces.impulse` (once) or `Forces.force` (every tick until set back to 0), so a slow system can
  decide a push and leave it on. `impulseAt(forces, worldTransforms, e, ix, iy, iz, px, py, pz)` pushes at a point
  and turns it too.
- **A velocity**: write `RigidBody.velocity` / `angularVelocity`. Anything the stage did not write itself is taken
  as set.
- **A teleport**: write a dynamic body's `Transform` -- it is put there, its velocity kept.
- **A kinematic body** (a lift, a door, a moving platform) is moved by a 60 Hz system writing its `Transform`, as
  any 60 Hz mover; the bodies on it are carried.
- **React in `lateUpdate`**: it sees this tick's simulated poses; `update` sees the last tick's.
- `Disabled`, or `RigidBody` switched off (`cmd.enable(e, RigidBody, false)`), takes the body out of the
  simulation -- with `RigidBody` off, its colliders stay as a static obstacle. A pooled instance's body waits in
  the pool with it.

```ts
// src/game/systems/terminal.ts
import { RigidBody, type World } from '@vibe/engine';

/** terminal, 60 Hz: nothing falls faster than 20 m/s -- read and written after this tick's step. */
export function terminal(world: World): void {
  world.system({
    name: 'terminal',
    rate: 60,
    write: [RigidBody],
    lateUpdate({ members, count }, _read, [rb]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        if (rb.velocityY[e] < -20) rb.velocityY[e] = -20;
      }
    },
  });
}
```

## Collisions and triggers: events, the tick after

```ts
// src/game/systems/zone.ts
import { Render, TriggerEnter, TriggerExit, type World } from '@vibe/engine';

/** zone, 60 Hz: what comes into a trigger is tinted green, what leaves it white again. */
export function zone(world: World): void {
  const came = world.events(TriggerEnter);
  const went = world.events(TriggerExit);
  world.system({
    name: 'zone',
    rate: 60,
    write: [Render],
    update(ctx, _read, [render]) {
      for (let i = came.begin(ctx); i < came.end; i++) {
        const e = ctx.deref(came.other[i]);
        if (e) render.tint[e] = 0x55ff66;
      }
      for (let i = went.begin(ctx); i < went.end; i++) {
        const e = ctx.deref(went.other[i]);
        if (e) render.tint[e] = 0xffffff;
      }
    },
  });
}
```

- `CollisionEnter` / `CollisionStay` `{ a, b, point, normal, impulse, speed }` and `CollisionExit { a, b }`: `a` the
  lower entity, `b` the higher (each a body's entity, or a static collider's own), `normal` from `b` to `a`. `Stay`
  only where a collider asks (`events: ["enter", "stay", "exit"]`): it is said every tick.
- `TriggerEnter` / `TriggerStay` / `TriggerExit { trigger, other }`. A trigger is its entity's colliders together:
  put a solid shape and a trigger on two entities. A trigger on (or under) a body moves with it and is never said
  to touch that body.
- Read the tick after, by every reader, once -- the same as every event. An `Exit` names who it was even if that
  entity is gone: check `deref`.

## Layers

`physics.json` names up to 15 layers and the pairs that pass through each other:

```json
{ "layers": ["Default", "Props", "Ghosts", "Triggers"], "ignore": [["Ghosts", "Props"]] }
```

A collider's `layer` (`"SphereCollider": { "layer": "Ghosts" }` in a file) puts its body on it. The pairs are
symmetric, and an edit applies live. A body's layer is its first collider's. A layer is kept by its index: renaming one is free, but
reordering or removing layers moves every collider written by number (a save, a mask a system took) -- do it in
the editor's Config, which rewrites files by name, and swap the game so masks are taken again.

## Queries

```ts
// src/game/systems/ground.ts
import { physicsOf, RayHit, WorldTransform, type World } from '@vibe/engine';
import { Wander } from '../components.ts';

const hit = new RayHit();

/** ground, 10 Hz: how far below each wanderer the ground is, by a ray down. */
export function ground(world: World): void {
  const physics = physicsOf(world);
  const solid = physics.layers('Default');
  world.system({
    name: 'ground',
    rate: 10,
    read: [WorldTransform],
    with: [Wander],
    update({ members, count }, [at]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        if (physics.raycast(at.px[e], at.py[e] + 0.1, at.pz[e], 0, -1, 0, 50, solid, hit)) {
          // hit.entity, hit.x/y/z, hit.normalX/Y/Z, hit.distance
        }
      }
    },
  });
}
```

- `raycast(origin…, direction…, max, mask, hit, triggers?)` the nearest; `raycastAll(…, hits: RayHits)` every body
  along it, nearest first; `sweep(probe, from…, to…, mask, hit)` a shape pushed until it touches; `overlap(probe, at…,
  mask, out)` what a shape there touches. `probe` is `sphereProbe(r)`, `boxProbe(hx, hy, hz)` or `capsuleProbe(r, h)`,
  made at module level; `RayHit`, `RayHits` and `out` too: nothing is allocated per query.
- `physics.layers('Default', 'Props')` is a mask (no names: every layer), checked against `physics.json`.
- Triggers are skipped unless the last argument says `true`.
- A query sees the world as of the last step: last tick's in `update`, this tick's in `lateUpdate`. Never from a
  `parallel` system (it throws).

## Joints

A joint is a component on the body that has it (on its entity, or a child of it: the nearest body above), its
`other` a typed ref to the body it joins to -- none: the world, where it is. A door on a hinge:

```json
"components": ["Transform", "Render", "RigidBody", "BoxCollider", "HingeJoint"],
"data": {
  "BoxCollider": { "size": [1.2, 2, 0.1] },
  "HingeJoint": { "anchor": [-0.6, 0, 0], "axis": [0, 1, 0], "limit": true, "lower": -100, "upper": 100 }
}
```

| Component | What it holds |
|---|---|
| `FixedJoint` | the two as one |
| `HingeJoint` | a turn about `axis` only; `limit` with `lower`/`upper` degrees; `motor` with `motorSpeed` (°/s) and `motorForce` (N·m) |
| `SliderJoint` | a slide along `axis` only, `lower` to `upper` metres from where it was made; `motor` with `motorSpeed` (m/s), `motorForce` (N) |
| `BallJoint` | the anchors together, every turn free: a chain's link, a rope of them |
| `ConeTwistJoint` | a swing within a cone about `axis` (`swing1`, `swing2` degrees) and a `twist` about it |
| `SixDofJoint` | each axis its own: `linearLower`/`linearUpper` and `angularLower`/`angularUpper` (lower above upper: free), `spring` (which axes, by name: `x` … `turnZ`) with `stiffness`, `damping`, `angularStiffness`, `angularDamping` |
| every joint | `other` (a ref; none: the world), `anchor` and `axis` in the entity's own space (the anchor scaled with it; the axis only turned, never skewed by a non-uniform scale); `autoAnchor` (on: the other's from where the two are when it is made; off: `otherAnchor`, `otherAxis`); `collide` (the two still touch); `breakForce` / `breakTorque` (0: never) |

- **A joint that breaks** stops holding, its `broken` set (runtime, saved: it stays broken across a load) and
  `JointBroke { joint, body, other }` said, read the tick after. Each limit holds alone: `breakForce` against the
  force it carries, `breakTorque` against the torque about its anchor (a ball joint carries none).
  Clear `broken` (or take the joint off and add it again) to join them anew, from where they are then.
- **Several joints on one body** are child entities, one joint each (one component of a kind an entity).
- A joint is made again when either body is, or its numbers change; it goes when either body dies, its component
  is switched off (`cmd.enable(e, HingeJoint, false)`) or its entity is `Disabled`, and comes back with them.
- A motor keeps its bodies awake; nothing else a joint does wakes a sleeping body.
- **The other body away** (`Disabled`, its `RigidBody` switched off): the joint waits, and joins the two again from
  where they are when it is back. One given back to its pool is gone for good (the ref goes to none).

```ts
// src/game/systems/creak.ts
import { JointBroke, type World } from '@vibe/engine';

/** creak, 60 Hz: says where a joint gave way. */
export function creak(world: World): void {
  const broke = world.events(JointBroke);
  world.system({
    name: 'creak',
    rate: 60,
    update(ctx) {
      for (let i = broke.begin(ctx); i < broke.end; i++) {
        const joint = ctx.deref(broke.joint[i]);
        if (joint) console.info('[creak] gave way', joint);
      }
    },
  });
}
```

## A character

`CharacterController` is a walker the engine moves -- never simulated -- by what a system asks: a capsule `radius`
wide and `height` tall, **its entity's origin at its feet**, on a root entity (no parent, no body: a prefab with
either does not compile).

```ts
// src/game/systems/stroll.ts
import { CharacterController, type World } from '@vibe/engine';

/** stroll, 60 Hz: every character walks in a slow circle, and hops every few seconds when on the ground. */
export function stroll(world: World): void {
  world.system({
    name: 'stroll',
    rate: 60,
    write: [CharacterController],
    update({ members, count, time, tick }, _read, [walker]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        walker.moveX[e] = Math.cos(time * 0.5) * 2;
        walker.moveZ[e] = Math.sin(time * 0.5) * 2;
        if (tick % 240 === 0 && walker.grounded[e]) walker.jump[e] = 5;
      }
    },
  });
}
```

- **In**: `move` (metres a second it wants to go; `moveY` too, for a ladder or a swimmer), `jump` (an upward speed,
  taken only when grounded, then cleared). **Out, each tick, saved**: `grounded`, `groundNormal`, `fall` (its
  vertical speed).
- It slides along what it meets (four slides a tick at most), walks up and down steps to `stepHeight`, stands on
  slopes up to `slopeLimit` degrees and slides down steeper ones, keeps `skin` metres from what it touches, falls
  with `gravityScale` of the project's gravity, rides what it stands on (a kinematic platform, a moving body: carried
  along, not turned), and pushes a dynamic body it walks into with `pushForce` newtons. `layer` is its physics layer.
- `CharacterLanded { who, ground }` once as it comes onto the ground; `CharacterHit { who, other, point, normal }`
  every tick it walks into something.
- It moves before the step, against the world as last tick left it, so a body's step this tick sees it where it is
  now. Its `Transform` written is a teleport.
- A `CharacterController` beside a `RigidBody` does not compile: a character is a body of its own.

## A scene to copy from

The engine's own sandbox has a physics scene (`scenes/physics.scene`) built from prefabs under
`prefabs/physics/` and five small systems -- each the pattern for its job:

| What | How |
|---|---|
| A floor; an ice patch | a `BoxCollider` with no body (static), on the `Floor` layer (set in the scene); the ice's `material` an `ice.physmat` (`friction` 0.02, `min`) |
| Crates that fall and tumble | `RigidBody` + `BoxCollider` (`center` half a crate up: the model's origin is its base) |
| Ghost crates | the same crate, its collider's `layer` `Ghost`, and `physics.json`'s `ignore: [["Default", "Ghost"]]`: through the crates, onto the floor |
| A bouncy ball, a barrel, a pill, a cone, a rock | `SphereCollider` with a `bouncy.physmat` (`restitution` 0.85, `max`), `CylinderCollider`, `CapsuleCollider`, `ConeCollider`, a `HullCollider` of the parrot model |
| A ramp | a `MeshCollider` of the ramp model: static |
| A hinged door; a chain | `HingeJoint` (`limit`, `motor`) to a static post; six `BallJoint` links, each `other` the one above |
| A lift | a kinematic body moved by its `Transform` (below): what stands on it rides |
| A trigger zone | `BoxCollider { trigger: true }` and a system reading `TriggerEnter`/`TriggerExit` that tints what is inside |
| A cannon | F fires a pooled shot (`"pool"` in its file) with `startVelocity` and `ccd`; Shift+F without `ccd`, which passes through a thin wall |
| A walker | `CharacterController` on a root entity, its model a child; WASD into `move`, Space into `jump` -- game input (`input.down`, `input.pressed`), never a debug key |

```ts
// src/game/systems/lift.ts
import { Transform, type World } from '@vibe/engine';
import { Lift } from '../components.ts';

/** lift, 60 Hz: a kinematic platform goes up and down -- by its Transform, which the stage drives it to. */
export function lift(world: World): void {
  world.system({
    name: 'lift',
    rate: 60,
    read: [Lift],
    write: [Transform],
    update({ members, count, time }, [up], [at]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        at.py[e] = up.y[e] + Math.sin(time * up.speed[e]) * up.height[e];
      }
    },
  });
}
```


## The physics itself

`physicsOf(world)`, taken where a system is registered (as `world.events` is), never at module level: `ready`
(false where physics is off or Ammo did not load), `stats()` (bodies, awake, contacts, step time), `sync()` (a tool's:
bodies brought up to the components with no step, outside a tick).

```ts
// src/game/systems/watch.ts
import { physicsOf, type World } from '@vibe/engine';

export function watch(world: World): void {
  const physics = physicsOf(world);
  if (!physics.ready) console.info('[watch] no physics in this build');
}
```

## The rules that bite

- **Never move a dynamic body by its `Transform` every tick**: that is a teleport every tick, and it stops
  colliding properly. Push it (`Forces`) or set its `velocity`.
- **`physics.json`** at the project's root: `enabled`, `gravity` ([x, y, z] m/s²), `substeps` (1-8 steps a tick),
  `iterations` (the solver's, 1-50), `sleep` (`linear`, `angular` thresholds), `defaultMaterial` (`friction`,
  `restitution`), `layers` and `ignore` (the layer names, and the pairs that pass through each other). An edit
  applies live in the dev server; `enabled` changed restarts it. A bad field fails `vibe dev` and `vibe build`,
  naming it. The studio's Config ▸ Game ▸ Physics writes it, with the matrix as checkboxes
  ([the studio's physics page](../studio/physics.md)).
- **Colliders drawn**: the studio's top bar draws them (none, the selection's, every one) from the components, and
  a collider's Fit to model sizes it from its model.
- **Determinism**: the same seed and input give the same simulation, bit for bit, and a save loaded plays the
  same every time it is loaded -- but not bit-equal to the run that went on without saving (Bullet's contact
  caches are not in a save).
- **Never `parallel`**: the stage runs on the main thread; a parallel system may read `RigidBody` and write
  `Forces`' numbers.
- **Tests**: `loadAmmo()` from `@vibe/engine/physics-node`, then `installPhysics(world, { ammo })` on a test's own world
  and `world.loop.runTick()`.
