/**
 * Physics as data (Docs/physics.md §4): `RigidBody`, the colliders a shape each, and `Forces` -- numeric
 * components the engine defines and its physics stage (`physics/bridge.ts`, on Ammo) simulates. In a prefab's
 * `components` and `data` like any other, saved, overridden, shown in the inspector. Defined whether or not the
 * project has physics on (D4): content made with it loads without it, inert.
 *
 * F1's set: the body, the box, the sphere, the plane, the forces. The rest of the shapes, physics materials,
 * layers, triggers, events and joints come with their phases (Docs/physics.md §9).
 *
 * Pure: no DOM, no three, no Ammo. A node test imports it, and so does the worker.
 */
import { checkPrefabNodes } from '../ecs/prefab.ts';
import { bool, component, enumOf, event, f32, flagsOf, key, mesh, ref, u16, vec2, vec3, type Field, type FieldOptions } from '../ecs/component.ts';
import { physicsSettings } from './settings.ts';

/**
 * A physics layer (D9): a `u8`, 0 to 14, whose names are the project's -- `physics.json`'s `"layers"` -- read as they are
 * now, so a file writes and reads it by name and the inspector offers the names, as an enum's, and an edit of the
 * names is there at once. 15, not 32: this Ammo's collision filters are shorts, and their last bit is the queries'.
 */
export function physicsLayer(initial = 0, options?: FieldOptions): Field & { readonly enum: readonly string[] } {
  const made = { ...(options ?? {}), type: 'u8' as const, initial, min: 0, max: 14 };
  Object.defineProperty(made, 'enum', { get: () => physicsSettings().layers, enumerable: true });
  return made as Field & { readonly enum: readonly string[] };
}

/** Which of a collider's contacts are said: entering, every tick while touching (`stay`: opt-in, it floods), leaving. */
export const ContactEvents = flagsOf(['enter', 'stay', 'exit'], ['enter', 'exit']);

/** How a body moves: `dynamic` simulated, `kinematic` moved by its `Transform` and pushing what it meets, `static` never. */
export const BodyType = enumOf(['dynamic', 'kinematic', 'static'], 'dynamic');

/** Axes, as flags: a body's locks. */
export const LockAxes = flagsOf(['x', 'y', 'z']);

/**
 * A rigid body: simulated by the physics stage once a tick, its shape the colliders on it and on its descendants
 * that have no body of their own (a compound; none: a point mass that touches nothing). `velocity`,
 * `angularVelocity` (radians a second, world space) and `sleeping` are written by the stage after each step,
 * saved, never authored: a system that writes one has set it -- a set velocity, a body woken (D6). A `Transform`
 * written by anyone but the stage is a teleport (dynamic: the velocity kept) or the pose a kinematic body is
 * driven to. `startVelocity` and `startSpin` (degrees a second) are what a prefab's instance is made moving with.
 */
export const RigidBody = component('RigidBody', {
  type: BodyType.as('dynamic', { help: 'dynamic: simulated; kinematic: moved by its Transform; static: never moves' }),
  mass: f32(1, { min: 0.001, help: 'Kilograms (dynamic only)' }),
  linearDamping: f32(0.05, { min: 0, max: 1, slider: true, help: 'How fast it slows down moving, a share a second' }),
  angularDamping: f32(0.05, { min: 0, max: 1, slider: true, help: 'How fast it slows down turning, a share a second' }),
  gravityScale: f32(1, { help: '0 floats; 2 falls twice as hard' }),
  lockPosition: LockAxes.as([], { help: 'Axes it may not move along' }),
  lockRotation: LockAxes.as([], { help: 'Axes it may not turn about' }),
  canSleep: bool(true, { help: 'Rests when still, costing nothing until touched' }),
  startAsleep: bool(false, { help: 'Begins at rest until something touches it' }),
  ccd: bool(false, { label: 'Swept (CCD)', help: 'Never passes through thin things when fast, at a cost' }),
  ccdRadius: f32(0, { min: 0, group: 'Swept', help: 'The swept sphere\'s radius, metres; 0: from the shape' }),
  startVelocity: vec3(0, { group: 'Start', help: 'Metres a second, world space, an instance is made moving with' }),
  startSpin: vec3(0, { group: 'Start', help: 'Degrees a second about each world axis, an instance is made turning with' }),
  velocity: vec3(0),
  angularVelocity: vec3(0),
  sleeping: bool(false),
}, { menu: 'Physics', help: 'A body the physics simulates, its shape the colliders on it', runtime: ['velocity', 'angularVelocity', 'sleeping'] });

/**
 * What every collider has: where it sits on its entity (`turn` in degrees about x, y, z, as three's 'XYZ' Euler), and
 * what it is made of -- a physics material's key (`src/assets/physics-materials/<key>.physmat`: friction, bounce and
 * how each combines), or none: the project's default (`physics.json`'s `defaultMaterial`).
 */
const COLLIDER = {
  center: vec3(0, { help: 'Offset from the entity, in its space, metres' }),
  turn: vec3(0, { help: 'Degrees about x, y and z, in its space' }),
  material: key('PhysicsMaterial', { help: 'Its friction and bounce: a physics material (none: the project default)' }),
  trigger: bool(false, { help: 'Reports what enters it; pushes nothing. Its entity\'s colliders are one trigger together' }),
  layer: physicsLayer(0, { help: 'Its physics layer: what it collides with is the project\'s matrix (physics.json)' }),
  events: ContactEvents.as(['enter', 'exit'], { help: 'Which of its contacts are said as events: stay floods, so it is opt-in' }),
};

/** The axis a capsule, cylinder or cone runs along, in its entity's space. */
export const ShapeAxis = enumOf(['y', 'x', 'z'], 'y');

/** A box: `size` its full extents, metres, scaled by the entity's world scale per axis. */
export const BoxCollider = component('BoxCollider', {
  size: vec3(1, { min: 0.001, help: 'Its full width, height and depth, metres' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'A box' });

/** A sphere: `radius` metres, scaled by the largest of the entity's world scale's axes. */
export const SphereCollider = component('SphereCollider', {
  radius: f32(0.5, { min: 0.001, help: 'Metres' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'A sphere' });

/**
 * An infinite plane, static only: everything on its `normal`'s side (in the entity's space, turned by it) of
 * `offset` metres along it is outside. The ground of a level that has no edge.
 */
export const PlaneCollider = component('PlaneCollider', {
  normal: vec3([0, 1, 0], { help: 'The way out of it, in the entity\'s space' }),
  offset: f32(0, { help: 'Metres along the normal from the entity' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'An infinite plane, static only' });

/**
 * A capsule: a cylinder with a half sphere at each end, `height` end to end (at least `2 × radius`), along `axis`. The
 * radius scaled by the larger of the two scale axes across it, the height by the one along it (D11).
 */
export const CapsuleCollider = component('CapsuleCollider', {
  radius: f32(0.5, { min: 0.001, help: 'Metres' }),
  height: f32(2, { min: 0.001, help: 'End to end, metres: at least twice the radius' }),
  axis: ShapeAxis.as('y', { help: 'The axis it runs along' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'A capsule' });

/** A cylinder, `height` long along `axis`, its centre at the entity's: scaled as a capsule (D11). */
export const CylinderCollider = component('CylinderCollider', {
  radius: f32(0.5, { min: 0.001, help: 'Metres' }),
  height: f32(1, { min: 0.001, help: 'Metres' }),
  axis: ShapeAxis.as('y', { help: 'The axis it runs along' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'A cylinder' });

/** A cone, its point up `axis`, its centre half way up (so it rests on its base at `height / 2`): scaled as a capsule. */
export const ConeCollider = component('ConeCollider', {
  radius: f32(0.5, { min: 0.001, help: 'Of its base, metres' }),
  height: f32(1, { min: 0.001, help: 'Base to point, metres' }),
  axis: ShapeAxis.as('y', { help: 'The axis its point is up' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'A cone' });

/**
 * The convex hull of a model, or of one part of it (`mesh`, `'props/crate'` or `'props/robot#arm'`; none: the entity's
 * `Render.model`): any body type, the way a model that rolls or tumbles collides. Simplified to at most `maxPoints`
 * points; scaled exactly, per axis.
 */
export const HullCollider = component('HullCollider', {
  mesh: mesh({ help: 'The model, or one part of it, wrapped (none: the one its Render draws)' }),
  maxPoints: u16(64, { min: 4, max: 255, help: 'The most points the hull keeps' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'The convex hull of a model or a part of it' });

/**
 * A model's (or a part's) triangles as they are: concave, exact, for what does not move -- static or kinematic only
 * (a dynamic body takes a `HullCollider`, or several primitives). Scaled exactly; one BVH a model shared by every one.
 */
export const MeshCollider = component('MeshCollider', {
  mesh: mesh({ help: 'The model, or one part of it (none: the one its Render draws)' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'A model\'s triangles, static or kinematic only' });

/**
 * Ground from a height map, static only: `heights` a texture whose red channel is the height (0 to 1), its pixels spread
 * over `size` metres (x by z) centred on the entity, `heightScale` metres at full red.
 */
export const HeightfieldCollider = component('HeightfieldCollider', {
  heights: key('Texture', { help: 'A height map: its red channel, 0 to 1' }),
  size: vec2([10, 10], { min: 0.001, help: 'Metres across, x by z' }),
  heightScale: f32(1, { min: 0, help: 'Metres at full red' }),
  ...COLLIDER,
}, { menu: 'Physics/Colliders', help: 'Ground from a height map, static only' });

/** Every collider component: `any: COLLIDERS` for a system that wants whatever has a shape. */
export const COLLIDERS = [BoxCollider, SphereCollider, PlaneCollider, CapsuleCollider, CylinderCollider, ConeCollider, HullCollider, MeshCollider, HeightfieldCollider] as const;

/** The colliders only a body that does not move may have: refused on a dynamic one (D7, §4.2). */
export const STILL_ONLY = [PlaneCollider, MeshCollider, HeightfieldCollider] as const;

// A prefab file saying both a dynamic body and a shape only a still one may have is a compile error, said where the file is.
// A collider belongs to the body on its entity, else the nearest ancestor's (D7): walked up the file to the one that has it.
checkPrefabNodes((node) => {
  const still = STILL_ONLY.find((c) => node.components.includes(c));
  if (!still) return null;
  let owner: typeof node | null = node;
  while (owner !== null && !owner.components.includes(RigidBody)) owner = owner.parent();
  if (owner === null) return null;
  const type = owner.value(RigidBody, 'type') ?? RigidBody.schema.type.initial;
  if (type !== BodyType.dynamic) return null;
  const whose = owner === node ? 'on a dynamic body' : 'under a dynamic body (its collider, a part of it)';
  return `${still.name} ${whose}: a ${still.name.replace('Collider', '').toLowerCase()} is for what does not move -- use a HullCollider, or several primitives as a compound, or make the RigidBody static or kinematic`;
});

/** Which way a `Forces`' vectors point: world axes, or the body's own. */
export const ForceSpace = enumOf(['world', 'local'], 'world');

/**
 * Pushes on a dynamic body (D13). `force` (newtons) and `torque` (newton metres) are applied every step until
 * changed -- a slow system can decide a push -- and a prefab may author them (a constant push).
 * `impulse` (newton seconds) and `angularImpulse` are applied once, at the next step, and cleared by the stage.
 * Writing any of them wakes a sleeping body. `impulseAt` adds an impulse at a point.
 */
export const Forces = component('Forces', {
  force: vec3(0, { help: 'Newtons, every step until changed' }),
  torque: vec3(0, { help: 'Newton metres, every step until changed' }),
  impulse: vec3(0),
  angularImpulse: vec3(0),
  space: ForceSpace.as('world', { help: 'world: along the world\'s axes; local: along the body\'s own' }),
}, { menu: 'Physics', help: 'Pushes on a dynamic body: forces, torques, impulses', runtime: ['impulse', 'angularImpulse'] });

/**
 * Two bodies touching, said the tick after it began (`Enter`), each tick it goes on where either collider asks for
 * `stay` (`Stay`), and the tick after it ended (`Exit`). `a` is the lower entity, `b` the higher -- each a body's
 * entity, or a static collider's own; `point` where they touch most (world), `normal` from `b` to `a`, `impulse` the
 * solver's push along it (newton seconds, this step), `speed` how fast they closed along it (m/s). Read the tick after,
 * by every reader, once (Docs/ecs.md §18).
 */
export const CollisionEnter = event('CollisionEnter', { a: ref(), b: ref(), point: vec3(), normal: vec3(), impulse: f32(), speed: f32() });
export const CollisionStay = event('CollisionStay', { a: ref(), b: ref(), point: vec3(), normal: vec3(), impulse: f32(), speed: f32() });
export const CollisionExit = event('CollisionExit', { a: ref(), b: ref() });

/** Something in a trigger: `trigger` the trigger's entity, `other` the body's (or the static collider's) that came in, stays or went. */
export const TriggerEnter = event('TriggerEnter', { trigger: ref(), other: ref() });
export const TriggerStay = event('TriggerStay', { trigger: ref(), other: ref() });
export const TriggerExit = event('TriggerExit', { trigger: ref(), other: ref() });

// ── joints (D16) ─────────────────────────────────────────────────────────────

/**
 * What every joint has. It joins the body its entity is (its own `RigidBody`, else the nearest ancestor's) to `other`'s
 * (none: the world, where it is). `anchor` is where, and `axis` which way (hinge, slider, cone twist), both in the
 * entity's space; `otherAnchor` and `otherAxis` the same in `other`'s, or -- `autoAnchor` -- worked out from where the
 * two are when the joint is made. `collide`: the two bodies still collide. `breakForce` / `breakTorque` (0: never): it
 * breaks past either -- the force it carries, the torque about its anchor, each against its own -- is marked `broken`
 * (saved) and says `JointBroke`.
 */
const JOINT = {
  other: ref(RigidBody, { help: 'The body it joins to (none: the world, where it is)' }),
  anchor: vec3(0, { help: 'Where, in this entity\'s space, metres' }),
  axis: vec3([1, 0, 0], { help: 'Its axis, in this entity\'s space (a hinge turns about it, a slider slides along it)' }),
  autoAnchor: bool(true, { help: 'The other\'s anchor and axis from where the two are when it is made' }),
  otherAnchor: vec3(0, { help: 'Where, in the other\'s space (autoAnchor off)' }),
  otherAxis: vec3([1, 0, 0], { help: 'Its axis in the other\'s space (autoAnchor off)' }),
  collide: bool(false, { help: 'The two bodies collide with each other' }),
  breakForce: f32(0, { min: 0, help: 'Newtons pulling or pushing at it that break it (0: never)' }),
  breakTorque: f32(0, { min: 0, help: 'Newton metres twisting it about its anchor that break it (0: never)' }),
  broken: bool(false),
};

/** Two bodies held as one. */
export const FixedJoint = component('FixedJoint', { ...JOINT }, { menu: 'Physics/Joints', help: 'Two bodies held as one', runtime: ['broken'] });

/** A door's: turning about `axis` only -- between `lower` and `upper` degrees where `limit`; driven at `motorSpeed` by up to `motorForce` where `motor`. */
export const HingeJoint = component('HingeJoint', {
  ...JOINT,
  limit: bool(false, { group: 'Limit' }),
  lower: f32(-90, { group: 'Limit', help: 'Degrees' }),
  upper: f32(90, { group: 'Limit', help: 'Degrees' }),
  motor: bool(false, { group: 'Motor' }),
  motorSpeed: f32(90, { group: 'Motor', help: 'Degrees a second' }),
  motorForce: f32(10, { group: 'Motor', min: 0, help: 'Newton metres at most' }),
}, { menu: 'Physics/Joints', help: 'Turning about one axis: a door', runtime: ['broken'] });

/** A drawer's: sliding along `axis` only, `lower` to `upper` metres from where it was made; a motor drives it at `motorSpeed`. */
export const SliderJoint = component('SliderJoint', {
  ...JOINT,
  lower: f32(-1, { group: 'Limit', help: 'Metres' }),
  upper: f32(1, { group: 'Limit', help: 'Metres' }),
  motor: bool(false, { group: 'Motor' }),
  motorSpeed: f32(1, { group: 'Motor', help: 'Metres a second' }),
  motorForce: f32(10, { group: 'Motor', min: 0, help: 'Newtons at most' }),
}, { menu: 'Physics/Joints', help: 'Sliding along one axis: a drawer', runtime: ['broken'] });

/** A chain link's: the anchors held together, every turn free. */
export const BallJoint = component('BallJoint', { ...JOINT }, { menu: 'Physics/Joints', help: 'Every turn free: a chain link', runtime: ['broken'] });

/** A shoulder's: swinging within a cone about `axis` (`swing1`, `swing2` degrees) and twisting about it by `twist`. */
export const ConeTwistJoint = component('ConeTwistJoint', {
  ...JOINT,
  swing1: f32(45, { min: 0, max: 180, help: 'Degrees' }),
  swing2: f32(45, { min: 0, max: 180, help: 'Degrees' }),
  twist: f32(30, { min: 0, max: 180, help: 'Degrees' }),
}, { menu: 'Physics/Joints', help: 'Swinging in a cone and twisting: a shoulder', runtime: ['broken'] });

/** Which of a six-way joint's axes are springs: x, y, z along, then about. */
export const SpringAxes = flagsOf(['x', 'y', 'z', 'turnX', 'turnY', 'turnZ']);

/**
 * Every axis its own (Bullet's generic six-way spring joint): along x, y, z between `linearLower` and `linearUpper`
 * metres, about them between `angularLower` and `angularUpper` degrees (lower above upper: free; equal: locked), and the
 * axes in `spring` springs back to where it was made, `stiffness` and `damping` along, `angularStiffness` and
 * `angularDamping` about.
 */
export const SixDofJoint = component('SixDofJoint', {
  ...JOINT,
  linearLower: vec3(0, { group: 'Limits', help: 'Metres' }),
  linearUpper: vec3(0, { group: 'Limits', help: 'Metres' }),
  angularLower: vec3(0, { group: 'Limits', help: 'Degrees' }),
  angularUpper: vec3(0, { group: 'Limits', help: 'Degrees' }),
  spring: SpringAxes.as([], { group: 'Springs' }),
  stiffness: vec3(100, { group: 'Springs', min: 0, help: 'Newtons a metre' }),
  damping: vec3(0.5, { group: 'Springs', min: 0, max: 1, help: 'Bullet\'s, 0 to 1' }),
  angularStiffness: vec3(10, { group: 'Springs', min: 0, help: 'Newton metres a radian' }),
  angularDamping: vec3(0.5, { group: 'Springs', min: 0, max: 1 }),
}, { menu: 'Physics/Joints', help: 'Every axis its own, limits and springs', runtime: ['broken'] });

/** Every joint component: `any: JOINTS`. */
export const JOINTS = [FixedJoint, HingeJoint, SliderJoint, BallJoint, ConeTwistJoint, SixDofJoint] as const;

/** A joint broke under more than it takes: `joint` its entity, `body` and `other` what it held (other none: the world). Once. */
export const JointBroke = event('JointBroke', { joint: ref(), body: ref(), other: ref() });

// ── the character (D17) ──────────────────────────────────────────────────────

/**
 * A walker: a capsule `height` tall (its entity's origin at its feet), moved by the stage -- never simulated -- by what a
 * system asks (`move`, metres a second; `jump`, an upward speed taken if grounded, then cleared): it slides along walls,
 * steps up and down to `stepHeight`, stands on slopes up to `slopeLimit` degrees and slides off steeper ones, falls with
 * `gravityScale` of the project's gravity, rides what it stands on, and pushes dynamic bodies it walks into with
 * `pushForce` newtons. `grounded`, `groundNormal` and `fall` (vertical speed) are written each tick and saved. Not
 * beside a `RigidBody`.
 */
export const CharacterController = component('CharacterController', {
  radius: f32(0.4, { min: 0.01, help: 'Metres' }),
  height: f32(1.8, { min: 0.02, help: 'Feet to head, metres' }),
  stepHeight: f32(0.3, { min: 0, help: 'The highest step it walks up, metres' }),
  slopeLimit: f32(45, { min: 0, max: 89, slider: true, help: 'The steepest slope it stands on, degrees' }),
  skin: f32(0.02, { min: 0.001, help: 'The gap it keeps from what it touches, metres' }),
  gravityScale: f32(1),
  pushForce: f32(20, { min: 0, help: 'Newtons it pushes a dynamic body with' }),
  layer: physicsLayer(0),
  move: vec3(0, { help: 'Metres a second it wants to go; a system writes it' }),
  jump: f32(0, { help: 'Upward speed to take this tick if grounded; cleared' }),
  grounded: bool(false),
  groundNormal: vec3([0, 1, 0]),
  fall: f32(0),
}, { menu: 'Physics/Character', help: 'A walker moved by the physics stage, never simulated', runtime: ['move', 'jump', 'grounded', 'groundNormal', 'fall'] });

/** A character came onto the ground (`ground`: what it stands on). */
export const CharacterLanded = event('CharacterLanded', { who: ref(), ground: ref() });
/** A character walked into something not its ground: `other` it, `point` where, `normal` out of it. Each tick it does. */
export const CharacterHit = event('CharacterHit', { who: ref(), other: ref(), point: vec3(), normal: vec3() });

// A character and a body on one entity: refused in a file (the stage would have the controller win, warned).
// A character under a parent: refused too (its Transform is written as a world pose; at run time, warned once).
checkPrefabNodes((node) => {
  if (!node.components.includes(CharacterController)) return null;
  if (node.components.includes(RigidBody)) return 'a CharacterController beside a RigidBody: a character is a body of its own -- take one off';
  if (node.parent() !== null) return 'a CharacterController under a parent: a character is a root entity -- make it the prefab\'s root, or a prefab of its own';
  return null;
});
