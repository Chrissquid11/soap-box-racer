/**
 * The project's physics settings (Docs/physics.md §3): what its `physics.json` says, as the page has it. The
 * pipeline reads and checks the file (`packages/pipeline/src/physics/settings.ts`) and serves it to the page as
 * `virtual:vibe/physics`, which the generated `bundle.ts` hands here (`usePhysicsSettings`); an edit of the file
 * comes in again the same way, live, and every installed physics world is told (`onPhysicsSettings`). A node test
 * hands its own to `installPhysics`.
 *
 * Pure: no DOM, no Ammo.
 */

/** Friction and bounce, the default a collider with no material of its own takes. */
export interface PhysicsMaterialValues {
  friction: number;
  restitution: number;
}

/** What `physics.json` holds, filled in: every field there. */
export interface PhysicsSettings {
  /** Physics in this project's builds at all (`PHYSICS_BUILD`): the editor's switch. */
  enabled: boolean;
  /** Metres a second squared, world space. */
  gravity: readonly [number, number, number];
  /** Steps a tick, 1 to 8: each 1/(60 × substeps) seconds. */
  substeps: number;
  /** The solver's iterations a step, 1 to 50. */
  iterations: number;
  /** Under these speeds (m/s, rad/s) for a while, a body sleeps. */
  sleep: { linear: number; angular: number };
  defaultMaterial: PhysicsMaterialValues;
  /** The physics layers' names, at most 15, in order from 0. */
  layers: readonly string[];
  /** The pairs of layers that do not collide, by name, each way listed once (F3). */
  ignore: readonly (readonly [string, string])[];
}

/** Every default: a project with no `physics.json` has physics on, with these. */
export const PHYSICS_DEFAULTS: PhysicsSettings = {
  enabled: true,
  gravity: [0, -9.81, 0],
  substeps: 1,
  iterations: 10,
  sleep: { linear: 0.8, angular: 1 },
  defaultMaterial: { friction: 0.5, restitution: 0 },
  layers: ['Default'],
  ignore: [],
};

let current: PhysicsSettings = PHYSICS_DEFAULTS;
const listeners = new Set<(settings: PhysicsSettings) => void>();

/** The project's settings, from its generated `bundle.ts`: kept, and every installed physics world told. */
export function usePhysicsSettings(settings: PhysicsSettings): void {
  current = settings;
  for (const listener of listeners) listener(settings);
}

/** The settings in effect: the project's, or the defaults before it said. */
export const physicsSettings = (): PhysicsSettings => current;

/** Told of every change after this; returns the undo. */
export function onPhysicsSettings(listener: (settings: PhysicsSettings) => void): () => void {
  listeners.add(listener);
  return () => void listeners.delete(listener);
}
