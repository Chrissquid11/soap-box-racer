/**
 * `physicsOf(world)`: the physics a system asks things of (Docs/physics.md D13), taken where the system is
 * registered as a channel is (`world.events(...)`), never at module level (the `ecs` check). The page's physics
 * world, installed by `Game` over Ammo (`bridge.ts`), or -- physics off in the project, Ammo failed to load, a
 * worker's world, a test with none -- the inert handle, which steps nothing and answers nothing (D4).
 *
 * Whether there is physics (`ready`), bodies brought up to the components with no step (`sync`), the numbers Config ▸
 * Physics shows (`stats`), and the queries (F3): a ray's nearest hit and every hit, a shape swept, a shape's overlaps,
 * by layer mask (`layers(...)`), each into a scratch object the caller made once (`RayHit`, `RayHits`, a `Uint32Array`).
 *
 * And `impulseAt`, the pure helper that pushes at a point. Pure: no Ammo; a node test imports it.
 */
import type { Entity, ReadStore, Store } from '../ecs/component.ts';
import type { WorldTransform } from '../ecs/component.ts';
import type { World } from '../ecs/world.ts';
import type { Forces } from './components.ts';

/** What the physics world has in it, as of the last step: one object, filled in place. */
export interface PhysicsStats {
  /** Bodies of each type in the simulation, and how many of all are awake. */
  dynamic: number;
  kinematic: number;
  static: number;
  awake: number;
  /** Shapes made (each collider's, and each compound's). */
  shapes: number;
  /** Pairs touching after the last step. */
  contacts: number;
  /**
   * Milliseconds the last step took, and the most over the last 60 (wall time: measurement, not simulation). Timed
   * only for the 60 ticks after a `stats()` read -- reading the clock allocates -- so the first read says 0.
   */
  stepMs: number;
  maxStepMs: number;
  /** Bullet objects made since the install: what a pooled instance's take does not add to. */
  made: number;
  /** Bullet worlds made afresh since the install: one a load (`world.onLoad`), never a game removing its bodies. */
  worlds: number;
  /** Triggers in the simulation (counted apart from the kinematic bodies they are to Bullet). */
  triggers: number;
}

/** What a query hit: one object, made at module level and filled by each query (nothing allocated per call). */
export class RayHit {
  /** The body's entity (or a static collider's, or a trigger's own). */
  entity = 0;
  /** Where, world space. */
  x = 0;
  y = 0;
  z = 0;
  /** The surface's normal there, out of what was hit. */
  normalX = 0;
  normalY = 0;
  normalZ = 0;
  /** Metres from the start along the ray (or the sweep's centre's path). */
  distance = 0;
  /** The share of the way to the end: 0 at the start, 1 at the end. */
  fraction = 0;
}

/** Every hit along a ray, nearest first, up to `capacity`: rows of numbers, made once, filled by `raycastAll`. */
export class RayHits {
  readonly capacity: number;
  count = 0;
  readonly entity: Uint32Array;
  /** Three numbers a hit: x, y, z. */
  readonly point: Float32Array;
  readonly normal: Float32Array;
  readonly distance: Float32Array;
  constructor(capacity: number) {
    this.capacity = capacity;
    this.entity = new Uint32Array(capacity);
    this.point = new Float32Array(capacity * 3);
    this.normal = new Float32Array(capacity * 3);
    this.distance = new Float32Array(capacity);
  }
}

/** A shape a sweep pushes or an overlap tests: a description, made at module level; its Bullet shape is the stage's, made once. */
export interface Probe {
  readonly kind: 'sphere' | 'box' | 'capsule';
  /** Sphere: radius. Box: half extents x, y, z. Capsule: radius, height end to end (along y). */
  readonly a: number;
  readonly b: number;
  readonly c: number;
}
export const sphereProbe = (radius: number): Probe => ({ kind: 'sphere', a: radius, b: 0, c: 0 });
export const boxProbe = (halfX: number, halfY: number, halfZ: number): Probe => ({ kind: 'box', a: halfX, b: halfY, c: halfZ });
export const capsuleProbe = (radius: number, height: number): Probe => ({ kind: 'capsule', a: radius, b: height, c: 0 });

/** Every physics layer: a query's mask that skips none. */
export const ALL_LAYERS = 0x7fff;

/** The physics, as a system asks it. */
export interface Physics {
  /** Is there a physics world here at all: false for the inert handle. */
  readonly ready: boolean;
  /**
   * Bodies made, removed and moved to match the components, with no step: what a tool asks before it reads the
   * physics world of a stopped game (the editor's). Outside a tick only.
   */
  sync(): void;
  /** The numbers as of the last step (or sync): the same object every call. */
  stats(): PhysicsStats;
  /**
   * A query's mask of the physics layers named (`physics.json`'s names), checked: an unknown name throws. Take it where
   * the system is registered, beside `physicsOf`. No names: every layer.
   */
  layers(...names: string[]): number;
  /**
   * The nearest body the ray from `o` along `d` (any length: normalised) meets within `max` metres, on a layer of
   * `mask`, into `hit`: true if it met one. `triggers` true to meet triggers too. As of the last step: in `update`
   * last tick's poses, in `lateUpdate` this tick's. Throws in a `parallel` system (D19). Allocates nothing.
   */
  raycast(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number, mask: number, hit: RayHit, triggers?: boolean): boolean;
  /** Every body along the ray, nearest first, once each, into `hits` (up to its capacity): how many. */
  raycastAll(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, max: number, mask: number, hits: RayHits, triggers?: boolean): number;
  /** `probe` (unturned) pushed from `from` to `to`: the first body it would touch, its centre's place then in `hit`. */
  sweep(probe: Probe, fx: number, fy: number, fz: number, tx: number, ty: number, tz: number, mask: number, hit: RayHit, triggers?: boolean): boolean;
  /** The bodies `probe` (unturned) at `(x, y, z)` touches or is inside of, their entities into `out`: how many (up to its length). */
  overlap(probe: Probe, x: number, y: number, z: number, mask: number, out: Uint32Array, triggers?: boolean): number;
}

const zeroStats = (): PhysicsStats => ({ dynamic: 0, kinematic: 0, static: 0, awake: 0, shapes: 0, contacts: 0, stepMs: 0, maxStepMs: 0, made: 0, worlds: 0, triggers: 0 });

/** The handle where there is no physics: nothing to sync, nothing in it. */
export const INERT: Physics = {
  ready: false,
  sync: () => {},
  stats: (() => {
    const none = zeroStats();
    return () => none;
  })(),
  layers: () => ALL_LAYERS,
  raycast: () => false,
  raycastAll: (_ox, _oy, _oz, _dx, _dy, _dz, _max, _mask, hits) => (hits.count = 0),
  sweep: () => false,
  overlap: () => 0,
};

const installed = new WeakMap<World, Physics>();

/** A query on a worker thread: refused, as `rng` is in a parallel system (D19) -- never a quiet "nothing there". */
const onWorker = (what: string): never => {
  throw new Error(`[physics] ${what} from a parallel system, here on a worker thread, where there is no physics. Take parallel off, or ask from another system`);
};

/** A worker's world's handle: no physics, and a query is an error (it came from a parallel system, the only kind there). */
export const WORKER: Physics = {
  ready: false,
  sync: () => {},
  stats: INERT.stats,
  layers: INERT.layers,
  raycast: () => onWorker('raycast'),
  raycastAll: () => onWorker('raycastAll'),
  sweep: () => onWorker('sweep'),
  overlap: () => onWorker('overlap'),
};

/** `world`'s physics: the installed one, a worker's world's (which refuses queries), or the inert handle. Taken where a system is registered, as a channel is. */
export function physicsOf(world: World): Physics {
  return installed.get(world) ?? (world.onWorker ? WORKER : INERT);
}

/** The bridge's: `physics` is `world`'s from now on (null: none again). */
export function bindPhysics(world: World, physics: Physics | null): void {
  if (physics) installed.set(world, physics);
  else installed.delete(world);
}

/** A fresh stats object, for the bridge. */
export const newStats = zeroStats;

/**
 * An impulse `(ix, iy, iz)` (newton seconds, world space) at the world point `(px, py, pz)` on `e`'s body: its
 * share that turns it added to `angularImpulse` about the body's origin (its centre of mass), the whole to
 * `impulse`. For a `Forces` in `world` space (its default); the stage applies both at the next step. Allocates
 * nothing.
 */
export function impulseAt(
  forces: Store<typeof Forces.schema>,
  at: ReadStore<typeof WorldTransform.schema>,
  e: Entity,
  ix: number, iy: number, iz: number,
  px: number, py: number, pz: number,
): void {
  const rx = px - at.px[e]!, ry = py - at.py[e]!, rz = pz - at.pz[e]!;
  forces.impulseX[e] += ix;
  forces.impulseY[e] += iy;
  forces.impulseZ[e] += iz;
  forces.angularImpulseX[e] += ry * iz - rz * iy;
  forces.angularImpulseY[e] += rz * ix - rx * iz;
  forces.angularImpulseZ[e] += rx * iy - ry * ix;
}
