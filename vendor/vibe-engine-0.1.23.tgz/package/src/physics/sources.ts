/**
 * Where the page's physics finds what a collider is made of (Docs/physics.md §4.2): `Game` hands these to
 * `installPhysics`, as it hands `animate` a model's clips. A model's triangles from the loaded glTF -- the whole model,
 * or one part of it where the whole model draws it (as `Render` places a part) -- a height map's samples from a
 * texture's red channel, and a physics material's file from the project's data kind `physicsmaterials`.
 *
 * The page's: three and the asset store. A node test hands `installPhysics` arrays instead.
 */
import * as THREE from 'three';
import { Assets } from '../assets/index.ts';
import { caseKey } from '../assets/case-key.ts';
import { onModelReplaced, textures } from '../assets/store.ts';
import { dataIfPresent, onDataFiles } from '../data.ts';
import type { HeightData, MeshData, PhysicsOptions } from './bridge.ts';

const scratch = new THREE.Matrix4();
const corner = new THREE.Vector3();

/** `model`'s triangles (or its part `part`'s), in the model's own space: null for a model not loaded or a part it has not. */
export function meshFrom(model: string, part: string | null): MeshData | null {
  const gltf = Assets.modelIfPresent(model);
  if (!gltf) return null;
  const root = gltf.scene;
  const from = part === null ? root : root.getObjectByName(part);
  if (!from) return null;
  root.updateWorldMatrix(true, true);
  const back = new THREE.Matrix4().copy(root.matrixWorld).invert();
  const positions: number[] = [];
  const indices: number[] = [];
  from.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    const at = mesh.geometry.getAttribute('position');
    if (!at) return;
    scratch.multiplyMatrices(back, mesh.matrixWorld);
    const base = positions.length / 3;
    for (let i = 0; i < at.count; i++) {
      corner.fromBufferAttribute(at, i).applyMatrix4(scratch);
      positions.push(corner.x, corner.y, corner.z);
    }
    const index = mesh.geometry.getIndex();
    if (index) for (let i = 0; i < index.count; i++) indices.push(base + index.getX(i));
    else for (let i = 0; i < at.count; i++) indices.push(base + i);
  });
  return positions.length === 0 ? null : { positions: Float32Array.from(positions), indices: Uint32Array.from(indices) };
}

/** A texture's red channel, 0 to 1, row by row: null for one not loaded or not readable. */
export function heightsFrom(key: string): HeightData | null {
  const texture = textures.get(caseKey(key));
  if (!texture) return null;
  const image = texture.image as (CanvasImageSource & { width: number; height: number }) | null;
  if (!image || !image.width || !image.height) return null;
  const canvas = document.createElement('canvas');
  canvas.width = image.width;
  canvas.height = image.height;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  if (!context) return null;
  context.drawImage(image, 0, 0);
  const pixels = context.getImageData(0, 0, image.width, image.height).data;
  const values = new Float32Array(image.width * image.height);
  for (let i = 0; i < values.length; i++) values[i] = pixels[i * 4]! / 255;
  return { width: image.width, depth: image.height, values };
}

/** The page's sources, for `installPhysics`. */
export const PAGE_SOURCES: Omit<PhysicsOptions, 'ammo' | 'settings'> = {
  mesh: meshFrom,
  heights: heightsFrom,
  material: (key) => dataIfPresent('physicsmaterials', key),
  onModels: (told) => onModelReplaced(told),
  onMaterials: (told) => onDataFiles((kind) => {
    if (kind === 'physicsmaterials') told();
  }),
};
