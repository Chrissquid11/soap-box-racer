/**
 * Real time into base ticks (Docs/loop.md §8).
 *
 * Each frame's real seconds, times the time scale, go into an accumulator, and
 * every whole 1/60 s in it is a tick to run. **Falling behind drops time, never
 * ticks**: past `maxSteps` in one frame the rest of the whole steps are thrown
 * away, the fraction is kept, and the loop runs the ticks it was given in
 * order -- every slot still gets its turn, every input window still tiles. The
 * game slows for a moment instead of skipping updates or spiralling.
 *
 * What is left in the accumulator, as a fraction of a tick, is `alpha`: how far
 * the frame being drawn is between the last tick and the next. Interpolate by it.
 */
import { STEP } from './rate.ts';

/** A float's worth of slack, in ticks: 1/60 s added up sixty times is not quite one second. */
const EPSILON = 1e-6;

export class Clock {
  /** How fast game time runs against real time: 0.5 is slow motion, 0 holds it still. */
  timeScale = 1;
  private acc = 0;
  /** Ticks one frame may run; the rest of the time is dropped. */
  readonly maxSteps: number;

  constructor(maxSteps = 5) {
    this.maxSteps = maxSteps;
  }

  /** The frame's real seconds: set it, then `advance()`. A field, not an argument: see `Loop.aim`. */
  frameDt = 0;
  /** How far between the last tick and the next the frame is, 0 to 1. Set by `advance`. */
  alpha = 0;

  /** Ticks to run for a frame of `frameDt` real seconds: pass it, or set the field first. */
  advance(frameDt = this.frameDt): number {
    this.acc += frameDt * this.timeScale;
    const whole = Math.floor(this.acc / STEP + EPSILON);
    // All of them leave the accumulator, those past the cap included: dropped.
    this.acc = Math.max(0, this.acc - whole * STEP);
    this.alpha = Math.min(1, this.acc / STEP);
    return Math.min(whole, this.maxSteps);
  }
}
