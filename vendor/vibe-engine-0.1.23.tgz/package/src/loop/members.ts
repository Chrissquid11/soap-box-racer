/**
 * Member lists: ids grouped by slot, in typed arrays (Docs/loop.md §4).
 *
 * One `Uint32Array` per slot with a count beside it, so a tick's batch is one
 * contiguous run and nothing is allocated to hand it over. Joining appends;
 * leaving swap-removes, by way of an index array from id to position. A list
 * grows by doubling and never shrinks, and the tail past its count is kept at
 * zero, so a loop that overruns visits only id 0.
 *
 * The caller says which slot: the loop's is `id % period`, the ECS's transform
 * lists use an entity's depth.
 */

const EMPTY = new Uint32Array(0);

export class Members {
  /** The ids of each slot. Read `counts[slot]` of them: the rest is zero. */
  readonly lists: Uint32Array[];
  /** How many ids each slot holds. */
  readonly counts: Int32Array;
  /** Members in all slots together. */
  total = 0;
  /** An id's position in its slot's list, plus one; 0 for "not a member". */
  private pos: Uint32Array = EMPTY;

  constructor(slots: number) {
    this.lists = Array.from({ length: slots }, () => EMPTY);
    this.counts = new Int32Array(slots);
  }

  has(id: number): boolean {
    return id < this.pos.length && this.pos[id] !== 0;
  }

  /** `id` into `slot`. It must not be a member already. */
  add(id: number, slot: number): void {
    if (id >= this.pos.length) this.growIndex(id);
    let list = this.lists[slot]!;
    const n = this.counts[slot]!;
    if (n === list.length) {
      const grown = new Uint32Array(Math.max(16, n * 2));
      grown.set(list);
      this.lists[slot] = list = grown;
    }
    list[n] = id;
    this.pos[id] = n + 1;
    this.counts[slot] = n + 1;
    this.total++;
  }

  /** `id` out of `slot`, which it must be in: the slot's last member takes its place. */
  remove(id: number, slot: number): void {
    const list = this.lists[slot]!;
    const at = this.pos[id]! - 1;
    const last = this.counts[slot]! - 1;
    const moved = list[last]!;
    list[at] = moved;
    this.pos[moved] = at + 1;
    list[last] = 0;
    this.pos[id] = 0;
    this.counts[slot] = last;
    this.total--;
  }

  private growIndex(id: number): void {
    let size = Math.max(64, this.pos.length);
    while (size <= id) size *= 2;
    const grown = new Uint32Array(size);
    grown.set(this.pos);
    this.pos = grown;
  }
}
