/**
 * The load table (Docs/loop.md §5): where an unstaggered system's one slot
 * goes, and the debug panel's load readout. A member's own slot is not chosen
 * here any more: it is `id % period` (`schedule.ts`).
 *
 * One entry per tick of the 60-tick cycle, holding the summed weight of every
 * member, in every system, that runs on that tick. A member joining a system of
 * period P is scored on each candidate slot k over the ticks it would run on --
 * k, k+P, k+2P ... -- and takes the slot with:
 *
 *   1. the lowest peak, the busiest of those ticks, so no tick piles up;
 *   2. then the lowest total over them;
 *   3. then the soonest, the first of the tied slots to come up from the next
 *      tick on, which also keeps spawn latency down.
 *
 * Deterministic: the inputs are the table (the product of every earlier join and
 * leave), the period, and the next tick. Weights are whole numbers, so sums
 * compare exactly however a table came to hold them.
 */
import { CYCLE } from './rate.ts';

export class LoadTable {
  private readonly load: number[] = new Array<number>(CYCLE).fill(0);

  /** The slot, 0 to `period` - 1, a new member of a system with this period should take. */
  choose(period: number, nextTick: number): number {
    let best = 0;
    let bestPeak = Infinity;
    let bestTotal = Infinity;
    let bestWait = Infinity;
    for (let slot = 0; slot < period; slot++) {
      let peak = 0;
      let total = 0;
      for (let t = slot; t < CYCLE; t += period) {
        const load = this.load[t]!;
        if (load > peak) peak = load;
        total += load;
      }
      // Ticks from `nextTick` until this slot first comes up: 0 if it runs then.
      const wait = (((slot - nextTick) % period) + period) % period;
      if (peak < bestPeak || (peak === bestPeak && (total < bestTotal || (total === bestTotal && wait < bestWait)))) {
        best = slot;
        bestPeak = peak;
        bestTotal = total;
        bestWait = wait;
      }
    }
    return best;
  }

  /** A member's weight on every tick its slot runs on. */
  add(period: number, slot: number, weight: number): void {
    for (let t = slot; t < CYCLE; t += period) this.load[t]! += weight;
  }

  /** And off again, when it leaves. */
  remove(period: number, slot: number, weight: number): void {
    for (let t = slot; t < CYCLE; t += period) this.load[t]! -= weight;
  }

  /** The load on each tick of the cycle: for the debug panel and the tests. */
  loads(): readonly number[] {
    return this.load;
  }
}
