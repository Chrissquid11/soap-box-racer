/**
 * The loop: systems in three phases, the simulation at seven rates, members
 * spread over slots, joins and leaves at tick boundaries (Docs/loop.md).
 *
 * Each frame (`frame`):
 *
 *   input        input-phase systems, then every queued edge stamped with the next tick
 *   simulation   as many ticks as the clock gives: each due system, level by level,
 *                then the queued joins and leaves
 *   render       render-phase systems, with `alpha` for interpolation
 *
 * The draw itself is the caller's, after `frame` returns: three, then Pixi.
 *
 * **`step` is one tick by hand**, for a paused game (Game.step, the editor's F10):
 * the input absorbed, one tick, then the render phase with `alpha` at 1 -- the
 * clock and its accumulator untouched, no real time counted.
 *
 * **A tick has two stages**: every due system's `update`, then every due
 * system's `lateUpdate`, with `hooks.betweenStages` between them (the ECS
 * propagates transforms there). `hooks.beforeTick` and `hooks.afterTick` are
 * the tick boundary, where the ECS applies its commands; the joins and leaves
 * they queue are applied right after each.
 *
 * **A member's slot is `id % period`** (Docs/ecs.md §4): no choosing, no map.
 * Members are typed arrays with a count (`members.ts`), the queue is a typed
 * array, each system has one context: a steady tick allocates nothing.
 *
 * **When a simulation system is called.** A staggered system (the default) is
 * due every tick and gets that tick's slot -- empty or not. An unstaggered one
 * is due on its one slot's ticks, every P. A 60 Hz system is due every tick
 * either way. So a system with no members, maintaining something of its own,
 * is simply an unstaggered system that ignores `members`.
 *
 * **`reset` drops every system** and the tick, keeping the seed, the clock and
 * the input: the running game rebuilt in place, the same `Loop` object
 * (Docs/squidwright-implementation.md 0.3).
 *
 * Pure: no DOM, no three. `Game` drives it from its animation frame.
 */
import { Clock } from './clock.ts';
import { InputState, InputView, type InputSink } from './input.ts';
import { Members } from './members.ts';
import { dependencyLevels } from './order.ts';
import { TICK_HZ, isRate, periodOf, type Rate } from './rate.ts';
import { Rng } from './rng.ts';
import { LoadTable } from './slots.ts';

export type Phase = 'input' | 'simulation' | 'render';

/** What a simulation system gets each call. One object a system, moved on each call: read it during the call. */
export interface SimulationContext {
  /** The members due now: one slot's worth. Read `count` of them; do not keep or change it. */
  readonly members: Uint32Array;
  /** How many of `members` are due. The array is longer: loop `n < count`, never `for...of`. */
  readonly count: number;
  /** Seconds since this slot last ran: the system's period, always. */
  readonly dt: number;
  /** The system's period, ticks: 60 / rate. */
  readonly period: number;
  /** Are its members spread over the period's slots? False for a 60 Hz or an unstaggered system: every member in every call. */
  readonly staggered: boolean;
  /** The tick being run. */
  readonly tick: number;
  /** Game time, seconds: `tick / 60`, never summed, so it cannot drift. */
  readonly time: number;
  /** Input over this system's window: since it last ran (`InputView`). */
  readonly input: InputView;
  /** This system's own seeded stream. Never `Math.random` in the simulation. */
  readonly rng: Rng;
}

export interface InputContext {
  /** Real seconds since the last frame. */
  readonly frameDt: number;
  /** Where input-phase systems put what they make: stamped with the rest. */
  readonly input: InputSink;
}

export interface RenderContext {
  /** Real seconds since the last frame. */
  readonly frameDt: number;
  /** How far the frame is between the last tick and the next, 0 to 1: interpolate by it. */
  readonly alpha: number;
  /** The next tick to run. */
  readonly tick: number;
  /** What `tick` was at the last frame's render phase: the ticks from `since` up to `tick` ran in between. */
  readonly since: number;
}

interface Named {
  /** Unique across every phase. */
  name: string;
  /** Systems of the same phase this one runs after, on a tick both run. */
  after?: readonly string[];
}

export interface SimulationSystem extends Named {
  phase?: 'simulation';
  rate: Rate;
  /** A whole number: this system's cost per member, for the load readout and for placing unstaggered systems. Default 1. */
  weight?: number;
  /** Spread members over the period's slots (default), or run them all on one slot. */
  stagger?: boolean;
  /** New members, once, on the first tick after they joined, before that tick's slot. */
  onJoin?(ctx: SimulationContext): void;
  /** Those that left at the last boundary, once, on the first tick after, before that tick's slot. They are no longer members. */
  onLeave?(ctx: SimulationContext): void;
  /** The first stage of a tick: things move. At least one of `update` and `lateUpdate`. */
  update?(ctx: SimulationContext): void;
  /** The second stage, after every system's `update`: things follow (Docs/ecs.md §8). */
  lateUpdate?(ctx: SimulationContext): void;
  /** More fields for this system's context, copied on when it registers: how the ECS adds its own. */
  context?: object;
}

export interface InputSystem extends Named {
  phase: 'input';
  update(ctx: InputContext): void;
}

export interface RenderSystem extends Named {
  phase: 'render';
  update(ctx: RenderContext): void;
}

export type System = SimulationSystem | InputSystem | RenderSystem;

export interface LoopOptions {
  /** The game's seed: every system's stream comes from it. Record it to replay a game. */
  seed?: number;
  /** Ticks one frame may run before the rest of the time is dropped. Default 5. */
  maxStepsPerFrame?: number;
}

/** Called by the loop at fixed points of a tick: how the ECS takes part (Docs/ecs.md §7, §8). */
export interface LoopHooks {
  /** Before a tick's first system. Joins and leaves queued here are applied before the tick runs. */
  beforeTick?(tick: number): void;
  /** Between every `update` and every `lateUpdate`. */
  betweenStages?(tick: number): void;
  /** After a tick's last system. Joins and leaves queued here are applied at this boundary. */
  afterTick?(tick: number): void;
}

/** `Loop.failure`: a tick that threw. */
export interface TickFailure {
  /** The system whose `update`, `lateUpdate`, `onJoin` or `onLeave` threw; null for a hook (the ECS's boundary). */
  system: string | null;
  tick: number;
  error: unknown;
}

/** `Loop.saveState()`: plain data, safe to turn into JSON. */
export interface LoopState {
  tick: number;
  /** Each simulation system's random stream, by the system's name. Empty for content (a scene, a level): every stream from the seed. */
  streams: Record<string, number[]>;
}

/** One system, for a debug readout: `Loop.info()`. */
export interface SystemInfo {
  name: string;
  phase: Phase;
  /** Hz; 0 for an input or render system. */
  rate: number;
  /** Its dependency level within its phase. */
  level: number;
  stagger: boolean;
  /** Has an `update`, a `lateUpdate`. */
  stages: string;
  /** Members in each slot. */
  slots: number[];
}

/** A frame longer than this, real seconds, counts as this long: a tab switch, a hitch. */
const MAX_FRAME_DT = 0.25;

type Mutable<T> = {
  -readonly [K in keyof T]: T[K];
};

type Context = Mutable<SimulationContext> & { input: InputView };

interface SimEntry {
  readonly phase: 'simulation';
  readonly name: string;
  readonly after: readonly string[] | undefined;
  readonly def: SimulationSystem;
  /** Its number: what `handle` returns. */
  readonly index: number;
  readonly period: number;
  readonly weight: number;
  readonly stagger: boolean;
  /** The one slot of an unstaggered system. */
  readonly fixedSlot: number;
  /** Members by slot: `period` of them, or one for an unstaggered system. */
  readonly members: Members;
  /** Joined at the last boundary, waiting for `onJoin`. */
  joined: Uint32Array;
  joinedCount: number;
  /** Left at the last boundary, waiting for `onLeave`. */
  left: Uint32Array;
  leftCount: number;
  readonly ctx: Context;
  readonly joinCtx: Context;
}

interface FrameEntry<S extends InputSystem | RenderSystem> {
  readonly phase: S['phase'];
  readonly name: string;
  readonly after: readonly string[] | undefined;
  readonly def: S;
}

type Entry = SimEntry | FrameEntry<InputSystem> | FrameEntry<RenderSystem>;

/** The systems of each phase, in the order they run: levels flattened. */
interface Order {
  input: FrameEntry<InputSystem>[];
  simulation: SimEntry[];
  /** Those of `simulation` with a `lateUpdate`. */
  late: SimEntry[];
  render: FrameEntry<RenderSystem>[];
  levelOf: Map<string, number>;
}

export class Loop {
  /** The stamped input every simulation system reads, and devices feed. */
  readonly input = new InputState();
  readonly seed: number;
  /** The ECS's way into a tick: each world on this loop adds its own. Called in the order added. */
  readonly hooks: LoopHooks[] = [];
  /**
   * The last tick that threw, and in which system (null: in a hook, at the
   * boundary): what a game says when it stops on one (`boot`). Set before
   * the error is thrown on; never cleared.
   */
  failure: TickFailure | null = null;
  /** The system being called just now, for `failure`. */
  private inSystem: string | null = null;

  private readonly clock: Clock;
  private load = new LoadTable();
  private readonly entries = new Map<string, Entry>();
  private readonly registered: Entry[] = [];
  private readonly sims: SimEntry[] = [];
  private order: Order | null = null;
  /** Queued joins and leaves, two numbers each: the system's index doubled, plus one for a join; then the id. */
  private queue = new Int32Array(256);
  private queued = 0;
  private nextTick = 0;
  /**
   * The last frame's timestamp, ms; negative for "the next frame is the first"
   * (start, resume). Always a number, never null: a field that holds either
   * boxes every fraction stored in it.
   */
  private last = -1;
  private readonly inputCtx: Mutable<InputContext>;
  private readonly renderCtx: Mutable<RenderContext> = { frameDt: 0, alpha: 0, tick: 0, since: 0 };
  /** In `frame`, `runTick` or `present` just now: `reset` refuses then. */
  private running = false;
  /**
   * A `step` was the last tick run: the render phase draws at alpha 1, the tick
   * itself, until the next tick runs -- not the clock's alpha, which is as old
   * as the pause, through `present` and a frame after `resume` that runs none.
   */
  private stepped = false;

  constructor({ seed = 0, maxStepsPerFrame = 5 }: LoopOptions = {}) {
    this.seed = seed >>> 0;
    this.clock = new Clock(maxStepsPerFrame);
    this.inputCtx = { frameDt: 0, input: this.input };
  }

  /** The next tick to run: how many have run. */
  get tick(): number {
    return this.nextTick;
  }

  /** Game time, seconds. */
  get time(): number {
    return this.nextTick / TICK_HZ;
  }

  /** How fast game time runs: 1 normal, 0.5 slow motion, 0 hit-stop. Every rate together. */
  get timeScale(): number {
    return this.clock.timeScale;
  }

  set timeScale(value: number) {
    this.clock.timeScale = Math.max(0, value);
  }

  /**
   * A seeded stream for code outside any system that the simulation still
   * depends on -- setting up a level, scattering its first props. Named, so
   * each use has its own sequence, independent of every other.
   */
  random(name: string): Rng {
    return Rng.stream(this.seed, `setup:${name}`);
  }

  addSystem(def: System): void {
    if (this.entries.has(def.name)) throw new Error(`[loop] a system called '${def.name}' is already registered`);
    let entry: Entry;
    if (def.phase === 'input' || def.phase === 'render') {
      entry = { phase: def.phase, name: def.name, after: def.after, def } as Entry;
    } else {
      if (!isRate(def.rate)) throw new Error(`[loop] '${def.name}' has rate ${String(def.rate)}: a rate is one of 1, 5, 10, 15, 20, 30 or 60 Hz`);
      if (!def.update && !def.lateUpdate) throw new Error(`[loop] '${def.name}' has neither update nor lateUpdate: give it one`);
      const weight = def.weight ?? 1;
      if (!Number.isInteger(weight) || weight < 1) throw new Error(`[loop] '${def.name}' has weight ${weight}: a weight is a whole number from 1`);
      const period = periodOf(def.rate);
      const stagger = def.stagger ?? true;
      // An unstaggered system takes its one slot now, and reserves it: its own
      // weight goes on the table, so the next unstaggered system at the same
      // rate lands elsewhere rather than on the same ticks.
      const fixedSlot = stagger ? 0 : this.load.choose(period, this.nextTick);
      if (!stagger) this.load.add(period, fixedSlot, weight);
      const rng = Rng.stream(this.seed, def.name);
      const members = new Members(stagger ? period : 1);
      const context = (window: number): Context => ({
        members: members.lists[0]!,
        count: 0,
        dt: period / TICK_HZ,
        period,
        staggered: stagger && period > 1,
        tick: 0,
        time: 0,
        input: new InputView(this.input, window),
        rng,
        ...def.context,
      });
      const sim: SimEntry = {
        phase: 'simulation',
        name: def.name,
        after: def.after,
        def,
        index: this.sims.length,
        period,
        weight,
        stagger,
        fixedSlot,
        members,
        joined: new Uint32Array(16),
        joinedCount: 0,
        left: new Uint32Array(16),
        leftCount: 0,
        ctx: context(period),
        // `onJoin` sees this tick's input only: a new member has no "since I last ran".
        joinCtx: context(1),
      };
      this.sims.push(sim);
      entry = sim;
    }
    this.entries.set(def.name, entry);
    this.registered.push(entry);
    this.order = null;
  }

  /**
   * Every system dropped, as if the loop were new: the entries, the order, the
   * load table, the queued joins and leaves, the tick, the failure and the
   * hooks (each world on the loop adds its own again as it is reset). The seed,
   * the clock and the input stay; the input's history is dropped, as a load
   * does, the tick going back to 0. Then `addSystem` and `build()` as on a
   * fresh loop, and a save's `loadState` sets the tick and the streams. For
   * the running game rebuilt in place (Docs/squidwright-implementation.md
   * 0.3). Throws during a frame or a tick: a system cannot reset its own loop.
   */
  reset(): void {
    if (this.running) throw new Error('[loop] reset() during a frame or a tick: reset the loop between frames');
    this.entries.clear();
    this.registered.length = 0;
    this.sims.length = 0;
    this.order = null;
    this.load = new LoadTable();
    this.queued = 0;
    this.nextTick = 0;
    this.last = -1;
    this.failure = null;
    this.inSystem = null;
    this.hooks.length = 0;
    this.inputCtx.frameDt = 0;
    this.renderCtx.frameDt = 0;
    this.renderCtx.alpha = 0;
    this.renderCtx.tick = 0;
    this.renderCtx.since = 0;
    this.stepped = false;
    this.input.rebase();
  }

  /** A simulation system's number, for `joinAt` and `leaveAt`: look it up once, not per member. */
  handle(system: string): number {
    return this.simEntry(system).index;
  }

  /** Queue `id` to join a simulation system: it takes slot `id % period` at the next tick boundary. */
  join(system: string, id: number): void {
    this.enqueue(this.simEntry(system).index * 2 + 1, id);
  }

  /** Queue `id` to leave a simulation system at the next tick boundary. Until then it is still a member. */
  leave(system: string, id: number): void {
    this.enqueue(this.simEntry(system).index * 2, id);
  }

  /** `join`, by the system's `handle`. */
  joinAt(handle: number, id: number): void {
    this.enqueue(handle * 2 + 1, id);
  }

  /** `leave`, by the system's `handle`. */
  leaveAt(handle: number, id: number): void {
    this.enqueue(handle * 2, id);
  }

  /** Is `id` a member now (joins and leaves still queued not counted)? */
  isMember(system: string, id: number): boolean {
    return this.simEntry(system).members.has(id);
  }

  /** `isMember`, by the system's `handle`. */
  isMemberAt(handle: number, id: number): boolean {
    return this.sims[handle]!.members.has(id);
  }

  /** The slot `id` holds in a system, or undefined. */
  slotOf(system: string, id: number): number | undefined {
    const entry = this.simEntry(system);
    if (!entry.members.has(id)) return undefined;
    return entry.stagger ? id % entry.period : entry.fixedSlot;
  }

  /**
   * What a saved game needs of the loop to carry on exactly: the tick, and where
   * each system's random stream had got to. Input history and the clock's
   * fraction of a tick are not part of it.
   */
  saveState(): LoopState {
    const streams: Record<string, number[]> = {};
    for (const sim of this.sims) streams[sim.name] = sim.ctx.rng.state();
    return { tick: this.nextTick, streams };
  }

  /**
   * A saved state taken back: the tick, and each stream of a system that is
   * still registered. A state with no streams -- content, a scene or a level,
   * not a saved game (`sceneSave`, Docs/loop.md §10) -- starts every stream
   * afresh from this loop's own seed instead, so the run's seed holds whatever
   * the file was saved from. The input history starts again either way: the
   * tick may have gone back.
   */
  loadState(state: LoopState): void {
    this.nextTick = state.tick;
    this.renderCtx.tick = state.tick;
    this.input.rebase();
    let content = true;
    for (const _ in state.streams) {
      content = false;
      break;
    }
    for (const sim of this.sims) {
      if (content) {
        sim.ctx.rng.restore(Rng.stream(this.seed, sim.name).state());
        continue;
      }
      const stream = state.streams[sim.name];
      if (stream) sim.ctx.rng.restore(stream);
    }
  }

  /** The load on each tick of the 60-tick cycle (`slots.ts`): for the debug panel. */
  loads(): readonly number[] {
    return this.load.loads();
  }

  /** Every system, in the order it runs within its phase: for `world.describe()` and the editor. Allocates: not for a tick. */
  info(): SystemInfo[] {
    const order = this.ordered();
    const out: SystemInfo[] = [];
    for (const entry of [...order.input, ...order.simulation, ...order.render]) {
      const sim = entry.phase === 'simulation' ? entry : null;
      out.push({
        name: entry.name,
        phase: entry.phase,
        rate: sim ? TICK_HZ / sim.period : 0,
        level: order.levelOf.get(entry.name) ?? 0,
        stagger: sim ? sim.stagger : false,
        stages: sim ? [sim.def.update ? 'update' : '', sim.def.lateUpdate ? 'lateUpdate' : ''].filter(Boolean).join('+') : 'update',
        slots: sim ? Array.from(sim.members.counts) : [],
      });
    }
    return out;
  }

  /**
   * The order, built: dependencies resolved into levels. Throws on an unknown
   * name or a cycle, naming the systems. Runs by itself on the first frame or
   * tick after a system is added; call it after registering to fail at startup.
   */
  build(): void {
    this.ordered();
  }

  /**
   * One animation frame, at `now` (ms, `requestAnimationFrame`'s clock): the
   * input phase, the ticks the clock gives, the render phase.
   */
  frame(now: number): void {
    const outer = this.running;
    this.running = true;
    try {
      this.runFrame(now);
    } finally {
      this.running = outer;
    }
  }

  private runFrame(now: number): void {
    const order = this.ordered();
    const frameDt = this.last < 0 ? 0 : Math.min(Math.max(0, (now - this.last) / 1000), MAX_FRAME_DT);
    this.last = now;

    this.inputCtx.frameDt = frameDt;
    const input = order.input;
    for (let i = 0; i < input.length; i++) input[i]!.def.update(this.inputCtx);
    this.input.stamp(this.nextTick);

    this.clock.frameDt = frameDt;
    const steps = this.clock.advance();
    for (let i = 0; i < steps; i++) this.runTick();

    this.renderCtx.frameDt = frameDt;
    this.renderCtx.alpha = this.stepped ? 1 : this.clock.alpha;
    this.renderCtx.since = this.renderCtx.tick;
    this.renderCtx.tick = this.nextTick;
    const render = order.render;
    for (let i = 0; i < render.length; i++) render[i]!.def.update(this.renderCtx);
  }

  /**
   * The render phase alone, for a stopped game: the render systems run with
   * no time passed, so what a tool changed while paused reaches what is drawn.
   */
  present(): void {
    const outer = this.running;
    this.running = true;
    try {
      this.presentRender();
    } finally {
      this.running = outer;
    }
  }

  private presentRender(): void {
    const render = this.ordered().render;
    this.renderCtx.frameDt = 0;
    this.renderCtx.alpha = this.stepped ? 1 : this.clock.alpha;
    this.renderCtx.since = this.renderCtx.tick;
    this.renderCtx.tick = this.nextTick;
    for (let i = 0; i < render.length; i++) render[i]!.def.update(this.renderCtx);
  }

  /**
   * One tick by hand, while paused (`Game.step`): what was pressed is absorbed
   * without an edge (the key that asked for the step is not the game's), one
   * tick -- every system due at it, the commands applied at its boundary --
   * then the render phase with `alpha` at 1, the tick just run drawn as it is.
   * The clock is not touched: no real time counted, its accumulator as it
   * was, so the frames after `resume` go on as they would have. A tick that
   * throws is thrown on, ended, as from `runTick`.
   */
  step(): void {
    if (this.running) throw new Error('[loop] step() during a frame or a tick');
    this.input.absorb();
    try {
      this.runTick();
    } finally {
      // After the tick, which clears it; a tick that throws is still the tick drawn as it ended, by whoever presents next.
      this.stepped = true;
    }
    this.present();
  }

  /**
   * After a pause: the time paused is not counted, and what was pressed during
   * it is taken into the state without an edge -- the press that closed the
   * menu does not also act in the game.
   */
  resume(): void {
    this.last = -1;
    this.input.absorb();
  }

  /**
   * One tick: what was queued since the last one joins and leaves; every due
   * system's `update`, level by level; every due system's `lateUpdate`; then
   * the boundary, where what this tick queued joins and leaves.
   */
  runTick(): void {
    const tick = this.nextTick;
    let ended = false;
    const outer = this.running;
    this.running = true;
    this.inSystem = null;
    // A tick run: the clock's alpha is what is drawn again (`step` marks its own after).
    this.stepped = false;
    try {
      this.runSystems(tick);
      ended = true;
      this.endTick(tick);
    } catch (err) {
      // A system threw (or a hook did): the tick still ends -- every world's
      // boundary applies what was queued up to the throw, and leaves the tick -- so
      // the world is usable after it, by the editor, a save, the next tick. Then it
      // is thrown on, to whoever runs the loop.
      this.failure = { system: ended ? null : this.inSystem, tick, error: err };
      if (!ended) {
        try {
          this.endTick(tick);
        } catch {
          // The first error is the one that says what went wrong.
        }
      }
      throw err;
    } finally {
      this.nextTick = tick + 1;
      this.running = outer;
    }
  }

  /** A tick's `afterTick` hooks, every one even if one throws (the first error thrown after), and the joins they queued. */
  private endTick(tick: number): void {
    const hooks = this.hooks;
    let failed: unknown = null;
    for (let i = 0; i < hooks.length; i++) {
      try {
        hooks[i]!.afterTick?.(tick);
      } catch (err) {
        failed ??= err;
      }
    }
    if (this.queued > 0) this.applyQueue();
    if (failed !== null) throw failed;
  }

  private runSystems(tick: number): void {
    const order = this.ordered();
    const hooks = this.hooks;

    // Asked for outside a tick -- setup, the input phase: in before this tick runs.
    for (let i = 0; i < hooks.length; i++) hooks[i]!.beforeTick?.(tick);
    if (this.queued > 0) this.applyQueue();

    const simulation = order.simulation;
    for (let i = 0; i < simulation.length; i++) {
      const entry = simulation[i]!;
      if (entry.leftCount > 0) {
        const ctx = entry.joinCtx;
        const count = entry.leftCount;
        // Taken before the hook runs: one that throws is not handed the same ones again.
        entry.leftCount = 0;
        ctx.members = entry.left;
        ctx.count = count;
        ctx.tick = tick;
        ctx.time = tick / TICK_HZ;
        ctx.input.tick = tick;
        this.inSystem = entry.name;
        entry.def.onLeave!(ctx);
        entry.left.fill(0, 0, count);
      }
      if (entry.joinedCount > 0) {
        const ctx = entry.joinCtx;
        const count = entry.joinedCount;
        entry.joinedCount = 0;
        ctx.members = entry.joined;
        ctx.count = count;
        ctx.tick = tick;
        ctx.time = tick / TICK_HZ;
        ctx.input.tick = tick;
        this.inSystem = entry.name;
        entry.def.onJoin!(ctx);
        entry.joined.fill(0, 0, count);
      }
      if (!entry.def.update) continue;
      if (this.aim(entry, tick)) {
        this.inSystem = entry.name;
        entry.def.update(entry.ctx);
      }
    }

    this.inSystem = null;
    for (let i = 0; i < hooks.length; i++) hooks[i]!.betweenStages?.(tick);

    const late = order.late;
    for (let i = 0; i < late.length; i++) {
      const entry = late[i]!;
      if (this.aim(entry, tick)) {
        this.inSystem = entry.name;
        entry.def.lateUpdate!(entry.ctx);
      }
    }
    this.inSystem = null;
  }

  /**
   * A system's context moved to this tick's slot. False if the system is not
   * due on this tick. Only whole numbers are passed in: a fraction handed to a
   * function the engine has not inlined is boxed on the heap.
   */
  private aim(entry: SimEntry, tick: number): boolean {
    let slot = 0;
    if (entry.stagger) slot = tick % entry.period;
    else if (tick % entry.period !== entry.fixedSlot) return false;
    const ctx = entry.ctx;
    ctx.members = entry.members.lists[slot]!;
    ctx.count = entry.members.counts[slot]!;
    ctx.tick = tick;
    ctx.time = tick / TICK_HZ;
    ctx.input.tick = tick;
    return true;
  }

  private enqueue(what: number, id: number): void {
    if (this.queued + 2 > this.queue.length) {
      const grown = new Int32Array(this.queue.length * 2);
      grown.set(this.queue);
      this.queue = grown;
    }
    this.queue[this.queued++] = what;
    this.queue[this.queued++] = id;
  }

  /**
   * Queued joins and leaves applied now, outside a tick: for the ECS's
   * `world.flush()`, so setup code and the editor see members without running
   * a tick. Never call it from a system.
   */
  applyPending(): void {
    if (this.queued > 0) this.applyQueue();
  }

  /**
   * Every pending `onJoin` and `onLeave` dropped: for the ECS's `world.load`,
   * where the members were members already when the game was saved.
   */
  forgetNotices(): void {
    for (const sim of this.sims) {
      sim.joined.fill(0, 0, sim.joinedCount);
      sim.left.fill(0, 0, sim.leftCount);
      sim.joinedCount = sim.leftCount = 0;
    }
  }

  /** The boundary: queued joins and leaves, in the order they were asked for. */
  private applyQueue(): void {
    const queue = this.queue;
    const n = this.queued;
    // Emptied first: a throw part way must not leave the queue to be applied again.
    this.queued = 0;
    for (let i = 0; i < n; i += 2) {
      const what = queue[i]!;
      const entry = this.sims[what >> 1]!;
      if (what & 1) this.add(entry, queue[i + 1]!);
      else this.remove(entry, queue[i + 1]!);
    }
  }

  private add(entry: SimEntry, id: number): void {
    if (entry.members.has(id)) throw new Error(`[loop] ${id} joined '${entry.name}' twice`);
    // The id decides the slot: every system of one rate runs it on the same ticks.
    const slot = entry.stagger ? id % entry.period : 0;
    entry.members.add(id, slot);
    this.load.add(entry.period, entry.stagger ? slot : entry.fixedSlot, entry.weight);
    // Gone and back at the same boundary: it never left.
    const left = entry.left;
    for (let i = 0; i < entry.leftCount; i++) {
      if (left[i] !== id) continue;
      left.copyWithin(i, i + 1, entry.leftCount);
      left[--entry.leftCount] = 0;
      return;
    }
    if (entry.def.onJoin) {
      if (entry.joinedCount === entry.joined.length) {
        const grown = new Uint32Array(entry.joined.length * 2);
        grown.set(entry.joined);
        entry.joined = grown;
      }
      entry.joined[entry.joinedCount++] = id;
    }
  }

  private remove(entry: SimEntry, id: number): void {
    if (!entry.members.has(id)) throw new Error(`[loop] ${id} left '${entry.name}', which it is not in`);
    const slot = entry.stagger ? id % entry.period : 0;
    entry.members.remove(id, slot);
    this.load.remove(entry.period, entry.stagger ? slot : entry.fixedSlot, entry.weight);
    // Joined and gone at the same boundary: no first look, and no last.
    const joined = entry.joined;
    for (let i = 0; i < entry.joinedCount; i++) {
      if (joined[i] !== id) continue;
      joined.copyWithin(i, i + 1, entry.joinedCount);
      joined[--entry.joinedCount] = 0;
      return;
    }
    if (entry.def.onLeave) {
      if (entry.leftCount === entry.left.length) {
        const grown = new Uint32Array(entry.left.length * 2);
        grown.set(entry.left);
        entry.left = grown;
      }
      entry.left[entry.leftCount++] = id;
    }
  }

  private simEntry(system: string): SimEntry {
    const entry = this.entries.get(system);
    if (!entry) throw new Error(`[loop] no system called '${system}'`);
    if (entry.phase !== 'simulation') throw new Error(`[loop] '${system}' is a ${entry.phase} system: only simulation systems have members`);
    return entry;
  }

  /**
   * The order, built if it has to be. Two functions on purpose: `buildOrder`
   * has closures over its locals, and a function like that allocates a context
   * every time it is entered -- even to return at once. This one is entered
   * every tick.
   */
  private ordered(): Order {
    return this.order ?? this.buildOrder();
  }

  private buildOrder(): Order {
    const phaseOf = (name: string): string | undefined => this.entries.get(name)?.phase;
    const levelOf = new Map<string, number>();
    const of = <E extends Entry>(phase: Phase): E[] => {
      const levels = dependencyLevels(
        this.registered.filter((e): e is E => e.phase === phase),
        phaseOf,
      );
      levels.forEach((level, n) => level.forEach((entry) => levelOf.set(entry.name, n)));
      return levels.flat();
    };
    const simulation = of<SimEntry>('simulation');
    this.order = {
      input: of<FrameEntry<InputSystem>>('input'),
      simulation,
      late: simulation.filter((entry) => entry.def.lateUpdate),
      render: of<FrameEntry<RenderSystem>>('render'),
      levelOf,
    };
    return this.order;
  }
}
