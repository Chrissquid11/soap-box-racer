/**
 * Seeded randomness for the simulation (Docs/loop.md §10): never `Math.random`.
 *
 * **One stream per system.** Each simulation system gets its own generator,
 * seeded from the game's seed and the system's name. With one stream for the
 * whole game, adding or removing any system that draws numbers would shift
 * every other system's sequence, and a bug reproduced yesterday would play
 * differently in today's build. Per system, a stream depends only on the seed
 * and on what that system itself drew.
 *
 * The generator is sfc32 (Chris Doty-Humphrey's Small Fast Counting
 * generator): 128 bits of state, fast in 32-bit integer maths, good statistical
 * quality, a few lines. The seed text is spread into its four words by cyrb128.
 * Integer arithmetic throughout, so every engine gives the same sequence.
 */

/** Four 32-bit words from a string: cyrb128, a simple, well-mixed hash. */
function cyrb128(text: string): [number, number, number, number] {
  let h1 = 1779033703;
  let h2 = 3144134277;
  let h3 = 1013904242;
  let h4 = 2773480762;
  for (let i = 0; i < text.length; i++) {
    const k = text.charCodeAt(i);
    h1 = h2 ^ Math.imul(h1 ^ k, 597399067);
    h2 = h3 ^ Math.imul(h2 ^ k, 2869860233);
    h3 = h4 ^ Math.imul(h3 ^ k, 951274213);
    h4 = h1 ^ Math.imul(h4 ^ k, 2716044179);
  }
  h1 = Math.imul(h3 ^ (h1 >>> 18), 597399067);
  h2 = Math.imul(h4 ^ (h2 >>> 22), 2869860233);
  h3 = Math.imul(h1 ^ (h3 >>> 17), 951274213);
  h4 = Math.imul(h2 ^ (h4 >>> 19), 2716044179);
  h1 ^= h2 ^ h3 ^ h4;
  h2 ^= h1;
  h3 ^= h1;
  h4 ^= h1;
  return [h1 >>> 0, h2 >>> 0, h3 >>> 0, h4 >>> 0];
}

export class Rng {
  private a: number;
  private b: number;
  private c: number;
  private d: number;

  /** The stream for `name` under `seed`: the same pair always gives the same sequence. */
  static stream(seed: number, name: string): Rng {
    return new Rng(...cyrb128(`${seed >>> 0}:${name}`));
  }

  constructor(a: number, b: number, c: number, d: number) {
    this.a = a | 0;
    this.b = b | 0;
    this.c = c | 0;
    this.d = d | 0;
    // The first few outputs of a freshly seeded sfc32 are the least mixed.
    for (let i = 0; i < 12; i++) this.uint32();
  }

  /** The last 32 bits drawn, signed. */
  private out = 0;

  /**
   * The generator's step: the next 32 bits, left in `out`. Every public method
   * calls this and nothing else of the class, and it hands nothing back: a
   * number returned from a function the engine has not inlined is boxed on the
   * heap unless it is a small integer, and each layer of calls would box one
   * more. So a draw costs at most the one number its caller asked for.
   */
  private step(): void {
    const t = (((this.a + this.b) | 0) + this.d) | 0;
    this.d = (this.d + 1) | 0;
    this.a = this.b ^ (this.b >>> 9);
    this.b = (this.c + (this.c << 3)) | 0;
    this.c = (this.c << 21) | (this.c >>> 11);
    this.c = (this.c + t) | 0;
    this.out = t;
  }

  /** A whole number in [0, 2^32). */
  uint32(): number {
    this.step();
    return this.out >>> 0;
  }

  /** A number in [0, 1). */
  next(): number {
    this.step();
    return (this.out >>> 0) / 4294967296;
  }

  /** A whole number from `lo` to `hi`, both included. */
  int(lo: number, hi: number): number {
    this.step();
    return lo + Math.floor(((this.out >>> 0) / 4294967296) * (hi - lo + 1));
  }

  /** A number in [lo, hi). */
  range(lo: number, hi: number): number {
    this.step();
    return lo + ((this.out >>> 0) / 4294967296) * (hi - lo);
  }

  /** True with probability `p`. */
  chance(p: number): boolean {
    this.step();
    return (this.out >>> 0) / 4294967296 < p;
  }

  /** Where the stream has got to, as four numbers: for a saved game. */
  state(): number[] {
    return [this.a, this.b, this.c, this.d];
  }

  /** A `state()` taken back: the stream carries on from there. */
  restore(state: readonly number[]): void {
    this.a = state[0]! | 0;
    this.b = state[1]! | 0;
    this.c = state[2]! | 0;
    this.d = state[3]! | 0;
  }

  /** One element of a list. Throws on an empty one: there is nothing to pick. */
  pick<T>(list: readonly T[]): T {
    if (list.length === 0) throw new Error('[rng] pick from an empty list');
    return list[this.int(0, list.length - 1)]!;
  }
}
