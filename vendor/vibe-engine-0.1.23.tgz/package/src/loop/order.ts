/**
 * The order systems run in: dependency levels (Docs/loop.md §4).
 *
 * A system lists the systems it runs after. Its level is 0 if it lists none,
 * else one more than the highest level among them. Levels run in order, and
 * within a level systems run in registration order. So a system with a
 * dependency runs after every system with none, even those registered after
 * it -- a rule simple enough to read off the list. Systems in one level never
 * depend on each other.
 *
 * Names are resolved here, not when a system is added, so a system may name a
 * dependency registered after it. An unknown name and a cycle are errors that
 * name the systems involved.
 */

export interface Ordered {
  readonly name: string;
  readonly after?: readonly string[];
}

/**
 * The systems of one phase, in levels. `elsewhere` says which phase a name
 * belongs to if it is not in this one, so a dependency across phases gets an
 * error that says so rather than "not registered".
 */
export function dependencyLevels<T extends Ordered>(systems: readonly T[], elsewhere: (name: string) => string | undefined = () => undefined): T[][] {
  const byName = new Map<string, T>();
  for (const system of systems) byName.set(system.name, system);

  const levelOf = new Map<string, number>();
  /** The path being resolved, for naming a cycle. */
  const path: string[] = [];

  const resolve = (system: T): number => {
    const known = levelOf.get(system.name);
    if (known !== undefined) return known;
    const at = path.indexOf(system.name);
    if (at >= 0) throw new Error(`[loop] dependency cycle: ${[...path.slice(at), system.name].join(' -> ')}`);
    path.push(system.name);
    let level = 0;
    for (const name of system.after ?? []) {
      const dependency = byName.get(name);
      if (!dependency) {
        const phase = elsewhere(name);
        throw new Error(
          phase
            ? `[loop] '${system.name}' runs after '${name}', which is a ${phase} system: dependencies cannot cross phases`
            : `[loop] '${system.name}' runs after '${name}', which is not registered`,
        );
      }
      level = Math.max(level, resolve(dependency) + 1);
    }
    path.pop();
    levelOf.set(system.name, level);
    return level;
  };

  // In registration order, so each level fills in registration order.
  const levels: T[][] = [];
  for (const system of systems) (levels[resolve(system)] ??= []).push(system);
  return levels;
}
