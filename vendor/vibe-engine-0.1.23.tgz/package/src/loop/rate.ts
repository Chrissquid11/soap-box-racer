/**
 * The seven rates a simulation system can run at, and the base tick they
 * divide (Docs/loop.md §2).
 *
 * Every rate divides 60, so the whole schedule -- every slot of every rate --
 * repeats every `CYCLE` ticks. That is what lets one 60-entry load table
 * balance every rate at once (`slots.ts`), and 60 ticks of input history serve
 * every window (`input.ts`). Adding a rate is one more number here, and it
 * must divide 60.
 */

/** A simulation system's rate, in Hz. A closed list: `rate: 12` is a compile error. */
export type Rate = 1 | 5 | 10 | 15 | 20 | 30 | 60;

export const RATES: readonly Rate[] = [1, 5, 10, 15, 20, 30, 60];

/** Base ticks a second. */
export const TICK_HZ = 60;

/** One base tick, seconds. */
export const STEP = 1 / TICK_HZ;

/** Ticks in which every rate's schedule repeats: the longest period. */
export const CYCLE = 60;

/** A rate's period: how many base ticks between a member's updates. */
export function periodOf(rate: Rate): number {
  return TICK_HZ / rate;
}

/** Is this a rate a system may have? For values that did not come through the type. */
export function isRate(value: unknown): value is Rate {
  return RATES.includes(value as Rate);
}
