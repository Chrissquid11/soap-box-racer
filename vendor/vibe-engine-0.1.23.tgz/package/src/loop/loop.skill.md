---
skill: engine
title: The loop
when: Before choosing a system's rate, reading input or chance or time in a system, or pausing and slowing the game
covers:
  modules: [loop/]
order: 20
---
# The loop: one clock, seven rates

Gameplay runs on fixed ticks of one clock, 60 a second. Each system picks one rate, and runs every so many
ticks; its members are spread over those ticks, so a 1 Hz system with 60 members updates one of them each
tick rather than all 60 at once. Input is stamped with the tick it came in on, and chance and time come from
the loop -- so the same seed and the same input play the same game. The code is
`node_modules/@vibe/engine/src/loop/` (`schedule.ts` has the contexts, `rng.ts` the streams, `input.ts` the
windows); the ECS's `world.system(...)` is how a game uses it ([the ECS page](ecs.md)).

## Rates

| Rate | Every | `dt` | Its input window |
|---|---|---|---|
| 60 Hz | tick | 1/60 s | this tick |
| 30 Hz | 2 ticks | 1/30 s | the last 2 |
| 20 Hz | 3 ticks | 0.05 s | the last 3 |
| 15 Hz | 4 ticks | 1/15 s | the last 4 |
| 10 Hz | 6 ticks | 0.1 s | the last 6 |
| 5 Hz | 12 ticks | 0.2 s | the last 12 |
| 1 Hz | 60 ticks | 1 s | the last 60 |

A rate is one of these seven, and any other number is a type error. A rate is the system's, never an entity's:
an entity in a 60 Hz and a 1 Hz system is simply in both.

- **Slow systems decide; 60 Hz systems move.** A target, a state, an AI's choice: 1 to 20 Hz. Anything that
  writes `Transform` is 60 Hz (the `ecs` check fails otherwise), and the renderer draws it interpolated
  between ticks, so motion is smooth at any frame rate.
- **`dt` is the system's period**, always: a 5 Hz system gets 0.2. A member's first update after it joined may
  come sooner -- a system that cares does its first look in `onJoin`.
- **A slow decision may be a period old**: a 1 Hz target may have died 0.9 s ago. Whatever acts on it at 60 Hz
  checks it each tick (`deref`, and `NONE`).

## Staggered, or all at once

A slow system is **staggered** by default: a member's slot comes from its id, so its members are spread over
the period and each runs once a period, a few each tick. Two things follow:

- **A staggered system is called every tick**, with that tick's few. Work it does per call -- sorting a list,
  building an index -- happens 60 times a second. Shared structures belong to a 60 Hz system; slow ones read
  them, with that system in `after`.
- **`stagger: false`** runs every member on one tick of the period: a 5 Hz economy pass, a 1 Hz count. An
  event reader below 60 Hz needs it. So does a system with no members that keeps something of its own: it
  ignores `members`, and runs once a period.

`after: ['name']` orders systems on a tick both run (rates do not order anything); an unknown name or a cycle
fails at start, naming the systems. `weight` (a whole number, default 1) is a system's cost per member, for the
debug panel's load readout.

## A tick, a frame

Each animation frame: the input phase (devices to stamped input), then as many ticks as the time owes (at
most five a frame -- a slow device slows the game down rather than skipping), then the render phase (the
views drawn, interpolated by `alpha`), then three draws, then the UI over it. A tick has two stages: every
due system's `update`, then every due system's `lateUpdate`, with world transforms worked out between them.

- **What changes structure waits for the boundary**: an entity made or destroyed, a component added, at the
  end of the tick. Iterating `members` is always safe.
- **A system that throws still ends its tick**: the world stays good. A debug build pauses there and names the
  system; a release says it once on the console and runs on.
- **Render systems** (`world.system({ name, phase: 'render', read, update })`) run once a frame with `alpha`
  and `frameDt`, for presentation only -- they never change what the simulation reads.

## Input in a system

```ts
import { type World } from '@vibe/engine';
import { Hop } from '../components.ts';

export function jump(world: World): void {
  world.system({
    name: 'jump',
    rate: 10,                                      // decides at 10 Hz; a 60 Hz system moves it by vy
    write: [Hop],
    update({ members, count, input }, _read, [hop]) {
      for (let n = 0; n < count; n++) {
        const e = members[n];
        if (input.pressed('Space') && hop.vy[e] === 0) hop.vy[e] = 6;   // each member sees the press, once
      }
    },
  });
}
```

`ctx.input` is already bound to the system's window, so a 10 Hz system misses no press that came between
its runs, and no system's reading uses a press up for another:

- `input.pressed(code)` went down at least once in the window; `released(code)` went up; `presses(code)` how
  many times it went down.
- `input.down(code)` is held now, as of this tick. A tap within one tick still counts: `pressed` and
  `released` true, `down` false.
- `input.pointer` is `{ x, y }` in CSS pixels from the canvas's top left; `input.axis(i)` a pad's stick, -1 to 1
  (0 and 1 the left, 2 and 3 the right).

Codes are `KeyboardEvent.code`s (`'Space'`, `'KeyW'`, `'ArrowLeft'`); pointer buttons and pads have their own
([the input page](input.md)). A press the UI took never reaches the game's input. Keys lost to a blur come
up by themselves; presses while paused are dropped.

## Chance and time

```ts
const { rng, time, dt, tick } = ctx;
const roll = rng.range(0, 1);        // [0, 1); rng.int(1, 6) a whole one, both ends in; rng.chance(0.25); rng.next()
const late = time > 30 + roll;       // game seconds: tick / 60, never summed
```

- **Every simulation system has its own seeded stream** (`ctx.rng`): a system added or taken away never shifts
  another's numbers. Never `Math.random`, `Date.now()` or `performance.now()` in simulation code -- the same
  seed must play the same game. Render and UI code may use either.
- **Setup the simulation depends on** (scattering a level's first props in `populate`) takes a named stream
  of its own: `world.loop.random('scatter')`.
- **`time` and `tick` go back on a load**: a save carries its tick, so something keyed to an absolute time (a
  cooldown's `until`) counts from the save's clock. A save carries every stream too; a scene does not, so a
  scene plays out from the run's seed.
- The seed is `boot({ seed })`, random when not said, and `?seed=1234` on the URL in a debug build, whose console
  says the one it chose.

## Pausing and slowing down

```ts
import type { Game } from '@vibe/engine/boot';

export function slowMotion(game: Game, on: boolean): void {
  game.loop.timeScale = on ? 0.5 : 1;               // every rate together; 0 is hit-stop
}
```

- `game.pause()` and `game.resume()` stop and start the ticks (the pause menu does it; a pause is not counted
  as time on resume). The UI goes on animating on real time over the kept frame.
- `timeScale` 0 is not a pause: input is still stamped and render systems still run.

## The rules that bite

- One loop shape over `members`: `for (let n = 0; n < count; n++)`, never `for...of`, never `members.length`
  (`members` is longer than what is due).
- Read the context during the call; never keep it, or its `members`, for later.
- `onJoin` is a new member's first look, the tick after it joined (a 1 Hz system would otherwise leave it
  waiting a second); `onLeave` those that left, once.

The game's systems under `src/game/systems/` are examples of each rate; the [ECS page](ecs.md) has the
declaration, events and the rest.
