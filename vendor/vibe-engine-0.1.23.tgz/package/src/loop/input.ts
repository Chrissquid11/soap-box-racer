/**
 * Input every rate can see (Docs/loop.md §7).
 *
 * **Stamped edges.** Device events -- a key, a pointer button, a pad button --
 * are queued as edges (down or up) as they arrive (`src/input/devices.ts`).
 * Once a frame, before any tick runs, `stamp` gives everything queued the
 * number of the next tick to run and files it in the history. A frame that runs
 * no tick leaves nothing behind: its edges are stamped, and wait for that tick.
 *
 * **Windowed reads.** A simulation system on tick t reads over (t - P, t],
 * P being its own period: `pressed` is "went down at least once since this
 * system last ran". Each slot of a system runs exactly every P ticks, so the
 * windows of its consecutive runs tile time with no gap and no overlap: every
 * slot of every rate sees every edge exactly once, and reading never uses an
 * edge up for anyone else.
 *
 * **State** -- what is down now, where the pointer is, the pad's sticks -- is as
 * of the last stamp, which is never later than the tick being run.
 *
 * Pure: no DOM. The history is 60 ticks, the longest window.
 */
import { CYCLE } from './rate.ts';

interface Edge {
  readonly tick: number;
  readonly code: string;
  readonly down: boolean;
}

/** What device adapters and input-phase systems feed: queued until the next stamp. */
export interface InputSink {
  /** A button went down or up: a `KeyboardEvent.code` (`'Space'`), `'Pointer0'`, `'Pad0'`. */
  edge(code: string, down: boolean): void;
  /** Where the pointer is, CSS pixels from the canvas's top left. */
  pointerAt(x: number, y: number): void;
  /** A pad's axes, -1 to 1: left stick x and y, right stick x and y. */
  axes(values: ArrayLike<number>): void;
}

export class InputState implements InputSink {
  // Queued until the next stamp, in parallel lists and plain fields: a frame
  // with nothing queued allocates nothing, and nor does a pointer that moves.
  private readonly queuedCodes: string[] = [];
  private readonly queuedDowns: boolean[] = [];
  private pointerMoved = false;
  private pointerX = 0;
  private pointerY = 0;
  private axesSet = false;
  private readonly queuedAxes = [0, 0, 0, 0];

  /** Stamped edges, oldest first, from `start` on. */
  private edges: Edge[] = [];
  private start = 0;
  private readonly held = new Set<string>();
  private readonly point = { x: 0, y: 0 };
  private readonly stick = [0, 0, 0, 0];

  edge(code: string, down: boolean): void {
    this.queuedCodes.push(code);
    this.queuedDowns.push(down);
  }

  pointerAt(x: number, y: number): void {
    this.pointerMoved = true;
    this.pointerX = x;
    this.pointerY = y;
  }

  axes(values: ArrayLike<number>): void {
    this.axesSet = true;
    for (let i = 0; i < 4; i++) this.queuedAxes[i] = values[i] ?? 0;
  }

  /**
   * Everything queued, filed under `tick`: the next tick to run. An edge that
   * changes nothing -- down for a button already down -- is no edge. Edges too
   * old for any window go.
   */
  stamp(tick: number): void {
    const codes = this.queuedCodes;
    for (let i = 0; i < codes.length; i++) {
      const code = codes[i]!;
      const down = this.queuedDowns[i]!;
      if (down === this.held.has(code)) continue;
      if (down) this.held.add(code);
      else this.held.delete(code);
      this.edges.push({ tick, code, down });
    }
    codes.length = 0;
    this.queuedDowns.length = 0;
    this.takeState();
    // The longest window at any tick from `tick` on starts after `tick - CYCLE`.
    while (this.start < this.edges.length && this.edges[this.start]!.tick <= tick - CYCLE) this.start++;
    if (this.start > 256 && this.start * 2 > this.edges.length) {
      this.edges = this.edges.slice(this.start);
      this.start = 0;
    }
  }

  /**
   * Everything queued, taken into the state without an edge: after a pause.
   * The press that closed the menu must not also act in the game, but a key
   * let go of during the pause must not stay down.
   */
  absorb(): void {
    const codes = this.queuedCodes;
    for (let i = 0; i < codes.length; i++) {
      if (this.queuedDowns[i]) this.held.add(codes[i]!);
      else this.held.delete(codes[i]!);
    }
    codes.length = 0;
    this.queuedDowns.length = 0;
    this.takeState();
  }

  /**
   * The history dropped, what is held kept: for a load, which may move the
   * tick back (`Loop.loadState`). Edges stamped at the old ticks would sit at
   * the front of a history that is in tick order, and none would ever be pruned.
   */
  rebase(): void {
    this.edges.length = 0;
    this.start = 0;
  }

  /** How many edges of `code` going `down` (or up) were stamped in (from, to]. */
  count(code: string, down: boolean, from: number, to: number): number {
    let n = 0;
    for (let i = this.edges.length - 1; i >= this.start; i--) {
      const edge = this.edges[i]!;
      if (edge.tick <= from) break;
      if (edge.tick <= to && edge.down === down && edge.code === code) n++;
    }
    return n;
  }

  isDown(code: string): boolean {
    return this.held.has(code);
  }

  get pointer(): { readonly x: number; readonly y: number } {
    return this.point;
  }

  axis(index: number): number {
    return this.stick[index] ?? 0;
  }

  private takeState(): void {
    if (this.pointerMoved) {
      this.point.x = this.pointerX;
      this.point.y = this.pointerY;
      this.pointerMoved = false;
    }
    if (this.axesSet) {
      for (let i = 0; i < 4; i++) this.stick[i] = this.queuedAxes[i]!;
      this.axesSet = false;
    }
  }
}

/**
 * Input as one system sees it: the state, read over a window as long as the
 * system's period, ending at the tick being run. The loop keeps one per system
 * and moves it on each call, so read it during the call; do not keep it.
 */
export class InputView {
  /** The tick being run: the window's end. Set by the loop. */
  tick = 0;
  /** The window's length, ticks: the system's period. */
  readonly period: number;
  private readonly state: InputState;

  constructor(state: InputState, period: number) {
    this.state = state;
    this.period = period;
  }

  /** Went down at least once since this system last ran. */
  pressed(code: string): boolean {
    return this.state.count(code, true, this.tick - this.period, this.tick) > 0;
  }

  /** Went up at least once since this system last ran. */
  released(code: string): boolean {
    return this.state.count(code, false, this.tick - this.period, this.tick) > 0;
  }

  /** How many times it went down since this system last ran. */
  presses(code: string): number {
    return this.state.count(code, true, this.tick - this.period, this.tick);
  }

  /** Is down now. */
  down(code: string): boolean {
    return this.state.isDown(code);
  }

  /** Where the pointer is, CSS pixels from the canvas's top left. */
  get pointer(): { readonly x: number; readonly y: number } {
    return this.state.pointer;
  }

  /** A pad axis, -1 to 1 (0 with no pad): 0 and 1 the left stick, 2 and 3 the right. */
  axis(index: number): number {
    return this.state.axis(index);
  }
}
