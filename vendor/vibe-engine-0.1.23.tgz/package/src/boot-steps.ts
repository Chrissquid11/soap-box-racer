/**
 * The pure parts of `boot` (`boot.ts`): its steps' order as a list, the seed, studio mode, the player's settings.
 * Apart from `boot.ts`, which reads `DEBUG_BUILD` and the page as it loads, so a node test imports
 * these (`boot.test.ts`).
 */
import { projectId, projectKey } from './project-key.ts';

/**
 * `boot`'s steps, in the order it takes them -- the contract a project's hooks are called in. `boot`
 * marks each as it reaches it (`inOrder`), and a debug build says so if the code and this list part.
 *
 *   progress     the loading bar at its first notch, studio mode's P from the first moment
 *   portal       a portal SDK's init, awaited before anything else loads (`BootOptions.portal`)
 *   preload      the fonts beside `Assets.preload()`: the long part
 *   compile      every prefab compiled, before the world is made
 *   game         `new Game` from the project's entry, its swap wired, the project's `setup`
 *   resume       a reload the editor survived (studio mode): its world in place of the game's
 *   startScene   the scene that says `"start": true` -- never over a resumed world
 *   watchAssets  re-exported assets swapped into what is drawn, from now on
 *   workers      worker threads for the parallel systems, where the page allows them
 *   renderer     the asset store told the renderer, the bar near its end
 *   ui           the canvas UI on the game's context, and the project's widgets in it (`BootOptions.ui`)
 *   debug        MrDebug's other keys, the debug panel, the console's handles
 *   first frame  drawn, the loader put away
 *   listeners    sound, the tab hidden, the pause key
 *   run          the game running -- or, in studio mode, the editor open over it, paused
 */
export const BOOT_STEPS = ['progress', 'portal', 'preload', 'compile', 'game', 'resume', 'startScene', 'watchAssets', 'workers', 'renderer', 'ui', 'debug', 'first frame', 'listeners', 'run'] as const;
export type BootStep = (typeof BOOT_STEPS)[number];

/**
 * Studio mode's probe page (Docs/studio.md §1, "Mid-session"; the pipeline's `studio/probe.ts`, whose `PROBE_GLOBAL`
 * is this key's name): a hidden page that imports a changed module fresh, `src/main.ts` among them, only to see that it
 * evaluates before the dev server lets a page reload go. It sets `globalThis[ENTRY_PROBE]` first, and `boot` then
 * does nothing (`probing`): the entry evaluated, no second game booted. The frame is same-origin, so every other module
 * it imports runs its top level for real there (its storage, a fetch, an `AudioContext`): a project module with a
 * top-level side effect checks `probing()` -- `@vibe/engine/boot` exports it -- first.
 */
export const ENTRY_PROBE = Symbol.for('vibebase.probe');

/** Is this realm the probe page (`ENTRY_PROBE`)? */
export const probing = (realm: object = globalThis): boolean => (realm as Record<symbol, unknown>)[ENTRY_PROBE] === true;

/**
 * Studio mode's cold-start guard (Docs/studio.md §1, "Recovery"; the pipeline's `studio/cold-start.ts`, whose
 * `BOOT_GLOBAL` is this key's name): `boot` sets `globalThis[BOOT_STARTED]` as it starts, in a debug build. The guard,
 * an inline script the dev server puts before `src/main.ts`, reads it: a page whose entry's module graph failed (a
 * bad named import, a top-level throw, a module the dev server could not serve) never got here, and the guard boots
 * the editor in recovery itself.
 */
export const BOOT_STARTED = Symbol.for('vibebase.boot');

/** Where the first boot on a page hears of a second (`onSecondBoot`, `refuseSecond`). */
const SECOND_BOOT = Symbol.for('vibebase.boot.second');

/** What the first boot's editor says when a second was refused: `main.ts` came after all, so a reload boots the game. */
export const SECOND_BOOT_TEXT = "src/main.ts ran after all, after studio mode's cold-start recovery had booted the editor: Reload to boot the game";

/**
 * One boot a page (`BOOT_STARTED`), in a debug build: the first marks the realm and goes on (false); a second -- `main.ts`
 * late, a top-level await in its graph, after the cold-start guard recovered over an error heard first -- is refused
 * (true), and the first boot is told (`onSecondBoot`): its editor says so, with Reload.
 */
export function refuseSecond(realm: object = globalThis): boolean {
  const r = realm as Record<symbol, unknown>;
  if (r[BOOT_STARTED] !== true) {
    r[BOOT_STARTED] = true;
    return false;
  }
  const told = r[SECOND_BOOT];
  if (typeof told === 'function') (told as () => void)();
  return true;
}

/** The first boot's ear for a second that was refused (`refuseSecond`). */
export const onSecondBoot = (heard: () => void, realm: object = globalThis): void => {
  (realm as Record<symbol, unknown>)[SECOND_BOOT] = heard;
};

/** `BootOptions.ui`'s import form: the UI's module, whose `ui` export is the hook. */
export interface UiImport<H> {
  import(): Promise<{ ui: H }>;
}

/**
 * The project's UI hook, handed in or imported now (`BootOptions.ui`): a function is the hook itself; `{ import }` is its
 * module's import (`{ import: () => import('./ui/index.ts') }`, its `ui` export the hook), called at once -- beside the
 * preload, as the game's is -- so a UI module that does not load is boot's to catch, and studio mode's recovery's. Any
 * throw of the import, a synchronous one too, is the returned promise's rejection, the awaiter's -- never an unhandled
 * rejection first, never a throw out of here.
 */
export function loadUi<H extends (...args: never[]) => unknown>(ui: H | UiImport<H> | undefined): Promise<H | undefined> {
  if (ui === undefined) return Promise.resolve(undefined);
  if (typeof ui === 'function') return Promise.resolve(ui);
  const module = new Promise<{ ui: H }>((resolve) => resolve(ui.import())).then((m) => {
    if (typeof m?.ui !== 'function') throw new Error("boot's `ui`: `{ import }` imports the UI's module, whose `ui` export is the hook `(game, ui, actions) => ({ hud, menu })`");
    return m.ui;
  });
  module.catch(() => undefined);
  return module;
}

/** A marker for each step as it is reached: true while they come in `BOOT_STEPS`' order, false for one out of it. */
export function inOrder(): (step: BootStep) => boolean {
  let last = -1;
  return (step) => {
    const at = BOOT_STEPS.indexOf(step);
    const ok = at > last;
    last = Math.max(last, at);
    return ok;
  };
}

/**
 * The game's seed: random, from outside the simulation, so it may use `Math.random`. `?seed=1234` in
 * `search` replays one (Docs/loop.md §10) -- `boot` hands in the page's only in a debug build, and
 * logs the seed there, so a bug report can carry it.
 */
export function pickSeed(search: string): number {
  const asked = new URLSearchParams(search).get('seed');
  return asked !== null && /^\d+$/.test(asked) ? Number(asked) >>> 0 : Math.floor(Math.random() * 2 ** 32);
}

/**
 * Studio mode: `?studio` in `search`, with a value or none -- `?studio`,
 * `?studio=1`. The editor is then the whole page: open as boot ends and kept open, Playtest at its top bar's end --
 * and only then: without it the page is the game, and never loads the editor.
 * `boot` hands in the page's only in a debug build; a reload keeps it, as it is in the URL.
 */
export function readStudio(search: string): boolean {
  return new URLSearchParams(search).has('studio');
}

/** An error's words: its message, or the thing itself. */
export const errorWords = (err: unknown): string => (err instanceof Error ? err.message : String(err));

/**
 * Studio mode's editor did not load -- its module, or `createEditor` throwing: the page's loader says so over the game,
 * paused under where the editor would be, in place of its bar. The editor's own notices strip is no place to say it:
 * there is no editor. A reload is the clean way: `P` tries the editor's module again (`createEditor` takes back the
 * keys of one that threw half made, so a second try never fails on them), but nothing else a half-made editor left --
 * its elements, its listeners -- is undone. The console has the error in full.
 */
export function editorFailedText(err: unknown): string {
  return `The editor did not load -- ${errorWords(err)}\nThe game is under it, paused. Fix what the console names, then reload the page -- the clean way; P tries the editor again, but leaves what a half-made one left.`;
}

/**
 * The game's modules and the project's tool components, loaded in the order the worker defines components in
 * (Docs/ecs.md §10, the sandbox's `worker.ts`): `game` called at once (a value handed, as it is), `components`
 * only once the game's import has settled -- resolved or rejected, so a game that does not load (studio mode's
 * recovery) still gets the tools' components after it. The game's rejection is said where it is awaited, never as
 * an unhandled rejection first; the components' is the caller's to catch. No `components`, nothing loaded.
 */
export function loadGame<G extends object>(game: G | (() => Promise<G>), components?: () => Promise<unknown>): { game: Promise<G>; components: Promise<unknown> } {
  const module = typeof game === 'function' ? (game as () => Promise<G>)() : Promise.resolve(game);
  module.catch(() => undefined);
  const after = (): Promise<unknown> | undefined => components?.();
  return { game: module, components: module.then(after, after) };
}

/** The player's own settings, kept on this device. */
export interface Settings {
  muted: boolean;
}

/**
 * Where a project's settings are kept: `<name>.settings`, at the project's id where it has one (`projectKey`: the
 * dev server's and a debug build's, so two projects of one name on one port keep their own; a release's is its
 * origin's alone, the bare key).
 */
export const settingsKey = (name: string, id: string = projectId()): string => projectKey(`${name}.settings`, id);

/** The settings as kept, over the defaults; storage blocked or garbled, the defaults, every time. `storage` is asked inside the guard: reaching `localStorage` itself can throw. */
export function readSettings(name: string, storage: () => Pick<Storage, 'getItem'>, id: string = projectId()): Settings {
  try {
    return { muted: false, ...(JSON.parse(storage().getItem(settingsKey(name, id)) ?? '{}') as Partial<Settings>) };
  } catch {
    return { muted: false };
  }
}

/** The settings kept; storage blocked or full, not remembered, then. */
export function saveSettings(name: string, settings: Settings, storage: () => Pick<Storage, 'setItem'>, id: string = projectId()): void {
  try {
    storage().setItem(settingsKey(name, id), JSON.stringify(settings));
  } catch {
    // Not remembered, then.
  }
}
