/**
 * The engine's `cameras` system (Docs/camera.md §2): every entity with a
 * `Camera` seen through -- a three `PerspectiveCamera` or `OrthographicCamera`
 * made for it and attached as its `View`, so `present` places it from its world
 * transform, interpolated between ticks, as it places anything. `Game` asks
 * this for what to draw through (`camerasToDraw`, `main`).
 *
 * - **On `Camera` added** (at the boundary: an instance made or loaded, a
 *   paste, Add Component): its camera made, of the kind `projection` says,
 *   attached, its numbers applied, and a `CameraState` row beside it -- `ours`
 *   set, and the numbers as applied. An entity that has a view already (a
 *   `Render`'s) is not given one: said once, and not drawn through.
 * - **Each frame** (the `cameras` render-phase system, after `present`): each
 *   member's `Camera` against its `CameraState` row -- column compares, as the
 *   `render` system's against `ViewState`. A projection changed is the other
 *   kind of camera put in place of the old (`putView`: now, where it was);
 *   `fov`, `size`, `near`, `far` or the aspect of its viewport rect in pixels
 *   changed (the canvas resized, the rect edited) is the projection matrix made
 *   again; `layers` changed is `camera.layers.mask`. A frame with nothing
 *   changed reads the columns and writes nothing.
 * - **Scale is ignored**: `present` writes the whole matrix, scale and all, and
 *   three inverts that for the view -- a camera on a scaled entity (or under a
 *   scaled parent) would see the world squashed. Each frame, after `present`,
 *   the matrix's three axes are put back to unit length where they are not
 *   (three square roots a camera; nothing written when they are).
 * - **On `Camera` removed** (or the entity destroyed): its view goes with it.
 * - **The `render` system leaves it alone**: it walks the members of `Render`
 *   alone, and a camera's `ViewState.ours` is 0 (`attach`'s). `wear` and the
 *   layer hook (`view.ts`) never write a camera's `layers`: what a camera sees
 *   is `Camera.layers`, never the layer its entity is on (§1 rule 5).
 * - **What to draw through** (`camerasToDraw`): every live, active (no
 *   `Disabled` on it or above), enabled `Camera` with its camera made, by
 *   `depth`, then by entity. `Hidden` does not matter: a camera is never drawn
 *   as a thing. **The main one** (`main`): the first of those, by entity, with
 *   `main` on -- several said once -- or 0.
 * - **A pooled camera** keeps no view parked: the reset lets it go (the
 *   `render` system's keeper does not know it), and the `onInstance` hook the
 *   same reset runs last makes it again -- as for an instance made or loaded,
 *   each entity of it with a `Camera` and no view is given its camera, at the
 *   boundary, never from inside the frame's system.
 *
 * Imports three's cameras (node-safe: no renderer, no DOM), so a node test
 * installs it on a stand-in scene (`camera.test.ts`). Returns the cameras'
 * questions and their uninstall, for `Game.rebuild`: the hooks and the system
 * go with the world's reset, the views with `installView`'s uninstall.
 */
import * as THREE from 'three';
import { bool, Camera, CameraProjection, component, f32, Instance, optional, u32, u8, type Entity, type ReadStore, type Store, type World } from './ecs/index.ts';
import { attach, putView, releaseView, View, ViewState } from './view.ts';

/**
 * The `cameras` system's notes per camera, a row beside each `View` it made: `ours`, and `Camera`'s
 * numbers as last applied -- `aspect` the viewport rect's in pixels -- so its per-frame compare is
 * column reads. Transient: never saved, never shown.
 */
export const CameraState = component(
  'CameraState',
  {
    ours: bool(),
    projection: u8(),
    fov: f32(),
    size: f32(),
    near: f32(),
    far: f32(),
    aspect: f32(),
    layers: u32(),
  },
  { transient: true },
);

/** The game's frame's size in CSS pixels, as it is now (`frame.ts`: the whole canvas but in the editor). */
export interface CanvasSize {
  readonly width: number;
  readonly height: number;
}

export interface CameraOptions {
  /** The game's frame's size now (the canvas's, unless a frame is set): read once a frame, and as a camera is made. The same object each call is fine. */
  canvasSize(): CanvasSize;
}

/** One of the two cameras a `Camera` becomes. */
export type GameCamera = THREE.PerspectiveCamera | THREE.OrthographicCamera;

/** What `installCamera` answers. */
export interface Cameras {
  /**
   * Every camera to draw through, in order: live, active and enabled, its camera made, by `depth` then
   * entity. Empty: none -- `Game` draws through its built-in camera. The same list each call, written
   * over: read it at once.
   */
  camerasToDraw(): readonly Entity[];
  /** The camera the game is seen through: the first of `camerasToDraw` by entity with `main` on, or 0 for none. */
  main(): Entity;
  /** `e`'s camera, or null: none made, or the view on it not this system's. */
  object(e: Entity): GameCamera | null;
  /** The list forgotten: the hooks and the system go with the world's reset, the views with `installView`'s uninstall. */
  uninstall(): void;
}

/**
 * The camera the game itself is seen through: the built-in one while it is lent (`lent`: `Game.cameraControl`), else
 * the main `Camera` entity's, else the built-in one. Allocates nothing: `Game.mainCamera` asks it at every pointer
 * event, and the editor's `view_shot` through `Game.gameView`.
 */
export function gameCameraOf(cameras: Pick<Cameras, 'main' | 'object'>, builtIn: THREE.Camera, lent: boolean): THREE.Camera {
  if (lent) return builtIn;
  const main = cameras.main();
  if (main === 0) return builtIn;
  return cameras.object(main) ?? builtIn;
}

type Lens = ReadStore<typeof Camera.schema>;
type Notes = Store<typeof CameraState.schema>;

/**
 * The `cameras` system and its hooks on `world`, after `installView` (its `present` placed first, so
 * the scale is stripped from what it wrote).
 */
export function installCamera(world: World, { canvasSize }: CameraOptions): Cameras {
  const views = world.store(View);
  /** Every entity a `Camera` landed on and has not left: what `camerasToDraw` walks. */
  const all: Entity[] = [];
  /** `camerasToDraw`'s answer, written over each call. */
  const drawn: Entity[] = [];
  const said = new Set<string>();
  /** The main camera last said to be one of several with `main` on: `main()` says it once, not each call. */
  let severalSaid = 0 as Entity;
  const say = (what: string): void => {
    if (said.has(what)) return;
    said.add(what);
    console.warn(`[camera] ${what}`);
  };

  /** `e`'s camera made and attached, its numbers applied and noted: on `Camera` added, or an instance's entity with none. At a boundary. */
  const make = (e: Entity): void => {
    if (world.has(e, View)) {
      say(`entity ${e} has a Camera and a view of its own already (a Render?): not drawn through`);
      return;
    }
    const c = world.store(Camera);
    const object: GameCamera = c.projection[e] === CameraProjection.orthographic ? new THREE.OrthographicCamera() : new THREE.PerspectiveCamera();
    attach(world, e, object);
    if (!world.has(e, CameraState)) world.add(e, CameraState);
    // The store as it is now: the adds may have grown the world.
    const s = world.store(CameraState);
    s.ours[e] = 1;
    s.projection[e] = c.projection[e]!;
    lens(e, object, c, s, aspectOf(e, c, canvasSize()));
    s.layers[e] = c.layers[e]!;
    object.layers.mask = c.layers[e]! | 0;
  };

  /** `e`'s camera made again as the other kind, where the old one was, now: a projection changed. In the frame, with the system's stores. */
  const swap = (e: Entity, c: Lens, view: { value: (THREE.Object3D | null)[] }, s: Notes, aspect: number): void => {
    const next: GameCamera = c.projection[e] === CameraProjection.orthographic ? new THREE.OrthographicCamera() : new THREE.PerspectiveCamera();
    const old = putView(world, e, next, view, world.store(ViewState).drawn);
    if (old) releaseView(world, old);
    s.projection[e] = c.projection[e]!;
    lens(e, next, c, s, aspect);
    s.layers[e] = c.layers[e]!;
    next.layers.mask = c.layers[e]! | 0;
  };

  world.onAdd(Camera, (e) => {
    if (!all.includes(e)) all.push(e);
    make(e);
  });
  world.onRemove(Camera, (e) => {
    const at = all.indexOf(e);
    if (at >= 0) all.splice(at, 1);
    if (world.alive(e) && world.has(e, CameraState) && world.store(CameraState).ours[e] === 1) {
      if (world.has(e, View)) world.remove(e, View);
      world.remove(e, ViewState);
      world.remove(e, CameraState);
    }
  });
  // An instance made, loaded or reset into its pool: each entity of it with a `Camera` and no view given its
  // camera -- a pooled one's was let go at the reset. One made with it was given its view by `onAdd` in the same
  // boundary: that add may not have landed yet, but its object is in the column already, so it is not made twice.
  world.onInstance((root) => {
    const inst = world.rawStore(Instance) as { next: ArrayLike<number> };
    const objects = world.store(View).value;
    for (let e = root as number; e !== 0; e = inst.next[e]!) {
      if (!(world.alive(e as Entity) || world.parked(e as Entity)) || !world.has(e as Entity, Camera) || world.has(e as Entity, View) || objects[e]) continue;
      make(e as Entity);
    }
  });

  world.system({
    name: 'cameras',
    phase: 'render',
    after: ['present'],
    read: [Camera],
    write: [optional(View), optional(CameraState)],
    update({ members, count, has }, [c], [view, s]) {
      const size = canvasSize();
      for (let n = 0; n < count; n++) {
        const e = members[n];
        const object = view.value[e];
        // None: a view of another's that went, or one that would not make. Made at a boundary, never here.
        if (object === null || object === undefined) continue;
        // `has` first: a reused id keeps a dead camera's row, `ours` 1 and all -- a `Render`'s mesh is no camera.
        if (!has(e, CameraState) || s.ours[e] !== 1) continue;
        const aspect = aspectOf(e, c, size);
        if (s.projection[e] !== c.projection[e]) swap(e, c, view, s, aspect);
        else {
          if (s.fov[e] !== c.fov[e] || s.size[e] !== c.size[e] || s.near[e] !== c.near[e] || s.far[e] !== c.far[e] || s.aspect[e] !== Math.fround(aspect)) lens(e, object as GameCamera, c, s, aspect);
          if (s.layers[e] !== c.layers[e]) {
            s.layers[e] = c.layers[e]!;
            object.layers.mask = c.layers[e]! | 0;
          }
        }
        unscale(view.value[e]!);
      }
    },
  });

  /** Is `e` one to draw through now. */
  const live = (e: Entity): boolean => {
    if (!world.alive(e) || !world.active(e) || !world.enabled(e, Camera)) return false;
    const object = views.value[e];
    return object !== null && object !== undefined && world.has(e, CameraState) && world.store(CameraState).ours[e] === 1;
  };

  return {
    camerasToDraw() {
      let count = 0;
      const depth = all.length > 0 ? world.store(Camera).depth : null;
      for (let i = 0; i < all.length; i++) {
        const e = all[i]!;
        if (!live(e)) continue;
        // Into place as it goes: by depth, then entity. A handful of cameras: an insertion sort, no allocation.
        let at = count++;
        while (at > 0) {
          const before = drawn[at - 1]!;
          if (depth![before]! < depth![e]! || (depth![before] === depth![e] && before < e)) break;
          drawn[at] = before;
          at--;
        }
        drawn[at] = e;
      }
      if (drawn.length !== count) drawn.length = count;
      return drawn;
    },
    main() {
      let found = 0 as Entity;
      let mains = 0;
      if (all.length === 0) return found;
      const main = world.store(Camera).main;
      for (let i = 0; i < all.length; i++) {
        const e = all[i]!;
        if (main[e] !== 1 || !live(e)) continue;
        mains++;
        if (found === 0 || e < found) found = e;
      }
      // Said once for each one found so, its words built only then: asked at every pointer event, nothing made.
      if (mains > 1 && found !== severalSaid) {
        severalSaid = found;
        say(`several cameras have main on: entity ${found}, the first, is the main one`);
      }
      return found;
    },
    object(e) {
      const object = views.value[e];
      if (object === null || object === undefined || !world.has(e, CameraState) || world.store(CameraState).ours[e] !== 1) return null;
      return object as GameCamera;
    },
    uninstall() {
      all.length = 0;
      drawn.length = 0;
    },
  };
}

/** One camera's part of a frame, in `drawPlan`: its rect in CSS pixels from the canvas's bottom left (the game's frame's corner added), and how it is cleared. */
export interface DrawStep {
  entity: Entity;
  x: number;
  y: number;
  w: number;
  h: number;
  /** `Camera.clear`: 0 none (depth alone), 1 `color`, 2 the scene's own background. */
  clear: number;
  color: number;
}

/** A frame's cameras in the order they are drawn: `steps[0..count)`, the objects reused frame to frame. */
export interface DrawPlan {
  count: number;
  readonly steps: DrawStep[];
}

/** An empty plan, to be written over by `drawPlan` each frame. */
export function newDrawPlan(): DrawPlan {
  return { count: 0, steps: [] };
}

/**
 * What `Game.drawWorld` draws, worked out: `list` (`camerasToDraw`: by depth, then entity) in that
 * order, each with its viewport rect on a frame of `width` by `height` CSS pixels and its clear; a
 * rect of no area left out. The frame's corner is `left`, `bottom` on the canvas (from its bottom
 * left, as three's viewports are: `frame.ts`), and each rect is put there -- 0, 0 for a frame that is
 * the whole canvas. Written into `plan` -- nothing allocated once it has room for as many.
 * Pure: the columns read, nothing else.
 */
export function drawPlan(list: readonly Entity[], c: Lens, width: number, height: number, plan: DrawPlan, left = 0, bottom = 0): DrawPlan {
  let count = 0;
  for (let i = 0; i < list.length; i++) {
    const e = list[i]!;
    const w = c.w[e]! * width;
    const h = c.h[e]! * height;
    if (!(w > 0 && h > 0)) continue;
    // alloc-ok: the plan grows to the most cameras ever drawn at once, then is reused.
    if (count === plan.steps.length) plan.steps.push({ entity: e, x: 0, y: 0, w: 0, h: 0, clear: 0, color: 0 });
    const step = plan.steps[count++]!;
    step.entity = e;
    step.x = left + c.x[e]! * width;
    step.y = bottom + c.y[e]! * height;
    step.w = w;
    step.h = h;
    step.clear = c.clear[e]!;
    step.color = c.clearColor[e]!;
  }
  plan.count = count;
  return plan;
}

/** The aspect of `e`'s viewport rect on a frame of `size`, width over height; 1 for a rect of no height. */
function aspectOf(e: Entity, c: Lens, size: CanvasSize): number {
  const w = c.w[e]! * size.width;
  const h = c.h[e]! * size.height;
  return w > 0 && h > 0 ? w / h : 1;
}

/** `e`'s projection onto `object` -- fov or size, near, far, the aspect -- and noted. */
function lens(e: Entity, object: GameCamera, c: Lens, s: Notes, aspect: number): void {
  if ((object as THREE.PerspectiveCamera).isPerspectiveCamera) {
    const p = object as THREE.PerspectiveCamera;
    p.fov = c.fov[e]!;
    p.aspect = aspect;
  } else {
    const o = object as THREE.OrthographicCamera;
    const half = c.size[e]!;
    o.top = half;
    o.bottom = -half;
    o.left = -half * aspect;
    o.right = half * aspect;
  }
  object.near = c.near[e]!;
  object.far = c.far[e]!;
  object.updateProjectionMatrix();
  s.fov[e] = c.fov[e]!;
  s.size[e] = c.size[e]!;
  s.near[e] = c.near[e]!;
  s.far[e] = c.far[e]!;
  s.aspect[e] = aspect;
}

/** `object`'s matrix with its three axes of unit length: the scale `present` wrote taken out. Nothing written when there is none. */
function unscale(object: THREE.Object3D): void {
  const m = object.matrix.elements;
  let fixed = false;
  for (let i = 0; i < 12; i += 4) {
    const length = Math.sqrt(m[i]! * m[i]! + m[i + 1]! * m[i + 1]! + m[i + 2]! * m[i + 2]!);
    if (length === 0 || Math.abs(length - 1) < 1e-6) continue;
    m[i] = m[i]! / length;
    m[i + 1] = m[i + 1]! / length;
    m[i + 2] = m[i + 2]! / length;
    fixed = true;
  }
  if (fixed) object.matrixWorldNeedsUpdate = true;
}
