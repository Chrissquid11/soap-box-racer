/**
 * `vibe`'s subcommands, each what the matching npm script did before the pipeline was a package
 * (Docs/packages.md §2): a table from a name to a function of the project root
 * and the arguments after the name. Defines only -- `cli.ts` is the one module that acts -- so a
 * test reads the table, and Vite loads only when a command that needs it runs.
 *
 * `dev`, `build` and `preview` call Vite's API, not a shell to `vite`: the project's Vite (the
 * peer), with the project's `vite.config.ts`, so a process manager has one entry to spawn.
 * `typecheck` runs the project's `tsc`.
 *
 * `vibe dev` has two roles while the pipeline is linked (its real path has no `node_modules`
 * segment: the workspace's link, or a `file:` or `npm link` dependency -- its own code being
 * developed). The **supervisor** runs the dev server as a child, starts a new one when the child
 * exits with `RESTART`, and waits for the next change when one fails to load. The **child** is the dev
 * server, and watches the pipeline's `src/` and the workspace's package manifests (a package's `exports` are read once, at
 * the start): a change to either ends the child with `RESTART`,
 * deferred to the end of a running Claude turn. Why a new process: the dev server restarts itself
 * when `vite.config.ts` or a file it imports by a relative path changes -- Vite bundles only those
 * with the config -- but the pipeline is a package, which the config loader leaves to node, and
 * node's module cache keeps the first copy of each module for the life of the process. A new
 * process starts from disk: the agent's conversations come back from their index and logs
 * (`agent/conversations.ts`), each resuming its session at the next Send; what was held on
 * `globalThis` (a turn's held exports) is gone, the turn having ended. A project with an installed
 * copy under `node_modules` never takes either role: its `vibe dev` is the dev server, in one process.
 */
import { spawn, spawnSync, type ChildProcess } from 'node:child_process';
import { existsSync, watch } from 'node:fs';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { EXPORT_USAGE, exportCommand } from './assets/command.ts';
import { generateKeys } from './assets/keys.ts';
import { stampUids } from './assets/stamp.ts';
import { projectKinds } from './assets/project-kinds.ts';
import { buildPacks } from './assets/packs.ts';
import { afterTurns, turnLink } from './assets/turn-hold.ts';
import { syncClaude } from './agent/sync.ts';
import { syncSkills } from './skills/install.ts';
import { checkLines, runChecks } from './checks/index.ts';
import { detectMode, type Mode } from './modes.ts';
import { NEW_USAGE } from './new/new.ts';
import { projectTsc } from './project-tsc.ts';
import { runTests } from './test-runner.ts';

/** A subcommand: the project root and the arguments after its name; the exit code. */
export type Command = (root: string, args: string[]) => Promise<number>;

export const USAGE = [
  'usage: vibe <command> [--root <dir>]',
  '  dev [--isolated] [--port <n>]   the generated files, then the dev server',
  '  build [--debug]                 typecheck, then the production (or debug) build into dist/',
  '  preview [--port <n>]            serve dist/',
  '  typecheck                       the generated files, then tsc over the project',
  '  test [folder|file...] [--packages <dir,dir>] [--no-checks]',
  '                                  every *.test.ts under each folder (default src), or a .test.ts file alone, then the checks over',
  '                                  the project (and each --packages source root); --no-checks skips them',
  '  assets [--no-stamp]             every asset given its uid, stale references repaired, then the generated files (also: keys);',
  '                                  --no-stamp writes the generated files alone (a typecheck\'s, a build\'s, a postinstall\'s)',
  '  packs                           every pack zipped into public/packs/',
  '  sync                            the package\'s Claude files (the vibe and gladius skills, the critic) into .claude/',
  '  mcp [--rotate] [--port <n>]     the running dev server\'s MCP endpoint for outside clients (/__mcp): its URL, its token and',
  '                                  the line to add it to a terminal Claude Code; --rotate makes a new token (the server takes it)',
  '  pack [--version <x.y.z>] [--out <dir>]',
  '                                  the workspace\'s packages as tarballs (published mode) into release/ -- from the engine\'s checkout;',
  '                                  --out is relative to the workspace (--root), like release/',
  `  ${NEW_USAGE}`,
  '                                  a new game from the template, in its own git repo, its packages installed -- anywhere,',
  '                                  <dir> relative to the cwd (or --root); the port pair from 5190 upward when not said',
  `  ${EXPORT_USAGE}`,
  'The project is the folder vibe runs in (npm runs a package\'s scripts in its folder), or --root.',
].join('\n');

/** `--root <dir>` anywhere in `argv`, resolved against `cwd`; the cwd when there is none. The rest, in order. */
export function parseRoot(argv: readonly string[], cwd: string = process.cwd()): { root: string; rest: string[] } {
  const rest: string[] = [];
  let root = cwd;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] !== '--root') rest.push(argv[i]!);
    else if (i + 1 < argv.length) root = resolve(cwd, argv[++i]!);
    else throw new Error('--root takes a folder');
  }
  return { root: root.replace(/(.)[\\/]$/, '$1'), rest };
}

/**
 * `vibe test`'s arguments: the folders of test files, `--packages <dir,dir>` (the extra source roots the
 * checks read -- the workspace's packages'; a project passes none) and `--no-checks` (the test files
 * only, a project debugging a test). Folders and packages are relative to the cwd, as `--root` is, so the
 * workspace's root runs the packages' tests with the sandbox as the project the checks read; the packages are
 * handed to `runChecks` absolute, so the root never re-resolves them.
 */
export function parseTestArgs(args: readonly string[], cwd: string = process.cwd()): { folders: string[]; packages: string[]; checks: boolean } {
  const folders: string[] = [];
  const packages: string[] = [];
  let checks = true;
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    if (arg === '--no-checks') checks = false;
    else if (arg === '--packages') {
      const list = args[++i];
      if (list === undefined || list.startsWith('--')) throw new Error('--packages takes folders, comma-separated');
      packages.push(...list.split(',').filter((dir) => dir !== '').map((dir) => resolve(cwd, dir)));
    } else folders.push(resolve(cwd, arg));
  }
  return { folders, packages, checks };
}

/** The value after `--port`, as a number; undefined when it is not there. */
function portArg(args: readonly string[]): number | undefined {
  const i = args.indexOf('--port');
  if (i < 0) return undefined;
  const port = Number(args[i + 1]);
  if (!Number.isInteger(port) || port <= 0) throw new Error(`--port takes a number, not ${args[i + 1] ?? 'nothing'}`);
  return port;
}

/**
 * A command that works on a project's files refuses a folder that is none: a cwd that is no project
 * would get an empty project's generated files written into it (a `src/assets/` made at the
 * workspace root, say, hidden by .gitignore).
 */
function project(command: Command): Command {
  const wrapped: Command = (root, args) => {
    if (!existsSync(join(root, 'src', 'assets'))) {
      console.error(`${root} is no project: no src/assets/ here -- run vibe from a project folder (examples/sandbox/), or with --root`);
      return Promise.resolve(2);
    }
    return command(root, args);
  };
  PROJECT_COMMANDS.add(wrapped);
  return wrapped;
}

/** The commands `project` wrapped: those that refuse a folder with no `src/assets/`. */
const PROJECT_COMMANDS = new WeakSet<Command>();

/** Does the command `name` work on a project's files, refusing a folder that is none? `new`, `sync`, `pack` and `test` do not. */
export const isProjectCommand = (name: string): boolean => COMMANDS[name] !== undefined && PROJECT_COMMANDS.has(COMMANDS[name]);

/**
 * The generated files (keys.d.ts, the globs, uids.ts): before the dev server, a typecheck and a build, and at install --
 * with the project's own kinds, read from its `vite.config.ts` (`projectKinds`: the config loaded, no server). Run by
 * hand (and at the dev server's start, the watcher's), every asset is given its uid first, a duplicate's made one
 * asset's and the references' keys kept true (`stampUids`, Docs/asset-ids.md §1 rule 6; a path in `VIBE_STAMP_SKIP`
 * left alone). `--no-stamp` -- what a typecheck, a build and a postinstall run -- only reads the assets and writes the
 * generated files: a checkout is never changed by them, so CI's `uids` check sees a committed file with no uid.
 */
const assets: Command = async (root, args) => {
  const kinds = await projectKinds(root);
  if (!args.includes(NO_STAMP)) stampUids(root, kinds);
  const wrote = generateKeys(root, kinds);
  if (process.env.npm_lifecycle_event !== 'postinstall') for (const file of wrote) console.log(file.startsWith('-') ? `[assets] removed ${file.slice(1)}` : `[assets] wrote ${file}`);
  return 0;
};

/** `vibe assets`' flag for the runs that only read: the generated files written, no file stamped or repaired. */
export const NO_STAMP = '--no-stamp';

// A typecheck (and so a build) stamps nothing: the generated files only (rule 6).
const typecheck: Command = async (root) => {
  const keys = await assets(root, [NO_STAMP]);
  if (keys !== 0) return keys;
  const tsc = projectTsc(root);
  const programs = [root, ...(existsSync(join(root, 'tsconfig.node.json')) ? [join(root, 'tsconfig.node.json')] : [])];
  for (const program of programs) {
    const run = spawnSync(process.execPath, [tsc, '--noEmit', '-p', program], { stdio: 'inherit' });
    if (run.status !== 0) return run.status ?? 1;
  }
  return 0;
};

/** The project's `vite.config.ts`. */
const configFile = (root: string): string => join(root, 'vite.config.ts');

/** This module, and the pipeline's `src/` it sits in. */
const HERE = fileURLToPath(import.meta.url);
const PIPELINE_SRC = dirname(HERE);

/**
 * The pipeline's real path has no `node_modules` segment: a link to its source (the workspace's, or a
 * `file:` or `npm link` dependency), so its own code may change under a running dev server, and
 * `vibe dev` restarts the server when it does (`supervise`, `watchPipeline`).
 */
const LINKED = !HERE.includes(`${sep}node_modules${sep}`);

/** The dev server's exit code that asks its supervisor for a new one: EX_TEMPFAIL. */
export const RESTART = 75;

/** Milliseconds a burst of saves under the pipeline is gathered for, before one restart. */
const RESTART_QUIET = 150;

/** Milliseconds between a turn's end and a restart owed to it: the replayed code's swaps fetched by the page first. */
const TURN_END_GRACE = 1000;

/** A file (relative to the pipeline's `src/`) whose change restarts the dev server: its code, `.d.ts` too -- not its tests, nor anything under a `fixtures/`. */
export const restartsFor = (file: string): boolean => file.endsWith('.ts') && !file.endsWith('.test.ts') && !file.split(/[\\/]/).includes('fixtures');

/**
 * The workspace's packages' manifests (`packages/<name>/package.json`), watched beside the pipeline's code: Vite reads a
 * package's `exports` once, when the server starts, so an entry added to the engine's (`./project-key`) is "not exported"
 * to a server that was up before it -- until a restart. The ones there are; none outside the workspace.
 */
export function packageManifests(packagesDir: string): string[] {
  return ['engine', 'editor', 'pipeline', 'studio'].map((name) => join(packagesDir, name, 'package.json')).filter((path) => existsSync(path));
}

/**
 * The pipeline's `src/` watched, and the workspace's package manifests: `changed` told once a burst of saves settles, with
 * the last file. Answers the function that stops it.
 */
function watchCode(changed: (file: string) => void): () => void {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const told = (file: string): void => {
    clearTimeout(timer);
    timer = setTimeout(() => changed(file), RESTART_QUIET);
  };
  const watcher = watch(PIPELINE_SRC, { recursive: true }, (_event, name) => {
    if (name === null || !restartsFor(String(name))) return;
    told(String(name));
  });
  const manifests = packageManifests(dirname(dirname(PIPELINE_SRC))).map((path) =>
    watch(path, () => told(relative(dirname(dirname(PIPELINE_SRC)), path).split(sep).join('/'))),
  );
  return () => {
    clearTimeout(timer);
    watcher.close();
    for (const m of manifests) m.close();
  };
}

/**
 * `vibe dev` while the pipeline is linked: the supervisor. It runs the dev server as a child
 * (`VIBE_DEV_CHILD` set) and starts another when the child exits with `RESTART`. A child that
 * exits otherwise -- a pipeline that does not load, say a typo mid-edit -- is not the end: it
 * waits, watching the pipeline's code, and starts one again at the next change. SIGINT or SIGTERM
 * to it stops the child (or the waiting) and ends.
 */
function supervise(root: string, args: readonly string[]): Promise<number> {
  // A literal `new URL`: `vibe pack` spells it `cli.js` in the published form (pack/strip.ts).
  const cli = fileURLToPath(new URL('./cli.ts', import.meta.url));
  const argv = [...process.execArgv, cli, 'dev', '--root', root, ...args];
  return new Promise((done) => {
    let child: ChildProcess | undefined;
    let stopping = false;
    /** Stops the watch while no child runs: set only between a failed child and the next change. */
    let waiting: (() => void) | undefined;
    const start = (): void => {
      const made = spawn(process.execPath, argv, { stdio: 'inherit', env: { ...process.env, VIBE_DEV_CHILD: '1' } });
      child = made;
      made.on('exit', (code, signal) => {
        child = undefined;
        if (stopping) return finish(0);
        if (code === RESTART) {
          console.log('[vibe] the dev server restarts');
          return start();
        }
        console.log(`[vibe] the dev server exited with ${code ?? signal}: waiting for the next pipeline change (Ctrl+C to stop)`);
        waiting = watchCode((file) => {
          waiting?.();
          waiting = undefined;
          console.log(`[vibe] the pipeline changed (${file}): the dev server starts again`);
          start();
        });
      });
    };
    const stop = (): void => {
      if (stopping) return;
      stopping = true;
      if (child) child.kill('SIGTERM');
      else finish(0);
    };
    const finish = (code: number): void => {
      waiting?.();
      waiting = undefined;
      process.off('SIGINT', stop);
      process.off('SIGTERM', stop);
      done(code);
    };
    process.on('SIGINT', stop);
    process.on('SIGTERM', stop);
    start();
  });
}

/**
 * The child's half: the pipeline's `src/` watched, and a change to its code ends this server with
 * `RESTART` once no Claude turn runs (`afterTurns`): at once, or when the turns end, so a pipeline
 * edit never cuts a turn off. Several changes are one restart. The agent's queued writes are done
 * before the exit.
 */
function watchPipeline(server: () => { close(): Promise<void> } | undefined): void {
  let owed = false;
  const link = turnLink();
  const restart = async (): Promise<void> => {
    stopWatching();
    await server()?.close().catch(() => {});
    await link.flushed?.().catch(() => {});
    process.exit(RESTART);
  };
  const stopWatching = watchCode((file) => {
    if (owed) return;
    owed = true;
    console.log(`[vibe] the pipeline changed (${file}): the dev server restarts${link.turns() ? ' when the turn ends' : ''}`);
    afterTurns(link, TURN_END_GRACE, () => void restart());
  });
}

/** `vibe dev`'s first line: the project's mode, and the engine's folder relative to the project (`engine/packages/engine`, `node_modules/@vibe/engine`). */
export const modeLine = (root: string, { mode, packages }: Mode): string =>
  `[vibe] ${mode} mode: the engine from ${relative(root, packages.engine).split(sep).join('/')}`;

/**
 * `vibe dev`'s studio line, under Vite's `Local:`: the editor's page, studio mode (`?studio` on the local url --
 * the plain page is the game alone). Null with no local url (a server on a host alone).
 */
export const studioLine = (local: string | undefined): string | null => (local ? `[vibe] studio: ${new URL('?studio', local).href}` : null);

const dev: Command = async (root, args) => {
  // Said once: by the supervisor, or by the one process when there is none -- never again by a child.
  if (!process.env.VIBE_DEV_CHILD) console.log(modeLine(root, detectMode(root)));
  if (LINKED && !process.env.VIBE_DEV_CHILD) return supervise(root, args);
  const keys = await assets(root, args);
  if (keys !== 0) return keys;
  const port = portArg(args);
  // The watch starts before the server is made: a save to the pipeline while the config loads and the
  // plugins come up (a second or two) is neither in this code nor missed.
  let server: { close(): Promise<void> } | undefined;
  if (LINKED) watchPipeline(() => server);
  // The project's Vite: the peer, resolved from here as from the project (in the workspace, the root's hoisted copy).
  const { createServer } = await import('vite');
  try {
    const made = await createServer({
      root,
      configFile: configFile(root),
      mode: args.includes('--isolated') ? 'isolated' : 'development',
      // A second server on the same project (--port) pre-bundles into a cache of its own: sharing
      // node_modules/.vite, each one's re-optimize rewrote the deps under the other's pages (a stale ?v= 404s).
      ...(port ? { server: { port }, cacheDir: `node_modules/.vite-${port}` } : {}),
    });
    server = made;
    await made.listen();
    made.printUrls();
    // The editor's way in, said by the server that serves it (the child under a supervisor, as `Local:` is).
    const studio = studioLine(made.resolvedUrls?.local[0]);
    if (studio) console.log(studio);
    made.bindCLIShortcuts({ print: true });
  } catch (err) {
    // A server that fails to come up (a pipeline that does not load, a port taken) may leave something
    // holding the process open -- a half-made Vite, the watch above. Out once the error line is written
    // (stderr to a pipe is asynchronous on macOS), so the supervisor sees the exit and waits for a fix.
    const line = `${err instanceof Error ? err.message : String(err)}\n`;
    await new Promise<void>((written) => process.stderr.write(line, () => written()));
    process.exit(1);
  }
  return 0;
};

/**
 * `mode: 'production'` keeps NODE_ENV production, as `vite build` does: Vite fixes NODE_ENV to
 * `production` for every build with NODE_ENV unset, whatever the mode (the config's `modeDefines`).
 */
const build: Command = async (root, args) => {
  const checked = await typecheck(root, args);
  if (checked !== 0) return checked;
  const debug = args.includes('--debug');
  const { build: viteBuild } = await import('vite');
  await viteBuild({ root, configFile: configFile(root), mode: debug ? 'debug' : 'production', ...(debug ? { build: { sourcemap: true } } : {}) });
  return 0;
};

const preview: Command = async (root, args) => {
  const port = portArg(args);
  const { preview: vitePreview } = await import('vite');
  const server = await vitePreview({ root, configFile: configFile(root), ...(port ? { preview: { port } } : {}) });
  server.printUrls();
  return 0;
};

const generated = project(assets);

/** Every subcommand by name. */
export const COMMANDS: Record<string, Command> = {
  dev: project(dev),
  build: project(build),
  preview: project(preview),
  typecheck: project(typecheck),
  test: async (root, args) => {
    const { folders, packages, checks } = parseTestArgs(args);
    const tests = runTests(folders.length > 0 ? folders : [join(root, 'src')]);
    // A folder that is not there: the usage's code, nothing run.
    if (tests === 2 || !checks) return tests;
    let result: Awaited<ReturnType<typeof runChecks>>;
    try {
      result = await runChecks({ root, packages });
    } catch (err) {
      console.error(`[checks] ${err instanceof Error ? err.message : String(err)}`);
      return 2;
    }
    for (const line of checkLines(result)) console.log(line);
    return tests !== 0 || result.findings.length > 0 ? 1 : 0;
  },
  assets: generated,
  keys: generated,
  packs: project(async (root) => {
    const index = await buildPacks(root);
    if (!Object.keys(index).length) console.log('[packs] nothing to build -- packs/ is empty.');
    return 0;
  }),
  // An export stamps too, after: a record written by it has its uid; a loose file, a data file, whatever else came, theirs.
  export: project(async (root, args) => {
    const code = await exportCommand(root, args);
    if (!args.includes('--check') && !args.includes('--dry')) stampUids(root, await projectKinds(root));
    return code;
  }),
  // Any folder, not only a project's: the workspace's root is one for a terminal session (its postinstall).
  // The package's Claude files, then the engine and studio skills from the installed packages' pages and the
  // project's tools' (Docs/skills.md §3). A page's problem is said here, and failed on by `vibe test`'s skills check.
  sync: async (root) => {
    const wrote = syncClaude(root);
    const skills = await syncSkills(root);
    const all = [...wrote, ...skills.wrote];
    for (const file of all) console.log(`[sync] wrote ${file}`);
    for (const file of skills.removed) console.log(`[sync] removed ${file}`);
    for (const note of skills.notes) console.log(`[sync] ${note}`);
    for (const p of skills.problems) console.log(`[sync] ${isAbsolute(p.file) ? relative(root, p.file) : `.claude/skills/${p.file}`}${p.line > 0 ? `:${p.line}` : ''} ${p.problem} -- vibe test fails on it`);
    console.log(`[sync] ${all.length} files`);
    return 0;
  },
  // The running dev server's /__mcp for outside clients (Docs/mcp.md M7): read off the file it keeps. Loaded when it runs.
  mcp: project(async (root, args) => (await import('./mcp/command.ts')).mcpCommand(root, args)),
  // The workspace's root (`--root`, or the cwd), not a project's: loaded when it runs (TypeScript comes with it).
  pack: async (root, args) => (await import('./pack/pack.ts')).packWorkspace(root, args, () => projectTsc(root)),
  // Anywhere: it makes the project. <dir> is relative to the cwd (or --root). Loaded when it runs.
  new: async (root, args) => (await import('./new/new.ts')).newProject(root, args),
};

/** `vibe <argv>`: the command named, or 2 and the usage. */
export async function run(argv: readonly string[], error: (line: string) => void = console.error): Promise<number> {
  const { root, rest } = parseRoot(argv);
  const [name, ...args] = rest;
  const command = name === undefined ? undefined : COMMANDS[name];
  if (!command) {
    error(USAGE);
    return 2;
  }
  return command(root, args);
}
