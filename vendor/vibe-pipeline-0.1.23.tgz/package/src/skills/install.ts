/**
 * The `engine` and `studio` skills written into a project (Docs/skills.md §3): the pages of its installed
 * `@vibe/engine` and `@vibe/editor` and of its own tool folders, collected (`pages.ts`) and written as
 * `.claude/skills/engine/` and `.claude/skills/studio/` -- a generated `SKILL.md` and one `<page>.md` each.
 *
 * - **The roots are the project's**: each package's `src/` as the project resolves it (`modes.ts`' `packageDir`:
 *   the workspace link in the sandbox and in source mode, the tarball's copy in published mode), so a project reads
 *   the pages of the version it has; then its tool folders (`vibe({ tools })`). A package not installed is said,
 *   and has no pages.
 * - **Written as `vibe sync` writes**: each file carries `SYNC_HEADER` (a page's file a second line saying where
 *   it came from, its package and version) and is overwritten whole -- only when its text changed, so the dev
 *   server's run before each turn writes nothing most of the time -- and whole (`writeWhole`: a temp file renamed
 *   over it), so a terminal's `vibe sync` and the dev server at once never leave a reader half a file. A file of the folder carrying the header that
 *   is no page now is removed; a file without it is never touched, and a folder whose `SKILL.md` is the
 *   project's own (no header) is left alone, said. A skill with no pages is not written (an empty skill is no
 *   skill): what an earlier sync wrote of it goes, and its folder with it when nothing else is in it.
 * - **Git leaves out the copies, never the project's files**: each folder written gets a `.gitignore` of its own
 *   naming exactly the files sync wrote there (`gitignoreText`), rather than a line in the project's `.gitignore`
 *   hiding the whole folder -- so a project's own skill named `engine` or `studio` (left alone, said) is committed
 *   as any other, and so is a file of its own beside the copies. A `.gitignore` there without the header is the
 *   project's: never written over (said; nothing is ignored then). A project's own skill's folder keeps everything in
 *   it -- its `SKILL.md` may link to pages an earlier sync copied -- but sync's old `.gitignore`, which would hide it.
 * - **A dead writer's temp file is swept** (`sweepTemps`) from each skill folder before it is written.
 * - **Two writers, one function**: `vibe sync` (on install) and the dev server, before each of the panel's turns
 *   (`agent/vite.ts`): the editor's Claude reads `.claude/skills/` (`settingSources: 'project'`), so a page saved
 *   in a tool folder reaches the next turn, and a changed set has the query up read its skills again.
 *
 * Nothing at module level but constants.
 */
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readdirSync, readFileSync, rmdirSync, unlinkSync } from 'node:fs';
import { join, relative, resolve, sep } from 'node:path';
import { SYNC_HEADER, sweepTemps, withHeader, writeWhole } from '../agent/sync.ts';
import { projectOptions, toolDirs } from '../assets/project-kinds.ts';
import { PACKAGES, packageDir } from '../modes.ts';
import { collectPages, skillIndex, SKILLS, type Collected, type Page, type PageRoot } from './pages.ts';

/** Where the skills go, under the project's root. */
export const SKILLS_DIR = '.claude/skills';

const posix = (path: string): string => path.split(sep).join('/');

/** A package's version, from its manifest; '' when it says none. */
function versionOf(dir: string): string {
  try {
    return String((JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as { version?: unknown }).version ?? '');
  } catch {
    return '';
  }
}

/**
 * The roots of a project's pages: the installed engine's and editor's `src/`, then each tool folder (relative to the
 * root, as `vibe({ tools })` says them) that is there. `notes`: a package not installed.
 */
export function projectRoots(root: string, tools: readonly string[] = ['src/tools']): { roots: PageRoot[]; notes: string[] } {
  const roots: PageRoot[] = [];
  const notes: string[] = [];
  for (const [owner, name] of [['engine', PACKAGES.engine], ['editor', PACKAGES.editor]] as const) {
    let dir: string | undefined;
    try {
      dir = packageDir(resolve(root), name);
    } catch (err) {
      notes.push(`${name}: ${err instanceof Error ? err.message : String(err)} -- its pages are left out`);
      continue;
    }
    if (dir === undefined) {
      notes.push(`${name} is not installed here: its pages are left out`);
      continue;
    }
    const version = versionOf(dir);
    roots.push({ dir: join(dir, 'src'), owner, from: version === '' ? name : `${name} ${version}`, base: dir });
  }
  for (const tool of tools) {
    const dir = resolve(root, tool);
    if (existsSync(dir)) roots.push({ dir, owner: 'project', from: 'the project', base: resolve(root) });
  }
  return { roots, notes };
}

/** The project's roots, its tool folders read from its config (`projectOptions`): what `vibe sync`, the dev server and the check share. */
export async function projectPageRoots(root: string): Promise<{ roots: PageRoot[]; notes: string[]; tools: readonly string[] }> {
  const tools = toolDirs((await projectOptions(root))?.tools);
  return { ...projectRoots(root, tools), tools };
}

/** A page's copy: the header, where it came from, then its body. */
export function pageCopy(page: Page): string {
  const body = page.body.replace(/^\n+/, '');
  return `${SYNC_HEADER}\n<!-- from ${page.root.from}: ${posix(relative(page.root.base, page.file))} -->\n\n${body.endsWith('\n') ? body : `${body}\n`}`;
}

/** Each skill's files as they should be: `SKILL.md` and `<page>.md`, by skill, each with its header. A skill with no pages has none: no empty skill is written. */
export function skillFiles(collected: Collected): Record<string, Map<string, string>> {
  const out: Record<string, Map<string, string>> = {};
  for (const skill of SKILLS) {
    if (collected.pages[skill].length === 0) continue;
    const files = new Map<string, string>([['SKILL.md', withHeader(skillIndex(skill, collected.pages[skill]))]]);
    for (const page of collected.pages[skill]) files.set(`${page.name}.md`, pageCopy(page));
    out[skill] = files;
  }
  return out;
}

/**
 * What a write did: the files written and removed (relative to the root), what was left alone and why, whether this
 * call changed anything -- and `digest`, the skills' text as they now are, whoever wrote them: a conversation compares
 * it with the one its query last read, so a change written by another conversation's turn, or by a terminal's `vibe
 * sync` since, reaches it too (`agent/session.ts`).
 */
export interface Installed {
  wrote: string[];
  removed: string[];
  notes: string[];
  changed: boolean;
  digest: string;
}

/** The skills' files as one hash: by skill, then by file name. */
export function skillsDigest(files: Record<string, Map<string, string>>): string {
  const hash = createHash('sha256');
  for (const skill of Object.keys(files).sort()) {
    for (const name of [...files[skill]!.keys()].sort()) hash.update(`${skill}/${name}\0${files[skill]!.get(name)}\0`);
  }
  return hash.digest('hex');
}

const read = (file: string): string | null => {
  try {
    return readFileSync(file, 'utf8');
  } catch {
    return null;
  }
};

/** The `.gitignore` sync writes in each skill's folder. */
export const GITIGNORE = '.gitignore';

/**
 * A skill folder's `.gitignore`: the header (as a comment), then itself and each file sync wrote there, anchored. Git
 * leaves out exactly the copies; a file of the project's in the folder, or a project's own skill of the name (where
 * sync writes nothing, and removes this file), is the project's to commit.
 */
export function gitignoreText(names: readonly string[]): string {
  return `# ${SYNC_HEADER}\n# The files below are vibe sync's copies, never committed; a file of your own here is git's as ever.\n${[GITIGNORE, ...[...names].sort()].map((n) => `/${n}`).join('\n')}\n`;
}

/** The collected skills written into `<root>/.claude/skills/`: see the module's comment. */
export function installSkills(root: string, collected: Collected): Installed {
  const all = skillFiles(collected);
  const done: Installed = { wrote: [], removed: [], notes: [], changed: false, digest: skillsDigest(all) };
  for (const skill of SKILLS) {
    // No pages: nothing written, and what an earlier sync wrote goes (below) -- an empty skill is no skill.
    const files = all[skill] ?? new Map<string, string>();
    const dir = join(root, SKILLS_DIR, skill);
    // A temp file a killed sync left (its pid dead) goes first, whoever's folder this is: it is sync's, never the project's.
    for (const name of sweepTemps(dir)) {
      done.removed.push(`${SKILLS_DIR}/${skill}/${name}`);
      done.changed = true;
    }
    const index = read(join(dir, 'SKILL.md'));
    if (index !== null && !index.includes(SYNC_HEADER)) {
      // The folder is the project's now (its SKILL.md has no header): nothing in it is removed -- its SKILL.md may link
      // to the pages an earlier sync copied there -- but sync's own .gitignore, which would hide the project's
      // SKILL.md and those pages from git.
      const ignore = join(dir, GITIGNORE);
      const gone = (read(ignore) ?? '').includes(SYNC_HEADER);
      if (gone) {
        unlinkSync(ignore);
        done.removed.push(`${SKILLS_DIR}/${skill}/${GITIGNORE}`);
        done.changed = true;
      }
      if (files.size > 0 || gone) {
        done.notes.push(
          `${SKILLS_DIR}/${skill}/ is the project's own skill (its SKILL.md has no vibe sync header): left as it is${files.size > 0 ? `, the ${skill} pages not written` : ''}${gone ? `; vibe sync's old ${GITIGNORE} there removed, so git sees the folder -- any page an earlier sync copied there stays, now the project's` : ''}`,
        );
      }
      continue;
    }
    if (files.size === 0 && !existsSync(dir)) continue;
    mkdirSync(dir, { recursive: true });
    const ours: string[] = [];
    for (const [name, text] of files) {
      const file = join(dir, name);
      const was = read(file);
      if (was !== null && !was.includes(SYNC_HEADER)) {
        done.notes.push(`${SKILLS_DIR}/${skill}/${name} is no vibe sync copy: left as it is`);
        continue;
      }
      if (was !== text) {
        writeWhole(file, text);
        done.changed = true;
      }
      done.wrote.push(`${SKILLS_DIR}/${skill}/${name}`);
      ours.push(name);
    }
    // The folder's own .gitignore, naming exactly the files written: a file of the project's beside them stays git's.
    // Only one of sync's own (with the header) is written over: a .gitignore of the project's there stays as it is,
    // said, and nothing is ignored for it.
    let ignoreOurs = false;
    if (ours.length > 0) {
      const ignore = gitignoreText(ours);
      const was = read(join(dir, GITIGNORE));
      if (was !== null && !was.includes(SYNC_HEADER)) {
        done.notes.push(`${SKILLS_DIR}/${skill}/${GITIGNORE} is the project's own (no vibe sync header): left as it is, so git is not told to leave out the copies there`);
      } else {
        ignoreOurs = true;
        if (was !== ignore) {
          writeWhole(join(dir, GITIGNORE), ignore);
          done.changed = true;
        }
      }
    }
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      // Another writer's temp file (`writeWhole`) is its own to rename: never taken from under it.
      if (!entry.isFile() || files.has(entry.name) || (ignoreOurs && entry.name === GITIGNORE) || /^\..*\.tmp$/.test(entry.name)) continue;
      const text = read(join(dir, entry.name));
      if (text === null || !text.includes(SYNC_HEADER)) continue;
      unlinkSync(join(dir, entry.name));
      done.removed.push(`${SKILLS_DIR}/${skill}/${entry.name}`);
      done.changed = true;
    }
    // An emptied folder of ours goes too; one with anything of the project's in it stays.
    if (files.size === 0 && readdirSync(dir).length === 0) rmdirSync(dir);
  }
  return done;
}

/** `vibe sync`'s and the dev server's one call: the project's pages collected and written. The problems are the check's to fail on; here they are said. */
export async function syncSkills(root: string, tools?: readonly string[]): Promise<Installed & { problems: Collected['problems'] }> {
  const { roots, notes } = tools === undefined ? await projectPageRoots(root) : projectRoots(root, tools);
  const collected = collectPages(roots);
  const done = installSkills(root, collected);
  return { ...done, notes: [...notes, ...done.notes], problems: collected.problems };
}
