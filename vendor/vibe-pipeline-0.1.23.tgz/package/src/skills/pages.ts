/**
 * The skill pages (Docs/skills.md §3): a `<name>.skill.md` beside the code it is about, in a package's `src/` or a
 * project's tool folder, put together into the `engine` and `studio` skills. This module reads them and says what is
 * wrong with them; `install.ts` writes the skills, `checks/skills.ts` holds them to the catalogue.
 *
 * - **A page**: Markdown under a frontmatter block -- `skill` (`engine` | `studio`), `title`, `when` (one line, which
 *   goes in the skill's index), `covers` (`tools: [...]` for a studio page, the MCP tools it is about; `modules:
 *   [...]` for an engine page, paths under its package's `src/`), and `order` (the index's, lowest first; 100 when not
 *   said). Lists are written `[a, b]` or as `- a` lines under the key. Its file name, less `.skill.md`, is its name:
 *   lowercase words joined by `-`, once in its skill.
 * - **Links** go from page to page by file name: `[the scene](scene.md)` in the same skill, `../engine/ecs.md` into
 *   the other, `SKILL.md` to the index; a web link is anyone's. Any other relative link goes nowhere once the pages
 *   are copied into `.claude/skills/`, so it is a problem.
 * - **Never the engine's `Docs/`** (`docsMentions`): a project installed from the tarballs has no `Docs/`, and the docs
 *   are plans and ledgers, not the how -- so a mention of `Docs/` in a page's body or its `when`, a link or not, is a
 *   problem (a relative link there is said once, as the link that goes nowhere). The `skills` check holds the synced
 *   skills (`vibe`, `gladius`) to the same.
 * - **Limits**: a page at most `PAGE_LINES` lines (it is read whole when it is read); a skill's `SKILL.md` at most
 *   `INDEX_LINES` (its description is in every turn's context, its index read before any page).
 * - **The walk** skips `node_modules`, dot folders and `fixtures/` (which `vibe pack` leaves out too).
 *
 * Pure but for reading the folders it is given. Nothing at module level but constants.
 */
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { basename, join } from 'node:path';

/** The skills pages join, in the order `vibe sync` writes them. */
export const SKILLS = ['engine', 'studio'] as const;
export type SkillName = (typeof SKILLS)[number];

/** A page's file ends so. */
export const PAGE_SUFFIX = '.skill.md';
/** The most lines a page may have, frontmatter and all. */
export const PAGE_LINES = 400;
/** The most lines a generated `SKILL.md` may have. */
export const INDEX_LINES = 80;
/** A page's `order` when it says none. */
export const ORDER = 100;

/** A page's name: its file's, less the suffix. */
const NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
/** An MCP tool's name, as a studio page covers it (`scene_query`, `project_tiles_paint`). */
const TOOL = /^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$/;

/** What each skill is, at the top of its generated `SKILL.md`: its description, then the lines over its index. */
export const ABOUT: Record<SkillName, { title: string; description: string; intro: string[] }> = {
  engine: {
    title: 'The engine',
    description: 'How to make a game on @vibe/engine, a page per engine system (the ECS, the loop, prefabs, rendering, assets, UI, ...): what it is, how to do the common jobs, the rules that bite, an example to copy. Load it before writing or changing gameplay, and read the one page the task needs.',
    intro: [
      'How each system of the engine is used to make a game, one page a system, each from the engine version this',
      'project has installed. The rules that are easy to break are the `vibe` skill; these pages are the how.',
      "The engine's code is always there to read: `node_modules/@vibe/engine/src/`.",
    ],
  },
  studio: {
    title: 'The studio',
    description: "How to drive the Squidwright studio's editors through its MCP tools (mcp__studio__*), a page per editor: a whole job done with the tools, read first then act, one step Z undoes, what a refusal means. Load it before working in the scene, the assets, the Model tab, a playtest or the code through the studio.",
    intro: [
      "How to do a whole job in the studio's editors through its MCP tools (`mcp__studio__*`), one page an editor,",
      "each from the editor version this project has installed (and the project's own tools' pages beside them).",
      "A tool's own description says what it does; a page says how the tools make a job.",
    ],
  },
};

/** Where pages are looked for: a folder, and whose it is -- said in each page's copy. */
export interface PageRoot {
  dir: string;
  /** `engine` and `editor`, the installed packages' `src/`; `project`, one of its tool folders. */
  owner: 'engine' | 'editor' | 'project';
  /** Whose words, in a copy's header: `@vibe/engine 0.1.12`, `the project`. */
  from: string;
  /** The folder the header names a page's file from: the package's, or the project's root. */
  base: string;
}

/** A page read. */
export interface Page {
  name: string;
  skill: SkillName;
  title: string;
  when: string;
  tools: string[];
  modules: string[];
  order: number;
  /** The text after the frontmatter. */
  body: string;
  /** The 1-based line the body starts on in the file. */
  bodyLine: number;
  /** The file, absolute. */
  file: string;
  root: PageRoot;
  /** Each frontmatter key's 1-based line, and each listed name's (`tools:scene_query`), for a finding. */
  lines: Record<string, number>;
}

/** Something wrong with a page, or a skill's index: the file (absolute; a skill's `SKILL.md` as `<skill>/SKILL.md`), the line, what, and what to do. */
export interface PageProblem {
  file: string;
  line: number;
  problem: string;
  fix: string;
}

/** A value of the frontmatter: one, or a list. */
type Value = string | string[];

const unquote = (value: string): string => {
  const v = value.trim();
  return v.length >= 2 && (v[0] === '"' || v[0] === "'") && v.at(-1) === v[0] ? v.slice(1, -1) : v;
};

/** `[a, b]` as its items; anything else as one string. */
function scalarOrList(raw: string): Value {
  const v = raw.trim();
  if (v.startsWith('[') && v.endsWith(']')) return v.slice(1, -1).split(',').map(unquote).filter((item) => item !== '');
  return unquote(v);
}

const FORMAT = 'a page opens with `---`, then `skill: engine` or `skill: studio`, `title:`, `when:`, `covers:` (`  tools: [...]` or `  modules: [...]`), an optional `order:`, then `---`';

/** A page's text read: the page, or what is wrong with it. `name` and `root` as the collector has them. */
export function parsePage(text: string, file: string, name: string, root: PageRoot): { page: Page | null; problems: PageProblem[] } {
  const problems: PageProblem[] = [];
  const say = (line: number, problem: string, fix: string): void => void problems.push({ file, line, problem, fix });
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  if (!NAME.test(name)) say(1, `"${name}" is no page name`, `name the file lowercase words joined by - and ending ${PAGE_SUFFIX} (scene${PAGE_SUFFIX})`);
  if (lines.length > PAGE_LINES) say(PAGE_LINES + 1, `the page is ${lines.length} lines: at most ${PAGE_LINES}`, 'split it into two pages linked by file name, or cut what a game maker does not need');
  if (lines[0]?.trim() !== '---') {
    say(1, 'no frontmatter', FORMAT);
    return { page: null, problems };
  }
  const end = lines.indexOf('---', 1);
  if (end < 0) {
    say(1, 'the frontmatter is never closed', FORMAT);
    return { page: null, problems };
  }
  const top: Record<string, Value> = {};
  const covers: Record<string, Value> = {};
  const at: Record<string, number> = {};
  /** The key a `- item` line adds to: top level or under covers. */
  let open: { into: Record<string, Value>; key: string } | null = null;
  for (let i = 1; i < end; i++) {
    const line = lines[i]!;
    const n = i + 1;
    if (line.trim() === '' || line.trim().startsWith('#')) continue;
    const item = /^\s*-\s+(.*)$/.exec(line);
    if (item) {
      const list = open ? open.into[open.key] : undefined;
      if (!open || !Array.isArray(list)) {
        say(n, 'a list item under no list', FORMAT);
        continue;
      }
      list.push(unquote(item[1]!));
      at[`${open.key}:${unquote(item[1]!)}`] = n;
      continue;
    }
    const nested = /^\s+([a-z]+)\s*:\s*(.*)$/.exec(line);
    if (nested) {
      if (!('covers' in top)) {
        say(n, `"${nested[1]}" is indented under no key`, FORMAT);
        continue;
      }
      const [, key, raw] = nested;
      if (key !== 'tools' && key !== 'modules') {
        say(n, `covers has no "${key}"`, '`covers:` takes `tools:` (a studio page) or `modules:` (an engine page)');
        continue;
      }
      covers[key] = raw!.trim() === '' ? [] : scalarOrList(raw!);
      at[key] = n;
      open = raw!.trim() === '' ? { into: covers, key } : null;
      if (Array.isArray(covers[key])) for (const name of covers[key]) at[`${key}:${name}`] ??= n;
      continue;
    }
    const pair = /^([a-z]+)\s*:\s*(.*)$/.exec(line);
    if (!pair) {
      say(n, `"${line.trim()}" is no key: value`, FORMAT);
      continue;
    }
    const [, key, raw] = pair;
    if (!['skill', 'title', 'when', 'covers', 'order'].includes(key!)) {
      say(n, `"${key}" is no key of a page`, FORMAT);
      continue;
    }
    if (key in top) say(n, `"${key}" is said twice`, 'say each key once');
    top[key!] = key === 'covers' ? '' : raw!.trim() === '' ? [] : scalarOrList(raw!);
    at[key!] = n;
    open = key !== 'covers' && raw!.trim() === '' ? { into: top, key: key! } : null;
  }
  const text1 = (key: string): string => (typeof top[key] === 'string' ? (top[key] as string).trim() : '');
  const skill = text1('skill');
  if (!(SKILLS as readonly string[]).includes(skill)) say(at.skill ?? 1, skill === '' ? 'no skill' : `"${skill}" is no skill`, 'skill: engine (making a game: an engine system) or skill: studio (driving an editor through its MCP tools)');
  const title = text1('title');
  if (title === '') say(at.title ?? 1, 'no title', 'title: what the page is about, a few words (The scene)');
  const when = text1('when');
  if (when === '') say(at.when ?? 1, 'no when', "when: one line saying when to read the page -- it is the page's line in the skill's index");
  else if (when.length > 240) say(at.when!, `when is ${when.length} characters: at most 240`, 'one short line: the index is read before any page');
  let order = ORDER;
  if ('order' in top) {
    order = Number(text1('order'));
    if (!Number.isInteger(order)) {
      say(at.order!, `order "${text1('order')}" is no whole number`, 'order: a whole number, lowest first in the index (100 when not said)');
      order = ORDER;
    }
  }
  const list = (key: 'tools' | 'modules'): string[] => {
    const v = covers[key];
    return v === undefined ? [] : Array.isArray(v) ? v : [v];
  };
  const tools = list('tools');
  const modules = list('modules');
  if (!('covers' in top)) say(1, 'no covers', skill === 'engine' ? "covers: with modules: [the folders and files under the package's src/ the page is about]" : 'covers: with tools: [the MCP tools the page is about]');
  else if (skill === 'studio') {
    if (!('tools' in covers)) say(at.covers!, "a studio page's covers has no tools", 'covers: with tools: [the MCP tools the page is about] -- every tool it explains');
    if ('modules' in covers) say(at.modules!, 'a studio page covers tools, not modules', 'take modules out: an engine page names modules');
  } else if (skill === 'engine') {
    if (!('modules' in covers)) say(at.covers!, "an engine page's covers has no modules", "covers: with modules: [paths under the package's src/: ecs/, render.ts]");
    if ('tools' in covers) say(at.tools!, 'an engine page covers modules, not tools', 'take tools out: a studio page names MCP tools');
  }
  for (const tool of tools) if (!TOOL.test(tool)) say(at[`tools:${tool}`] ?? at.tools ?? 1, `"${tool}" is no tool name`, 'a tool as the catalogue names it, bare: scene_query (not mcp__studio__scene_query)');
  for (const module of modules) {
    if (module === '' || module.startsWith('/') || module.split('/').includes('..')) say(at[`modules:${module}`] ?? at.modules ?? 1, `"${module}" is no module path`, "a path under the package's src/, relative: ecs/ or render.ts");
  }
  const body = lines.slice(end + 1).join('\n');
  if (body.trim() === '') say(end + 2, 'the page has no body', 'write the page under the frontmatter');
  problems.sort((a, b) => a.line - b.line);
  if (problems.length > 0 && (!(SKILLS as readonly string[]).includes(skill) || title === '' || when === '' || !('covers' in top))) return { page: null, problems };
  return {
    page: { name, skill: skill as SkillName, title, when, tools, modules, order, body, bodyLine: end + 2, file, root, lines: at },
    problems,
  };
}

/** Every page file under `dir`, absolute, in name order: no `node_modules`, dot folders or `fixtures/`. */
export function pageFiles(dir: string): string[] {
  if (!existsSync(dir)) return [];
  const out: string[] = [];
  const entries = readdirSync(dir, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1));
  for (const entry of entries) {
    if (entry.name.startsWith('.') || entry.name === 'node_modules' || entry.name === 'fixtures') continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...pageFiles(full));
    else if (entry.name.endsWith(PAGE_SUFFIX)) out.push(full);
  }
  return out;
}

/** A Markdown link's target in a line: `[x](target)` or `[x](target "title")`. */
const LINK = /\]\(\s*([^)\s]+)(?:\s+"[^"]*")?\s*\)/g;

/** Where the engine's docs are named: `Docs/`, alone or in a path (`engine/Docs/`, a web link's). */
const DOCS = /(?:^|[^A-Za-z0-9_])Docs\//;

/** The 1-based lines of `text` that name the engine's `Docs/` (the module's comment): a page's body, a synced skill. */
export function docsMentions(text: string): number[] {
  const out: number[] = [];
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) if (DOCS.test(lines[i]!)) out.push(i + 1);
  return out;
}

/** What to do about a mention of `Docs/`: shared with the `skills` check's finding for a synced skill. */
export const DOCS_FIX = "say it here, in the page's own words, or link the page that does (`assets.md`, `../studio/scene.md`); name code by its file (`node_modules/@vibe/engine/src/...`) -- a project has no `Docs/`";

/** A page's mentions of `Docs/`, each a problem at its line -- but a line whose link to it is already said to go nowhere. */
function docsProblems(page: Page, linked: readonly PageProblem[]): PageProblem[] {
  const said = new Set(linked.filter((p) => p.file === page.file && p.problem.includes('Docs/')).map((p) => p.line));
  const out: PageProblem[] = [];
  if (DOCS.test(page.when)) out.push({ file: page.file, line: page.lines.when ?? 1, problem: 'the when line names Docs/', fix: DOCS_FIX });
  for (const n of docsMentions(page.body)) {
    const line = page.bodyLine + n - 1;
    if (!said.has(line)) out.push({ file: page.file, line, problem: 'the page names Docs/, which a project does not have', fix: DOCS_FIX });
  }
  return out;
}

/** A page's links that go nowhere once copied: each a problem at its line. */
function linkProblems(page: Page, names: Record<SkillName, Set<string>>): PageProblem[] {
  const out: PageProblem[] = [];
  const lines = page.body.split('\n');
  let fenced = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    if (/^\s*(```|~~~)/.test(line)) fenced = !fenced;
    if (fenced) continue;
    for (const match of line.matchAll(LINK)) {
      const target = match[1]!;
      if (/^[a-z][a-z0-9+.-]*:/i.test(target) || target.startsWith('#')) continue;
      const path = target.split('#')[0]!;
      const to = /^(?:\.\.\/(engine|studio)\/)?([a-z0-9-]+|SKILL)\.md$/.exec(path);
      const skill = (to?.[1] as SkillName | undefined) ?? page.skill;
      if (to && (to[2] === 'SKILL' || names[skill].has(to[2]!))) continue;
      out.push({
        file: page.file,
        line: page.bodyLine + i,
        problem: `the link to ${target} goes nowhere`,
        fix: `link a page by its file name -- [the scene](scene.md), [the ECS](../engine/ecs.md) in the other skill -- or name a file in code (\`node_modules/@vibe/engine/src/...\`), never a path the copied page cannot reach`,
      });
    }
  }
  return out;
}

/** A skill's generated `SKILL.md` (no header: `install.ts` adds it): its frontmatter, what it is, then each page's line. */
export function skillIndex(skill: SkillName, pages: readonly Page[]): string {
  const about = ABOUT[skill];
  const out = ['---', `name: ${skill}`, `description: ${JSON.stringify(about.description)}`, '---', '', `# ${about.title}`, '', ...about.intro, ''];
  if (pages.length === 0) out.push('No pages yet.');
  else {
    out.push('Read only the page the task needs: each is a file beside this one.', '');
    for (const page of pages) out.push(`- [${page.title}](${page.name}.md) -- ${page.when}`);
  }
  out.push('');
  return out.join('\n');
}

/** The pages of a skill in the index's order: by `order`, then name. */
export const ordered = (pages: readonly Page[]): Page[] => [...pages].sort((a, b) => a.order - b.order || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));

/** What the collector found: each skill's pages, ordered, and every problem -- a page with one that makes it unreadable left out, a name's second page too. */
export interface Collected {
  pages: Record<SkillName, Page[]>;
  problems: PageProblem[];
}

/** Every page under the roots, read and checked: the skills' pages and the problems. */
export function collectPages(roots: readonly PageRoot[]): Collected {
  const problems: PageProblem[] = [];
  const pages: Record<SkillName, Page[]> = { engine: [], studio: [] };
  for (const root of roots) {
    for (const file of pageFiles(root.dir)) {
      const name = basename(file).slice(0, -PAGE_SUFFIX.length);
      const read = parsePage(readFileSync(file, 'utf8'), file, name, root);
      problems.push(...read.problems);
      if (!read.page) continue;
      const first = pages[read.page.skill].find((p) => p.name === name);
      if (first) {
        problems.push({ file, line: 1, problem: `a second page named ${name} in the ${read.page.skill} skill (the first: ${first.file})`, fix: 'rename one: a page is its file name, once in its skill' });
        continue;
      }
      pages[read.page.skill].push(read.page);
    }
  }
  const names = { engine: new Set(pages.engine.map((p) => p.name)), studio: new Set(pages.studio.map((p) => p.name)) };
  for (const skill of SKILLS) {
    pages[skill] = ordered(pages[skill]);
    for (const page of pages[skill]) {
      const links = linkProblems(page, names);
      problems.push(...links, ...docsProblems(page, links));
    }
    const index = skillIndex(skill, pages[skill]).split('\n').length;
    if (index > INDEX_LINES) problems.push({ file: `${skill}/SKILL.md`, line: 0, problem: `the ${skill} skill's index is ${index} lines: at most ${INDEX_LINES}`, fix: "shorten the pages' when lines, or fold pages together" });
  }
  return { pages, problems };
}
