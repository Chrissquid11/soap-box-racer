/**
 * A project's own dev-server routes (`vibe({ routes })`, Docs/squidwright-implementation.md 1.11): a
 * route `{ name, handler }` answers every request under `/__tools/<name>/`, as the assets server answers
 * `/__assets/` -- mounted on Vite's own middleware stack (after its CORS and host checks, before its
 * transforms), in the dev server alone: a build has no routes.
 *
 * - **Through the pipeline's guards** (`assets/http.ts`): a mutating request -- any method but GET and
 *   HEAD -- from this machine only, from this server's own page if from a page at all, and a POST as
 *   JSON (`guardWrite`); a refusal the handler throws as `Refused` is answered with the status it names,
 *   anything else `500` with its message. A path the handler writes is the handler's to check
 *   (`checkPath`: under the folders it names, nothing leading out by a link).
 * - **What the handler is handed** (`ToolContext`): the project's root, the path after
 *   `/__tools/<name>/` (`save` for `/__tools/tiles/save?x=1`), and `push(message)`, which sends
 *   `{ type: 'tool', kind: 'vibe:tool:<name>', tool: <name>, message }` to every page through the assets
 *   push channel -- the websocket the assets server holds, reached through the link the two share
 *   (`TurnLink.send`) -- where the editor's `Live` fires `tool(name, message)` (`assets/live.ts`).
 *
 * `toolsHandler` is the plumbing, Node's own `http` types and nothing of Vite's, so `tools.test.ts`
 * runs it on a bare `http.createServer`; `toolRoutes` is the plugin. Nothing at module level.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Plugin } from 'vite';
import type { PushMessage } from '../assets/api-types.ts';
import { Refused, drain, guardHost, guardWrite, mutating, sendJson, allowedHosts } from '../assets/http.ts';
import { PUSH_EVENT } from '../assets/kinds.ts';
import type { TurnLink } from '../assets/turn-hold.ts';

/** What a route's handler is handed besides the request and the answer. */
export interface ToolContext {
  /** The project's root, absolute. */
  root: string;
  /** The path after `/__tools/<name>/`, without the query: `save`; `''` for the route's own folder. */
  path: string;
  /** A message to every page, as `{ type: 'tool', kind: 'vibe:tool:<name>', tool: <name>, message }` on the assets push channel. */
  push(message: unknown): void;
}

/** A route of the project's own: `/__tools/<name>/…` answered by `handler`. */
export interface ToolRoute {
  /** Its folder under `/__tools/`: lowercase letters, digits and dashes. */
  name: string;
  handler(req: IncomingMessage, res: ServerResponse, ctx: ToolContext): Promise<void>;
}

/** Where the routes are mounted. */
export const TOOLS_PREFIX = '/__tools/';

/** What the routes are run with: the root, the port a refusal names, and the channel a push goes out on. */
export interface ToolsOptions {
  root: string;
  port?: () => number | undefined;
  /** This server's `server.allowedHosts` (`assets/http.ts`' `allowedHosts`): `Host` names trusted beside this machine's. None: none. */
  hosts?: () => readonly string[];
  /** One message to every page, already wrapped (`{ type: 'tool', ... }`). */
  send(message: PushMessage): void;
}

/** A route's name: a folder of a URL, said plainly. */
const NAME = /^[a-z0-9][a-z0-9-]*$/;

/** The routes checked: each name a plain folder, none twice. Throws naming every problem. */
export function checkRoutes(routes: readonly ToolRoute[]): void {
  const problems: string[] = [];
  const seen = new Set<string>();
  for (const route of routes) {
    if (!NAME.test(route.name)) problems.push(`vibe({ routes }): '${route.name}' is no route's name -- lowercase letters, digits and dashes (it is /__tools/<name>/)`);
    else if (seen.has(route.name)) problems.push(`vibe({ routes }): two routes are called '${route.name}'`);
    seen.add(route.name);
    if (typeof route.handler !== 'function') problems.push(`vibe({ routes }): '${route.name}' has no handler`);
  }
  if (problems.length > 0) throw new Error(problems.join('\n'));
}

/**
 * A request under `/__tools/` answered by its route; false for anything else (the next middleware's).
 * A name no route has is `404`, as JSON.
 */
export function toolsHandler(routes: readonly ToolRoute[], options: ToolsOptions): (req: IncomingMessage, res: ServerResponse) => Promise<boolean> {
  checkRoutes(routes);
  const byName = new Map(routes.map((route) => [route.name, route]));
  return async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost');
    if (!url.pathname.startsWith(TOOLS_PREFIX)) return false;
    const rest = url.pathname.slice(TOOLS_PREFIX.length);
    const slash = rest.indexOf('/');
    const name = slash < 0 ? rest : rest.slice(0, slash);
    const path = slash < 0 ? '' : rest.slice(slash + 1);
    try {
      const allowed = options.hosts?.() ?? [];
      guardHost(req, allowed);
      const route = byName.get(name);
      if (!route) throw new Refused(404, `no route /__tools/${name}/ here${byName.size ? `: ${[...byName.keys()].join(', ')}` : ' -- a project adds one with vibe({ routes })'}`);
      if (mutating(req)) guardWrite(req, options.port?.(), allowed);
      const push = (message: unknown): void => options.send({ type: 'tool', kind: `vibe:tool:${name}`, tool: name, message });
      await route.handler(req, res, { root: options.root, path, push });
      if (!res.writableEnded && !res.headersSent) sendJson(res, 500, { refused: `/__tools/${name}/${path} answered nothing` });
    } catch (err) {
      if (res.headersSent || res.destroyed) {
        res.destroy();
      } else if (err instanceof Refused) {
        await drain(req);
        sendJson(res, err.status, err.body);
      } else {
        console.error(`[tools] /__tools/${name}/${path}:`, err);
        sendJson(res, 500, { refused: (err as Error).message });
      }
    }
    return true;
  };
}

/**
 * The plugin: the project's routes on the dev server, their pushes on the assets channel. The assets
 * server puts its `send` on the link as it is made (`server.ts`); before it has -- or with no assets
 * plugin at all -- a push goes straight out on Vite's socket, under the same event.
 */
export function toolRoutes(routes: readonly ToolRoute[], options: { link?: TurnLink } = {}): Plugin {
  checkRoutes(routes);
  return {
    name: 'tool-routes',
    apply: 'serve',
    configureServer(server) {
      if (routes.length === 0) return;
      const handle = toolsHandler(routes, {
        root: server.config.root,
        port: () => server.config.server.port,
        hosts: () => allowedHosts(server.config.server?.allowedHosts),
        send: (message) => (options.link?.send ?? ((data: PushMessage) => server.ws.send({ type: 'custom', event: PUSH_EVENT, data })))(message),
      });
      server.middlewares.use((req, res, next) => {
        handle(req, res).then((handled) => {
          if (!handled) next();
        }, next);
      });
    },
  };
}
