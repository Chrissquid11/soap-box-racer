/**
 * `vibe new <dir>` (Docs/packages.md §7): a new game from the template -- the
 * smallest project that boots, draws one model, runs one system and opens in the editor.
 *
 * The template is the pipeline's own `template/` (beside `src/`, and beside `dist/` in the published
 * form, where `vibe pack` copies it: `../../template` holds from `dist/new/new.js` as from here), so a
 * project made from an installed pipeline gets the template of that version. In it:
 *
 * - **Names**: a project may have any name (`--name`, "Chicken Golf", "Kalle's Kart"): the name as typed is its
 *   **display name** -- `package.json`'s `"displayName"` (npm ignores the field), the page's `<title>`, `boot()`'s `title`,
 *   the README's and CLAUDE.md's heading -- and its **npm name** (`package.json`'s `name`, `boot()`'s `name`: the
 *   settings' key) is derived from it (`npmName`: "chicken-golf", "kalles-kart") unless `--package` says one, which
 *   is checked against npm's rule (`NAME`). The folder is the argument as given; the launcher makes it from the name
 *   with `folderName`. With no `--name` the display name is the folder's own.
 * - **Placeholders**: `__NAME__` (the npm name), `__TITLE__` (the display name, escaped for the file it lands in:
 *   HTML in a `.html`, a string's in a `.ts`/`.js`/`.json`, as it is elsewhere), `__PORT__`, `__PREVIEW_PORT__` (`port - 1000`, as `vibe()` takes it),
 *   `__DEBUG_PORT__` (`port + 4032`, `DEBUG_PORT_OFFSET`: "Studio (dev)"'s Chrome debugging port, the dev server's
 *   debugger's, Docs/studio.md §11) and `__VERSION__`, filled in every text file; a file with a NUL byte (the model, the font) is
 *   binary and copied as it is. One left anywhere afterwards is an error, never a project.
 * - **`gitignore`**, not `.gitignore`: npm leaves a `.gitignore` out of a tarball, so the template
 *   carries it without the dot and the copy is renamed.
 * - **Uids made anew**: the template's assets carry their uids (Docs/asset-ids.md), and each project's are its own --
 *   every one replaced in the copy, every reference to one with it (`restampUids`).
 *
 * The three `@vibe/*` dependencies are written by mode:
 *
 * - `--submodule <url>`: source mode, the engine a git submodule at `engine/` (`git submodule add`),
 *   each package `file:./engine/packages/<p>` -- a person's own games;
 * - `--source <path>`: source mode on a checkout of the engine's beside it, `file:<path>/packages/<p>`,
 *   the path as given, read relative to the project;
 * - `--tarballs <dir>`: published mode, the three tarballs `vibe pack` writes copied into `vendor/`,
 *   each `file:./vendor/<tarball>` -- the studio's way, and CI's;
 * - none of them: this pipeline's own version as a caret range -- with `--no-install` only, since it
 *   resolves nowhere until the packages are on a registry: with the install on, the command line is
 *   refused (exit 2), naming the three flags that work today.
 *
 * Then `git init`, `git lfs install --local` (the `.gitattributes` rules want it), `--lfsconfig`'s file
 * as `.lfsconfig` (none by default: a game for someone else points at their LFS server, not ours),
 * `npm install` streamed (its postinstall runs `vibe assets --no-stamp && vibe sync`) unless `--no-install`, and
 * the first commit -- the person's own, no trailers.
 *
 * **Idempotent on a failure**: once anything is written, an error removes what `vibe new` made -- the
 * folder, when it made the folder; the folder's contents, when it was there and empty -- and says
 * why. Never anything it did not make. Exit 2 for what the command line got wrong (checked before
 * anything is written), 1 for a step that failed.
 *
 * Defines only: `commands.ts` reads `NEW_USAGE` for its usage, and calls `newProject` when `new` runs.
 */
import { spawn, spawnSync, type SpawnSyncOptions } from 'node:child_process';
import { copyFileSync, cpSync, existsSync, mkdirSync, readdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:net';
import { basename, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { PACKAGES } from '../modes.ts';
import { DEBUG_PORT_OFFSET } from '../studio/api-types.ts';
import { fromNpmScript } from '../agent/env.ts';
import { npmSpawn } from '../npm.ts';
import { restampUids } from '../assets/stamp.ts';

/** The template's folder: the pipeline's `template/`. */
export const TEMPLATE = fileURLToPath(new URL('../../template', import.meta.url));

/** The pipeline's own manifest: its version is the default range's. */
const OWN_MANIFEST = fileURLToPath(new URL('../../package.json', import.meta.url));

export const NEW_USAGE =
  'new <dir> [--name <any name>] [--package <npm name>] [--port <port>] [--source <path> | --submodule <url> | --tarballs <dir>] [--lfsconfig <file>] [--no-install]';

/** The first commit's message: the person's own commit. */
export const FIRST_COMMIT = 'A Squidwright game, from vibe new';

/** The first port the default probe tries; the pair is it and `port - 1000`, and the next candidate two up. */
export const FIRST_PORT = 5190;

/** A project's npm name (`--package`, `package.json`'s `name`): lowercase letters, digits and dashes, not a dash first -- a valid npm name. */
export const NAME = /^[a-z0-9][a-z0-9-]{0,213}$/;

/** A placeholder left in a file: what the fill missed. */
const PLACEHOLDER = /__(?:NAME|TITLE|PORT|PREVIEW_PORT|DEBUG_PORT|VERSION)__/;

/** Where the three packages come from. */
export type Source =
  | { kind: 'version' }
  | { kind: 'source'; path: string }
  | { kind: 'submodule'; url: string }
  | { kind: 'tarballs'; dir: string };

export interface NewOptions {
  /** The project's folder, absolute. */
  dir: string;
  /** Its display name, any text (`--name`); the folder's own name when absent. */
  name?: string;
  /** Its npm name (`--package`), checked by `NAME`; derived from the display name (`npmName`) when absent. */
  packageName?: string;
  port?: number;
  source: Source;
  /** A file to copy as the project's `.lfsconfig`, absolute. */
  lfsconfig?: string;
  install: boolean;
}

/** What the command line got wrong (exit 2), or a step that failed (exit 1). */
export class NewError extends Error {
  code: number;
  constructor(message: string, code = 1) {
    super(message);
    this.code = code;
  }
}

const usage = (message: string): NewError => new NewError(`${message}\nusage: vibe ${NEW_USAGE}`, 2);

/** `vibe new`'s arguments; paths resolved against `cwd`. Throws a `NewError` (2) saying what is wrong. */
export function parseNewArgs(args: readonly string[], cwd: string): NewOptions {
  let dir: string | undefined;
  let name: string | undefined;
  let packageName: string | undefined;
  let port: number | undefined;
  let lfsconfig: string | undefined;
  let install = true;
  const sources: Source[] = [];
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    if (arg === '--no-install') {
      install = false;
      continue;
    }
    if (!arg.startsWith('--')) {
      if (dir !== undefined) throw usage(`one folder, not ${dir} and ${arg}`);
      dir = resolve(cwd, arg);
      continue;
    }
    const value = args[i + 1];
    if (value === undefined || value.startsWith('--')) throw usage(`${arg} takes a value`);
    i++;
    if (arg === '--name') {
      if (value.trim() === '') throw usage('--name takes a name: any text but a blank');
      name = value.trim();
    } else if (arg === '--package') packageName = value;
    else if (arg === '--port') {
      port = Number(value);
      if (!Number.isInteger(port) || port <= 1000 || port > 65535) throw usage(`--port takes a port above 1000 (its preview is 1000 below), not ${value}`);
    } else if (arg === '--source') sources.push({ kind: 'source', path: value.replace(/(.)[\\/]$/, '$1') });
    else if (arg === '--submodule') sources.push({ kind: 'submodule', url: value });
    else if (arg === '--tarballs') sources.push({ kind: 'tarballs', dir: resolve(cwd, value) });
    else if (arg === '--lfsconfig') lfsconfig = resolve(cwd, value);
    else throw usage(`no such argument ${arg}`);
  }
  if (dir === undefined) throw usage('the project\'s folder is missing');
  if (sources.length > 1) throw usage('one of --source, --submodule and --tarballs, not several');
  if (sources.length === 0 && install) {
    throw usage('no registry has the @vibe/* packages yet: say where they come from -- --tarballs <dir> (vibe pack\'s release/), --source <path> or --submodule <url> -- or --no-install');
  }
  if (packageName !== undefined) {
    const problem = npmNameProblem(packageName);
    if (problem !== null) throw usage(`--package takes an npm name -- ${problem} -- not ${packageName}`);
  }
  return { dir, name, packageName, port, source: sources[0] ?? { kind: 'version' }, lfsconfig, install };
}

/** Why `name` is no npm name as a project takes one (`NAME`), or null when it is one. */
export function npmNameProblem(name: string): string | null {
  if (NAME.test(name)) return null;
  if (name === '') return 'not empty';
  if (/[A-Z]/.test(name)) return 'lowercase only';
  if (name.length > 214) return 'at most 214 characters';
  if (/^[a-z0-9-]+$/.test(name)) return 'not a dash first';
  return 'lowercase letters, digits and dashes only';
}

/** Letters a decomposition leaves whole, spelled in plain ones. */
const LIGATURES: Readonly<Record<string, string>> = { æ: 'ae', œ: 'oe', ø: 'o', ß: 'ss', ð: 'd', þ: 'th', ł: 'l', đ: 'd', ı: 'i' };

/**
 * A display name as an npm name (`NAME`): accents folded ("Café" `cafe`, "Æsir" `aesir`), lowercased, an apostrophe
 * dropped ("Kalle's Kart" `kalles-kart`), every other run of anything but letters, digits and dashes a `-`, none at
 * the ends (a leading dot or dash goes with them; a leading digit is npm's own and stays), at most 214 characters.
 * `game` when nothing is left ("!!!").
 */
export function npmName(name: string): string {
  const out = name
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[æœøßðþłđı]/g, (c) => LIGATURES[c]!)
    .replace(/['\u2019`]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 214)
    .replace(/-+$/, '');
  return out === '' ? 'game' : out;
}

/** The names Windows keeps for devices: a folder may not be one, whatever its extension. */
const RESERVED = /^(con|prn|aux|nul|com[0-9¹²³]|lpt[0-9¹²³])(?=\.|$)/i;

/**
 * A display name as a folder's name, the same on macOS, Windows and Linux: each of `/ \ : * ? " < > |` and every
 * control character a `-`, a leading or trailing space or dot dropped, a name Windows keeps for a device (`CON`,
 * `nul.txt`, `COM1`) given a `-game` after it (`CON-game`, `nul-game.txt`), at most 200 characters; `game` when nothing
 * is left. Otherwise the name as typed:
 * "Chicken Golf" is the folder `Chicken Golf`.
 */
export function folderName(name: string): string {
  let out = name
    .replace(/[/\\:*?"<>|\u0000-\u001f\u007f]/g, '-')
    .replace(/^[\s.]+|[\s.]+$/g, '');
  out = [...out].slice(0, 200).join('').replace(/[\s.]+$/, '');
  if (out === '') return 'game';
  return out.replace(RESERVED, '$1-game');
}

/** `value` as it is written inside a file named `path`: escaped for HTML in a `.html`, inside a string in code or JSON, as it is elsewhere. */
export function escapeFor(path: string, value: string): string {
  if (/\.html?$/i.test(path)) return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  if (/\.json$/i.test(path)) return JSON.stringify(value).slice(1, -1);
  if (/\.[cm]?[jt]sx?$/i.test(path)) return JSON.stringify(value).slice(1, -1).replace(/'/g, "\\'").replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
  return value;
}

/** Can a server listen on `port` at `host` (every address when undefined)? Only a port in use, or one not ours to take, says no. */
function listenable(port: number, host?: string): Promise<boolean> {
  return new Promise((done) => {
    const server = createServer();
    server.once('error', (err: NodeJS.ErrnoException) => done(err.code !== 'EADDRINUSE' && err.code !== 'EACCES'));
    server.listen({ port, host, exclusive: true }, () => server.close(() => done(true)));
  });
}

/** Is `port` free: on every address, and on each loopback (a server bound to 127.0.0.1 alone is missed by a wildcard probe on some systems)? */
export async function portFree(port: number): Promise<boolean> {
  for (const host of [undefined, '127.0.0.1', '::1']) if (!(await listenable(port, host))) return false;
  return true;
}

/** The first port from `from` upward, two apart, that is free with its preview (`port - 1000`). */
export async function freePort(from: number = FIRST_PORT, tries = 200): Promise<number> {
  for (let port = from, n = 0; n < tries && port <= 65535; port += 2, n++) {
    if ((await portFree(port)) && (await portFree(port - 1000))) return port;
  }
  throw new NewError(`no free port pair from ${from} upward -- say one with --port`, 2);
}

/** The three tarballs `vibe pack` wrote into `dir`, by package; throws a `NewError` (2) naming what is missing or doubled. */
export function findTarballs(dir: string): Record<keyof typeof PACKAGES, string> {
  if (!existsSync(dir) || !statSync(dir).isDirectory()) throw usage(`--tarballs: no folder ${dir}`);
  const files = readdirSync(dir);
  const found: Partial<Record<keyof typeof PACKAGES, string>> = {};
  const problems: string[] = [];
  for (const short of Object.keys(PACKAGES) as (keyof typeof PACKAGES)[]) {
    const matches = files.filter((file) => file.startsWith(`vibe-${short}-`) && file.endsWith('.tgz'));
    if (matches.length === 1) found[short] = matches[0]!;
    else problems.push(matches.length === 0 ? `no vibe-${short}-<version>.tgz` : `${matches.length} of ${PACKAGES[short]} (${matches.join(', ')}): keep one`);
  }
  if (problems.length > 0) throw usage(`--tarballs ${dir}: ${problems.join('; ')} -- vibe pack writes the three into release/`);
  return found as Record<keyof typeof PACKAGES, string>;
}

/** Every file under `dir`, relative, in name order. */
function walk(dir: string, under = ''): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(join(dir, under), { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
    const path = under === '' ? entry.name : join(under, entry.name);
    if (entry.isDirectory()) out.push(...walk(dir, path));
    else out.push(path);
  }
  return out;
}

/** `text` with each placeholder replaced; `path`, when given, the file's, each value escaped for it (`escapeFor`). */
export function fill(text: string, values: Readonly<Record<string, string>>, path?: string): string {
  return text.replace(/__(NAME|TITLE|PORT|PREVIEW_PORT|DEBUG_PORT|VERSION)__/g, (whole, key: string) => {
    const value = values[key];
    return value === undefined ? whole : path === undefined ? value : escapeFor(path, value);
  });
}

/**
 * The template copied into `dir` (which exists), `gitignore` renamed, the placeholders filled -- throws on one left --
 * and every asset's uid made anew (`restampUids`, Docs/asset-ids.md §1): the template's files are stamped, and two
 * projects made from it must share no uid.
 */
export function copyTemplate(dir: string, values: Readonly<Record<string, string>>, from: string = TEMPLATE): void {
  cpSync(from, dir, { recursive: true, filter: (path) => basename(path) !== '.DS_Store' });
  if (existsSync(join(dir, 'gitignore'))) renameSync(join(dir, 'gitignore'), join(dir, '.gitignore'));
  const left: string[] = [];
  for (const path of walk(dir)) {
    const file = join(dir, path);
    const bytes = readFileSync(file);
    if (bytes.includes(0)) continue;
    const text = fill(bytes.toString('utf8'), values, path);
    writeFileSync(file, text);
    if (PLACEHOLDER.test(text)) left.push(path);
  }
  if (left.length > 0) throw new NewError(`placeholders left in ${left.join(', ')}: the template has one vibe new does not know`);
  restampUids(dir);
}

/** The three `@vibe/*` ranges for `source`; `version` is the pipeline's own. Tarballs are named by their place under `vendor/`. */
export function dependencyRanges(source: Source, version: string, tarballs?: Record<keyof typeof PACKAGES, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [short, name] of Object.entries(PACKAGES) as [keyof typeof PACKAGES, string][]) {
    if (source.kind === 'version') out[name] = `^${version}`;
    else if (source.kind === 'source') out[name] = `file:${source.path}/packages/${short}`;
    else if (source.kind === 'submodule') out[name] = `file:./engine/packages/${short}`;
    else out[name] = `file:./vendor/${tarballs![short]}`;
  }
  return out;
}

/** The project's `package.json` with the `@vibe/*` ranges written where the template names them. */
function writeRanges(dir: string, ranges: Readonly<Record<string, string>>): void {
  const file = join(dir, 'package.json');
  const manifest = JSON.parse(readFileSync(file, 'utf8')) as Record<string, Record<string, string> | unknown>;
  for (const field of ['dependencies', 'devDependencies'] as const) {
    const deps = manifest[field] as Record<string, string> | undefined;
    if (deps) for (const name of Object.keys(deps)) if (name in ranges) deps[name] = ranges[name]!;
  }
  writeFileSync(file, `${JSON.stringify(manifest, null, 2)}\n`);
}

/** The environment a child npm or git runs in: npm's own variables from a script that ran `vibe new` left out, so they do not reach the new project's install. */
function childEnv(): NodeJS.ProcessEnv {
  return Object.fromEntries(Object.entries(process.env).filter(([key]) => !fromNpmScript(key)));
}

/** Runs a quick step in `cwd`, its output kept and given in the error. Throws a `NewError` (1) when it fails. */
function step(command: string, args: readonly string[], cwd: string): void {
  const options: SpawnSyncOptions = { cwd, env: childEnv(), stdio: 'pipe', encoding: 'utf8' };
  const run = spawnSync(command, args, options);
  if (run.error) throw new NewError(`${command} ${args.join(' ')}: ${run.error.message}`);
  if (run.status !== 0) throw new NewError(`${command} ${args.join(' ')} failed (exit ${run.status ?? run.signal})\n${String(run.stderr ?? '').trim()}`);
}

/**
 * Runs a long step in `cwd` (`npm install`, a submodule's clone), its output streamed as it comes: to the
 * terminal (inherited) when there is no `output`, else line by line into it, stdout's and stderr's alike --
 * the launcher's way (`packages/studio/`), which sends each line to its page. Never synchronous, so a
 * server running `newProject` keeps answering while it runs. Throws a `NewError` (1) when it fails.
 */
function streamStep(command: string, args: readonly string[], cwd: string, output?: (line: string) => void): Promise<void> {
  return new Promise((done, fail) => {
    // npm is npm.cmd through the shell on Windows (`npmSpawn`); git an .exe either way.
    const run = command === 'npm' ? npmSpawn(args) : { command, args: [...args], shell: false };
    const child = spawn(run.command, run.args, { cwd, env: childEnv(), stdio: output ? ['ignore', 'pipe', 'pipe'] : 'inherit', shell: run.shell });
    if (output) {
      for (const stream of [child.stdout!, child.stderr!]) {
        let rest = '';
        stream.setEncoding('utf8');
        stream.on('data', (chunk: string) => {
          const lines = (rest + chunk).split(/\r?\n|\r/);
          rest = lines.pop()!;
          for (const line of lines) if (line.trim() !== '') output(line);
        });
        stream.on('end', () => rest.trim() !== '' && output(rest));
      }
    }
    child.once('error', (err) => fail(new NewError(`${command} ${args.join(' ')}: ${err.message}`)));
    child.once('close', (code, signal) => (code === 0 ? done() : fail(new NewError(`${command} ${args.join(' ')} failed (exit ${code ?? signal})`))));
  });
}

/** What `vibe new` made, undone: the folder it made, or the contents of the empty one it was given. */
function undo(dir: string, made: boolean): void {
  if (!existsSync(dir)) return;
  if (made) rmSync(dir, { recursive: true, force: true });
  else for (const entry of readdirSync(dir)) rmSync(join(dir, entry), { recursive: true, force: true });
}

/**
 * `vibe new` with `args`, paths relative to `cwd`; the exit code. `log` and `error` take its own lines;
 * `output` the long steps' (`npm install`'s), line by line -- the terminal's own, inherited, when absent.
 */
export async function newProject(
  cwd: string,
  args: readonly string[],
  log: (line: string) => void = console.log,
  error: (line: string) => void = console.error,
  output?: (line: string) => void,
): Promise<number> {
  let options: NewOptions;
  let tarballs: Record<keyof typeof PACKAGES, string> | undefined;
  let port: number;
  let name: string;
  let title: string;
  try {
    options = parseNewArgs(args, cwd);
    const { dir, source } = options;
    if (existsSync(dir) && (!statSync(dir).isDirectory() || readdirSync(dir).length > 0)) throw usage(`${dir} is there and not an empty folder`);
    title = options.name ?? basename(dir);
    name = options.packageName ?? npmName(title);
    if (source.kind === 'tarballs') tarballs = findTarballs(source.dir);
    if (source.kind === 'source' && !existsSync(join(resolve(dir, source.path), 'packages', 'engine', 'package.json'))) {
      throw usage(`--source ${source.path}: no packages/engine/ there, read from the project (${resolve(dir, source.path)})`);
    }
    if (options.lfsconfig !== undefined && !existsSync(options.lfsconfig)) throw usage(`--lfsconfig: no file ${options.lfsconfig}`);
    port = options.port ?? (await freePort());
  } catch (err) {
    error(err instanceof Error ? err.message : String(err));
    return err instanceof NewError ? err.code : 1;
  }

  const { dir, source } = options;
  const made = !existsSync(dir);
  const version = (JSON.parse(readFileSync(OWN_MANIFEST, 'utf8')) as { version: string }).version;
  try {
    mkdirSync(dir, { recursive: true });
    copyTemplate(dir, { NAME: name, TITLE: title, PORT: String(port), PREVIEW_PORT: String(port - 1000), DEBUG_PORT: String(port + DEBUG_PORT_OFFSET), VERSION: `^${version}` });
    writeRanges(dir, dependencyRanges(source, version, tarballs));
    if (source.kind === 'tarballs') {
      mkdirSync(join(dir, 'vendor'));
      for (const file of Object.values(tarballs!)) copyFileSync(join(source.dir, file), join(dir, 'vendor', file));
    }
    if (options.lfsconfig !== undefined) copyFileSync(options.lfsconfig, join(dir, '.lfsconfig'));
    log(`[new] ${relative(cwd, dir) || '.'}: ${title === name ? name : `${title} (package ${name})`}, port ${port} (preview ${port - 1000}), ${describe(source, version)}`);
    if (source.kind === 'version') log(`[new] no registry has @vibe/* ^${version} yet: npm install fails until one has -- --tarballs <dir>, --source <path> or --submodule <url> is what a project needs today`);

    step('git', ['init', '--quiet'], dir);
    step('git', ['lfs', 'install', '--local'], dir);
    if (source.kind === 'submodule') await streamStep('git', ['submodule', 'add', source.url, 'engine'], dir, output);
    if (options.install) await streamStep('npm', ['install'], dir, output);
    step('git', ['add', '-A'], dir);
    step('git', ['commit', '--quiet', '-m', FIRST_COMMIT], dir);
  } catch (err) {
    undo(dir, made);
    error(`${err instanceof Error ? err.message : String(err)}\n[new] ${made ? `${dir} removed` : `${dir} emptied again`}`);
    return err instanceof NewError ? err.code : 1;
  }
  log(`[new] made ${dir}${options.install ? ': npm run dev' : ': npm install, then npm run dev'}`);
  return 0;
}

/** Where the packages come from, said. */
function describe(source: Source, version: string): string {
  if (source.kind === 'version') return `the packages at ^${version}`;
  if (source.kind === 'source') return `source mode on ${source.path}`;
  if (source.kind === 'submodule') return `source mode, engine/ a submodule of ${source.url}`;
  return `published mode, the tarballs in vendor/`;
}
