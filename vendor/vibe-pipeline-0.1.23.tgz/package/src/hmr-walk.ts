/**
 * Would Vite apply a change in place, or reload the page? -- Vite's own answer, walked over its module graph as its
 * server's `propagateUpdate` walks it (`vite/dist/node/chunks/node.js`, Vite 8), so the dev server's two holds ask the
 * same question the same way: the agent's (`agent/vite.ts`, a turn's reload held for its end) and studio mode's
 * mid-session one (`studio/broken.ts`, a reload held while a module is broken).
 *
 * From each changed module up through its importers: a module that accepts itself (CSS, `import.meta.hot.accept()`)
 * or accepts the exports its importers take is a boundary; an importer that accepts it (`acceptedHmrDeps`) is one --
 * the game's `src/game/live.ts`, accepting `./index.ts`, is the swap's; a module no importer leads on from to a
 * boundary is a dead end, the page reloaded. Every path is followed (a game module a HUD imports by value reloads,
 * whatever folder it is in; a shared module only the game imports swaps), each module once (`traversed`, shared across
 * the change's modules as Vite shares it) and never back round a cycle (`chain`). A module with an id the page never
 * loaded (`isSelfAccepting` not known yet) stops its path, neither a boundary nor a dead end, as in Vite.
 *
 * No Vite, no `node:` import: the stand-in graphs of `hmr-walk.test.ts` run it.
 */

/** What the walk reads of a module: Vite's `EnvironmentModuleNode`, in part -- a test's stand-in may leave most out. */
export interface HmrNode {
  id?: string | null;
  file?: string | null;
  isSelfAccepting?: boolean;
  /** The exports it accepts for its importers (`import.meta.hot.acceptExports`). */
  acceptedHmrExports?: Set<string> | null;
  /** By imported module id, the names this one imports of it. */
  importedBindings?: Map<string, Set<string>> | null;
  importers?: Iterable<HmrNode> & { size?: number };
  acceptedHmrDeps?: { has(m: never): boolean };
}

/** The walk's answer for a change. */
export interface HmrWalk {
  /** A dead end on some path: Vite answers the change with a page reload. */
  reload: boolean;
  /** The modules that take the update in place (each boundary), when it does not reload. */
  boundaries: HmrNode[];
}

const sizeOf = (importers: HmrNode['importers']): number => {
  if (!importers) return 0;
  if (typeof importers.size === 'number') return importers.size;
  let n = 0;
  for (const _ of importers) n++;
  return n;
};

/** Does `importer` take nothing of `node` but the exports `node` accepts? */
function allImportsAccepted(node: HmrNode, importer: HmrNode): boolean {
  if (!node.id || !node.acceptedHmrExports || !importer.importedBindings) return false;
  const taken = importer.importedBindings.get(node.id);
  if (!taken) return false;
  for (const name of taken) if (!node.acceptedHmrExports.has(name)) return false;
  return true;
}

/** One module's paths up: true at a dead end. Vite's `propagateUpdate`, its circular-import flag aside. */
function propagate(node: HmrNode, traversed: Set<HmrNode>, boundaries: HmrNode[], chain: HmrNode[]): boolean {
  if (traversed.has(node)) return false;
  traversed.add(node);
  if (node.id && node.isSelfAccepting === undefined) return false;
  if (node.isSelfAccepting) {
    boundaries.push(node);
    return false;
  }
  if (node.acceptedHmrExports) boundaries.push(node);
  else if (sizeOf(node.importers) === 0) return true;
  for (const importer of node.importers ?? []) {
    if (importer.acceptedHmrDeps?.has(node as never)) {
      boundaries.push(importer);
      continue;
    }
    if (allImportsAccepted(node, importer)) continue;
    if (!chain.includes(importer) && propagate(importer, traversed, boundaries, [...chain, importer])) return true;
  }
  return false;
}

/** Vite's answer for a change of `modules`. None (a file nothing imports): no reload -- Vite sends nothing for it. */
export function hmrWalk(modules: readonly HmrNode[]): HmrWalk {
  const traversed = new Set<HmrNode>();
  const boundaries: HmrNode[] = [];
  let reload = false;
  for (const m of modules) if (propagate(m, traversed, boundaries, [m])) reload = true;
  return { reload, boundaries };
}

/** The game's swap boundary, the generated `src/game/live.ts` (`rel` makes a module's file relative). */
export const isGameBoundary = (m: HmrNode, rel: (file: string) => string): boolean => typeof m.file === 'string' && rel(m.file) === 'src/game/live.ts';

/**
 * Would Vite apply this change in place, with no reload? No dead end on any path. `swap`: a boundary that is the
 * game's (`live.ts`) counts as in place -- studio mode's hold: the swap takes it; the agent's says false, a world
 * rebuild being no patch, held for the turn's end.
 */
export function appliedInPlace(modules: readonly HmrNode[], rel: (file: string) => string, swap: boolean): boolean {
  const walk = hmrWalk(modules);
  if (walk.reload) return false;
  return swap || !walk.boundaries.some((b) => isGameBoundary(b, rel));
}
