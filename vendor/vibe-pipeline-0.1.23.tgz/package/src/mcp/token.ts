/**
 * The `/__mcp` endpoint's token (Docs/mcp.md M7, D1): made at random each time a dev server process starts, kept in
 * memory and in a file only its owner may read -- `.cache/agent/<port>/mcp.json`, mode 0600, beside the port's
 * conversations (gitignored with `.cache/`) -- with the endpoint's URL and the server's pid, so `vibe mcp` can print
 * the line to paste into a terminal Claude Code. `vibe mcp --rotate` writes a new token into the file; the running
 * server reads the file again whenever it changed (`createTokenKeeper`), so the old token is refused from then on.
 * The file goes when the process exits.
 *
 * Node only. Nothing at module level.
 */
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { mkdirSync, readdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';

/** What the file holds. */
export interface EndpointRecord {
  /** The endpoint: `http://localhost:<port>/__mcp`. */
  url: string;
  port: number;
  /** The dev server's process: a record whose process is gone is stale. */
  pid: number;
  token: string;
  /** When the token was made, as an ISO time. */
  made: string;
}

/** The endpoint's path on the dev server. */
export const MCP_PATH = '/__mcp';

/** Where a port's record is kept, under the project's root. */
export const endpointFile = (root: string, port: number): string => join(root, '.cache', 'agent', String(port), 'mcp.json');

/** A new token: 32 random bytes, URL-safe base64. */
export const newToken = (): string => randomBytes(32).toString('base64url');

/** Do two tokens match -- in a time that does not say how much of one does. */
export function tokenMatches(given: string, want: string): boolean {
  const a = Buffer.from(given);
  const b = Buffer.from(want);
  return a.length === b.length && timingSafeEqual(a, b);
}

/** The record written whole, readable by its owner alone (0600 from its first byte), then moved into place. */
export function writeEndpoint(file: string, record: EndpointRecord): void {
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  const tmp = `${file}.${process.pid}.${randomBytes(4).toString('hex')}.tmp`;
  writeFileSync(tmp, `${JSON.stringify(record, null, 2)}\n`, { mode: 0o600, flag: 'wx' });
  renameSync(tmp, file);
}

/** A record read, or null: none, or not one. */
export function readEndpoint(file: string): EndpointRecord | null {
  try {
    const r = JSON.parse(readFileSync(file, 'utf8')) as Partial<EndpointRecord>;
    if (typeof r.url !== 'string' || typeof r.token !== 'string' || typeof r.port !== 'number' || typeof r.pid !== 'number') return null;
    return { url: r.url, port: r.port, pid: r.pid, token: r.token, made: typeof r.made === 'string' ? r.made : '' };
  } catch {
    return null;
  }
}

/** Is a process there (signal 0: asked, not sent). */
export function alive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    // There, but another user's: alive all the same.
    return (err as NodeJS.ErrnoException).code === 'EPERM';
  }
}

/** The project's endpoints whose dev server still runs, by port: each port's record under `.cache/agent/`. */
export function runningEndpoints(root: string): { file: string; record: EndpointRecord }[] {
  let ports: string[];
  try {
    ports = readdirSync(join(root, '.cache', 'agent')).filter((n) => /^\d+$/.test(n));
  } catch {
    return [];
  }
  return ports.flatMap((p) => {
    const file = endpointFile(root, Number(p));
    const record = readEndpoint(file);
    return record && alive(record.pid) ? [{ file, record }] : [];
  }).sort((a, b) => a.record.port - b.record.port);
}

/** The token as the running server holds it: its own, or a rotated one read off the file once the file changed. */
export interface TokenKeeper {
  /** The token now -- the file read again if it changed since. */
  current(): string;
  /** The record written for `port` (the server listening): the URL and the pid with it. */
  publish(port: number): void;
  /** The file taken away: the process is going. */
  remove(): void;
}

/** A keeper of `token` for the project at `root`. */
export function createTokenKeeper(root: string, token: string): TokenKeeper {
  let held = token;
  let file: string | null = null;
  let seen = -1;
  const stamp = (): number => {
    try {
      return file === null ? -1 : statSync(file).mtimeMs;
    } catch {
      return -1;
    }
  };
  return {
    current() {
      const now = stamp();
      if (file !== null && now !== seen && now !== -1) {
        seen = now;
        const r = readEndpoint(file);
        // Only a rotation of this server's own record: a record another process wrote there is not ours to take.
        if (r && r.pid === process.pid && r.token.length >= 32) held = r.token;
      }
      return held;
    },
    publish(port) {
      file = endpointFile(root, port);
      writeEndpoint(file, { url: `http://localhost:${port}${MCP_PATH}`, port, pid: process.pid, token: held, made: new Date().toISOString() });
      seen = stamp();
    },
    remove() {
      if (file === null) return;
      const r = readEndpoint(file);
      if (r && r.pid === process.pid) rmSync(file, { force: true });
    },
  };
}
