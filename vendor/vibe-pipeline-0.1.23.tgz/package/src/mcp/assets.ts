/**
 * The asset tools' dev-server half (Docs/mcp.md §4's assets, M3): the reads, and each write's server path -- what runs
 * when no studio tab can run it through the Assets panel's own step (D2). Every write here is a route's own work called
 * in-process (`AssetsCalls.call`, the same function the route sends the answer of: one implementation), after the
 * checks the panel makes before it calls the same route -- what game code names refusing a move (`code-naming.ts`),
 * what a data file names refusing a delete (`POST referrers`) -- and with no question asked: the permission gate asks
 * the person where the tool is destructive.
 *
 * - **Reads**: `asset_list` (a folder's files with kind, key, uid, status; paged; or the trash's slots), `asset_info`
 *   (one file whole: its record, uses, referrers, problems), `asset_uses`, `material_get`, `prefab_file`, `asset_thumb`.
 * - **Writes, the server's**: no step -- Undo this turn alone takes them back (the files each touched, `files`).
 * - **Exports are jobs**: `followExports` makes one studio job of the pipeline's jobs a call queued, its progress from
 *   their `job` messages (`onJob`), the files they wrote the turn's as each ends.
 *
 * Imports the assets server's types and its pure modules; node only for the files it reads.
 */
import { readdir, readFile, realpath, stat } from 'node:fs/promises';
import { homedir } from 'node:os';
import { isAbsolute, join, relative, sep } from 'node:path';
import { materialSet, parseMaterialFile } from '@vibe/engine/material-file';
import { parsePhysicsMaterial, PHYSICS_MATERIAL_DEFAULTS } from '@vibe/engine/physics-material-file';
import { caseKey } from '@vibe/engine/case-key';
import type {
  AssetCopyResult, AssetDeleteResult, AssetExportResult, AssetMoveResult, AssetNewResult, AssetOptionsResult, AssetRestoreResult, MaterialSetResult, ModelAdoptResult, PhysmatSetResult,
} from '../agent/api-types.ts';
import type { Entry, JobMessage, Status } from '../assets/api-types.ts';
import { codeNaming, entryKey, namedKeys, prefabKeyOf, type PrefabAt } from '../assets/code-naming.ts';
import { familyOf } from '../assets/families.ts';
import { jsonProblem } from '../assets/json-problem.ts';
import { ENGINE_DATA_KINDS, KINDS, MATERIAL_SUFFIX, PREFAB_SUFFIX, ROOTS, TRASH } from '../assets/kinds.ts';
import { baseName, dirName, exportAsValue, joinPath, twin, under } from '../assets/paths.ts';
import type { AssetOps, AssetsCalls } from '../assets/server.ts';
import { scanUids } from '../assets/stamp.ts';
import type { JobHandle } from './jobs.ts';
import { ToolRefusal, type StudioContext } from './tool.ts';
import { plural } from './words.ts';

/** `asset_list`'s page, unless it asks for another; and at most. */
export const LIST_PAGE = 100;
export const LIST_MAX = 500;
/** How long `asset_export` waits for its jobs before answering with the studio job's id alone. */
export const EXPORT_WAIT_MS = 20_000;

/** The folders a project's assets are in, from the top: what `asset_list` with no folder answers. */
const TOPS = [ROOTS.boot.dir, ROOTS.source.dir, ROOTS.packs.dir] as const;

/** The assets server, or refused: none runs here (a dev server with no assets plugin). */
export function assetsOf(ctx: StudioContext): AssetsCalls {
  const calls = ctx.assets?.();
  if (!calls) throw new ToolRefusal('The assets server is not running here: the asset tools need the dev server (npm run dev)');
  return calls;
}

/** A route's work, its refusal said as the tool's: the route's own words. */
export async function routed<K extends keyof AssetOps>(calls: AssetsCalls, route: K, query: Record<string, string>, body?: Record<string, unknown>): Promise<AssetOps[K]> {
  try {
    return await calls.call(route, query, body);
  } catch (err) {
    throw refusalOf(err);
  }
}

/** A route's refusal (`Refused`: `body.refused`) as the tool's; any other error as it is. */
export function refusalOf(err: unknown): Error {
  const refused = (err as { body?: { refused?: unknown } } | null)?.body?.refused;
  return typeof refused === 'string' ? new ToolRefusal(refused) : (err as Error);
}

/** A path as given: project-relative, `/` between parts, no leading `./` or trailing `/`. */
export function cleanPath(raw: unknown, what = 'path'): string {
  if (typeof raw !== 'string' || raw.trim() === '') throw new ToolRefusal(`${what} is a project-relative path: src/assets/models/props/crate.glb`);
  const path = raw.trim().replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '');
  if (isAbsolute(path) || path.split('/').includes('..')) throw new ToolRefusal(`${what}: ${raw} -- a path in the project, relative to its root (src/assets/…, AssetsSource/…, packs/…)`);
  return path;
}

/** Paths as given: one or a list. */
export function cleanPaths(raw: unknown, what = 'paths'): string[] {
  const list = Array.isArray(raw) ? raw : [raw];
  if (list.length === 0) throw new ToolRefusal(`${what}: at least one`);
  return [...new Set(list.map((p) => cleanPath(p, what)))];
}

// ---------------------------------------------------------------- reads

/** One file as `asset_list` and `asset_info` say it. */
export interface AssetRow {
  path: string;
  role: Entry['role'];
  kind: string | null;
  key: string | null;
  uid: string | null;
  status: Status | null;
  included: boolean;
  size: number;
}

/** Every asset's uid, by kind and key (`kind\0key`): one scan of the project. */
function uidsOf(calls: AssetsCalls): Map<string, string> {
  const out = new Map<string, string>();
  try {
    for (const a of scanUids(calls.root, calls.kinds).assets) if (a.uid !== undefined && a.key !== undefined) out.set(`${a.kind}\0${caseKey(a.key)}`, a.uid);
  } catch {
    // Unreadable now: no uids said, the rest is.
  }
  return out;
}

/** A row of the index as the tools say it. */
function rowOf(e: Entry, entries: ReadonlyMap<string, Entry>, uids: ReadonlyMap<string, string>): AssetRow {
  const key = entryKey(e, entries) ?? null;
  return { path: e.path, role: e.role, kind: e.kind ?? null, key, uid: e.kind !== undefined && key !== null ? (uids.get(`${e.kind}\0${caseKey(key)}`) ?? null) : null, status: e.status ?? null, included: e.included, size: e.size };
}

/** The folders directly in `dir` on disk, by path: an empty one too, which no entry shows. */
async function foldersIn(root: string, dir: string): Promise<string[]> {
  try {
    const found = await readdir(join(root, dir), { withFileTypes: true });
    return found.filter((d) => d.isDirectory() && !d.name.startsWith('.')).map((d) => joinPath(dir, d.name)).sort();
  } catch {
    return [];
  }
}

/** `asset_list`: a folder's files (and its folders), or everything under it; the trash's slots; paged. */
export async function assetList(calls: AssetsCalls, args: Record<string, unknown>): Promise<{ folder: string | null; folders: string[]; files: AssetRow[]; total: number; next: string | null; trash?: Array<{ slot: string; files: string[] }> }> {
  const tree = calls.catalog.answer();
  if (args.trash === true) {
    const trash = tree.trash.map((s) => ({ slot: s.slot, files: s.files.map((f) => f.path) }));
    return { folder: TRASH, folders: [], files: [], total: trash.length, next: null, trash };
  }
  const limit = typeof args.limit === 'number' ? Math.min(Math.max(1, Math.floor(args.limit)), LIST_MAX) : LIST_PAGE;
  const from = typeof args.cursor === 'string' && /^\d+$/.test(args.cursor) ? Number(args.cursor) : 0;
  const folder = args.folder === undefined ? null : cleanPath(args.folder, 'folder');
  const recursive = args.recursive === true;
  const kind = typeof args.kind === 'string' ? args.kind : null;
  const entries = calls.catalog.entries as ReadonlyMap<string, Entry>;
  if (folder === null) {
    const folders = (await Promise.all(TOPS.map(async (t) => ((await stat(join(calls.root, t)).catch(() => null))?.isDirectory() ? [t] : [])))).flat();
    return { folder: null, folders, files: [], total: 0, next: null };
  }
  const all = tree.tree
    .filter((e) => (recursive ? under(e.path, folder) && e.path !== folder : dirName(e.path) === folder))
    .filter((e) => kind === null || e.kind === kind)
    .sort((a, b) => (a.path < b.path ? -1 : 1));
  const uids = uidsOf(calls);
  const page = all.slice(from, from + limit).map((e) => rowOf(e, entries, uids));
  const folders = recursive ? [] : await foldersIn(calls.root, folder);
  return { folder, folders, files: page, total: all.length, next: from + limit < all.length ? String(from + limit) : null };
}

/** `asset_info`: one file whole -- its row, its family, its record's options, the code naming its key, the data files naming it, what is wrong. */
export async function assetInfo(calls: AssetsCalls, args: Record<string, unknown>): Promise<Record<string, unknown>> {
  const path = cleanPath(args.path);
  const entries = calls.catalog.entries as ReadonlyMap<string, Entry>;
  const e = entries.get(path);
  if (!e) {
    if ((await stat(join(calls.root, path)).catch(() => null))?.isDirectory()) throw new ToolRefusal(`${path} is a folder: asset_list lists what is in it`);
    throw new ToolRefusal(`${path} is not in the index: asset_list shows what is (a file starting with _ or . is not an asset)`);
  }
  const row = rowOf(e, entries, uidsOf(calls));
  let record: { path: string; options: unknown; include: boolean } | null = null;
  if (e.role === 'source') {
    const file = calls.catalog.recordOf(path);
    try {
      const json = JSON.parse(await readFile(join(calls.root, file), 'utf8')) as { options?: unknown; include?: unknown };
      record = { path: file, options: json.options ?? {}, include: json.include !== false };
    } catch {
      record = { path: file, options: {}, include: true };
    }
  }
  const uses = row.key !== null ? await calls.call('GET uses', { key: row.key }).catch(() => []) : [];
  const referrers = await calls.call('POST referrers', {}, { paths: [path] }).then((r) => r.referrers, () => []);
  const problems: string[] = [];
  // A source's status not current, and why: a loose file's or an export's line says what it is, no problem.
  if (e.reason !== undefined && e.status !== undefined && e.status !== 'current') problems.push(e.reason);
  if (e.pointer) problems.push('an unfetched Git LFS pointer: git lfs pull');
  if (path.endsWith('.prefab') || path.endsWith(MATERIAL_SUFFIX) || path.endsWith('.scene')) {
    const problem = jsonProblem(await readFile(join(calls.root, path), 'utf8').catch(() => ''));
    if (problem) problems.push(`${problem.line !== undefined ? `line ${problem.line}: ` : ''}${problem.message}`);
  }
  return {
    ...row,
    reason: e.reason ?? null,
    note: e.note ?? null,
    exports: e.exports ?? [],
    source: e.source ?? null,
    parts: e.parts ?? [],
    owners: e.owners ?? [],
    record,
    uses,
    referrers,
    problems,
  };
}

/** `asset_uses`: where game code names a key -- given, or the key of a path. */
export async function assetUses(calls: AssetsCalls, args: Record<string, unknown>): Promise<{ key: string; uses: Array<{ file: string; line: number; text: string }> }> {
  let key = typeof args.key === 'string' && args.key !== '' ? args.key : null;
  if (key === null) {
    const path = cleanPath(args.path);
    const e = calls.catalog.entries.get(path);
    key = e ? (entryKey(e, calls.catalog.entries as ReadonlyMap<string, Entry>) ?? null) : prefabKeyOf(path) ?? null;
    if (key === null) throw new ToolRefusal(`${path} has no key: nothing names it in code`);
  }
  return { key, uses: await routed(calls, 'GET uses', { key }) };
}

/** A data file by its key or its path, under its kind's folder: the path, as the index has it (its case). */
function dataPath(calls: AssetsCalls, args: Record<string, unknown>, kind: 'materials' | 'prefabs', suffix: string): string {
  if (typeof args.path === 'string') return cleanPath(args.path);
  if (typeof args.key !== 'string' || args.key === '') throw new ToolRefusal(`key is a ${kind === 'materials' ? 'material' : 'prefab'}'s key (props/rust), or give its path`);
  const want = caseKey(args.key);
  const dir = `${ROOTS.boot.dir}/${KINDS[kind].dir}`;
  for (const p of calls.catalog.entries.keys()) if (p.startsWith(`${dir}/`) && p.endsWith(suffix) && caseKey(p.slice(dir.length + 1, -suffix.length)) === want) return p;
  throw new ToolRefusal(`There is no ${kind === 'materials' ? 'material' : 'prefab'} ${args.key}: asset_list ${dir} lists them`);
}

/** `material_get`: a material file's fields, every one (the defaults where it says nothing), and what is wrong in it. */
export async function materialGet(calls: AssetsCalls, args: Record<string, unknown>): Promise<{ key: string; path: string; fields: unknown; problems: string[] }> {
  const path = dataPath(calls, args, 'materials', MATERIAL_SUFFIX);
  const text = await readFile(join(calls.root, path), 'utf8').catch(() => null);
  if (text === null) throw new ToolRefusal(`${path} is not there`);
  const problem = jsonProblem(text);
  if (problem) return { key: materialKey(path), path, fields: null, problems: [`${problem.line !== undefined ? `line ${problem.line}: ` : ''}${problem.message}`] };
  const parsed = parseMaterialFile(JSON.parse(text));
  return { key: materialKey(path), path, fields: parsed.file, problems: parsed.problems };
}

const materialKey = (path: string): string => caseKey(path.slice(`${ROOTS.boot.dir}/${KINDS.materials.dir}/`.length, -MATERIAL_SUFFIX.length));

/** `prefab_file`: a prefab file as JSON, and why it would not parse. */
export async function prefabFile(calls: AssetsCalls, args: Record<string, unknown>): Promise<{ key: string; path: string; file: unknown; problem: string | null }> {
  const path = dataPath(calls, args, 'prefabs', PREFAB_SUFFIX);
  const text = await readFile(join(calls.root, path), 'utf8').catch(() => null);
  if (text === null) throw new ToolRefusal(`${path} is not there`);
  const key = prefabKeyOf(path) ?? caseKey(path);
  const problem = jsonProblem(text);
  if (problem) return { key, path, file: null, problem: `${problem.line !== undefined ? `line ${problem.line}: ` : ''}${problem.message}` };
  const file = JSON.parse(text) as { is?: unknown };
  return { key, path, file, problem: file.is === 'vibebase.prefab' ? null : 'a prefab file says "is": "vibebase.prefab"' };
}

// ---------------------------------------------------------------- the writes' server path (no studio tab: D2)

/** The prefabs the index has, by key and file: what a folder's move takes the keys of. */
function prefabsOf(calls: AssetsCalls): PrefabAt[] {
  const out: PrefabAt[] = [];
  for (const p of calls.catalog.entries.keys()) {
    const key = prefabKeyOf(p);
    if (key !== undefined) out.push({ key, path: p });
  }
  return out;
}

/** Is `path` a folder on disk. */
const isDir = async (calls: AssetsCalls, path: string): Promise<boolean> => (await stat(join(calls.root, path)).catch(() => null))?.isDirectory() === true;

/** The heads of their families, each once: a source and its export are one move, one copy. */
function heads(calls: AssetsCalls, paths: readonly string[]): string[] {
  const out: string[] = [];
  const taken = new Set<string>();
  for (const p of paths) {
    if (taken.has(p)) continue;
    for (const f of familyOf(calls.catalog.entries, p)) taken.add(f);
    out.push(p);
  }
  return out;
}

const server = { via: 'server' as const, step: null };

/**
 * `asset_move`'s server path: each family into `to` (a folder), or one renamed to `name` in its folder -- the move's
 * repair pass rewriting what names it by uid (Docs/asset-ids.md §4) -- after what game code names refused (rule 5).
 */
export async function moveOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<AssetMoveResult> {
  const paths = cleanPaths(args.paths);
  const pairs = await movePairs(calls, paths, args);
  // What game code names refuses the move (rule 5): its keys change, the code's would not -- the panel's check.
  const entries = calls.catalog.entries as ReadonlyMap<string, Entry>;
  const prefabs = prefabsOf(calls);
  const keys: string[] = [];
  for (const [from, to] of pairs) if (caseKey(from) !== caseKey(to)) keys.push(...namedKeys(from, await isDir(calls, from), entries, prefabs));
  const named = await codeNaming(keys, (key) => calls.call('GET uses', { key }));
  if (named !== null) throw new ToolRefusal(`Not moved: ${named}`);
  const moved: Array<[string, string]> = [];
  const rewritten: string[] = [];
  let partial: string | undefined;
  for (const [from, to] of pairs) {
    try {
      const answer = await routed(calls, 'POST move', {}, { from, to });
      moved.push(...answer.moved);
      rewritten.push(...(answer.rewritten ?? []).map((r) => r.path));
      if (answer.partial) partial = answer.partial;
    } catch (err) {
      if (moved.length === 0) throw err;
      partial = `${moved.length} moved, then ${from} was not: ${(err as Error).message}`;
      break;
    }
  }
  return { tool: 'asset_move', ...server, moved, rewritten, files: [...new Set([...moved.flat(), ...rewritten])], ...(partial !== undefined ? { partial } : {}) };
}

/** Each move asked: into the folder `to`, or one path renamed to `name` beside it. */
export async function movePairs(calls: AssetsCalls, paths: readonly string[], args: Record<string, unknown>): Promise<Array<[string, string]>> {
  if (typeof args.name === 'string') {
    if (paths.length !== 1) throw new ToolRefusal('name renames one path: give one');
    if (args.to !== undefined) throw new ToolRefusal('name or to: a rename stays in its folder, a move keeps its name');
    const name = args.name.trim();
    if (name === '' || /[/\\]/.test(name)) throw new ToolRefusal('name is a new name, no folder in it: crate-big.glb');
    // A file's extension kept when the name has none.
    const from = paths[0]!;
    const ext = (await isDir(calls, from)) || /\.[^.]+$/.test(name) ? '' : (/\.[^./]+$/.exec(baseName(from))?.[0] ?? '');
    return [[from, joinPath(dirName(from), `${name}${ext}`)]];
  }
  const to = cleanPath(args.to, 'to');
  if (!(await isDir(calls, to))) throw new ToolRefusal(`${to} is no folder: asset_new kind folder makes one`);
  return heads(calls, paths).map((p) => [p, joinPath(to, baseName(p))] as [string, string]);
}

/** `asset_copy`'s server path: each family copied into `to`, or beside itself (a duplicate, named -2). */
export async function copyOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<AssetCopyResult> {
  const paths = cleanPaths(args.paths);
  const to = args.to === undefined ? null : cleanPath(args.to, 'to');
  if (to !== null && !(await isDir(calls, to))) throw new ToolRefusal(`${to} is no folder: asset_new kind folder makes one`);
  const copies: string[] = [];
  let partial: string | undefined;
  for (const from of heads(calls, paths)) {
    try {
      copies.push(...(await routed(calls, 'POST copy', {}, { from, to: to ?? dirName(from) })).paths);
    } catch (err) {
      if (copies.length === 0) throw err;
      partial = `${plural(copies.length, 'file')} copied, then ${from} was not: ${(err as Error).message}`;
      break;
    }
  }
  return { tool: 'asset_copy', ...server, copies, files: copies, ...(partial !== undefined ? { partial } : {}) };
}

/** Every file a delete of `paths` takes: the files, and everything under a folder and its twin. */
function deleted(calls: AssetsCalls, paths: readonly string[], dirs: readonly string[]): string[] {
  const all = new Set(paths.filter((p) => !dirs.includes(p)));
  for (const d of dirs) {
    const other = twin(d);
    for (const p of calls.catalog.entries.keys()) if (under(p, d) || (other !== undefined && under(p, other))) all.add(p);
  }
  return [...all];
}

/** Why nothing may be deleted: the data files still naming what would go (`POST referrers`), or null. */
export async function referrersRefusal(calls: AssetsCalls, files: readonly string[]): Promise<string | null> {
  if (files.length === 0) return null;
  const { referrers } = await routed(calls, 'POST referrers', {}, { paths: [...files] });
  if (referrers.length === 0) return null;
  const names = [...new Set(referrers.flatMap((r) => r.names))].sort();
  const who = referrers.map((r) => r.path);
  return `Not deleted: ${who.join(', ')} ${who.length === 1 ? 'names' : 'name'} ${names.join(', ')} -- take ${names.length === 1 ? 'it' : 'them'} out of ${who.length === 1 ? 'that one' : 'those'} first`;
}

/** `asset_delete`'s server path: to the trash, refused while a data file names any of it; a folder's files, then the folder. */
export async function deleteOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<AssetDeleteResult> {
  const paths = cleanPaths(args.paths);
  if (paths.some((p) => under(p, TRASH))) throw new ToolRefusal('That is in the trash already: asset_restore brings it back, asset_empty_trash removes everything there for good');
  const dirs: string[] = [];
  for (const p of paths) if (await isDir(calls, p)) dirs.push(p);
  const files = deleted(calls, paths, dirs);
  const why = await referrersRefusal(calls, files);
  if (why !== null) throw new ToolRefusal(why);
  const removed: string[] = [];
  let slot: string | null = null;
  if (files.length > 0) {
    const answer = await routed(calls, 'POST delete', {}, { paths: files });
    removed.push(...answer.removed);
    slot = answer.slot ?? null;
  }
  // Each folder left, the deepest first, its twin with it: one with something the index never lists stays, said.
  const left: string[] = [];
  const folders = [...new Set(dirs.flatMap((d) => [d, twin(d)].filter((x): x is string => x !== undefined)))].sort((a, b) => b.split('/').length - a.split('/').length);
  for (const d of folders) {
    if (!(await isDir(calls, d))) continue;
    try {
      removed.push(...(await routed(calls, 'POST delete', {}, { paths: [d] })).removed);
    } catch {
      left.push(d);
    }
  }
  return { tool: 'asset_delete', ...server, removed, slot, files: removed.filter((p) => !folders.includes(p)), ...(left.length > 0 ? { partial: `left in place, something in them the index does not list: ${left.join(', ')}` } : {}) };
}

/** `asset_restore`'s server path: a trash slot's files (or some) back where they were, or into `to`. */
export async function restoreOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<AssetRestoreResult> {
  const slot = typeof args.slot === 'string' && args.slot !== '' ? args.slot : null;
  if (slot === null) throw new ToolRefusal('slot is a trash slot, as asset_list with trash: true lists them');
  const paths = args.paths === undefined ? undefined : cleanPaths(args.paths);
  const answer = await routed(calls, 'POST restore', {}, { slot, ...(paths ? { paths } : {}) });
  let restored = answer.restored;
  if (args.to !== undefined) {
    const to = cleanPath(args.to, 'to');
    const into: string[] = [];
    for (const p of heads(calls, restored)) into.push(...(await routed(calls, 'POST move', {}, { from: p, to: joinPath(to, baseName(p)) })).moved.map(([, b]) => b));
    restored = into;
  }
  return { tool: 'asset_restore', ...server, restored, files: [...new Set([...answer.restored, ...restored])] };
}

/**
 * `asset_options`' server path: a source's export options (`set` merged over its record's, `reset` taking every one
 * off) or a folder's defaults (`export.json`), and a source in the build or out of it (`include`) -- `PUT sidecar`, which
 * re-exports.
 */
export async function optionsOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<AssetOptionsResult> {
  const path = cleanPath(args.path);
  // The export's name, as the panel's Rename the export… sends it (`PUT export-as`).
  if (args.as !== undefined) {
    if (args.as !== null && (typeof args.as !== 'string' || args.as === '')) throw new ToolRefusal('as is the name the export ships as (no extension), or null for the source\'s own');
    if (args.set !== undefined || args.reset !== undefined || args.include !== undefined) throw new ToolRefusal('as is its own call: name the export, then set the options in another');
    const as = exportAsValue(path, args.as as string | null);
    const done = await routed(calls, 'PUT export-as', { path }, { as });
    return { tool: 'asset_options', ...server, path, jobs: (done.jobs ?? []).map((j) => ({ id: j.id, source: j.source })), files: [done.record, ...done.moved.map(([, to]) => to), ...(done.rewritten ?? []).map((r) => r.path)], exportAs: { as, moved: done.moved } };
  }
  const body: Record<string, unknown> = {};
  if (args.set !== undefined || args.reset === true) body.options = { ...(args.reset === true ? {} : await recordOptions(calls, path)), ...((args.set ?? {}) as Record<string, unknown>) };
  if (typeof args.include === 'boolean') body.include = args.include;
  if (Object.keys(body).length === 0) throw new ToolRefusal('Nothing to set: give set (options by name), reset, or include');
  const answer = await routed(calls, 'PUT sidecar', { path }, body);
  const record = (await isDir(calls, path)) ? joinPath(path, 'export.json') : calls.catalog.recordOf(path);
  return { tool: 'asset_options', ...server, path, jobs: answer.jobs, files: [record] };
}

/**
 * `model_adopt`'s server path: `POST adopt`'s work, as Make a script for it sends it -- the script and its copy written,
 * its build queued (not waited for: the page's step waits, the server's answers at once).
 */
export async function adoptOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<ModelAdoptResult> {
  const path = cleanPath(args.path);
  const answer = await routed(calls, 'POST adopt', {}, { path });
  return { tool: 'model_adopt', ...server, path, script: answer.path, copied: answer.copy ?? null, decoded: answer.decoded ?? [], built: null, jobs: answer.jobs.map((j) => ({ id: j.id, source: j.source })), files: [answer.path, ...(answer.copy !== undefined ? [answer.copy] : [])] };
}

/** The options a source's record, or a folder's `export.json`, sets now. */
async function recordOptions(calls: AssetsCalls, path: string): Promise<Record<string, unknown>> {
  const file = (await isDir(calls, path)) ? joinPath(path, 'export.json') : calls.catalog.recordOf(path);
  try {
    const json = JSON.parse(await readFile(join(calls.root, file), 'utf8')) as { options?: unknown };
    return json.options !== null && typeof json.options === 'object' ? (json.options as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

/** `material_set`'s server path: the fields written as the Material block writes them (`materialSet`), through `PUT prefab`. */
export async function materialSetOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<MaterialSetResult> {
  const path = dataPath(calls, args, 'materials', MATERIAL_SUFFIX);
  const set = setOf(args);
  const text = await readFile(join(calls.root, path), 'utf8').catch(() => null);
  if (text === null) throw new ToolRefusal(`${path} is not there`);
  const problem = jsonProblem(text);
  if (problem) throw new ToolRefusal(`${path} would not parse (${problem.message}): fix it by hand first`);
  const next = materialSet(JSON.parse(text), set);
  if ('problems' in next) throw new ToolRefusal(`Not written: ${next.problems.join('; ')}`);
  if (next.text !== text) await routed(calls, 'PUT prefab', { path }, { text: next.text });
  return { tool: 'material_set', ...server, key: materialKey(path), path, set, files: next.text !== text ? [path] : [] };
}

/**
 * `physmat_set`'s server path, with no studio tab (Docs/physics.md §7): the physics material by its key, the change laid
 * over its file and checked by the engine's own reader, written as the block writes it -- only what differs from the
 * defaults, its uid kept -- through `PUT prefab`.
 */
export async function physmatSetOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<PhysmatSetResult> {
  const { key, ...set } = args;
  if (typeof key !== 'string' || key === '') throw new ToolRefusal('key is the physics material\'s key: ice');
  if (Object.keys(set).length === 0) throw new ToolRefusal('nothing to set: any of friction, rollingFriction, restitution, frictionCombine, restitutionCombine');
  const want = caseKey(key);
  const dir = `${ROOTS.boot.dir}/${ENGINE_DATA_KINDS.physicsmaterials!.dir}`;
  let path: string | undefined;
  for (const p of calls.catalog.entries.keys()) if (p.startsWith(`${dir}/`) && p.toLowerCase().endsWith('.physmat') && caseKey(p.slice(dir.length + 1, -'.physmat'.length)) === want) path = p;
  if (path === undefined) throw new ToolRefusal(`There is no physics material ${key}: asset_list ${dir} lists them; asset_new kind physicsmaterial makes one`);
  const text = await readFile(join(calls.root, path), 'utf8').catch(() => null);
  if (text === null) throw new ToolRefusal(`${path} is not there`);
  const problem = jsonProblem(text);
  if (problem) throw new ToolRefusal(`${path} would not parse (${problem.message}): fix it by hand first`);
  const was = JSON.parse(text) as Record<string, unknown>;
  const read = parsePhysicsMaterial({ ...was, ...set });
  if (typeof read === 'string') throw new ToolRefusal(`Not written: ${read}`);
  const out: Record<string, unknown> = typeof was.uid === 'string' ? { uid: was.uid } : {};
  for (const k of ['friction', 'rollingFriction', 'restitution', 'frictionCombine', 'restitutionCombine'] as const) if (read[k] !== PHYSICS_MATERIAL_DEFAULTS[k]) out[k] = read[k];
  const next = `${JSON.stringify(out, null, 2)}\n`;
  if (next !== text) await routed(calls, 'PUT prefab', { path }, { text: next });
  return { tool: 'physmat_set', ...server, key: want, path, values: { ...read }, files: next !== text ? [path] : [] };
}

/** `set`, an object of fields. */
export function setOf(args: Record<string, unknown>): Record<string, unknown> {
  const set = args.set;
  if (set === null || typeof set !== 'object' || Array.isArray(set) || Object.keys(set).length === 0) throw new ToolRefusal('set is an object of fields: { "color": "#ff8800", "roughness": 0.4 }');
  return set as Record<string, unknown>;
}

/** Where a new thing of `kind` goes when no folder is given. */
export function newHome(kind: string): string {
  if (kind === 'model') return `${ROOTS.source.dir}/${KINDS.models.dir}`;
  if (kind === 'material') return `${ROOTS.boot.dir}/${KINDS.materials.dir}`;
  if (kind === 'physicsmaterial') return `${ROOTS.boot.dir}/${ENGINE_DATA_KINDS.physicsmaterials!.dir}`;
  if (kind === 'scene') return `${ROOTS.boot.dir}/${KINDS.scenes.dir}`;
  if (kind === 'prefab' || kind === 'variant') return `${ROOTS.boot.dir}/${KINDS.prefabs.dir}`;
  return ROOTS.boot.dir;
}

/**
 * `asset_new`'s server path: a folder (its twin too, made by the pipeline as it exports there), a pack (`packs/<name>`
 * and its source twin), a material (as New material writes it) or a model script (`POST model`, its export queued).
 * A prefab, a variant and a scene are the editor's writers' (their layout, the compile): a studio tab's.
 */
export async function newOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<AssetNewResult> {
  const kind = String(args.kind);
  const name = typeof args.name === 'string' ? args.name.trim() : '';
  const folder = args.in === undefined ? newHome(kind) : cleanPath(args.in, 'in');
  if (kind === 'prefab' || kind === 'variant' || kind === 'scene') {
    throw new ToolRefusal(`A new ${kind} is written by the editor (its file's layout, checked by the compile): it needs the studio open -- ask the person to open it`);
  }
  if (kind === 'folder' || kind === 'pack') {
    if (name === '' || /[/\\]/.test(name)) throw new ToolRefusal(`name is the new ${kind}'s name, no folder in it`);
    const dirs = kind === 'pack' ? [joinPath(ROOTS.packs.dir, name), joinPath(ROOTS.packs.source, name)] : [joinPath(folder, name)];
    for (const d of dirs) await routed(calls, 'POST mkdir', {}, { path: d });
    return { tool: 'asset_new', ...server, kind, path: dirs[0]!, key: null, jobs: [], files: [] };
  }
  if (kind === 'material') {
    const stem = name !== '' ? name.replace(new RegExp(`\\${MATERIAL_SUFFIX}$`), '') : await freeStem(calls, folder, 'new-material', MATERIAL_SUFFIX);
    const path = joinPath(folder, `${stem}${MATERIAL_SUFFIX}`);
    const made = materialSet({ is: 'vibebase.material', version: 1, type: 'standard' }, {});
    if ('problems' in made) throw new ToolRefusal(made.problems.join('; '));
    await routed(calls, 'PUT prefab', { path }, { text: made.text, create: true });
    return { tool: 'asset_new', ...server, kind, path, key: materialKey(path), jobs: [], files: [path] };
  }
  if (kind === 'physicsmaterial') {
    // As New physics material writes it: the defaults, nothing differing -- `{}` -- the pipeline stamping its uid.
    const stem = name !== '' ? name.replace(/\.physmat$/i, '') : await freeStem(calls, folder, 'new-physics-material', '.physmat');
    const path = joinPath(folder, `${stem}.physmat`);
    await routed(calls, 'PUT prefab', { path }, { text: '{}\n', create: true });
    return { tool: 'asset_new', ...server, kind, path, key: caseKey(path.slice(newHome(kind).length + 1, -'.physmat'.length)), jobs: [], files: [path] };
  }
  if (kind === 'model') {
    if (name === '') throw new ToolRefusal('name is the new model\'s name: Test Thing');
    const answer = await routed(calls, 'POST model', {}, { dir: folder, name });
    return { tool: 'asset_new', ...server, kind, path: answer.path, key: null, jobs: answer.jobs, files: [answer.path] };
  }
  throw new ToolRefusal(`kind is folder, pack, prefab, variant, material, physicsmaterial, scene or model -- not ${kind}`);
}

/** The first of `stem`, `stem-2`… with no file of `suffix` in `folder`, in any case. */
async function freeStem(calls: AssetsCalls, folder: string, stem: string, suffix: string): Promise<string> {
  const taken = new Set((await readdir(join(calls.root, folder)).catch(() => [] as string[])).map((n) => n.toLowerCase()));
  for (let n = 1; ; n++) {
    const s = n === 1 ? stem : `${stem}-${n}`;
    if (!taken.has(`${s}${suffix}`.toLowerCase())) return s;
  }
}

/** `asset_export`'s server path: `POST export` -- the paths' sources, or every stale one under a folder (`force`: current ones too). */
export async function exportOffline(calls: AssetsCalls, args: Record<string, unknown>): Promise<AssetExportResult> {
  const body = exportBody(args);
  const answer = await routed(calls, 'POST export', {}, body);
  return { tool: 'asset_export', ...server, jobs: answer.jobs, job: null, files: [] };
}

/** What `POST export` takes, from the tool's input. */
export function exportBody(args: Record<string, unknown>): { paths: string[]; force: boolean } | { under: string; force: boolean } {
  const force = args.force === true;
  if (args.under !== undefined) return { under: cleanPath(args.under, 'under'), force };
  if (args.paths === undefined) throw new ToolRefusal('paths (sources or their exports) or under (a folder: every stale source in it)');
  return { paths: cleanPaths(args.paths), force };
}

/** Is a pipeline job's state its end. */
const ended = (state: string): boolean => state !== 'queued' && state !== 'running' && state !== 'parked';

/**
 * The pipeline's export jobs a call queued, followed as one studio job (`job_wait`): its progress as each ends, the
 * files each `done` wrote the turn's (`ctx.wrote`), finished with how each ended. Waits up to `wait` ms: the result
 * with `ended` when they all ended by then, else the job's id alone.
 */
export async function followExports(ctx: StudioContext, result: AssetExportResult, wait = EXPORT_WAIT_MS): Promise<AssetExportResult> {
  const calls = ctx.assets?.();
  if (result.jobs.length === 0) return result;
  const ids = new Set(result.jobs.map((j) => j.id));
  const states = new Map<string, JobMessage>();
  const label = result.jobs.length === 1 ? `export ${baseName(result.jobs[0]!.source)}` : `export ${result.jobs.length} sources`;
  const job: JobHandle = ctx.jobs.start('export', label);
  let done: () => void = () => {};
  const all = new Promise<void>((resolve) => (done = resolve));
  const endedNow = (): Array<{ source: string; state: string; error?: string }> =>
    result.jobs.map((j) => {
      const m = states.get(j.id);
      return { source: j.source, state: m?.state ?? 'queued', ...(m?.error !== undefined ? { error: m.error } : {}) };
    });
  const hear = (m: JobMessage): void => {
    if (!ids.has(m.id)) return;
    states.set(m.id, m);
    if (!ended(m.state)) return;
    if (m.state === 'done' && calls) {
      const e = calls.catalog.entries.get(m.source);
      ctx.wrote?.([...(e?.exports ?? []), calls.catalog.recordOf(m.source)]);
    }
    const over = [...ids].filter((id) => ended(states.get(id)?.state ?? 'queued')).length;
    job.progress(over, ids.size, `${m.state} ${baseName(m.source)}`);
    if (over < ids.size) return;
    off();
    const list = endedNow();
    const failed = list.filter((x) => x.state === 'failed' || x.state === 'unmade');
    if (failed.length === list.length) job.fail(failed.map((f) => `${baseName(f.source)}: ${f.error ?? f.state}`).join('; '));
    else job.finish({ ended: list });
    done();
  };
  const off = calls ? calls.onJob(hear) : () => {};
  // Already over before the following began (a job skipped at once): heard from the runner's list -- none there is over.
  if (calls) {
    const live = new Set((await calls.call('GET jobs', {}).catch(() => [])).map((j) => j.id));
    for (const id of ids) if (!live.has(id) && !states.has(id)) states.set(id, { id, source: result.jobs.find((j) => j.id === id)!.source, step: 0, of: 0, state: 'done' });
  }
  job.progress([...ids].filter((id) => ended(states.get(id)?.state ?? 'queued')).length, ids.size, null);
  if ([...ids].every((id) => ended(states.get(id)?.state ?? 'queued'))) {
    off();
    job.finish({ ended: endedNow() });
    return { ...result, job: job.id, ended: endedNow() };
  }
  const timer = new Promise<'late'>((resolve) => setTimeout(() => resolve('late'), wait));
  const how = await Promise.race([all.then(() => 'over' as const), timer]);
  return how === 'over' ? { ...result, job: job.id, ended: endedNow() } : { ...result, job: job.id };
}

// ---------------------------------------------------------------- import (the server's alone)

/**
 * The most an import reads from this machine: 1 GB. The panel's drop streams what the browser hands it with no limit
 * but the disk; a path given by Claude is read by the dev server unseen, so it is bounded -- no game asset is larger.
 */
export const IMPORT_MAX = 1024 * 1024 * 1024;

/** A file an import may read: its real path (every link followed), its size, and whether it is outside the project. */
export interface ImportSource {
  real: string;
  size: number;
  outside: boolean;
}

/** Is `path` inside `dir` (never `dir` itself)? Both absolute. */
function within(path: string, dir: string): boolean {
  const rel = relative(dir, path);
  return rel !== '' && !rel.startsWith('..') && !isAbsolute(rel);
}

/** The real path of `path`, or null where nothing is. */
async function realOf(path: string): Promise<string | null> {
  try {
    return await realpath(path);
  } catch {
    return null;
  }
}

/**
 * Where an import may read from (decided, Docs/mcp.md M3 and its review): an absolute path to a file on this machine
 * whose **real** path -- every link followed, each check made on it -- is inside the person's home folder or the
 * project; never one with any part starting with `.` -- a folder (`~/.ssh`, `~/.aws`) or the file itself (`~/.netrc`,
 * `~/.npmrc`, the project's `.env`) -- as given or as it really is; never a link out of home and the project; never the
 * project's own assets (asset_copy copies those, keeping their uids right); at most `max` bytes (`IMPORT_MAX`). The
 * file, or the refusal's words.
 */
export async function importSource(from: string, root: string, home = homedir(), max = IMPORT_MAX): Promise<ImportSource | string> {
  if (!isAbsolute(from)) return `from is an absolute path to a file on this machine, not ${from}`;
  const realHome = (await realOf(home)) ?? home;
  const realRoot = (await realOf(root)) ?? root;
  const hidden = (path: string, base: string): boolean => relative(base, path).split(sep).some((part) => part.startsWith('.') && part !== '..');
  // As given: a hidden part named outright is refused before anything is read.
  const givenBase = within(from, root) ? root : within(from, home) ? home : null;
  if (givenBase !== null && hidden(from, givenBase)) return `${from} is hidden (a name starting with .): an import does not read those`;
  const real = await realOf(from);
  if (real === null) return `${from} is no file here`;
  const inRoot = within(real, realRoot);
  if (!inRoot && !within(real, realHome)) {
    return real === from ? `${from} is outside your home folder and the project: an import reads a file from either` : `${from} is a link to ${real}, outside your home folder and the project: an import does not follow a link out of them`;
  }
  const base = inRoot ? realRoot : realHome;
  if (hidden(real, base)) return real === from ? `${from} is hidden (a name starting with .): an import does not read those` : `${from} is a link to ${real}, which is hidden (a name starting with .): an import does not read those`;
  const first = relative(base, real).split(sep)[0];
  if (inRoot && (first === 'src' || first === ROOTS.source.dir || first === ROOTS.packs.dir || first === TRASH)) return `${from} is one of the project's assets already: asset_copy copies it, asset_move moves it`;
  const st = await stat(real).catch(() => null);
  if (!st?.isFile()) return `${from} is no file here`;
  if (st.size > max) return `${from} is ${Math.ceil(st.size / (1024 * 1024))} MB: an import reads at most ${Math.round(max / (1024 * 1024))} MB`;
  return { real, size: st.size, outside: !inRoot };
}

