/**
 * The studio's MCP server for outside clients (Docs/mcp.md M7, D1): `/__mcp` on the dev server, MCP's Streamable
 * HTTP transport (`@modelcontextprotocol/sdk`'s, the agent SDK's own peer -- there whenever the agent SDK is), serving
 * the same registry as the AI panel's session -- the same tools, handlers and words -- to a terminal Claude Code or
 * any other MCP client on this machine.
 *
 * - **Who may call**: this machine alone (loopback, `403` else), with no `Origin` or this server's own (`403`: no page
 *   of another site), carrying `Authorization: Bearer <token>` (`401` without it or with another: `token.ts`).
 * - **What is served** is the person's choice (`outside.ts`, Config ▸ Claude ▸ Settings, "Outside clients"): off
 *   (`403`), read-only (the default), read and write, or those and the destructive tools. The tools are listed as the
 *   level stands when a client's session begins; each call is judged as it comes, by the level then.
 * - **A session a client**: `initialize` with no `Mcp-Session-Id` makes one -- a transport and a studio server of its
 *   own (`studioServer` with the gate) -- answered with its id; later requests name it; `DELETE` ends it; the oldest is
 *   let go past `SESSIONS_MAX`. Progress notifications go out on the request's own stream, as the transport does.
 * - **Page tools** relay to the last studio tab that said hello (`AgentServer.relay(null, …)`, marked `outside`:
 *   their steps are labelled `MCP: …`, undone with Z); no turn, so no Undo this turn. With no tab, `not open` and the
 *   URL to open, as for the panel.
 * - **A terminal run's token** (Docs/terminal.md D6, `runs.ts`): a conversation continued in the `claude` CLI is served
 *   the column's list -- every tool but `claude_settings` -- whatever the outside clients' level, even off: it is the
 *   person's own conversation, and the CLI asks them by its own rules and the run's `ask` settings. What asks the person
 *   at every level (`asksWhen`) is refused, as for an outside client: the studio sees no yes of the terminal's. Its page
 *   tools relay as the column's (`runContext`: `Claude: …` steps). A session is its token's: another token naming it is
 *   refused, and a revoked run's sessions are closed.
 *
 * Nothing at module level; the transport is imported when the first session is made.
 */
import { randomUUID } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import type { OutsideLevel } from '../agent/api-types.ts';
import { authority, isLoopback, mayWrite, readBody, trustedHost } from '../assets/http.ts';
import { listedFor, OUTSIDE_WORDS, refusalFor } from './outside.ts';
import { callKind, type Place } from './catalog.ts';
import { studioServer, type McpKit, type ServeGate, type StudioContext } from './registry.ts';
import { MCP_PATH, tokenMatches } from './token.ts';

/** Client sessions kept at once: the oldest let go past it. */
export const SESSIONS_MAX = 16;
/** A request's body, at most. */
const BODY_LIMIT = 4 * 1024 * 1024;

export interface EndpointOptions {
  /** The token now (`TokenKeeper.current`): a rotation is taken at the next request. */
  token(): string;
  /** What outside clients may do now (the conversations' index read first). */
  level(): Promise<OutsideLevel>;
  /** The SDK's makings: its `tool()` and `createSdkMcpServer`, imported when the first session is made. */
  kit(): Promise<McpKit>;
  /** The tools' context: the page tools relayed as an outside client's (`outside`), the dev server's work in-process. */
  context: StudioContext;
  /** Where the gate judges paths (`asksWhen`, `callKind`): the project's root, and a path's real one. */
  place: Place;
  /** The transport's class: `@modelcontextprotocol/sdk`'s, or a test's. */
  transport?(): Promise<typeof StreamableHTTPServerTransport>;
  /** This server's `server.allowedHosts` (`assets/http.ts`' `allowedHosts`): `Host` names trusted beside this machine's. None: none. */
  hosts?(): readonly string[];
  /** The conversation whose terminal run holds `token` (`runs.ts`' `find`), or null. None: no runs. */
  run?(token: string): string | null;
  /** The tools' context for a run's sessions: page tools relayed as the column's (`outside` false). None: `context`. */
  runContext?: StudioContext;
}

export interface Endpoint {
  /** `/__mcp`'s requests answered; false for any other path. */
  handle(req: IncomingMessage, res: ServerResponse): Promise<boolean>;
  /** The sessions open, by id: a test's. */
  readonly sessions: number;
  /** A revoked run's sessions closed (D6). */
  closeRun(conversation: string): Promise<void>;
  /** Every session closed. */
  close(): Promise<void>;
}

/** A refusal, as JSON-RPC's error with no id: what an MCP client reads off a failed request. */
function refuse(res: ServerResponse, status: number, message: string, headers: Record<string, string> = {}): void {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify({ jsonrpc: '2.0', error: { code: status === 401 || status === 403 ? -32001 : -32000, message }, id: null }));
}

/** The panel's Claude's alone, at any level: `claude_settings` is its own model, effort and review (D4), no outside client's to read or set. */
const PANEL_ONLY: ReadonlySet<string> = new Set(['claude_settings']);

/** A run's call refused (D6): what asks the person every time, which the studio cannot do for a terminal. Null: it may run. */
export function runRefusal(meta: Parameters<typeof callKind>[0], input: Record<string, unknown>, place: Place): string | null {
  const asks = meta.asksWhen?.(input, { ...place, written: [] }) ?? null;
  if (asks === null) return null;
  return `Not done: ${meta.name} asks the person in the studio every time (${asks}), and the studio cannot ask them from a terminal. Ask the person to do it there -- in Claude's column (Back to the column) or by hand; nothing was changed.`;
}

/** A session's owner when it is an outside client's: a run's is its conversation's id. */
const OUTSIDE = '\u0000outside';

/** Is a parsed body an `initialize` request (alone, or in a batch). */
const initializes = (body: unknown): boolean => (Array.isArray(body) ? body : [body]).some((m) => typeof m === 'object' && m !== null && (m as { method?: unknown }).method === 'initialize');

export function createEndpoint(options: EndpointOptions): Endpoint {
  /** Each session: its transport, its server, and whose -- `outside`, or the conversation whose run's token made it. */
  const sessions = new Map<string, { transport: StreamableHTTPServerTransport; server: McpServer; owner: string }>();
  /** A run's gate (D6): the column's list, its asking calls refused. */
  const runGate: ServeGate = {
    listed: (meta) => !PANEL_ONLY.has(meta.name),
    refused: (meta, input) => runRefusal(meta, input, options.place),
  };
  /** The gate for a session begun at `start`: listed by that level, each call by the level as it comes. */
  const gateFor = (start: OutsideLevel, now: () => OutsideLevel): ServeGate => ({
    listed: (meta) => !PANEL_ONLY.has(meta.name) && listedFor(start, meta),
    refused: (meta, input) => refusalFor(now(), meta, input, options.place),
  });
  let level: OutsideLevel = 'read';

  /** `owner`: `outside`, or a run's conversation. */
  async function begin(req: IncomingMessage, res: ServerResponse, body: unknown, owner: string): Promise<void> {
    const Transport = await (options.transport ?? (async () => (await import('@modelcontextprotocol/sdk/server/streamableHttp.js')).StreamableHTTPServerTransport))();
    const outside = owner === OUTSIDE;
    const made = await studioServer(await options.kit(), outside ? options.context : (options.runContext ?? options.context), outside ? gateFor(level, () => level) : runGate);
    const server = made.instance;
    const transport: StreamableHTTPServerTransport = new Transport({
      sessionIdGenerator: () => randomUUID(),
      onsessioninitialized: (id) => {
        sessions.set(id, { transport, server, owner });
        // The oldest let go: a client that never said DELETE does not hold one for ever.
        while (sessions.size > SESSIONS_MAX) {
          const [oldest, s] = sessions.entries().next().value!;
          sessions.delete(oldest);
          void s.transport.close().catch(() => {});
        }
      },
    });
    transport.onclose = () => {
      const id = transport.sessionId;
      if (id !== undefined && sessions.get(id)?.transport === transport) sessions.delete(id);
      void server.close().catch(() => {});
    };
    await server.connect(transport);
    await transport.handleRequest(req, res, body);
  }

  return {
    get sessions() {
      return sessions.size;
    },
    async handle(req, res) {
      const path = new URL(req.url ?? '/', 'http://localhost').pathname.replace(/\/+$/, '');
      if (path !== MCP_PATH) return false;
      // This machine, and no other site's page: before the token is even read.
      if (!isLoopback(req.socket.remoteAddress)) {
        refuse(res, 403, 'The studio\'s MCP endpoint answers this machine only');
        return true;
      }
      const allowed = options.hosts?.() ?? [];
      if (!trustedHost(authority(req), allowed)) {
        refuse(res, 403, `The studio's MCP endpoint answers to localhost, not to ${JSON.stringify(authority(req))}`);
        return true;
      }
      if (!mayWrite(req, allowed)) {
        refuse(res, 403, `Another page may not call the studio's MCP endpoint (Origin ${String(req.headers.origin)})`);
        return true;
      }
      const auth = req.headers.authorization ?? '';
      const given = /^Bearer\s+(\S+)$/i.exec(auth)?.[1];
      // A terminal run's token first (D6): the person's own conversation, whatever the outside clients' level.
      const run = given === undefined ? null : (options.run?.(given) ?? null);
      if (given === undefined || (run === null && !tokenMatches(given, options.token()))) {
        refuse(res, 401, given === undefined ? 'The studio\'s MCP endpoint needs its token: Authorization: Bearer <token> (vibe mcp prints it)' : 'That token is not this dev server\'s (it is made anew at each start; vibe mcp prints the one now)', { 'WWW-Authenticate': 'Bearer realm="studio"' });
        return true;
      }
      const owner = run ?? OUTSIDE;
      if (run === null) level = await options.level();
      if (run === null && level === 'off') {
        refuse(res, 403, `Outside clients are ${OUTSIDE_WORDS.off} in this studio: the person may turn them on in Config ▸ Claude ▸ Settings, "Outside clients"`);
        return true;
      }
      try {
        const id = req.headers['mcp-session-id'];
        if (typeof id === 'string') {
          const session = sessions.get(id);
          // A session is its token's: another's naming it is told there is none.
          if (!session || session.owner !== owner) {
            refuse(res, 404, 'No such session: it ended, or the dev server restarted -- initialize again');
            return true;
          }
          await session.transport.handleRequest(req, res);
          return true;
        }
        if (req.method !== 'POST') {
          refuse(res, 400, 'Begin a session first: POST initialize, with no Mcp-Session-Id');
          return true;
        }
        let body: unknown;
        try {
          body = JSON.parse((await readBody(req, BODY_LIMIT)).toString('utf8'));
        } catch {
          refuse(res, 400, 'The body is not JSON-RPC');
          return true;
        }
        if (!initializes(body)) {
          refuse(res, 400, 'No session named: initialize first, then send its Mcp-Session-Id');
          return true;
        }
        await begin(req, res, body, owner);
      } catch (err) {
        if (!res.headersSent) refuse(res, 500, `The studio's MCP endpoint failed: ${(err as Error).message ?? String(err)}`);
        else res.end();
      }
      return true;
    },
    async closeRun(conversation) {
      const theirs = [...sessions].filter(([, s]) => s.owner === conversation);
      for (const [id] of theirs) sessions.delete(id);
      await Promise.all(theirs.map(([, s]) => s.transport.close().catch(() => {})));
    },
    async close() {
      const all = [...sessions.values()];
      sessions.clear();
      await Promise.all(all.map((s) => s.transport.close().catch(() => {})));
    },
  };
}
