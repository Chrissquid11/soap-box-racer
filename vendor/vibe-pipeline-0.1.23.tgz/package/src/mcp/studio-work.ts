/**
 * The studio and code tools' work (Docs/mcp.md §4's Studio, M5): server tools, each through the studio routes' own
 * functions in-process (`StudioCalls`, `studio/calls.ts`) -- the Problems card's lists, the Console's log, the Tests
 * and Build cards' tasks, the Build card's preview, the Code card's search and TypeScript bridge, the Git card's git
 * -- never HTTP from node to itself, never a second path that could disagree.
 *
 * - **Problems** (`problemsOf`): tsc's and Vite's, as the Problems card lists them, and the checks' findings of the
 *   last `vibe test` the studio ran (its `task:test` stream: `[checks] N findings`, each `file:line  rule`).
 * - **Tasks are jobs** (`runTask`): `npm run <script>` through the tasks runner -- the allow-list, one at a time, the
 *   cards seeing the same `studio:task` pushes -- one studio job for the run (several test files: one run each, in
 *   turn), its lines read off the stream as they come (the ring keeps 2000), ended with the run parsed: a test run by
 *   the Tests card's own parser (`test-output.ts`), a build by its exit and its last lines. Waited for `TASK_WAIT_MS`,
 *   then answered with the job's id for `job_wait`. A run stopped -- `job_cancel`, or the person's Stop (`TaskEnd.stopped`)
 *   -- ends the job there: the next file never starts; a job stopped between its files (`job_cancel` with its id, no
 *   task running) starts none, and a file that started as it was stopped is stopped too.
 * - **TypeScript** (`tsAt`, `tsDiagnostics`): a file opened on the bridge for the call and closed after; positions
 *   from 1, as an editor shows them.
 * - **Git**: `git.ts`' functions over the Git card's context (its stream, its serial), their `Refused` said as the
 *   tool's refusal.
 *
 * Node only.
 */
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { LogLine, Problem, TaskEnd } from '../studio/api-types.ts';
import type { StudioCalls } from '../studio/calls.ts';
import { pathForm, readProjectFile } from '../studio/files.ts';
import { parseTestOutput, type TestRun } from '../studio/test-output.ts';
import { TsError } from '../studio/ts-client.ts';
import { Refused } from '../assets/http.ts';
import type { JobHandle } from './jobs.ts';
import { ToolRefusal, type StudioContext } from './tool.ts';

/** How long `tests_run` and `build_run` wait for their run before answering with the job's id. */
export const TASK_WAIT_MS = 20_000;
/** How often a running task's stream is read for its lines: well inside the ring's 2000. */
const READ_MS = 200;

/** The studio routes' work, or refused: none here (a dev server with no studio routes). */
export function studioOf(ctx: StudioContext): StudioCalls {
  const calls = ctx.studio?.();
  if (!calls) throw new ToolRefusal('The studio routes are not running here: the studio tools need the dev server (npm run dev)');
  return calls;
}

/** A route function's refusal as the tool's: its words. Anything else thrown as it is. */
export async function asTool<T>(work: () => Promise<T>): Promise<T> {
  try {
    return await work();
  } catch (err) {
    if (err instanceof Refused) {
      const body = err.body as { why?: unknown } | undefined;
      const why = typeof body?.why === 'string' && !err.message.includes(body.why) ? ` (${body.why})` : '';
      throw new ToolRefusal(`${err.message}${why}`);
    }
    if (err instanceof TsError) throw new ToolRefusal(`TypeScript's server: ${err.message}`);
    throw err;
  }
}

// ---------------------------------------------------------------- problems

/** A problem as the tools answer it: where, and the words; its program (`tsc`, `vite`, `checks`) and code. */
export interface ProblemRow {
  file: string;
  line: number;
  col: number;
  words: string;
  program: string;
  code: string;
}

/** The checks' findings in `vibe test`'s lines (`checks/index.ts`' `checkLines`): `  <file>:<line>  <rule>`, its fix under it. */
export function checkFindings(lines: readonly string[]): ProblemRow[] {
  const out: ProblemRow[] = [];
  for (let i = 0; i < lines.length; i++) {
    const m = /^ {2}(\S[^\s]*?)(?::(\d+))? {2}(.+)$/.exec(lines[i]!);
    if (!m) continue;
    const fix = /^ {6}(.+)$/.exec(lines[i + 1] ?? '')?.[1];
    out.push({ file: m[1]!, line: m[2] ? Number(m[2]) : 0, col: 0, words: fix ? `${m[3]!} -- ${fix}` : m[3]!, program: 'checks', code: m[3]! });
  }
  return out;
}

/** The last test run's lines the studio kept (`task:test`), from its `$ npm run test` on; none if it ran none. */
export function lastRun(calls: StudioCalls, script = 'test'): string[] {
  const lines = calls.log(`task:${script}`, 0).lines.map((l) => l.text);
  let from = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i]!.startsWith(`$ npm run ${script}`)) {
      from = i;
      break;
    }
  }
  return from < 0 ? [] : lines.slice(from);
}

/** Every problem now: tsc's and Vite's (the Problems card's), then the checks' of the last test run that reached them. */
export function problemsOf(calls: StudioCalls): { rows: ProblemRow[]; checksFrom: 'last test run' | null } {
  const rows: ProblemRow[] = calls.problems().problems.map((p: Problem) => ({ file: p.file, line: p.line, col: p.col, words: p.message, program: p.program, code: p.code }));
  const run = lastRun(calls);
  const checks = run.length > 0 ? parseTestOutput(run).checks : null;
  if (checks && !checks.clean) rows.push(...checkFindings(checks.lines.map((l) => (l.startsWith('  ') ? l : `  ${l}`))).filter((r) => r.file !== ''));
  return { rows, checksFrom: checks ? 'last test run' : null };
}

// ---------------------------------------------------------------- the log

/** ANSI colour codes off a line: the Console strips them too. */
// eslint-disable-next-line no-control-regex
export const plain = (text: string): string => text.replace(/\u001b\[[0-9;?]*[A-Za-z]/g, '');

/** A stream's lines after `since`, those that have `filter` (any case), the last `limit` of them. */
export function readLog(calls: StudioCalls, stream: string, since: number, filter: string | null, limit: number): { seq: number; lines: LogLine[]; dropped: number } {
  const { seq, lines } = calls.log(stream, since);
  const wanted = filter ? lines.filter((l) => plain(l.text).toLowerCase().includes(filter.toLowerCase())) : lines;
  const kept = wanted.slice(-limit).map((l) => ({ ...l, text: plain(l.text) }));
  return { seq, lines: kept, dropped: wanted.length - kept.length };
}

// ---------------------------------------------------------------- tasks

/** A test run's facts: the files, each failure by name and message, the checks. */
export interface TestsFacts {
  exit: string | null;
  files: { passed: number; failed: number; total: number };
  failed: { title: string; path: string | null; failures: { name: string; message: string }[]; crashed: boolean }[];
  checks: { clean: boolean; findings: ProblemRow[] } | null;
  skipped: number;
}

/** A parsed run as the tool answers it: every failing file, each `FAIL` with the lines under it as its message. */
export function testsFacts(run: TestRun): TestsFacts {
  const failed = run.files.filter((f) => f.failed > 0 || !f.done).map((f) => {
    const failures: { name: string; message: string }[] = [];
    for (const line of f.lines) {
      const m = /^\s*FAIL (.+)$/.exec(line);
      if (m) failures.push({ name: m[1]!, message: '' });
      else if (failures.length > 0 && /^\s{3,}/.test(line)) {
        const last = failures[failures.length - 1]!;
        last.message = last.message === '' ? line.trim() : `${last.message}\n${line.trim()}`;
      }
    }
    // A crash prints no count and no FAIL: its last lines are what it said.
    if (!f.done && failures.length === 0) failures.push({ name: '(the file crashed)', message: f.lines.slice(-12).join('\n') });
    return { title: f.title, path: f.path, failures, crashed: !f.done };
  });
  const passedFiles = run.files.filter((f) => f.done && f.failed === 0).length;
  return {
    exit: run.exit,
    files: { passed: run.total?.passed ?? passedFiles, failed: failed.length, total: run.total?.files ?? run.files.length },
    failed,
    checks: run.checks ? { clean: run.checks.clean, findings: checkFindings(run.checks.lines.map((l) => (l.startsWith('  ') ? l : `  ${l}`))) } : null,
    skipped: run.files.reduce((n, f) => n + f.skipped, 0),
  };
}

/** One run's end and its lines. */
export interface Ran {
  script: string;
  args: string[];
  end: TaskEnd;
  lines: string[];
}

/**
 * `npm run <script>` (with each of `each`'s args in turn, or once with none) through the tasks runner as one studio
 * job: its lines read as they come, the job finished with `finish(ran)` -- the work's own JSON -- once the last ends,
 * or failed when one cannot start. Answers once it is started; the caller waits on the job.
 */
export async function runTask(ctx: StudioContext, calls: StudioCalls, script: string, each: readonly (readonly string[])[], label: string, finish: (ran: Ran[]) => unknown): Promise<JobHandle> {
  const runs = each.length === 0 ? [[]] : each;
  // The first start's refusal (not allowed, one running, no such test file) is the call's, before any job.
  const first = await asTool(() => calls.tasks.run({ script, ...(runs[0]!.length > 0 ? { args: [...runs[0]!] } : {}) }));
  const job = ctx.jobs.start(script === 'test' ? 'tests' : 'build', label);
  void (async () => {
    const done: Ran[] = [];
    let started: { from: number } | null = first;
    for (let i = 0; i < runs.length; i++) {
      const args = runs[i]!;
      if (started === null) {
        // Stopped between files (job_cancel with its id, nothing running): no next file.
        if (ctx.jobs.get(job.id)?.state !== 'running') return;
        try {
          started = await calls.tasks.run({ script, ...(args.length > 0 ? { args: [...args] } : {}) });
        } catch (err) {
          job.fail(`${script}${args.length > 0 ? ` ${args.join(' ')}` : ''} did not start: ${(err as Error).message}`);
          return;
        }
        // ...or while it started: the file just started is stopped too, as the job was.
        if (ctx.jobs.get(job.id)?.state !== 'running') {
          calls.tasks.cancel();
          return;
        }
      }
      if (runs.length > 1) job.progress(i, runs.length, `${script} ${args.join(' ')}`);
      const ran = await follow(calls, script, args, started.from, () => ctx.jobs.get(job.id)?.state === 'running');
      // The job ended without it -- failed at its lifetime, or a restart's abandon: nothing is followed on.
      if (ran === null) return;
      // Stopped -- job_cancel failed the job, or the person's Stop ended the run: the next file never starts.
      if (ctx.jobs.get(job.id)?.state !== 'running') return;
      if (ran.end.stopped === true) {
        job.fail(`stopped: npm run ${script}${args.length > 0 ? ` ${args.join(' ')}` : ''} was ended by a Stop${i + 1 < runs.length ? `; ${runs.length - i - 1} more not run` : ''}`);
        return;
      }
      done.push(ran);
      started = null;
    }
    job.finish(finish(done));
  })().catch((err: unknown) => job.fail((err as Error).message ?? String(err)));
  return job;
}

/**
 * A run followed from its first line (`from`) to its end: its lines, read off the ring as they come. Let go -- the
 * timer cleared, the listener off, null -- once its job is no longer running (`alive`): failed at its lifetime
 * (`JOB_MAX_MS`), or abandoned by a restart, so a run whose end is never heard leaks nothing.
 */
function follow(calls: StudioCalls, script: string, args: readonly string[], from: number, alive: () => boolean): Promise<Ran | null> {
  const stream = `task:${script}`;
  const lines: string[] = [];
  let seen = from - 1;
  const read = (): void => {
    const got = calls.log(stream, seen);
    for (const l of got.lines) lines.push(plain(l.text));
    seen = got.seq;
  };
  return new Promise((resolve) => {
    const timer = setInterval(() => {
      if (alive()) return read();
      off();
      clearInterval(timer);
      resolve(null);
    }, READ_MS);
    const off = calls.ended((end) => {
      if (end.name !== script) return;
      off();
      clearInterval(timer);
      // The stream is flushed before `ended` goes: every line is in the ring.
      read();
      resolve({ script, args: [...args], end, lines });
    });
  });
}

/** The job waited for at most `ms`: as it ended, or still running (null). */
export async function waitJob(ctx: StudioContext, id: string, ms = TASK_WAIT_MS): Promise<{ state: string; result: unknown; error: string | null } | null> {
  const job = await ctx.jobs.wait(id, ms);
  if (!job || job.state === 'running') return null;
  return { state: job.state, result: job.result, error: job.error };
}

/** A test file's path as `test`'s one argument: a plain `.test.ts` under `src/` -- the tasks runner checks it again. */
export function testPath(raw: unknown): string {
  const path = asPath(raw);
  if (!path.endsWith('.test.ts')) throw new ToolRefusal(`${path} is no test file: a test file's name ends .test.ts`);
  return path;
}

// ---------------------------------------------------------------- TypeScript

/** A project file's path for the bridge: a `.ts`, `.tsx`, `.js` or `.mjs` of the project. */
export function scriptPath(raw: unknown): string {
  const path = asPath(raw);
  if (!/\.(?:ts|tsx|mts|cts|js|mjs|cjs)$/.test(path)) throw new ToolRefusal(`${path} is no script: TypeScript's server reads .ts and .js files`);
  return path;
}

/** A project-relative path, checked as the file routes check one. */
export function asPath(raw: unknown): string {
  try {
    return pathForm(raw);
  } catch (err) {
    throw new ToolRefusal(err instanceof Error ? err.message : String(err));
  }
}

/** A file's text as the Code card's `GET file` reads it -- inside the project, no link leading out, not too big, no binary. */
export async function textOf(calls: StudioCalls, path: string): Promise<string> {
  return (await asTool(() => readProjectFile({ root: calls.root, port: 0 }, path))).text;
}

/** An LSP range as the tools say it: lines and columns from 1. */
export interface Place {
  path: string | null;
  uri: string;
  line: number;
  col: number;
  endLine: number;
  endCol: number;
  /** The place's own line of text, trimmed, where the file can be read. */
  text?: string;
}

type LspRange = { start: { line: number; character: number }; end: { line: number; character: number } };

/** An LSP location (or link) as a `Place`; `text` read off the file where it is the project's. */
export async function placeOf(calls: StudioCalls, loc: { uri?: string; range?: LspRange; targetUri?: string; targetSelectionRange?: LspRange; targetRange?: LspRange }): Promise<Place | null> {
  const uri = loc.uri ?? loc.targetUri;
  const range = loc.range ?? loc.targetSelectionRange ?? loc.targetRange;
  if (!uri || !range) return null;
  const path = calls.ts().pathOf(uri);
  const place: Place = { path, uri, line: range.start.line + 1, col: range.start.character + 1, endLine: range.end.line + 1, endCol: range.end.character + 1 };
  if (path !== null) {
    const text = await readFile(join(calls.root, path), 'utf8').then((t) => t.split('\n')[range.start.line], () => undefined);
    if (text !== undefined) place.text = text.trim().slice(0, 200);
  }
  return place;
}

/** A position from a tool's line and column (from 1), as LSP's. */
export function lspPosition(line: unknown, col: unknown): { line: number; character: number } {
  if (typeof line !== 'number' || !Number.isInteger(line) || line < 1) throw new ToolRefusal('line is a whole number from 1');
  if (typeof col !== 'number' || !Number.isInteger(col) || col < 1) throw new ToolRefusal('col is a whole number from 1');
  return { line: line - 1, character: col - 1 };
}

/** The severities LSP numbers. */
const SEVERITY = ['', 'error', 'warning', 'info', 'hint'] as const;

/** A diagnostic as the tools answer it. */
export interface DiagnosticRow {
  file: string;
  line: number;
  col: number;
  severity: string;
  code: string;
  words: string;
}

/** A file's diagnostics, pulled from the bridge (`textDocument/diagnostic`) as the Code card asks after a save. */
export async function fileDiagnostics(calls: StudioCalls, path: string): Promise<DiagnosticRow[]> {
  const ts = calls.ts();
  const text = await textOf(calls, path);
  return asTool(() => ts.withFile(path, text, async (uri) => {
    const report = (await ts.request('textDocument/diagnostic', { textDocument: { uri } })) as { items?: { range: LspRange; severity?: number; code?: unknown; message: string }[] } | null;
    return (report?.items ?? []).map((d) => ({
      file: path,
      line: d.range.start.line + 1,
      col: d.range.start.character + 1,
      severity: SEVERITY[d.severity ?? 1] ?? 'error',
      code: d.code === undefined ? '' : `TS${String(d.code)}`.replace(/^TSTS/, 'TS'),
      words: d.message,
    }));
  }));
}

/** Hover's contents as plain text: its markdown or strings joined. */
export function hoverText(hover: unknown): string {
  const contents = (hover as { contents?: unknown } | null)?.contents;
  const one = (c: unknown): string => (typeof c === 'string' ? c : typeof (c as { value?: unknown })?.value === 'string' ? (c as { value: string }).value : '');
  return (Array.isArray(contents) ? contents.map(one) : [one(contents)]).filter((s) => s !== '').join('\n\n').trim();
}
