/**
 * A studio tool's result as MCP carries it (Docs/mcp.md §2 rule 6): a line of
 * words, then the tool's JSON -- its output schema's shape -- in the same text,
 * and images beside it where a look matters.
 *
 * - **The JSON rides in the text**, after the words, as the eight editor tools'
 *   answers always had it. Not as `structuredContent`: the CLI (0.3.220's)
 *   hands the model a result's `structuredContent` *instead of* its text when
 *   it is there, and the words would be lost (Docs/mcp.md §9).
 * - **Images** (`{ type: 'image', data, mimeType }`, base64): PNG, JPEG, GIF or
 *   WebP, each at most `IMAGE_MAX` characters of base64 -- the API's limit is on
 *   the base64 text, 5 MB (the CLI's own check: `maxBase64Size` 5242880, its
 *   raw target 3.75 MB) -- at most `IMAGES_MAX` a call; one over a cap left
 *   out, and said in the words, never an error.
 * - **Text capped** at `TEXT_MAX` characters, less `IMAGE_TEXT` for each image
 *   kept: a longer one cut, said. Below the CLI's own cap on an MCP result
 *   (`MAX_MCP_OUTPUT_TOKENS`, 25 000 tokens by default, an image counted as 1600;
 *   over it the CLI cuts at four characters a token, 100 000, and says so
 *   itself), so the note read is ours, naming how to ask for less.
 *
 * Pure: no import.
 */

/** An image a tool answers: base64 bytes and their type. */
export interface ToolImage {
  data: string;
  mimeType: string;
}

/** What a tool's run comes to, before it is MCP's. */
export interface ToolOutput {
  /** A line or a few of words: what was done, and what to do next. */
  words: string;
  /** The tool's JSON, its output schema's shape; left out, words alone. */
  json?: unknown;
  /** Pretty (one space a level), for a long answer read by eye -- the selection, the prefabs; compact otherwise. */
  pretty?: boolean;
  images?: ToolImage[];
  isError?: boolean;
}

/** MCP's content blocks, as the SDK's `CallToolResult` takes them. */
export type ToolContent = { type: 'text'; text: string } | { type: 'image'; data: string; mimeType: string };

/** A tool's result: the SDK's `CallToolResult`. */
export interface ToolResult {
  content: ToolContent[];
  isError?: boolean;
  [key: string]: unknown;
}

/** An image's base64 text, at most, in characters: the API's own limit, which is on the base64 (5 MB), not the bytes decoded. */
export const IMAGE_MAX = 5 * 1024 * 1024;
/** Images in one result, at most. */
export const IMAGES_MAX = 4;
/**
 * A result's text, at most, in characters: 88 000 -- the CLI's cap is 25 000 tokens, which it cuts at 100 000
 * characters; at the 3.5 characters a token of JSON with numbers, 88 000 is 25 000 tokens, so its cut rarely
 * comes after ours.
 */
export const TEXT_MAX = 88_000;
/** What an image kept costs the text, in characters: the CLI counts one as 1600 tokens, four characters each. */
export const IMAGE_TEXT = 6_400;

const MEDIA = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp']);


/** Why an image is left out, or null: kept -- `kept` the ones before it that were. */
function refused(image: ToolImage, at: number, kept: number): string | null {
  if (!MEDIA.has(image.mimeType)) return `image ${at + 1} left out: ${image.mimeType} is not PNG, JPEG, GIF or WebP`;
  if (typeof image.data !== 'string' || image.data === '' || !/^[A-Za-z0-9+/]+={0,2}$/.test(image.data)) return `image ${at + 1} left out: its bytes are not base64`;
  // The API measures the base64 text, not the bytes it decodes to.
  if (image.data.length > IMAGE_MAX) return `image ${at + 1} left out: ${(image.data.length / 1024 / 1024).toFixed(1)} MB of base64 is over the API's ${IMAGE_MAX / 1024 / 1024} MB -- ask for it smaller`;
  if (kept >= IMAGES_MAX) return `image ${at + 1} left out: at most ${IMAGES_MAX} a call`;
  return null;
}

/** The output as MCP's result: the words and the JSON in one text, the images that pass beside it. */
export function toolResult(out: ToolOutput): ToolResult {
  const kept: ToolContent[] = [];
  const notes: string[] = [];
  (out.images ?? []).forEach((image, at) => {
    const why = refused(image, at, kept.length);
    if (why === null) kept.push({ type: 'image', data: image.data, mimeType: image.mimeType });
    else notes.push(why);
  });
  const json = out.json === undefined ? '' : `\n${JSON.stringify(out.json, null, out.pretty ? 1 : undefined)}`;
  let text = `${out.words}${notes.length > 0 ? `\n(${notes.join('; ')})` : ''}${json}`;
  const most = TEXT_MAX - IMAGE_TEXT * kept.length;
  if (text.length > most) text = `${text.slice(0, most)}\n… cut at ${most} characters (the CLI takes about ${TEXT_MAX}): ask for less -- a key, a page, fewer entities`;
  return { content: [{ type: 'text', text }, ...kept], ...(out.isError ? { isError: true } : {}) };
}

/** An error result: words alone. */
export const errorResult = (words: string): ToolResult => toolResult({ words, isError: true });
