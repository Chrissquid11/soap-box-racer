/**
 * Long work as jobs (Docs/mcp.md §2 rule 7, §3): an export, a build, a test
 * run, a compile -- whatever would outlast a tool's deadline -- is started as
 * a job and answered at once with its id; `job_status` says how one stands (or
 * all), `job_wait` waits for one to end, with its progress as it goes.
 *
 * - **A job**: id, kind (`export`, `build`, …), a label in words, its state
 *   (`running`, `done`, `failed`), its progress (done of total, a note), its
 *   result once done or its error once failed, and when it started and ended.
 * - **Made by the work, not by a tool**: `start(kind, label)` hands back the
 *   job's handle -- `progress`, `finish`, `fail` -- to whatever runs it. No
 *   tool makes one in M1 (M3 and M5 add them); a test makes a fake one.
 * - **Kept a while**: the last `keep` ended jobs (64), the running ones while
 *   they run, so `job_status` with no id is a short list.
 * - **Never running for ever**: each job has a lifetime (`start`'s `maxMs`,
 *   `JOB_MAX_MS` -- an hour -- by default); one still running past it is failed
 *   as abandoned the next time the jobs are read or one starts or ends (`trim`),
 *   its waiters told. A dev server restarted in-process keeps the registry but
 *   fails the old bundle's running jobs (`abandon`): the work that ran them is
 *   gone, and its handle can no longer end them.
 * - **Stopped** (`stop`): one running job failed with why, as `job_cancel` stops the task it follows; its work sees
 *   it no longer running and lets go.
 * - **Waited for** (`wait`): resolved as the job ends, or at the timeout with
 *   it as it stands -- never rejected; each progress said to `onProgress` on
 *   the way.
 *
 * Nothing at module level; no timer but a wait's own.
 */

/** How a job stands. */
export type JobState = 'running' | 'done' | 'failed';

/** A job, as `job_status` answers it. */
export interface Job {
  id: string;
  kind: string;
  label: string;
  state: JobState;
  /** How far: `done` of `total` (null: not known), and a note ("exporting crate.lua"); null before any is said. */
  progress: { done: number; total: number | null; note: string | null } | null;
  /** What it came to, once done: the work's own JSON. */
  result: unknown;
  /** Why it failed, once failed. */
  error: string | null;
  /** When it started and ended, as `Date.now()`; `ended` null while it runs. */
  started: number;
  ended: number | null;
}

/** What the work holds of its job. */
export interface JobHandle {
  readonly id: string;
  progress(done: number, total?: number | null, note?: string | null): void;
  finish(result?: unknown): void;
  fail(error: string): void;
}

export interface Jobs {
  /** A job begun: its handle, for the work to say how it goes. `maxMs`: how long it may run before it is failed as abandoned (`JOB_MAX_MS`). */
  start(kind: string, label: string, maxMs?: number): JobHandle;
  /** One job, as it stands (a copy); undefined for an id never made, or let go of. */
  get(id: string): Job | undefined;
  /** Every job kept: the running first, then the ended, newest first. */
  list(): Job[];
  /** Waits for `id` to end, at most `timeoutMs`: the job as it stands then (undefined for an unknown id). Each progress said to `onProgress`. */
  wait(id: string, timeoutMs: number, onProgress?: (job: Job) => void): Promise<Job | undefined>;
  /** Every running job failed, `why` its error: a restart's, whose old work can no longer end them. */
  abandon(why: string): void;
  /** One running job failed, `why` its error -- stopped (`job_cancel`): its work, which follows it, lets go. False: it was not running. */
  stop(id: string, why: string): boolean;
}

/** A job's lifetime when its work names none: an hour, past any export, build or test run. */
export const JOB_MAX_MS = 3_600_000;

export interface JobsOptions {
  now?: () => number;
  /** Ended jobs kept, at most (64). */
  keep?: number;
  /** An id: a test's own. */
  newId?: () => string;
}

/** The registry: one per dev server. */
export function createJobs(options: JobsOptions = {}): Jobs {
  const now = options.now ?? Date.now;
  const keep = options.keep ?? 64;
  let n = 0;
  const newId = options.newId ?? (() => `job-${(++n).toString(36)}-${now().toString(36)}`);
  const jobs = new Map<string, Job>();
  /** When each running job is past its lifetime, by id. */
  const deadlines = new Map<string, number>();
  /** Each running job's end, by id: what `trim` and `abandon` fail it with. */
  const enders = new Map<string, (state: JobState, result: unknown, error: string | null) => void>();
  /** Who waits on each job: told on every change. */
  const watchers = new Map<string, Set<() => void>>();

  const copy = (job: Job): Job => ({ ...job, progress: job.progress && { ...job.progress } });
  const told = (id: string): void => {
    for (const fn of [...(watchers.get(id) ?? [])]) fn();
  };
  /** Running jobs past their lifetime failed as abandoned; the oldest ended let go past `keep`. */
  const trim = (): void => {
    const at = now();
    for (const [id, until] of [...deadlines]) {
      if (at > until) enders.get(id)?.('failed', null, `abandoned: still running after ${Math.round((until - jobs.get(id)!.started) / 1000)} s, its lifetime -- the work that ran it never said it ended`);
    }
    const ended = [...jobs.values()].filter((j) => j.state !== 'running').sort((a, b) => (a.ended ?? 0) - (b.ended ?? 0));
    while (ended.length > keep) jobs.delete(ended.shift()!.id);
  };

  return {
    start(kind, label, maxMs = JOB_MAX_MS) {
      trim();
      const job: Job = { id: newId(), kind, label, state: 'running', progress: null, result: null, error: null, started: now(), ended: null };
      jobs.set(job.id, job);
      deadlines.set(job.id, job.started + Math.max(0, maxMs));
      const end = (state: JobState, result: unknown, error: string | null): void => {
        if (job.state !== 'running') return;
        job.state = state;
        job.result = result;
        job.error = error;
        job.ended = now();
        deadlines.delete(job.id);
        enders.delete(job.id);
        told(job.id);
        trim();
      };
      enders.set(job.id, end);
      return {
        id: job.id,
        progress(done, total = null, note = null) {
          if (job.state !== 'running') return;
          job.progress = { done, total, note };
          told(job.id);
        },
        finish: (result = null) => end('done', result, null),
        fail: (error) => end('failed', null, error),
      };
    },
    get: (id) => {
      trim();
      const job = jobs.get(id);
      return job && copy(job);
    },
    list: () =>
      (trim(), [...jobs.values()])
        .sort((a, b) => (a.state === 'running' ? 0 : 1) - (b.state === 'running' ? 0 : 1) || (b.ended ?? b.started) - (a.ended ?? a.started))
        .map(copy),
    wait(id, timeoutMs, onProgress) {
      trim();
      const job = jobs.get(id);
      if (!job) return Promise.resolve(undefined);
      if (job.state !== 'running') return Promise.resolve(copy(job));
      return new Promise<Job>((resolve) => {
        const set = watchers.get(id) ?? new Set<() => void>();
        watchers.set(id, set);
        const done = (): void => {
          clearTimeout(timer);
          set.delete(watch);
          if (set.size === 0) watchers.delete(id);
          resolve(copy(job));
        };
        const watch = (): void => {
          if (job.state !== 'running') done();
          else onProgress?.(copy(job));
        };
        // Past its lifetime before the wait is over: failed as abandoned then, and the wait answered. A timer counts from
        // libuv's cached time, not `now()`, so it may fire a little early: a job still running, short of its deadline,
        // with the wait's own time not run out, is waited on for the remainder rather than answered.
        const until = now() + timeoutMs;
        let timer: ReturnType<typeof setTimeout> | undefined;
        const arm = (): void => {
          const at = now();
          const left = deadlines.has(id) ? deadlines.get(id)! - at + 1 : Infinity;
          timer = setTimeout(fire, Math.max(0, Math.min(until - at, left)));
        };
        const fire = (): void => {
          trim();
          const at = now();
          if (job.state === 'running' && at < until && (!deadlines.has(id) || at <= deadlines.get(id)!)) arm();
          else done();
        };
        arm();
        set.add(watch);
      });
    },
    abandon(why) {
      for (const end of [...enders.values()]) end('failed', null, why);
    },
    stop(id, why) {
      const end = enders.get(id);
      if (!end) return false;
      end('failed', null, why);
      return true;
    },
  };
}

/** A job in a line, for the words: "export crate.lua: running, 3 of 7 (exporting crate.lua)". */
export function jobLine(job: Job): string {
  const p = job.progress;
  const how = job.state === 'running'
    ? `running${p ? `, ${p.done}${p.total !== null ? ` of ${p.total}` : ''}${p.note ? ` (${p.note})` : ''}` : ''}`
    : job.state === 'done'
      ? 'done'
      : `failed: ${job.error ?? 'no reason given'}`;
  return `${job.id} ${job.kind} "${job.label}": ${how}`;
}
