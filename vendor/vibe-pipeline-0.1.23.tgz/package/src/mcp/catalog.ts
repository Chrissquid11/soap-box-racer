/**
 * The studio's MCP tools as plain data (Docs/mcp.md §3, §4): each tool's name
 * (`<area>_<verb>`), area, kind -- a **page** tool runs in a studio tab,
 * relayed to it; a **server** tool runs in the dev server -- its MCP
 * annotations, its deadline and whether it is always loaded or deferred
 * behind the CLI's tool search. The schemas and the descriptions are
 * `registry.ts`', made with `zod` only as a session starts; this is what the
 * permission gate (`permissions.ts`) reads at every call, with nothing
 * imported.
 *
 * - **Annotations decide the permission** (§2 rule 8, D3): `readOnlyHint` --
 *   never asks; a write follows the level; `destructiveHint` -- asks under Ask
 *   and Auto, goes by under Unsafe auto. `openWorldHint` is false for every
 *   one but `tools_download`, which fetches from the internet: the studio is a
 *   closed world otherwise. A tool whose input decides whether it
 *   writes (`claude_settings`, read or set) says so (`readsWhen`).
 * - **Deadlines** are the relay's (`server.ts`' `relay`): a page tool's answer
 *   waited for that long, then `timeout` -- and a write not begun by then is
 *   never begun (the call's `expires`). Every tool that changes the world may
 *   wait for an Apply landing first (the page's `WAITS`), and Apply and Save as
 *   prefab wait for the live compile themselves, so each has a minute
 *   (`COMPILE_MS`): well over the page's own waits -- a write to disk (8 s at
 *   most) and the compile seen (5 s at most), twice over for one held behind
 *   another Apply. The reads have the relay's 15 s.
 * - **Core or deferred** (`alwaysLoad`): what reads the studio, the scene and
 *   the assets and makes the common edits -- `studio_state`, `scene_query`,
 *   `scene_entity`, `scene_set`, `scene_create`, `batch`, `asset_list`,
 *   `asset_info`, `asset_new`, `asset_move`, `play_state`, `view_shot`,
 *   `problems_list`, `tests_run`, `model_info` -- always in the prompt; the rest wait behind the tool search until Claude
 *   looks for them.
 * - **Offline** (`offline`): an asset write is a page tool -- the Assets
 *   panel's own step in a studio tab (D2) -- that the dev server runs when no
 *   tab can (Docs/mcp.md M3).
 * - **Destructive by input** (`destroysWhen`): a tool that can drop what
 *   nobody saved says so in its annotations, and the gate holds it
 *   destructive only for the inputs that do -- `scene_open` with `discard`.
 * - **Asks by input** (`asksWhen`): a write that reaches outside the project
 *   -- `asset_import` reading a file elsewhere in the home folder -- asks at
 *   every level, as Unsafe auto's floor asks of anything outside the project.
 *
 * - **The names are the table's** (`as const`): `ToolName`, `PageToolName`
 *   (the page's, which `api-types.ts` hands the editor) and `ServerToolName`
 *   are read off it, never written twice; each tool's description, schemas
 *   and words are its area's module (`tools/`), one record for every name.
 *
 * Nothing at module level but the table: no import, no zod.
 */

/** The server's name: its tools are `mcp__studio__<name>`. */
export const STUDIO_SERVER = 'studio' as const;
/** What the agent calls the studio's tools: `mcp__studio__scene_set`. */
export const STUDIO_TOOLS = `mcp__${STUDIO_SERVER}__` as const;

/** The areas of Docs/mcp.md §4 built so far. */
export type ToolArea = 'studio' | 'scene' | 'prefab' | 'job' | 'claude' | 'asset' | 'material' | 'play' | 'view' | 'game' | 'history' | 'problems' | 'console' | 'tests' | 'build' | 'preview' | 'ts' | 'git' | 'code' | 'model' | 'project' | 'tools' | 'physics' | 'physmat';

/** MCP's tool annotations (2025-06-18), every one said. */
export interface StudioAnnotations {
  readOnlyHint: boolean;
  destructiveHint: boolean;
  idempotentHint: boolean;
  /** True for `tools_download` alone: it reaches the internet. */
  openWorldHint: boolean;
}

/** Where a call's paths are judged: the project's root, a path's real one (null where nothing is), and what the turn wrote. */
export interface Place {
  root: string;
  real(path: string): string | null;
  /** The files the running turn wrote (project-relative): its Edits and Writes, and its tools' files. None with no turn. */
  written?: readonly string[];
}

/** A tool as the gate and the relay know it. */
export interface ToolMeta {
  name: string;
  area: ToolArea;
  /** `page`: relayed to a studio tab, answered there; `server`: run in the dev server. */
  kind: 'page' | 'server';
  annotations: StudioAnnotations;
  /** How long its answer is waited for, in milliseconds: a page tool's relay, a server tool's own bound. */
  deadline: number;
  /** Always in the prompt (core), or deferred behind the tool search. */
  alwaysLoad: boolean;
  /** A tool that only reads for some inputs: true for those -- `claude_settings` with nothing to set. */
  readsWhen?(input: Record<string, unknown>): boolean;
  /**
   * A destructive tool whose input decides it: true for the inputs that destroy -- `scene_open` with `discard`. The rest
   * are writes. `place`, where the gate has it: `git_commit` naming a file the turn did not write.
   */
  destroysWhen?(input: Record<string, unknown>, place?: Place): boolean;
  /**
   * A write that asks the person at every level for some inputs -- Unsafe auto's floor, "anything outside the project"
   * (D3): why, in a few words, or null. `asset_import` reading a file whose real path is outside the project. `place`
   * is the project's root and a real path (every link followed; null where nothing is), the gate's.
   */
  asksWhen?(input: Record<string, unknown>, place: Place): string | null;
  /**
   * A page tool the dev server runs when no studio tab can (Docs/mcp.md D2, M3): an asset write -- through the Assets
   * panel's own step when a tab is open, the routes' work in-process when none is (or none has the panel made).
   */
  offline?: boolean;
}

/** A relayed call's usual deadline: the relay's 15 s, as before the server. */
export const RELAY_MS = 15_000;
/** A call that waits for the live compile -- Apply, Save as prefab: a minute. */
export const COMPILE_MS = 60_000;
/** `job_wait`'s longest wait, whatever it is asked: five minutes, then it answers how the job stands. */
export const JOB_WAIT_MAX = 300_000;
/** A git push or pull: git's own two minutes on the network (`git.ts`' `NETWORK_MS`), and a little. */
export const NETWORK_MS = 130_000;

const READ = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false } as const;
const WRITE = { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false } as const;
/** A write that comes to the same thing twice over: a field set, a scene saved. */
const SETS = { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false } as const;
/** A write that can throw away what nobody saved -- for the inputs `destroysWhen` names. */
const DROPS = { readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: false } as const;
/** A write that sends what it names to the trash, or empties it: asks under Auto (D3). */
const TRASHES = { readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: false } as const;
/** A write that reaches the internet: `tools_download`. */
const FETCHES = { readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: true } as const;
/**
 * `asset_import`'s `from`, really outside the project (every link followed): it asks, even under Unsafe auto. A path
 * that is no absolute one, or names nothing, is the tool's to refuse, never read.
 */
function readsOutside(input: Record<string, unknown>, place: Place): string | null {
  const from = typeof input.from === 'string' ? input.from : '';
  // Not absolute -- relative, `~` -- is refused by `importSource` before anything is read: no card for what cannot run.
  if (!/^([\\/]|[A-Za-z]:[\\/])/.test(from)) return null;
  const real = place.real(from);
  if (real === null) return null;
  const root = (place.real(place.root) ?? place.root).replace(/[\\/]+$/, '');
  const inside = real.startsWith(`${root}/`) || real.startsWith(`${root}\\`);
  return inside ? null : `it reads ${real}, outside the project`;
}

/** `any: true`: a step that is not Claude's -- the person's own work -- taken back or done again. */
const anyStep = (input: Record<string, unknown>): boolean => input.any === true;

/** `git_branch` listing: a read; making or switching one is a write. */
const lists = (input: Record<string, unknown>): boolean => input.action === undefined || input.action === 'list';

/**
 * `tools_set` pointing the exports at a program (a path, not `''` to forget one): the dev server will run it -- a
 * program outside the project's files, so the person says, at every level (Unsafe auto's floor).
 */
const pointsAtProgram = (input: Record<string, unknown>): string | null =>
  typeof input.path === 'string' && input.path !== '' ? `it sets ${String(input.tool)} to ${input.path}, a program the dev server will run` : null;

/** `tools_download`: a program fetched from the internet onto this machine (the app's data folder), outside the project: it asks, at every level. */
const downloads = (input: Record<string, unknown>): string => `it downloads ${String(input.tool ?? 'a tool')} from the internet into this machine's app data, and sets the exports to run it`;

/** `confirm: true` on a switch with local changes: what the Git card asks before (the host's ask rule's `git switch`). */
const confirms = (input: Record<string, unknown>): boolean => input.confirm === true;

/** A path as the turn's files are kept: project-relative, `/` between, no leading `./`. */
const relative = (path: string, root: string): string => {
  const p = path.replace(/\\/g, '/');
  const r = root.replace(/\\/g, '/').replace(/\/+$/, '');
  return (p.startsWith(`${r}/`) ? p.slice(r.length + 1) : p).replace(/^(\.\/)+/, '');
};

/**
 * `git_commit` naming a file the running turn did not write: the person's own work committed, which the Git card's
 * ticks leave theirs to choose -- a card under Auto, Unsafe auto lets it by. `all` is the turn's own files alone.
 */
const commitsOthers = (input: Record<string, unknown>, place?: Place): boolean => {
  if (!Array.isArray(input.paths)) return false;
  const mine = new Set(place?.written ?? []);
  return input.paths.some((p) => typeof p !== 'string' || !mine.has(relative(p, place?.root ?? '')));
};

/** `discard: true`: what nobody saved goes. */
const discards = (input: Record<string, unknown>): boolean => input.discard === true;

/** Every tool of the server, in the order it lists them. */
export const CATALOG = [
  { name: 'studio_state', area: 'studio', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  // Docs/terminal.md D8: what a column turn is told, as a tool -- a terminal's run reads it mid-turn.
  { name: 'studio_context', area: 'studio', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'scene_query', area: 'scene', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'scene_entity', area: 'scene', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'scene_set', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: true },
  { name: 'scene_create', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: true },
  { name: 'batch', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: true },
  { name: 'scene_describe', area: 'scene', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'prefab_info', area: 'prefab', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'scene_destroy', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_duplicate', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_reparent', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_rename', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_component', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_flags', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_relate', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_unrelate', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  // P4: a data component's list and dictionary: the inspector's +, × and grip.
  { name: 'scene_list_insert', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_list_remove', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_list_move', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_main_camera', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_select', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  // S5: the tree's Copy and Paste -- entities from one scene into another, or from the person's clipboard.
  { name: 'scene_copy', area: 'scene', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'scene_paste', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_override', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_save_prefab', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_open_prefab', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  {
    name: 'scene_close_prefab', area: 'scene', kind: 'page', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false,
    // Back with `save: false`: the prefab's changes nobody saved go.
    destroysWhen: (input: Record<string, unknown>) => input.save === false,
  },
  { name: 'scene_save', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_save_as', area: 'scene', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_open', area: 'scene', kind: 'page', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false, destroysWhen: discards },
  { name: 'scene_new', area: 'scene', kind: 'page', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false, destroysWhen: discards },
  // S5: the Scenes page's Import… -- a world save as a new scene, in place of the world.
  { name: 'scene_import', area: 'scene', kind: 'page', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false, destroysWhen: discards },
  { name: 'scene_start', area: 'scene', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'scene_list', area: 'scene', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  // M3: assets -- the reads the dev server's, each write the Assets panel's step in a tab, else the server's (`offline`).
  { name: 'asset_list', area: 'asset', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'asset_info', area: 'asset', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'asset_new', area: 'asset', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: true, offline: true },
  { name: 'asset_move', area: 'asset', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: true, offline: true },
  { name: 'asset_uses', area: 'asset', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'asset_thumb', area: 'asset', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'material_get', area: 'material', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'prefab_file', area: 'prefab', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'asset_import', area: 'asset', kind: 'server', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false, asksWhen: readsOutside },
  { name: 'asset_copy', area: 'asset', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  { name: 'asset_delete', area: 'asset', kind: 'page', annotations: TRASHES, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  { name: 'asset_restore', area: 'asset', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  { name: 'asset_empty_trash', area: 'asset', kind: 'server', annotations: TRASHES, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'asset_options', area: 'asset', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  { name: 'material_set', area: 'material', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  { name: 'prefab_edit', area: 'prefab', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'asset_export', area: 'asset', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  // M4: play and view -- each the page's, through the same functions as F5, F6, F10, Shift+F5, F, the cube and Z.
  { name: 'play_state', area: 'play', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'play_start', area: 'play', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'play_pause', area: 'play', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'play_step', area: 'play', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'play_stop', area: 'play', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'view_shot', area: 'view', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'view_get', area: 'view', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'view_set', area: 'view', kind: 'page', annotations: SETS, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'view_focus', area: 'view', kind: 'page', annotations: SETS, deadline: RELAY_MS, alwaysLoad: false },
  // The game view (Docs/game-view.md D7): the rect of the canvas the game is drawn in, Maximize on Play, the presets.
  { name: 'game_view_state', area: 'game', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'game_view_set', area: 'game', kind: 'page', annotations: SETS, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'game_view_preset', area: 'game', kind: 'page', annotations: SETS, deadline: RELAY_MS, alwaysLoad: false },
  // Physics (Docs/physics.md §7): physics.json read and written, the world asked by a ray or a shape, a collider fitted.
  { name: 'physics_state', area: 'physics', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'physics_settings_set', area: 'physics', kind: 'page', annotations: SETS, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'physics_raycast', area: 'physics', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'physics_overlap', area: 'physics', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'physmat_set', area: 'physmat', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  { name: 'physics_fit', area: 'physics', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'history_list', area: 'history', kind: 'page', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'history_undo', area: 'history', kind: 'page', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false, destroysWhen: anyStep },
  { name: 'history_redo', area: 'history', kind: 'page', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false, destroysWhen: anyStep },
  // M5: studio and code -- the dev server's, each through the studio routes' own work (`studio/calls.ts`).
  { name: 'problems_list', area: 'problems', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: true },
  { name: 'console_read', area: 'console', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'tests_run', area: 'tests', kind: 'server', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: true },
  { name: 'build_run', area: 'build', kind: 'server', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'preview_start', area: 'preview', kind: 'server', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'preview_stop', area: 'preview', kind: 'server', annotations: SETS, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'ts_diagnostics', area: 'ts', kind: 'server', annotations: READ, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'ts_definition', area: 'ts', kind: 'server', annotations: READ, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'ts_references', area: 'ts', kind: 'server', annotations: READ, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'ts_hover', area: 'ts', kind: 'server', annotations: READ, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'code_search', area: 'code', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  // The Code card tree's Rename and drag, and its Delete: a move rewrites imports, a delete is for good.
  { name: 'code_move', area: 'code', kind: 'server', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'code_delete', area: 'code', kind: 'server', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'git_status', area: 'git', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'git_diff', area: 'git', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'git_log', area: 'git', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  // The turn's own files a write; a file it did not write -- the person's work -- asks as a destructive call does.
  { name: 'git_commit', area: 'git', kind: 'server', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false, destroysWhen: commitsOthers },
  {
    name: 'git_branch', area: 'git', kind: 'server', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false,
    // Listing reads; making one or switching writes; switching with local changes, confirmed, asks as the card does.
    readsWhen: lists,
    destroysWhen: confirms,
  },
  { name: 'git_push', area: 'git', kind: 'server', annotations: DROPS, deadline: NETWORK_MS, alwaysLoad: false },
  { name: 'git_pull', area: 'git', kind: 'server', annotations: DROPS, deadline: NETWORK_MS, alwaysLoad: false },
  // M6: the Model tab -- its page's own steps where the tab's state matters, the assets server's work otherwise.
  { name: 'model_open', area: 'model', kind: 'page', annotations: DROPS, deadline: COMPILE_MS, alwaysLoad: false, destroysWhen: discards },
  { name: 'model_info', area: 'model', kind: 'page', annotations: READ, deadline: COMPILE_MS, alwaysLoad: true },
  { name: 'model_params_get', area: 'model', kind: 'server', annotations: READ, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'model_params_set', area: 'model', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'model_preview', area: 'model', kind: 'page', annotations: READ, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'model_export', area: 'model', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'model_trace', area: 'model', kind: 'server', annotations: READ, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'model_materials_set', area: 'model', kind: 'page', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'model_pose', area: 'model', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false },
  // S5: Make a script for it -- the Assets panel's step in a tab, the assets server's work with none.
  { name: 'model_adopt', area: 'model', kind: 'page', annotations: WRITE, deadline: COMPILE_MS, alwaysLoad: false, offline: true },
  // S5: Config ▸ Assets ▸ Tools -- the export tools looked for again, a path set, ffmpeg downloaded.
  { name: 'tools_check', area: 'tools', kind: 'server', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false },
  { name: 'tools_set', area: 'tools', kind: 'server', annotations: SETS, deadline: COMPILE_MS, alwaysLoad: false, asksWhen: pointsAtProgram },
  { name: 'tools_download', area: 'tools', kind: 'server', annotations: FETCHES, deadline: COMPILE_MS, alwaysLoad: false, asksWhen: downloads },
  { name: 'job_status', area: 'job', kind: 'server', annotations: READ, deadline: RELAY_MS, alwaysLoad: false },
  { name: 'job_wait', area: 'job', kind: 'server', annotations: READ, deadline: JOB_WAIT_MAX + RELAY_MS, alwaysLoad: false },
  // S5: the Build and Tests cards' Stop -- the studio's task running, and the job that follows it.
  { name: 'job_cancel', area: 'job', kind: 'server', annotations: SETS, deadline: RELAY_MS, alwaysLoad: false },
  {
    name: 'claude_settings',
    area: 'claude',
    kind: 'server',
    annotations: SETS,
    deadline: RELAY_MS,
    alwaysLoad: false,
    readsWhen: (input: Record<string, unknown>) => input.model === undefined && input.effort === undefined && input.review === undefined,
  },
] as const satisfies readonly ToolMeta[];

type Entry = (typeof CATALOG)[number];
/** Every tool's name. */
export type ToolName = Entry['name'];
/** The page tools' names: relayed to a studio tab (`api-types.ts` hands them to the editor's dispatcher). */
export type PageToolName = Extract<Entry, { kind: 'page' }>['name'];
/** The server tools' names: run in the dev server. */
export type ServerToolName = Extract<Entry, { kind: 'server' }>['name'];

/** The longest deadline of any tool: what the CLI's own tool-call bound must stay above (`MCP_TOOL_TIMEOUT`). */
export const LONGEST_MS = Math.max(...CATALOG.map((m): number => m.deadline));

/** The page tools' names, as the page knows them. */
export const PAGE_TOOLS: readonly PageToolName[] = CATALOG.flatMap((m) => (m.kind === 'page' ? [m.name] : []));

/** The tools that change something -- every one but the reads (`readOnlyHint`): what a turn that answers in words refuses. */
export const WRITERS: readonly ToolName[] = CATALOG.flatMap((m) => (m.annotations.readOnlyHint ? [] : [m.name]));

/**
 * A turn's `deny` (`TurnRequest.deny`) naming every studio tool that writes, in one word: the session reads it as
 * `WRITERS`, each as the agent calls it -- so the Git card's draft refuses the writers the catalogue has, however many.
 */
export const DENY_WRITERS = `${STUDIO_TOOLS}writers` as const;

/** A turn's `deny` as the session keeps it: `DENY_WRITERS` read as every writer of the catalogue. */
export function deniedTools(list: readonly string[]): string[] {
  return [...new Set(list.flatMap((name) => (name === DENY_WRITERS ? WRITERS.map((w) => `${STUDIO_TOOLS}${w}`) : [name])))];
}

/** A tool by its name, bare (`scene_set`) or as the agent calls it (`mcp__studio__scene_set`); undefined for any other. */
export function metaOf(tool: string): ToolMeta | undefined {
  const name = tool.startsWith(STUDIO_TOOLS) ? tool.slice(STUDIO_TOOLS.length) : tool;
  return (CATALOG as readonly ToolMeta[]).find((m) => m.name === name);
}

/** What a call to a studio tool is, for the gate: a read, a write, or destructive -- by its annotations, and its input (and the turn's files, `place`) where that decides. */
export function callKind(meta: ToolMeta, input: Record<string, unknown>, place?: Place): 'read' | 'write' | 'destructive' {
  if (meta.annotations.readOnlyHint || meta.readsWhen?.(input) === true) return 'read';
  if (meta.destroysWhen) return meta.destroysWhen(input, place) ? 'destructive' : 'write';
  return meta.annotations.destructiveHint ? 'destructive' : 'write';
}
