/**
 * `vibe mcp` (Docs/mcp.md M7, D1): the running dev server's `/__mcp` endpoint for outside clients -- its URL, its
 * token and the exact line to add it to a terminal Claude Code, and a JSON block for any other MCP client -- read off
 * the file the dev server keeps (`token.ts`: `.cache/agent/<port>/mcp.json`, 0600, gone when it exits). Only while
 * one runs. `--rotate` writes a new token into that file; the server takes it at its next request, the old one
 * refused from then on. `--port <n>` picks one where several run.
 *
 * Never runs `claude mcp add` itself: the person's own Claude Code config is theirs to change. Node only.
 */
import { newToken, runningEndpoints, writeEndpoint, type EndpointRecord } from './token.ts';

/** The words `vibe mcp` prints for a record: the URL, the token, the line, the JSON. */
export function endpointWords(r: EndpointRecord): string[] {
  const header = `Authorization: Bearer ${r.token}`;
  const json = { mcpServers: { studio: { type: 'http', url: r.url, headers: { Authorization: `Bearer ${r.token}` } } } };
  return [
    `The studio's MCP endpoint (the dev server on port ${r.port}, pid ${r.pid}):`,
    `  URL    ${r.url}`,
    `  Token  ${r.token}`,
    '',
    'Add it to a terminal Claude Code (run in this project\'s folder):',
    `  claude mcp add --transport http studio ${r.url} --header "${header}"`,
    '',
    'Any other MCP client (Streamable HTTP):',
    ...JSON.stringify(json, null, 2).split('\n').map((l) => `  ${l}`),
    '',
    'What it may do is the person\'s choice: Config ▸ Claude ▸ Settings, "Outside clients" -- read-only unless changed.',
    'The token is made anew each time the dev server starts (add it again then); vibe mcp --rotate makes a new one now.',
  ];
}

export async function mcpCommand(root: string, args: readonly string[], out: (line: string) => void = console.log, error: (line: string) => void = console.error): Promise<number> {
  const at = args.indexOf('--port');
  const port = at < 0 ? undefined : Number(args[at + 1]);
  if (port !== undefined && (!Number.isInteger(port) || port <= 0)) {
    error(`--port takes a number, not ${args[at + 1] ?? 'nothing'}`);
    return 2;
  }
  const unknown = args.filter((a, i) => a !== '--rotate' && a !== '--port' && !(i > 0 && args[i - 1] === '--port'));
  if (unknown.length > 0) {
    error(`vibe mcp takes --rotate and --port <n>, not ${unknown.join(' ')}`);
    return 2;
  }
  const running = runningEndpoints(root).filter((e) => port === undefined || e.record.port === port);
  if (running.length === 0) {
    error(port === undefined ? 'No dev server runs in this project: start it (npm run dev), then vibe mcp.' : `No dev server of this project runs on port ${port}.`);
    return 1;
  }
  if (running.length > 1) {
    error(`Dev servers run on ports ${running.map((e) => e.record.port).join(', ')}: say which, --port <n>.`);
    return 2;
  }
  const { file, record } = running[0]!;
  let shown = record;
  if (args.includes('--rotate')) {
    shown = { ...record, token: newToken(), made: new Date().toISOString() };
    writeEndpoint(file, shown);
    out('A new token: the dev server takes it at its next request, and refuses the old one.');
    out('');
  }
  for (const line of endpointWords(shown)) out(line);
  return 0;
}
