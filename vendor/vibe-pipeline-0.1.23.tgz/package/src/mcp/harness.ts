/**
 * The studio MCP server's end-to-end harness (Docs/mcp.md §2 rule 10, §5 M1): the server driven through the MCP
 * protocol by script, with no model -- so the whole surface is checked in `npm test`.
 *
 * - **The dev server's own pieces, in-process**: the agent API (`../agent/server.ts`' `createAgentServer`) on a bare
 *   `http` server on a free loopback port -- its relay and its `POST /__agent/mcp/answer`, the routes a studio tab
 *   answers on -- and the studio server (`registry.ts`' `studioServer`) made with the kit it is handed: the SDK's own
 *   `tool()` and `createSdkMcpServer` in the test, so the schemas, the annotations and `alwaysLoad` are the CLI's.
 * - **An MCP client over an in-memory transport** joined to the server's own `McpServer` (`instance.connect`): JSON-RPC
 *   as the CLI speaks it -- `initialize`, `tools/list`, `tools/call` with a `_meta` (a progress token, the CLI's
 *   tool_use id) -- and the progress notifications a call is sent, kept by token.
 * - **A stand-in studio tab** (`page`): a socket on the API that says hello as a studio tab does and answers each
 *   relayed call over HTTP with the test's canned facts -- **not** the page's real dispatcher
 *   (`packages/editor/src/mcp/page.ts`, which the pipeline may not import: its own node tests run it on a world);
 *   none, and no tab is open. A real browser is the live check's (Docs/mcp.md §9).
 * - **The permission gate, where given** (`gate`: the session's `createCanUseTool`, `../agent/permissions.ts`): each
 *   call asked of it first, as the CLI asks `canUseTool` before it calls a tool -- a denial answered as the CLI
 *   answers the model, the tool never called. Left out, every call goes straight to the server.
 *
 * Nothing at module level; the SDK is never imported here -- the kit is handed in.
 */
import { createServer, request, type IncomingMessage, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import type { CanUseTool } from '@anthropic-ai/claude-agent-sdk';
import type { McpAnswerRequest, McpCall } from '../agent/api-types.ts';
import type { Conversations } from '../agent/conversations.ts';
import { createAgentServer, type AgentServer } from '../agent/server.ts';
import { STUDIO_TOOLS } from './catalog.ts';
import { createJobs, type Jobs } from './jobs.ts';
import { studioServer, type McpKit, type StudioContext } from './registry.ts';

/** A JSON-RPC message, as MCP's transport carries it. */
type Message = { jsonrpc: '2.0'; id?: number | string; method?: string; params?: Record<string, unknown>; result?: unknown; error?: { code: number; message: string } };

/** What a tool call came to, as the client reads it: MCP's result, and the progress notifications it was sent. */
export interface CallAnswer {
  content: ({ type: 'text'; text: string } | { type: 'image'; data: string; mimeType: string })[];
  isError?: boolean;
  /** Each `notifications/progress` for the call's token, as sent. */
  progress: Record<string, unknown>[];
  /** A JSON-RPC error instead of a result: the input refused before the handler ran. */
  error?: { code: number; message: string };
  /** The gate's denial: the tool never called (`gate` given). */
  denied?: string;
}

export interface HarnessOptions {
  /** The SDK's makings: its own `tool()` and `createSdkMcpServer` (a test's import), or stand-ins. */
  kit: McpKit;
  /** The stand-in studio tab: each relayed call answered, as the page would; null for no answer (a call left to its deadline). None: no tab open. */
  page?: (call: McpCall) => Omit<McpAnswerRequest, 'id'> | Promise<Omit<McpAnswerRequest, 'id'>> | null;
  /** The jobs the server tools read: the harness's own when left out. */
  jobs?: Jobs;
  /** A relayed call waits at most this long, whatever its tool's deadline: a test's short one. */
  relayMs?: number;
  /** The rest of the context, as a test wants it: Claude's settings, the problems count, the models, the assets server's work. */
  context?: Partial<Pick<StudioContext, 'settings' | 'problems' | 'models' | 'row' | 'root' | 'assets' | 'studio' | 'wrote' | 'written' | 'projectTools'>>;
  /** The permission gate each call is asked of first, as the CLI asks it (`createCanUseTool`); none, no gate. */
  gate?: CanUseTool;
}

export interface Harness {
  /** `tools/list`: each tool as the CLI sees it. */
  list(): Promise<{ name: string; description: string; annotations?: Record<string, unknown>; _meta?: Record<string, unknown>; inputSchema: Record<string, unknown> }[]>;
  /** `tools/call`, with a progress token and the CLI's tool_use id where given. */
  call(name: string, args?: Record<string, unknown>, meta?: { progressToken?: string; use?: string }): Promise<CallAnswer>;
  /** The calls the stand-in tab was relayed, in order. */
  readonly relayed: McpCall[];
  readonly jobs: Jobs;
  /** The studio page's address, as the words say it. */
  readonly url: string;
  /** Everything stopped: the client, the server, the port let go. */
  close(): Promise<void>;
}

/** The harness up: the API on a free loopback port, the studio server, a client initialised over MCP. */
export async function startHarness(options: HarnessOptions): Promise<Harness> {
  const jobs = options.jobs ?? createJobs();
  const relayed: McpCall[] = [];
  // The relay reads nothing of the conversations; the answer route waits for their disk read, which here is none.
  const conversations = { ready: Promise.resolve(), list: () => [] } as unknown as Conversations;
  let port = 0;
  const api: AgentServer = createAgentServer({ conversations, port: () => port, warn: () => {} });
  const http: Server = createServer((req, res) => {
    void api.handle(req, res).then((handled) => {
      if (!handled) {
        res.statusCode = 404;
        res.end();
      }
    });
  });
  await new Promise<void>((resolve) => http.listen(0, '127.0.0.1', resolve));
  port = (http.address() as AddressInfo).port;
  const url = `http://localhost:${port}/?studio`;

  /** `POST /__agent/mcp/answer`, as the page sends it. */
  const answer = (body: McpAnswerRequest): Promise<number> =>
    new Promise((resolve, reject) => {
      const text = JSON.stringify(body);
      const req = request({ host: '127.0.0.1', port, method: 'POST', path: '/__agent/mcp/answer', headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(text) }, agent: false }, (res) => {
        res.resume();
        res.on('end', () => resolve(res.statusCode ?? 0));
      });
      req.on('error', reject);
      req.end(text);
    });

  // The stand-in studio tab: a loopback socket that says hello, runs each call it is pushed and answers it.
  const closers: (() => void)[] = [];
  if (options.page) {
    const page = options.page;
    const socket = {
      send(data: string) {
        const m = JSON.parse(data) as { event?: string; data?: { mcp?: McpCall } };
        const call = m.event === 'vibebase:agent' ? m.data?.mcp : undefined;
        if (!call) return;
        relayed.push(call);
        void Promise.resolve(page(call)).then((done) => (done === null ? undefined : answer({ ...done, id: call.id } as McpAnswerRequest)));
      },
      on: (_event: 'close', fn: () => void) => void closers.push(fn),
    };
    const req = { socket: { remoteAddress: '127.0.0.1' }, headers: { host: `localhost:${port}` } } as unknown as IncomingMessage;
    api.connection(socket, req);
    api.hello(socket, { tab: 'harness-tab', multi: true });
  }

  const ctx: StudioContext = {
    call: (tool, args, use, deadline) => api.relay(null, { tool, args, turn: null, use }, options.relayMs === undefined ? deadline : Math.min(deadline, options.relayMs)),
    models: async () => new Map(),
    url: () => url,
    jobs,
    ...options.context,
  };
  const server = await studioServer(options.kit, ctx);

  // The client: JSON-RPC over an in-memory transport joined to the server's own McpServer.
  const waiting = new Map<number, (m: Message) => void>();
  const progress = new Map<string, Record<string, unknown>[]>();
  const transport = {
    onmessage: undefined as ((m: Message) => void) | undefined,
    onclose: undefined as (() => void) | undefined,
    onerror: undefined as ((e: Error) => void) | undefined,
    async start(): Promise<void> {},
    async send(m: Message): Promise<void> {
      if (m.method === 'notifications/progress') {
        const token = String(m.params?.progressToken);
        progress.set(token, [...(progress.get(token) ?? []), m.params ?? {}]);
        return;
      }
      if (typeof m.id === 'number' && waiting.has(m.id)) {
        waiting.get(m.id)!(m);
        waiting.delete(m.id);
      }
    },
    async close(): Promise<void> {
      this.onclose?.();
    },
  };
  await (server.instance as unknown as { connect(t: typeof transport): Promise<void> }).connect(transport);
  let next = 0;
  const rpc = (method: string, params: Record<string, unknown>): Promise<Message> =>
    new Promise((resolve) => {
      const id = ++next;
      waiting.set(id, resolve);
      transport.onmessage?.({ jsonrpc: '2.0', id, method, params });
    });
  const init = await rpc('initialize', { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 'studio-harness', version: '1.0.0' } });
  if (init.error) throw new Error(`initialize: ${init.error.message}`);
  transport.onmessage?.({ jsonrpc: '2.0', method: 'notifications/initialized' });

  return {
    async list() {
      const listed = await rpc('tools/list', {});
      if (listed.error) throw new Error(`tools/list: ${listed.error.message}`);
      return (listed.result as { tools: Awaited<ReturnType<Harness['list']>> }).tools;
    },
    async call(name, args = {}, meta = {}) {
      // The gate first, as the CLI asks it before a call: a denial is the model's answer, the tool never called.
      if (options.gate) {
        const asked = await options.gate(`${STUDIO_TOOLS}${name}`, args, { signal: new AbortController().signal, toolUseID: meta.use ?? `harness-${next + 1}`, suggestions: [] } as unknown as Parameters<CanUseTool>[2]);
        if (asked?.behavior === 'deny') return { content: [{ type: 'text', text: asked.message }], isError: true, progress: [], denied: asked.message };
      }
      const _meta: Record<string, unknown> = {};
      if (meta.progressToken !== undefined) _meta.progressToken = meta.progressToken;
      if (meta.use !== undefined) _meta['claudecode/toolUseId'] = meta.use;
      const done = await rpc('tools/call', { name, arguments: args, ...(Object.keys(_meta).length > 0 ? { _meta } : {}) });
      const sent = meta.progressToken === undefined ? [] : (progress.get(meta.progressToken) ?? []);
      if (done.error) return { content: [], progress: sent, error: done.error };
      return { ...(done.result as Omit<CallAnswer, 'progress'>), progress: sent };
    },
    relayed,
    jobs,
    url,
    async close() {
      await transport.close();
      for (const fn of closers) fn();
      await new Promise<void>((resolve) => http.close(() => resolve()));
    },
  };
}
