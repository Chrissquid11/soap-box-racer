/**
 * What a studio tool is, as its area's module writes it (`tools/`, Docs/mcp.md §3): one record per name of the
 * catalogue (`catalog.ts`) -- its description, its input and output schemas made from `zod` as the server is made,
 * its words, and how it runs -- and what the tools are handed of the session and the dev server (`StudioContext`).
 *
 * - **A page tool** is relayed to a studio tab and run there by the page's dispatcher (`packages/editor/src/mcp/`);
 *   here are its words: the agent's (`words`, a line or two, then the JSON) and the transcript row's (`row`), from
 *   the page's facts.
 * - **A server tool** runs in the dev server (`run`) and words its own answer; its row is `row`, from its input and
 *   what it came to.
 * - **Every tool** says its call in a few words from its input alone (`summary`): the transcript's line while it
 *   runs, and a row that was not done.
 *
 * Types and two small helpers; `zod` and the SDK as types only.
 */
import type { z as Zod } from 'zod';
import type { createSdkMcpServer, tool } from '@anthropic-ai/claude-agent-sdk';
import type { AssetsCalls } from '../assets/server.ts';
import type { StudioCalls } from '../studio/calls.ts';
import type { BarChoice, EditorResult, ModelChoice, PermissionLevel, ProjectToolDecl, ProjectToolName, ReviewBar } from '../agent/api-types.ts';
import type { PageToolName, ServerToolName, ToolName } from './catalog.ts';
import type { Jobs } from './jobs.ts';
import type { ToolOutput } from './result.ts';
import type { ModelsOf, PageAnswer, RowWords, ServerFacts } from './words.ts';

/** What the session hands over of the SDK. */
export interface McpKit {
  tool: typeof tool;
  createSdkMcpServer: typeof createSdkMcpServer;
}

/** Claude's settings as `claude_settings` reads them: the four, and what each may be. */
export interface ClaudeSettingsFacts {
  model: string | null;
  effort: string | null;
  review: ReviewBar;
  /** The person's alone: read, never set. */
  level: PermissionLevel;
  models: ModelChoice[];
  bars: BarChoice[];
}

/** What `claude_settings` may set: never the level. */
export interface ClaudeSettingsChange {
  model?: string | null;
  effort?: string | null;
  review?: ReviewBar;
}

/** What the tools need of the session and the dev server. */
export interface StudioContext {
  /** A page tool's call relayed to a studio tab -- the turn's, else the last to say hello -- answered within `deadline` ms. `use`: its `tool_use` id where the CLI said. */
  call(tool: PageToolName | ProjectToolName, args: Record<string, unknown>, use: string | null, deadline: number): Promise<PageAnswer>;
  /** The project's own tools (Docs/mcp.md M7), as the last studio tab declared them: registered beside the built-ins as the server is made. None: none. */
  projectTools?(): readonly ProjectToolDecl[];
  /** Model keys to their export and source (`turn.ts`' `resolveModels`). */
  models: ModelsOf;
  /** The studio page's address, said when none is open. */
  url(): string;
  /** The dev server's jobs. */
  jobs: Jobs;
  /** The Problems card's count now; null where it is not known (no studio routes). */
  problems?(): number | null;
  /** Claude's own settings (D4): read, and set -- each change said in the transcript by the session. None: `claude_settings` is refused. */
  settings?: { read(): ClaudeSettingsFacts; set(change: ClaudeSettingsChange): Promise<ClaudeSettingsFacts> };
  /** The project's root, on disk: what a server tool reads files under (`scene_list`). */
  root?(): string;
  /** The assets server's work in-process (Docs/mcp.md M3): the asset tools' server path. None, or null: no assets server here. */
  assets?(): AssetsCalls | null;
  /** The studio routes' work in-process (Docs/mcp.md M5): the studio and code tools'. None, or null: no studio routes here. */
  studio?(): StudioCalls | null;
  /** Files a tool wrote, moved or removed (project-relative): the running turn's, so Undo this turn puts them back. */
  wrote?(paths: readonly string[]): void;
  /** The files the running turn wrote (project-relative): its Edits and Writes, and its tools' -- `git_commit`'s `all`. None: none. */
  written?(): readonly string[];
  /** A server tool's call done: its transcript row's words (the session's `editor` entry). */
  row?(name: string, args: Record<string, unknown>, use: string | null, row: RowWords): void;
}

/** What the MCP SDK hands a handler beside the arguments: the request's `_meta` (the CLI's tool_use id, a progress token) and a way to notify. */
export interface CallExtra {
  _meta?: Record<string, unknown>;
  sendNotification?(notification: { method: string; params: Record<string, unknown> }): Promise<void>;
}

/** The zod shapes the tools share, made from `z` as the server is (`tools/shapes.ts`). */
export interface Shapes {
  /** An entity id. */
  id: Zod.ZodNumber;
  /** A reference as a file writes it (Docs/asset-ids.md §3): the uid an answer showed, and the key. */
  ref: Zod.ZodType;
  /** The scene open: its name (null: not saved yet), unsaved or not; null for the game's own world. */
  scene: Zod.ZodType;
  /** A job, as `job_status` answers it. */
  job: Zod.ZodType;
  /** An entity named (Docs/mcp.md §6): its ref -- a number, as answers give it -- or its path of names (big crate/rider). */
  entity: Zod.ZodType;
  /** Several of them. */
  entities: Zod.ZodType;
  /** An entity as an answer names it: ref, id, path, name. */
  row: Zod.ZodType;
}

/** What every tool says of itself. */
interface ToolBase<N extends ToolName> {
  name: N;
  description: string;
  /** The input's zod shape, as the SDK's `tool()` takes it. */
  input(z: typeof Zod, s: Shapes): Record<string, Zod.ZodType>;
  /** The JSON its result carries after the words; none, words alone. */
  output?(z: typeof Zod, s: Shapes): Zod.ZodType;
  /** The call in a few words, from its input alone: the transcript's line while it runs, and a row not done. */
  summary(args: Record<string, unknown>): string;
}

/** A page tool's facts: the page's result for it. */
export type ResultOf<N extends PageToolName> = Extract<EditorResult, { tool: N }>;

/** A page tool: relayed, run in the tab; its facts worded here. */
export interface PageTool<N extends PageToolName = PageToolName> extends ToolBase<N> {
  kind: 'page';
  /** The page's facts as the agent reads them: a line or two, then the JSON. */
  words(result: ResultOf<N>, models: ModelsOf, server: ServerFacts): ToolOutput | Promise<ToolOutput>;
  /** The transcript row's words once the page has done it. */
  row(result: ResultOf<N>, args: Record<string, unknown>): RowWords;
  /**
   * With no studio tab to run it (`offline` in the catalogue, D2): the same facts from the dev server -- the routes'
   * work in-process (`StudioContext.assets`). Throws `ToolRefusal` in words, as the page's refusal reads.
   */
  offline?(ctx: StudioContext, args: Record<string, unknown>): Promise<ResultOf<N>>;
  /** Its facts, either way, before they are worded: an export's jobs followed as one of the studio's (`asset_export`). */
  settle?(ctx: StudioContext, result: ResultOf<N>): Promise<ResultOf<N>>;
}

/** A server tool: run in the dev server. */
export interface ServerTool<N extends ServerToolName = ServerToolName> extends ToolBase<N> {
  kind: 'server';
  run(ctx: StudioContext, args: Record<string, unknown>, extra: CallExtra): Promise<ToolOutput>;
  /** Its row in the transcript, from its input and what it came to. */
  row(args: Record<string, unknown>, out: ToolOutput): RowWords;
}

/** Every tool of the catalogue, by name: one record each, the compiler holding the set whole. */
export type ToolDefs = { [N in PageToolName]: PageTool<N> } & { [N in ServerToolName]: ServerTool<N> };

/** A page tool's record, typed by its name: its result's type follows. */
export const pageTool = <N extends PageToolName>(name: N, def: Omit<PageTool<N>, 'name' | 'kind'>): PageTool<N> => ({ name, kind: 'page', ...def });

/** A server tool's record. */
export const serverTool = <N extends ServerToolName>(name: N, def: Omit<ServerTool<N>, 'name' | 'kind'>): ServerTool<N> => ({ name, kind: 'server', ...def });

/** A refusal a server tool's run throws: said to the agent as the tool's error. */
export class ToolRefusal extends Error {}

/** The CLI's own name for a call's `tool_use`, in the request's `_meta`. */
export const useOf = (extra: unknown): string | null => {
  const id = (extra as CallExtra | undefined)?._meta?.['claudecode/toolUseId'];
  return typeof id === 'string' && id !== '' ? id : null;
};

/** An entity named, in a few words: a path as it is, a ref as `entity <ref>`. */
export const oneWhom = (entity: unknown): string => (typeof entity === 'string' ? entity : `entity ${String(entity)}`);

/** Entities named, in a few words: one as `oneWhom`, several counted, none the selection. */
export const onWhom = (entities: unknown): string =>
  Array.isArray(entities) ? (entities.length === 1 ? oneWhom(entities[0]) : `${entities.length} entities`) : 'the selection';
