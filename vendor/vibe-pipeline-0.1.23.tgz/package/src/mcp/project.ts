/**
 * A project's own MCP tools (Docs/mcp.md M7, Docs/packages.md §10): declared in its `src/tools/` (`mcpTools`, each a
 * name, a description, an input as JSON Schema, annotations and a page handler), said to the dev server in the studio
 * tab's hello (`ProjectToolDecl`, the handler left on the page), and registered beside the built-ins as
 * `project_<name>` -- relayed to the tab as a page tool is, run there by the project's handler as one world step `Z`
 * undoes, and gated as any tool is, by its annotations.
 *
 * - **JSON Schema, not zod**: a project needs no dependency of its own; the server turns it into zod (`z.fromJSONSchema`)
 *   for the SDK's `tool()`, so Claude sees its properties, types and descriptions. One that does not convert is
 *   served with no schema of its arguments -- its handler checks them, as every handler does.
 * - **Checked as heard** (`checkDecls`): a name of lowercase words (`tiles_paint`), a description, an object schema
 *   of at most 16 KB as JSON, no `$ref` (nor any other reference or anchor: no recursion) and nested at most 32 deep;
 *   the rest left out -- a schema refused is the tool refused, never served with no schema -- and said in the dev
 *   server's log.
 * - **Read as a server is made**: the panel's session at its start, an outside client's session at its `initialize`.
 *   A tool declared later is there from the next conversation (or Clear), the next client session.
 *
 * Nothing at module level but the words; `zod` handed in.
 */
import type { z as Zod } from 'zod';
import { PROJECT_PREFIX, type ProjectToolDecl, type ProjectToolName, type ProjectToolResult } from '../agent/api-types.ts';
import { COMPILE_MS, type ToolMeta } from './catalog.ts';
import type { StudioTool } from './registry.ts';
import { useOf } from './tool.ts';
import { awayOf, awayWords } from './words.ts';

/** What Claude calls a project's tool before its name (`api-types.ts`' one spelling, the page's too). */
export { PROJECT_PREFIX };

/** The most a tool's input schema may be, as JSON: what the SDK's conversion and Claude's context take of it. */
export const SCHEMA_MAX = 16 * 1024;
/** How deep a schema may nest: deeper is no tool's input. */
const SCHEMA_DEPTH = 32;
/** The keywords that name another schema: a reference, or what one points at -- a recursion's way in. */
const REFERENCES = new Set(['$ref', '$dynamicRef', '$recursiveRef', '$anchor', '$dynamicAnchor', '$recursiveAnchor']);

/** What is wrong with an input schema, in words; null when nothing is: its size, a reference, its depth. */
export function schemaProblem(input: Record<string, unknown>): string | null {
  const size = Buffer.byteLength(JSON.stringify(input));
  if (size > SCHEMA_MAX) return `its input schema is ${Math.ceil(size / 1024)} KB as JSON -- at most ${SCHEMA_MAX / 1024} KB`;
  const walk = (value: unknown, depth: number): string | null => {
    if (typeof value !== 'object' || value === null) return null;
    if (depth > SCHEMA_DEPTH) return `its input schema nests more than ${SCHEMA_DEPTH} deep`;
    if (Array.isArray(value)) {
      for (const item of value) {
        const found = walk(item, depth + 1);
        if (found) return found;
      }
      return null;
    }
    for (const [key, item] of Object.entries(value)) {
      if (REFERENCES.has(key)) return `its input schema uses ${key} -- write each property out: no references, no recursion`;
      const found = walk(item, depth + 1);
      if (found) return found;
    }
    return null;
  };
  return walk(input, 0);
}

/** A project tool's name, as the project writes it: lowercase words joined by `_`. */
const NAME = /^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$/;

/** The declarations of a hello, each checked: the good kept (by name, the first of a name), the rest said in `bad`. */
export function checkDecls(raw: unknown): { decls: ProjectToolDecl[]; bad: string[] } {
  const decls: ProjectToolDecl[] = [];
  const bad: string[] = [];
  if (!Array.isArray(raw)) return { decls, bad: raw === undefined ? [] : ['tools is not a list'] };
  for (const item of raw.slice(0, 64)) {
    const d = item as Partial<ProjectToolDecl> | null;
    const name = typeof d?.name === 'string' ? d.name : '';
    if (!NAME.test(name) || name.length > 48) {
      bad.push(`${JSON.stringify(name)} is no tool name: lowercase words joined by _ (tiles_paint)`);
      continue;
    }
    if (decls.some((x) => x.name === name)) {
      bad.push(`${name} is declared twice: the first kept`);
      continue;
    }
    if (typeof d!.description !== 'string' || d!.description.trim() === '' || d!.description.length > 4000) {
      bad.push(`${name}: a description is what Claude reads of it -- a few sentences, at most 4000 characters`);
      continue;
    }
    const input = d!.input as Record<string, unknown> | undefined;
    if (typeof input !== 'object' || input === null || Array.isArray(input) || (input.type !== undefined && input.type !== 'object')) {
      bad.push(`${name}: input is a JSON Schema of an object ({ type: 'object', properties })`);
      continue;
    }
    const problem = schemaProblem(input);
    if (problem !== null) {
      bad.push(`${name}: ${problem} -- the tool is not served`);
      continue;
    }
    const a = d!.annotations ?? {};
    decls.push({ name, description: d!.description, input, annotations: { ...(a.readOnly === true ? { readOnly: true } : {}), ...(a.destructive === true ? { destructive: true } : {}), ...(a.idempotent === true ? { idempotent: true } : {}) } });
  }
  return { decls, bad };
}

/** A project tool as the gate and the server know it: a page tool of the area `project`, a minute to answer (it may wait on an Apply). */
export function projectMeta(decl: ProjectToolDecl): ToolMeta {
  const a = decl.annotations ?? {};
  return {
    name: `${PROJECT_PREFIX}${decl.name}`,
    area: 'project',
    kind: 'page',
    annotations: { readOnlyHint: a.readOnly === true, destructiveHint: a.readOnly !== true && a.destructive === true, idempotentHint: a.idempotent === true || a.readOnly === true, openWorldHint: false },
    deadline: COMPILE_MS,
    alwaysLoad: false,
  };
}

/** A tool's catalogue entry among the project's, by its name as the agent calls it (`mcp__studio__project_…`) or bare. */
export function projectMetaOf(decls: readonly ProjectToolDecl[], tool: string): ToolMeta | undefined {
  const bare = tool.replace(/^mcp__studio__/, '');
  const decl = bare.startsWith(PROJECT_PREFIX) ? decls.find((d) => d.name === bare.slice(PROJECT_PREFIX.length)) : undefined;
  return decl && projectMeta(decl);
}

/** Its input's zod shape, from its JSON Schema: none where it does not convert (its handler checks the arguments). */
function shapeOf(z: typeof Zod, input: Record<string, unknown>): Record<string, Zod.ZodType> {
  try {
    const made = z.fromJSONSchema({ type: 'object', ...input } as never) as unknown as { shape?: Record<string, Zod.ZodType> };
    return made.shape ?? {};
  } catch {
    return {};
  }
}

/** The project's tools as the server's: each relayed to the studio tab and worded from what the project's handler answered. */
export function projectTools(z: typeof Zod, decls: readonly ProjectToolDecl[]): StudioTool[] {
  return decls.map((decl) => {
    const meta = projectMeta(decl);
    const name = meta.name as ProjectToolName;
    return {
      ...meta,
      description: `${decl.description} (The project's own tool, from its src/tools/: run in the studio tab${meta.annotations.readOnlyHint ? '' : ', its edits one step Z undoes'}.)`,
      input: shapeOf(z, decl.input),
      async run(ctx, args, extra) {
        const answer = await ctx.call(name, args, useOf(extra), meta.deadline);
        if ('away' in answer) return { words: awayWords(awayOf(answer), name, meta.deadline, ctx.url()), isError: true };
        if ('error' in answer) return { words: answer.error, isError: true };
        // The page's answer for a project tool is its own shape, not a built-in's (`ProjectToolResult`).
        const r = answer.result as unknown as ProjectToolResult;
        const step = r.step === null ? '' : ` One step on the editor's undo stack, "${r.step}", which the person undoes with Z.`;
        return { words: `${r.words}${step}`, ...(r.json !== null && r.json !== undefined ? { json: r.json } : {}) };
      },
    };
  });
}
