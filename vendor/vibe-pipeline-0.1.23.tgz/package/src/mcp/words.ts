/**
 * What the studio tools' words share (Docs/mcp.md §2 rule 6): the page answers facts, and each tool words its own
 * (`tools/`: what the agent reads, and the transcript row's) with these -- a number tidied, whom a call acted on,
 * what is open in a line -- and the words for a call not done.
 *
 * - **Not done** is a fact too (`PageAnswer`'s `away`): no studio tab open (`gone`: the URL to open said),
 *   a playtest running (`playtest`: T stops it), or no answer within the tool's deadline (`timeout`: the call
 *   may still land -- read `studio_state` before trying again).
 * - **`studio_state`** is the page's facts and the server's (`ServerFacts`: the problems count, the jobs) in one
 *   answer; with no studio tab open it still answers -- the server's half, and that none is open -- rather than
 *   an error: what is open is what it is asked.
 *
 * Pure but for `jobLine`'s import: no SDK, no zod.
 */
import type { EditorResult, SelectionResult } from '../agent/api-types.ts';
import type { ModelFiles } from '../agent/turn.ts';
import { jobLine, type Job } from './jobs.ts';
import type { ToolOutput } from './result.ts';

/**
 * Why the studio could not act: no tab (`gone`), a tab with no Assets panel made for an asset tool (`nopanel`, refused
 * before any step), a playtest, no answer in time.
 */
export type Away = 'playtest' | 'gone' | 'nopanel' | 'timeout';

/**
 * What a relayed call came to: the page's result, its refusal, or why the studio could not. `delivered` on a `gone`:
 * the call had reached a tab, which may have begun it -- never run again by the dev server.
 */
export type PageAnswer = { result: EditorResult } | { error: string } | { away: Away; delivered?: boolean };

/**
 * Was a call not done known to be refused **before** any tab could begin it -- no tab to send it to, or a tab with no
 * Assets panel made: the dev server may run an asset write then (D2). A `gone` after delivery may yet be done.
 */
export const beforeDelivery = (answer: PageAnswer): boolean =>
  'away' in answer && (answer.away === 'nopanel' || (answer.away === 'gone' && answer.delivered !== true));

/** An answer's `away` as its words read it: a `gone` after delivery is `lost` -- it may yet be done. */
export const awayOf = (answer: { away: Away; delivered?: boolean }): Away | 'lost' => (answer.away === 'gone' && answer.delivered === true ? 'lost' : answer.away);

/** A relayed call's answer that came after its time ran out (`timeout` said already): what it did, from `tab`. */
export type LateAnswer = (answer: PageAnswer, tab: string) => void;

/** Model keys to their export and source (`turn.ts`' `resolveModels`). */
export type ModelsOf = (keys: readonly string[]) => Promise<ReadonlyMap<string, ModelFiles>>;

/** What the server adds to `studio_state`: the Problems card's count (null: not known here), and the jobs. */
export interface ServerFacts {
  problems: number | null;
  jobs: Job[];
}

/** The studio page's address, for the words when none is open: `http://localhost:5190/?studio`. */
export const studioUrl = (port: number | undefined): string => `http://localhost:${port ?? 5173}/?studio`;

/** What the agent reads when no studio tab is open. */
export const notOpen = (url: string): string => `The studio is not open: ask the person to open ${url}`;
/** ...and while a playtest runs (not paused): the play tools pause or stop it -- the person's own keys Shift+F5 and Esc (or T, which toggles it). */
export const PLAYTEST = 'A playtest is running in the studio: play_pause pauses it (the editor over its world, its tools working on it), play_stop stops it -- ask the person first if they started it (theirs are F6 to pause, Shift+F5 or Esc to stop)';
/** ...and when the tab did not answer in time: it may still be at it. */
export const timedOut = (tool: string, deadline: number): string =>
  `The studio did not answer ${tool} within ${Math.round(deadline / 1000)} s: it may still be working (a compile), or the tab is busy. It may yet be done -- read studio_state before trying it again.`;

/** ...and when the tab it reached went away before answering: it may have begun it. */
export const lost = (tool: string): string =>
  `The studio tab went away after ${tool} reached it: it may yet be done -- read ${tool.startsWith('asset_') || tool.startsWith('material_') || tool.startsWith('prefab_') ? 'asset_list' : 'studio_state'} before trying it again.`;
/** ...and when the tab has no Assets panel made, for a tool only the panel runs. */
export const NO_PANEL = 'The studio tab has no Assets panel made yet: ask the person to open it (4), then try again';

/** Why the studio could not act, as the agent reads it. */
export function awayWords(away: Away | 'lost', tool: string, deadline: number, url: string): string {
  return away === 'playtest' ? PLAYTEST : away === 'timeout' ? timedOut(tool, deadline) : away === 'lost' ? lost(tool) : away === 'nopanel' ? NO_PANEL : notOpen(url);
}

/** A number as Claude reads it, to seven figures (a 32-bit 2.5999999046 is 2.6); a key field's text as it is. */
export function tidy(n: number | string): number | string;
export function tidy(n: number | string | number[]): number | string | number[];
export function tidy(n: number | string | number[]): number | string | number[] {
  if (Array.isArray(n)) return n.map((x) => tidy(x) as number);
  return typeof n === 'string' ? n : Number.isFinite(n) ? Number(n.toPrecision(7)) : n;
}
/** A value in a line of words: a key's text quoted, so none (`''`) shows; a vector `[1, 2, 0]`. */
export const said = (n: number | string | number[]): string => (Array.isArray(n) ? `[${n.map((x) => String(tidy(x))).join(', ')}]` : typeof n === 'string' ? JSON.stringify(n) : String(tidy(n)));

export const plural = (n: number, one: string, many = `${one}s`): string => `${n} ${n === 1 ? one : many}`;

/** Whom a call acted on, in a few words: one by name, else its id; several counted. */
export function whom(list: readonly { id: number; name: string | null }[]): string {
  if (list.length !== 1) return plural(list.length, 'entity', 'entities');
  const [one] = list;
  return one!.name ? one!.name : `entity ${one!.id}`;
}

/** A step the person had undone, dropped from redo by the call's own: said, so the agent can tell them. */
export function droppedWords(result: EditorResult): string {
  const dropped = 'dropped' in result ? result.dropped : undefined;
  return dropped ? `\nThe person had undone "${dropped}"; this step dropped it from the redo side, so Y no longer brings it back -- tell them.` : '';
}

/** What is open, in a line: the tab, the scene, the prefab, the playtest, the problems and the jobs. */
export function openWords(state: SelectionResult | null, server: ServerFacts): string {
  const running = server.jobs.filter((j) => j.state === 'running');
  const tail = `${server.problems === null ? '' : ` ${plural(server.problems, 'problem')} in the Problems card.`}${running.length > 0 ? ` Jobs running: ${running.map(jobLine).join('; ')}.` : ''}`;
  if (state === null) return `No studio tab is open, so nothing of the scene can be read.${tail}`;
  const scene = state.scene === null ? "the game's own world (no scene file)" : `the scene ${state.scene.name ?? '(not saved yet)'}${state.scene.unsaved ? ', unsaved' : ''}`;
  const prefab = state.prefab === null ? '' : `; the prefab ${state.prefab} open to edit`;
  const play = state.playtest === 'none' ? '' : state.playtest === 'running' ? '; a playtest running (scene tools wait until it stops)' : '; a playtest paused (its world is the editor\'s)';
  return `The studio shows ${state.tab === null ? 'the editor' : `its ${state.tab} tab`}: ${scene}${prefab}${play}.${tail}`;
}

/** `studio_state` with no studio tab: the server's half, and that none is open. */
export function closedState(server: ServerFacts, url: string): ToolOutput {
  return { words: `${openWords(null, server)} To work on the scene, ask the person to open ${url}.`, json: { open: false, url, problems: server.problems, jobs: server.jobs }, pretty: true };
}

/** A transcript row's words: done or not, the line, and the hover's detail. */
export interface RowWords {
  ok: boolean;
  words: string;
  detail: string | null;
}
