/**
 * Outside clients (Docs/mcp.md M7, D1): what a client of the dev server's `/__mcp` endpoint -- a terminal Claude Code,
 * another MCP client -- may do. There is no `canUseTool` there: the client asks its own person, by its own rules. So
 * the endpoint serves only what the person chose in Config ▸ Claude ▸ Settings, "Outside clients" (`OutsideLevel`,
 * the project's, on the conversations' index): `off`, nothing; `read`, the reads alone -- the default; `write`, the
 * writes too; `destructive`, the destructive tools too.
 *
 * - **Listed** (`listedFor`): a tool any of whose calls the level allows -- a read, a tool that reads for some inputs
 *   (`readsWhen`: `git_branch` listing), a write under `write`, one destructive only by its input (`destroysWhen`)
 *   under `write` -- its destructive calls refused.
 * - **Each call judged** (`refusalFor`) as the gate judges it (`callKind`), with no turn: `git_commit` naming any path
 *   is destructive here, no turn having written it. A refusal says the level and where the person changes it.
 * - **What asks the person is refused at every level** (`asksWhen`): `tools_set` with a path (a program the dev server
 *   will run), `tools_download`, `asset_import` from outside the project. The panel's Claude puts these to the person on
 *   its card; an outside client has no card, and its own person's yes is no yes of this studio's. Such a tool may still
 *   be listed -- `tools_set` with `''` forgets a path, `asset_import` from inside the project imports -- its asking
 *   calls refused in words: do it in the studio.
 *
 * Nothing at module level but the words; the catalogue's types alone imported.
 */
import type { OutsideLevel } from '../agent/api-types.ts';
import { callKind, type Place, type ToolMeta } from './catalog.ts';

/** The levels, the setting's pick, in order. */
export const OUTSIDE_LEVELS: readonly OutsideLevel[] = ['off', 'read', 'write', 'destructive'];

/** The default: an outside client reads, and asks the person for nothing it could change. */
export const OUTSIDE_DEFAULT: OutsideLevel = 'read';

export const isOutside = (value: unknown): value is OutsideLevel => typeof value === 'string' && (OUTSIDE_LEVELS as readonly string[]).includes(value);

/** Each level in the setting's words. */
export const OUTSIDE_WORDS: Record<OutsideLevel, string> = {
  off: 'off',
  read: 'read-only',
  write: 'read and write',
  destructive: 'read, write and destructive',
};

/** Where the person changes it, said in every refusal. */
const WHERE = 'Config ▸ Claude ▸ Settings, "Outside clients"';

const rank = (level: OutsideLevel): number => OUTSIDE_LEVELS.indexOf(level);

/** Is the tool listed for an outside client at this level: some call of it is allowed. */
export function listedFor(level: OutsideLevel, meta: ToolMeta): boolean {
  if (level === 'off') return false;
  const reads = meta.annotations.readOnlyHint || meta.readsWhen !== undefined;
  if (level === 'read') return reads;
  if (level === 'write') return reads || !meta.annotations.destructiveHint || meta.destroysWhen !== undefined;
  return true;
}

/** Why an outside client's call is refused at this level, or null: it may run. `place` with no turn's files. */
export function refusalFor(level: OutsideLevel, meta: ToolMeta, input: Record<string, unknown>, place: Place): string | null {
  if (level === 'off') return `Outside clients are off in this studio (${WHERE}): the person may turn them on there.`;
  const asks = meta.asksWhen?.(input, { ...place, written: [] }) ?? null;
  if (asks !== null) return `Not done: ${meta.name} asks the person every time (${asks}), and an outside client cannot ask them. Do it in the studio -- its Claude asks on the card, or the person does it there; nothing was changed.`;
  const kind = callKind(meta, input, { ...place, written: [] });
  const needs: OutsideLevel = kind === 'read' ? 'read' : kind === 'write' ? 'write' : 'destructive';
  if (rank(level) >= rank(needs)) return null;
  const what = kind === 'write' ? 'changes the project' : 'is destructive -- it can lose work nobody saved, reach another machine, or commit files no turn wrote';
  return `Not done: ${meta.name} ${what}, and outside clients are ${OUTSIDE_WORDS[level]} in this studio (${WHERE}). The person may allow ${needs === 'write' ? 'writes' : 'destructive tools'} there; nothing was changed.`;
}
