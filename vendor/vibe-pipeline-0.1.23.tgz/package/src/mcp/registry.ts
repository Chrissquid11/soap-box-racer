/**
 * The studio's MCP server (Docs/mcp.md §3): one registry of tools, each one
 * object -- its catalogue entry (`catalog.ts`: name, area, kind, annotations,
 * deadline, core or deferred), its description, its input and output schemas
 * in `zod`, and how it runs -- and `studioServer`, the SDK server made from it,
 * named `studio` (the agent calls its tools `mcp__studio__<name>`).
 *
 * - **One source per tool**: each tool's description, schemas, words and run
 *   are its area's module (`tools/studio.ts`, `scene.ts`, `prefab.ts`,
 *   `job.ts`, `claude.ts`), on its catalogue entry; here they are made into
 *   the SDK's tools.
 * - **Two kinds, one surface.** A *page* tool is relayed to a studio tab
 *   (`StudioContext.call`, the session's relay with the tool's deadline) and
 *   run there by the page's dispatcher (`packages/editor/src/mcp/`); its facts
 *   are worded by its record. A *server* tool runs in the dev server (`run`):
 *   the jobs (`job_status`, `job_wait`) and Claude's own settings
 *   (`claude_settings`, D4).
 * - **Made as the session starts**, with the SDK's `tool()` and
 *   `createSdkMcpServer` handed over by `session.ts` -- which alone imports the
 *   SDK -- and `zod`, the SDK's peer, imported here only then: nothing at
 *   module level.
 * - **Results** (`result.ts`): words, then the JSON the output schema
 *   describes, in one text; images beside it, capped. A refusal is a tool error
 *   the agent reads.
 * - **Core or deferred** per tool (`alwaysLoad`, the SDK's `_meta`): the scene
 *   tools always in the prompt, the rest behind the CLI's tool search.
 * - **Permissions are the gate's** (`permissions.ts`), by each tool's
 *   annotations: the SDK passes them on to the CLI, and the gate reads the same
 *   catalogue.
 */
import type { McpSdkServerConfigWithInstance, SdkMcpToolDefinition } from '@anthropic-ai/claude-agent-sdk';
import type { z as Zod } from 'zod';
import { CATALOG, STUDIO_SERVER, type ToolMeta } from './catalog.ts';
import { errorResult, toolResult, type ToolOutput, type ToolResult } from './result.ts';
import { DEFS, pageOutput } from './tools/index.ts';
import { projectTools } from './project.ts';
import { shapes } from './tools/shapes.ts';
import { ToolRefusal, useOf, type CallExtra, type McpKit, type PageTool, type ServerTool, type StudioContext } from './tool.ts';
import type { EditorResult } from '../agent/api-types.ts';
import { awayOf, awayWords, beforeDelivery, closedState, type RowWords, type ServerFacts } from './words.ts';

export { ToolRefusal, useOf, type CallExtra, type ClaudeSettingsChange, type ClaudeSettingsFacts, type McpKit, type StudioContext } from './tool.ts';

/** A tool of the server: its catalogue entry, its words, its schemas made, how it runs. */
export interface StudioTool extends ToolMeta {
  description: string;
  /** The input's zod shape, as the SDK's `tool()` takes it. */
  input: Record<string, Zod.ZodType>;
  /** The JSON its result carries after the words; none, words alone. */
  output?: Zod.ZodType;
  run(ctx: StudioContext, args: Record<string, unknown>, extra: CallExtra): Promise<ToolOutput>;
  /** A server tool's row in the transcript, from its input and what it came to. */
  row?(args: Record<string, unknown>, out: ToolOutput): RowWords;
}

// ---------------------------------------------------------------- the tools

/**
 * A page tool's run: relayed with its deadline, its answer worded -- `studio_state` with the server's facts, and an
 * answer with no tab open. An asset write (`offline`, D2) with no tab to run it -- none open, or none with the Assets
 * panel made -- is run by the dev server instead (`def.offline`), its row the server's; either way its facts settle
 * (`def.settle`: an export's jobs followed) and the files it touched are the turn's (`ctx.wrote`).
 */
function relayed(def: PageTool, m: ToolMeta): StudioTool['run'] {
  return async (ctx, args, extra) => {
    const use = useOf(extra);
    const answer = await ctx.call(def.name, args, use, m.deadline);
    const server = (): ServerFacts => ({ problems: ctx.problems?.() ?? null, jobs: ctx.jobs.list() });
    let result: EditorResult;
    if ('away' in answer) {
      if (def.name === 'studio_state' && answer.away === 'gone' && answer.delivered !== true) return closedState(server(), ctx.url());
      // The server's path only for a call no tab can have begun (`beforeDelivery`): never a write done twice.
      if (!(m.offline && def.offline && beforeDelivery(answer) && ctx.assets?.())) return { words: awayWords(awayOf(answer), def.name, m.deadline, ctx.url()), isError: true };
      try {
        result = await def.offline(ctx, args);
      } catch (err) {
        const words = err instanceof ToolRefusal ? err.message : `The studio failed: ${(err as Error).message ?? String(err)}`;
        ctx.row?.(def.name, args, use, { ok: false, words: def.summary(args), detail: words });
        return { words, isError: true };
      }
    } else if ('error' in answer) return { words: answer.error, isError: true };
    else result = answer.result;
    if (def.settle) result = await def.settle(ctx, result as never);
    const files = (result as { files?: unknown }).files;
    if (Array.isArray(files) && files.length > 0) ctx.wrote?.(files as string[]);
    // The page's row is the session's, from its answer; the server's, here.
    if ('away' in answer) ctx.row?.(def.name, args, use, def.row(result as never, args));
    return pageOutput(result, ctx.models, server());
  };
}

/** Every tool, in the catalogue's order, with its schemas made from `z`: its area's record (`tools/`) on its catalogue entry. */
export function studioTools(z: typeof Zod): StudioTool[] {
  const s = shapes(z);
  return CATALOG.map((m): StudioTool => {
    const def = DEFS[m.name] as PageTool | ServerTool;
    const output = def.output?.(z, s);
    const base = { ...(m as ToolMeta), description: def.description, input: def.input(z, s), ...(output ? { output } : {}) };
    return def.kind === 'page' ? { ...base, run: relayed(def, m) } : { ...base, run: (ctx, args, extra) => def.run(ctx, args, extra), row: def.row };
  });
}

/**
 * What an outside client of `/__mcp` may be served (Docs/mcp.md M7, `outside.ts`): the tools listed, and each call
 * judged as it comes -- a refusal answered as the tool's error, the tool never run. None: the session's server, whose
 * calls the permission gate judges before they reach it.
 */
export interface ServeGate {
  listed(meta: ToolMeta): boolean;
  refused(meta: ToolMeta, input: Record<string, unknown>): string | null;
}

/** One tool's handler: its run, worded as MCP's result; a server tool's row said to the session. */
export function handlerOf(def: StudioTool, ctx: StudioContext, gate?: ServeGate): (args: Record<string, unknown>, extra: unknown) => Promise<ToolResult> {
  return async (args, extra) => {
    const refused = gate?.refused(def, args ?? {}) ?? null;
    if (refused !== null) return errorResult(refused);
    let out: ToolOutput;
    try {
      out = await def.run(ctx, args ?? {}, (extra ?? {}) as CallExtra);
    } catch (err) {
      out = { words: err instanceof ToolRefusal ? err.message : `The studio failed: ${(err as Error).message ?? String(err)}`, isError: true };
    }
    if (def.kind === 'server' && def.row) ctx.row?.(def.name, args ?? {}, useOf(extra), def.row(args ?? {}, out));
    return out.isError ? errorResult(out.words) : toolResult(out);
  };
}

/** The tools as the SDK's definitions: each with its annotations, and `alwaysLoad` for the core. */
export function makeStudioTools(make: McpKit['tool'], z: typeof Zod, ctx: StudioContext, gate?: ServeGate): SdkMcpToolDefinition<any>[] {
  // The built-ins, then the project's own (`project_<name>`, Docs/mcp.md M7) as the last studio tab declared them now.
  return [...studioTools(z), ...projectTools(z, ctx.projectTools?.() ?? [])]
    .filter((def) => gate?.listed(def) ?? true)
    .map((def) => make(def.name, def.description, def.input, handlerOf(def, ctx, gate) as never, { annotations: def.annotations, ...(def.alwaysLoad ? { alwaysLoad: true } : {}) }));
}

/**
 * The `studio` server for the query's `mcpServers` -- or, with a `gate`, for an outside client of `/__mcp` (one per
 * client session): `zod` imported now, never with the config.
 */
export async function studioServer(kit: McpKit, ctx: StudioContext, gate?: ServeGate): Promise<McpSdkServerConfigWithInstance> {
  const { z } = await import('zod');
  return kit.createSdkMcpServer({ name: STUDIO_SERVER, version: '1.0.0', tools: makeStudioTools(kit.tool, z, ctx, gate) });
}
