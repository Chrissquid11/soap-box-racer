/**
 * The prefab area's tools (Docs/mcp.md §4): `prefab_info` -- the prefabs as compiled now, every one in a line or one
 * whole. A page tool: the live compile is the tab's.
 */
import { pageTool } from '../tool.ts';
import { plural } from '../words.ts';

export const prefabTools = {
  prefab_info: pageTool('prefab_info', {
    description: 'The prefabs of the game running in the editor, as compiled now. Left to itself: every prefab in a line -- its key and file (src/assets/prefabs/<key>.prefab, JSON inside), how many entities an instance is and the names node() takes, the prefab it is a variant of, the prefabs it nests and those nesting it, its pool (warm, max, parked and out now), its instances in the world, and the live compile\'s problem with it -- then the files that do not compile, with why. With `key`: that prefab whole -- each entity by its path in the file, name, parent, what it is made of (the components cmd.init may fill in), its model, and the nested prefab whose file makes it -- and its instances\' root ids. Read it before writing a prefab file or the game code that instantiates one.',
    input: (z, s) => ({
      key: z.union([z.string().min(1).max(200), s.ref]).optional().describe('A prefab key, its file without .prefab: crates/big (or its { uid, key }); left out, every prefab'),
    }),
    output: (z) => z.array(z.object({ key: z.string(), file: z.string(), entities: z.number(), names: z.array(z.string()), variantOf: z.string().nullable(), nests: z.array(z.string()), nestedBy: z.array(z.string()), instances: z.number(), problem: z.string().nullable() }).loose()),
    summary: (args) => (typeof args.key === 'string' ? `read the prefab ${args.key}` : 'list the prefabs'),
    words(result) {
      const one = result.prefabs.length === 1 && result.prefabs[0]!.nodes !== undefined;
      const head = one
        ? `${result.prefabs[0]!.key}, whole: each entity by its path in the file ('' the root), what it is made of (what cmd.init may fill in), its model, and the nested prefab whose file makes it (from); its instances in the world by root id.`
        : `${plural(result.prefabs.length, 'prefab')}. Each is a file, src/assets/prefabs/<key>.prefab, JSON inside (Docs/prefabs.md §2): a file written recompiles live and updates every instance where it holds no override. Game code names one as prefab('<key>') in src/game/prefabs.ts. prefab_info with a key gives one whole.`;
      const broken = result.broken.length > 0 ? `\nNot compiling, so not listed: ${result.broken.map((b) => `${b.key} (${b.problem})`).join('; ')}` : '';
      return { words: `${head}${broken}`, json: result.prefabs, pretty: true };
    },
    row(result) {
      const one = result.prefabs.length === 1 && result.prefabs[0]!.nodes !== undefined;
      return { ok: true, words: one ? `read the prefab ${result.prefabs[0]!.key}` : 'list the prefabs', detail: result.prefabs.map((p) => p.key).join(', ') + (result.broken.length > 0 ? ` · not compiling: ${result.broken.map((b) => b.key).join(', ')}` : '') || null };
    },
  }),
};
