/**
 * The scene area's tools for whole scenes and the prefab open (Docs/mcp.md §4, M2): the page's -- `scene_open_prefab`,
 * `scene_close_prefab`, `scene_open`, `scene_new`, `scene_save_as`, `scene_start`, run in the studio tab through the
 * editor's own controls (`packages/editor/src/mcp/scenes.ts`) -- and the server's `scene_list`, the scene files read
 * off the disk, with what the studio tab has open.
 *
 * None is a step: another world is another history, as when the person opens it. What nobody saved is never lost
 * unasked: `discard: true` (and Back with `save: false`) is the catalogue's destructive input.
 */
import { readdir, readFile } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';
import { RELAY_MS } from '../catalog.ts';
import { pageTool, serverTool, ToolRefusal } from '../tool.ts';
import { plural } from '../words.ts';

/** Where a project's scene files are, under its root. */
const SCENES = join('src', 'assets', 'scenes');

/** Every `.scene` under `dir`, by path relative to it. */
async function sceneFiles(dir: string): Promise<string[]> {
  const out: string[] = [];
  const walk = async (at: string): Promise<void> => {
    let entries;
    try {
      entries = await readdir(at, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (entry.name.startsWith('.') || entry.name.startsWith('_')) continue;
      const path = join(at, entry.name);
      if (entry.isDirectory()) await walk(path);
      else if (entry.name.endsWith('.scene')) out.push(relative(dir, path).split(sep).join('/'));
    }
  };
  await walk(dir);
  return out.sort();
}

export const sceneFileTools = {
  scene_open_prefab: pageTool('scene_open_prefab', {
    description: 'Open a prefab to edit, as the tree\'s "Open prefab": its instance alone in the editor, the scene put aside (its changes kept, unsaved or not) until Back. Every scene tool then edits the prefab -- scene_query, scene_set, scene_create (under its root) …; scene_close_prefab saves it (save: true) and goes back. No step: the scene\'s history is put aside with it.',
    input: (z, s) => ({ key: z.union([z.string().min(1).max(200), s.ref]).describe('The prefab\'s key: crates/big (or its { uid, key })') }),
    output: (z, s) => z.object({ key: z.string(), root: s.row.nullable(), readOnly: z.string().nullable() }),
    summary: (args) => `open the prefab ${typeof args.key === 'string' ? args.key : JSON.stringify(args.key)}`,
    words: (result) => ({ words: result.said, json: { key: result.key, root: result.root, readOnly: result.readOnly } }),
    row: (result) => ({ ok: true, words: `open the prefab ${result.key}`, detail: result.readOnly ? `read-only: ${result.readOnly}` : null }),
  }),

  scene_close_prefab: pageTool('scene_close_prefab', {
    description: 'Back from the prefab open to edit, to what it was opened from (the scene, or the prefab it was opened inside). With changes not saved, say what to do with them: `save: true` writes its file first (answered once it is written and compiled), `save: false` drops them -- destructive: the person\'s edits of the prefab go. Left out, it goes back only if there is nothing to save.',
    input: (z) => ({ save: z.boolean().optional().describe('true: save it first; false: drop its changes; left out, only with none') }),
    output: (z) => z.object({ key: z.string(), back: z.string(), saved: z.boolean(), dropped: z.boolean() }),
    summary: (args) => (args.save === true ? 'save the prefab and go back' : args.save === false ? 'go back from the prefab, its changes dropped' : 'go back from the prefab'),
    words: (result) => ({ words: result.said, json: { key: result.key, back: result.back, saved: result.saved, dropped: result.dropped } }),
    row: (result) => ({ ok: true, words: `back from ${result.key} to ${result.back}${result.saved ? ', saved' : result.dropped ? ', its changes dropped' : ''}`, detail: result.said }),
  }),

  scene_open: pageTool('scene_open', {
    description: 'Open a scene file in place of the world, as the Scenes page\'s Open: src/assets/scenes/<key>.scene (scene_list lists them). Refused while the world has changes nobody saved -- unless `discard: true`, which drops them (destructive: ask the person first, or scene_save). No step: another world is another history.',
    input: (z) => ({ key: z.string().min(1).max(200).describe('The scene\'s key: forest/camp'), discard: z.boolean().optional().describe('Drop what nobody saved -- destructive') }),
    output: (z) => z.object({ key: z.string(), discarded: z.boolean(), skipped: z.array(z.string()) }),
    summary: (args) => `open the scene ${String(args.key)}${args.discard === true ? ', dropping what was not saved' : ''}`,
    words: (result) => ({ words: `Opened the scene ${result.key}${result.discarded ? ', what was not saved dropped' : ''}${result.skipped.length > 0 ? `; not loaded: ${result.skipped.join(', ')}` : ''}. The editor's history started again.`, json: { key: result.key, discarded: result.discarded, skipped: result.skipped } }),
    row: (result) => ({ ok: true, words: `open the scene ${result.key}`, detail: result.discarded ? 'what was not saved dropped' : null }),
  }),

  scene_import: pageTool('scene_import', {
    description: 'Import a world save as a new scene, as the Scenes page\'s Import…: `save` the JSON a world was exported as before scenes were files (read the .json file, and give its text), written as src/assets/scenes/<name>.scene -- named from `name` (a free one if taken: never over another scene) -- then opened in place of the world. Refused while the world has changes nobody saved -- unless `discard: true`, which drops them (destructive: ask the person first, or scene_save). No step: another world is another history.',
    input: (z) => ({
      save: z.string().min(2).max(8_000_000).describe('The world save, its JSON text'),
      name: z.string().min(1).max(100).describe('The new scene\'s name: forest-camp (a free one if taken)'),
      discard: z.boolean().optional().describe('Drop what nobody saved -- destructive'),
    }),
    output: (z) => z.object({ key: z.string(), file: z.string(), discarded: z.boolean(), skipped: z.array(z.string()) }),
    summary: (args) => `import a world save as the scene "${String(args.name)}"${args.discard === true ? ', dropping what was not saved' : ''}`,
    words: (result) => ({ words: `Imported the world save as ${result.file} (key ${result.key}) and opened it${result.discarded ? ', what was not saved dropped' : ''}${result.skipped.length > 0 ? `; not loaded: ${result.skipped.join(', ')}` : ''}. The editor's history started again.`, json: { key: result.key, file: result.file, discarded: result.discarded, skipped: result.skipped } }),
    row: (result) => ({ ok: true, words: `import the scene ${result.key}`, detail: `${result.file}${result.discarded ? ' · what was not saved dropped' : ''}` }),
  }),

  scene_new: pageTool('scene_new', {
    description: 'Empty the world for a new scene, as the Scenes page\'s New scene: every entity goes, and one main camera is made (Main Camera, at 0 5 10 looking at the origin), no file yet (scene_save_as writes one). Refused while the world has changes nobody saved -- unless `discard: true`, which drops them (destructive). No step: another world is another history.',
    input: (z) => ({ discard: z.boolean().optional().describe('Drop what nobody saved -- destructive') }),
    output: (z) => z.object({ discarded: z.boolean() }),
    summary: (args) => `empty the world for a new scene${args.discard === true ? ', dropping what was not saved' : ''}`,
    words: (result) => ({ words: `The world is empty but for its Main Camera: a new scene, no file yet (scene_save_as)${result.discarded ? '; what was not saved dropped' : ''}.`, json: { discarded: result.discarded } }),
    row: (result) => ({ ok: true, words: 'a new scene', detail: result.discarded ? 'what was not saved dropped' : null }),
  }),

  scene_save_as: pageTool('scene_save_as', {
    description: 'Save the world as a NEW scene file, as the Scenes page\'s Save as…: src/assets/scenes/<name>.scene (the name as given, capitals and spaces kept; its key the name lowercased), which is then the scene open. Never over another scene: a name taken is refused.',
    input: (z) => ({ name: z.string().min(1).max(100).describe('The new scene\'s name: my-camp, or forest/camp in a folder') }),
    output: (z) => z.object({ name: z.string(), key: z.string(), file: z.string() }),
    summary: (args) => `save the scene as a new one, "${String(args.name)}"`,
    words: (result) => ({ words: `Saved as src/assets/scenes/${result.name}.scene (key ${result.key}), now the scene open.`, json: { name: result.name, key: result.key, file: `src/assets/scenes/${result.name}.scene` } }),
    row: (result) => ({ ok: true, words: `save the scene as "${result.name}"`, detail: `Wrote src/assets/scenes/${result.name}.scene` }),
  }),

  scene_start: pageTool('scene_start', {
    description: 'Which scene the game opens on start, in every build, as the Scenes page\'s start pick: its file says "start": true (and the one before\'s no longer does) -- null for the game\'s own world. Written to the files by the dev server.',
    input: (z) => ({ key: z.string().min(1).max(200).nullable().describe('A scene\'s key, or null for the game\'s own world') }),
    output: (z) => z.object({ start: z.string().nullable() }),
    summary: (args) => (args.key === null ? 'start on the game\'s own world' : `start the game on ${String(args.key)}`),
    words: (result) => ({ words: result.start === null ? 'The game builds its own world on start.' : `The game opens ${result.start} on start: its file says "start": true.`, json: { start: result.start } }),
    row: (result) => ({ ok: true, words: result.start === null ? 'start on the game\'s own world' : `start on ${result.start}`, detail: null }),
  }),

  scene_list: serverTool('scene_list', {
    description: 'The scene files of the project, src/assets/scenes/**/*.scene, read off the disk: each its key (what scene_open takes), file, whether the game starts on it, and -- with a studio tab open -- which is open there and whether that has changes nobody saved. Only reads.',
    input: () => ({}),
    output: (z) => z.object({ scenes: z.array(z.object({ key: z.string(), file: z.string(), start: z.boolean(), open: z.boolean(), unsaved: z.boolean() })) }),
    summary: () => 'list the scenes',
    async run(ctx) {
      if (!ctx.root) throw new ToolRefusal('The project\'s files are not reachable from here');
      const dir = join(ctx.root(), SCENES);
      const files = await sceneFiles(dir);
      // What the studio tab has open, if one is: its answer, or nothing known.
      const answer = await ctx.call('studio_state', {}, null, RELAY_MS).catch(() => null);
      const open = answer && 'result' in answer && answer.result.tool === 'studio_state' ? answer.result.scene : null;
      const scenes = await Promise.all(files.map(async (path) => {
        const key = path.slice(0, -'.scene'.length).toLowerCase();
        let start = false;
        try {
          start = (JSON.parse(await readFile(join(dir, path), 'utf8')) as { start?: unknown }).start === true;
        } catch {
          // Not readable as JSON: listed, not the start.
        }
        const here = open !== null && open.name !== null && open.name.toLowerCase() === key;
        return { key, file: `src/assets/scenes/${path}`, start, open: here, unsaved: here && open!.unsaved };
      }));
      const now = scenes.find((s) => s.open);
      return {
        words: scenes.length === 0 ? 'No scene files yet: scene_save_as writes the world as one.' : `${plural(scenes.length, 'scene')}${now ? `; ${now.key} is open in the studio${now.unsaved ? ', with changes nobody saved' : ''}` : ''}. scene_open opens one by its key.`,
        json: { scenes },
        pretty: true,
      };
    },
    row: (_args, out) => ({ ok: !out.isError, words: 'list the scenes', detail: out.words.split('\n')[0] ?? null }),
  }),
};
