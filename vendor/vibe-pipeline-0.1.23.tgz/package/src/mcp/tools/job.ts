/**
 * The job area's tools (Docs/mcp.md §2 rule 7): `job_status` (one job, or every one kept) and `job_wait` (one job to
 * its end, its progress said as MCP progress notifications where the client asked for them), reads; and `job_cancel`,
 * the Build and Tests cards' Stop: the studio's task running stopped (`tasks.cancel`, as `POST cancel` does), and
 * the job that follows it failed as stopped. Server tools.
 */
import { JOB_WAIT_MAX } from '../catalog.ts';
import { jobLine, type Job } from '../jobs.ts';
import { studioOf } from '../studio-work.ts';
import { serverTool, ToolRefusal } from '../tool.ts';
import { plural } from '../words.ts';

/** The kinds of job that follow a studio task (`studio-work.ts`' `runTask`), each with the scripts it runs: a test run, a build. */
const TASK_JOBS: Readonly<Record<string, readonly string[]>> = { tests: ['test'], build: ['build', 'build:debug', 'packs'] };

/** Does a job of this kind follow the task running (`script`)? */
const follows = (kind: string, script: string): boolean => TASK_JOBS[kind]?.includes(script) ?? false;

/** An id no job has, said with those there are. */
function noJob(id: string, all: readonly Job[]): string {
  return `There is no job ${id}${all.length > 0 ? `: the jobs are ${all.map((j) => j.id).join(', ')}` : ': no job has run lately'}`;
}

export const jobTools = {
  job_status: serverTool('job_status', {
    description: 'How the studio\'s long work stands -- an export, a build, a test run, a compile started as a job: its id, kind, label, state (running, done, failed), progress, result or error, and when it started and ended. With `id`, that job; left out, every job kept (the running first). Only reads.',
    input: (z) => ({ id: z.string().min(1).max(100).optional().describe('A job\'s id, as the tool that started it answered; left out, every job') }),
    output: (z, s) => z.union([s.job, z.array(s.job)]),
    summary: (args) => (typeof args.id === 'string' ? `read the job ${args.id}` : 'list the jobs'),
    async run(ctx, args) {
      if (typeof args.id === 'string') {
        const one = ctx.jobs.get(args.id);
        if (!one) throw new ToolRefusal(noJob(args.id, ctx.jobs.list()));
        return { words: jobLine(one), json: one };
      }
      const all = ctx.jobs.list();
      return { words: all.length === 0 ? 'No jobs: nothing long is running or has run lately.' : `${plural(all.length, 'job')}:\n${all.map(jobLine).join('\n')}`, json: all, pretty: true };
    },
    row: (args, out) => ({ ok: !out.isError, words: typeof args.id === 'string' ? `read the job ${args.id}` : 'list the jobs', detail: out.words.split('\n')[0] ?? null }),
  }),

  job_cancel: serverTool('job_cancel', {
    description: 'Stop the task running -- a test run, a build, an export or another npm script the studio runs -- as the Build and Tests cards\' Stop: the process ended (SIGTERM, then SIGKILL), and the job that follows it (tests_run\'s, build_run\'s) failed as stopped. With `id`, only if that job follows the task running now (a test run\'s job and a test task, a build\'s and a build) -- another task, the person\'s own, is never stopped for it; a test run\'s job between its files, nothing running, is stopped there and runs no more. Nothing running is refused. The person may have started it: stop only what you started, or what they asked you to.',
    input: (z) => ({ id: z.string().min(1).max(100).optional().describe('The job to stop, as tests_run or build_run answered; left out, whatever task runs') }),
    output: (z) => z.object({ task: z.string().nullable(), stopped: z.array(z.string()) }),
    summary: (args) => (typeof args.id === 'string' ? `stop the job ${args.id}` : 'stop the task running'),
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const running = calls.task().running?.name ?? null;
      if (typeof args.id === 'string') {
        const job = ctx.jobs.get(args.id);
        if (!job) throw new ToolRefusal(noJob(args.id, ctx.jobs.list()));
        if (job.state !== 'running') throw new ToolRefusal(`${jobLine(job)}: it is not running, nothing to stop`);
        if (TASK_JOBS[job.kind] === undefined) throw new ToolRefusal(`${job.id} is ${job.kind === 'export' ? 'an export' : `a ${job.kind}`} job, which follows no studio task: job_cancel stops a test run or a build`);
        // Between a test run's files another task may run -- the person's own build: never theirs stopped for this job.
        if (running !== null && !follows(job.kind, running)) throw new ToolRefusal(`${job.id} is not what runs now: npm run ${running} is, not its job's -- nothing was stopped. Wait for it, or leave the person's task alone`);
        // Between its files, no task running: the job failed as stopped, and runTask starts no file after it.
        if (running === null) {
          ctx.jobs.stop(job.id, 'stopped by job_cancel between its files: no more were run');
          return { words: `Stopped ${job.id} between its files: nothing was running, and no more of its files will run. The Build and Tests cards say it ended.`, json: { task: null, stopped: [job.id] } };
        }
      }
      if (running === null) throw new ToolRefusal('Nothing is running: no task to stop');
      calls.tasks.cancel();
      // One task at a time: the jobs following this task follow this one, and only they.
      const why = `stopped by job_cancel: npm run ${running} was ended`;
      const stopped = ctx.jobs.list().filter((j) => j.state === 'running' && follows(j.kind, running)).map((j) => j.id).filter((id) => ctx.jobs.stop(id, why));
      return { words: `Stopped npm run ${running}${stopped.length > 0 ? `; its job ${stopped.join(', ')} failed as stopped` : ''}. The Build and Tests cards say it ended.`, json: { task: running, stopped } };
    },
    row: (args, out) => ({ ok: !out.isError, words: typeof args.id === 'string' ? `stop the job ${args.id}` : 'stop the task running', detail: out.words }),
  }),

  job_wait: serverTool('job_wait', {
    description: `Wait for a job to end -- an export, a build, a test run -- at most \`timeoutMs\` (${JOB_WAIT_MAX / 60000} minutes at most, the default), with its progress said as it goes: answered with the job as it ended, or as it stands when the time ran out (then wait again, or go on with other work). Only reads.`,
    input: (z) => ({
      id: z.string().min(1).max(100).describe('The job\'s id'),
      timeoutMs: z.number().int().min(0).max(JOB_WAIT_MAX).optional().describe(`How long to wait, ms; left out, ${JOB_WAIT_MAX}`),
    }),
    output: (_z, s) => s.job,
    summary: (args) => `wait for the job ${String(args.id)}`,
    async run(ctx, args, extra) {
      const id = String(args.id);
      const token = extra._meta?.progressToken;
      const send = extra.sendNotification;
      // MCP progress notifications where the client asked for them (a progress token) and the SDK passes a way to send them.
      const onProgress = (token !== undefined && send)
        ? (j: Job): void => void send({ method: 'notifications/progress', params: { progressToken: token, progress: j.progress?.done ?? 0, ...(j.progress?.total != null ? { total: j.progress.total } : {}), ...(j.progress?.note ? { message: j.progress.note } : {}) } }).catch(() => {})
        : undefined;
      const ms = typeof args.timeoutMs === 'number' ? Math.min(args.timeoutMs, JOB_WAIT_MAX) : JOB_WAIT_MAX;
      const started = Date.now();
      const one = await ctx.jobs.wait(id, ms, onProgress);
      if (!one) throw new ToolRefusal(noJob(id, ctx.jobs.list()));
      const waited = Math.round((Date.now() - started) / 1000);
      return { words: one.state === 'running' ? `Still running after ${waited} s: ${jobLine(one)}. Wait again, or go on with other work.` : jobLine(one), json: one };
    },
    row: (args, out) => ({ ok: !out.isError, words: `wait for the job ${String(args.id)}`, detail: out.words }),
  }),
};
