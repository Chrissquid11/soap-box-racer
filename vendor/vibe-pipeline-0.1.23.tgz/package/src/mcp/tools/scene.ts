/**
 * The scene area's tools (Docs/mcp.md §4), each what the editor's own control does, run in the studio tab
 * (`packages/editor/src/mcp/scene.ts`): `scene_describe`, `scene_save_prefab`, `scene_set`, `scene_create`,
 * `scene_override`, `scene_save`. Each write one step on the editor's undo stack, labelled `Claude: …`.
 */
import { oneWhom, onWhom, pageTool } from '../tool.ts';
import { plural, said, tidy, whom } from '../words.ts';

export const sceneTools = {
  scene_describe: pageTool('scene_describe', {
    description: 'world.describe() of the game running in the editor: every prefab with its entities and how many are alive, every component with its fields, the component set each prefab entity is grouped by, every system with its rate, data and member count.',
    input: () => ({}),
    summary: () => 'describe the world',
    words: (result) => ({ words: result.text }),
    row: (result) => ({ ok: true, words: 'describe the world', detail: result.text.split('\n')[0] ?? null }),
  }),

  scene_save_prefab: pageTool('scene_save_prefab', {
    description: 'Save entities in the scene as a new prefab, as the tree\'s "Save as prefab…" does: they and everything under them written as src/assets/prefabs/<key>.prefab -- only what differs from the defaults, an instance among them kept a nested instance with its overrides, several roots under one empty root -- then, once the file compiles, replaced by one instance of it where they stood, what systems set on them carried over. `key` is a name in a folder (crates/pile, Test Case/Big Thing: capitals and spaces kept in the file\'s name), whose key -- the name lowercased -- is no prefab\'s yet. `entities` are refs or paths (left out: the selection). One step on the editor\'s undo stack, labelled `Claude: Save as prefab …`, which the person undoes with Z -- the entities back, the file to the trash. Answered once the file is compiled (it waits up to a minute for the compile); one that does not compile changes nothing and goes to the trash, its error said. Answers the instance\'s root id.',
    input: (z, s) => ({
      key: z.string().min(1).max(200).describe('The new prefab\'s name: a name in a folder -- crates/pile; its key is it lowercased'),
      entities: s.entities.optional().describe('Entities, each a ref or a path; left out, the selection'),
    }),
    output: (z) => z.object({ key: z.string(), file: z.string(), root: z.number() }),
    summary: (args) => `save ${onWhom(args.entities)} as the prefab ${String(args.key)}`,
    words: (result) => ({
      words: `${result.said}\nWrote ${result.file}; the entities are now one instance of ${result.key} (${plural(result.entities, 'entity', 'entities')}), its root entity ${result.root}${result.name ? ` "${result.name}"` : ''}, where they stood: one step on the editor's undo stack, "${result.step}", which the person undoes with Z -- the file going to the trash with it. The scene is not saved by it (scene_save).`,
      json: { key: result.key, file: result.file, root: result.root },
    }),
    row: (result) => ({ ok: true, words: `save as the prefab ${result.key}`, detail: `${result.said} · one step, "${result.step}"` }),
  }),

  scene_set: pageTool('scene_set', {
    description: 'Set a field of a component on entities in the editor, live, as the inspector does -- one step on the editor\'s undo stack, which the person undoes with Z; the scene is not saved by it (scene_save). `entities` are refs or paths (scene_query finds them; left out, the selection). `value` is one for all, or one per entity, in order, as the field is -- scene_entity\'s `schema` says what each field takes: a number (Transform: px py pz position in metres relative to the parent, qx qy qz qw a quaternion, sx sy sz scale), held to the field\'s min and max (clamped, and said); an enum\'s name ("run"); flags a list of their names (["fire", "ice"]; [] for none); a vector its numbers under its one name ([0, 1, 0]; one per entity a list of them; one axis by its column, dirY); a key field\'s asset key of its kind (schema `keyKind`: a Model, Texture, Material, Prefab, Scene, Level, Sfx, UiSfx, Music, Atlas, Icon, Font or the project\'s own -- Render.model "props/crate", "props/robot#arm" for a part, a key(\'Sfx\') "hop", "" for none -- or the { uid, key } an answer showed; never a uid made up), refused with the keys there are where none of its kind has it, and said where it is another kind\'s ("hop is a Sfx, not a Model"); a mesh (schema kind `mesh`) a model and one of its parts, { key, part } ({ "key": "props/parrot", "part": "wing" }; no part for the whole model) or "props/parrot#wing"; a colour "#rrggbb", one with alpha "#rrggbbaa"; a yes or no, true or false; a ref() field the entity it points at, by ref or path (null for none) -- a typed one (schema `needs`: ["Health"]) only an entity with every component it needs, else refused with why; a read-only field is refused; an object component whole -- `field` left out -- in its save shape as scene_entity shows it under `saved` (Name: the name\'s text, "" or null for none). A data component (schema kinds string, list, dict, record): `field` a path into it -- waypoints[2], loot.sword, stats.speed, crew[0].who -- or a field whole; left out, the fields `value` names, the rest left as they are (a read-only one refused); every element checked, the path of what does not fit said. One value an entity is `values`, never a list in `value` (a list there is the one value). `was`, given (one or one per entity, as `value`): written only where the field still holds it -- else the answer is `changed`, each entity\'s value now, and nothing is written: read it, and decide again. Answers the values written.',
    input: (z, s) => ({
      entities: s.entities.optional().describe('Entities, each a ref or a path; left out, the selection'),
      component: z.string().min(1).max(100).describe('The component: Transform, Render, Name, a game\'s own, as scene_describe lists them'),
      field: z.string().min(1).max(100).optional().describe('The field: px, model, tint, a vector\'s name (dir) …; left out for an object component (Name, or one with a save shape)'),
      values: z.array(z.unknown()).max(256).optional().describe('One value an entity, in the order of entities, in place of value: always so for a data component (where a list, a dict\'s pairs or a path is one value)'),
      value: z.unknown().optional().describe('One value for all, or a list of one per entity: a number, an enum\'s name, flags\' names (a list), a vector\'s numbers (a list), a key\'s text or { uid, key }, a mesh\'s { key, part }, "#rrggbb" ("#rrggbbaa" with alpha), true/false, an entity\'s ref or path, an object\'s save shape'),
      was: z.unknown().optional().describe('What you read the field holding (one, or one per entity): written only if it holds it still, else `changed`'),
    }),
    output: (z) => z.union([
      z.array(z.object({ id: z.number(), ref: z.number().optional(), name: z.string().nullable(), was: z.union([z.number(), z.string(), z.array(z.number())]), now: z.union([z.number(), z.string(), z.array(z.number())]), uid: z.string().optional() })),
      z.object({ changed: z.array(z.object({ ref: z.number(), id: z.number(), name: z.string().nullable(), now: z.union([z.number(), z.string(), z.array(z.number())]) })) }),
    ]),
    summary: (args) => {
      const value = Array.isArray(args.value) ? args.value.map((v) => JSON.stringify(v)).join(', ') : typeof args.value === 'string' ? args.value : JSON.stringify(args.value);
      return `set ${String(args.component)}${args.field === undefined ? '' : `.${String(args.field)}`} = ${value} on ${onWhom(args.entities)}`;
    },
    words(result) {
      const key = result.object ? result.component : `${result.component}.${result.field}`;
      if (result.changed) {
        const each = result.changed.map((c) => `${c.name ?? `entity ${c.ref}`}: ${said(c.now)}`);
        return { words: `Not written: ${key} changed since you read it -- now ${each.join('; ')}. Nothing was written: read it again, and decide.`, json: { changed: result.changed.map((c) => ({ ...c, now: tidy(c.now) })) }, isError: true };
      }
      const written = result.written.map((w) => ({ id: w.id, ...(w.ref !== undefined ? { ref: w.ref } : {}), name: w.name, was: tidy(w.was), now: tidy(w.now), ...(w.uid !== undefined ? { uid: w.uid } : {}) }));
      const clamped = result.clamped?.length ? ` Held to its bounds: ${result.clamped.join('; ')}.` : '';
      if (result.step === null) return { words: `Nothing changed: ${key} was already that on ${whom(result.written)}, so there is no step to undo.${clamped}`, json: written };
      return { words: `Set ${key} on ${whom(result.written)}: one step on the editor's undo stack, "${result.step}", which the person undoes with Z. The scene is not saved by it (scene_save).${clamped}`, json: written };
    },
    row(result) {
      const key = result.object ? result.component : `${result.component}.${result.field}`;
      if (result.changed) return { ok: false, words: `set ${key}: changed since read, nothing written`, detail: result.changed.map((c) => `${c.name ?? `entity ${c.ref}`}: now ${said(c.now)}`).join('; ') };
      const values = [...new Set(result.written.map((w) => said(w.now)))];
      const words = `set ${key} = ${values.join(', ')} on ${whom(result.written)}${result.step === null ? ' (no change)' : ''}`;
      const each = result.written.map((w) => `${w.name ?? `entity ${w.id}`} (#${w.id}): ${said(w.was)} → ${said(w.now)}`);
      // Where the step is now -- on top, undone, from before a reload, in another tab -- is the page's to say beside it.
      return { ok: true, words, detail: `${each.join('; ')}${result.step === null ? '' : ` · one step, "${result.step}"`}` };
    },
  }),

  scene_create: pageTool('scene_create', {
    description: 'Make something in the scene, as the Create menu does -- one step on the editor\'s undo stack, which the person undoes with Z; the scene is not saved by it (scene_save). `kind`: `prefab` (the default) -- one instance of a prefab, as the Spawn list places it, the whole prefab, nested ones in it, its root named from the file; `prefab` is its key, its file under src/assets/prefabs/ without `.prefab` (crates/big; prefab_info lists them) -- `empty`, an entity with a Transform and a name alone, for code to fill in -- or `camera`, as Create ▸ Camera: in front of the editor\'s view looking along it (or at `at`), the main camera when the scene has none. `at` is where it goes in metres -- in the world, or relative to `parent` when that is given -- the origin when left out. `parent` (a ref or path) to put it under, in front of `before` (one of its children); with a prefab open to edit and no `parent`, under that prefab\'s root, never beside it. `name` names it. The person\'s selection is left as it was (scene_select sets it, when asked). Answers its ref and path.',
    input: (z, s) => ({
      kind: z.enum(['prefab', 'empty', 'camera']).optional().describe('What to make: prefab (the default), empty or camera'),
      prefab: z.union([z.string().min(1).max(200), s.ref]).optional().describe('kind prefab: its key, its file without .prefab: crates/big (or its { uid, key })'),
      at: z.object({ x: z.number(), y: z.number(), z: z.number() }).optional().describe('Where it goes, metres; relative to parent when given'),
      parent: s.entity.optional().describe('The entity to put it under: a ref or a path'),
      before: s.entity.optional().describe('One of parent\'s children (a root, with no parent) to put it in front of; left out, last'),
      name: z.string().min(1).max(200).optional().describe('Its name; left out, the file\'s (Empty: entity; a camera: Camera), numbered'),
    }),
    output: (z) => z.object({ kind: z.enum(['prefab', 'empty', 'camera']), ref: z.number(), id: z.number(), path: z.string(), name: z.string().nullable(), parent: z.number().nullable(), at: z.object({ x: z.number(), y: z.number(), z: z.number() }), main: z.boolean().optional() }),
    summary: (args) => {
      const parent = args.parent !== undefined ? ` under ${oneWhom(args.parent)}` : '';
      const at = args.at && typeof args.at === 'object' ? ` at ${['x', 'y', 'z'].map((k) => String((args.at as Record<string, unknown>)[k] ?? 0)).join(', ')}` : '';
      const prefab = typeof args.prefab === 'object' && args.prefab !== null ? String((args.prefab as { key?: unknown }).key) : String(args.prefab);
      const what = args.kind === 'empty' ? 'an Empty' : args.kind === 'camera' ? 'a camera' : prefab;
      return `place ${what}${at}${parent}`;
    },
    words: (result) => ({
      words: `${result.kind === 'prefab' ? `Placed ${result.prefab} (${plural(result.entities, 'entity', 'entities')}), its root` : result.kind === 'camera' ? `Made a camera${result.main ? ', the main one (the scene had none)' : ''},` : 'Made an Empty,'} ${result.path} (ref ${result.ref}): one step on the editor's undo stack, "${result.step}", which the person undoes with Z. The scene is not saved by it (scene_save).`,
      json: { kind: result.kind, ref: result.ref, id: result.id, path: result.path, name: result.name, parent: result.parent, at: result.at, ...(result.main !== undefined ? { main: result.main } : {}) },
    }),
    row(result) {
      const at = [result.at.x, result.at.y, result.at.z].map(tidy).join(', ');
      const what = result.kind === 'prefab' ? result.prefab : result.kind === 'camera' ? 'a camera' : 'an Empty';
      return { ok: true, words: `place ${what} as ${result.name ?? `entity ${result.id}`}`, detail: `#${result.id}, ${plural(result.entities, 'entity', 'entities')}, at ${at}${result.parent === null ? '' : ` under #${result.parent}`} · one step, "${result.step}"` };
    },
  }),

  scene_override: pageTool('scene_override', {
    description: 'Settle an instance\'s overrides -- what it changes from its prefab, as studio_state lists them -- as the inspector does. `revert`: back to what the prefab gives, in the world only. `apply`: written into the prefab\'s file (`to`, one of the override\'s `to` list: an inner prefab, or one nesting it; the instance\'s own prefab when left out), so every instance of it takes it where it holds no override of its own -- answered once the file is written and compiled (it waits up to a minute for the compile). `unpack`: on an instance\'s root, its entities made plain, no longer linked to the prefab (`completely`: what it nests too). `entity` is one of the instance\'s (left out: the selection\'s first); `what` the overrides by their handles as studio_state lists them (left out: every one studio_state lists for that entity -- on a root, every one of the whole instance, so read that list first and name only what should go). One step on the editor\'s undo stack, labelled `Claude: Revert …`, `Claude: Apply to …`, which the person undoes with Z -- an Apply\'s with its file written back.',
    input: (z, s) => ({
      verb: z.enum(['revert', 'apply', 'unpack']).describe('revert, apply or unpack'),
      entity: s.entity.optional().describe('An entity of the instance, a ref or a path; left out, the selection\'s first'),
      what: z.array(z.string().min(1).max(200)).min(1).max(256).optional().describe('Overrides by their handles (Transform.px, +Spin, removed, added #12); left out, all of the entity'),
      to: z.union([z.string().min(1).max(200), s.ref]).optional().describe('apply: the prefab key to write (or its { uid, key }); left out, the instance\'s own'),
      completely: z.boolean().optional().describe('unpack: the prefabs it nests too'),
    }),
    output: (z) => z.object({ root: z.number(), prefab: z.string(), done: z.array(z.string()), to: z.string().nullable() }),
    summary: (args) => {
      const on = args.entity !== undefined ? oneWhom(args.entity) : 'the selection';
      const what = Array.isArray(args.what) && args.what.length > 0 ? args.what.map(String).join(', ') : args.verb === 'unpack' ? '' : 'every override';
      if (args.verb === 'unpack') return `unpack ${on}${args.completely === true ? ' completely' : ''}`;
      return `${args.verb === 'apply' ? 'apply' : 'revert'} ${what} of ${on}${args.verb === 'apply' && typeof args.to === 'string' ? ` to ${args.to}` : ''}`;
    },
    words: (result) => ({
      words: `${result.said}\nOne step on the editor's undo stack, "${result.step}", which the person undoes with Z${result.verb === 'apply' ? ` -- the file ${result.to} written back with it` : ''}.`,
      json: { root: result.root, prefab: result.prefab, done: result.done, to: result.to },
    }),
    row(result) {
      const verb = result.verb === 'apply' ? 'apply' : result.verb === 'revert' ? 'revert' : 'unpack';
      const what = result.verb === 'unpack' ? '' : ` ${result.done.length === 1 ? result.done[0] : `${result.done.length} overrides`}`;
      return { ok: true, words: `${verb}${what} of #${result.root} (${result.prefab})${result.to ? ` to ${result.to}` : ''}`, detail: `${result.said} · one step, "${result.step}"` };
    },
  }),

  scene_save: pageTool('scene_save', {
    description: 'Save the editor\'s world as a scene file, as the Scenes page\'s Save does: its own file, or `name` for a new one, written as src/assets/scenes/<name>.scene (a world save inside; the name as given, capitals and spaces kept -- one no file may have is refused -- and the answer says the key, the name lowercased). The game loads it with game.load(scene(key)) from src/scenes.ts. It never saves over another scene, and needs the dev server. With a prefab open to edit (scene_open_prefab), it saves that prefab to its own file and stays in it, as S and the header\'s Save do -- no name then.',
    input: (z) => ({
      name: z.string().min(1).max(100).optional().describe('A new scene\'s name, its file\'s: my-camp, or forest/camp in a folder; left out, the scene\'s own'),
    }),
    output: (z) => z.object({ name: z.string(), key: z.string(), file: z.string(), saved: z.literal(true), prefab: z.boolean().optional(), wrote: z.boolean().optional() }),
    summary: (args) => (typeof args.name === 'string' ? `save the scene as "${args.name}"` : 'save the scene'),
    words: (result) => result.prefab
      ? { words: `${result.prefab.wrote ? 'Saved the prefab open' : 'Nothing to save in the prefab open'}: ${result.prefab.file} (key ${result.key}), still open -- ${result.prefab.said}.`, json: { name: result.name, key: result.key, file: result.prefab.file, saved: true, prefab: true, wrote: result.prefab.wrote } }
      : { words: `Saved: src/assets/scenes/${result.name}.scene (key ${result.key}).`, json: { name: result.name, key: result.key, file: `src/assets/scenes/${result.name}.scene`, saved: true } },
    row: (result) => result.prefab
      ? { ok: true, words: `save the prefab ${result.key}`, detail: `${result.prefab.wrote ? 'Wrote' : 'Nothing new for'} ${result.prefab.file}, as the prefab's Save does; still open` }
      : { ok: true, words: `save the scene as "${result.name}"`, detail: `Wrote src/assets/scenes/${result.name}.scene, as the Scenes page's Save does` },
  }),
};
