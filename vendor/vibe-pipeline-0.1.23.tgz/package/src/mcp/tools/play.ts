/**
 * The play, view and history tools (Docs/mcp.md §4's play and view, M4): the page's, each through the editor's own
 * functions -- the playtest's (`F5`, `F6`, `F10`, `Shift+F5`: `play_start`, `play_pause`, `play_step`, `play_stop`, and
 * `play_state` reading it), the editor's view (`F`, the cube's sides and centre, a pose: `view_focus`, `view_set`,
 * `view_get`), an image of a view (`view_shot`: the scene view, a camera entity's, the game's main camera, the Model
 * tab's -- drawn the way the screen draws it, never moving the person's view), and the world's history (`history_list`,
 * `history_undo`, `history_redo`, as the History card and `Z` and `Y`).
 *
 * - **A playtest running** refuses what acts on the world (the page's `away`, as ever) but not these: the play tools
 *   are how it is paused and stopped, and a look or a read changes nothing.
 * - **The view is the person's**: `view_set` and `view_focus` move it, no step -- nothing for `Z` to take back -- as F
 *   and the cube do; their descriptions say so.
 * - **`history_undo` and `history_redo`** take Claude's own steps (`Claude: …`); one of the person's only with `any`,
 *   the catalogue's destructive input.
 *
 * Nothing at module level but the records.
 */
import type { z as Zod } from 'zod';
import type { GameViewResult, HistoryStepFacts, PlayFacts, ViewGetResult } from '../../agent/api-types.ts';
import { pageTool } from '../tool.ts';
import { plural } from '../words.ts';

/** A playtest in a line: none, or its state, tick and time, and the changes Stop offers. */
function playWords(p: PlayFacts): string {
  if (p.state === 'none') return 'No playtest.';
  const at = `${p.state === 'running' ? 'Running' : 'Paused'} at tick ${p.ticks} (${p.seconds.toFixed(1)} s in)`;
  const offered = p.changes.length === 0 ? '' : ` ${plural(p.changes.length, 'change')} made while paused, which Stop offers to keep (play_stop keep: 'all', 'none' or their ids): ${p.changes.slice(0, 8).map((c) => `${c.id} ${c.words}`).join('; ')}${p.changes.length > 8 ? ` and ${p.changes.length - 8} more` : ''}.`;
  return `${at}.${offered}`;
}

/** Whose a step is, in words (`HistoryStepFacts.by`). */
const BY_WORDS: Record<HistoryStepFacts['by'], string> = { person: 'the person\'s', Claude: 'Claude\'s', MCP: 'an outside client\'s, MCP' };

/** The JSON every play answer carries. */
const playJson = (p: PlayFacts): PlayFacts => ({ state: p.state, tick: p.tick, ticks: p.ticks, seconds: p.seconds, changes: p.changes });

/** The view in a line. */
function viewWords(r: ViewGetResult): string {
  const v = r.view;
  const n = (xs: readonly number[]): string => xs.map((x) => Number(x.toFixed(3))).join(', ');
  return `The editor's view: from (${n(v.position)}) toward (${n(v.target)}), ${v.preset}, ${v.projection}${v.projection === 'perspective' ? ` ${v.fov ?? 50}°` : ` ${Number((v.height ?? 0).toFixed(3))} m high`}.`;
}

/** The game view in a line. */
function gameViewWords(r: GameViewResult): string {
  const f = r.frame;
  const where = r.fills === 'room' ? 'in the scene\'s room between the editor\'s cards' : 'over the whole canvas';
  const scaled = r.pixels.width !== f.width || r.pixels.height !== f.height;
  const preset = r.applies
    ? `The preset ${r.preset} shapes it now${scaled ? `: the world drawn at ${r.pixels.width}×${r.pixels.height}, scaled ×${Number(r.scale.toFixed(3))}` : ''}.`
    : `The preset ${r.preset} shapes a playtest and the Game look; now the editor's camera fills the room.`;
  const own = r.presets.filter((p) => p.own).map((p) => p.name);
  return `The game is drawn ${where}: ${f.width}×${f.height} at (${f.x}, ${f.y}) of a ${r.canvas.width}×${r.canvas.height} canvas. ${preset} Look: ${r.look === 'game' ? 'Game, the scene through the game\'s cameras' : 'Scene, the editor\'s camera'}. Maximize on Play ${r.maximizeOnPlay ? 'on: a playtest fills the window, every card hidden' : 'off: a playtest plays docked, in the room, the cards where they are'}. Presets: ${r.presets.filter((p) => !p.own).map((p) => p.name).join(', ')}${own.length > 0 ? `; the project's: ${own.join(', ')}` : '; none of the project\'s'}.`;
}

const PLAY_OUT = (z: typeof Zod) => z.object({ state: z.enum(['none', 'running', 'paused']), tick: z.number(), ticks: z.number(), seconds: z.number(), changes: z.array(z.object({ id: z.string(), words: z.string() })) }).loose();
const GAME_VIEW_OUT = (z: typeof Zod) => z.object({
  frame: z.object({ x: z.number(), y: z.number(), width: z.number(), height: z.number() }), canvas: z.object({ width: z.number(), height: z.number() }), fills: z.enum(['room', 'window']), maximizeOnPlay: z.boolean(),
  preset: z.string(), applies: z.boolean(), pixels: z.object({ width: z.number(), height: z.number() }), scale: z.number(), look: z.enum(['scene', 'game']),
  presets: z.array(z.object({ name: z.string(), size: z.string().nullable(), mode: z.enum(['fit', 'pixel', 'stretch']), filter: z.enum(['nearest', 'linear']), own: z.boolean() })),
}).loose();
const gameViewJson = (r: GameViewResult): Omit<GameViewResult, 'tool'> => ({
  frame: r.frame, canvas: r.canvas, fills: r.fills, maximizeOnPlay: r.maximizeOnPlay, preset: r.preset, applies: r.applies, pixels: r.pixels, scale: r.scale, look: r.look, presets: r.presets, ...(r.did ? { did: r.did } : {}),
});
const VIEW_OUT = (z: typeof Zod) => z.object({ view: z.object({ position: z.array(z.number()), target: z.array(z.number()), projection: z.string(), fov: z.number().nullable(), height: z.number().nullable(), preset: z.string() }), room: z.unknown(), canvas: z.object({ width: z.number(), height: z.number() }) }).loose();

export const playTools = {
  // ---------------------------------------------------------------- the playtest

  play_state: pageTool('play_state', {
    description: 'The playtest as it stands: none, running (the game the player\'s, the editor hidden under it) or paused (the editor over the playtest\'s world) -- the loop\'s tick, the ticks and seconds since it began, and what was changed while paused, each by an id and in words: what Stop offers to keep (play_stop\'s keep). Only reads; answers while one runs.',
    input: () => ({}),
    output: (z) => PLAY_OUT(z),
    summary: () => 'read the playtest',
    words: (r) => ({ words: playWords(r), json: playJson(r) }),
    row: (r) => ({ ok: true, words: 'read the playtest', detail: playWords(r) }),
  }),

  play_start: pageTool('play_start', {
    description: 'Play, as F5 (the play strip\'s Play): a playtest from the world as it is -- the game runs, the editor hidden under it -- or a paused one run on from where it is, its changes in it. The world the playtest found is put back at play_stop. While one runs, the scene tools wait (they answer that a playtest runs): play_pause, then edit, then play_start again or play_stop.',
    input: () => ({}),
    output: (z) => PLAY_OUT(z),
    summary: () => 'play the game',
    words: (r) => ({ words: `${r.did === 'resumed' ? 'Resumed' : 'Started'}: the game runs. ${playWords(r)} play_pause pauses it, play_stop ends it with the world put back.`, json: playJson(r) }),
    row: (r) => ({ ok: true, words: r.did === 'resumed' ? 'resume the playtest' : 'start a playtest', detail: playWords(r) }),
  }),

  play_pause: pageTool('play_pause', {
    description: 'Pause the playtest running, as F6: the game stops, the editor over its world as it is now -- nothing put back. Scene tools work on that world then (each a step), view_shot shows it, play_step runs single ticks, play_start runs on, play_stop ends it and offers what was changed meanwhile.',
    input: () => ({}),
    output: (z) => PLAY_OUT(z),
    summary: () => 'pause the playtest',
    words: (r) => ({ words: `Paused. ${playWords(r)}`, json: playJson(r) }),
    row: (r) => ({ ok: true, words: 'pause the playtest', detail: playWords(r) }),
  }),

  play_step: pageTool('play_step', {
    description: 'Step the paused playtest, as F10: `n` ticks of the game (1 by default, at most 600 -- ten seconds at 60 Hz), then paused again. As each F10, the pause\'s edits are kept for Stop and its history starts again (an undo would rewind the tick with it). Refused unless a playtest is paused.',
    input: (z) => ({ n: z.number().int().min(1).max(600).optional().describe('Ticks to run (1)') }),
    output: (z) => PLAY_OUT(z),
    summary: (args) => `step the playtest ${typeof args.n === 'number' ? plural(args.n, 'tick') : 'a tick'}`,
    words: (r) => ({ words: `Stepped ${plural(r.stepped ?? 1, 'tick')}. ${playWords(r)}`, json: { ...playJson(r), stepped: r.stepped ?? 1 } }),
    row: (r) => ({ ok: true, words: `step the playtest ${plural(r.stepped ?? 1, 'tick')}`, detail: playWords(r) }),
  }),

  play_stop: pageTool('play_stop', {
    description: 'Stop the playtest, running or paused, as Shift+F5: the game stopped, the world put back as the playtest found it, the editor\'s history as it was. What was changed while paused (play_state lists it by id) is then kept or not -- `keep: \'all\'`, `\'none\'`, or a list of the ids to keep, answering the offer the person would see, with no dialog; left out, the person\'s preference (Config ▸ Editor ▸ Preferences, "After a playtest") decides: keep, drop, or ask them (the dialog shown to the person). What is kept is one step, "Kept from the playtest", that Z undoes.',
    input: (z) => ({
      keep: z.union([z.enum(['all', 'none']), z.array(z.string().min(1).max(300)).max(500)]).optional().describe('all, none, or the ids (play_state) of the changes to keep; left out, the person\'s preference'),
    }),
    output: (z) => PLAY_OUT(z).extend({ how: z.string(), kept: z.array(z.string()), skipped: z.array(z.string()), discarded: z.number(), step: z.string().nullable() }),
    summary: (args) => (args.keep === 'all' ? 'stop the playtest, keeping what was changed' : args.keep === 'none' ? 'stop the playtest, dropping what was changed' : Array.isArray(args.keep) ? `stop the playtest, keeping ${plural(args.keep.length, 'change')}` : 'stop the playtest'),
    words: (r) => {
      const kept = r.kept.length > 0 ? ` Kept ${plural(r.kept.length, 'change')} as one step, "${r.step ?? 'Kept from the playtest'}" -- Z undoes it: ${r.kept.slice(0, 8).join('; ')}.` : '';
      const skipped = r.skipped.length > 0 ? ` Skipped: ${r.skipped.join('; ')}.` : '';
      const dropped = r.discarded > 0 ? ` ${plural(r.discarded, 'change')} from the pause dropped.` : '';
      const asked = r.how === 'asked' ? ' The person is asked which changes to keep (their preference): their answer is theirs.' : '';
      return { words: `Stopped: the world is as the playtest found it.${kept}${skipped}${dropped}${asked}`, json: { ...playJson(r), how: r.how, kept: r.kept, skipped: r.skipped, discarded: r.discarded, step: r.step } };
    },
    row: (r) => ({ ok: true, words: `stop the playtest${r.kept.length > 0 ? `, ${plural(r.kept.length, 'change')} kept` : ''}`, detail: `${r.how}${r.discarded > 0 ? ` · ${r.discarded} dropped` : ''}${r.skipped.length > 0 ? ` · skipped: ${r.skipped.join('; ')}` : ''}` }),
  }),

  // ---------------------------------------------------------------- the view

  view_shot: pageTool('view_shot', {
    description: 'Look: an image of a view, drawn as the screen draws it, to see what you did. `target`: `scene` -- the editor\'s scene view as the person sees it (its grid, gizmo, outlines and camera icons with `overlays`, on by default); `camera` -- a camera entity\'s view (`camera`: its ref or path); `main` -- the game\'s own view: every camera it draws through, laid out over the canvas as the game lays them out (the main one, a split screen\'s others), with its HUD only while a playtest runs -- otherwise the 3D world alone, no HUD, which the answer says; `model` -- the Model tab\'s views as drawn (open on the Model tab). `width`/`height` in pixels (at most 2048 on the long side; by default the view\'s own shape about 1024 wide). A paused or stopped world is drawn as it stands. The person\'s view does not move. Refused while the WebGL context is lost (look again once it is back). Only reads.',
    input: (z, s) => ({
      target: z.enum(['scene', 'camera', 'main', 'model']).optional().describe('scene (the default), camera, main or model'),
      camera: s.entity.optional().describe('target camera: the camera entity, by ref or path'),
      width: z.number().int().min(16).max(2048).optional().describe('Pixels wide'),
      height: z.number().int().min(16).max(2048).optional().describe('Pixels high'),
      overlays: z.boolean().optional().describe('The editor\'s grid, gizmo, outlines and icons drawn too (scene: on; camera, main: off)'),
      format: z.enum(['webp', 'png']).optional().describe('webp (the default, smaller) or png'),
    }),
    output: (z, s) => z.object({ target: z.string(), camera: s.row.nullable(), width: z.number(), height: z.number(), overlays: z.boolean(), mimeType: z.string(), notes: z.array(z.string()) }),
    summary: (args) => `look at ${args.target === 'camera' ? `the camera ${String(args.camera)}` : args.target === 'main' ? 'the main camera\'s view' : args.target === 'model' ? 'the Model tab' : 'the scene view'}`,
    words: (r) => {
      const what = r.target === 'scene' ? 'The editor\'s scene view' : r.target === 'model' ? 'The Model tab\'s view' : r.target === 'main' ? `The game's main camera${r.camera ? ` (${r.camera.path})` : ' (the built-in one: no camera entity is main)'}` : `The camera ${r.camera?.path ?? ''}`;
      return {
        words: `${what}, ${r.width}×${r.height}${r.overlays ? ', the editor\'s overlays drawn' : ''}.${r.notes.length > 0 ? ` ${r.notes.join(' ')}` : ''}`,
        json: { target: r.target, camera: r.camera, width: r.width, height: r.height, overlays: r.overlays, mimeType: r.mimeType, notes: r.notes },
        images: [{ data: r.data, mimeType: r.mimeType }],
      };
    },
    row: (r) => ({ ok: true, words: `look at ${r.target === 'camera' ? `the camera ${r.camera?.path ?? ''}` : r.target === 'main' ? 'the main camera\'s view' : r.target === 'model' ? 'the Model tab' : 'the scene view'}`, detail: `${r.width}×${r.height} ${r.mimeType}` }),
  }),

  view_get: pageTool('view_get', {
    description: 'The editor\'s view as numbers: where its camera is and what it turns round, its projection (perspective with its field of view, or orthographic with the height it sees), which side it looks from (front, right, top … or free), the room past the editor\'s cards, and the canvas\'s size. Only reads.',
    input: () => ({}),
    output: (z) => VIEW_OUT(z),
    summary: () => 'read the view',
    words: (r) => ({ words: viewWords(r), json: { view: r.view, room: r.room, canvas: r.canvas } }),
    row: (r) => ({ ok: true, words: 'read the view', detail: viewWords(r) }),
  }),

  view_set: pageTool('view_set', {
    description: 'Move the editor\'s view -- the person\'s, as they see it; no step, so not undoable (Z does not bring the old view back: view_get first to put it back with a pose). One of: `pose` {position, target} (the camera there, turning round target); `numpad` front, back, left, right, top or bottom (the view from that side at the distance it has, as Numpad1, 3, 7 and the cube\'s cones); `projection` perspective or orthographic (as Numpad5: what is seen at the target kept the same size); `colliders` none, selected or all -- the collider overlay, the view menu\'s Colliders (green dynamic, blue kinematic, grey static, cyan triggers, dim asleep, amber the selection\'s; joints\' pivots and axes), shown in the scene and a view_shot. Answers the view after.',
    input: (z) => ({
      pose: z.object({ position: z.tuple([z.number(), z.number(), z.number()]), target: z.tuple([z.number(), z.number(), z.number()]) }).optional().describe('Where the camera is and what it turns round, in metres'),
      numpad: z.enum(['front', 'back', 'left', 'right', 'top', 'bottom']).optional().describe('The view from a side'),
      projection: z.enum(['perspective', 'orthographic']).optional().describe('Perspective or orthographic'),
      colliders: z.enum(['none', 'selected', 'all']).optional().describe('The collider overlay: none, the selection\'s colliders, or every one -- so a view_shot shows them'),
    }),
    output: (z) => VIEW_OUT(z),
    summary: (args) => (args.numpad ? `look from the ${String(args.numpad)}` : args.projection ? `view ${String(args.projection)}` : args.colliders ? `colliders ${String(args.colliders)}` : 'move the view'),
    words: (r) => ({ words: `${r.colliders !== undefined ? `The collider overlay: ${r.colliders}.` : 'Moved'} (no step: not undoable). ${viewWords(r)}`, json: { view: r.view, room: r.room, canvas: r.canvas, ...(r.colliders !== undefined ? { colliders: r.colliders } : {}) } }),
    row: (r) => ({ ok: true, words: `move the view: ${r.view.preset}, ${r.view.projection}`, detail: viewWords(r) }),
  }),

  view_focus: pageTool('view_focus', {
    description: 'Frame entities in the editor\'s view, as F does the selection: the camera onto them, near enough that they fill the room past the cards, from the side it looks from now. By ref or path; the selection does not move. Moves the person\'s view -- no step, not undoable.',
    input: (_z, s) => ({ entities: s.entities.describe('The entities to frame') }),
    output: (z, s) => VIEW_OUT(z).extend({ framed: z.array(s.row) }),
    summary: (args) => `frame ${Array.isArray(args.entities) ? plural(args.entities.length, 'entity', 'entities') : 'entities'}`,
    words: (r) => ({ words: `Framed ${(r.framed ?? []).map((e) => e.path).join(', ')} (no step: not undoable). ${viewWords(r)}`, json: { view: r.view, room: r.room, canvas: r.canvas, framed: r.framed ?? [] } }),
    row: (r) => ({ ok: true, words: `frame ${(r.framed ?? []).map((e) => e.path).join(', ')}`, detail: viewWords(r) }),
  }),

  // ---------------------------------------------------------------- the game view (Docs/game-view.md D7)

  game_view_state: pageTool('game_view_state', {
    description: 'The game view: the rect of the canvas the game is drawn in (its frame, CSS pixels from the canvas\'s top left) -- in the studio the scene\'s room between the editor\'s cards, the whole canvas with the cards away or in a maximized playtest, and inside that the box a preset fits while it applies -- the canvas\'s size, Maximize on Play, the preset chosen (Free Aspect, 16:9, 320×180 Pixel...; `applies` while the game\'s own cameras draw: a playtest running, or the Game look), the game\'s pixels and the scale (a Pixel or Stretch preset draws the world at exactly its resolution and scales it), the look, and every preset. The game\'s cameras and pointer measure `pixels`, its HUD the frame. Only reads.',
    input: () => ({}),
    output: (z) => GAME_VIEW_OUT(z),
    summary: () => 'read the game view',
    words: (r) => ({ words: gameViewWords(r), json: gameViewJson(r) }),
    row: (r) => ({ ok: true, words: 'read the game view', detail: gameViewWords(r) }),
  }),

  game_view_set: pageTool('game_view_set', {
    description: 'Set the game view, as the play strip does: `preset` -- the dropdown, a preset by its name (`Free Aspect`, `16:9`, `320×180 Pixel`, one of the project\'s; game_view_state lists them), shaping a playtest and the Game look into a box of its aspect, letterboxed, at its resolution for Pixel or Stretch; `look` -- the dropdown\'s Game: `game` shows the stopped or paused scene through the game\'s own cameras shaped by the preset (the editor\'s camera and gizmo put away), `scene` the editor\'s camera again; `maximizeOnPlay` -- the Maximize on Play toggle (and Config ▸ Preferences): true, a playtest fills the whole window, every card hidden; false, it plays docked in the scene\'s room. Any of them, at least one. The person\'s preferences and view: no step, not undoable. Answers the game view after -- `view_shot` with target `main` then shows the box as it draws.',
    input: (z) => ({
      preset: z.string().optional().describe('A preset by its name, as game_view_state lists them: Free Aspect for none'),
      look: z.enum(['scene', 'game']).optional().describe('game: the scene through the game\'s cameras and the preset; scene: the editor\'s camera'),
      maximizeOnPlay: z.boolean().optional().describe('A playtest over the whole window (true), or docked in the scene\'s room (false)'),
    }),
    output: (z) => GAME_VIEW_OUT(z),
    summary: (args) => (typeof args.preset === 'string' ? `game view ${args.preset}` : args.look === 'game' ? 'the Game look' : args.look === 'scene' ? 'the editor\'s camera' : args.maximizeOnPlay === true ? 'maximize on play' : args.maximizeOnPlay === false ? 'play docked in the room' : 'set the game view'),
    words: (r) => ({ words: `Set (a preference: no step). ${gameViewWords(r)}`, json: gameViewJson(r) }),
    row: (r) => ({ ok: true, words: `game view ${r.preset}${r.look === 'game' ? ', Game look' : ''}${r.maximizeOnPlay ? ', maximize on play' : ''}`, detail: gameViewWords(r) }),
  }),

  game_view_preset: pageTool('game_view_preset', {
    description: 'Add, change, move or remove a game view preset of the project\'s own, as the dropdown\'s Add… and Config ▸ Game view: `name` the preset; `size` an aspect (`16:9`, Fit only) or pixels (`640x360`); `mode` fit (the screen\'s sharpness in the largest box of its aspect), pixel (exactly its pixels, scaled by the largest whole number, nearest) or stretch (exactly its pixels, scaled by any factor); `filter` nearest or linear, for stretch. A name no preset of the project\'s has adds one (size needed); one it has is changed (`rename` to call it something else) -- or with `remove: true` taken out, or with `move` (-1 up, 1 down) moved in the list. The built-ins are not changed. Kept with the project\'s editor settings: no step. Answers the game view after.',
    input: (z) => ({
      name: z.string().describe('The preset: a new name adds one, one of the project\'s changes it'),
      size: z.string().optional().describe('16:9 (an aspect, Fit only) or 640x360 (pixels)'),
      mode: z.enum(['fit', 'pixel', 'stretch']).optional(),
      filter: z.enum(['nearest', 'linear']).optional().describe('Stretch\'s: nearest for crisp pixels, linear for smooth'),
      rename: z.string().optional().describe('A new name for one of the project\'s'),
      remove: z.boolean().optional().describe('true: the preset taken out (the dropdown back to Free Aspect if it was chosen)'),
      move: z.number().int().optional().describe('Places up (-1) or down (1) the list'),
    }),
    output: (z) => GAME_VIEW_OUT(z),
    summary: (args) => `${args.remove === true ? 'remove' : 'preset'} ${typeof args.name === 'string' ? args.name : ''}`.trim(),
    words: (r) => ({ words: `Preset ${r.did ?? 'set'} (the project's editor settings: no step). ${gameViewWords(r)}`, json: gameViewJson(r) }),
    row: (r) => ({ ok: true, words: `preset ${r.did ?? 'set'}`, detail: gameViewWords(r) }),
  }),

  // ---------------------------------------------------------------- history

  history_list: pageTool('history_list', {
    description: 'The world\'s undo stack, as the History card shows it: each step\'s label, whose it is (`by`: Claude\'s in the studio\'s panel, "Claude: …"; an outside client\'s, "MCP: …"; or the person\'s), and where the person is -- steps done, then those undone that redo brings back. Only reads.',
    input: () => ({}),
    output: (z) => z.object({ steps: z.array(z.object({ n: z.number(), label: z.string(), by: z.enum(['person', 'Claude', 'MCP']), done: z.boolean() })), done: z.number(), saved: z.boolean() }),
    summary: () => 'read the history',
    words: (r) => {
      const top = r.steps.filter((s) => s.done).at(-1);
      return {
        words: r.steps.length === 0 ? 'The history is empty.' : `${plural(r.steps.length, 'step')}, ${r.done} done${top ? `; the last done "${top.label}" (${BY_WORDS[top.by]})` : ''}${r.steps.length > r.done ? `; ${r.steps.length - r.done} to redo` : ''}${r.saved ? '; saved here' : ''}.`,
        json: { steps: r.steps, done: r.done, saved: r.saved },
      };
    },
    row: (r) => ({ ok: true, words: 'read the history', detail: `${plural(r.steps.length, 'step')}, ${r.done} done` }),
  }),

  history_undo: pageTool('history_undo', {
    description: 'Undo the world\'s last `n` steps (1 by default), as Z: an agent\'s own (Claude\'s "Claude: …", an outside client\'s "MCP: …") -- one of the person\'s is refused, unless `any: true`, which takes back the person\'s work (destructive: it asks them under Auto). history_list shows the steps.',
    input: (z) => ({ n: z.number().int().min(1).max(100).optional().describe('Steps to undo (1)'), any: z.boolean().optional().describe('Undo the person\'s steps too') }),
    output: (z) => z.object({ moved: z.array(z.string()), done: z.number() }),
    summary: (args) => `undo ${typeof args.n === 'number' ? plural(args.n, 'step') : 'a step'}`,
    words: (r) => ({ words: `Undone: ${r.moved.map((l) => `"${l}"`).join(', ')}. history_redo does it again.`, json: { moved: r.moved, done: r.done } }),
    row: (r) => ({ ok: true, words: `undo ${r.moved.map((l) => `"${l}"`).join(', ')}`, detail: null }),
  }),

  history_redo: pageTool('history_redo', {
    description: 'Redo the next `n` steps undone (1 by default), as Y: Claude\'s own -- one of the person\'s only with `any: true` (destructive: it asks them under Auto).',
    input: (z) => ({ n: z.number().int().min(1).max(100).optional().describe('Steps to redo (1)'), any: z.boolean().optional().describe('Redo the person\'s steps too') }),
    output: (z) => z.object({ moved: z.array(z.string()), done: z.number() }),
    summary: (args) => `redo ${typeof args.n === 'number' ? plural(args.n, 'step') : 'a step'}`,
    words: (r) => ({ words: `Done again: ${r.moved.map((l) => `"${l}"`).join(', ')}.`, json: { moved: r.moved, done: r.done } }),
    row: (r) => ({ ok: true, words: `redo ${r.moved.map((l) => `"${l}"`).join(', ')}`, detail: null }),
  }),
};
