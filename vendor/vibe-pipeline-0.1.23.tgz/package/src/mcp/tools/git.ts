/**
 * The git tools (Docs/mcp.md §4's Studio, M5): the Git card's, each through `studio/git.ts`' own functions over the
 * card's context -- its `git` stream (the Console's), its one-at-a-time serial -- never a second git path.
 *
 * - **Reads**: `git_status`, `git_diff` (paths against `HEAD`, staged or not, untracked as new), `git_log`.
 * - **`git_commit`**: exactly the paths named -- or, with `all`, the files this turn wrote (its Edits and Writes, its
 *   tools' files) that git sees changed -- as the card's Commit takes the ticked rows (`git add -- <paths>`, `git commit
 *   -F - -- <paths>`): what was staged by hand and not named stays out, and the person's own work is never swept up.
 *   Naming a file the turn did not write asks at the gate (`destroysWhen`: a card under Auto, Unsafe auto lets it by).
 *   A write: the commit stays, as one Claude's Bash makes does; Undo this turn puts the files back from its snapshot,
 *   never the commit away.
 * - **`git_branch`**: list (a read), create, switch -- switching with local changes is what the card asks before,
 *   and the tool is refused then unless `confirm: true`, which the permission gate holds destructive (a card under
 *   Auto).
 * - **`git_push`, `git_pull`**: destructive at any input (they reach another machine, or bring its work in): the gate
 *   asks under Ask and Auto, Unsafe auto lets them by; then run as the card's confirmed call -- never forced, a pull
 *   `--ff-only`.
 *
 * Nothing at module level but the records.
 */
import type { GitAsk, GitBranches, GitChange, GitLog, GitRan, GitStatus } from '../../studio/api-types.ts';
import { gitBranches, gitCheckout, gitCommit, gitDiff, gitLog, gitPull, gitPush, gitStatus } from '../../studio/git.ts';
import { serverTool, ToolRefusal } from '../tool.ts';
import { plural } from '../words.ts';
import { asPath, asTool, studioOf } from '../studio-work.ts';

/** A change in a line: `M src/game/x.ts` (staged said). */
const KIND: Record<GitChange['kind'], string> = { modified: 'M', added: 'A', deleted: 'D', renamed: 'R', untracked: 'U', conflict: '!' };
const changeLine = (c: GitChange): string => `${KIND[c.kind]} ${c.from ? `${c.from} → ` : ''}${c.path}${c.staged ? ' (staged)' : ''}${c.repo === 'engine' ? ' [engine]' : ''}`;

/** The repository a call names: `project` (the default) or `engine`. */
const repoOf = (raw: unknown): 'project' | 'engine' => {
  if (raw === undefined) return 'project';
  if (raw !== 'project' && raw !== 'engine') throw new ToolRefusal('repo is project or engine');
  return raw;
};

/** A head in a line. */
function headWords(s: GitStatus): string {
  if (s.repos.length === 0) return 'No git repository here.';
  return s.repos.map((r) => `${r.repo === 'engine' ? 'engine/: ' : ''}${r.branch ?? '(detached HEAD)'}${r.upstream ? ` → ${r.upstream}${r.ahead || r.behind ? ` (↑${r.ahead} ↓${r.behind}, as last fetched)` : ''}` : ', no upstream'}${r.clean ? ', clean' : ''}`).join('; ');
}

/** A push's or pull's answer: git's last lines, or the card's ask -- which a confirmed call never gets. */
const ranWords = (what: string, r: GitAsk | GitRan): string => ('ask' in r ? `Not run: ${r.ask}` : `${what}: ${r.lines.slice(-6).join('\n') || 'done'}`);

export const gitTools = {
  git_status: serverTool('git_status', {
    description: 'The project\'s git as the Git card shows it: each repository\'s branch, upstream, ahead and behind (as last fetched -- nothing is fetched) and each changed file (modified, added, deleted, renamed, untracked, conflict; staged or not). The engine\'s submodule (engine/) too in a source project. Only reads.',
    input: () => ({}),
    output: (z) => z.object({ repos: z.array(z.unknown()), changes: z.array(z.object({ path: z.string(), repo: z.string(), kind: z.string(), staged: z.boolean(), from: z.string().optional() })) }),
    summary: () => 'read git\'s status',
    async run(ctx) {
      const calls = studioOf(ctx);
      const s = await asTool(() => gitStatus(calls.git));
      const words = `${headWords(s)}${s.changes.length === 0 ? '\nNothing changed.' : `\n${plural(s.changes.length, 'change')}:\n${s.changes.slice(0, 80).map(changeLine).join('\n')}${s.changes.length > 80 ? `\n… and ${s.changes.length - 80} more in the JSON` : ''}`}`;
      return { words, json: s };
    },
    row: (_args, out) => ({ ok: !out.isError, words: 'read git\'s status', detail: out.words.split('\n')[0] ?? null }),
  }),

  git_diff: serverTool('git_diff', {
    description: 'The diff of `paths` against the last commit (HEAD), staged or not -- an untracked file as new -- as the Git card\'s Draft reads it; cut at 100 KB. Only reads.',
    input: (z) => ({ paths: z.array(z.string().min(1).max(500)).min(1).max(200) }),
    output: (z) => z.object({ diff: z.string(), truncated: z.boolean() }),
    summary: (args) => `read the diff of ${Array.isArray(args.paths) && args.paths.length === 1 ? String(args.paths[0]) : plural(Array.isArray(args.paths) ? args.paths.length : 0, 'file')}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const paths = (args.paths as unknown[]).map(asPath);
      const d = await asTool(() => gitDiff(calls.git, paths));
      return { words: d.diff === '' ? `No difference from HEAD in ${paths.join(', ')}.` : `${d.truncated ? 'The diff, cut at 100 KB:' : 'The diff:'}\n${d.diff}`, json: d };
    },
    row: (args, out) => ({ ok: !out.isError, words: `read the diff of ${Array.isArray(args.paths) ? plural(args.paths.length, 'file') : 'files'}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  git_log: serverTool('git_log', {
    description: 'The last commits touching the project, as the Git card\'s log: each repository\'s, newest first, with hash, author, date, subject and each file\'s lines added and deleted. `count` (20, at most 100). Only reads.',
    input: (z) => ({ count: z.number().int().min(1).max(100).optional() }),
    output: (z) => z.array(z.object({ repo: z.string(), entries: z.array(z.unknown()) })),
    summary: () => 'read git\'s log',
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const logs: GitLog[] = await asTool(() => gitLog(calls.git, typeof args.count === 'number' ? String(args.count) : null));
      const words = logs.length === 0 ? 'No git repository here.' : logs.map((l) => `${l.repo === 'engine' ? 'engine/:\n' : ''}${l.entries.length === 0 ? 'No commit yet.' : l.entries.map((e) => `${e.short} ${e.date.slice(0, 10)} ${e.author}: ${e.subject}`).join('\n')}`).join('\n');
      return { words, json: logs };
    },
    row: (_args, out) => ({ ok: !out.isError, words: 'read git\'s log', detail: out.words.split('\n')[0] ?? null }),
  }),

  git_commit: serverTool('git_commit', {
    description: 'Commit, as the Git card\'s Commit: exactly `paths` (project-relative; a rename\'s old path beside its new one), or `all: true` for the files this turn wrote (its Edit and Write calls, its tools\' files) that git sees changed -- never a file the person changed or made -- staged and committed with `message` as written; what was staged by hand and not named stays out. Naming a file this turn did not write asks the person first (under Auto too). One repository a commit (`repo`: project, the default, or engine). The commit stays as a Bash commit does: Undo this turn puts files back, never the commit away. Never pushes (git_push).',
    input: (z) => ({
      message: z.string().min(1).max(20_000),
      paths: z.array(z.string().min(1).max(500)).min(1).max(2000).optional(),
      all: z.boolean().optional().describe('The files this turn wrote that git sees changed, in place of paths'),
      repo: z.enum(['project', 'engine']).optional(),
    }),
    output: (z) => z.object({ hash: z.string(), short: z.string(), paths: z.array(z.string()), repo: z.string() }),
    summary: (args) => `commit ${args.all === true ? 'this turn\'s files' : plural(Array.isArray(args.paths) ? args.paths.length : 0, 'file')}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const repo = repoOf(args.repo);
      if ((args.all === true) === Array.isArray(args.paths)) throw new ToolRefusal('Name the paths to commit, or all: true -- one of them');
      let paths: string[];
      if (args.all === true) {
        // The turn's own files that git sees changed (a rename's old path beside, when the turn wrote the new one): never the person's.
        const turn = new Set(ctx.written?.() ?? []);
        const s = await asTool(() => gitStatus(calls.git));
        const mine = s.changes.filter((c) => c.repo === repo && (turn.has(c.path) || (c.from !== undefined && turn.has(c.from))));
        paths = [...new Set(mine.flatMap((c) => (c.from ? [c.from, c.path] : [c.path])))];
        if (paths.length === 0) throw new ToolRefusal(`Nothing this turn wrote is changed in the ${repo === 'engine' ? 'engine\'s repository' : 'project'}${turn.size === 0 ? ' (it has written nothing)' : ''}: name the paths to commit -- the person is asked about any this turn did not write`);
      } else paths = (args.paths as unknown[]).map(asPath);
      const done = await asTool(() => gitCommit(calls.git, { message: String(args.message), paths, repo }));
      return { words: `Committed ${done.short} (${plural(paths.length, 'file')}) in the ${repo === 'engine' ? 'engine\'s repository' : 'project'}: ${String(args.message).split('\n')[0]}. Not pushed.`, json: { ...done, paths, repo } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `commit ${args.all === true ? 'this turn\'s files' : plural(Array.isArray(args.paths) ? args.paths.length : 0, 'file')}`, detail: out.words }),
  }),

  git_branch: serverTool('git_branch', {
    description: 'Branches, as the Git card\'s picker: `action: list` (the default; a read) -- each repository\'s local branches and the current one; `create` -- a new branch `name` from where HEAD is, switched to (git switch -c); `switch` -- to the branch `name` (git switch). Switching with local changes is what the card asks the person about first: refused unless `confirm: true` (which asks the person under Auto). `repo`: project (the default) or engine.',
    input: (z) => ({
      action: z.enum(['list', 'create', 'switch']).optional(),
      name: z.string().min(1).max(250).optional(),
      repo: z.enum(['project', 'engine']).optional(),
      confirm: z.boolean().optional().describe('Switch with local changes: they go with you, as git switch carries them'),
    }),
    output: (z) => z.union([z.array(z.unknown()), z.object({ ok: z.boolean(), lines: z.array(z.string()), branch: z.string() })]),
    summary: (args) => (args.action === 'create' ? `make the branch ${String(args.name)}` : args.action === 'switch' ? `switch to ${String(args.name)}` : 'list the branches'),
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const action = typeof args.action === 'string' ? args.action : 'list';
      if (action === 'list') {
        const all: GitBranches[] = await asTool(() => gitBranches(calls.git));
        return { words: all.length === 0 ? 'No git repository here.' : all.map((b) => `${b.repo === 'engine' ? 'engine/: ' : ''}${b.branches.map((x) => `${x.current ? '* ' : ''}${x.name}${x.upstream ? ` → ${x.upstream}` : ''}`).join(', ') || 'no branch yet'}`).join('\n'), json: all };
      }
      if (typeof args.name !== 'string') throw new ToolRefusal(`${action} names the branch: name`);
      const repo = repoOf(args.repo);
      const r = await asTool(() => gitCheckout(calls.git, { branch: args.name, repo, ...(action === 'create' ? { create: true } : {}), ...(args.confirm === true ? { confirm: true } : {}) }));
      if ('ask' in r) throw new ToolRefusal(`Not switched: ${r.ask} -- call again with confirm: true once the person agrees`);
      return { words: `${action === 'create' ? 'Made and switched to' : 'Switched to'} ${args.name}${repo === 'engine' ? ' in engine/' : ''}. ${r.lines.slice(-3).join(' ')}`.trim(), json: { ...r, branch: args.name } };
    },
    row: (args, out) => ({ ok: !out.isError, words: args.action === 'create' ? `make the branch ${String(args.name)}` : args.action === 'switch' ? `switch to ${String(args.name)}` : 'list the branches', detail: out.words.split('\n')[0] ?? null }),
  }),

  git_push: serverTool('git_push', {
    description: 'Push the current branch to its upstream, as the Git card\'s Push confirmed -- never forced; a branch with no upstream is pushed --set-upstream to origin (or the one remote). Reaches another machine: the person is asked first under Ask and Auto. `repo`: project (the default) or engine. Git\'s last lines answered; a refusal in git\'s words.',
    input: (z) => ({ repo: z.enum(['project', 'engine']).optional() }),
    output: (z) => z.object({ ok: z.boolean(), lines: z.array(z.string()) }),
    summary: (args) => `push ${args.repo === 'engine' ? 'the engine' : 'the project'} to its remote`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const r = await asTool(() => gitPush(calls.git, { repo: repoOf(args.repo), confirm: true }));
      return { words: ranWords('Pushed', r), json: r };
    },
    row: (args, out) => ({ ok: !out.isError, words: `push${args.repo === 'engine' ? ' the engine' : ''}`, detail: out.words }),
  }),

  git_pull: serverTool('git_pull', {
    description: 'Pull the current branch from its upstream, fast-forward only, as the Git card\'s Pull confirmed: one that would merge is git\'s refusal, said, never a merge. Brings another machine\'s work in: the person is asked first under Ask and Auto. `repo`: project (the default) or engine.',
    input: (z) => ({ repo: z.enum(['project', 'engine']).optional() }),
    output: (z) => z.object({ ok: z.boolean(), lines: z.array(z.string()) }),
    summary: (args) => `pull ${args.repo === 'engine' ? 'the engine' : 'the project'} from its remote`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const r = await asTool(() => gitPull(calls.git, { repo: repoOf(args.repo), confirm: true }));
      return { words: ranWords('Pulled', r), json: r };
    },
    row: (args, out) => ({ ok: !out.isError, words: `pull${args.repo === 'engine' ? ' the engine' : ''}`, detail: out.words }),
  }),
};
