/**
 * The zod shapes the studio tools share (`../tool.ts`' `Shapes`), made from `z` as the server is made -- never at
 * module level: `zod` is imported only as a session starts.
 */
import type { z as Zod } from 'zod';
import type { Shapes } from '../tool.ts';

export function shapes(z: typeof Zod): Shapes {
  const entity = z.union([z.number().int().positive(), z.string().min(1).max(500)]).describe('An entity: its ref (a number, as answers give it) or its path of names (big crate/rider; #<ref> for one with no name)');
  return {
    id: z.number().int().positive(),
    ref: z.object({ uid: z.string().min(1).max(40), key: z.string().max(300) }),
    scene: z.object({ name: z.string().nullable(), unsaved: z.boolean() }).nullable(),
    job: z.object({
      id: z.string(), kind: z.string(), label: z.string(), state: z.enum(['running', 'done', 'failed']),
      progress: z.object({ done: z.number(), total: z.number().nullable(), note: z.string().nullable() }).nullable(),
      result: z.unknown(), error: z.string().nullable(), started: z.number(), ended: z.number().nullable(),
    }),
    entity,
    entities: z.array(entity).min(1).max(256),
    row: z.object({ ref: z.number(), id: z.number(), path: z.string(), name: z.string().nullable() }),
  };
}
