/**
 * The physics tools (Docs/physics.md §7): the page's, each through the editor's own -- Config ▸ Game ▸ Physics'
 * rows (`physics_state` reads them, `physics_settings_set` writes `physics.json` as they do), a ray or a shape put to
 * the world as it stands (`physics_raycast`, `physics_overlap`: the bodies brought up to the components first, so
 * they answer while stopped too), and a collider's Fit to model (`physics_fit`, one step). Component edits stay
 * `scene_set` and `scene_component`'s; the collider overlay is `view_set`'s `colliders`.
 *
 * Nothing at module level but the records.
 */
import type { z as Zod } from 'zod';
import type { EntityRow, PhysicsSettingsFacts, PhysicsStateResult } from '../../agent/api-types.ts';
import { pageTool } from '../tool.ts';
import { plural } from '../words.ts';
import { assetsOf, physmatSetOffline } from '../assets.ts';

const SETTINGS_OUT = (z: typeof Zod) => z.object({
  enabled: z.boolean(), gravity: z.array(z.number()), substeps: z.number(), iterations: z.number(),
  sleep: z.object({ linear: z.number(), angular: z.number() }), defaultMaterial: z.object({ friction: z.number(), restitution: z.number() }),
  layers: z.array(z.string()), ignore: z.array(z.array(z.string())),
});

/** The settings in a line. */
function settingsWords(s: PhysicsSettingsFacts): string {
  const pairs = s.ignore.length === 0 ? 'every layer colliding with every other' : `${s.ignore.map(([a, b]) => `${a} passing through ${b}`).join(', ')}`;
  return `Physics ${s.enabled ? 'on' : 'off'}: gravity (${s.gravity.join(', ')}), ${plural(s.substeps, 'substep')}, ${s.iterations} iterations, sleep below ${s.sleep.linear} m/s and ${s.sleep.angular} rad/s, default friction ${s.defaultMaterial.friction} and bounce ${s.defaultMaterial.restitution}; layers ${s.layers.join(', ')}, ${pairs}.`;
}

/** `physics_state` in words. */
function stateWords(r: PhysicsStateResult): string {
  const s = r.stats;
  const running = r.running && s ? ` Running: ${s.dynamic} dynamic, ${s.kinematic} kinematic, ${s.static} static (${s.awake} awake), ${s.triggers} triggers, ${s.contacts} contacts, a step ${Number(s.stepMs.toFixed(2))} ms (at most ${Number(s.maxStepMs.toFixed(2))}).` : r.enabled ? ' Not running in this page (Ammo not loaded).' : '';
  return `${settingsWords(r.settings)}${running} The collider overlay: ${r.colliders}.`;
}

const row = (e: EntityRow): string => e.path;

export const physicsTools = {
  physics_state: pageTool('physics_state', {
    description: 'The project\'s physics, as Config ▸ Game ▸ Physics shows it: on or off (physics.json\'s `enabled`; off, the components load and do nothing and Ammo is left out of the build), whether it runs in this page, the settings -- gravity, substeps, solver iterations, sleep thresholds, the default material, the layer names and the ignore pairs -- the matrix as each layer\'s list of those it collides with, the stats (bodies by type and awake, triggers, contacts, the step\'s milliseconds; null where it does not run), and the collider overlay\'s choice. Only reads.',
    input: () => ({}),
    output: (z) => z.object({ enabled: z.boolean(), running: z.boolean(), settings: SETTINGS_OUT(z), matrix: z.record(z.string(), z.array(z.string())), stats: z.unknown(), colliders: z.enum(['none', 'selected', 'all']) }),
    summary: () => 'read the physics',
    words: (r) => ({ words: stateWords(r), json: { enabled: r.enabled, running: r.running, settings: r.settings, matrix: r.matrix, stats: r.stats, colliders: r.colliders } }),
    row: (r) => ({ ok: true, words: `read the physics (${r.enabled ? 'on' : 'off'})`, detail: stateWords(r) }),
  }),

  physics_settings_set: pageTool('physics_settings_set', {
    description: 'Write the project\'s physics.json, as Config ▸ Game ▸ Physics does -- any of: `enabled` (physics on or off: the dev server restarts and the page with it, so only with the scene saved; off, Ammo is out of every build), `gravity` [x, y, z] m/s², `substeps` (1-8 steps a tick), `iterations` (the solver\'s, 1-50), `sleep` {linear, angular} thresholds, `defaultMaterial` {friction, restitution}, `layers` (the names, 1 to 15, the first every collider\'s to begin with), `ignore` (the pairs of layer names that pass through each other -- the matrix; renaming a layer without it carries its pairs off). Checked as the file is: a wrong field refused, nothing written. Refused while a playtest is on. The file\'s change, not the world\'s: no step, not undoable -- the running game takes it at once. Answers the settings after.',
    input: (z) => ({
      enabled: z.boolean().optional().describe('Physics on or off in the project (the dev server restarts)'),
      gravity: z.tuple([z.number(), z.number(), z.number()]).optional().describe('Metres a second squared'),
      substeps: z.number().int().optional().describe('1 to 8'),
      iterations: z.number().int().optional().describe('1 to 50'),
      sleep: z.object({ linear: z.number().optional(), angular: z.number().optional() }).optional(),
      defaultMaterial: z.object({ friction: z.number().optional(), restitution: z.number().optional() }).optional(),
      layers: z.array(z.string()).optional().describe('Every layer\'s name, in order: 1 to 15'),
      ignore: z.array(z.tuple([z.string(), z.string()])).optional().describe('Every pair of layers that pass through each other'),
    }),
    output: (z) => z.object({ settings: SETTINGS_OUT(z), restart: z.boolean() }),
    summary: (args) => `physics.json: ${Object.keys(args).join(', ') || 'nothing'}`,
    words: (r) => ({ words: `physics.json written (the file's: no step).${r.restart ? ' Physics turned on or off: the dev server restarts, and the page with it.' : ''} ${settingsWords(r.settings)}`, json: { settings: r.settings, restart: r.restart } }),
    row: (r) => ({ ok: true, words: `physics.json written${r.restart ? ', restarting' : ''}`, detail: settingsWords(r.settings) }),
  }),

  physics_raycast: pageTool('physics_raycast', {
    description: 'A ray put to the physics world as it stands -- the bodies brought up to the components first, so it answers while stopped and paused as in a playtest: from `from` along `direction` for `max` metres (100), against `layers` by name (every layer), triggers only with `triggers`; the nearest hit, or with `all` every body along it, nearest first -- each its entity, the point, the surface\'s normal and the distance. Refused where physics does not run (off, or Ammo not loaded). Only reads.',
    input: (z) => ({
      from: z.tuple([z.number(), z.number(), z.number()]).describe('Where the ray starts, world space'),
      direction: z.tuple([z.number(), z.number(), z.number()]).describe('Which way: need not be unit'),
      max: z.number().optional().describe('Metres, 100 when left out'),
      layers: z.array(z.string()).optional().describe('The layers it sees, by name: every one when left out'),
      triggers: z.boolean().optional().describe('Triggers too'),
      all: z.boolean().optional().describe('Every body along it, not the nearest only'),
    }),
    output: (z, s) => z.object({ hits: z.array(z.object({ entity: s.row, point: z.array(z.number()), normal: z.array(z.number()), distance: z.number() })) }),
    summary: (args) => `raycast from ${Array.isArray(args.from) ? args.from.join(', ') : '?'}`,
    words: (r) => ({ words: r.hits.length === 0 ? 'The ray met nothing.' : r.hits.map((h) => `${row(h.entity)} at ${Number(h.distance.toFixed(3))} m (${h.point.map((n) => Number(n.toFixed(3))).join(', ')}), normal (${h.normal.map((n) => Number(n.toFixed(3))).join(', ')})`).join('; '), json: { hits: r.hits } }),
    row: (r) => ({ ok: true, words: `raycast: ${plural(r.hits.length, 'hit')}`, detail: r.hits.map((h) => row(h.entity)).join(', ') }),
  }),

  physics_overlap: pageTool('physics_overlap', {
    description: 'What a sphere or a box at a point overlaps in the physics world as it stands (the bodies brought up to the components first): `shape` sphere (`radius`) or box (`half` extents), at `at`, against `layers` by name (every one), triggers only with `triggers`. The entities, in id order. Refused where physics does not run. Only reads.',
    input: (z) => ({
      shape: z.enum(['sphere', 'box']),
      at: z.tuple([z.number(), z.number(), z.number()]).describe('Its centre, world space'),
      radius: z.number().optional().describe('A sphere\'s, metres'),
      half: z.tuple([z.number(), z.number(), z.number()]).optional().describe('A box\'s half extents, metres'),
      layers: z.array(z.string()).optional(),
      triggers: z.boolean().optional(),
    }),
    output: (z, s) => z.object({ entities: z.array(s.row) }),
    summary: (args) => `overlap a ${String(args.shape ?? 'shape')}`,
    words: (r) => ({ words: r.entities.length === 0 ? 'It overlaps nothing.' : `It overlaps ${r.entities.map(row).join(', ')}.`, json: { entities: r.entities } }),
    row: (r) => ({ ok: true, words: `overlap: ${plural(r.entities.length, 'entity', 'entities')}`, detail: r.entities.map(row).join(', ') }),
  }),

  physmat_set: pageTool('physmat_set', {
    description: 'Set a physics material\'s fields, as the Assets inspector\'s Physics material block does: `key` (its path under src/assets/physics-materials, lowercased: ice, floors/rubber), and any of `friction` (sliding, 0 ice up), `rollingFriction` (0: a ball rolls on forever), `restitution` (bounce, 0 dead to 1 back as high), `frictionCombine` and `restitutionCombine` (how two colliders\' values meet: average, min, multiply or max -- the higher of the two modes wins). Written as the editor writes the file (only what differs from the defaults, its uid kept); a wrong value refuses the call whole. One step in the Assets panel\'s history (Z there writes the text back); the game takes it live. asset_new kind physicsmaterial makes one. Needs the studio open.',
    input: (z) => ({
      key: z.string().min(1).max(300).describe('The physics material\'s key: ice'),
      friction: z.number().min(0).optional(),
      rollingFriction: z.number().min(0).optional(),
      restitution: z.number().min(0).optional(),
      frictionCombine: z.enum(['average', 'min', 'multiply', 'max']).optional(),
      restitutionCombine: z.enum(['average', 'min', 'multiply', 'max']).optional(),
    }),
    output: (z) => z.object({ key: z.string(), path: z.string(), values: z.record(z.string(), z.unknown()), via: z.string() }).loose(),
    summary: (args) => `set ${Object.keys(args).filter((k) => k !== 'key').join(', ') || 'nothing'} of the physics material ${String(args.key)}`,
    offline: (ctx, args) => physmatSetOffline(assetsOf(ctx), args),
    words: (r) => ({ words: `${r.key}: friction ${r.values.friction} (${r.values.frictionCombine}), rolling ${r.values.rollingFriction}, bounce ${r.values.restitution} (${r.values.restitutionCombine})${r.step ? ` -- ${r.step}, Z in the Assets panel undoes` : ' -- it said so already: nothing written'}.`, json: { key: r.key, path: r.path, values: r.values, step: r.step, via: r.via } }),
    row: (r) => ({ ok: true, words: `set the physics material ${r.key}`, detail: `friction ${r.values.friction}, rolling ${r.values.rollingFriction}, bounce ${r.values.restitution}` }),
  }),

  physics_fit: pageTool('physics_fit', {
    description: 'Fit a collider of an entity to its model, as the collider block\'s Fit to model: the bounds of its Render.model in its own space -- a box to them, a sphere round them, a capsule, cylinder or cone along their longest axis, a hull or mesh to the model itself (mesh none, the one its Render draws); centre to their middle, turn nought. `collider` names which (BoxCollider …) where it has several. One step, Z undoes. Refused for a plane or a height field, or an entity with no model drawn.',
    input: (z, s) => ({ entity: s.entity, collider: z.string().optional().describe('BoxCollider, SphereCollider, CapsuleCollider, CylinderCollider, ConeCollider, HullCollider or MeshCollider: which, where it has several') }),
    output: (z, s) => z.object({ entity: s.row, collider: z.string(), set: z.record(z.string(), z.number()), step: z.string().nullable() }),
    summary: (args) => `fit ${typeof args.collider === 'string' ? args.collider : 'a collider'} to its model`,
    words: (r) => ({ words: `${r.collider} on ${row(r.entity)} fitted to its model: ${Object.entries(r.set).map(([k, v]) => `${k} ${Number(v.toFixed(4))}`).join(', ')}${r.step ? ` (${r.step}: Z undoes)` : ' (it was so already: no step)'}.`, json: { entity: r.entity, collider: r.collider, set: r.set, step: r.step } }),
    row: (r) => ({ ok: true, words: `fit ${r.collider} on ${row(r.entity)}`, detail: Object.entries(r.set).map(([k, v]) => `${k} ${Number(v.toFixed(4))}`).join(', ') }),
  }),
};
