/**
 * The asset area's tools (Docs/mcp.md §4's assets, M3): the project's files as the Assets panel shows and changes
 * them -- reads, and writes that are the panel's own steps when a studio tab is open (D2), else the dev server's.
 *
 * - **Reads** (server tools): `asset_list`, `asset_info`, `asset_uses`, `asset_thumb` (an image), `material_get`,
 *   `prefab_file`.
 * - **Writes** (page tools with a server path, `offline` in the catalogue): `asset_new`, `asset_move`, `asset_copy`,
 *   `asset_delete` (destructive), `asset_restore`, `asset_options`, `material_set`, `asset_export` (a job). In a tab
 *   each is a step on the Assets panel's history, `Claude: …`, Z there undoing it; with none, the routes' work in the
 *   dev server (`../assets.ts`), Undo this turn alone. Either way the files touched are the turn's.
 * - **The server's alone**: `asset_import` (a file on this machine: the server reads it, the page never could) and
 *   `asset_empty_trash` (destructive; no step anywhere -- it is for good). **The page's alone**: `prefab_edit` (the
 *   root's components are the compile's, the editor's writer's).
 *
 * Nothing at module level but the records.
 */
import type { AssetWrite } from '../../agent/api-types.ts';
import {
  assetInfo, assetList, assetsOf, assetUses, cleanPath, copyOffline, deleteOffline, exportOffline, followExports, importSource, materialGet, materialSetOffline,
  moveOffline, newOffline, optionsOffline, prefabFile, refusalOf, restoreOffline, routed,
} from '../assets.ts';
import { pageTool, serverTool, ToolRefusal } from '../tool.ts';
import { plural } from '../words.ts';

/** Where a write ran, in words: the panel's step Z undoes, or the server's, Undo this turn's. */
function viaWords(r: AssetWrite): string {
  const how = r.via === 'panel'
    ? r.step !== null ? ` One step in the Assets panel's history, "${r.step}": Z there undoes it.` : ''
    : ' No studio tab: the dev server did it -- Undo this turn takes it back.';
  return `${how}${r.partial ? ` Not all of it: ${r.partial}.` : ''}`;
}

/** The row's hover: the step, or the server's. */
const viaDetail = (r: AssetWrite, more: string): string => `${more}${r.via === 'panel' ? (r.step !== null ? ` · one step, "${r.step}"` : '') : ' · the dev server (no studio tab)'}${r.partial ? ` · ${r.partial}` : ''}`;

/** A list in a line, at most `n` said. */
const some = (list: readonly string[], n = 6): string => (list.length <= n ? list.join(', ') : `${list.slice(0, n).join(', ')} and ${list.length - n} more`);

/** The JSON every write carries of where it ran. */
const viaJson = (r: AssetWrite): Record<string, unknown> => ({ via: r.via, step: r.step, files: r.files, ...(r.partial ? { partial: r.partial } : {}) });

const PATHS = 'Project-relative paths: src/assets/models/props/crate.glb, AssetsSource/models/props/crate.blend';

export const assetTools = {
  // ---------------------------------------------------------------- reads
  asset_list: serverTool('asset_list', {
    description: 'The project\'s asset files, as the Assets panel lists them: a folder\'s files -- each its path, role (source, export, loose, record, part …), kind, key (what code and files name it by), uid, export status (current, stale, missing, failed …) and whether it is in the build -- and its folders; `recursive` for everything under it; paged (`limit`, `cursor`). Left with no folder: the top folders (src/assets, AssetsSource, packs). `trash: true`: the trash\'s slots and what each holds (asset_restore takes a slot). Only reads.',
    input: (z) => ({
      folder: z.string().min(1).max(500).optional().describe('A folder: src/assets/models/props, AssetsSource/models; left out, the top folders'),
      recursive: z.boolean().optional().describe('Everything under the folder, not just in it'),
      kind: z.string().min(1).max(40).optional().describe('Only files of this kind: models, textures, prefabs, materials, scenes …'),
      trash: z.boolean().optional().describe('The trash\'s slots instead'),
      limit: z.number().int().min(1).max(500).optional().describe('How many, at most (100)'),
      cursor: z.string().max(20).optional().describe('Where the last page left off: its `next`'),
    }),
    output: (z) => z.object({ folder: z.string().nullable(), folders: z.array(z.string()), files: z.array(z.object({ path: z.string() }).loose()), total: z.number(), next: z.string().nullable() }).loose(),
    summary: (args) => (args.trash === true ? 'list the trash' : typeof args.folder === 'string' ? `list ${args.folder}` : 'list the asset folders'),
    async run(ctx, args) {
      const out = await assetList(assetsOf(ctx), args);
      const words = out.trash
        ? out.trash.length === 0 ? 'The trash is empty.' : `${plural(out.trash.length, 'slot')} in the trash, newest last: asset_restore takes a slot (and paths).`
        : out.folder === null ? `The top folders: ${out.folders.join(', ')}. asset_list with a folder lists one.`
        : `${out.folder}: ${plural(out.total, 'file')}${out.files.length < out.total ? `, ${out.files.length} here${out.next ? ` (cursor ${out.next} for more)` : ''}` : ''}${out.folders.length > 0 ? `; ${plural(out.folders.length, 'folder')}` : ''}.`;
      return { words, json: out, pretty: true };
    },
    row: (args, out) => ({ ok: !out.isError, words: args.trash === true ? 'list the trash' : `list ${typeof args.folder === 'string' ? args.folder : 'the asset folders'}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  asset_info: serverTool('asset_info', {
    description: 'One asset file whole, as the Assets panel\'s inspector shows it: its role, kind, key, uid, status and why, its family (a source\'s exports and parts, an export\'s source), its record\'s export options and whether it is in the build, where game code names its key (file and line), the data files naming it (prefabs, scenes, materials -- what would refuse its delete), and what is wrong with it. Only reads.',
    input: (z) => ({ path: z.string().min(1).max(500).describe('The file: src/assets/models/props/crate.glb, AssetsSource/models/props/crate.blend') }),
    output: (z) => z.object({ path: z.string(), role: z.string(), kind: z.string().nullable(), key: z.string().nullable(), uid: z.string().nullable(), status: z.string().nullable() }).loose(),
    summary: (args) => `read ${String(args.path)}`,
    async run(ctx, args) {
      const info = await assetInfo(assetsOf(ctx), args);
      const problems = info.problems as string[];
      const uses = info.uses as unknown[];
      const referrers = info.referrers as unknown[];
      return {
        words: `${String(info.path)}: ${String(info.role)}${info.kind ? ` ${String(info.kind)}` : ''}${info.key ? `, key ${String(info.key)}` : ''}${info.status ? `, ${String(info.status)}` : ''}${info.included ? '' : ', out of the build'}. ${uses.length > 0 ? `Named in code ${plural(uses.length, 'time')}` : 'Named in no code'}; ${referrers.length > 0 ? `named by ${plural(referrers.length, 'data file')}` : 'named by no data file'}.${problems.length > 0 ? ` Problems: ${problems.join('; ')}` : ''}`,
        json: info,
        pretty: true,
      };
    },
    row: (args, out) => ({ ok: !out.isError, words: `read ${String(args.path)}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  asset_uses: serverTool('asset_uses', {
    description: 'Where game code names an asset\'s key -- each file and line under src/ (what refuses a move or rename of it: code holds keys, so it changes first). Give the key (props/crate, crates/big, reef:props/crate) or a file\'s path. Only reads.',
    input: (z) => ({ key: z.string().min(1).max(300).optional().describe('The key as code spells it'), path: z.string().min(1).max(500).optional().describe('Or a file, whose key is asked') }),
    output: (z) => z.object({ key: z.string(), uses: z.array(z.object({ file: z.string(), line: z.number(), text: z.string() })) }),
    summary: (args) => `find the uses of ${String(args.key ?? args.path)}`,
    async run(ctx, args) {
      const out = await assetUses(assetsOf(ctx), args);
      return { words: out.uses.length === 0 ? `No code names ${out.key}.` : `${out.key} is named ${plural(out.uses.length, 'time')}: ${some(out.uses.map((u) => `${u.file}:${u.line}`))}.`, json: out };
    },
    row: (args, out) => ({ ok: !out.isError, words: `find the uses of ${String(args.key ?? args.path)}`, detail: out.words }),
  }),

  asset_thumb: serverTool('asset_thumb', {
    description: 'A file\'s thumbnail, as an image -- what the Assets panel\'s tile shows: a texture, a model\'s render, a sound\'s waveform (made where the dev server makes it; a model\'s is made by a studio tab as its tile is drawn -- with none drawn yet, said). Size 64, 128 or 256 on its longer side.',
    input: (z) => ({ path: z.string().min(1).max(500).describe('The file'), size: z.union([z.literal(64), z.literal(128), z.literal(256)]).optional().describe('64, 128 or 256 (256)') }),
    summary: (args) => `look at ${String(args.path)}`,
    async run(ctx, args) {
      const calls = assetsOf(ctx);
      const path = cleanPath(args.path);
      const size = typeof args.size === 'number' ? args.size : 256;
      const got = await calls.thumb(path, size).catch((err: unknown) => {
        throw refusalOf(err);
      });
      if ('webp' in got) return { words: `${path}'s thumbnail, ${size} on its longer side.`, images: [{ data: Buffer.from(got.webp).toString('base64'), mimeType: 'image/webp' }] };
      if ('checking' in got) throw new ToolRefusal(`${path} is not read yet: ask again in a moment`);
      if ('make' in got) throw new ToolRefusal(`${path}'s thumbnail is made by a studio tab as its tile is drawn, and none has been yet: open its folder in the Assets panel, then ask again`);
      throw new ToolRefusal(`No thumbnail for ${path}: ${got.none}`);
    },
    row: (args, out) => ({ ok: !out.isError, words: `look at ${String(args.path)}`, detail: out.words }),
  }),

  material_get: serverTool('material_get', {
    description: 'A material file\'s fields, every one (the default where the file says nothing): type, color, roughness, metalness, emissive, maps by texture key, opacity, side, … -- and what is wrong in it. By key (props/rust: src/assets/materials/props/rust.material) or path. Only reads; material_set writes.',
    input: (z) => ({ key: z.string().min(1).max(300).optional().describe('The material\'s key'), path: z.string().min(1).max(500).optional().describe('Or its file') }),
    output: (z) => z.object({ key: z.string(), path: z.string(), fields: z.unknown(), problems: z.array(z.string()) }),
    summary: (args) => `read the material ${String(args.key ?? args.path)}`,
    async run(ctx, args) {
      const out = await materialGet(assetsOf(ctx), args);
      return { words: `${out.key} (${out.path})${out.problems.length > 0 ? `: ${out.problems.join('; ')}` : ''}.`, json: out, pretty: true };
    },
    row: (args, out) => ({ ok: !out.isError, words: `read the material ${String(args.key ?? args.path)}`, detail: out.words }),
  }),

  prefab_file: serverTool('prefab_file', {
    description: 'A prefab file as it is on disk -- its JSON (Docs/prefabs.md §2: entities, their components and numbers, its tree, its pool) -- and why it would not parse. By key (crates/big) or path. Only reads; prefab_info has the prefab as compiled, prefab_edit writes its pool and its root.',
    input: (z) => ({ key: z.string().min(1).max(300).optional().describe('The prefab\'s key'), path: z.string().min(1).max(500).optional().describe('Or its file') }),
    output: (z) => z.object({ key: z.string(), path: z.string(), file: z.unknown(), problem: z.string().nullable() }),
    summary: (args) => `read the prefab file ${String(args.key ?? args.path)}`,
    async run(ctx, args) {
      const out = await prefabFile(assetsOf(ctx), args);
      return { words: `${out.path}${out.problem ? `: ${out.problem}` : ''}.`, json: out, pretty: true };
    },
    row: (args, out) => ({ ok: !out.isError, words: `read the prefab file ${String(args.key ?? args.path)}`, detail: out.words }),
  }),

  // ---------------------------------------------------------------- writes: the panel's step in a tab, else the server's

  asset_new: pageTool('asset_new', {
    description: `Make something new, as the Assets panel's New menu does: \`folder\` (in \`in\`, named \`name\`), \`pack\` (packs/<name> and its source twin), \`prefab\` (one entity, a Transform, named from its folder), \`variant\` (of the prefab \`of\`: its root an instance of it), \`material\` (a white standard), \`physicsmaterial\` (a .physmat under src/assets/physics-materials: the defaults, friction 0.5, no bounce -- physmat_set sets its fields), \`scene\` (a world empty but for its Main Camera) or \`model\` (a Gladius script under AssetsSource/models, its export queued). \`in\` is the folder (left out, the kind's own: src/assets/prefabs, …); \`name\` its name (left out, new-material, new-scene, a free one). With the studio open it is a step in the Assets panel's history (Z there undoes it); with none, the dev server makes it (Undo this turn takes it back) -- but a prefab, a variant and a scene need the studio, whose editor writes them.`,
    input: (z) => ({
      kind: z.enum(['folder', 'pack', 'prefab', 'variant', 'material', 'physicsmaterial', 'scene', 'model']).describe('What to make'),
      in: z.string().min(1).max(500).optional().describe('The folder it goes in'),
      name: z.string().min(1).max(120).optional().describe('Its name (a folder\'s, a pack\'s, a model\'s: needed)'),
      of: z.string().min(1).max(300).optional().describe('A variant\'s base prefab key: crates/big'),
    }),
    output: (z) => z.object({ kind: z.string(), path: z.string(), key: z.string().nullable(), via: z.string() }).loose(),
    summary: (args) => `make a new ${String(args.kind)}${typeof args.name === 'string' ? ` ${args.name}` : ''}`,
    offline: (ctx, args) => newOffline(assetsOf(ctx), args),
    words: (r) => ({ words: `Made ${r.kind} ${r.path}${r.key ? ` (key ${r.key})` : ''}${r.jobs.length > 0 ? `; its export queued` : ''}.${viaWords(r)}`, json: { kind: r.kind, path: r.path, key: r.key, jobs: r.jobs, ...viaJson(r) } }),
    row: (r) => ({ ok: true, words: `make ${r.kind} ${r.path}`, detail: viaDetail(r, r.path) }),
  }),

  asset_move: pageTool('asset_move', {
    description: `Move or rename asset files and folders, as the Assets panel's drag, Move to… and rename do: \`paths\` into the folder \`to\` (each with its family: a source with its exports and record), or one path renamed to \`name\` in its folder (its extension kept when the name has none). Every data file naming what moves -- a prefab nesting it, a scene, a material's map -- follows by uid in the same move. Refused when game code names its key (asset_uses; rule 5: change the code first). ${PATHS}. With the studio open, a step in the Assets panel's history (Z there undoes it, the rewritten files with it); with none, the dev server moves them (Undo this turn).`,
    input: (z) => ({
      paths: z.union([z.string().min(1).max(500), z.array(z.string().min(1).max(500)).min(1).max(64)]).describe('What to move: a file, a folder, or a list'),
      to: z.string().min(1).max(500).optional().describe('The folder to move them into'),
      name: z.string().min(1).max(120).optional().describe('Or a new name for the one path, in its folder'),
    }),
    output: (z) => z.object({ moved: z.array(z.tuple([z.string(), z.string()])), rewritten: z.array(z.string()), via: z.string() }).loose(),
    summary: (args) => (typeof args.name === 'string' ? `rename ${String(args.paths)} to ${args.name}` : `move ${Array.isArray(args.paths) ? plural(args.paths.length, 'path') : String(args.paths)} to ${String(args.to)}`),
    offline: (ctx, args) => moveOffline(assetsOf(ctx), args),
    words: (r) => ({ words: `Moved ${plural(r.moved.length, 'file')}${r.moved.length > 0 ? `: ${some(r.moved.map(([a, b]) => `${a} → ${b}`), 4)}` : ''}${r.rewritten.length > 0 ? `; ${plural(r.rewritten.length, 'data file')} naming them rewritten` : ''}.${viaWords(r)}`, json: { moved: r.moved, rewritten: r.rewritten, ...viaJson(r) } }),
    row: (r) => ({ ok: true, words: `move ${plural(r.moved.length, 'file')}`, detail: viaDetail(r, some(r.moved.map(([a, b]) => `${a} → ${b}`), 3)) }),
  }),

  asset_copy: pageTool('asset_copy', {
    description: `Copy asset files into a folder (\`to\`), or duplicate them beside themselves (\`to\` left out: named -2), each with its family -- as the panel's Copy to… and Duplicate. A copy is a new asset: its own uid. ${PATHS}. A step in the Assets panel's history with the studio open; else the dev server's (Undo this turn).`,
    input: (z) => ({
      paths: z.union([z.string().min(1).max(500), z.array(z.string().min(1).max(500)).min(1).max(64)]).describe('What to copy'),
      to: z.string().min(1).max(500).optional().describe('The folder to copy into; left out, beside each'),
    }),
    output: (z) => z.object({ copies: z.array(z.string()), via: z.string() }).loose(),
    summary: (args) => `copy ${Array.isArray(args.paths) ? plural(args.paths.length, 'path') : String(args.paths)}${typeof args.to === 'string' ? ` to ${args.to}` : ''}`,
    offline: (ctx, args) => copyOffline(assetsOf(ctx), args),
    words: (r) => ({ words: `Copied: ${some(r.copies)}.${viaWords(r)}`, json: { copies: r.copies, ...viaJson(r) } }),
    row: (r) => ({ ok: true, words: `copy ${plural(r.copies.length, 'file')}`, detail: viaDetail(r, some(r.copies, 3)) }),
  }),

  asset_delete: pageTool('asset_delete', {
    description: `Delete asset files or folders -- to the project's trash, each with its family (a folder with everything under it and its twin), as the panel's Delete. Refused while a data file still names any of it (a prefab nesting it, a scene holding it, a material wearing it -- asset_info lists them): take it out of those first. Destructive: asks the person under Auto. ${PATHS}. With the studio open, a step in the Assets panel's history (Z there brings it back); else asset_restore with the slot answered, or Undo this turn.`,
    input: (z) => ({ paths: z.union([z.string().min(1).max(500), z.array(z.string().min(1).max(500)).min(1).max(64)]).describe('What to delete') }),
    output: (z) => z.object({ removed: z.array(z.string()), slot: z.string().nullable(), via: z.string() }).loose(),
    summary: (args) => `delete ${Array.isArray(args.paths) ? plural(args.paths.length, 'path') : String(args.paths)}`,
    offline: (ctx, args) => deleteOffline(assetsOf(ctx), args),
    words: (r) => ({ words: `To the trash${r.slot ? ` (slot ${r.slot})` : ''}: ${some(r.removed)}.${viaWords(r)}`, json: { removed: r.removed, slot: r.slot, ...viaJson(r) } }),
    row: (r) => ({ ok: true, words: `delete ${plural(r.removed.length, 'file')}`, detail: viaDetail(r, some(r.removed, 3)) }),
  }),

  asset_restore: pageTool('asset_restore', {
    description: 'Bring files back from the trash, as the panel\'s Restore: a slot\'s files (asset_list with trash: true lists them), or `paths` of it -- each where it was, or into the folder `to`. A step in the Assets panel\'s history with the studio open; else the dev server\'s (Undo this turn).',
    input: (z) => ({
      slot: z.string().min(1).max(100).describe('The trash slot'),
      paths: z.union([z.string().min(1).max(500), z.array(z.string().min(1).max(500)).min(1).max(64)]).optional().describe('Of its files, the paths they had; left out, all of them'),
      to: z.string().min(1).max(500).optional().describe('A folder to put them in instead of where they were'),
    }),
    output: (z) => z.object({ restored: z.array(z.string()), via: z.string() }).loose(),
    summary: (args) => `restore from the trash slot ${String(args.slot)}`,
    offline: (ctx, args) => restoreOffline(assetsOf(ctx), args),
    words: (r) => ({ words: `Restored: ${some(r.restored)}.${viaWords(r)}`, json: { restored: r.restored, ...viaJson(r) } }),
    row: (r) => ({ ok: true, words: `restore ${plural(r.restored.length, 'file')}`, detail: viaDetail(r, some(r.restored, 3)) }),
  }),

  asset_options: pageTool('asset_options', {
    description: 'A source\'s export options, as the panel\'s Options block sets them -- `set` (option names to values: textureMax 1024, angle 70 …; asset_info shows the record\'s) merged over what its record sets, `reset` to take every one off -- or a folder\'s defaults (its export.json), and `include` (true or false: the source in the build or out of it, as its tick). Re-exports what it changes. Or, alone, `as`: the name the source\'s export ships as -- its key\'s last part, written as its record\'s "as", as the menu\'s Rename the export… (null, or the source\'s own stem: no "as"); its exports move to the new name and what names them follows by uid, and a conflict of two sources of one stem goes. A step in the Assets panel\'s history with the studio open; else the dev server\'s (Undo this turn).',
    input: (z) => ({
      path: z.string().min(1).max(500).describe('A source under AssetsSource/, or a folder there'),
      set: z.record(z.string(), z.unknown()).optional().describe('Options by name'),
      reset: z.boolean().optional().describe('Every option taken off first: the defaults and the folders\' apply again'),
      include: z.boolean().optional().describe('In the build (true) or out of it (false)'),
      as: z.string().min(1).max(100).nullable().optional().describe('Alone: the name the export ships as, no extension (null: the source\'s own)'),
    }),
    output: (z) => z.object({ path: z.string(), jobs: z.array(z.object({ id: z.string(), source: z.string() })), via: z.string() }).loose(),
    summary: (args) => (args.as !== undefined ? `name the export of ${String(args.path)} ${args.as === null ? 'as its source' : `"${String(args.as)}"`}` : `set the export options of ${String(args.path)}`),
    offline: (ctx, args) => optionsOffline(assetsOf(ctx), args),
    words: (r) => r.exportAs
      ? { words: `${r.path}'s export ships as ${r.exportAs.as ?? 'its own name'} now${r.exportAs.moved.length > 0 ? `: ${r.exportAs.moved.map(([, to]) => to).join(', ')}` : ''}${r.jobs.length > 0 ? `; ${plural(r.jobs.length, 'export')} queued` : ''}.${viaWords(r)}`, json: { path: r.path, as: r.exportAs.as, moved: r.exportAs.moved, jobs: r.jobs, ...viaJson(r) } }
      : { words: `${r.path}'s options written${r.jobs.length > 0 ? `; ${plural(r.jobs.length, 'export')} queued` : ''}.${viaWords(r)}`, json: { path: r.path, jobs: r.jobs, ...viaJson(r) } },
    row: (r) => (r.exportAs
      ? { ok: true, words: `name the export of ${r.path} ${r.exportAs.as ?? 'as its source'}`, detail: viaDetail(r, r.exportAs.moved.length > 0 ? `moved to ${r.exportAs.moved.map(([, to]) => to).join(', ')}` : 'written') }
      : { ok: true, words: `set the options of ${r.path}`, detail: viaDetail(r, r.jobs.length > 0 ? `${plural(r.jobs.length, 'export')} queued` : 'written') }),
  }),

  material_set: pageTool('material_set', {
    description: 'Set a material\'s fields, as the inspector\'s Material block does: `set` -- type (standard, physical, basic, toon), color "#rrggbb", roughness, metalness, emissive, emissiveIntensity, map / normalMap / … (a texture key, or null), opacity, transparent, alphaTest, side (front, back, double), flatShading, wireframe, depthWrite, physical { clearcoat, … } -- written as the editor writes the file (only what differs from the defaults). material_get reads them. A field the type draws without, or a wrong value, refuses it whole. A step in the Assets panel\'s history with the studio open; else the dev server\'s (Undo this turn).',
    input: (z) => ({
      key: z.string().min(1).max(300).optional().describe('The material\'s key: props/rust'),
      path: z.string().min(1).max(500).optional().describe('Or its file'),
      set: z.record(z.string(), z.unknown()).describe('Fields by name'),
    }),
    output: (z) => z.object({ key: z.string(), path: z.string(), via: z.string() }).loose(),
    summary: (args) => `set ${Object.keys((args.set ?? {}) as object).join(', ')} of the material ${String(args.key ?? args.path)}`,
    offline: (ctx, args) => materialSetOffline(assetsOf(ctx), args),
    words: (r) => ({ words: `${r.key}: ${Object.keys(r.set).join(', ')} written.${viaWords(r)}`, json: { key: r.key, path: r.path, set: r.set, ...viaJson(r) } }),
    row: (r) => ({ ok: true, words: `set ${Object.keys(r.set).join(', ')} of ${r.key}`, detail: viaDetail(r, r.path) }),
  }),

  prefab_edit: pageTool('prefab_edit', {
    description: 'Edit a prefab file without opening it, as the Assets panel\'s Prefab block does: its `pool` ({ warm, max }, or null for none) and its root entity\'s components -- `set` fields ({ "Spin": { "speed": 2 } }, values as scene_set takes them), `add` and `remove` components by name. Written by the editor\'s own writer, checked by the compile first (a file that would not compile is refused, nothing written). One step in the Assets panel\'s history (Z there writes the text back). Needs the studio open. For more than the root, scene_open_prefab.',
    input: (z) => ({
      key: z.string().min(1).max(300).describe('The prefab\'s key: crates/big'),
      pool: z.object({ warm: z.number().int().min(0).max(100000), max: z.number().int().min(1).max(100000) }).nullable().optional().describe('Its pool, or null for none'),
      set: z.record(z.string(), z.record(z.string(), z.unknown())).optional().describe('The root\'s fields: { Component: { field: value } }'),
      add: z.array(z.string().min(1).max(100)).max(32).optional().describe('Components to put on the root'),
      remove: z.array(z.string().min(1).max(100)).max(32).optional().describe('Components to take off the root'),
    }),
    output: (z) => z.object({ key: z.string(), path: z.string(), changed: z.array(z.string()), via: z.string() }).loose(),
    summary: (args) => `edit the prefab ${String(args.key)}`,
    words: (r) => ({ words: r.changed.length === 0 ? `${r.key}: the file says that already -- nothing written.` : `${r.key}: ${r.changed.join(', ')} written to ${r.path}.${viaWords(r)}`, json: { key: r.key, path: r.path, changed: r.changed, ...viaJson(r) } }),
    row: (r) => ({ ok: true, words: `edit the prefab ${r.key}`, detail: viaDetail(r, r.changed.join(', ') || 'no change') }),
  }),

  asset_export: pageTool('asset_export', {
    description: 'Export sources now, as the panel\'s Export (E) and Export all stale: `paths` (sources, or their exports), or `under` a folder -- every stale or missing source there; `force` exports current ones too. Answers at once with the pipeline\'s jobs and a studio job following them (`job_wait` waits for it, `job_status` reads it) -- and how they ended, when they did within 20 s. The Assets panel\'s job strip shows them as the person\'s. With the studio open, the export is a step in the Assets panel\'s history once it ends (Z there puts the previous exports back); with none, the dev server\'s (Undo this turn).',
    input: (z) => ({
      paths: z.union([z.string().min(1).max(500), z.array(z.string().min(1).max(500)).min(1).max(64)]).optional().describe('Sources, or their exports'),
      under: z.string().min(1).max(500).optional().describe('Or a folder: every stale source under it'),
      force: z.boolean().optional().describe('Export current ones too'),
    }),
    output: (z) => z.object({ jobs: z.array(z.object({ id: z.string(), source: z.string() })), job: z.string().nullable(), via: z.string() }).loose(),
    summary: (args) => (typeof args.under === 'string' ? `export the stale sources under ${args.under}` : `export ${Array.isArray(args.paths) ? plural(args.paths.length, 'source') : String(args.paths)}`),
    offline: (ctx, args) => exportOffline(assetsOf(ctx), args),
    settle: (ctx, r) => followExports(ctx, r),
    words: (r) => ({
      words: r.jobs.length === 0
        ? 'Nothing needed exporting: each is current (force exports it again).'
        : r.ended
          ? `Exported: ${r.ended.map((e) => `${e.source} ${e.state}${e.error ? ` (${e.error.split('\n')[0]})` : ''}`).join('; ')}.${viaWords(r)}`
          : `${plural(r.jobs.length, 'export')} running: job ${r.job} follows them -- job_wait waits for it.${viaWords(r)}`,
      json: { jobs: r.jobs, job: r.job, ...(r.ended ? { ended: r.ended } : {}), ...viaJson(r) },
    }),
    row: (r) => ({ ok: true, words: `export ${plural(r.jobs.length, 'source')}`, detail: viaDetail(r, r.ended ? r.ended.map((e) => `${e.source} ${e.state}`).join(', ') : `job ${r.job ?? 'none'}`) }),
  }),

  // ---------------------------------------------------------------- the server's alone

  asset_import: serverTool('asset_import', {
    description: 'Import a file from this machine into the project, as a drop on the Assets panel does: `from` an absolute path (its real path inside your home folder or the project, nothing in it hidden -- no part starting with `.` -- at most 1 GB; one outside the project asks the person first) into the folder `to` -- a source under AssetsSource/ (exported by its recipe: options as the import sheet sets them, `include: false` to leave it out of the build) or a file as delivered under src/assets/ -- named `name` (left out, its own). `replace: true` puts what has that name or key to the trash first. `script: true`, for a .glb or an .fbx into a folder under AssetsSource/models/: the model imported beside a Gladius script that imports it (`<stem>.lua`, the file copied in as `<stem>.source.glb` -- parts, colours, skin and clips kept), built as its export, as the Model tab\'s and the panel\'s Import model… do (model_open then opens it in the Model tab). Run by the dev server, which reads the file (a studio tab never sees it): no panel step -- Undo this turn takes it back.',
    input: (z) => ({
      from: z.string().min(1).max(1000).describe('The file on this machine, an absolute path'),
      to: z.string().min(1).max(500).describe('The folder: AssetsSource/models/props, src/assets/textures/ui'),
      name: z.string().min(1).max(200).optional().describe('Its name there; left out, the file\'s own'),
      replace: z.boolean().optional().describe('Replace what is there by that name or key (to the trash)'),
      options: z.record(z.string(), z.unknown()).optional().describe('A source\'s export options, as the import sheet sets them'),
      include: z.boolean().optional().describe('false: a source out of the build from the start'),
      script: z.boolean().optional().describe('A .glb or .fbx imported beside a Gladius script that imports it, into AssetsSource/models/…'),
    }),
    output: (z) => z.object({ path: z.string(), jobs: z.array(z.object({ id: z.string(), source: z.string() })), slot: z.string().nullable(), copy: z.string().optional() }),
    summary: (args) => `import ${String(args.from)} into ${String(args.to)}`,
    async run(ctx, args) {
      const calls = assetsOf(ctx);
      const from = String(args.from);
      // Every check on the real path, and the real path copied: a link swapped after the check reads nothing new.
      const source = await importSource(from, calls.root);
      if (typeof source === 'string') throw new ToolRefusal(source);
      const name = typeof args.name === 'string' ? args.name : from.split(/[/\\]/).pop()!;
      const query: Record<string, string> = { dest: cleanPath(args.to, 'to'), name };
      if (args.replace === true) query.replace = 'true';
      if (args.include === false) query.include = 'false';
      if (args.options !== undefined) query.options = JSON.stringify(args.options);
      if (args.script === true) query.script = 'true';
      const answer = await calls.importFrom(source.real, query).catch((err: unknown) => {
        throw refusalOf(err);
      });
      // The replaced family too: Undo this turn puts it back as it takes the import away.
      ctx.wrote?.([answer.path, ...(answer.script?.copy !== undefined ? [answer.script.copy] : []), ...(args.options !== undefined || args.include === false ? [calls.catalog.recordOf(answer.path)] : []), ...(answer.replaced ?? [])]);
      const jobs = answer.jobs ?? [];
      if (answer.script) {
        const decoded = answer.script.decoded && answer.script.decoded.length > 0 ? ` (${answer.script.decoded.join(', ')} decoded)` : '';
        return {
          words: `Imported ${name} as ${answer.path}, a Gladius script importing ${answer.script.copy ?? 'its copy'}${decoded}${jobs.length > 0 ? '; its build queued (job_wait on asset_export\'s job, or asset_info, says how it went) -- model_open opens it in the Model tab' : ''}${answer.slot ? `; what it replaced is in the trash (slot ${answer.slot})` : ''}. No studio step -- Undo this turn takes it back.`,
          json: { path: answer.path, jobs, slot: answer.slot ?? null, ...(answer.script.copy !== undefined ? { copy: answer.script.copy } : {}) },
        };
      }
      return { words: `Imported ${answer.path}${jobs.length > 0 ? `; its export queued (asset_export's job_wait, or asset_info, says how it went)` : ''}${answer.slot ? `; what it replaced is in the trash (slot ${answer.slot})` : ''}. No studio step -- Undo this turn takes it back.`, json: { path: answer.path, jobs, slot: answer.slot ?? null } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `import ${String(args.from).split(/[/\\]/).pop()} into ${String(args.to)}`, detail: out.words }),
  }),

  asset_empty_trash: serverTool('asset_empty_trash', {
    description: 'Empty the project\'s trash, for good, as the panel\'s Empty: every slot\'s files gone -- nothing brings them back, not Z, not Undo this turn. Destructive: asks the person under Auto.',
    input: () => ({}),
    summary: () => 'empty the trash',
    async run(ctx) {
      await routed(assetsOf(ctx), 'POST empty-trash', {});
      return { words: 'The trash is empty: what was in it is gone for good.' };
    },
    row: (_args, out) => ({ ok: !out.isError, words: 'empty the trash', detail: out.words }),
  }),
};
