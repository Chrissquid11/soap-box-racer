/**
 * The studio area's tools (Docs/mcp.md §4): `studio_state` -- what is open in the studio and what is selected there,
 * with the server's facts (the problems count, the jobs). A page tool, answered with no tab too (`registry.ts`).
 * `studio_context` (Docs/terminal.md D8) -- what Claude's column tells each turn of the editor, the page's `gather(true)`
 * checked and worded by the same functions as a turn's (`checkContext`, `wordContext`): one source for the column, the
 * terminal's prompts and the tool.
 */
import { checkContext } from '../../agent/server.ts';
import { modelKeys, wordContext } from '../../agent/turn.ts';
import { pageTool } from '../tool.ts';
import { openWords, plural, whom, type ModelsOf } from '../words.ts';
import type { TurnContext } from '../../agent/api-types.ts';

/** What `studio_context` adds after the facts: the picture is a call away. */
export const SHOT_LINE = 'A picture of the view: view_shot (the scene view, a camera, the Model tab).';

/**
 * The tab's `studio_context` facts in words, once for both its readers -- the tool's answer and a terminal run's prompt
 * (`agent/terminal-context.ts`): checked as a turn's (`checkContext`), worded as a turn's head (`wordContext`), the
 * picture's line after. The checked facts with them, for the tool's JSON.
 */
export async function studioContextWords(raw: unknown, models: ModelsOf): Promise<{ words: string; context: TurnContext }> {
  const context = checkContext(raw);
  return { words: `${wordContext(context, await models(modelKeys(context)))}\n${SHOT_LINE}`, context };
}

export const studioTools = {
  studio_context: pageTool('studio_context', {
    description: 'What the editor shows now, as Claude\'s column tells each of its turns at their head: the game; a playtest, running or paused; the scene open and whether it is saved; the tab up; each tool\'s own facts -- the Code card\'s file with the caret\'s line and column and the text selected there, the Problems (their count and the first five), the Assets panel\'s folder and files chosen, the Model tab\'s model with its build and parts selected -- and the first eight entities selected, each with its prefab, labels and its models\' files. A terminal\'s prompts carry it already (its hook); call it to read it again mid-turn. view_shot is the picture; studio_state the selection whole.',
    input: () => ({}),
    output: (z) => z.object({ words: z.string(), context: z.record(z.string(), z.unknown()) }),
    summary: () => 'read what the editor shows',
    async words(result, models) {
      const { words, context } = await studioContextWords(result.context, models);
      return { words, json: { words, context } };
    },
    row: (result) => ({ ok: true, words: 'read what the editor shows', detail: result.context.tool === null ? null : `tool up: ${result.context.tool}` }),
  }),
  studio_state: pageTool('studio_state', {
    description: 'What is open in the studio (the editor, in the person\'s browser) and what is selected there: the tab shown (Scene, Config, Model, Studio …), the scene (its name, saved or not), the prefab open to edit, the playtest (none, running, paused), the Problems card\'s count and the jobs running -- and per selected entity its id, name, prefab (and which entity of it, inside an instance; `instance` true for an instance\'s root), what it changes from its prefab (`overrides`: each by its handle `what` (a rotation is one, Transform.rotation, its values the angles in degrees that differ), `at` the entity of the prefab, the prefab\'s value and its own, `to` the prefabs Apply could write it to, innermost first; on an instance\'s root every override of the whole instance, each `what` as `<at>: <handle>` -- rider: Transform.px -- the entities removed and added among them: exactly what scene_override on the root acts on when given no `what`), labels, parent, layer, models with their export and source files, tags, components switched off, every numeric component\'s fields and values (Transform: px py pz position in metres, qx qy qz qw rotation as a quaternion, sx sy sz scale), object components summarised, and its links. Read it before changing an instance with scene_set or scene_override. With no studio tab open it says so, and the URL to ask the person to open.',
    input: () => ({}),
    output: (z, s) =>
      z.union([
        z.object({ open: z.literal(true), tab: z.string().nullable(), scene: s.scene, prefab: z.string().nullable(), playtest: z.enum(['none', 'running', 'paused']), problems: z.number().nullable(), jobs: z.array(s.job), selected: z.number(), entities: z.array(z.record(z.string(), z.unknown())) }),
        z.object({ open: z.literal(false), url: z.string(), problems: z.number().nullable(), jobs: z.array(s.job) }),
      ]),
    summary: () => 'read the studio',
    async words(result, models, server) {
      const files = await models([...new Set(result.entities.flatMap((e) => e.models))]);
      const entities = result.entities.map((e) => ({
        ...e,
        models: e.models.map((key) => ({ key, export: files.get(key)?.export ?? null, source: files.get(key)?.source ?? null })),
      }));
      const head = result.selected === 0
        ? 'Nothing is selected in the editor.'
        : `${plural(result.selected, 'entity', 'entities')} selected${result.selected > entities.length ? `: the first ${entities.length} here` : ''}. scene_set changes a numeric field of one instance; the person undoes it with Z.`;
      return {
        words: `${openWords(result, server)}\n${head}`,
        json: { open: true, tab: result.tab, scene: result.scene, prefab: result.prefab, playtest: result.playtest, problems: server.problems, jobs: server.jobs, selected: result.selected, entities },
        pretty: true,
      };
    },
    row(result) {
      const shown = result.entities.map((e) => {
        const made = e.prefab === null ? 'entity' : e.node === null ? e.prefab : `${e.prefab} · ${e.node}`;
        return `#${e.id} ${e.name ?? made}${e.name ? ` (${made})` : ''}`;
      });
      const words = `read the studio: ${result.selected === 0 ? 'nothing selected' : result.selected === 1 ? whom(result.entities) : plural(result.selected, 'entity', 'entities')}`;
      return { ok: true, words, detail: shown.length > 0 ? shown.join(', ') + (result.selected > shown.length ? `, and ${result.selected - shown.length} more` : '') : null };
    },
  }),
};
