/**
 * The export tools' tools (Config ▸ Assets ▸ Tools, Docs/assets-tool.md §7): what an export needs on this machine --
 * Gladius, ffmpeg, Git LFS and the rest. Server tools, each the route's own work in-process:
 *
 * - **`tools_check`** -- Check again (`POST tools/check`): every tool looked for again, what can now be made queued;
 *   answered with each tool's state. Also what reads them.
 * - **`tools_set`** -- a tool's Set its path (`PUT tools`): the path the project's local file keeps (`''` forgets it,
 *   the PATH looked at again). A path asks the person at every level: the dev server will run that program.
 * - **`tools_download`** -- Download ffmpeg (`POST download`, `StudioCalls.download`): a static build for this machine,
 *   its checksum checked, its path set; a job, followed to its end. Asks the person at every level: a program from
 *   the internet.
 *
 * Nothing at module level but the records.
 */
import type { ToolLook } from '../../assets/api-types.ts';
import { assetsOf, refusalOf, routed } from '../assets.ts';
import type { StudioContext } from '../tool.ts';
import { studioOf, TASK_WAIT_MS } from '../studio-work.ts';
import { serverTool, ToolRefusal } from '../tool.ts';
import { plural } from '../words.ts';

/** A tool's state in a line: `ffmpeg: found 7.1 (/opt/homebrew/bin/ffmpeg)`, `gladius: missing -- did not answer`. */
const toolLine = (t: ToolLook): string => `${t.tool}: ${t.state}${t.version ? ` ${t.version}` : ''}${t.path ? ` (${t.path})` : ''}${t.why ? ` -- ${t.why}` : ''}${t.state !== 'found' && t.hint ? ` -- ${t.hint}` : ''}`;

/** How often a download's state is read while it runs. */
const DOWNLOAD_READ_MS = 250;

/** A download followed as a job to its end: its state read until done or failed, then the tools looked for again. */
function followDownload(ctx: StudioContext, tool: string): string {
  const calls = studioOf(ctx);
  const job = ctx.jobs.start('download', tool);
  const timer = setInterval(() => {
    const s = calls.download.state(tool);
    if (ctx.jobs.get(job.id)?.state !== 'running') return void clearInterval(timer);
    if (s.state === 'downloading' || s.state === 'unpacking') return job.progress(s.received, s.total, s.state);
    clearInterval(timer);
    if (s.state === 'done') {
      // As the page does once one lands: every tool looked for again, so the path set is read and what it makes queued.
      const assets = ctx.assets?.();
      void (assets ? routed(assets, 'POST tools/check', {}).then((a) => a.jobs.length, () => 0) : Promise.resolve(0)).then((queued) => job.finish({ path: s.path ?? null, queued }));
    } else job.fail(s.why ?? `${tool} was not downloaded`);
  }, DOWNLOAD_READ_MS);
  timer.unref?.();
  return job.id;
}

export const toolsTools = {
  tools_check: serverTool('tools_check', {
    description: 'The tools the exports need on this machine -- Gladius, ffmpeg, Git LFS, Blender … -- looked for again, as Config ▸ Assets ▸ Tools\' Check again: each tool\'s state (found, missing, lacking), version, path and what to do about it; what can now be made is queued to export. Use it after a tool was installed, and to read where they stand.',
    input: () => ({}),
    output: (z) => z.object({ tools: z.array(z.object({ tool: z.string(), state: z.string() }).loose()), queued: z.number() }),
    summary: () => 'look for the export tools again',
    async run(ctx) {
      const answer = await routed(assetsOf(ctx), 'POST tools/check', {});
      const tools = answer.tools ?? [];
      return { words: `${tools.map(toolLine).join('\n')}${answer.jobs.length > 0 ? `\n${plural(answer.jobs.length, 'export')} queued now that it can be made.` : ''}`, json: { tools, queued: answer.jobs.length }, pretty: true };
    },
    row: (_args, out) => ({ ok: !out.isError, words: 'look for the export tools again', detail: out.words.split('\n')[0] ?? null }),
  }),

  tools_set: serverTool('tools_set', {
    description: 'Set where an export tool is, as its Set its path field in Config ▸ Assets ▸ Tools: `tool` (gladius, ffmpeg, blender …; tools_check names them) and `path`, the program on this machine -- kept in the project\'s local file, never committed -- or \'\' to forget it and look on the PATH again. It is looked at again, and what it can now make is queued. A path asks the person, at every level: the dev server will run that program.',
    input: (z) => ({
      tool: z.string().min(1).max(40).describe('The tool: gladius, ffmpeg …'),
      path: z.string().max(1000).describe('The program\'s path on this machine, or \'\' to forget it'),
    }),
    output: (z) => z.object({ tool: z.object({ tool: z.string(), state: z.string() }).loose().nullable(), queued: z.number() }),
    summary: (args) => (args.path === '' ? `forget the path of ${String(args.tool)}` : `set ${String(args.tool)} to ${String(args.path)}`),
    async run(ctx, args) {
      const tool = String(args.tool);
      const answer = await routed(assetsOf(ctx), 'PUT tools', { name: tool }, { path: String(args.path) });
      const now = (answer.tools ?? []).find((t) => t.tool === tool) ?? null;
      return { words: `${now ? toolLine(now) : `${tool}: set`}${answer.jobs.length > 0 ? `; ${plural(answer.jobs.length, 'export')} queued now that it can be made` : ''}.`, json: { tool: now, queued: answer.jobs.length } };
    },
    row: (args, out) => ({ ok: !out.isError, words: args.path === '' ? `forget the path of ${String(args.tool)}` : `set the path of ${String(args.tool)}`, detail: out.words }),
  }),

  tools_download: serverTool('tools_download', {
    description: 'Download a tool the exports need, as Config ▸ Assets ▸ Tools\' Download: `tool` ffmpeg -- a static build for this machine, its checksum checked, unpacked into the app\'s data folder and its path set, then every tool looked for again. A job: answered when it ends within 20 s, else with its id for job_wait. Asks the person, at every level: a program from the internet.',
    input: (z) => ({ tool: z.enum(['ffmpeg']).describe('What to download: ffmpeg') }),
    output: (z) => z.object({ job: z.string(), state: z.string() }).loose(),
    summary: (args) => `download ${String(args.tool)}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const tool = String(args.tool);
      if (!calls.download.tools.includes(tool)) throw new ToolRefusal(`${tool} is not downloaded by the studio: ${calls.download.tools.join(', ')}`);
      try {
        calls.download.start(tool);
      } catch (err) {
        throw refusalOf(err);
      }
      const id = followDownload(ctx, tool);
      const ended = await ctx.jobs.wait(id, TASK_WAIT_MS);
      if (!ended || ended.state === 'running') return { words: `Downloading ${tool}: job ${id} -- job_wait waits for it; the Tools page shows it.`, json: { job: id, state: 'running' } };
      if (ended.state === 'failed') return { words: `${tool} was not downloaded: ${ended.error ?? 'it failed'}`, json: { job: id, state: 'failed', error: ended.error }, isError: true };
      const r = ended.result as { path: string | null; queued: number };
      return { words: `Downloaded ${tool}${r.path ? ` to ${r.path}` : ''}, its path set${r.queued > 0 ? `; ${plural(r.queued, 'export')} queued now that it can be made` : ''}.`, json: { job: id, state: 'done', path: r.path, queued: r.queued } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `download ${String(args.tool)}`, detail: out.words }),
  }),
};
