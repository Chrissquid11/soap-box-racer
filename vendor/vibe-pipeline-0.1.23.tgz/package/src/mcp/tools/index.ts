/**
 * Every studio tool, by name (Docs/mcp.md §3): the areas' modules joined into one record the compiler holds whole
 * against the catalogue (`ToolDefs`: a name of `catalog.ts` with no record, or a record with no name, does not
 * build) -- and what reads them by name: a page tool's answer worded for the agent (`pageOutput`) and for the
 * transcript (`rowWords`), any tool's call in a few words (`summaryOf`, the transcript's line while it runs).
 *
 * Nothing at module level but the records: `zod` is made only as the server is (`../registry.ts`).
 */
import type { EditorResult, PageToolName } from '../../agent/api-types.ts';
import type { ToolName } from '../catalog.ts';
import type { ToolOutput } from '../result.ts';
import type { PageTool, ToolDefs } from '../tool.ts';
import { awayOf, droppedWords, type Away, type ModelsOf, type PageAnswer, type RowWords, type ServerFacts } from '../words.ts';
import { assetTools } from './assets.ts';
import { claudeTools } from './claude.ts';
import { codeTools } from './code.ts';
import { entityTools } from './entities.ts';
import { gitTools } from './git.ts';
import { jobTools } from './job.ts';
import { modelTools } from './model.ts';
import { physicsTools } from './physics.ts';
import { playTools } from './play.ts';
import { prefabTools } from './prefab.ts';
import { sceneTools } from './scene.ts';
import { sceneFileTools } from './scenes.ts';
import { studioTools } from './studio.ts';
import { toolsTools } from './tools.ts';

/** Every tool's record, by its name. */
export const DEFS: ToolDefs = { ...studioTools, ...sceneTools, ...entityTools, ...sceneFileTools, ...prefabTools, ...assetTools, ...playTools, ...physicsTools, ...codeTools, ...gitTools, ...modelTools, ...toolsTools, ...jobTools, ...claudeTools };

/** True only while the page's results (`EditorResult`) are one per page tool, no more and no fewer: else it does not build. */
type Same<A, B> = [A] extends [B] ? ([B] extends [A] ? true : false) : false;
export const RESULTS_ARE_THE_PAGE_TOOLS: Same<EditorResult['tool'], PageToolName> = true;

/** A page tool's record, its result's type let go: what reads one by a name known only as it runs. */
const pageDef = (name: PageToolName): PageTool<PageToolName> => DEFS[name] as unknown as PageTool<PageToolName>;

/** A tool's call in a few words, from its input: the name of no tool, itself. */
export function summaryOf(name: string, args: Record<string, unknown>): string {
  return Object.hasOwn(DEFS, name) ? DEFS[name as ToolName].summary(args) : name;
}

/**
 * A page tool's answer as the agent reads it: the page's facts worded by the tool, then its JSON; model keys resolved
 * to their files; `studio_state` with the server's facts; a step the person had undone, dropped from redo, said.
 */
export async function pageOutput(result: EditorResult, models: ModelsOf, server: ServerFacts): Promise<ToolOutput> {
  const out = await pageDef(result.tool).words(result as never, models, server);
  return { ...out, words: `${out.words}${droppedWords(result)}` };
}

/**
 * The transcript row's words once the page has answered (the `editor` entry): what was done, by name -- "set
 * Transform.px = 3 on big crate" -- and in full for the hover; or, not done, the call's words and why not. Whether `Z`
 * undoes the step is the page's to say: a reload, or another tab, and it does not.
 */
export function rowWords(name: PageToolName, args: Record<string, unknown>, answer: PageAnswer, why: (away: Away | 'lost') => string): RowWords {
  if (!('result' in answer)) return { ok: false, words: pageDef(name).summary(args), detail: 'error' in answer ? answer.error : why(awayOf(answer)) };
  return pageDef(answer.result.tool).row(answer.result as never, args);
}
