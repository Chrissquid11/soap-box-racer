/**
 * The scene area's entity tools (Docs/mcp.md §4, M2), run in the studio tab (`packages/editor/src/mcp/entities.ts`):
 * the reads -- `scene_query`, `scene_entity` -- and the writes, each what the tree's menu, the inspector or the state
 * line does, ONE step on the editor's undo stack labelled `Claude: …`; and `batch`, several of them as one.
 *
 * Entities are named by ref or path everywhere (`Shapes.entity`); answers carry both (`EntityRow`).
 */
import { BATCHED_TOOLS, type EditorResult, type EntityRow } from '../../agent/api-types.ts';
import { oneWhom, onWhom, pageTool } from '../tool.ts';
import { plural } from '../words.ts';

/** An entity as words name it: its path, and its ref. */
const named = (row: EntityRow): string => `${row.path} (ref ${row.ref})`;
/** Several, in a few words. */
const namedAll = (rows: readonly EntityRow[]): string => (rows.length === 1 ? named(rows[0]!) : rows.length <= 4 ? rows.map(named).join(', ') : `${rows.length} entities`);
/** The step said, for the words: undone with Z. */
const stepSaid = (step: string | null): string => (step === null ? 'Nothing changed, so there is no step to undo.' : `One step on the editor's undo stack, "${step}", which the person undoes with Z; the scene is not saved by it (scene_save).`);
/** A row's detail: the step. */
const stepDetail = (step: string | null): string => (step === null ? 'no change' : `one step, "${step}"`);

/** One line per result of a batch: what each call did. */
function batchLine(r: EditorResult): string {
  switch (r.tool) {
    case 'scene_create':
      return `made ${r.kind === 'prefab' ? r.prefab : r.kind} ${r.path} (ref ${r.ref})`;
    case 'scene_destroy':
      return `destroyed ${namedAll(r.destroyed)}`;
    case 'scene_duplicate':
      return `duplicated ${r.of.path} as ${named(r.copy)}`;
    case 'scene_reparent':
      return `moved ${namedAll(r.moved)} under ${r.parent ? r.parent.path : 'the roots'}`;
    case 'scene_rename':
      return `renamed ${r.renamed.map((x) => `${x.was ?? 'unnamed'} → ${x.name ?? 'unnamed'}`).join(', ')}`;
    case 'scene_component':
      return `${r.verb} ${r.component} on ${r.done.length}`;
    case 'scene_set':
      return `set ${r.object ? r.component : `${r.component}.${r.field}`} on ${r.written.length}`;
    case 'scene_flags':
      return r.changed.join(', ') || 'flags unchanged';
    case 'scene_relate':
      return `linked ${r.from.path} → ${r.to.path} (${r.relation})`;
    case 'scene_unrelate':
      return `cut ${r.from.path} → ${r.to.path} (${r.relation})`;
    case 'scene_main_camera':
      return `${r.camera.path} the main camera`;
    case 'scene_list_insert':
    case 'scene_list_remove':
    case 'scene_list_move':
      return `${r.tool === 'scene_list_insert' ? 'added to' : r.tool === 'scene_list_remove' ? 'removed from' : 'moved in'} ${r.component}.${r.path} on ${r.written.length}`;
    default:
      return r.tool;
  }
}

/** A batch's result, without the steps of each (there are none but the batch's): what each call answers. */
function batchJson(r: EditorResult): unknown {
  switch (r.tool) {
    case 'scene_create':
      return { tool: r.tool, kind: r.kind, ref: r.ref, path: r.path, name: r.name };
    case 'scene_duplicate':
      return { tool: r.tool, ref: r.copy.ref, path: r.copy.path, of: r.of.ref };
    default: {
      const { step: _step, ...rest } = r as EditorResult & { step?: unknown };
      return rest;
    }
  }
}

export const entityTools = {
  scene_query: pageTool('scene_query', {
    description: 'Find entities in the scene open (or the prefab open to edit): by `name` (a part of it, any case; `exact` for the whole name), `path` (names joined by /, from a root: big crate/rider -- ending in / for everything under it), `component`, `prefab` (made by it), `label`, `tag`, `layer` (number or name), `parent` (its children; null, the roots) -- every one given must hold. In the tree\'s order, a page at a time (`limit`, 50 by default; `cursor` from the answer\'s `next`). Each: its ref (what every scene tool takes -- it holds the entity\'s generation, so a ref to one destroyed since names nothing), id, path, name, prefab and node, and the components it has. Only reads.',
    input: (z, s) => ({
      name: z.string().min(1).max(200).optional().describe('A part of its name, any case'),
      exact: z.boolean().optional().describe('name is the whole name, case and all'),
      path: z.string().min(1).max(1000).optional().describe('Its path: big crate/rider; ending in /, everything under it'),
      component: z.string().min(1).max(100).optional().describe('A component it has'),
      prefab: z.string().min(1).max(200).optional().describe('The prefab that made it: crates/big'),
      label: z.string().min(1).max(200).optional().describe('A label it has'),
      tag: z.string().min(1).max(100).optional().describe('A tag it has'),
      layer: z.union([z.number().int().min(0).max(31), z.string().min(1).max(100)]).optional().describe('Its layer, by number or name'),
      parent: s.entity.nullable().optional().describe('Its parent (a ref or path); null, the roots'),
      limit: z.number().int().min(1).max(200).optional().describe('How many to answer; left out, 50'),
      cursor: z.string().max(20).optional().describe('The `next` of an answer: the page after it'),
    }),
    output: (z) => z.object({ total: z.number(), next: z.string().nullable(), entities: z.array(z.object({ ref: z.number(), id: z.number(), path: z.string(), name: z.string().nullable(), prefab: z.string().nullable(), node: z.string().nullable(), components: z.array(z.string()) })) }),
    summary: (args) => {
      const by = Object.entries(args).filter(([k]) => k !== 'limit' && k !== 'cursor' && k !== 'exact').map(([k, v]) => `${k} ${typeof v === 'string' ? v : JSON.stringify(v)}`);
      return `find entities${by.length > 0 ? ` by ${by.join(', ')}` : ''}`;
    },
    words: (result) => ({
      words: result.total === 0 ? 'No entity matches.' : `${plural(result.total, 'entity matches', 'entities match')}${result.next !== null ? `: these ${result.entities.length}, then scene_query again with cursor "${result.next}"` : ''}. Name one by its ref (or path) in any scene tool.`,
      json: { total: result.total, next: result.next, entities: result.entities },
      pretty: true,
    }),
    row: (result, args) => ({ ok: true, words: `find entities: ${result.total} found`, detail: Object.keys(args).length > 0 ? JSON.stringify(args) : null }),
  }),

  scene_entity: pageTool('scene_entity', {
    description: 'One entity whole: its ref, path, name, prefab and node (and its overrides, inside an instance), parent, children (refs and paths), layer, labels, tags, components switched off, every numeric component\'s fields and values (a ref() field as the entity it points at, an enum by its name, flags by their names, a vector by its numbers under its one name, a key field as { key, uid } where its asset has a uid, a mesh as { key, part, uid }) and each field\'s schema (`schema`: its kind -- `mesh` for a model and one of its parts --, an enum\'s or flags\' names, a vector\'s size, a key\'s kind (`keyKind`: Model, Sfx, Prefab … what the field holds), a typed ref\'s `needs` (the components an entity must have to be held), min, max, step, read only -- what scene_set takes there), object components summarised -- and, where one has a save shape, as it saves (`saved`: what scene_set takes back) -- and every link, out and in, with its data. Only reads.',
    input: (_z, s) => ({ entity: s.entity }),
    output: (z) => z.record(z.string(), z.unknown()),
    summary: (args) => `read ${oneWhom(args.entity)}`,
    words: (result) => ({ words: `${named(result.entity)}${result.entity.prefab ? `, of ${result.entity.prefab}` : ''}: ${plural(result.entity.children.length, 'child', 'children')}.`, json: result.entity, pretty: true }),
    row: (result) => ({ ok: true, words: `read ${result.entity.path}`, detail: `ref ${result.entity.ref}` }),
  }),

  scene_destroy: pageTool('scene_destroy', {
    description: 'Destroy entities and everything under them, as the tree\'s Destroy -- one step on the editor\'s undo stack, which the person undoes with Z (everything back as it was, under the same refs). Never the root of a prefab open to edit (scene_close_prefab).',
    input: (_z, s) => ({ entities: s.entities }),
    output: (z, s) => z.object({ destroyed: z.array(s.row), count: z.number() }),
    summary: (args) => `destroy ${onWhom(args.entities)}`,
    words: (result) => ({ words: `Destroyed ${namedAll(result.destroyed)} -- ${plural(result.count, 'entity', 'entities')} in all, with what was under them. ${stepSaid(result.step)}`, json: { destroyed: result.destroyed, count: result.count } }),
    row: (result) => ({ ok: true, words: `destroy ${result.destroyed.length === 1 ? result.destroyed[0]!.path : `${result.destroyed.length} entities`}`, detail: `${result.count} in all · ${stepDetail(result.step)}` }),
  }),

  scene_duplicate: pageTool('scene_duplicate', {
    description: 'A copy of an entity where it is, as the tree\'s Duplicate: an instance\'s root copied whole, an instance again; any other entity its components, tags, links out, layer and switches, under the same parent -- not its children. One step on the editor\'s undo stack, which the person undoes with Z. Answers the copy\'s ref and path.',
    input: (_z, s) => ({ entity: s.entity }),
    output: (z, s) => z.object({ copy: s.row, of: s.row }),
    summary: (args) => `duplicate ${oneWhom(args.entity)}`,
    words: (result) => ({ words: `Duplicated ${result.of.path} as ${named(result.copy)}. ${stepSaid(result.step)}`, json: { copy: result.copy, of: result.of } }),
    row: (result) => ({ ok: true, words: `duplicate ${result.of.path}`, detail: `${result.copy.path} (ref ${result.copy.ref}) · ${stepDetail(result.step)}` }),
  }),

  scene_copy: pageTool('scene_copy', {
    description: 'Copy entities as the tree\'s Copy (Mod+C) copies them -- each with everything under it, one under another going with it. The clip is kept in the studio tab for you (the person\'s clipboard is left alone): its `handle` is what scene_paste takes, in this scene or another (scene_open between); the last 8 are kept, until the page reloads. A small clip\'s JSON comes too (`clip`, the text the editor puts on the clipboard), to show or hand on. Only reads: nothing is changed.',
    input: (_z, s) => ({ entities: s.entities }),
    output: (z, s) => z.object({ roots: z.array(s.row), count: z.number(), handle: z.string(), size: z.number(), clip: z.string().optional() }),
    summary: (args) => `copy ${onWhom(args.entities)}`,
    words: (result) => ({ words: `Copied ${namedAll(result.roots)}: ${result.count} ${result.count === 1 ? 'entity' : 'entities'} in all, kept as ${result.handle} -- give scene_paste handle: '${result.handle}'.${result.clip === undefined ? ` Its JSON (${result.size} characters) is too long to answer: the handle is the clip.` : ''}`, json: { roots: result.roots, count: result.count, handle: result.handle, size: result.size, ...(result.clip !== undefined ? { clip: result.clip } : {}) } }),
    row: (result) => ({ ok: true, words: `copy ${namedAll(result.roots)}`, detail: `${result.count} ${result.count === 1 ? 'entity' : 'entities'} as ${result.handle}, ${result.size} characters` }),
  }),

  scene_paste: pageTool('scene_paste', {
    description: 'Make a clip\'s entities in the world, as the tree\'s Paste (Mod+V): `handle` the one scene_copy answered -- or `clip`, entities the person copied in the editor and gave you as text (its JSON) -- each a new entity with a free name, an instance\'s root a whole instance again, links and refs among them kept (a ref out of the clip kept only in the world it was copied from). `at` { x, z } puts the clip\'s middle there across the ground; left out, they keep the places they were copied at. With a prefab open, they go under its root, as the tree\'s Paste puts them. What this build lacks (a prefab gone, a component) is left out and said. One step on the editor\'s undo stack, which the person undoes with Z.',
    input: (z) => ({
      handle: z.string().min(1).max(100).optional().describe('The clip scene_copy kept: its handle (clip-3)'),
      clip: z.string().min(1).max(4_000_000).optional().describe('Or a clip\'s JSON, as the clipboard holds it: what the person copied and handed over'),
      at: z.object({ x: z.number(), z: z.number() }).optional().describe('Where the middle goes, across the ground; left out, where they were'),
    }),
    output: (z, s) => z.object({ roots: z.array(s.row), count: z.number(), skipped: z.array(z.string()) }),
    summary: () => 'paste entities',
    words: (result) => ({ words: `Pasted ${namedAll(result.roots)}: ${result.count} ${result.count === 1 ? 'entity' : 'entities'} in all${result.skipped.length > 0 ? `; left out, as this build lacks them: ${result.skipped.join(', ')}` : ''}. ${stepSaid(result.step)}`, json: { roots: result.roots, count: result.count, skipped: result.skipped } }),
    row: (result) => ({ ok: true, words: `paste ${namedAll(result.roots)}`, detail: `${result.count} ${result.count === 1 ? 'entity' : 'entities'} · ${stepDetail(result.step)}` }),
  }),

  scene_reparent: pageTool('scene_reparent', {
    description: 'Move entities in the tree, as a drag there: under `parent` (a ref or path; null or left out, the roots -- with a prefab open, under its root), in front of `before` (one of that parent\'s children; left out, last), together in the tree\'s order; each stays where it is in the world (its Transform worked out again in the new parent\'s space, as a drag in the tree does; under a parent scaled unevenly with the entity turned against it, the nearest a Transform can hold), or with `keepWorld: false` keeps its own Transform numbers, now relative to the new parent, so it may jump. One step on the editor\'s undo stack -- Reparent, Unparent or Reorder -- which the person undoes with Z.',
    input: (z, s) => ({ entities: s.entities, parent: s.entity.nullable().optional().describe('The new parent, a ref or path; null, the roots'), before: s.entity.optional().describe('One of the parent\'s children to go in front of; left out, last'), keepWorld: z.boolean().optional().describe('true (the default): each stays where it is in the world; false: its Transform numbers kept, relative to the new parent') }),
    output: (z, s) => z.object({ moved: z.array(s.row), parent: s.row.nullable(), before: s.row.nullable() }),
    summary: (args) => `move ${onWhom(args.entities)} under ${args.parent === undefined || args.parent === null ? 'the roots' : oneWhom(args.parent)}`,
    words: (result) => ({ words: `Moved ${namedAll(result.moved)} under ${result.parent ? named(result.parent) : 'the roots'}${result.before ? `, in front of ${result.before.path}` : ''}; their paths are new. ${stepSaid(result.step)}`, json: { moved: result.moved, parent: result.parent, before: result.before } }),
    row: (result) => ({ ok: true, words: `move ${result.moved.length === 1 ? result.moved[0]!.path : `${result.moved.length} entities`} under ${result.parent ? result.parent.path : 'the roots'}`, detail: stepDetail(result.step) }),
  }),

  scene_rename: pageTool('scene_rename', {
    description: 'Name entities, as the inspector\'s title: one gets `name`; several are numbered in the order named (wall, wall 2, wall 3); "" takes the name off. One step on the editor\'s undo stack, which the person undoes with Z. A path names an entity by its name: after a rename, use the new path, or the ref.',
    input: (z, s) => ({ entities: s.entities, name: z.string().max(200).describe('The name; "" for none') }),
    output: (z, s) => z.object({ renamed: z.array(s.row.and(z.object({ was: z.string().nullable() }))) }),
    summary: (args) => `name ${onWhom(args.entities)} "${String(args.name)}"`,
    words: (result) => ({ words: `${result.renamed.map((r) => `${r.was ?? 'unnamed'} → ${r.name ?? 'unnamed'}`).join('; ')}. ${stepSaid(result.step)}`, json: { renamed: result.renamed } }),
    row: (result) => ({ ok: true, words: `rename ${result.renamed.length === 1 ? `${result.renamed[0]!.was ?? 'an entity'} to ${result.renamed[0]!.name ?? 'none'}` : `${result.renamed.length} entities`}`, detail: stepDetail(result.step) }),
  }),

  scene_component: pageTool('scene_component', {
    description: 'Add, remove, switch on (enable) or off (disable) a component on entities, as the inspector\'s Add Component button, its × and its box: an added one at its defaults (scene_set then fills it in). Add Component groups what may be added by each component\'s `menu` (Physics/Colliders, Rendering; a game\'s own with none under Game), the categories scene_describe prints after each component -- name the component here directly; one switched off keeps its data, and the systems that need it leave the entity. Refused as the inspector refuses: a tag (scene_flags), a relation (scene_relate), the switches and labels (scene_flags), the world\'s own (View, Hierarchy, WorldTransform); switching only what has a box. One step on the editor\'s undo stack, which the person undoes with Z.',
    input: (z, s) => ({ entities: s.entities, component: z.string().min(1).max(100).describe('The component: as scene_describe names it'), verb: z.enum(['add', 'remove', 'enable', 'disable']) }),
    output: (z, s) => z.object({ verb: z.string(), component: z.string(), done: z.array(s.row) }),
    summary: (args) => `${String(args.verb)} ${String(args.component)} on ${onWhom(args.entities)}`,
    words: (result) => ({ words: `${result.verb === 'add' ? 'Added' : result.verb === 'remove' ? 'Removed' : result.verb === 'enable' ? 'Switched on' : 'Switched off'} ${result.component} on ${result.done.length === 0 ? 'none -- every one had it so already' : namedAll(result.done)}. ${stepSaid(result.step)}`, json: { verb: result.verb, component: result.component, done: result.done } }),
    row: (result) => ({ ok: true, words: `${result.verb} ${result.component} on ${result.done.length === 1 ? result.done[0]!.path : `${result.done.length} entities`}`, detail: stepDetail(result.step) }),
  }),

  scene_flags: pageTool('scene_flags', {
    description: 'The state line of entities, as the inspector and the tree set it: `hidden` (not drawn, still running), `disabled` (in no system, not drawn), `unpickable` (not picked in the scene) -- each set true or false, for the entity and so for everything under it -- the `layer` (0 to 31, or a layer\'s name), tags (`tags`: { add, remove }, names of the game\'s tags) and labels (`labels`: { add, remove }). One step on the editor\'s undo stack for all of it, which the person undoes with Z.',
    input: (z, s) => {
      const lists = z.object({ add: z.array(z.string().min(1).max(200)).max(64).optional(), remove: z.array(z.string().min(1).max(200)).max(64).optional() });
      return {
        entities: s.entities,
        hidden: z.boolean().optional(),
        disabled: z.boolean().optional(),
        unpickable: z.boolean().optional(),
        layer: z.union([z.number().int().min(0).max(31), z.string().min(1).max(100)]).optional().describe('A layer by number or name'),
        tags: lists.optional().describe('Tags to put on and take off'),
        labels: lists.optional().describe('Labels to add and take off'),
      };
    },
    output: (z, s) => z.object({ entities: z.array(s.row), changed: z.array(z.string()) }),
    summary: (args) => `set the flags of ${onWhom(args.entities)}`,
    words: (result) => ({ words: result.changed.length === 0 ? `Nothing changed: ${namedAll(result.entities)} had it so already.` : `${result.changed.join('; ')} on ${namedAll(result.entities)}. ${stepSaid(result.step)}`, json: { entities: result.entities, changed: result.changed } }),
    row: (result) => ({ ok: true, words: `flags of ${result.entities.length === 1 ? result.entities[0]!.path : `${result.entities.length} entities`}: ${result.changed.length === 0 ? 'no change' : result.changed.join(', ')}`, detail: stepDetail(result.step) }),
  }),

  scene_relate: pageTool('scene_relate', {
    description: 'Link an entity to a target by a relation, as "Link to…" and a click on the target: the link\'s `data` its fields (numbers). One step on the editor\'s undo stack, which the person undoes with Z. A link dies with either end.',
    input: (z, s) => ({ entity: s.entity.describe('Where the link goes from: a ref or path'), relation: z.string().min(1).max(100).describe('The relation, as scene_describe names it'), target: s.entity.describe('Where it goes to'), data: z.record(z.string(), z.number()).optional().describe('The link\'s fields: { weight: 2 }') }),
    output: (z, s) => z.object({ relation: z.string(), from: s.row, to: s.row, data: z.record(z.string(), z.number()) }),
    summary: (args) => `link ${oneWhom(args.entity)} to ${oneWhom(args.target)} by ${String(args.relation)}`,
    words: (result) => ({ words: `Linked ${result.from.path} → ${result.to.path} by ${result.relation}. ${stepSaid(result.step)}`, json: { relation: result.relation, from: result.from, to: result.to, data: result.data } }),
    row: (result) => ({ ok: true, words: `link ${result.from.path} → ${result.to.path} (${result.relation})`, detail: stepDetail(result.step) }),
  }),

  scene_unrelate: pageTool('scene_unrelate', {
    description: 'Cut the link from an entity to a target by a relation, as the inspector\'s ×. One step on the editor\'s undo stack, which the person undoes with Z.',
    input: (z, s) => ({ entity: s.entity, relation: z.string().min(1).max(100), target: s.entity }),
    output: (z, s) => z.object({ relation: z.string(), from: s.row, to: s.row }),
    summary: (args) => `cut ${oneWhom(args.entity)} → ${oneWhom(args.target)} (${String(args.relation)})`,
    words: (result) => ({ words: `Cut ${result.from.path} → ${result.to.path} (${result.relation}). ${stepSaid(result.step)}`, json: { relation: result.relation, from: result.from, to: result.to } }),
    row: (result) => ({ ok: true, words: `cut ${result.from.path} → ${result.to.path} (${result.relation})`, detail: stepDetail(result.step) }),
  }),

  scene_list_insert: pageTool('scene_list_insert', {
    description: 'Add an element to a list of a data component, as the inspector\'s + (or a drop onto the list) does -- or an entry to a dictionary. `path` names the list or dictionary (scene_entity\'s `schema` kinds `list` and `dict`): a field (waypoints), or one inside another (crew[0].stops). A list: `index` where it goes (left out: the end), `value` the element in its plain form as scene_set takes one (an entity\'s ref or path, an enum\'s name, a key\'s text, a record\'s { field: value }; left out: the element\'s default). A dictionary: `key` its key (an enum\'s name, text, a number, an entity\'s ref or path; left out: the first key it has not -- an enum\'s next name, "key 2"), `value` its value; a key it has is refused. A list at its `max` refuses one more. One step on the editor\'s undo stack, which the person undoes with Z. Answers the list after, each entity\'s.',
    input: (z, s) => ({
      entities: s.entities.optional().describe('Entities, each a ref or a path; left out, the selection'),
      component: z.string().min(1).max(100).describe('The data component, as scene_describe names it'),
      path: z.string().min(1).max(300).describe('The list or dictionary: waypoints, loot, crew[0].stops'),
      index: z.number().int().min(0).optional().describe('A list: where the element goes; left out, the end'),
      key: z.unknown().optional().describe('A dictionary: the new entry\'s key; left out, the first free one'),
      value: z.unknown().optional().describe('The element, or the entry\'s value, as scene_set takes one; left out, its default'),
    }),
    output: (z) => z.array(z.object({ id: z.number(), ref: z.number(), was: z.string(), now: z.string() })),
    summary: (args) => `add to ${String(args.component)}.${String(args.path)}${args.value === undefined ? '' : ` ${JSON.stringify(args.value)}`} on ${onWhom(args.entities)}`,
    words: (result) => ({ words: `${result.step === null ? 'Nothing changed.' : `Added to ${result.component}.${result.path}.`} ${stepSaid(result.step)}`, json: result.written }),
    row: (result) => ({ ok: true, words: `add to ${result.component}.${result.path} on ${result.written.length}`, detail: stepDetail(result.step) }),
  }),

  scene_list_remove: pageTool('scene_list_remove', {
    description: 'Take an element out of a list of a data component, as the inspector\'s × on its row does -- by `index` -- or an entry out of a dictionary, by `key`. A list at its `min` refuses one fewer. One step on the editor\'s undo stack, which the person undoes with Z. Answers the list after, each entity\'s.',
    input: (z, s) => ({
      entities: s.entities.optional().describe('Entities, each a ref or a path; left out, the selection'),
      component: z.string().min(1).max(100).describe('The data component'),
      path: z.string().min(1).max(300).describe('The list or dictionary: waypoints, loot'),
      index: z.number().int().min(0).optional().describe('A list: the element\'s index'),
      key: z.unknown().optional().describe('A dictionary: the entry\'s key'),
    }),
    output: (z) => z.array(z.object({ id: z.number(), ref: z.number(), was: z.string(), now: z.string() })),
    summary: (args) => `remove ${args.key !== undefined ? JSON.stringify(args.key) : `[${String(args.index)}]`} from ${String(args.component)}.${String(args.path)} on ${onWhom(args.entities)}`,
    words: (result) => ({ words: `${result.step === null ? 'Nothing changed.' : `Removed from ${result.component}.${result.path}.`} ${stepSaid(result.step)}`, json: result.written }),
    row: (result) => ({ ok: true, words: `remove from ${result.component}.${result.path} on ${result.written.length}`, detail: stepDetail(result.step) }),
  }),

  scene_list_move: pageTool('scene_list_move', {
    description: 'Move an element of a list of a data component from `from` to `to` (indices, the rest keeping their order), as dragging its row\'s grip does -- or a dictionary\'s entry, named by `key` or its place `from`, to place `to` in its order (kept in the file); or, with `rename`, a dictionary\'s entry `key` given that key in its place, as typing its key anew in the inspector does (a key it has refused). One step on the editor\'s undo stack, which the person undoes with Z. Answers the list after, each entity\'s.',
    input: (z, s) => ({
      entities: s.entities.optional().describe('Entities, each a ref or a path; left out, the selection'),
      component: z.string().min(1).max(100).describe('The data component'),
      path: z.string().min(1).max(300).describe('The list or dictionary: waypoints, loot'),
      from: z.number().int().min(0).optional().describe('Its place now'),
      key: z.unknown().optional().describe('A dictionary: the entry by its key, in place of from'),
      to: z.number().int().min(0).optional().describe('Its place after'),
      rename: z.unknown().optional().describe('A dictionary: the entry `key` given this key instead, in its place (in place of to)'),
    }),
    output: (z) => z.array(z.object({ id: z.number(), ref: z.number(), was: z.string(), now: z.string() })),
    summary: (args) => args.rename !== undefined ? `rename ${JSON.stringify(args.key)} to ${JSON.stringify(args.rename)} in ${String(args.component)}.${String(args.path)} on ${onWhom(args.entities)}` : `move ${args.key !== undefined ? JSON.stringify(args.key) : `[${String(args.from)}]`} to [${String(args.to)}] in ${String(args.component)}.${String(args.path)} on ${onWhom(args.entities)}`,
    words: (result) => ({ words: `${result.step === null ? 'Nothing changed.' : `Moved in ${result.component}.${result.path}.`} ${stepSaid(result.step)}`, json: result.written }),
    row: (result) => ({ ok: true, words: `move in ${result.component}.${result.path} on ${result.written.length}`, detail: stepDetail(result.step) }),
  }),

  scene_main_camera: pageTool('scene_main_camera', {
    description: 'Make a camera entity the one the game draws through, as the notice\'s "Make <name> main": its Camera.main on, every other camera\'s off. One step on the editor\'s undo stack, which the person undoes with Z.',
    input: (_z, s) => ({ entity: s.entity.describe('A camera entity: a ref or path') }),
    output: (z, s) => z.object({ camera: s.row, was: z.array(s.row) }),
    summary: (args) => `make ${oneWhom(args.entity)} the main camera`,
    words: (result) => ({ words: `${named(result.camera)} is the main camera${result.was.length > 0 ? `; ${result.was.map((r) => r.path).join(', ')} no longer` : ''}. ${stepSaid(result.step)}`, json: { camera: result.camera, was: result.was } }),
    row: (result) => ({ ok: true, words: `make ${result.camera.path} the main camera`, detail: stepDetail(result.step) }),
  }),

  scene_select: pageTool('scene_select', {
    description: 'Set the person\'s selection in the editor -- only when they asked for it: no other tool moves it. [] clears it. No step: a selection is no edit.',
    input: (z, s) => ({ entities: z.array(s.entity).max(256).describe('The entities to select, refs or paths; [] for none') }),
    output: (z, s) => z.object({ selected: z.array(s.row) }),
    summary: (args) => (Array.isArray(args.entities) && args.entities.length === 0 ? 'clear the selection' : `select ${onWhom(args.entities)}`),
    words: (result) => ({ words: result.selected.length === 0 ? 'Nothing is selected now.' : `Selected ${namedAll(result.selected)}.`, json: { selected: result.selected } }),
    row: (result) => ({ ok: true, words: result.selected.length === 0 ? 'clear the selection' : `select ${result.selected.length === 1 ? result.selected[0]!.path : `${result.selected.length} entities`}`, detail: null }),
  }),

  batch: pageTool('batch', {
    description: `Several scene edits as ONE step on the editor's undo stack ("Claude: N edits"), which the person undoes with one Z: \`calls\` in order, each { tool, args } of ${BATCHED_TOOLS.join(', ')}. A later call names what an earlier one made as "$<n>" -- "$0" the entity call 0 created or duplicated -- anywhere in its args (parent: "$0", entities: ["$1"]). One that fails undoes the ones before it: nothing changed, and the answer says which failed and why. Answers each call's result in order.`,
    input: (z) => ({
      calls: z.array(z.object({ tool: z.enum(BATCHED_TOOLS), args: z.record(z.string(), z.unknown()).optional() })).min(1).max(64).describe('The calls, in order'),
    }),
    output: (z) => z.object({ results: z.array(z.unknown()) }),
    summary: (args) => `${Array.isArray(args.calls) ? args.calls.length : 0} edits as one step`,
    words: (result) => ({ words: `${result.results.length} edits: ${result.results.map(batchLine).join('; ')}. ${stepSaid(result.step)}`, json: { results: result.results.map(batchJson) } }),
    row: (result) => ({ ok: true, words: `${result.results.length} edits as one step`, detail: `${result.results.map(batchLine).join('; ')} · ${stepDetail(result.step)}` }),
  }),
};
