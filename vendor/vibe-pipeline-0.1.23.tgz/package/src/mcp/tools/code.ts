/**
 * The studio and code tools (Docs/mcp.md §4's Studio, M5): server tools, the dev server's own work in-process
 * (`studio-work.ts` over `studio/calls.ts`) -- what the Studio tab's cards do:
 *
 * - **Problems** (`problems_list`): tsc's, Vite's modules that do not serve, the checks' findings of the last test run.
 * - **The Console** (`console_read`): a stream of the log since a seq, filtered.
 * - **Tests and Build** (`tests_run`, `build_run`): the allow-listed npm scripts as jobs, the cards showing them;
 *   **the preview** (`preview_start`, `preview_stop`), the Build card's.
 * - **TypeScript** (`ts_diagnostics`, `ts_definition`, `ts_references`, `ts_hover`): the Code card's bridge.
 * - **Search** (`code_search`): the Code card's. Reading and writing files stays Claude Code's own Read, Grep, Edit
 *   and Write.
 * - **Moving and deleting** (`code_move`, `code_delete`): the Code card tree's Rename, drag and Delete (`file-ops.ts`) --
 *   a script's imports updated by TypeScript as it moves, an asset moved or deleted the Assets panel's way. A new file,
 *   a copy, Save As stay Write's.
 *
 * Nothing at module level but the records.
 */
import { stat } from 'node:fs/promises';
import { join } from 'node:path';
import type { z as Zod } from 'zod';
import { serverTool, ToolRefusal } from '../tool.ts';
import { plural } from '../words.ts';
import {
  asTool, fileDiagnostics, TASK_WAIT_MS, hoverText, lspPosition, placeOf, problemsOf, readLog, runTask, scriptPath, studioOf, testPath, testsFacts, textOf, waitJob,
  type DiagnosticRow, type Place, type ProblemRow, type Ran, type TestsFacts,
} from '../studio-work.ts';
import { parseTestOutput } from '../../studio/test-output.ts';
import { deleteEntries, filesUnder, moveEntry, type FileOpsContext } from '../../studio/file-ops.ts';
import type { StudioContext } from '../tool.ts';
import type { ToolOutput } from '../result.ts';

/** Problems in a few lines: `file:line:col  words`. */
const problemLines = (rows: readonly ProblemRow[], max = 30): string =>
  `${rows.slice(0, max).map((r) => `${r.file}${r.line > 0 ? `:${r.line}${r.col > 0 ? `:${r.col}` : ''}` : ''}  ${r.words.split('\n')[0]} (${r.program}${r.code && r.program !== 'checks' ? ` ${r.code}` : ''})`).join('\n')}${rows.length > max ? `\n… and ${rows.length - max} more (ask for a file)` : ''}`;

/** A test run in words: the files, then each failure by name. */
function testsWords(f: TestsFacts): string {
  const head = f.exit === '0' ? 'The tests passed' : f.exit === null ? 'The tests did not finish' : `The tests failed (exit ${f.exit})`;
  const files = `${f.files.passed} of ${f.files.total} test files passed`;
  const failing = f.failed.map((x) => `${x.path ?? x.title}${x.crashed ? ' (crashed)' : ''}: ${x.failures.map((y) => y.name).join('; ')}`).join('\n');
  const checks = f.checks === null ? '' : f.checks.clean ? ' The checks are clean.' : ` The checks found ${plural(f.checks.findings.length, 'thing')}:\n${problemLines(f.checks.findings)}`;
  return `${head}: ${files}.${failing ? `\n${failing}` : ''}${checks}`;
}

/** A finished test job's facts: each run's lines parsed as one (several files: one run each). */
function testsResult(ran: readonly Ran[]): TestsFacts {
  const facts = ran.map((r) => testsFacts(parseTestOutput(r.lines)));
  if (facts.length === 1) return facts[0]!;
  return {
    exit: facts.every((x) => x.exit === '0') ? '0' : (facts.find((x) => x.exit !== '0')?.exit ?? null),
    files: facts.reduce((a, x) => ({ passed: a.passed + x.files.passed, failed: a.failed + x.files.failed, total: a.total + x.files.total }), { passed: 0, failed: 0, total: 0 }),
    failed: facts.flatMap((x) => x.failed),
    checks: facts.find((x) => x.checks !== null)?.checks ?? null,
    skipped: facts.reduce((n, x) => n + x.skipped, 0),
  };
}

/** A build's facts: its script, its exit, its last lines (all of the failing one's, at most 40). */
interface BuildFacts {
  script: string;
  exit: number | null;
  signal: string | null;
  lines: string[];
}

const SCRIPTS = { release: 'build', debug: 'build:debug', packs: 'packs' } as const;

/** The Code card's file operations' context for a tool: the studio's root and bridge, the assets server -- no running turn's lock (the turn is the caller). */
function opsOf(ctx: StudioContext): FileOpsContext {
  const calls = studioOf(ctx);
  return { root: calls.root, ts: () => calls.ts(), assets: () => ctx.assets?.() ?? null };
}

/** The files at and under a path now (a folder's every file, a file itself): what Undo this turn must know of. */
async function filesAt(root: string, path: string): Promise<string[]> {
  const folder = await stat(join(root, path)).then((info) => info.isDirectory(), () => false);
  return folder ? await filesUnder(root, path).catch(() => [path]) : [path];
}

/** A task's job in words, as it ended or still running. */
async function settled<T>(ctx: Parameters<typeof waitJob>[0], id: string, words: (result: T) => string, running: string): Promise<ToolOutput> {
  const ended = await waitJob(ctx, id);
  if (ended === null) return { words: `${running} Still running: job ${id} -- job_wait waits for it, the Studio tab's cards show it.`, json: { job: id, state: 'running' } };
  if (ended.state === 'failed') return { words: `Job ${id} failed: ${ended.error ?? 'no reason said'}`, json: { job: id, state: 'failed', error: ended.error }, isError: true };
  return { words: words(ended.result as T), json: { job: id, state: 'done', ...(ended.result as object) } };
}

const PLACE = (z: typeof Zod) => z.object({ path: z.string().nullable(), uri: z.string(), line: z.number(), col: z.number(), endLine: z.number(), endCol: z.number(), text: z.string().optional() });
const PROBLEM = (z: typeof Zod) => z.object({ file: z.string(), line: z.number(), col: z.number(), words: z.string(), program: z.string(), code: z.string() });

/** A place in a line: `src/game/x.ts:12:5  the line's text`. */
const placeLine = (p: Place): string => `${p.path ?? p.uri}:${p.line}:${p.col}${p.text ? `  ${p.text}` : ''}`;

export const codeTools = {
  problems_list: serverTool('problems_list', {
    description: 'What is wrong with the project now, as the Studio tab\'s Problems card lists it: tsc\'s errors (both programs, from its watch), the modules Vite cannot serve (a syntax error, an import of no file -- these stop the game swapping in new code), and the checks\' findings of the last test run the studio made (`vibe test`\'s rules: the ECS, the routes, the UI). Each with its file, line, column and words. `file` narrows to one file. Only reads.',
    input: (z) => ({
      file: z.string().min(1).max(500).optional().describe('Only this file\'s (project-relative)'),
      limit: z.number().int().min(1).max(500).optional().describe('At most this many (200)'),
    }),
    output: (z) => z.object({ problems: z.array(PROBLEM(z)), total: z.number(), checksFrom: z.string().nullable() }),
    summary: (args) => (typeof args.file === 'string' ? `read the problems in ${args.file}` : 'read the problems'),
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const { rows, checksFrom } = problemsOf(calls);
      const mine = typeof args.file === 'string' ? rows.filter((r) => r.file === args.file) : rows;
      const limit = typeof args.limit === 'number' ? args.limit : 200;
      const shown = mine.slice(0, limit);
      const words = mine.length === 0
        ? `No problems${typeof args.file === 'string' ? ` in ${args.file}` : ''}: tsc and Vite say nothing${checksFrom ? ', and the last test run\'s checks were clean' : ' (no test run yet for the checks: tests_run)'}.`
        : `${plural(mine.length, 'problem')}${mine.length > shown.length ? `, the first ${shown.length}` : ''}:\n${problemLines(shown)}`;
      return { words, json: { problems: shown, total: mine.length, checksFrom } };
    },
    row: (args, out) => ({ ok: !out.isError, words: typeof args.file === 'string' ? `read the problems in ${args.file}` : 'read the problems', detail: out.words.split('\n')[0] ?? null }),
  }),

  console_read: serverTool('console_read', {
    description: 'The Console card\'s log: a stream\'s lines -- `server` (the dev server\'s own: the plugins\' [assets], [agent], [studio] lines and Vite\'s), `task:<script>` (a test run\'s, a build\'s), `git` (the Git card\'s commands) -- after `since` (a seq an earlier answer gave: only what is new), with `filter` (any case) to keep the lines that have it. The last 2000 lines a stream are kept. Answers the stream\'s seq to read on from. Only reads.',
    input: (z) => ({
      stream: z.string().min(1).max(100).optional().describe('server (the default), task:<script>, git'),
      since: z.number().int().min(0).optional().describe('Only the lines after this seq (an earlier answer\'s `seq`)'),
      filter: z.string().min(1).max(200).optional().describe('Only lines with this text, any case'),
      limit: z.number().int().min(1).max(1000).optional().describe('The last this many (200)'),
    }),
    output: (z) => z.object({ stream: z.string(), seq: z.number(), lines: z.array(z.object({ seq: z.number(), at: z.number(), text: z.string() })), dropped: z.number(), streams: z.array(z.string()) }),
    summary: (args) => `read the console${typeof args.stream === 'string' ? ` (${args.stream})` : ''}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const stream = typeof args.stream === 'string' ? args.stream : 'server';
      const streams = calls.streams();
      if (stream !== 'server' && !streams.includes(stream)) throw new ToolRefusal(`No stream ${stream} yet: the streams are ${streams.join(', ') || 'none'}`);
      const got = readLog(calls, stream, typeof args.since === 'number' ? args.since : 0, typeof args.filter === 'string' ? args.filter : null, typeof args.limit === 'number' ? args.limit : 200);
      const words = got.lines.length === 0 ? `Nothing ${typeof args.since === 'number' ? 'new ' : ''}in ${stream}${typeof args.filter === 'string' ? ` with "${args.filter}"` : ''} (seq ${got.seq}).` : `${plural(got.lines.length, 'line')} of ${stream}${got.dropped > 0 ? ` (the last; ${got.dropped} before them left out)` : ''}, to seq ${got.seq}:\n${got.lines.map((l) => l.text).join('\n')}`;
      return { words, json: { stream, seq: got.seq, lines: got.lines, dropped: got.dropped, streams } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `read the console${typeof args.stream === 'string' ? ` (${args.stream})` : ''}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  tests_run: serverTool('tests_run', {
    description: `Run the tests, as the Tests card's Run all (\`vibe test\`: every test file, then the checks) -- or \`paths\`, test files under src/ (\`src/game/spin.test.ts\`), each run alone as the card's Run one does. A job: answered with the result when it ends within ${TASK_WAIT_MS / 1000} s -- files passed and failed, each failure's name and message, the checks' findings -- else with the job's id for job_wait. The Tests card shows the run. One task at a time in the studio: refused while another runs.`,
    input: (z) => ({ paths: z.array(z.string().min(1).max(500)).min(1).max(20).optional().describe('Test files to run, each alone; left out, all and the checks') }),
    output: (z) => z.object({ job: z.string(), state: z.string() }).loose(),
    summary: (args) => (Array.isArray(args.paths) ? `run ${plural(args.paths.length, 'test file')}` : 'run the tests'),
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const paths = Array.isArray(args.paths) ? args.paths.map(testPath) : [];
      const label = paths.length === 0 ? 'vibe test' : paths.length === 1 ? `test ${paths[0]}` : `test ${plural(paths.length, 'file')}`;
      const job = await runTask(ctx, calls, 'test', paths.map((p) => [p]), label, testsResult);
      return settled<TestsFacts>(ctx, job.id, testsWords, 'The tests are running.');
    },
    row: (args, out) => ({ ok: !out.isError, words: Array.isArray(args.paths) ? `run ${plural(args.paths.length, 'test file')}` : 'run the tests', detail: out.words.split('\n')[0] ?? null }),
  }),

  build_run: serverTool('build_run', {
    description: 'Build, as the Build card does: `release` (npm run build: the typechecks, the packs, the production build into dist/), `debug` (build:debug: sourcemaps and the debug tools kept) or `packs` (the content packs alone). A job: answered when it ends within 20 s, with its exit and last lines, else with the job\'s id for job_wait. The Build card shows it, and measures dist/ after. A running preview is stopped as a build starts. One task at a time.',
    input: (z) => ({ kind: z.enum(['release', 'debug', 'packs']).optional().describe('release (the default), debug or packs') }),
    output: (z) => z.object({ job: z.string(), state: z.string() }).loose(),
    summary: (args) => `build${args.kind === 'debug' ? ' (debug)' : args.kind === 'packs' ? ' the packs' : ''}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const kind = (typeof args.kind === 'string' ? args.kind : 'release') as keyof typeof SCRIPTS;
      const script = SCRIPTS[kind];
      if (!script) throw new ToolRefusal('kind is release, debug or packs');
      const job = await runTask(ctx, calls, script, [], `npm run ${script}`, (ran): BuildFacts => {
        const r = ran[0]!;
        const ok = r.end.code === 0;
        return { script, exit: r.end.code, signal: r.end.signal, lines: r.lines.slice(ok ? -8 : -40) };
      });
      return settled<BuildFacts>(ctx, job.id, (b) => `${b.exit === 0 ? `npm run ${b.script} succeeded` : `npm run ${b.script} ${b.signal ? `was stopped (${b.signal})` : `failed (exit ${b.exit})`}`}. Its last lines:\n${b.lines.join('\n')}`, `npm run ${script} is running.`);
    },
    row: (args, out) => ({ ok: !out.isError, words: `build${args.kind === 'debug' ? ' (debug)' : args.kind === 'packs' ? ' the packs' : ''}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  preview_start: serverTool('preview_start', {
    description: 'Serve the last build\'s dist/ (vite preview), as the Build card\'s Preview: its url, for the person to open (no tab is opened). The running one\'s url if one runs. A build stops it.',
    input: (z) => ({ port: z.number().int().min(1).max(65535).optional().describe('A port of its own; left out, the project\'s preview port') }),
    output: (z) => z.object({ url: z.string() }),
    summary: () => 'start the preview',
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const was = calls.preview.url();
      let url: string;
      try {
        url = await calls.preview.start(typeof args.port === 'number' ? args.port : undefined);
      } catch (err) {
        throw new ToolRefusal(`The preview did not start: ${(err as Error).message} -- build first (build_run)`);
      }
      return { words: `${was === url ? 'The preview runs already' : 'The preview runs'} at ${url}: the release build of dist/. Give the person the link; preview_stop stops it.`, json: { url } };
    },
    row: (_args, out) => ({ ok: !out.isError, words: 'start the preview', detail: out.words }),
  }),

  preview_stop: serverTool('preview_stop', {
    description: 'Stop the preview of dist/ (vite preview), as a build\'s start stops it. Nothing to stop is said, not refused.',
    input: () => ({}),
    output: (z) => z.object({ stopped: z.boolean() }),
    summary: () => 'stop the preview',
    async run(ctx) {
      const stopped = await studioOf(ctx).preview.stop();
      return { words: stopped ? 'The preview stopped.' : 'No preview was running.', json: { stopped } };
    },
    row: (_args, out) => ({ ok: !out.isError, words: 'stop the preview', detail: out.words }),
  }),

  ts_diagnostics: serverTool('ts_diagnostics', {
    description: 'TypeScript\'s errors and warnings: for `file` (project-relative), as the Code card\'s gutter has them -- the project\'s own TypeScript, through the studio\'s language server, the file as it is on disk (while a Code card tab has it open, that tab\'s text, unsaved edits and all); with no `file`, the whole project as tsc\'s watch last checked it (the Problems card\'s tsc rows). Only reads.',
    input: (z) => ({ file: z.string().min(1).max(500).optional().describe('A .ts or .js file of the project; left out, the project') }),
    output: (z) => z.object({ scope: z.string(), diagnostics: z.array(z.object({ file: z.string(), line: z.number(), col: z.number(), severity: z.string(), code: z.string(), words: z.string() })) }),
    summary: (args) => `check the types${typeof args.file === 'string' ? ` of ${args.file}` : ''}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      let rows: DiagnosticRow[];
      let scope: string;
      if (typeof args.file === 'string') {
        scope = scriptPath(args.file);
        rows = await fileDiagnostics(calls, scope);
      } else {
        scope = 'project';
        rows = calls.problems().problems.filter((p) => p.program !== 'vite').map((p) => ({ file: p.file, line: p.line, col: p.col, severity: 'error', code: p.code, words: p.message }));
      }
      const words = rows.length === 0 ? `No type errors in ${scope === 'project' ? 'the project (tsc\'s watch)' : scope}.` : `${plural(rows.length, 'diagnostic')} in ${scope === 'project' ? 'the project (tsc\'s watch)' : scope}:\n${rows.slice(0, 40).map((d) => `${d.file}:${d.line}:${d.col}  ${d.severity} ${d.code}: ${d.words.split('\n')[0]}`).join('\n')}${rows.length > 40 ? `\n… and ${rows.length - 40} more` : ''}`;
      return { words, json: { scope, diagnostics: rows } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `check the types${typeof args.file === 'string' ? ` of ${args.file}` : ''}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  ts_definition: serverTool('ts_definition', {
    description: 'Where the name at a place is defined, as the Code card\'s Go to definition: `file`, `line` and `col` (from 1, as an editor shows them). Answers each definition\'s file and place, and its line of text. While a Code card tab has the file open, the answer is for that tab\'s text, unsaved edits and all. Only reads.',
    input: (z) => ({ file: z.string().min(1).max(500), line: z.number().int().min(1), col: z.number().int().min(1) }),
    output: (z) => z.object({ definitions: z.array(PLACE(z)) }),
    summary: (args) => `find the definition at ${String(args.file)}:${String(args.line)}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const file = scriptPath(args.file);
      const position = lspPosition(args.line, args.col);
      const ts = calls.ts();
      const text = await textOf(calls, file);
      const found = await asTool(() => ts.withFile(file, text, (uri) => ts.request('textDocument/definition', { textDocument: { uri }, position })));
      const list = (Array.isArray(found) ? found : found ? [found] : []) as Parameters<typeof placeOf>[1][];
      const places = (await Promise.all(list.map((l) => placeOf(calls, l)))).filter((p): p is Place => p !== null);
      return { words: places.length === 0 ? `No definition at ${file}:${String(args.line)}:${String(args.col)}.` : `${plural(places.length, 'definition')}:\n${places.map(placeLine).join('\n')}`, json: { definitions: places } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `find the definition at ${String(args.file)}:${String(args.line)}`, detail: out.words.split('\n')[1] ?? out.words }),
  }),

  ts_references: serverTool('ts_references', {
    description: 'Every use of the name at a place, as the Code card\'s references: `file`, `line` and `col` (from 1). The declaration too, unless `declaration: false`. While a Code card tab has the file open, the answer is for that tab\'s text, unsaved edits and all. Only reads.',
    input: (z) => ({ file: z.string().min(1).max(500), line: z.number().int().min(1), col: z.number().int().min(1), declaration: z.boolean().optional().describe('The declaration with them (true)') }),
    output: (z) => z.object({ references: z.array(PLACE(z)), total: z.number() }),
    summary: (args) => `find the uses at ${String(args.file)}:${String(args.line)}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const file = scriptPath(args.file);
      const position = lspPosition(args.line, args.col);
      const ts = calls.ts();
      const text = await textOf(calls, file);
      const found = await asTool(() => ts.withFile(file, text, (uri) => ts.request('textDocument/references', { textDocument: { uri }, position, context: { includeDeclaration: args.declaration !== false } })));
      const list = (Array.isArray(found) ? found : []) as Parameters<typeof placeOf>[1][];
      const places = (await Promise.all(list.slice(0, 300).map((l) => placeOf(calls, l)))).filter((p): p is Place => p !== null);
      return { words: places.length === 0 ? `No uses found at ${file}:${String(args.line)}:${String(args.col)}.` : `${plural(list.length, 'use')}${list.length > places.length ? ` (the first ${places.length})` : ''}:\n${places.slice(0, 60).map(placeLine).join('\n')}${places.length > 60 ? `\n… and ${places.length - 60} more in the JSON` : ''}`, json: { references: places, total: list.length } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `find the uses at ${String(args.file)}:${String(args.line)}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  ts_hover: serverTool('ts_hover', {
    description: 'What TypeScript says of the name at a place, as the Code card\'s hover: its type and its doc comment. `file`, `line` and `col` (from 1). While a Code card tab has the file open, the answer is for that tab\'s text, unsaved edits and all. Only reads.',
    input: (z) => ({ file: z.string().min(1).max(500), line: z.number().int().min(1), col: z.number().int().min(1) }),
    output: (z) => z.object({ text: z.string() }),
    summary: (args) => `read the type at ${String(args.file)}:${String(args.line)}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const file = scriptPath(args.file);
      const position = lspPosition(args.line, args.col);
      const ts = calls.ts();
      const text = await textOf(calls, file);
      const hover = await asTool(() => ts.withFile(file, text, (uri) => ts.request('textDocument/hover', { textDocument: { uri }, position })));
      const said = hoverText(hover);
      return { words: said === '' ? `Nothing to say at ${file}:${String(args.line)}:${String(args.col)}.` : said, json: { text: said } };
    },
    row: (args, out) => ({ ok: !out.isError, words: `read the type at ${String(args.file)}:${String(args.line)}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  code_move: serverTool('code_move', {
    description: 'Move or rename a file or a folder of the project, as the Code card tree\'s Rename and drag: `from` and `to`, project-relative (`src/game/systems/spin.ts` to `src/game/motion/spin.ts`). A script (.ts, .js) or a folder of them: TypeScript updates every import of it and its own relative imports first (as VS Code does), the files it changed answered. Under src/assets/, AssetsSource/ or packs/: the Assets panel\'s move (the uid kept, the keys in files rewritten; refused while game code names the asset -- change the code first). Refused for a generated file (keys.d.ts, the globs, live.ts), a folder holding one, a folder into itself, and a destination already there unless `replace: true` (a file only). To make, copy or write a file, use Write.',
    input: (z) => ({ from: z.string().min(1).max(500), to: z.string().min(1).max(500), replace: z.boolean().optional().describe('A file at `to` replaced (false)') }),
    output: (z) => z.object({ via: z.string(), moved: z.array(z.tuple([z.string(), z.string()])), edited: z.array(z.string()), held: z.array(z.string()), rewritten: z.array(z.string()), imports: z.string().optional() }),
    summary: (args) => `move ${String(args.from)} to ${String(args.to)}`,
    async run(ctx, args) {
      const ops = opsOf(ctx);
      const before = await filesAt(ops.root, String(args.from));
      const done = await asTool(() => moveEntry(ops, { from: args.from, to: args.to, replace: args.replace === true }));
      const after = done.moved.flatMap(([from, to]) => before.map((p) => (p === from ? to : p.startsWith(`${from}/`) ? to + p.slice(from.length) : p)));
      ctx.wrote?.([...new Set([...before, ...after, ...done.edited, ...done.rewritten])]);
      const touched = done.edited.length + done.rewritten.length;
      const words = done.moved.length === 0
        ? `${String(args.from)} is already there.`
        : `Moved ${done.moved.map(([a, b]) => `${a} to ${b}`).join(', ')}${done.via === 'assets' ? ' (the Assets panel\'s move)' : ''}${touched > 0 ? `; ${plural(touched, 'file')} rewritten: ${[...done.edited, ...done.rewritten].join(', ')}` : ''}.${done.held.length > 0 ? ` Open in a Code card tab, so given their new imports there -- saved by the tab where it had no unsaved changes, else waiting for the person to save: ${done.held.join(', ')}.` : ''}${done.imports ? ` Imports ${done.imports}.` : ''}`;
      return { words, json: done };
    },
    row: (args, out) => ({ ok: !out.isError, words: `move ${String(args.from)} to ${String(args.to)}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  code_delete: serverTool('code_delete', {
    description: 'Delete files or folders of the project, as the Code card tree\'s Delete: `paths`, project-relative. Gone for good (Undo this turn puts back what this turn deleted); an asset under src/assets/, AssetsSource/ or packs/ goes to the project\'s .trash/ the Assets panel\'s way, refused while a data file names it. Refused for a generated file and a folder holding one. Ask before deleting anything you did not make.',
    input: (z) => ({ paths: z.array(z.string().min(1).max(500)).min(1).max(100) }),
    output: (z) => z.object({ via: z.string(), removed: z.array(z.string()), slot: z.string().optional() }),
    summary: (args) => `delete ${Array.isArray(args.paths) ? args.paths.join(', ') : String(args.paths)}`,
    async run(ctx, args) {
      const ops = opsOf(ctx);
      const paths = Array.isArray(args.paths) ? args.paths.map(String) : [String(args.paths)];
      const before = (await Promise.all(paths.map((p) => filesAt(ops.root, p)))).flat();
      const done = await asTool(() => deleteEntries(ops, { paths }));
      ctx.wrote?.([...new Set([...before, ...done.removed])]);
      return { words: `Deleted ${done.removed.join(', ')}${done.via === 'assets' ? ` (to the project's .trash/${done.slot ? `, slot ${done.slot}` : ''})` : ''}.`, json: done };
    },
    row: (args, out) => ({ ok: !out.isError, words: `delete ${Array.isArray(args.paths) ? args.paths.join(', ') : String(args.paths)}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  code_search: serverTool('code_search', {
    description: 'Search the project\'s files, as the Code card\'s search: `q` a literal text (any case), `glob` a filter on paths (`**/*.lua`; one with no / matches the file\'s name, `*.ts`). Over the card\'s tree -- src/, AssetsSource/, packs/, public/, engine/, the project\'s .claude skills and agents, CLAUDE.md; never node_modules, .git, dist. The first 500 hits, each file, line, column and line of text. Only reads (to read a file whole, Read it).',
    input: (z) => ({ q: z.string().min(1).max(500), glob: z.string().min(1).max(200).optional() }),
    output: (z) => z.object({ hits: z.array(z.object({ path: z.string(), line: z.number(), col: z.number(), text: z.string() })), truncated: z.boolean(), by: z.string() }),
    summary: (args) => `search for "${String(args.q)}"${typeof args.glob === 'string' ? ` in ${args.glob}` : ''}`,
    async run(ctx, args) {
      const calls = studioOf(ctx);
      const found = await asTool(() => calls.search(String(args.q), typeof args.glob === 'string' ? args.glob : null));
      const files = new Set(found.hits.map((h) => h.path)).size;
      const words = found.hits.length === 0 ? `No hits for "${String(args.q)}".` : `${plural(found.hits.length, 'hit')} in ${plural(files, 'file')}${found.truncated ? ' (the first 500: narrow it with glob)' : ''}:\n${found.hits.slice(0, 80).map((h) => `${h.path}:${h.line}:${h.col}  ${h.text.trim().slice(0, 160)}`).join('\n')}${found.hits.length > 80 ? `\n… and ${found.hits.length - 80} more in the JSON` : ''}`;
      return { words, json: found };
    },
    row: (args, out) => ({ ok: !out.isError, words: `search for "${String(args.q)}"`, detail: out.words.split('\n')[0] ?? null }),
  }),
};
