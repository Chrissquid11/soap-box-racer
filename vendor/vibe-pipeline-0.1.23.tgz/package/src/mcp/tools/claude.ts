/**
 * The claude area's tools (Docs/mcp.md §7 D4): `claude_settings` -- Claude's own model, effort and review bar, read or
 * set, each change said in the transcript by the session; the permission level read only, the person's alone. A
 * server tool.
 */
import type { ReviewBar } from '../../agent/api-types.ts';
import { serverTool, ToolRefusal, type ClaudeSettingsChange, type ClaudeSettingsFacts } from '../tool.ts';

/** Is a `claude_settings` call a read: nothing to set (the catalogue's `readsWhen` too). */
const reads = (args: Record<string, unknown>): boolean => args.model === undefined && args.effort === undefined && args.review === undefined;

export const claudeTools = {
  claude_settings: serverTool('claude_settings', {
    description: 'Claude\'s own settings in this conversation: the model, the effort and the review bar -- read (nothing given), or set (any of model, effort, review; each change said in the transcript). Answers all four and the choices: the models with their effort levels, the review bars. The permission level (Ask, Auto, Unsafe auto) is read only: it is the person\'s alone, and no tool sets it.',
    input: (z) => ({
      model: z.string().min(1).max(200).nullable().optional().describe('A model\'s value from `models` ("default" or null: the CLI\'s own)'),
      effort: z.string().min(1).max(50).nullable().optional().describe('One of the model\'s effort levels; null: the CLI\'s own'),
      review: z.enum(['none', 'ok', 'good', 'very-good', 'excellent', 'perfect']).optional().describe('The review bar: none, or the score a separate critic\'s review must reach'),
    }),
    output: (z) => z.object({ model: z.string().nullable(), effort: z.string().nullable(), review: z.string(), level: z.enum(['ask', 'auto', 'unsafe']), models: z.array(z.unknown()), bars: z.array(z.unknown()) }),
    summary: (args) => {
      const set = (['model', 'effort', 'review'] as const).filter((k) => args[k] !== undefined).map((k) => `${k} ${String(args[k] ?? 'default')}`);
      return set.length === 0 ? "read Claude's settings" : `set Claude's ${set.join(', ')}`;
    },
    async run(ctx, args) {
      if (!ctx.settings) throw new ToolRefusal('Claude\'s settings are not reachable from here');
      const change: ClaudeSettingsChange = {};
      if (args.model !== undefined) change.model = args.model === 'default' ? null : (args.model as string | null);
      if (args.effort !== undefined) change.effort = args.effort as string | null;
      if (args.review !== undefined) change.review = args.review as ReviewBar;
      const reading = Object.keys(change).length === 0;
      let facts: ClaudeSettingsFacts;
      try {
        facts = reading ? ctx.settings.read() : await ctx.settings.set(change);
      } catch (err) {
        throw new ToolRefusal(`Not changed: ${(err as Error).message}`);
      }
      const now = `model ${facts.model ?? 'default'}, effort ${facts.effort ?? 'default'}, review ${facts.review}, permission level ${facts.level} (the person's)`;
      return { words: reading ? `Claude's settings: ${now}.` : `Set. Now: ${now}.`, json: facts, pretty: true };
    },
    row: (args, out) => ({ ok: !out.isError, words: reads(args) ? 'read Claude\'s settings' : 'change Claude\'s settings', detail: out.words.split('\n')[0] ?? null }),
  }),
};
