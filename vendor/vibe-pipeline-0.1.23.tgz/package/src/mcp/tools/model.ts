/**
 * The Model tab's tools (Docs/mcp.md §4's Model tab, M6): a Gladius script's model -- opened, read, its parameters set
 * (as a drag and its let go, or baked into the script), built as a preview to look at, exported, traced, its declared
 * materials changed, a bone keyed at a frame -- each through the tab's own steps where the tab's state matters (page
 * tools: `model/model-agent.ts` in the editor), each write one step of the tab's own history (its Z) and its file the
 * turn's (Undo this turn); and the assets server's own work where it does not (`model_params_get`, `model_trace`:
 * `GET params`, `POST trace`, in-process).
 *
 * Nothing at module level but the records.
 */
import type { z as Zod } from 'zod';
import type { ModelFacts, ModelParamFacts } from '../../agent/api-types.ts';
import { paramFacts } from '../../agent/model-facts.ts';
import type { TraceAnswer } from '../../assets/api-types.ts';
import { adoptOffline, assetsOf, followExports } from '../assets.ts';
import { pageTool, serverTool, ToolRefusal } from '../tool.ts';
import { plural } from '../words.ts';

/** A script's path as the model tools take it: a `.lua` under `AssetsSource/models/`. */
function scriptOf(raw: unknown): string {
  if (typeof raw !== 'string' || !/^AssetsSource\/models\/.+\.lua$/.test(raw) || raw.split('/').some((p) => p === '..' || p === '.' || p === '')) {
    throw new ToolRefusal(`${String(raw)} is no Gladius script: a model's script is AssetsSource/models/…/<name>.lua`);
  }
  return raw;
}

/** A parameter in a few words: `width 2 (default 1, set by the record)`. */
const paramLine = (p: ModelParamFacts): string => `${p.name} = ${String(p.value)}${p.set ? ` (default ${String(p.default)}, set by its record)` : ''}${p.min !== undefined || p.max !== undefined ? ` [${p.min ?? ''}..${p.max ?? ''}]` : ''}${p.choices ? ` (one of ${p.choices.join(', ')})` : ''}`;

/** The model open, in words. */
function modelWords(m: ModelFacts): string {
  const name = m.script.split('/').pop();
  const lines = [
    `${name} (${m.script}) -- ${m.buildWords}${m.error ? `: ${m.error}` : ''}${m.export ? `; its export ${m.export}` : ''}${m.previewing ? '; the views show a preview, not the export' : ''}.`,
    `${plural(m.parts.count, 'part')}${m.parts.names.length > 0 ? `: ${m.parts.names.slice(0, 24).join(', ')}${m.parts.count > 24 ? ' …' : ''}` : ''}${m.parts.selected.length > 0 ? `; selected ${m.parts.selected.join(', ')}` : ''}${m.parts.hidden.length > 0 ? `; hidden ${m.parts.hidden.join(', ')}` : ''}.`,
  ];
  if (m.params) lines.push(m.params.length === 0 ? 'No parameters.' : `Parameters: ${m.params.map(paramLine).join('; ')}.`);
  if (m.materials.length > 0) lines.push(`Materials: ${m.materials.map((x) => `${x.name}${x.declared ? '' : ' (not declared by a material{} here: not editable)'}`).join(', ')}.`);
  if (m.clips.length > 0 || m.actions.length > 0) lines.push(`Clips: ${m.clips.join(', ') || 'none in the export'}; the script's actions: ${m.actions.map((a) => `${a.name} (${a.fps} fps, keys at ${a.keys.join(', ')} s)${a.problem ? ` -- ${a.problem}` : ''}`).join('; ') || 'none'}.`);
  return lines.join('\n');
}

const FACTS = (z: typeof Zod) => z.object({ script: z.string(), export: z.string().nullable(), build: z.string(), buildWords: z.string(), error: z.string().nullable(), parts: z.object({ count: z.number() }).loose(), materials: z.array(z.unknown()), clips: z.array(z.string()), actions: z.array(z.unknown()), params: z.array(z.unknown()).nullable(), previewing: z.boolean(), history: z.unknown() });

/** A trace's summary: its steps, the costliest, the triangles kept and built. */
function traceWords(script: string, t: TraceAnswer): string {
  if (!t.ok) return `${script} did not trace: ${t.error ?? (t.missing ? `${t.missing} is not found on this machine` : 'no reason said')}${t.diagnostics.length > 0 ? `\n${t.diagnostics.slice(0, 6).map((d) => `line ${d.line ?? '?'}: ${d.message}`).join('\n')}` : ''}`;
  const costly = [...t.steps].sort((a, b) => b.triangles - a.triangles).slice(0, 8);
  return `${script}: ${plural(t.steps.length, 'step')} in ${t.ms} ms, ${t.triangles} triangles kept of ${t.total} built.${t.capped ? ` ${t.capped.dropped} steps past the cap of ${t.capped.cap} left out.` : ''}\nThe costliest: ${costly.map((s) => `#${s.index} ${s.op}${s.label ? ` "${s.label}"` : ''} ${s.triangles} tris${s.kept === false ? ' (not kept)' : ''}`).join('; ')}.`;
}

export const modelTools = {
  model_open: pageTool('model_open', {
    description: 'Open a Gladius script in the Model tab, as the Assets panel\'s Open in Model tab does (the tab brought up): `script`, a .lua under AssetsSource/models/. Answers its facts as they stand at once -- its build may be on its way (model_info again). A preview of a parameter not written is shown for the model open: refused then unless `discard: true` (which asks the person under Auto).',
    input: (z) => ({ script: z.string().min(1).max(500), discard: z.boolean().optional().describe('Put away a preview of the model open that nobody wrote') }),
    output: (z) => z.object({ model: FACTS(z), discarded: z.boolean() }),
    summary: (args) => `open ${String(args.script).split('/').pop()} in the Model tab`,
    words: (r) => ({ words: `Opened in the Model tab${r.discarded ? ' (the preview shown before put away)' : ''}.\n${modelWords(r.model)}`, json: { model: r.model, discarded: r.discarded }, pretty: true }),
    row: (r) => ({ ok: true, words: `open ${r.model.script.split('/').pop()} in the Model tab`, detail: r.model.buildWords }),
  }),

  model_info: pageTool('model_info', {
    description: 'The model open in the Model tab: its script and export, its build (ready, building, failed with Gladius\'s line), its parts (selected, hidden), its materials (as shown, and whether a material{} declares them -- only those are editable), its clips and the script\'s actions with their keys\' times, its parameters with their values (set by the record or the default), whether a preview is shown, and the tab\'s history. Null when none is open. Only reads.',
    input: () => ({}),
    output: (z) => z.object({ model: FACTS(z).nullable() }),
    summary: () => 'read the model open',
    words: (r) => ({ words: r.model ? modelWords(r.model) : 'No model is open in the Model tab: model_open opens one.', json: { model: r.model }, pretty: true }),
    row: (r) => ({ ok: true, words: 'read the model open', detail: r.model ? `${r.model.script} -- ${r.model.buildWords}` : 'none open' }),
  }),

  model_params_get: serverTool('model_params_get', {
    description: 'A Gladius script\'s parameters (its params{}, read by Gladius with no build): each one\'s type, value as the export is built, default, range or choices and doc, and whether its record sets it. `script`: a .lua under AssetsSource/models/. Only reads.',
    input: (z) => ({ script: z.string().min(1).max(500) }),
    output: (z) => z.object({ script: z.string(), params: z.array(z.unknown()).nullable(), error: z.string().nullable() }),
    summary: (args) => `read the parameters of ${String(args.script).split('/').pop()}`,
    async run(ctx, args) {
      const script = scriptOf(args.script);
      const answer = await assetsOf(ctx).call('GET params', { path: script }).catch((err: Error) => {
        throw new ToolRefusal(err.message);
      });
      const params = paramFacts(answer);
      const error = answer.ok ? null : (answer.error ?? answer.problem ?? (answer.missing ? `${answer.missing} is not found on this machine` : 'not read'));
      const words = error ? `The parameters of ${script} were not read: ${error}` : params === null ? `${script}: this Gladius says no parameters (older than 0.6?).` : params.length === 0 ? `${script} declares no parameters.` : `${script}'s parameters:\n${params.map(paramLine).join('\n')}`;
      return { words, json: { script, params, error }, ...(error ? { isError: true } : {}) };
    },
    row: (args, out) => ({ ok: !out.isError, words: `read the parameters of ${String(args.script).split('/').pop()}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  model_params_set: pageTool('model_params_set', {
    description: 'Set parameters of the model open in the Model tab, as its Parameters block does: built as a preview and shown, then written to the script\'s record (`<name>.export.json`\'s params: the script\'s own text untouched) and exported once -- one step of the tab\'s history (its Z). `values`: name to value as text ("2.5", "true", "oak"); null puts one back to its default. `bake: true` writes the values into the script\'s params{} defaults instead and clears their overrides, as the block\'s Bake -- one step. Refused for a name the script does not declare, or a value its type refuses.',
    input: (z) => ({
      values: z.record(z.string(), z.union([z.string().max(500), z.number(), z.boolean(), z.null()])).describe('Parameter names to values; null: back to the default'),
      bake: z.boolean().optional().describe('Into the script\'s defaults (the Bake), not the record'),
    }),
    output: (z) => z.object({ step: z.string(), baked: z.array(z.string()), skipped: z.array(z.string()), params: z.array(z.unknown()).nullable(), files: z.array(z.string()) }),
    summary: (args) => `${args.bake === true ? 'bake' : 'set'} ${plural(Object.keys((args.values ?? {}) as object).length, 'parameter')}`,
    words: (r) => ({
      words: `${r.step}: written ${r.baked.length > 0 ? 'into the script\'s params{}' : 'to its record'}, one step of the Model tab's history (Z there takes it back); the export follows.${r.skipped.length > 0 ? ` Not baked: ${r.skipped.join(', ')}.` : ''}${r.params ? `\nNow: ${r.params.map(paramLine).join('; ')}.` : ''}`,
      json: { step: r.step, baked: r.baked, skipped: r.skipped, params: r.params, files: r.files },
    }),
    row: (r) => ({ ok: true, words: r.step, detail: r.files.join(', ') }),
  }),

  model_preview: pageTool('model_preview', {
    description: 'Look at the model open built at other parameter values, nothing written: a preview build (as a drag of the Parameters block builds one) shown in the Model tab\'s views, its image answered (as view_shot\'s model target), then the export shown again. `values`: name to value as text; none: the script as it is. Answers the image, or why it did not build.',
    input: (z) => ({
      values: z.record(z.string(), z.union([z.string().max(500), z.number(), z.boolean()])).optional(),
      width: z.number().int().min(16).max(2048).optional(),
      format: z.enum(['webp', 'png']).optional(),
    }),
    output: (z) => z.object({ params: z.record(z.string(), z.string()), width: z.number(), height: z.number(), mimeType: z.string(), notes: z.array(z.string()) }),
    summary: (args) => `preview the model${args.values ? ` at ${plural(Object.keys(args.values as object).length, 'value')}` : ''}`,
    words: (r) => ({
      words: `A preview build${Object.keys(r.params).length > 0 ? ` at ${Object.entries(r.params).map(([k, v]) => `${k}=${v}`).join(', ')}` : ''}, ${r.width}×${r.height}: nothing written, the export shown again.${r.notes.length > 0 ? ` ${r.notes.join(' ')}` : ''}`,
      json: { params: r.params, width: r.width, height: r.height, mimeType: r.mimeType, notes: r.notes },
      images: [{ data: r.data, mimeType: r.mimeType }],
    }),
    row: (r) => ({ ok: true, words: 'preview the model', detail: `${r.width}×${r.height}` }),
  }),

  model_export: pageTool('model_export', {
    description: 'Export the model open now, as the Model tab\'s Build: the script built by Gladius into its .glb (current or not). A job: answered when it ends within 20 s, else with the job\'s id for job_wait. The tab\'s banner shows it.',
    input: () => ({}),
    output: (z) => z.object({ script: z.string(), jobs: z.array(z.object({ id: z.string(), source: z.string() })), job: z.string().nullable() }).loose(),
    summary: () => 'export the model open',
    settle: async (ctx, r) => {
      if (r.jobs.length === 0 || !ctx.assets?.()) return r;
      const f = await followExports(ctx, { tool: 'asset_export', jobs: r.jobs, job: null, via: 'panel', step: null, files: [] });
      return { ...r, job: f.job, ...(f.ended ? { ended: f.ended } : {}) };
    },
    words: (r) => ({
      words: r.ended
        ? r.ended.map((e) => `${e.source}: ${e.state}${e.error ? ` -- ${e.error}` : ''}`).join('\n')
        : r.jobs.length === 0 ? `${r.script}: nothing was queued (exported already, or held for a Claude turn: it is built as the turn ends).` : `${r.script} is being exported: job ${r.job ?? '?'} -- job_wait waits for it.`,
      json: { script: r.script, jobs: r.jobs, job: r.job, ...(r.ended ? { ended: r.ended } : {}) },
    }),
    row: (r) => ({ ok: true, words: `export ${r.script.split('/').pop()}`, detail: r.ended ? r.ended.map((e) => e.state).join(', ') : `job ${r.job ?? 'none'}` }),
  }),

  model_trace: serverTool('model_trace', {
    description: 'Trace a Gladius script\'s build, as the Model tab\'s Build trace: the script replayed op by op at its export\'s parameters, answered as a summary -- its steps, the triangles each kept, the costliest, and a failed build\'s lines. `script`: a .lua under AssetsSource/models/. Only reads (the trace is the cache\'s).',
    input: (z) => ({ script: z.string().min(1).max(500), steps: z.boolean().optional().describe('Every step in the JSON, not only the costliest') }),
    output: (z) => z.object({ script: z.string(), ok: z.boolean(), steps: z.array(z.unknown()), triangles: z.number(), total: z.number(), ms: z.number() }).loose(),
    summary: (args) => `trace the build of ${String(args.script).split('/').pop()}`,
    async run(ctx, args) {
      const script = scriptOf(args.script);
      const t = await assetsOf(ctx).call('POST trace', { path: script }).catch((err: Error) => {
        throw new ToolRefusal(err.message);
      });
      if (t.superseded) throw new ToolRefusal(`A newer trace of ${script} was asked for meanwhile: ask again`);
      const steps = args.steps === true ? t.steps : [...t.steps].sort((a, b) => b.triangles - a.triangles).slice(0, 20);
      return { words: traceWords(script, t), json: { script, ok: t.ok, steps, triangles: t.triangles, total: t.total, ms: t.ms, count: t.steps.length, diagnostics: t.diagnostics, ...(t.error ? { error: t.error } : {}) }, ...(t.ok ? {} : { isError: true }) };
    },
    row: (args, out) => ({ ok: !out.isError, words: `trace the build of ${String(args.script).split('/').pop()}`, detail: out.words.split('\n')[0] ?? null }),
  }),

  model_materials_set: pageTool('model_materials_set', {
    description: 'Change a material the model open\'s script declares (`material{ name = … }`), as the Materials block does: its fields written into that call -- one step of the Model tab\'s history -- then exported. `fields`: base_color and emissive as [r, g, b] linear 0..1, metallic, roughness, alpha_cutoff numbers, alpha_mode OPAQUE/MASK/BLEND, texture and the other maps an image\'s path beside the script, texture_filter, texture_wrap, compress words; null takes a field out. A material made some other way (an import) is refused.',
    input: (z) => ({
      material: z.string().min(1).max(200),
      fields: z.record(z.string(), z.union([z.number(), z.string().max(500), z.tuple([z.number(), z.number(), z.number()]), z.null()])),
    }),
    output: (z) => z.object({ step: z.string(), material: z.string(), files: z.array(z.string()) }),
    summary: (args) => `change the material ${String(args.material)}`,
    words: (r) => ({ words: `${r.step}: written into the script's material{}, one step of the Model tab's history (Z there takes it back); the export follows.`, json: { step: r.step, material: r.material, files: r.files } }),
    row: (r) => ({ ok: true, words: `change the material ${r.material}`, detail: r.step }),
  }),

  model_pose: pageTool('model_pose', {
    description: 'Key a bone\'s pose into the model open\'s script, as K does: the joint(s) at `time` (seconds) or `frame` of `clip` (an action{} the script declares) written into that key -- made if there is none, merged if there is -- one step of the Model tab\'s history, then exported. `joints`: name (as the script spells it; a rig\'s prefix may be left off) to { forward, left, twist } in degrees from rest (Gladius\'s readable trio) and/or translate [x, y, z] metres from rest. A key whose pose is an expression, a rest key, or a joint the key spells with rotate or orient is refused, saying so.',
    input: (z) => ({
      clip: z.string().min(1).max(200),
      time: z.number().min(0).optional(),
      frame: z.number().int().min(0).optional(),
      joints: z.record(z.string(), z.object({ forward: z.number().optional(), left: z.number().optional(), twist: z.number().optional(), translate: z.tuple([z.number(), z.number(), z.number()]).optional() })),
    }),
    output: (z) => z.object({ step: z.string(), note: z.string(), clip: z.string(), time: z.number(), files: z.array(z.string()) }),
    summary: (args) => `key ${Object.keys((args.joints ?? {}) as object).join(', ') || 'a pose'} in ${String(args.clip)}`,
    words: (r) => ({ words: `${r.step} -- ${r.note}: written into the script's action{} "${r.clip}" at ${r.time} s, one step of the Model tab's history (Z there takes it back); the export follows.`, json: { step: r.step, note: r.note, clip: r.clip, time: r.time, files: r.files } }),
    row: (r) => ({ ok: true, words: r.step, detail: r.note }),
  }),

  model_adopt: pageTool('model_adopt', {
    description: 'Make a Gladius script for a model file, as the Assets panel\'s and the Model tab\'s Make a script for it: `path` a .glb delivered as it is under src/assets/models/ (no source of its own) -- a script <stem>.lua written in its AssetsSource/models/ twin folder, importing a copy of the file beside it (parts, colours, skin and clips kept), and built as that model\'s export: the key unchanged, so every prefab and scene naming it keeps it. Then model_open opens the script, and the gladius skill changes it. With the studio open, one step in the Assets panel\'s history (Z there takes the script away and puts the file back), answered once its build ends; with none, the dev server writes it and queues the build (Undo this turn).',
    input: (z) => ({ path: z.string().min(1).max(500).describe('The model file: src/assets/models/props/crate.glb') }),
    output: (z) => z.object({ path: z.string(), script: z.string(), copied: z.string().nullable(), built: z.string().nullable(), via: z.string() }).loose(),
    summary: (args) => `make a script for ${String(args.path)}`,
    offline: (ctx, args) => adoptOffline(assetsOf(ctx), args),
    words: (r) => ({
      words: `${r.script} imports ${r.copied ?? 'the file'}${r.decoded.length > 0 ? ` (${r.decoded.join(', ')} decoded)` : ''} and is ${r.path}'s source now${r.built === 'done' ? ', built over it' : r.built === 'failed' ? '; its build failed: asset_info on the script says why' : r.jobs.length > 0 ? '; its build queued (asset_info, or asset_export\'s job_wait, says how it went)' : ''}. model_open opens it.${r.via === 'panel' ? (r.step !== null ? ` One step in the Assets panel's history, "${r.step}": Z there undoes it.` : '') : ' No studio tab: the dev server did it -- Undo this turn takes it back.'}`,
      json: { path: r.path, script: r.script, copied: r.copied, built: r.built, jobs: r.jobs, via: r.via, step: r.step, files: r.files },
    }),
    row: (r) => ({ ok: true, words: `make a script for ${r.path}`, detail: `${r.script}${r.built === 'failed' ? ' · its build failed' : ''}` }),
  }),
};
