/**
 * Terminal runs' tokens (Docs/terminal.md D6): a conversation handed to the `claude` CLI in a terminal reaches the studio's
 * MCP server at `/__mcp` with a token of its own, made as the run starts and revoked as it ends -- never the outside
 * clients' token, and never their level: the run is the person's own conversation, served the column's list (`http.ts`).
 *
 * 32 random bytes each, URL-safe base64, compared in constant time (`tokenMatches`). One a conversation: a new run of it
 * replaces the last. Held in memory (on the agent's holder, so an in-process restart keeps them with the terminals);
 * a new process, none -- its terminals went with the old one.
 *
 * Node only. Nothing at module level.
 */
import { newToken, tokenMatches } from './token.ts';

export interface Runs {
  /** A new token for `conversation`'s run: the one before it revoked. */
  issue(conversation: string): string;
  /** The run's token revoked: its sessions are refused from the next request (`http.ts` closes them). */
  revoke(conversation: string): void;
  /** A run's token read back after a restart (Docs/terminal.md D5): held for `conversation` again; false for one that is no token. */
  adopt(conversation: string, token: string): boolean;
  /** The conversation whose run holds `token`, or null. */
  find(token: string): string | null;
  /** Told of each revocation: `http.ts` closes the run's MCP sessions. Returns the undo. */
  onRevoke(fn: (conversation: string) => void): () => void;
}

export function createRuns(): Runs {
  const tokens = new Map<string, string>();
  const told = new Set<(conversation: string) => void>();
  const revoke = (conversation: string): void => {
    if (!tokens.delete(conversation)) return;
    for (const fn of told) fn(conversation);
  };
  return {
    issue(conversation) {
      revoke(conversation);
      const token = newToken();
      tokens.set(conversation, token);
      return token;
    },
    revoke,
    adopt(conversation, token) {
      if (!/^[A-Za-z0-9_-]{43}$/.test(token)) return false;
      tokens.set(conversation, token);
      return true;
    },
    find(token) {
      for (const [conversation, held] of tokens) if (tokenMatches(token, held)) return conversation;
      return null;
    },
    onRevoke(fn) {
      told.add(fn);
      return () => void told.delete(fn);
    },
  };
}
