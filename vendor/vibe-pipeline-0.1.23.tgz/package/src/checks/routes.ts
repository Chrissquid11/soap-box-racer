/**
 * Every debug key and button goes through MrDebug (CLAUDE.md): the source read, and anything else
 * that listens for keys or makes a debug button named -- over the project's `src/` and each extra
 * root (`packages`: the workspace passes the engine's and the editor's `src/`; a project passes none,
 * and the rules hold for its own code). Was the sandbox's `src/debug/routes.test.ts`.
 *
 * - **no key listener** but MrDebug's (`@vibe/engine/debug/mr-debug.ts`), the game's input
 *   (`@vibe/engine/input/devices.ts`, stamped for the loop) and the page's pause keys
 *   (`@vibe/engine/boot.ts`); and in those but MrDebug, **no key checked under a debug flag** -- a
 *   debug key belongs to MrDebug;
 * - **no lil-gui button** (`.add({ go: () => ... }, 'go')`) but the panel's (`@vibe/editor/panel.ts`),
 *   and each of those runs a MrDebug action (`MrDebug.run(`);
 * - **no `prompt`, `confirm` or `alert`** in the editor (a question is a line in its panel, `ask.ts`):
 *   they stop the page, and the game and any automation driving it with it;
 * - **no module imports a `DEBUG` flag**: the bundler does not fold an imported constant, so the branch
 *   would ship in a release; each writes `const DEBUG = DEBUG_BUILD && MrDebug.on` itself.
 *
 * The allowances name files by identity (`source.ts`' `identify`): the engine's and the editor's as the
 * project resolves them, so a project's own `src/boot.ts` or `src/panel.ts` is held to every rule.
 * A tripwire, not a proof: it catches the usual ways, by pattern.
 */
import { join } from 'node:path';
import { lineAt, packageRoots, packageSources, readSources, sorted, type Check, type CheckFinding } from './source.ts';

/** Who may listen for keys at all, and why, by identity. */
export const KEY_LISTENERS: Readonly<Record<string, string>> = {
  '@vibe/engine/debug/mr-debug.ts': 'MrDebug: the one debug key listener',
  '@vibe/engine/input/devices.ts': "the game's input, into the loop",
  '@vibe/engine/boot.ts': "the game's own pause keys (a project's page, booted)",
};
/** The one file that makes debug buttons, from MrDebug's list. */
export const PANEL = '@vibe/editor/panel.ts';

export const KEY_LISTENER = /addEventListener\(\s*['"`]key(down|up|press)['"`]|\.onkey(down|up|press)\s*=/;
/** A key handled under a debug flag. */
export const DEBUG_KEY = (line: string): boolean => /\bDEBUG\w*\b/.test(line) && /\.(code|key)\b\s*===?/.test(line);
/**
 * A lil-gui button: a function on an object handed to `.add` with the name of that property --
 * `.add({ go: () => ... }, 'go')`. (`MrDebug.add({...})` takes one object and no name: not a button, the way to make one.)
 */
export const GUI_BUTTON = /\.add\(\s*\{[^}]*(=>|\bfunction\b)[^}]*\}\s*,\s*['"`]/;
/** The browser's own dialogs, called (`ask.confirm(x)` is a method of something else). */
export const DIALOG = /(?:^|[^\w$.])(?:(?:window|globalThis)\s*\.\s*)?(?:prompt|confirm|alert)\(/;
export const IMPORTED_DEBUG = /import\s*\{[^}]*\bDEBUG\b[^}]*\}\s*from/g;

const FIX = {
  listener: 'a debug key is a MrDebug action (MrDebug.add({ name, key, help, run })), a game key comes through the input (devices.ts, stamped for the loop)',
  debugKey: 'a key checked under a debug flag is a debug key: make it a MrDebug action',
  button: 'register the action with MrDebug.add({ name, help, run }): the panel makes its button',
  panelButton: "the panel's buttons run MrDebug's actions: .add({ run: () => MrDebug.run(action.name) }, 'run')",
  dialog: "a question in the editor is a line in its panel (ask.ts): prompt, confirm and alert stop the page",
  importedDebug: 'write `const DEBUG = DEBUG_BUILD && MrDebug.on;` in this module: an imported constant is not folded, and the branch would ship in a release',
};

export const checkRoutes: Check = async (options) => {
  const { root } = options;
  const known = packageSources(root);
  const files = await readSources(root, [join(root, 'src'), ...packageRoots(options)], known);
  const findings: CheckFinding[] = [];
  for (const { name, id, text } of files) {
    const allowed = id !== undefined && id in KEY_LISTENERS;
    const editor = id?.startsWith('@vibe/editor/') ?? false;
    text.split('\n').forEach((line, i) => {
      const at = (rule: string, fix: string): void => void findings.push({ file: name, line: i + 1, rule, fix, text: line.trim() });
      if (!allowed && KEY_LISTENER.test(line)) at('key listener', FIX.listener);
      if (allowed && id !== '@vibe/engine/debug/mr-debug.ts' && DEBUG_KEY(line)) at('debug key', FIX.debugKey);
      if (GUI_BUTTON.test(line)) {
        if (id !== PANEL) at('debug button', FIX.button);
        else if (!line.includes('MrDebug.run(')) at('debug button', FIX.panelButton);
      }
      if (editor) {
        const code = line.trim();
        // Comments say why not; only code calls.
        if (!(code.startsWith('*') || code.startsWith('//') || code.startsWith('/*')) && DIALOG.test(line.replace(/\/\/.*$/, ''))) at('browser dialog', FIX.dialog);
      }
    });
    for (const m of text.matchAll(IMPORTED_DEBUG)) {
      findings.push({ file: name, line: lineAt(text, m.index), rule: 'imported DEBUG', fix: FIX.importedDebug, text: m[0].replace(/\s+/g, ' ') });
    }
  }
  return sorted(findings);
};
