/**
 * A project's debug keys never take the editor's (Docs/studio.md, "Keys"): every `MrDebug.add` of the project's
 * `src/` and of each extra root (the workspace passes the engine's `src/`; the editor's own files are passed by), read
 * from the source, its keys held to the editor's table -- `EDITOR_KEYS` in the installed editor's
 * `src/editor-keys.ts`, read as text, one `'<name>': [<keys>],` a line (node strips no types under `node_modules`, as
 * the `skills` check's tab list) -- and under each keymap the editor has (Docs/navigation.md §8: `INDUSTRY_KEYS`'
 * entries in place of `EDITOR_KEYS`' for Industry Compatible's, the default), a clash under either a clash, the finding
 * naming the keymap. A key is compared as MrDebug compares it (`keysOf`: `Ctrl` is `Mod` off a Mac), on a
 * Mac and off one.
 *
 * - **A game's action with no `when`** on a key the editor takes outside a field is a **finding**: in studio mode
 *   the editor's action goes without that key (`editor-keys.ts`' `giveWay`, a `keys` notice) -- the walk's left off,
 *   say, while the game's Shift+A holds it. Its fix: another key, or a `when`.
 * - **One with a `when`** is a **note**, said and never failed: MrDebug takes the first live action on a key, the
 *   game's (registered first), so while its `when` holds it has the key in the editor too -- which may be meant.
 * - A field's own key (`field:`) never meets the page's, and is passed by; so is a key that is no literal.
 *
 * A tripwire, not a proof, as `routes` is: an object read by pattern, the editor's table as the editor keeps it
 * (`addKey` says a key of its own the table lacks). Pure but for reading files.
 */
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { keysOf } from '@vibe/engine/debug-keys';
import { codeOnly } from './mcp.ts';
import { lineAt, packageRoots, packageSources, readSources, sorted, type Check, type CheckFinding } from './source.ts';

/** The editor's key table, in its `src/`. */
export const KEYS_FILE = 'editor-keys.ts';

/**
 * The editor's keys from `editor-keys.ts`' text: each `'<name>': [<keys>],` line of its `EDITOR_KEYS` -- or of another
 * table of the same form, `INDUSTRY_KEYS` (Industry Compatible's changes, Docs/navigation.md §8). Empty for a text
 * without one.
 */
export function editorKeys(text: string, table = 'EDITOR_KEYS'): Map<string, string[]> {
  const out = new Map<string, string[]>();
  const lines = text.split('\n');
  const start = lines.findIndex((line) => new RegExp(`\\b${table}\\b.*=\\s*\\{`).test(line));
  if (start < 0) return out;
  for (let i = start + 1; i < lines.length && !/^\s*\}/.test(lines[i]!); i++) {
    const m = /^\s*'([^']+)'\s*:\s*\[(.*)\],?\s*$/.exec(lines[i]!);
    if (m) out.set(m[1]!, [...m[2]!.matchAll(/'([^']+)'/g)].map((k) => k[1]!));
  }
  return out;
}

/** A `MrDebug.add` as read from the source: its name and keys where literal, whether it has a `when` or a `field`. */
export interface ReadAction {
  name: string;
  keys: string[];
  when: boolean;
  field: boolean;
  /** Where `MrDebug.add(` stands in the text. */
  at: number;
}

/** The object handed to the call opening at `from` (just past its `(`): up to its matching `)`, strings skipped. */
function argument(code: string, from: number): string {
  let depth = 1;
  for (let i = from; i < code.length; i++) {
    const c = code[i]!;
    if (c === "'" || c === '"' || c === '`') {
      for (i++; i < code.length && code[i] !== c; i++) if (code[i] === '\\') i++;
    } else if (c === '(' || c === '{' || c === '[') depth++;
    else if (c === ')' || c === '}' || c === ']') {
      if (--depth === 0) return code.slice(from, i);
    }
  }
  return code.slice(from);
}

/** Every `MrDebug.add(...)` of a source with a key written as a string or a list of them -- comments blanked first (`codeOnly`). */
export function readActions(text: string): ReadAction[] {
  const code = codeOnly(text);
  const out: ReadAction[] = [];
  for (const m of code.matchAll(/\bMrDebug\.add\(/g)) {
    const arg = argument(code, m.index + m[0].length);
    const name = /\bname\s*:\s*(['"])((?:(?!\1).)*)\1/.exec(arg)?.[2];
    const key = /\bkey\s*:\s*(?:(['"])((?:(?!\1).)*)\1|\[([^\]]*)\])/.exec(arg);
    if (name === undefined || !key) continue;
    const keys = key[2] !== undefined ? [key[2]] : [...key[3]!.matchAll(/(['"])((?:(?!\1).)*)\1/g)].map((k) => k[2]!);
    if (keys.length === 0) continue;
    out.push({ name, keys, when: /\bwhen\s*:/.test(arg), field: /\bfield\s*:/.test(arg), at: m.index });
  }
  return out;
}

/** The editor's two keymaps (Docs/navigation.md §8), as a finding names them. */
export const KEYMAP_WORDS = { industry: 'Industry Compatible', blender: 'Blender' } as const;

/**
 * The editor's keys under each keymap from `editor-keys.ts`' text: Blender's, `EDITOR_KEYS` as written; Industry
 * Compatible's, `EDITOR_KEYS` with `INDUSTRY_KEYS`' entries in place (an editor from before it: Blender's alone).
 */
export function keymaps(text: string): { keymap: keyof typeof KEYMAP_WORDS; keys: Map<string, string[]> }[] {
  const blender = editorKeys(text);
  const industry = editorKeys(text, 'INDUSTRY_KEYS');
  if (industry.size === 0) return [{ keymap: 'blender', keys: blender }];
  return [{ keymap: 'industry', keys: new Map([...blender, ...industry]) }, { keymap: 'blender', keys: blender }];
}

/** The editor's actions a game's `keys` take under any keymap: each name, the keys shared, and the keymaps it is under. */
export function clashesOf(keys: readonly string[], maps: ReturnType<typeof keymaps>): { name: string; keys: string[]; under: (keyof typeof KEYMAP_WORDS)[] }[] {
  const out = new Map<string, { name: string; keys: string[]; under: (keyof typeof KEYMAP_WORDS)[] }>();
  for (const { keymap, keys: table } of maps) {
    for (const [name, theirs] of table) {
      const shared = sharedKeys(keys, theirs);
      if (shared.length === 0) continue;
      const one = out.get(name) ?? { name, keys: [], under: [] };
      for (const k of shared) if (!one.keys.includes(k)) one.keys.push(k);
      one.under.push(keymap);
      out.set(name, one);
    }
  }
  return [...out.values()];
}

/** Which keymaps, in a finding's words: none said when there is one map, or a clash is under every one. */
const underWords = (under: readonly (keyof typeof KEYMAP_WORDS)[], all: number): string =>
  under.length === all ? (all > 1 ? ' (under both keymaps)' : '') : ` (under ${under.map((k) => KEYMAP_WORDS[k]).join(' and ')})`;

/** The keys of `a` and `b` that are one key, as MrDebug reads them on a Mac or off one -- each in MrDebug's form (`keysOf`), once. */
export function sharedKeys(a: readonly string[], b: readonly string[]): string[] {
  const out = new Set<string>();
  for (const mac of [true, false]) {
    let mine: string[];
    let theirs: string[];
    try {
      mine = keysOf({ key: a }, mac);
      theirs = keysOf({ key: b }, mac);
    } catch {
      // A chord MrDebug cannot read: its own throw says so as it is added.
      return [];
    }
    for (const key of mine) if (theirs.includes(key)) out.add(key);
  }
  return [...out];
}

export const checkKeys: Check = async (options) => {
  const { root } = options;
  const known = packageSources(root);
  if (known.editor === undefined) return [];
  const table = join(known.editor, KEYS_FILE);
  // An editor without the table (one from before it): nothing to hold the keys to.
  if (!existsSync(table)) return [];
  // Under either keymap: a person may switch at any time (Docs/navigation.md D14).
  const maps = keymaps(readFileSync(table, 'utf8'));
  const files = await readSources(root, [join(root, 'src'), ...packageRoots(options)], known);
  const findings: CheckFinding[] = [];
  for (const { name: file, id, text } of files) {
    // The editor's own keys give way by themselves; its MrDebug calls are its own.
    if (id?.startsWith('@vibe/editor/')) continue;
    for (const action of readActions(text)) {
      if (action.field) continue;
      const line = lineAt(text, action.at);
      const clashes = clashesOf(action.keys, maps);
      if (clashes.length === 0) continue;
      const keys = [...new Set(clashes.flatMap((c) => c.keys))].join(', ');
      const theirs = clashes.map((c) => `'${c.name}'${underWords(c.under, maps.length)}`).join(', ');
      if (action.when) {
        options.note?.(`keys: ${file}:${line} '${action.name}' (${keys}, with a when) shares a key with the editor's ${theirs}: while its when holds it is the game's, in the editor too`);
        continue;
      }
      findings.push({
        file,
        line,
        rule: `keys: the debug action '${action.name}' always takes ${keys}, which the editor's ${theirs} take${clashes.length === 1 ? 's' : ''}: in studio mode the editor's go${clashes.length === 1 ? 'es' : ''} without it`,
        fix: "give it a key the editor has not (the keys card, ?, lists them), or a `when` -- MrDebug.add({ name, key, when, help, run })",
        text: text.split('\n')[line - 1]!.trim(),
      });
    }
  }
  return sorted(findings);
};
