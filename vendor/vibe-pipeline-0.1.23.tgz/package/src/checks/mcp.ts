/**
 * Every studio feature comes with its MCP tool (Docs/skills.md §2 rule 7, §9 S2): each action a person has in the
 * editor says which studio tool does the same, `ui` (it changes only the editor's own view), or why none does. Where
 * the action is made through the editor's declaration points -- `button`, `iconButton` and `control` (their first
 * argument), a menu entry (`MenuItem.mcp`), a tool's key (`ToolKey.mcp`), a notice's action -- the typecheck holds it,
 * and in the editor a none must be an entry of `mcp/gaps.ts` (`declare.ts`' `Mcp`). This check holds the rest, from
 * the code -- its comments blanked first, outside strings, template literals and regular expressions (`codeOnly`), so
 * a `//` in a URL hides nothing:
 *
 * - **A button made raw** -- `el`, `make` or `createElement` of `'button'`, a `<button` in markup (a string) --
 *   anywhere but the engine's files and the helpers themselves (`@vibe/editor/dom.ts`, which take the `mcp` argument);
 * - in the studio (the editor's files and a project's tool folders, `vibe({ tools })`; the template's are a
 *   project's): **a `MrDebug.add`**, a key or a button that does not go through `ctx.keys.add`; **a click given to an
 *   element** -- a `click`, `dblclick` or `auxclick` listener (`addEventListener`, or `x[method]('click', …)`) on
 *   anything but the page itself (`window`, `document`) and an element the file declares by `button`, `iconButton` or
 *   `control` (wrapped or not: `letGo(control(…))`) or marks where it is made; **an `onclick`** (a property, markup,
 *   a maker's field); **an element with the role of a button**; **an element whose tag is no literal**
 *   (`createElement(tag)`), which could be any of them;
 * - in the editor: **`projectNone(`** outside `mcp/declare.ts` -- the editor's nones are its gap list's;
 *
 * each carries `// mcp: <tool>` (or several, `a, b`), `// mcp: ui` or `// mcp: none: <why>` on its line or the line
 * above -- words after ` -- ` are the reader's -- or, at a funnel whose argument carries its own declaration (the
 * editor's `addKey`, `letGo`, the Debugger page's `make`), `// mcp: typed: <where>`. A tool is one of the catalogue's
 * (`../mcp/catalog.ts`) or a project's own, `project_<name>`. In the editor a `none` names its entry of
 * `mcp/gaps.ts` -- `none: GAPS.<key>` or `NOT_FOR_CLAUDE.<key>` -- so every gap is one line of Docs/skills.md §9; a
 * project's says why.
 *
 * A tripwire, not a proof, as `routes` is. **Open, and said so**: a field's own control (an input, a select, a
 * checkbox: their `change` and `input`), a press heard as `pointerdown` or `mousedown` (a drag, a pick in the
 * viewport), a drop, a key handled by a field, a click listener on what a call returns (`make().addEventListener`)
 * or added by a helper of another name, and a control another library makes -- most of them a tool's already
 * (`scene_set`, `asset_options`, `scene_reparent`), the rest a review's to find. Not read at all: the launcher
 * (`@vibe/studio`'s project picker, outside every project's studio) and the app's shell.
 */
import { existsSync, readFileSync } from 'node:fs';
import { join, resolve, sep } from 'node:path';
import { projectOptions, toolDirs } from '../assets/project-kinds.ts';
import { CATALOG } from '../mcp/catalog.ts';
import { packageRoots, packageSources, readSources, sorted, type Check, type CheckFinding } from './source.ts';

/** A raw clickable control: a button element made by hand, or in markup. */
export const RAW_BUTTON = /\b(?:el|make|createElement)\(\s*['"`]button['"`]|<button\b/;
/** A MrDebug action made directly: in the studio, a key or a button of its own. */
export const MRDEBUG_ADD = /\bMrDebug\.add\(/;
/** The marker: `// mcp: …` at a line's end, or alone on the line above. */
export const MARKER = /\/\/\s*mcp:\s*(.*?)\s*$/;

/**
 * The marker on `source`'s line, or null -- only in a comment: a `//` that `codeOnly` blanked in `code`'s line (the
 * same columns), never one inside a string, a template literal or a regular expression (`` `// mcp: ui` `` is text).
 */
export function markerOn(source: string, code: string | undefined): RegExpExecArray | null {
  for (let at = source.indexOf('//'); at >= 0; at = source.indexOf('//', at + 1)) {
    if (code !== undefined && code[at] !== ' ') continue;
    const m = MARKER.exec(source.slice(at));
    if (m && m.index === 0) return m;
  }
  return null;
}

/** The marker declaring line `i`: on it, or alone on the line above -- each only in a comment (`markerOn`). */
export function markerFor(source: readonly string[], code: readonly string[], i: number): { marker: RegExpExecArray; above: boolean } | null {
  const own = markerOn(source[i]!, code[i]);
  if (own) return { marker: own, above: false };
  const above = i > 0 && source[i - 1]!.trim().startsWith('//') ? markerOn(source[i - 1]!, code[i - 1]) : null;
  return above ? { marker: above, above: true } : null;
}

/** A click given to an element: a `click`, `dblclick` or `auxclick` listener (`addEventListener`, or a method named by a variable, `x[method]('click', …)`). */
export const CLICK_LISTENER = /(?:\.addEventListener|\])\(\s*['"`](?:click|dblclick|auxclick)['"`]/;
/** A click as a property or an attribute: `x.onclick = …`, `onclick=` in markup, `onclick: …` handed to a maker. */
export const ONCLICK = /\bon(?:dbl)?click\b\s*[:=]/;
/** An element made a button by its role: `role="button"`, `role: 'button'`, `setAttribute('role', 'button')`, `.role = 'button'`. */
export const ROLE_BUTTON = /\brole['"`]?\s*(?:[:=]|,)\s*['"`]button['"`]/;
/** An element whose tag is no literal: `createElement(tag)`, which may be a button the patterns above never see. */
export const VARIABLE_TAG = /\bcreateElement\(\s*(?!['"`]|\))/;
/** What a listener's receiver may be that is no control: the page itself. */
const NO_CONTROL = new Set(['window', 'document', 'globalThis', 'body', 'documentElement']);
/** The helpers that make a declared control (`dom.ts`): a listener on what one made is declared already. */
const DECLARED_BY = /^[\s(]*(?:[\w$]+\s*=\s*)?(?:[\w$.]+\()*(?:[\w$]+\.)?(?:button|iconButton|control)\(/;

/**
 * The element a click listener is added to, by name (the last of `a.b.c.addEventListener`, `x` of `x[m](`), and
 * whether that name is declared in the file already -- the nearest `const|let|var <name> = …` above the line made by
 * `button(`, `iconButton(` or `control(` (wrapped in a call or not: `letGo(control(…))`), or marked `// mcp: …` on
 * its line or the one above (a raw button declared where it is made). `code` is the file's code (`codeOnly`), `source`
 * its text, for the markers. Undefined when the receiver is no name (a call's result).
 */
export function clickReceiver(code: readonly string[], at: number, source: readonly string[] = code): { name: string; declared: boolean } | undefined {
  const lines = code;
  const m = /([\w$]+)\s*\??\s*(?:\.addEventListener|\[[^\]]*\])\(\s*['"`](?:click|dblclick|auxclick)/.exec(lines[at]!);
  if (!m) return undefined;
  const name = m[1]!;
  const decl = new RegExp(`\\b(?:const|let|var)\\s+${name.replace(/\$/g, '\\$')}\\b(?:\\s*:[^=]+)?\\s*=\\s*(.*)$`);
  for (let i = at; i >= 0; i--) {
    const d = decl.exec(lines[i]!);
    if (d) return { name, declared: DECLARED_BY.test(d[1]!) || markerFor(source, source === code ? [] : code, i) !== null };
  }
  return { name, declared: false };
}

/** The helpers that take the declaration as an argument: their own raw button is the caller's to declare. */
export const HELPERS = new Set(['@vibe/editor/dom.ts']);

const TOOLS: ReadonlySet<string> = new Set(CATALOG.map((m) => m.name));
const PROJECT_TOOL = /^project_[a-z][a-z0-9]*(?:_[a-z0-9]+)*$/;

/**
 * What is wrong with a marker's declaration, or null: `ui`, `typed: <where>`, `none: <why>`, or tool names. `gaps`:
 * the editor's `mcp/gaps.ts` keys (`GAPS.x`, `NOT_FOR_CLAUDE.x`) a `none` must name; null, any why.
 */
export function declarationProblem(given: string, gaps: ReadonlySet<string> | null = null): string | null {
  const none = /^none\s*:\s*(.*)$/.exec(given);
  if (none) {
    const why = none[1]!.trim();
    if (gaps === null) return why.length >= 3 ? null : 'none says why: `// mcp: none: <what a person does here that no tool does>`';
    const key = /^((?:GAPS|NOT_FOR_CLAUDE)\.\w+)\b/.exec(why)?.[1];
    return key !== undefined && gaps.has(key) ? null : `none names its entry of the editor's mcp/gaps.ts -- \`none: GAPS.<key>\` or \`NOT_FOR_CLAUDE.<key>\`${key !== undefined ? `: ${key} is none of them` : ''}`;
  }
  const decl = given.split(' -- ')[0]!.trim();
  if (decl === 'ui') return null;
  const typed = /^typed\s*:\s*(.*)$/.exec(decl);
  if (typed) return typed[1]!.trim().length >= 3 ? null : 'typed says where: `// mcp: typed: <the typed argument that carries it>`';
  if (decl === '') return 'no declaration after `mcp:`';
  const names = decl.split(/[\s,|]+/).filter((n) => n !== '');
  const bad = names.filter((n) => !TOOLS.has(n) && !PROJECT_TOOL.test(n));
  return bad.length === 0 ? null : `${bad.join(', ')} ${bad.length === 1 ? 'is' : 'are'} no studio MCP tool (mcp/catalog.ts) nor a project's (project_<name>)`;
}

/** Where a `/` may open a regular expression rather than divide: after one of these marks, a keyword, or at the start. */
const REGEX_MARKS = new Set([...'(,=:[!&|?{};+-*%<>~^']);
const REGEX_WORDS = new Set(['return', 'typeof', 'case', 'do', 'else', 'in', 'of', 'void', 'yield', 'await']);
/** The heads whose `)` a statement follows: a `/` after one opens a regular expression (`if (x) /a/.test(y)`). */
const HEADS = new Set(['if', 'while', 'for']);
const regexMayOpen = (before: string): boolean => {
  let j = before.length - 1;
  while (j >= 0 && /\s/.test(before[j]!)) j--;
  if (j < 0) return true;
  if (REGEX_MARKS.has(before[j]!)) return true;
  if (before[j] === ')') return closesHead(before, j);
  let k = j;
  while (k >= 0 && /[\w$]/.test(before[k]!)) k--;
  return REGEX_WORDS.has(before.slice(k + 1, j + 1));
};

/** Does the `)` at `at` close an `if`, `while` or `for` head: its `(` found back over nested ones, a head's word before it. */
function closesHead(before: string, at: number): boolean {
  let depth = 0;
  for (let k = at; k >= 0; k--) {
    const c = before[k]!;
    if (c === ')') depth++;
    else if (c === '(' && --depth === 0) {
      let w = k - 1;
      while (w >= 0 && /\s/.test(before[w]!)) w--;
      // `for await (…)`: the word before is await, and before it for.
      let end = w;
      while (w >= 0 && /[\w$]/.test(before[w]!)) w--;
      let word = before.slice(w + 1, end + 1);
      if (word === 'await') {
        while (w >= 0 && /\s/.test(before[w]!)) w--;
        end = w;
        while (w >= 0 && /[\w$]/.test(before[w]!)) w--;
        word = before.slice(w + 1, end + 1);
      }
      return HEADS.has(word);
    }
  }
  return false;
}

/**
 * The code of a source with its comments blanked to spaces, every newline kept (so a line is the same line), and its
 * strings, template literals and regular expressions left as they are: a `//` in a string or a URL is no comment, a
 * `${…}` in a template is code again. A lexer of the little a check needs, not a parser: a `/` after an operator or
 * a keyword opens a regular expression, anywhere else divides.
 */
export function codeOnly(text: string): string {
  let out = '';
  /** The template literals open around here: each the depth of `{` at which its `${` was opened. */
  const templates: number[] = [];
  let depth = 0;
  let i = 0;
  const n = text.length;
  const blank = (from: number, to: number): void => {
    out += text.slice(from, to).replace(/[^\n]/g, ' ');
  };
  /** A string from `i` (its quote) to its end, kept. */
  const quoted = (q: string): void => {
    let j = i + 1;
    while (j < n && text[j] !== q && text[j] !== '\n') j += text[j] === '\\' ? 2 : 1;
    out += text.slice(i, j + 1);
    i = j + 1;
  };
  /** A template's text from `i` to its end or its next `${`, kept; true when a `${` opened. */
  const template = (): boolean => {
    let j = i;
    while (j < n) {
      if (text[j] === '\\') j += 2;
      else if (text[j] === '`') {
        out += text.slice(i, j + 1);
        i = j + 1;
        return false;
      } else if (text[j] === '$' && text[j + 1] === '{') {
        out += text.slice(i, j + 2);
        i = j + 2;
        return true;
      } else j++;
    }
    out += text.slice(i);
    i = n;
    return false;
  };
  while (i < n) {
    const c = text[i]!;
    const next = text[i + 1];
    if (c === '/' && next === '/') {
      const end = text.indexOf('\n', i);
      blank(i, end === -1 ? n : end);
      i = end === -1 ? n : end;
    } else if (c === '/' && next === '*') {
      const end = text.indexOf('*/', i + 2);
      blank(i, end === -1 ? n : end + 2);
      i = end === -1 ? n : end + 2;
    } else if (c === '"' || c === "'") {
      quoted(c);
    } else if (c === '`') {
      i++;
      out += '`';
      if (template()) templates.push(depth), depth++;
    } else if (c === '{') {
      depth++;
      out += c;
      i++;
    } else if (c === '}') {
      depth--;
      out += c;
      i++;
      if (templates.length > 0 && templates[templates.length - 1] === depth) {
        templates.pop();
        if (template()) templates.push(depth), depth++;
      }
    } else if (c === '/' && regexMayOpen(out)) {
      let j = i + 1;
      let inClass = false;
      while (j < n && text[j] !== '\n') {
        if (text[j] === '\\') j += 2;
        else {
          if (text[j] === '[') inClass = true;
          else if (text[j] === ']') inClass = false;
          else if (text[j] === '/' && !inClass) break;
          j++;
        }
      }
      out += text.slice(i, j + 1);
      i = j + 1;
    } else {
      out += c;
      i++;
    }
  }
  return out;
}

const FIX = {
  raw: "make it with the editor's button, iconButton or control, whose first argument is the declaration -- or, where it cannot be, end the line (or put above it) `// mcp: <tool>`, `// mcp: ui` or `// mcp: none: <why>`",
  mrdebug: "a studio key is ctx.keys.add({ name, key, help, mcp, run }) -- or mark this one `// mcp: <tool>`, `// mcp: ui` or `// mcp: none: <why>` on its line or the line above",
};

/** The editor's gap list (`mcp/gaps.ts`): `GAPS.<key>` and `NOT_FOR_CLAUDE.<key>`, read from its source; null when it cannot be read. */
export function gapKeys(editorSrc: string | undefined): Set<string> | null {
  if (editorSrc === undefined) return null;
  let text: string;
  try {
    text = readFileSync(join(editorSrc, 'mcp', 'gaps.ts'), 'utf8');
  } catch {
    return null;
  }
  const out = new Set<string>();
  // Each list's own braces: `{}` when it is empty, never running on into the next list.
  for (const block of text.matchAll(/export const (GAPS|NOT_FOR_CLAUDE) = \{((?:\n[\s\S]*?\n)?)\} as const;/g)) {
    for (const entry of block[2]!.matchAll(/^\s+(\w+): \{ none:/gm)) out.add(`${block[1]}.${entry[1]}`);
  }
  return out;
}

export const checkMcp: Check = async (options) => {
  const { root } = options;
  const known = packageSources(root);
  const gaps = gapKeys(known.editor);
  const tools = toolDirs((await projectOptions(root))?.tools).map((dir) => resolve(root, dir)).filter((dir) => existsSync(dir));
  const files = await readSources(root, [join(root, 'src'), ...packageRoots(options), ...tools], known);
  const inTools = (path: string): boolean => tools.some((dir) => path === dir || path.startsWith(dir + sep));
  const findings: CheckFinding[] = [];
  for (const { path, name, id, text } of files) {
    if (id?.startsWith('@vibe/engine/') || (id !== undefined && HELPERS.has(id))) continue;
    const editor = id?.startsWith('@vibe/editor/') === true;
    const studio = editor || inTools(path);
    const lines = text.split('\n');
    const code = codeOnly(text).split('\n');
    code.forEach((line, i) => {
      // A project's none in the editor: its nones are its gap list's (`mcp/declare.ts`), never a why of its own.
      if (editor && id !== '@vibe/editor/mcp/declare.ts' && /\bprojectNone\(/.test(line)) {
        findings.push({ file: name, line: i + 1, rule: "mcp: projectNone in the editor: the editor's nones are entries of its mcp/gaps.ts", fix: 'name the entry -- GAPS.<key> or NOT_FOR_CLAUDE.<key> -- adding one to gaps.ts (and Docs/skills.md §9) if it is new', text: lines[i]!.trim() });
      }
      let what: string | undefined;
      if (RAW_BUTTON.test(line)) what = 'a button made raw';
      else if (studio && MRDEBUG_ADD.test(line)) what = 'a MrDebug action in the studio';
      else if (studio && CLICK_LISTENER.test(line)) {
        const r = clickReceiver(code, i, lines);
        if (r === undefined || (!r.declared && !NO_CONTROL.has(r.name))) what = `a click given to ${r === undefined ? 'an element' : `\`${r.name}\``}, no control of the helpers`;
      } else if (studio && ONCLICK.test(line)) what = 'an onclick';
      else if (studio && ROLE_BUTTON.test(line)) what = 'an element with the role of a button';
      else if (studio && VARIABLE_TAG.test(line)) what = 'an element whose tag is no literal';
      if (what === undefined) return;
      const fix = what === 'a MrDebug action in the studio' ? FIX.mrdebug : FIX.raw;
      const found = markerFor(lines, code, i);
      if (!found) {
        findings.push({ file: name, line: i + 1, rule: `mcp: ${what}, no declaration`, fix, text: lines[i]!.trim() });
        return;
      }
      const problem = declarationProblem(found.marker[1]!, editor ? gaps : null);
      if (problem) findings.push({ file: name, line: found.above ? i : i + 1, rule: `mcp: ${what}: ${problem}`, fix, text: lines[i]!.trim() });
    });
  }
  return sorted(findings);
};
