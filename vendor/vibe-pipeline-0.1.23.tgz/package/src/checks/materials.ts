/**
 * Materials (Docs/render.md §4): every material file that ships -- `src/assets/materials/**\/*.material`
 * and a pack's `packs/<pack>/materials/` -- parses (a JSON problem with its line, `json-problem.ts`), reads
 * as a material with no problem (`@vibe/engine/material-file`: a colour, a number, a type, a field the
 * type has no use for), and names only textures there are -- a key under `src/assets/textures/`, a pack's
 * own first. Each a finding at its file and the line of the field, the engine's own words beside it: the
 * compile at boot draws the material without what is wrong, and this says so before anyone looks. A map
 * by `{ uid, key }` (Docs/asset-ids.md §3) is read as the engine reads it -- by its uid first, through the
 * boot set's index handed to the engine's (`useUids`) -- so a texture moved since is no finding here (the
 * `uids` check says the key is stale).
 */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { materialMaps, parseMaterialFile } from '@vibe/engine/material-file';
import { caseKey } from '@vibe/engine/case-key';
import { useUids } from '@vibe/engine/uids';
import { scanUids, uidIndex } from '../assets/stamp.ts';
import { walkSync } from '../assets/fs.ts';
import { jsonProblem } from '../assets/json-problem.ts';
import { KINDS, MATERIAL_SUFFIX, ROOTS } from '../assets/kinds.ts';
import type { Check, CheckFinding } from './source.ts';

/** The texture keys under a shipping folder (`src/assets`, `packs/reef`), each with `prefix` (`reef:`). */
function textureKeys(dir: string, prefix: string): string[] {
  const ext = new Set<string>(KINDS.textures.ext);
  return walkSync(join(dir, KINDS.textures.dir)).flatMap((file) => {
    const dot = file.lastIndexOf('.');
    return dot > 0 && ext.has(file.slice(dot + 1).toLowerCase()) ? [caseKey(prefix + file.slice(0, dot))] : [];
  });
}

/** The line `"field"` first appears on in `text`, 1-based; 1 when it is not there (a missing `is`). */
function lineOf(text: string, field: string): number {
  const at = text.indexOf(`"${field}"`);
  return at < 0 ? 1 : text.slice(0, at).split('\n').length;
}

/** The findings for one material file's text: `file` as a finding names it, `prefix` its pack's (`reef:`) or `''`. */
export function materialFindings(file: string, text: string, textures: ReadonlySet<string>, prefix = ''): CheckFinding[] {
  const problem = jsonProblem(text);
  if (problem) return [{ file, line: problem.line ?? 1, rule: 'material does not parse', fix: `${problem.message} -- a material file is JSON (Docs/render.md §4)`, text: '' }];
  const json = JSON.parse(text) as unknown;
  const { file: read, problems } = parseMaterialFile(json);
  const out: CheckFinding[] = problems.map((p) => {
    const field = /^"([^"]+)"/.exec(p)?.[1]?.split('.')[0] ?? /^physical: "([^"]+)"/.exec(p)?.[1] ?? '';
    const line = field === '' ? 1 : lineOf(text, field);
    return { file, line, rule: 'material', fix: p, text: text.split('\n')[line - 1]?.trim() ?? '' };
  });
  for (const { field, key } of materialMaps(read)) {
    const known = (prefix !== '' && !key.includes(':') && textures.has(`${prefix}${key}`)) || textures.has(key);
    if (known) continue;
    const line = lineOf(text, field);
    out.push({ file, line, rule: 'material: no such texture', fix: `${field} '${key}' is no texture key -- a file under src/assets/textures/, its path without the extension, lowercased (AssetKeys.Texture); the material draws without it`, text: text.split('\n')[line - 1]?.trim() ?? '' });
  }
  return out;
}

export const checkMaterials: Check = async ({ root }) => {
  const findings: CheckFinding[] = [];
  useUids(Object.fromEntries(uidIndex(scanUids(root)).boot));
  const boot = join(root, ROOTS.boot.dir);
  const textures = new Set(textureKeys(boot, ''));
  const places: { dir: string; label: string; prefix: string }[] = [{ dir: boot, label: ROOTS.boot.dir, prefix: '' }];
  for (const pack of walkSync(join(root, ROOTS.packs.dir)).map((f) => f.split('/')[0]!).filter((p, i, all) => all.indexOf(p) === i)) {
    const dir = join(root, ROOTS.packs.dir, pack);
    for (const key of textureKeys(dir, `${pack}:`)) textures.add(key);
    places.push({ dir, label: `${ROOTS.packs.dir}/${pack}`, prefix: `${caseKey(pack)}:` });
  }
  for (const { dir, label, prefix } of places) {
    for (const file of walkSync(join(dir, KINDS.materials.dir))) {
      if (!file.toLowerCase().endsWith(MATERIAL_SUFFIX)) continue;
      const name = `${label}/${KINDS.materials.dir}/${file}`;
      findings.push(...materialFindings(name, readFileSync(join(dir, KINDS.materials.dir, file), 'utf8'), textures, prefix));
    }
  }
  return findings;
};
