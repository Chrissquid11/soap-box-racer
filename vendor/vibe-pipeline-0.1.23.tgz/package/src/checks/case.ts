/**
 * Case, on a disk that has none (`assets/case.ts`): every path git tracks under the project's asset roots
 * in the case the disk has, each that differs a finding with its `git mv`. Without git -- not installed,
 * or no checkout -- no findings, and a note that the check did not run. `vibe export --check` runs the
 * same check.
 */
import { caseLines, caseMismatches, type CaseMismatch } from '../assets/case.ts';
import type { Check, CheckFinding } from './source.ts';

/** The findings for what `caseMismatches` found: the path itself, line 0. */
export function caseFindings(mismatches: readonly CaseMismatch[]): CheckFinding[] {
  const lines = caseLines(mismatches);
  return mismatches.map((m, i) => ({ file: m.tracked, line: 0, rule: 'case', fix: `the live host would 404 on it -- record the disk's ${m.disk}: ${m.fix}`, text: lines[i]! }));
}

export const checkCase: Check = async ({ root, note }) => {
  const found = await caseMismatches(root);
  if (found === undefined) {
    note?.('case: skipped -- no git, or no checkout here');
    return [];
  }
  return caseFindings(found);
};
