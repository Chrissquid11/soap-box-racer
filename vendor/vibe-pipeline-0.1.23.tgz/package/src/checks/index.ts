/**
 * The rules a project's source keeps, run by the pipeline for every project (Docs/packages.md
 * §8): `vibe test` runs them over the project after its test files, so a project carries no test file of
 * its own for them. Each check a function over a root (`source.ts`' `Check`), pure but for reading files:
 *
 *   ecs     the rules a system keeps, no world kept at module level, made from prefabs (`ecs.ts`)
 *   routes  every debug key and button through MrDebug, no imported DEBUG, no browser dialog in the editor (`routes.ts`)
 *   ui      theme names and units in a widget, never a literal (`ui.ts`)
 *   case    git and the disk agree on the case of every asset path (`case.ts`)
 *   materials  every material file parses, reads with no problem, and names textures there are (`materials.ts`)
 *   uids    every asset has its uid, no uid is two assets', no .uid sidecar without its file (`uids.ts`, Docs/asset-ids.md §5)
 *   skills  the skill pages read, link and stay in size; every MCP tool and every editor tab in a studio page; what a page names there (`skills.ts`, `skill-tabs.ts`, Docs/skills.md §3)
 *   mcp     every action a person has in the studio names its MCP tool, `ui`, or why none: a raw button, a MrDebug action (`mcp.ts`, Docs/skills.md §9 S2)
 *   keys    no debug key of the project's always takes one of the editor's (`keys.ts`, the editor's `editor-keys.ts`; Docs/studio.md, "Keys")
 *
 * Defines only.
 */
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { checkCase } from './case.ts';
import { checkEcs } from './ecs.ts';
import { checkKeys } from './keys.ts';
import { checkMaterials } from './materials.ts';
import { checkMcp } from './mcp.ts';
import { checkRoutes } from './routes.ts';
import { checkSkills } from './skills.ts';
import { packageRoots, type Check, type CheckFinding, type CheckOptions } from './source.ts';
import { checkUi } from './ui.ts';
import { checkUids } from './uids.ts';

export type { Check, CheckFinding, CheckOptions } from './source.ts';

/** Every check by name. */
export const CHECKS: Record<string, Check> = { ecs: checkEcs, routes: checkRoutes, ui: checkUi, case: checkCase, materials: checkMaterials, uids: checkUids, skills: checkSkills, mcp: checkMcp, keys: checkKeys };

/** Every check over the project, one after another: their findings in the table's order, and what a check could not do. An extra root that is not there throws. */
export async function runChecks(options: CheckOptions): Promise<{ findings: CheckFinding[]; notes: string[] }> {
  const missing = packageRoots(options).filter((dir) => !existsSync(dir));
  if (missing.length > 0) throw new Error(`no such source folder: ${missing.join(', ')}`);
  const notes: string[] = [];
  const findings: CheckFinding[] = [];
  for (const check of Object.values(CHECKS)) {
    findings.push(...(await check({ ...options, root: resolve(options.root), note: (line) => {
      notes.push(line);
      options.note?.(line);
    } })));
  }
  return { findings, notes };
}

/** What `vibe test` prints: the notes, then `[checks] clean`, or `[checks] <n> findings` and each as `  <file>:<line>  <rule>` with its fix under it. */
export function checkLines({ findings, notes }: { findings: readonly CheckFinding[]; notes: readonly string[] }): string[] {
  const out = notes.map((line) => `[checks] ${line}`);
  if (findings.length === 0) return [...out, '[checks] clean'];
  out.push(`[checks] ${findings.length} finding${findings.length === 1 ? '' : 's'}`);
  for (const f of findings) out.push(`  ${f.line > 0 ? `${f.file}:${f.line}` : f.file}  ${f.rule}`, `      ${f.fix}`);
  return out;
}
