/**
 * What every check shares (Docs/squidwright-implementation.md 1.7): the one shape of a check and its
 * findings, the walk over a source folder, a file's name in a finding, and a file's identity -- which
 * package's file it is, by the real path the project resolves that package to. Defines only.
 */
import { existsSync, realpathSync } from 'node:fs';
import { readdir, readFile } from 'node:fs/promises';
import { join, relative, resolve, sep } from 'node:path';
import { PACKAGES, packageDir } from '../modes.ts';

/** One line that breaks a rule. */
export interface CheckFinding {
  /** Relative to the root, posix (`src/game/systems/wander.ts`; a package's outside it `../../packages/engine/src/boot.ts`). */
  file: string;
  /** 1-based; 0 when the finding is the path itself (the case check). */
  line: number;
  rule: string;
  /** What to do instead. */
  fix: string;
  /** The line as written. */
  text?: string;
}

export interface CheckOptions {
  /** The project: its `src/` is what the checks read. */
  root: string;
  /** Extra source roots to walk, absolute or relative to the root (`vibe test` hands them absolute): the workspace's packages' `src/` (a project passes none). */
  packages?: readonly string[];
  /** Told what a check could not do (no git for the case check): said, never a finding. */
  note?: (line: string) => void;
}

/** A check: every finding over a project, sorted by file and line. Pure but for reading files. */
export type Check = (options: CheckOptions) => Promise<CheckFinding[]>;

/** Every `.ts` under `dir` (absolute, name order), no `.d.ts`; tests left out unless asked. None when there is no `dir`. Skips dot folders and `node_modules`. */
export async function sources(dir: string, { tests = false }: { tests?: boolean } = {}): Promise<string[]> {
  if (!existsSync(dir)) return [];
  const out: string[] = [];
  const entries = (await readdir(dir, { withFileTypes: true })).sort((a, b) => (a.name < b.name ? -1 : 1));
  for (const entry of entries) {
    if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...(await sources(full, { tests })));
    else if (entry.name.endsWith('.ts') && !entry.name.endsWith('.d.ts') && (tests || !entry.name.endsWith('.test.ts'))) out.push(full);
  }
  return out;
}

/** A file read, as the checks see it. */
export interface SourceFile {
  path: string;
  /** As a finding names it: relative to the root, posix. */
  name: string;
  /** `@vibe/engine/boot.ts`: a package's file by the package the project resolves (`identify`); undefined for any other. */
  id: string | undefined;
  text: string;
}

/** `path` relative to `root`, posix. */
export const named = (root: string, path: string): string => relative(root, path).split(sep).join('/');

/** The extra roots, resolved against the root. */
export const packageRoots = ({ root, packages = [] }: CheckOptions): string[] => packages.map((dir) => resolve(root, dir));

/**
 * The `src/` of the engine and the editor as the project at `root` resolves them (`modes.ts`' `packageDir`:
 * through `node_modules`, to the real path), each undefined when it is not installed.
 */
export function packageSources(root: string): { engine?: string; editor?: string } {
  const at = (name: string): string | undefined => {
    const dir = packageDir(resolve(root), name);
    return dir === undefined ? undefined : join(dir, 'src');
  };
  const engine = at(PACKAGES.engine);
  const editor = at(PACKAGES.editor);
  return { ...(engine === undefined ? {} : { engine }), ...(editor === undefined ? {} : { editor }) };
}

/**
 * A file's identity: `@vibe/engine/<path under its src/>` when its real path is under the engine the project
 * resolves, `@vibe/editor/...` the same way, else undefined. An allowance names a file by this, never by a
 * path a project's own file could share: a project's `src/boot.ts` is no `@vibe/engine/boot.ts`.
 */
export function identify(path: string, known: { engine?: string; editor?: string }, real: string = realpathSync(path)): string | undefined {
  for (const [name, src] of [[PACKAGES.engine, known.engine], [PACKAGES.editor, known.editor]] as const) {
    if (src !== undefined && real.startsWith(src + sep)) return `${name}/${relative(src, real).split(sep).join('/')}`;
  }
  return undefined;
}

/** Every file under each of `dirs`, read once (a folder given twice, or a project's own src/ among the packages, read once). */
export async function readSources(root: string, dirs: readonly string[], known: { engine?: string; editor?: string }): Promise<SourceFile[]> {
  const seen = new Set<string>();
  const out: SourceFile[] = [];
  for (const dir of dirs) {
    for (const path of await sources(dir)) {
      const real = realpathSync(path);
      if (seen.has(real)) continue;
      seen.add(real);
      out.push({ path, name: named(root, path), id: identify(path, known, real), text: await readFile(path, 'utf8') });
    }
  }
  return out;
}

/** The 1-based line of `index` in `text`. */
export const lineAt = (text: string, index: number): number => text.slice(0, index).split('\n').length;

/** Findings in file, then line order. */
export const sorted = (findings: CheckFinding[]): CheckFinding[] =>
  findings.sort((a, b) => (a.file === b.file ? a.line - b.line : a.file < b.file ? -1 : 1));
