/**
 * The skill pages (Docs/skills.md §3): the pages a project's skills are put together from -- its installed engine's
 * and editor's, and its own tools' (`../skills/install.ts`' roots) -- hold together, and every MCP tool has one.
 *
 * - **The pages' own problems** (`../skills/pages.ts`): no or bad frontmatter, a second page of a name, a link that
 *   goes nowhere, a page or an index over its limit.
 * - **Every tool covered**: each tool of the studio's catalogue (`../mcp/catalog.ts`, zod-free) and each of the
 *   project's own (`mcpTools`, `project_<name>`) is in some `studio` page's `covers: tools`. (S1 to S3 let a list of
 *   tools not yet covered by; S3 emptied it, and it is gone: a new tool comes with its page.)
 * - **Every tab covered** (`skill-tabs.ts`): each of the editor's own tabs names its page in the editor's
 *   `tab-pages.ts`, which must be a studio page of the editor's; each editor tool of the project's own has the
 *   project's studio page named as its id.
 * - **No skill points at `Docs/`**: a page's mention is the collector's problem (`docsMentions`); the synced files
 *   (`vibe`, `gladius` and the critic's brief, `agents/code-critic.md`: every file `SYNCED` lists, from the pipeline
 *   the project runs) are read here for the same, each mention a finding at its line -- a project has no `Docs/`, and
 *   the how is the pages'.
 * - **What a page names is there**: each tool a studio page covers is one (the catalogue's or the project's), and
 *   each module an engine page covers is a file or folder under its package's `src/` (its tool folder, a project's).
 *
 * **A project's own MCP tools are read from the source**, not imported: its `src/tools/index.ts` is the browser's
 * (the editor's types, the DOM), so a tool is a `name: '<words>'` followed by `description:` in a file of its tool
 * folders that names `ProjectMcpTool` -- the shape every `ProjectMcpTool` is written in (`examples/tools/tile-tool/mcp.ts`).
 * Another object of that shape in such a file is taken for a tool too (Docs/skills.md §9): keep helpers elsewhere.
 */
import { existsSync, readFileSync } from 'node:fs';
import { isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { CLAUDE_DIR, SYNCED } from '../agent/plugin.ts';
import { CATALOG } from '../mcp/catalog.ts';
import { PACKAGES, packageDir } from '../modes.ts';
import { projectPageRoots } from '../skills/install.ts';
import { collectPages, docsMentions, DOCS_FIX, type Page } from '../skills/pages.ts';
import { tabFindings } from './skill-tabs.ts';
import { named, sorted, sources, type Check, type CheckFinding, type CheckOptions } from './source.ts';

/** What Claude calls a project's tool before its name (`agent/api-types.ts`' `PROJECT_PREFIX`, said again: that module is the page's too). */
const PROJECT = 'project_';

/** A project tool declared in the source: its name as Claude calls it (`project_tiles_paint`), its file and line. */
export interface DeclaredTool {
  name: string;
  file: string;
  line: number;
}

/** `name: '<words>'` then `description:`: a `ProjectMcpTool`'s head. */
const DECLARED = /\bname:\s*(['"])([a-z][a-z0-9]*(?:_[a-z0-9]+)*)\1\s*,\s*description\s*:/g;

/** The project's own MCP tools, read from its tool folders' sources (the module's comment). */
export async function declaredTools(dirs: readonly string[]): Promise<DeclaredTool[]> {
  const out: DeclaredTool[] = [];
  for (const dir of dirs) {
    for (const file of await sources(dir)) {
      const text = readFileSync(file, 'utf8');
      if (!text.includes('ProjectMcpTool')) continue;
      for (const match of text.matchAll(DECLARED)) out.push({ name: `${PROJECT}${match[2]}`, file, line: text.slice(0, match.index).split('\n').length });
    }
  }
  return out;
}

/** A file of the pipeline the project runs (its `src/`, in both forms), else this checkout's: the catalogue. */
function pipelineFile(root: string, path: string): string {
  try {
    const dir = packageDir(resolve(root), PACKAGES.pipeline);
    if (dir !== undefined && existsSync(join(dir, 'src', path))) return join(dir, 'src', path);
  } catch {
    // Not resolvable: this module's own.
  }
  return fileURLToPath(new URL(`../${path}`, import.meta.url));
}

/** The plugin's folder of the pipeline the project runs (its `claude/`), else this checkout's: the synced skills. */
function pluginDir(root: string): string {
  try {
    const dir = packageDir(resolve(root), PACKAGES.pipeline);
    if (dir !== undefined && existsSync(join(dir, 'claude'))) return join(dir, 'claude');
  } catch {
    // Not resolvable: this module's own.
  }
  return CLAUDE_DIR;
}

/** The 1-based line of `'<name>'` in `file`; 0 when it is not there. */
function lineOf(file: string, name: string): number {
  try {
    const text = readFileSync(file, 'utf8');
    const at = text.indexOf(`'${name}'`);
    return at < 0 ? 0 : text.slice(0, at).split('\n').length;
  } catch {
    return 0;
  }
}

/** The check's findings, with the catalogue's names given (a test's own, with a tool no page covers); `checkSkills` is it with the catalogue's. */
export async function skillFindings({ root, note }: CheckOptions, names: readonly string[] = CATALOG.map((m) => m.name)): Promise<CheckFinding[]> {
  const findings: CheckFinding[] = [];
  const { roots, notes, tools: toolFolders } = await projectPageRoots(root);
  for (const line of notes) note?.(`skills: ${line}`);
  const { pages, problems } = collectPages(roots);
  for (const p of problems) {
    findings.push({ file: isAbsolute(p.file) ? named(root, p.file) : `the ${p.file.split('/')[0]} skill's SKILL.md`, line: p.line, rule: `skill page: ${p.problem}`, fix: p.fix });
  }
  const plugin = pluginDir(root);
  for (const path of SYNCED) {
    const file = join(plugin, path);
    if (!existsSync(file)) continue;
    // A skill's file, or an agent's brief (the critic's): each copied into a project, which has no Docs/.
    const what = path.startsWith('agents/') ? `the ${path.slice('agents/'.length).replace(/\.md$/, '')} agent` : `the ${path.split('/')[1]} skill`;
    for (const line of docsMentions(readFileSync(file, 'utf8'))) {
      findings.push({ file: named(root, file), line, rule: `skills: ${what} names Docs/, which a project does not have`, fix: DOCS_FIX });
    }
  }
  const catalogue = new Set<string>(names);
  const declared = await declaredTools(toolFolders.map((dir) => resolve(root, dir)).filter((dir) => existsSync(dir)));
  const project = new Set(declared.map((d) => d.name));
  const covered = new Map<string, Page>();
  for (const page of pages.studio) for (const tool of page.tools) if (!covered.has(tool)) covered.set(tool, page);
  const catalogFile = pipelineFile(root, 'mcp/catalog.ts');
  const COVER = 'add it to the covers: tools: of the studio page about its editor (a <name>.skill.md beside the code), saying in the page how a job uses it -- or write that page';

  for (const name of catalogue) {
    if (covered.has(name)) continue;
    findings.push({ file: named(root, catalogFile), line: lineOf(catalogFile, name), rule: `skills: the MCP tool ${name} is in no studio page`, fix: COVER });
  }
  for (const d of declared) {
    if (covered.has(d.name)) continue;
    findings.push({ file: named(root, d.file), line: d.line, rule: `skills: the project's MCP tool ${d.name} is in no studio page`, fix: `${COVER} -- a project tool's page sits in its tool folder and joins the studio skill` });
  }
  findings.push(...(await tabFindings(root, roots, pages.studio, toolFolders.map((dir) => resolve(root, dir)).filter((dir) => existsSync(dir)))));
  for (const page of pages.studio) {
    for (const tool of page.tools) {
      if (catalogue.has(tool) || project.has(tool)) continue;
      findings.push({ file: named(root, page.file), line: page.lines[`tools:${tool}`] ?? page.lines.tools ?? 1, rule: `skills: ${page.name}.skill.md covers ${tool}, which is no MCP tool`, fix: `name a tool of the catalogue (mcp/catalog.ts) bare, or a project's as Claude calls it (${PROJECT}<name>) -- or take it out` });
    }
  }
  for (const page of pages.engine) {
    for (const module of page.modules) {
      if (existsSync(join(page.root.dir, module))) continue;
      findings.push({ file: named(root, page.file), line: page.lines[`modules:${module}`] ?? page.lines.modules ?? 1, rule: `skills: ${page.name}.skill.md covers ${module}, which is not there`, fix: `a path under ${named(root, page.root.dir)}/ (a folder ends with /): the module the page is about` });
    }
  }
  return sorted(findings);
}

export const checkSkills: Check = (options) => skillFindings(options);
