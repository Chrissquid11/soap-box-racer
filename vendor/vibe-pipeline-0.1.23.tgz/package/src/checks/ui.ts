/**
 * The canvas UI's rules (CLAUDE.md: "UI sizes are units"; "Colours and sizes come from theme.ts, never a
 * literal in a widget"): every widget file under the project's `src/ui/`, and under the engine's `ui/` when
 * the engine's `src/` is among the extra roots (the workspace's; the stock widgets: the pill, the
 * pressable), is read, and a colour written out, a size in units that is a bare number (`14 * u`), a bare
 * pixel size (`size: 14`, `outline: 3`) or a menu width in numbers is named. The machinery the widgets
 * stand on -- the engine's text, images, units, the layer, its input, the subpath's index -- is no widget
 * and is left out, by identity (`source.ts`' `identify`): a project's own `src/ui/theme.ts` is held to the
 * rules. Was the sandbox's `src/ui/rules.test.ts`.
 */
import { realpathSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { packageRoots, packageSources, readSources, sorted, type Check, type CheckFinding, type CheckOptions, type SourceFile } from './source.ts';

/** Not widgets: what the widgets are drawn with (the engine's), and the subpath's list of exports. */
export const MACHINERY = new Set(['theme.ts', 'text.ts', 'images.ts', 'units.ts', 'layer.ts', 'input.ts', 'widget.ts', 'index.ts'].map((name) => `@vibe/engine/ui/${name}`));

const RULES: { rule: string; pattern: RegExp; fix: string }[] = [
  { rule: 'colour', pattern: /#[0-9a-fA-F]{3,8}\b|\brgba?\(|\bhsla?\(/, fix: 'a colour written out: name it in COLOUR (theme.ts)' },
  { rule: 'unit size', pattern: /\b\d+(\.\d+)?\s*\*\s*(u|m|this\.u|this\.m|units\.u|units\.m)\b/, fix: 'a size in units that is a bare number: name it in SIZE_U or SIZE_M (theme.ts)' },
  { rule: 'pixel size', pattern: /\b(size|outline|width|height|radius|gap|padding)\s*:\s*\d/, fix: 'a bare pixel size: a SIZE_U or SIZE_M entry (theme.ts), times the unit in layout' },
  { rule: 'menu width', pattern: /\bmenu\(\s*units\s*,\s*\d/, fix: 'a menu width in numbers: SIZE_M entries (theme.ts)' },
];

/** Every line of `text` that breaks a rule, comments left out. */
export function literalsIn(text: string): { line: number; rule: string; fix: string; text: string }[] {
  const found: { line: number; rule: string; fix: string; text: string }[] = [];
  const lines = text.replace(/\/\*[\s\S]*?\*\//g, (block) => block.replace(/[^\n]/g, ' ')).split('\n');
  lines.forEach((raw, i) => {
    const line = raw.replace(/\/\/.*$/, '');
    for (const { rule, pattern, fix } of RULES) if (pattern.test(line)) found.push({ line: i + 1, rule, fix, text: line.trim() });
  });
  return found;
}

/** The widget files the check reads: the project's `src/ui/`, the engine's `ui/` when its `src/` is an extra root, the machinery left out. */
export async function widgetFiles(options: CheckOptions): Promise<SourceFile[]> {
  const { root, note } = options;
  const known = packageSources(root);
  // A walk that finds nothing is said, never passed in silence.
  if (!existsSync(join(root, 'src', 'ui'))) note?.(`ui: no src/ui/ under ${root}, nothing of the project's checked`);
  const real = (dir: string): string | undefined => {
    try {
      return realpathSync(dir);
    } catch {
      return undefined;
    }
  };
  const engineUi = known.engine !== undefined && packageRoots(options).some((dir) => real(dir) === known.engine) ? [join(known.engine, 'ui')] : [];
  const files = await readSources(root, [join(root, 'src', 'ui'), ...engineUi], known);
  return files.filter(({ id }) => id === undefined || !MACHINERY.has(id));
}

export const checkUi: Check = async (options) => {
  const findings: CheckFinding[] = [];
  for (const { name, text } of await widgetFiles(options)) {
    for (const f of literalsIn(text)) findings.push({ file: name, ...f });
  }
  return sorted(findings);
};
