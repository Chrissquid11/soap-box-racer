/**
 * The `skills` check's tabs (Docs/skills.md §2 rule 8, §9 S3): every editor tab, the editor's own and a project's,
 * has its `studio` page.
 *
 * - **The editor's own** are its `tab-pages.ts` (`TAB_PAGES`: each tab's id and the page about it), which every tool of
 *   the editor's takes its id from -- read as text from the installed editor's `src/`, one `<id>: '<page>',` a line:
 *   node strips no types under `node_modules`, so a published project could not import it. A page it names that is no
 *   `studio` page of the editor's is a finding at its line.
 * - **A project's own** are read from its tool folders as its MCP tools are (`skills.ts`' `declaredTools`): in a file
 *   naming `EditorTool`, each `: EditorTool = {` (or `EditorTab`) and the first `id:` after it -- a string, a `const`
 *   of the file, or `tabId('<id>')`. Its page is the project's `studio` page named as its id (`tiles` is
 *   `tiles.skill.md`), or the editor's own when the id is one of the editor's tabs (a game's own Assets tool, in the
 *   editor's place). A tool made by a call (`createAssetsTool(…)`) has no `id:` of its own: its id is the factory's,
 *   the editor's, and it is passed by. An id that is none of those forms is a finding: write it plainly.
 *
 * Pure but for reading the files it is given.
 */
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Page, PageRoot } from '../skills/pages.ts';
import { named, sources, type CheckFinding } from './source.ts';

/** The editor's tab list, in its `src/`. */
export const TAB_FILE = 'tab-pages.ts';

/** A tab of the editor's list: its id, its page, and its line in the file. */
export interface ListedTab {
  id: string;
  page: string;
  line: number;
}

/** The editor's tabs from `tab-pages.ts`' text: each `<id>: '<page>',` line of its `TAB_PAGES`. Empty for a text without one. */
export function listedTabs(text: string): ListedTab[] {
  const lines = text.split('\n');
  const start = lines.findIndex((line) => /\bTAB_PAGES\s*=\s*\{/.test(line));
  if (start < 0) return [];
  const out: ListedTab[] = [];
  for (let i = start + 1; i < lines.length && !/^\s*\}/.test(lines[i]!); i++) {
    const m = /^\s*(?:(['"])([a-z][a-z0-9-]*)\1|([a-z][a-z0-9]*))\s*:\s*(['"])([a-z][a-z0-9-]*)\4\s*,?\s*$/.exec(lines[i]!);
    if (m) out.push({ id: m[2] ?? m[3]!, page: m[5]!, line: i + 1 });
  }
  return out;
}

/** A project's editor tool as read from its source: its id (null: not readable), its file and line. */
export interface DeclaredTab {
  id: string | null;
  file: string;
  line: number;
}

/** `: EditorTool = {` (or `EditorTab`): a tool's object, written out. */
const TOOL = /:\s*Editor(?:Tool|Tab)\s*=\s*\{/g;
/** Its first `id:` -- a string, `tabId('<id>')`, or a name. */
const ID = /\bid\s*:\s*(?:(['"])([^'"\n]+)\1|tabId\(\s*(['"])([^'"\n]+)\3\s*\)|([A-Za-z_$][\w$]*))/;

/** The project's own editor tools, read from its tool folders' sources (the module's comment). */
export async function declaredTabs(dirs: readonly string[]): Promise<DeclaredTab[]> {
  const out: DeclaredTab[] = [];
  for (const dir of dirs) {
    for (const file of await sources(dir)) {
      const text = readFileSync(file, 'utf8');
      if (!text.includes('EditorTool') && !text.includes('EditorTab')) continue;
      for (const match of text.matchAll(TOOL)) {
        const line = text.slice(0, match.index).split('\n').length;
        const id = ID.exec(text.slice(match.index + match[0].length));
        let value: string | null = null;
        if (id?.[2] !== undefined) value = id[2];
        else if (id?.[4] !== undefined) value = id[4];
        else if (id?.[5] !== undefined) {
          const constant = new RegExp(`\\bconst\\s+${id[5].replace(/\$/g, '\\$')}\\s*(?::[^=\\n]+)?=\\s*(['"])([^'"\\n]+)\\1`).exec(text);
          value = constant ? constant[2]! : null;
        }
        out.push({ id: value, file, line });
      }
    }
  }
  return out;
}

/** What the tab rules find: the editor's list against its pages, a project's tools against theirs. */
export async function tabFindings(root: string, roots: readonly PageRoot[], studio: readonly Page[], toolDirs: readonly string[]): Promise<CheckFinding[]> {
  const findings: CheckFinding[] = [];
  const editor = roots.find((r) => r.owner === 'editor');
  const listFile = editor ? join(editor.dir, TAB_FILE) : null;
  // An editor from before the list (or none installed) has nothing to hold: its pages are its own.
  const listed = listFile && existsSync(listFile) ? listedTabs(readFileSync(listFile, 'utf8')) : [];
  const editorPages = new Set(studio.filter((p) => p.root.owner === 'editor').map((p) => p.name));
  const projectPages = new Set(studio.filter((p) => p.root.owner === 'project').map((p) => p.name));
  for (const tab of listed) {
    if (editorPages.has(tab.page)) continue;
    findings.push({
      file: named(root, listFile!),
      line: tab.line,
      rule: `skills: the editor's tab ${tab.id} names the page ${tab.page}, which is no studio page of the editor's`,
      fix: `write ${tab.page}.skill.md beside the tab's code (skill: studio, its tools in covers), or name the page that is about the tab`,
    });
  }
  const editorTabs = new Set(listed.map((t) => t.id));
  for (const tool of await declaredTabs(toolDirs)) {
    if (tool.id === null) {
      findings.push({ file: named(root, tool.file), line: tool.line, rule: "skills: the project's editor tool's id is not readable from its source", fix: "write its id as a string (id: 'tiles') or a const of the same file, so the skills check finds the page named as it" });
      continue;
    }
    if (projectPages.has(tool.id) || editorTabs.has(tool.id)) continue;
    findings.push({
      file: named(root, tool.file),
      line: tool.line,
      rule: `skills: the project's editor tool ${tool.id} has no studio page`,
      fix: `write ${tool.id}.skill.md beside it (skill: studio; covers: tools: its project_<name> tools, [] if none): who it is for, the jobs with real calls, its refusals, a job end to end`,
    });
  }
  return findings;
}
