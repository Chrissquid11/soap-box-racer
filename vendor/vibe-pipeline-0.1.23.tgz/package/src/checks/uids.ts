/**
 * Uids (Docs/asset-ids.md §1, §5): every asset has one -- a data file's `"uid"`, a source's record's, a loose
 * file's `.uid` sidecar (`assets/stamp.ts`' scan) -- no uid is two assets', and no sidecar is left without its
 * file. Read only: `vibe assets` stamps, this says.
 *
 * **A missing uid fails in what is committed**: an asset whose file git tracks unchanged -- a clean checkout,
 * CI's -- with no uid is a finding ("run vibe assets"); one new or changed in the working tree is the next
 * `vibe assets`' or the dev server's to stamp, and is a note. Without git -- not installed, or no checkout --
 * every one missing is a finding. A duplicate and an orphaned sidecar are findings wherever they are.
 *
 * **A stale reference fails in what is committed** (§5): a data file git tracks unchanged holding a `{ uid, key }`
 * whose key is not its uid's asset's key now -- the repair pass (`repair.ts`), run dry -- is a finding ("run vibe
 * assets": it rewrites the key); one in a file new or changed in the working tree is a note, the next pass's.
 */
import { projectKinds } from '../assets/project-kinds.ts';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { repairRefs } from '../assets/repair.ts';
import { holderFile, scanUids, uidKeys } from '../assets/stamp.ts';
import { uncommitted } from '../assets/uncommitted.ts';
import type { ProjectKinds } from '../assets/kinds.ts';
import type { Check, CheckFinding } from './source.ts';

/** The findings for a scan: `fresh` the files new or changed in the working tree (their missing uids a note), or undefined for none known. */
export function uidFindings(scan: ReturnType<typeof scanUids>, fresh: ReadonlySet<string> | undefined, note?: (line: string) => void): CheckFinding[] {
  const out: CheckFinding[] = [];
  const waiting: string[] = [];
  const seen = new Map<string, string>();
  const sorted = [...scan.assets].sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  for (const a of sorted) {
    if (a.unread) continue; // its own check, or its source's status, says it does not parse or is no object
    if (a.uid === undefined) {
      if (fresh?.has(a.path)) {
        waiting.push(a.path);
        continue;
      }
      out.push({ file: holderFile(a), line: 0, rule: a.bad ? 'a uid that is none' : 'no uid', fix: `${a.path} has ${a.bad ? 'a "uid" that is no uid' : 'no uid'} -- run vibe assets: it stamps one (Docs/asset-ids.md §1), then commit it` });
      continue;
    }
    const first = seen.get(a.uid);
    if (first !== undefined) out.push({ file: holderFile(a), line: 0, rule: 'a uid twice', fix: `${a.path} has the uid of ${first} (${a.uid}), a copy's -- run vibe assets: the file git tracks unchanged keeps it (else the older, else the first by path), the other is stamped anew (rule 7)` });
    else seen.set(a.uid, a.path);
  }
  for (const orphan of scan.orphans) out.push({ file: orphan, line: 0, rule: 'a .uid without its file', fix: `the file it was beside is gone -- moved without it, or deleted: move it with its file, or delete it` });
  if (waiting.length > 0) note?.(`uids: ${waiting.length} new or changed in the working tree with none yet -- the next vibe assets (or the dev server) stamps ${waiting.length === 1 ? 'it' : 'them'}: ${waiting.join(', ')}`);
  return out.sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : 0));
}

/**
 * The references a pass would rewrite (rule 6, run dry): each committed data file holding a `{ uid, key }` whose key
 * is not its uid's asset's now, a finding; one new or changed in the working tree (`fresh`), a note.
 */
export function staleFindings(root: string, scan: ReturnType<typeof scanUids>, fresh: ReadonlySet<string> | undefined, note?: (line: string) => void): CheckFinding[] {
  const keys = uidKeys(scan);
  const out: CheckFinding[] = [];
  const waiting: string[] = [];
  for (const a of scan.assets) {
    if (a.holder !== 'json' || a.unread) continue;
    let text: string;
    try {
      text = readFileSync(join(root, a.path), 'utf8');
    } catch {
      continue;
    }
    const { changed } = repairRefs(text, (uid) => keys.get(uid));
    if (changed.length === 0) continue;
    if (fresh?.has(a.path)) {
      waiting.push(a.path);
      continue;
    }
    out.push({ file: a.path, line: 0, rule: 'a stale reference', fix: `${changed.map((c) => `"${c.from}" is "${c.to}" now (${c.uid})`).join(', ')} -- run vibe assets: it rewrites the key${changed.length === 1 ? '' : 's'} (Docs/asset-ids.md §1, rule 6), then commit it` });
  }
  if (waiting.length > 0) note?.(`uids: ${waiting.length} new or changed in the working tree with a stale key -- the next vibe assets (or the dev server) rewrites ${waiting.length === 1 ? 'it' : 'them'}: ${waiting.sort().join(', ')}`);
  return out.sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : 0));
}

export const checkUids: Check = async ({ root, note }) => {
  let kinds: ProjectKinds = {};
  try {
    kinds = await projectKinds(root);
  } catch (err) {
    note?.(`uids: the project's own kinds not read (${err instanceof Error ? err.message.split('\n')[0] : String(err)}): their files not checked`);
  }
  const scan = scanUids(root, kinds);
  const fresh = uncommitted(root);
  return [...uidFindings(scan, fresh, note), ...staleFindings(root, scan, fresh, note)].sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : 0));
};
