/**
 * The game's rules, over a project's `src/game/` (CLAUDE.md, Docs/ecs.md §11, §12, §22, Docs/prefabs.md):
 *
 * - **the rules a system keeps** -- chance and time from the loop, nothing allocated in a system, the one
 *   loop shape -- over every file under `src/game/systems/` (`checkSystemSource`, the engine's; a line
 *   that must break one says why on it: `// alloc-ok: <reason>`);
 * - **no world, store or channel kept at module level** -- a swap rebuilds the world in place -- over
 *   every module under `src/game/` (`checkModuleState`, the engine's; no waiver);
 * - **no data component in a `parallel` system** (`checkParallelData`, the engine's): its lists and strings are the
 *   main thread's objects, never in the memory a worker shares;
 * - **made from prefabs**: no `kind(` and no `spawn(<a kind>)` under `src/game/` -- what a thing is made
 *   of, its numbers as made and its model belong in a prefab file, instantiated. A bare `cmd.spawn()`
 *   (an entity with nothing yet) stays legal. No waiver: the editor spawned kinds through `src/game/`
 *   until it spawned prefabs itself, and nothing else ever needed one.
 *
 * Tests are left out: a test may plant what it checks. Was the sandbox's `src/game/rules.test.ts`.
 */
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join, sep } from 'node:path';
import { checkModuleState, checkParallelData, checkSystemSource, dataComponentsIn, type Finding } from '@vibe/engine/rules';
import { named, sorted, sources, type Check, type CheckFinding } from './source.ts';

/** What to write instead of a kind. */
export const SAY = 'write a prefab file (src/assets/prefabs/<key>.prefab) and `cmd.instantiate` it (`world.instantiate` outside a system), its token in src/game/prefabs.ts';
/** A kind defined: `kind(` not after a word or a dot (`world.kindOfEntity(e)` passes). */
export const KIND = /(^|[^\w.])kind\(/;
/** A kind spawned: `spawn(` with a name first (`cmd.spawn()` passes). */
export const SPAWN = /\bspawn\(\s*[A-Za-z_$][\w$.]*\s*[,)]/;

/** Every line of a game module that defines a kind or spawns one. Comments say what they like. */
export function kindsIn(text: string): Finding[] {
  const out: Finding[] = [];
  text.split('\n').forEach((line, i) => {
    if (/^\s*\*|^\s*\/\*/.test(line)) return;
    const code = line.replace(/\/\/.*$/, '');
    if (KIND.test(code)) out.push({ line: i + 1, rule: 'kind(', fix: SAY, text: line.trim() });
    else if (SPAWN.test(code)) out.push({ line: i + 1, rule: 'spawn(<a kind>)', fix: SAY, text: line.trim() });
  });
  return out;
}

export const checkEcs: Check = async ({ root, note }) => {
  const game = join(root, 'src', 'game');
  const systems = join(game, 'systems');
  // A walk that finds nothing is said, never passed in silence: a misnamed folder would print clean.
  if (!existsSync(game)) {
    note?.(`ecs: no src/game/ under ${root}, nothing checked`);
    return [];
  }
  const findings: CheckFinding[] = [];
  const add = (path: string, found: Finding[]): void => {
    for (const f of found) findings.push({ file: named(root, path), line: f.line, rule: f.rule, fix: f.fix, text: f.text });
  };
  const files = await sources(game);
  const texts = new Map<string, string>();
  for (const path of files) texts.set(path, await readFile(path, 'utf8'));
  // Every data component the game declares, by its name in code: none may be in a parallel system.
  const data = new Set([...texts.values()].flatMap(dataComponentsIn));
  for (const path of files) {
    const text = texts.get(path)!;
    if (path.startsWith(systems + sep)) {
      add(path, checkSystemSource(text));
      add(path, checkParallelData(text, data));
    }
    add(path, checkModuleState(text));
    add(path, kindsIn(text));
  }
  return sorted(findings);
};
