/**
 * The bare imports of a package's shipped modules (Docs/squidwright-implementation.md 1.9), for the dev
 * server's pre-bundling (`config.ts`' `package-deps`). The engine and the editor are excluded from
 * pre-bundling (served as modules, their `import.meta.hot` live), and Vite pre-bundles nothing an excluded
 * package imports by itself: in source mode the packages sit outside `node_modules` and its scanner reads
 * them through their entries as the project's own; in published mode they are under `node_modules`, which
 * the scanner never reads, so `pixi.js` and `three` were served raw -- and pixi's CommonJS `eventemitter3`
 * broke the page. Named in `optimizeDeps.include`, each is pre-bundled in both modes.
 *
 * A cheap pattern over the text, not a parse: an import in a comment or a template literal is collected too,
 * and harmless -- a relative one, `@vibe/*` or `node:*` is dropped, and the plugin keeps only what resolves
 * from the project. `import type` and `export type` are dropped (a `.ts` in source mode; the published
 * `.js` has none). Defines only.
 */
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { createRequire, isBuiltin } from 'node:module';
import { join, relative, resolve, sep } from 'node:path';

/** `import ... from`, `export ... from` (group 1 `type` when type-only, group 2 the specifier). */
const FROM = /(?:^|[;\n}])\s*(?:import|export)\b(\s+type\b)?[^'";]*?\bfrom\s*['"]([^'"]+)['"]/g;
/** `import 'x'`. */
const BARE = /(?:^|[;\n])\s*import\s*['"]([^'"]+)['"]/g;
/** `import('x')`. */
const DYNAMIC = /\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/g;

/**
 * Every file the exports map of the package at `dir` names, relative to the project at `root` (`/`-separated):
 * the scanner's entries. An entry is a path (the source form) or `{ types, default }` (the published form,
 * `vibe pack`): the code is `default`.
 */
export function packageEntries(root: string, dir: string): string[] {
  const { exports: map } = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as { exports?: Record<string, string | { default: string }> };
  return Object.values(map ?? {}).map((entry) => relative(root, join(dir, typeof entry === 'string' ? entry : entry.default)).split(sep).join('/'));
}

/** Is `spec` a package's name, and not one of ours or node's (with or without the `node:` prefix)? */
const foreign = (spec: string): boolean => !spec.startsWith('.') && !spec.startsWith('/') && !spec.startsWith('@vibe/') && !spec.startsWith('node:') && !isBuiltin(spec) && !spec.includes('?');

/** The bare specifiers `text` imports at run time. */
export function bareImports(text: string): string[] {
  const out: string[] = [];
  for (const m of text.matchAll(FROM)) if (m[1] === undefined) out.push(m[2]!);
  for (const m of text.matchAll(BARE)) out.push(m[1]!);
  for (const m of text.matchAll(DYNAMIC)) out.push(m[1]!);
  return out.filter(foreign);
}

/** Every module file under `dir` with `ext` (`.js` or `.ts`), but tests, `.d.ts` and anything under a `fixtures/`. */
function modules(dir: string, ext: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === 'fixtures' || entry.name.startsWith('.')) continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...modules(full, ext));
    else if (entry.name.endsWith(ext) && !entry.name.endsWith('.d.ts') && !entry.name.includes('.test.')) out.push(full);
  }
  return out;
}

/** The bare imports of the package at `dir`, deduped and sorted: its `dist/**\/*.js` when it has one (published), else its `src/**\/*.ts`. */
export function packageImports(dir: string): string[] {
  const published = existsSync(join(dir, 'dist'));
  const files = modules(join(dir, published ? 'dist' : 'src'), published ? '.js' : '.ts');
  return [...new Set(files.flatMap((file) => bareImports(readFileSync(file, 'utf8'))))].sort();
}

/** The package a specifier names: its first segment, two for a scope (`three/addons/x.js` → `three`, `@a/b/c` → `@a/b`). */
export const packageOf = (spec: string): string => spec.split('/').slice(0, spec.startsWith('@') ? 2 : 1).join('/');

/**
 * The specifiers of `specs` whose package is installed for the project at `root`: a package's optional
 * import, not installed here, never stops the start. The package is looked for, not the subpath: node's
 * `require.resolve` is CommonJS resolution and would refuse an ESM-only package or a subpath exported under
 * `import` alone -- which Vite's optimizer resolves fine.
 */
export function resolvable(root: string, specs: readonly string[]): string[] {
  const require = createRequire(join(resolve(root), 'package.json'));
  const installed = (name: string): boolean => (require.resolve.paths(name) ?? []).some((dir) => existsSync(join(dir, name, 'package.json')));
  return specs.filter((spec) => installed(packageOf(spec)));
}
