/**
 * `@vibe/pipeline/debugger`: the debugger's core (`studio/debugger/`, Docs/studio.md §13) for a host that carries
 * Chrome's debugging protocol its own way -- the Squidwright app, over each project window's
 * `webContents.debugger` (`packages/studio/electron/debugger.ts`). The dev server's own host is `studio/debugger/server.ts`,
 * over a WebSocket. A subpath of its own, as `./launcher` is: node's side, never the browser's.
 *
 * - `createSession`: one project's breakpoints and pauses over a `Cdp` (`session.ts`).
 * - The model's list rules and `breakpoints.json`'s shape (`model.ts`): what the app's store reads and writes.
 *
 * Defines only.
 */
export {
  createSession,
  DEBUGGER_COMMANDS,
  isCommand,
  linkedPackages,
  sourceFromServer,
  type BreakpointStore,
  type Cdp,
  type DebuggerCommand,
  type DebugSession,
  type DebugSource,
  type DebugView,
  type SessionOptions,
} from './studio/debugger/session.ts';
export { breakpointsOf, isBreakpoint, shownBreakpoints, toggleBreakpoint, withBreakpoints, type Breakpoint, type ShownBreakpoint } from './studio/debugger/model.ts';
