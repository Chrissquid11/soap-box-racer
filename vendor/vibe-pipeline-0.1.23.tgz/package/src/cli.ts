#!/usr/bin/env -S node --disable-warning=ExperimentalWarning
/**
 * `vibe`, the pipeline's one entry (Docs/assets.md §4): the only module under
 * `packages/pipeline/src/` that acts when it is loaded -- every other one only
 * defines, so the Vite config and the dev server can import them for free.
 *
 *   vibe dev [--isolated] [--port <n>]   the generated files, then the dev server (npm run dev)
 *   vibe build [--debug]                 typecheck, then the build (npm run build, build:debug)
 *   vibe preview [--port <n>]            dist/ served (npm run preview)
 *   vibe typecheck                       the generated files, then the project's tsc
 *   vibe test [folder...] [--packages <dir,dir>] [--no-checks]
 *                                        every *.test.ts under each (default src/), then the checks
 *                                        over the project (`checks/`), exit 1 on a finding
 *   vibe assets                          the generated files (npm run assets in the workspace, postinstall; also `keys`)
 *   vibe packs                           every pack zipped into public/packs/ (npm run packs)
 *   vibe export [filter...] [--force] [--check] [--dry]
 *                                        (npm run export: `assets/command.ts`, which says what each does)
 *   vibe sync                            the package's Claude files into .claude/ (postinstall: `agent/sync.ts`)
 *   vibe pack [--version <x.y.z>] [--out <dir>]
 *                                        the workspace's packages as tarballs into release/ (`pack/pack.ts`)
 *   vibe new <dir> [--name <any name>] [--package <npm name>] [--port <port>]
 *                  [--source <path> | --submodule <url> | --tarballs <dir>] [--lfsconfig <file>] [--no-install]
 *                                        a new game from the template, anywhere (`new/new.ts`)
 *
 * The project is the folder the command runs in -- a project's own `package.json` runs it
 * (`examples/sandbox/`'s; the root's scripts run that one's with `npm run -w`, which runs it
 * there) -- or `--root <dir>` anywhere on the line. The table is `commands.ts`.
 *
 * Node strips the types: the file's real path (`packages/pipeline/src/cli.ts`, which npm links
 * as `node_modules/.bin/vibe`) is outside `node_modules`. `import.meta.main` cannot tell this file
 * it is the entry: it is `false` for a `.ts` entry on Node 24.2 (a quirk of type stripping). So it
 * simply acts.
 */
import { run } from './commands.ts';

try {
  process.exitCode = await run(process.argv.slice(2));
} catch (err) {
  console.error(err instanceof Error ? err.message : err);
  process.exitCode = 1;
}
