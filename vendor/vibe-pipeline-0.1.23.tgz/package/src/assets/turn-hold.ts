/**
 * The link between the dev server's two plugins for a Claude turn
 * (Docs/modeler.md M21, D110): the agent's knows when a turn runs and ends,
 * the assets' exports Gladius scripts and can build one -- neither imports the
 * other, both are handed this.
 *
 * - **While any conversation's turn runs** (`turns`, the agent's), a Gladius
 *   script's auto-export is held: its shipped `.glb` -- in Git LFS, loaded by
 *   the game -- is not rewritten for every intermediate save, broken ones and
 *   all. The scripts held are listed here (`held`), the pages told
 *   (`vibebase:assets`' `held`), and the Model tab shows each save as a
 *   preview build instead.
 * - **When the last turn ends** (`over`, the agent's call, after a turn left
 *   broken was sent back to fix it): each held script exported once, as it is
 *   on disk then -- a turn stopped half way too. `over` resolves once those
 *   exports have ended and the watcher has seen what they wrote, and only then
 *   does the agent replay the held code (`conversations.ts`' `turnsEnded`): a
 *   page the replay reloads finds the new `.glb` in the asset registry, never
 *   a prefab naming a model not there yet. While they run, `exporting` is
 *   their promise -- what "Reload now" waits for.
 * - **A turn's scripts built** (`check`, the assets server's: `gladius query
 *   --checks none` with the export's parameters): the errors of each that
 *   does not build, for the agent to send the turn back with (D110).
 *
 * Kept on `globalThis`, like the agent's conversations: Vite restarts the
 * dev server in-process when `vite.config.ts` changes -- a turn may edit it;
 * a change to the pipeline's code restarts it as a new process when the
 * turns end (`vibe dev`, `commands.ts`, through `afterTurns`) -- and
 * the held list must outlive the server that made it. The functions are put
 * in again by each new server; the list is data. And a project route's push
 * (`send`) rides on it to the live server's channel.
 */
import type { PushMessage } from './api-types.ts';

/** One script's build at a turn's end: the errors Gladius reported, each with its line where it names one. */
export interface ScriptCheck {
  path: string;
  errors: { message: string; line?: number }[];
}

export interface TurnLink {
  /** Is a turn of any conversation running: the agent's plugin answers. */
  turns: () => boolean;
  /** The Gladius scripts whose export waits for the turns' end, in the order held. */
  readonly held: string[];
  /**
   * The last turn ended: every held script exported now (the assets server's) -- answering what became of each, in
   * words, for the transcript, once those exports have ended and the watcher has seen the files they wrote.
   */
  over: () => Promise<string[]>;
  /** The exports `over` (or a server's start, for a list kept on disk) is making, until they end and their files are seen; null when none run. */
  exporting: Promise<void> | null;
  /** The scripts among `paths` that do not build, with Gladius's errors (the assets server's); none for a script that builds. */
  check: (paths: readonly string[]) => Promise<ScriptCheck[]>;
  /** The held list to every page, through the live server's socket (each new server puts its own in). */
  push?: (held: string[]) => void;
  /** Any message to every page on the assets push channel, the same way: a project route's (`tools/tools.ts`' `ctx.push`). */
  send?: (message: PushMessage) => void;
  /** Told when the turns end, once the held exports are made, just before the held code is replayed (`onTurnEnd`); data, kept across a restart in-process. */
  readonly ended: (() => void)[];
  /** Every write the agent has queued done (its conversations' stores and index): what a restart's exit waits for. The agent's plugin puts it in. */
  flushed?: () => Promise<void>;
}

/** Where the link is kept across Vite's in-process restarts. */
export const TURN_LINK_KEY = Symbol.for('vibebase.turnLink');

/** A link of its own, with no turns and nothing to export or check: a test's, and what each plugin starts from. */
export function freshLink(): TurnLink {
  return { turns: () => false, held: [], over: async () => [], exporting: null, check: async () => [], ended: [] };
}

/** The process's link: made the first time, the same one after a restart. `key`, a test's own. */
export function turnLink(key: symbol = TURN_LINK_KEY): TurnLink {
  const g = globalThis as unknown as Record<symbol, TurnLink | undefined>;
  return (g[key] ??= freshLink());
}

/**
 * `listener` told each time the turns end (`turnEnded`: the agent's plugin, once no conversation's
 * turn runs and the held exports are made, just before the held code is replayed): `vibe dev`'s restart owed to a pipeline change made
 * during a turn. Answers the function that stops it.
 */
export function onTurnEnd(link: TurnLink, listener: () => void): () => void {
  link.ended.push(listener);
  return () => {
    const at = link.ended.indexOf(listener);
    if (at >= 0) link.ended.splice(at, 1);
  };
}

/** The turns ended: every `onTurnEnd` listener told, in the order added (each may stop itself as it is told). */
export function turnEnded(link: TurnLink): void {
  for (const listener of link.ended.slice()) listener();
}

/**
 * `act` once no turn runs: at once when none does; else at the end of the turns, `graceMs` after it
 * (the replayed code's swaps fetched by the page first) -- and if a turn began in that grace, at the
 * end of that one instead, so `act` never cuts a turn off. `vibe dev`'s restart owed to a pipeline
 * change.
 */
export function afterTurns(link: TurnLink, graceMs: number, act: () => void): void {
  if (!link.turns()) {
    act();
    return;
  }
  const arm = (): void => {
    const off = onTurnEnd(link, () => {
      if (link.turns()) return;
      off();
      setTimeout(() => (link.turns() ? arm() : act()), graceMs);
    });
  };
  arm();
}
