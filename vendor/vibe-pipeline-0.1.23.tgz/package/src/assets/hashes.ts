/**
 * Content hashes, and the parts found in the same read (Docs/assets.md §2 step
 * 4, §3 "Parts", §4 "Caches").
 *
 * A source is read once, **streamed**: every chunk goes to the sha1 and to its
 * row's parts scanner together, so finding what a model names costs no read of
 * its own, and nothing is held whole but what a scanner keeps. The answer is
 * cached in `.cache/assets/hashes.json` as
 * `{ "<path>": [mtimeMs, size, "<sha1>", parts?] }`, valid while the file's
 * mtime and size are those: a warm start opens no file. A rename or a `git
 * pull` that rewrites mtimes costs one re-read of what it touched; `--check`
 * reads every file. A row read within `racyMs` of its file's mtime is not
 * trusted until a later read finds the mtime old (git's racy rule: coarse
 * timestamps).
 *
 * The cache is written a second after its last change, **atomically** (a temp
 * file, then a rename). The CLI and the dev server may both write it; the last
 * whole file wins, and the worst case is a hash computed twice. A write that
 * fails (a read-only `.cache/`, a full disk) is told to `onError`, never
 * swallowed: every start would otherwise be cold without a word.
 *
 * The streamed read itself, `hashFile`, is `fs.ts`'s. sha1, as git uses it:
 * for identity, not security.
 */
import { mkdir, readFile, stat } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { hashFile, sortedObject, writeAtomic, type FileHash } from './fs.ts';
import { CACHE } from './kinds.ts';
import type { Deps } from './parts.ts';

/** One row of `hashes.json`: the parts, and the scanner's `version` that found them where it is past 1. */
export type HashRow = [mtimeMs: number, size: number, sha1: string, parts?: string[], scanner?: number];

export class HashCache {
  /** `.cache/assets/hashes.json`, absolute. */
  readonly file: string;
  readonly rows = new Map<string, HashRow>();
  /** Milliseconds after the last change the file is written. */
  readonly delay: number;
  /** Told when a delayed write fails. */
  private readonly onError: (err: Error) => void;
  /**
   * How near its read a file's mtime makes its row suspect (git's "racy" rule): on a disk with coarse
   * timestamps (FAT, exFAT: 2 s; some SMB shares) an edit that keeps the size within one tick keeps the
   * mtime too, and the row would answer for the new bytes. Such a row is kept but never answers, nor is
   * written to the file: the next look reads the file again, and once its mtime is old enough it is trusted.
   */
  readonly racyMs: number;
  private readonly racy = new Set<string>();
  private timer: ReturnType<typeof setTimeout> | undefined;
  private dirty = false;

  /** `delay` 0: written only by `save()` (the CLI's way). */
  constructor(root: string, delay = 1000, onError: (err: Error) => void = (err) => console.error(`[assets] the hashes cache was not written: ${err.message}`), racyMs = 3000) {
    this.file = join(root, CACHE, 'hashes.json');
    this.delay = delay;
    this.onError = onError;
    this.racyMs = racyMs;
  }

  /** The file read, if there is one; a broken one is a cold cache. */
  async load(): Promise<void> {
    try {
      const json = JSON.parse(await readFile(this.file, 'utf8')) as Record<string, HashRow>;
      for (const [path, row] of Object.entries(json)) if (Array.isArray(row) && typeof row[2] === 'string') this.rows.set(path, row);
    } catch {
      // No cache yet, or one cut short: everything is read once.
    }
  }

  /** The row for a file whose mtime and size are these, or undefined. */
  get(path: string, mtimeMs: number, size: number): HashRow | undefined {
    if (this.racy.has(path)) return undefined;
    const row = this.rows.get(path);
    return row && row[0] === mtimeMs && row[1] === size ? row : undefined;
  }

  /** A row. `racy`: read so soon after its mtime that the mtime may not tell the next edit apart (above). */
  set(path: string, mtimeMs: number, size: number, sha1: string, parts?: readonly string[], scanner = 1, racy = false): void {
    this.rows.set(path, parts ? (scanner > 1 ? [mtimeMs, size, sha1, [...parts], scanner] : [mtimeMs, size, sha1, [...parts]]) : [mtimeMs, size, sha1]);
    if (racy) this.racy.add(path);
    else this.racy.delete(path);
    this.changed();
  }

  forget(path: string): void {
    this.racy.delete(path);
    if (this.rows.delete(path)) this.changed();
  }

  /** The rows of files no longer there (deleted, renamed, a fixture removed) let go; how many. */
  prune(there: (path: string) => boolean): number {
    let gone = 0;
    for (const path of [...this.rows.keys()]) {
      if (there(path)) continue;
      this.rows.delete(path);
      this.racy.delete(path);
      gone++;
    }
    if (gone > 0) this.changed();
    return gone;
  }

  /** Written a second after the last change: fifty files hashed are one write. */
  private changed(): void {
    this.dirty = true;
    if (this.delay <= 0) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.save().catch((err: unknown) => this.onError(err as Error)), this.delay);
    this.timer.unref?.();
  }

  /** The cache written now, atomically, its rows sorted (a stable file to diff when debugging). */
  async save(): Promise<void> {
    if (this.timer) clearTimeout(this.timer);
    this.timer = undefined;
    if (!this.dirty) return;
    this.dirty = false;
    try {
      await mkdir(dirname(this.file), { recursive: true });
      await writeAtomic(this.file, JSON.stringify(sortedObject([...this.rows].filter(([path]) => !this.racy.has(path)))) + '\n');
    } catch (err) {
      // Not written: the next change, or the next save, tries again.
      this.dirty = true;
      throw err;
    }
  }
}

/** A file's hash through the cache: `read` false when the cache answered. */
export interface Hashed extends FileHash {
  read: boolean;
}

/**
 * A file's hash, and its parts when `deps` is given: from the cache while its
 * mtime and size match (and it has parts found by this scanner's version, if
 * parts are wanted), else read. A file that changed while it was read is
 * answered but not cached.
 */
export async function hashOf(cache: HashCache, root: string, path: string, options: { deps?: Deps; check?: boolean } = {}): Promise<Hashed> {
  const abs = join(root, path);
  const before = await stat(abs);
  if (!options.check) {
    const row = cache.get(path, before.mtimeMs, before.size);
    const scanner = options.deps?.version ?? 1;
    if (row && (!options.deps || (row[3] !== undefined && (row[4] ?? 1) === scanner))) return { sha1: row[2], size: row[1], ...(row[3] ? { parts: row[3] } : {}), read: false };
  }
  const read = await hashFile(abs, options.deps?.(path));
  const after = await stat(abs);
  if (after.mtimeMs === before.mtimeMs && after.size === before.size && read.size === after.size && !read.partsError) {
    cache.set(path, after.mtimeMs, after.size, read.sha1, read.parts, options.deps?.version, Date.now() - after.mtimeMs < cache.racyMs);
  }
  return { ...read, read: true };
}
