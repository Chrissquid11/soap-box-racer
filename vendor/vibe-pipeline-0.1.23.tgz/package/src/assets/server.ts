/**
 * The dev server's side of the pipeline (Docs/assets.md §5): the API under
 * `/__assets/`, the push channel, the job runner wired to the game tabs,
 * auto-export, and what Vite's hooks ask of the index -- reached by `vite.ts`
 * with `await import()` inside `configureServer`, so neither a build nor a
 * `keys` run loads any of it.
 *
 * It is handed what it needs of Vite, never Vite itself: the project root, a
 * push channel (`server.ws.send`), the watcher's events (`watch`), the
 * websocket's connections (`connection`) -- so `server.test.ts` runs it on a
 * bare `http.createServer` with a fake channel.
 *
 * - **The index on the watcher.** Every event under the roots goes to the
 *   index (`catalog.onEvent`), but the server's own: a write is expected first
 *   with the stat it will have (the index consumes its event, `hotUpdate` reads
 *   `catalog.writes`), and a removal of its own is applied by `learn`, its
 *   `unlink` not news. After each write the index learns what changed, the
 *   sources it moved settle, and the call answers the diff from the client's
 *   `since` -- one commit, no gap (§6).
 * - **The push channel**: `changed` debounced on quiet (150 ms after the last
 *   commit, not every 150 ms), with the Trash's slots when re-read within it;
 *   `job` from the runner; `convert` for a browser step; `reload` from
 *   `hotUpdate`; `tools` after a look.
 * - **The serial runner** (`jobs.ts`), its browser steps parked: with no game
 *   tab on this machine -- a loopback websocket -- one is `unmade` at once and
 *   queued again on the next connection, which is also asked about every
 *   conversion still waiting for a claim. Jobs wait for the first look for
 *   tools: without it an export could not tell `unmade` from a failure. A job
 *   already parked when the last tab closes keeps its claim window (60 s) on
 *   purpose: a tab reloaded, or the designer's second window, connects within
 *   it and claims; nobody does, and it ends `unmade` as any unclaimed one
 *   does, the runner's one slot held meanwhile.
 * - **Auto-export** (§4): a source a watch event on the Source side -- itself, a
 *   part, its record, a folder's `export.json`, its intermediate -- left
 *   `stale` or `missing`, once quiet, unless a step of its row is not `auto`;
 *   an option set by `PUT sidecar`; and what a tool found again can now make.
 *   Never the server's own writes: an undone export stays `stale` until asked.
 * - **Once listening** (`listening`): the tools looked for, the trash and the
 *   caches pruned, every source hashed, `src/` read for `GET uses`.
 * - **Names** (`GET names`): each against the folder and its twin, the index's
 *   keys, and the names asked before it in the same call -- one drop's files
 *   may not share a name or a key -- and, with `source=` said, refused as the
 *   import would refuse it. A source out of the build has no key to share --
 *   but with a source of its stem beside it, which would share its record.
 * - **In the build** (`PUT sidecar { include }`): a source taken out has its
 *   record say `"include": false` and its exports moved to a slot of their
 *   own first, in the same call -- answered as `slot`, which the tool's undo
 *   restores before it puts the source back in; put back in, the flag comes
 *   off and the source, `missing`, is exported. `PUT import` takes
 *   `include=false` for a source: its record is written saying so, and
 *   nothing is queued.
 *
 * Every route answers JSON (`GET file` and `GET thumb` the bytes). A refusal is
 * `{ refused, suggested? }` with `403`, `409`, `413`, `415` or `422`; what is
 * not there, `404`. Nothing at module level.
 */
import { randomBytes } from 'node:crypto';
import { createReadStream, readFileSync } from 'node:fs';
import { copyFile, lstat, mkdir, open, readdir, readFile, rename, rm, stat, utimes, writeFile } from 'node:fs/promises';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { dirname, isAbsolute, join, relative } from 'node:path';
import { pipeline } from 'node:stream/promises';
import type {
  ConvertMessage,
  CopyAnswer,
  DeleteAnswer,
  Diff,
  ExportAnswer,
  ExportRecord,
  FileStats,
  HeldAnswer,
  KindsAnswer,
  ImportAnswer,
  JobInfo,
  JobMessage,
  ModelAnswer,
  ModelMadeAnswer,
  ParamsAnswer,
  Run,
  PreviewFailure,
  ScriptAnswer,
  MoveAnswer,
  ExportAsAnswer,
  ReferrersAnswer,
  NameAnswer,
  Options,
  PushEvent,
  PrefabAnswer,
  PushMessage,
  QueuedJobInfo,
  RestoreAnswer,
  SidecarAnswer,
  ThumbMiss,
  ToolLook,
  TraceAnswer,
  TraceFaces,
  ToolsAnswer,
  ToolsCheckAnswer,
  Use,
  WatchType,
  WriteAnswer,
} from './api-types.ts';
import { Catalog } from './catalog.ts';
import { withUid } from './json-spans.ts';
import { keepUid, newUid, sidecarOf, sidecarText } from './uid.ts';
import { planRefs, referrersOf, refsTo, type RefsFilter } from './stamp.ts';
import { REAL_CLOCK, type Clock, type TimerHandle } from './clock.ts';
import { Runs, exportSource } from './export.ts';
import { familyOf, isRefusal, planCopy, planFolderMove, planMove, sides, sourceOf, type PlanRefusal, type Step } from './families.ts';
import { renameCase } from './case.ts';
import { caseKey } from '@vibe/engine/case-key';
import { code, exists, moveFile, sha1, writeAtomic } from './fs.ts';
import { HashCache, hashOf } from './hashes.ts';
import { Refused, authority, bodyToFile, checkPath, drain, guardHost, guardWrite, isLoopback, mayWrite, mutating, readBody, readJson, sendJson, trustedHost } from './http.ts';
import { BrowserBridge, Drops, Runner, newId, type JobControl, type QueuedJob } from './jobs.ts';
import { parsePhysicsMaterial } from '@vibe/engine/physics-material-file';
import { CACHE, ENGINE_DATA_KINDS, KINDS, MATERIAL_SUFFIX, MIME, PREFAB_SUFFIX, ROOTS, SCENE_SUFFIX, THUMB_MISS_HEADER, PUSH_EVENT, isDataKind, kindDef, kindRows, type ProjectKinds } from './kinds.ts';
import {
  baseName,
  devUrl,
  dirName,
  exportKey,
  exportPaths,
  extOf,
  folderRecordPath,
  globbed,
  hotUpdateFor,
  isRecordName,
  joinPath,
  keyOf,
  locate,
  norm,
  numbered,
  asProblem,
  recordPath,
  splitName,
  twin,
  under,
  underscored,
  validName,
  familyStem,
  READ_DIRS,
  WRITE_DIRS,
} from './paths.ts';
import { MODEL_SOURCE_EXT, aboveKinds, canonical, checkOptions, isFound, kindOptions, recipeFor, resolveOptions, type Found } from './recipes.ts';
import { folderChain, identity, parseRecord, readFolderDefaults, readRecord, recordText, sourceOptions, withInclude } from './record.ts';
import { queryParams } from './model-params.ts';
import { Latest, SUPERSEDED, buildPreview, previewParams, type PreviewBuilt } from './model-preview.ts';
import { queryModel } from './model-query.ts';
import { buildTrace, traceFaces } from './model-trace.ts';
import { sweepCopies } from './gladius-export.ts';
import { decodeForImport, importCopyName, importKind, importScript, sha256, starterScript, stemProblem } from './model-scripts.ts';
import { STATS_NEEDS, readStats } from './stats/index.ts';
import { webpStats } from './stats/image.ts';
import { peekPointer } from './stats/lfs.ts';
import { STEPS, stepInfo, type Job } from './steps/index.ts';
import { THUMB_SIZES, makeThumb, pruneCaches, statsFile, thumbFile, thumbHow, thumbTag } from './thumbs.ts';
import { lookForAll, mergeNeeds, npmVersions, setLocalTool, exec, type LookContext, type Need } from './tools.ts';
import { jsonProblem } from './json-problem.ts';
import type { ScriptCheck, TurnLink } from './turn-hold.ts';
import { emptyTrash, readTrash, remove, restore } from './trash.ts';
import { Uses } from './uses.ts';

/**
 * A script's trace's file name under `.cache/assets/trace/`, and its preview's under `preview/`: by the path's hash --
 * `a/b.lua` and `a_b.lua` once shared one, and one script's trace or preview was served for the other.
 */
export function traceName(path: string): string {
  return `${sha1(path)}.glb`;
}

/** Where the API is. */
const PREFIX = '/__assets/';

/** The push channel's event (`api-types.ts`'s `PushEvent`). */
const EVENT: PushEvent = PUSH_EVENT;

/** Why a browser step cannot run here: the runner's word, and the status's (§4, Jobs). */
const NO_TAB = 'needs a game tab open on this machine';

/** What `server.ws` is to this module: a channel to every page. */
export interface PushChannel {
  send(payload: { type: 'custom'; event: PushEvent; data: PushMessage }): void;
}

/** A page's websocket, as `server.ws.on('connection', (socket, req) => ...)` hands it over. */
export interface TabSocket {
  send(data: string): void;
  on(event: 'close', listener: () => void): unknown;
}

export interface AssetsServerOptions {
  /** The project root, absolute. */
  root: string;
  ws: PushChannel;
  /** The port the page is served on: the read-only refusal names it. */
  port?: () => number | undefined;
  /** This server's `server.allowedHosts` (`http.ts`' `allowedHosts`): `Host` names trusted beside this machine's. None: none. */
  hosts?: () => readonly string[];
  clock?: Clock;
  /** The terminal: one line per export, the pointers at startup. */
  log?: (line: string) => void;
  /** What failed in the background. */
  warn?: (line: string) => void;
  /** How tools are looked for: a test's canned answers. */
  look?: Partial<LookContext>;
  /** How `POST reveal` runs `open`, `explorer` or `xdg-open`: a test's stub. */
  reveal?: (bin: string, args: readonly string[]) => Promise<void>;
  /** The platform `POST reveal` speaks to. */
  platform?: NodeJS.Platform;
  /** Milliseconds: a file quiet before it settles (500), an own write expected (2000), `changed` debounced (150). */
  quietMs?: number;
  expectMs?: number;
  pushMs?: number;
  /** A tab's deadlines (60 000 each), and how long a drop is held for its rest (10 000). */
  claimMs?: number;
  sendMs?: number;
  holdMs?: number;
  /**
   * How long a turn's end waits for the watcher to report what its held exports wrote (2000), real time: the page the
   * held code's replay reloads must find the new file in Vite's globs, and a file never reported is waited for no longer.
   */
  seenMs?: number;
  /**
   * How long a turn's end waits for its held exports at most (60 000), real time: an export that hangs never keeps
   * the held code from its replay, nor "Reload now" from its reload -- it goes on, and its file lands when it does.
   */
  exportMs?: number;
  /** The hashes cache's write delay (1000; 0 writes only on `close`). */
  hashDelay?: number;
  /** The diffs the index keeps for `since` (1000): a client further behind gets the tree. */
  keepDiffs?: number;
  /**
   * The link with the agent's plugin (`turn-hold.ts`, Docs/modeler.md M21): while
   * a Claude turn runs a Gladius script's auto-export is held, and exported once
   * as the last turn ends; and a turn's scripts are built for D110's check.
   * None: nothing is ever held (a test's, or a dev server with no agent).
   */
  link?: TurnLink;
  /** The project's own kinds (`vibe({ kinds })`): listed by `GET kinds`, and their files' hot updates the glob's, as a level's. */
  kinds?: ProjectKinds;
}

export interface AssetsServer {
  readonly catalog: Catalog;
  /** The routes' work in-process, for the studio's MCP tools (Docs/mcp.md §3). */
  readonly calls: AssetsCalls;
  readonly runner: Runner;
  readonly bridge: BrowserBridge;
  /** The first walk, done: `GET tree` and every call but `GET tools` wait for it. */
  readonly ready: Promise<void>;
  /** A request under `/__assets/` answered; false for anything else (the next middleware's). */
  handle(req: IncomingMessage, res: ServerResponse): Promise<boolean>;
  /** A watcher event, an absolute path or one relative to the root. */
  watch(event: string, file: string): void;
  /** A page's websocket: a game tab on this machine, if it is loopback. */
  connection(socket: TabSocket, req: IncomingMessage): void;
  /** The HTTP server is listening: the tools, the prunes, the hashing, `src/` read. Resolves when all have ended. */
  listening(): Promise<void>;
  /**
   * Vite's `hotUpdate` for the client environment (§5's table): the reloads
   * sent, and what the hook answers -- `none` is `[]`, `vite` Vite's set, and
   * `globs` Vite's set less the file's own modules (`HotDecision.globsOnly`).
   */
  hotUpdate(file: string, type: WatchType): HotPass;
  /** `load`'s question for a `?url` id: the error to throw when the file is an LFS pointer. */
  pointer(id: string): Promise<string | undefined>;
  /** Is an export queued, running or parked? Packs are never zipped while one is. */
  busy(): boolean;
  /** Resolves once no job is queued, running or parked. */
  idle(): Promise<void>;
  /**
   * A move or an export-as with its repair passes under way (Docs/asset-ids.md §4): a promise of its end, or undefined
   * when none is. The plugin's regenerate waits for it -- a stamp landing between the move and its second pass would
   * write files outside what the step puts back.
   */
  repairing(): Promise<void> | undefined;
  /** The caches written; timers stopped. */
  close(): Promise<void>;
}

/** A route's work as a function: its query and its JSON body in, its answer out -- the route's and `call`'s (Docs/mcp.md §3). */
export type Op = (url: URL, body: Record<string, unknown>) => Promise<unknown>;

/** The routes whose work the studio's MCP tools call in-process (`AssetsServer.call`, Docs/mcp.md M3), and what each answers. */
export interface AssetOps {
  'GET uses': Use[];
  'GET jobs': JobInfo[];
  'POST referrers': ReferrersAnswer;
  'POST delete': DeleteAnswer;
  'POST restore': RestoreAnswer;
  'POST empty-trash': WriteAnswer;
  'POST mkdir': WriteAnswer;
  'PUT prefab': PrefabAnswer;
  'POST copy': CopyAnswer;
  'POST move': MoveAnswer;
  'POST model': ModelMadeAnswer;
  'POST export': ExportAnswer;
  'PUT sidecar': SidecarAnswer;
  'PUT export-as': ExportAsAnswer;
  'POST adopt': ModelMadeAnswer;
  'POST tools/check': ToolsCheckAnswer;
  'PUT tools': ToolsCheckAnswer;
  'GET params': ParamsAnswer;
  'POST trace': TraceAnswer;
}

/** What the studio's MCP tools reach of the assets server in-process: each a route's own work, past its guards. */
export interface AssetsCalls {
  /** The project's root, absolute. */
  readonly root: string;
  /** The project's own kinds (`vibe({ kinds })`): what a uid scan reads beside the engine's. */
  readonly kinds: ProjectKinds;
  readonly catalog: Catalog;
  /** A route's work (after the first walk): what the route answers; a refusal thrown as `Refused` (`status`, `body.refused`). */
  call<K extends keyof AssetOps>(route: K, query: Record<string, string>, body?: Record<string, unknown>): Promise<AssetOps[K]>;
  /** `PUT import`'s work with the file at `from` (absolute, read here) as its body; `query` the route's (`dest`, `name`, `replace`, `include`, `options`, `source`). */
  importFrom(from: string, query: Record<string, string>): Promise<ImportAnswer>;
  /** `GET thumb`'s work: the thumbnail's bytes -- cached, or made here where the server can -- or why there are none. */
  thumb(path: string, size: number): Promise<{ webp: Uint8Array; hash: string } | ThumbMiss>;
  /** Each job's message, as a tab hears it: the unsubscribe. */
  onJob(listener: (message: JobMessage) => void): () => void;
}

/**
 * What Vite's `hotUpdate` hook answers for a file: `[]`, Vite's set, Vite's set less the file's own modules,
 * or `src/assets/prefab-globs.ts` (a prefab file new while it did not parse, which the glob never took, parsing now),
 * or `src/assets/material-globs.ts` (a material file the same).
 */
export type HotPass = 'none' | 'vite' | 'globs' | 'prefabGlob' | 'materialGlob';

/** A job id as `jobs.ts` makes them: time-ordered, a folder's name under `.cache/assets/jobs/`. */
function jobId(raw: string | null): string {
  if (raw === null || !/^[a-z0-9]+-[0-9a-f]{6}$/.test(raw)) throw new Refused(422, 'no such job');
  return raw;
}

/** At most `n` of these at once, the rest waiting in order. */
function limiter(n: number): <T>(fn: () => Promise<T>) => Promise<T> {
  let running = 0;
  const waiting: Array<() => void> = [];
  return async <T>(fn: () => Promise<T>): Promise<T> => {
    if (running >= n) await new Promise<void>((resolve) => waiting.push(resolve));
    running++;
    try {
      return await fn();
    } finally {
      running--;
      waiting.shift()?.();
    }
  };
}

const unique = <T>(items: Iterable<T>): T[] => [...new Set(items)];

/**
 * A copy's text as the server's copy writes it (Docs/asset-ids.md rule 7: the editor's copies are new assets): a
 * record's uid, or a data file's (`dataFile`), replaced by a new one -- `make`'s -- and a record's `"as"` dropped
 * (rule 8): the copy exports under its own stem, never the original's export name, so the two never ship one key.
 * Undefined when the copy is the bytes as they are: a record with neither (its first export stamps a uid), a record or
 * data file that does not parse (the next stamp says so), any other file (a loose file's sidecar is not copied: the
 * copy is given a new one).
 */
export function freshCopy(path: string, text: string, dataFile: boolean, make: () => string = () => newUid()): string | undefined {
  if (isRecordName(baseName(path))) {
    try {
      const record = parseRecord(text);
      if (record.uid === undefined && record.as === undefined) return undefined;
      const copy = { ...record, ...(record.uid !== undefined ? { uid: make() } : {}) };
      delete copy.as;
      return recordText(copy);
    } catch {
      return undefined;
    }
  }
  return dataFile ? (withUid(text, make()) ?? undefined) : undefined;
}

/** A plan of `families.ts`, or its refusal thrown as the router answers it. */
function planned<T extends object>(plan: T | PlanRefusal): T {
  if (isRefusal(plan)) {
    const { status, refused, ...extra } = plan;
    throw new Refused(status, refused, extra);
  }
  return plan;
}

export function createAssetsServer(options: AssetsServerOptions): AssetsServer {
  const { root, ws } = options;
  const clock = options.clock ?? REAL_CLOCK;
  const log = options.log ?? ((line: string) => console.log(line));
  const warn = options.warn ?? ((line: string) => console.error(line));
  const onError = (err: Error): void => warn(`[assets] ${err.message}`);
  const port = options.port ?? (() => undefined);
  const hosts = options.hosts ?? (() => []);
  const expectMs = options.expectMs ?? 2000;
  const abs = (path: string): string => join(root, path);
  /** The data kinds beside the table's (the engine's physics materials, a project's own): their folders and extensions. */
  const dataKinds = Object.values(options.kinds ?? {}).map((kind) => ({ dir: joinPath(ROOTS.boot.dir, kind.dir), ext: [...kind.ext] }));
  const dataDirs = dataKinds.map((k) => k.dir);
  /** A path from the watcher or Vite, relative to the root with `/`; undefined outside it. */
  const rel = (file: string): string | undefined => {
    const r = norm(isAbsolute(file) || /^[a-zA-Z]:[\\/]/.test(file) ? relative(root, file) : file);
    return r === '..' || r.startsWith('../') || r === '' ? undefined : r;
  };

  /** Is `path` (relative) a data file -- a data kind's (a pack's materials too) or one of the project's own kinds' -- whose uid is in its JSON? */
  const dataFile = (path: string): boolean => {
    const where = locate(path);
    if (where?.kind !== undefined && where.root !== 'source' && isDataKind(where.kind)) return kindDef(where.kind).ext.includes(extOf(path));
    return ownKindFile(path);
  };

  /** Is `path` (relative) a key of one of the project's own kinds: under its folder in `src/assets/`, its extension, no `_` on the way? */
  const ownKindFile = (path: string): boolean =>
    Object.values(options.kinds ?? {}).some((kind) => {
      const dir = `${ROOTS.boot.dir}/${kind.dir}/`;
      if (!path.startsWith(dir) || path.slice(dir.length).split('/').some((part) => part.startsWith('_'))) return false;
      return kind.ext.includes(path.slice(path.lastIndexOf('.') + 1).toLowerCase());
    });

  // ---------------------------------------------------------------- the push channel

  const push = (data: PushMessage): void => ws.send({ type: 'custom', event: EVENT, data });
  /** Prefab and material files made while they did not parse, by kind and key (`prefabs:crates/big`): kept from the glob until they do (`hotUpdate`). */
  const unborn = new Set<string>();
  /** The `seq` the last `changed` brought the pages to. */
  let sentSeq = 0;
  let lastDiff: Diff | undefined;
  let pushTimer: TimerHandle | undefined;
  /** A commit: `changed` is sent once the commits stop for `pushMs` -- fifty files from the Finder are one message. */
  function changed(diff: Diff): void {
    lastDiff = diff;
    if (pushTimer !== undefined) clock.clearTimeout(pushTimer);
    pushTimer = clock.setTimeout(flushChanged, options.pushMs ?? 150);
  }
  function flushChanged(): void {
    pushTimer = undefined;
    if (catalog.seq === sentSeq || lastDiff === undefined) return;
    const diff = catalog.since(sentSeq);
    // Further back than the diffs kept (a second walk): the last commit's diff, whose `from` every page sees as a gap.
    push({ type: 'changed', diff: 'tree' in diff ? lastDiff : diff });
    sentSeq = catalog.seq;
  }

  // ---------------------------------------------------------------- the index

  const hashes = new HashCache(root, options.hashDelay ?? 1000, onError);
  const runs = new Runs(root);
  const uses = new Uses(root);
  const catalog = new Catalog({
    root,
    // A data kind beside the table's -- the engine's physics materials, a project's own -- listed as loose files.
    dataKinds,
    hashes,
    runs,
    browser: 'none',
    lanes: 2,
    clock,
    expectMs,
    ...(options.quietMs !== undefined ? { quietMs: options.quietMs } : {}),
    ...(options.keepDiffs !== undefined ? { keepDiffs: options.keepDiffs } : {}),
    onChange: changed,
    onError,
    onQuiet: (moved) => {
      if (closed) return;
      // A watch event on the Source side -- a source, a part, a record, a folder's defaults, an intermediate -- exports.
      const candidates = new Set<string>();
      for (const [path, sources] of moved) if (locate(path)?.root === 'source') for (const s of sources) candidates.add(s);
      // A Gladius script saved while a Claude turn runs: held to the turns' end (M21), its shipped export written once then.
      for (const s of candidates) if (!holdExport(s)) autoExport(s);
    },
  });

  /** Removals of the server's own, for `expectMs`: their `unlink` (or a folder's `unlinkDir`) is not news -- `learn` applies them. */
  const ownGone = new Map<string, TimerHandle>();
  /** Who hears each job's message in-process, as a tab hears it on the push channel (`onJob`: the studio's export tool). */
  const jobListeners = new Set<(message: JobMessage) => void>();
  /** Folders the server made (a move's, a `mkdir`'s): their `addDir` is not news. */
  const ownDirs = new Map<string, TimerHandle>();
  function own(map: Map<string, TimerHandle>, path: string): void {
    const old = map.get(path);
    if (old !== undefined) clock.clearTimeout(old);
    map.set(
      path,
      clock.setTimeout(() => map.delete(path), expectMs),
    );
  }
  /** Paths about to be removed, with nothing in their place: no write of ours is waited for there, and their `unlink` is ours. */
  function removing(paths: Iterable<string>): void {
    for (const p of paths) {
      catalog.unexpect(p);
      own(ownGone, p);
    }
  }

  /** A finished file put in place at `dest` from `tmp` (absolute): expected first, with the stat it has -- again if the move made a new one. */
  async function place(tmp: string, dest: string, replaced: boolean): Promise<void> {
    const before = await stat(tmp);
    catalog.expect(dest, before, replaced);
    try {
      await moveFile(tmp, abs(dest));
    } catch (err) {
      catalog.unexpect(dest);
      throw err;
    }
    const after = await stat(abs(dest));
    if (after.mtimeMs !== before.mtimeMs || after.size !== before.size) catalog.expect(dest, after, replaced);
  }

  /**
   * A replace that could not put its file in place: the family it sent to
   * `slot` brought back where it was, each file expected as the server's own.
   * What could not come back is said in `err`, with the slot it is in.
   */
  async function putBack(slot: string, err: Error): Promise<void> {
    const back = await restore(root, slot, {
      replace: true,
      before: async (moves) => {
        for (const m of moves) catalog.expect(m.to, await stat(m.from), m.replaced);
      },
    }).catch((e: Error) => ({ refused: e.message }));
    err.message += 'refused' in back ? `; and what it replaced is still in the trash, slot ${slot}: ${back.refused}` : '; what it replaced is back';
  }

  /** A dot-named temp file beside `dest` (never listed, never globbed). */
  const tempBeside = (dest: string): string => join(dirname(abs(dest)), `.${baseName(dest)}.${randomBytes(4).toString('hex')}.tmp`);

  /** Bytes written at `dest` as one of the server's own writes. */
  async function writeOwn(dest: string, data: string | Uint8Array, replaced: boolean): Promise<void> {
    const tmp = tempBeside(dest);
    await mkdir(dirname(tmp), { recursive: true });
    await writeFile(tmp, data); // write-ok: a temp file, renamed below
    try {
      await place(tmp, dest, replaced);
    } catch (err) {
      await rm(tmp, { force: true });
      throw err;
    }
  }

  /** `from` copied to `dest` as one of the server's own writes; its hash carried over when the cache knows it. */
  async function copyOwn(from: string, dest: string): Promise<void> {
    const tmp = tempBeside(dest);
    await mkdir(dirname(tmp), { recursive: true });
    await copyFile(abs(from), tmp);
    try {
      await place(tmp, dest, false);
    } catch (err) {
      await rm(tmp, { force: true });
      throw err;
    }
    const was = await stat(abs(from));
    const row = hashes.get(from, was.mtimeMs, was.size);
    if (row) {
      const now = await stat(abs(dest));
      hashes.set(dest, now.mtimeMs, now.size, row[2], row[3]);
    }
  }

  /** A file's cached hash moved with it: a rename keeps the mtime and the size. */
  function moveHashRow(from: string, to: string): void {
    const row = hashes.rows.get(from);
    if (!row) return;
    hashes.set(to, row[0], row[1], row[2], row[3]);
    hashes.forget(from);
  }

  /**
   * What the server wrote and removed, told to the index (`learn`; `exact`, the
   * paths only a listing spells right); the Trash read again if it was
   * touched; the sources it moved settled -- all in one commit, which the
   * call's answer carries.
   */
  /**
   * The repair pass run at once (Docs/asset-ids.md §4, `planRefs`): each data file it rewrites written as the server's
   * own, its text before kept in `befores` by the path it had before the move (`movedFrom`: a moved file's new path to
   * its old) -- the first text kept, so a file rewritten twice in one move is put back as it was before both -- and its
   * text after in `afters`, the last kept. `only` holds it to the references to what moves (`refsTo`).
   */
  async function repairNow(done: Rewrites, movedFrom: ReadonlyMap<string, string>, only: RefsFilter): Promise<void> {
    for (const r of planRefs(root, options.kinds, { only })) {
      const was = movedFrom.get(r.path) ?? r.path;
      if (!done.befores.has(was)) done.befores.set(was, r.before);
      await writeOwn(r.path, r.text, true);
      done.afters.set(was, r.text);
    }
  }

  /** What an undo's `restore` item is: a data file's text to put back, and what the doing left there (`after`). */
  interface RestoreItem {
    path: string;
    text: string;
    after?: string;
  }

  /** A move's `restore`: `[{ path, text, after? }]`, each a data file of the project's (what a move's answer `rewritten` named). */
  async function restoreList(raw: unknown): Promise<RestoreItem[]> {
    if (raw === undefined) return [];
    if (!Array.isArray(raw)) throw new Refused(422, 'restore is a list of { path, text, after }');
    const out: RestoreItem[] = [];
    for (const item of raw as Array<{ path?: unknown; text?: unknown; after?: unknown }>) {
      if (item === null || typeof item !== 'object' || typeof item.text !== 'string' || (item.after !== undefined && typeof item.after !== 'string')) throw new Refused(422, 'restore is a list of { path, text, after }');
      const path = await checkPath(root, item.path, WRITE_DIRS);
      if (!dataFile(path)) throw new Refused(422, `${path}: only a data file's text is put back with a move`);
      const problem = jsonProblem(item.text);
      if (problem) throw new Refused(422, `${baseName(path)} would not parse: ${problem.message}`);
      writable(path);
      out.push({ path, text: item.text, ...(typeof item.after === 'string' ? { after: item.after } : {}) });
    }
    return out;
  }

  /**
   * The restore items whose file no longer holds what the doing left there (`after`): edited since, so kept as they
   * are -- an undo never overwrites a later edit. An item with no `after` is put back as ever.
   */
  async function editedSince(items: readonly RestoreItem[]): Promise<Set<string>> {
    const kept = new Set<string>();
    for (const r of items) {
      if (r.after === undefined) continue;
      const now = await readFile(abs(r.path), 'utf8').catch(() => null);
      if (now !== r.after) kept.add(r.path);
    }
    return kept;
  }

  /** The files a repair pass rewrote: each text before and after, by its path before the move. */
  interface Rewrites {
    befores: Map<string, string>;
    afters: Map<string, string>;
  }
  const rewrites = (): Rewrites => ({ befores: new Map(), afters: new Map() });
  /** As an answer's `rewritten`: each file's path, its text before and after. */
  const rewrittenOf = (done: Rewrites): Array<{ path: string; before: string; after: string }> =>
    [...done.befores].map(([path, before]) => ({ path, before, after: done.afters.get(path) ?? before }));

  async function learned(paths: readonly string[], trash: boolean, exact: readonly string[] = []): Promise<void> {
    await catalog.learn(paths, exact);
    if (trash) await catalog.readTrash();
    const sources = new Set<string>();
    for (const p of paths) for (const s of catalog.affected(p)) sources.add(s);
    await catalog.settle([...sources]);
  }

  /** The move or export-as running its passes now, as `repairing()` answers it. */
  let repairHeld: Promise<void> | undefined;
  /** `fn` -- a move's or an export-as's work, inside `serially` -- held as `repairing()` until it ends, however it ends. */
  async function repairWindow<T>(fn: () => Promise<T>): Promise<T> {
    let end!: () => void;
    repairHeld = new Promise<void>((resolve) => (end = resolve));
    try {
      return await fn();
    } finally {
      repairHeld = undefined;
      end();
    }
  }

  /** Mutating file work, one call at a time: two tabs' undos never interleave on the disk. */
  let writing: Promise<unknown> = Promise.resolve();
  function serially<T>(fn: () => Promise<T>): Promise<T> {
    const run = writing.then(fn);
    writing = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  }

  // ---------------------------------------------------------------- tools

  const NEEDS: Need[] = mergeNeeds([...Object.values(STEPS).map((s) => s.needs), STATS_NEEDS]);
  const NPM = unique(Object.values(STEPS).flatMap((s) => s.npm));
  let toolsLooked!: () => void;
  /** The first look for tools has ended: jobs wait for it. */
  const toolsReady = new Promise<void>((resolve) => (toolsLooked = resolve));
  const toolList = (): ToolLook[] | null => (catalog.tools ? [...catalog.tools.values()] : null);
  const bin = (tool: string): string => catalog.tools?.get(tool)?.path ?? tool;

  async function lookTools(needs: readonly Need[]): Promise<void> {
    const found = await lookForAll(needs, { root, ...options.look });
    const merged = new Map(catalog.tools ?? []);
    for (const [tool, look] of found) merged.set(tool, look);
    catalog.tools = merged;
    push({ type: 'tools', tools: [...merged.values()] });
  }

  /** The tools looked for again, every status worked out with them, and what was `unmade` and now can be made, queued. */
  async function lookAgain(needs: readonly Need[]): Promise<QueuedJobInfo[]> {
    const before = new Map(catalog.sources().map((s) => [s, catalog.status(s)] as const));
    await lookTools(needs);
    await catalog.settle();
    const jobs: QueuedJobInfo[] = [];
    for (const [source, was] of before) {
      if (was !== 'unmade') continue;
      const job = autoExport(source);
      if (job) jobs.push(job);
    }
    return jobs;
  }

  // ---------------------------------------------------------------- the runner and the tabs

  /** Game tabs on this machine: loopback websockets. */
  const tabs = new Set<TabSocket>();
  /** The `convert` each waiting job sent, for a tab that connects after it went out. */
  const asked = new Map<string, ConvertMessage>();
  const bridge = new BrowserBridge({
    connected: () => tabs.size > 0,
    ask: (message) => {
      asked.set(message.job, message);
      push({ type: 'convert', convert: message });
    },
    clock,
    ...(options.claimMs !== undefined ? { claimMs: options.claimMs } : {}),
    ...(options.sendMs !== undefined ? { sendMs: options.sendMs } : {}),
  });

  /** A browser step: the job parked while a tab converts, its slot taken again once the file is here. */
  async function viaTab(job: QueuedJob, step: Job, control: JobControl): Promise<string> {
    control.park();
    try {
      return await bridge.request(job.id, step.source, step.parts.map((p) => rel(p) ?? p), control.signal);
    } finally {
      asked.delete(job.id);
      await control.resume();
    }
  }

  async function runJob(job: QueuedJob, control: JobControl): Promise<void> {
    await toolsReady;
    let told = false;
    const progress = (message: JobMessage): void => {
      if (message.state === 'done' || message.state === 'failed' || message.state === 'unmade') told = true;
      control.progress(message);
    };
    const result = await exportSource(
      { root, catalog, runs, log, progress, browser: (step) => viaTab(job, step, control) },
      job.source,
      { ...job.options, id: job.id, signal: control.signal },
    );
    jobEnded(job.id, result.state === 'done' ? result.exports : []);
    // Refused at the door, it said nothing: its job ends here, saying why -- a source current when its
    // turn came (a job ahead of it made the export) is nothing to do, `skipped`, never a failure.
    if (!told && result.state !== 'dropped' && !control.signal.aborted) {
      // Out of the build by its turn (its record edited meanwhile): nothing to do either, no failure.
    const current = result.state === 'skipped' && (result.reason === 'current' || (result.reason ?? '').startsWith('excluded:'));
      const why = result.state === 'skipped' ? `not exported: ${result.reason}` : (result.reason ?? result.error ?? 'not exported');
      const state = current ? 'skipped' : result.state === 'unmade' ? 'unmade' : 'failed';
      control.progress({ id: job.id, source: job.source, step: 0, of: 0, state, ...(current ? {} : { error: why }), ms: result.ms });
    }
    if (result.state === 'unmade' && result.reason === NO_TAB) bridge.waiting.add(result.source);
    await runs.save().catch(onError);
  }

  /** The jobs a turn's end waits for (`turnsOver`), by id: each told as it ends, with the files it wrote. */
  const ending = new Map<string, (exports: string[]) => void>();
  /** A job ended: whoever waits for it told, with what it wrote (none but for a `done`). */
  function jobEnded(id: string, exports: string[]): void {
    const tell = ending.get(id);
    ending.delete(id);
    tell?.(exports);
  }
  const runner = new Runner({
    concurrency: 1,
    run: runJob,
    onMessage: (message) => {
      push({ type: 'job', job: message });
      for (const listen of jobListeners) listen(message);
      // A job that ends without running its export to the end (dropped while queued, refused, thrown): nothing written.
      // A `done` is told by `runJob` once the export has returned, with its files.
      if (message.state === 'failed' || message.state === 'dropped' || message.state === 'unmade' || message.state === 'skipped') jobEnded(message.id, []);
    },
  });

  /** Does a source's row run by itself: no step that waits to be asked (`blender`)? */
  function automatic(source: string): boolean {
    const answer = recipeFor(source);
    return isFound(answer) && answer.row.steps.every((name) => STEPS[name].auto);
  }

  /**
   * A source a watch event, an option or a tool moved: queued if it is now
   * `stale` or `missing` and its row runs by itself (to the auto slot); kept for
   * the next tab if a tab is what it lacks.
   */
  function autoExport(source: string): QueuedJobInfo | undefined {
    const e = catalog.entries.get(source);
    if (!e || e.role !== 'source') return undefined;
    // In a drop still coming: its export is the drop's, queued with its last file (§5, Importing).
    if (drops.holds(source)) return undefined;
    if (e.status === 'unmade' && e.reason === NO_TAB) {
      bridge.waiting.add(source);
      return undefined;
    }
    if ((e.status !== 'stale' && e.status !== 'missing') || !automatic(source)) return undefined;
    const { id } = runner.add(source);
    return { id, source };
  }

  // ---------------------------------------------------------------- a Claude turn's scripts (Docs/modeler.md M21, D110)

  const link = options.link;
  /** Closed by `close`: an old server after an in-process restart hears nothing more and exports nothing. */
  let closed = false;
  /**
   * The held list as it is now, to every page -- the Model tab shows a held script's saves as previews -- and
   * to `.cache/assets/held.json`: a dev server stopped mid-turn and started again finds what it owes (below).
   */
  const HELD_FILE = join(root, CACHE, 'held.json');
  /** The writes of `held.json`, one after another: a hold then a quick `turnsOver` must end as the list is, never rm-then-write. */
  let heldWrites: Promise<void> = Promise.resolve();
  /**
   * A held list to the pages alone, through the link's push: the live server's, whichever server noticed -- after an
   * in-process restart an old one's socket reaches no page (review round 2: the page missed `held`, its chip wrong).
   */
  const tellHeld = (held: string[]): void => (link?.push ?? ((h: string[]) => push({ type: 'held', held: h })))(held);
  const pushHeld = (): void => {
    const held = [...(link?.held ?? [])];
    tellHeld(held);
    heldWrites = heldWrites
      .then(() => mkdir(dirname(HELD_FILE), { recursive: true }))
      .then(() => (held.length > 0 ? writeAtomic(HELD_FILE, JSON.stringify({ held })) : rm(HELD_FILE, { force: true })))
      .catch(onError);
  };

  /** A Gladius script's auto-export held while a turn runs: true if it was (it joins the list, once). */
  function holdExport(source: string): boolean {
    if (!link || !link.turns() || extOf(source) !== 'lua' || locate(source)?.root !== 'source') return false;
    const e = catalog.entries.get(source);
    if (!e || e.role !== 'source' || (e.status !== 'stale' && e.status !== 'missing')) return false;
    if (!link.held.includes(source)) {
      link.held.push(source);
      pushHeld();
    }
    return true;
  }

  /**
   * The files the watcher reported while a turn's end waits (`seen`), and its wake-up: a file is in Vite's globs once
   * the watcher has told Vite of it, so the held code's replay waits for that, not only for the file on disk.
   */
  let seenFiles: Set<string> | null = null;
  let seenWake: (() => void) | null = null;
  /** Resolves once the watcher has reported every one of `files` since `seenFiles` was opened, or `seenMs` has passed. */
  async function seen(files: readonly string[]): Promise<void> {
    const deadline = Date.now() + (options.seenMs ?? 2000);
    while (seenFiles && files.some((f) => !seenFiles!.has(f)) && Date.now() < deadline) {
      await new Promise<void>((resolve) => {
        const timer = setTimeout(resolve, Math.max(0, deadline - Date.now()));
        seenWake = () => {
          clearTimeout(timer);
          resolve();
        };
      });
      seenWake = null;
    }
    // Vite's own handlers for those events, and `assets:generate`'s regeneration at the end of their macrotask, run first.
    if (files.length > 0) await new Promise((resolve) => setTimeout(resolve, 50));
  }

  /**
   * The last turn over: each held script exported once, as it is on disk now -- one gone or current since,
   * nothing. Resolves once those exports have ended and the watcher has seen what they wrote (`seen`): what the
   * agent awaits before it replays the held code (`turnsEnded`), so a page the replay reloads finds the new model.
   * `link.exporting` is that wait meanwhile, for "Reload now". Answers what became of each, for the transcript:
   * the words say what happened, never more.
   */
  async function turnsOver(): Promise<string[]> {
    if (!link) return [];
    if (link.held.length === 0) {
      // Nothing held: the empty list pushed all the same, to the pages alone -- the Model tab's wait for the turns' end hears it (M21).
      tellHeld([]);
      return [];
    }
    const now = link.held.splice(0);
    const said: string[] = [];
    const jobs: Promise<string[]>[] = [];
    seenFiles ??= new Set();
    for (const source of now) {
      const name = baseName(source);
      const e = catalog.entries.get(source);
      const job = autoExport(source);
      if (job) {
        said.push(`${name}: exported now that no turn runs`);
        jobs.push(new Promise((resolve) => ending.set(job.id, resolve)));
      } else if (e?.status === 'current') said.push(`${name}: nothing to export -- its export is the script as it is`);
      else if (e) said.push(`${name}: not exported (${e.status}${e.reason ? `: ${e.reason}` : ''})`);
      else said.push(`${name}: not exported -- it is not there any more`);
    }
    pushHeld();
    // Bounded (`exportMs`): a job that never ends holds neither the replay nor "Reload now" past the cap.
    const capMs = options.exportMs ?? 60_000;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let capped = false;
    const exporting = Promise.race([
      Promise.all(jobs).then((written) => seen(written.flat())),
      new Promise<void>((resolve) => {
        timer = setTimeout(() => {
          capped = true;
          resolve();
        }, capMs);
      }),
    ]);
    const owner = link;
    owner.exporting = exporting;
    try {
      await exporting;
    } finally {
      clearTimeout(timer);
      if (owner.exporting === exporting) {
        owner.exporting = null;
        seenFiles = null;
      }
    }
    if (capped) said.push(`the exports still running: not waited for past ${capMs >= 1000 ? `${Math.round(capMs / 1000)} s` : `${capMs} ms`} -- the code replayed without them, each file landing when its export ends`);
    return said;
  }


  /**
   * What a dev server before this one held -- stopped mid-turn, its list on disk -- exported once the tools are
   * looked for and the scripts settled, if no turn runs (an in-process restart keeps the list on globalThis, and a
   * turn still running keeps holding it).
   */
  async function flushKept(): Promise<void> {
    if (!link) return;
    let kept: { held?: unknown } = {};
    try {
      kept = JSON.parse(await readFile(HELD_FILE, 'utf8').catch(() => '{}')) as { held?: unknown };
    } catch {
      // Torn (a write cut short before they were atomic): nothing owed that can be read; the list on disk goes with the next write.
    }
    if (kept === null || typeof kept !== 'object') kept = {};
    for (const path of Array.isArray(kept.held) ? kept.held : []) if (typeof path === 'string' && !link.held.includes(path)) link.held.push(path);
    if (link.held.length === 0 || link.turns()) return;
    await catalog.settle(link.held.filter((p) => catalog.entries.has(p)));
    for (const line of await turnsOver()) log(`[assets] ${line}`);
  }

  /** The scripts among `paths` that do not build, each with Gladius's errors: the export's parameters, `--checks none` (D110). */
  async function checkScripts(paths: readonly string[]): Promise<ScriptCheck[]> {
    const look = catalog.tools?.get('gladius');
    // No Gladius: nothing can be said of the build, and no turn is sent back for it.
    if (look && look.state !== 'found') return [];
    const out: ScriptCheck[] = [];
    for (const path of unique(paths)) {
      if (extOf(path) !== 'lua' || locate(path)?.root !== 'source') continue;
      const found = recipeFor(path);
      if (!isFound(found)) continue;
      if ((await isFolder(path)) !== false) continue;
      const { options: resolved } = await sourceOptions(root, path, found);
      const answer = await querying(() => queryModel({ bin: bin('gladius'), input: abs(path), params: paramsOf(resolved), ...(look?.hint ? { hint: look.hint } : {}) }));
      if (answer.missing) continue;
      const errors = answer.diagnostics.filter((d) => d.severity === 'error').map((d) => ({ message: d.message, ...(d.line !== undefined ? { line: d.line } : {}) }));
      if (errors.length === 0 && !answer.ok) errors.push({ message: answer.problem ?? 'the script did not build' });
      if (errors.length > 0) out.push({ path, errors });
    }
    return out;
  }

  if (link) {
    link.over = turnsOver;
    link.check = (paths) => ready.then(() => checkScripts(paths));
    link.push = (held) => push({ type: 'held', held });
    // A project route's message (`vibe({ routes })`, `tools/tools.ts`): out on this server's channel, the live one.
    link.send = push;
  }

  /** A source whose first step is a game tab's. */
  function needsTab(source: string): boolean {
    const answer = recipeFor(source);
    return isFound(answer) && stepInfo(answer.row.steps[0]!).where === 'browser';
  }

  /** A tab came or the last went: the sources a tab makes, worked out again. */
  function browserIs(state: 'tab' | 'none'): void {
    if (catalog.browser === state) return;
    catalog.browser = state;
    const affected = catalog.sources().filter(needsTab);
    if (affected.length > 0) catalog.settle(affected).catch(onError);
  }

  // ---------------------------------------------------------------- the drops

  /**
   * A drop's sources, once its last file is in and its owners read (§5,
   * Importing): owners first, then the rest, then the owners outside the drop
   * of a part in it (a texture dropped for a model already there). Each one
   * `stale` or `missing` is queued -- unless a job for it is under way or
   * queued already, whose id is answered instead: a job is never queued to
   * find its source current. Answers the jobs, for the last file's `PUT
   * import` to say.
   */
  async function queueDrop(sources: readonly string[]): Promise<QueuedJobInfo[]> {
    await catalog.settle(sources.filter((s) => catalog.entries.has(s)));
    const owners = sources.flatMap((s) => {
      const e = catalog.entries.get(s);
      return e?.role === 'part' ? (e.owners ?? []).filter((o) => !sources.includes(o)) : [];
    });
    if (owners.length > 0) await catalog.settle(unique(owners).filter((s) => catalog.entries.has(s)));
    const jobs: QueuedJobInfo[] = [];
    const under = new Map(runner.jobs().map((j) => [j.source, j.id] as const));
    for (const source of unique([...sources, ...owners])) {
      const e = catalog.entries.get(source);
      if (!e || e.role !== 'source') continue;
      const live = under.get(source);
      if (live !== undefined) jobs.push({ id: live, source });
      else if (e.status === 'stale' || e.status === 'missing') jobs.push({ id: runner.add(source, { slot: 'new' }).id, source });
      else if (e.status === 'unmade' && e.reason === NO_TAB) bridge.waiting.add(source);
    }
    return jobs;
  }
  const drops = new Drops(
    (sources) =>
      queueDrop(sources).catch((err: unknown) => {
        onError(err as Error);
        return [];
      }),
    { clock, ...(options.holdMs !== undefined ? { holdMs: options.holdMs } : {}) },
  );

  /** A model source: an owner, imported and read before the files it names. */
  const isOwner = (path: string): boolean => locate(path)?.kind === 'models' && MODEL_SOURCE_EXT.includes(extOf(path));

  // ---------------------------------------------------------------- the start

  const ready = (async () => {
    await Promise.all([hashes.load(), runs.load()]);
    catalog.npm = await npmVersions(root, NPM);
    await catalog.walk();
    // The walk is the tree a page asks for: no page needs it pushed.
    sentSeq = catalog.seq;
    if (pushTimer !== undefined) clock.clearTimeout(pushTimer);
    pushTimer = undefined;
    const pointers = catalog.pointerLine();
    if (pointers) log(pointers);
  })();
  ready.catch(onError);


  // ---------------------------------------------------------------- reading files

  /**
   * A file's content hash: the index's, or through the hashes cache (one read
   * the first time its content is seen -- a trashed file too). Undefined for
   * a source not hashed yet: the settle reads it, once.
   */
  async function hashFor(path: string): Promise<string | undefined> {
    const e = catalog.entries.get(path);
    if (e?.hash !== undefined) return e.hash;
    if (e?.role === 'source' && e.status === 'checking') return undefined;
    return (await hashOf(hashes, root, path)).sha1;
  }

  /** The cached file a read touched: its mtime is when it was last read, which the prune reads. */
  const touch = (file: string): void => {
    const now = new Date();
    utimes(file, now, now).catch(() => {});
  };

  /** `GET params`' runs: quick, two at a time. */
  const asking = limiter(2);
  /** Preview builds (`POST preview`): per script one running and the newest waiting (`Latest`), two scripts at a time. */
  const building = limiter(2);
  const previews = new Latest<{ options: Options; params: Record<string, string> }, PreviewBuilt | PreviewFailure>((path, { options, params }) => {
    const look = catalog.tools?.get('gladius');
    return building(() => buildPreview({ bin: bin('gladius'), input: abs(path), out: join(root, CACHE, 'preview', traceName(path)), options, params, ...(look?.hint ? { hint: look.hint } : {}) }));
  });

  /**
   * Build traces (`POST trace`, Docs/modeler.md M34): per script one running and the newest waiting (`Latest`), one
   * script at a time -- a trace is a whole build and some. The last one per script kept under `.cache/assets/trace/`,
   * by the version its answer gave, for `GET trace` to serve; its polygons asked once and kept with it.
   */
  const tracing = limiter(1);
  const traceFile = (path: string): string => join(root, CACHE, 'trace', traceName(path));
  /** The last trace per script: its version, and the very text traced -- its faces are asked of that, not of the file as it is by then. */
  const traced = new Map<string, { version: string; params: Record<string, string>; source: string; faces?: Promise<TraceFaces> }>();
  /** The traces a server before this one left: unreachable (a trace is served by this server's version), up to ~100 MB each -- gone at the first trace. */
  let tracesSwept = false;
  const traces = new Latest<{ params: Record<string, string> }, TraceAnswer>((path, { params }) => {
    const look = catalog.tools?.get('gladius');
    return tracing(async () => {
      if (!tracesSwept) {
        tracesSwept = true;
        await rm(join(root, CACHE, 'trace'), { recursive: true, force: true });
      }
      const source = await readFile(abs(path), 'utf8').catch(() => null);
      if (source === null) return { ok: false, ms: 0, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics: [], error: `${path} is not there` } satisfies TraceAnswer;
      const answer = await buildTrace({ bin: bin('gladius'), input: abs(path), out: traceFile(path), params, source, ...(look?.hint ? { hint: look.hint } : {}) });
      if (!answer.ok) return answer;
      const version = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
      traced.set(path, { version, params, source });
      return { ...answer, version };
    });
  });

  /** A route's `path=`, a Gladius script under the Source root that is there, and its recipe: refused as `GET stats` refuses. */
  async function gladiusScript(url: URL, route: string): Promise<{ path: string; found: Found }> {
    const path = await checkPath(root, q(url, 'path'), READ_DIRS);
    if (extOf(path) !== 'lua' || locate(path)?.root !== 'source') throw new Refused(422, `${path} is no Gladius script: ${route} takes a .lua under ${ROOTS.source.dir}/`);
    if ((await isFolder(path)) !== false) throw new Refused(404, `${path} is not there`);
    const found = recipeFor(path);
    if (!isFound(found)) throw new Refused(422, found.refused);
    return { path, found };
  }

  /** A source's `params` option as Gladius takes it: every value its text. */
  const paramsOf = (options: Options): Record<string, string> => {
    const out: Record<string, string> = {};
    const map = options.params;
    if (typeof map === 'object' && map !== null && !Array.isArray(map)) for (const [k, v] of Object.entries(map)) out[k] = String(v);
    return out;
  };

  /** Stats and thumbnails made two at a time, one of each per file and size however many ask. */
  const making = limiter(2);
  /** `GET model`'s queries: one at a time, as the export's Gladius runs are. */
  const querying = limiter(1);
  const inFlight = new Map<string, Promise<unknown>>();
  function once<T>(key: string, fn: () => Promise<T>): Promise<T> {
    const hit = inFlight.get(key) as Promise<T> | undefined;
    if (hit) return hit;
    const p = making(fn).finally(() => inFlight.delete(key));
    inFlight.set(key, p);
    return p;
  }

  /** A file's bytes, `Range`d, `ETag`ged, `304` when unchanged. */
  async function sendFile(req: IncomingMessage, res: ServerResponse, path: string): Promise<void> {
    let st;
    try {
      st = await stat(abs(path));
    } catch {
      throw new Refused(404, `${path} is not there`);
    }
    if (!st.isFile()) throw new Refused(422, `${path} is a folder`);
    const e = catalog.entries.get(path);
    const sha = e?.hash !== undefined && e.mtime === st.mtimeMs && e.size === st.size ? e.hash : hashes.get(path, st.mtimeMs, st.size)?.[2];
    const etag = sha !== undefined ? `"${sha}"` : `W/"${Math.round(st.mtimeMs)}-${st.size}"`;
    const headers: Record<string, string | number> = {
      'Content-Type': MIME[extOf(path)] ?? 'application/octet-stream',
      'Cache-Control': 'no-cache',
      ETag: etag,
      'Accept-Ranges': 'bytes',
    };
    const match = req.headers['if-none-match'];
    if (match !== undefined && match.split(',').some((m) => m.trim() === etag)) {
      res.writeHead(304, headers);
      res.end();
      return;
    }
    let start = 0;
    let end = st.size - 1;
    let status = 200;
    const range = req.headers.range;
    if (range !== undefined) {
      const m = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
      if (m && (m[1] !== '' || m[2] !== '')) {
        if (m[1] === '') {
          start = Math.max(0, st.size - Number(m[2]));
        } else {
          start = Number(m[1]);
          if (m[2] !== '') end = Math.min(end, Number(m[2]));
        }
        if (start > end || start >= st.size) {
          res.writeHead(416, { 'Content-Range': `bytes */${st.size}` });
          res.end();
          return;
        }
        status = 206;
        headers['Content-Range'] = `bytes ${start}-${end}/${st.size}`;
      }
    }
    headers['Content-Length'] = st.size === 0 ? 0 : end - start + 1;
    res.writeHead(status, headers);
    if (req.method === 'HEAD' || st.size === 0) {
      res.end();
      return;
    }
    try {
      await pipeline(createReadStream(abs(path), { start, end }), res);
    } catch (err) {
      // The page stopped listening -- a seek, a closed preview -- is no failure of ours.
      if (!['ERR_STREAM_PREMATURE_CLOSE', 'ECONNRESET', 'EPIPE'].includes(code(err) ?? '')) throw err;
    }
  }

  // ---------------------------------------------------------------- names

  /** The names in a folder; none if it is not there. */
  async function namesIn(dir: string | undefined): Promise<string[]> {
    if (dir === undefined) return [];
    try {
      return await readdir(abs(dir));
    } catch {
      return [];
    }
  }

  /** The first `-2`, `-3`... of `name` free in both lists, as either spells it. */
  function freeName(name: string, lists: ReadonlyArray<readonly string[]>, folder: boolean): string {
    const taken = new Set(lists.flatMap((l) => l.map((n) => n.toLowerCase())));
    for (let n = 2; n < 10000; n++) {
      const candidate = folder ? `${name}-${n}` : baseName(numbered(name, n));
      if (!taken.has(candidate.toLowerCase())) return candidate;
    }
    return name;
  }

  /** Where a file dropped on `dest` goes and what it is (§5, Importing), or why not. */
  function importTarget(dest: string, name: string, asSource: boolean): { target: string; found?: Found; extra?: true } {
    if (asSource) {
      const sourceDir = locate(dest)?.root === 'source' ? dest : twin(dest);
      if (sourceDir === undefined || locate(joinPath(sourceDir, name))?.reference) {
        const answer = recipeFor(joinPath(dest, name));
        throw new Refused(422, isFound(answer) ? `${dest} has no AssetsSource/ twin` : answer.refused);
      }
      const target = joinPath(sourceDir, name);
      const answer = recipeFor(target);
      if (isFound(answer)) return { target, found: answer };
      if (answer.extra) return { target, extra: true };
      throw new Refused(422, answer.refused);
    }
    if (under(dest, ROOTS.source.reference)) return { target: joinPath(dest, name) };
    if (locate(dest)?.root === 'source') throw new Refused(422, 'AssetsSource/ holds sources: import this as a source, or into AssetsSource/reference/');
    const target = joinPath(dest, name);
    const where = locate(target);
    if (!where?.kind || !where.under) throw new Refused(422, `${dest} is not a kind's folder`);
    if (!globbed(target) && !underscored(where.under)) {
      throw new Refused(422, `.${extOf(name)} does not ship under ${KINDS[where.kind].dir}${where.root === 'packs' ? ' in a pack' : ''}`);
    }
    return { target };
  }

  /** The key a file imported at `target` would take: its export's for a source, its own for a loose file. */
  const keyFor = (target: string, found: Found | undefined): string | undefined => (found ? exportKey(target, found.row.to) : keyOf(target));

  /**
   * The files a new one at `target` would share a key with (one stem, one
   * source, §2): sources and loose files, not itself -- by the index's key
   * list. A source out of the build has no key to share, and is none -- but
   * for a source beside `target` with its stem, whose record would be the new
   * one's too (one stem, one record).
   */
  function keyClash(target: string, found: Found | undefined): { key: string; paths: string[] } | undefined {
    const key = keyFor(target, found);
    if (key === undefined) return undefined;
    const paths: string[] = [];
    for (const p of catalog.withKey(key)) {
      const e = catalog.entries.get(p);
      if (!e || e.key !== key || p === target || (e.role !== 'source' && e.role !== 'loose')) continue;
      if (e.role === 'source' && !e.included && dirName(p) !== dirName(target)) continue;
      paths.push(p);
    }
    return paths.length > 0 ? { key, paths: paths.sort() } : undefined;
  }

  /**
   * Where a script the Model tab makes goes (Docs/modeler.md M38, M39): `<stem>.lua` in `dir` -- a folder under
   * `AssetsSource/models/`, or its twin -- with what is in its way said, not refused: the script there already,
   * the import's copy (`copy`) there already, and the files whose key it would take (but `except`: the `.glb` Make a
   * script turns into its export). Refused outright: a folder no model goes in, a name `validName` refuses.
   */
  async function scriptPlace(dir: string, stem: string, options: { copy?: string; except?: string } = {}): Promise<{ lua: string; found: Found; name: string; occupied: boolean; copyTaken: boolean; clash?: { key: string; paths: string[] }; suggested: string }> {
    const sourceDir = locate(joinPath(dir, 'x'))?.root === 'source' ? dir : twin(dir);
    if (sourceDir === undefined) throw new Refused(422, `${dir} has no AssetsSource/ twin`);
    const lua = joinPath(sourceDir, `${stem}.lua`);
    if (locate(lua)?.kind !== 'models' || locate(lua)?.reference) throw new Refused(422, `a model's script goes under ${ROOTS.source.dir}/${KINDS.models.dir}/: ${sourceDir} is not there`);
    writable(lua);
    const why = stemProblem(stem);
    const here = await namesIn(sourceDir);
    const there = await namesIn(twin(sourceDir));
    const name = `${stem}.lua`;
    const suggested = splitName(freeName(name, [here, there], false)).stem;
    if (why) throw new Refused(422, why);
    const valid = validName(name, { siblings: here, twinSiblings: there });
    if ('refused' in valid) throw new Refused(422, valid.refused, valid.suggested !== undefined ? { suggested: splitName(valid.suggested).stem } : {});
    const found = recipeFor(lua);
    if (!isFound(found)) throw new Refused(422, found.refused);
    const occupied = await exists(abs(lua));
    const copyTaken = options.copy !== undefined && (await exists(abs(joinPath(sourceDir, options.copy))));
    const clashed = keyClash(lua, found);
    const paths = (clashed?.paths ?? []).filter((p) => p !== options.except);
    return { lua, found, name, occupied, copyTaken, ...(clashed && paths.length > 0 ? { clash: { key: clashed.key, paths } } : {}), suggested };
  }

  /** `scriptPlace`'s answer, refused where anything is in the way: what New model and Make a script do, which replace nothing. */
  function freePlace(place: Awaited<ReturnType<typeof scriptPlace>>, copy?: string): void {
    const { name, suggested } = place;
    if (place.occupied) throw new Refused(409, `${name} exists already: pick another name, or open it and keep working`, { suggested, exists: true });
    if (place.copyTaken) throw new Refused(409, `${copy} is there already: it is the file an import keeps beside its script -- pick another name`, { suggested });
    if (place.clash) throw new Refused(409, `${name} would be a second source for ${place.clash.key} (${place.clash.paths.map(baseName).join(', ')}): name it differently`, { suggested });
  }

  /**
   * What one `GET names` has answered so far -- the names it found fine, the
   * names it suggested (for the name refused), the keys they take: one drop's
   * files are checked against each other too.
   */
  interface Asked {
    names: string[];
    suggested: Map<string, string>;
    keys: Map<string, string>;
  }

  /**
   * One name asked about by `GET names` (§1, §5): valid, free -- of the folder,
   * its twin, and the names asked before it in the same call -- and no second
   * source for a key, the index's or another of the call's. With `asSource`
   * said, refused as the import would refuse it; unsaid, either way may work,
   * and the import says why when one does not.
   */
  function checkName(dest: string, name: string, here: readonly string[], there: readonly string[], folder: boolean, asSource: boolean | undefined, asked: Asked): NameAnswer {
    const taken = [here, there, asked.names, [...asked.suggested.keys()]];
    const answer = ((): NameAnswer => {
      const valid = validName(name, { folder, siblings: [...here, ...asked.names], twinSiblings: there });
      if ('refused' in valid) return { name, ...valid };
      if (here.includes(name) || there.includes(name)) return { name, refused: `${name} exists in ${dest}`, suggested: freeName(name, taken, folder), exists: true };
      if (asked.names.includes(name)) return { name, refused: `${name} is asked for twice: one of them needs another name`, suggested: freeName(name, taken, folder) };
      const mine = asked.suggested.get(name);
      if (mine !== undefined) return { name, refused: `${name} is the name suggested above for another ${mine}: one of them needs another`, suggested: freeName(name, taken, folder) };
      const keys: string[] = [];
      if (!folder) {
        for (const source of asSource === undefined ? [true, false] : [asSource]) {
          let target;
          try {
            target = importTarget(dest, name, source);
          } catch (err) {
            if (asSource === undefined || !(err instanceof Refused)) continue; // either way may work: the import says why
            return { name, refused: err.body.refused, ...(typeof err.body.suggested === 'string' ? { suggested: err.body.suggested } : {}) };
          }
          const clash = keyClash(target.target, target.found);
          if (clash) {
            return { name, refused: `${name} would be a second source for ${clash.key}; replace ${clash.paths.map(baseName).join(', ')}, or name it differently`, suggested: freeName(name, taken, false) };
          }
          const key = keyFor(target.target, target.found);
          const other = key !== undefined ? asked.keys.get(key) : undefined;
          if (key !== undefined && other !== undefined) return { name, refused: `${name} and ${other} would both be ${key}: one of them needs another name`, suggested: freeName(name, taken, false) };
          if (key !== undefined) keys.push(key);
        }
      }
      for (const key of keys) asked.keys.set(key, name);
      return valid.note !== undefined ? { name, ok: true, note: valid.note } : { name, ok: true };
    })();
    // What this file will be called -- the name, or the one suggested -- is taken for the names after it.
    if ('ok' in answer) asked.names.push(name);
    else if (answer.suggested !== undefined) asked.suggested.set(answer.suggested, name);
    return answer;
  }

  // ---------------------------------------------------------------- an import as a script

  /**
   * `PUT import?script=true` (Docs/modeler.md M39; Vibe3D D36, D90, D92, D112): the `.glb` or `.fbx` uploaded, copied
   * in as `<stem>.source.<ext>` -- a `.glb` decoded where it is Draco, meshopt or quantised -- beside `<stem>.lua`, which
   * imports it pinned by its sha256; the copy is the script's part. `replace`: the script's family, the copy and any
   * file with its key to the trash first, one slot. Its export is the drop's, as any source's.
   */
  async function importAsScript(
    url: URL,
    o: { since: number; dest: string; name: string; replace: boolean; excluded: boolean; drop: string | undefined; left: number },
    fill: (tmp: string) => Promise<unknown>,
  ): Promise<ImportAnswer> {
    try {
      const kind = importKind(o.name);
      if (!kind) throw new Refused(422, `${o.name}: a script imports a .glb or an .fbx`);
      const stem = splitName(o.name).stem;
      const copy = importCopyName(stem, kind);
      const place = await scriptPlace(o.dest, stem, { copy });
      if ((place.occupied || place.copyTaken || place.clash) && !o.replace) {
        const what = place.occupied ? `${place.name} exists` : place.copyTaken ? `${copy} is there` : `${place.name} would be a second source for ${place.clash!.key}`;
        throw new Refused(409, `${what}: tick it to replace, or name it differently`, { suggested: `${place.suggested}.${kind}`, ...(place.occupied ? { exists: true } : {}) });
      }
      let overrides: Options = {};
      const optionsText = q(url, 'options');
      if (optionsText !== null && optionsText !== '' && optionsText !== '{}') {
        let parsed: unknown;
        try {
          parsed = JSON.parse(optionsText);
        } catch {
          throw new Refused(422, 'options is not JSON');
        }
        if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) throw new Refused(422, 'options is an object of option names');
        const problems = checkOptions(place.found.row.options ?? {}, parsed as Record<string, unknown>);
        if (problems.length > 0) throw new Refused(422, problems.join('; '));
        const layers = await Promise.all(folderChain(place.lua).map((d) => readFolderDefaults(root, d)));
        const base = resolveOptions(place.found.row, layers.map((l) => l.record?.options)).options;
        for (const [k, v] of Object.entries(parsed as Options)) if (canonical(v) !== canonical(base[k])) overrides[k] = v;
      }
      const tmp = join(root, CACHE, 'tmp', newId());
      try {
        await mkdir(dirname(tmp), { recursive: true });
        await fill(tmp);
      } catch {
        await rm(tmp, { force: true });
        throw new Refused(400, 'the upload ended early: nothing was written');
      }
      const copyPath = joinPath(dirName(place.lua), copy);
      const done = await serially(async () => {
        let bytes: Uint8Array;
        let decoded: string[] = [];
        try {
          const raw = new Uint8Array(await readFile(tmp));
          ({ bytes, decoded } = kind === 'glb' ? await decodeForImport(raw) : { bytes: raw, decoded: [] });
        } catch (err) {
          throw new Refused(422, `${o.name} could not be read as a ${kind === 'glb' ? 'GLB' : 'file'}: ${(err as Error).message}`);
        } finally {
          await rm(tmp, { force: true });
        }
        const family = o.replace
          ? unique([...(place.occupied ? familyOf(catalog.entries, place.lua) : []), ...(place.copyTaken ? familyOf(catalog.entries, copyPath) : []), ...(place.clash?.paths ?? []).flatMap((p) => familyOf(catalog.entries, p))])
          : [];
        await dropJobs(family);
        removing(family);
        let slot: string | undefined;
        if (family.length > 0) {
          const gone = await remove(root, { paths: family, only: true });
          if ('refused' in gone) throw new Refused(409, gone.refused);
          slot = gone.slot;
        }
        try {
          // The script first: the copy, seen before it is read, waits as `checking` for the script that names it.
          await writeOwn(place.lua, importScript(stem, copy, sha256(bytes), o.name), false);
          await writeOwn(copyPath, bytes, false);
          const record = Object.keys(overrides).length > 0 || o.excluded ? recordPath(place.lua) : undefined;
          if (record !== undefined) await writeOwn(record, recordText({ ...(o.excluded ? { include: false as const } : {}), options: overrides }), false);
          await learned([place.lua, copyPath, ...(record !== undefined ? [record] : []), ...family], slot !== undefined);
        } catch (err) {
          if (slot !== undefined) await putBack(slot, err as Error);
          await learned([place.lua, copyPath, ...family], slot !== undefined).catch(onError);
          throw err;
        }
        return { slot, decoded, family };
      });
      const flushed = drops.add(o.drop ?? newId(), { source: place.lua, owner: true, read: catalog.settle([place.lua]) }, o.drop !== undefined ? o.left : 0);
      const jobs = await flushed;
      return {
        ...answer(o.since),
        path: place.lua,
        ...(done.slot !== undefined ? { slot: done.slot } : {}),
        // What `replace` sent to the trash, as a plain import says it.
        ...(done.family.length > 0 ? { replaced: done.family } : {}),
        script: { copy: copyPath, decoded: done.decoded },
        jobs,
      } satisfies ImportAnswer;
    } catch (err) {
      // Refused, or broken off: the drop goes on without it -- queued now if it was the last.
      if (o.drop !== undefined) void drops.end(o.drop, o.left);
      throw err;
    }
  }

  // ---------------------------------------------------------------- writes' rules

  /** A write's path: anything in `AssetsSource/`; in a shipping root, only in a kind's folder (or a pack's own) -- `src/assets/` holds the game's code too. */
  function writable(path: string, folder = false): void {
    const where = locate(path);
    if (where?.root === 'source') return;
    if (where?.kind !== undefined && where.under !== undefined && where.under !== '') return;
    // A data kind's beside the table's (the engine's physics materials, a project's own): in its folder, under it.
    if (where?.root === 'boot' && dataDirs.some((dir) => path.startsWith(`${dir}/`))) return;
    if (folder && where?.pack !== undefined && where.rel === where.pack) return;
    throw new Refused(403, `${path} is not in a kind's folder: the asset tool writes only there`);
  }

  const isFolder = async (path: string): Promise<boolean | undefined> => {
    try {
      return (await lstat(abs(path))).isDirectory();
    } catch (err) {
      if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') return undefined;
      throw err;
    }
  };

  /** The sources among `paths` whose jobs a removal or a move must stop first (`Runner.drop`, §4). */
  async function dropJobs(paths: readonly string[]): Promise<void> {
    const sources = paths.filter((p) => catalog.entries.get(p)?.role === 'source');
    await Promise.all(sources.map((s) => runner.drop(s)));
  }

  /** `since`, as the call carries it; the `seq` it started at otherwise. */
  const sinceOf = (url: URL, fallback: number): number => {
    const raw = url.searchParams.get('since');
    const n = raw === null ? NaN : Number(raw);
    return Number.isInteger(n) && n >= 0 ? n : fallback;
  };
  const answer = (since: number): WriteAnswer => ({ seq: catalog.seq, diff: catalog.since(since) });

  /** The moves of a plan carried out: every destination expected, every origin ours to remove; put back as it was if one fails. */
  async function carryOut(steps: readonly Step[], records: ReadonlyMap<string, string>, caseOnly: readonly string[]): Promise<void> {
    for (const s of steps) if (!records.has(s.to)) catalog.expect(s.to, await stat(abs(s.from)), false);
    removing(steps.map((s) => s.from));
    const done: Step[] = [];
    try {
      for (const s of steps) {
        const text = records.get(s.to);
        if (text !== undefined) {
          await writeOwn(s.to, text, false);
          await rm(abs(s.from));
        } else if (caseOnly.includes(s.to)) {
          // macOS has one name for both spellings: through another -- and with `git mv` for a file git tracks, which
          // would not see it otherwise, and the live host would keep the old case (`case.ts`).
          await renameCase(root, s.from, s.to);
        } else await moveFile(abs(s.from), abs(s.to));
        moveHashRow(s.from, s.to);
        done.push(s);
        // A loose file's `.uid` (Docs/asset-ids.md §1) moves with it: its uid goes where it goes, no orphan left.
        if (await exists(abs(sidecarOf(s.from)))) {
          const side = { from: sidecarOf(s.from), to: sidecarOf(s.to) };
          if (caseOnly.includes(s.to)) await renameCase(root, side.from, side.to);
          else await moveFile(abs(side.from), abs(side.to));
          done.push(side);
        }
      }
    } catch (err) {
      for (const s of done.reverse()) {
        try {
          await moveFile(abs(s.to), abs(s.from));
        } catch (back) {
          (err as Error).message += `; and ${s.to} could not be moved back: ${(back as Error).message}`;
        }
      }
      throw err;
    }
  }

  /**
   * `GET thumb`'s work (the route's and `calls.thumb`'s): the cached thumbnail of `raw`, a path any root may hold, at
   * `size` -- made here where the server makes it -- or why there is none: not hashed yet, a browser's to make, none.
   */
  async function thumbOf(raw: unknown, size: number): Promise<{ file: string; hash: string } | ThumbMiss> {
    if (!THUMB_SIZES.includes(size)) throw new Refused(422, `a thumbnail is ${THUMB_SIZES.join(', ')} on its longer side`);
    const path = await checkPath(root, raw, READ_DIRS);
    if ((await isFolder(path)) !== false) throw new Refused(404, `${path} is not a file here`);
    const hash = await hashFor(path);
    if (hash === undefined) return { checking: true };
    const file = thumbFile(root, hash, size);
    const how = thumbHow(path);
    if (!(await exists(file))) {
      if (how === 'browser') return { make: 'browser', hash };
      if (how === 'none') return { none: `no thumbnail for .${extOf(path)}: its export, or its format's icon` };
      try {
        await once(`thumb:${hash}-${size}`, async () => {
          const bytes = await makeThumb(root, path, abs(path), size, catalog.tools ?? new Map(), bin);
          await mkdir(dirname(file), { recursive: true });
          await writeAtomic(file, bytes);
        });
      } catch (err) {
        return { none: (err as Error).message.split('\n')[0]! };
      }
    } else touch(file);
    return { file, hash };
  }

  /**
   * `PUT import`'s work (the route's and `calls.importFrom`'s): `fill` writes the file's bytes to a temp path -- the
   * request's body streamed, or a file on this machine copied -- and `script`, the route's alone, runs a `script=true`
   * import (the Model tab's, which answers itself). The file's place, name and options checked before a byte is read.
   */
  async function importing(
    url: URL,
    fill: (tmp: string) => Promise<unknown>,
    script?: (o: { since: number; dest: string; name: string; replace: boolean; excluded: boolean; drop: string | undefined; left: number }) => Promise<ImportAnswer>,
  ): Promise<ImportAnswer | undefined> {
    // A file of a drop on its way: the drop's hold does not run out while it comes (§5, Importing).
    const drop = q(url, 'drop') || undefined;
    const left = Number(q(url, 'left') ?? 0) || 0;
    if (drop !== undefined) drops.begin(drop);
    let ended = false;
    try {
      const since = sinceOf(url, catalog.seq);
      const dest = await checkPath(root, q(url, 'dest'), WRITE_DIRS, { folder: true });
      const name = q(url, 'name') ?? '';
      const asSource = q(url, 'source') !== 'false';
      const replace = q(url, 'replace') === 'true';
      // Out of the build from the start: its record says so, and nothing is exported.
      const include = q(url, 'include');
      if (include !== null && include !== 'true' && include !== 'false') throw new Refused(422, 'include is true or false');
      const excluded = include === 'false';
      // A .glb or .fbx as a Gladius script that imports it (Docs/modeler.md M39): its own way, below.
      if (q(url, 'script') === 'true') {
        if (!script) throw new Refused(422, 'script=true is an import of a .glb or .fbx beside a script, through the route or importFrom');
        ended = true;
        return await script({ since, dest, name, replace, excluded, drop, left });
      }
      const { target, found, extra } = importTarget(dest, name, asSource);
      if (excluded && !found) {
        throw new Refused(422, asSource ? 'include=false is for a source the pipeline exports' : `include=false is for a source: a file as delivered is left out of the build by an _ before its name, _${name}`);
      }
      writable(target);
      const folder = dirName(target);
      const here = await namesIn(folder);
      const there = await namesIn(twin(folder));
      const valid = validName(name, { siblings: here, twinSiblings: there });
      if ('refused' in valid) throw new Refused(422, valid.refused, valid.suggested !== undefined ? { suggested: valid.suggested } : {});
      // Options, for a source's record: checked now, before a byte is read.
      let overrides: Options = {};
      const optionsText = q(url, 'options');
      if (optionsText !== null && optionsText !== '' && optionsText !== '{}') {
        if (!found) throw new Refused(422, 'options are for a source the pipeline exports');
        let parsed: unknown;
        try {
          parsed = JSON.parse(optionsText);
        } catch {
          throw new Refused(422, 'options is not JSON');
        }
        if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) throw new Refused(422, 'options is an object of option names');
        const problems = checkOptions(found.row.options ?? {}, parsed as Record<string, unknown>);
        if (problems.length > 0) throw new Refused(422, problems.join('; '));
        const layers = await Promise.all(folderChain(target).map((d) => readFolderDefaults(root, d)));
        const base = resolveOptions(found.row, layers.map((l) => l.record?.options)).options;
        for (const [k, v] of Object.entries(parsed as Options)) if (canonical(v) !== canonical(base[k])) overrides[k] = v;
      }
      // What it would replace: itself, or a file whose key it would take.
      const occupied = await exists(abs(target));
      const clash = keyClash(target, found);
      if ((occupied || clash) && !replace) {
        throw new Refused(
          409,
          occupied ? `${name} exists in ${folder}` : `${name} would be a second source for ${clash!.key}; replace ${clash!.paths.map(baseName).join(', ')}, or name it differently`,
          { suggested: freeName(name, [here, there], false), ...(occupied ? { exists: true } : {}) },
        );
      }
      // The body, streamed: nothing is in place until all of it is here.
      const tmp = join(root, CACHE, 'tmp', newId());
      try {
        await fill(tmp);
      } catch {
        throw new Refused(400, 'the upload ended early: nothing was written');
      }
      const done = await serially(async () => {
        // Staged beside its place before anything goes to the trash: the copy that can fail (another
        // volume, out of space) is made while the old family is still in place, and what replaces it
        // is then one rename within one folder.
        const staged = tempBeside(target);
        try {
          await mkdir(dirname(staged), { recursive: true });
          await moveFile(tmp, staged);
        } finally {
          await rm(tmp, { force: true });
        }
        try {
          const family = replace ? unique([...(occupied ? familyOf(catalog.entries, target) : []), ...(clash?.paths ?? []).flatMap((p) => familyOf(catalog.entries, p))]) : [];
          // In order, for `hotUpdate`: the new file expected over the old before the old goes.
          catalog.expect(target, await stat(staged), occupied);
          await dropJobs(family);
          own(ownGone, target);
          removing(family.filter((p) => p !== target));
          let slot: string | undefined;
          if (family.length > 0) {
            const gone = await remove(root, { paths: family, only: true });
            if ('refused' in gone) throw new Refused(409, gone.refused);
            slot = gone.slot;
          }
          try {
            await place(staged, target, occupied);
          } catch (err) {
            // Nothing in place: the family back from its slot, where it was, and the index told.
            if (slot !== undefined) await putBack(slot, err as Error);
            await learned([target, ...family], slot !== undefined).catch(onError);
            throw err;
          }
          const record = found && (Object.keys(overrides).length > 0 || excluded) ? recordPath(target) : undefined;
          if (record !== undefined) await writeOwn(record, recordText({ ...(excluded ? { include: false as const } : {}), options: overrides }), await exists(abs(record)));
          await learned([target, ...(record !== undefined ? [record] : []), ...family], slot !== undefined);
          return { slot, family };
        } finally {
          await rm(staged, { force: true });
        }
      });
      // The drop's exports: with its last file, its owners read first (§5, step 6) -- answered with it. An extra queues nothing.
      ended = true;
      let flushed: Promise<QueuedJobInfo[]> | undefined;
      if (found && asSource) {
        const owner = isOwner(target);
        flushed = drops.add(drop ?? newId(), { source: target, owner, read: owner ? catalog.settle([target]) : Promise.resolve() }, drop !== undefined ? left : 0);
      } else if (drop !== undefined) flushed = drops.end(drop, left);
      const jobs = flushed ? await flushed : undefined;
      return { ...answer(since), path: target, ...(done.slot !== undefined ? { slot: done.slot, replaced: done.family } : {}), ...(extra ? { extra: true as const } : {}), ...(jobs ? { jobs } : {}) } satisfies ImportAnswer;
    } finally {
      // Refused, or its upload broken off: the drop goes on without it -- queued now if it was the last.
      if (drop !== undefined && !ended) void drops.end(drop, left);
    }
  }

  // ---------------------------------------------------------------- the routes

  type Route = (req: IncomingMessage, res: ServerResponse, url: URL) => Promise<void>;
  const q = (url: URL, name: string): string | null => url.searchParams.get(name);
  /**
   * A route whose work is a function of its query and its JSON body (Docs/mcp.md §3): the route reads the body and
   * sends what the work answers; the studio's MCP tools call the same work in-process (`call`), past the route's
   * guards -- which stay the route's (`handle`). `limit`, the body's at most; 0 for a `GET`, which reads none.
   */
  const json = (op: Op, limit?: number): Route & { op: Op } =>
    Object.assign(async (req: IncomingMessage, res: ServerResponse, url: URL) => sendJson(res, 200, await op(url, limit === 0 ? {} : await readJson(req, limit))), { op });

  const routes: Record<string, Route> = {
    // -------------------------------------------------- tools
    'GET tools': async (req, res) => {
      sendJson(res, 200, { write: mayWrite(req, hosts()), tools: toolList() } satisfies ToolsAnswer);
    },

    'POST tools/check': json(async (url) => {
      const since = sinceOf(url, catalog.seq);
      const jobs = await serially(() => lookAgain(NEEDS));
      return { ...answer(since), write: true, tools: toolList(), jobs } satisfies ToolsCheckAnswer;
    }),

    'PUT tools': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const name = q(url, 'name');
      const need = NEEDS.find((n) => n.tool === name);
      if (!need) throw new Refused(422, `no tool called ${name}: ${NEEDS.map((n) => n.tool).join(', ')}`);
      if (typeof body.path !== 'string') throw new Refused(422, "the body is { path }: the tool's path, or '' to forget it");
      await setLocalTool(root, need.tool, body.path);
      const jobs = await serially(() => lookAgain([need]));
      return { ...answer(since), write: true, tools: toolList(), jobs } satisfies ToolsCheckAnswer;
    }),

    // -------------------------------------------------- reading
    // The Gladius scripts whose export waits for a Claude turn's end (M21): the Model tab asks as it starts, then hears `held`.
    'GET held': async (_req, res) => {
      sendJson(res, 200, { held: [...(link?.held ?? [])], turns: link?.turns() ?? false } satisfies HeldAnswer);
    },

    // Every kind, the project's own too: what the Assets panel titles their folders by.
    'GET kinds': async (_req, res) => {
      sendJson(res, 200, { kinds: kindRows(options.kinds) } satisfies KindsAnswer);
    },

    'GET tree': async (_req, res, url) => {
      const raw = q(url, 'since');
      if (raw === null) return sendJson(res, 200, catalog.answer());
      const since = Number(raw);
      if (!Number.isInteger(since) || since < 0) throw new Refused(422, 'since is a seq: a whole number');
      sendJson(res, 200, catalog.since(since));
    },

    'GET stats': async (req, res, url) => {
      const path = await checkPath(root, q(url, 'path'), READ_DIRS);
      if ((await isFolder(path)) !== false) throw new Refused(404, `${path} is not a file here`);
      const hash = await hashFor(path);
      // Not hashed yet -- a source re-checked after its export: a 200 to a page that says it expects it
      // (`THUMB_MISS_HEADER`), as for a thumbnail, so an inspector asking as it redraws fills no console with red.
      if (hash === undefined) return sendJson(res, req.headers[THUMB_MISS_HEADER] === '200' ? 200 : 404, { checking: true } satisfies ThumbMiss);
      const file = statsFile(root, hash);
      try {
        const cached = JSON.parse(await readFile(file, 'utf8')) as FileStats;
        touch(file);
        return sendJson(res, 200, cached);
      } catch {
        // Not read yet: read now.
      }
      const stats = await once(`stats:${hash}`, async () => {
        const read = await readStats(abs(path), bin);
        await mkdir(dirname(file), { recursive: true });
        await writeAtomic(file, JSON.stringify(read));
        return read;
      });
      sendJson(res, 200, stats);
    },

    'GET file': async (req, res, url) => {
      const path = await checkPath(root, q(url, 'path'), READ_DIRS);
      await sendFile(req, res, path);
    },

    'GET thumb': async (req, res, url) => {
      const size = Number(q(url, 'size'));
      // A miss is `404`, or `200` for a page that says it expects them (`THUMB_MISS_HEADER`): its console stays quiet.
      const missed = req.headers[THUMB_MISS_HEADER] === '200' ? 200 : 404;
      const found = await thumbOf(q(url, 'path'), size);
      if (!('file' in found)) return sendJson(res, missed, found);
      const etag = thumbTag(found.hash, size);
      if (req.headers['if-none-match'] === etag) {
        res.writeHead(304, { ETag: etag, 'Cache-Control': 'no-cache' });
        res.end();
        return;
      }
      const bytes = await readFile(found.file);
      res.writeHead(200, { 'Content-Type': 'image/webp', 'Content-Length': bytes.length, 'Cache-Control': 'no-cache', ETag: etag });
      res.end(req.method === 'HEAD' ? undefined : bytes);
    },

    // Any 40-hex hash, on purpose: a `.trash/` file has no entry to check it against, and the hash is the
    // content the page rendered, not what is at a path by now. Loopback only, 1 MB, a WebP of its size;
    // one no file hashes to is the caches' prune's after 30 days (`thumbs.ts`).
    'PUT thumb': async (req, res, url) => {
      const since = sinceOf(url, catalog.seq);
      const hash = q(url, 'hash') ?? '';
      if (!/^[0-9a-f]{40}$/.test(hash)) throw new Refused(422, 'hash is the sha1 of the content the thumbnail shows');
      const size = Number(q(url, 'size'));
      if (!THUMB_SIZES.includes(size)) throw new Refused(422, `a thumbnail is ${THUMB_SIZES.join(', ')} on its longer side`);
      const body = await readBody(req, 1024 * 1024);
      let header;
      try {
        header = webpStats(body.subarray(0, 30));
      } catch {
        throw new Refused(422, 'a thumbnail is a WebP');
      }
      if (Math.max(header.width ?? 0, header.height ?? 0) !== size) {
        throw new Refused(422, `a ${size} thumbnail is ${size} on its longer side; this is ${header.width}×${header.height}`);
      }
      const file = thumbFile(root, hash, size);
      await mkdir(dirname(file), { recursive: true });
      await writeAtomic(file, body);
      sendJson(res, 200, answer(since));
    },

    'GET uses': json(async (url) => {
      const key = q(url, 'key');
      if (!key || key.length > 300) throw new Refused(422, 'key is the key, as Assets spells it: props/crate, reef:props/crate');
      return uses.find(key);
    }, 0),

    'GET names': async (_req, res, url) => {
      const dest = await checkPath(root, q(url, 'dest'), WRITE_DIRS, { folder: true });
      const folder = q(url, 'folder') === '1';
      const source = q(url, 'source');
      const asSource = source === null ? undefined : source !== 'false';
      const here = await namesIn(dest);
      const there = await namesIn(twin(dest));
      // In order, each against the folder and the names before it: a drop's files are one folder's names.
      const asked: Asked = { names: [], suggested: new Map(), keys: new Map() };
      sendJson(res, 200, url.searchParams.getAll('name').map((name) => checkName(dest, name, here, there, folder, asSource, asked)));
    },

    // A Gladius script as the kernel builds it (Docs/modeler.md §3): its polygons, its counts, a failed build's lines.
    // Writes nothing; one query at a time, the rest waiting in order.
    'GET model': async (_req, res, url) => {
      const { path, found } = await gladiusScript(url, 'GET model');
      const look = catalog.tools?.get('gladius');
      if (look && look.state !== 'found') {
        return sendJson(res, 200, { ok: false, ms: 0, diagnostics: [], nodes: [], missing: 'gladius', ...(look.hint ? { hint: look.hint } : {}) } satisfies ModelAnswer);
      }
      const { options } = await sourceOptions(root, path, found);
      const params = paramsOf(options);
      const answer = await querying(() => queryModel({ bin: bin('gladius'), input: abs(path), params, ...(look?.hint ? { hint: look.hint } : {}) }));
      sendJson(res, 200, answer);
    },

    // A Gladius script's params{} (Docs/modeler.md §3, M22): `gladius params`, no build, at the export's parameters. Writes nothing.
    'GET params': json(async (url): Promise<ParamsAnswer> => {
      const { path, found } = await gladiusScript(url, 'GET params');
      const { options, record } = await sourceOptions(root, path, found);
      const set = paramsOf(options);
      const own = paramsOf(record?.options ?? {});
      const look = catalog.tools?.get('gladius');
      if (look && look.state !== 'found') {
        return { ok: false, ms: 0, params: null, diagnostics: [], set, own, missing: 'gladius', ...(look.hint ? { hint: look.hint } : {}) } satisfies ParamsAnswer;
      }
      return asking(() => queryParams({ bin: bin('gladius'), input: abs(path), set, own, ...(look?.hint ? { hint: look.hint } : {}) }));
    }, 0),

    // A build that is not the export (Docs/modeler.md §3, M22): to .cache/assets/preview/, the bytes answered; per script
    // one running and the newest waiting, a replaced one answered `superseded`. Writes nothing under the roots.
    'POST preview': async (req, res, url) => {
      const { path, found } = await gladiusScript(url, 'POST preview');
      const body = await readJson(req, 64 * 1024);
      const asked = body.params;
      if (asked !== undefined && (typeof asked !== 'object' || asked === null || Array.isArray(asked))) throw new Refused(422, 'params is an object of parameter names and their values');
      const over: Record<string, string> = {};
      for (const [name, value] of Object.entries((asked ?? {}) as Record<string, unknown>)) {
        if (typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean') throw new Refused(422, `params.${name} is a number, a string or true or false`);
        over[name] = String(value);
      }
      const look = catalog.tools?.get('gladius');
      if (look && look.state !== 'found') {
        return sendJson(res, 200, { ok: false, ms: 0, diagnostics: [], error: 'gladius is not found on this machine', missing: 'gladius', ...(look.hint ? { hint: look.hint } : {}) } satisfies PreviewFailure);
      }
      const { options } = await sourceOptions(root, path, found);
      const got = await previews.ask(path, { options, params: previewParams(paramsOf(options), over) });
      if (got === SUPERSEDED) return sendJson(res, 200, { ok: false, ms: 0, diagnostics: [], superseded: true } satisfies PreviewFailure);
      if (!got.ok) return sendJson(res, 200, got);
      res.writeHead(200, { 'Content-Type': 'model/gltf-binary', 'Content-Length': got.bytes.byteLength, 'Cache-Control': 'no-store', 'X-Preview-Ms': String(got.ms) });
      res.end(Buffer.from(got.bytes.buffer, got.bytes.byteOffset, got.bytes.byteLength));
    },

    // A Gladius script replayed op by op (Docs/modeler.md §3, M34): built instrumented to .cache/assets/trace/, the steps
    // answered and the GLB kept for `GET trace`; per script one running and the newest waiting. Writes nothing under the roots.
    'POST trace': json(async (url): Promise<TraceAnswer> => {
      const { path, found } = await gladiusScript(url, 'POST trace');
      const look = catalog.tools?.get('gladius');
      if (look && look.state !== 'found') {
        return { ok: false, ms: 0, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics: [], error: 'gladius is not found on this machine', missing: 'gladius', ...(look.hint ? { hint: look.hint } : {}) } satisfies TraceAnswer;
      }
      const { options } = await sourceOptions(root, path, found);
      const got = await traces.ask(path, { params: paramsOf(options) });
      if (got === SUPERSEDED) return { ok: false, ms: 0, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics: [], superseded: true } satisfies TraceAnswer;
      return got;
    }, 0),

    // The trace `POST trace` answered, by its version: its GLB -- or, `faces=1`, each step's polygons (a second Gladius
    // pass, asked while a wire mode is on, kept with the trace). A version not the last one built is gone: 404.
    'GET trace': async (_req, res, url) => {
      const { path } = await gladiusScript(url, 'GET trace');
      const kept = traced.get(path);
      if (!kept || kept.version !== q(url, 'v')) throw new Refused(404, `no trace ${q(url, 'v') ?? ''} of ${path} here: trace it again`);
      if (q(url, 'faces') === '1') {
        // Of the text traced, not the file now (a save since would give its steps another script's polygons); one that
        // failed is not kept -- the next ask tries again.
        const faces = (kept.faces ??= tracing(() => traceFaces({ bin: bin('gladius'), input: abs(path), params: kept.params, source: kept.source })));
        const got = await faces;
        if (!got.ok && kept.faces === faces) delete kept.faces;
        return sendJson(res, 200, got);
      }
      let bytes: Buffer;
      try {
        bytes = await readFile(traceFile(path));
      } catch {
        throw new Refused(404, `the trace of ${path} is not in the cache any more: trace it again`);
      }
      res.writeHead(200, { 'Content-Type': 'model/gltf-binary', 'Content-Length': bytes.byteLength, 'Cache-Control': 'no-store' });
      res.end(bytes);
    },

    // A Gladius script written whole (Docs/modeler.md M23): the Model tab's bakes, material edits and undo. `expect` is the
    // text the page last read: anything else on disk now -- an outside edit since -- is a 409, and nothing is written.
    'PUT script': async (req, res, url) => {
      const since = sinceOf(url, catalog.seq);
      const { path } = await gladiusScript(url, 'PUT script');
      const body = await readJson(req, 4 * 1024 * 1024);
      const { text, expect } = body;
      if (typeof text !== 'string' || typeof expect !== 'string') throw new Refused(422, 'the body is { text, expect }: the script as it is to be, and as the page last read it');
      writable(path);
      const jobs = await serially(async () => {
        const now = await readFile(abs(path), 'utf8').catch(() => null);
        if (now === null) throw new Refused(404, `${path} is not there`);
        if (now !== expect) throw new Refused(409, `${baseName(path)} changed on disk since it was read: read it again first`, { changed: true });
        if (now === text) return [];
        await writeOwn(path, text, true);
        await learned([path], false);
        // The server's own write is no watch event: its export queued here, as an option set is (§4, Auto-export).
        const job = autoExport(path);
        return job ? [job] : [];
      });
      sendJson(res, 200, { ...answer(since), jobs } satisfies ScriptAnswer);
    },

    // A Gladius script's record written back, its settings as they were (Docs/modeler.md M23): the Model tab's undo of a
    // record step -- the settings from before verbatim, under the disk's own `built` stamp; not options re-derived (PUT sidecar keeps only what differs from the defaults, so a
    // `"merge": "none"` written by hand would not come back). Guarded as PUT script is: refused unless the disk still has
    // `expect` (null: no record); `text` null takes the record away. Its export queued.
    'PUT record': async (req, res, url) => {
      const since = sinceOf(url, catalog.seq);
      const { path } = await gladiusScript(url, 'PUT record');
      const body = await readJson(req, 256 * 1024);
      const { text, expect } = body;
      if ((typeof text !== 'string' && text !== null) || (typeof expect !== 'string' && expect !== null)) throw new Refused(422, 'the body is { text, expect }: the record as it is to be, and as the page last read it -- null for none');
      if (typeof text === 'string') {
        let parsed: unknown;
        try {
          parsed = JSON.parse(text);
        } catch {
          throw new Refused(422, 'text is not JSON');
        }
        if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) throw new Refused(422, 'text is not a record: an object');
      }
      const file = catalog.recordOf(path);
      writable(file);
      const jobs = await serially(async () => {
        const now = await readFile(abs(file), 'utf8').catch(() => null);
        // What a person set -- the options, the tick -- must be as the page read it; the build's own stamp (`built`) is
        // the pipeline's, rewritten by every export, and not the page's to have seen.
        const settings = (t: string | null): string | null => {
          if (t === null) return null;
          try {
            const { built: _built, ...rest } = JSON.parse(t) as Record<string, unknown>;
            void _built;
            return canonical(rest);
          } catch {
            return t;
          }
        };
        if (settings(now) !== settings(expect)) throw new Refused(409, `${baseName(file)} changed on disk since it was read: read it again first`, { changed: true });
        // The settings are the page's, the stamp never: `built` says what made the export on disk now, and only an export
        // writes it. The page's text carries the stamp of when it was read -- written back, a source whose settings went
        // back would read current against an export built from the others (an anim 0 undone, its glb left in place).
        // So the disk's own stamp is kept under the settings restored, and the source reads stale if they differ.
        const kept = (() => {
          if (now === null) return undefined;
          try {
            const b = (JSON.parse(now) as Partial<ExportRecord>).built;
            // Only a stamp the pipeline wrote: a broken one is dropped, the source then stale.
            return b && typeof b.source === 'string' && typeof b.recipe === 'string' && Array.isArray(b.to) && typeof b.at === 'string' && typeof b.tools === 'object' && b.tools !== null ? b : undefined;
          } catch {
            return undefined;
          }
        })();
        // The asset's uid is the disk's too, never the page's to change (Docs/asset-ids.md §1); the stem it ships `as` is the page's.
        const uid = (() => {
          try {
            return now === null ? undefined : parseRecord(now).uid;
          } catch {
            return undefined;
          }
        })();
        let next: string | null = text;
        if (text !== null) {
          const asked = JSON.parse(text) as Partial<ExportRecord> & Record<string, unknown>;
          const options = typeof asked.options === 'object' && asked.options !== null && !Array.isArray(asked.options) ? (asked.options as Options) : {};
          const as = asProblem(asked.as) === undefined ? (asked.as as string) : undefined;
          next = recordText({ ...(asked.include === false ? { include: false as const } : {}), ...(uid !== undefined ? { uid } : {}), ...(as !== undefined ? { as } : {}), options, ...(kept ? { built: kept } : {}) });
        }
        if (now === next) return [];
        if (next === null) {
          removing([file]);
          await rm(abs(file));
        } else await writeOwn(file, next, now !== null);
        await learned([file], false);
        const job = autoExport(path);
        return job ? [job] : [];
      });
      sendJson(res, 200, { ...answer(since), jobs } satisfies ScriptAnswer);
    },

    // New model (Docs/modeler.md M38; Vibe3D D34, D40): `{ dir, name }` -- a starter script, `<name>.lua`, in a folder
    // under AssetsSource/models/ (or its twin), refused where the name is taken or its key is another file's; its
    // export queued at once, so the Model tab has a model to open. The page's step takes it to the trash.
    'POST model': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const dir = await checkPath(root, body.dir, WRITE_DIRS, { folder: true });
      // As typed, a `.lua` typed with it let go (D34).
      const stem = typeof body.name === 'string' ? body.name.replace(/\.lua$/i, '') : '';
      const place = await scriptPlace(dir, stem);
      freePlace(place);
      const jobs = await serially(async () => {
        if (await exists(abs(place.lua))) throw new Refused(409, `${place.name} exists already: pick another name, or open it and keep working`, { suggested: place.suggested, exists: true });
        await writeOwn(place.lua, starterScript(stem), false);
        await learned([place.lua], false);
        const { id } = runner.add(place.lua, { slot: 'new', force: true });
        return [{ id, source: place.lua }];
      });
      return { ...answer(since), path: place.lua, jobs } satisfies ModelMadeAnswer;
    }),

    // Make a script for a .glb (Docs/modeler.md M39; Vibe3D D49): `{ path }`, a .glb delivered as it is under a models
    // folder, with no source -- copied (decoded, if compressed) into its AssetsSource/ twin as `<stem>.source.glb` beside
    // a script that imports it pinned by hash. Its key is the script's now: the export, queued to a slot of its own,
    // replaces the file, which that slot keeps (the page's undo puts it back).
    'POST adopt': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const path = await checkPath(root, body.path, WRITE_DIRS);
      const e = catalog.entries.get(path);
      if (!e || e.role !== 'loose' || e.kind !== 'models' || extOf(path) !== 'glb') {
        throw new Refused(422, `${baseName(path)} is not a .glb delivered as it is under models: Make a script is for a model with no source`);
      }
      const stem = splitName(baseName(path)).stem;
      const copy = importCopyName(stem, 'glb');
      const place = await scriptPlace(dirName(path), stem, { copy, except: path });
      freePlace(place, copy);
      const made = await serially(async () => {
        const { bytes, decoded } = await decodeForImport(new Uint8Array(await readFile(abs(path))));
        const copyPath = joinPath(dirName(place.lua), copy);
        // The script first: the copy, seen before it is read, waits as `checking` for the script that names it.
        await writeOwn(place.lua, importScript(stem, copy, sha256(bytes), baseName(path)), false);
        await writeOwn(copyPath, bytes, false);
        await learned([place.lua, copyPath], false);
        const { id } = runner.add(place.lua, { slot: 'new', force: true });
        return { copy: copyPath, decoded, jobs: [{ id, source: place.lua }] };
      });
      return { ...answer(since), path: place.lua, ...made } satisfies ModelMadeAnswer;
    }),

    'GET jobs': json(async () => runner.jobs(), 0),

    'GET run': async (req, res, url) => {
      const path = await checkPath(root, q(url, 'path'), WRITE_DIRS);
      const run = runs.get(path);
      // None, said as a 200 to a page that expects it (`THUMB_MISS_HEADER`): its console stays quiet, as for a thumbnail.
      if (!run && req.headers[THUMB_MISS_HEADER] === '200') return sendJson(res, 200, { none: true });
      if (!run) throw new Refused(404, `no export of ${path} has been tried on this machine`);
      // Does it describe the export there now: its source and recipe the record's `built` (a note of a build since
      // replaced -- an option changed back, the record from git -- is not the export's to say).
      const built = (await readRecord(root, path)).record?.built;
      sendJson(res, 200, { ...run, current: run.ok && built !== undefined && built.source === run.source && built.recipe === run.recipe } satisfies Run);
    },

    // -------------------------------------------------- importing
    'PUT import': async (req, res, url) => {
      const fill = (tmp: string): Promise<unknown> => bodyToFile(req, tmp);
      const done = await importing(url, fill, (o) => importAsScript(url, o, fill));
      if (done) sendJson(res, 200, done);
    },

    // -------------------------------------------------- exporting
    'POST export': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const force = body.force === true;
      const chosen = new Set<string>();
      if (body.under !== undefined) {
        const dir = await checkPath(root, body.under, WRITE_DIRS, { folder: true });
        const s = sides(dir);
        for (const source of catalog.sources()) {
          if (!under(source, dir) && !(s.source !== undefined && under(source, s.source))) continue;
          const status = catalog.status(source);
          if (force ? status !== 'reference' && status !== 'conflict' && status !== 'excluded' : status === 'stale' || status === 'missing') chosen.add(source);
        }
      } else if (Array.isArray(body.paths)) {
        for (const raw of body.paths) {
          const path = await checkPath(root, raw, WRITE_DIRS);
          const e = catalog.entries.get(path);
          const sources = e?.role === 'part' ? (e.owners ?? []) : [sourceOf(catalog.entries, path)].filter((s): s is string => s !== undefined);
          if (sources.length === 0) throw new Refused(422, `${path} is not made by the pipeline: nothing to export`);
          for (const source of sources) {
            const status = catalog.status(source);
            // Out of the build: never exported, asked or not -- its tick, or its record, puts it back.
            if (status === 'reference' || status === 'excluded' || (status === 'current' && !force)) continue;
            chosen.add(source);
          }
        }
      } else throw new Refused(422, 'the body is { paths } or { under }, and force if wanted');
      const jobs = [...chosen].map((source) => ({ id: runner.add(source, { force, slot: 'new' }).id, source }));
      return { ...answer(since), jobs } satisfies ExportAnswer;
    }),

    'POST convert/claim': async (req, res, url) => {
      const since = sinceOf(url, catalog.seq);
      await readJson(req);
      const job = jobId(q(url, 'job'));
      if (!bridge.claim(job)) throw new Refused(409, 'another tab took this conversion, or it is not waiting for one');
      sendJson(res, 200, answer(since));
    },

    'PUT intermediate': async (req, res, url) => {
      const since = sinceOf(url, catalog.seq);
      const job = jobId(q(url, 'job'));
      if (!bridge.open().some((o) => o.job === job && o.claimed)) throw new Refused(409, 'this job is not waiting for a tab of yours');
      const three = q(url, 'three');
      if (three !== null && catalog.npm.three !== undefined && three !== catalog.npm.three) {
        throw new Refused(422, `this tab runs three r${three}, the project has r${catalog.npm.three}: reload the tab`);
      }
      const dir = join(root, CACHE, 'jobs', job);
      if (!(await exists(dir))) throw new Refused(409, 'this job has ended');
      const tmp = join(dir, `.browser.${randomBytes(4).toString('hex')}.tmp`);
      try {
        await bodyToFile(req, tmp);
      } catch {
        // Its job dropped while the file came (its source deleted, an import undone): ended, not broken.
        if (!(await exists(dir))) throw new Refused(409, 'this job has ended');
        if (!res.headersSent && !res.destroyed) sendJson(res, 400, { refused: 'the upload ended early: nothing was written' });
        return;
      }
      const file = join(dir, 'browser.glb');
      try {
        const head = Buffer.alloc(4);
        const handle = await open(tmp, 'r');
        try {
          await handle.read(head, 0, 4, 0);
        } finally {
          await handle.close();
        }
        if (head.toString('latin1') !== 'glTF') throw new Refused(422, 'a conversion is sent as a .glb');
        await rename(tmp, file);
      } catch (err) {
        await rm(tmp, { force: true });
        if (!(err instanceof Refused) && !(await exists(dir))) throw new Refused(409, 'this job has ended');
        throw err;
      }
      if (!bridge.sent(job, file)) {
        await rm(file, { force: true });
        throw new Refused(409, 'this job is not waiting for a tab of yours');
      }
      sendJson(res, 200, answer(since));
    },

    // -------------------------------------------------- moving, deleting, restoring
    'POST move': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const from = await checkPath(root, body.from, WRITE_DIRS, { folder: true });
      const to = await checkPath(root, body.to, WRITE_DIRS, { folder: true });
      writable(from, true);
      writable(to, true);
      // An undo's texts (Docs/asset-ids.md §4): the files this move's forward run rewrote, as they were -- written back after it.
      const restoring = await restoreList(body.restore);
      // The move with the repair pass on either side of it (Docs/asset-ids.md §4): before, every bare key given its uid while
      // the index still knows the old path (so a hand-written key follows too); after, every reference's key the one its
      // uid's asset has now. The files it rewrote answered with their texts before, for the step's undo. The move's checks
      // all run first, so a refused move writes nothing; a pass that throws after the move answers what it did (`partial`),
      // a step Z undoes like any. Both passes touch only the references to what moves (`refsTo`): its uids, and before
      // the move a bare key naming it -- never an unrelated bare key elsewhere. An undo's restore writes a file back only
      // where it still holds what the doing left (`after`); one edited since is kept as it is, answered as `kept`.
      const done = rewrites();
      let partial: string | undefined;
      let kept = new Set<string>();
      const moved = await serially((): Promise<Array<[string, string]>> => repairWindow(async () => {
        const plan = await planNow();
        const only = refsTo(root, options.kinds ?? {}, plan.paths);
        try {
          await repairNow(done, new Map(), only);
        } catch (err) {
          // Nothing moved yet: what the pass wrote goes back as it was, and the move is not made.
          for (const [path, text] of done.befores) await writeOwn(path, text, true).catch(() => undefined);
          throw err;
        }
        const pairs = await plan.carry();
        kept = await editedSince(restoring);
        try {
          await repairNow(done, new Map(pairs.map(([a, b]) => [b, a])), { uids: only.uids, slots: new Set() });
        } catch (err) {
          partial = `the files naming what moved were not all rewritten: ${(err as Error).message}`;
        }
        for (const r of restoring) {
          if (kept.has(r.path) || !(await exists(abs(r.path)))) continue;
          const was = await readFile(abs(r.path), 'utf8');
          if (was === r.text) continue;
          if (!done.befores.has(r.path)) done.befores.set(r.path, was);
          await writeOwn(r.path, r.text, true);
          done.afters.set(r.path, r.text);
        }
        if (done.befores.size > 0) await learned([...done.befores.keys()], false);
        return pairs;
      }));
      return {
        ...answer(since),
        moved,
        ...(done.befores.size > 0 ? { rewritten: rewrittenOf(done) } : {}),
        ...(kept.size > 0 ? { kept: [...kept] } : {}),
        ...(partial !== undefined ? { partial } : {}),
      } satisfies MoveAnswer;

      /**
       * The move's checks -- the folder there, the plan and its refusals -- writing nothing; answers the move itself to
       * run, and the files it takes.
       */
      async function planNow(): Promise<{ carry: () => Promise<Array<[string, string]>>; paths: string[] }> {
        const folder = await isFolder(from);
        if (folder === undefined) throw new Refused(404, `${from} is not there`);
        if (folder) {
          const plan = planned(await planFolderMove(root, catalog.entries, from, to));
          return { carry: () => moveFolder(plan), paths: plan.steps.map((s) => s.from) };
        }
        const plan = planned(await planMove(root, catalog.entries, from, to));
        return { carry: () => moveFamily(plan), paths: plan.steps.map((s) => s.from) };
      }

      /** A folder with its twin, moved. */
      async function moveFolder(plan: Exclude<Awaited<ReturnType<typeof planFolderMove>>, PlanRefusal>): Promise<Array<[string, string]>> {
        await dropJobs(plan.steps.map((s) => s.from));
        for (const s of plan.steps) catalog.expect(s.to, await stat(abs(s.from)), false);
        removing(plan.steps.map((s) => s.from));
        // Every folder that moves, the ones inside too (`hud/textures/`): its `unlinkDir` and its `addDir` are the server's own.
        for (const d of plan.dirs) {
          for (const s of plan.steps) {
            if (!under(s.from, d.from)) continue;
            for (let dir = dirName(s.from); dir !== d.from && under(dir, d.from); dir = dirName(dir)) {
              own(ownGone, dir);
              own(ownDirs, d.to + dir.slice(d.from.length));
            }
          }
        }
        const done: Step[] = [];
        try {
          for (const d of plan.dirs) {
            own(ownGone, d.from);
            own(ownDirs, d.to);
            // A folder renamed in case only: through another name, `git mv` for one git tracks (`case.ts`).
            if (caseKey(d.from) === caseKey(d.to)) await renameCase(root, d.from, d.to);
            else await moveFile(abs(d.from), abs(d.to));
            done.push(d);
          }
        } catch (err) {
          for (const d of done.reverse()) {
            try {
              await moveFile(abs(d.to), abs(d.from));
            } catch (back) {
              (err as Error).message += `; and ${d.to} could not be moved back: ${(back as Error).message}`;
            }
          }
          throw err;
        }
        for (const s of plan.steps) moveHashRow(s.from, s.to);
        // Renamed in case only: one name for both spellings on macOS, so the listings say which the disk has.
        const spelled = plan.dirs.some((d) => caseKey(d.from) === caseKey(d.to)) ? plan.steps.flatMap((s) => [s.from, s.to]) : [];
        await learned([...plan.steps.map((s) => s.from), ...plan.steps.map((s) => s.to)], false, spelled);
        return plan.steps.map((s) => [s.from, s.to]);
      }

      /** A family, moved. */
      async function moveFamily(plan: Exclude<Awaited<ReturnType<typeof planMove>>, PlanRefusal>): Promise<Array<[string, string]>> {
        await dropJobs(plan.steps.map((s) => s.from));
        await carryOut(plan.steps, plan.records, plan.caseOnly);
        // A case-only rename: one name for both spellings on macOS, so the folder's listing says which the disk has -- no walk.
        const spelled = plan.steps.filter((s) => plan.caseOnly.includes(s.to)).flatMap((s) => [s.from, s.to]);
        await learned([...plan.steps.map((s) => s.from), ...plan.steps.map((s) => s.to)], false, spelled);
        return plan.steps.map((s) => [s.from, s.to]);
      }
    }),

    // What names these files' assets (Docs/asset-ids.md §4): the data files whose references -- by uid, a stale key
    // too, or a bare key where a reference goes -- name any of them, whole families taken as a delete takes them, those
    // among them left out. The tool's Delete asks first, and is refused while any is left. Reads only.
    'POST referrers': json(async (_url, body) => {
      if (!Array.isArray(body.paths) || body.paths.length === 0) throw new Refused(422, 'the body is { paths }');
      const paths: string[] = [];
      for (const raw of body.paths) paths.push(await checkPath(root, raw, WRITE_DIRS, { folder: true }));
      const all = unique(paths.flatMap((p) => familyOf(catalog.entries, p)));
      return { referrers: referrersOf(root, options.kinds ?? {}, all) } satisfies ReferrersAnswer;
    }),

    'POST delete': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      if (!Array.isArray(body.paths) || body.paths.length === 0) throw new Refused(422, 'the body is { paths }, and only if only those files');
      const paths: string[] = [];
      for (const raw of body.paths) {
        const path = await checkPath(root, raw, WRITE_DIRS, { folder: true });
        writable(path, true);
        paths.push(path);
      }
      const only = body.only === true;
      const gone = await serially(async () => {
        // Nothing there: an undo that pointed at the wrong path must not "succeed".
        const there = await Promise.all(paths.map(isFolder));
        if (there.every((t) => t === undefined)) throw new Refused(404, `${paths.length === 1 ? `${paths[0]} is not there` : 'none of these is there'}: nothing was removed`, { removed: [] });
        const all = only ? unique(paths) : unique(paths.flatMap((p) => familyOf(catalog.entries, p)));
        // A source with a job: stopped first, so the delete trashes after it, never under it.
        await dropJobs(all);
        removing(all);
        const done = await remove(root, { paths: all, only: true });
        if ('refused' in done) throw new Refused(409, done.refused);
        await learned(done.removed, done.slot !== undefined);
        return done;
      });
      return { ...answer(since), removed: gone.removed, ...(gone.slot !== undefined ? { slot: gone.slot } : {}) } satisfies DeleteAnswer;
    }),

    'POST restore': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const slot = body.slot;
      if (typeof slot !== 'string' || slot === '' || slot === '.' || slot === '..' || /[/\\\0]/.test(slot)) throw new Refused(422, 'slot is a trash slot\'s name');
      let paths: string[] | undefined;
      if (body.paths !== undefined) {
        if (!Array.isArray(body.paths)) throw new Refused(422, 'paths is a list');
        paths = [];
        for (const raw of body.paths) paths.push(await checkPath(root, raw, WRITE_DIRS));
      }
      const replace = body.replace === true;
      const result = await serially(async () => {
        const inSlot = (await readTrash(root)).find((s) => s.slot === slot)?.files.map((f) => f.path) ?? [];
        const wanted = paths ?? inSlot;
        for (const p of wanted) writable(p);
        // A part keeps its name (its source names it): a file beside a model source coming back with it, or one the index calls a part.
        const models = wanted.filter(isOwner);
        const parts = wanted.filter(
          (p) =>
            catalog.entries.get(p)?.role === 'part' ||
            (!isOwner(p) &&
              !isRecordName(baseName(p)) &&
              !baseName(p).startsWith('_') &&
              models.some((m) => (dirName(p) === dirName(m) || dirName(p) === joinPath(dirName(m), 'textures')) && familyStem(baseName(p)) !== familyStem(baseName(m)))),
        );
        let displacedPaths: readonly string[] = [];
        const done = await restore(root, slot, {
          ...(paths !== undefined ? { paths } : {}),
          replace,
          parts,
          before: async (moves, displaced) => {
            displacedPaths = displaced;
            await dropJobs([...displaced]);
            for (const d of displaced) own(ownGone, d);
            for (const m of moves) catalog.expect(m.to, await stat(m.from), m.replaced);
          },
        });
        if ('refused' in done) throw new Refused(/other content/.test(done.refused) ? 409 : 422, done.refused);
        for (const p of done.restored) {
          const st = await stat(abs(p));
          const was = catalog.writes.get(p);
          if (was && (was.mtimeMs !== st.mtimeMs || was.size !== st.size)) catalog.expect(p, st, was.replaced);
        }
        await learned(unique([...done.restored, ...displacedPaths]), true);
        return done;
      });
      return { ...answer(since), restored: result.restored, ...(result.slot !== undefined ? { slot: result.slot } : {}) } satisfies RestoreAnswer;
    }),

    'POST empty-trash': json(async (url) => {
      const since = sinceOf(url, catalog.seq);
      await serially(async () => {
        await emptyTrash(root);
        await learned([], true);
      });
      return answer(since);
    }),

    'POST mkdir': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const path = await checkPath(root, body.path, WRITE_DIRS, { folder: true });
      writable(path, true);
      await serially(async () => {
        if ((await isFolder(path)) !== undefined) throw new Refused(409, `${path} exists`, { exists: true });
        const valid = validName(baseName(path), { folder: true, siblings: await namesIn(dirName(path)), twinSiblings: await namesIn(twin(dirName(path))) });
        if ('refused' in valid) throw new Refused(422, valid.refused, valid.suggested !== undefined ? { suggested: valid.suggested } : {});
        own(ownDirs, path);
        await mkdir(abs(path), { recursive: true });
      });
      return answer(since);
    }),

    // A prefab file written whole (Docs/prefabs.md §7): the Assets tool's New prefab, Make variant, a pool's
    // numbers, a rename's nesting prefabs. Under src/assets/prefabs/, a .prefab whose JSON parses and says it is a
    // prefab; `create` refuses one there (`exists`), else it must be there. Answers its text before, for the undo.
    // A scene the same way (the editor's Save, Docs/ecs.md §19): under src/assets/scenes/, a .scene whose JSON is a
    // world save, made with `create` or written again without. And a level rewritten by a prefab's rename (a level
    // holds instances by key: Docs/prefabs.md §6): under src/assets/levels/, a .json there already, a world save.
    // And a material file (Docs/render.md §4: the Assets tool's New material, the Material block's edits, a rename's
    // prefabs naming it): under src/assets/materials/, a .material whose JSON says it is a material.
    // The file's uid (Docs/asset-ids.md §1) is the file's, not the page's: a text written without one keeps the one
    // the file had (the editor's writers know no uid yet), a new file has one at once -- never a second stamp later.
    'PUT prefab': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const levels = joinPath(ROOTS.boot.dir, KINDS.levels.dir);
      const scenes = joinPath(ROOTS.boot.dir, KINDS.scenes.dir);
      const materials = joinPath(ROOTS.boot.dir, KINDS.materials.dir);
      const physmats = joinPath(ROOTS.boot.dir, ENGINE_DATA_KINDS.physicsmaterials!.dir);
      const path = await checkPath(root, q(url, 'path'), [joinPath(ROOTS.boot.dir, KINDS.prefabs.dir), levels, scenes, materials, physmats]);
      const text = body.text;
      const create = body.create === true;
      const level = path.startsWith(`${levels}/`);
      const scene = path.startsWith(`${scenes}/`);
      const material = path.startsWith(`${materials}/`);
      // A physics material (Docs/physics.md §4.3): the editor's Assets panel makes and edits one as it does a material.
      const physmat = path.startsWith(`${physmats}/`);
      const prefab = !level && !scene && !material && !physmat;
      if (typeof text !== 'string') throw new Refused(422, 'the body is { text, create? }: the file as text');
      if (level && (!path.endsWith('.json') || create)) throw new Refused(422, `${path}: a level is rewritten here, a .json there already`);
      if (scene && !path.endsWith(SCENE_SUFFIX)) throw new Refused(422, `${path}: a scene file ends in ${SCENE_SUFFIX}`);
      if (material && !path.endsWith(MATERIAL_SUFFIX)) throw new Refused(422, `${path}: a material file ends in ${MATERIAL_SUFFIX}`);
      if (physmat && !path.endsWith('.physmat')) throw new Refused(422, `${path}: a physics material file ends in .physmat`);
      if (prefab && !path.endsWith(PREFAB_SUFFIX)) throw new Refused(422, `${path}: a prefab file ends in ${PREFAB_SUFFIX}`);
      const problem = jsonProblem(text);
      if (problem) throw new Refused(422, `${baseName(path)} would not parse${problem.line !== undefined ? ` (line ${problem.line})` : ''}: ${problem.message}`);
      const parsed = JSON.parse(text) as { is?: unknown; version?: unknown; entities?: unknown };
      if ((level || scene) && (parsed === null || typeof parsed !== 'object' || parsed.version !== 1 || !Array.isArray(parsed.entities))) throw new Refused(422, `${baseName(path)}: a ${level ? 'level' : 'scene'} is a world save ("version": 1, "entities": [...])`);
      if (material && (parsed === null || typeof parsed !== 'object' || parsed.is !== 'vibebase.material')) throw new Refused(422, `${baseName(path)}: a material file says "is": "vibebase.material"`);
      if (physmat) {
        const read = parsePhysicsMaterial(parsed);
        if (typeof read === 'string') throw new Refused(422, `${baseName(path)}: ${read}`);
      }
      if (prefab && (parsed === null || typeof parsed !== 'object' || parsed.is !== 'vibebase.prefab')) throw new Refused(422, `${baseName(path)}: a prefab file says "is": "vibebase.prefab"`);
      writable(path);
      const before = await serially(async () => {
        const there = await exists(abs(path));
        if (create && there) throw new Refused(409, `${baseName(path)} exists in ${dirName(path)}`, { exists: true });
        if (!create && !there) throw new Refused(404, `${path} is not there`);
        if (create) {
          const valid = validName(baseName(path), { siblings: await namesIn(dirName(path)), twinSiblings: [] });
          if ('refused' in valid) throw new Refused(422, valid.refused, valid.suggested !== undefined ? { suggested: valid.suggested } : {});
        }
        const was = there ? await readFile(abs(path), 'utf8') : null;
        await writeOwn(path, keepUid(text, was), there);
        // The file as it lands has every key current (the repair pass over it alone): an Apply's undo or redo writing a
        // file of an older era -- a prefab it nests renamed since -- names each by the key its uid has now.
        for (const r of planRefs(root, options.kinds, { within: new Set([path]) })) await writeOwn(r.path, r.text, true);
        await learned([path], false);
        return was;
      });
      return { ...answer(since), path, before } satisfies PrefabAnswer;
    }, 16 * 1024 * 1024),

    'POST copy': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const from = await checkPath(root, body.from, WRITE_DIRS);
      const to = await checkPath(root, body.to, WRITE_DIRS, { folder: true });
      writable(from);
      writable(joinPath(to, baseName(from)));
      const paths = await serially(async () => {
        if ((await isFolder(from)) !== false) throw new Refused(404, `${from} is not a file here`);
        const plan = planned(await planCopy(root, catalog.entries, from, to));
        const written: string[] = [];
        const sidecars: string[] = [];
        try {
          for (const s of plan.steps) {
            // The copy is an asset of its own (rule 7): a record's or a data file's uid a new one, a loose file's sidecar new.
            const record = plan.records.get(s.to);
            const textual = record !== undefined || isRecordName(baseName(s.to)) || dataFile(s.to);
            const text = record ?? (textual ? await readFile(abs(s.from), 'utf8') : undefined);
            const fresh = text === undefined ? undefined : (freshCopy(s.to, text, dataFile(s.to)) ?? record);
            if (fresh !== undefined) await writeOwn(s.to, fresh, false);
            else await copyOwn(s.from, s.to);
            written.push(s.to);
            if (await exists(abs(sidecarOf(s.from)))) {
              await writeAtomic(abs(sidecarOf(s.to)), sidecarText(newUid()));
              sidecars.push(sidecarOf(s.to));
            }
          }
        } catch (err) {
          for (const c of sidecars) await rm(abs(c), { force: true });
          removing(written);
          for (const w of written) await rm(abs(w), { force: true });
          await learned(written, false);
          throw err;
        }
        await learned(written, false);
        return written;
      });
      return { ...answer(since), paths } satisfies CopyAnswer;
    }),

    'POST reveal': async (req, res, url) => {
      const since = sinceOf(url, catalog.seq);
      const body = await readJson(req);
      const path = await checkPath(root, body.path, READ_DIRS, { folder: true });
      const target = abs(path);
      const opening = body.open === true;
      const platform = options.platform ?? process.platform;
      const [command, args]: [string, string[]] =
        platform === 'darwin' ? ['open', opening ? [target] : ['-R', target]] : platform === 'win32' ? ['explorer', opening ? [target] : [`/select,${target}`]] : ['xdg-open', [opening ? target : dirname(target)]];
      const run = options.reveal ?? (async (b: string, a: readonly string[]) => void (await exec(b, a)));
      try {
        await run(command, args);
      } catch (err) {
        // Explorer answers 1 for a window it opened all the same.
        if (platform !== 'win32') throw new Refused(422, `${command} could not show ${path}: ${(err as Error).message}`);
      }
      sendJson(res, 200, answer(since));
    },

    // Rename the export (Docs/asset-ids.md §1 rule 8, §4): a source's record names the stem its export ships as, `"as"`.
    // `{ as }` writes it (null takes it out): into the source's own record (`<name>.export.json`) when another source of
    // its stem shares the stem's -- one made for it, the stem record's options copied, a new uid -- else into its record.
    // Its exports on disk move to the new name (a source alone; in a conflict the export there is the other's, and this
    // one's is made anew), and the repair pass runs on either side of the record's write, as a move's does: what named its
    // key follows. Answers what its undo needs: the record's text before (null: none), the exports moved, the exports to
    // be made anew (`made`, in a conflict), the files rewritten -- `{ restore }` puts them back, its source's export job
    // stopped and those made exports to the trash, so none is left behind or written after.
    'PUT export-as': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const path = await checkPath(root, q(url, 'path'), [ROOTS.source.dir]);
      const back = body.restore as { record?: unknown; text?: unknown; moved?: unknown; made?: unknown; texts?: unknown } | undefined;
      if (back === undefined && body.as !== null && asProblem(body.as) !== undefined) throw new Refused(422, `as ${asProblem(body.as)}`);
      const done = rewrites();
      let kept = new Set<string>();
      let record = '';
      let before: string | null = null;
      let moved: Array<[string, string]> = [];
      let made: string[] = [];
      let job: QueuedJobInfo | undefined;
      await serially(() => repairWindow(async () => {
        if (catalog.entries.get(path)?.role !== 'source') throw new Refused(422, `${path} is not a source: only a source names its export`);
        const found = recipeFor(path);
        if (!isFound(found)) throw new Refused(422, found.refused);
        if (back !== undefined) {
          // The undo: the exports moved back, the record as it was (or none), the rewritten files as they were.
          if (typeof back.record !== 'string' || (typeof back.text !== 'string' && back.text !== null) || !Array.isArray(back.moved)) throw new Refused(422, 'restore is { record, text, moved, texts }');
          record = await checkPath(root, back.record, [ROOTS.source.dir]);
          if (!isRecordName(baseName(record)) || dirName(record) !== dirName(path)) throw new Refused(422, `${record} is no record of ${baseName(path)}`);
          // The exports the doing set going (a conflict's): its job stopped, so none is written after; what it made, trashed.
          if (back.made !== undefined && (!Array.isArray(back.made) || back.made.some((m) => typeof m !== 'string'))) throw new Refused(422, 'restore.made is a list of paths');
          const gone: string[] = [];
          for (const m of (back.made ?? []) as string[]) {
            const p = await checkPath(root, m, WRITE_DIRS);
            writable(p);
            gone.push(p);
          }
          if (gone.length > 0) {
            await dropJobs([path]);
            const there: string[] = [];
            for (const p of gone) if (await exists(abs(p))) there.push(p);
            if (there.length > 0) {
              removing(there);
              const done = await remove(root, { paths: there, only: true });
              if ('refused' in done) throw new Refused(409, done.refused);
              await learned(done.removed, done.slot !== undefined);
            }
          }
          const pairs = (back.moved as unknown[]).map((m) => (Array.isArray(m) && typeof m[0] === 'string' && typeof m[1] === 'string' ? [m[0], m[1]] as [string, string] : null));
          for (const m of pairs) {
            if (m === null) throw new Refused(422, 'restore.moved is a list of [from, to]');
            const a = await checkPath(root, m[1], WRITE_DIRS);
            const b = await checkPath(root, m[0], WRITE_DIRS);
            if ((await exists(abs(a))) && !(await exists(abs(b)))) {
              await carryOut([{ from: a, to: b }], new Map(), []);
              moved.push([a, b]);
            }
          }
          before = await readFile(abs(record), 'utf8').catch(() => null);
          if (back.text === null) {
            if (before !== null) {
              removing([record]);
              await rm(abs(record));
            }
          } else {
            try {
              parseRecord(back.text as string);
            } catch (err) {
              throw new Refused(422, `${baseName(record)} is no record: ${(err as Error).message}`);
            }
            await writeOwn(record, back.text as string, before !== null);
          }
          await learned([record, path, ...moved.flat()], false);
          const texts = await restoreList(back.texts ?? []);
          kept = await editedSince(texts);
          for (const r of texts) {
            const was = await readFile(abs(r.path), 'utf8').catch(() => null);
            if (kept.has(r.path) || was === null || was === r.text) continue;
            done.befores.set(r.path, was);
            await writeOwn(r.path, r.text, true);
            done.afters.set(r.path, r.text);
          }
          if (done.befores.size > 0) await learned([...done.befores.keys()], false);
          return;
        }
        const as = body.as === null ? undefined : (body.as as string);
        const stem = splitName(baseName(path)).stem;
        const sharing = [...catalog.inFolder(dirName(path))].filter((p) => p !== path && catalog.entries.get(p)?.role === 'source' && splitName(baseName(p)).stem === stem);
        const own = joinPath(dirName(path), `${baseName(path)}.export.json`);
        record = sharing.length > 0 || (await exists(abs(own))) ? own : catalog.recordOf(path);
        writable(record);
        before = await readFile(abs(record), 'utf8').catch(() => null);
        let was: ExportRecord;
        if (before !== null) {
          try {
            was = parseRecord(before);
          } catch (err) {
            throw new Refused(409, `${baseName(record)} is no record (${(err as Error).message}): fix it in a text editor, or delete it`);
          }
        } else {
          // A record of its own, made: the stem record's options kept (nothing about the export changes but its name).
          const shared = await readFile(abs(recordPath(path)), 'utf8').catch(() => null);
          let options: Options = {};
          try {
            if (shared !== null) options = parseRecord(shared).options;
          } catch {
            options = {};
          }
          was = { uid: newUid(), options };
        }
        const oldAs = was.as;
        if ((oldAs ?? undefined) === as) throw new Refused(409, `${baseName(path)} ships as ${as ?? stem} already`);
        // The key it would ship as: none other may have it.
        const from = exportPaths(path, found.row.to, oldAs);
        const to = exportPaths(path, found.row.to, as);
        const wanted = exportKey(path, found.row.to, as);
        if (wanted !== undefined) {
          const mine = new Set([path, ...from]);
          for (const [p, e] of catalog.entries) {
            if (mine.has(p) || e.key === undefined || caseKey(e.key) !== caseKey(wanted)) continue;
            if (e.role === 'source' && catalog.entries.get(p)?.included === false) continue;
            throw new Refused(409, `${wanted} is ${baseName(p)}'s: name the export something else`, { taken: p });
          }
        }
        const next: ExportRecord = { ...was };
        if (as === undefined) delete next.as;
        else next.as = as;
        // The pass before the write, as a move's: a bare key naming its export now given its uid, while the index still
        // knows it by this name. Thrown, what it wrote goes back and nothing else is done.
        const only = refsTo(root, options.kinds ?? {}, [record]);
        try {
          await repairNow(done, new Map(), only);
        } catch (err) {
          for (const [p, t] of done.befores) await writeOwn(p, t, true).catch(() => undefined);
          throw err;
        }
        await writeOwn(record, recordText(next), before !== null);
        // A source alone: its exports go where its name is now, so nothing is made again. In a conflict the file there is the other's.
        if (sharing.length === 0) {
          const steps = from.map((f, i) => ({ from: f, to: to[i]! })).filter((m) => m.from !== m.to);
          const there: Step[] = [];
          for (const m of steps) if ((await exists(abs(m.from))) && !(await exists(abs(m.to)))) there.push(m);
          if (there.length > 0) await carryOut(there, new Map(), []);
          moved = there.map((m) => [m.from, m.to]);
        }
        await learned([record, path, ...moved.flat()], false);
        // What named its key follows by uid -- the record's uid is the export's.
        await repairNow(done, new Map(), { uids: new Set([...only.uids, ...refsTo(root, options.kinds ?? {}, [record]).uids]), slots: new Set() });
        if (done.befores.size > 0) await learned([...done.befores.keys()], false);
        if (sharing.length > 0) {
          made = to;
          job = autoExport(path);
        }
      }));
      return {
        ...answer(since),
        record,
        before,
        moved,
        ...(made.length > 0 ? { made } : {}),
        ...(done.befores.size > 0 ? { rewritten: rewrittenOf(done) } : {}),
        ...(kept.size > 0 ? { kept: [...kept] } : {}),
        ...(job ? { jobs: [job] } : {}),
      } satisfies ExportAsAnswer;
    }, 4 * 1024 * 1024),

    'PUT sidecar': json(async (url, body) => {
      const since = sinceOf(url, catalog.seq);
      const path = await checkPath(root, q(url, 'path'), [ROOTS.source.dir], { folder: true });
      const options = body.options;
      const include = body.include;
      if (options !== undefined && (typeof options !== 'object' || options === null || Array.isArray(options))) throw new Refused(422, 'options is an object of option names');
      if (include !== undefined && typeof include !== 'boolean') throw new Refused(422, 'include is true or false');
      if (options === undefined && include === undefined) throw new Refused(422, 'the body is { options }, { include }, or both');
      /** Where a source taken out of the build had its exports moved: what the tool's undo restores. */
      let slot: string | undefined;
      const jobs = await serially(async () => {
        const folder = await isFolder(path);
        if (folder === undefined) throw new Refused(404, `${path} is not there`);
        let file: string;
        const gone: string[] = [];
        if (!folder) {
          if (catalog.entries.get(path)?.role !== 'source') throw new Refused(422, `${path} is not a source: its options are its source's`);
          const found = recipeFor(path);
          if (!isFound(found)) throw new Refused(422, found.refused);
          file = catalog.recordOf(path);
          const existing = await readRecord(root, path, file);
          if (existing.problem) throw new Refused(409, `${existing.problem}: fix it in a text editor, or delete it`);
          let next: ExportRecord | undefined = existing.record;
          if (options !== undefined) {
            const problems = checkOptions(found.row.options ?? {}, options as Record<string, unknown>);
            if (problems.length > 0) throw new Refused(422, problems.join('; '));
            // Only what differs from the defaults, the folders' included (§3).
            const layers = await Promise.all(folderChain(path).map((d) => readFolderDefaults(root, d)));
            const base = resolveOptions(found.row, layers.map((l) => l.record?.options)).options;
            const kept: Options = {};
            for (const [k, v] of Object.entries(options as Options)) if (canonical(v) !== canonical(base[k])) kept[k] = v;
            next = { ...(next?.include === false ? { include: false as const } : {}), ...identity(next), options: kept, ...(next?.built ? { built: next.built } : {}) };
          }
          if (include !== undefined) {
            // One stem, one record: two sources of one stem share it, so the flag cannot take out one alone.
            const stem = splitName(baseName(path)).stem;
            const sharing = [...catalog.inFolder(dirName(path))].filter((p) => p !== path && catalog.entries.get(p)?.role === 'source' && splitName(baseName(p)).stem === stem);
            if (!include && sharing.length > 0) {
              throw new Refused(409, `${baseName(path)} shares ${baseName(file)} with ${sharing.map(baseName).join(', ')}: one of them goes out of the build by its name -- _${baseName(path)} -- or keep one`);
            }
            next = withInclude(next, include);
          }
          // Out of the build: what it ships goes to a slot of its own first, in this one call -- its job, if any, stopped.
          if (include === false && existing.record?.include !== false) {
            await dropJobs([path]);
            const shipped = catalog.entries.get(path)?.exports ?? [];
            removing(shipped);
            const done = await remove(root, { paths: shipped, only: true });
            if ('refused' in done) throw new Refused(409, done.refused);
            slot = done.slot;
            gone.push(...done.removed);
          }
          if (next !== undefined) await writeOwn(file, recordText(next), await exists(abs(file)));
          else if (await exists(abs(file))) {
            // Back in the build, and nothing else to say: the record an untick made goes with its flag.
            removing([file]);
            await rm(abs(file));
          }
        } else {
          if (include !== undefined) throw new Refused(422, `${path}: a folder has no tick of its own -- its files are in the build or not, each by its own`);
          if (options === undefined) throw new Refused(422, 'the body is { options }');
          const where = locate(joinPath(path, 'x'));
          if (where?.reference) throw new Refused(422, `${path}: nothing under reference/ is exported, so it has no options`);
          // Above the kinds' folders: their options share names, not meanings -- the tool's own words (`aboveKinds`).
          if (where?.kind === undefined) throw new Refused(422, `${path}: ${aboveKinds(path)}`);
          const problems = checkOptions(kindOptions(where.kind), options as Record<string, unknown>);
          if (problems.length > 0) throw new Refused(422, problems.join('; '));
          file = folderRecordPath(path);
          const there = await exists(abs(file));
          if (Object.keys(options).length === 0) {
            if (there) {
              removing([file]);
              await rm(abs(file));
            }
          } else await writeOwn(file, recordText({ options: options as Options }), there);
        }
        await learned([file, ...gone], slot !== undefined);
        // An option changed exports, with no waiting -- so does a source put back in the build: the server wrote it (§4, Auto-export).
        const out: QueuedJobInfo[] = [];
        for (const source of catalog.affected(file)) {
          const job = autoExport(source);
          if (job) out.push(job);
        }
        return out;
      });
      return { ...answer(since), jobs, ...(slot !== undefined ? { slot } : {}) } satisfies SidecarAnswer;
    }),
  };

  // ---------------------------------------------------------------- the server

  const calls: AssetsCalls = {
    root,
    kinds: options.kinds ?? {},
    catalog,
    async call(route, query, body = {}) {
      const work = (routes[route] as Route & { op?: Op }).op;
      if (!work) throw new Error(`${route} is no work to call`);
      await ready;
      const url = new URL(`http://localhost${PREFIX}${route.slice(route.indexOf(' ') + 1)}`);
      for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);
      return (await work(url, body)) as never;
    },
    async importFrom(from, query) {
      await ready;
      const url = new URL(`http://localhost${PREFIX}import`);
      for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);
      const fill = async (tmp: string): Promise<void> => {
        await mkdir(dirname(tmp), { recursive: true });
        await copyFile(from, tmp);
      };
      const done = await importing(url, fill, (o) => importAsScript(url, o, fill));
      return done!;
    },
    async thumb(path, size) {
      await ready;
      const found = await thumbOf(path, size);
      return 'file' in found ? { webp: new Uint8Array(await readFile(found.file)), hash: found.hash } : found;
    },
    onJob(listener) {
      jobListeners.add(listener);
      return () => void jobListeners.delete(listener);
    },
  };

  return {
    catalog,
    calls,
    runner,
    bridge,
    ready,

    async handle(req, res) {
      const url = new URL(req.url ?? '/', 'http://localhost');
      if (!url.pathname.startsWith(PREFIX)) return false;
      const route = url.pathname.slice(PREFIX.length);
      const method = req.method === 'HEAD' ? 'GET' : (req.method ?? 'GET');
      try {
        guardHost(req, hosts());
        const handler = routes[`${method} ${route}`];
        if (!handler) throw new Refused(404, `no ${method} ${route} here`);
        if (mutating(req)) guardWrite(req, port(), hosts());
        // Everything but the probe waits for the first walk.
        if (route !== 'tools' || method !== 'GET') await ready;
        await handler(req, res, url);
      } catch (err) {
        if (res.headersSent || res.destroyed) {
          if (!(err instanceof Refused)) onError(err as Error);
          res.destroy();
        } else if (err instanceof Refused) {
          await drain(req);
          sendJson(res, err.status, err.body);
        } else {
          onError(err as Error);
          sendJson(res, 500, { refused: (err as Error).message });
        }
      }
      return true;
    },

    watch(event, file) {
      if (closed) return;
      if (event !== 'add' && event !== 'change' && event !== 'unlink' && event !== 'addDir' && event !== 'unlinkDir') return;
      const path = rel(file);
      if (path === undefined) return;
      if ((event === 'unlink' || event === 'unlinkDir') && ownGone.has(path)) return;
      if (event === 'addDir' && ownDirs.has(path)) return;
      if (seenFiles && (event === 'add' || event === 'change')) {
        seenFiles.add(path);
        seenWake?.();
      }
      void catalog.onEvent(event, path);
    },

    connection(socket, req) {
      if (!isLoopback(req.socket.remoteAddress) || !trustedHost(authority(req), hosts())) return;
      tabs.add(socket);
      socket.on('close', () => {
        tabs.delete(socket);
        if (tabs.size === 0) browserIs('none');
      });
      browserIs('tab');
      // What waited for a tab, queued again; what a tab may still claim, asked of this one.
      for (const source of bridge.connected()) runner.add(source);
      for (const o of bridge.open()) {
        const message = asked.get(o.job);
        if (!o.claimed && message) socket.send(JSON.stringify({ type: 'custom', event: EVENT, data: { type: 'convert', convert: message } satisfies PushMessage }));
      }
    },

    async listening() {
      try {
        await ready;
      } catch {
        return;
      }
      const tools = lookTools(NEEDS)
        .then(() => catalog.settle())
        .finally(() => toolsLooked())
        .then(() => flushKept());
      const pruned = catalog.prune().then((count) => {
        if (count > 0) log(`[assets] ${count} file${count === 1 ? '' : 's'} older than 30 days removed from the trash`);
      });
      const hashed = catalog.settle().then(async () => {
        const keep = new Set<string>([...hashes.rows.values()].map((row) => row[2]));
        for (const e of catalog.entries.values()) if (e.hash !== undefined) keep.add(e.hash);
        await pruneCaches(root, keep);
        // The last attempts of sources no longer there: `runs.json` keeps only this tree's.
        if (runs.prune((source) => catalog.entries.has(source)) > 0) await runs.save();
        // And the hashes cache's rows of files no longer there: an import undone, a fixture removed.
        if (hashes.prune((path) => catalog.entries.has(path)) > 0) await hashes.save();
      });
      // A trace's instrumented copy, or a clean export's wrapped one, a crash left beside its script (Docs/modeler.md M34, M42): taken away.
      const swept = sweepCopies(join(root, ROOTS.source.dir)).then((left) => {
        if (left.length > 0) log(`[assets] ${left.length} script cop${left.length === 1 ? 'y' : 'ies'} a stopped server left (a build trace's, a clean export's) removed: ${left.join(', ')}`);
      });
      const warmed = uses.refresh();
      for (const result of await Promise.allSettled([tools, pruned, hashed, warmed, swept])) if (result.status === 'rejected') onError(result.reason as Error);
    },

    hotUpdate(file, type) {
      const path = rel(file);
      if (path === undefined) return 'vite';
      // A prefab or a material file that does not parse is kept from the page, said instead: the transform (`vite.ts`'
      // `prefabJson`) would throw at the page, and the last good one stays compiled (Docs/prefabs.md §7, Docs/render.md §4).
      const at = locate(path);
      const suffix = at?.kind === 'prefabs' ? PREFAB_SUFFIX : at?.kind === 'materials' ? MATERIAL_SUFFIX : null;
      if (at?.root === 'boot' && (at.kind === 'prefabs' || at.kind === 'materials') && suffix !== null && at.under?.endsWith(suffix) && !underscored(at.under)) {
        const kind = at.kind;
        const key = at.under.slice(0, -suffix.length);
        let text = '';
        try {
          text = type === 'delete' ? '{}' : readFileSync(file, 'utf8');
        } catch {
          text = '{}';
        }
        const problem = jsonProblem(text);
        push({ type: 'problem', problem: problem ? { kind, key, ...problem } : { kind, key, message: null } });
        if (problem) {
          // A new file refused never reached the glob: once it parses, the glob is what updates.
          if (type === 'create') unborn.add(`${kind}:${key}`);
          return 'none';
        }
        if (unborn.delete(`${kind}:${key}`)) return type === 'delete' ? 'none' : kind === 'prefabs' ? 'prefabGlob' : 'materialGlob';
      }
      // A file of a project's own kind (`vibe({ kinds })`): as a level, its glob file's own module accepts it --
      // an edit Vite's set, a file made or gone the glob file alone (`hotUpdateFor`'s `globsOnly`).
      if (ownKindFile(path)) return type === 'update' ? 'vite' : 'globs';
      const decision = hotUpdateFor(path, type, catalog.writes.get(path));
      if (decision.reload) push({ type: 'reload', reload: decision.reload });
      if (decision.beside) {
        // The models in that folder, by the index's folder list: never a walk of every entry.
        const folder = joinPath(ROOTS.boot.dir, KINDS.models.dir, decision.beside.folder);
        for (const p of catalog.inFolder(folder)) {
          const e = catalog.entries.get(p);
          if (!e || e.kind !== 'models' || e.key === undefined || (e.role !== 'export' && e.role !== 'loose')) continue;
          push({ type: 'reload', reload: { kind: 'models', key: e.key, url: devUrl(e.path), beside: decision.beside.image } });
        }
      }
      return !decision.pass ? 'none' : decision.globsOnly ? 'globs' : 'vite';
    },

    async pointer(id) {
      const at = id.indexOf('?');
      if (at < 0 || !id.slice(at + 1).split('&').includes('url')) return undefined;
      const path = rel(id.slice(0, at));
      if (path === undefined || !(under(path, ROOTS.boot.dir) || under(path, ROOTS.packs.dir))) return undefined;
      try {
        if (await peekPointer(abs(path))) return `${path} is a Git LFS pointer, not the file: run git lfs install && git lfs pull`;
      } catch {
        // Not there, or not readable: Vite's own load says so.
      }
      return undefined;
    },

    busy: () => runner.jobs().length > 0,
    idle: () => runner.idle(),
    repairing: () => repairHeld,

    async close() {
      // Closed (an in-process restart): the watcher's events are the next server's to read, never this one's too.
      closed = true;
      if (pushTimer !== undefined) clock.clearTimeout(pushTimer);
      for (const handle of [...ownGone.values(), ...ownDirs.values()]) clock.clearTimeout(handle);
      await Promise.allSettled([hashes.save(), runs.save()]);
    },
  };
}
