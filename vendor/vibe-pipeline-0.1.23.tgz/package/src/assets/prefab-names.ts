/**
 * Each prefab's shape, for the key types (Docs/prefabs.md §4): what
 * `P.node(name)` can find in the prefab compiled -- its own entities' `name`s
 * and those of every nested instance in it, after its `removed` and `name`
 * overrides -- and what each of those entities, and the root, is made of, so
 * `keys.ts` can write both into `keys.d.ts`: `Turret.node('muzle')` and
 * `init(e, Shield)` on an entity made without `Shield` are compile errors. And
 * the model each entity draws (`Render.model` in its `data` or an override's
 * `set`, after overrides), so `keys.d.ts` can hold every one to `AssetKeys.Model`: a typo
 * there is a compile error too -- and the material each wears (`Render.material`,
 * held to `AssetKeys.Material` the same way).
 *
 * The rules:
 *   - **The same answer as `compilePrefabs`** (`src/ecs/prefab.ts`), worked out
 *     from the files alone: a nested instance's nodes under its id, overrides
 *     applied after every entity is read, then only what is reachable from the
 *     root (a removed entity takes its subtree with it). An entity is made of
 *     its `components`, its `tags`, its `objects`' components, what overrides
 *     `add` less what they `remove`, and `Name` if it has a name.
 *     `prefab-names.test.ts` compares the two over nesting, a removal, renamed
 *     inner entities, added and removed components and the real files. It mirrors
 *     `flattenFile` there, and that test is all that holds them together: a change
 *     to one is a change to the other.
 *   - **Names only**: no component is looked up, so a file naming a component
 *     the game lacks still has its shape; the compile at boot says what is wrong.
 *   - **A problem is a line, not a throw**: a file that does not parse (passed in
 *     as its `Error`), a missing nested prefab, a cycle or a bad path leaves that
 *     key without names (`never`), and the generator prints the line.
 *
 * Pure and node-free, like `kinds.ts`; a model, a material and a nested prefab
 * are read as keys, lowercased (`caseKey`), as the compile reads them -- a
 * reference `{ uid, key }` (Docs/asset-ids.md §3) as the key its uid has now
 * (`resolve`, the pipeline's index: so a moved model's prefab typechecks before
 * the repair pass has rewritten its key), else its key as written.
 */
import { caseKey } from '@vibe/engine/case-key';

/** A node as far as names go: its id path in the file, its parent's, its name, whether it was removed, and its components' names. */
interface NameNode {
  path: string;
  parent: string | null;
  name: string | null;
  removed: boolean;
  components: Set<string>;
  /** Its `Render.model` as its key now, null for none. */
  view: string | null;
  /** Its `Render.material` as written, null for none (as authored). */
  material: string | null;
}

/** A file's entity, as far as names go. */
interface Entity {
  id?: unknown;
  parent?: unknown;
  prefab?: unknown;
  name?: unknown;
  overrides?: unknown;
  components?: unknown;
  tags?: unknown;
  objects?: unknown;
  data?: unknown;
  links?: unknown;
}
interface Override {
  at?: unknown;
  name?: unknown;
  removed?: unknown;
  add?: unknown;
  remove?: unknown;
  set?: unknown;
  parent?: unknown;
  links?: unknown;
}

/**
 * The keys each shape of a prefab file takes: `PREFAB_KEYS` of
 * `src/ecs/prefab.ts`, which this cannot import (pure, the pipeline's only).
 * `src/prefab-names.test.ts` holds the two tables, and `keyProblem`'s words,
 * equal: a key added there is added here.
 */
export const PREFAB_KEYS = {
  file: ['uid', 'is', 'version', 'pool', 'entities'],
  entity: ['id', 'parent', 'name', 'components', 'data', 'tags', 'objects', 'refs', 'links', 'layer', 'off'],
  nested: ['id', 'parent', 'prefab', 'overrides'],
  override: ['at', 'set', 'add', 'remove', 'off', 'on', 'layer', 'name', 'removed', 'links', 'refs', 'objects', 'parent'],
  link: ['relation', 'to', 'data'],
  linkOverride: ['relation', 'to', 'set'],
} as const;
export type KeyShape = keyof typeof PREFAB_KEYS;

/** How many single-letter edits turn `a` into `b` (for "did you mean"). */
function editDistance(a: string, b: string): number {
  let row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const next = [i];
    for (let j = 1; j <= b.length; j++) next.push(Math.min(row[j]! + 1, next[j - 1]! + 1, row[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1)));
    row = next;
  }
  return row[b.length]!;
}

/** What is wrong with `key` on a `shape` of the file, or null: the compile's `keyProblem`, word for word. */
export function keyProblem(shape: KeyShape, key: string): string | null {
  const allowed: readonly string[] = PREFAB_KEYS[shape];
  if (allowed.includes(key)) return null;
  const q = `"${key}"`;
  // The old form of Render (Docs/render.md §1), gone: no backwards compatibility (Docs/asset-ids.md).
  if (key === 'view' && (shape === 'entity' || shape === 'override' || shape === 'nested')) return `${q} is gone: a model is Render's -- ${shape === 'entity' ? '"data"' : 'an override\'s "set"'}: { "Render": { "model": … } }`;
  if (shape === 'nested') {
    const as = key === 'data' ? 'set' : key === 'components' || key === 'tags' ? 'add' : key;
    if ((PREFAB_KEYS.override as readonly string[]).includes(as) && as !== 'at') {
      return `${q} on a nested instance is an override${as === key ? '' : `'s "${as}"`} -- { "at": [], "${as}": … }`;
    }
  }
  if (shape === 'entity') {
    if (key === 'overrides') return `${q} go with "prefab", on a nested instance's line`;
    if (key === 'set' || key === 'add' || key === 'remove' || key === 'on' || key === 'removed' || key === 'at') return `${q} is an override's, in a nested instance's "overrides"`;
  }
  if (shape === 'override') {
    if (key === 'data') return `${q} in an override is "set"`;
    if (key === 'components' || key === 'tags') return `${q} in an override is "add"`;
    if (key === 'id' || key === 'prefab' || key === 'overrides') return `${q} belongs on the nested instance's own line, not in an override`;
  }
  if (shape === 'link' && key === 'set') return `a link's fields are its "data"`;
  if (shape === 'linkOverride' && key === 'data') return `a link override's fields are its "set"`;
  let near = '';
  let best = 3;
  for (const k of allowed) {
    const d = editDistance(key, k);
    if (d < best) [near, best] = [k, d];
  }
  return `no key ${q}${near ? ` (did you mean "${near}"?)` : ''}`;
}

/** Each key of `value` checked against `shape`'s; the first problem thrown, prefixed by `where`. */
function checkKeys(value: unknown, shape: KeyShape, where: string): void {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return;
  for (const k of Object.keys(value)) {
    const problem = keyProblem(shape, k);
    if (problem) throw new Error(`${where}: ${problem}`);
  }
}

/** The strings of a list in a file; anything else none (the compile says what is wrong). */
const strings = (list: unknown): string[] => (Array.isArray(list) ? list.filter((x): x is string => typeof x === 'string') : []);

/** What `init` takes on a prefab's entities: by name, the first in tree order with it, and `''` for the root. */
export type PrefabComponents = Map<string, string[]>;

/** A uid's key now, as the pipeline's index has it; undefined for one it does not know. */
export type UidResolve = (uid: string) => string | undefined;

/**
 * A reference's key now, as the compile's `resolveRef` reads it (Docs/asset-ids.md §1, rule 4): a bare key as it is;
 * a `{ uid, key }` the key its uid has now (its `#part` kept), else its key as written. Undefined for what is no
 * reference (the compile says what is wrong); `''` stays `''`.
 */
export function refKey(value: unknown, resolve: UidResolve = () => undefined): string | undefined {
  if (typeof value === 'string') return value;
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return undefined;
  const { uid, key } = value as { uid?: unknown; key?: unknown };
  if (typeof uid !== 'string' || typeof key !== 'string') return undefined;
  const now = resolve(uid);
  if (now === undefined) return key;
  const hash = key.indexOf('#');
  return now + (hash < 0 ? '' : key.slice(hash));
}

/** A `Render` key field's key in a `data` or a `set` (text, or `{ uid, key }`), or undefined where it gives none (`''` is none, null). */
const renderKeyOf = (data: unknown, field: 'model' | 'material', resolve: UidResolve): string | null | undefined => {
  const value = refKey((data as { Render?: Record<string, unknown> } | null | undefined)?.Render?.[field], resolve);
  if (value === undefined) return undefined;
  return value === '' ? null : caseKey(value);
};

/** A `Render.model` and a `Render.material` in `data` or `set`, as the compile sets them on the node. */
function looks(node: NameNode, data: unknown, resolve: UidResolve): void {
  const model = renderKeyOf(data, 'model', resolve);
  if (model !== undefined) node.view = model;
  const material = renderKeyOf(data, 'material', resolve);
  if (material !== undefined) node.material = material;
}

const pathText = (p: unknown, where: string): string => {
  if (typeof p === 'string') return p;
  if (Array.isArray(p) && p.every((x) => typeof x === 'string')) return p.join('/');
  throw new Error(`${where}: a parent that is neither an id nor a path of ids`);
};

/**
 * The names `P.node(name)` takes, by prefab key, sorted, what each named
 * entity and the root are made of (`components`, each list sorted), and the
 * model each entity draws by its path (`views`, `''` the root) and the material
 * it wears (`materials`); a key whose file (or a prefab it nests) has a problem
 * is left out of all four, and the problem is in `problems`. `resolve` reads a
 * reference's uid (the pipeline's index; none by default: each by its key).
 */
export function prefabNames(files: Readonly<Record<string, unknown>>, resolve: UidResolve = () => undefined): {
  names: Map<string, string[]>;
  components: Map<string, PrefabComponents>;
  views: Map<string, Map<string, string>>;
  materials: Map<string, Map<string, string>>;
  problems: string[];
} {
  const done = new Map<string, NameNode[]>();
  const doing: string[] = [];

  const flatten = (key: string, from: string): NameNode[] => {
    const had = done.get(key);
    if (had) return had;
    if (doing.includes(key)) throw new Error(`a cycle: ${[...doing.slice(doing.indexOf(key)), key].join(' -> ')}`);
    if (!Object.hasOwn(files, key)) throw new Error(`${from}: no prefab '${key}'`);
    const file = files[key];
    if (file instanceof Error) throw new Error(`${key}.prefab does not parse: ${file.message}`);
    const entities = (file as { entities?: unknown } | null)?.entities;
    if (!Array.isArray(entities) || entities.length === 0) throw new Error(`${key}: no "entities"`);
    checkKeys(file, 'file', key);
    doing.push(key);
    const nodes = new Map<string, NameNode>();
    const later: (() => void)[] = [];
    for (const ent of entities as Entity[]) {
      if (typeof ent?.id !== 'string' || ent.id === '') throw new Error(`${key}: an entity without an id`);
      const id = ent.id;
      if (id.includes('/')) throw new Error(`${key} at ${id}: an id with '/' in it, which joins the ids of a path`);
      const parent = ent.parent === null ? null : pathText(ent.parent, `${key} at ${id}`);
      checkKeys(ent, ent.prefab !== undefined ? 'nested' : 'entity', `${key} at ${id}`);
      for (const l of Array.isArray(ent.links) ? ent.links : []) checkKeys(l, 'link', `${key} at ${id}: a link`);
      const nests = ent.prefab === undefined ? undefined : refKey(ent.prefab, resolve);
      if (ent.prefab !== undefined && !nests) throw new Error(`${key} at ${id}: "prefab" is the nested prefab -- { "uid": …, "key": … }, or its key`);
      if (nests) {
        for (const n of flatten(caseKey(nests), `${key} at ${id}`)) {
          const path = n.path === '' ? id : `${id}/${n.path}`;
          nodes.set(path, { path, parent: n.path === '' ? parent : n.parent === '' ? id : `${id}/${n.parent}`, name: n.name, removed: false, components: new Set(n.components), view: n.view, material: n.material });
        }
        for (const o of (Array.isArray(ent.overrides) ? ent.overrides : []) as Override[]) {
          later.push(() => {
            if (!Array.isArray(o?.at)) throw new Error(`${key} at ${id}: an override without "at"`);
            const at = [id, ...(o.at as unknown[])].join('/');
            checkKeys(o, 'override', `${key} at ${at}`);
            for (const l of Array.isArray(o.links) ? o.links : []) checkKeys(l, 'linkOverride', `${key} at ${at}: a link override`);
            const node = nodes.get(at);
            if (!node) throw new Error(`${key} at ${at}: no such entity`);
            if (o.removed === true && at === id) throw new Error(`${key} at ${id}: the root of a nested instance cannot be removed`);
            if (o.removed === true) node.removed = true;
            if (typeof o.name === 'string') node.name = o.name;
            for (const c of strings(o.add)) node.components.add(c);
            for (const c of strings(o.remove)) node.components.delete(c);
            if (strings(o.remove).includes('Render')) node.view = node.material = null;
            looks(node, o.set, resolve);
            // Under another entity of the same instance: the tree changes, so does which of a name is first in it.
            if (Array.isArray(o.parent) && o.at.length > 0) node.parent = [id, ...(o.parent as unknown[])].join('/');
          });
        }
      } else {
        const objects = ent.objects && typeof ent.objects === 'object' && !Array.isArray(ent.objects) ? Object.keys(ent.objects) : [];
        const node: NameNode = { path: id, parent, name: typeof ent.name === 'string' ? ent.name : null, removed: false, components: new Set([...strings(ent.components), ...strings(ent.tags), ...objects]), view: null, material: null };
        looks(node, ent.data, resolve);
        nodes.set(id, node);
      }
    }
    for (const f of later) f();
    doing.pop();

    // Reachable from the root, as the compile's walk: a removed node and everything under it are gone.
    const root = [...nodes.values()][0]!;
    const kept: NameNode[] = [];
    const visit = (n: NameNode, depth: number): void => {
      if (depth > nodes.size) throw new Error(`${key} at ${n.path}: its parents go round in a loop`);
      kept.push(n);
      for (const c of nodes.values()) if (!c.removed && c.parent === n.path) visit(c, depth + 1);
    };
    visit(root, 0);
    // Paths relative to the prefab, as the compile's: the root is '' and its id leaves every other path.
    const top = root.path;
    const rel = (p: string): string => (p === top ? '' : p.startsWith(`${top}/`) ? p.slice(top.length + 1) : p);
    // A variant's own entity with an id its base has: one path for two entities, refused as the compile refuses it.
    for (const n of nodes.values()) {
      if (n.path.startsWith(`${top}/`) && nodes.has(rel(n.path))) {
        throw new Error(`the id '${rel(n.path)}' is also ${String(refKey((entities[0] as Entity).prefab, resolve))}'s '${rel(n.path)}': ids in a prefab are unique, what its root nests included`);
      }
    }
    const made = kept.map((n) => ({ path: rel(n.path), parent: n === root ? null : rel(n.parent!), name: n.name, removed: false, components: n.components, view: n.view, material: n.material }));
    done.set(key, made);
    return made;
  };

  const names = new Map<string, string[]>();
  const components = new Map<string, PrefabComponents>();
  const views = new Map<string, Map<string, string>>();
  const materials = new Map<string, Map<string, string>>();
  const problems: string[] = [];
  // What the compile makes an entity of: a named one has `Name` whatever its lists say.
  const madeOf = (n: NameNode): string[] => [...new Set([...n.components, ...(n.name === null ? [] : ['Name'])])].sort();
  for (const key of Object.keys(files).sort()) {
    try {
      const nodes = flatten(key, key);
      names.set(key, [...new Set(nodes.flatMap((n) => (n.name === null ? [] : [n.name])))].sort());
      const shape: PrefabComponents = new Map([['', madeOf(nodes[0]!)]]);
      for (const n of nodes) if (n.name && !shape.has(n.name)) shape.set(n.name, madeOf(n));
      components.set(key, shape);
      views.set(key, new Map(nodes.flatMap((n) => (n.view === null ? [] : [[n.path, n.view] as const]))));
      materials.set(key, new Map(nodes.flatMap((n) => (n.material === null ? [] : [[n.path, n.material] as const]))));
    } catch (e) {
      doing.length = 0;
      problems.push(`  ${key}: ${(e as Error).message}`);
    }
  }
  return { names, components, views, materials, problems };
}
