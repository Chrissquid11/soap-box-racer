/**
 * Gladius's words, read: the line of the script a Lua error names, and the
 * error without its place -- `runtime error: crate.lua:3: too big` is line 3,
 * `too big`. Pure, no node: the dev server's routes and the Model tab's banner
 * read them alike (Docs/modeler.md §3).
 */

/** `crate.lua:12:` in a message's first line -- at its front, or after `runtime error: ` and its like. */
const AT_LINE = /(?:^|\s)[^\s:]*\.lua:(\d+):\s*/;

/** The script line a Lua error's first line names, if it names one. */
export function luaLine(message: string): number | undefined {
  const m = AT_LINE.exec(message.split('\n')[0] ?? '');
  return m ? Number(m[1]) : undefined;
}

/** A message's first line without its place: `runtime error: b.lua:3: too big to build` is `too big to build`. */
export function bareWords(message: string): string {
  const first = message.split('\n')[0] ?? '';
  return first.replace(/^(?:[a-z ]*error:\s*)?[^\s:]*\.lua:\d+:\s*/i, '').trim() || first.trim();
}
