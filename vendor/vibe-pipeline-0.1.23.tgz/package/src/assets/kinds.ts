/**
 * What the game ships, and where: every kind of asset and every root, in one
 * table each (Docs/assets.md §2, §4).
 *
 *   KINDS   the registry's `Kind`s, plus the data kinds, `levels`, `prefabs`,
 *           `scenes` and `materials` (`DATA_KINDS`): each one's folder, key type,
 *           the extensions it ships as keys, the ones it ships beside them
 *           (a model's own images, an atlas's `.json`), and what a pack carries.
 *   ROOTS   `src/assets/` (the boot set), `packs/` and `AssetsSource/`.
 *   MIME    a content type per extension.
 *
 * **The extension lists exist here and nowhere else.** Vite needs literals in
 * `import.meta.glob`, so `keys.ts` writes them into `src/assets/globs.ts`,
 * `level-globs.ts`, `prefab-globs.ts`, `scene-globs.ts`, `material-globs.ts`
 * and `pack-kinds.ts`; the key types, the zipper and the recipes read this
 * table directly. A format goes on a list only once
 * `src/assets/store.ts` can decode it: `Assets.preload()` awaits every file, so
 * a key with no loader fails boot, not one asset.
 *
 * Pure: no `node:` import and no import at all, so the browser side of the
 * editor can share it.
 */

/** A kind's row. */
export interface KindDef {
  /** Its folder under a shipping root, and under `AssetsSource/`: `models`, `audio/sfx`. */
  readonly dir: string;
  /** Its key type in `AssetKeys` (`keys.d.ts`): what the accessor takes. */
  readonly type: string;
  /** The extensions that ship under it and are keys. */
  readonly ext: readonly string[];
  /** Extensions that ship under it but are not keys: a model's own images, an atlas's `.json`. */
  readonly beside?: readonly string[];
  /** Narrower than `ext` in a pack: a pack decodes from bytes with no base URL, so `.glb` only. */
  readonly packExt?: readonly string[];
  /** A pack can carry it. Icons and fonts are URLs handed to CSS, and a pack has bytes. */
  readonly inPacks?: boolean;
  /** It has a twin in `AssetsSource/`, where its sources live. A data kind does not: a level, a prefab or a scene is a loose file. */
  readonly source: boolean;
}

const AUDIO = ['ogg', 'm4a', 'mp3', 'wav', 'opus'] as const;
const IMAGES = ['ktx2', 'webp', 'png', 'jpg', 'jpeg', 'avif'] as const;

/**
 * The sound masters a page decodes for a waveform, past the formats that ship
 * (an audio kind's `ext`): what an `.ogg` is made from. One list for the
 * server, which sends their thumbnails to the page (`thumbs.ts`), and the
 * page's queue, which draws them (`packages/editor/src/assets/preview/thumbs.ts`).
 */
export const SOUND_MASTERS = ['flac', 'aif', 'aiff'] as const;

/** Where a picture's thumbnail comes from (§5, `GET thumb`): sharp, a step first, a browser, or nowhere. */
export type ThumbHow = 'sharp' | 'flatten' | 'kra' | 'browser' | 'none';

/** What sharp reads as it is. */
const THUMB_SHARP: readonly string[] = ['png', 'jpg', 'jpeg', 'webp', 'avif', 'gif', 'tif', 'tiff', 'svg'];
/** What only a page decodes: models (three's loaders), sounds (a waveform), and KTX2 (the GPU's formats). */
const THUMB_BROWSER: readonly string[] = ['glb', 'gltf', 'fbx', 'obj', 'dae', 'stl', ...AUDIO, ...SOUND_MASTERS, 'ktx2'];

/**
 * How a file with this (lowercase) extension gets its thumbnail: one rule for
 * the server, which makes or refuses it (`thumbs.ts`), and the Assets tool's
 * grid, which asks only for what can have one.
 */
export function thumbMaker(ext: string): ThumbHow {
  if (THUMB_SHARP.includes(ext)) return 'sharp';
  if (ext === 'psd' || ext === 'psb' || ext === 'xcf') return 'flatten';
  if (ext === 'kra') return 'kra';
  if (THUMB_BROWSER.includes(ext)) return 'browser';
  return 'none';
}

export const KINDS = {
  // `.gltf` must be self-contained in the boot set: a sibling `.bin` would not
  // survive hashing. The pipeline packs a `.gltf` source into a `.glb`.
  models: { dir: 'models', type: 'Model', ext: ['glb', 'gltf'], beside: IMAGES, packExt: ['glb'], inPacks: true, source: true },
  textures: { dir: 'textures', type: 'Texture', ext: IMAGES, inPacks: true, source: true },
  atlases: { dir: 'sprites', type: 'Atlas', ext: ['webp', 'png'], beside: ['json'], inPacks: true, source: true },
  icons: { dir: 'icons', type: 'Icon', ext: ['svg', 'webp', 'png'], source: true },
  // A font ships as a face (`.woff2` first) or, `.json`, a bitmap or MSDF font's glyph layout
  // beside its sheet -- a URL handed to the UI either way, as the old registry's glob took them.
  fonts: { dir: 'fonts', type: 'Font', ext: ['woff2', 'woff', 'ttf', 'otf', 'json'], source: true },
  sfx: { dir: 'audio/sfx', type: 'Sfx', ext: AUDIO, inPacks: true, source: true },
  uiSfx: { dir: 'audio/ui', type: 'UiSfx', ext: AUDIO, inPacks: true, source: true },
  music: { dir: 'audio/music', type: 'Music', ext: AUDIO, inPacks: true, source: true },
  // Read by the engine's `data.ts` and the engine's `prefabs.ts`, not the registry: data, not media. A prefab is
  // JSON named `.prefab`, so it is told apart from every other JSON file at a glance; Vite reads
  // it as JSON through `prefabJson` (`vite.ts`).
  levels: { dir: 'levels', type: 'Level', ext: ['json'], source: false },
  prefabs: { dir: 'prefabs', type: 'Prefab', ext: ['prefab'], source: false },
  // Read by the engine's `scenes.ts`: a scene is a world save (`world.save()`, as the editor's Save writes it), JSON
  // named `.scene` for the same reason, read as JSON by the same plugin.
  scenes: { dir: 'scenes', type: 'Scene', ext: ['scene'], source: false },
  // Read by the engine's `assets/materials.ts` (Docs/render.md §4): a material is JSON named `.material` -- its type,
  // its numbers, its maps as texture keys -- compiled after the preload into one shared three material. A pack may
  // carry them (`packs.ts` compiles a pack's once its textures are in); read as JSON by the same plugin.
  materials: { dir: 'materials', type: 'Material', ext: ['material'], inPacks: true, source: false },
} as const satisfies Record<string, KindDef>;

/**
 * A project's own kind (`vibe({ kinds })`, Docs/squidwright-implementation.md 1.11): a **data kind**, as
 * `levels` is -- JSON the game reads, bundled, parsed, keyed by its path under `dir` without the
 * extension; no twin in `AssetsSource/`, never in a pack or the registry. `keys.ts` writes its glob file
 * (`src/assets/<name>-globs.ts`), its key union (`AssetKeys.<type>`, and its row in `AssetKeys.DataKinds`)
 * and its hand-in in `bundle.ts`; the engine's `Assets.data(name, key)` reads it. `data: true` is the
 * only kind a project may add yet: a registry kind needs a loader on the engine's store, and is later.
 */
export interface ProjectKind {
  /** Its folder under `src/assets/`: `tilemaps`. */
  readonly dir: string;
  /** Its key type in `AssetKeys`: `Tilemap`. */
  readonly type: string;
  /** The extensions that are its keys, lowercase, without the dot: `['tilemap']`. Read as JSON whatever they are called. */
  readonly ext: readonly string[];
  /** A data kind. `false` is refused (`kindProblems`): no loader for one yet. */
  readonly data: boolean;
}

/** A project's kinds by name (`vibe({ kinds })`): the name is the glob file's (`<name>-globs.ts`) and `Assets.data`'s. */
export type ProjectKinds = Readonly<Record<string, ProjectKind>>;

/** A kind as the dev server lists it for the Assets panel (`GET kinds`): the table's rows and a project's, by name. */
export interface KindRow {
  name: string;
  dir: string;
  type: string;
  ext: readonly string[];
  /** It has a twin in `AssetsSource/`. */
  source: boolean;
  /** A project's own (`vibe({ kinds })`). */
  project: boolean;
}

/**
 * What is wrong with a project's kinds, one line each; none, they may be used. A name is a word of
 * lowercase letters and digits (it names a file and a constant); folder, type and extensions are
 * the table's own form, and none may be one a kind here has -- two kinds in one folder, or one key
 * type for two, would be two answers to one question.
 */
export function kindProblems(kinds: ProjectKinds): string[] {
  const problems: string[] = [];
  const engine = Object.entries(ENGINE_DATA_KINDS);
  const dirs = new Map<string, string>([...KIND_NAMES.map((k) => [KINDS[k].dir, k] as const), ...engine.map(([n, k]) => [k.dir, n] as const)]);
  const types = new Map<string, string>([...KIND_NAMES.map((k) => [KINDS[k].type, k] as const), ...engine.map(([n, k]) => [k.type, n] as const)]);
  for (const [name, kind] of Object.entries(kinds)) {
    const at = `vibe({ kinds }): '${name}'`;
    if (!/^[a-z][a-z0-9]*$/.test(name)) problems.push(`${at} is no kind's name: lowercase letters and digits, a letter first (it names src/assets/${name}-globs.ts)`);
    if ((KIND_NAMES as readonly string[]).includes(name) || name in ENGINE_DATA_KINDS) problems.push(`${at} is the engine's own kind`);
    // Its glob file exports the name in capitals, which `bundle.ts` imports beside its own.
    if (['globs', 'mime'].includes(name)) problems.push(`${at} is a name the generated bundle.ts uses itself`);
    if (kind.data !== true) {
      problems.push(`${at} is not a data kind (data: true): a project's kind is JSON the game reads, as levels are -- a kind decoded by a loader (a model, a sound) needs one on the engine's store, which a project cannot add yet`);
    }
    if (typeof kind.dir !== 'string' || !/^[a-z0-9]+(\/[a-z0-9]+)*$/.test(kind.dir)) problems.push(`${at}: its dir is a folder under src/assets/, lowercase with /: 'tilemaps'`);
    else if (dirs.has(kind.dir)) problems.push(`${at}: src/assets/${kind.dir}/ is ${dirs.get(kind.dir)}'s already`);
    else dirs.set(kind.dir, name);
    if (typeof kind.type !== 'string' || !/^[A-Z][A-Za-z0-9]*$/.test(kind.type)) problems.push(`${at}: its type is a key type's name, capitalised: 'Tilemap'`);
    else if (types.has(kind.type) || ['Pack', 'Kind', 'DataKinds'].includes(kind.type)) problems.push(`${at}: AssetKeys.${kind.type} is taken`);
    else types.set(kind.type, name);
    if (!Array.isArray(kind.ext) || kind.ext.length === 0 || !kind.ext.every((e) => typeof e === 'string' && /^[a-z0-9]+$/.test(e))) {
      problems.push(`${at}: its ext is a list of extensions, lowercase, without the dot: ['tilemap']`);
    }
  }
  return problems;
}

/**
 * The engine's own data kinds every project has, made as a project's own are (their glob file, key type, uids and
 * `Assets.data`): `physicsmaterials`, a physics material a `.physmat` file under `src/assets/physics-materials/`
 * (Docs/physics.md §4.3), read by the engine's physics stage through `data('physicsmaterials', key)`.
 */
export const ENGINE_DATA_KINDS: ProjectKinds = {
  physicsmaterials: { dir: 'physics-materials', type: 'PhysicsMaterial', ext: ['physmat'], data: true },
};

/** A project's kinds, checked -- thrown, every problem named, when `kindProblems` finds any -- with the engine's own data kinds first. */
export function checkKinds(kinds: ProjectKinds | undefined): ProjectKinds {
  const problems = kindProblems(kinds ?? {});
  if (problems.length > 0) throw new Error(problems.join('\n'));
  return { ...ENGINE_DATA_KINDS, ...(kinds ?? {}) };
}

/** Every kind as the Assets panel lists it: the table's, then a project's. */
export function kindRows(kinds: ProjectKinds = {}): KindRow[] {
  return [
    ...KIND_NAMES.map((name) => ({ name, dir: KINDS[name].dir, type: KINDS[name].type, ext: KINDS[name].ext, source: KINDS[name].source, project: false })),
    ...Object.entries(kinds).map(([name, kind]) => ({ name, dir: kind.dir, type: kind.type, ext: kind.ext, source: false, project: true })),
  ];
}

/**
 * A prefab file's ending, `.prefab` (JSON inside): what names one, its key the path
 * under `prefabs/` without it (`crates/big.prefab` is `crates/big`). A `.json` under
 * `prefabs/` is no prefab, nor a `.prefab` anywhere else -- both listed as problems.
 */
export const PREFAB_SUFFIX = `.${KINDS.prefabs.ext[0]}`;

/** A scene file's ending, `.scene` (a world save inside): its key the path under `scenes/` without it (`forest/camp.scene` is `forest/camp`). */
export const SCENE_SUFFIX = `.${KINDS.scenes.ext[0]}`;

/**
 * A material file's ending, `.material` (JSON inside): its key the path under `materials/` without it
 * (`props/rust.material` is `props/rust`). A `.json` under `materials/` is no material, and a `.material`
 * is one only under the boot set's `materials/` or a pack's -- anywhere else both are listed as problems,
 * as a stray prefab is (`paths.ts`' `strayMaterial`).
 */
export const MATERIAL_SUFFIX = `.${KINDS.materials.ext[0]}`;

/** Every kind, the registry's and the data kinds. */
export type KindName = keyof typeof KINDS;

/**
 * The data kinds: JSON the game reads, each through its own generated glob
 * (`level-globs.ts`, `prefab-globs.ts`, `scene-globs.ts`, `material-globs.ts`, handed to the engine's
 * `data.ts`, `prefabs.ts`, `scenes.ts` and `assets/materials.ts` by the generated bundles), bundled,
 * never in the registry or `AssetsSource/`. Of them only a material may ship in a pack as well (`inPacks`).
 */
export const DATA_KINDS = ['levels', 'prefabs', 'scenes', 'materials'] as const;
export type DataKind = (typeof DATA_KINDS)[number];
export const isDataKind = (kind: KindName): kind is DataKind => (DATA_KINDS as readonly KindName[]).includes(kind);

/** The registry's `Kind` (the engine's `assets/registry.ts`): every kind but the data kinds. */
export type Kind = Exclude<KindName, DataKind>;

export const KIND_NAMES = Object.keys(KINDS) as KindName[];

/** A kind's row, typed loosely enough to read every optional field. */
export function kindDef(kind: KindName): KindDef {
  return KINDS[kind];
}

/** Every extension a kind ships: its keys first, then what goes beside them. */
export function shipped(kind: KindName): readonly string[] {
  const def = kindDef(kind);
  return [...def.ext, ...(def.beside ?? [])];
}

/** Every extension a pack carries for a kind: what keys there, then what goes beside. */
export function packed(kind: KindName): readonly string[] {
  const def = kindDef(kind);
  return [...(def.packExt ?? def.ext), ...(def.beside ?? [])];
}

/**
 * The kind whose folder `rel` (a path under a root, with `/`) is in, and the
 * rest of the path under it. The longest `dir` wins (`audio/sfx` before a
 * hypothetical `audio`). Undefined for a path in no kind's folder.
 */
export function kindAt(rel: string): { kind: KindName; under: string } | undefined {
  let best: { kind: KindName; under: string } | undefined;
  let bestLength = -1;
  for (const kind of KIND_NAMES) {
    const dir = KINDS[kind].dir;
    if (rel.startsWith(dir + '/') && dir.length > bestLength) {
      best = { kind, under: rel.slice(dir.length + 1) };
      bestLength = dir.length;
    }
  }
  return best;
}

/**
 * A root's row (§2). `source` and `perName` only on a root that ships,
 * `reference` only on one that does not; `title`, on any, what the Assets tool
 * calls it -- a game's own root names itself; the three here have none, the
 * tool having its own words for them.
 */
export interface Root {
  dir: string;
  ships: boolean;
  title?: string;
  source?: string;
  perName?: boolean;
  reference?: string;
}

export const ROOTS = {
  boot: { dir: 'src/assets', ships: true, source: 'AssetsSource' },
  packs: { dir: 'packs', ships: true, source: 'AssetsSource/packs', perName: true },
  source: { dir: 'AssetsSource', ships: false, reference: 'AssetsSource/reference' },
} as const satisfies Record<string, Root>;

export type RootName = keyof typeof ROOTS;

export const ROOT_NAMES = Object.keys(ROOTS) as RootName[];

/** Where the trash is, under the project root. Not a root: the API reads it for restore (§6). */
export const TRASH = '.trash';

/** The pipeline's caches: deleting it costs time, never work (§4). */
export const CACHE = '.cache/assets';

/**
 * A request header for `GET thumb` (§5), `X-Assets-Miss: 200`: a miss -- not
 * hashed yet, made by a browser, none to be had -- is then answered `200` with
 * the same `ThumbMiss` as JSON (`application/json`) in place of `404`. A page
 * asking for a folder's thumbnails sends it, so the miss it expects, every
 * first one, is no red line in the browser's console. A hit is `image/webp`
 * either way. `GET run` takes it too: no run tried here is `200 { none: true }`.
 * Here, not in `api-types.ts`, which the page imports as types.
 */
export const THUMB_MISS_HEADER = 'x-assets-miss';

/**
 * The push channel's one event (`api-types.ts`' `PushEvent`): what the assets server and a project's routes send
 * on (`server.ws.send({ type: 'custom', event, data })`) and the page hears (`import.meta.hot.on(event, ...)`).
 * Here, not in `api-types.ts`, for the same reason as `THUMB_MISS_HEADER`: the page imports that one as types.
 */
export const PUSH_EVENT = 'vibebase:assets';

/** Content types by extension: shipped formats, and the sources the dev server serves. */
export const MIME: Readonly<Record<string, string>> = {
  glb: 'model/gltf-binary',
  gltf: 'model/gltf+json',
  bin: 'application/octet-stream',
  ktx2: 'image/ktx2',
  webp: 'image/webp',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  avif: 'image/avif',
  svg: 'image/svg+xml',
  gif: 'image/gif',
  tif: 'image/tiff',
  tiff: 'image/tiff',
  psd: 'image/vnd.adobe.photoshop',
  json: 'application/json',
  prefab: 'application/json',
  scene: 'application/json',
  material: 'application/json',
  woff2: 'font/woff2',
  woff: 'font/woff',
  ttf: 'font/ttf',
  otf: 'font/otf',
  ogg: 'audio/ogg',
  opus: 'audio/ogg',
  m4a: 'audio/mp4',
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
  flac: 'audio/flac',
  aif: 'audio/aiff',
  aiff: 'audio/aiff',
  lua: 'text/plain; charset=utf-8',
  obj: 'text/plain; charset=utf-8',
  mtl: 'text/plain; charset=utf-8',
  dae: 'model/vnd.collada+xml',
  stl: 'model/stl',
  md: 'text/markdown; charset=utf-8',
  txt: 'text/plain; charset=utf-8',
};
