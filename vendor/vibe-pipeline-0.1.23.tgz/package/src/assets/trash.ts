/**
 * The trash (Docs/assets.md §6): where the tool puts what it deletes, and
 * where an export keeps the one it replaced (§4, an export's step 5).
 *
 *   .trash/<slot>/<path as it was>      a slot a time, `2026-10-04T09-00-12Z`
 *   .trash/auto/<path as it was>        automatic exports: one previous export
 *
 * The rules it keeps:
 *
 * - **Nothing is ever destroyed by the tool.** A delete is a move into a new
 *   slot; an export keeps the file it replaces by a hard link (a copy where
 *   links are not possible), so the old one is there without being moved.
 *   Only `emptyTrash` and `prune` (30 days) remove anything for good. A
 *   folder deleted with nothing in it but names `ignored()` hides -- a tracked
 *   `.gitkeep`, a `.DS_Store` -- has those moved to the slot too, and a
 *   restore of the slot puts them back; a slot holding nothing else is not
 *   listed (`readTrash`), as the index lists no such file.
 * - **The auto slot keeps one previous export, not every one**: ten saves from
 *   Blender overwrite it ten times, and the one before the last is still there.
 *   Every other slot is written once.
 * - **A restore never overwrites.** Onto a taken name the whole family comes
 *   back as `-2` (then `-3`...), the smallest number free for every member in
 *   both roots; a part, which its source names inside itself, keeps its name --
 *   left where it is when the same content is already there, refused when other
 *   content is. With `replace`, what is in the way goes to a new slot first.
 *
 * What a family is (record, intermediate, exports, its own parts) is the
 * caller's knowledge -- the index's -- handed in as `familyOf` and `parts`.
 * Every path here is project-relative with `/`; `root` is the project root.
 * Nothing at module level: every read and write is inside a function.
 */
import { copyFile, cp, link, lstat, mkdir, readdir, rm, rmdir, stat, unlink } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import type { TrashSlot } from './api-types.ts';
import { code, exists, hashFile, moveFile } from './fs.ts';
import { TRASH } from './kinds.ts';
import { isSidecar, sidecarOf } from './uid.ts';
import { AUTO_SLOT, baseName, dirName, familyStem, ignored, isRecordName, joinPath, locate, norm, numbered, slotName, slotTime, trashPath, twin, validName } from './paths.ts';

/** Error codes on which a hard link is given up for a copy. */
const NO_LINK = new Set(['EXDEV', 'EPERM', 'ENOTSUP', 'EOPNOTSUPP', 'EMLINK', 'ENOSYS', 'EACCES']);

const DAY = 24 * 60 * 60 * 1000;

/** Do two files hold the same bytes? Sizes first, then the content's hash. */
async function sameContent(a: string, b: string): Promise<boolean> {
  const [sa, sb] = await Promise.all([stat(a), stat(b)]);
  if (!sa.isFile() || !sb.isFile() || sa.size !== sb.size) return false;
  const [ha, hb] = await Promise.all([hashFile(a), hashFile(b)]);
  return ha.sha1 === hb.sha1;
}

/** Empty folders removed from `abs` up to (not including) `stop`. */
async function pruneUp(abs: string, stop: string): Promise<void> {
  let dir = abs;
  while (dir.length > stop.length && dir.startsWith(stop)) {
    try {
      await rmdir(dir);
    } catch {
      return;
    }
    const up = dirname(dir);
    if (up === dir) return;
    dir = up;
  }
}

/** Every empty folder under `abs` removed, bottom-up; `abs` too when it ends up empty. */
async function pruneEmpty(abs: string): Promise<boolean> {
  let entries;
  try {
    entries = await readdir(abs, { withFileTypes: true });
  } catch {
    return false;
  }
  let left = 0;
  for (const entry of entries) {
    if (entry.isDirectory() && (await pruneEmpty(join(abs, entry.name)))) continue;
    left++;
  }
  if (left > 0) return false;
  try {
    await rmdir(abs);
    return true;
  } catch {
    return false;
  }
}

/**
 * Every file under `abs`, as paths relative to it with `/`, skipping what `ignored()` hides and a loose file's `.uid`
 * (it goes and comes with its file, never listed) -- unless `all`. None for a folder not there; one that cannot be
 * read throws, saying so.
 */
async function filesUnder(abs: string, rel = '', all = false): Promise<string[]> {
  let entries;
  try {
    entries = await readdir(abs, { withFileTypes: true });
  } catch (err) {
    if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') return [];
    throw err;
  }
  const out: string[] = [];
  for (const entry of entries) {
    if (!all && (ignored(entry.name) || (!entry.isDirectory() && isSidecar(entry.name)))) continue;
    const r = rel ? `${rel}/${entry.name}` : entry.name;
    if (entry.isDirectory()) out.push(...(await filesUnder(join(abs, entry.name), r, all)));
    else out.push(r);
  }
  return out.sort();
}

/**
 * A new slot, named for the time (`2026-10-04T09-00-12Z`), made unique with
 * `-2`, `-3` when one of that second exists; its folder is made.
 */
export async function newSlot(root: string, at?: Date): Promise<string> {
  const base = slotName(at ?? new Date());
  await mkdir(join(root, TRASH), { recursive: true });
  for (let n = 1; ; n++) {
    const slot = n === 1 ? base : `${base}-${n}`;
    try {
      await mkdir(join(root, TRASH, slot));
      return slot;
    } catch (err) {
      if (code(err) !== 'EEXIST') throw err;
    }
  }
}

/** A file this size or smaller is copied into the trash by `link`, not linked (below). */
export const COPY_MAX = 64 * 1024;

/**
 * Each path to `.trash/<slot>/<path>`. `move` renames it there; `link` keeps it
 * where it is too, by a hard link (a copy where linking fails, and for a file
 * of `COPY_MAX` or less: a record, a small export -- a program saving over the
 * live file in place edits every link to it), which is how an
 * export keeps the file it is about to replace. A path that does not exist is
 * skipped. In the auto slot whatever is there is overwritten; in any other an
 * existing destination is an error -- a slot is written once. Returns the trash
 * paths written.
 */
export async function toTrash(root: string, paths: readonly string[], slot: string, how: 'move' | 'link'): Promise<string[]> {
  const written: string[] = [];
  // A loose file's `.uid` (Docs/asset-ids.md §1) goes with it into a slot, and comes back with it (`restore`).
  const all = paths.map(norm);
  if (how === 'move') for (const p of [...all]) if (!isSidecar(p) && !all.includes(sidecarOf(p)) && (await exists(join(root, sidecarOf(p))))) all.push(sidecarOf(p));
  for (const path of all) {
    const from = join(root, path);
    let info;
    try {
      info = await lstat(from);
    } catch (err) {
      if (code(err) === 'ENOENT') continue;
      throw err;
    }
    const at = trashPath(slot, path);
    const to = join(root, at);
    if (await exists(to)) {
      if (slot !== AUTO_SLOT) throw new Error(`${at} is already in the trash: a slot is written once`);
      await rm(to, { recursive: true, force: true });
    }
    await mkdir(join(root, dirName(at)), { recursive: true });
    if (how === 'move') await moveFile(from, to);
    else if (info.isDirectory()) await cp(from, to, { recursive: true });
    // Small -- every record, most exports -- a copy: a program that saves in place (vim with two links, a
    // truncate-and-write editor) would edit the kept copy too, and a restore bring back the edit.
    else if (info.size <= COPY_MAX) await copyFile(from, to);
    else {
      try {
        await link(from, to);
      } catch (err) {
        if (!NO_LINK.has(code(err) ?? '')) throw err;
        await copyFile(from, to);
      }
    }
    written.push(at);
  }
  return written;
}

/** The folder a family is grouped by: a shipping root's folder seen from `AssetsSource/`. */
function familyFolder(dir: string): string {
  const where = locate(dir);
  if (where && (where.root === 'boot' || where.root === 'packs')) return twin(dir) ?? dir;
  return dir;
}

/** The paths a restored file must find free: its own, and the same name in its twin folder. */
function claims(path: string): string[] {
  const t = twin(dirName(path));
  return t === undefined ? [path] : [path, joinPath(t, baseName(path))];
}

/** One file a restore puts back: from the slot (absolute), to the project (relative), and whether it replaces a file there. */
export interface RestoreMove {
  from: string;
  to: string;
  replaced: boolean;
}

/**
 * Files back from a slot to where they were: `paths` as they were, every file
 * in the slot by default. Never over anything (above): a family whose name is
 * taken comes back numbered, a part whose name is taken by the same content is
 * left as it is (and leaves the slot), by other content the restore is refused
 * and nothing moves. With `replace`, whatever is at a destination goes to a new
 * slot first, answered as `slot`. `restored` lists the paths as written.
 *
 * `before` hears the plan once it is decided and before anything moves -- what
 * comes back, and what `replace` sends away -- so the dev server can expect
 * each write as its own (§4) before its watch event can come.
 */
export async function restore(
  root: string,
  slot: string,
  options: {
    paths?: readonly string[];
    replace?: boolean;
    parts?: readonly string[];
    at?: Date;
    before?: (moves: readonly RestoreMove[], displaced: readonly string[]) => void | Promise<void>;
  } = {},
): Promise<{ restored: string[]; slot?: string } | { refused: string }> {
  const slotDir = join(root, TRASH, slot);
  // A slot emptied in the Finder, or never made: an undo pointing at it must not "succeed" with nothing.
  if (!(await exists(slotDir))) return { refused: `no trash slot ${slot}` };
  const inSlot = await filesUnder(slotDir);
  const wanted = options.paths ? options.paths.map(norm) : inSlot;
  for (const p of wanted) if (!inSlot.includes(p)) return { refused: `${p} is not in the trash slot ${slot}` };
  const parts = new Set((options.parts ?? []).map(norm));

  /** [from the slot, to the project], decided before anything moves. */
  const plan: Array<[string, string]> = [];
  /** Parts already there with the same content: they only leave the slot. */
  const shared: string[] = [];
  /** What is in the way of a `replace`. */
  const displaced: string[] = [];

  if (options.replace) {
    for (const p of wanted) {
      plan.push([p, p]);
      if (await exists(join(root, p))) displaced.push(p);
    }
  } else {
    const families = new Map<string, string[]>();
    for (const p of wanted) {
      if (parts.has(p)) {
        if (await exists(join(root, p))) {
          if (await sameContent(join(slotDir, p), join(root, p))) shared.push(p);
          else return { refused: `${baseName(p)} exists with other content: restore with replace` };
        } else plan.push([p, p]);
        continue;
      }
      const key = `${familyFolder(dirName(p))}|${familyStem(baseName(p))}`;
      const list = families.get(key) ?? [];
      list.push(p);
      families.set(key, list);
    }
    for (const members of families.values()) {
      let n = 1;
      for (; n < 10000; n++) {
        let free = true;
        for (const m of members) {
          const to = numbered(m, n);
          if (n > 1 && !isRecordName(baseName(to))) {
            const check = validName(baseName(to));
            if (!('ok' in check)) return { refused: `${baseName(m)} cannot come back numbered (${check.refused}): restore with replace, or rename what is there` };
          }
          for (const c of claims(to)) {
            if (await exists(join(root, c))) {
              free = false;
              break;
            }
          }
          if (!free) break;
        }
        if (free) break;
      }
      for (const m of members) plan.push([m, numbered(m, n)]);
    }
  }

  if (options.before) {
    const taken = new Set(displaced);
    await options.before(
      plan.map(([from, to]) => ({ from: join(slotDir, from), to, replaced: taken.has(to) })),
      displaced,
    );
  }
  let newSlotName: string | undefined;
  if (displaced.length > 0) {
    newSlotName = await newSlot(root, options.at);
    await toTrash(root, displaced, newSlotName, 'move');
  }
  const restored: string[] = [];
  for (const [from, to] of plan) {
    await moveFile(join(slotDir, from), join(root, to));
    // Its `.uid` back with it, at its name now (never over one there).
    if ((await exists(join(slotDir, sidecarOf(from)))) && !(await exists(join(root, sidecarOf(to))))) await moveFile(join(slotDir, sidecarOf(from)), join(root, sidecarOf(to)));
    await pruneUp(join(slotDir, dirName(from)), slotDir);
    restored.push(to);
  }
  for (const p of shared) {
    await unlink(join(slotDir, p));
    await pruneUp(join(slotDir, dirName(p)), slotDir);
  }
  // The whole slot: what a folder's delete put there that is never listed (its `.gitkeep`) goes back too,
  // as it was -- never numbered, never over anything: one whose place is taken stays in the slot.
  if (!options.paths) {
    for (const p of (await filesUnder(slotDir, '', true)).filter((f) => f.split('/').some(ignored))) {
      if (await exists(join(root, p))) continue;
      await moveFile(join(slotDir, p), join(root, p));
      await pruneUp(join(slotDir, dirName(p)), slotDir);
    }
  }
  await pruneEmpty(slotDir);
  return newSlotName === undefined ? { restored } : { restored, slot: newSlotName };
}

/** What is in this folder but for what `ignored()` hides (a `.DS_Store`, a `.gitkeep`): its hidden files' names, or null when anything else is -- a folder, a file the index lists. */
async function emptyFolder(abs: string): Promise<string[] | null> {
  const entries = await readdir(abs, { withFileTypes: true });
  return entries.every((e) => !e.isDirectory() && ignored(e.name)) ? entries.map((e) => e.name) : null;
}

/**
 * Delete: files to a new slot with their families (`familyOf`, unless `only`);
 * a folder with nothing in it removed, what it held that `ignored()` hides --
 * a tracked `.gitkeep` -- to the slot (never destroyed); a folder with
 * anything else in it refused, before anything moves. Answers the slot, if
 * one was used, and the paths removed.
 */
export async function remove(
  root: string,
  request: { paths: readonly string[]; only?: boolean; familyOf?: (path: string) => readonly string[] },
  at?: Date,
): Promise<{ slot?: string; removed: string[] } | { refused: string }> {
  const folders: string[] = [];
  const files: string[] = [];
  /** A folder's hidden files: to the slot with it. */
  const kept: string[] = [];
  for (const raw of request.paths) {
    const path = norm(raw);
    let info;
    try {
      info = await lstat(join(root, path));
    } catch (err) {
      if (code(err) === 'ENOENT') continue;
      throw err;
    }
    if (info.isDirectory()) {
      const hidden = await emptyFolder(join(root, path));
      if (hidden === null) return { refused: `${path} is not empty` };
      folders.push(path);
      for (const name of hidden) kept.push(joinPath(path, name));
      continue;
    }
    const family = request.only || !request.familyOf ? [path] : [path, ...request.familyOf(path).map(norm)];
    for (const f of family) if (!files.includes(f)) files.push(f);
  }
  const present: string[] = [];
  for (const f of files) if (await exists(join(root, f))) present.push(f);
  const removed: string[] = [];
  const slot = present.length > 0 || kept.length > 0 ? await newSlot(root, at) : undefined;
  if (slot !== undefined) await toTrash(root, [...present, ...kept], slot, 'move');
  for (const f of folders) {
    await rm(join(root, f), { recursive: true, force: true });
    removed.push(f);
  }
  removed.push(...present);
  return slot === undefined ? { removed } : { slot, removed };
}

/**
 * Every slot as the disk has it -- the index's Trash root, read again after
 * each of the server's own writes there, never kept by the watcher. Newest
 * slot first, the auto slot last.
 */
export async function readTrash(root: string): Promise<TrashSlot[]> {
  let entries;
  try {
    entries = await readdir(join(root, TRASH), { withFileTypes: true });
  } catch {
    return [];
  }
  const out: TrashSlot[] = [];
  for (const entry of entries) {
    if (!entry.isDirectory() || ignored(entry.name)) continue;
    const dir = join(root, TRASH, entry.name);
    const files = [];
    for (const path of await filesUnder(dir)) {
      const info = await stat(join(dir, path));
      files.push({ path, size: info.size, mtime: info.mtimeMs });
    }
    // Only a folder's hidden files (its `.gitkeep`): nothing the tool lists -- its step's undo brings them back.
    if (files.length === 0 && (await filesUnder(dir, '', true)).length > 0) continue;
    out.push({ slot: entry.name, files });
  }
  const rank = (slot: string): number => (slot === AUTO_SLOT ? 2 : slotTime(slot) ? 0 : 1);
  return out.sort((a, b) => rank(a.slot) - rank(b.slot) || (a.slot < b.slot ? 1 : a.slot > b.slot ? -1 : 0));
}

/** The trash emptied, for good. */
export async function emptyTrash(root: string): Promise<void> {
  await rm(join(root, TRASH), { recursive: true, force: true });
}

/**
 * Slots older than `days` (30) removed for good, and in the auto slot each file
 * older than that -- by the later of its mtime and its ctime, since a hard link
 * keeps the export's own mtime but sets the ctime to when it arrived. Returns
 * how many files went, for the Trash root's line.
 */
export async function prune(root: string, options: { days?: number; now?: Date } = {}): Promise<number> {
  const cutoff = (options.now ?? new Date()).getTime() - (options.days ?? 30) * DAY;
  let entries;
  try {
    entries = await readdir(join(root, TRASH), { withFileTypes: true });
  } catch {
    return 0;
  }
  let count = 0;
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const dir = join(root, TRASH, entry.name);
    if (entry.name === AUTO_SLOT) {
      for (const path of await filesUnder(dir)) {
        const info = await stat(join(dir, path));
        if (Math.max(info.mtimeMs, info.ctimeMs) < cutoff) {
          await unlink(join(dir, path));
          count++;
        }
      }
      await pruneEmpty(dir);
      continue;
    }
    const time = slotTime(entry.name);
    if (!time || time.getTime() >= cutoff) continue;
    count += (await filesUnder(dir)).length;
    await rm(dir, { recursive: true, force: true });
  }
  return count;
}
