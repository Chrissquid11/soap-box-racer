/**
 * Thumbnails made where the decoder is (Docs/assets.md §5 `GET thumb`, §7):
 * here, the pictures sharp reads, and through the pipeline's own steps the
 * layered ones -- a `.psd` or `.xcf` by `flatten` (ImageMagick), a `.kra` by its
 * own `mergedimage.png`; in the browser, a model, a sound and a KTX2, whose
 * decoders are three's and the page's (`404 { make: 'browser', hash }`, then
 * `PUT thumb`). Each is a WebP at 64, 128 or 256 on its longer side, never
 * scaled up (but an SVG, which has no pixels to lose), cached under the hash
 * of the content it shows and the rule it was drawn by:
 * `.cache/assets/thumbs/<sha1>-<size>-v<THUMBS_VERSION>.webp`, so a rename, a
 * move, a branch switch or a pull costs nothing, and two copies share one.
 *
 * **`THUMBS_VERSION` is the rule's**: bumped when what a thumbnail is drawn
 * from or how changes -- here, or in the page (`renderer.ts`' `capture`,
 * `scratch.ts`' decode, `waveform.ts`' strip). Every thumbnail made under the
 * last rule is then a miss, made again and posted over, and its file the
 * prune's at once. Version 2: a one-mip KTX2 drawn at level 0, not empty; a
 * model drawn once its own textures are in, not black (the phase-3 review's).
 *
 * And the caches' prune (§4, Caches): a stat or thumbnail no current file
 * hashes to, and not read for 30 days -- a read touches its mtime -- is removed
 * once the server is listening, with the trash; a thumbnail of an older rule
 * whatever it shows.
 *
 * `PUT thumb` files a page's thumbnail under any 40-hex hash it names, on
 * purpose: a `.trash/` file has no entry to check it against, and the hash is
 * of the content the page rendered, not of what is at a path by the time it
 * arrives -- over what is there, if anything. It is loopback-only and 1 MB at
 * most, and one no file hashes to is the prune's above.
 *
 * sharp is imported inside the function that uses it, so a build never loads
 * it. Nothing at module level.
 */
import { mkdir, mkdtemp, readdir, rm, stat, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import type { ToolLook } from './api-types.ts';
import { CACHE, thumbMaker, type ThumbHow } from './kinds.ts';
import { extOf } from './paths.ts';
import { step as flatten } from './steps/flatten.ts';
import { readZipEntry } from './zip.ts';

/** The sizes a thumbnail is made at. */
export const THUMB_SIZES: readonly number[] = [64, 128, 256];

export type { ThumbHow } from './kinds.ts';

/** How `path`'s thumbnail is made: `kinds.ts`'s `thumbMaker`, the one rule the tool's grid reads too. */
export function thumbHow(path: string): ThumbHow {
  return thumbMaker(extOf(path));
}

/** The rule thumbnails are drawn by: a thumbnail of another is never served, and goes with the next prune. */
export const THUMBS_VERSION = 2;

/** `.cache/assets/thumbs/<sha1>-<size>-v<THUMBS_VERSION>.webp`, absolute. */
export function thumbFile(root: string, hash: string, size: number): string {
  return join(root, CACHE, 'thumbs', `${hash}-${size}-v${THUMBS_VERSION}.webp`);
}

/** A thumbnail's `ETag`: its hash, its size and the rule -- one made again by a new rule is not the browser's cached one. */
export function thumbTag(hash: string, size: number): string {
  return `"${hash}-${size}-v${THUMBS_VERSION}"`;
}

/** `.cache/assets/stats/<sha1>.json`, absolute. */
export function statsFile(root: string, hash: string): string {
  return join(root, CACHE, 'stats', `${hash}.json`);
}

/**
 * A thumbnail of the file at `abs` (project-relative `path`), `size` on its
 * longer side, as WebP bytes. `tools` and `bin` are the server's look: a
 * layered file needs `magick`, found as every tool is (§3, Tools).
 */
export async function makeThumb(root: string, path: string, abs: string, size: number, tools: ReadonlyMap<string, ToolLook>, bin: (tool: string) => string): Promise<Buffer> {
  const sharp = (await import('sharp')).default;
  const ext = extOf(path);
  const how = thumbHow(path);
  const shrink = (input: string | Buffer): Promise<Buffer> =>
    sharp(input, { failOn: 'none' })
      .rotate()
      .resize(size, size, { fit: 'inside', withoutEnlargement: ext !== 'svg' })
      .webp({ quality: 80 })
      .toBuffer();
  if (how === 'sharp') return shrink(abs);
  if (how === 'kra') return shrink(await readZipEntry(abs, 'mergedimage.png'));
  if (how === 'flatten') {
    const magick = tools.get('magick');
    if (!magick || magick.state !== 'found') throw new Error(`needs magick${magick?.hint ? `: ${magick.hint}` : ''}`);
    await mkdir(join(root, CACHE, 'tmp'), { recursive: true });
    const dir = await mkdtemp(join(root, CACHE, 'tmp', 'thumb-'));
    try {
      const stem = path.slice(path.lastIndexOf('/') + 1).replace(/\.[^.]+$/, '');
      const flat = await flatten.run({ id: 'thumb', root, source: path, input: abs, parts: [], dir, stem, ext, kind: 'textures', options: {}, tools, bin, log: () => {} });
      return await shrink(flat.files[0]!);
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  }
  throw new Error(`no thumbnail is made here for .${ext}`);
}

/**
 * Stats and thumbnails no hash in `keep` names, and not read for `days` (30):
 * removed -- and a thumbnail of an older rule (`THUMBS_VERSION`), whatever it
 * shows and however lately read: it is never served again. A read touches the
 * file's mtime, so the mtime is when it was last read. Answers how many went.
 */
export async function pruneCaches(root: string, keep: ReadonlySet<string>, options: { days?: number; now?: number } = {}): Promise<number> {
  const cutoff = (options.now ?? Date.now()) - (options.days ?? 30) * 24 * 60 * 60 * 1000;
  let count = 0;
  for (const folder of ['stats', 'thumbs']) {
    const dir = join(root, CACHE, folder);
    let names: string[];
    try {
      names = await readdir(dir);
    } catch {
      continue;
    }
    for (const name of names) {
      const hash = /^([0-9a-f]{40})[-.]/.exec(name)?.[1];
      if (hash === undefined) continue;
      const older = folder === 'thumbs' && !name.endsWith(`-v${THUMBS_VERSION}.webp`);
      if (!older && keep.has(hash)) continue;
      try {
        if (!older && (await stat(join(dir, name))).mtimeMs >= cutoff) continue;
        await unlink(join(dir, name));
        count++;
      } catch {
        // Gone already, or not ours to remove: the next prune looks again.
      }
    }
  }
  return count;
}
