/**
 * The shapes the pipeline, the dev server and the editor's Assets tool share
 * (Docs/assets.md §2-§6): an index entry, a record, a tool's look, a job
 * message, a diff, the tree, a file's stats; the push channel's messages and
 * what each call of the dev server's API (§5, under `/__assets/`) answers.
 * Types only.
 *
 * The contract, whole: some of it is read only by the dev server and the tool
 * (phases 2 and 3) -- a folder's defaults, `reload`, the job states a server
 * sends -- and is here so the two sides are written against one file.
 *
 * Pure: it imports nothing but the other pure modules' types, so the browser
 * side can import it too.
 */
import type { KindName, KindRow, PUSH_EVENT, RootName } from './kinds.ts';
import type { StudioMessage } from '../studio/api-types.ts';

/** What a path is (§2, "What every path is"). */
export type Role = 'source' | 'part' | 'intermediate' | 'record' | 'export' | 'loose' | 'reference' | 'extra';

/**
 * A source's status (§2). `checking` until it is hashed and the tools looked
 * for. `excluded`: out of the build -- its record says `"include": false` --
 * so never exported, never stale, in no conflict.
 */
export type Status = 'current' | 'stale' | 'missing' | 'unmade' | 'failed' | 'conflict' | 'reference' | 'excluded' | 'checking';

/** One file in the index (§4). `key` is spelled as `Assets` spells it: `props/crate`, `reef:props/crate`. */
export interface Entry {
  path: string;
  root: RootName;
  role: Role;
  kind?: KindName;
  key?: string;
  size: number;
  mtime: number;
  /** sha1 of the content, once read. */
  hash?: string;
  /** A source's status. */
  status?: Status;
  /** One line: why the status is not `current`, or what an extra is. */
  reason?: string;
  /** One line said about a `current` source: "built with ffmpeg 7.1; 8.1 here". */
  note?: string;
  /** A source's exports, the keyed one first (`exportPaths(…)[0]`, whose key is `exportKey`): what a preview of a current source shows. */
  exports?: string[];
  /** An export's, a record's or an intermediate's source. */
  source?: string;
  /** A source's parts. */
  parts?: string[];
  /** A part's sources. */
  owners?: string[];
  /** An unfetched Git LFS pointer. */
  pointer?: boolean;
  /**
   * In the build (§2, "In the build"): a source unless its record says
   * `"include": false`; a part if one of its owners is; an export, a record
   * and an intermediate as their source is; a loose file always. False for
   * what never ships whatever is ticked -- a reference, an extra, a name
   * starting with `_` (which the tick takes off again where that would ship).
   */
  included: boolean;
}

/** An option's value: what a schema's `type` describes. */
export type OptionValue = number | boolean | string | Readonly<Record<string, string>>;

/** Options by name. */
export type Options = Record<string, OptionValue>;

/** One option's schema (§3, Options): what the tool draws a field from and the API checks an override against. */
export interface OptionSchema {
  readonly default: OptionValue;
  readonly type: 'number' | 'boolean' | 'enum' | 'map';
  readonly values?: readonly string[];
  readonly min?: number;
  readonly max?: number;
  readonly step?: number;
  readonly unit?: string;
  /** One line for the tool. */
  readonly help: string;
  /** At its default it does nothing: left out of the recipe hash there, so adding it stales no export (`recipes.ts`' `hashedOptions`). */
  readonly inert?: boolean;
  /**
   * It applies only while another option is one of `values` (a cull method's knob): otherwise it does nothing --
   * left out of the recipe hash and dimmed in the Options block, its value kept for when it applies again.
   */
  readonly when?: { readonly option: string; readonly values: readonly string[] };
}

/** The pipeline's half of a record: what was built, from what, with what (§3). Never edited by hand. */
export interface Built {
  /** sha1 of the source. */
  source: string;
  /** sha1 of the recipe: the resolved row, its steps' versions, the tools' versions (§2). */
  recipe: string;
  /** The extensions written, the keyed one first. */
  to: string[];
  /** When, ISO, to the second. */
  at: string;
  /** sha1 of every part and the intermediate, by path relative to the source's folder. */
  deps?: Record<string, string>;
  /** The version of every tool used: npm packages, PATH tools, `three` for a browser conversion. */
  tools: Record<string, string>;
  /**
   * sha1 of every file written, by its extension in `to` (`{ "glb": "..." }`): what `--check` and the
   * status hold the shipped files to -- an LFS pointer, junk, or an edit by hand is not what was built.
   * By extension, not path, so a record moved with its source still holds. Absent in a record written
   * before it was (not yet hashed: nothing to hold the files to, never stale for it); the next export
   * writes it.
   */
  out?: Record<string, string>;
}

/** `<stem>.export.json`, beside every exported source. */
export interface ExportRecord {
  /** Out of the build (§3): its source is never exported. Absent means in -- `true` is never written. */
  include?: false;
  /** The asset's uid (Docs/asset-ids.md §1): stamped by the pipeline -- the export's first record, or `vibe assets` -- never changed. */
  uid?: string;
  /** The stem its export ships as (Docs/asset-ids.md §1, rule 8): `crate.blend` with `"as": "crate-hi"` ships `crate-hi.glb`, the key `props/crate-hi`. */
  as?: string;
  options: Options;
  built?: Built;
  /** Keys this pipeline does not know (a newer one wrote them): kept, written back after the rest. */
  more?: Record<string, unknown>;
}

/** A folder's `export.json`: defaults for every source under it. */
export interface FolderDefaults {
  options: Options;
}

/** A write of the server's own, which the index does not take for news (§4). */
export interface Expected {
  mtimeMs: number;
  size: number;
  /** The write replaces a file there: an export over the last one, an import with `replace`. */
  replaced: boolean;
}

/** A watch event, as Vite's `hotUpdate` spells it. */
export type WatchType = 'create' | 'update' | 'delete';

/** `reload` on the push channel (§5): an export changed under `src/assets/`. */
export interface HotReload {
  kind: KindName;
  key: string;
  /** The unhashed dev-server URL: the same address serves the new bytes. */
  url: string;
}

/** An image under `models/` changed: one `reload` per model export in `folder`, with `beside: image`. */
export interface BesideReload {
  kind: 'models';
  /** The folder under `models/`, `''` at its top. */
  folder: string;
  /** The image's path under `models/`. */
  image: string;
  url: string;
}

/**
 * What `hotUpdate` does with a watch event (§5's table): `pass` false is `[]`,
 * true Vite's set -- less the file's own modules with `globsOnly`, for a file a
 * glob takes created or removed: the generated glob file is what updates, and
 * the file's own `?url` node, stale, would be a dead end to Vite.
 */
export interface HotDecision {
  pass: boolean;
  globsOnly?: true;
  reload?: HotReload;
  beside?: BesideReload;
}

/** How a look for a tool ended (§3, Tools). */
export type ToolState = 'found' | 'missing' | 'lacking';

export interface ToolLook {
  tool: string;
  state: ToolState;
  /** What was run, as handed to `spawn`. */
  path?: string;
  version?: string;
  /** The line a `require` check read: which ffmpeg, and what it lacks. */
  line?: string;
  /** What to do about it, for this platform. */
  hint?: string;
  /** Why it is missing: "did not answer in 10 s". */
  why?: string;
  /**
   * The path set for it (Config ▸ Tools, `assets.local.json`) when that did not
   * run and another candidate was looked at in its place -- the PATH's, an
   * app's: what it is and why, so the person who set it is told, not left to
   * find their path quietly passed over.
   */
  passedOver?: { path: string; why: string };
}

/**
 * The index's changes over (`from`, `seq`] (§5, `changed`), and the Trash's
 * slots, whole, when `.trash/` was re-read within them -- replacing the
 * client's copy.
 */
export interface Diff {
  from: number;
  seq: number;
  added: Entry[];
  removed: string[];
  updated: Entry[];
  trash?: TrashSlot[];
}

/** `GET tree`'s answer, and `since`'s for a client further behind than the diffs kept: the whole index and the Trash. */
export interface TreeAnswer {
  seq: number;
  tree: Entry[];
  trash: TrashSlot[];
  /** What the 30-day prune removed when the server started, for the Trash root's line (§6). */
  pruned?: { count: number; at: string };
}

/**
 * A job's state on the push channel. `dropped`: its source was deleted while
 * it waited or ran (part two §10). `skipped`: its source was current when its
 * turn came -- a job ahead of it made the export -- so it did nothing, which is
 * no failure.
 */
export type JobState = 'queued' | 'running' | 'parked' | 'done' | 'failed' | 'unmade' | 'dropped' | 'skipped';

/** `job` on the push channel: which step of how many, done, failed with its output. */
export interface JobMessage {
  id: string;
  source: string;
  step: number;
  of: number;
  state: JobState;
  error?: string;
  ms?: number;
  /** On a `done`: the trash slot the previous export went to (`auto` for an automatic export); absent after a first export. */
  slot?: string;
  /** On a `done`: what a person should read of the build -- hidden surfaces removed, samples dropped, a merge not made (`StepResult.notes`). */
  notes?: string[];
}

/** A job as `GET jobs` lists it: what is queued, running, and parked waiting for a tab (§4). */
export interface JobInfo {
  id: string;
  source: string;
  state: 'queued' | 'running' | 'parked';
}

/**
 * The last attempt to export a source (`runs.json`, §4; `GET run` answers
 * `{ at, ms, ok, output? }` of it). Failure output and timings belong to one
 * machine: here, not in the record.
 */
export interface Run {
  at: string;
  ms: number;
  ok: boolean;
  source: string;
  deps: Record<string, string>;
  recipe: string;
  error?: string;
  /** On failure, the whole output, at most 64 KB. */
  output?: string;
  /** On success, what a person should read of it (`JobMessage.notes`): the Model tab says them after a reload too. */
  notes?: string[];
  /** `GET run`'s: it made the export there now -- its source and recipe the record's `built`. Its notes are said only then. */
  current?: boolean;
}

/** A refusal from the API, or from `validName`: always with a way on when there is one. */
export interface Refusal {
  refused: string;
  suggested?: string;
}

/** A trash slot as read from disk (§6). Each file's `path` is the one it had, project-relative. */
export interface TrashSlot {
  slot: string;
  files: Array<{ path: string; size: number; mtime: number }>;
}

/**
 * A trashed file as the Assets tool lists it under the Trash root (§8,
 * `model.ts`'s `childrenOf`): `path` is where it is now, `.trash/<slot>/<the
 * path it had>` -- what `GET file`, `GET thumb` and `GET stats` take, and what
 * `fromTrash` reads back -- and `slot` the slot it is in.
 */
export interface TrashFile {
  path: string;
  size: number;
  mtime: number;
  slot: string;
}

// ---------------------------------------------------------------- a file's stats (§4, "Stats are lazy")

/** A model's numbers, from its JSON alone (`stats/glb.ts`). */
export interface ModelStats {
  format: 'glb' | 'gltf';
  meshes: number;
  primitives: number;
  vertices: number;
  triangles: number;
  materials: number;
  textures: number;
  images: Array<{ name?: string; uri?: string; bytes?: number; mimeType?: string }>;
  animations: Array<{ name: string; duration: number; channels: number }>;
  skins: Array<{ joints: number }>;
  extensionsUsed: string[];
  draco: boolean;
  meshopt: boolean;
  ktx2: boolean;
  /** The union of every `POSITION` accessor's min and max: mesh space, node transforms not applied. */
  bounds?: { min: [number, number, number]; max: [number, number, number] };
}

/** An image's numbers, from its header (`stats/image.ts`). */
export interface ImageStats {
  format: string;
  width?: number;
  height?: number;
  alpha?: boolean;
  /** Both sides a power of two. */
  pow2?: boolean;
  /** Mip levels (KTX2). */
  mips?: number;
  /** PSD: Photoshop's own composite is in the file (Maximize Compatibility); undefined when the file does not say. */
  composite?: boolean;
}

/** A sound's numbers, from its headers (`stats/audio.ts`). */
export interface AudioStats {
  format: string;
  /** Seconds. */
  duration?: number;
  channels?: number;
  sampleRate?: number;
  /** Opus: samples at 48 kHz the decoder drops from the front. */
  preSkip?: number;
}

/** Which reader a file goes to. */
export type StatsKind = 'model' | 'image' | 'audio' | 'other';

/** `GET stats?path=`: a file's stats, or that it is an unfetched LFS pointer. */
export interface FileStats {
  kind: StatsKind;
  stats?: ModelStats | ImageStats | AudioStats;
  pointer?: boolean;
}

// ---------------------------------------------------------------- the push channel (§5)

/** The push channel's one event, `kinds.ts`' `PUSH_EVENT`: `server.ws.send({ type: 'custom', event, data })`, `import.meta.hot.on(event, ...)`. */
export type PushEvent = typeof PUSH_EVENT;

/** `reload`: an export changed under `src/assets/`; with `beside`, an image under `models/` (its path there) its model may name (§8). */
export interface ReloadMessage extends HotReload {
  beside?: string;
}

/** `convert`: a browser step wants a game tab (§8). `source` and `parts` relative to the project root, for `GET file`. */
export interface ConvertMessage {
  job: string;
  source: string;
  parts: string[];
}

/**
 * `problem`: a prefab file under `src/assets/prefabs/` -- or a material file under `src/assets/materials/` --
 * that does not parse, kept from the page -- the update is not passed on, so the last good file stays
 * compiled -- with the parser's words and the line; `message` null when the file parses again, or is gone
 * (Docs/prefabs.md §7, Docs/render.md §4).
 */
export interface ProblemMessage {
  kind: 'prefabs' | 'materials';
  key: string;
  message: string | null;
  line?: number;
}

/** What the push channel carries, as its `data`. */
export type PushMessage =
  | { type: 'changed'; diff: Diff }
  | { type: 'job'; job: JobMessage }
  | { type: 'convert'; convert: ConvertMessage }
  | { type: 'reload'; reload: ReloadMessage }
  | { type: 'tools'; tools: ToolLook[] }
  | { type: 'problem'; problem: ProblemMessage }
  | { type: 'held'; held: string[] }
  /** A project route's message (`vibe({ routes })`, its handler's `ctx.push`): `kind` is `vibe:tool:<name>`, the editor's `Live` its `tool` event. */
  | { type: 'tool'; kind: `vibe:tool:${string}`; tool: string; message: unknown }
  /** The studio's (`studio/`, Docs/squidwright-implementation.md 2.2): a server log's lines, a task's start and end, tsc's problems, a build's sizes, a download's progress. */
  | ({ type: 'studio' } & StudioMessage);

// ---------------------------------------------------------------- the API's answers (§5, under /__assets/)

/** `GET tools`: may this caller write, and the tools found -- `null` until the first look has finished. */
export interface ToolsAnswer {
  write: boolean;
  tools: ToolLook[] | null;
}

/**
 * What every mutating call answers: the diff from the client's `since` to the
 * call's own last change -- the whole tree when `since` is older than the
 * diffs kept -- so applying it brings the client to `seq` with no gap (§6).
 */
export interface WriteAnswer {
  seq: number;
  diff: Diff | TreeAnswer;
}

/** A job a call queued: the id whose `job` messages say how it went. */
export interface QueuedJobInfo {
  id: string;
  source: string;
}

/** `POST tools/check`, `PUT tools?name=`: the tools looked for again, and what could now be made, queued. */
export interface ToolsCheckAnswer extends WriteAnswer, ToolsAnswer {
  jobs: QueuedJobInfo[];
}

/** `POST export`: the job that will run for each source (§4, dedupe), whose `done` names the slot its previous export went to. */
export interface ExportAnswer extends WriteAnswer {
  jobs: QueuedJobInfo[];
}

/**
 * `PUT import`: where the file was written, the slot what it replaced went to,
 * and whether it is an extra (no job). On a drop's last file (`left=0`, or a
 * file of no drop), `jobs`: the drop's exports, once its owners are read --
 * queued now, or a job already under way for one -- owners first. A source of
 * the drop not among them needs no job (current, unmade, an extra's).
 */
export interface ImportAnswer extends WriteAnswer {
  path: string;
  slot?: string;
  /** `replace=true`: what went to the trash (`slot`) -- the family it replaced, read before any of it went. */
  replaced?: string[];
  extra?: true;
  jobs?: QueuedJobInfo[];
  /** `script=true` (Docs/modeler.md M39): the copy the script imports, beside it, and the codecs decoded on the way in. */
  script?: ScriptMade;
}

/** A script the Model tab's New model, Import or Make a script wrote (Docs/modeler.md M38, M39). */
export interface ScriptMade {
  /** The import's copy beside the script, `robot.source.glb`; absent for New model. */
  copy?: string;
  /** The compression decoded on the way in (`KHR_draco_mesh_compression`, …): empty for a file copied byte for byte. */
  decoded?: string[];
}

/** `POST model` (New model) and `POST adopt` (Make a script for a `.glb`): the script, what it imports, its export queued. */
export interface ModelMadeAnswer extends WriteAnswer, ScriptMade {
  /** The script written. */
  path: string;
  jobs: QueuedJobInfo[];
}

/** `POST delete`: what went (`removed`, the families' files and the empty folders), and the slot the files went to; none when only empty folders were removed. */
export interface DeleteAnswer extends WriteAnswer {
  removed: string[];
  slot?: string;
}

/** `POST restore`: the paths as written (a taken name made `-2`), and the slot what `replace` displaced went to. */
export interface RestoreAnswer extends WriteAnswer {
  restored: string[];
  slot?: string;
}

/** `POST move`: every file moved, from and to -- a family, or every file of a folder and its twin. */
export interface MoveAnswer extends WriteAnswer {
  moved: Array<[from: string, to: string]>;
  /**
   * The data files the repair pass rewrote around the move (Docs/asset-ids.md §4) -- each by its path before the move,
   * with its text then and the text the move left: what the step's undo hands back as the move back's `restore`
   * (`{ path, text: before, after }`). Absent when none.
   */
  rewritten?: Array<{ path: string; before: string; after: string }>;
  /** An undo's restore items left as they are: each file no longer held what the doing left (edited since). */
  kept?: string[];
  /**
   * The pass after the move threw midway: what was done is answered all the same (`moved`, `rewritten`), a step Z
   * undoes like any; this says what went wrong.
   */
  partial?: string;
}

/**
 * `PUT export-as?path=`: a source's export named (`"as"`, Docs/asset-ids.md rule 8) -- the record written (its text
 * before, null for one made), the exports moved to the new name, the files the repair pass rewrote. Its undo sends them
 * back as `{ restore: { record, text: before, moved, made, texts } }`.
 */
export interface ExportAsAnswer extends WriteAnswer {
  record: string;
  before: string | null;
  moved: Array<[from: string, to: string]>;
  /** In a conflict, the exports its job makes anew under the new name: what the undo stops and trashes. */
  made?: string[];
  rewritten?: Array<{ path: string; before: string; after: string }>;
  /** An undo's texts left as they are, edited since (as `MoveAnswer.kept`). */
  kept?: string[];
  jobs?: QueuedJobInfo[];
}

/** `POST referrers`: the data files naming any of the given files' assets, each with the keys it names them by. */
export interface ReferrersAnswer {
  referrers: Array<{ path: string; names: string[] }>;
}

/** `POST copy`: the paths written (the family's, numbered where a name was taken). */
export interface CopyAnswer extends WriteAnswer {
  paths: string[];
}

/** `PUT prefab`: a prefab file written (Docs/prefabs.md §7) -- `before`, its text before, null for one made: what an undo writes back. */
export interface PrefabAnswer extends WriteAnswer {
  path: string;
  before: string | null;
}

/**
 * `PUT sidecar`: the record or folder defaults written, and the exports that
 * follow queued. A source taken out of the build (`include: false`) answers
 * `slot`, where its exports went -- what the tool's undo restores.
 */
export interface SidecarAnswer extends WriteAnswer {
  jobs: QueuedJobInfo[];
  slot?: string;
}

/** One name's answer from `GET names`, in the order asked: fine, or refused with a way on (`exists` when the name is taken). */
export type NameAnswer = { name: string } & ({ ok: true; note?: string } | (Refusal & { exists?: true }));

/** `GET thumb`'s `404`: not hashed yet; made by a browser, posted under `hash`; or none to be had. */
export type ThumbMiss = { checking: true } | { make: 'browser'; hash: string } | { none: string };

/** `GET uses?key=`: a literal use of a key in `src/` (§5). */
export interface Use {
  /** Project-relative, with `/`. */
  file: string;
  /** 1-based. */
  line: number;
  /** The line, trimmed. */
  text: string;
}

/**
 * One thing Gladius said of a script (`GET model`, Docs/modeler.md §3): its
 * severity and code as Gladius has them, its words, and the line of the script
 * it names -- `script_span`'s, or a syntax error's `<file>:<line>:` -- if any.
 */
export interface ModelDiagnostic {
  severity: 'error' | 'warning' | 'info';
  code?: string;
  message: string;
  line?: number;
}

/**
 * A node as the kernel builds it (Docs/modeler.md M4): its name -- the
 * `emit{name=…}` string -- its vertices, edges and faces counted as the kernel
 * stores them (an edge once a pair of vertex indices), its triangles, and its
 * polygons' boundaries as flat segments (`x, y, z, x, y, z` each), in the
 * script's metres, an edge two faces share once.
 */
export interface ModelNode {
  name: string;
  vertices: number;
  edges: number;
  faces: number;
  triangles: number;
  segments: number[];
}

/**
 * `GET model?path=` (Docs/modeler.md §3): a `.lua` source built by `gladius
 * query --faces --checks none` with its resolved parameters. `ok` is the
 * build's; a failed one has its diagnostics and no nodes. `missing` names a
 * tool that is not here (`gladius`), with its `hint`; `problem`, an answer that
 * could not be read.
 */
export interface ModelAnswer {
  ok: boolean;
  /** Milliseconds the query took. */
  ms: number;
  diagnostics: ModelDiagnostic[];
  nodes: ModelNode[];
  missing?: string;
  hint?: string;
  problem?: string;
}

/**
 * One step of a build trace (Docs/modeler.md M34): an operation the script
 * ran that made a mesh, in the order it ran (`index` from 1; its node in the
 * trace's GLB is `__trace_0007`), its op's name, its triangles, the step that
 * took its mesh as an argument and so replaced it (absent: nothing did, it is
 * there to the end -- an emitted part), the `emit{name=}` or an import's
 * part's name. `kept: false`, past the trace's budget: listed, not in the
 * GLB. `from`: a grow-from shape (`__trace_0007_from`) to morph out of;
 * `frames`, that many builds at growing amounts (`_f01`...); `edges`, an op
 * that moves nothing and is drawn as the lines it cut (D70).
 */
export interface TraceStep {
  index: number;
  op: string;
  triangles: number;
  consumedAt?: number;
  label?: string;
  kept?: false;
  from?: true;
  frames?: number;
  edges?: true;
}

/**
 * `POST trace?path=` (Docs/modeler.md §3): the script built instrumented,
 * every operation's mesh a node of one GLB under `.cache/assets/trace/`
 * (fetched by `GET trace?path=&v=`, `v` this answer's `version`). Its cost:
 * the triangles kept, and the build's whole (`total`); `bytes`, the GLB's
 * size; `capped` when the budget left steps out. A failure: Gladius's
 * diagnostics, the script's lines, its first error as one line (`error`).
 */
export interface TraceAnswer {
  ok: boolean;
  ms: number;
  steps: TraceStep[];
  triangles: number;
  total: number;
  bytes: number;
  version?: string;
  capped?: { cap: number; dropped: number };
  diagnostics: ModelDiagnostic[];
  error?: string;
  superseded?: true;
  missing?: string;
  hint?: string;
}

/** `GET trace?path=&v=&faces=1`: each kept step's polygons, flat segments by step index (`ModelNode.segments`'). */
export interface TraceFaces {
  ok: boolean;
  ms: number;
  steps: Record<number, number[]>;
}

/**
 * One parameter a script's `params{}` declares, as Gladius reports it
 * (`gladius params --format json`, Docs/modeler.md §3): its type as its
 * default's Lua type -- `integer` for a whole-number default or `integer =
 * true` -- its default and the value it builds at with the overrides given,
 * `overridden` when they differ by an override, its bounds, its choices, its
 * doc and the line it is declared on.
 */
export interface ParamSpec {
  name: string;
  type: 'number' | 'integer' | 'string' | 'boolean';
  default: number | string | boolean;
  value: number | string | boolean;
  overridden: boolean;
  min?: number;
  max?: number;
  choices?: Array<number | string>;
  doc?: string;
  line?: number;
}

/**
 * `GET params?path=` (Docs/modeler.md §3): what a `.lua` source's `params{}`
 * declares, by `gladius params` -- no build -- with its resolved parameters,
 * the export's. `params` null: this Gladius reports none (older than 0.6), or
 * the script did not get as far as `params{}` (`error` says why). `ok` false
 * with `params` there: an override was refused (`error`, its words), the rows
 * read at the script's own defaults with the overrides painted back on (Vibe3D
 * D45). `set` is what the export passes, `own` what the source's own record
 * sets of it (the rest are its folders' `export.json`).
 */
export interface ParamsAnswer {
  ok: boolean;
  ms: number;
  params: ParamSpec[] | null;
  set: Record<string, string>;
  own: Record<string, string>;
  diagnostics: ModelDiagnostic[];
  error?: string;
  missing?: string;
  hint?: string;
  problem?: string;
}

/**
 * `POST preview?path=` (Docs/modeler.md §3, M22): a build that is not the
 * export. Its bytes when it built (`model/gltf-binary`, the time in
 * `X-Preview-Ms`); this, as JSON, when it did not -- Gladius's diagnostics,
 * its one line, or `superseded`, a later ask for the same script having come
 * while this one waited.
 */
export interface PreviewFailure {
  ok: false;
  ms: number;
  diagnostics: ModelDiagnostic[];
  error?: string;
  superseded?: true;
  missing?: string;
  hint?: string;
}

/**
 * `GET held`, and the push's `held`: the Gladius scripts whose auto-export
 * waits for a Claude turn's end (Docs/modeler.md M21), in the order held --
 * the whole list each time; empty once the turns are over and they export.
 */
export interface HeldAnswer {
  held: string[];
  /**
   * `GET held` alone: is a turn of any conversation running now (the link's `turns`)? While one does, the Model tab
   * builds no stale script itself -- the auto-export holds it, and the turn's end exports it. Absent from the push.
   */
  turns?: boolean;
}

/**
 * `GET kinds`: every kind as the Assets panel lists its folder -- the table's (`KINDS`) and the
 * project's own (`vibe({ kinds })`), each with its key type, the folder's title there.
 */
export interface KindsAnswer {
  kinds: KindRow[];
}

/** `PUT script?path=`: the script written whole, and its export queued. */
export interface ScriptAnswer extends WriteAnswer {
  jobs: QueuedJobInfo[];
}
