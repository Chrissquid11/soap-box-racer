/**
 * `POST trace` and `GET trace` (Docs/modeler.md §3, M34-M36): a Gladius script
 * replayed op by op -- Vibe3D's build trace (D66, `src/core/debugBuild.ts`),
 * ported to the dev server.
 *
 * **Instrumented, not stepped** (D66). Gladius has no debugger and cannot
 * build part of a script; what it has is the property that makes a trace
 * possible at all: every mesh operation is a pure function returning a new
 * mesh, and every one is a global. So the script is neither parsed nor
 * changed: a **prelude** replaces each geometry global with a wrapper that
 * records what came back, the script runs verbatim, and an **epilogue** emits
 * every recorded intermediate as a node of its own (`__trace_0007`). One build
 * makes every frame: stepping is showing one node and hiding the rest.
 *
 * Kept from Vibe3D, each a trap it found:
 * - **`table.pack`**, never one value: `extrude_faces` returns the mesh *and*
 *   the faces it made; a wrapper keeping the first breaks every selection
 *   chained after it.
 * - **"Is it a mesh?" is `pcall(triangle_count, v)`** -- profiles, sets,
 *   lattices and numbers fail it, which is the filter wanted.
 * - **A lifetime per mesh** (Total, D66): each wrapper charges the recorded
 *   meshes among its arguments -- at any depth, a seen-set against a table met
 *   twice (D87) -- to its own step, so a mesh is alive over `index <= K <
 *   consumedAt`, and a step's Total is the model as it stands then.
 * - **`merge`, `bind` and `cull_hidden` consume** (D87): what they are given
 *   dies there; what `merge` and `cull_hidden` hand back (a list) is recorded
 *   step by step, so the merged mesh is a step the emit then takes.
 * - **`bind` is the identity, `emit_action` nothing** (D95): two step nodes of
 *   one skin under one name are two skeletons (GLD-2005); a trace draws static
 *   steps. Ownership passes to the call's own step after its arguments are
 *   consumed, so an op handing back its argument does not live for ever.
 * - **Every step emitted `open = true`** (D95): a half-built part is not a
 *   closed surface, and a step is scaffolding to look at, not an asset.
 * - **An amount grows** (D66): `bevel`, `extrude`, `extrude_faces`,
 *   `inset_faces`, `slide_verts`, `displace` built again at almost nothing (the
 *   first of 0.002, 0.15, 0.4 whose vertex count is the real one's) to morph
 *   out of -- else at eight amounts, played as frames.
 *
 * Changed here:
 * - **The script's own line numbers** (better than D66's): the whole prelude is
 *   on line 1, the script starts on it, so a failed trace's diagnostics name
 *   the script's lines; the instrumented file's name in a message is the
 *   script's again.
 * - **A script that ends in `return` traces** (D87's open gap): the script runs
 *   inside a function -- its `return` returns from that -- and the epilogue
 *   runs after it.
 * - **Bounded, the cost said** (D66 changed, M35): a budget of triangles kept
 *   (`TRACE_TRIANGLES`, a million). Past it, the steps' grow-from shapes go first, then
 *   whole steps, from the start of the build back -- the end is the model, and
 *   the emitted parts are kept first -- each listed all the same, `kept: false`,
 *   and the answer says how many and what it cost.
 * - **Beside the script, dot-named** (`.crate.trace.lua`): Gladius resolves
 *   `import` and `include` against the script's folder and confines them to it,
 *   so the instrumented copy is written there; the asset index never lists a
 *   dot-named file (`paths.ts`' `IGNORED`), and it is taken away after.
 *
 * `instrument`, `readSteps`, `traceArgs` are pure (`model-trace.test.ts`);
 * `buildTrace` and `traceFaces` run Gladius.
 */
import { mkdir, readdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { basename, dirname, join } from 'node:path';
import type { ModelDiagnostic, TraceAnswer, TraceFaces, TraceStep } from './api-types.ts';
import { bareWords } from './gladius-words.ts';
import { paramArgs } from './model-params.ts';
import { diagnosticOf, readReport, type RawDiagnostic } from './model-query.ts';
import { run } from './tools.ts';

/** A trace that has not finished in this long is given up: it is a whole build and some. */
export const TRACE_MS = 120_000;

/**
 * Triangles kept across every step and its grow-from shapes, by default: a
 * million is about 95 MB of GLB (measured: a 415 k-triangle sphere traced
 * through eleven steps came to 279 MB at 2.9 M) -- the page fetches and decodes
 * it whole, and a trace past that is a wait and a tab's memory. Measured: the
 * parrot traces at 52 k (6.8 MB), the crate at 48.
 */
export const TRACE_TRIANGLES = 1_000_000;

/** Gladius's own instruction budget is 50 M; the wrappers and the grow-from builds spend more of it. */
const INSTRUCTIONS = 200_000_000;

/**
 * Ops that return a mesh: each call a step. Gladius 0.8.0's (as 0.7.3's), in its reference's
 * groups (Vibe3D D71's list, and what came since: `sdf_mesh`, `sdf_graft`,
 * `sample_uvs`). A name the running Gladius lacks is skipped, not a failure.
 * Every function Gladius has is in this list, `CONSUMING_OPS` or `NOT_STEPS`
 * -- `model-trace.test.ts` asks Gladius for its globals and fails on one in none
 * (D71: the lists that must follow it, made loud).
 */
export const MESH_OPS: readonly string[] = [
  // Primitives
  'box', 'sphere', 'cylinder', 'cone', 'torus', 'capsule', 'polyhedron',
  // Generators
  'extrude', 'revolve', 'loft', 'sweep',
  // Transforms
  'translate', 'rotate', 'scale', 'mirror', 'place', 'align',
  // Component transforms
  'translate_verts', 'rotate_verts', 'scale_verts', 'orient_verts', 'relax_verts', 'slide_verts', 'project_verts', 'apply_lattice',
  // Booleans
  'union', 'subtract', 'intersect', 'join',
  // Modifiers
  'bevel', 'extrude_faces', 'inset_faces', 'knife_profile', 'knife', 'dissolve_edges', 'subdivide', 'decimate', 'weld', 'clean',
  'smooth_normals', 'merge_faces', 'retriangulate', 'displace',
  // UVs and paint: things done to the mesh, a build that spends its time there visible doing it
  'unwrap_box', 'unwrap_cylindrical', 'unwrap_spherical', 'uv_swatch', 'unwrap', 'pack_islands', 'paint_faces', 'sample_colors', 'sample_uvs',
  // Fields made a mesh
  'sdf_mesh', 'sdf_graft',
  // An imported file: the whole mesh, and each part of its record (D95)
  'import',
];

/** Ops wrapped for what they take (D87): their arguments die there; a list they return is recorded mesh by mesh. */
export const CONSUMING_OPS: readonly string[] = ['merge', 'bind', 'cull_hidden'];

/**
 * Every other function Gladius 0.8.0 has: queries, selections, profiles, fields,
 * skeletons, actions, numbers -- a step whose result cannot be looked at is a row
 * only scrolled past (D71). Lua's own (`pairs`, `pcall`, ...) are in `LUA_OWN`.
 */
export const NOT_STEPS: readonly string[] = [
  'action', 'anchor_of', 'axis_x', 'axis_y', 'axis_z', 'bbox', 'boundary', 'check', 'circle', 'component_count', 'concave_edges', 'connected',
  'convex_edges', 'cross', 'deg', 'dot', 'edge_loop', 'edge_ring', 'edges_in_box', 'edges_of', 'edges_where', 'emit', 'emit_action', 'envelope',
  'face_count', 'faces_facing', 'faces_in_box', 'faces_of', 'faces_where', 'fail', 'fit_skeleton', 'grow', 'has_uvs', 'include', 'info',
  'is_manifold', 'islands', 'joint', 'lattice', 'lattice_info', 'length', 'lerp', 'material', 'measure', 'mirror_joints', 'mirror_pose',
  'move_control', 'move_controls', 'move_joint', 'ngon', 'ngon_count', 'noise3', 'normalize', 'offset', 'origin', 'params', 'path', 'path_arc',
  'poly', 'profile_area', 'profile_intersect', 'profile_subtract', 'profile_union', 'rad', 'rect', 'region', 'reselect', 'rng', 'rounded_rect',
  'sdf_box', 'sdf_capsule', 'sdf_cylinder', 'sdf_displace', 'sdf_distance', 'sdf_ellipsoid', 'sdf_from_mesh', 'sdf_intersect', 'sdf_offset',
  'sdf_part_faces', 'sdf_round_cone', 'sdf_shell', 'sdf_sphere', 'sdf_subtract', 'sdf_symmetry', 'sdf_torus', 'sdf_union', 'section',
  'section_area', 'select', 'selection_bounds', 'selection_frame', 'set_count', 'set_subtract', 'set_union', 'sharp_edges', 'shrink', 'skeleton',
  'surface_area', 'triangle_count', 'unmapped_count', 'v2', 'v3', 'vertex_count', 'verts_in_box', 'verts_of', 'verts_where', 'volume', 'warn',
];

/** Lua's own globals that Gladius's sandbox keeps. */
export const LUA_OWN: readonly string[] = [
  'assert', 'error', 'getmetatable', 'ipairs', 'loadfile', 'next', 'pairs', 'pcall', 'print', 'rawequal', 'rawget', 'rawlen', 'rawset',
  'setmetatable', 'tonumber', 'tostring', 'type', 'xpcall',
];

/** Ops whose effect is an amount (D66): built again at almost none, to grow out of. Their option's name. */
export const AMOUNT_OPS: Readonly<Record<string, string>> = {
  bevel: 'width',
  displace: 'amount',
  extrude: 'distance',
  extrude_faces: 'distance',
  inset_faces: 'distance',
  slide_verts: 'amount',
};

/** Ops that move nothing and change only the edges (D70): drawn as the lines they cut. */
export const EDGE_OPS: readonly string[] = ['knife', 'knife_profile', 'dissolve_edges', 'retriangulate', 'weld', 'clean', 'merge_faces'];

/** The frames an amount op that cannot be morphed is built at (D66). */
const AMOUNT_FRAMES = 8;

/** What each recorded step prints, read back out of the build's diagnostics. */
const MARK = 'TRACESTEP';
/** A step's node, `__trace_0007`; its grow-from shape `__trace_0007_from`, its frames `__trace_0007_f01`. */
export const STEP_NODE = /^__trace_(\d+)(?:_(from|f(\d+)))?$/;

const luaList = (names: readonly string[]): string => `{ ${names.map((n) => `"${n}"`).join(', ')} }`;

/**
 * The prelude, every statement on one line -- so the script, which starts on
 * that line, keeps its own line numbers -- ending in the opening of the
 * function the script runs in.
 */
function prelude(cap: number): string {
  const amounts = Object.entries(AMOUNT_OPS).map(([op, key]) => `${op} = "${key}"`).join(', ');
  return [
    // D95: a skin cannot be emitted step by step; nothing is bound, so no action plays. Before the wrappers capture them.
    'if type(bind) == "function" then bind = function(m) return m end end;',
    'if type(emit_action) == "function" then emit_action = function(a) return a end end;',
    `local __t_ops = ${luaList(MESH_OPS)};`,
    `local __t_consuming = ${luaList(CONSUMING_OPS)};`,
    `local __t_amounts = { ${amounts} };`,
    'local __t_steps = {}; local __t_owner = {}; local __t_last = {}; local __t_from = {}; local __t_frames = {}; local __t_parts = {};',
    'local __t_tris, __t_verts_of = triangle_count, vertex_count;',
    'local function __t_count(v) local ok, n = pcall(__t_tris, v); if ok and type(n) == "number" then return n end return nil end;',
    'local function __t_verts(v) local ok, n = pcall(__t_verts_of, v); if ok and type(n) == "number" then return n end return nil end;',
    // A dielectric grey for the steps with no material of their own: glTF's default is metallic 1, black under analytic light (D70).
    'local __t_grey = material{ name = "__trace_grey", base_color = v3(0.55, 0.56, 0.58), metallic = 0.0, roughness = 0.65 };',
    'local function __t_record(op, mesh, label, mat) local n = __t_count(mesh); if n == nil then return nil end;',
    '  local i = #__t_steps + 1; __t_steps[i] = { op = op, mesh = mesh, tris = n, label = label, material = mat };',
    '  if __t_owner[mesh] == nil then __t_owner[mesh] = i end; return i end;',
    'local function __t_touch(v, at) local i = __t_owner[v]; if i ~= nil and i < at then __t_last[i] = at end end;',
    'local function __t_consume_value(v, at, seen) __t_touch(v, at);',
    '  if type(v) == "table" and not seen[v] then seen[v] = true; for _, x in pairs(v) do __t_consume_value(x, at, seen) end end end;',
    'local function __t_consume(args, at) local seen = {}; for k = 1, args.n do __t_consume_value(args[k], at, seen) end end;',
    // An amount op built again at a share of its amount, on the unwrapped function: not a step itself.
    'local function __t_grow(fn, op, a, r, i) local key = __t_amounts[op];',
    '  if not (i and key and type(a[2]) == "table" and type(a[2][key]) == "number") then return end;',
    '  local want = __t_verts(r[1]);',
    '  local function at(f) local seed = {}; for k, v in pairs(a[2]) do seed[k] = v end; seed[key] = a[2][key] * f;',
    '    local ok, m = pcall(fn, a[1], seed); if ok and __t_count(m) then return m end return nil end;',
    '  for _, f in ipairs({ 0.002, 0.15, 0.4 }) do local z = at(f);',
    '    if z and want and __t_verts(z) == want then __t_from[i] = z; return end end;',
    `  local seq = {}; for k = 1, ${AMOUNT_FRAMES} do local m = at(k / ${AMOUNT_FRAMES + 1}); if m then seq[#seq + 1] = m end end;`,
    '  if #seq > 0 then __t_frames[i] = seq end end;',
    // The whole-file import and its parts (D95): each part a step of its own, settled in the flush.
    'local function __t_import_parts(r, i) if not (i and type(r[2]) == "table" and type(r[2].parts) == "table") then return end;',
    '  local ids = {}; for _, p in ipairs(r[2].parts) do if type(p) == "table" and p.mesh ~= nil then',
    '    local j = __t_record("import", p.mesh, p.name); if j then ids[#ids + 1] = j end end end;',
    '  if #ids > 0 then __t_parts[i] = ids end end;',
    'for _, name in ipairs(__t_ops) do local fn = _G[name]; if type(fn) == "function" then local op = name;',
    '  _G[name] = function(...) local a = table.pack(...); local r = table.pack(fn(...));',
    '    local i = __t_record(op, r[1], nil); if op == "import" then __t_import_parts(r, i) end; __t_grow(fn, op, a, r, i);',
    '    __t_consume(a, i or (#__t_steps + 1)); if i then __t_owner[r[1]] = i end;',
    '    return table.unpack(r, 1, r.n) end end end;',
    // merge, bind, cull_hidden: what they take dies here; a list they hand back recorded mesh by mesh, after.
    'for _, name in ipairs(__t_consuming) do local fn = _G[name]; if type(fn) == "function" then local op = name;',
    '  _G[name] = function(...) local a = table.pack(...); local r = table.pack(fn(...));',
    '    local i = __t_record(op, r[1], nil); __t_consume(a, i or (#__t_steps + 1));',
    '    if i then __t_owner[r[1]] = i elseif type(r[1]) == "table" then for _, x in ipairs(r[1]) do',
    '      local m = x; if type(x) == "table" then m = x.mesh end; local j = __t_record(op, m, type(x) == "table" and x.name or nil);',
    '      if j then __t_owner[m] = j end end end;',
    '    return table.unpack(r, 1, r.n) end end end;',
    // emit: the part finished, with its name and material -- never consumed, so it stays to the end. Its placement
    // (Gladius 0.8.0's position, rotation, scale: the mesh is the node's local space) kept for its step's node.
    'local __t_emit = emit; emit = function(m, opts) local i = __t_record("emit", m, opts and opts.name or nil, opts and opts.material or nil);',
    '  if i and type(opts) == "table" then __t_steps[i].place = { position = opts.position, rotation = opts.rotation, scale = opts.scale } end;',
    '  __t_touch(m, i or (#__t_steps + 1)); return __t_emit(m, opts) end;',
    // The flush: imports settled, the budget spent from the end, every step said and the kept ones emitted.
    'function __t_flush() for i, ids in pairs(__t_parts) do local used = false; for _, j in ipairs(ids) do if __t_last[j] then used = true end end;',
    '    if used then if not __t_last[i] then __t_last[i] = ids[1] end else for _, j in ipairs(ids) do __t_last[j] = j end end end;',
    `  local budget = ${cap}; local keep = {}; local extras = {}; local spent = 0; local total = 0;`,
    '  local function extra(i) local n = 0; if __t_from[i] then n = n + (__t_count(__t_from[i]) or 0) end;',
    '    if __t_frames[i] then for _, m in ipairs(__t_frames[i]) do n = n + (__t_count(m) or 0) end end; return n end;',
    '  for i, s in ipairs(__t_steps) do total = total + s.tris + extra(i) end;',
    '  for i = #__t_steps, 1, -1 do local s = __t_steps[i]; if s.op == "emit" and spent + s.tris <= budget then keep[i] = true; spent = spent + s.tris end end;',
    '  for i = #__t_steps, 1, -1 do local s = __t_steps[i]; if not keep[i] and spent + s.tris <= budget then keep[i] = true; spent = spent + s.tris end end;',
    '  for i = #__t_steps, 1, -1 do if keep[i] then local e = extra(i); if e > 0 and spent + e <= budget then extras[i] = true; spent = spent + e end end end;',
    '  for i, s in ipairs(__t_steps) do',
    `    info(string.format("${MARK} %d|%s|%d|%d|%d|%d|%d|%s", i, s.op, s.tris, __t_last[i] or 0, keep[i] and 1 or 0,`,
    '      (extras[i] and __t_from[i]) and 1 or 0, (extras[i] and __t_frames[i]) and #__t_frames[i] or 0, s.label or ""));',
    '    if keep[i] then local p = s.place or {}; __t_emit(s.mesh, { name = string.format("__trace_%04d", i), material = s.material or __t_grey, open = true,',
    '      position = p.position, rotation = p.rotation, scale = p.scale });',
    '      if extras[i] and __t_from[i] then __t_emit(__t_from[i], { name = string.format("__trace_%04d_from", i), material = __t_grey, open = true }) end;',
    '      if extras[i] and __t_frames[i] then for k, m in ipairs(__t_frames[i]) do',
    '        __t_emit(m, { name = string.format("__trace_%04d_f%02d", i, k), material = s.material or __t_grey, open = true }) end end end end;',
    `  info(string.format("${MARK}END %d|%d|%d", #__t_steps, spent, total)) end;`,
    // The script, in a function: a `return` at its end returns from it, and the flush still runs.
    '(function(...) ',
  ].join(' ');
}

/** After the script: its function closed and called, the trace flushed. */
const EPILOGUE = '\nend)(...); __t_flush()\n';

/** The script `source`, instrumented: its first line on the prelude's, every line of it where it was. */
export function instrument(source: string, cap = TRACE_TRIANGLES): string {
  // A shebang would not be Lua after the prelude; Gladius scripts have none, but a `#` first line is made a comment.
  const body = source.startsWith('#') ? `--${source}` : source;
  return prelude(cap) + body + EPILOGUE;
}

/** An instrumented copy's name: dot-named, `.trace.lua`. */
export const TRACED = /^\.[^/]+\.trace\.lua$/;

/**
 * The instrumented copies a server that stopped mid-trace left under `dir` (the Source root), taken away: each is
 * removed as its trace ends, so one found at start is a crash's. Their paths, relative.
 */
export async function sweepTraced(dir: string): Promise<string[]> {
  let names: string[];
  try {
    names = (await readdir(dir, { recursive: true })) as string[];
  } catch {
    return [];
  }
  const left = names.filter((n) => TRACED.test(n.split(/[\\/]/).pop() ?? ''));
  for (const n of left) await rm(join(dir, n), { force: true });
  return left;
}

/** `crate.lua` -> `.crate.trace.lua`, the instrumented copy beside it. */
export function tracedName(script: string): string {
  return `.${basename(script).replace(/\.lua$/i, '')}.trace.lua`;
}

/** The command line: `gladius run`, embedded textures (a page decodes it alone), no merge (the steps are nodes), the params. */
export function traceArgs(input: string, out: string, params: Readonly<Record<string, string>>): string[] {
  return ['run', '--format', 'json', '--textures', 'embedded', '--optimise-anim', '0', '--instruction-limit', String(INSTRUCTIONS), ...paramArgs(params), '--out', out, input];
}

const STEP_LINE = new RegExp(`^${MARK} (\\d+)\\|([^|]*)\\|(\\d+)\\|(\\d+)\\|([01])\\|([01])\\|(\\d+)\\|(.*)$`);
const END_LINE = new RegExp(`^${MARK}END (\\d+)\\|(\\d+)\\|(\\d+)$`);

/** The steps read out of the build's messages, and its end line's figures -- null when it never got there. */
export function readSteps(messages: readonly string[]): { steps: TraceStep[]; kept: number; total: number } | null {
  const steps: TraceStep[] = [];
  let end: { kept: number; total: number } | null = null;
  const edge = new Set(EDGE_OPS);
  for (const message of messages) {
    const line = message.trim();
    const s = STEP_LINE.exec(line);
    if (s) {
      const consumedAt = Number(s[4]);
      const label = s[8]!.trim();
      steps.push({
        index: Number(s[1]),
        op: s[2]!,
        triangles: Number(s[3]),
        ...(consumedAt > 0 ? { consumedAt } : {}),
        ...(label ? { label } : {}),
        ...(s[5] === '0' ? { kept: false } : {}),
        ...(s[6] === '1' ? { from: true } : {}),
        ...(Number(s[7]) > 0 ? { frames: Number(s[7]) } : {}),
        ...(edge.has(s[2]!) ? { edges: true } : {}),
      });
      continue;
    }
    const e = END_LINE.exec(line);
    if (e) end = { kept: Number(e[2]), total: Number(e[3]) };
  }
  return end ? { steps, ...end } : null;
}

/**
 * The script's line a traceback names, for an error whose first line names none (a wrong argument to an op: `bad
 * argument #2: …`): the first frame in the script's own file that is neither line 1 -- the prelude's, where every
 * wrapper is -- nor past the script's last line (the epilogue's call). Undefined where there is none.
 */
export function tracebackLine(message: string, script: string, lines: number): number | undefined {
  const at = new RegExp(`(?:^|\\s)${script.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}:(\\d+):`, 'g');
  for (const m of message.matchAll(at)) {
    const n = Number(m[1]);
    if (n > 1 && n <= lines) return n;
  }
  return undefined;
}

/** A diagnostic of the instrumented build, about the script: its file's name put back, its line found in the traceback where its words name none. */
function aboutScript(d: ModelDiagnostic, traced: string, script: string, lines: number): ModelDiagnostic {
  const message = d.message.split(traced).join(script);
  const line = d.line ?? tracebackLine(message, script, lines);
  return { ...d, message, ...(line !== undefined ? { line } : {}) };
}

export interface TraceOptions {
  bin: string;
  /** The script, absolute: its copy is instrumented beside it and run in its folder, as the export is. */
  input: string;
  /** The trace's GLB, under `.cache/assets/trace/`: replaced whole. */
  out: string;
  params: Readonly<Record<string, string>>;
  /**
   * The script's text to trace, as the caller read it -- the file's now by default. The server traces a text and asks
   * its faces of that same text: a save between the two must not give one script's steps another's polygons.
   */
  source?: string;
  cap?: number;
  hint?: string;
  now?: () => number;
}

/** A trace built: its steps, the GLB written to `out`, the cost. */
export interface TraceBuilt {
  answer: TraceAnswer;
  bytes: number;
}

/** Write the instrumented copy beside the script, run `go` on it, take it away again -- always. */
async function withTraced<T>(input: string, cap: number, go: (traced: string, lines: number) => Promise<T>, text?: string): Promise<T> {
  const traced = join(dirname(input), tracedName(input));
  const source = text ?? (await readFile(input, 'utf8'));
  try {
    await writeFile(traced, instrument(source, cap)); // write-ok: dot-named copy beside the script, never listed, removed after
    return await go(traced, source.split('\n').length);
  } finally {
    await rm(traced, { force: true });
  }
}

/** The failure of a trace, as `POST preview`'s: Gladius's diagnostics, its first error as one line. */
function failed(text: string, ms: number, traced: string, script: string, lines: number): TraceAnswer {
  const start = text.indexOf('{');
  let diagnostics: ModelDiagnostic[] = [];
  try {
    const read = start >= 0 ? (JSON.parse(text.slice(start)) as { diagnostics?: unknown }) : null;
    if (read && Array.isArray(read.diagnostics)) diagnostics = (read.diagnostics as RawDiagnostic[]).map(diagnosticOf);
  } catch {
    diagnostics = [];
  }
  diagnostics = diagnostics.filter((d) => d.severity !== 'info').map((d) => aboutScript(d, traced, script, lines));
  const first = diagnostics.find((d) => d.severity === 'error');
  const said = text.trim().split('\n')[0] ?? '';
  const error = first ? `${first.line !== undefined ? `line ${first.line}: ` : ''}${bareWords(first.message)}` : said ? `gladius said: ${said.split(traced).join(script)}` : 'the traced build failed';
  return { ok: false, ms, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics, error };
}

/** The trace of `input`: built to `out` (through a temp file beside it), its steps read. */
export async function buildTrace({ bin, input, out, params, source, cap = TRACE_TRIANGLES, hint, now = Date.now }: TraceOptions): Promise<TraceAnswer> {
  const began = now();
  await mkdir(dirname(out), { recursive: true });
  const tmp = join(dirname(out), `.${Math.random().toString(36).slice(2)}.glb`);
  const script = basename(input);
  try {
    return await withTraced(input, cap, async (traced, lines) => {
      const name = basename(traced);
      const ran = await run(bin, traceArgs(traced, tmp, params), { cwd: dirname(input), timeoutMs: TRACE_MS });
      const ms = now() - began;
      if ('error' in ran) {
        if (ran.error === 'missing') return { ok: false, ms, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics: [], error: 'gladius is not found on this machine', missing: 'gladius', ...(hint ? { hint } : {}) };
        return { ok: false, ms, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics: [], error: `the traced build ${ran.message}` };
      }
      const text = ran.stdout.includes('{') ? ran.stdout : ran.stdout + ran.stderr;
      if (ran.code !== 0) return failed(text, ms, name, script, lines);
      let messages: string[] = [];
      try {
        const read = JSON.parse(text.slice(text.indexOf('{'))) as { diagnostics?: { message?: unknown }[] };
        messages = (read.diagnostics ?? []).map((d) => (typeof d.message === 'string' ? d.message : ''));
      } catch {
        return failed(text, ms, name, script, lines);
      }
      const read = readSteps(messages);
      if (!read) return failed(text, ms, name, script, lines);
      const bytes = (await readFile(tmp)).byteLength;
      await rename(tmp, out);
      const dropped = read.steps.filter((s) => s.kept === false).length;
      return { ok: true, ms, steps: read.steps, triangles: read.kept, total: read.total, bytes, diagnostics: [], ...(dropped > 0 ? { capped: { cap, dropped } } : {}) };
    }, source);
  } catch (err) {
    return { ok: false, ms: now() - began, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics: [], error: (err as Error).message };
  } finally {
    await rm(tmp, { force: true });
  }
}

/**
 * The polygons of every kept step (D73 for the trace, Vibe3D's `traceFaces`): a
 * second pass, `gladius query --faces` of the same instrumented script -- `run`
 * has no faces -- asked only while a wire mode is on. Each step's boundaries as
 * flat segments, `GET model`'s reading (`readReport`).
 */
export async function traceFaces({ bin, input, params, source, cap = TRACE_TRIANGLES, now = Date.now }: Omit<TraceOptions, 'out' | 'hint'>): Promise<TraceFaces> {
  const began = now();
  try {
    return await withTraced(input, cap, async (traced) => {
      const args = ['query', '--faces', '--checks', 'none', '--format', 'json', '--instruction-limit', String(INSTRUCTIONS), ...paramArgs(params), traced];
      const ran = await run(bin, args, { cwd: dirname(input), timeoutMs: TRACE_MS });
      const ms = now() - began;
      if ('error' in ran) return { ok: false, ms, steps: {} };
      const report = readReport(ran.stdout.includes('{') ? ran.stdout : ran.stdout + ran.stderr, ms);
      const steps: Record<number, number[]> = {};
      for (const node of report.nodes) {
        const m = STEP_NODE.exec(node.name);
        if (m && m[2] === undefined) steps[Number(m[1])] = node.segments;
      }
      return { ok: report.ok, ms, steps };
    }, source);
  } catch {
    return { ok: false, ms: now() - began, steps: {} };
  }
}
