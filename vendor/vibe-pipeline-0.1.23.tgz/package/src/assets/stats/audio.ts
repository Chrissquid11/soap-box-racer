/**
 * A sound's duration, channels and sample rate, from its headers
 * (Docs/assets.md §4, "Stats are lazy"):
 *
 *   WAV    the `fmt ` chunk; the `data` chunk's size gives the duration
 *   AIFF   `COMM`: channels, frames, and the rate as an 80-bit float
 *   FLAC   STREAMINFO
 *   Ogg    Vorbis's identification header; Opus's `OpusHead` (its pre-skip);
 *          the duration from the last page's granule position, read from the
 *          file's last 64 KB -- Opus counts at 48 kHz, less the pre-skip
 *   MP3    a Xing/Info header's frame count less the LAME tag's delay and
 *          padding, or VBRI's; else a walk of the frame headers (each one's 4
 *          bytes, the frames skipped)
 *   M4A    `mvhd`'s duration; `stsd`'s `mp4a` entry for channels and rate
 *   other  `ffprobe`, when it is there
 *
 * The `ffmpeg` step reads the channel count and rate from here (`mono: 'auto'`
 * measures only a two-channel source, §3), so a 200 MB master is described
 * from its first and last few kilobytes. `ffprobe` is run through `tools.ts`'s
 * `exec` at the path `bin` gives -- the one look-up order every tool has (§3,
 * Tools). Nothing happens at module level.
 */
import { open, type FileHandle } from 'node:fs/promises';
import type { AudioStats } from '../api-types.ts';
import { readAt } from '../fs.ts';
import { extOf } from '../paths.ts';
import { exec } from '../tools.ts';
import { bare, type Bin } from './image.ts';

export type { AudioStats };

// ---------------------------------------------------------------- WAV

async function wavStats(file: FileHandle, size: number): Promise<AudioStats> {
  const riff = await readAt(file, 0, 12);
  if (riff.toString('latin1', 0, 4) !== 'RIFF' || riff.toString('latin1', 8, 12) !== 'WAVE') throw new Error('not a WAV');
  const stats: AudioStats = { format: 'wav' };
  let byteRate = 0;
  for (let at = 12; at + 8 <= size; ) {
    const head = await readAt(file, at, 8);
    const id = head.toString('latin1', 0, 4);
    const length = head.readUInt32LE(4);
    if (id === 'fmt ') {
      const fmt = await readAt(file, at + 8, 16);
      stats.channels = fmt.readUInt16LE(2);
      stats.sampleRate = fmt.readUInt32LE(4);
      byteRate = fmt.readUInt32LE(8);
    } else if (id === 'data') {
      // A file still being written may say more than it holds.
      const bytes = Math.min(length, size - at - 8);
      if (byteRate > 0) stats.duration = bytes / byteRate;
      break;
    }
    at += 8 + length + (length & 1);
  }
  return stats;
}

// ---------------------------------------------------------------- AIFF

/** An 80-bit IEEE extended float, as AIFF stores its sample rate. */
function extended(b: Buffer, at: number): number {
  const exponent = b.readUInt16BE(at) & 0x7fff;
  const sign = b[at]! & 0x80 ? -1 : 1;
  const mantissa = b.readUInt32BE(at + 2) * 2 ** 32 + b.readUInt32BE(at + 6);
  if (exponent === 0 && mantissa === 0) return 0;
  return sign * mantissa * 2 ** (exponent - 16383 - 63);
}

async function aiffStats(file: FileHandle, size: number): Promise<AudioStats> {
  const form = await readAt(file, 0, 12);
  const type = form.toString('latin1', 8, 12);
  if (form.toString('latin1', 0, 4) !== 'FORM' || (type !== 'AIFF' && type !== 'AIFC')) throw new Error('not an AIFF');
  for (let at = 12; at + 8 <= size; ) {
    const head = await readAt(file, at, 8);
    const length = head.readUInt32BE(4);
    if (head.toString('latin1', 0, 4) === 'COMM') {
      const comm = await readAt(file, at + 8, 18);
      const channels = comm.readUInt16BE(0);
      const frames = comm.readUInt32BE(2);
      const sampleRate = extended(comm, 8);
      return { format: 'aiff', channels, sampleRate, duration: sampleRate > 0 ? frames / sampleRate : undefined };
    }
    at += 8 + length + (length & 1);
  }
  throw new Error('an AIFF with no COMM chunk');
}

// ---------------------------------------------------------------- FLAC

/** Past an ID3v2 tag at the front, if there is one. */
async function afterId3(file: FileHandle): Promise<number> {
  const h = await readAt(file, 0, 10);
  if (h.length < 10 || h.toString('latin1', 0, 3) !== 'ID3') return 0;
  const size = ((h[6]! & 0x7f) << 21) | ((h[7]! & 0x7f) << 14) | ((h[8]! & 0x7f) << 7) | (h[9]! & 0x7f);
  return 10 + size + (h[5]! & 0x10 ? 10 : 0);
}

async function flacStats(file: FileHandle): Promise<AudioStats> {
  const start = await afterId3(file);
  const h = await readAt(file, start, 4 + 4 + 34);
  if (h.toString('latin1', 0, 4) !== 'fLaC' || (h[4]! & 0x7f) !== 0) throw new Error('not a FLAC (no STREAMINFO first)');
  const s = h.subarray(8);
  const sampleRate = (s[10]! << 12) | (s[11]! << 4) | (s[12]! >> 4);
  const channels = ((s[12]! >> 1) & 0x07) + 1;
  const total = (s[13]! & 0x0f) * 2 ** 32 + s.readUInt32BE(14);
  return { format: 'flac', channels, sampleRate, duration: sampleRate > 0 && total > 0 ? total / sampleRate : undefined };
}

// ---------------------------------------------------------------- Ogg

/** The first page's packet, and its stream's serial number. */
async function oggFirst(file: FileHandle): Promise<{ serial: number; packet: Buffer }> {
  const h = await readAt(file, 0, 27 + 255);
  if (h.toString('latin1', 0, 4) !== 'OggS') throw new Error('not an Ogg');
  const segments = h[26]!;
  let length = 0;
  for (let i = 0; i < segments; i++) length += h[27 + i]!;
  return { serial: h.readUInt32LE(14), packet: await readAt(file, 27 + segments, Math.min(length, 64)) };
}

/** The granule position of the stream's last page that has one, from the last 64 KB. */
async function lastGranule(file: FileHandle, size: number, serial: number): Promise<number | undefined> {
  const from = Math.max(0, size - 64 * 1024);
  const tail = await readAt(file, from, size - from);
  for (let at = tail.lastIndexOf('OggS'); at >= 0; at = at > 0 ? tail.lastIndexOf('OggS', at - 1) : -1) {
    if (at + 27 > tail.length || tail.readUInt32LE(at + 14) !== serial) continue;
    const granule = tail.readBigInt64LE(at + 6);
    if (granule >= 0n) return Number(granule);
  }
  return undefined;
}

async function oggStats(file: FileHandle, size: number, ext: string): Promise<AudioStats> {
  const { serial, packet } = await oggFirst(file);
  const granule = await lastGranule(file, size, serial);
  if (packet[0] === 0x01 && packet.toString('latin1', 1, 7) === 'vorbis') {
    const channels = packet[11]!;
    const sampleRate = packet.readUInt32LE(12);
    return { format: 'vorbis', channels, sampleRate, duration: granule !== undefined && sampleRate > 0 ? granule / sampleRate : undefined };
  }
  if (packet.toString('latin1', 0, 8) === 'OpusHead') {
    const channels = packet[9]!;
    const preSkip = packet.readUInt16LE(10);
    // Opus decodes at 48 kHz whatever it was made from; the input rate is a note.
    return { format: 'opus', channels, sampleRate: 48000, preSkip, duration: granule !== undefined ? Math.max(0, granule - preSkip) / 48000 : undefined };
  }
  return { format: ext };
}

// ---------------------------------------------------------------- MP3

interface Mp3Frame {
  version: 1 | 2 | 2.5;
  layer: 1 | 2 | 3;
  bitrate: number;
  sampleRate: number;
  padding: number;
  channels: number;
  length: number;
  samples: number;
}

const BITRATES: Record<string, number[]> = {
  '1-1': [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448],
  '1-2': [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384],
  '1-3': [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320],
  '2-1': [0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256],
  '2-2': [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
  '2-3': [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
};
const RATES: Record<string, number[]> = { '1': [44100, 48000, 32000], '2': [22050, 24000, 16000], '2.5': [11025, 12000, 8000] };

/** An MPEG audio frame header from four bytes, or undefined if they are not one. */
function mp3Frame(b: Buffer, at: number): Mp3Frame | undefined {
  if (at + 4 > b.length || b[at] !== 0xff || (b[at + 1]! & 0xe0) !== 0xe0) return undefined;
  const v = (b[at + 1]! >> 3) & 0x03;
  const l = (b[at + 1]! >> 1) & 0x03;
  const bi = b[at + 2]! >> 4;
  const ri = (b[at + 2]! >> 2) & 0x03;
  if (v === 1 || l === 0 || bi === 0 || bi === 15 || ri === 3) return undefined;
  const version = v === 3 ? 1 : v === 2 ? 2 : 2.5;
  const layer = (4 - l) as 1 | 2 | 3;
  const bitrate = BITRATES[`${version === 1 ? 1 : 2}-${layer}`]![bi]! * 1000;
  const sampleRate = RATES[String(version)]![ri]!;
  const padding = (b[at + 2]! >> 1) & 1;
  const channels = b[at + 3]! >> 6 === 3 ? 1 : 2;
  const samples = layer === 1 ? 384 : layer === 2 || version === 1 ? 1152 : 576;
  const length = layer === 1 ? (Math.floor((12 * bitrate) / sampleRate) + padding) * 4 : Math.floor(((samples / 8) * bitrate) / sampleRate) + padding;
  return { version, layer, bitrate, sampleRate, padding, channels, length, samples };
}

async function mp3Stats(file: FileHandle, size: number): Promise<AudioStats> {
  const start = await afterId3(file);
  const head = await readAt(file, start, 4096);
  let first = -1;
  for (let i = 0; i + 4 <= head.length; i++) {
    const f = mp3Frame(head, i);
    // A real frame is followed by another, or by the end.
    if (f && (mp3Frame(head, i + f.length) || i + f.length >= head.length)) {
      first = i;
      break;
    }
  }
  if (first < 0) throw new Error('not an MP3 (no frame in its first 4 KB)');
  const f = mp3Frame(head, first)!;
  const stats: AudioStats = { format: 'mp3', channels: f.channels, sampleRate: f.sampleRate };
  // Xing/Info sits after the side information; VBRI 32 bytes in.
  const side = f.version === 1 ? (f.channels === 1 ? 17 : 32) : f.channels === 1 ? 9 : 17;
  const xing = first + 4 + side;
  const tag = head.toString('latin1', xing, xing + 4);
  if ((tag === 'Xing' || tag === 'Info') && head.readUInt32BE(xing + 4) & 0x01) {
    const flags = head.readUInt32BE(xing + 4);
    let samples = head.readUInt32BE(xing + 8) * f.samples;
    // The LAME tag after the fields the flags say are there: the encoder's delay
    // and padding, which a player drops (12 bits each, 21 bytes in).
    const lame = xing + 8 + 4 + (flags & 0x02 ? 4 : 0) + (flags & 0x04 ? 100 : 0) + (flags & 0x08 ? 4 : 0);
    if (lame + 24 <= head.length && /^[A-Za-z][A-Za-z0-9. ]{3}/.test(head.toString('latin1', lame, lame + 4))) {
      const delay = (head[lame + 21]! << 4) | (head[lame + 22]! >> 4);
      const padding = ((head[lame + 22]! & 0x0f) << 8) | head[lame + 23]!;
      if (delay + padding < samples) samples -= delay + padding;
    }
    stats.duration = samples / f.sampleRate;
    return stats;
  }
  if (head.toString('latin1', first + 36, first + 40) === 'VBRI') {
    stats.duration = (head.readUInt32BE(first + 36 + 14) * f.samples) / f.sampleRate;
    return stats;
  }
  // No header: walk the frames, four bytes each, skipping their data.
  let frames = 0;
  let samples = 0;
  for (let at = start + first; at + 4 <= size; ) {
    const frame = mp3Frame(await readAt(file, at, 4), 0);
    if (!frame || frame.length <= 0) break;
    frames++;
    samples += frame.samples;
    at += frame.length;
  }
  if (frames > 0) stats.duration = samples / f.sampleRate;
  return stats;
}

// ---------------------------------------------------------------- M4A

/** The boxes of an MP4 run within [from, to), headers read from the file: [type, payload start, end]. */
async function mp4Boxes(file: FileHandle, from: number, to: number): Promise<Array<[string, number, number]>> {
  const out: Array<[string, number, number]> = [];
  for (let at = from; at + 8 <= to; ) {
    const h = await readAt(file, at, 16);
    let size = h.readUInt32BE(0);
    const type = h.toString('latin1', 4, 8);
    let header = 8;
    if (size === 1) {
      size = Number(h.readBigUInt64BE(8));
      header = 16;
    } else if (size === 0) size = to - at;
    if (size < header) break;
    out.push([type, at + header, Math.min(at + size, to)]);
    at += size;
  }
  return out;
}

async function child(file: FileHandle, parent: [string, number, number] | undefined, type: string): Promise<[string, number, number] | undefined> {
  return parent ? (await mp4Boxes(file, parent[1], parent[2])).find(([t]) => t === type) : undefined;
}

async function m4aStats(file: FileHandle, size: number): Promise<AudioStats> {
  const top = await mp4Boxes(file, 0, size);
  const moov = top.find(([t]) => t === 'moov');
  if (!top.some(([t]) => t === 'ftyp') || !moov) throw new Error('not an MP4 (no ftyp and moov)');
  const stats: AudioStats = { format: 'm4a' };
  const mvhd = await child(file, moov, 'mvhd');
  if (mvhd) {
    const m = await readAt(file, mvhd[1], 32);
    const v1 = m[0] === 1;
    const timescale = v1 ? m.readUInt32BE(20) : m.readUInt32BE(12);
    const duration = v1 ? Number(m.readBigUInt64BE(24)) : m.readUInt32BE(16);
    if (timescale > 0) stats.duration = duration / timescale;
  }
  for (const trak of (await mp4Boxes(file, moov[1], moov[2])).filter(([t]) => t === 'trak')) {
    const stbl = await child(file, await child(file, await child(file, trak, 'mdia'), 'minf'), 'stbl');
    const stsd = await child(file, stbl, 'stsd');
    if (!stsd) continue;
    // A full box, then an entry count, then the sample entries.
    const entry = await readAt(file, stsd[1] + 8, 36);
    if (entry.toString('latin1', 4, 8) !== 'mp4a') continue;
    stats.channels = entry.readUInt16BE(24);
    stats.sampleRate = entry.readUInt32BE(32) >>> 16;
    break;
  }
  return stats;
}

// ---------------------------------------------------------------- anything else

/** `ffprobe`'s answer, or only the format when it is not on this machine (or cannot read the file). */
async function probe(absPath: string, format: string, bin: Bin): Promise<AudioStats> {
  let json: { streams?: Array<{ channels?: number; sample_rate?: string }>; format?: { duration?: string } };
  try {
    const ran = await exec(bin('ffprobe'), ['-v', 'error', '-show_entries', 'stream=channels,sample_rate:format=duration', '-of', 'json', absPath]);
    json = JSON.parse(ran.stdout) as typeof json;
  } catch {
    // No ffprobe here, or none that reads this: the format is all there is to say.
    return { format };
  }
  const stream = json.streams?.find((s) => s.channels !== undefined) ?? json.streams?.[0];
  const stats: AudioStats = { format };
  if (stream?.channels !== undefined) stats.channels = stream.channels;
  if (stream?.sample_rate !== undefined) stats.sampleRate = Number(stream.sample_rate);
  if (json.format?.duration !== undefined) stats.duration = Number(json.format.duration);
  return stats;
}

// ---------------------------------------------------------------- the front door

/** The formats read here, header-only; anything else goes to `ffprobe`. */
export const AUDIO_READ = ['wav', 'aif', 'aiff', 'flac', 'ogg', 'opus', 'mp3', 'm4a'] as const;

/** A sound's stats, by its extension. `bin` finds `ffprobe` (§3's look-up order). */
export async function audioStats(absPath: string, bin: Bin = bare): Promise<AudioStats> {
  const ext = extOf(absPath);
  if (!(AUDIO_READ as readonly string[]).includes(ext)) return probe(absPath, ext, bin);
  const file = await open(absPath, 'r');
  try {
    const size = (await file.stat()).size;
    switch (ext) {
      case 'wav':
        return await wavStats(file, size);
      case 'aif':
      case 'aiff':
        return await aiffStats(file, size);
      case 'flac':
        return await flacStats(file);
      case 'ogg':
      case 'opus':
        return await oggStats(file, size, ext);
      case 'mp3':
        return await mp3Stats(file, size);
      default:
        return await m4aStats(file, size);
    }
  } finally {
    await file.close();
  }
}
