/**
 * Is this file an unfetched Git LFS pointer, not the file (Docs/assets.md §4,
 * §5)? A clone where `git lfs install` never ran checks out every `.glb`,
 * `.png` and `.wav` as a pointer of about 130 bytes:
 *
 *   version https://git-lfs.github.com/spec/v1
 *   oid sha256:4d7a...
 *   size 12345
 *
 * For a source that is "run git lfs pull", never an export attempted; for an
 * export the game would fail to parse at boot, which the dev server's `load`
 * hook says by name instead.
 *
 * Header-only: a file is opened only when it is `POINTER_MAX` bytes or less, so
 * the index's walk peeks at the small files and reads nothing big. Nothing
 * happens at module level.
 */
import { open, stat } from 'node:fs/promises';

/** A pointer is about 130 bytes; anything over this is a real file. */
export const POINTER_MAX = 200;

const SPEC = 'version https://git-lfs.github.com/spec/v1';

/** Do these bytes start as an LFS pointer does? */
export function isPointer(bytes: Uint8Array): boolean {
  if (bytes.length < SPEC.length || bytes.length > POINTER_MAX) return false;
  for (let i = 0; i < SPEC.length; i++) if (bytes[i] !== SPEC.charCodeAt(i)) return false;
  return true;
}

/** A pointer's object id and the size of the file it stands for; undefined if it is not one. */
export function parsePointer(bytes: Uint8Array): { oid: string; size: number } | undefined {
  if (!isPointer(bytes)) return undefined;
  const text = new TextDecoder().decode(bytes);
  const oid = /^oid sha256:([0-9a-f]{64})$/m.exec(text);
  const size = /^size (\d+)$/m.exec(text);
  if (!oid || !size) return undefined;
  return { oid: oid[1]!, size: Number(size[1]) };
}

/** Is the file at `absPath` a pointer? Opens it only if it is small enough to be one. */
export async function peekPointer(absPath: string, size?: number): Promise<boolean> {
  const bytes = size ?? (await stat(absPath)).size;
  if (bytes > POINTER_MAX || bytes < SPEC.length) return false;
  const file = await open(absPath, 'r');
  try {
    const buffer = Buffer.alloc(bytes);
    const { bytesRead } = await file.read(buffer, 0, bytes, 0);
    return isPointer(buffer.subarray(0, bytesRead));
  } finally {
    await file.close();
  }
}
