/**
 * A model's numbers, from its JSON alone (Docs/assets.md §4, "Stats are
 * lazy"): meshes, primitives, vertices and triangles (accessor counts, a Draco
 * mesh's included -- its accessors still carry them), materials, textures and
 * their images (embedded bytes, or the URI they name), animations (name,
 * duration from the sampler inputs' max, channels), skins, the extensions used,
 * whether Draco, meshopt or KTX2 is in it, and bounds from `POSITION`'s
 * min/max.
 *
 * Header-only: a `.glb` costs its first 20 bytes and its JSON chunk, never the
 * binary chunk, so a 200 MB model is described in a few kilobytes. The GLB
 * parser is `parts.ts`'s, which reads a source's parts with the same code.
 * Nothing happens at module level.
 */
import { open, readFile } from 'node:fs/promises';
import { readAt } from '../fs.ts';
import type { ModelStats } from '../api-types.ts';
import { glbHeadLength, glbJson, type GltfJson } from '../parts.ts';

export type { ModelStats };

/** The numbers, from a glTF's JSON: pure, for a `.glb`'s JSON chunk and a `.gltf` alike. */
export function statsFromJson(json: GltfJson, format: 'glb' | 'gltf'): ModelStats {
  const accessors = json.accessors ?? [];
  let primitives = 0;
  let vertices = 0;
  let triangles = 0;
  let min: [number, number, number] | undefined;
  let max: [number, number, number] | undefined;
  for (const mesh of json.meshes ?? []) {
    for (const primitive of mesh.primitives ?? []) {
      primitives++;
      const position = primitive.attributes?.POSITION;
      const p = position !== undefined ? accessors[position] : undefined;
      if (p) {
        vertices += p.count;
        if (p.min && p.max && p.min.length >= 3 && p.max.length >= 3) {
          min = min ? [Math.min(min[0], p.min[0]!), Math.min(min[1], p.min[1]!), Math.min(min[2], p.min[2]!)] : [p.min[0]!, p.min[1]!, p.min[2]!];
          max = max ? [Math.max(max[0], p.max[0]!), Math.max(max[1], p.max[1]!), Math.max(max[2], p.max[2]!)] : [p.max[0]!, p.max[1]!, p.max[2]!];
        }
      }
      if ((primitive.mode ?? 4) !== 4) continue;
      const indices = primitive.indices !== undefined ? accessors[primitive.indices] : undefined;
      const corners = indices ? indices.count : (p?.count ?? 0);
      triangles += Math.floor(corners / 3);
    }
  }
  const bufferViews = json.bufferViews ?? [];
  const images = (json.images ?? []).map((image) => {
    const out: { name?: string; uri?: string; bytes?: number; mimeType?: string } = {};
    if (image.name !== undefined) out.name = image.name;
    if (image.mimeType !== undefined) out.mimeType = image.mimeType;
    if (image.uri !== undefined) {
      if (/^data:/i.test(image.uri)) {
        const comma = image.uri.indexOf(',');
        const header = image.uri.slice(5, comma);
        out.mimeType ??= header.split(';')[0] || undefined;
        const payload = image.uri.slice(comma + 1);
        out.bytes = header.endsWith(';base64') ? Math.floor((payload.replace(/=+$/, '').length * 3) / 4) : payload.length;
        if (out.mimeType === undefined) delete out.mimeType;
      } else out.uri = image.uri;
    } else if (image.bufferView !== undefined) {
      const view = bufferViews[image.bufferView];
      if (view?.byteLength !== undefined) out.bytes = view.byteLength;
    }
    return out;
  });
  const animations = (json.animations ?? []).map((animation, i) => {
    let duration = 0;
    for (const sampler of animation.samplers ?? []) {
      const input = accessors[sampler.input];
      const end = input?.max?.[0];
      if (end !== undefined && end > duration) duration = end;
    }
    return { name: animation.name ?? `animation ${i}`, duration, channels: animation.channels?.length ?? 0 };
  });
  const extensionsUsed = [...(json.extensionsUsed ?? [])];
  const stats: ModelStats = {
    format,
    meshes: json.meshes?.length ?? 0,
    primitives,
    vertices,
    triangles,
    materials: json.materials?.length ?? 0,
    textures: json.textures?.length ?? 0,
    images,
    animations,
    skins: (json.skins ?? []).map((skin) => ({ joints: skin.joints?.length ?? 0 })),
    extensionsUsed,
    draco: extensionsUsed.includes('KHR_draco_mesh_compression'),
    meshopt: extensionsUsed.includes('EXT_meshopt_compression') || extensionsUsed.includes('KHR_meshopt_compression'),
    ktx2: extensionsUsed.includes('KHR_texture_basisu'),
  };
  if (min && max) stats.bounds = { min, max };
  return stats;
}

/**
 * A `.glb`'s header and JSON chunk, and nothing after them: what `glbJson`
 * parses. Its own reader (`parts.ts`) is pure; this is the one place a `.glb`
 * is opened for its head -- here, and by the `pack-gltf` step. A file cut short
 * comes back short, and `glbJson` says so ("a GLB cut short").
 */
export async function glbHead(absPath: string): Promise<Uint8Array> {
  const file = await open(absPath, 'r');
  try {
    const length = glbHeadLength(await readAt(file, 0, 20));
    if (length === undefined) throw new Error(`${absPath}: not a GLB (no glTF header and JSON chunk)`);
    return await readAt(file, 0, length);
  } finally {
    await file.close();
  }
}

/** A model's stats: a `.glb` from its JSON chunk, a `.gltf` from its file. */
export async function modelStats(absPath: string): Promise<ModelStats> {
  if (/\.gltf$/i.test(absPath)) return statsFromJson(JSON.parse(await readFile(absPath, 'utf8')) as GltfJson, 'gltf');
  return statsFromJson(glbJson(await glbHead(absPath)), 'glb');
}
