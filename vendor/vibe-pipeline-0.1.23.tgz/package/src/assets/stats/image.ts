/**
 * An image's size, alpha and power of two, from its header (Docs/assets.md §4,
 * "Stats are lazy"):
 *
 *   PNG    IHDR, and a tRNS chunk before the first IDAT
 *   JPEG   its SOF marker (never alpha)
 *   WebP   VP8, VP8L (its alpha bit) or VP8X (its flags and canvas)
 *   KTX2   its header (size, mip levels) and data format descriptor (alpha)
 *   AVIF   `ispe` in meta/iprp/ipco; alpha when an `auxC` names the alpha plane
 *   SVG    its `viewBox`, else its width and height
 *   PSD    the 26-byte header, and Version Info (resource 0x0421): is the
 *          composite real, which the `flatten` step asks (§3)
 *   KRA    `mergedimage.png`'s IHDR, inflated out of the zip only that far
 *   TIFF, XCF  through sharp, else `magick identify`
 *
 * A 50 MB `.psd` costs a few hundred bytes to describe. Only what each format
 * needs is read, at offsets; `sharp` is imported inside the function that uses
 * it, and `magick` is run through `tools.ts`'s `exec` at the path `bin` gives --
 * the one look-up order every tool has (§3, Tools). Nothing happens at module
 * level.
 */
import { open, type FileHandle } from 'node:fs/promises';
import type { ImageStats } from '../api-types.ts';
import { readAt } from '../fs.ts';
import { extOf } from '../paths.ts';
import { exec } from '../tools.ts';
import { readZipEntryHead } from '../zip.ts';

export type { ImageStats };

async function withFile<T>(absPath: string, use: (file: FileHandle, size: number) => Promise<T>): Promise<T> {
  const file = await open(absPath, 'r');
  try {
    return await use(file, (await file.stat()).size);
  } finally {
    await file.close();
  }
}

const isPow2 = (n: number): boolean => n > 0 && (n & (n - 1)) === 0;

function finish(stats: ImageStats): ImageStats {
  if (stats.width !== undefined && stats.height !== undefined) stats.pow2 = isPow2(stats.width) && isPow2(stats.height);
  return stats;
}

// ---------------------------------------------------------------- PNG

const PNG_SIG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];

/** A PNG's IHDR, and whether a tRNS chunk comes before the pixels, from its first bytes. */
export function pngStats(head: Uint8Array): ImageStats {
  const b = Buffer.from(head.buffer, head.byteOffset, head.byteLength);
  if (b.length < 33 || PNG_SIG.some((v, i) => b[i] !== v) || b.toString('latin1', 12, 16) !== 'IHDR') throw new Error('not a PNG');
  const width = b.readUInt32BE(16);
  const height = b.readUInt32BE(20);
  const colourType = b[25]!;
  let alpha = colourType === 4 || colourType === 6;
  for (let at = 8; !alpha && at + 8 <= b.length; ) {
    const length = b.readUInt32BE(at);
    const type = b.toString('latin1', at + 4, at + 8);
    if (type === 'IDAT' || type === 'IEND') break;
    if (type === 'tRNS') alpha = true;
    at += 12 + length;
  }
  return finish({ format: 'png', width, height, alpha });
}

// ---------------------------------------------------------------- JPEG

async function jpegStats(file: FileHandle, size: number): Promise<ImageStats> {
  let at = 2;
  while (at + 4 <= size) {
    const head = await readAt(file, at, 9);
    if (head[0] !== 0xff) throw new Error('not a JPEG (lost the marker chain)');
    const marker = head[1]!;
    if (marker === 0xff) {
      at += 1; // fill byte
      continue;
    }
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) {
      at += 2;
      continue;
    }
    // SOF0..SOF15, but DHT (C4), JPG (C8) and DAC (CC).
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
      return finish({ format: 'jpeg', height: head.readUInt16BE(5), width: head.readUInt16BE(7), alpha: false });
    }
    if (marker === 0xd9 || marker === 0xda) break;
    at += 2 + head.readUInt16BE(2);
  }
  throw new Error('a JPEG with no frame header');
}

// ---------------------------------------------------------------- WebP

/** A WebP's size and alpha from its first 30 bytes: the image reader's, and `PUT thumb`'s check of what a tab sent. */
export function webpStats(b: Buffer): ImageStats {
  if (b.toString('latin1', 0, 4) !== 'RIFF' || b.toString('latin1', 8, 12) !== 'WEBP') throw new Error('not a WebP');
  const chunk = b.toString('latin1', 12, 16);
  const d = 20;
  if (chunk === 'VP8 ') {
    // A key frame: 3-byte tag, the start code 9d 01 2a, then 14-bit sizes.
    return finish({ format: 'webp', width: b.readUInt16LE(d + 6) & 0x3fff, height: b.readUInt16LE(d + 8) & 0x3fff, alpha: false });
  }
  if (chunk === 'VP8L') {
    if (b[d] !== 0x2f) throw new Error('a WebP whose VP8L signature is wrong');
    const bits = b.readUInt32LE(d + 1);
    return finish({ format: 'webp', width: (bits & 0x3fff) + 1, height: ((bits >>> 14) & 0x3fff) + 1, alpha: ((bits >>> 28) & 1) === 1 });
  }
  if (chunk === 'VP8X') {
    const flags = b[d]!;
    const width = (b[d + 4]! | (b[d + 5]! << 8) | (b[d + 6]! << 16)) + 1;
    const height = (b[d + 7]! | (b[d + 8]! << 8) | (b[d + 9]! << 16)) + 1;
    return finish({ format: 'webp', width, height, alpha: (flags & 0x10) !== 0 });
  }
  throw new Error(`a WebP with a first chunk of ${chunk}`);
}

// ---------------------------------------------------------------- KTX2

const KTX2_ID = [0xab, 0x4b, 0x54, 0x58, 0x20, 0x32, 0x30, 0xbb, 0x0d, 0x0a, 0x1a, 0x0a];

/** Alpha from a KTX2's data format descriptor: a sample on the alpha channel, by colour model. */
function ktxAlpha(dfd: Buffer): boolean | undefined {
  if (dfd.length < 28) return undefined;
  const model = dfd[12]!;
  const blockSize = dfd.readUInt16LE(10);
  const samples = Math.max(0, Math.floor((Math.min(blockSize, dfd.length - 4) - 24) / 16));
  const channels: number[] = [];
  for (let s = 0; s < samples; s++) channels.push(dfd[4 + 24 + s * 16 + 3]! & 0x0f);
  if (model === 166) return channels.some((c) => c === 3 || c === 5); // UASTC: RGBA, RRRG
  if (model === 163 || model === 1) return channels.includes(15); // ETC1S, RGBSDA: the alpha channel
  return undefined;
}

async function ktx2Stats(file: FileHandle): Promise<ImageStats> {
  const h = await readAt(file, 0, 80);
  if (h.length < 80 || KTX2_ID.some((v, i) => h[i] !== v)) throw new Error('not a KTX2');
  const stats: ImageStats = { format: 'ktx2', width: h.readUInt32LE(20), height: Math.max(1, h.readUInt32LE(24)), mips: Math.max(1, h.readUInt32LE(40)) };
  const dfdOffset = h.readUInt32LE(48);
  const dfdLength = h.readUInt32LE(52);
  if (dfdLength > 0 && dfdLength < 4096) {
    const alpha = ktxAlpha(await readAt(file, dfdOffset, dfdLength));
    if (alpha !== undefined) stats.alpha = alpha;
  }
  return finish(stats);
}

// ---------------------------------------------------------------- AVIF

/** The boxes of an ISO-BMFF run, as [type, payload start, end] within `b`. */
function boxes(b: Buffer, from: number, to: number): Array<[string, number, number]> {
  const out: Array<[string, number, number]> = [];
  for (let at = from; at + 8 <= to; ) {
    let size = b.readUInt32BE(at);
    const type = b.toString('latin1', at + 4, at + 8);
    let header = 8;
    if (size === 1) {
      if (at + 16 > to) break;
      size = Number(b.readBigUInt64BE(at + 8));
      header = 16;
    } else if (size === 0) size = to - at;
    if (size < header) break;
    out.push([type, at + header, Math.min(at + size, to)]);
    at += size;
  }
  return out;
}

function avifStats(b: Buffer): ImageStats {
  const top = boxes(b, 0, b.length);
  const ftyp = top.find(([t]) => t === 'ftyp');
  if (!ftyp) throw new Error('not an AVIF (no ftyp box)');
  const meta = top.find(([t]) => t === 'meta');
  if (!meta) throw new Error('an AVIF whose meta box is past the first 64 KB');
  // `meta` is a full box: four bytes of version and flags first.
  const iprp = boxes(b, meta[1] + 4, meta[2]).find(([t]) => t === 'iprp');
  const ipco = iprp ? boxes(b, iprp[1], iprp[2]).find(([t]) => t === 'ipco') : undefined;
  if (!ipco) throw new Error('an AVIF with no item properties');
  const properties = boxes(b, ipco[1], ipco[2]);
  const ispe = properties.find(([t]) => t === 'ispe');
  const alpha = properties.some(([t, s, e]) => t === 'auxC' && b.toString('latin1', s + 4, e).includes('urn:mpeg:mpegB:cicp:systems:auxiliary:alpha'));
  // The first `ispe` is the primary image's in what encoders write.
  return finish({ format: 'avif', width: ispe ? b.readUInt32BE(ispe[1] + 4) : undefined, height: ispe ? b.readUInt32BE(ispe[1] + 8) : undefined, alpha });
}

// ---------------------------------------------------------------- SVG

function svgStats(text: string): ImageStats {
  const tag = /<svg\b[^>]*>/i.exec(text)?.[0];
  if (!tag) throw new Error('not an SVG (no <svg> in its first 4 KB)');
  const attr = (name: string): string | undefined => new RegExp(`\\s${name}\\s*=\\s*["']([^"']*)["']`, 'i').exec(tag)?.[1];
  const viewBox = attr('viewBox')?.trim().split(/[\s,]+/).map(Number);
  if (viewBox && viewBox.length === 4 && viewBox.every(Number.isFinite)) return finish({ format: 'svg', width: viewBox[2], height: viewBox[3], alpha: true });
  const size = (v: string | undefined): number | undefined => {
    const m = v ? /^\s*([\d.]+)\s*(px)?\s*$/.exec(v) : null;
    return m ? Number(m[1]) : undefined;
  };
  return finish({ format: 'svg', width: size(attr('width')), height: size(attr('height')), alpha: true });
}

// ---------------------------------------------------------------- PSD

/** Version Info (0x0421)'s `hasRealMergedData`, walking the image resources by their headers. */
async function psdVersionInfo(file: FileHandle, size: number): Promise<boolean | undefined> {
  const modeLength = (await readAt(file, 26, 4)).readUInt32BE(0);
  const sectionAt = 30 + modeLength;
  const sectionLength = (await readAt(file, sectionAt, 4)).readUInt32BE(0);
  const end = Math.min(size, sectionAt + 4 + sectionLength);
  for (let at = sectionAt + 4; at + 12 <= end; ) {
    const head = await readAt(file, at, 8 + 256);
    if (head.toString('latin1', 0, 4) !== '8BIM') return undefined;
    const id = head.readUInt16BE(4);
    const nameLength = head[6]!;
    const nameBytes = (1 + nameLength + 1) & ~1; // a Pascal string padded to even
    const lengthAt = at + 6 + nameBytes;
    const length = (await readAt(file, lengthAt, 4)).readUInt32BE(0);
    if (id === 0x0421) {
      const data = await readAt(file, lengthAt + 4, Math.min(length, 5));
      return data.length >= 5 ? data[4] !== 0 : undefined;
    }
    at = lengthAt + 4 + ((length + 1) & ~1);
  }
  return undefined;
}

async function psdStats(file: FileHandle, size: number): Promise<ImageStats> {
  const h = await readAt(file, 0, 26);
  if (h.length < 26 || h.toString('latin1', 0, 4) !== '8BPS') throw new Error('not a PSD');
  const channels = h.readUInt16BE(12);
  const mode = h.readUInt16BE(24);
  const stats: ImageStats = { format: h.readUInt16BE(4) === 2 ? 'psb' : 'psd', height: h.readUInt32BE(14), width: h.readUInt32BE(18) };
  // Extra channels past the colour ones are alpha (or spot) channels.
  if (mode === 3) stats.alpha = channels >= 4;
  else if (mode === 1) stats.alpha = channels >= 2;
  else if (mode === 4) stats.alpha = channels >= 5;
  const composite = await psdVersionInfo(file, size);
  if (composite !== undefined) stats.composite = composite;
  return finish(stats);
}

/**
 * Does this `.psd` carry Photoshop's own composite (Maximize Compatibility, the
 * default)? Undefined when the file has no Version Info to say: the `flatten`
 * step then flattens the layers itself.
 */
export async function psdComposite(absPath: string): Promise<boolean | undefined> {
  return withFile(absPath, async (file, size) => (await psdStats(file, size)).composite);
}

// ---------------------------------------------------------------- through a tool

/** The path to run for a tool: what the look found (`Job.bin`, the server's tools), or its bare name. */
export type Bin = (tool: string) => string;

/** A tool by its bare name: the readers' default, where no look was made. */
export const bare: Bin = (tool) => tool;

/** TIFF and XCF: sharp when it reads the format, else `magick identify`. */
async function toolStats(absPath: string, format: string, bin: Bin): Promise<ImageStats> {
  try {
    const sharp = (await import('sharp')).default;
    const meta = await sharp(absPath).metadata();
    if (meta.width && meta.height) return finish({ format, width: meta.width, height: meta.height, alpha: meta.hasAlpha === true });
  } catch {
    // sharp has no reader for it (XCF): magick's turn.
  }
  const [w, h, a] = (await exec(bin('magick'), ['identify', '-format', '%w %h %A', `${absPath}[0]`])).stdout.trim().split(/\s+/);
  return finish({ format, width: Number(w), height: Number(h), alpha: a !== undefined && !/^(false|undefined)$/i.test(a) });
}

// ---------------------------------------------------------------- the front door

/** An image's stats, by its extension, the header checked against it. `bin` finds `magick` (§3's look-up order). */
export async function imageStats(absPath: string, bin: Bin = bare): Promise<ImageStats> {
  const ext = extOf(absPath);
  switch (ext) {
    case 'png':
      return withFile(absPath, async (file) => pngStats(await readAt(file, 0, 64 * 1024)));
    case 'jpg':
    case 'jpeg':
      return withFile(absPath, (file, size) => jpegStats(file, size));
    case 'webp':
      return withFile(absPath, async (file) => webpStats(await readAt(file, 0, 30)));
    case 'ktx2':
      return withFile(absPath, (file) => ktx2Stats(file));
    case 'avif':
      return withFile(absPath, async (file) => avifStats(await readAt(file, 0, 64 * 1024)));
    case 'svg':
      return withFile(absPath, async (file) => svgStats((await readAt(file, 0, 4096)).toString('utf8')));
    case 'psd':
    case 'psb':
      return withFile(absPath, (file, size) => psdStats(file, size));
    case 'kra':
      return { ...pngStats(await readZipEntryHead(absPath, 'mergedimage.png', 4096)), format: 'kra' };
    case 'tif':
    case 'tiff':
      return toolStats(absPath, 'tiff', bin);
    case 'xcf':
      return toolStats(absPath, 'xcf', bin);
    default:
      throw new Error(`no image reader for .${ext}`);
  }
}
