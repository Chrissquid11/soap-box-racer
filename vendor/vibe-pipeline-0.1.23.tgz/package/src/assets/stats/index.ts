/**
 * A file's stats, by its extension (Docs/assets.md §4, "Stats are lazy"): the
 * one call `GET stats` makes, read the first time a client asks and cached
 * under the file's content hash.
 *
 * An unfetched LFS pointer is said first and read no further: its "header" is
 * a line of text, and every reader would call it a corrupt file. A format no
 * reader knows is `other`, with no numbers -- never an error.
 *
 * Which reader takes a file: every extension a kind ships (`KINDS`, the one
 * list), and the source formats only a reader knows -- a reader's
 * capabilities, not a shipping list. The two tools a reader may run, `magick`
 * and `ffprobe`, are `STATS_NEEDS`: looked for with the steps' needs, and
 * found through `bin`, as every tool is (§3, Tools). Nothing happens at module
 * level.
 */
import { stat } from 'node:fs/promises';
import type { FileStats, StatsKind } from '../api-types.ts';
import { KINDS } from '../kinds.ts';
import { extOf } from '../paths.ts';
import { FFPROBE, MAGICK, type Need } from '../tools.ts';
import { AUDIO_READ, audioStats } from './audio.ts';
import { modelStats } from './glb.ts';
import { bare, imageStats, type Bin } from './image.ts';
import { peekPointer } from './lfs.ts';

export type { FileStats, StatsKind };

/** The tools a reader runs when it must: looked for once, with the steps' -- by the dev server's `GET stats`, in phase 2 (the CLI reads no stats). */
export const STATS_NEEDS: readonly Need[] = [MAGICK, FFPROBE];

const MODEL = new Set<string>(KINDS.models.ext);
/** What ships as a picture, and the layered and tool-read sources besides. */
const IMAGE = new Set<string>([...KINDS.textures.ext, ...KINDS.icons.ext, 'psd', 'psb', 'kra', 'tif', 'tiff', 'xcf']);
/** What ships as a sound, the masters read here, and two ffprobe knows. */
const AUDIO = new Set<string>([...KINDS.sfx.ext, ...AUDIO_READ, 'wma', 'aac']);

/** Which reader a file goes to, by its extension. */
export function statsKind(path: string): StatsKind {
  const ext = extOf(path);
  if (MODEL.has(ext)) return 'model';
  if (IMAGE.has(ext)) return 'image';
  if (AUDIO.has(ext)) return 'audio';
  return 'other';
}

/** A file's stats. `bin` is the path of a tool as it was found (`magick`, `ffprobe`); its bare name by default. */
export async function readStats(absPath: string, bin: Bin = bare): Promise<FileStats> {
  const kind = statsKind(absPath);
  if (await peekPointer(absPath, (await stat(absPath)).size)) return { kind, pointer: true };
  switch (kind) {
    case 'model':
      return { kind, stats: await modelStats(absPath) };
    case 'image':
      return { kind, stats: await imageStats(absPath, bin) };
    case 'audio':
      return { kind, stats: await audioStats(absPath, bin) };
    default:
      return { kind };
  }
}
