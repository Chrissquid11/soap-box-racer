/**
 * A project's own asset kinds (`vibe({ kinds })`, `ProjectKind`), read before Vite runs: `vibe assets`
 * -- at install, and at the start of `dev`, `typecheck` and `build` -- writes the generated files, a
 * project kind's glob file among them, before any Vite server exists to hand the plugin its options.
 *
 * **One source: the config.** `vibe()` puts the options it was given on the config it returns, under
 * `vibe` (a key Vite ignores); this loads the project's `vite.config.ts` through Vite's own
 * `loadConfigFromFile` -- the file bundled and evaluated as Vite would, no server made, no plugin run
 * -- and reads `config.vibe?.kinds`. The cost is that bundle and evaluation, a few hundred
 * milliseconds and the plugins' modules loaded (each defines only, `config.ts` §4), once a command. A
 * project with no `vite.config.ts`, or whose config is not `vibe()`'s, has no kinds of its own. Its tool
 * folders (`vibe({ tools })`) are read the same way, for the skill pages beside its tools (`skills/install.ts`).
 */
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { checkKinds, type ProjectKinds } from './kinds.ts';

/** What the project's `vite.config.ts` gave `vibe()`, as it kept it under `vibe`; undefined with no config, or one not `vibe()`'s. */
export async function projectOptions(root: string): Promise<{ kinds?: ProjectKinds; tools?: string | readonly string[] } | undefined> {
  const file = join(root, 'vite.config.ts');
  if (!existsSync(file)) return undefined;
  // Vite, the project's peer, loaded only here: a command that never reads the config never loads it.
  const { loadConfigFromFile } = await import('vite');
  const loaded = await loadConfigFromFile({ command: 'serve', mode: 'development' }, file, root, 'silent');
  return (loaded?.config as { vibe?: { kinds?: ProjectKinds; tools?: string | readonly string[] } } | undefined)?.vibe;
}

/** The project's kinds, checked (`checkKinds` throws on a bad one); none without a `vite.config.ts`. */
export async function projectKinds(root: string): Promise<ProjectKinds> {
  return checkKinds((await projectOptions(root))?.kinds);
}

/** The project's own editor tools' folders, relative to its root, as `vibe({ tools })` says them: `src/tools` when not said. */
export const toolDirs = (tools: string | readonly string[] | undefined): readonly string[] => (typeof tools === 'string' ? [tools] : (tools ?? ['src/tools']));
