/**
 * Every asset's uid (Docs/asset-ids.md §1, rules 1, 2, 6 and 7): found where
 * it is kept, stamped where there is none, made one asset's where two have one,
 * and the keys of the references to them kept true.
 *
 *   a data file   a `.prefab`, `.material`, `.scene`, a level, a project's own
 *                 data kind's file (a pack's materials too): its top-level
 *                 `"uid"`, written as its first member in the file's own layout
 *                 (`json-spans.ts`' `withUid`)
 *   a sourced     a source's record, `<stem>.export.json` (or the source's own,
 *     asset       `<name>.export.json`): its `"uid"` -- the asset is the export,
 *                 the record its source's, so a record with no export yet has
 *                 one too. A source with no record gets its uid with its first
 *                 export (`export.ts`): no record is made for it here
 *   a loose file  a file that ships as delivered -- under a registry kind's
 *                 folder in `src/assets/` or a pack, a key, no record claiming
 *                 it: `<file>.uid` beside it, the uid and a newline
 *
 * **When** -- only these (rule 6): `vibe assets` run by hand (before the keys
 * are generated), the dev server's start and its watcher (a file added, a data
 * file or a record changed: `vite.ts`), `vibe export` (not `--check`, `--dry`).
 * Never the `vibe assets --no-stamp` that `vibe typecheck`, `vibe build` and a
 * postinstall run, nor a build's plugin, `vibe test` or `export --check`: they
 * read (`scanUids`) and say (`checks/uids.ts`).
 *
 * **Duplicates** (rule 7): two files with one uid -- a Finder copy, a `.uid`
 * copied with its file, a merge -- the original keeps it (`keeperOrder`: the
 * file git tracks unchanged; else the one the watcher did not just see added;
 * else the older by birth time; else the first by path), the other is stamped
 * anew, said once. The editor's own copies are written with a uid of their own
 * (`server.ts`), so they never come here.
 *
 * **The repair pass** (rules 3 and 6): after the stamps, every data file's
 * `{ uid, key }` references whose key is not their uid's asset's now rewritten,
 * and every bare key at a place a reference goes given its uid (`repair.ts`:
 * `repairRefs`, `upgradeRefs`) -- the file in its own layout, said once.
 *
 * **What it never touches**: a file that does not parse (said, left), a record
 * that is no record (its source's status says so), and a path the caller hands
 * in as `skip` -- by default the project-relative paths in `VIBE_STAMP_SKIP`,
 * comma-separated: a file someone has open elsewhere, left to be stamped later.
 *
 * Synchronous, as the key generation it runs before is.
 */
import { existsSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { caseKey } from '@vibe/engine/case-key';
import { skipped, walkSync, writeAtomicSync } from './fs.ts';
import { topUid, withUid } from './json-spans.ts';
import { DATA_KINDS, KINDS, KIND_NAMES, ROOTS, isDataKind, kindDef, type KindName, type ProjectKinds } from './kinds.ts';
import { dirName, joinPath, keyOf, locate, recordStem, splitName, twin } from './paths.ts';
import { exportAsIn, excludedBy, parseRecord, recordText } from './record.ts';
import { keyFieldsIn } from './key-fields.ts';
import { repairRefs, upgradeRefs, type OwnKeyFields, type Rewritten, type Upgraded } from './repair.ts';
import { isSidecar, isUid, newUid, sidecarFile, sidecarOf, sidecarText, sidecarUid } from './uid.ts';
import { uncommitted } from './uncommitted.ts';

/** Where an asset's uid is kept: its own JSON, its source's record, or a sidecar beside it. */
export type Holder = 'json' | 'record' | 'sidecar';

/** One asset as the scan found it. */
export interface AssetUid {
  /** The file the uid is kept in -- the data file, the record -- or, for a sidecar, the loose file it is beside. Relative to the root. */
  path: string;
  holder: Holder;
  /** `models`, `prefabs`, a project kind's name. */
  kind: string;
  /** Its key, a pack's with its prefix (`reef:props/coral`); undefined for a record whose export would not ship (`_`). */
  key?: string;
  /** The pack it is in. */
  pack?: string;
  /** Its uid, when the file holds one that is one. */
  uid?: string;
  /** The file holds a `"uid"` that is no uid: stamped anew. */
  bad?: boolean;
  /** The file does not parse -- or parses, but to no JSON object (`noObject`): left alone, said, never stamped. */
  unread?: boolean;
  /** Read, and valid JSON, but its top level no object (an array, a number): no place for a uid. */
  noObject?: boolean;
  /** Out of the build (a record saying `"include": false`): stamped, but in no index -- its key is a loose file's, if any. */
  out?: boolean;
}

/** What the scan found. */
export interface UidScan {
  assets: AssetUid[];
  /** Sidecars whose file is not there, relative to the root. */
  orphans: string[];
}

/** A sidecar's uid by the key of the file it is beside (`kind\0key`): what a record with none adopts. */
type Sidecars = Map<string, { file: string; uid: string }>;

const read = (root: string, path: string): string | undefined => {
  try {
    return readFileSync(join(root, path), 'utf8');
  } catch {
    return undefined;
  }
};

/** Is there a file at `path` (relative to the root)? */
const isFileAt = (root: string, path: string): boolean => {
  try {
    return statSync(join(root, path)).isFile();
  } catch {
    return false;
  }
};

/** The packs: folders under `packs/`, none starting with `_` or `.`. */
function packsOf(root: string): string[] {
  const dir = join(root, ROOTS.packs.dir);
  if (!existsSync(dir)) return [];
  return readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.isDirectory() && !skipped(e.name))
    .map((e) => e.name)
    .sort();
}

const parses = (text: string): boolean => {
  try {
    JSON.parse(text);
    return true;
  } catch {
    return false;
  }
};

/** A data file's asset: its uid read from its JSON. */
function dataAsset(root: string, path: string, kind: string, key: string, pack?: string): AssetUid {
  const text = read(root, path);
  const uid = text === undefined ? null : topUid(text);
  const base: AssetUid = { path, holder: 'json', kind, key, ...(pack !== undefined ? { pack } : {}) };
  if (uid === null) return { ...base, unread: true, ...(text !== undefined && parses(text) ? { noObject: true } : {}) };
  if (uid === undefined) return base;
  return isUid(uid) ? { ...base, uid } : { ...base, bad: true };
}

/** The slot a key is in, across kinds: `kind\0key`. */
const slot = (kind: string, key: string): string => `${kind}\0${caseKey(key)}`;

/**
 * Every asset of the project with where its uid is kept, and whether it has one -- read only. Data files
 * (the data kinds, a project's own, a pack's materials), every source's record under `AssetsSource/` (but
 * `reference/`), and the loose files: a key under a registry kind's folder that no record in the build claims.
 * And the sidecars whose file is gone.
 */
export function scanUids(root: string, kinds: ProjectKinds = {}): UidScan {
  const assets: AssetUid[] = [];
  const boot = ROOTS.boot.dir;
  // Data files: the data kinds in src/assets/, a project's own.
  for (const kind of DATA_KINDS) {
    const def = kindDef(kind);
    for (const rel of walkSync(join(root, boot, def.dir))) {
      const { ext } = splitName(rel.slice(rel.lastIndexOf('/') + 1));
      if (!def.ext.includes(ext)) continue;
      assets.push(dataAsset(root, `${boot}/${def.dir}/${rel}`, kind, caseKey(rel.slice(0, -(ext.length + 1)))));
    }
  }
  for (const [name, kind] of Object.entries(kinds)) {
    for (const rel of walkSync(join(root, boot, kind.dir))) {
      const { ext } = splitName(rel.slice(rel.lastIndexOf('/') + 1));
      if (!kind.ext.includes(ext)) continue;
      assets.push(dataAsset(root, `${boot}/${kind.dir}/${rel}`, name, caseKey(rel.slice(0, -(ext.length + 1)))));
    }
  }
  // The records: each a sourced asset, its export's key the twin of its stem -- or of the stem it ships `as`.
  const claimed = new Set<string>();
  const source = ROOTS.source.dir;
  for (const rel of walkSync(join(root, source))) {
    const path = `${source}/${rel}`;
    const name = path.slice(path.lastIndexOf('/') + 1);
    const stem = recordStem(name);
    if (!stem) continue;
    const where = locate(path);
    if (!where || where.reference || !where.kind || isDataKind(where.kind)) continue;
    const text = read(root, path);
    if (text === undefined) continue;
    let uid: string | undefined;
    let bad = false;
    try {
      const { uid: had, ...rest } = JSON.parse(text) as { uid?: unknown };
      if (had !== undefined) {
        if (isUid(had)) uid = had;
        else bad = true;
      }
      parseRecord(JSON.stringify(rest));
    } catch {
      // A record that is no record: its source's status says so; nothing here writes it.
      assets.push({ path, holder: 'record', kind: where.kind, unread: true, ...(where.pack !== undefined ? { pack: where.pack } : {}) });
      continue;
    }
    // A source's own record (`crate.blend.export.json`: a source named `crate.blend` beside it) its source's stem; a
    // stem's (`crate.export.json`, and `big.crate.export.json` for `big.crate.lua`) its stem -- as the index decides.
    const own = isFileAt(root, joinPath(dirName(path), stem));
    const exportStem = exportAsIn(text) ?? (own ? splitName(stem).stem : stem);
    const dir = twin(dirName(path));
    const def = kindDef(where.kind);
    const ext = (where.pack !== undefined ? (def.packExt ?? def.ext) : def.ext)[0]!;
    const key = dir === undefined ? undefined : keyOf(joinPath(dir, `${exportStem}.${ext}`));
    const out = excludedBy(text);
    if (key !== undefined && !out) claimed.add(slot(where.kind, key));
    assets.push({ path, holder: 'record', kind: where.kind, ...(key !== undefined ? { key } : {}), ...(where.pack !== undefined ? { pack: where.pack } : {}), ...(uid !== undefined ? { uid } : {}), ...(bad ? { bad } : {}), ...(out ? { out } : {}) });
  }
  // The shipped files of the registry kinds: a key no record claims is a loose file, its uid in a sidecar.
  const orphans: string[] = [];
  const shipRoots: Array<{ dir: string; pack?: string }> = [{ dir: boot }, ...packsOf(root).map((pack) => ({ dir: `${ROOTS.packs.dir}/${pack}`, pack }))];
  for (const { dir, pack } of shipRoots) {
    for (const kind of KIND_NAMES) {
      const def = kindDef(kind);
      if (pack !== undefined && !def.inPacks) continue;
      const files = walkSync(join(root, dir, def.dir));
      for (const rel of files) {
        const path = `${dir}/${def.dir}/${rel}`;
        if (isSidecar(rel)) {
          if (!existsSync(join(root, sidecarFile(path)))) orphans.push(path);
          continue;
        }
        if (isDataKind(kind)) {
          // A pack's materials: data files, as the boot set's.
          if (pack === undefined) continue;
          const { ext } = splitName(rel.slice(rel.lastIndexOf('/') + 1));
          if (def.ext.includes(ext)) assets.push(dataAsset(root, path, kind, `${caseKey(pack)}:${caseKey(rel.slice(0, -(ext.length + 1)))}`, pack));
          continue;
        }
        const key = keyOf(path);
        if (key === undefined || claimed.has(slot(kind, key))) continue;
        const text = existsSync(join(root, sidecarOf(path))) ? read(root, sidecarOf(path)) : undefined;
        const uid = text === undefined ? undefined : sidecarUid(text);
        assets.push({ path, holder: 'sidecar', kind, key, ...(pack !== undefined ? { pack } : {}), ...(uid !== undefined ? { uid } : {}), ...(text !== undefined && uid === undefined ? { bad: true } : {}) });
      }
    }
  }
  return { assets, orphans: orphans.sort() };
}

/** The sidecars beside exports a record claims: a uid a loose file had before a source came for it. */
function claimedSidecars(root: string, scan: UidScan): Sidecars {
  const out: Sidecars = new Map();
  const wanted = new Set(scan.assets.filter((a) => a.holder === 'record' && a.uid === undefined && !a.unread && a.key !== undefined).map((a) => slot(a.kind, a.key!)));
  if (wanted.size === 0) return out;
  for (const dir of [ROOTS.boot.dir, ...packsOf(root).map((p) => `${ROOTS.packs.dir}/${p}`)]) {
    for (const kind of KIND_NAMES) {
      if (isDataKind(kind)) continue;
      const def = kindDef(kind);
      for (const rel of walkSync(join(root, dir, def.dir))) {
        if (!isSidecar(rel)) continue;
        const file = `${dir}/${def.dir}/${sidecarFile(rel)}`;
        const key = keyOf(file);
        if (key === undefined || !wanted.has(slot(kind, key))) continue;
        const uid = sidecarUid(read(root, `${dir}/${def.dir}/${rel}`) ?? '');
        if (uid !== undefined) out.set(slot(kind, key), { file, uid });
      }
    }
  }
  return out;
}

/** The file an asset's uid is kept in: the data file, the record, the sidecar. */
export const holderFile = (a: AssetUid): string => (a.holder === 'sidecar' ? sidecarOf(a.path) : a.path);

const byPath = (x: AssetUid, y: AssetUid): number => (x.path < y.path ? -1 : x.path > y.path ? 1 : 0);

/**
 * The uid each asset keeps once duplicates are settled: of the files that have one uid, the first by `order`
 * keeps it -- by default the path's (the index's, which has no git to ask) -- the rest are `dupes`.
 */
function firstHolders(assets: readonly AssetUid[], order: (x: AssetUid, y: AssetUid) => number = byPath): { keeps: Map<string, AssetUid>; dupes: AssetUid[] } {
  const keeps = new Map<string, AssetUid>();
  const dupes: AssetUid[] = [];
  for (const a of [...assets].sort(order)) {
    if (a.uid === undefined) continue;
    if (keeps.has(a.uid)) dupes.push(a);
    else keeps.set(a.uid, a);
  }
  return { keeps, dupes };
}

/**
 * Rule 7's order for files that have one uid (Docs/asset-ids.md §1): the file git tracks unchanged first (an
 * untracked or changed one is the copy); else the one not `added` just now (the dev server's watcher: the path
 * whose `add` fired is the copy); else the older by birth time; else the path. `fresh` is git's new and changed
 * files (`uncommitted`), undefined without git: then no file is told by it.
 */
export function keeperOrder(root: string, fresh: ReadonlySet<string> | undefined, added: ReadonlySet<string> = new Set()): (x: AssetUid, y: AssetUid) => number {
  const births = new Map<string, number>();
  const birth = (file: string): number => {
    let ms = births.get(file);
    if (ms === undefined) {
      try {
        ms = statSync(join(root, file)).birthtimeMs;
      } catch {
        ms = Infinity;
      }
      // A file system with no birth time answers 0 (or its change time on some): then the path decides.
      births.set(file, ms);
    }
    return ms;
  };
  return (x, y) => {
    const fx = holderFile(x);
    const fy = holderFile(y);
    if (fresh !== undefined) {
      const d = Number(fresh.has(fx)) - Number(fresh.has(fy));
      if (d !== 0) return d;
    }
    const a = Number(added.has(fx) || added.has(x.path)) - Number(added.has(fy) || added.has(y.path));
    if (a !== 0) return a;
    const bx = birth(fx);
    const by = birth(fy);
    if (bx > 0 && by > 0 && bx !== by) return bx < by ? -1 : 1;
    return byPath(x, y);
  };
}

/** Each uid's key now (a pack's with its prefix), as the repair pass resolves a reference's: its keeper's, by `order` (the path's by default). */
export function uidKeys(scan: UidScan, order?: (x: AssetUid, y: AssetUid) => number): Map<string, string> {
  const keys = new Map<string, string>();
  for (const [uid, a] of firstHolders(scan.assets, order).keeps) if (a.key !== undefined) keys.set(uid, a.key);
  return keys;
}

/** One row of the index: an asset's kind (the pipeline's name), its key, and its kind's type (`Model`) -- what a key field's `key('Model')` names it by. */
export interface UidRow {
  kind: string;
  key: string;
  type?: string;
}

/** The index the generated `uids.ts` and a pack's `uids.json` are written from: each uid once (the first holder's), in the build. */
export interface UidIndex {
  /** The boot set's: uid -> kind and key. */
  boot: Map<string, UidRow>;
  /** Each pack's, its keys without the prefix: pack -> uid -> kind and key. */
  packs: Map<string, Map<string, UidRow>>;
}

/** The type of a kind: a registry or data kind's (`KINDS`), a project kind's own; none for a name neither knows. */
const typeOf = (kind: string, kinds: ProjectKinds): string | undefined => (Object.hasOwn(KINDS, kind) ? kindDef(kind as KindName).type : kinds[kind]?.type);

/** The index of a scan: every asset with a uid, a key and in the build, a duplicate's uid its first holder's alone; each row with its kind's type. */
export function uidIndex(scan: UidScan, kinds: ProjectKinds = {}): UidIndex {
  const out: UidIndex = { boot: new Map(), packs: new Map() };
  const { keeps } = firstHolders(scan.assets);
  for (const [uid, a] of [...keeps].sort(([x], [y]) => (x < y ? -1 : 1))) {
    if (a.key === undefined || a.out) continue;
    const type = typeOf(a.kind, kinds);
    const row = (key: string): UidRow => ({ kind: a.kind, key, ...(type !== undefined ? { type } : {}) });
    if (a.pack === undefined) out.boot.set(uid, row(a.key));
    else {
      let rows = out.packs.get(a.pack);
      if (!rows) out.packs.set(a.pack, (rows = new Map()));
      rows.set(uid, row(a.key.slice(a.key.indexOf(':') + 1)));
    }
  }
  return out;
}

/** The project-relative paths `VIBE_STAMP_SKIP` names: left unstamped, by whoever stamps. */
export function stampSkip(env: NodeJS.ProcessEnv = process.env): Set<string> {
  return new Set((env.VIBE_STAMP_SKIP ?? '').split(',').map((s) => s.trim()).filter((s) => s !== ''));
}

export interface StampOptions {
  /** Paths (relative to the root) never written: by default `VIBE_STAMP_SKIP`'s. */
  skip?: ReadonlySet<string>;
  /** Where each thing done is said: the terminal by default. */
  say?: (line: string) => void;
  /** A uid's maker: `newUid` (a test hands in its own). */
  make?: () => string;
  /** Paths (relative to the root) the dev server's watcher saw added since the last stamp: of two files with one uid, the copy (rule 7). */
  added?: ReadonlySet<string>;
  /** Git's new and changed files (`uncommitted`), for rule 7; asked of git when a uid is found twice, and not given. */
  fresh?: ReadonlySet<string>;
}

/** What a stamp did, each a project-relative path. */
export interface StampResult {
  /** Given a uid it did not have. */
  stamped: string[];
  /** Given a new one: it had another asset's (rule 7), or one that is none. */
  restamped: string[];
  /** A sidecar's uid taken into a record that came to claim its file, the sidecar removed. */
  adopted: string[];
  /** References' keys rewritten (rule 6). */
  repaired: string[];
  /** Bare keys made `{ uid, key }` (rule 3: what a person wrote by hand, given its uid). */
  upgraded: string[];
  /** Wanted a uid, and on the skip list. */
  skipped: string[];
  /** Files that do not parse: left as they are. */
  unread: string[];
}

/** Each unreadable file said once a process: the watcher stamps on every event. */
const unreadSaid = new Set<string>();

/**
 * Every asset given a uid that has none, every duplicate made one asset's, every stale reference repaired --
 * each file written only when it changes, whole (`writeAtomicSync`), in its own layout. See the header.
 */
export function stampUids(root: string, kinds: ProjectKinds = {}, options: StampOptions = {}): StampResult {
  const skip = options.skip ?? stampSkip();
  const say = options.say ?? ((line: string) => console.log(line));
  const make = options.make ?? (() => newUid());
  const result: StampResult = { stamped: [], restamped: [], adopted: [], repaired: [], upgraded: [], skipped: [], unread: [] };
  const scan = scanUids(root, kinds);
  const taken = new Set(scan.assets.flatMap((a) => (a.uid !== undefined ? [a.uid] : [])));
  const fresh = (): string => {
    let uid = make();
    while (taken.has(uid)) uid = make();
    taken.add(uid);
    return uid;
  };
  const sidecars = claimedSidecars(root, scan);
  // Rule 7: of the files with one uid, the keeper by keeperOrder -- git asked only when there is a duplicate.
  let order = byPath;
  if (firstHolders(scan.assets).dupes.length > 0) order = keeperOrder(root, options.fresh ?? uncommitted(root), options.added);
  const { keeps, dupes } = firstHolders(scan.assets, order);
  const dupeOf = new Map(dupes.map((a) => [a, keeps.get(a.uid!)!.path]));

  /** The uid written where `a` keeps it; false when it could not be (a file that is no JSON object). */
  const write = (a: AssetUid, uid: string): boolean => {
    if (a.holder === 'sidecar') {
      writeAtomicSync(join(root, sidecarOf(a.path)), sidecarText(uid));
      return true;
    }
    const text = read(root, a.path);
    if (text === undefined) return false;
    let next: string | null;
    if (a.holder === 'record') {
      // A record keeps the pipeline's one shape (`recordText`): the uid after `include`, before the options.
      try {
        const { uid: _had, ...rest } = JSON.parse(text) as { uid?: unknown };
        void _had;
        next = recordText({ ...parseRecord(JSON.stringify(rest)), uid });
      } catch {
        next = null;
      }
    } else next = withUid(text, uid);
    if (next === null) return false;
    if (next !== text) writeAtomicSync(join(root, a.path), next);
    return true;
  };

  for (const a of scan.assets) {
    const where = a.holder === 'sidecar' ? sidecarOf(a.path) : a.path;
    if (a.unread) {
      result.unread.push(a.path);
      if (!unreadSaid.has(a.path)) {
        unreadSaid.add(a.path);
        say(a.noObject ? `[assets] ${a.path} is no JSON object: it has no uid until it is one` : `[assets] ${a.path} does not parse: it has no uid until it does`);
      }
      continue;
    }
    const dupe = dupeOf.get(a);
    if (a.uid !== undefined && dupe === undefined) continue;
    if (skip.has(a.path) || skip.has(where)) {
      result.skipped.push(a.path);
      continue;
    }
    // A record come for a loose file: the uid its sidecar held is the asset's still, and the sidecar goes.
    const adopt = a.holder === 'record' && a.uid === undefined && a.key !== undefined ? sidecars.get(slot(a.kind, a.key)) : undefined;
    if (adopt && !skip.has(sidecarOf(adopt.file)) && write(a, adopt.uid)) {
      rmSync(join(root, sidecarOf(adopt.file)), { force: true });
      result.adopted.push(a.path);
      say(`[assets] ${a.path} takes the uid ${adopt.uid} of ${sidecarOf(adopt.file)}, which goes: its file is that source's export now`);
      continue;
    }
    const uid = fresh();
    if (!write(a, uid)) {
      result.unread.push(a.path);
      continue;
    }
    if (dupe !== undefined) {
      result.restamped.push(a.path);
      say(`[assets] ${a.path} had the uid of ${dupe} (${a.uid}), which keeps it: a copy, stamped anew (${uid})`);
    } else if (a.bad) {
      result.restamped.push(a.path);
      say(`[assets] ${where} held a uid that is none: stamped anew (${uid})`);
    } else result.stamped.push(a.path);
  }
  if (result.stamped.length > 0) say(`[assets] ${result.stamped.length === 1 ? `a uid stamped on ${result.stamped[0]}` : `uids stamped on ${result.stamped.length} assets: ${result.stamped.join(', ')}`}`);

  // The repair pass: every data file's references held to their uids' assets now, and a bare key given its uid.
  const after = result.stamped.length + result.restamped.length + result.adopted.length > 0 ? scanUids(root, kinds) : scan;
  const upgradedSaid: string[] = [];
  for (const r of refsPlan(root, after, order, skip, ownKeyFields(root, kinds))) {
    writeAtomicSync(join(root, r.path), r.text);
    if (r.changed.length > 0) {
      result.repaired.push(r.path);
      say(`[assets] ${r.path}: ${r.changed.map((c) => `${c.from} -> ${c.to}`).join(', ')} (moved; found by uid)`);
    }
    if (r.upgraded.length > 0) {
      result.upgraded.push(r.path);
      upgradedSaid.push(`${r.path} (${r.upgraded.length})`);
    }
  }
  if (upgradedSaid.length > 0) say(`[assets] keys given their uids (Docs/asset-ids.md §1, rule 3): ${upgradedSaid.join(', ')}`);
  return result;
}

/**
 * A game's own key fields (`key-fields.ts`, read from its `src/`) and each key type's kind name -- the table's and
 * the project's own (`Sfx` is `sfx`, `Tilemap` `tilemaps`): what lets the repair pass give a bare key in one its uid.
 */
export function ownKeyFields(root: string, kinds: ProjectKinds = {}): OwnKeyFields {
  const names = new Map<string, string>();
  for (const name of KIND_NAMES) names.set(kindDef(name).type, name);
  for (const [name, k] of Object.entries(kinds)) names.set(k.type, name);
  return { fields: keyFieldsIn(root), kindOf: (type) => names.get(type) };
}

/** One data file the repair pass would rewrite: its path, its text before and after, and what changed in it. */
export interface RefsRewrite {
  path: string;
  before: string;
  text: string;
  changed: Rewritten[];
  upgraded: Upgraded[];
}

/**
 * What a pass is held to (`planRefs`' `only`): the references by these uids, and the bare keys of these slots
 * (`refsTo` makes it) -- the rest of every file left as it is.
 */
export interface RefsFilter {
  uids: ReadonlySet<string>;
  slots: ReadonlySet<string>;
}

/**
 * The assets kept in `paths` -- project-relative, the files a move takes (a data file, a record, a loose file beside
 * its sidecar) -- as a pass's filter: their uids, and their keys as they are now (a bare key naming one is upgraded
 * before the move, while the index still knows it there).
 */
export function refsTo(root: string, kinds: ProjectKinds, paths: Iterable<string>): RefsFilter {
  const set = new Set(paths);
  const uids = new Set<string>();
  const slots = new Set<string>();
  for (const a of scanUids(root, kinds).assets) {
    if (!set.has(a.path)) continue;
    if (a.uid !== undefined) uids.add(a.uid);
    if (a.key !== undefined) slots.add(slot(a.kind, a.key));
  }
  return { uids, slots };
}

/** The repair pass over `scan`'s data files, written nowhere: each file whose references it would rewrite, or give their uids. */
function refsPlan(root: string, scan: UidScan, order: (x: AssetUid, y: AssetUid) => number, skip: ReadonlySet<string>, own: OwnKeyFields, only?: RefsFilter, within?: ReadonlySet<string>): RefsRewrite[] {
  const keys = uidKeys(scan, order);
  const bySlot = new Map<string, string>();
  for (const [uid, a] of firstHolders(scan.assets, order).keeps) if (a.key !== undefined && a.pack === undefined) bySlot.set(slot(a.kind, a.key), uid);
  const out: RefsRewrite[] = [];
  for (const a of scan.assets) {
    if (a.holder !== 'json' || a.unread || skip.has(a.path) || (within !== undefined && !within.has(a.path))) continue;
    const text = read(root, a.path);
    if (text === undefined) continue;
    const { text: repaired, changed } = repairRefs(text, (uid) => (only === undefined || only.uids.has(uid) ? keys.get(uid) : undefined));
    const uidOf = (kind: string, key: string): string | undefined => {
      const at = slot(kind, key);
      return only === undefined || only.slots.has(at) ? bySlot.get(at) : undefined;
    };
    // A pack's own file is left bare: a key in it may be the pack's own (its textures), which the boot set's index cannot tell.
    const { text: next, upgraded } = a.pack === undefined ? upgradeRefs(repaired, a.kind, uidOf, own) : { text: repaired, upgraded: [] };
    if (next !== text) out.push({ path: a.path, before: text, text: next, changed, upgraded });
  }
  return out;
}

/**
 * The repair pass as the dev server's move runs it at once (Docs/asset-ids.md §4): every data file whose references
 * would be rewritten -- a stale key to its uid's asset's now, a bare key given its uid -- with its text before and
 * after, written nowhere: the caller writes them (its own writes, which its watcher knows) and keeps the befores for
 * the move's undo. Stamps nothing; `skip` (by default `VIBE_STAMP_SKIP`'s paths) and `leave` are never planned. `only`
 * (`refsTo`) holds it to the references to what moves: a move never upgrades an unrelated bare key project-wide;
 * `within` to those files alone (`PUT prefab`'s, the one it writes).
 */
export function planRefs(root: string, kinds: ProjectKinds = {}, options: { skip?: ReadonlySet<string>; leave?: ReadonlySet<string>; only?: RefsFilter; within?: ReadonlySet<string> } = {}): RefsRewrite[] {
  const skip = new Set([...(options.skip ?? stampSkip()), ...(options.leave ?? [])]);
  return refsPlan(root, scanUids(root, kinds), byPath, skip, ownKeyFields(root, kinds), options.only, options.within);
}

/** One data file naming an asset that would go: its path and the keys it names them by. */
export interface Referrer {
  path: string;
  names: string[];
}

/**
 * The data files that name any of `going` -- project-relative paths, whole families (the server's `familyOf`: a
 * source with its record and exports): data files, records, loose files -- by uid (a `{ uid, key }` whose uid is one of theirs, its key stale or not) or by a bare key
 * where a reference goes (Docs/asset-ids.md §4: a Delete is refused while something still names it). Those among
 * `going` are no referrers: deleted together, nothing is left broken.
 */
export function referrersOf(root: string, kinds: ProjectKinds, going: readonly string[]): Referrer[] {
  const scan = scanUids(root, kinds);
  const paths = new Set(going);
  const gone = scan.assets.filter((a) => paths.has(a.path));
  const uids = new Map<string, string>();
  const slots = new Map<string, string>();
  for (const a of gone) {
    if (a.uid !== undefined && a.key !== undefined) uids.set(a.uid, a.key);
    if (a.key !== undefined) slots.set(slot(a.kind, a.key), a.key);
  }
  if (uids.size === 0 && slots.size === 0) return [];
  const own = ownKeyFields(root, kinds);
  const out: Referrer[] = [];
  for (const a of scan.assets) {
    if (a.holder !== 'json' || a.unread || paths.has(a.path)) continue;
    const text = read(root, a.path);
    if (text === undefined) continue;
    const names = new Set<string>();
    repairRefs(text, (uid) => {
      const key = uids.get(uid);
      if (key !== undefined) names.add(key);
      return undefined;
    });
    // A bare key where a reference goes: upgradeRefs finds each place, here for the asking alone.
    if (a.pack === undefined) {
      upgradeRefs(text, a.kind, (kind, key) => {
        const named = slots.get(slot(kind, key));
        if (named !== undefined) names.add(named);
        return undefined;
      }, own);
    }
    if (names.size > 0) out.push({ path: a.path, names: [...names].sort() });
  }
  return out.sort((x, y) => (x.path < y.path ? -1 : 1));
}

/**
 * Every uid of the project replaced by a new one -- data files, records, sidecars -- and every reference to
 * one in a data file with it (`vibe new`: a project copied from the template must share no uid with another
 * made from it). Answers how many were replaced.
 */
export function restampUids(root: string, kinds: ProjectKinds = {}, make: () => string = () => newUid()): number {
  const scan = scanUids(root, kinds);
  const map = new Map<string, string>();
  for (const a of scan.assets) {
    if (a.uid === undefined || a.unread) continue;
    let next = map.get(a.uid);
    if (next === undefined) map.set(a.uid, (next = make()));
  }
  if (map.size === 0) return 0;
  const swap = (text: string): string => text.replace(/uid:\/\/[a-z2-7]{13}/g, (uid) => map.get(uid) ?? uid);
  const files = new Set<string>();
  for (const a of scan.assets) {
    if (a.unread) continue;
    if (a.holder === 'sidecar') {
      if (a.uid !== undefined) files.add(sidecarOf(a.path));
    } else files.add(a.path);
  }
  for (const file of files) {
    const text = read(root, file);
    if (text === undefined) continue;
    const next = swap(text);
    if (next !== text) writeAtomicSync(join(root, file), next);
  }
  return map.size;
}
