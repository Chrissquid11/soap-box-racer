/**
 * The file-system helpers the pipeline's Node side shares, each written once
 * (Docs/assets.md §3 "What a recipe must guarantee", §4):
 *
 *   exists / isFile    is something there (lstat: a dangling link is there)
 *   readAt             bytes at an offset, short only at the end of the file
 *   writeAtomic        whole or not at all: a dot-named temp file, then a rename
 *                      (writeAtomicSync the same, for `keys.ts`); a mode given,
 *                      and an fsync before the rename asked for (the Code card's save)
 *   isTempName         is a file name one of those temp files' (the watcher skips them)
 *   moveFile           a rename -- or, across volumes (`EXDEV`), a copy beside
 *                      the destination under a dot-name, then a rename: the
 *                      destination is never half a file and never missing
 *   sha1, hashFile     a content hash, streamed; a parts scanner fed the same chunks
 *   sortedObject       keys in order, so a JSON file written from it diffs well
 *   walk, walkSync     the files under a folder, as the globs see them (a link
 *                      followed: a linked folder walked, a dangling link skipped)
 *   skipped            the names those walks (and the packs' folders) skip
 *
 * Every temp name starts with `.` and ends in `.tmp`, which `IGNORED` hides:
 * the index and the watcher never take one for an asset.
 *
 * Node's own modules only, and nothing at module level: the Vite config and
 * `vibe assets` load this for free.
 */
import { createHash, randomBytes } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, readdirSync, realpathSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { chmod, cp, lstat, mkdir, open, readdir, realpath, rename, rm, stat, writeFile, type FileHandle } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import type { Scanner } from './parts.ts';

/** An error's `code` (`ENOENT`), if it has one. */
export function code(err: unknown): string | undefined {
  return err && typeof err === 'object' && 'code' in err ? String((err as { code: unknown }).code) : undefined;
}

/** Is anything at `abs` (a file, a folder, a link)? Missing is false; any other error is thrown. */
export async function exists(abs: string): Promise<boolean> {
  try {
    await lstat(abs);
    return true;
  } catch (err) {
    if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') return false;
    throw err;
  }
}

/** Is `abs` a file (a link followed)? Anything unreadable is not. */
export async function isFile(abs: string): Promise<boolean> {
  try {
    return (await stat(abs)).isFile();
  } catch {
    return false;
  }
}

/** `length` bytes from `position`, fewer only where the file ends: a short read is read again. */
export async function readAt(file: FileHandle, position: number, length: number): Promise<Buffer> {
  const buffer = Buffer.alloc(Math.max(0, length));
  let done = 0;
  while (done < length) {
    const { bytesRead } = await file.read(buffer, done, length - done, position + done);
    if (bytesRead === 0) break;
    done += bytesRead;
  }
  return done === length ? buffer : buffer.subarray(0, done);
}

/** A dot-named, unique temp path beside `file`: `.<name>.<8 hex>.tmp`. */
export function tempBeside(file: string): string {
  return join(dirname(file), `.${file.slice(Math.max(file.lastIndexOf('/'), file.lastIndexOf('\\')) + 1)}.${randomBytes(4).toString('hex')}.tmp`);
}

/** Is a file's name (no folder) one `tempBeside` makes: a watcher's event for it is a write on its way, not a file. */
export const isTempName = (name: string): boolean => /^\..+\.[0-9a-f]{8}\.tmp$/.test(name);

/** How `writeAtomic` writes: the file's mode (its permission bits), and an fsync before the rename. */
export interface AtomicOptions {
  /** The new file's mode (`& 0o7777`): an existing file's kept by passing its `stat().mode`. */
  mode?: number;
  /** Flushed to the disk before the rename: a crash leaves the old file or the new one, never an empty one. */
  sync?: boolean;
}

/**
 * A file written whole or not at all: a dot-named temp file beside it, then a
 * rename over it. A rename is atomic within a folder, so a reader -- the
 * watcher, another process -- sees the old file or the new one. The temp file
 * is made new (`wx`), given `options.mode`, flushed when `options.sync`; on any
 * failure it is taken away (but one that was there already, never ours).
 */
export async function writeAtomic(file: string, data: string | Uint8Array, options: AtomicOptions = {}): Promise<void> {
  const tmp = tempBeside(file);
  try {
    await writeFile(tmp, data, { flag: 'wx' });
    if (options.mode !== undefined) await chmod(tmp, options.mode & 0o7777);
    if (options.sync) {
      const handle = await open(tmp, 'r+');
      try {
        await handle.sync();
      } finally {
        await handle.close();
      }
    }
    await renameOver(tmp, file);
  } catch (err) {
    if (code(err) !== 'EEXIST') await rm(tmp, { force: true });
    throw err;
  }
}

/** The errors a rename over a file gives on Windows while another process has it open a moment (a reader, the virus scan). */
const BUSY = new Set(['EPERM', 'EACCES', 'EBUSY']);

/**
 * `rename(from, to)`, over what is at `to`. On Windows a file another handle holds open -- a reader of it, Defender
 * scanning it -- refuses to be replaced for a moment (EPERM, EACCES, EBUSY): tried again, waiting a little longer
 * each time, for about 2 s in all, before the error is let through -- else the write is lost (an index missing a
 * conversation). Elsewhere a rename is atomic and never refused so: one try.
 */
export async function renameOver(from: string, to: string, platform: NodeJS.Platform = process.platform, tries = 10): Promise<void> {
  for (let n = 1; ; n++) {
    try {
      await rename(from, to);
      return;
    } catch (err) {
      if (platform !== 'win32' || n >= tries || !BUSY.has(code(err) ?? '')) throw err;
      await new Promise((done) => setTimeout(done, 20 * n));
    }
  }
}

/** `writeAtomic`, synchronously: for `keys.ts`, whose generated files Vite may read mid-burst. Its folder made first. */
export function writeAtomicSync(file: string, data: string | Uint8Array): void {
  mkdirSync(dirname(file), { recursive: true });
  const tmp = tempBeside(file);
  writeFileSync(tmp, data);
  try {
    renameSync(tmp, file);
  } catch (err) {
    rmSync(tmp, { force: true });
    throw err;
  }
}

/**
 * `from` moved to `to` (a file or a folder), its folder made, whatever file is
 * at `to` replaced. A rename; across volumes (`EXDEV`: `.cache/` a symlink to
 * another disk) a copy beside `to` under a dot-name, renamed over it, then
 * `from` removed -- so `to` is never missing and never half written.
 */
export async function moveFile(from: string, to: string): Promise<void> {
  await mkdir(dirname(to), { recursive: true });
  try {
    await renameOver(from, to);
  } catch (err) {
    if (code(err) !== 'EXDEV') throw err;
    const tmp = tempBeside(to);
    try {
      await cp(from, tmp, { recursive: true, errorOnExist: true, force: false });
      await renameOver(tmp, to);
    } catch (copyErr) {
      await rm(tmp, { recursive: true, force: true });
      throw copyErr;
    }
    await rm(from, { recursive: true, force: true });
  }
}

/** sha1 of some bytes or text: for identity, as git uses it, not security. */
export function sha1(data: string | Uint8Array): string {
  return createHash('sha1').update(data).digest('hex');
}

/** What one streamed read found: the content's hash, and its parts if a scanner was fed. */
export interface FileHash {
  sha1: string;
  size: number;
  parts?: string[];
  /** The scanner could not read the source (a `.gltf` that is not JSON). */
  partsError?: string;
}

/** A file read once, in chunks: each to the hash and to the scanner. Nothing is held whole but what the scanner keeps. */
export async function hashFile(absPath: string, scanner?: Scanner): Promise<FileHash> {
  const hash = createHash('sha1');
  let size = 0;
  for await (const chunk of createReadStream(absPath, { highWaterMark: 64 * 1024 })) {
    const bytes = chunk as Buffer;
    hash.update(bytes);
    size += bytes.length;
    scanner?.feed(bytes);
  }
  const out: FileHash = { sha1: hash.digest('hex'), size };
  if (scanner) {
    try {
      out.parts = await scanner.done();
    } catch (err) {
      out.partsError = (err as Error).message;
    }
  }
  return out;
}

/** An object of these entries with its keys sorted: a JSON file written from it diffs line by line. */
export function sortedObject<T>(entries: Iterable<readonly [string, T]>): Record<string, T> {
  return Object.fromEntries([...entries].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)));
}

/** The rule both walks keep, and the packs' folders: a name starting with `_` (it never ships) or `.` (the OS's) is skipped, file or folder. */
export const skipped = (name: string): boolean => name.startsWith('_') || name.startsWith('.');

const byName = (a: { name: string }, b: { name: string }): number => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0);

/** True the first time `real` is added to `seen`. */
function once(seen: Set<string>, real: string): boolean {
  if (seen.has(real)) return false;
  seen.add(real);
  return true;
}

/** Every file under `dir`, relative to it with `/`, sorted; `_` and `.` names skipped. None for a folder not there. */
export async function walk(dir: string, base = dir, linked = new Set<string>()): Promise<string[]> {
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch (err) {
    if (code(err) === 'ENOENT') return [];
    throw err;
  }
  const out: string[] = [];
  for (const entry of entries.sort(byName)) {
    if (skipped(entry.name)) continue;
    const full = join(dir, entry.name);
    let folder = entry.isDirectory();
    if (entry.isSymbolicLink()) {
      // Followed, as Vite's globs follow it: a linked folder is walked, a dangling link is nothing.
      // A linked folder is walked once a walk: a link back up is no loop.
      try {
        folder = (await stat(full)).isDirectory();
        if (folder && !once(linked, await realpath(full))) continue;
      } catch {
        continue;
      }
    }
    if (folder) out.push(...(await walk(full, base, linked)));
    else out.push(full.slice(base.length + 1).split('\\').join('/'));
  }
  return out;
}

/** `walk`, synchronously: for `keys.ts`, which runs before every build and must not be awaited there. */
export function walkSync(dir: string, base = dir, linked = new Set<string>()): string[] {
  if (!existsSync(dir)) return [];
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true }).sort(byName)) {
    if (skipped(entry.name)) continue;
    const full = join(dir, entry.name);
    let folder = entry.isDirectory();
    if (entry.isSymbolicLink()) {
      try {
        folder = statSync(full).isDirectory();
        if (folder && !once(linked, realpathSync(full))) continue;
      } catch {
        continue;
      }
    }
    if (folder) out.push(...walkSync(full, base, linked));
    else out.push(full.slice(base.length + 1).split('\\').join('/'));
  }
  return out;
}
