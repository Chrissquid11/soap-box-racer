/**
 * `GET model` (Docs/modeler.md §3, M4): what the kernel says of a Gladius
 * script that its `.glb` cannot -- which triangles were one polygon, the
 * vertices, edges and faces as the kernel stores them, and a failed build's
 * diagnostics with the lines they name -- from one `gladius query --faces
 * --checks none --format json`, run with the source's resolved parameters.
 *
 * - **`--checks none`**: the default checks pose a rig at every sample of
 *   every action (Vibe3D D111), a minute on a heavy rig; this wants the mesh.
 * - **Its own envelope read, not its exit code**: a failed build exits 1 and
 *   still prints the envelope, `ok: false` and its diagnostics -- the answer.
 * - **Segments, not loops**: each node's face loops become its polygons'
 *   boundary edges as flat `x, y, z, x, y, z`, an edge two faces share drawn
 *   once -- by where its ends are, so a seam the kernel keeps as two vertices
 *   is one line on screen -- while the counts go by index, as the kernel
 *   stores them (Vibe3D's `faces.ts`, D73).
 * - **A line for every diagnostic that names one**: `script_span.line`, or a
 *   Lua syntax error's `crate.lua:12:` read off the front of its message.
 *
 * `readReport` is pure (`model-query.test.ts`); `queryModel` runs Gladius.
 */
import { dirname } from 'node:path';
import type { ModelAnswer, ModelDiagnostic, ModelNode } from './api-types.ts';
import { luaLine } from './gladius-words.ts';
import { run } from './tools.ts';

/** A query that has not answered in this long is given up: a script in an endless loop must not hold the route. */
export const QUERY_MS = 60_000;

/** The command line: the source, its parameters sorted by name -- the same options, the same command, as the export's (`steps/gladius.ts`). */
export function queryArgs(input: string, params: Readonly<Record<string, string>>): string[] {
  const args = ['query', '--faces', '--checks', 'none', '--format', 'json'];
  for (const name of Object.keys(params).sort()) args.push('--param', `${name}=${params[name]}`);
  args.push(input);
  return args;
}


export interface RawDiagnostic {
  severity?: unknown;
  code?: unknown;
  message?: unknown;
  script_span?: { line?: unknown } | null;
}

interface RawNode {
  name?: unknown;
  positions?: unknown;
  faces?: unknown;
  triangles?: unknown;
}

/** One of Gladius's diagnostics, read: its words, and the line it names if any. */
export function diagnosticOf(raw: RawDiagnostic): ModelDiagnostic {
  const severity = raw.severity === 'error' || raw.severity === 'warning' ? raw.severity : 'info';
  const message = typeof raw.message === 'string' ? raw.message : String(raw.message ?? '');
  const spanLine = raw.script_span?.line;
  const line = typeof spanLine === 'number' && Number.isInteger(spanLine) ? spanLine : luaLine(message);
  return {
    severity,
    ...(typeof raw.code === 'string' ? { code: raw.code } : {}),
    message,
    ...(line !== undefined ? { line } : {}),
  };
}

/** A position as three numbers, or null for anything else. */
function point(value: unknown): [number, number, number] | null {
  if (!Array.isArray(value) || value.length < 3) return null;
  const [x, y, z] = value as unknown[];
  return typeof x === 'number' && typeof y === 'number' && typeof z === 'number' ? [x, y, z] : null;
}

/** Where a point is, to a tenth of a millimetre: two vertices the kernel keeps apart at a seam are one end of a line. */
const spot = (p: readonly number[]): string => `${Math.round(p[0]! * 1e4)},${Math.round(p[1]! * 1e4)},${Math.round(p[2]! * 1e4)}`;

/** A node read: its counts by index, its polygons' boundaries as segments by where they are. */
function nodeOf(raw: RawNode): ModelNode | null {
  if (typeof raw.name !== 'string' || !Array.isArray(raw.positions) || !Array.isArray(raw.faces)) return null;
  const positions = raw.positions.map(point);
  const byIndex = new Set<string>();
  const drawn = new Set<string>();
  const segments: number[] = [];
  for (const face of raw.faces as { loop?: unknown }[]) {
    const loop = face?.loop;
    if (!Array.isArray(loop)) continue;
    for (let i = 0; i < loop.length; i++) {
      const a = loop[i];
      const b = loop[(i + 1) % loop.length];
      if (typeof a !== 'number' || typeof b !== 'number' || a === b) continue;
      byIndex.add(a < b ? `${a}:${b}` : `${b}:${a}`);
      const p = positions[a];
      const q = positions[b];
      if (!p || !q) continue;
      const sp = spot(p);
      const sq = spot(q);
      if (sp === sq) continue;
      const key = sp < sq ? `${sp}|${sq}` : `${sq}|${sp}`;
      if (drawn.has(key)) continue;
      drawn.add(key);
      segments.push(p[0], p[1], p[2], q[0], q[1], q[2]);
    }
  }
  return {
    name: raw.name,
    vertices: positions.length,
    edges: byIndex.size,
    faces: raw.faces.length,
    triangles: Array.isArray(raw.triangles) ? raw.triangles.length : 0,
    segments,
  };
}

/**
 * Gladius's envelope, read (`text` its whole output: the JSON from its first
 * `{`). Output that is no envelope is `ok: false` with a `problem` -- its
 * first line, so a crash says what it said.
 */
export function readReport(text: string, ms: number): ModelAnswer {
  const start = text.indexOf('{');
  let read: unknown = null;
  if (start >= 0) {
    try {
      read = JSON.parse(text.slice(start));
    } catch {
      read = null;
    }
  }
  const parsed = typeof read === 'object' && read !== null ? (read as { ok?: unknown; diagnostics?: unknown; nodes?: unknown }) : null;
  if (!parsed) {
    const first = text.trim().split('\n')[0] ?? '';
    return { ok: false, ms, diagnostics: [], nodes: [], problem: first ? `gladius said: ${first}` : 'gladius printed nothing' };
  }
  const diagnostics = Array.isArray(parsed.diagnostics) ? (parsed.diagnostics as RawDiagnostic[]).map(diagnosticOf) : [];
  const ok = parsed.ok === true;
  // A failed build's nodes, if any, are not the model on screen: none are answered.
  const nodes = ok && Array.isArray(parsed.nodes) ? (parsed.nodes as RawNode[]).map(nodeOf).filter((n): n is ModelNode => n !== null) : [];
  return { ok, ms, diagnostics, nodes };
}

export interface QueryOptions {
  /** Gladius, as the tools' look found it. */
  bin: string;
  /** The source, absolute: Gladius is run in its folder, so what it `import()`s resolves as the export's does. */
  input: string;
  params: Readonly<Record<string, string>>;
  /** The hint for this platform, said when Gladius is not there. */
  hint?: string;
  /** The clock, for `ms`. */
  now?: () => number;
}

/** `gladius query` on `input`: its report read, or why it could not run -- Gladius not there, or no answer in `QUERY_MS`. */
export async function queryModel({ bin, input, params, hint, now = Date.now }: QueryOptions): Promise<ModelAnswer> {
  const began = now();
  const ran = await run(bin, queryArgs(input, params), { cwd: dirname(input), timeoutMs: QUERY_MS });
  const ms = now() - began;
  if ('error' in ran) {
    if (ran.error === 'missing') return { ok: false, ms, diagnostics: [], nodes: [], missing: 'gladius', ...(hint ? { hint } : {}) };
    return { ok: false, ms, diagnostics: [], nodes: [], problem: `gladius ${ran.message}` };
  }
  // The envelope is on stdout; a crash's words may be on stderr alone.
  return readReport(ran.stdout.includes('{') ? ran.stdout : ran.stdout + ran.stderr, ms);
}
