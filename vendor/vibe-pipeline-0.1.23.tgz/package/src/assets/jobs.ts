/**
 * The job runner (Docs/assets.md §4, "Jobs"). A job is one source's export.
 *
 * - **Serial in the dev server**: a designer's machine, a predictable terminal,
 *   no two jobs writing one folder. **Parallel in the CLI**:
 *   `os.availableParallelism()` at once, which `conflict` makes safe -- no two
 *   sources share an export.
 * - **Dedupe by source.** A job for a source already queued is dropped; for one
 *   whose job is running, it is queued once more behind it. The running job is
 *   not cancelled: its export, correct for the bytes it read, is written, then
 *   replaced by the next -- the export is never `missing`.
 * - **A browser step never holds the runner.** A job waiting for a game tab is
 *   *parked* -- it gives its slot back, and the runner takes the next; once the
 *   file has arrived it takes a slot again before anything queued, and the rest
 *   runs as the next job. A parked job counts as running for dedupe.
 * - **A job whose source is deleted is dropped** (`drop`): queued, it goes;
 *   parked, it is forgotten; running, it is told, and its export discards what
 *   it made instead of installing it. Its last message says `dropped`.
 * - **The tab has deadlines** (`BrowserBridge`): with no game tab on this
 *   machine the step is `unmade` at once, and the source is queued again on the
 *   next connection; a tab that is there has 60 s to claim, then 60 s to send.
 * - **A drop is held** (`Drops`) until its last file is in and its owners have
 *   been read for their parts -- then owners first -- or 10 s after its last
 *   file ended, for a drop whose rest never comes; never while one of its
 *   files is still uploading. Its sources' auto-exports wait for it (`holds`).
 *
 * Time comes from an injected clock, so the tests run the deadlines in a blink.
 * It loads one other file, `clock.ts` (the rest of its imports are types): a
 * server that only queues does not load the index, the steps or the readers.
 */
import { randomBytes } from 'node:crypto';
import type { JobInfo, JobMessage, QueuedJobInfo } from './api-types.ts';
import { REAL_CLOCK, type Clock, type TimerHandle } from './clock.ts';
import type { ExportOptions } from './export.ts';

/** A source a step could not make here, for a reason that is not a failure: no game tab. The runner's word. */
export class Unmade extends Error {}

/** A job whose source was deleted while it waited or ran (`Runner.drop`): discarded, never installed. Not a failure. */
export class Dropped extends Error {
  constructor(message = 'its source was deleted') {
    super(message);
  }
}

/** A job's id, and its directory's name under `.cache/assets/jobs/`: time-ordered, unique. */
export function newId(): string {
  return `${Date.now().toString(36)}-${randomBytes(3).toString('hex')}`;
}

export interface QueuedJob {
  id: string;
  source: string;
  options: ExportOptions;
}

/** What a running job may do besides running, and know. */
export interface JobControl {
  /** Its slot given back while it waits for a tab. */
  park(): void;
  /** A slot taken again, before anything queued. At once for a job dropped meanwhile, with no slot. */
  resume(): Promise<void>;
  /** Aborted when the job is dropped: the export checks it between steps and before it installs, and discards. */
  readonly signal: AbortSignal;
  /** The job's own progress (the export's `job` messages), passed on -- nothing after the job was dropped. */
  progress(message: JobMessage): void;
}

export interface RunnerOptions {
  /** Jobs at once: 1 in the dev server, the machine's parallelism in the CLI. */
  concurrency?: number;
  /** One job: an export. Its own failures are results, not throws; a throw is logged as a failure. */
  run: (job: QueuedJob, control: JobControl) => Promise<unknown>;
  onMessage?: (message: JobMessage) => void;
}

/** A job that has started: running, or parked. */
interface Live {
  job: QueuedJob;
  holding: boolean;
  dropped: boolean;
  controller: AbortController;
  /** Resolves when its run has ended. */
  ended: Promise<void>;
}

export class Runner {
  readonly concurrency: number;
  private readonly run: RunnerOptions['run'];
  private readonly onMessage: RunnerOptions['onMessage'];
  private readonly queue: QueuedJob[] = [];
  /** Running or parked, by source. */
  private readonly live = new Map<string, Live>();
  /** Sources asked for again while their job ran: the job queued once more behind it, its id already given out. */
  private readonly again = new Map<string, QueuedJob>();
  private free: number;
  /** Parked jobs whose file arrived, waiting for a slot: served before the queue. */
  private readonly resumers: Array<() => void> = [];
  private idlers: Array<() => void> = [];

  constructor(options: RunnerOptions) {
    this.concurrency = Math.max(1, options.concurrency ?? 1);
    this.free = this.concurrency;
    this.run = options.run;
    this.onMessage = options.onMessage;
  }

  /**
   * A source to export. Dropped if it is queued already (its job's id
   * answered); queued once more behind its job if that is running or parked --
   * that job made now, so the caller has the id whose `done` it waits for, and
   * asked for a third time, the same one. Answers the job's id and whether
   * anything was added.
   */
  add(source: string, options: ExportOptions = {}): { id: string; added: boolean } {
    const queued = this.queue.find((j) => j.source === source);
    if (queued) return { id: queued.id, added: false };
    if (this.live.has(source)) {
      const again = this.again.get(source);
      if (again) {
        again.options = options;
        return { id: again.id, added: false };
      }
      const job = { id: options.id ?? newId(), source, options };
      this.again.set(source, job);
      this.message(job, 'queued');
      return { id: job.id, added: true };
    }
    const job = { id: options.id ?? newId(), source, options };
    this.queue.push(job);
    this.message(job, 'queued');
    this.pump();
    return { id: job.id, added: true };
  }

  /**
   * A source's jobs dropped -- its source deleted while they waited or ran.
   * Queued ones (and one queued again) are removed; a parked one is forgotten;
   * a running one is told (`control.signal`), and its export discards instead
   * of installing. Each ends with a `dropped` message and nothing after it: at
   * once, or a running one's as it ends. Resolves once that one has ended, so
   * the caller deletes after it, never under it -- a second drop of a running
   * one too (two deletes of one family's files each drop its source), which
   * waits as the first does and says nothing more.
   */
  drop(source: string): Promise<void> {
    for (let i = this.queue.length - 1; i >= 0; i--) {
      if (this.queue[i]!.source !== source) continue;
      const [job] = this.queue.splice(i, 1);
      this.message(job!, 'dropped');
    }
    const again = this.again.get(source);
    if (again) {
      this.again.delete(source);
      this.message(again, 'dropped');
    }
    const live = this.live.get(source);
    let ended = Promise.resolve();
    if (live) {
      if (!live.dropped) {
        live.dropped = true;
        live.controller.abort(new Dropped());
        if (!live.holding) {
          // Parked: forgotten now. Its run ends when its wait does, and says nothing more.
          this.live.delete(source);
          this.message(live.job, 'dropped');
        }
      }
      if (live.holding) ended = live.ended;
    }
    this.pump();
    return ended;
  }

  /** What is queued, running and parked: running and parked first, then the queue in order, then what is queued again behind a running job. */
  jobs(): JobInfo[] {
    return [
      ...[...this.live.values()].map((l): JobInfo => ({ id: l.job.id, source: l.job.source, state: l.holding ? 'running' : 'parked' })),
      ...this.queue.map((j): JobInfo => ({ id: j.id, source: j.source, state: 'queued' })),
      ...[...this.again.values()].map((j): JobInfo => ({ id: j.id, source: j.source, state: 'queued' })),
    ];
  }

  /** Resolves once nothing is queued, running or parked. */
  idle(): Promise<void> {
    if (this.isIdle()) return Promise.resolve();
    return new Promise((resolve) => this.idlers.push(resolve));
  }

  private isIdle(): boolean {
    return this.queue.length === 0 && this.live.size === 0;
  }

  private message(job: QueuedJob, state: JobMessage['state'], extra: Partial<JobMessage> = {}): void {
    this.onMessage?.({ id: job.id, source: job.source, step: 0, of: 0, state, ...extra });
  }

  private pump(): void {
    while (this.free > 0 && (this.resumers.length > 0 || this.queue.length > 0)) {
      this.free--;
      const resumer = this.resumers.shift();
      if (resumer) resumer();
      else this.start(this.queue.shift()!);
    }
    if (this.isIdle()) {
      const idlers = this.idlers;
      this.idlers = [];
      for (const resolve of idlers) resolve();
    }
  }

  private start(job: QueuedJob): void {
    let end!: () => void;
    const live: Live = { job, holding: true, dropped: false, controller: new AbortController(), ended: new Promise((resolve) => (end = resolve)) };
    this.live.set(job.source, live);
    const control: JobControl = {
      park: () => {
        if (!live.holding || live.dropped) return;
        live.holding = false;
        this.message(job, 'parked');
        this.free++;
        this.pump();
      },
      resume: () =>
        new Promise<void>((resolve) => {
          if (live.holding || live.dropped) return resolve();
          this.resumers.push(() => {
            if (live.dropped) {
              // Dropped while its file came: no slot, and nothing more to say.
              this.free++;
              return resolve();
            }
            live.holding = true;
            this.message(job, 'running');
            resolve();
          });
          this.pump();
        }),
      signal: live.controller.signal,
      progress: (message) => {
        if (!live.dropped) this.onMessage?.(message);
      },
    };
    void (async () => {
      try {
        await this.run(job, control);
      } catch (err) {
        if (!live.dropped) this.message(job, 'failed', { error: (err as Error).message });
      } finally {
        // A parked job dropped is forgotten already; another job of its source may be live by now.
        if (this.live.get(job.source) === live) this.live.delete(job.source);
        if (live.holding) this.free++;
        if (live.dropped && live.holding) this.message(job, 'dropped');
        const again = this.again.get(job.source);
        if (again && !this.live.has(job.source)) {
          this.again.delete(job.source);
          this.queue.push(again);
        }
        end();
        this.pump();
      }
    })();
  }
}

// ---------------------------------------------------------------- the browser step's tab

export interface BridgeOptions {
  /** Is a game tab on this machine connected (a loopback websocket)? */
  connected: () => boolean;
  /** Ask the tabs: the `convert` message (§5). */
  ask: (message: { job: string; source: string; parts: string[] }) => void;
  /** Milliseconds a tab has to claim. Default 60 000. */
  claimMs?: number;
  /** Milliseconds a claiming tab has to send the file. Default 60 000. */
  sendMs?: number;
  clock?: Clock;
}

interface Pending {
  source: string;
  claimed: boolean;
  timer: TimerHandle;
  resolve: (file: string) => void;
  reject: (err: Error) => void;
}

/**
 * Between a parked browser step and the game tabs: one request a job, its
 * deadlines, the first claim winning, and the sources to queue again when a tab
 * connects.
 */
export class BrowserBridge {
  private readonly pending = new Map<string, Pending>();
  /** Sources found `unmade` for want of a tab: queued again on the next connection. */
  readonly waiting = new Set<string>();
  private readonly options: BridgeOptions;
  private readonly clock: Clock;

  constructor(options: BridgeOptions) {
    this.options = options;
    this.clock = options.clock ?? REAL_CLOCK;
  }

  /**
   * The file a tab sends for this job; `Unmade` with no tab or no claim, an
   * error when none is sent, `Dropped` -- at once, the wait forgotten -- when
   * `signal` aborts (the job's source deleted: `Runner.drop`).
   */
  request(job: string, source: string, parts: readonly string[], signal?: AbortSignal): Promise<string> {
    if (signal?.aborted) return Promise.reject(new Dropped());
    if (!this.options.connected()) {
      this.waiting.add(source);
      return Promise.reject(new Unmade('needs a game tab open on this machine'));
    }
    return new Promise<string>((resolve, reject) => {
      const timer = this.clock.setTimeout(() => {
        this.pending.delete(job);
        this.waiting.add(source);
        reject(new Unmade(`no game tab took the conversion in ${Math.round((this.options.claimMs ?? 60000) / 1000)} s`));
      }, this.options.claimMs ?? 60000);
      this.pending.set(job, { source, claimed: false, timer, resolve, reject });
      signal?.addEventListener(
        'abort',
        () => {
          const p = this.pending.get(job);
          if (!p) return;
          this.clock.clearTimeout(p.timer);
          this.pending.delete(job);
          p.reject(new Dropped());
        },
        { once: true },
      );
      this.options.ask({ job, source, parts: [...parts] });
    });
  }

  /** A tab's claim: the first wins (`true`), the rest are refused (`409`). */
  claim(job: string): boolean {
    const p = this.pending.get(job);
    if (!p || p.claimed) return false;
    p.claimed = true;
    this.clock.clearTimeout(p.timer);
    p.timer = this.clock.setTimeout(() => {
      this.pending.delete(job);
      p.reject(new Error('the editor did not send the model'));
    }, this.options.sendMs ?? 60000);
    return true;
  }

  /** The file arrived (streamed into the job's directory). False if the job is not waiting for one. */
  sent(job: string, file: string): boolean {
    const p = this.pending.get(job);
    if (!p || !p.claimed) return false;
    this.clock.clearTimeout(p.timer);
    this.pending.delete(job);
    p.resolve(file);
    return true;
  }

  /** A game tab connected: the sources to queue again. */
  connected(): string[] {
    const sources = [...this.waiting];
    this.waiting.clear();
    return sources;
  }

  /** Jobs waiting for a tab, for `GET jobs` and a tab that connects late. */
  open(): Array<{ job: string; source: string; claimed: boolean }> {
    return [...this.pending].map(([job, p]) => ({ job, source: p.source, claimed: p.claimed }));
  }
}

// ---------------------------------------------------------------- drops

export interface DropFile {
  source: string;
  /** A model source: queued before the rest. */
  owner: boolean;
  /** Settles once the file has been read for its parts (owners) or at once. */
  read: Promise<unknown>;
}

/** A drop held: its files in, how many are on their way, the hold's timer, and its exports once queued. */
interface Held {
  files: DropFile[];
  /** Files begun (`begin`) and not yet in or given up: no hold runs out while one comes. */
  coming: number;
  timer: TimerHandle | undefined;
  /** Its exports queued: what the enqueue answered. */
  flushed: Promise<QueuedJobInfo[]> | undefined;
}

/**
 * An import's drop, held (§5, Importing): its exports are queued with its last
 * file (`left` 0), once every owner in it has been read for its parts --
 * owners first -- so no model is made before its parts are in, and no image a
 * dropped model names is exported alone. Until then its sources are `holds`:
 * an auto-export a watch event asks for waits for the drop. A drop whose rest
 * never comes is queued `holdMs` after its last file ended -- not while one is
 * still on its way (`begin`): a texture uploading for a minute holds its model
 * for that minute, and a closed tab's drop goes 10 s after its upload broke off.
 */
export class Drops {
  private readonly drops = new Map<string, Held>();
  private readonly enqueue: (sources: string[]) => Promise<QueuedJobInfo[]> | QueuedJobInfo[] | void;
  private readonly holdMs: number;
  private readonly clock: Clock;

  constructor(enqueue: (sources: string[]) => Promise<QueuedJobInfo[]> | QueuedJobInfo[] | void, options: { holdMs?: number; clock?: Clock } = {}) {
    this.enqueue = enqueue;
    this.holdMs = options.holdMs ?? 10000;
    this.clock = options.clock ?? REAL_CLOCK;
  }

  /** A held drop by id: a new one if it is not held (a flushed drop is forgotten, so a file of it arriving later starts one of its own). */
  private held(drop: string): Held {
    let d = this.drops.get(drop);
    if (!d) this.drops.set(drop, (d = { files: [], coming: 0, timer: undefined, flushed: undefined }));
    return d;
  }

  /** A file of `drop` is on its way: no hold runs out while it comes. */
  begin(drop: string): void {
    const d = this.held(drop);
    d.coming++;
    if (d.timer !== undefined) this.clock.clearTimeout(d.timer);
    d.timer = undefined;
  }

  /**
   * A file of `drop` in, `left` the files sent after it. With `left` 0 the
   * drop's exports are queued once its owners are read: answers what was
   * queued, which the last file's `PUT import` says.
   */
  add(drop: string, file: DropFile, left: number): Promise<QueuedJobInfo[]> | undefined {
    const d = this.held(drop);
    d.files.push(file);
    return this.ended(drop, d, left);
  }

  /** A file of `drop` that did not come -- refused, or its upload broken off: the hold as for one that did. */
  end(drop: string, left: number): Promise<QueuedJobInfo[]> | undefined {
    const d = this.drops.get(drop);
    if (!d) return undefined;
    return this.ended(drop, d, left);
  }

  /** Is `source` in a drop not yet queued? Its export waits for the drop's. */
  holds(source: string): boolean {
    for (const d of this.drops.values()) if (d.flushed === undefined && d.files.some((f) => f.source === source)) return true;
    return false;
  }

  private ended(drop: string, d: Held, left: number): Promise<QueuedJobInfo[]> | undefined {
    d.coming = Math.max(0, d.coming - 1);
    if (d.timer !== undefined) this.clock.clearTimeout(d.timer);
    d.timer = undefined;
    if (left <= 0) {
      const files = [...d.files];
      return Promise.allSettled(files.filter((f) => f.owner).map((f) => f.read)).then(() => this.flush(drop, d));
    }
    if (d.coming === 0) d.timer = this.clock.setTimeout(() => void this.flush(drop, d), this.holdMs);
    return undefined;
  }

  private flush(drop: string, d: Held): Promise<QueuedJobInfo[]> {
    if (d.flushed) return d.flushed;
    if (d.timer !== undefined) this.clock.clearTimeout(d.timer);
    d.timer = undefined;
    if (this.drops.get(drop) === d) this.drops.delete(drop);
    const owners = d.files.filter((f) => f.owner).map((f) => f.source);
    const rest = d.files.filter((f) => !f.owner).map((f) => f.source);
    d.flushed = Promise.resolve(this.enqueue([...owners, ...rest])).then((jobs) => jobs ?? []);
    return d.flushed;
  }
}
