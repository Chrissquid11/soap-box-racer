/**
 * Finding what the steps need (Docs/assets.md §3, "Tools").
 *
 * A step lists the external programs it runs (`needs`); this collects every
 * entry of every step a recipe uses, merged by name, and finds each once. An
 * entry says where to look, what must be true of what it finds, and what to
 * tell a person. A tool is looked for in this order:
 *
 *   1. a path set in the Tools card, kept in the gitignored `assets.local.json`
 *   2. an environment variable named for it (`FFMPEG`, `BLENDER`, ...)
 *   3. the PATH
 *   4. the app locations: how the common Mac (Blender in /Applications, never
 *      on the PATH) finds it
 *
 * A look ends `found`, `missing` or `lacking` -- found, but a `require` check
 * failed: Homebrew's ffmpeg lists only the native, experimental `vorbis`
 * encoder, never `libvorbis`, which the step needs -- each with its own hint
 * and the line it read, so which ffmpeg and what it lacks is never a guess.
 * Every check has 5 s (Blender's 10: a cold laptop disk); one that does not
 * answer is "missing" ("did not answer in 10 s"), never an exception.
 *
 * npm packages are not looked for: they are devDependencies, pinned by
 * `package-lock.json`, and their versions (for `built.tools`) come from their
 * own `package.json`.
 *
 * Every program the pipeline runs -- a look's check, a step's command, a stats
 * reader's `magick` or `ffprobe` -- goes through `run` here: `spawn(bin, args)`,
 * no shell, each argument one array element, so a path with spaces needs no
 * quoting. And every one is found through the look-up order above: a step and
 * a reader are handed `bin(tool)`, the path the look found. Nothing runs at
 * module level.
 */
import { spawn } from 'node:child_process';
import { readdir, readFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import type { ToolLook } from './api-types.ts';
import { isFile, writeAtomic } from './fs.ts';

export type Platform = 'darwin' | 'win32' | 'linux';

/** What a step needs of the machine: one external program. */
export interface Need {
  /** Its name in `assets.local.json`, in `built.tools` and on the Tools card. */
  readonly tool: string;
  /** The names to try on the PATH. */
  readonly bin: readonly string[];
  /** The arguments that print its version. */
  readonly version: readonly string[];
  /** The version in that output, as the first group. */
  readonly match: RegExp;
  /** Where an app keeps it, per platform: `~` is the home folder, `*` one folder of any name. */
  readonly apps?: Readonly<Partial<Record<Platform, readonly string[]>>>;
  /** Found is not enough: this command's output must have a line matching `line`. */
  readonly require?: {
    readonly args: readonly string[];
    readonly line: RegExp;
    /** The line shown when `line` is not there: what it has instead. */
    readonly near?: RegExp;
    /** Said when neither is there. */
    readonly none?: string;
    /** What it must have, in a reason: "needs ffmpeg with libvorbis". */
    readonly what?: string;
  };
  /** What to do when it is missing, per platform. */
  readonly hint: Readonly<Partial<Record<Platform, string>>>;
  /** What to do when it is found but lacking, per platform. */
  readonly lacking?: Readonly<Partial<Record<Platform, string>>>;
  /** Milliseconds each check has. Default 5000. */
  readonly timeout?: number;
}

export const GLADIUS: Need = {
  tool: 'gladius',
  bin: ['gladius'],
  version: ['--version'],
  match: /gladius (\S+)/,
  hint: {
    darwin: 'Gladius: put `gladius` on the PATH, or set its path here',
    win32: 'Gladius: put `gladius.exe` on the PATH, or set its path here',
    linux: 'Gladius: put `gladius` on the PATH, or set its path here',
  },
};

export const FFMPEG: Need = {
  tool: 'ffmpeg',
  bin: ['ffmpeg'],
  version: ['-version'],
  match: /ffmpeg version (\S+)/,
  require: {
    args: ['-hide_banner', '-encoders'],
    line: /^\s*A\S*\s+libvorbis\s.*$/m,
    near: /^\s*A\S*\s+vorbis\s.*$/m,
    none: 'no Vorbis encoder listed',
    what: 'libvorbis',
  },
  hint: {
    darwin:
      "a static build from ffmpeg.org, its path set here (quickest); or brew tap homebrew-ffmpeg/ffmpeg && brew install homebrew-ffmpeg/ffmpeg/ffmpeg (builds from source: allow some minutes; Homebrew's own ffmpeg has no libvorbis)",
    win32: 'winget install ffmpeg',
    linux: 'apt install ffmpeg',
  },
  lacking: {
    darwin:
      "Homebrew's ffmpeg is built without libvorbis: a static build from ffmpeg.org, its path set here (quickest); or brew uninstall ffmpeg, then the tap above (builds from source: allow some minutes)",
    win32: 'this ffmpeg has no libvorbis: winget install ffmpeg (gyan.dev builds list it)',
    linux: 'this ffmpeg has no libvorbis: apt install ffmpeg',
  },
};

export const MAGICK: Need = {
  tool: 'magick',
  bin: ['magick'],
  version: ['--version'],
  match: /ImageMagick (\S+)/,
  hint: { darwin: 'brew install imagemagick', win32: 'winget install ImageMagick.ImageMagick', linux: 'apt install imagemagick (version 7, which has `magick`)' },
};

export const BLENDER: Need = {
  tool: 'blender',
  bin: ['blender'],
  version: ['--version'],
  match: /Blender (\d+\.\d+(\.\d+)?)/,
  apps: {
    darwin: ['/Applications/Blender.app/Contents/MacOS/Blender', '~/Applications/Blender.app/Contents/MacOS/Blender'],
    win32: ['C:/Program Files/Blender Foundation/Blender */blender.exe'],
  },
  hint: { darwin: 'Install Blender from blender.org', win32: 'winget install BlenderFoundation.Blender', linux: 'apt install blender' },
  timeout: 10000,
};

export const ASEPRITE: Need = {
  tool: 'aseprite',
  bin: ['aseprite'],
  version: ['--version'],
  match: /Aseprite (\S+)/,
  apps: {
    darwin: [
      '/Applications/Aseprite.app/Contents/MacOS/aseprite',
      '~/Applications/Aseprite.app/Contents/MacOS/aseprite',
      '~/Library/Application Support/Steam/steamapps/common/Aseprite/Aseprite.app/Contents/MacOS/aseprite',
    ],
    win32: ['C:/Program Files/Aseprite/Aseprite.exe', 'C:/Program Files (x86)/Steam/steamapps/common/Aseprite/Aseprite.exe'],
  },
  hint: { darwin: 'Install Aseprite (aseprite.org or Steam), or set its path here', win32: 'Install Aseprite (aseprite.org or Steam), or set its path here', linux: 'Install Aseprite, or set its path here' },
};

/**
 * Not a step's: `stats/audio.ts` asks it about a format no reader of its own
 * knows, when it is there (`STATS_NEEDS`, which the dev server looks for with
 * the steps' needs). Missing, such a file is described by its format alone.
 */
export const FFPROBE: Need = {
  tool: 'ffprobe',
  bin: ['ffprobe'],
  version: ['-version'],
  match: /ffprobe version (\S+)/,
  hint: { darwin: 'brew install ffmpeg', win32: 'winget install ffmpeg', linux: 'apt install ffmpeg' },
};

/**
 * Not a step's: the Code card's search (`studio/search.ts`) runs it when it is there, and walks the files
 * itself when not -- never a check that fails for want of it.
 */
export const RG: Need = {
  tool: 'rg',
  bin: ['rg'],
  version: ['--version'],
  match: /ripgrep (\S+)/,
  hint: { darwin: 'brew install ripgrep', win32: 'winget install BurntSushi.ripgrep.MSVC', linux: 'apt install ripgrep' },
};

/** Every need of a list of steps' needs, merged by name: each tool looked for once. */
export function mergeNeeds(lists: ReadonlyArray<readonly Need[]>): Need[] {
  const out = new Map<string, Need>();
  for (const list of lists) for (const need of list) if (!out.has(need.tool)) out.set(need.tool, need);
  return [...out.values()];
}

// ---------------------------------------------------------------- running a program

export interface Ran {
  code: number | null;
  stdout: string;
  stderr: string;
}

export type RunError = { error: 'missing' | 'timeout' | 'failed'; message: string };

/** How a look runs a program: `spawn`, or canned output in a test. */
export type Runner = (bin: string, args: readonly string[], timeoutMs: number) => Promise<Ran | RunError>;

/**
 * The one `spawn`: `bin` with `args`, no shell, its output collected; killed
 * after `timeoutMs` if given, or when `signal` aborts. Never rejects: a program
 * not there, one that did not answer and one that could not start are answers.
 */
export function run(bin: string, args: readonly string[], options: { cwd?: string; timeoutMs?: number; signal?: AbortSignal } = {}): Promise<Ran | RunError> {
  return new Promise((resolve) => {
    let done = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const finish = (value: Ran | RunError): void => {
      if (done) return;
      done = true;
      if (timer) clearTimeout(timer);
      resolve(value);
    };
    let stdout = '';
    let stderr = '';
    const child = spawn(bin, [...args], { cwd: options.cwd, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true, signal: options.signal });
    if (options.timeoutMs !== undefined) {
      const ms = options.timeoutMs;
      timer = setTimeout(() => {
        child.kill('SIGKILL');
        finish({ error: 'timeout', message: `did not answer in ${Math.round(ms / 1000)} s` });
      }, ms);
    }
    child.stdout.setEncoding('utf8').on('data', (s: string) => void (stdout += s));
    child.stderr.setEncoding('utf8').on('data', (s: string) => void (stderr += s));
    child.on('error', (err: NodeJS.ErrnoException) => {
      finish(err.code === 'ENOENT' ? { error: 'missing', message: `${bin}: not found` } : { error: 'failed', message: err.message });
    });
    child.on('close', (code) => finish({ code, stdout, stderr }));
  });
}

/** A look's check: `run` with a deadline, every answer an answer. */
export const runProgram: Runner = (bin, args, timeoutMs) => run(bin, args, { timeoutMs });

/**
 * A step's command (or a reader's): `run`, resolving with the output on exit
 * 0, rejecting otherwise with an error that carries the whole output (the runs
 * cache keeps it, §4) and says, in its message, the first line of it that
 * names an error -- or the last line. No deadline: an export takes what it takes.
 */
export async function exec(bin: string, args: readonly string[], options: { cwd?: string; signal?: AbortSignal } = {}): Promise<Ran> {
  const ran = await run(bin, args, options);
  if ('error' in ran) throw Object.assign(new Error(ran.error === 'missing' ? ran.message : `${bin}: ${ran.message}`), { output: '' });
  if (ran.code === 0) return ran;
  const output = (ran.stdout + ran.stderr).trim();
  const lines = output.split('\n');
  const first = lines.find((l) => /error|fail|invalid|cannot|could not/i.test(l)) ?? lines.pop() ?? '';
  throw Object.assign(new Error(`${bin.split(/[\\/]/).pop()} exited ${ran.code}: ${first.trim()}`), { output });
}

// ---------------------------------------------------------------- assets.local.json

/** `assets.local.json` at the project root: this machine's tool paths. Gitignored. */
export interface Local {
  tools?: Record<string, string>;
}

export const LOCAL_FILE = 'assets.local.json';

export async function readLocal(root: string): Promise<Local> {
  try {
    const parsed = JSON.parse(await readFile(join(root, LOCAL_FILE), 'utf8')) as unknown;
    return typeof parsed === 'object' && parsed !== null ? (parsed as Local) : {};
  } catch {
    return {};
  }
}

/** A tool's path, from the Tools card, into `assets.local.json` (atomically); `''` removes it. */
export async function setLocalTool(root: string, tool: string, path: string): Promise<void> {
  const local = await readLocal(root);
  const tools = { ...(local.tools ?? {}) };
  if (path === '') delete tools[tool];
  else tools[tool] = path;
  await writeAtomic(join(root, LOCAL_FILE), JSON.stringify({ ...local, tools }, null, 2) + '\n');
}

// ---------------------------------------------------------------- looking

export interface LookContext {
  /** The project root: where `assets.local.json` is. */
  root: string;
  platform?: Platform;
  env?: Readonly<Record<string, string | undefined>>;
  home?: string;
  run?: Runner;
  /** Whether a path is a file: stubbed in tests. */
  exists?: (path: string) => Promise<boolean>;
  /** Folder names, for a `*` in an app location. */
  list?: (dir: string) => Promise<string[]>;
  /** `assets.local.json`'s contents; read from `root` when absent. */
  local?: Local;
}

async function listDir(dir: string): Promise<string[]> {
  try {
    return await readdir(dir);
  } catch {
    return [];
  }
}

/** An app location made real: `~` the home folder, each `*` segment every folder there. */
async function expand(pattern: string, home: string, list: (dir: string) => Promise<string[]>): Promise<string[]> {
  const p = pattern.startsWith('~/') ? home + pattern.slice(1) : pattern;
  const segments = p.split('/');
  let paths = [segments[0]!];
  for (const segment of segments.slice(1)) {
    if (!segment.includes('*')) {
      paths = paths.map((x) => `${x}/${segment}`);
      continue;
    }
    // A pattern from `apps` above, the base's own table -- never a path from `assets.local.json` -- escaped all the same.
    const re = new RegExp(`^${segment.split('*').map((s) => s.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*')}$`);
    const next: string[] = [];
    for (const dir of paths) for (const name of (await list(dir === '' ? '/' : dir)).sort()) if (re.test(name)) next.push(`${dir}/${name}`);
    paths = next;
  }
  return paths;
}

/** The first line of `text` that `re` matches, trimmed. */
function lineOf(text: string, re: RegExp): string | undefined {
  const m = re.exec(text);
  return m ? m[0].trim() : undefined;
}

/**
 * One tool, looked for: every candidate in order (local path, environment
 * variable, the PATH, the app locations), the first that answers its version
 * check decides. A `require` check then makes it `lacking` if it fails.
 */
export async function lookFor(need: Need, context: LookContext): Promise<ToolLook> {
  const platform = context.platform ?? (process.platform as Platform);
  const env = context.env ?? process.env;
  const run = context.run ?? runProgram;
  const exists = context.exists ?? isFile;
  const list = context.list ?? listDir;
  const home = context.home ?? homedir();
  const local = context.local ?? (await readLocal(context.root));
  const timeout = need.timeout ?? 5000;
  const hint = need.hint[platform];
  const candidates: Array<{ path: string; checkFile: boolean }> = [];
  const set = local.tools?.[need.tool];
  if (set) candidates.push({ path: set, checkFile: false });
  const fromEnv = env[need.tool.toUpperCase()];
  if (fromEnv) candidates.push({ path: fromEnv, checkFile: false });
  for (const bin of need.bin) candidates.push({ path: bin, checkFile: false });
  for (const app of need.apps?.[platform] ?? []) for (const path of await expand(app, home, list)) candidates.push({ path, checkFile: true });

  let why: string | undefined;
  /** The path set for it, if it was tried and did not run: said with whatever is used instead. */
  let passed: { path: string; why: string } | undefined;
  const over = (): { passedOver?: { path: string; why: string } } => (passed ? { passedOver: passed } : {});
  for (const { path, checkFile } of candidates) {
    if (checkFile && !(await exists(path))) continue;
    const ran = await run(path, need.version, timeout);
    if ('error' in ran) {
      if (ran.error !== 'missing') why = ran.message;
      if (path === set && passed === undefined) passed = { path, why: ran.error === 'missing' ? 'not found there' : ran.message };
      continue;
    }
    const version = need.match.exec(ran.stdout + ran.stderr)?.[1];
    if (!version) {
      why = `${path} did not say its version`;
      if (path === set && passed === undefined) passed = { path, why: 'it did not say its version' };
      continue;
    }
    if (!need.require) return { tool: need.tool, state: 'found', path, version, ...over() };
    const checked = await run(path, need.require.args, timeout);
    if ('error' in checked) return { tool: need.tool, state: 'missing', path, version, why: checked.message, ...(hint ? { hint } : {}), ...over() };
    const text = checked.stdout + checked.stderr;
    const line = lineOf(text, need.require.line);
    if (line) return { tool: need.tool, state: 'found', path, version, line, ...over() };
    const instead = (need.require.near && lineOf(text, need.require.near)) ?? need.require.none ?? 'the required check failed';
    const lacking = need.lacking?.[platform] ?? hint;
    return { tool: need.tool, state: 'lacking', path, version, line: instead, ...(lacking ? { hint: lacking } : {}), ...over() };
  }
  return { tool: need.tool, state: 'missing', ...(why ? { why } : {}), ...(hint ? { hint } : {}), ...over() };
}

/** Every need, looked for at once; the answers by tool name. */
export async function lookForAll(needs: readonly Need[], context: LookContext): Promise<Map<string, ToolLook>> {
  const local = context.local ?? (await readLocal(context.root));
  const looks = await Promise.all(needs.map((need) => lookFor(need, { ...context, local })));
  return new Map(looks.map((look) => [look.tool, look]));
}

/** One line for a person: `ffmpeg 8.1.2 (lacking): A..X.D vorbis ...`. */
export function sayLook(look: ToolLook): string {
  if (look.state === 'found') return `${look.tool} ${look.version}${look.path && look.path !== look.tool ? ` (${look.path})` : ''}`;
  if (look.state === 'lacking') return `${look.tool} ${look.version} lacks what the step needs: ${look.line}${look.hint ? ` -- ${look.hint}` : ''}`;
  return `${look.tool} not found${look.why ? ` (${look.why})` : ''}${look.hint ? ` -- ${look.hint}` : ''}`;
}

// ---------------------------------------------------------------- npm packages

/**
 * An npm package's version, from its own `package.json` under `node_modules`
 * (the same on every machine: `package-lock.json`). `three` is recorded as its
 * `REVISION`, as a browser conversion reports it: `0.186.1` is `186`.
 *
 * Looked for as node resolves a package: in the project's `node_modules`, then each
 * folder's above it -- a project of a workspace (`examples/sandbox/`) has its packages
 * hoisted to the workspace's root.
 */
export async function npmVersion(root: string, name: string): Promise<string | undefined> {
  for (let dir = root; ; dir = dirname(dir)) {
    try {
      const json = JSON.parse(await readFile(join(dir, 'node_modules', name, 'package.json'), 'utf8')) as { version?: string };
      if (!json.version) return undefined;
      if (name === 'three') return /^0\.(\d+)\./.exec(json.version)?.[1] ?? json.version;
      return json.version;
    } catch {
      if (dirname(dir) === dir) return undefined;
    }
  }
}

export async function npmVersions(root: string, names: Iterable<string>): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  for (const name of new Set(names)) {
    const version = await npmVersion(root, name);
    if (version) out[name] = version;
  }
  return out;
}
