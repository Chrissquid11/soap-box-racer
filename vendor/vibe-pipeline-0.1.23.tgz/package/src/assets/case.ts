/**
 * Case, on a disk that has none (CLAUDE.md: a key is the path lowercased; the
 * live host is case-sensitive, macOS is not). Two things git cannot be left
 * to see for itself, since `core.ignorecase` is true on a Mac:
 *
 * - **A case-only rename** (`renameCase`): `crate.glb` -> `Crate.glb` is no
 *   change to git there, and the deployed host would keep the old spelling --
 *   a 404 in production alone. A file or folder git tracks is renamed with
 *   `git mv`, through a temporary name (two steps: git and the disk both see
 *   a rename each time); one it does not, with two renames on disk the same way.
 *   The dev server's move (`server.ts`) calls it for every case-only step.
 * - **The check** (`caseMismatches`): every path git tracks under
 *   `src/assets/`, `packs/` and `AssetsSource/`, held to the case the disk
 *   has (a folder's listing, part by part): each that differs named once, at
 *   the highest folder that differs, with its fix (`git mv -f <old> <new>`; a
 *   folder's in two, through a name between, as git's own fails on a Mac).
 *   Unicode is compared composed (NFC): git and the disk may store either
 *   form, and only case is the question. `vibe test` runs it on the project
 *   (`checks/case.ts`, a note without git), and so does `npm run export --
 *   --check`.
 *
 * Without git -- not installed, or no checkout -- the rename is the disk's
 * and the check answers undefined. Nothing at module level.
 */
import { execFile } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { readdir, rename } from 'node:fs/promises';
import { join } from 'node:path';
import { ROOTS } from './kinds.ts';
import { baseName, dirName, joinPath } from './paths.ts';

/** git in `cwd`: its output, or undefined when it failed (no git, no checkout, a path refused). */
function git(cwd: string, args: readonly string[]): Promise<string | undefined> {
  return new Promise((resolve) => {
    execFile('git', args, { cwd, maxBuffer: 64 * 1024 * 1024 }, (err, stdout) => resolve(err ? undefined : stdout));
  });
}

/** Does git track `path` (relative to `root`) -- a file, or anything under a folder? Undefined without git or a checkout. */
export async function gitTracks(root: string, path: string): Promise<boolean | undefined> {
  const out = await git(root, ['ls-files', '-z', '--', path]);
  return out === undefined ? undefined : out.length > 0;
}

/** A name beside `path` for a moment: dot-named, so the index and the watcher let it be. */
const tempBeside = (path: string): string => joinPath(dirName(path), `.${baseName(path)}.${randomBytes(4).toString('hex')}.case`);

/**
 * `from` renamed `to`, the two differing only in case (or Unicode form), file
 * or folder, both relative to `root`: through a temporary name, with `git mv`
 * when git tracks it, on disk otherwise. Answers which it was.
 */
export async function renameCase(root: string, from: string, to: string): Promise<'git' | 'disk'> {
  const tmp = tempBeside(to);
  if ((await gitTracks(root, from)) === true) {
    if ((await git(root, ['mv', '-f', '--', from, tmp])) !== undefined) {
      if ((await git(root, ['mv', '-f', '--', tmp, to])) !== undefined) return 'git';
      // Half way: back to where it was, then said.
      await git(root, ['mv', '-f', '--', tmp, from]);
      throw new Error(`git mv ${tmp} ${to} failed: ${from} left as it was`);
    }
  }
  await rename(join(root, from), join(root, tmp));
  try {
    await rename(join(root, tmp), join(root, to));
  } catch (err) {
    await rename(join(root, tmp), join(root, from)).catch(() => undefined);
    throw err;
  }
  return 'disk';
}

/** A path git has in another case than the disk's. */
export interface CaseMismatch {
  /** As git has it: the file, or the highest folder that differs. */
  tracked: string;
  /** As the disk has it. */
  disk: string;
  /** What records it: `git mv -f <tracked> <disk>` -- a folder through a name between, two of them. */
  fix: string;
}

/** A path for a shell: as it is if plain, else in single quotes. */
const shell = (path: string): string => (/^[\w./-]+$/.test(path) ? path : `'${path.replace(/'/g, `'\\''`)}'`);

/**
 * Every path git tracks under the asset roots whose case differs from the
 * disk's, the highest folder that differs once for all under it. Undefined
 * without git or a checkout. A tracked path the disk no longer has is git
 * status's to say, not this.
 */
export async function caseMismatches(root: string, dirs: readonly string[] = [ROOTS.boot.dir, ROOTS.packs.dir, ROOTS.source.dir]): Promise<CaseMismatch[] | undefined> {
  const out = await git(root, ['ls-files', '-z', '--', ...dirs]);
  if (out === undefined) return undefined;
  const listings = new Map<string, Promise<string[] | null>>();
  const listing = (dir: string): Promise<string[] | null> => {
    let names = listings.get(dir);
    if (!names) {
      names = readdir(join(root, dir)).catch(() => null);
      listings.set(dir, names);
    }
    return names;
  };
  const found = new Map<string, CaseMismatch>();
  for (const tracked of out.split('\0')) {
    if (tracked === '') continue;
    const parts = tracked.split('/');
    let gitPath = '';
    let diskPath = '';
    for (const part of parts) {
      const names = await listing(diskPath);
      if (names === null) break;
      const composed = part.normalize('NFC');
      const exact = names.find((n) => n.normalize('NFC') === composed);
      const other = exact ?? names.find((n) => n.normalize('NFC').toLowerCase() === composed.toLowerCase());
      if (other === undefined) break;
      gitPath = joinPath(gitPath, part);
      diskPath = joinPath(diskPath, other);
      if (exact === undefined) {
        // A folder through a name between: git's own case-only rename of a folder fails on a case-insensitive disk.
        const folder = gitPath !== tracked;
        const between = `${gitPath}.case`;
        const fix = folder ? `git mv -f ${shell(gitPath)} ${shell(between)} && git mv -f ${shell(between)} ${shell(diskPath)}` : `git mv -f ${shell(gitPath)} ${shell(diskPath)}`;
        if (!found.has(gitPath)) found.set(gitPath, { tracked: gitPath, disk: diskPath, fix });
        break;
      }
    }
  }
  return [...found.values()].sort((a, b) => (a.tracked < b.tracked ? -1 : 1));
}

/** The check's lines: none when git and the disk agree. */
export function caseLines(mismatches: readonly CaseMismatch[]): string[] {
  return mismatches.map((m) => `[assets] case: git has ${m.tracked}, the disk ${m.disk} -- the live host would 404; record it: ${m.fix}`);
}
