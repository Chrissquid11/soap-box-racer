/**
 * `POST preview` (Docs/modeler.md §3, M22): a Gladius script built **not** as
 * its export -- to a cache file under `.cache/assets/preview/`, never the
 * shipped `.glb` under `src/assets/` -- for what the Model tab shows while a
 * parameter is dragged (Vibe3D D47), and, in phase 3, while a Claude turn
 * edits the script and the export waits for its end (M21).
 *
 * - **The export's build, short of its compression**: `gladius run` with the
 *   options the export passes -- `--textures embedded`, `--optimise-anim`,
 *   `--merge`, hidden-surface removal, clean's wrapper (`gladius-export.ts`, the
 *   step's own), the source's resolved `params` with the asked ones over them --
 *   then `finish` (its normals, its colours, its unused materials dropped), so
 *   the preview looks as the export will. Not `webp-textures` nor `draco`: they
 *   change the bytes, not the look, and cost most of an export's time.
 * - **Latest wins** (`Latest`, D47): per script, one build runs and one waits;
 *   an ask that comes while one waits takes its place, and the one it replaced
 *   is answered `superseded`, never built. A slider makes far more values than
 *   any build rate, and every one but the newest is stale before a slot frees:
 *   the cost regulates itself, with no rate to tune.
 * - **A failure is an answer**: Gladius's diagnostics with their lines, its one
 *   line -- the page keeps the last good preview and says it quietly.
 *
 * `previewArgs` and `Latest` are pure (`model-preview.test.ts`); `buildPreview`
 * runs Gladius.
 */
import { mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import type { ModelDiagnostic, Options, PreviewFailure } from './api-types.ts';
import { bareWords } from './gladius-words.ts';
import { diagnosticOf, type RawDiagnostic } from './model-query.ts';
import { paramArgs } from './model-params.ts';
import { finish } from './steps/finish.ts';
import { buildExport, exportFlags } from './gladius-export.ts';
import { run, type RunError } from './tools.ts';

/** A preview build that has not finished in this long is given up: a drag must never wait on a script that loops. */
export const PREVIEW_MS = 60_000;

/** The command line, as `steps/gladius.ts` builds the export's, to `out` -- merge, cull and all (`gladius-export.ts`); clean wraps `input`. */
export function previewArgs(input: string, out: string, options: Options, params: Readonly<Record<string, string>>): string[] {
  return ['run', '--format', 'json', ...exportFlags(options), ...paramArgs(params), '--out', out, input];
}

/** The parameters a preview builds at: the source's resolved ones, the asked ones over them. */
export function previewParams(set: Readonly<Record<string, string>>, asked: Readonly<Record<string, string>> | undefined): Record<string, string> {
  return { ...set, ...(asked ?? {}) };
}

/** What `Latest.ask` answers for an ask a later one replaced while it waited. */
export const SUPERSEDED = Symbol('superseded');

/**
 * One build per key at a time, the newest waiting: `ask` runs at once if the
 * key is idle, waits if one runs, and replaces the one waiting -- which is
 * answered `SUPERSEDED`, never built. Keys are independent.
 */
export class Latest<In, Out> {
  private readonly build: (key: string, input: In) => Promise<Out>;
  private readonly running = new Set<string>();
  private readonly waiting = new Map<string, { input: In; resolve: (out: Out | typeof SUPERSEDED) => void; reject: (err: unknown) => void }>();

  constructor(build: (key: string, input: In) => Promise<Out>) {
    this.build = build;
  }

  /** Is a build of `key` running or waiting? */
  busy(key: string): boolean {
    return this.running.has(key) || this.waiting.has(key);
  }

  ask(key: string, input: In): Promise<Out | typeof SUPERSEDED> {
    return new Promise((resolve, reject) => {
      if (!this.running.has(key)) {
        this.start(key, input, resolve, reject);
        return;
      }
      this.waiting.get(key)?.resolve(SUPERSEDED);
      this.waiting.set(key, { input, resolve, reject });
    });
  }

  private start(key: string, input: In, resolve: (out: Out | typeof SUPERSEDED) => void, reject: (err: unknown) => void): void {
    this.running.add(key);
    this.build(key, input).then(resolve, reject).finally(() => {
      this.running.delete(key);
      const next = this.waiting.get(key);
      if (!next) return;
      this.waiting.delete(key);
      this.start(key, next.input, next.resolve, next.reject);
    });
  }
}

/** A preview built: its bytes, finished. */
export interface PreviewBuilt {
  ok: true;
  ms: number;
  bytes: Uint8Array;
}

export interface PreviewOptions {
  bin: string;
  /** The source, absolute: run in its folder, as the export is. */
  input: string;
  /** The file it is built to: `.cache/assets/preview/<name>.glb`, replaced whole. */
  out: string;
  /** The source's resolved options: `anim`, `merge`, the finish's `angle`, `keepNormals`, `smoothColours`. */
  options: Options;
  params: Readonly<Record<string, string>>;
  hint?: string;
  now?: () => number;
}

/** Gladius's envelope on a failed run: its diagnostics, and its first error as one line. */
function failureOf(text: string, ms: number): PreviewFailure {
  const start = text.indexOf('{');
  let diagnostics: ModelDiagnostic[] = [];
  try {
    const read = start >= 0 ? (JSON.parse(text.slice(start)) as { diagnostics?: unknown }) : null;
    if (read && Array.isArray(read.diagnostics)) diagnostics = (read.diagnostics as RawDiagnostic[]).map(diagnosticOf);
  } catch {
    diagnostics = [];
  }
  const first = diagnostics.find((d) => d.severity === 'error');
  const said = text.trim().split('\n')[0] ?? '';
  const error = first ? `${first.line !== undefined ? `line ${first.line}: ` : ''}${bareWords(first.message)}` : said ? `gladius said: ${said}` : 'the build failed';
  return { ok: false, ms, diagnostics: diagnostics.filter((d) => d.severity !== 'info'), error };
}

/** One preview build: `gladius run` to `out` (through a temp file beside it), then `finish`. */
export async function buildPreview({ bin, input, out, options, params, hint, now = Date.now }: PreviewOptions): Promise<PreviewBuilt | PreviewFailure> {
  const began = now();
  await mkdir(dirname(out), { recursive: true });
  const tmp = join(dirname(out), `.${Math.random().toString(36).slice(2)}.glb`);
  try {
    // The export's own build -- clean's wrapper, a refused merge built again unmerged -- in JSON, to a temp file.
    const failed: { ran?: RunError } = {};
    const built = await buildExport({
      input,
      out: tmp,
      options,
      params: paramArgs(params),
      json: true,
      run: async (args) => {
        const ran = await run(bin, args, { cwd: dirname(input), timeoutMs: PREVIEW_MS });
        if ('error' in ran) {
          failed.ran = ran;
          return { code: -1, text: '' };
        }
        return { code: ran.code, text: ran.stdout.includes('{') ? ran.stdout : ran.stdout + ran.stderr };
      },
    });
    const missing = failed.ran;
    if (missing) {
      if (missing.error === 'missing') return { ok: false, ms: now() - began, diagnostics: [], error: 'gladius is not found on this machine', missing: 'gladius', ...(hint ? { hint } : {}) };
      return { ok: false, ms: now() - began, diagnostics: [], error: `gladius ${missing.message}` };
    }
    if (built.code !== 0) return failureOf(built.text, now() - began);
    const bytes = finish(new Uint8Array(await readFile(tmp)), {
      angle: typeof options.angle === 'number' ? options.angle : 70,
      keepNormals: options.keepNormals === true,
      smoothColours: options.smoothColours === true,
    }).bytes;
    // The last one kept, for a look at it by hand; the answer is the bytes.
    await writeFile(tmp, bytes); // write-ok: a temp file, renamed below
    await rename(tmp, out);
    return { ok: true, ms: now() - began, bytes };
  } catch (err) {
    return { ok: false, ms: now() - began, diagnostics: [], error: (err as Error).message };
  } finally {
    await rm(tmp, { force: true });
  }
}
