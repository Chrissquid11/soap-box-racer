/**
 * JSON read with where each value is in the text: what lets the pipeline
 * change one value of a file -- a data file's `"uid"`, a reference's `"key"`
 * (Docs/asset-ids.md §1, rules 2 and 6) -- and leave every other byte as it
 * was, so a file keeps the layout its writer gave it (the editor's
 * `prefabText`, a scene on one line, a level by hand) and a diff is the one
 * line that changed.
 *
 * `spans(text)` parses as `JSON.parse` does (it throws on what that refuses)
 * and answers the tree with each value's `start` and `end`; `withUid` and
 * `topUid` are the data file's own uid, read and written through it.
 *
 * Pure: no import, so the editor's side may share it.
 */

/** A value and where it is: `text.slice(start, end)` is its text. */
export type Span =
  | { type: 'object'; start: number; end: number; members: Member[] }
  | { type: 'array'; start: number; end: number; items: Span[] }
  | { type: 'string'; start: number; end: number; value: string }
  | { type: 'other'; start: number; end: number };

/** An object's member: its key, where the key's text ends (after its closing quote), and its value. */
export interface Member {
  key: string;
  keyStart: number;
  keyEnd: number;
  value: Span;
}

/** `text` parsed, every value with its place. Throws, as `JSON.parse` would, on what is not JSON. */
export function spans(text: string): Span {
  JSON.parse(text); // its refusal, in its words, before anything here is believed
  let at = 0;
  const space = (): void => {
    while (at < text.length && ' \t\n\r'.includes(text[at]!)) at++;
  };
  const string = (): { value: string; start: number; end: number } => {
    const start = at;
    at++;
    while (text[at] !== '"') at += text[at] === '\\' ? 2 : 1;
    at++;
    return { value: JSON.parse(text.slice(start, at)) as string, start, end: at };
  };
  const value = (): Span => {
    space();
    const start = at;
    const c = text[at];
    if (c === '{') {
      at++;
      const members: Member[] = [];
      space();
      if (text[at] === '}') {
        at++;
        return { type: 'object', start, end: at, members };
      }
      for (;;) {
        space();
        const key = string();
        space();
        at++; // :
        const v = value();
        members.push({ key: key.value, keyStart: key.start, keyEnd: key.end, value: v });
        space();
        if (text[at++] === '}') return { type: 'object', start, end: at, members };
      }
    }
    if (c === '[') {
      at++;
      const items: Span[] = [];
      space();
      if (text[at] === ']') {
        at++;
        return { type: 'array', start, end: at, items };
      }
      for (;;) {
        items.push(value());
        space();
        if (text[at++] === ']') return { type: 'array', start, end: at, items };
      }
    }
    if (c === '"') return { type: 'string', ...string() };
    while (at < text.length && !',]} \t\n\r'.includes(text[at]!)) at++;
    return { type: 'other', start, end: at };
  };
  return value();
}

/** One change to a text: `[start, end)` replaced by `text`. */
export interface Edit {
  start: number;
  end: number;
  text: string;
}

/** `text` with the edits made, from the last back, so each one's place still holds. Edits do not overlap. */
export function applyEdits(text: string, edits: readonly Edit[]): string {
  let out = text;
  for (const e of [...edits].sort((a, b) => b.start - a.start)) out = out.slice(0, e.start) + e.text + out.slice(e.end);
  return out;
}

/** The top-level object of a data file's text, or undefined when it is none: it does not parse, or its top level is no object (an array, a number). */
export function topObject(text: string): Extract<Span, { type: 'object' }> | undefined {
  try {
    const top = spans(text);
    return top.type === 'object' ? top : undefined;
  } catch {
    return undefined;
  }
}

/**
 * A data file's own uid: its top-level `"uid"` -- a string, whatever it holds (`isUid` says whether it is
 * one) -- or undefined for none; null when the text is no JSON object: it does not parse, or parses to something
 * else (an array) -- either way left alone, and said by the caller as what it is (`stamp.ts`).
 */
export function topUid(text: string): string | undefined | null {
  const top = topObject(text);
  if (!top) return null;
  const member = top.members.find((m) => m.key === 'uid');
  return member?.value.type === 'string' ? member.value.value : undefined;
}

/**
 * The text with its top-level `"uid"` set to `uid`, every other byte as it was: the value replaced where the
 * file has one, else written as its first member in the file's own layout -- on a line of its own, indented
 * as the next, in a file laid out a line a member; inline (`{"uid":"…",…`) in one on one line, with the
 * spacing its first member has. Null for a text that is no JSON object: left alone, and said by the caller.
 */
export function withUid(text: string, uid: string): string | null {
  const top = topObject(text);
  if (!top) return null;
  const said = JSON.stringify(uid);
  const own = top.members.find((m) => m.key === 'uid');
  if (own) return applyEdits(text, [{ start: own.value.start, end: own.value.end, text: said }]);
  const open = top.start + 1;
  const first = top.members[0];
  if (!first) return applyEdits(text, [{ start: open, end: top.end - 1, text: `"uid": ${said}` }]);
  // The gap before the first member (`\n  `, ` `, or nothing) and what its key and value have between them (`: `, `:`).
  const gap = text.slice(open, first.keyStart);
  const colon = text.slice(first.keyEnd, first.value.start);
  // The rest starts with that same gap, so the old first member keeps its own line, or its own spacing.
  return applyEdits(text, [{ start: open, end: open, text: `${gap}"uid"${colon}${said},` }]);
}
