/**
 * An asset's uid (Docs/asset-ids.md §1, rules 1 and 2): `uid://` and 13
 * characters of base-32 (`a-z`, `2-7`) from 64 random bits --
 * `uid://k7f3q2m9x4b6t`. Made once, by the pipeline, the first time it sees the
 * asset; never changed, never reused. Where one is kept: a data file's
 * top-level `"uid"`, a source's record's `"uid"`, or a loose file's sidecar,
 * `<file>.uid` beside it, holding the uid and a newline.
 *
 * Pure: no `node:` import (`crypto.getRandomValues` is the global one, node's
 * and a browser's), so the editor's side may share it.
 */
import { topUid, withUid } from './json-spans.ts';

/** What every uid starts with. */
export const UID_PREFIX = 'uid://';

/** RFC 4648's base-32 alphabet, lowercase: what follows the prefix. */
const ALPHABET = 'abcdefghijklmnopqrstuvwxyz234567';

/** How many characters follow the prefix: 64 bits, five a character. */
export const UID_LENGTH = 13;

const UID = /^uid:\/\/[a-z2-7]{13}$/;

/**
 * A new uid from 64 random bits: the eight bytes `random` fills (the
 * platform's `crypto.getRandomValues` by default; a test hands in its own),
 * read as one number and written in base-32, 13 characters, the first from
 * the top four bits alone.
 */
export function newUid(random: (bytes: Uint8Array<ArrayBuffer>) => void = (bytes) => void crypto.getRandomValues(bytes)): string {
  const bytes = new Uint8Array(8);
  random(bytes);
  let n = 0n;
  for (const b of bytes) n = (n << 8n) | BigInt(b);
  let out = '';
  for (let i = 0; i < UID_LENGTH; i++) {
    out = ALPHABET[Number(n & 31n)]! + out;
    n >>= 5n;
  }
  return UID_PREFIX + out;
}

/** Is `value` a uid as the pipeline writes one? */
export function isUid(value: unknown): value is string {
  return typeof value === 'string' && UID.test(value);
}

/** A loose file's sidecar's extension: `fredoka-700.woff2.uid`. */
export const SIDECAR_EXT = 'uid';

/** The sidecar beside a loose file: its path and `.uid`. */
export function sidecarOf(path: string): string {
  return `${path}.${SIDECAR_EXT}`;
}

/** Is this name or path a sidecar -- `<file>.uid`? Never a key, never shipped, never in the index. */
export function isSidecar(path: string): boolean {
  return path.toLowerCase().endsWith(`.${SIDECAR_EXT}`);
}

/** The file a sidecar is beside: the path without `.uid`. */
export function sidecarFile(sidecar: string): string {
  return sidecar.slice(0, -(SIDECAR_EXT.length + 1));
}

/** A sidecar's text: the uid and a newline. */
export function sidecarText(uid: string): string {
  return `${uid}\n`;
}

/** The uid a sidecar's text holds, or undefined for one that holds none. */
export function sidecarUid(text: string): string | undefined {
  const uid = text.trim();
  return isUid(uid) ? uid : undefined;
}

/**
 * A data file's text as a writer that knows no uid writes it (Docs/asset-ids.md §1: the file's uid is the file's):
 * with the uid it says when that is one; else the uid the file there had (`was`, its text before; null for none)
 * when that is one; else a new one -- `make`'s. A text that is no JSON object is written as it came. `PUT prefab`'s,
 * and a project's own route's (the tile tool's save): exported from `@vibe/pipeline`.
 */
export function keepUid(text: string, was: string | null, make: () => string = () => newUid()): string {
  const own = topUid(text);
  if (own === null || isUid(own)) return text;
  const had = was === null ? undefined : topUid(was);
  return withUid(text, isUid(had) ? had : make()) ?? text;
}
