/// <reference path="./draco3dgltf.d.ts" preserve="true" />
/**
 * The scripts the Model tab writes for a person (Docs/modeler.md M38, M39;
 * Vibe3D `src/core/newModel.ts`, D34, D36, D40, D49, D90, D92, D112):
 *
 * - **New model** (`starterScript`): empty but valid -- it builds, to a model
 *   with nothing in it (Gladius's `GLD-2007` is a warning: D40) -- and
 *   documented: the units, the axes, `params{}` with an example to uncomment,
 *   `emit` and its name, a material, `info()`. A starter shape would only be in
 *   the way: a mark drawn on the grid says where a thing goes (D33).
 * - **Import** (`importScript`): a `.glb` or `.fbx` copied in beside the script
 *   (`importCopyName`: `<stem>.source.glb`, the extension kept -- Gladius picks
 *   its reader by it, D112) and `import`ed **pinned by its sha256** (D36: an
 *   unpinned import is not reproducible from the script alone), part by part,
 *   keeping what the file carries -- names, materials, colours, hard and soft
 *   edges, skin, clips (D92) -- each step running only where the file has that;
 *   `merge_faces` only on a closed part, an open one emitted `open = true`
 *   (D90). Decided in the script, not here, so it stays right when the copy is
 *   replaced. An FBX's note says what FBX does not bring.
 * - **Compressed sources decoded on the way in** (`decodeForImport`, D92):
 *   Gladius reads plain accessors only, so a Draco, meshopt or quantised `.glb`
 *   is decoded once as it is copied -- the pin is the decoded copy's, what
 *   Gladius reads. Any other file is copied byte for byte.
 *
 * The copy is a **part of its script** (`parts.ts`' `luaParts` finds the names
 * of model files in a script's text): never a source of its own, its hash in
 * the script's record, so replacing it makes the script stale.
 *
 * Pure but for `decodeForImport`, which loads glTF-Transform inside itself.
 */
import { createHash } from 'node:crypto';
import { splitName } from './paths.ts';

/** What Import takes, by extension: Gladius reads both (an `.fbx` since 0.7.2). */
export const IMPORTS = ['glb', 'fbx'] as const;
export type ImportKind = (typeof IMPORTS)[number];

/** The kind of a file to import by its extension, or undefined: not one Gladius imports. */
export function importKind(name: string): ImportKind | undefined {
  const ext = splitName(name).ext.toLowerCase();
  return (IMPORTS as readonly string[]).includes(ext) ? (ext as ImportKind) : undefined;
}

/** `robot` and `glb` -> `robot.source.glb`: the copy beside the script, its extension kept (D112). */
export function importCopyName(stem: string, kind: ImportKind): string {
  return `${stem}.source.${kind}`;
}

/** A Lua string literal's body: what a name or path in a comment or a string must not break. */
const luaString = (text: string): string => text.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, ' ');

/**
 * New model's script (D40): it emits nothing, and says so -- every build reports
 * GLD-2007, a warning, until something is emitted.
 */
export function starterScript(name: string): string {
  return `-- ${name}
--
-- A Gladius script: this file is the model. The pipeline builds it into
-- src/assets/models/…/${name}.glb as it is saved (never edit the .glb), and the
-- editor's Model tab (3) shows each build. Draw over a view and ask Claude in
-- its card, or write it here.
--
-- Units are metres and degrees; Y is up, the model stands on Y = 0, its front
-- toward +Z. Every tunable number belongs in params{} with a min and a max: it
-- is then a slider in the Model tab, and the export's record can set it.
--
-- local P = params{
--   size = {default = 1.0, min = 0.1, max = 4.0, doc = "Edge length, metres"},
-- }
--
-- local mat = material{name = "Wood", base_color = v3(0.55, 0.36, 0.2), roughness = 0.8}
-- local body = box{size = P.size, anchor = "bottom"}
-- emit(body, {name = "body", material = mat})   -- each emit is a part, by its name
-- info(string.format("%d triangles", triangle_count(body)))
--
-- Empty on purpose: until something is emitted every build says GLD-2007
-- ("emitted no geometry") -- a warning about this file being empty, not a fault.
`;
}

/** An import's script (D36, D90, D92, D112): `stem` the model's name, `file` the copy beside it, pinned by `sha256`. */
export function importScript(stem: string, file: string, sha256: string, from: string): string {
  const kind = importKind(file) ?? 'glb';
  // Said in the script, where it is still read in a month, not in a sheet that is gone (D112).
  const fbx =
    kind === 'fbx'
      ? `
--
-- What an FBX brings: its geometry, UVs, parts and a material per part by name.
-- What it does not: textures, skin weights and animation -- a rigged FBX
-- arrives as its rest shape, its maps unset. Set them here, or import a .glb,
-- which carries them.`
      : '';
  return `-- ${stem}
--
-- Imported from ${luaString(from)}: ${file} beside this script is the file as it came
-- (decoded, if it was compressed) and is never written to; this script builds the
-- model from it, and the pipeline its .glb. Edit this script, never either file.${fbx}
--
-- The import is pinned by sha256, so this builds the same model anywhere. Replace
-- ${file} and the hash must change with it, on purpose (GLD-1024 says so).

local p = params{
  scale = {default = 1.0, min = 0.01, max = 10.0, doc = "Uniform scale of the import (0.01 for a file in centimetres)"},
}

-- Gladius names an import's materials "<prefix>:<name>"; the prefix is the model's own name, not the copy's.
local _, source = import("${luaString(file)}", {
  sha256 = "${sha256}",
  prefix = "${luaString(stem)}",
})

-- The file part by part -- one per node and material, named after the node -- so
-- the parts keep the file's names and materials. Each step below runs only where
-- the file carries that data, so this one script fits any import.
for _, part in ipairs(source.parts) do
  -- An import arrives vertex-split (exporters split every vertex at normals and
  -- UV seams): nothing topological works until it is welded.
  local mesh = weld(part.mesh)

  -- merge_faces recovers the quads the exporter threw away, and needs a closed
  -- surface; an open part (a plane, a cape) is emitted as it is, open = true --
  -- union, subtract and intersect refuse an open mesh.
  local closed = is_manifold(mesh)
  if closed then
    mesh = merge_faces(mesh)
  end

  -- The file's own vertex colours and hard and soft edges, sampled back by
  -- position: the weld renumbered the vertices.
  if source.colors then
    mesh = sample_colors(mesh, {source = source.colors})
  end
  if source.normals then
    mesh = smooth_normals(mesh, {source = source.normals})
  else
    mesh = smooth_normals(mesh)
  end

  -- The file's skeleton and its own skin weights, sampled by position.
  if source.skin then
    mesh = bind(mesh, source.skeleton, {source = source.skin})
  end

  -- After bind: scaling a bound mesh scales its skeleton and skin with it.
  mesh = scale(mesh, {factor = p.scale, pivot = origin()})

  emit(mesh, {name = part.name, material = part.material, open = not closed})
end

-- Every animation of the file's skeleton, scaled as the meshes are so it still fits.
for _, clip in ipairs(source.actions or {}) do
  emit_action(scale(clip, {factor = p.scale, pivot = origin()}))
end
`;
}

/** The sha256 of bytes, hex: what `import`'s pin is. */
export function sha256(bytes: Uint8Array): string {
  return createHash('sha256').update(bytes).digest('hex');
}

/** Geometry encodings a GLB can need that Gladius's `import` cannot read (D92): quantisation travels with both. */
export const IMPORT_CODECS = ['KHR_draco_mesh_compression', 'EXT_meshopt_compression', 'KHR_mesh_quantization'] as const;

/** A GLB's `extensionsUsed`, read from its JSON chunk alone; none for a file that is not a GLB (Gladius says what is wrong). */
export function glbExtensions(bytes: Uint8Array): string[] {
  try {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (bytes.byteLength < 20 || view.getUint32(0, true) !== 0x46546c67) return [];
    const length = view.getUint32(12, true);
    const json = JSON.parse(new TextDecoder().decode(bytes.subarray(20, 20 + length))) as { extensionsUsed?: unknown };
    return Array.isArray(json.extensionsUsed) ? json.extensionsUsed.filter((e): e is string => typeof e === 'string') : [];
  } catch {
    return [];
  }
}

/**
 * An import's bytes with their geometry decoded -- or the same bytes, `decoded`
 * empty, when they use none of `IMPORT_CODECS` (copied byte for byte: a round
 * trip through another writer is a change nobody asked for).
 */
export async function decodeForImport(bytes: Uint8Array): Promise<{ bytes: Uint8Array; decoded: string[] }> {
  const decoded = glbExtensions(bytes).filter((e) => (IMPORT_CODECS as readonly string[]).includes(e));
  if (decoded.length === 0) return { bytes, decoded };
  const [{ NodeIO }, { ALL_EXTENSIONS }, { dequantize }, draco3d, { MeshoptDecoder }] = await Promise.all([
    import('@gltf-transform/core'),
    import('@gltf-transform/extensions'),
    import('@gltf-transform/functions'),
    import('draco3dgltf'),
    import('meshoptimizer'),
  ]);
  await MeshoptDecoder.ready;
  const io = new NodeIO()
    .registerExtensions(ALL_EXTENSIONS)
    .registerDependencies({ 'draco3d.decoder': await draco3d.default.createDecoderModule(), 'meshopt.decoder': MeshoptDecoder });
  const document = await io.readBinary(bytes);
  if (decoded.includes('KHR_mesh_quantization')) await document.transform(dequantize());
  // Reading decoded the geometry; the extensions disposed, the writer writes it plain.
  for (const extension of document.getRoot().listExtensionsUsed()) {
    if ((IMPORT_CODECS as readonly string[]).includes(extension.extensionName)) extension.dispose();
  }
  return { bytes: await io.writeBinary(document), decoded };
}

/** Why a stem is no model's name here, or undefined: `validName` checks the rest, with its `.lua`. */
export function stemProblem(stem: string): string | undefined {
  if (stem === '') return 'give it a name';
  if (/\.source$/i.test(stem)) return 'a name ending in .source is an import\'s copy';
  return undefined;
}
