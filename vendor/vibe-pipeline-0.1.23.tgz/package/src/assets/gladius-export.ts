/**
 * A Gladius script built as the export builds it (Docs/assets.md §3; Docs/modeler.md
 * M40-M42): the one place the `gladius run` of the `lua` recipe is put together, so
 * the export's step (`steps/gladius.ts`) and the Model tab's preview
 * (`model-preview.ts`) cannot drift.
 *
 * - **The flags** (`exportFlags`): `--textures embedded` and `--optimise-anim`
 *   always (D123: absent is 5 %, not off), `--merge` but for `none`, and the
 *   hidden-surface removal's -- `--cull-hidden --cull-method` and only the chosen
 *   method's own knob, which Gladius refuses under another (D107).
 * - **Clean** (D48) is a Lua op, not a flag: the script runs under a **prelude**
 *   that wraps `emit` in `clean()`, all on the script's line 1 (as the build
 *   trace's, M34), the script in a function after it -- so a failed build names
 *   the script's own lines, the copy's name said as the script's. A mesh `bind`
 *   made -- and what `translate`, `rotate`, `scale`, `sample_colors`,
 *   `smooth_normals` make of one, which keep the bind (D93) -- is emitted as it
 *   is: clean() drops a skin. The copy is dot-named beside the script, a name
 *   of its own a build (`.crate.3f2a….clean.lua`: `import` resolves there, the
 *   index never lists it, and two builds at once never share one),
 *   taken away after, git-ignored, and one a crash left swept at start.
 * - **A merge Gladius refuses** -- a skinned node, or a textured material
 *   (`GLD-4038`) -- is built again unmerged, said (D84, D93 changed: the skin and
 *   the clips are worth more to a game than one draw call; Vibe3D's merged rig
 *   kept bones and lost its skin).
 * - **What it did, said** (`exportNotes`): the triangles hidden-surface removal
 *   took and the parts it took whole (D105), the animation samples dropped and
 *   the worst error (D98), a mesh kept uncleaned, a merge not made.
 *
 * `exportFlags`, `cleaned`, `exportNotes` and `mergeRefusal` are pure
 * (`gladius-export.test.ts`); `buildExport` runs Gladius through a runner it is
 * handed.
 */
import { readdir, readFile, rm, writeFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { basename, dirname, join } from 'node:path';
import type { Options } from './api-types.ts';

/** Our option's method names, the question each asks, to Gladius's (D107: named by the question, not the algorithm). */
export const CULL_METHODS: Readonly<Record<string, string>> = { unseen: 'camera', unreachable: 'voxel', coplanar: 'coplanar', covered: 'cut' };

/** The cull flags of `options`: none for `none`, and only the chosen method's knob (Gladius refuses another's). */
export function cullFlags(options: Options): string[] {
  const method = CULL_METHODS[String(options.cull ?? 'none')];
  if (!method) return [];
  const args = ['--cull-hidden', '--cull-method', method];
  if (method === 'camera') args.push('--cull-views', String(options.cullViews ?? 64), '--cull-size', String(options.cullResolution ?? 512));
  // 0 is Gladius's own choice, the longest side over 128: no flag.
  if (method === 'voxel' && typeof options.cullVoxel === 'number' && options.cullVoxel > 0) args.push('--cull-voxel', String(options.cullVoxel));
  return args;
}

/** Every export flag of `options` but the parameters, `--out` and the script: `merge` given apart, for the unmerged retry. */
export function exportFlags(options: Options, merge = String(options.merge ?? 'none')): string[] {
  return ['--textures', 'embedded', '--optimise-anim', String(options.anim ?? 5), ...(merge !== 'none' ? ['--merge', merge] : []), ...cullFlags(options)];
}

// ---------------------------------------------------------------- clean

const luaList = (names: readonly string[]): string => `{ ${names.map((n) => `"${n}"`).join(', ')} }`;

/** The ops that hand back a mesh still bound when given one (Gladius ADR-075..077; Vibe3D D93). */
export const KEEP_BIND = ['translate', 'rotate', 'scale', 'sample_colors', 'smooth_normals'] as const;

/** What clean() is asked to drop: everything it can. */
const CLEAN_ARGS = '{ degenerate = true, duplicates = true, orphans = true }';

/**
 * The prelude, one line: an old Gladius with no clean() refused in words; bind's
 * meshes marked (weakly), the mark carried through the ops that keep a bind; emit
 * cleaning all but a marked mesh -- that one said, once each.
 */
const CLEAN_PRELUDE = [
  'if type(clean) ~= "function" then error("this Gladius has no clean(): update it, or turn clean off in the export\'s options", 0) end;',
  'local __c_bound = setmetatable({}, { __mode = "k" });',
  'if type(bind) == "function" then local f = bind; bind = function(m, ...) local b = f(m, ...); __c_bound[b] = true; return b end end;',
  `for _, n in ipairs(${luaList(KEEP_BIND)}) do local f = _G[n]; if type(f) == "function" then`,
  '  _G[n] = function(m, ...) local r = table.pack(f(m, ...)); if __c_bound[m] then __c_bound[r[1]] = true end; return table.unpack(r, 1, r.n) end end end;',
  'local __c_emit, __c_clean = emit, clean;',
  'emit = function(m, o) if __c_bound[m] then',
  `  info("${'clean: kept '}" .. tostring(o and o.name or "a skinned mesh") .. " as it is: it is bound to a skeleton, and clean() would drop its skin"); return __c_emit(m, o) end;`,
  `  return __c_emit(__c_clean(m, ${CLEAN_ARGS}), o) end;`,
  '(function(...) ',
].join(' ');

/** After the script: its function closed and called. */
const CLEAN_EPILOGUE = '\nend)(...)\n';

/** The script `source`, wrapped for clean: its first line on the prelude's, every line where it was. */
export function cleaned(source: string): string {
  const body = source.startsWith('#') ? `--${source}` : source;
  return CLEAN_PRELUDE + body + CLEAN_EPILOGUE;
}

/**
 * `crate.lua` -> `.crate.<id>.clean.lua`, the wrapped copy beside it: one a build, so two builds of one script
 * side by side -- the export's runner and the preview's queue -- never take each other's copy away (review round 1).
 */
export function cleanedName(script: string, id = randomBytes(4).toString('hex')): string {
  return `.${basename(script).replace(/\.lua$/i, '')}.${id}.clean.lua`;
}

/** A wrapped copy's name. */
export const CLEANED = /^\.[^/]+\.clean\.lua$/;

/** A copy beside a script that a server stopped half way left (a trace's, a clean's): `.crate.trace.lua`, `.crate.clean.lua`. */
export const LEFT_COPY = /^\.[^/]+\.(?:trace|clean)\.lua$/;

/**
 * The copies a server that stopped mid-build left under `dir` (the Source root), taken away: each is removed as
 * its build ends, so one found at start is a crash's. Their paths, relative.
 */
export async function sweepCopies(dir: string): Promise<string[]> {
  let names: string[];
  try {
    names = (await readdir(dir, { recursive: true })) as string[];
  } catch {
    return [];
  }
  const left = names.filter((n) => LEFT_COPY.test(n.split(/[\\/]/).pop() ?? ''));
  for (const n of left) await rm(join(dir, n), { force: true });
  return left;
}

// ---------------------------------------------------------------- what it said

/** Gladius's refusal to merge, in words a person acts on -- or undefined where it is not one (`GLD-4038`). */
export function mergeRefusal(output: string): string | undefined {
  if (!/GLD-4038/.test(output)) return undefined;
  const node = /node '([^']+)'/.exec(output)?.[1];
  const material = /material '([^']+)'/.exec(output)?.[1];
  if (/bound to a skeleton/.test(output)) return `not merged: ${node ? `'${node}'` : 'a mesh'} is skinned -- merging would renumber the vertices its skin weights are for -- so the model is exported unmerged, its skin and clips kept`;
  if (/texture/.test(output)) return `not merged: ${material ? `material '${material}'` : 'a material'} carries a texture, and merging combines untextured materials alone -- exported unmerged`;
  return undefined;
}

const n = (value: string | number): string => Number(value).toLocaleString('en-US');

/**
 * The lines worth saying of a build's output (D98, D105): hidden-surface removal's
 * count and what vanished whole, the animation samples dropped and the worst error,
 * each mesh clean() left as it was.
 */
export function exportNotes(output: string): string[] {
  const out: string[] = [];
  const lines = output.split('\n').map((l) => l.trim());
  for (const line of lines) {
    const m = /removed (\d+) of (\d+) triangle\(s\) [—-]+ (\d+) node\(s\) trimmed, (\d+) removed entirely/.exec(line);
    if (!m) continue;
    const gone = Number(m[4]);
    out.push(`hidden surfaces: removed ${n(m[1]!)} of ${n(m[2]!)} triangles -- ${n(m[3]!)} part${m[3] === '1' ? '' : 's'} trimmed${gone > 0 ? `, ${n(gone)} removed entirely` : ''}`);
  }
  // Gladius names the parts that vanished, and the skinned ones it kept whole.
  for (const line of lines) {
    if (/GLD-5005/.test(line)) out.push(`hidden surfaces: ${line.replace(/^GLD-\d+\s+\w+:\s*/, '')}`);
    else if (/GLD-500\d\s+warning/.test(line)) out.push(`hidden surfaces: ${line.replace(/^GLD-\d+\s+\w+:\s*/, '')}`);
  }
  let dropped = 0;
  let total = 0;
  let tolerance = '';
  let degrees = 0;
  let metres = 0;
  for (const line of lines) {
    const c = /dropped (\d+) of (\d+) sample\(s\) at ([\d.]+)%/.exec(line);
    if (!c) continue;
    dropped += Number(c[1]);
    total += Number(c[2]);
    tolerance = c[3]!;
    const e = /worst error ([\d.]+)° \/ ([\d.]+) m/.exec(line);
    if (e) {
      degrees = Math.max(degrees, Number(e[1]));
      metres = Math.max(metres, Number(e[2]));
    }
  }
  if (total > 0) out.push(`animations: dropped ${n(dropped)} of ${n(total)} samples at ${tolerance} % -- worst error ${degrees.toFixed(2)}° / ${metres.toFixed(4)} m`);
  for (const line of lines) {
    const k = /clean: kept (.+) as it is/.exec(line);
    if (k) out.push(`clean: kept ${k[1]} as it is (skinned)`);
  }
  return [...new Set(out)];
}

// ---------------------------------------------------------------- the build

/** What a runner answers: the exit code, and stdout then stderr as one text. */
export interface Built {
  code: number | null;
  text: string;
}

export interface ExportBuild {
  /** The script, absolute: built in its folder. */
  input: string;
  out: string;
  options: Options;
  /** `--param` flags, sorted. */
  params: readonly string[];
  /** `--format json`, for a caller that reads the envelope. */
  json?: boolean;
  /** Runs `gladius` with these arguments in the script's folder. */
  run(args: readonly string[]): Promise<Built>;
}

/** One export build: wrapped for clean if asked, merged if asked -- unmerged again where Gladius refuses that, said. */
export async function buildExport(b: ExportBuild): Promise<Built & { notes: string[] }> {
  const script = basename(b.input);
  const clean = b.options.clean === true;
  const copy = clean ? join(dirname(b.input), cleanedName(b.input)) : undefined;
  const say = (text: string): string => (copy ? text.split(basename(copy)).join(script) : text);
  try {
    if (copy) await writeFile(copy, cleaned(await readFile(b.input, 'utf8'))); // write-ok: dot-named copy beside the script, never listed, removed after
    const go = (merge?: string): Promise<Built> =>
      b.run(['run', ...(b.json ? ['--format', 'json'] : []), ...exportFlags(b.options, merge), ...b.params, '--out', b.out, copy ?? b.input]);
    let built = await go();
    const notes: string[] = [];
    const refused = built.code !== 0 && String(b.options.merge ?? 'none') !== 'none' ? mergeRefusal(built.text) : undefined;
    if (refused) {
      notes.push(refused);
      built = await go('none');
    }
    const text = say(built.text);
    return { code: built.code, text, notes: built.code === 0 ? [...notes, ...exportNotes(text)] : notes };
  } finally {
    if (copy) await rm(copy, { force: true });
  }
}
