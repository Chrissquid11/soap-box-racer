/**
 * One source through its recipe (Docs/assets.md §4, "An export, step by step"):
 *
 *   1. its row and options resolved, checked (the index's `inspect`)
 *   2. refused up front what cannot succeed: a missing part, an LFS pointer, a
 *      tool not found -- the source's status already says which (`refusal`)
 *   3. `.cache/assets/jobs/<id>/` made; the first step's input is the source,
 *      or its `_<stem>.glb`
 *   4. the steps in order, each writing into the job's directory; a browser
 *      step's file becomes `_<stem>.glb` beside the source (`runSteps`); the
 *      files of `to` found among what they wrote (`collectOutputs`)
 *   5. every destination checked first -- a folder where an export goes is
 *      refused before anything moves; a symlink is replaced like a file (a
 *      rename replaces the link, never its target) -- then the previous export
 *      and its record to the trash **by hard link** (a copy, 64 kB or less), kept without moving them:
 *      a new slot for a tool-asked export, the auto slot for an automatic one
 *      and the CLI's. What is "previous" is what that look found on the disk,
 *      not what the index has: an export written behind its back is kept too
 *   6. every file of `to` renamed over its export (never a moment with no
 *      file), **then the record** (its `built.out` the sha1 of each file); the hashes cache and `expected` learn them
 *      by the stat they have in place (`install`). A rename that fails midway
 *      puts back what it had replaced, from the slot of step 5: an export of
 *      two files is both new or both old, never one of each; a new slot made
 *      for it goes again, its files all back in place
 *   7. one terminal line; `runs.json`; the index told
 *   8. on failure at any point: the job dir goes, the export and record stay as
 *      they were, the output goes to `runs.json`, and the terminal says
 *      `[assets] FAILED <source>: <first line>`
 *
 * **A job dropped** (its source deleted while it ran: `Runner.drop`) is told by
 * `signal`: it is looked at before each step and before step 5, and a step's
 * program is stopped by it. Dropped, the export installs nothing and answers
 * `dropped` -- not a failure: nothing in `runs.json`, no `FAILED` line.
 *
 * **Atomic**: steps write only into the job's directory, and only finished
 * files are renamed into place; if `.cache/` is on another volume the rename
 * fails with `EXDEV`, and the file is copied beside its export under a dot-name
 * first, then renamed (`fs.ts`'s `moveFile`). The watcher never sees half a
 * file, and a failure leaves the old export whole.
 *
 * **An export of the unchanged changes nothing in git.** When the new `built`
 * is the old one but for `at`, the record is not written and keeps its `at`:
 * `npm run export -- --force` on a current tree leaves the tree clean (the
 * exports are byte-identical, being deterministic). And when it is the one
 * before the last export -- the record the auto slot kept, an option tried and
 * undone -- it takes that one's `at`, so the record is written back as git has
 * it. When it ran is in `runs.json`, which is this machine's.
 */
import { copyFile, link, lstat, mkdir, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import type { Built, JobMessage, Run } from './api-types.ts';
import type { Catalog, SourceState } from './catalog.ts';
import { code, exists, hashFile, moveFile, writeAtomic, type FileHash } from './fs.ts';
import { Dropped, Unmade, newId } from './jobs.ts';
import { CACHE, TRASH } from './kinds.ts';
import { AUTO_SLOT, baseName, intermediatePath, isoSeconds, splitName, trashPath } from './paths.ts';
import { identity, parseRecord, readRecord, recordText } from './record.ts';
import { canonical } from './recipes.ts';
import { STEPS, type Job } from './steps/index.ts';
import { newSlot, toTrash } from './trash.ts';
import { newUid } from './uid.ts';

// ---------------------------------------------------------------- runs.json

const OUTPUT_MAX = 64 * 1024;

export class Runs {
  readonly file: string;
  readonly rows = new Map<string, Run>();

  constructor(root: string) {
    this.file = join(root, CACHE, 'runs.json');
  }

  async load(): Promise<void> {
    try {
      const json = JSON.parse(await readFile(this.file, 'utf8')) as Record<string, Run>;
      for (const [source, run] of Object.entries(json)) this.rows.set(source, run);
    } catch {
      // None yet, or one cut short: every source's last attempt is unknown, which is no failure.
    }
  }

  get(source: string): Run | undefined {
    return this.rows.get(source);
  }

  /** A source's last attempt; a failure's output kept to its last 64 KB, where the error is. */
  set(source: string, run: Run): void {
    this.rows.set(source, run.output && run.output.length > OUTPUT_MAX ? { ...run, output: run.output.slice(-OUTPUT_MAX) } : run);
  }

  /** The rows of sources no longer there (deleted, renamed, a fixture removed) let go; how many. */
  prune(there: (source: string) => boolean): number {
    let gone = 0;
    for (const source of [...this.rows.keys()]) {
      if (there(source)) continue;
      this.rows.delete(source);
      gone++;
    }
    return gone;
  }

  async save(): Promise<void> {
    await mkdir(dirname(this.file), { recursive: true });
    await writeAtomic(this.file, JSON.stringify(Object.fromEntries(this.rows), null, 1) + '\n');
  }
}

// ---------------------------------------------------------------- one export

export interface ExportContext {
  /** The project root, absolute. */
  root: string;
  catalog: Catalog;
  runs: Runs;
  /** The terminal: one line per export, a failure's first line. */
  log?: (line: string) => void;
  /** A browser step's way to a game tab (the dev server's); absent in the CLI. */
  browser?: (job: Job) => Promise<string>;
  /** Progress, as `job` messages (§5). */
  progress?: (message: JobMessage) => void;
  now?: () => Date;
  /** How a finished file is put in place: `fs.ts`'s `moveFile`. A test watches the order through it, or makes one fail. */
  move?: (from: string, to: string) => Promise<void>;
}

export interface ExportOptions {
  /** Export even a `current` source, and try again one whose last attempt failed. */
  force?: boolean;
  /** The trash slot for the previous export: `auto` (the default: automatic and CLI exports), `new`, or a slot by name. */
  slot?: string;
  /** The job's id; made up when absent. */
  id?: string;
  /** Aborted when the job is dropped: what it made is discarded, never installed. */
  signal?: AbortSignal;
}

export interface ExportResult {
  source: string;
  state: 'done' | 'failed' | 'unmade' | 'skipped' | 'dropped';
  /** Why it was skipped, refused, or unmade. */
  reason?: string;
  exports: string[];
  /** The terminal line of an export that ran, done or failed. */
  line?: string;
  /** Why it failed: its first line, or the refusal's reason. */
  error?: string;
  ms: number;
  /** The slot the previous export went to. */
  slot?: string;
}

/** `1.1 kB`, `212 kB`, `3.4 MB`: decimal, as the Finder says it, one decimal under ten -- as it reads once rounded (9,999 is `10 kB`). */
export function sayBytes(n: number): string {
  if (n < 1000) return `${n} B`;
  if (n < 999_500) return `${(n / 1000).toFixed(n < 9_950 ? 1 : 0)} kB`;
  return `${(n / 1e6).toFixed(n < 9_950_000 ? 1 : 0)} MB`;
}

/** A source's path as the terminal says it: under `AssetsSource/`, without it. */
function said(source: string): string {
  return source.startsWith('AssetsSource/') ? source.slice('AssetsSource/'.length) : source;
}

/** Why a source is not exported now, or undefined to go ahead. */
function refusal(state: SourceState, force: boolean): { state: ExportResult['state']; reason: string } | undefined {
  switch (state.status) {
    case 'stale':
    case 'missing':
      return undefined;
    case 'current':
      return force ? undefined : { state: 'skipped', reason: 'current' };
    case 'failed':
      return force && state.lastRunFailed ? undefined : { state: 'failed', reason: state.reason ?? 'failed' };
    case 'unmade':
      return { state: 'unmade', reason: state.reason ?? 'cannot be made here' };
    // Out of the build, `--force` or not: "excluded: tick it in the tool, or remove `include: false` from its record".
    case 'excluded':
      return { state: 'skipped', reason: `excluded: ${state.reason ?? 'out of the build'}` };
    default:
      return { state: 'skipped', reason: `${state.status}${state.reason ? `: ${state.reason}` : ''}` };
  }
}

/** What one job has made so far: what a failure needs to know too. */
interface Made {
  /** The last step's files, absolute: the first is the keyed one. */
  files: string[];
  /** What each step said. */
  lines: string[];
  /** What a person should read of it (`StepResult.notes`). */
  notes: string[];
  /** `built.deps`: the parts' and the intermediate's hashes. */
  deps: Record<string, string>;
  /** `_<stem>.glb`, if a browser step wrote it beside the source. */
  wroteIntermediate?: string;
}

/** The job: its id and directory, the output it keeps, how it says where it is, whether it is still wanted. */
interface JobRun {
  id: string;
  dir: string;
  output: string[];
  tell: (step: number, state: JobMessage['state'], extra?: Partial<JobMessage>) => void;
  signal: AbortSignal | undefined;
}

/** Throws `Dropped` once the job's source has been deleted: looked at between the steps and before anything is installed. */
function stillWanted(run: JobRun): void {
  if (run.signal?.aborted) throw new Dropped();
}

/**
 * A finished file into place at `dest` (relative to the root): expected first
 * with the stat it has (a rename keeps it), and again if the move made a new
 * one (a copy across volumes). A move that fails took nothing anywhere, so no
 * watch event will come for it: its expectation goes at once.
 */
async function place(ctx: ExportContext, from: string, dest: string, replaced: boolean): Promise<{ mtimeMs: number; size: number }> {
  const before = await stat(from);
  ctx.catalog.expect(dest, before, replaced);
  try {
    await (ctx.move ?? moveFile)(from, join(ctx.root, dest));
  } catch (err) {
    ctx.catalog.expected.delete(dest);
    throw err;
  }
  const after = await stat(join(ctx.root, dest));
  if (after.mtimeMs !== before.mtimeMs || after.size !== before.size) ctx.catalog.expect(dest, after, replaced);
  return after;
}

/** 3, 4: the steps in order, each reading the last one's files and writing its own into the job's directory. */
async function runSteps(ctx: ExportContext, state: SourceState, run: JobRun, made: Made): Promise<void> {
  const { root, catalog } = ctx;
  const abs = (p: string): string => join(root, p);
  const steps = state.found.row.steps;
  const { stem } = splitName(baseName(state.source));
  made.files = [state.fromIntermediate ? abs(state.intermediate!) : abs(state.source)];
  for (let i = state.fromIntermediate ? 1 : 0; i < steps.length; i++) {
    stillWanted(run);
    const step = STEPS[steps[i]!];
    run.tell(i + 1, 'running');
    const job: Job = {
      id: run.id,
      root,
      source: state.source,
      input: made.files[0]!,
      parts: state.parts.map(abs),
      dir: run.dir,
      stem,
      ext: state.found.ext,
      kind: state.found.kind,
      options: state.options,
      tools: catalog.tools ?? new Map(),
      bin: (tool) => catalog.tools?.get(tool)?.path ?? tool,
      log: (text) => void run.output.push(text),
      ...(ctx.browser ? { browser: ctx.browser } : {}),
      ...(run.signal ? { signal: run.signal } : {}),
    };
    const result = await step.run(job);
    if (result.line) made.lines.push(result.line);
    if (result.notes) {
      made.notes.push(...result.notes);
      made.lines.push(...result.notes);
    }
    made.files = result.files;
    if (step.where === 'browser') {
      // The tab's file is the intermediate now: beside the source, temp then rename.
      const ip = intermediatePath(state.source);
      const tmp = join(run.dir, `_${stem}.glb.tmp`);
      await copyFile(made.files[0]!, tmp);
      await place(ctx, tmp, ip, await exists(abs(ip)));
      made.deps[baseName(ip)] = (await hashFile(abs(ip))).sha1;
      made.wroteIntermediate = ip;
    }
  }
}

/**
 * The files of `to`, each in the job's directory. The first is the keyed one:
 * the last step's first file, whatever its name, checked for its extension; the
 * rest are found among the others by extension (an atlas's `.json` beside its
 * sheet). A step that passed its input on hands back a file outside the job:
 * it is copied in, never moved -- it may be the source.
 */
async function collectOutputs(files: readonly string[], to: readonly string[], dir: string): Promise<string[]> {
  const outputs: string[] = [];
  for (let k = 0; k < to.length; k++) {
    const ext = to[k]!;
    const file = k === 0 ? files[0] : files.slice(1).find((f) => f.toLowerCase().endsWith(`.${ext}`));
    if (!file || !file.toLowerCase().endsWith(`.${ext}`)) throw new Error(`the steps wrote no .${ext}`);
    if (!file.startsWith(dir)) {
      const inside = join(dir, `out-${k}.${ext}`);
      await copyFile(file, inside);
      outputs.push(inside);
    } else outputs.push(file);
  }
  return outputs;
}

/** What `install` did: the slot the previous export went to, the files it moved besides, what to say. */
interface Installed {
  slot?: string;
  touched: string[];
  lines: string[];
}

/** The `built` of the record the auto slot keeps for this one -- what the last export replaced -- if it parses. */
async function keptBuilt(root: string, record: string): Promise<Built | undefined> {
  try {
    return parseRecord(await readFile(join(root, trashPath(AUTO_SLOT, record)), 'utf8')).built;
  } catch {
    return undefined;
  }
}

/**
 * 5, 6: every destination checked, the previous export and record kept in the
 * trash by hard link, every file of `to` renamed over its export, then the
 * record -- or, when the new `built` differs from the old only in `at`, no
 * record written at all. A rename that fails puts back what was replaced.
 */
async function install(ctx: ExportContext, state: SourceState, outputs: readonly string[], hashes: readonly FileHash[], made: Made, run: JobRun, slotAsked: string | undefined, at: Date): Promise<Installed> {
  const { root, catalog } = ctx;
  const abs = (p: string): string => join(root, p);
  const record = state.recordPath;

  // 5. Every destination first: something there that is not a file (or a link, which a rename replaces) is in the way,
  // before anything moves. What is there is what this export replaces -- the disk's word, not the index's.
  const there = new Set<string>();
  for (const dest of [...state.exports, record]) {
    const info = await lstat(abs(dest)).catch((err: unknown) => {
      if (code(err) === 'ENOENT') return undefined;
      throw err;
    });
    if (info === undefined) continue;
    if (!info.isFile() && !info.isSymbolicLink()) throw new Error(`${dest} is in the way and is not a file`);
    there.add(dest);
  }
  // Where Blender made it here, a leftover hand export goes to the trash once this is in place: no dep of the record.
  const leftover = state.found.row.steps[0] === 'blender' && !state.fromIntermediate && catalog.entries.has(intermediatePath(state.source)) ? intermediatePath(state.source) : undefined;
  if (leftover !== undefined) delete made.deps[baseName(leftover)];
  const built: Built = {
    source: state.hash!,
    recipe: state.recipe!,
    to: state.to,
    at: isoSeconds(at),
    ...(Object.keys(made.deps).length > 0 ? { deps: made.deps } : {}),
    tools: state.tools ?? {},
    // What went into place, by extension: what `--check` and the status hold the shipped files to.
    out: Object.fromEntries(state.to.map((ext, k) => [ext, hashes[k]!.sha1])),
  };
  // The unchanged: the old `at` kept, and the record not written -- git sees nothing.
  const old = state.record?.built;
  const unchanged = old !== undefined && canonical({ ...old, at: '' }) === canonical({ ...built, at: '' });
  if (unchanged) built.at = old.at;
  // Built again as it was before the last export -- an option changed and undone: the record that one replaced, kept in
  // the auto slot, gives its `at`, so the record goes back to the bytes git has.
  const before = unchanged ? undefined : await keptBuilt(root, record);
  if (before !== undefined && canonical({ ...before, at: '' }) === canonical({ ...built, at: '' })) built.at = before.at;
  const previous = [...state.exports, ...(unchanged ? [] : [record])].filter((p) => there.has(p));
  stillWanted(run); // the last look: from here, what is made goes into place
  const slotMade = slotAsked === 'new';
  const slot = previous.length === 0 ? undefined : slotAsked === undefined || slotAsked === AUTO_SLOT ? AUTO_SLOT : slotMade ? await newSlot(root, at) : slotAsked;
  if (slot !== undefined) await toTrash(root, previous, slot, 'link');

  // 6. Every export renamed over the last, then the record; put back as it was if a rename fails.
  const installed: string[] = [];
  const rows: Array<[string, number, number, string]> = [];
  try {
    for (let k = 0; k < outputs.length; k++) {
      const dest = state.exports[k]!;
      const after = await place(ctx, outputs[k]!, dest, there.has(dest));
      installed.push(dest);
      rows.push([dest, after.mtimeMs, after.size, hashes[k]!.sha1]);
    }
    if (!unchanged) {
      const tmp = join(run.dir, 'record.json');
      // The options as they are now, not as they were read: one set through `PUT sidecar` while this ran is kept
      // (and this export, built with the old ones, reads stale against them -- the next one, queued behind, makes them).
      // So is the record's `"include": false`, written by hand meanwhile: the record says what it said.
      // And the asset's uid (Docs/asset-ids.md §1): the record's, or -- its first record -- a new one; and the stem it ships `as`.
      const now = await readRecord(root, state.source, record);
      const was = now.record ?? state.record;
      const named = { ...identity(was), uid: was?.uid ?? newUid() };
      await writeFile(tmp, recordText({ ...(now.record?.include === false ? { include: false as const } : {}), ...named, options: now.record?.options ?? state.record?.options ?? {}, built, ...(now.record?.more ? { more: now.record.more } : {}) })); // write-ok: the job's directory; place() renames it over the record
      await place(ctx, tmp, record, there.has(record));
      installed.push(record);
    }
  } catch (err) {
    const problems = await putBack(ctx, installed, slot !== undefined ? previous : [], slot, run.id);
    // A slot made for this export, everything in it back in place byte for byte: a Trash row for an export that never happened goes.
    if (slot !== undefined && slotMade && problems.length === 0) await rm(join(root, TRASH, slot), { recursive: true, force: true });
    if (problems.length > 0) (err as Error).message += `; and putting the old files back failed: ${problems.join('; ')}`;
    throw err;
  }
  // The hashes cache learns the exports without reading them back, by the stat they have in place.
  for (const [dest, mtimeMs, size, sha] of rows) catalog.hashes.set(dest, mtimeMs, size, sha);

  // The leftover hand export, and the line says so. Failing that, the export stands, and says so too.
  const touched: string[] = [];
  const lines: string[] = [];
  if (leftover !== undefined) {
    try {
      await toTrash(root, [leftover], slot ?? AUTO_SLOT, 'move');
      touched.push(leftover);
      lines.push(`a leftover ${baseName(leftover)} moved to the trash`);
    } catch (err) {
      lines.push(`a leftover ${baseName(leftover)} could not be moved to the trash: ${(err as Error).message}`);
    }
  }
  return { ...(slot !== undefined && previous.length > 0 ? { slot } : {}), touched, lines };
}

/**
 * Step 6 undone: each file already renamed into place goes back to the one it
 * replaced -- from the slot step 5 linked it into, through a dot-named temp
 * file and a rename, so it is never missing -- or, where there was none, goes.
 * Answers what could not be put back.
 */
async function putBack(ctx: ExportContext, installed: readonly string[], previous: readonly string[], slot: string | undefined, id: string): Promise<string[]> {
  const problems: string[] = [];
  for (const dest of [...installed].reverse()) {
    const abs = join(ctx.root, dest);
    // What comes back is news: its watch event is read, not consumed.
    ctx.catalog.expected.delete(dest);
    try {
      const kept = slot !== undefined && previous.includes(dest) ? join(ctx.root, trashPath(slot, dest)) : undefined;
      if (kept !== undefined && (await exists(kept))) {
        // Not fs.ts's random temp name: the job's id, so one a crash mid-rollback leaves says whose it is. Dot-named, `.tmp`: never listed.
        const tmp = join(dirname(abs), `.${baseName(dest)}.${id}.back.tmp`);
        try {
          await link(kept, tmp);
        } catch {
          await copyFile(kept, tmp); // no hard link here (another volume, a FAT disk): a copy
        }
        await rename(tmp, abs);
      } else await rm(abs, { force: true });
    } catch (err) {
      problems.push(`${dest}: ${(err as Error).message}`);
    }
  }
  return problems;
}

/** One source exported, or said why not. Never throws for the source's own failure: that is a result. */
export async function exportSource(ctx: ExportContext, source: string, options: ExportOptions = {}): Promise<ExportResult> {
  const started = performance.now();
  const ms = (): number => Math.round(performance.now() - started);
  const { root, catalog } = ctx;
  const state = await catalog.inspect(source);
  const no = refusal(state, options.force === true);
  if (no) return { source: state.source, state: no.state, reason: no.reason, ...(no.state === 'failed' ? { error: no.reason } : {}), exports: state.exports, ms: ms() };

  const id = options.id ?? newId();
  const steps = state.found.row.steps;
  const run: JobRun = {
    id,
    dir: join(root, CACHE, 'jobs', id),
    output: [],
    tell: (step, s, extra = {}) => ctx.progress?.({ id, source: state.source, step, of: steps.length, state: s, ...extra }),
    signal: options.signal,
  };
  const made: Made = { files: [], lines: [], notes: [], deps: { ...(state.deps ?? {}) } };
  const at = ctx.now?.() ?? new Date();
  try {
    await mkdir(run.dir, { recursive: true });
    await runSteps(ctx, state, run, made);
    const outputs = await collectOutputs(made.files, state.to, run.dir);
    const hashes = await Promise.all(outputs.map((f) => hashFile(f)));
    stillWanted(run);
    const installed = await install(ctx, state, outputs, hashes, made, run, options.slot, at);

    // 7.
    const record = state.recordPath;
    const line = `[assets] ${said(state.source)} -> ${state.exports[0]}  ${sayBytes(hashes[0]!.size)}  ${(ms() / 1000).toFixed(1)} s`;
    ctx.log?.(line);
    ctx.runs.set(state.source, { at: isoSeconds(at), ms: ms(), ok: true, source: state.hash!, deps: made.deps, recipe: state.recipe!, ...(made.notes.length > 0 ? { notes: made.notes } : {}) });
    await catalog.learn([...state.exports, record, ...installed.touched, ...(made.wroteIntermediate ? [made.wroteIntermediate] : [])]);
    if (installed.slot !== undefined || installed.touched.length > 0) await catalog.readTrash();
    await catalog.refresh(state.source);
    run.tell(steps.length, 'done', { ms: ms(), ...(installed.slot !== undefined ? { slot: installed.slot } : {}), ...(made.notes.length > 0 ? { notes: made.notes } : {}) });
    const lines = [...made.lines, ...installed.lines];
    return {
      source: state.source,
      state: 'done',
      exports: state.exports,
      line: [line, ...lines.map((l) => `  ${l}`)].join('\n'),
      ms: ms(),
      ...(installed.slot !== undefined ? { slot: installed.slot } : {}),
    };
  } catch (err) {
    const message = (err as Error).message;
    // An intermediate a browser step wrote stays: it was made from this very source. Its watch event was expected, so the index is told here.
    if (made.wroteIntermediate) await catalog.learn([made.wroteIntermediate]);
    if (err instanceof Dropped || options.signal?.aborted) {
      // Its source is gone or going: nothing installed, nothing to remember. The runner says `dropped`.
      await catalog.refresh(state.source);
      return { source: state.source, state: 'dropped', reason: 'its source was deleted', exports: state.exports, ms: ms() };
    }
    if (err instanceof Unmade) {
      run.tell(0, 'unmade', { error: message });
      await catalog.refresh(state.source);
      return { source: state.source, state: 'unmade', reason: message, exports: state.exports, ms: ms() };
    }
    const first = message.split('\n')[0]!;
    const all = [...run.output, (err as { output?: string }).output ?? ''].join('\n').trim();
    ctx.log?.(`[assets] FAILED ${said(state.source)}: ${first}`);
    ctx.runs.set(state.source, {
      at: isoSeconds(at),
      ms: ms(),
      ok: false,
      source: state.hash ?? '',
      deps: state.deps ?? {},
      recipe: state.recipe ?? '',
      error: first,
      output: all || message,
    });
    run.tell(0, 'failed', { error: first, ms: ms() });
    await catalog.refresh(state.source);
    return { source: state.source, state: 'failed', error: first, exports: state.exports, line: `[assets] FAILED ${said(state.source)}: ${first}`, ms: ms() };
  } finally {
    await rm(run.dir, { recursive: true, force: true });
  }
}
