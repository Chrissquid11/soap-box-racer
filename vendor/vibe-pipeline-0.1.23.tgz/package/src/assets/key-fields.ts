/**
 * A game's own key fields, read from its source (Docs/asset-ids.md §1 rule 3, Docs/properties.md P3): which field of
 * which component holds an asset key of which kind -- `component('Traits', { call: key('Sfx'), preens: mesh() })` is
 * `Traits.call` a `Sfx` and `Traits.preens` a `Model` mesh -- so the repair pass can give a bare key written there by
 * hand its uid (`upgradeRefs`' `fields`), as it does `Render.model`'s, without running the game's code.
 *
 * **By pattern, as the `ecs` check reads a system**: a `component('Name', { … })` call with its name a string
 * literal, and among its schema's own properties (depth one of its braces, strings and comments skipped) each
 * `field: key('Kind'…)` or `field: mesh(…)`. A field declared any other way -- a `key()` kept in a variable, a
 * schema built by a function -- is not found, and a bare key in it stays bare until the editor or Claude writes it
 * (both always write `{ uid, key }`). `Clip` is no asset: left out.
 *
 * A `...NAME` spread of a `const NAME = { … }` in the same file is read too. Read over the project's `src/` and the
 * engine's (`keyFieldsIn`, every `.ts` but `.d.ts`), each file kept by its mtime and size so a pass reads only what
 * changed. Pure but for that walk.
 */
import { existsSync, readFileSync, statSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { walkSync } from './fs.ts';

/** A key field: the key type it holds (`Sfx`, `Model`, a project's `Tilemap`), and whether it is a `mesh()` (`{ uid, key, part }`). */
export interface KeyField {
  readonly type: string;
  readonly mesh: boolean;
  /**
   * A data component's field (`dataComponent('Loot', { drops: list(key('Prefab')) })`): where its keys are inside its
   * value, by its schema's own shape -- a list's elements, a dict's values, a record's fields by name -- never any
   * other text in it (an enum's name, a string, a ref's id).
   */
  readonly deep?: KeyShape;
}

/** Where a data component's keys are, as its maker declares them: a key, or a list, dict or record holding some. */
export type KeyShape =
  | { readonly key: string; readonly mesh: boolean }
  | { readonly list: KeyShape }
  | { readonly dict: KeyShape }
  | { readonly record: Readonly<Record<string, KeyShape>> };

/** Component name -> field -> what it holds. */
export type KeyFields = ReadonlyMap<string, ReadonlyMap<string, KeyField>>;

/** `source` with its strings' and comments' insides blanked (same length): what a brace or a comma there means nothing. */
function blank(source: string): string {
  return source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*|(['"`])(?:\\.|(?!\1)[^\\])*\1/g, (m) => (m.startsWith('/') ? ' '.repeat(m.length) : m[0] + ' '.repeat(Math.max(0, m.length - 2)) + m[m.length - 1]));
}

/**
 * The key fields of the object literal whose `{` is at `open` in `source` (`flat` its blanked copy): each own property
 * `field: key('Kind'…)` or `field: mesh(…)`, and each `...NAME` spread of a `const NAME = { … }` of the same file
 * (`consts`) -- the engine's colliders share their `material` that way (`...COLLIDER`).
 */
function schemaFields(source: string, flat: string, open: number, consts: ReadonlyMap<string, number>, seen: ReadonlySet<string> = new Set()): Map<string, KeyField> {
  // The schema's own properties: from its `{` to the matching `}`, each starting at depth one.
  let depth = 0;
  let end = open;
  const starts: number[] = [open + 1];
  for (let i = open; i < flat.length; i++) {
    const c = flat[i];
    if (c === '{' || c === '(' || c === '[') depth++;
    else if (c === '}' || c === ')' || c === ']') {
      depth--;
      if (depth === 0) {
        end = i;
        break;
      }
    } else if (c === ',' && depth === 1) starts.push(i + 1);
  }
  const fields = new Map<string, KeyField>();
  starts.forEach((at, n) => {
    const upTo = n + 1 < starts.length ? starts[n + 1]! - 1 : end;
    const part = source.slice(at, upTo);
    const shape = flat.slice(at, upTo);
    const spread = /^\s*\.\.\.\s*([A-Za-z_$][\w$]*)\s*$/.exec(shape);
    if (spread) {
      const from = consts.get(spread[1]!);
      if (from !== undefined && !seen.has(spread[1]!)) for (const [f, k] of schemaFields(source, flat, from, consts, new Set([...seen, spread[1]!]))) fields.set(f, k);
      return;
    }
    const prop = /^\s*(?:(['"]?)([A-Za-z_$][\w$]*)\1)\s*:\s*(key|mesh)\s*\(/.exec(shape);
    if (!prop) return;
    if (prop[3] === 'mesh') return void fields.set(prop[2]!, { type: 'Model', mesh: true });
    const kind = /:\s*key\s*\(\s*(['"])([A-Za-z]\w*)\1/.exec(part);
    if (kind && kind[2] !== 'Clip') fields.set(prop[2]!, { type: kind[2]!, mesh: false });
  });
  return fields;
}

/** Every component's key fields declared in `source`. */
export function keyFieldsOf(source: string): Map<string, Map<string, KeyField>> {
  const out = new Map<string, Map<string, KeyField>>();
  const flat = blank(source);
  // The file's `const NAME = { … }` objects, by name: what a schema's `...NAME` spreads.
  const consts = new Map<string, number>();
  const declared = /\bconst\s+([A-Za-z_$][\w$]*)\s*(?::[^=]*)?=\s*\{/g;
  for (let m = declared.exec(flat); m !== null; m = declared.exec(flat)) consts.set(m[1]!, m.index + m[0].length - 1);
  const call = /\bcomponent\(\s*(['"])([^'"]+)\1\s*,\s*\{/g;
  for (let m = call.exec(flat); m !== null; m = call.exec(flat)) {
    // The name from the source itself (the blanked copy has it emptied).
    const name = /\bcomponent\(\s*(['"])([^'"]+)\1/.exec(source.slice(m.index))![2]!;
    const fields = schemaFields(source, flat, m.index + m[0].length - 1, consts);
    if (fields.size > 0) out.set(name, fields);
  }
  for (const [name, fields] of dataKeyFieldsOf(source, flat)) out.set(name, new Map([...(out.get(name) ?? []), ...fields]));
  return out;
}

/** The index of the bracket closing the one at `open` in `flat`. */
function closeOf(flat: string, open: number): number {
  let depth = 0;
  for (let i = open; i < flat.length; i++) {
    const c = flat[i];
    if (c === '{' || c === '(' || c === '[') depth++;
    else if (c === '}' || c === ')' || c === ']') {
      depth--;
      if (depth === 0) return i;
    }
  }
  return flat.length;
}

/** Past one expression from `i`: to the `,` or the closing bracket that ends it, at its own depth. */
function skipExpr(flat: string, i: number): number {
  let depth = 0;
  for (; i < flat.length; i++) {
    const c = flat[i];
    if (c === '{' || c === '(' || c === '[') depth++;
    else if (c === '}' || c === ')' || c === ']') {
      if (depth === 0) return i;
      depth--;
    } else if (c === ',' && depth === 0) return i;
  }
  return i;
}

/**
 * The maker at `i` -- `list(…)`, `dict(…, …)`, `record({ … })`, `key('Kind')`, `mesh()` -- as where its keys are, and
 * where it ends; null for one that holds none (a number, an enum named by a variable, a string, a ref).
 */
function shapeAt(source: string, flat: string, i: number): { shape: KeyShape | null; end: number } {
  while (/\s/.test(flat[i] ?? '')) i++;
  const m = /^(list|dict|record|key|mesh)\s*\(/.exec(flat.slice(i, i + 12));
  if (!m) return { shape: null, end: skipExpr(flat, i) };
  const open = i + m[0].length - 1;
  const close = closeOf(flat, open);
  const end = close + 1;
  if (m[1] === 'mesh') return { shape: { key: 'Model', mesh: true }, end };
  if (m[1] === 'key') {
    const kind = /^\s*(['"])([A-Za-z]\w*)\1/.exec(source.slice(open + 1, close))?.[2];
    return { shape: kind && kind !== 'Clip' ? { key: kind, mesh: false } : null, end };
  }
  if (m[1] === 'list') {
    const of = shapeAt(source, flat, open + 1).shape;
    return { shape: of ? { list: of } : null, end };
  }
  if (m[1] === 'dict') {
    const comma = skipExpr(flat, open + 1);
    const value = flat[comma] === ',' ? shapeAt(source, flat, comma + 1).shape : null;
    return { shape: value ? { dict: value } : null, end };
  }
  let at = open + 1;
  while (/\s/.test(flat[at] ?? '')) at++;
  if (flat[at] !== '{') return { shape: null, end };
  const fields = recordAt(source, flat, at);
  return { shape: Object.keys(fields).length > 0 ? { record: fields } : null, end };
}

/** The fields of the object literal at `open` (`{ a: maker, b: maker }`) that hold keys, by name. */
function recordAt(source: string, flat: string, open: number): Record<string, KeyShape> {
  const out: Record<string, KeyShape> = {};
  const close = closeOf(flat, open);
  let i = open + 1;
  while (i < close) {
    const prop = /^\s*(['"]?)([A-Za-z_$][\w$]*)\1\s*:/.exec(flat.slice(i, close));
    if (!prop) {
      i = skipExpr(flat, i) + 1;
      continue;
    }
    const { shape, end } = shapeAt(source, flat, i + prop[0].length);
    if (shape) out[prop[2]!] = shape;
    i = skipExpr(flat, end) + 1;
  }
  return out;
}

/** The first key a shape holds: a field's `type` and `mesh`, for what reads a key field flat. */
function firstKey(shape: KeyShape): { key: string; mesh: boolean } {
  if ('key' in shape) return shape;
  if ('list' in shape) return firstKey(shape.list);
  if ('dict' in shape) return firstKey(shape.dict);
  return firstKey(Object.values(shape.record)[0]!);
}

/**
 * A data component's key fields: each top-level field whose maker holds keys -- `list(key('Prefab'))`, `dict(Slot,
 * key('Sfx'))`, `list(record({ slot: Slot, item: key('Prefab') }))` -- with where they are (`deep`), by the schema's own
 * shape read from the source: a record's fields by name, a list's elements, a dict's values. Nothing else in it is
 * taken for a key -- an enum's name, a string, a ref's id.
 */
function dataKeyFieldsOf(source: string, flat: string): Map<string, Map<string, KeyField>> {
  const out = new Map<string, Map<string, KeyField>>();
  const call = /\bdataComponent\(\s*(['"])([^'"]+)\1\s*,\s*\{/g;
  for (let m = call.exec(flat); m !== null; m = call.exec(flat)) {
    const name = /\bdataComponent\(\s*(['"])([^'"]+)\1/.exec(source.slice(m.index))![2]!;
    const fields = new Map<string, KeyField>();
    for (const [f, shape] of Object.entries(recordAt(source, flat, m.index + m[0].length - 1))) {
      const first = firstKey(shape);
      fields.set(f, { type: first.key, mesh: first.mesh, deep: shape });
    }
    if (fields.size > 0) out.set(name, fields);
  }
  return out;
}

/** Each file read, by its path: its stamp and what it declared. */
const read = new Map<string, { stamp: string; fields: Map<string, Map<string, KeyField>> }>();

/**
 * Every key field declared under the project's `src/` (`root` the project's root) -- and the engine's own, under its
 * `src/` as the project resolves it (`@vibe/engine`: every collider's `material`, a hull's and a mesh's `mesh`, a
 * height field's `heights`), so a bare key a person writes in one gets its uid too -- the files read again only when
 * changed.
 */
export function keyFieldsIn(root: string): KeyFields {
  const out = new Map<string, Map<string, KeyField>>();
  const engine = engineSrc(root);
  if (engine !== null) collect(engine, out, (rel) => !rel.endsWith('.test.ts'));
  collect(join(root, 'src'), out, () => true);
  return out;
}

/**
 * The engine's `src/` as the project at `root` resolves `@vibe/engine`: up from the file an entry resolves to -- in
 * the workspace a source file, in a published package one of `dist/` -- to the folder with its `package.json`, and
 * its `src/` (which the tarball ships beside `dist/`); null where it does not resolve or has none.
 */
function engineSrc(root: string): string | null {
  let dir: string;
  try {
    dir = dirname(createRequire(join(root, 'package.json')).resolve('@vibe/engine/physics-settings'));
  } catch {
    return null;
  }
  for (let up = dir; ; up = dirname(up)) {
    if (existsSync(join(up, 'package.json'))) return existsSync(join(up, 'src')) ? join(up, 'src') : null;
    if (dirname(up) === up) return null;
  }
}

/** The key fields declared in `dir`'s `.ts` files that `take`, into `out`. */
function collect(dir: string, out: Map<string, Map<string, KeyField>>, take: (rel: string) => boolean): void {
  for (const rel of walkSync(dir)) {
    if (!rel.endsWith('.ts') || rel.endsWith('.d.ts') || !take(rel)) continue;
    const file = join(dir, rel);
    let stamp: string;
    try {
      const s = statSync(file);
      stamp = `${s.mtimeMs}:${s.size}`;
    } catch {
      continue;
    }
    let kept = read.get(file);
    if (kept?.stamp !== stamp) {
      let text = '';
      try {
        text = readFileSync(file, 'utf8');
      } catch {
        continue;
      }
      kept = { stamp, fields: /\b(?:c|dataC)omponent\(/.test(text) ? keyFieldsOf(text) : new Map() };
      read.set(file, kept);
    }
    for (const [name, fields] of kept.fields) out.set(name, new Map([...(out.get(name) ?? []), ...fields]));
  }
}
