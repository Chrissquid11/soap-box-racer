/**
 * The generated files (Docs/assets.md §4): what is on disk, and what `kinds.ts`
 * says ships, written where the game's TypeScript and Vite can read them. Was
 * `scripts/gen-asset-keys.mjs`.
 *
 *   src/assets/keys.d.ts      the key types: a string-literal union per kind,
 *                             and the packs (`AssetKeys.Model`, `AssetKeys.Pack`)
 *   src/assets/globs.ts       the registry's globs, with the extension lists as
 *                             the literals `import.meta.glob` needs
 *   src/assets/level-globs.ts the levels' glob
 *   src/assets/prefab-globs.ts the prefabs' glob
 *   src/assets/scene-globs.ts the scenes' glob
 *   src/assets/material-globs.ts the materials' glob
 *   src/assets/pack-kinds.ts  the pack folders, a model's image extensions, MIME
 *   src/assets/prefab-bundle.ts the prefab files handed to the engine (`usePrefabFiles`):
 *                             `prefab-globs.ts`' one importer, the worker's way to them
 *   src/assets/material-bundle.ts the material files handed to the engine (`useMaterialFiles`):
 *                             `material-globs.ts`' one importer; the page's alone (three), never the worker's
 *   src/assets/bundle.ts      the rest handed to the engine (`useBundle`): the other four
 *                             globs' one importer, and `main.ts`'s first import
 *   src/assets/uids.ts        every asset's uid -> its kind and key (`stamp.ts`' scan), handed to
 *                             the engine (`useUids`, Docs/asset-ids.md §2): `prefab-bundle.ts`' import
 *                             (so the worker resolves by uid as the page does), accepting its own hot updates -- a stamp or a move re-evaluates it alone
 *   src/game/live.ts          the game's swap boundary (Docs/ecs.md §22): the game entry's
 *                             one importer, accepting it, and the maker of its workers --
 *                             the one file that knows the project's layout (`liveGame`)
 *   src/assets/<name>-globs.ts a project's own data kind's glob (`vibe({ kinds })`, `ProjectKind`),
 *                             one a kind, beside `level-globs.ts` and handed in by `bundle.ts` the same way
 *
 * There is no manifest: a key is a file's path under its kind's folder, without
 * the extension, lowercased (`caseKey`: `models/characters/Crab.glb` is
 * `characters/crab`, a pack's with its prefix, `reef:props/coral`); two files
 * whose paths are one key -- `Crate.glb` beside `crate.glb` -- throw, both named. `keys.d.ts` has each prefab's shape
 * too, from `prefab-names.ts`: its node names (`AssetKeys.PrefabNodes`),
 * what its root and each named entity is made of (`AssetKeys.PrefabComponents`)
 * and the model each entity draws (`AssetKeys.PrefabViews`, checked against
 * `AssetKeys.Model` in `src/prefab-token.ts`: a `.d.ts` is not checked itself),
 * and the material each wears (`AssetKeys.PrefabMaterials`, held to `AssetKeys.Material`).
 * A prefab file that does not parse, or nests one that is not there, keeps its
 * key, has `never` for both, and is printed. A `.json` under `prefabs/` is no
 * prefab and no key (prefab files end in `.prefab`): printed once a process.
 * All twelve are gitignored: a generated
 * file that is committed conflicts as badly as a hand-written one when two
 * people add an asset on the same day, and nothing in them is a decision.
 *
 * **Vite rewrites `import.meta.glob` only for literal arguments**, which is why
 * the lists were written three times before; now they are written once, in
 * `kinds.ts`, and spelled out here. Each glob file has exactly one importer --
 * `prefab-globs.ts` `prefab-bundle.ts`, `material-globs.ts` `material-bundle.ts`, the other four `bundle.ts` --
 * and the three bundles accept their own hot updates, so a file added, removed or re-exported
 * re-evaluates the one bundle and nothing else: it hands the fresh maps to the
 * engine, which syncs them into the live ones in place (`useBundle`,
 * `usePrefabFiles`, `useMaterialFiles`). A prefab edit wakes only the prefab bundle, a material's the material bundle.
 *
 * **Written only when the text differs**: the same text rewritten would be a
 * watch event, and a second, empty HMR pass on every drop. Throws on a
 * duplicate key rather than exiting, so the dev server can say so and stay up.
 * Synchronous, and nothing at module level: `vibe assets` runs it at install
 * and before every build.
 */
import { existsSync, readFileSync, readdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { skipped, walkSync, writeAtomicSync } from './fs.ts';
import { KINDS, MATERIAL_SUFFIX, MIME, PREFAB_SUFFIX, ROOTS, SCENE_SUFFIX, isDataKind, kindDef, packed, shipped, type KindName, type ProjectKind, type ProjectKinds } from './kinds.ts';
import { prefabNames } from './prefab-names.ts';
import { scanUids, uidIndex, uidKeys, type UidRow, type UidScan } from './stamp.ts';
import { strayMaterial, strayPrefab } from './paths.ts';
import { caseKey } from '@vibe/engine/case-key';

/** The generated files every project has, relative to its root; a project's kinds add theirs (`generatedFiles`). */
export const GENERATED = [
  'src/assets/keys.d.ts',
  'src/assets/globs.ts',
  'src/assets/level-globs.ts',
  'src/assets/prefab-globs.ts',
  'src/assets/scene-globs.ts',
  'src/assets/material-globs.ts',
  'src/assets/pack-kinds.ts',
  'src/assets/prefab-bundle.ts',
  'src/assets/material-bundle.ts',
  'src/assets/bundle.ts',
  'src/assets/uids.ts',
  'src/game/live.ts',
] as const;

/** A project kind's glob file, relative to the root: `src/assets/tilemaps-globs.ts`. */
export const dataGlobsFile = (name: string): string => `${ROOTS.boot.dir}/${name}-globs.ts`;

/** Every generated file of a project with these kinds: `GENERATED`, each kind's glob file after `material-globs.ts`. */
export function generatedFiles(kinds: ProjectKinds = {}): string[] {
  const at = GENERATED.indexOf('src/assets/material-globs.ts') + 1;
  return [...GENERATED.slice(0, at), ...Object.keys(kinds).map(dataGlobsFile), ...GENERATED.slice(at)];
}

/**
 * Is `path` (relative to the root, with `/`) a generated file, whatever kinds the project has: one of
 * `GENERATED`, or any `src/assets/*-globs.ts` -- the name the generator keeps for itself, so a project's
 * `.gitignore` says `src/assets/*-globs.ts` once and never names a kind.
 */
export function isGenerated(path: string): boolean {
  return (GENERATED as readonly string[]).includes(path) || /^src\/assets\/[^/]+-globs\.ts$/.test(path);
}

/** The packs: folders under `packs/`, none starting with `_` or `.`. */
function packNames(root: string): string[] {
  const dir = join(root, ROOTS.packs.dir);
  if (!existsSync(dir)) return [];
  return readdirSync(dir, { withFileTypes: true })
    .filter((e) => e.isDirectory() && !skipped(e.name))
    .map((e) => e.name)
    .sort();
}

/** `.ext` or `.{a,b}`: a brace with one name is not a list to every glob library. */
function extGlob(exts: readonly string[]): string {
  return exts.length === 1 ? exts[0]! : `{${exts.join(',')}}`;
}

/** The regex source matching any of the extensions at the end of a name. */
function extRegex(exts: readonly string[]): string {
  return `/\\.(${exts.join('|')})$/i`;
}

const HEADER = (file: string): string =>
  `// ${file} -- AUTO-GENERATED by packages/pipeline/src/assets/keys.ts from kinds.ts. Do not edit, do not commit.\n` +
  '// Regenerated by `vibe assets`, on dev, typecheck, build and install, and by the dev server\n' +
  '// whenever a file appears or goes. Vite needs the extension lists as literals: they live in\n' +
  '// packages/pipeline/src/assets/kinds.ts, and are spelled out here.\n';

/** `src/assets/keys.d.ts`, from what is on disk, with a project's own kinds. Throws on a duplicate key. */
export function keysText(root: string, kinds: ProjectKinds = {}, scan: UidScan = scanUids(root, kinds)): string {
  const problems: string[] = [];
  const found = new Map<KindName, Map<string, string>>((Object.keys(KINDS) as KindName[]).map((k) => [k, new Map()]));
  const collect = (kind: KindName, dir: string, ext: readonly string[], prefix: string, label: string): number => {
    const allowed = new Set(ext);
    const keys = found.get(kind)!;
    let added = 0;
    for (const file of walkSync(dir)) {
      const dot = file.lastIndexOf('.');
      if (dot < 0 || !allowed.has(file.slice(dot + 1).toLowerCase())) continue;
      const key = caseKey(prefix + file.slice(0, dot));
      const clash = keys.get(key);
      if (clash) {
        problems.push(`  ${clash} and ${label}/${file} both want the key '${key}' (a key is the path lowercased, without the extension) -- rename one.`);
        continue;
      }
      keys.set(key, `${label}/${file}`);
      added++;
    }
    return added;
  };
  for (const kind of Object.keys(KINDS) as KindName[]) {
    const def = kindDef(kind);
    collect(kind, join(root, ROOTS.boot.dir, def.dir), def.ext, '', `${ROOTS.boot.dir}/${def.dir}`);
  }
  // Only packs with something in them get a name: the zipper skips an empty one,
  // and a name that is missing at runtime would typecheck and throw only live.
  const packs: string[] = [];
  for (const pack of packNames(root)) {
    let assets = 0;
    for (const kind of Object.keys(KINDS) as KindName[]) {
      const def = kindDef(kind);
      if (!def.inPacks) continue;
      assets += collect(kind, join(root, ROOTS.packs.dir, pack, def.dir), def.packExt ?? def.ext, `${pack}:`, `${ROOTS.packs.dir}/${pack}/${def.dir}`);
    }
    if (assets) packs.push(caseKey(pack));
  }
  // A project's own kinds: a folder each under src/assets/, nothing in packs (`ProjectKind`).
  const own = new Map<string, Map<string, string>>();
  for (const [name, kind] of Object.entries(kinds)) {
    const keys = new Map<string, string>();
    own.set(name, keys);
    const allowed = new Set(kind.ext);
    for (const file of walkSync(join(root, ROOTS.boot.dir, kind.dir))) {
      const dot = file.lastIndexOf('.');
      if (dot < 0 || !allowed.has(file.slice(dot + 1).toLowerCase())) continue;
      const key = caseKey(file.slice(0, dot));
      const clash = keys.get(key);
      if (clash) problems.push(`  ${clash} and ${ROOTS.boot.dir}/${kind.dir}/${file} both want the key '${key}' (a key is the path lowercased, without the extension) -- rename one.`);
      else keys.set(key, `${ROOTS.boot.dir}/${kind.dir}/${file}`);
    }
  }
  if (problems.length) throw new Error('[assets] duplicate keys:\n' + problems.join('\n'));
  sayStrays(root);
  sayGltfBuffers(root, found.get('models')!);
  const union = (values: string[]): string => (values.length ? values.sort().map((v) => JSON.stringify(v)).join(' | ') : 'never');
  const blocks = (Object.keys(KINDS) as KindName[]).map((kind) => {
    const def = kindDef(kind);
    const keys = found.get(kind)!;
    return `  /** ${keys.size} in ${ROOTS.boot.dir}/${def.dir}${packs.length ? ' and packs/' : ''}. */\n  type ${def.type} = ${union([...keys.keys()])};`;
  });
  for (const [name, kind] of Object.entries(kinds)) {
    const keys = own.get(name)!;
    blocks.push(`  /** ${keys.size} in ${ROOTS.boot.dir}/${kind.dir}: the project's own kind '${name}' (vibe({ kinds })), read with Assets.data('${name}', key). */\n  type ${kind.type} = ${union([...keys.keys()])};`);
  }
  blocks.push(`  /** Packs under packs/, mountable with Assets.mount(). */\n  type Pack = ${union(packs)};`);
  const dataRows = [`    levels: Level;`, ...Object.entries(kinds).map(([name, kind]) => `    ${name}: ${kind.type};`)];
  blocks.push(`  /** The data kinds \`Assets.data(kind, key)\` reads, each to its key type: the levels, and the project's own. */\n  type DataKinds = {\n${dataRows.join('\n')}\n  };`);
  const registryKinds = (Object.keys(KINDS) as KindName[]).filter((kind) => !isDataKind(kind));
  blocks.push(`  /** The registry's kinds (\`globs.ts\`): what the engine's \`useBundle\` takes a glob of. */\n  type Kind = ${union(registryKinds)};`);
  // What a `key(kind)` field may hold (the engine's `KeyKind`, with `Clip`): every kind's key type, the project's own too.
  const keyKinds = [...(Object.keys(KINDS) as KindName[]).map((kind) => kindDef(kind).type), ...Object.values(kinds).map((kind) => kind.type)];
  blocks.push(`  /** The kinds a \`key(kind)\` field may hold (\`key('Sfx')\`): every kind's key type, the project's own too. */\n  type KeyKind = ${union(keyKinds)};`);
  blocks.push(prefabNodesBlock(root, found.get('prefabs')!, uidKeys(scan)));
  return `// AUTO-GENERATED by packages/pipeline/src/assets/keys.ts -- do not edit, do not commit.
// Regenerate with \`vibe assets\`. Runs automatically on dev, typecheck,
// build and install, and whenever a file changes while the dev server is up.
//
// A key is the file's path under its kind's folder, without the extension, lowercased
// (a lookup takes any case):
//   src/assets/models/characters/Crab.glb -> Assets.instance('characters/crab')
//   packs/reef/models/props/coral.glb     -> Assets.instance('reef:props/coral')
// A leading underscore on a file or folder keeps it out of the build entirely.

declare namespace AssetKeys {
${blocks.join('\n\n')}
}
`;
}

/** The stray prefab files already printed: the dev server regenerates on every file added, and says each once. */
const straysSaid = new Set<string>();

/**
 * A `.json` under `src/assets/prefabs/` or `src/assets/materials/` -- no prefab, no material, no key -- printed,
 * once each a process (Docs/prefabs.md §2, Docs/render.md §4).
 */
function sayStrays(root: string): void {
  for (const [kind, stray] of [['prefabs', strayPrefab], ['materials', strayMaterial]] as const) {
    const dir = `${ROOTS.boot.dir}/${KINDS[kind].dir}`;
    for (const file of walkSync(join(root, dir))) {
      const path = `${dir}/${file}`;
      const found = stray(path);
      if (!found || straysSaid.has(path)) continue;
      straysSaid.add(path);
      console.warn(`[assets] ${path}: ${found.problem}${found.renameTo !== undefined ? ` (${found.renameTo})` : ''}`);
    }
  }
}

/** The `.gltf` files already printed for their buffers: once each a process, as the stray prefabs. */
const buffersSaid = new Set<string>();

/**
 * A `.gltf` that ships whose buffers are files beside it (`"uri": "crate.bin"`), printed: the `.bin` is no
 * key and is not shipped, and hashing renames the `.gltf` the loader resolves it against -- the model loads
 * in no build. A `.glb`, or a `.gltf` with its buffers inline (`data:`), is whole (src/assets/README.md).
 */
function sayGltfBuffers(root: string, models: ReadonlyMap<string, string>): void {
  for (const file of models.values()) {
    if (!file.toLowerCase().endsWith('.gltf') || buffersSaid.has(file)) continue;
    let uris: string[] = [];
    try {
      const json = JSON.parse(readFileSync(join(root, file), 'utf8')) as { buffers?: Array<{ uri?: unknown }> };
      uris = (json.buffers ?? []).flatMap((b) => (typeof b.uri === 'string' && !b.uri.startsWith('data:') ? [b.uri] : []));
    } catch {
      continue; // one that does not parse is the loader's to say
    }
    if (uris.length === 0) continue;
    buffersSaid.add(file);
    console.warn(`[assets] ${file} names its buffers as files beside it (${uris.join(', ')}): they do not ship -- export a .glb, or embed them`);
  }
}

/**
 * `interface PrefabNodes`: each prefab key's node names, what `P.node(name)`
 * takes; `interface PrefabComponents`: by key, its root (`''`) and each named
 * entity, the names of what it is made of -- what `init` takes on it
 * (`src/prefab-token.ts`); `PrefabViews` and `PrefabMaterials`, each entity's
 * model and material. A file with a problem is printed and has `never`.
 */
function prefabNodesBlock(root: string, keys: ReadonlyMap<string, string>, uids: ReadonlyMap<string, string>): string {
  const files: Record<string, unknown> = {};
  for (const [key, file] of keys) {
    try {
      files[key] = JSON.parse(readFileSync(join(root, file), 'utf8'));
    } catch (e) {
      files[key] = e instanceof Error ? e : new Error(String(e));
    }
  }
  // A reference by uid as the key it has now (Docs/asset-ids.md §1): a moved model's prefab typechecks before the repair pass rewrites it.
  const { names, components, views, materials, problems } = prefabNames(files, (uid) => uids.get(uid));
  if (problems.length) console.warn(`[assets] prefabs whose node names are never (the compile at boot will say it too):\n${problems.join('\n')}`);
  const union = (list: readonly string[]): string => (list.length ? list.map((n) => JSON.stringify(n)).join(' | ') : 'never');
  const sorted = [...keys.keys()].sort();
  const rows = sorted.map((key) => `    ${JSON.stringify(key)}: ${union(names.get(key) ?? [])};`);
  const shapes = sorted.map((key) => {
    const shape = components.get(key);
    if (!shape) return `    ${JSON.stringify(key)}: never;`;
    return `    ${JSON.stringify(key)}: {\n${[...shape].map(([name, list]) => `      ${JSON.stringify(name)}: ${union(list)};`).join('\n')}\n    };`;
  });
  // Each `Render.model` as the model's key: a part after `#` is the compile's to check (Docs/render.md §2).
  const drawn = sorted.flatMap((key) => {
    const each = [...(views.get(key) ?? [])];
    return each.length ? [`    ${JSON.stringify(key)}: {\n${each.map(([path, model]) => `      ${JSON.stringify(path)}: ${JSON.stringify(model.split('#')[0])};`).join('\n')}\n    };`] : [];
  });
  // Each `Render.material` as written: held to `AssetKeys.Material` the same way (Docs/render.md §4).
  const worn = sorted.flatMap((key) => {
    const each = [...(materials.get(key) ?? [])];
    return each.length ? [`    ${JSON.stringify(key)}: {\n${each.map(([path, material]) => `      ${JSON.stringify(path)}: ${JSON.stringify(material)};`).join('\n')}\n    };`] : [];
  });
  const block = (doc: string, name: string, lines: string[]): string => `  /** ${doc} */\n  interface ${name} {${lines.length ? `\n${lines.join('\n')}\n  ` : ''}}`;
  return [
    block("Each prefab's node names: what `P.node(name)` takes (src/prefab-token.ts).", 'PrefabNodes', rows),
    block("What each prefab's root (`\"\"`) and each named entity of it are made of: what `init` takes on one (src/prefab-token.ts).", 'PrefabComponents', shapes),
    block("The model each prefab's entities draw, by id path (`\"\"` its root): each `Render.model` (a part after `#` left out) held to `Model` by src/prefab-token.ts, so a typo in a file fails the typecheck.", 'PrefabViews', drawn),
    block("The material each prefab's entities wear, by id path (`\"\"` its root): each `Render.material` held to `Material` by src/prefab-token.ts, so a typo in a file fails the typecheck.", 'PrefabMaterials', worn),
  ].join('\n\n');
}

/** `src/assets/globs.ts`: every registry kind's glob, its prefix, and what under it is not a key. */
export function globsText(): string {
  const rows = (Object.keys(KINDS) as KindName[])
    .filter((kind) => !isDataKind(kind))
    .map((kind) => {
      const def = kindDef(kind);
      const notKey = def.beside && def.beside.length > 0 ? extRegex(def.beside) : 'null';
      return (
        `  ${kind}: {\n` +
        `    prefix: '${def.dir}',\n` +
        `    notKey: ${notKey},\n` +
        `    files: import.meta.glob<string>(['./${def.dir}/**/*.${extGlob(shipped(kind))}', '!**/_*', '!**/_*/**'], { eager: true, query: '?url', import: 'default' }),\n` +
        `  },`
      );
    });
  return `${HEADER('src/assets/globs.ts')}// Imported by bundle.ts alone.

/** Every kind the registry has: its folder, what under it is not a key, and its files by hashed URL. */
export const GLOBS = {
${rows.join('\n')}
} as const;
`;
}

/** `src/assets/level-globs.ts`: the levels, parsed, by path. */
export function levelGlobsText(): string {
  return `${HEADER('src/assets/level-globs.ts')}// Imported by bundle.ts alone.

/** Every level file, parsed, by its path under src/assets/: \`./levels/beach.json\`. */
export const LEVELS = import.meta.glob<unknown>(['./${KINDS.levels.dir}/**/*.${extGlob(KINDS.levels.ext)}', '!**/_*', '!**/_*/**'], { eager: true, import: 'default' });
`;
}

/**
 * `src/assets/<name>-globs.ts`: a project's own data kind's files, parsed, by path, and the folder a key
 * is its path under -- as `level-globs.ts`. Imported by bundle.ts alone.
 */
export function dataGlobsText(name: string, kind: ProjectKind): string {
  const file = dataGlobsFile(name);
  return `${HEADER(file)}// Imported by bundle.ts alone. The project's own kind '${name}' (vibe({ kinds }) in vite.config.ts).

/** Every ${kind.type} file, parsed, by its path under src/assets/ (\`./${kind.dir}/a.${kind.ext[0]}\`), and the folder its key is the path under. */
export const ${name.toUpperCase()} = {
  dir: '${kind.dir}',
  files: import.meta.glob<unknown>(['./${kind.dir}/**/*.${extGlob(kind.ext)}', '!**/_*', '!**/_*/**'], { eager: true, import: 'default' }),
};
`;
}

/** `src/assets/prefab-globs.ts`: the prefab files, parsed, by path. */
export function prefabGlobsText(): string {
  return `${HEADER('src/assets/prefab-globs.ts')}// Imported by prefab-bundle.ts alone.

/** A prefab file's ending (JSON inside): what its key is its path without. */
export const PREFAB_SUFFIX = '${PREFAB_SUFFIX}';

/** Every prefab file, parsed, by its path under src/assets/: \`./prefabs/crates/little.prefab\`. */
export const PREFABS = import.meta.glob<unknown>(['./${KINDS.prefabs.dir}/**/*.${extGlob(KINDS.prefabs.ext)}', '!**/_*', '!**/_*/**'], { eager: true, import: 'default' });
`;
}

/** `src/assets/scene-globs.ts`: the scene files, parsed, by path. */
export function sceneGlobsText(): string {
  return `${HEADER('src/assets/scene-globs.ts')}// Imported by bundle.ts alone.

/** A scene file's ending (a world save inside): what its key is its path without. */
export const SCENE_SUFFIX = '${SCENE_SUFFIX}';

/** Every scene file, parsed, by its path under src/assets/: \`./scenes/forest/camp.scene\`. */
export const SCENES = import.meta.glob<unknown>(['./${KINDS.scenes.dir}/**/*.${extGlob(KINDS.scenes.ext)}', '!**/_*', '!**/_*/**'], { eager: true, import: 'default' });
`;
}

/** `src/assets/material-globs.ts`: the material files, parsed, by path. */
export function materialGlobsText(): string {
  return `${HEADER('src/assets/material-globs.ts')}// Imported by material-bundle.ts alone.

/** A material file's ending (JSON inside): what its key is its path without. */
export const MATERIAL_SUFFIX = '${MATERIAL_SUFFIX}';

/** Every material file, parsed, by its path under src/assets/: \`./materials/props/rust.material\`. */
export const MATERIALS = import.meta.glob<unknown>(['./${KINDS.materials.dir}/**/*.${extGlob(KINDS.materials.ext)}', '!**/_*', '!**/_*/**'], { eager: true, import: 'default' });
`;
}

/** `src/assets/pack-kinds.ts`: what the engine's `assets/packs.ts` needs to decode a zip by folder. */
export function packKindsText(): string {
  const kinds = (Object.keys(KINDS) as KindName[]).filter((k) => kindDef(k).inPacks);
  const folders = kinds.map((k) => kindDef(k).dir.replace(/\//g, '\\/')).join('|');
  const exts = [...new Set(kinds.flatMap((k) => packed(k)))];
  const mime = exts
    .filter((e) => MIME[e] !== undefined)
    .map((e) => `  ${e}: '${MIME[e]}',`)
    .join('\n');
  return `${HEADER('src/assets/pack-kinds.ts')}// Imported by bundle.ts alone.

/** A file in a pack's zip: its kind's folder (the first group) and its path under it, without the extension (the second). */
export const PACK_FOLDER = /^(${folders})\\/(.+)\\.[^.]+$/;

/** An image under \`models/\`: a model's own texture, found by name, not a key of its own. */
export const MODEL_IMAGE = ${extRegex(kindDef('models').beside ?? [])};

/** Content types of what a pack carries, by extension. */
export const MIME: Readonly<Record<string, string>> = {
${mime}
};
`;
}

/**
 * `src/assets/prefab-bundle.ts`: the prefab files handed to the engine. Its own file, apart from
 * `bundle.ts`, so the game's worker -- which compiles the prefabs and must stay free of three.js
 * and the page -- reaches them without the asset runtime.
 */
export function prefabBundleText(): string {
  return `${HEADER('src/assets/prefab-bundle.ts')}// The project's prefab files handed to the engine: prefab-globs.ts' one importer, and uids.ts' -- the uid index
// first, so the prefabs' references resolve by uid on both threads alike. Imported by bundle.ts and by the game's
// worker (game/worker.ts), which compiles them with no asset runtime; the worker never hot-updates, so its import
// is no second path for one. In the dev server this module accepts its own hot updates: a prefab file added,
// removed or saved re-evaluates it alone, and \`usePrefabFiles\` syncs the fresh files into the engine's live map
// in place and tells its listeners -- the page never reloads.
import './uids.ts';
import { PREFABS, PREFAB_SUFFIX } from './prefab-globs.ts';
import { usePrefabFiles } from '@vibe/engine';

usePrefabFiles({ files: PREFABS, suffix: PREFAB_SUFFIX });
if (import.meta.hot) import.meta.hot.accept();
`;
}

/**
 * `src/assets/material-bundle.ts`: the material files handed to the engine. Its own file, apart from
 * `bundle.ts`, so a material saved re-evaluates it alone and the engine sets the new values into the
 * shared three material in place; the page's alone -- the worker draws nothing.
 */
export function materialBundleText(): string {
  return `${HEADER('src/assets/material-bundle.ts')}// The project's material files handed to the engine: material-globs.ts' one importer. Imported by bundle.ts
// alone (the game's worker draws nothing). In the dev server this module accepts its own hot updates: a material
// file added, removed or saved re-evaluates it alone, and \`useMaterialFiles\` syncs the fresh files into the engine's
// map in place and compiles what changed into the shared three material every view wears -- the page never reloads.
import { MATERIALS, MATERIAL_SUFFIX } from './material-globs.ts';
import { useMaterialFiles } from '@vibe/engine';

useMaterialFiles({ files: MATERIALS, suffix: MATERIAL_SUFFIX });
if (import.meta.hot) import.meta.hot.accept();
`;
}

/** `src/assets/bundle.ts`: the project's assets handed to the engine, and `main.ts`'s first import. */
export function bundleText(kinds: ProjectKinds = {}): string {
  const names = Object.keys(kinds);
  const imports = names.map((name) => `import { ${name.toUpperCase()} } from './${name}-globs.ts';\n`).join('');
  const data = names.length ? `, data: { ${names.map((name) => `${name}: ${name.toUpperCase()}`).join(', ')} }` : '';
  // Every key type to its kind's name -- the table's and the project's own: what a key field's picker lists by (`kind-keys.ts`).
  const types = [...(Object.keys(KINDS) as KindName[]).map((name) => [kindDef(name).type, name] as const), ...Object.entries(kinds).map(([name, k]) => [k.type, name] as const)];
  const typed = `, types: { ${types.map(([type, name]) => `${type}: ${JSON.stringify(name)}`).join(', ')} }`;
  return `${HEADER('src/assets/bundle.ts')}// The project's assets handed to the engine: the one importer of globs.ts, level-globs.ts, scene-globs.ts,
// pack-kinds.ts and each of the project's own kinds' <name>-globs.ts (prefab-bundle.ts holds prefab-globs.ts and
// uids.ts, material-bundle.ts material-globs.ts), and main.ts's first import. In the dev server it
// accepts its own hot updates: a file added, removed or re-exported under src/assets/ re-evaluates this module
// alone, and \`useBundle\` syncs the fresh maps into the live ones in place -- nothing else is evaluated again
// and the page never reloads.
// Their order is no matter: each only hands its map to the engine (whose index, imported by each, defines the
// components first), and nothing is compiled or resolved as they are imported -- the boot does that, after them all.
// And the project's physics.json, served by vibe() as \`virtual:vibe/physics\` (Docs/physics.md §3): an edit of it is
// an update of that module, which this one accepts, and the running physics takes the settings live.
import './prefab-bundle.ts';
import './material-bundle.ts';
import { GLOBS } from './globs.ts';
import { LEVELS } from './level-globs.ts';
import { SCENES, SCENE_SUFFIX } from './scene-globs.ts';
import { MIME, MODEL_IMAGE, PACK_FOLDER } from './pack-kinds.ts';
${imports}import { useBundle } from '@vibe/engine/assets';
import { usePhysicsSettings } from '@vibe/engine';
import PHYSICS from 'virtual:vibe/physics';

usePhysicsSettings(PHYSICS);
useBundle({ globs: GLOBS, levels: LEVELS, scenes: { files: SCENES, suffix: SCENE_SUFFIX }, packs: { MIME, MODEL_IMAGE, PACK_FOLDER }${data}${typed} });
if (import.meta.hot) import.meta.hot.accept();
`;
}

/**
 * `src/assets/uids.ts`: every asset's uid -> its kind and key, handed to the engine (`useUids`, Docs/asset-ids.md
 * §2) -- the boot set's; a pack carries its own (`uids.json`, `packs.ts`). Its own module, imported by `prefab-bundle.ts`
 * alone -- so the game's worker, which compiles the prefabs, has the index too -- and accepting its own hot updates, so a uid stamped or an asset moved re-evaluates it and nothing else.
 */
export function uidsText(rows: ReadonlyMap<string, UidRow>): string {
  const lines = [...rows].map(([uid, row]) => `  ${JSON.stringify(uid)}: { kind: ${JSON.stringify(row.kind)}, key: ${JSON.stringify(row.key)}${row.type !== undefined ? `, type: ${JSON.stringify(row.type)}` : ''} },`);
  return `${HEADER('src/assets/uids.ts')}// Every asset's uid (Docs/asset-ids.md): what the pipeline stamped on it -- in a data file's JSON, a source's
// record, a loose file's .uid sidecar -- with its kind and key now. Imported by prefab-bundle.ts alone (the page's and the worker's); in the dev server it
// accepts its own hot updates, and \`useUids\` takes the fresh rows in place -- the page never reloads.
import { useUids } from '@vibe/engine';

useUids({${lines.length ? `\n${lines.join('\n')}\n` : ''}});
if (import.meta.hot) import.meta.hot.accept();
`;
}

/**
 * `src/game/live.ts`: the game's swap boundary, beside the game's entry. Generated because Vite's
 * `accept(deps)` takes paths relative to the module holding the call, written as literals: only a
 * file in the project, at a place it knows, can say them -- and a worker's URL, the same.
 */
export function liveText(): string {
  return `// src/game/live.ts -- AUTO-GENERATED by packages/pipeline/src/assets/keys.ts. Do not edit, do not commit.
// The game's swap boundary (Docs/ecs.md §22): the one importer of the game's entry, accepted here so a change
// under src/game/ swaps into the running game with no reload. The accept is spelled out because Vite's server
// finds a boundary's deps by that literal text. The worker is made here too: its URL is this folder's.
import * as entry from './index.ts';
import { liveGame } from '@vibe/engine/boot';

export const live = liveGame(entry, import.meta.hot, () => new Worker(new URL('./worker.ts', import.meta.url), { type: 'module' }));
if (import.meta.hot) import.meta.hot.accept(['./index.ts'], ([next]) => live.arrived(next));
`;
}

/** A file written only when its text differs, whole (a temp file, then a rename: Vite never reads half). True when it was written. */
function writeIfChanged(file: string, text: string): boolean {
  if (existsSync(file) && readFileSync(file, 'utf8') === text) return false;
  writeAtomicSync(file, text);
  return true;
}

/**
 * Every generated file -- the twelve, and a glob file a project kind (`kinds`, the project's
 * `vibe({ kinds })`: `projectKinds` reads them before Vite runs) -- each written only if its text
 * changed. Answers the ones written, relative to the root. Throws on a duplicate key (and then
 * writes nothing). A `src/assets/*-globs.ts` of a kind no longer there -- taken out of the config -- is
 * deleted, and answered among the written: generated and gitignored, nothing of anyone's, and left it would
 * be a glob file with no importer.
 */
export function generateKeys(root: string, kinds: ProjectKinds = {}): string[] {
  const scan = scanUids(root, kinds);
  const texts: Record<string, string> = {
    'src/assets/keys.d.ts': keysText(root, kinds, scan),
    'src/assets/globs.ts': globsText(),
    'src/assets/level-globs.ts': levelGlobsText(),
    'src/assets/prefab-globs.ts': prefabGlobsText(),
    'src/assets/scene-globs.ts': sceneGlobsText(),
    'src/assets/material-globs.ts': materialGlobsText(),
    'src/assets/pack-kinds.ts': packKindsText(),
    'src/assets/prefab-bundle.ts': prefabBundleText(),
    'src/assets/material-bundle.ts': materialBundleText(),
    'src/assets/bundle.ts': bundleText(kinds),
    'src/assets/uids.ts': uidsText(uidIndex(scan, kinds).boot),
    'src/game/live.ts': liveText(),
  };
  for (const [name, kind] of Object.entries(kinds)) texts[dataGlobsFile(name)] = dataGlobsText(name, kind);
  const wrote: string[] = [];
  const files = generatedFiles(kinds);
  for (const file of files) if (writeIfChanged(join(root, file), texts[file]!)) wrote.push(file);
  // A glob file of a kind the config no longer has: removed -- by its name and its generated header, never a hand-written
  // file -- and listed with a `-` so the CLI can say removed.
  const assets = join(root, ROOTS.boot.dir);
  for (const name of existsSync(assets) ? readdirSync(assets) : []) {
    const file = `${ROOTS.boot.dir}/${name}`;
    if (isGenerated(file) && !files.includes(file) && readFileSync(join(root, file), 'utf8').includes('AUTO-GENERATED')) {
      rmSync(join(root, file), { force: true });
      wrote.push(`-${file}`);
    }
  }
  return wrote;
}
