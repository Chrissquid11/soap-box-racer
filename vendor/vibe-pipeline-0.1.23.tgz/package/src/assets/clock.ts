/**
 * Time, for the pipeline's waits (Docs/assets.md §4): the index's quiet and
 * expected windows, the runner's tab deadlines, a drop's hold. The real one
 * here; a test hands in one it moves by hand (`testing.ts`), so the deadlines
 * run in a blink.
 *
 * Its own module so the runner (`jobs.ts`) needs nothing else to load: the
 * index and the steps stay out of a server that only queues.
 *
 * A timer handle is Node's (`ReturnType<typeof setTimeout>`: both programs see
 * Node's `setTimeout`) or a test clock's number. Nothing at module level but
 * the one constant.
 */

/** What `Clock.setTimeout` answers, and `clearTimeout` takes. */
export type TimerHandle = ReturnType<typeof setTimeout> | number;

export interface Clock {
  now(): number;
  setTimeout(fn: () => void, ms: number): TimerHandle;
  clearTimeout(handle: TimerHandle): void;
}

/** The machine's clock. Its timers never keep the process alive: the CLI exits when its work is done. */
export const REAL_CLOCK: Clock = {
  now: () => Date.now(),
  setTimeout: (fn, ms) => {
    const handle = setTimeout(fn, ms);
    handle.unref?.();
    return handle;
  },
  clearTimeout: (handle) => clearTimeout(handle),
};
