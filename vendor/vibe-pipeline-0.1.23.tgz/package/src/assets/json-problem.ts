/**
 * A JSON file's parse error, with the line it is on: what the dev server says
 * of a prefab file it will not hand the page (`server.ts`' `hotUpdate`, the
 * push's `problem`), and what the Assets tool shows in red (Docs/prefabs.md §7).
 *
 * `JSON.parse`'s message gives a position (and, in newer engines, the line);
 * the line is worked out from the position either way, so it reads the same in
 * node and every browser. Pure: a node test covers it (`json-problem.test.ts`).
 */

/** Why `text` is not JSON, and on which line (1 and up) when the parser says where; null when it parses. */
export function jsonProblem(text: string): { message: string; line?: number } | null {
  try {
    JSON.parse(text);
    return null;
  } catch (err) {
    const raw = err instanceof Error ? err.message : String(err);
    const at = /position (\d+)/.exec(raw);
    const lineSaid = /line (\d+)/.exec(raw);
    const line = at ? text.slice(0, Number(at[1])).split('\n').length : lineSaid ? Number(lineSaid[1]) : text.trim() === '' ? 1 : undefined;
    // The engine's own words, less where it puts the position: the line is said apart.
    const message = raw.replace(/\s*(?:in JSON )?at position \d+(?: \(line \d+ column \d+\))?/, '').replace(/^JSON\.parse: /, '') || 'not JSON';
    return line !== undefined ? { message, line } : { message };
  }
}
