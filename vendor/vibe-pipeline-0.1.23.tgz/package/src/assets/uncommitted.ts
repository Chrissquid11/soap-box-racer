/**
 * The files git has new or changed under a project -- untracked (but not ignored) or modified in the working
 * tree -- relative to its root; undefined without git or a checkout. What tells a committed file from one the
 * working tree has made or changed: the `uids` check's missing uid (a finding when committed, a note when not),
 * and rule 7's keeper of a uid two files have (Docs/asset-ids.md §1: the file git tracks unchanged keeps it).
 */
import { execFileSync } from 'node:child_process';

export function uncommitted(root: string): Set<string> | undefined {
  try {
    const out = execFileSync('git', ['ls-files', '-z', '--modified', '--others', '--exclude-standard', '--', '.'], { cwd: root, maxBuffer: 64 * 1024 * 1024, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
    return new Set(out.split('\0').filter((p) => p !== ''));
  } catch {
    return undefined;
  }
}
