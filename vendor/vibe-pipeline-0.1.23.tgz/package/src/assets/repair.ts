/**
 * The repair pass (Docs/asset-ids.md §1, rule 6): a reference in a data file
 * is `{ "uid": "uid://…", "key": "props/crate" }` -- the uid that finds it, the
 * key a person reads -- and when the asset has moved, its key in the file is
 * rewritten to the one its uid's asset has now, the file's layout kept (only
 * the key's text changes: `json-spans.ts`). Run wherever the uids are stamped
 * (`stamp.ts`): `vibe assets`, the dev server's watcher, `vibe export`.
 *
 * A reference is any object of the file but its top-level one -- the file's own
 * `"uid"` -- with a `"uid"` that is a uid and a `"key"` that is a string. A key
 * with a part (`"props/robot#arm"`) keeps its part. A key that differs only in
 * case is the same key (`caseKey`), left as written; a uid the index does not
 * know is left too -- its key is the reference's last word (rule 4).
 *
 * **A bare key upgraded** (`upgradeRefs`, rule 3: what a person or Claude
 * writes by hand gets its uid the next time the pipeline passes): where a data
 * file of a known kind names an asset -- a prefab's nested `"prefab"`, a
 * `Render.model` or `Render.material` in an entity's `data` or an override's
 * `set`; a scene's or a level's `instances.keys`, its saved `Render` column and
 * its instances' overrides; a material's maps -- a string whose asset has a uid
 * becomes `{ "uid", "key" }` in its place, one line, as the file lays a small
 * object out (`{ "uid": …, "key": … }`, or with no spaces in a file on one
 * line). A game's own key field too (`own`: `key-fields.ts` reads which field of
 * which component holds which kind from the game's source, by pattern) -- a
 * bare key there given its uid where it is exactly that kind's asset's key, a
 * `mesh()`'s as `{ "uid", "key", "part" }`. A key no asset has, `''`, and a
 * field declared in a way the pattern cannot read are left as they are.
 *
 * Pure: no `node:` import.
 */
import { caseKey } from '@vibe/engine/case-key';
import { MATERIAL_MAPS } from '@vibe/engine/material-file';
import { applyEdits, spans, type Edit, type Span } from './json-spans.ts';
import type { KeyFields, KeyShape } from './key-fields.ts';
import { isUid } from './uid.ts';

/** One key rewritten: the reference's uid, its key as it was, and as it is now. */
export interface Rewritten {
  uid: string;
  from: string;
  to: string;
}

/** What the pass did to one file's text: the text, and every key it rewrote (none: the text as it came). */
export interface Repaired {
  text: string;
  changed: Rewritten[];
}

/**
 * Every `{ uid, key }` in `text` -- a data file of any kind: its own top-level object is never a reference --
 * whose key is not the key `resolve` gives its uid now, rewritten to that one. A text that does not parse comes
 * back as it was.
 */
export function repairRefs(text: string, resolve: (uid: string) => string | undefined): Repaired {
  let top: Span;
  try {
    top = spans(text);
  } catch {
    return { text, changed: [] };
  }
  const edits: Edit[] = [];
  const changed: Rewritten[] = [];
  const visit = (span: Span, isTop: boolean): void => {
    if (span.type === 'array') for (const item of span.items) visit(item, false);
    if (span.type !== 'object') return;
    for (const m of span.members) visit(m.value, false);
    if (isTop) return;
    const uid = span.members.find((m) => m.key === 'uid')?.value;
    const key = span.members.find((m) => m.key === 'key')?.value;
    if (uid?.type !== 'string' || key?.type !== 'string' || !isUid(uid.value)) return;
    const now = resolve(uid.value);
    if (now === undefined) return;
    const hash = key.value.indexOf('#');
    const base = hash < 0 ? key.value : key.value.slice(0, hash);
    if (caseKey(base) === caseKey(now)) return;
    const next = now + (hash < 0 ? '' : key.value.slice(hash));
    edits.push({ start: key.start, end: key.end, text: JSON.stringify(next) });
    changed.push({ uid: uid.value, from: key.value, to: next });
  };
  visit(top, true);
  return edits.length === 0 ? { text, changed } : { text: applyEdits(text, edits), changed };
}

/** One bare key given its uid: where (a path into the file, for the word), the key, the uid. */
export interface Upgraded {
  at: string;
  key: string;
  uid: string;
}

/** A member's value by key, or undefined. */
const member = (span: Span | undefined, key: string): Span | undefined => (span?.type === 'object' ? span.members.find((m) => m.key === key)?.value : undefined);

/**
 * Every bare key `text` -- a data file of `kind` (`prefabs`, `scenes`, `levels`, `materials`; any other is left) --
 * names an asset by, at the places the header lists, made `{ uid, key }` where `uidOf(kind, key)` knows its uid (a
 * `#part`'s, its model's), the rest of the text untouched. A text that does not parse comes back as it was.
 */
/** What `upgradeRefs` knows of a game's own key fields (`key-fields.ts`): each field's kind, and the pipeline's name for a key type. */
export interface OwnKeyFields {
  fields: KeyFields;
  /** A key type's kind name (`Sfx` is `sfx`, a project's `Tilemap` `tilemaps`); undefined for one the pipeline has not. */
  kindOf(type: string): string | undefined;
}

export function upgradeRefs(text: string, kind: string, uidOf: (kind: string, key: string) => string | undefined, own?: OwnKeyFields): { text: string; upgraded: Upgraded[] } {
  let top: Span;
  try {
    top = spans(text);
  } catch {
    return { text, upgraded: [] };
  }
  const compact = !text.trimEnd().includes('\n');
  const edits: Edit[] = [];
  const upgraded: Upgraded[] = [];
  /** A bare key at `span`, of `assets`' kind, made `{ uid, key }` -- a `mesh()`'s `{ uid, key, part }` -- where it has a uid. */
  const at = (span: Span | undefined, assets: string, where: string, mesh = false): void => {
    if (span?.type !== 'string' || span.value === '') return;
    const hash = span.value.indexOf('#');
    const model = hash < 0 ? span.value : span.value.slice(0, hash);
    const uid = uidOf(assets, model);
    if (uid === undefined) return;
    const u = JSON.stringify(uid);
    const k = JSON.stringify(mesh ? model : span.value);
    const p = mesh && hash >= 0 && hash < span.value.length - 1 ? JSON.stringify(span.value.slice(hash + 1)) : null;
    const body = compact ? `{"uid":${u},"key":${k}${p === null ? '' : `,"part":${p}`}}` : `{ "uid": ${u}, "key": ${k}${p === null ? '' : `, "part": ${p}`} }`;
    edits.push({ start: span.start, end: span.end, text: body });
    upgraded.push({ at: where, key: span.value, uid });
  };
  /** A game's own key field of `component` (`own`), as its kind's name and whether it is a mesh; undefined for none -- or a data component's (`inside`). */
  const ownField = (component: string, field: string, inside = false): { assets: string; mesh: boolean } | undefined => {
    const f = own?.fields.get(component)?.get(field);
    if (f !== undefined && (f.deep !== undefined) !== inside) return undefined;
    const assets = f === undefined ? undefined : own!.kindOf(f.type);
    return assets === undefined ? undefined : { assets, mesh: f!.mesh };
  };
  /** A data component's field's keys, where its schema's shape has them (`KeyShape`): nothing else in it is read. */
  const deep = (span: Span | undefined, shape: KeyShape, where: string): void => {
    if (span === undefined) return;
    if ('key' in shape) {
      const assets = own!.kindOf(shape.key);
      if (assets !== undefined) at(span, assets, where, shape.mesh);
    } else if ('list' in shape) {
      if (span.type === 'array') span.items.forEach((x, i) => deep(x, shape.list, `${where}[${i}]`));
    } else if ('dict' in shape) {
      if (span.type === 'array') span.items.forEach((pair, i) => pair.type === 'array' && deep(pair.items[1], shape.dict, `${where}[${i}]`));
      else if (span.type === 'object') for (const m of span.members) deep(m.value, shape.dict, `${where}.${m.key}`);
    } else if (span.type === 'object') {
      for (const m of span.members) if (Object.hasOwn(shape.record, m.key)) deep(m.value, shape.record[m.key]!, `${where}.${m.key}`);
    }
  };
  /** A data component's `objects` (an entity's, an override's): each field of a game's own a key field, its keys where its shape has them. */
  const dataFields = (component: string, value: Span | undefined, where: string): void => {
    if (value?.type !== 'object') return;
    for (const f of value.members) {
      const shape = ownField(component, f.key, true) ? own!.fields.get(component)!.get(f.key)!.deep! : null;
      if (shape) deep(f.value, shape, `${where}.${f.key}`);
    }
  };
  const objects = (data: Span | undefined, where: string): void => {
    if (data?.type !== 'object' || own === undefined) return;
    for (const c of data.members) dataFields(c.key, c.value, `${where}.${c.key}`);
  };
  /** `Render.model` and `Render.material` in a `data` or a `set` -- and every field of a game's own a key field (`own`). */
  const render = (data: Span | undefined, where: string): void => {
    const r = member(data, 'Render');
    at(member(r, 'model'), 'models', `${where}.Render.model`);
    at(member(r, 'material'), 'materials', `${where}.Render.material`);
    if (data?.type !== 'object' || own === undefined) return;
    for (const c of data.members) {
      if (c.key === 'Render' || c.value.type !== 'object') continue;
      for (const f of c.value.members) {
        const field = ownField(c.key, f.key);
        if (field) at(f.value, field.assets, `${where}.${c.key}.${f.key}`, field.mesh);
      }
    }
  };
  const overrides = (list: Span | undefined, where: string): void => {
    if (list?.type !== 'array') return;
    list.items.forEach((o, i) => {
      render(member(o, 'set'), `${where}[${i}].set`);
      objects(member(o, 'objects'), `${where}[${i}].objects`);
    });
  };
  if (kind === 'prefabs') {
    const entities = member(top, 'entities');
    if (entities?.type === 'array') {
      entities.items.forEach((e, i) => {
        at(member(e, 'prefab'), 'prefabs', `entities[${i}].prefab`);
        render(member(e, 'data'), `entities[${i}].data`);
        objects(member(e, 'objects'), `entities[${i}].objects`);
        overrides(member(e, 'overrides'), `entities[${i}].overrides`);
      });
    }
  } else if (kind === 'scenes' || kind === 'levels') {
    const inst = member(top, 'instances');
    const keys = member(inst, 'keys');
    if (keys?.type === 'array') keys.items.forEach((k, i) => at(k, 'prefabs', `instances.keys[${i}]`));
    const table = member(inst, 'overrides');
    if (table?.type === 'object') for (const m of table.members) overrides(m.value, `instances.overrides.${m.key}`);
    const fields = member(member(member(top, 'components'), 'Render'), 'fields');
    for (const [field, assets] of [['model', 'models'], ['material', 'materials']] as const) {
      const column = member(fields, field);
      if (column?.type === 'array') column.items.forEach((v, i) => at(v, assets, `components.Render.fields.${field}[${i}]`));
    }
    // A game's own key field's column, each entity's value.
    const components = member(top, 'components');
    if (components?.type === 'object' && own !== undefined) {
      for (const c of components.members) {
        if (c.key === 'Render') continue;
        // A data component's values, an entity each: its key fields' keys anywhere inside.
        const values = member(c.value, 'values');
        if (values?.type === 'array') values.items.forEach((v, i) => dataFields(c.key, v, `components.${c.key}.values[${i}]`));
        const columns = member(c.value, 'fields');
        if (columns?.type !== 'object') continue;
        for (const f of columns.members) {
          const field = ownField(c.key, f.key);
          if (field && f.value.type === 'array') f.value.items.forEach((v, i) => at(v, field.assets, `components.${c.key}.fields.${f.key}[${i}]`, field.mesh));
        }
      }
    }
  } else if (kind === 'materials') {
    for (const field of MATERIAL_MAPS) at(member(top, field), 'textures', field);
  }
  return edits.length === 0 ? { text, upgraded } : { text: applyEdits(text, edits), upgraded };
}
