/**
 * What moves together (Docs/assets.md §6, "What moves together"): a source,
 * its record, its intermediate, its exports, and the parts that belong to it
 * alone -- a **family** -- worked out from the index; and the plans for `POST
 * move` and `POST copy` (§5) that keep one whole.
 *
 * - **A move, a rename, a delete and a restore take the whole family.** A
 *   shared part stays where it is; a move to another folder that would leave a
 *   source without one is refused ("robot.png is also part of robot-lod.fbx:
 *   move both"), and so is a part moved on its own.
 * - **A rename keeps the parts' names** -- the source names them inside itself
 *   -- and renames the rest by its stem: `crate.lua` -> `box.lua` makes
 *   `box.glb`, `box.export.json`, `_box.glb`. The record's `built.deps` names
 *   the intermediate, so a record moved with a renamed one is rewritten to say
 *   its new name (`renamedDeps`): the family stays as current as it was.
 * - **Both sides go together.** A destination may be given on either side --
 *   an export moved into `packs/reef/` takes its source to
 *   `AssetsSource/packs/reef/...` -- and a move to another kind is refused.
 * - **A folder moves with its twin**, every family under it with it -- refused
 *   where one family's move would be, onto a folder that exists, or into itself.
 * - **A copy** (`Duplicate`, `Copy to...`) takes the family into a folder, a
 *   taken name made `-2` as a restore makes it (the smallest number free for
 *   every member, in both roots); a part is left where the same content is
 *   there already and refused where other content is.
 *
 * Plans only: nothing here moves a file. They read the index's entries and ask
 * the disk what is in the way; the dev server carries them out (`server.ts`),
 * its own writes expected first. A plan refused is a value (`PlanRefusal`, with
 * the status the server answers), never a throw: nothing here knows HTTP.
 * Nothing at module level.
 */
import { lstat, readdir, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { Entry, Refusal } from './api-types.ts';
import { code, hashFile } from './fs.ts';
import { baseName, dirName, familyStem, intermediatePath, joinPath, locate, numbered, ownRecordPath, recordPath, strayFile, twin, under, validName } from './paths.ts';
import { parseRecord, recordText } from './record.ts';
import { caseKey } from '@vibe/engine/case-key';

type Entries = ReadonlyMap<string, Entry>;

/** A plan refused before anything moved: why, a way on if there is one, and the status the server answers (`409` for what is in the way). */
export interface PlanRefusal extends Refusal {
  status: 409 | 422;
  exists?: true;
}

const refuse = (status: 409 | 422, refused: string, extra: { suggested?: string | undefined; exists?: true } = {}): PlanRefusal => ({
  status,
  refused,
  ...(extra.suggested !== undefined ? { suggested: extra.suggested } : {}),
  ...(extra.exists ? { exists: true as const } : {}),
});

/** Is this plan a refusal? */
export function isRefusal(plan: object): plan is PlanRefusal {
  return 'refused' in plan;
}

/** One file's move or copy: project-relative, from and to. */
export interface Step {
  from: string;
  to: string;
}

/** The source whose family a path is in, if it is in one: itself, or the source of its export, record or intermediate. */
export function sourceOf(entries: Entries, path: string): string | undefined {
  const e = entries.get(path);
  if (!e) return undefined;
  if (e.role === 'source') return path;
  if ((e.role === 'export' || e.role === 'record' || e.role === 'intermediate') && e.source !== undefined && entries.has(e.source)) return e.source;
  return undefined;
}

/** A source's parts that are its alone: they go with it. */
function ownParts(entries: Entries, source: string): string[] {
  return (entries.get(source)?.parts ?? []).filter((p) => {
    const owners = entries.get(p)?.owners ?? [];
    return owners.length === 1 && owners[0] === source;
  });
}

/** A source's parts some other source names too: they stay. */
function sharedParts(entries: Entries, source: string): Array<{ part: string; others: string[] }> {
  const out: Array<{ part: string; others: string[] }> = [];
  for (const p of entries.get(source)?.parts ?? []) {
    const others = (entries.get(p)?.owners ?? []).filter((o) => o !== source);
    if (others.length > 0) out.push({ part: p, others });
  }
  return out;
}

/**
 * The family of `path`, `path` first: its source, record (its own, `crate.blend.export.json`, or its stem's), intermediate,
 * exports and the parts that are the source's alone -- those the index has.
 * A file in no family (a loose file, an extra, a part, a reference) is itself.
 * A source out of the build has no exports: a file at its export path is a
 * loose one, delivered by hand, and stays where it is.
 */
export function familyOf(entries: Entries, path: string): string[] {
  const out = [path];
  const source = sourceOf(entries, path);
  if (source === undefined) return out;
  const add = (p: string): void => {
    if (entries.has(p) && !out.includes(p)) out.push(p);
  };
  add(source);
  // Its own record when it has one (the other source of its stem keeps the stem's), else its stem's.
  add(entries.has(ownRecordPath(source)) ? ownRecordPath(source) : recordPath(source));
  if (entries.get(intermediatePath(source))?.role === 'intermediate') add(intermediatePath(source));
  if (entries.get(source)?.included !== false) for (const x of entries.get(source)?.exports ?? []) add(x);
  for (const p of ownParts(entries, source)) add(p);
  return out;
}

/** A folder's two sides, given either: where its sources are, and where its exports go. */
export function sides(dir: string): { source?: string; ship?: string } {
  const where = locate(dir);
  const other = twin(dir);
  if (where?.root === 'source') return { source: dir, ...(other !== undefined ? { ship: other } : {}) };
  return { ship: dir, ...(other !== undefined ? { source: other } : {}) };
}

/** A family member's name under a new stem: `_crate.glb` is `_box.glb`, `crate.export.json` `box.export.json`. */
export function restem(name: string, stem: string, newStem: string): string {
  const lead = name.startsWith('_') ? '_' : '';
  const body = lead ? name.slice(1) : name;
  return body.startsWith(stem) ? lead + newStem + body.slice(stem.length) : name;
}

/** Is anything at `path` (a file, a folder, a link)? */
async function taken(root: string, path: string): Promise<boolean> {
  try {
    await lstat(join(root, path));
    return true;
  } catch (err) {
    if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') return false;
    throw err;
  }
}

/** The names in a folder, none if it is not there. */
async function namesIn(root: string, dir: string | undefined): Promise<string[]> {
  if (dir === undefined) return [];
  try {
    return await readdir(join(root, dir));
  } catch {
    return [];
  }
}

/** The kind a path is under -- `'reference'` for `AssetsSource/reference/`, `''` for none -- as a move compares them. */
function kindWord(path: string): string {
  const where = locate(path);
  if (where?.reference) return 'reference';
  return where?.kind ?? '';
}

/**
 * A record that names `renames`' old names in `built.deps` (an intermediate
 * renamed with its family), rewritten to name the new ones. Undefined when it
 * names none of them, or does not parse (then it is moved as it is).
 */
export async function renamedDeps(root: string, record: string, renames: ReadonlyMap<string, string>): Promise<string | undefined> {
  let parsed;
  try {
    parsed = parseRecord(await readFile(join(root, record), 'utf8'));
  } catch {
    return undefined;
  }
  const deps = parsed.built?.deps;
  if (!deps || !Object.keys(deps).some((k) => renames.has(k))) return undefined;
  const next: Record<string, string> = {};
  for (const [name, hash] of Object.entries(deps)) next[renames.get(name) ?? name] = hash;
  return recordText({ ...parsed, built: { ...parsed.built!, deps: next } });
}

// ---------------------------------------------------------------- a file's move

export interface MovePlan {
  steps: Step[];
  /** Destinations that are their source with only its case changed: moved through a temporary name (macOS). */
  caseOnly: string[];
  /** Records rewritten as they move, their intermediate renamed: destination -> text. */
  records: Map<string, string>;
}

/**
 * `from` and its family to `to` (§6): renamed by `to`'s stem, both sides
 * together, the parts with it when the folder changes. Refused before anything
 * moves: a part on its own, another kind, a shared part left behind, a
 * destination taken or a name `validName` refuses. A `_` put on or taken off
 * in its folder -- a `.glb` made its `.blend`'s export by hand -- is the file
 * alone.
 */
export async function planMove(root: string, entries: Entries, from: string, asked: string): Promise<MovePlan | PlanRefusal> {
  // Given on the other side (an export dropped where its source goes, or back): `from`'s own side of it.
  const mine = locate(from)?.root === 'source' ? sides(dirName(asked)).source : sides(dirName(asked)).ship;
  if (mine === undefined) return refuse(422, `${dirName(asked)} has no twin for ${baseName(from)}`);
  const to = joinPath(mine, baseName(asked));
  if (from === to) return refuse(422, `${from} is already there`);
  const e = entries.get(from);
  if (e?.role === 'part' && (e.owners ?? []).length > 0) {
    return refuse(422, `${baseName(from)} is part of ${(e.owners ?? []).map(baseName).join(', ')}: move it with its model`);
  }
  if (kindWord(from) !== kindWord(to)) return refuse(422, `a move to another kind is refused: ${kindWord(from) || 'no kind'} -> ${kindWord(to) || 'no kind'}`);
  // A `_` put on or taken off, in its folder: `crate.glb` made crate.blend's export by hand, `_crate.glb`
  // (§2, one stem, one source), or back. The file alone: the stem's record and exports stay the
  // family's, whichever source it has now.
  if (dirName(from) === dirName(to) && (baseName(to) === `_${baseName(from)}` || baseName(from) === `_${baseName(to)}`)) {
    if (await taken(root, to)) return refuse(409, `${baseName(to)} exists in ${dirName(to)}`, { exists: true });
    return { steps: [{ from, to }], caseOnly: [], records: new Map() };
  }
  // A stray prefab or material file -- `rvd.json` under prefabs/ -- given its `.prefab` in its folder (the Assets tool's Rename to
  // .prefab, Docs/prefabs.md §2), and back (its undo): the one rename that changes an extension. The file alone;
  // it has no family.
  if (dirName(from) === dirName(to) && (strayFile(from)?.renameTo === baseName(to) || strayFile(to)?.renameTo === baseName(from))) {
    if (await taken(root, to)) return refuse(409, `${baseName(to)} exists in ${dirName(to)}`, { exists: true });
    return { steps: [{ from, to }], caseOnly: [], records: new Map() };
  }
  const oldStem = familyStem(baseName(from));
  const newStem = familyStem(baseName(to));
  if (restem(baseName(from), oldStem, newStem) !== baseName(to)) return refuse(422, `a rename keeps the extension: ${baseName(from)} -> ${restem(baseName(from), oldStem, newStem)}`);
  const source = sourceOf(entries, from);
  const family = familyOf(entries, from);
  const parts = new Set(source !== undefined ? ownParts(entries, source) : []);
  const toSides = sides(dirName(to));
  const folderMoves = dirName(from) !== dirName(to);
  if (source !== undefined && folderMoves) {
    const shared = sharedParts(entries, source)[0];
    if (shared) return refuse(409, `${baseName(shared.part)} is also part of ${shared.others.map(baseName).join(', ')}: move both`);
  }
  const steps: Step[] = [];
  const records = new Map<string, string>();
  const renames = new Map<string, string>();
  for (const m of family) {
    let dest: string;
    if (parts.has(m)) {
      if (!folderMoves) continue;
      // Keeps its name, and its place beside the source (`textures/` under it, too).
      const rel = m.slice(dirName(source!).length + 1);
      if (toSides.source === undefined) return refuse(422, `${baseName(m)} has nowhere to go beside its source under ${dirName(to)}`);
      dest = joinPath(toSides.source, rel);
    } else {
      const side = locate(m)?.root === 'source' ? toSides.source : toSides.ship;
      if (side === undefined) return refuse(422, `${baseName(m)} has no twin folder under ${dirName(to)}`);
      dest = joinPath(side, restem(baseName(m), oldStem, newStem));
      if (baseName(dest) !== baseName(m)) renames.set(baseName(m), baseName(dest));
    }
    if (dest !== m) steps.push({ from: m, to: dest });
  }
  const check = validName(baseName(to), { siblings: await namesIn(root, dirName(to)), twinSiblings: await namesIn(root, twin(dirName(to))) });
  if ('refused' in check && !(caseKey(baseName(to)) === caseKey(baseName(from)) && 'ok' in validName(baseName(to)))) return refuse(422, check.refused, { suggested: check.suggested });
  const caseOnly: string[] = [];
  const goingTo = new Set<string>();
  for (const step of steps) {
    if (goingTo.has(step.to)) return refuse(409, `two files would go to ${step.to}`);
    goingTo.add(step.to);
    if (caseKey(step.to) === caseKey(step.from)) caseOnly.push(step.to);
    else if (await taken(root, step.to)) return refuse(409, `${baseName(step.to)} exists in ${dirName(step.to)}`, { exists: true });
  }
  // The record names the intermediate it was built from: renamed with it, it says so.
  const renamedIntermediates = new Map([...renames].filter(([name]) => name.startsWith('_')));
  if (source !== undefined && renamedIntermediates.size > 0) {
    const record = steps.find((s) => s.from === recordPath(source));
    if (record) {
      const text = await renamedDeps(root, record.from, renamedIntermediates);
      if (text !== undefined) records.set(record.to, text);
    }
  }
  return { steps, caseOnly, records };
}

// ---------------------------------------------------------------- a folder's move

export interface FolderMovePlan {
  /** The folder and its twin, from and to. */
  dirs: Step[];
  /** Every file under them, from and to. */
  steps: Step[];
}

/** Is this folder one a move may take: inside a kind's folder, or a pack's own folder -- never a root or a kind's folder itself? */
function movableFolder(dir: string): boolean {
  const where = locate(dir);
  if (!where || where.reference) return false;
  if (where.kind !== undefined) return where.under !== undefined && where.under !== '';
  // A pack's own folder: `packs/reef`, `AssetsSource/packs/reef`.
  return where.pack !== undefined && (where.rel === where.pack || where.rel === `packs/${where.pack}`);
}

/**
 * The folder `from`, its twin, and every family under them, to `to` (§5, `POST
 * move` with a folder). Refused onto a folder that exists (either side), into
 * itself, to another kind, and where a family under it would be split: a part
 * inside shared with a source outside, or a source inside whose part is not.
 */
export async function planFolderMove(root: string, entries: Entries, from: string, to: string): Promise<FolderMovePlan | PlanRefusal> {
  if (!movableFolder(from)) return refuse(422, `${from} stays where it is: only a folder inside a kind's folder, or a pack's, moves`);
  if (!movableFolder(to)) return refuse(422, `${to} is not a folder inside a kind's folder, or a pack's`);
  if (under(to, from)) return refuse(422, `${from} cannot move into itself`);
  const fromKind = locate(from)?.kind ?? 'pack';
  const toKind = locate(to)?.kind ?? 'pack';
  if (fromKind !== toKind) return refuse(422, `a move to another kind is refused: ${fromKind} -> ${toKind}`);
  const check = validName(baseName(to), { folder: true });
  if ('refused' in check) return refuse(422, check.refused, { suggested: check.suggested });
  // Renamed in case only (`Props` -> `props`): the disk has one name for both, so it is "there" -- and is itself.
  const caseOnly = caseKey(from) === caseKey(to);
  if (caseOnly && from === to) return refuse(422, `${from} is ${to} already`);
  const dirs: Step[] = [{ from, to }];
  const fromTwin = twin(from);
  const toTwin = twin(to);
  if (fromTwin !== undefined && toTwin !== undefined && (await taken(root, fromTwin))) dirs.push({ from: fromTwin, to: toTwin });
  for (const d of caseOnly ? [] : [to, ...(toTwin !== undefined ? [toTwin] : [])]) {
    if (await taken(root, d)) return refuse(409, `${d} exists: a folder is not moved onto another`, { exists: true });
  }
  const moving = (p: string): boolean => dirs.some((d) => under(p, d.from));
  const steps: Step[] = [];
  for (const [path, e] of entries) {
    if (!moving(path)) continue;
    const d = dirs.find((x) => under(path, x.from))!;
    steps.push({ from: path, to: d.to + path.slice(d.from.length) });
    if (e.role === 'source') {
      const outside = (e.parts ?? []).find((p) => !moving(p));
      if (outside) return refuse(409, `${baseName(outside)} is part of ${baseName(path)} and is not in ${from}: move both`);
    }
    if (e.role === 'part') {
      const others = (e.owners ?? []).filter((o) => !moving(o));
      if (others.length > 0) return refuse(409, `${baseName(path)} is also part of ${others.map(baseName).join(', ')}: move both`);
    }
  }
  return { dirs, steps };
}

// ---------------------------------------------------------------- a copy

export interface CopyPlan {
  steps: Step[];
  /** Records rewritten as they are copied, their intermediate numbered: destination -> text. */
  records: Map<string, string>;
}

/** Do two files hold the same bytes? */
async function sameBytes(root: string, a: string, b: string): Promise<boolean> {
  const [sa, sb] = await Promise.all([lstat(join(root, a)), lstat(join(root, b))]);
  if (!sa.isFile() || !sb.isFile() || sa.size !== sb.size) return false;
  const [ha, hb] = await Promise.all([hashFile(join(root, a)), hashFile(join(root, b))]);
  return ha.sha1 === hb.sha1;
}

/**
 * `from`'s family copied into the folder `to` -- its own, for a duplicate --
 * both sides, numbered where a name is taken (the smallest number free for
 * every member, in its folder and its twin), the parts beside the copy: left
 * where the same content is there, refused where other content is.
 */
export async function planCopy(root: string, entries: Entries, from: string, to: string): Promise<CopyPlan | PlanRefusal> {
  const e = entries.get(from);
  if (e?.role === 'part' && (e.owners ?? []).length > 0) return refuse(422, `${baseName(from)} is part of ${(e.owners ?? []).map(baseName).join(', ')}: copy its model`);
  const toSides = sides(to);
  if (kindWord(from) !== kindWord(joinPath(to, baseName(from)))) return refuse(422, `a copy to another kind is refused: ${kindWord(from) || 'no kind'} -> ${kindWord(joinPath(to, baseName(from))) || 'no kind'}`);
  const source = sourceOf(entries, from);
  // The parts a copy needs beside it: every one, shared too -- the copy names them all.
  const parts = new Set(source !== undefined ? (entries.get(source)?.parts ?? []) : []);
  const members = [...new Set([...familyOf(entries, from), ...parts])];
  const own = members.filter((m) => !parts.has(m));
  // Each member's folder under `to`: its own side's.
  const dirs = new Map<string, string>();
  for (const m of own) {
    const side = locate(m)?.root === 'source' ? toSides.source : toSides.ship;
    if (side === undefined) return refuse(422, `${baseName(m)} has no twin folder under ${to}`);
    dirs.set(m, side);
  }
  const destDir = (m: string): string => dirs.get(m)!;
  // The smallest number free for every member, in its folder and its twin (`1`: the names as they are).
  let n = 1;
  for (; n < 10000; n++) {
    let free = true;
    for (const m of own) {
      const dest = numbered(joinPath(destDir(m), baseName(m)), n);
      const claims = [dest, ...(twin(dirName(dest)) !== undefined ? [joinPath(twin(dirName(dest))!, baseName(dest))] : [])];
      for (const c of claims) {
        if (c === m || (await taken(root, c))) {
          free = false;
          break;
        }
      }
      if (!free) break;
    }
    if (free) break;
  }
  const steps: Step[] = [];
  const renames = new Map<string, string>();
  for (const m of own) {
    const dest = numbered(joinPath(destDir(m), baseName(m)), n);
    if (n > 1) {
      const check = validName(baseName(dest));
      if ('refused' in check && !baseName(dest).endsWith('.export.json')) return refuse(422, `${baseName(m)} cannot be copied as ${baseName(dest)}: ${check.refused}`);
    }
    if (baseName(dest) !== baseName(m)) renames.set(baseName(m), baseName(dest));
    steps.push({ from: m, to: dest });
  }
  if (source !== undefined && toSides.source !== undefined) {
    for (const p of parts) {
      const dest = joinPath(toSides.source, p.slice(dirName(source).length + 1));
      if (dest === p) continue;
      if (await taken(root, dest)) {
        if (await sameBytes(root, p, dest)) continue; // the same part, now shared
        return refuse(409, `${baseName(dest)} exists in ${dirName(dest)} with other content`, { exists: true });
      }
      steps.push({ from: p, to: dest });
    }
  }
  const records = new Map<string, string>();
  const renamedIntermediates = new Map([...renames].filter(([name]) => name.startsWith('_')));
  if (source !== undefined && renamedIntermediates.size > 0) {
    const record = steps.find((s) => s.from === recordPath(source));
    if (record) {
      const text = await renamedDeps(root, record.from, renamedIntermediates);
      if (text !== undefined) records.set(record.to, text);
    }
  }
  return { steps, records };
}
