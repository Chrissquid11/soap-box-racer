/**
 * Where a key appears in `src/` -- the API's `GET uses?key=` (Docs/assets.md
 * §5), shown before a rename, a move or a delete: "used in
 * `src/game/index.ts:38`".
 *
 * Every `src/**\/*.ts` and `src/**\/*.json` but the generated files and the
 * tests (`*.test.ts`, whose keys are fixtures), searched for the key as a
 * string literal in any quotes, in any case (a lookup takes any: `caseKey`),
 * on a line that is not all comment: `'props/crate'`, `"Props/Crate"`,
 * `` `props/crate` ``, a part of it (`'props/crate#lid'`), a pack key with
 * its prefix (`'reef:props/crate'`), never `'props/crate-2'`.
 *
 * **No hits is "no literal uses found", never "unused".** A key built at
 * runtime (`Assets.parts('props')`, a level naming a model) cannot be seen, and
 * two kinds can share a key word (`crate` the model and the sound), so the
 * lines are shown, not counted.
 *
 * The files are read once and kept in memory by mtime and size: each `find`
 * walks the folders (new files picked up, removed ones dropped) and reads again
 * only what changed. Nothing at module level.
 */
import { readdir, readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { caseKey } from '@vibe/engine/case-key';
import type { Use } from './api-types.ts';
import { isGenerated } from './keys.ts';

export type { Use };


function escape(text: string): string {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** A line that is all comment: `// …`, a doc comment's `* …`, a `/* …` -- a key written there in quotes is an example, not a use. */
const COMMENT = /^\s*(\/\/|\/\*|\*)/;

/**
 * The 1-based lines of `text` holding `key` as a whole string literal, in any
 * of the three quotes and in any case (`caseKey`), or with a `#part` -- not on
 * a line that is all comment, where it names the key without loading it, and
 * no build fails for it.
 */
export function literalsIn(text: string, key: string): number[] {
  const literal = new RegExp(`(['"\`])${escape(caseKey(key))}(?:#[^'"\`]*)?\\1`);
  const out: number[] = [];
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) if (!COMMENT.test(lines[i]!) && literal.test(caseKey(lines[i]!))) out.push(i + 1);
  return out;
}

interface Cached {
  mtimeMs: number;
  size: number;
  text: string;
}

export class Uses {
  /** The project root. */
  root: string;
  /** Project-relative path -> what was read, and when it was written. */
  files = new Map<string, Cached>();

  constructor(root: string) {
    this.root = root;
  }

  /** Every literal use of `key` in `src/`, by file and line. */
  async find(key: string): Promise<Use[]> {
    await this.refresh();
    const out: Use[] = [];
    for (const file of [...this.files.keys()].sort()) {
      const { text } = this.files.get(file)!;
      if (!caseKey(text).includes(caseKey(key))) continue;
      const lines = text.split(/\r?\n/);
      for (const line of literalsIn(text, key)) out.push({ file, line, text: lines[line - 1]!.trim() });
    }
    return out;
  }

  /** One walk of `src/`; what changed since the last is read again. The dev server's first, once it is listening, warms it. */
  async refresh(): Promise<void> {
    const seen = new Set<string>();
    const walk = async (rel: string): Promise<void> => {
      let entries;
      try {
        entries = await readdir(join(this.root, rel), { withFileTypes: true });
      } catch {
        return;
      }
      for (const entry of entries) {
        if (entry.name.startsWith('.') || entry.name === 'node_modules') continue;
        const path = `${rel}/${entry.name}`;
        if (entry.isDirectory()) await walk(path);
        // A test's keys are its fixtures: no build fails for one renamed. A generated file (`keys.ts`) has every key, and none is a use.
        else if (/\.(ts|json)$/.test(entry.name) && !entry.name.endsWith('.test.ts') && !isGenerated(path)) seen.add(path);
      }
    };
    await walk('src');
    for (const path of [...this.files.keys()]) if (!seen.has(path)) this.files.delete(path);
    await Promise.all(
      [...seen].map(async (path) => {
        const abs = join(this.root, path);
        let info;
        try {
          info = await stat(abs);
        } catch {
          this.files.delete(path);
          return;
        }
        const cached = this.files.get(path);
        if (cached && cached.mtimeMs === info.mtimeMs && cached.size === info.size) return;
        this.files.set(path, { mtimeMs: info.mtimeMs, size: info.size, text: await readFile(abs, 'utf8') });
      }),
    );
  }
}
