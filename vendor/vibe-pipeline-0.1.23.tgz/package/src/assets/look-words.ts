/**
 * A tool's look, said where a person reads it -- the Tools page, the Model
 * tab's banner: pure, no node, so the page imports it.
 */
import type { ToolLook } from './api-types.ts';

/**
 * The path set for a tool, passed over because it did not run, in words:
 * `your path /opt/gladius did not run (not found there); using gladius from the
 * PATH` -- or `… and nothing else was found`. Null when none was passed over.
 */
export function sayPassedOver(look: ToolLook): string | null {
  if (!look.passedOver) return null;
  const { path, why } = look.passedOver;
  const instead = look.state === 'missing' || look.path === undefined ? 'and nothing else was found' : `using ${look.path === look.tool ? `${look.tool} from the PATH` : look.path}`;
  return `your path ${path} did not run (${why}); ${instead}`;
}
