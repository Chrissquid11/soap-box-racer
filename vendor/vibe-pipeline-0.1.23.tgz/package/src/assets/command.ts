/**
 * `npm run export` (Docs/assets.md §4): what `vibe export` runs, given the
 * project root and where to print -- so its test runs it on a temp project.
 *
 *   npm run export                     every stale or missing source
 *   npm run export -- props bubble     only sources whose path contains one of these, or whose key is one
 *   npm run export -- --force          everything, current or not
 *   npm run export -- --check          exit 1 if any source is not current; hashes every
 *                                      file, ignores the cache, needs no external tool
 *   npm run export -- --dry            say what would run
 *
 * **Every chosen source is said once.** One that will not run is said before
 * anything runs: `unmade`, `conflict`, `failed` (its reason). One that runs says
 * how it went: the export's line, `FAILED` with the first line of the output,
 * or -- refused when it got there, `--force` asking for one that cannot succeed
 * -- `failed` and why, `unmade`, or `skipped` and why. `--dry` always ends with
 * a line, even when there is nothing to do; every run ends with the counts.
 *
 * **A source out of the build** (`excluded`: its record says `"include":
 * false`) is never exported and never counted: `--check` passes over it, and
 * so does a run -- `--force` too. Asked for by name (a filter that chooses it)
 * it is refused, said with the way back in -- "excluded: tick it in the tool,
 * or remove `include: false` from its record" -- and the run ends 1.
 *
 * The CLI has no game tab: a browser-made source whose `_<stem>.glb` is out of
 * date is `unmade` and says so. `--check` is what CI runs (`npm ci && npm run
 * export -- --check`, with LFS checked out): it fails on `stale`, `missing`,
 * `unmade`, `failed` and `conflict`, not on a PATH tool's version -- an export
 * that is an LFS pointer is `failed`, one that is not what its record's
 * `built.out` says was written `stale` (a record without `out`, written before
 * it was, holds nothing there); and on an excluded source whose export is still
 * there, and on an export whose source is gone but its record is not -- and on a
 * path git tracks in another case than the disk's (`case.ts`: the live host
 * would 404 on it), each said with its `git mv`. It also
 * writes the hashes cache it filled by reading every file -- harmless, and the
 * next run starts warm. Exports run as many at once as the machine has cores;
 * `conflict` sees to it that no two share a file.
 *
 * Nothing at module level.
 */
import { readFile } from 'node:fs/promises';
import { availableParallelism } from 'node:os';
import { join } from 'node:path';
import type { Status } from './api-types.ts';
import { caseLines, caseMismatches } from './case.ts';
import { Catalog } from './catalog.ts';
import { Runs, exportSource, type ExportResult } from './export.ts';
import { HashCache } from './hashes.ts';
import { Runner } from './jobs.ts';
import { baseName, dirName, joinPath, recordStem, twin } from './paths.ts';
import { parseRecord } from './record.ts';
import { isFound, recipeFor } from './recipes.ts';
import { STEPS, type Step } from './steps/index.ts';
import { lookForAll, mergeNeeds, npmVersions, sayLook, type LookContext } from './tools.ts';

export const EXPORT_USAGE = 'export [filter...] [--force] [--check] [--dry]';

/** Where the command prints: the terminal's two streams, or a test's lists. */
export interface Out {
  log(line: string): void;
  error(line: string): void;
}

/** The steps of the recipes of these sources. */
function stepsOf(sources: readonly string[]): Step[] {
  const names = new Set<keyof typeof STEPS>();
  for (const source of sources) {
    const answer = recipeFor(source);
    if (isFound(answer)) for (const step of answer.row.steps) names.add(step);
  }
  return [...names].map((n) => STEPS[n]);
}

/**
 * `--check`'s look past the sources: a file that ships where the records say nothing should.
 *
 *  - an excluded source's export still there: `"include": false` written by hand (or pulled) takes the
 *    source out, but only the tool's untick moves its export to the trash -- the file would ship;
 *  - an export whose source is gone (deleted in git or the Finder), its record left behind: the file
 *    is loose now, shipped as delivered, made from nothing anyone has.
 */
async function strayExports(root: string, catalog: Catalog, excluded: readonly string[]): Promise<string[]> {
  const lines: string[] = [];
  for (const source of excluded) {
    for (const path of catalog.entries.get(source)?.exports ?? []) {
      if (catalog.entries.has(path)) lines.push(`[assets] excluded ${source}: its export ${path} still ships -- remove it, or tick the source back in`);
    }
  }
  for (const e of catalog.entries.values()) {
    if (e.role !== 'record' || e.source !== undefined) continue;
    const stem = recordStem(baseName(e.path));
    const dir = twin(dirName(e.path));
    if (!stem || dir === undefined) continue;
    let to: readonly string[] = [];
    try {
      to = parseRecord(await readFile(join(root, e.path), 'utf8')).built?.to ?? [];
    } catch {
      continue; // a record that does not parse says nothing here
    }
    for (const ext of to) {
      const path = joinPath(dir, `${stem}.${ext}`);
      if (catalog.entries.get(path)?.role === 'loose') lines.push(`[assets] loose ${path}: its source is gone, its record ${e.path} left -- remove both, or put the source back`);
    }
  }
  return lines;
}

/**
 * `export` with these arguments, on the project at `root`; the exit code.
 * `look` adds to how tools are looked for (a test's canned answers).
 */
export async function exportCommand(root: string, args: readonly string[], out: Out = { log: console.log, error: console.error }, look: Partial<LookContext> = {}): Promise<number> {
  const flags = new Set(args.filter((a) => a.startsWith('--')));
  const filters = args.filter((a) => !a.startsWith('--'));
  for (const flag of flags) {
    if (!['--force', '--check', '--dry'].includes(flag)) {
      out.error(`[assets] unknown option ${flag}\nusage: ${EXPORT_USAGE}`);
      return 2;
    }
  }
  const check = flags.has('--check');
  const force = flags.has('--force');
  const dry = flags.has('--dry');

  const onError = (err: Error): void => out.error(`[assets] ${err.message}`);
  const hashes = new HashCache(root, 0, onError);
  const runs = new Runs(root);
  // `--check` says what the checkout has, not what this machine last tried: no `runs.json`.
  await Promise.all([hashes.load(), check ? undefined : runs.load()]);
  const allNpm = Object.values(STEPS).flatMap((s) => s.npm);
  // Reading, not writing: as many sources at once as the machine has cores.
  const catalog = new Catalog({ root, hashes, runs, npm: await npmVersions(root, allNpm), browser: 'cli', check, lanes: availableParallelism(), onError });
  await catalog.walk();
  const pointers = catalog.pointerLine();
  if (pointers) out.log(pointers);

  const wanted = (path: string): boolean => {
    if (filters.length === 0) return true;
    const key = catalog.entries.get(path)?.key;
    return filters.some((f) => path.includes(f) || key === f);
  };
  // The tools the chosen sources' recipes need, looked for once. Not for --check: it needs only the files.
  // Only theirs: the settle below settles every source, and one not chosen whose tool was not looked for
  // reads `missing` where it might be `unmade` -- never said, since only the chosen are.
  const chosenFirst = catalog.sources().filter(wanted);
  if (!check) {
    const needs = mergeNeeds(stepsOf(chosenFirst).map((s) => s.needs));
    catalog.tools = await lookForAll(needs, { root, ...look });
  }
  // Every source settles, chosen or not: an image is a part only once its model has been read.
  await catalog.settle();
  await hashes.save();
  const chosen = catalog.sources().filter(wanted);
  if (filters.length > 0 && chosen.length === 0) {
    out.error(`[assets] no source matches ${filters.join(', ')}`);
    return 1;
  }
  const statusOf = (path: string): Status => catalog.entries.get(path)?.status ?? 'checking';
  const reasonOf = (path: string): string => {
    const e = catalog.entries.get(path);
    return e?.reason ? `: ${e.reason}` : '';
  };
  // Out of the build: never exported, never counted -- and, chosen by name, refused (below).
  const excluded = chosen.filter((p) => statusOf(p) === 'excluded');
  const counted = chosen.filter((p) => statusOf(p) !== 'excluded');
  const outOfBuild = excluded.length > 0 ? `; ${excluded.length} out of the build` : '';
  const currentCount = (): number => counted.filter((p) => statusOf(p) === 'current').length;

  if (check) {
    const bad = counted.filter((p) => statusOf(p) !== 'current');
    for (const p of bad) out.log(`[assets] ${statusOf(p)} ${p}${reasonOf(p)}`);
    for (const p of counted) {
      const note = catalog.entries.get(p)?.note;
      if (note && statusOf(p) === 'current') out.log(`[assets] current ${p} (${note})`);
    }
    // Shipping what the records say is out of the build, or what no source makes any more.
    const shipping = filters.length === 0 ? await strayExports(root, catalog, excluded) : [];
    for (const line of shipping) out.log(line);
    out.log(`[assets] ${counted.length - bad.length} of ${counted.length} source${counted.length === 1 ? '' : 's'} current${outOfBuild}`);
    // Case: what git records against what the disk has (no checkout, no git: nothing to hold it to).
    const cases = (await caseMismatches(root)) ?? [];
    for (const line of caseLines(cases)) out.log(line);
    return bad.length > 0 || cases.length > 0 || shipping.length > 0 ? 1 : 0;
  }

  // Asked for by name and out of the build: refused, with the way back in.
  const refused = filters.length > 0 ? excluded : [];
  for (const p of refused) out.error(`[assets] ${p}: excluded: ${catalog.entries.get(p)?.reason ?? 'out of the build'}`);
  const toRun = counted.filter((p) => force || statusOf(p) === 'stale' || statusOf(p) === 'missing');
  const running = new Set(toRun);
  // What will not run, said now; what runs says how it went.
  for (const p of chosen) {
    const s = statusOf(p);
    if (!running.has(p) && (s === 'unmade' || s === 'conflict' || s === 'failed')) out.log(`[assets] ${s} ${p}${reasonOf(p)}`);
  }
  if (dry) {
    for (const p of toRun) out.log(`[assets] would export ${p} (${statusOf(p)}${reasonOf(p)})`);
    for (const look of catalog.tools?.values() ?? []) if (look.state !== 'found') out.log(`[assets] ${sayLook(look)}`);
    const current = currentCount();
    if (toRun.length === 0) out.log(`[assets] nothing to export${current === counted.length && counted.length > 0 ? ': every source is current' : ''} (${current} of ${counted.length} current${outOfBuild})`);
    else out.log(`[assets] ${toRun.length} would be exported; ${current} of ${counted.length} current${outOfBuild}`);
    return refused.length > 0 ? 1 : 0;
  }

  const results: ExportResult[] = [];
  const runner = new Runner({
    concurrency: availableParallelism(),
    run: async (job, control) => {
      const result = await exportSource({ root, catalog, runs, log: (line) => out.log(line) }, job.source, { ...job.options, id: job.id, signal: control.signal });
      results.push(result);
      // Done and FAILED said their own line; a refusal at the door says it here.
      if (result.state === 'unmade') out.log(`[assets] unmade ${result.source}: ${result.reason}`);
      else if (result.state === 'failed' && !result.line) out.log(`[assets] failed ${result.source}: ${result.reason}`);
      else if (result.state === 'skipped' && result.reason !== 'current') out.log(`[assets] skipped ${result.source}: ${result.reason}`);
      return result;
    },
  });
  for (const p of toRun) runner.add(p, { force });
  await runner.idle();
  await Promise.all([hashes.save(), runs.save()]);

  const count = (state: ExportResult['state']): number => results.filter((r) => r.state === state).length;
  out.log(`[assets] ${count('done')} exported, ${count('failed')} failed, ${count('unmade')} unmade; ${currentCount()} of ${counted.length} current${outOfBuild}`);
  return count('failed') > 0 || refused.length > 0 ? 1 : 0;
}
