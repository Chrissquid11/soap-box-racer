/**
 * A source's status, worked out (Docs/assets.md §2, "How status is worked
 * out"): from what the index read off the disk -- the source's hash, its parts'
 * and its intermediate's, its record, which exports exist -- and what this
 * machine has: its tools, a game tab or not. In order:
 *
 *   0. its record says `"include": false` -> excluded: out of the build, nothing
 *      read, never exported, never stale, in no conflict
 *   1. under `reference/` -> reference; an export shared with another -> conflict
 *   2. a part named but absent, or an LFS pointer (the source, a part, or an
 *      export: what would ship is a pointer) -> failed, nothing tried
 *   3. the recipe hashed: the resolved row, its steps' versions, its tools'
 *   4. not hashed yet -> checking
 *   5. against the record's `built`: no export -> missing; no record -> stale;
 *      the source or a part changed -> stale; an export is not the file
 *      `built.out` says was written (by hand, a bad copy) -> stale; a record
 *      without `out` (older) holds nothing there; the recipe changed -> hashed
 *      again with the record's PATH-tool versions in place of this machine's:
 *      still different -> stale (options, steps or an npm tool); the same ->
 *      current, noted ("built with ffmpeg 7.1; 8.1 here")
 *   6. stale or missing, and nothing here can make it -> unmade, saying what would
 *   7. stale or missing, and the last attempt failed with these same inputs -> failed
 *
 * **Why the content hash, not "newer than".** A checkout writes files in any
 * order, all in one second: after a pull "newer" says nothing, and on CI it
 * says the wrong thing. The hash, committed in the record, answers everywhere.
 *
 * **Why a PATH tool's version does not make an export stale.** Two designers
 * with different ffmpeg builds would re-export each other's sounds forever, and
 * CI would fail on whatever its runner has. An npm tool's version is the same
 * everywhere (`package-lock.json`), so a change there is an upgrade: stale on
 * purpose.
 *
 * **The intermediate** (§3): a `.blend` exported by hand, or an `.fbx`
 * converted by a game tab, leaves `_<stem>.glb` beside it. It stands in for the
 * first step while it was made from this very source -- there is no record yet,
 * the record's `built.source` is this source's hash, or the intermediate itself
 * is newer than the record (a fresh hand export or conversion) -- and then any
 * machine can rebuild the export from it. A hand export never stands in where
 * its tool is found: there Blender exports, and the leftover goes to the trash.
 * So `built.tools` names Blender only when Blender ran.
 *
 * Pure: everything comes in as an argument, the sha1 included.
 */
import type { ExportRecord, Options, Run, Status, ToolLook } from './api-types.ts';
import { canonical, recipeText, type Found } from './recipes.ts';

/** What status needs of a step: its version, where it runs, what it needs. */
export interface StepInfo {
  name: string;
  version: number;
  where: 'node' | 'browser';
  /** The PATH tools it runs, and what each must have beyond being found (`libvorbis`). */
  needs: ReadonlyArray<{ tool: string; what?: string }>;
  /** The npm packages it imports. */
  npm: readonly string[];
}

/** A part, by its path relative to the source's folder. */
export interface PartState {
  name: string;
  hash?: string;
  /** Named, but not there. */
  missing?: boolean;
  /** An unfetched LFS pointer. */
  pointer?: boolean;
}

/** The last attempt to export a source (`runs.json`, §4): what of a `Run` the status reads. */
export type LastRun = Pick<Run, 'ok' | 'source' | 'deps' | 'recipe' | 'error'>;

export interface StatusInput {
  /** The source, relative to the project root. */
  source: string;
  /** Its record says `"include": false`: out of the build. */
  excluded?: boolean;
  found: Found;
  options: Options;
  /** Records that would not parse, values a schema refused. */
  problems?: readonly string[];
  reference?: boolean;
  /** Its export would share a path or a key with another file's: why. */
  conflict?: string;
  /** The source is an unfetched LFS pointer. */
  pointer?: boolean;
  /** Its sha1; undefined until read. */
  hash?: string;
  /** Its scanner could not read it for parts. */
  partsError?: string;
  parts: readonly PartState[];
  record?: ExportRecord;
  /** Export paths not on disk. */
  exportsMissing: readonly string[];
  /**
   * The exports on disk, each with the extension of `to` it is written as: an unfetched LFS pointer,
   * or its sha1 (read only when the record has `built.out` to hold it to; undefined until read).
   */
  exportsThere?: ReadonlyArray<{ path: string; ext: string; hash?: string; pointer?: boolean }>;
  /** `_<stem>.glb` beside it, when its row may use one: its name and hash (undefined until read). */
  intermediate?: { name: string; hash?: string };
  /** The row's steps, in order. */
  steps: readonly StepInfo[];
  /** This machine's tools; undefined when not looked for (`--check`, or still looking). */
  tools?: ReadonlyMap<string, ToolLook>;
  /** npm packages' versions. */
  npm: Readonly<Record<string, string>>;
  /** Who can do a browser step: a game tab is connected, none is, or this is the CLI. */
  browser: 'tab' | 'none' | 'cli';
  lastRun?: LastRun;
  /** sha1 of a text. */
  digest: (text: string) => string;
}

export interface StatusResult {
  status: Status;
  reason?: string;
  note?: string;
  /** The recipe hash with this machine's tools. */
  recipe?: string;
  /** What `built.tools` says when this exports now. */
  tools?: Record<string, string>;
  /** Parts' and the intermediate's hashes, by name: `built.deps`. */
  deps?: Record<string, string>;
  /** The intermediate stands in for the first step. */
  fromIntermediate: boolean;
}

const base = (path: string): string => path.slice(path.lastIndexOf('/') + 1);

/**
 * Why an excluded source is not exported: its status's reason, and -- after
 * "excluded: " -- what `npm run export` says when it is asked for by name.
 */
export const EXCLUDED = 'tick it in the tool, or remove `include: false` from its record';

/** The PATH tools of a list of steps, by name. */
function pathTools(steps: readonly StepInfo[]): string[] {
  return [...new Set(steps.flatMap((s) => s.needs.map((n) => n.tool)))].sort();
}

/** The versions the recipe hash is taken with: PATH tools from `tools`, npm ones from `npm`; `null` for none. */
export function recipeTools(steps: readonly StepInfo[], tools: ReadonlyMap<string, ToolLook> | undefined, npm: Readonly<Record<string, string>>): Record<string, string | null> {
  const out: Record<string, string | null> = {};
  for (const tool of pathTools(steps)) out[tool] = tools?.get(tool)?.version ?? null;
  for (const name of [...new Set(steps.flatMap((s) => s.npm))].sort()) out[name] = npm[name] ?? null;
  return out;
}

/** The recipe hash for these inputs. */
export function recipeHash(input: Pick<StatusInput, 'found' | 'options' | 'steps' | 'npm' | 'digest'>, tools: Readonly<Record<string, string | null>>): string {
  return input.digest(recipeText(input.found, input.options, input.steps.map((s) => [s.name, s.version] as const), tools));
}

/** Can the row's first step be stood in for by `_<stem>.glb`? */
export function usesIntermediate(found: Found, steps: readonly StepInfo[]): boolean {
  return found.row.byHand === true || steps[0]?.where === 'browser';
}

/**
 * Step 6: why a stale or missing source cannot be made on this machine, or
 * undefined when it can. Its first step out of reach with no intermediate made
 * from this very source standing in -- a browser step with no game tab, a hand
 * export with no Blender -- or a tool the steps still to run need missing or
 * lacking. Tools not looked for (`--check`) are not held against it.
 */
export function unmadeReason(input: StatusInput, fromIntermediate: boolean): string | undefined {
  const name = base(input.source);
  const toRun = fromIntermediate ? input.steps.slice(1) : input.steps;
  if (!fromIntermediate && usesIntermediate(input.found, input.steps)) {
    const first = input.steps[0]!;
    if (first.where === 'browser' && input.browser !== 'tab') {
      return input.browser === 'cli' ? 'needs the editor: open the Assets tool with this source in view' : 'needs a game tab open on this machine';
    }
    if (input.found.row.byHand && input.tools) {
      const look = input.tools.get(first.needs[0]?.tool ?? '');
      if (!look || look.state !== 'found') {
        const stem = name.replace(/\.[^.]+$/, '');
        const tool = first.needs[0]?.tool ?? first.name;
        const Tool = tool.charAt(0).toUpperCase() + tool.slice(1);
        return input.intermediate
          ? `${name} changed since its hand export: export _${stem}.glb again from ${Tool}, or install ${Tool}`
          : `export _${stem}.glb from ${Tool} by hand, or install ${Tool}`;
      }
    }
  }
  if (!input.tools) return undefined;
  for (const step of toRun) {
    if (step.where === 'browser') continue;
    for (const need of step.needs) {
      const look = input.tools.get(need.tool);
      if (!look || look.state === 'missing') return `needs ${need.tool}${look?.hint ? `: ${look.hint}` : ''}`;
      if (look.state === 'lacking') return `needs ${need.tool}${need.what ? ` with ${need.what}` : ''}${look.hint ? `: ${look.hint}` : ''}`;
    }
  }
  return undefined;
}

export function statusOf(input: StatusInput): StatusResult {
  const no = { fromIntermediate: false };
  const name = base(input.source);
  // 0.
  if (input.excluded) return { status: 'excluded', reason: EXCLUDED, ...no };
  // 1.
  if (input.reference) return { status: 'reference', reason: 'reference: nothing is made from it', ...no };
  if (input.conflict) return { status: 'conflict', reason: input.conflict, ...no };
  // 2.
  if (input.pointer) return { status: 'failed', reason: 'LFS pointer: run git lfs pull', ...no };
  const missing = input.parts.filter((p) => p.missing);
  if (missing.length > 0) {
    const more = missing.length > 1 ? ` (and ${missing.length - 1} more)` : '';
    return { status: 'failed', reason: `${name} names ${missing[0]!.name}, which is not there${more}`, ...no };
  }
  const pointer = input.parts.find((p) => p.pointer);
  if (pointer) return { status: 'failed', reason: `${pointer.name} is an LFS pointer: run git lfs pull`, ...no };
  // An export that is a pointer is not the file: what ships would be 130 bytes of text (CI checked out without LFS).
  const outPointer = input.exportsThere?.find((x) => x.pointer);
  if (outPointer) return { status: 'failed', reason: `${base(outPointer.path)} is an LFS pointer, not its export: run git lfs pull`, ...no };
  if (input.partsError) return { status: 'failed', reason: `${name} cannot be read for its parts: ${input.partsError}`, ...no };
  if (input.problems && input.problems.length > 0) return { status: 'failed', reason: input.problems[0]!, ...no };
  // 3, 4.
  const heldTo = input.record?.built?.out;
  if (
    input.hash === undefined ||
    input.parts.some((p) => p.hash === undefined) ||
    (input.intermediate && input.intermediate.hash === undefined) ||
    (heldTo !== undefined && input.exportsThere?.some((x) => heldTo[x.ext] !== undefined && x.hash === undefined))
  ) {
    return { status: 'checking', ...no };
  }
  const here = recipeTools(input.steps, input.tools, input.npm);
  const recipe = recipeHash(input, here);
  const tools: Record<string, string> = {};
  for (const [tool, version] of Object.entries(here)) if (version !== null) tools[tool] = version;
  const deps: Record<string, string> = {};
  for (const p of input.parts) deps[p.name] = p.hash!;
  if (input.intermediate) deps[input.intermediate.name] = input.intermediate.hash!;
  const built = input.record?.built;
  const canStandIn = usesIntermediate(input.found, input.steps);
  // A hand export stands in only where its tool is not: where Blender is found, Blender exports.
  const firstTool = input.steps[0]?.needs[0]?.tool;
  const toolHere = input.found.row.byHand === true && firstTool !== undefined && input.tools?.get(firstTool)?.state === 'found';
  const fromIntermediate =
    canStandIn &&
    !toolHere &&
    input.intermediate !== undefined &&
    (!built || built.source === input.hash || built.deps?.[input.intermediate.name] !== input.intermediate.hash);
  const out = { recipe, tools, deps, fromIntermediate };

  // 5. An export held to its record's `built.out`; a record without it (written before it was) holds nothing.
  const changedOut = heldTo === undefined ? undefined : input.exportsThere?.find((x) => heldTo[x.ext] !== undefined && x.hash !== heldTo[x.ext]);
  let status: 'missing' | 'stale';
  let reason: string;
  if (input.exportsMissing.length > 0) {
    status = 'missing';
    reason = built ? `${base(input.exportsMissing[0]!)} is missing` : 'no export yet';
  } else if (!built) {
    status = 'stale';
    reason = 'no record';
  } else if (built.source !== input.hash) {
    status = 'stale';
    reason = `${name} changed`;
  } else if (canonical(built.deps ?? {}) !== canonical(deps)) {
    status = 'stale';
    const was = built.deps ?? {};
    const changed = Object.keys(deps).find((k) => was[k] !== deps[k]) ?? Object.keys(was).find((k) => !(k in deps));
    reason = changed === undefined ? 'its parts changed' : changed in deps ? (changed in was ? `${changed} changed` : `${changed} is new`) : `${changed} is gone`;
  } else if (changedOut !== undefined) {
    status = 'stale';
    reason = `${base(changedOut.path)} is not the file its record says was built (edited by hand, or a bad copy)`;
  } else if (built.recipe !== recipe) {
    // Again, with the record's PATH-tool versions: only they may differ for `current`.
    const theirs = { ...here };
    for (const tool of pathTools(input.steps)) theirs[tool] = built.tools[tool] ?? null;
    if (recipeHash(input, theirs) !== built.recipe) {
      status = 'stale';
      reason = 'its options or its recipe changed';
    } else {
      // Not looked for (`--check`): nothing to compare, so nothing said.
      const differ = input.tools
        ? pathTools(input.steps)
            .filter((tool) => (built.tools[tool] ?? null) !== here[tool])
            .map((tool) => `built with ${tool} ${built.tools[tool] ?? '(none)'}; ${here[tool] ?? 'not found'} here`)
        : [];
      return { status: 'current', ...(differ.length ? { note: differ.join('; ') } : {}), ...out };
    }
  } else return { status: 'current', ...out };

  // 6.
  const unmade = unmadeReason(input, fromIntermediate);
  if (unmade !== undefined) return { status: 'unmade', reason: unmade, ...out };
  // 7.
  const last = input.lastRun;
  if (last && !last.ok && last.source === input.hash && last.recipe === recipe && canonical(last.deps) === canonical(deps)) {
    return { status: 'failed', reason: `the last export failed: ${last.error ?? 'see its output'}`, ...out };
  }
  return { status, reason, ...out };
}
