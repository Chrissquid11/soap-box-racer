/**
 * The files a source reads besides itself -- its *parts* -- found by reading
 * the source (Docs/assets.md §3, "Parts").
 *
 * A row's `deps(sourcePath)` returns a scanner, `{ feed(chunk), done() }`, fed
 * every chunk of **the one streamed read that hashes the source** (`hashes.ts`):
 * finding the parts costs no read of its own, and the names are cached with the
 * hash. So every scanner here works on chunks of any size, a name split across
 * two included, and keeps only what it needs (a `.glb`'s JSON chunk, a tail of
 * 256 bytes), never the whole of a big file.
 *
 *   .gltf / .glb   buffers[].uri and images[].uri, but `data:` URIs
 *   .obj           every `mtllib`; and a `.mtl` (itself a part) its texture maps
 *   .dae           every <init_from> under <library_images>
 *   .fbx / .lua    every image file name the bytes hold (`search`: matched
 *                  against the folder by the index, not here); a `.lua` its
 *                  model files too -- the `.glb` or `.fbx` it `import`s
 *                  (Docs/modeler.md M38)
 *   atlas sheet    <stem>.json beside it
 *
 * Paths come back relative to the source's folder, `/`-separated; a `search`
 * scanner's names are bare file names.
 *
 * Pure: no `node:` import, no import at all but types, so the editor reads a
 * dropped model's parts in the browser with the same code. The GLB parser here
 * is `stats/glb.ts`'s too.
 */

export interface Scanner {
  /** One more chunk of the source, in order. */
  feed(chunk: Uint8Array): void;
  /** Every part the source names. Rejects on a source it cannot read (bad JSON). */
  done(): Promise<string[]>;
}

/**
 * A row's `deps`: a scanner per source. `search` scanners return bare names
 * that the index matches against the files in the source's folder (and a
 * `textures/` folder under it); the rest return paths that must exist, or the
 * source is `failed` ("robot.obj names robot.mtl, which is not there").
 */
export interface Deps {
  (sourcePath: string): Scanner;
  readonly search?: boolean;
  /**
   * Bumped when the scanner finds more than it did: the names the hashes cache
   * kept from an older one are read again (`hashes.ts`). Absent is 1.
   */
  readonly version?: number;
}

const deps = (make: (sourcePath: string) => Scanner, search = false, version?: number): Deps => Object.assign(make, { search, ...(version !== undefined ? { version } : {}) });

/** Image extensions an `.fbx` or a script may name. */
export const IMAGE_EXT = ['png', 'jpg', 'jpeg', 'tga', 'bmp', 'tif', 'tiff', 'webp', 'psd', 'gif', 'dds', 'ktx2', 'exr', 'hdr', 'avif'] as const;

/**
 * Model files a script may `import` (Gladius reads a `.glb` and, since 0.7.2,
 * an `.fbx`): a part of the script that names one, never a source of its own
 * -- the copy an import writes beside its script (Docs/modeler.md M38).
 */
export const IMPORT_EXT = ['glb', 'fbx'] as const;

/** The longest file name a `search` scanner finds whole: the overlap kept between chunks. */
export const LONGEST_NAME = 255;

// ---------------------------------------------------------------- shared bits

/** A part path as written in a file: URI-decoded, `\` made `/`, `./` dropped. */
function cleanRef(ref: string, uri: boolean): string | undefined {
  // `file://name` (Collada writes it) is the name; any other scheme is not a file beside it.
  let r = ref.trim().replace(/^file:\/\//i, '');
  if (r === '' || /^data:/i.test(r) || /^[a-z][a-z0-9+.-]*:\/\//i.test(r)) return undefined;
  if (uri) {
    try {
      r = decodeURIComponent(r);
    } catch {
      // Not valid percent-encoding: the name as written.
    }
  }
  r = r.split('\\').join('/');
  while (r.startsWith('./')) r = r.slice(2);
  return r === '' ? undefined : r;
}

function unique(list: Iterable<string>): string[] {
  return [...new Set(list)];
}

/** Text decoded as it streams: a UTF-8 sequence split across chunks is kept whole. */
function utf8(): { push(chunk: Uint8Array): string; end(): string } {
  const decoder = new TextDecoder('utf-8', { fatal: false });
  return { push: (chunk) => decoder.decode(chunk, { stream: true }), end: () => decoder.decode() };
}

/** Lines as they stream: `line` for each whole one, the last one at `end`. */
function lines(onLine: (line: string) => void): { push(chunk: Uint8Array): void; end(): void } {
  const text = utf8();
  let carry = '';
  const take = (s: string, last: boolean): void => {
    carry += s;
    const parts = carry.split(/\r?\n|\r/);
    carry = last ? '' : parts.pop()!;
    for (const line of parts) onLine(line);
  };
  return { push: (chunk) => take(text.push(chunk), false), end: () => take(text.end(), true) };
}

// ---------------------------------------------------------------- glTF and GLB

/** The GLB magic, `glTF` little-endian. */
const GLB_MAGIC = 0x46546c67;
const CHUNK_JSON = 0x4e4f534a;

/**
 * How many bytes of a `.glb` hold its header and JSON chunk, read from its
 * first 20; undefined if they are not a GLB's.
 */
export function glbHeadLength(head: Uint8Array): number | undefined {
  if (head.length < 20) return undefined;
  const view = new DataView(head.buffer, head.byteOffset, head.byteLength);
  if (view.getUint32(0, true) !== GLB_MAGIC || view.getUint32(16, true) !== CHUNK_JSON) return undefined;
  return 20 + view.getUint32(12, true);
}

/** A glTF's JSON as this reads it: loosely, every field optional. */
export interface GltfJson {
  asset?: { generator?: string; version?: string };
  buffers?: Array<{ uri?: string; byteLength?: number }>;
  bufferViews?: Array<{ buffer?: number; byteOffset?: number; byteLength?: number; byteStride?: number }>;
  images?: Array<{ uri?: string; bufferView?: number; mimeType?: string; name?: string }>;
  textures?: Array<{ source?: number; extensions?: Record<string, { source?: number }> }>;
  materials?: unknown[];
  meshes?: Array<{
    name?: string;
    primitives: Array<{
      attributes: Record<string, number>;
      indices?: number;
      mode?: number;
      material?: number;
      extensions?: Record<string, unknown>;
    }>;
  }>;
  accessors?: Array<{ count: number; type: string; componentType: number; min?: number[]; max?: number[]; bufferView?: number }>;
  animations?: Array<{ name?: string; channels?: unknown[]; samplers?: Array<{ input: number; output: number }> }>;
  skins?: Array<{ joints?: number[] }>;
  nodes?: unknown[];
  extensionsUsed?: string[];
  extensionsRequired?: string[];
}

/** A GLB's JSON chunk, parsed from its first bytes (at least `glbHeadLength`). */
export function glbJson(bytes: Uint8Array): GltfJson {
  const length = glbHeadLength(bytes);
  if (length === undefined) throw new Error('not a GLB (no glTF header and JSON chunk)');
  if (bytes.length < length) throw new Error(`a GLB cut short: its JSON chunk is ${length - 20} bytes, ${bytes.length - 20} read`);
  return JSON.parse(new TextDecoder().decode(bytes.subarray(20, length))) as GltfJson;
}

/** The files a glTF names: its buffers' and images' URIs, but `data:` ones. */
export function gltfUris(json: GltfJson): string[] {
  const out: string[] = [];
  for (const { uri } of [...(json.buffers ?? []), ...(json.images ?? [])]) {
    const ref = uri === undefined ? undefined : cleanRef(uri, true);
    if (ref) out.push(ref);
  }
  return unique(out);
}

/** `.gltf`: the whole file is its JSON, so it is kept until `done`. */
export const gltfParts: Deps = deps(() => {
  const text = utf8();
  let all = '';
  return {
    feed: (chunk) => void (all += text.push(chunk)),
    done: async () => {
      all += text.end();
      return gltfUris(JSON.parse(all) as GltfJson);
    },
  };
});

/** `.glb`: only its header and JSON chunk are kept; the binary chunk streams past. */
export const glbParts: Deps = deps(() => {
  let head = new Uint8Array(0);
  let want: number | undefined;
  return {
    feed(chunk) {
      if (want !== undefined && head.length >= want) return;
      const next = new Uint8Array(head.length + chunk.length);
      next.set(head);
      next.set(chunk, head.length);
      head = next;
      want ??= glbHeadLength(head);
      if (want !== undefined && head.length > want) head = head.subarray(0, want);
    },
    async done() {
      if (want === undefined) throw new Error('not a GLB');
      return gltfUris(glbJson(head));
    },
  };
});

/** Is this `.glb`'s JSON naming files beside it -- so `pack-gltf` must read it by path? */
export function namesFiles(json: GltfJson): boolean {
  return gltfUris(json).length > 0;
}

// ---------------------------------------------------------------- OBJ and MTL

/** `.obj`: every `mtllib` it names (one line may name several). */
export const objParts: Deps = deps(() => {
  const found: string[] = [];
  const reader = lines((line) => {
    const m = /^\s*mtllib\s+(.+?)\s*$/.exec(line);
    if (!m) return;
    for (const name of m[1]!.split(/\s+/)) {
      const ref = cleanRef(name, false);
      if (ref) found.push(ref);
    }
  });
  return {
    feed: (chunk) => reader.push(chunk),
    done: async () => {
      reader.end();
      return unique(found);
    },
  };
});

const MTL_MAPS = new Set(['map_kd', 'map_ks', 'map_ka', 'map_ns', 'map_d', 'map_bump', 'bump', 'norm', 'disp']);

/** `.mtl` (a part with parts): the file of every texture map, after any `-option value`s. */
export const mtlParts: Deps = deps(() => {
  const found: string[] = [];
  const reader = lines((line) => {
    const words = line.trim().split(/\s+/);
    if (words.length < 2 || !MTL_MAPS.has(words[0]!.toLowerCase())) return;
    const ref = cleanRef(words[words.length - 1]!, false);
    if (ref) found.push(ref);
  });
  return {
    feed: (chunk) => reader.push(chunk),
    done: async () => {
      reader.end();
      return unique(found);
    },
  };
});

// ---------------------------------------------------------------- Collada

/**
 * `.dae`: the text of every `<init_from>` under `<library_images>` (COLLADA
 * 1.4; 1.5 wraps it in `<ref>`). An `<init_from>` elsewhere -- an effect's
 * surface naming an image by id -- is not a file. Tags are read as the text
 * streams; only the part after the last complete tag is kept.
 */
export const daeParts: Deps = deps(() => {
  const text = utf8();
  const found: string[] = [];
  let pending = '';
  let inImages = false;
  let capture: string | undefined;
  const TAG = /<\s*(\/?)\s*([A-Za-z_][\w:.-]*)[^>]*?(\/?)>/g;
  const scan = (last: boolean): void => {
    let consumed = 0;
    TAG.lastIndex = 0;
    for (let m = TAG.exec(pending); m; m = TAG.exec(pending)) {
      if (capture !== undefined) capture += pending.slice(consumed, m.index);
      consumed = TAG.lastIndex;
      const closing = m[1] === '/';
      const name = m[2]!.replace(/^.*:/, '');
      const empty = m[3] === '/';
      if (name === 'library_images') inImages = !closing && !empty;
      else if (inImages && (name === 'init_from' || name === 'ref')) {
        if (!closing && !empty && capture === undefined && name === 'init_from') capture = '';
        else if (closing && name === 'init_from' && capture !== undefined) {
          const ref = cleanRef(capture.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'), true);
          if (ref) found.push(ref);
          capture = undefined;
        }
      }
    }
    const rest = pending.slice(consumed);
    // Text inside a tag being captured is kept; outside, only what may begin the next tag.
    const lt = rest.lastIndexOf('<');
    if (capture !== undefined) {
      if (lt < 0) {
        capture += rest;
        pending = '';
      } else {
        capture += rest.slice(0, lt);
        pending = rest.slice(lt);
      }
    } else pending = last || lt < 0 ? '' : rest.slice(lt);
  };
  return {
    feed(chunk) {
      pending += text.push(chunk);
      scan(false);
    },
    async done() {
      pending += text.end();
      scan(true);
      return unique(found);
    },
  };
});

// ---------------------------------------------------------------- names in the bytes

const NAME_CHAR = 'A-Za-z0-9_.+~()\\-';
/** A name ending in one of `exts`, longest first: `x.tiff` is not `x.tif` and an `f`. */
const namePattern = (exts: readonly string[]): RegExp =>
  new RegExp(`(?<![${NAME_CHAR}])[${NAME_CHAR}]*?[A-Za-z0-9_+~()\\-]\\.(?:${[...exts].sort((a, b) => b.length - a.length).join('|')})`, 'gi');
const IMAGE_NAME = namePattern(IMAGE_EXT);

/**
 * Every image file name the bytes hold, binary or text: a run of name
 * characters up to an image extension, its last path component (an FBX stores
 * the names it refers to as plain strings, `C:\\Users\\mia\\robot-diffuse.png`;
 * `\\`, `/` and any other byte end a run). Nothing is asked of what follows the
 * extension: a binary FBX string runs straight into the next record's bytes,
 * often printable (the next property's type code, `S`), so `crate.png.bak`
 * names `crate.png` too -- a name the index then finds in the folder or not.
 *
 * Searched chunk by chunk with the last 256 bytes of the text before in front,
 * so a name split across two chunks is found whole. A match at the very front
 * of that overlap is skipped (its first character may not be the name's: it was
 * seen whole the pass before), and one at the very end waits for the next pass
 * (the name may go on: `x.tif` may be `x.tiff`).
 */
function imageNames(pattern = IMAGE_NAME): Scanner {
  const found = new Set<string>();
  let text = '';
  /** Where `text` starts in the file, in bytes. */
  let offset = 0;
  const scan = (last: boolean): void => {
    pattern.lastIndex = 0;
    for (let m = pattern.exec(text); m; m = pattern.exec(text)) {
      if (m.index === 0 && offset > 0) continue;
      if (m.index + m[0].length === text.length && !last) continue;
      found.add(m[0]);
    }
  };
  return {
    feed(chunk) {
      // latin1: one character a byte, so the overlap is counted in bytes. By hand, a 32 KB slice
      // at a time: this module imports nothing (the browser shares it), so no `Buffer`, and
      // `TextDecoder('latin1')` is windows-1252, which maps 0x80-0x9f to other characters.
      let s = '';
      for (let i = 0; i < chunk.length; i += 0x8000) s += String.fromCharCode(...chunk.subarray(i, i + 0x8000));
      const keep = text.slice(-(LONGEST_NAME + 1));
      offset += text.length - keep.length;
      text = keep + s;
      scan(false);
    },
    async done() {
      scan(true);
      return [...found];
    },
  };
}

/** `.fbx`, binary or ASCII: every image name in its bytes, matched against the folder by the index. */
export const fbxParts: Deps = deps(() => imageNames(), true);

/**
 * The string literals of a Lua text -- `"…"`, `'…'` (escapes stepped over) and
 * long brackets `[[…]]`, `[==[…]==]` -- never what is in a comment (`--` to the
 * line's end, `--[[ … ]]`): the names a script really passes.
 */
export function luaStrings(text: string): string[] {
  const out: string[] = [];
  const longClose = (at: number): { level: number; body: number } | null => {
    // `[` then `=`* then `[`: a long bracket opening at `at`.
    let i = at + 1;
    while (text[i] === '=') i++;
    return text[i] === '[' ? { level: i - at - 1, body: i + 1 } : null;
  };
  let i = 0;
  while (i < text.length) {
    const c = text[i]!;
    if (c === '-' && text[i + 1] === '-') {
      const long = text[i + 2] === '[' ? longClose(i + 2) : null;
      if (long) {
        const close = `]${'='.repeat(long.level)}]`;
        const end = text.indexOf(close, long.body);
        i = end < 0 ? text.length : end + close.length;
      } else {
        const end = text.indexOf('\n', i);
        i = end < 0 ? text.length : end + 1;
      }
      continue;
    }
    if (c === '"' || c === "'") {
      let j = i + 1;
      let body = '';
      while (j < text.length && text[j] !== c && text[j] !== '\n') {
        if (text[j] === '\\' && j + 1 < text.length) {
          body += text[j + 1];
          j += 2;
          continue;
        }
        body += text[j];
        j++;
      }
      out.push(body);
      i = j + 1;
      continue;
    }
    if (c === '[') {
      const long = longClose(i);
      if (long) {
        const close = `]${'='.repeat(long.level)}]`;
        const end = text.indexOf(close, long.body);
        out.push(text.slice(long.body, end < 0 ? text.length : end));
        i = end < 0 ? text.length : end + close.length;
        continue;
      }
    }
    i++;
  }
  return out;
}

/** A file name with one of these extensions at a string's end, its last path component: `"maps/Big Crate.source.glb"` names `Big Crate.source.glb`. */
const SCRIPT_FILE = new RegExp(`\\.(?:${[...IMAGE_EXT, ...IMPORT_EXT].join('|')})$`, 'i');

/**
 * `.lua`: the files the script names **in its string literals** -- images, and
 * the model files it `import`s, `import("Big Crate.source.glb", …)` making the
 * copy a part of the script (Docs/modeler.md M39) -- spaces and all; a name in
 * a comment is none (a starter's comment naming `Test Thing.glb` names no part).
 * A script is text and small: kept whole until `done`, then read as Lua.
 * Version 3: the hashes cache's names of version 1 (images in any bytes) and 2
 * (a name cut at a space) are read again.
 */
export const luaParts: Deps = deps(() => {
  const text = utf8();
  let all = '';
  return {
    feed: (chunk) => void (all += text.push(chunk)),
    done: async () => {
      all += text.end();
      const found = new Set<string>();
      for (const str of luaStrings(all)) {
        const name = str.trim().split(/[\\/]/).pop() ?? '';
        if (name !== '' && name.length <= LONGEST_NAME && SCRIPT_FILE.test(name)) found.add(name);
      }
      return [...found];
    },
  };
}, true, 3);

// ---------------------------------------------------------------- an atlas sheet

/** A packer's `.png`/`.webp`: `<stem>.json` beside it, which must exist. Nothing read. */
export const sheetJson: Deps = deps((sourcePath) => {
  const name = sourcePath.slice(sourcePath.lastIndexOf('/') + 1);
  const dot = name.lastIndexOf('.');
  const stem = dot > 0 ? name.slice(0, dot) : name;
  return { feed: () => {}, done: async () => [`${stem}.json`] };
});

/** A part's own parts, by its extension: an `.obj`'s `.mtl` names its textures. */
export const PART_DEPS: Readonly<Record<string, Deps>> = { mtl: mtlParts };

/**
 * A `search` scanner's names matched against what is in the source's folder
 * and a `textures/` folder under it: `names` from the scanner, `files` the
 * paths there relative to the folder. Case does not matter (an FBX written on
 * Windows names `Robot-Diffuse.PNG`); the file's own spelling comes back.
 */
export function matchNames(names: readonly string[], files: readonly string[]): string[] {
  const wanted = new Set(names.map((n) => n.toLowerCase()));
  return files.filter((f) => {
    const slash = f.lastIndexOf('/');
    const dir = slash < 0 ? '' : f.slice(0, slash);
    if (dir !== '' && dir !== 'textures') return false;
    return wanted.has(f.slice(slash + 1).toLowerCase());
  });
}
