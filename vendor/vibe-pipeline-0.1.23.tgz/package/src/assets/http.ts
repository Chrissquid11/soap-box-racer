/**
 * The dev server's HTTP plumbing (Docs/assets.md §5, "Who may call, and how"):
 * who may write, the path rule, bodies and their limits, and answers. Node's
 * own `http` types and nothing of Vite's, so `server.test.ts` runs the API on a
 * bare `http.createServer`.
 *
 * - **Writes only from this machine.** A mutating call -- any method but GET
 *   and HEAD -- from an address that is not loopback is `403`: a phone or a
 *   colleague on the LAN previews, never changes the project.
 * - **No other page can call it.** A mutating call is a `PUT`, or a `POST`
 *   with `Content-Type: application/json` (anything else `415`): both are
 *   preflighted by a browser. Vite's CORS default lets every localhost port in,
 *   so a call with an `Origin` must carry the request's own host and port
 *   there (`403`); one without (a `curl`) is held to loopback like the rest.
 * - **Only this machine's names** (DNS rebinding): every call -- a read too,
 *   since a read can leak -- must name the server by `localhost` (or a
 *   `*.localhost`), `127.0.0.1`, `[::1]` or one of Vite's own
 *   `server.allowedHosts` in its `Host` header, and an `Origin` must be that
 *   host (`403`). A page at `evil.example` whose name is made to resolve to
 *   127.0.0.1 sends `Host: evil.example`, and is refused here whatever Vite's
 *   own host check -- which runs before every route but is off with
 *   `allowedHosts: true` or HTTPS -- did. `allowedHosts: true` adds nothing.
 * - **The path rule.** A path argument is relative to the project root, `/`
 *   only, no empty, `.` or `..` segment, no `\` or NUL; it is under one of the
 *   allowed folders (a root's `dir`, or `.trash/` where a call reads it), and
 *   the real path of the deepest folder of it that exists is under the real
 *   path of one of them -- a symlink cannot lead out. A final symlink is
 *   resolved and checked the same way. A folder that does not exist yet (a
 *   twin an import makes) is checked lexically, then made by the caller.
 * - **Bodies have limits**: JSON 64 KB unless a call says otherwise, over it
 *   `413` (once the rest is read and dropped: an answer, not a reset). A body
 *   streamed to a file has none but the disk, and a request that ends early
 *   leaves nothing behind.
 *
 * A refusal is thrown as `Refused` -- `{ refused, suggested? }` and its status
 * -- and answered by the router. Nothing at module level: the hosts a server's
 * Vite config allows are handed to each guard by its routes (`allowedHosts`).
 */
import { createWriteStream } from 'node:fs';
import { lstat, mkdir, realpath, rm } from 'node:fs/promises';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { dirname, join, sep } from 'node:path';
import { pipeline } from 'node:stream/promises';
import type { Refusal } from './api-types.ts';
import { code } from './fs.ts';
import { checkedPath } from './paths.ts';

/** A call refused: its status (`403`, `409`, `413`, `415`, `422`, or `404`) and its body, always with `refused`. */
export class Refused extends Error {
  readonly status: number;
  readonly body: Refusal & Record<string, unknown>;
  constructor(status: number, refused: string, extra: Record<string, unknown> = {}) {
    super(refused);
    this.status = status;
    this.body = { refused, ...extra };
  }
}

/** The addresses that are this machine. */
const LOOPBACK = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);

export function isLoopback(address: string | undefined): boolean {
  return address !== undefined && LOOPBACK.has(address);
}

/** Does this call change anything? Every method but GET and HEAD. */
export function mutating(req: IncomingMessage): boolean {
  return req.method !== 'GET' && req.method !== 'HEAD';
}

/** The names that are this machine whatever DNS says: what `Host` may always be. */
const LOOPBACK_NAMES = new Set(['localhost', '127.0.0.1', '[::1]']);

/**
 * Vite's `server.allowedHosts` as the guards read it: lowercased, a leading `.` that domain and its subdomains.
 * `true` -- Vite's own check off -- trusts nothing more than this machine's names. Each server's own, handed to
 * each guard by the route that calls it (from its `server.config.server.allowedHosts`): never module state, so two
 * dev servers in one process each trust only theirs.
 */
export function allowedHosts(hosts: readonly string[] | boolean | undefined): readonly string[] {
  return Array.isArray(hosts) ? hosts.map((h) => h.toLowerCase()) : [];
}

/**
 * Is a `Host` header (or an `Origin`'s host) this machine by name? `localhost`, a `*.localhost`,
 * `127.0.0.1`, `[::1]`, or one of `allowed` (`allowedHosts`') -- any port. None at all (no browser sends that) passes.
 */
export function trustedHost(host: string | undefined, allowed: readonly string[] = []): boolean {
  if (host === undefined) return true;
  if (host === '' || /[/@?#\\\s]/.test(host)) return false;
  let name: string;
  try {
    name = new URL(`http://${host}`).hostname.toLowerCase();
  } catch {
    return false;
  }
  if (LOOPBACK_NAMES.has(name) || name.endsWith('.localhost')) return true;
  return allowed.some((a) => a === name || (a.startsWith('.') && (a.slice(1) === name || name.endsWith(a))));
}

/** The name a request gives the server: HTTP/2's `:authority`, else `Host` -- as Vite's own host check reads it. */
export function authority(req: IncomingMessage): string | undefined {
  const given = req.headers[':authority'];
  return typeof given === 'string' ? given : req.headers.host;
}

/** The DNS-rebinding guard, for every call to every route, reads too: `Host` this machine's name, else `403`. */
export function guardHost(req: IncomingMessage, allowed: readonly string[] = []): void {
  const host = authority(req);
  if (!trustedHost(host, allowed)) throw new Refused(403, `this dev server answers to localhost, not to ${JSON.stringify(host)}`);
}

/** Is an `Origin` header, when there is one, this server's own: the request's `Host` (`:authority`), port and all? */
function ownOrigin(req: IncomingMessage, allowed: readonly string[]): boolean {
  const host = authority(req);
  if (!trustedHost(host, allowed)) return false;
  const origin = req.headers.origin;
  if (origin === undefined) return true;
  try {
    return new URL(origin).host.toLowerCase() === (host ?? '').toLowerCase();
  } catch {
    return false;
  }
}

/** May this caller write? From this machine, by this machine's name, and from this server's own page if from a page at all. */
export function mayWrite(req: IncomingMessage, allowed: readonly string[] = []): boolean {
  return isLoopback(req.socket.remoteAddress) && ownOrigin(req, allowed);
}

/**
 * A mutating call's guards, in order: this machine, by its name, this server's own page,
 * and -- for a `POST` -- JSON, so a browser has to preflight it. `port` names
 * where the page is, in the refusal; `allowed` is the server's own `allowedHosts`.
 */
export function guardWrite(req: IncomingMessage, port: number | undefined, allowed: readonly string[] = []): void {
  if (!isLoopback(req.socket.remoteAddress)) {
    throw new Refused(403, `writes are only allowed from the machine running the dev server, at localhost:${port ?? 5190}`);
  }
  guardHost(req, allowed);
  if (!ownOrigin(req, allowed)) throw new Refused(403, `another page may not change this project (Origin ${req.headers.origin})`);
  if (req.method === 'POST') {
    const type = (req.headers['content-type'] ?? '').split(';')[0]!.trim().toLowerCase();
    if (type !== 'application/json') throw new Refused(415, 'a POST here is JSON: Content-Type: application/json');
  }
}

// ---------------------------------------------------------------- bodies

/**
 * The bytes of a body, at most `limit`: over it, `413`. The rest of a body
 * that is too big is read and dropped before the answer goes, so the caller
 * hears `413` rather than a connection reset in the middle of its upload.
 */
export async function readBody(req: IncomingMessage, limit: number): Promise<Buffer> {
  const said = limit >= 1024 * 1024 ? `${limit / (1024 * 1024)} MB` : `${Math.round(limit / 1024)} KB`;
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size <= limit) chunks.push(chunk as Buffer);
  }
  if (size > limit) throw new Refused(413, `the body is over ${said}`);
  return Buffer.concat(chunks);
}

/**
 * Whatever of a body is still coming, read and dropped: a call refused before
 * it read its body answers once the upload is over, so the caller hears the
 * refusal, not a reset in the middle of sending.
 */
export async function drain(req: IncomingMessage): Promise<void> {
  if (req.complete || req.destroyed) return;
  try {
    for await (const _chunk of req) {
      // dropped
    }
  } catch {
    // The caller went away: nobody to answer.
  }
}

/** A JSON body, at most `limit` bytes (64 KB): `422` when it is not JSON, or not an object. */
export async function readJson(req: IncomingMessage, limit = 64 * 1024): Promise<Record<string, unknown>> {
  const bytes = await readBody(req, limit);
  let value: unknown;
  try {
    value = bytes.length === 0 ? {} : JSON.parse(bytes.toString('utf8'));
  } catch {
    throw new Refused(422, 'the body is not JSON');
  }
  if (typeof value !== 'object' || value === null || Array.isArray(value)) throw new Refused(422, 'the body is not a JSON object');
  return value as Record<string, unknown>;
}

/**
 * A body streamed to `file` (absolute; its folder made), no limit but the
 * disk. A request that ends early -- the tab closed, the connection reset --
 * leaves nothing: the file goes, and the call throws. Answers the bytes written.
 */
export async function bodyToFile(req: IncomingMessage, file: string): Promise<number> {
  await mkdir(dirname(file), { recursive: true });
  const out = createWriteStream(file, { flags: 'wx' }); // write-ok: a new temp file (wx), renamed into place by the caller
  try {
    await pipeline(req, out);
    if (!req.complete) throw new Error('the request ended early');
  } catch (err) {
    await rm(file, { force: true });
    throw err;
  }
  return out.bytesWritten;
}

// ---------------------------------------------------------------- answers

/** An answer as JSON; never cached (it is the project as it is now). */
export function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const text = JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(text), 'Cache-Control': 'no-store' });
  res.end(text);
}

// ---------------------------------------------------------------- the path rule

/** The real path of `abs`, or undefined where nothing is. */
async function real(abs: string): Promise<string | undefined> {
  try {
    return await realpath(abs);
  } catch (err) {
    if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') return undefined;
    throw err;
  }
}

const inside = (path: string, dir: string): boolean => path === dir || path.startsWith(dir.endsWith(sep) ? dir : dir + sep);

/**
 * `raw` as a project-relative path, checked (the module's header): under one
 * of `dirs` -- the folder itself only where `folder` allows -- and nothing on
 * the way out of them by a symlink. Refused `403` (`422` for no path at all).
 */
export async function checkPath(root: string, raw: unknown, dirs: readonly string[], options: { folder?: boolean } = {}): Promise<string> {
  // Its form and its folder first, as `paths.ts` words it -- the editor's `api.ts` refuses with the same.
  const checked = checkedPath(raw, dirs, options);
  if ('refused' in checked) throw new Refused(checked.status, checked.refused);
  const { path, home } = checked;
  const reals = (await Promise.all(dirs.map((dir) => real(join(root, dir))))).filter((r): r is string => r !== undefined);
  const outside = (abs: string): boolean => !reals.some((r) => inside(abs, r));
  // Its own root's folder not there: nothing on the way can be a link of anyone's. Checked lexically.
  if ((await real(join(root, home))) !== undefined) {
    // The deepest folder of it that exists, by its real path.
    let dir = path === home ? path : path.slice(0, path.lastIndexOf('/'));
    for (;;) {
      const r = await real(join(root, dir));
      if (r !== undefined) {
        if (outside(r)) throw new Refused(403, `${path}: ${dir} leads out of ${home}`);
        break;
      }
      if (dir === home || !dir.includes('/')) break;
      dir = dir.slice(0, dir.lastIndexOf('/'));
    }
  }
  // A final symlink, followed.
  try {
    if ((await lstat(join(root, path))).isSymbolicLink()) {
      const target = await real(join(root, path));
      if (target === undefined || outside(target)) throw new Refused(403, `${path} is a link that leads out of ${home}`);
    }
  } catch (err) {
    if (err instanceof Refused) throw err;
    if (code(err) !== 'ENOENT' && code(err) !== 'ENOTDIR') throw err;
  }
  return path;
}
