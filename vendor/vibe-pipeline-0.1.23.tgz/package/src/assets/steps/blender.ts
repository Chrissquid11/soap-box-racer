/**
 * `blender`: a `.blend` exported as a plain `.glb` by Blender itself, in the
 * background (Docs/assets.md §3). Tested with Blender 5.2.0 (`export.test.ts`,
 * which makes its `.blend` with Blender and skips without it).
 *
 *   blender -b <src> --python-exit-code 1 --python <blender-export.py> -- <job>/plain.glb
 *
 * `--python-exit-code 1` beyond the documented command: without it a script
 * that raises leaves Blender exiting 0 (checked, 5.2.0), and the failure would
 * surface a step later as a missing file instead of Blender's own error.
 *
 * The script is found with `new URL('./blender-export.py', import.meta.url)`:
 * the real file from the CLI and from the bundled Vite config alike, never
 * `process.cwd()`. GLB, modifiers applied, +Y up, no Draco (that is ours).
 * The same `.blend` gives the same bytes (checked).
 *
 * `auto: false`: slow enough to be asked for. A `.blend` saved from Blender is
 * left `stale`, with an Export button, rather than exported on every save.
 */
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { BLENDER, exec } from '../tools.ts';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'blender',
  version: 1,
  where: 'node',
  auto: false,
  needs: [BLENDER],
  npm: [],
  async run(job) {
    const out = join(job.dir, 'plain.glb');
    const script = fileURLToPath(new URL('./blender-export.py', import.meta.url));
    const ran = await exec(job.bin('blender'), ['-b', job.input, '--python-exit-code', '1', '--python', script, '--', out], { cwd: job.dir, signal: job.signal });
    job.log(ran.stdout + ran.stderr);
    return { files: [out], line: 'exported by Blender' };
  },
};
