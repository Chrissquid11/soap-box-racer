/**
 * `pack-gltf`: a `.gltf`, or a `.glb` naming files beside it, made one
 * self-contained `.glb` (Docs/assets.md §3).
 *
 * Read with its parts by glTF-Transform's `NodeIO.read(path)`, which resolves a
 * GLB's external URIs too (read from bytes it would refuse them), and written
 * as one `.glb`. A `.glb` naming nothing is passed on as its bytes: the next
 * step reads the source itself.
 */
import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { glbJson, namesFiles } from '../parts.ts';
import { glbHead } from '../stats/glb.ts';
import { GLTF_NPM, readGltfPath, transformToGlb } from './gltf.ts';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'pack-gltf',
  version: 1,
  where: 'node',
  auto: true,
  needs: [],
  npm: GLTF_NPM,
  async run(job) {
    if (job.ext === 'glb' && !namesFiles(glbJson(await glbHead(job.input)))) return { files: [job.input], line: 'self-contained' };
    const bytes = await transformToGlb(await readGltfPath(job.input));
    const out = join(job.dir, 'packed.glb');
    await writeFile(out, bytes); // write-ok: the job's directory
    return { files: [out], line: `packed with ${job.parts.length} file${job.parts.length === 1 ? '' : 's'}` };
  },
};
