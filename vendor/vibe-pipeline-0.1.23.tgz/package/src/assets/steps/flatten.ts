/**
 * `flatten`: a layered `.psd` or `.xcf` made one flat PNG with ImageMagick
 * (Docs/assets.md §3), which the `image` step then makes WebP.
 *
 *   .psd  magick <src>[0] -strip png:<job>/flat.png
 *         -- frame 0 is Photoshop's own composite when the file has a real one
 *         (Maximize Compatibility, the default; `stats/image.ts` reads the
 *         flag); without one:
 *         magick <src> -delete 0 -background none -layers flatten -strip png:<job>/flat.png
 *         and the line says the layers were flattened, effects may differ.
 *   .xcf  magick <src> -background none -layers flatten -colorspace sRGB -strip png:<job>/flat.png
 *         (a 16-bit XCF would otherwise come out linear).
 *
 * `-strip`: no date chunks, so the same file gives the same bytes.
 *
 * The `.psd` commands are tested on fixtures (`export.test.ts`); the `.xcf` one
 * is not: ImageMagick reads XCF but cannot write one, so there is no fixture to
 * flatten -- a GIMP file of a real project is its first test.
 */
import { join } from 'node:path';
import { psdComposite } from '../stats/image.ts';
import { MAGICK, exec } from '../tools.ts';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'flatten',
  version: 1,
  where: 'node',
  auto: true,
  needs: [MAGICK],
  npm: [],
  async run(job) {
    const out = join(job.dir, 'flat.png');
    const magick = job.bin('magick');
    let line = 'flattened';
    let args: string[];
    if (job.ext === 'psd') {
      if ((await psdComposite(job.input)) !== false) {
        args = [`${job.input}[0]`, '-strip', `png:${out}`];
        line = "Photoshop's composite";
      } else {
        args = [job.input, '-delete', '0', '-background', 'none', '-layers', 'flatten', '-strip', `png:${out}`];
        line = 'no composite in the file: layers flattened, effects may differ';
      }
    } else {
      args = [job.input, '-background', 'none', '-layers', 'flatten', '-colorspace', 'sRGB', '-strip', `png:${out}`];
    }
    const ran = await exec(magick, args, { cwd: job.dir, signal: job.signal });
    job.log(ran.stdout + ran.stderr);
    return { files: [out], line };
  },
};
