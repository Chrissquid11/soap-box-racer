/**
 * `aseprite`: an Aseprite file exported as a packed sheet and its frames
 * (Docs/assets.md §3). Tested with Aseprite 1.3.18 (`export.test.ts`, which
 * makes its `.aseprite` with Aseprite and skips without it): the arguments in
 * this order, `--scale` after the file included, do what they say.
 *
 *   aseprite -b <stem>.aseprite --sheet <stem>.png --data <stem>.json
 *            --format json-hash --sheet-pack --list-tags --shape-padding <padding>
 *            [--trim] [--scale <scale>]
 *
 * Run in the job's directory on a copy named plainly, so the `.json` names
 * `<stem>.png`, not a path on someone's disk: the same file, the same bytes.
 */
import { copyFile } from 'node:fs/promises';
import { join } from 'node:path';
import { ASEPRITE, exec } from '../tools.ts';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'aseprite',
  version: 1,
  where: 'node',
  auto: true,
  needs: [ASEPRITE],
  npm: [],
  async run(job) {
    const input = `${job.stem}.${job.ext}`;
    await copyFile(job.input, join(job.dir, input));
    const sheet = `${job.stem}.png`;
    const data = `${job.stem}.json`;
    const args = ['-b', input, '--sheet', sheet, '--data', data, '--format', 'json-hash', '--sheet-pack', '--list-tags', '--shape-padding', String(job.options.padding)];
    if (job.options.trim === true) args.push('--trim');
    if ((job.options.scale as number) !== 1) args.push('--scale', String(job.options.scale));
    const ran = await exec(job.bin('aseprite'), args, { cwd: job.dir, signal: job.signal });
    job.log(ran.stdout + ran.stderr);
    return { files: [join(job.dir, sheet), join(job.dir, data)], line: 'sheet packed' };
  },
};
