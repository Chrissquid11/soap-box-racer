/**
 * Every step by name (Docs/assets.md §3): what a recipe's `steps` list names.
 * Importing a step loads only Node's own modules; each npm package a step uses
 * is imported inside its `run` (§4), so this table is cheap to load.
 */
import type { StepName } from '../recipes.ts';
import type { StepInfo } from '../status.ts';
import { step as aseprite } from './aseprite.ts';
import { step as blender } from './blender.ts';
import { step as browserToGlb } from './browser-to-glb.ts';
import { step as copy } from './copy.ts';
import { step as draco } from './draco.ts';
import { step as ffmpeg } from './ffmpeg.ts';
import { step as finish } from './finish.ts';
import { step as flatten } from './flatten.ts';
import { step as gladius } from './gladius.ts';
import { step as image } from './image.ts';
import { step as kra } from './kra.ts';
import { step as packGltf } from './pack-gltf.ts';
import type { Step } from './step.ts';
import { step as webpTextures } from './webp-textures.ts';

export const STEPS: Readonly<Record<StepName, Step>> = {
  gladius,
  blender,
  'browser-to-glb': browserToGlb,
  'pack-gltf': packGltf,
  flatten,
  kra,
  finish,
  'webp-textures': webpTextures,
  draco,
  image,
  aseprite,
  ffmpeg,
  copy,
};

export type { Job, Step, StepResult } from './step.ts';

/** What status needs of a step. */
export function stepInfo(name: StepName): StepInfo {
  const step = STEPS[name];
  return {
    name,
    version: step.version,
    where: step.where,
    needs: step.needs.map((need) => (need.require?.what ? { tool: need.tool, what: need.require.what } : { tool: need.tool })),
    npm: step.npm,
  };
}
