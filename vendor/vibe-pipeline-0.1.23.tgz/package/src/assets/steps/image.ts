/**
 * `image`: a picture made the WebP the game loads (Docs/assets.md §3), with
 * sharp: turned upright by its EXIF orientation, resized to `max` on its longer
 * side (lanczos3, never up), each side down to a power of two with `pow2`,
 * written lossy at `quality` or `lossless`, metadata dropped (sharp's default).
 *
 * Fixed settings, so the same picture and options give the same bytes; sharp is
 * pinned by `package-lock.json` and recorded in `built.tools`.
 */
import { join } from 'node:path';
import type { Step } from './step.ts';

/** The largest power of two at most `n`. */
export function floorPow2(n: number): number {
  return n < 1 ? 1 : 2 ** Math.floor(Math.log2(n));
}

/**
 * The size a picture is written at: inside `max` with its aspect kept, never
 * up, then each side down to a power of two if asked.
 */
export function targetSize(width: number, height: number, max: number, pow2: boolean): [number, number] {
  const scale = Math.min(1, max / Math.max(width, height));
  let w = Math.max(1, Math.round(width * scale));
  let h = Math.max(1, Math.round(height * scale));
  if (pow2) {
    w = floorPow2(w);
    h = floorPow2(h);
  }
  return [w, h];
}

export const step: Step = {
  name: 'image',
  version: 1,
  where: 'node',
  auto: true,
  needs: [],
  npm: ['sharp'],
  async run(job) {
    const sharp = (await import('sharp')).default;
    // One sharp instance: its header read for the size, then the same pipeline turned upright and written.
    const image = sharp(job.input);
    const meta = await image.metadata();
    image.rotate();
    const turned = (meta.orientation ?? 1) >= 5;
    const width = (turned ? meta.height : meta.width) ?? 0;
    const height = (turned ? meta.width : meta.height) ?? 0;
    if (!width || !height) throw new Error('image: no size in its header');
    const [w, h] = targetSize(width, height, job.options.max as number, job.options.pow2 as boolean);
    if (w !== width || h !== height) image.resize(w, h, { fit: 'fill', kernel: 'lanczos3' });
    const lossless = job.options.lossless as boolean;
    image.webp(lossless ? { lossless: true } : { quality: job.options.quality as number });
    const out = join(job.dir, `${job.stem}.webp`);
    await image.toFile(out);
    const size = w !== width || h !== height ? `${width}×${height} → ${w}×${h}` : `${w}×${h}`;
    return { files: [out], line: `${size}, ${lossless ? 'lossless' : `q${job.options.quality}`}` };
  },
};
