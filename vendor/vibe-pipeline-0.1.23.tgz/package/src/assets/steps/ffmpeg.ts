/**
 * `ffmpeg`: a sound master made the Ogg Vorbis the game plays (Docs/assets.md §3).
 *
 *   ffmpeg -nostdin -hide_banner -i <src> -map 0:a:0 -map_metadata -1
 *          -fflags +bitexact -flags:a +bitexact [-af <trim>] [-ac 1]
 *          -ar <the source's rate, at most 48000> -c:a libvorbis -q:a <quality> <job>/<stem>.ogg
 *
 * Never the native, experimental `vorbis` encoder: `tools.ts` makes an ffmpeg
 * without `libvorbis` `lacking`, and the source `unmade`, before this runs. The
 * `bitexact` flags and `-map_metadata -1` leave no encoder string and a fixed
 * Ogg serial: the same master, the same bytes.
 *
 * **`mono: 'auto'`.** The channel count comes from `stats/audio.ts`. One channel
 * is mono as it is; more than two are refused under `sfx` and `uiSfx` and mixed
 * to two under `music`; neither is measured. A two-channel source gets one extra
 * pass that measures the side signal -- left minus right -- and is mono when its
 * peak is under `monoBelow` (`c1` does not exist on a mono file, and ffmpeg
 * refuses the filter, which is why only stereo is measured). The same bytes and
 * the same ffmpeg make the same decision.
 *
 * `trim: lead` cuts silence under `trimBelow` from the start; `both` from both
 * ends (reversed, cut, reversed back). Music keeps its pre-delay and its tail.
 */
import { join } from 'node:path';
import type { Options } from '../api-types.ts';
import type { KindName } from '../kinds.ts';
import { audioStats } from '../stats/audio.ts';
import { FFMPEG, exec } from '../tools.ts';
import type { Step } from './step.ts';

/** The measuring pass's filter: the side signal's peak, over the whole file. */
export const SIDE_FILTER = 'pan=mono|c0=c0-c1,astats=metadata=0:measure_perchannel=none:measure_overall=Peak_level';

/** The peak level `astats` printed, in dB; `-Infinity` for silence (identical channels). */
export function peakOf(log: string): number | undefined {
  let last: string | undefined;
  for (const m of log.matchAll(/Peak level dB:\s*(-?inf|[-+]?\d+(?:\.\d+)?)/g)) last = m[1];
  if (last === undefined) return undefined;
  return /inf/.test(last) ? (last.startsWith('-') ? -Infinity : Infinity) : Number(last);
}

/** The side signal of a two-channel file, measured: its peak in dB. */
export async function measureSide(ffmpeg: string, source: string, signal?: AbortSignal): Promise<number> {
  const ran = await exec(ffmpeg, ['-nostdin', '-hide_banner', '-i', source, '-af', SIDE_FILTER, '-f', 'null', '-'], { signal });
  const peak = peakOf(ran.stderr + ran.stdout);
  if (peak === undefined) throw new Error('ffmpeg: no peak level in the measuring pass');
  return peak;
}

/**
 * What to do with the channels: `measure` a stereo source under `auto`; `-ac`
 * 1 or 2 or nothing. Throws for more than two channels where sounds must be
 * mono or stereo.
 */
export function channelPlan(kind: KindName, channels: number, mono: string): { measure: boolean; ac?: 1 | 2 } {
  if (channels > 2) {
    if (kind !== 'music') throw new Error(`${channels} channels: game sounds are mono or stereo`);
    return { measure: false, ac: mono === 'always' ? 1 : 2 };
  }
  if (channels === 1) return { measure: false };
  if (mono === 'always') return { measure: false, ac: 1 };
  if (mono === 'auto') return { measure: true };
  return { measure: false };
}

/** The `-af` for `trim`, or undefined for none. */
export function trimFilter(options: Options): string | undefined {
  const cut = `silenceremove=start_periods=1:start_threshold=${options.trimBelow}dB:start_silence=0.01`;
  if (options.trim === 'lead') return cut;
  if (options.trim === 'both') return `${cut},areverse,${cut},areverse`;
  return undefined;
}

/** The encode's arguments, given what the channel plan decided. */
export function encodeArgs(source: string, out: string, options: Options, rate: number, ac: 1 | 2 | undefined): string[] {
  const args = ['-nostdin', '-hide_banner', '-i', source, '-map', '0:a:0', '-map_metadata', '-1', '-fflags', '+bitexact', '-flags:a', '+bitexact'];
  const trim = trimFilter(options);
  if (trim) args.push('-af', trim);
  if (ac !== undefined) args.push('-ac', String(ac));
  args.push('-ar', String(Math.min(rate, 48000)), '-c:a', 'libvorbis', '-q:a', String(options.quality), out);
  return args;
}

export const step: Step = {
  name: 'ffmpeg',
  version: 1,
  where: 'node',
  auto: true,
  needs: [FFMPEG],
  npm: [],
  async run(job) {
    const ffmpeg = job.bin('ffmpeg');
    const stats = await audioStats(job.input, job.bin);
    if (!stats.channels || !stats.sampleRate) throw new Error(`ffmpeg: cannot read the channels and rate of this ${stats.format}`);
    const plan = channelPlan(job.kind, stats.channels, job.options.mono as string);
    let ac = plan.ac;
    let said = stats.channels === 1 ? 'mono' : ac === 1 ? 'mono' : 'stereo';
    if (plan.measure) {
      const peak = await measureSide(ffmpeg, job.input, job.signal);
      if (peak < (job.options.monoBelow as number)) {
        ac = 1;
        said = `mono (the channels differ by at most ${Number.isFinite(peak) ? `${peak.toFixed(1)} dB` : 'nothing'})`;
      } else said = 'stereo';
    }
    const out = join(job.dir, `${job.stem}.ogg`);
    const ran = await exec(ffmpeg, encodeArgs(job.input, out, job.options, stats.sampleRate, ac), { signal: job.signal });
    job.log(ran.stderr);
    return { files: [out], line: `${said}, q${job.options.quality}` };
  },
};
