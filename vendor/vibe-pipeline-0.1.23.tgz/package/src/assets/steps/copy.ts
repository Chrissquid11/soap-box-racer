/**
 * `copy`: the bytes as they are, and the row's parts beside them (Docs/assets.md
 * §3). What every file already in a shipping format goes through (an `.ogg`, a
 * `.woff2`, a model's own image), and a packer's sprite sheet with its `.json`.
 *
 * Copied into the job's directory like any step's output -- never linked: the
 * export is renamed into place from there, and must not share an inode with
 * the source it came from.
 */
import { copyFile } from 'node:fs/promises';
import { basename, join } from 'node:path';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'copy',
  version: 1,
  where: 'node',
  auto: true,
  needs: [],
  npm: [],
  async run(job) {
    const main = join(job.dir, `${job.stem}.${job.ext}`);
    await copyFile(job.input, main);
    const files = [main];
    for (const part of job.parts) {
      const beside = join(job.dir, basename(part));
      await copyFile(part, beside);
      files.push(beside);
    }
    return { files, line: files.length > 1 ? `copied with ${files.slice(1).map((f) => basename(f)).join(', ')}` : 'copied' };
  },
};
