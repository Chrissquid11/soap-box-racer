/**
 * `webp-textures`: a model's embedded textures made WebP, no larger than
 * `textureMax` (Docs/assets.md §3) -- the CLI's `gltf-transform webp`:
 *
 *   textureCompress({ encoder: sharp, targetFormat: 'webp',
 *                     quality: textureQuality, resize: [textureMax, textureMax] })
 *
 * then `unpartition()`. A model with no textures has nothing to do, and is
 * passed on as its bytes (checked: the crate's export is the same either way).
 * `textureQuality` defaults to 80, sharp's own default, which the CLI used.
 */
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { GLTF_NPM, readGlb, transformToGlb } from './gltf.ts';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'webp-textures',
  version: 1,
  where: 'node',
  auto: true,
  needs: [],
  npm: [...GLTF_NPM, '@gltf-transform/functions', 'sharp'],
  async run(job) {
    const document = await readGlb(await readFile(job.input));
    const textures = document.getRoot().listTextures().length;
    if (textures === 0) return { files: [job.input], line: 'no textures' };
    const [{ textureCompress }, sharp] = await Promise.all([import('@gltf-transform/functions'), import('sharp')]);
    const max = job.options.textureMax as number;
    const bytes = await transformToGlb(
      document,
      textureCompress({ encoder: sharp.default, targetFormat: 'webp', quality: job.options.textureQuality as number, resize: [max, max] }),
    );
    const out = join(job.dir, 'webp.glb');
    await writeFile(out, bytes); // write-ok: the job's directory
    return { files: [out], line: `${textures} texture${textures === 1 ? '' : 's'} to WebP` };
  },
};
