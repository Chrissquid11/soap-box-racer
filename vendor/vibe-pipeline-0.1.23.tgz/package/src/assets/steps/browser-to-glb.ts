/**
 * `browser-to-glb`: an `.fbx`, `.obj`, `.dae` or `.stl` turned into a plain
 * `.glb` by a game tab -- three's loader for the format, then `GLTFExporter`
 * (Docs/assets.md §3, §8) -- the one conversion only a browser can do here.
 *
 * The step itself only asks: `job.browser` is the runner's way to a tab (§4,
 * Jobs: the job is parked while it waits, and resumes with the file the tab
 * sent). The export writes that file beside the source as `_<stem>.glb`,
 * committed, so the CLI and CI carry on from it. In the CLI there is no tab, and
 * a source that needs one is `unmade` before it gets here.
 */
import type { Step } from './step.ts';

export const step: Step = {
  name: 'browser-to-glb',
  version: 1,
  where: 'browser',
  auto: true,
  needs: [],
  npm: ['three'],
  async run(job) {
    if (!job.browser) throw new Error('needs a game tab open on this machine');
    const file = await job.browser(job);
    return { files: [file], line: 'converted in the browser' };
  },
};
