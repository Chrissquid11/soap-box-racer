/**
 * `draco`: geometry compressed with Draco (Docs/assets.md §3) -- the CLI's
 * `gltf-transform draco` with glTF-Transform's defaults written out, so a new
 * default upstream never changes an export unasked: edgebreaker, encode and
 * decode speed 5, quantisation 14/10/8/12/12 (position, normal, colour,
 * texcoord, generic), volume `mesh`. Then `unpartition()`.
 *
 * Skipped with `draco: false`: bigger, and decodes without the Draco chunk.
 */
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { GLTF_NPM, readGlb, transformToGlb } from './gltf.ts';
import type { Step } from './step.ts';

export const DRACO = {
  method: 'edgebreaker',
  encodeSpeed: 5,
  decodeSpeed: 5,
  quantizePosition: 14,
  quantizeNormal: 10,
  quantizeColor: 8,
  quantizeTexcoord: 12,
  quantizeGeneric: 12,
  quantizationVolume: 'mesh',
} as const;

export const step: Step = {
  name: 'draco',
  version: 1,
  where: 'node',
  auto: true,
  needs: [],
  npm: [...GLTF_NPM, '@gltf-transform/functions'],
  async run(job) {
    if (job.options.draco === false) return { files: [job.input], line: 'Draco off' };
    const { draco } = await import('@gltf-transform/functions');
    const bytes = await transformToGlb(await readGlb(await readFile(job.input)), draco(DRACO));
    const out = join(job.dir, 'draco.glb');
    await writeFile(out, bytes); // write-ok: the job's directory
    return { files: [out], line: 'Draco' };
  },
};
