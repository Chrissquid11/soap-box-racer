# The `blender` step's script (packages/pipeline/src/assets/steps/blender.ts; Docs/assets.md §3).
# Tested with Blender 5.2.0 (packages/pipeline/src/assets/export.test.ts).
#
#   blender -b <src.blend> --python-exit-code 1 --python blender-export.py -- <out.glb>
#
# A plain GLB: modifiers applied, +Y up, images embedded, no Draco -- the
# pipeline's own `finish`, `webp-textures` and `draco` steps come after.
import sys

import bpy

out = sys.argv[sys.argv.index("--") + 1]
bpy.ops.export_scene.gltf(
    filepath=out,
    export_format="GLB",
    export_apply=True,
    export_yup=True,
    export_draco_mesh_compression_enable=False,
)
