/**
 * The shape every step has (Docs/assets.md §3, "Steps"), and what a step is
 * handed: a `Job`.
 *
 * A step reads `job.input` (the source, or the last step's file) and the
 * source's `job.parts`, writes its own files into `job.dir` -- the job's own
 * directory under `.cache/assets/jobs/`, so a failure leaves nothing behind and
 * the watcher never sees half a file -- and returns them, with one line said
 * about what it did. A step with nothing to do returns its input as it is.
 *
 * `version` is part of the recipe hash: bump it when a change to the step's file
 * changes what it writes, and every export it made goes stale on purpose.
 * `needs` are the external programs it runs (`tools.ts` finds them); `npm` the
 * packages it imports -- inside `run`, never at the top of the file, so a
 * `keys` run or a release build never loads them (§4) -- whose versions go
 * into `built.tools`.
 */
import type { Options, ToolLook } from '../api-types.ts';
import type { KindName } from '../kinds.ts';
import type { StepName } from '../recipes.ts';
import type { Need } from '../tools.ts';

export interface Job {
  /** The job's id: its directory's name. */
  id: string;
  /** The project root, absolute. */
  root: string;
  /** The source, relative to the root. */
  source: string;
  /** This step's input, absolute: the source, its intermediate, or the last step's file. */
  input: string;
  /** The source's parts, absolute. */
  parts: string[];
  /** The job's directory, absolute: every file a step writes goes here. */
  dir: string;
  stem: string;
  /** The source's extension, lowercase. */
  ext: string;
  kind: KindName;
  options: Options;
  tools: ReadonlyMap<string, ToolLook>;
  /** The path to spawn for a tool a step needs (found, or the run was refused up front). */
  bin(tool: string): string;
  /** Output kept for the runs cache: shown under the file when the export fails. */
  log(text: string): void;
  /** A browser step's file: asks a game tab, resolves with the `.glb` it sent (§4, Jobs). */
  browser?: (job: Job) => Promise<string>;
  /** Aborted when the job is dropped (its source deleted): a step hands it to the program it runs, which is stopped. */
  signal?: AbortSignal;
}

export interface StepResult {
  /** The files written, absolute: the first is the next step's input. */
  files: string[];
  /** One line said about what it did. */
  line?: string;
  /**
   * What a person should read of it -- hidden surfaces removed, animation samples
   * dropped, a merge not made (Docs/modeler.md M41, M42): with the job's `done`
   * and in the runs cache, the Model tab's to say.
   */
  notes?: string[];
}

export interface Step {
  name: StepName;
  /** Bumped when this file changes what it writes: part of the recipe hash. */
  version: number;
  where: 'node' | 'browser';
  /** False: never run by a watch event, only when asked (Export, import, the CLI). */
  auto: boolean;
  needs: readonly Need[];
  /** npm packages it imports, for `built.tools`. */
  npm: readonly string[];
  run(job: Job): Promise<StepResult>;
}
