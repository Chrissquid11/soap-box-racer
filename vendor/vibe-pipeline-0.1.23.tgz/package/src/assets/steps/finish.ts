/**
 * `finish`: a plain `.glb` made to look the way every model here looks, before
 * its textures and Draco (Docs/assets.md §3). Was `scripts/glb-finish.mjs`; now
 * `finish(bytes, { angle, keepNormals, smoothColours })`, a function, and the
 * step around it.
 *
 * 1. **Smooth-shades it**: faces meeting at a gentle angle share a normal,
 *    faces meeting at a real corner keep their own. Not with `keepNormals`: a
 *    model imported with its own normals -- an artist's hard and soft edges --
 *    keeps them.
 * 2. **With `smoothColours`, blends the vertex colour too**: every corner of a
 *    smooth surface at a point takes that surface's angle-weighted average
 *    colour, so a model painted a face at a time -- a boulder -- shades from tone
 *    to tone instead of showing each triangle as a patch. Blended only within a
 *    smoothing group, so a real corner keeps a crisp colour border.
 * 3. **Drops materials nothing draws with.** Gladius writes every material a
 *    script registers, used or not, and `merge` registers one of its own.
 *
 * **Why not Gladius's own `smooth_normals`.** Its `angle` is not the angle
 * between two faces: an 8-sided cylinder smoothed at 50 comes out with every
 * side normal tilted 35 degrees up into its cap, and at 60 the caps melt into
 * the sides -- while its sides, 45 degrees apart, never join below 55. There is
 * no setting that smooths a curve and keeps a rim (2026-09-26).
 *
 * **What it does.** Faces that share an edge and meet at under `angle` degrees
 * are one smooth surface; at every point, each smooth surface there gets one
 * angle-weighted normal. A cylinder's sides are one smooth curve; its caps and a
 * box's edges, at 90, stay crisp; two faces back to back never mix. The same
 * rule as a modelling package's auto-smooth.
 *
 * **Nothing but the normals changes** (and the colours, if asked). Vertices are
 * matched by position, not index, and none is added, merged or moved -- so a
 * skinned mesh keeps every joint and weight it had. Only float NORMAL and
 * COLOR_0 data in an uncompressed GLB is touched: a Draco-compressed input is
 * decoded first (glTF-Transform), and nothing else about the file changes, byte
 * for byte -- the crate's committed export is the proof (§13).
 */
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { glbJson, type GltfJson } from '../parts.ts';
import { GLTF_NPM, readGlb, transformToGlb } from './gltf.ts';
import type { Step } from './step.ts';

export interface FinishOptions {
  /** Degrees: faces meeting at under this are one smooth surface. */
  angle: number;
  keepNormals: boolean;
  smoothColours: boolean;
}

const GLB_MAGIC = 0x46546c67;
const SIZE: Record<string, number> = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 };
const BYTES: Record<number, number> = { 5121: 1, 5123: 2, 5125: 4, 5126: 4 };

type Json = GltfJson & {
  materials?: unknown[];
  bufferViews?: Array<{ buffer?: number; byteOffset?: number; byteLength?: number; byteStride?: number }>;
  accessors?: Array<{ count: number; type: string; componentType: number; bufferView?: number; byteOffset?: number }>;
};

interface Accessor {
  count: number;
  size: number;
  float: boolean;
  get(i: number, c: number): number;
  set(i: number, c: number, v: number): void;
}

/**
 * The finished `.glb`: normals smoothed at `angle` (or kept), colours smoothed
 * if asked, unused materials dropped. `bytes` is not changed; the answer is a
 * new array, and one line said about what was done.
 */
export function finish(bytes: Uint8Array, options: FinishOptions): { bytes: Uint8Array; line: string } {
  const out = new Uint8Array(bytes);
  const head = new DataView(out.buffer, out.byteOffset, out.byteLength);
  if (out.length < 20 || head.getUint32(0, true) !== GLB_MAGIC) throw new Error('finish: not a GLB');
  const jsonLength = head.getUint32(12, true);
  const json = glbJson(out) as Json;
  const binStart = 20 + jsonLength + 8;
  const binLength = out.length >= binStart ? head.getUint32(20 + jsonLength, true) : 0;
  // A model with nothing in it (a new script, Docs/modeler.md M38) has no BIN chunk at all: an empty view, nothing to read.
  const view = out.length >= binStart ? new DataView(out.buffer, out.byteOffset + binStart, binLength) : new DataView(new ArrayBuffer(0));
  const { angle, keepNormals, smoothColours } = options;

  /** An accessor's elements as get/set by index and component. Float only for writing. */
  const accessor = (index: number): Accessor => {
    const a = json.accessors![index]!;
    const bv = json.bufferViews![a.bufferView!]!;
    if ((bv.buffer ?? 0) !== 0) throw new Error('finish: only the GLB buffer is supported');
    const size = SIZE[a.type]!;
    const width = BYTES[a.componentType]!;
    const stride = bv.byteStride ?? size * width;
    const base = (bv.byteOffset ?? 0) + (a.byteOffset ?? 0);
    const read: (o: number) => number =
      a.componentType === 5121
        ? (o) => view.getUint8(o)
        : a.componentType === 5123
          ? (o) => view.getUint16(o, true)
          : a.componentType === 5125
            ? (o) => view.getUint32(o, true)
            : (o) => view.getFloat32(o, true);
    return {
      count: a.count,
      size,
      float: a.componentType === 5126,
      get: (i, c) => read(base + i * stride + c * width),
      set: (i, c, v) => view.setFloat32(base + i * stride + c * 4, v, true),
    };
  };

  const cos = Math.cos((angle * Math.PI) / 180);
  let primitives = 0;
  let corners = 0;
  let coloured = 0;
  for (const mesh of json.meshes ?? []) {
    for (const primitive of mesh.primitives) {
      const colours = smoothColours && primitive.attributes.COLOR_0 !== undefined;
      if ((keepNormals && !colours) || (primitive.mode ?? 4) !== 4 || primitive.attributes.NORMAL === undefined) continue;
      if (primitive.extensions?.KHR_draco_mesh_compression) throw new Error('finish: Draco-compressed; decode before finishing');
      const P = accessor(primitive.attributes.POSITION!);
      const N = accessor(primitive.attributes.NORMAL);
      if (!P.float || !N.float) throw new Error('finish: positions and normals must be float');
      const C = colours ? accessor(primitive.attributes.COLOR_0!) : null;
      if (C && !C.float) throw new Error('finish: vertex colours must be float to smooth');
      const channels = C ? C.size : 0;
      const index = primitive.indices !== undefined ? accessor(primitive.indices) : null;
      const tris = (index ? index.count : P.count) / 3;
      const corner = (t: number, k: number): number => (index ? index.get(t * 3 + k, 0) : t * 3 + k);

      // Every triangle's unit normal, and the angle at each of its corners.
      const face = new Float64Array(tris * 3);
      const weight = new Float64Array(tris * 3);
      const p = (i: number): [number, number, number] => [P.get(i, 0), P.get(i, 1), P.get(i, 2)];
      for (let t = 0; t < tris; t++) {
        const [a, b, c] = [p(corner(t, 0)), p(corner(t, 1)), p(corner(t, 2))];
        const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]] as const;
        const ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]] as const;
        const n = [ab[1] * ac[2] - ab[2] * ac[1], ab[2] * ac[0] - ab[0] * ac[2], ab[0] * ac[1] - ab[1] * ac[0]] as const;
        const length = Math.hypot(n[0], n[1], n[2]);
        if (length < 1e-18) continue; // degenerate: it lends no direction to anyone
        face.set([n[0] / length, n[1] / length, n[2] / length], t * 3);
        const corners3 = [a, b, c];
        for (let k = 0; k < 3; k++) {
          const o = corners3[k]!;
          const u = corners3[(k + 1) % 3]!;
          const v = corners3[(k + 2) % 3]!;
          const du = [u[0] - o[0], u[1] - o[1], u[2] - o[2]];
          const dv = [v[0] - o[0], v[1] - o[1], v[2] - o[2]];
          const d = (du[0]! * dv[0]! + du[1]! * dv[1]! + du[2]! * dv[2]!) / (Math.hypot(...du) * Math.hypot(...dv) || 1);
          weight[t * 3 + k] = Math.acos(Math.min(1, Math.max(-1, d)));
        }
      }

      // Where each corner is in space, whatever its vertex index: faces meet by
      // position, since a colour border or a flat export splits the vertices.
      const key = (i: number): string => `${Math.round(P.get(i, 0) * 1e6)},${Math.round(P.get(i, 1) * 1e6)},${Math.round(P.get(i, 2) * 1e6)}`;
      const pos: string[] = new Array<string>(tris * 3);
      for (let t = 0; t < tris; t++) for (let k = 0; k < 3; k++) pos[t * 3 + k] = key(corner(t, k));
      // Every edge by its two ends, and the faces along it.
      const edgeKey = (a: string, b: string): string => (a < b ? `${a}|${b}` : `${b}|${a}`);
      const edges = new Map<string, number[]>();
      for (let t = 0; t < tris; t++) {
        for (let k = 0; k < 3; k++) {
          const e = edgeKey(pos[t * 3 + k]!, pos[t * 3 + ((k + 1) % 3)]!);
          (edges.get(e) ?? edges.set(e, []).get(e)!).push(t);
        }
      }
      const soft = (a: number, b: number): boolean => face[a * 3]! * face[b * 3]! + face[a * 3 + 1]! * face[b * 3 + 1]! + face[a * 3 + 2]! * face[b * 3 + 2]! >= cos;

      // Round each point, the faces there fall into smoothing groups: two are in one
      // group when they share an edge from this point and meet at under the angle.
      // A corner's normal is its group's, angle-weighted -- so every corner of a group
      // gets exactly the same one, and a hard edge is hard all the way along.
      const around = new Map<string, number[]>();
      for (let c = 0; c < tris * 3; c++) (around.get(pos[c]!) ?? around.set(pos[c]!, []).get(pos[c]!)!).push(c);
      const normalOf = new Float64Array(tris * 9);
      const colourOf = new Float64Array(tris * 3 * channels);
      for (const [here, list] of around) {
        const parent = new Map<number, number>(list.map((c) => [Math.floor(c / 3), Math.floor(c / 3)]));
        const find = (t: number): number => {
          while (parent.get(t) !== t) {
            parent.set(t, parent.get(parent.get(t)!)!);
            t = parent.get(t)!;
          }
          return t;
        };
        for (const c of list) {
          const t = Math.floor(c / 3);
          const k = c % 3;
          for (const other of [pos[t * 3 + ((k + 1) % 3)]!, pos[t * 3 + ((k + 2) % 3)]!]) {
            for (const u of edges.get(edgeKey(here, other)) ?? []) {
              if (u !== t && parent.has(u) && soft(t, u)) parent.set(find(t), find(u));
            }
          }
        }
        const sums = new Map<number, [number, number, number]>();
        for (const c of list) {
          const t = Math.floor(c / 3);
          const g = find(t);
          const sum = sums.get(g) ?? sums.set(g, [0, 0, 0]).get(g)!;
          for (let x = 0; x < 3; x++) sum[x as 0 | 1 | 2] += face[t * 3 + x]! * weight[c]!;
        }
        for (const c of list) {
          const sum = sums.get(find(Math.floor(c / 3)))!;
          const l = Math.hypot(sum[0], sum[1], sum[2]);
          if (l > 1e-12) for (let x = 0; x < 3; x++) normalOf[c * 3 + x] = sum[x as 0 | 1 | 2] / l;
        }
        if (C) {
          // The same groups and the same weights: each group's colour is its corners' average.
          const paints = new Map<number, Float64Array>();
          for (const c of list) {
            const g = find(Math.floor(c / 3));
            const paint = paints.get(g) ?? paints.set(g, new Float64Array(channels + 1)).get(g)!;
            const w = weight[c] || 1e-9;
            const i = corner(Math.floor(c / 3), c % 3);
            for (let x = 0; x < channels; x++) paint[x] = paint[x]! + C.get(i, x) * w;
            paint[channels] = paint[channels]! + w;
          }
          for (const c of list) {
            const paint = paints.get(find(Math.floor(c / 3)))!;
            for (let x = 0; x < channels; x++) colourOf[c * channels + x] = paint[x]! / paint[channels]!;
          }
        }
      }

      // Onto the vertices. A vertex the export shared between two groups -- across
      // a crease it smoothed over -- cannot be split here, so it takes its first.
      const done = new Uint8Array(P.count);
      for (let c = 0; c < tris * 3; c++) {
        const i = corner(Math.floor(c / 3), c % 3);
        if (done[i]) continue;
        done[i] = 1;
        if (C) {
          for (let x = 0; x < channels; x++) C.set(i, x, colourOf[c * channels + x]!);
          coloured++;
        }
        if (keepNormals) continue;
        const n = [normalOf[c * 3]!, normalOf[c * 3 + 1]!, normalOf[c * 3 + 2]!];
        if (n[0] === 0 && n[1] === 0 && n[2] === 0) continue;
        for (let x = 0; x < 3; x++) N.set(i, x, n[x]!);
        corners++;
      }
      primitives++;
    }
  }

  // Materials nothing draws with, dropped and the rest renumbered.
  const used = new Set<number>();
  for (const mesh of json.meshes ?? []) for (const primitive of mesh.primitives) if (primitive.material !== undefined) used.add(primitive.material);
  const kept = (json.materials ?? []).map((_, i) => i).filter((i) => used.has(i));
  const dropped = (json.materials ?? []).length - kept.length;
  let result = out;
  if (dropped > 0) {
    const renumber = new Map(kept.map((old, i) => [old, i]));
    json.materials = kept.map((i) => json.materials![i]);
    for (const mesh of json.meshes ?? []) for (const primitive of mesh.primitives) if (primitive.material !== undefined) primitive.material = renumber.get(primitive.material)!;
    // A new JSON chunk, padded with spaces to four bytes; the binary chunk as it was.
    let text = new TextEncoder().encode(JSON.stringify(json));
    if (text.length % 4) {
      const padded = new Uint8Array(text.length + 4 - (text.length % 4)).fill(0x20);
      padded.set(text);
      text = padded;
    }
    const binChunk = out.subarray(20 + jsonLength);
    result = new Uint8Array(20 + text.length + binChunk.length);
    const header = new DataView(result.buffer);
    header.setUint32(0, GLB_MAGIC, true);
    header.setUint32(4, 2, true);
    header.setUint32(8, 20 + text.length + binChunk.length, true);
    header.setUint32(12, text.length, true);
    header.setUint32(16, 0x4e4f534a, true);
    result.set(text, 20);
    result.set(binChunk, 20 + text.length);
  }

  const line =
    `${keepNormals ? 'normals kept' : `normals smoothed at ${angle} degrees`} (${primitives} primitive${primitives === 1 ? '' : 's'}, ${corners} vertices)` +
    `${coloured ? `, colours smoothed (${coloured} vertices)` : ''}${dropped ? `, ${dropped} unused material${dropped === 1 ? '' : 's'} dropped` : ''}`;
  return { bytes: result, line };
}

/** Does this `.glb` carry Draco-compressed geometry? */
function isDraco(bytes: Uint8Array): boolean {
  try {
    return (glbJson(bytes).extensionsUsed ?? []).includes('KHR_draco_mesh_compression');
  } catch {
    return false;
  }
}

export const step: Step = {
  name: 'finish',
  version: 1,
  where: 'node',
  auto: true,
  needs: [],
  npm: GLTF_NPM,
  async run(job) {
    let bytes: Uint8Array = await readFile(job.input);
    // A Draco input is decoded first: the finish reads plain float attributes.
    if (isDraco(bytes)) bytes = await transformToGlb(await readGlb(bytes));
    const { bytes: finished, line } = finish(bytes, {
      angle: job.options.angle as number,
      keepNormals: job.options.keepNormals as boolean,
      smoothColours: job.options.smoothColours as boolean,
    });
    const file = join(job.dir, 'finished.glb');
    await writeFile(file, finished); // write-ok: the job's directory
    return { files: [file], line };
  },
};
