/// <reference path="../draco3dgltf.d.ts" preserve="true" />
/**
 * glTF-Transform as the glTF steps use it (Docs/assets.md §3): one `NodeIO`
 * set up as the glTF-Transform CLI sets up its own -- every extension, the
 * Draco encoder and decoder -- and read and write as its `Session` does: a
 * Draco- or meshopt-compressed input decoded on reading (further compression
 * would be lossy twice), `unpartition()` before writing a `.glb`.
 *
 * The steps hand each other **bytes, not a live document**: read, transform,
 * write, exactly the CLI calls `export-model.sh` made, so an export can be
 * checked byte for byte against one the CLI wrote (§13). One shared document is
 * an optimisation for later, held to the same test.
 *
 * Every package is imported inside a function (§4, "Nothing heavy at the top"):
 * a `keys` run and a release build never load glTF-Transform or Draco.
 */
import type { Document, NodeIO, Transform } from '@gltf-transform/core';

let io: Promise<NodeIO> | undefined;

/** The one `NodeIO`, made on first use. One that failed to be made is tried again next time, not kept. */
export function gltfIO(): Promise<NodeIO> {
  io ??= (async () => {
    const [{ NodeIO }, { ALL_EXTENSIONS }, draco3d] = await Promise.all([
      import('@gltf-transform/core'),
      import('@gltf-transform/extensions'),
      import('draco3dgltf'),
    ]);
    const [decoder, encoder] = await Promise.all([draco3d.default.createDecoderModule(), draco3d.default.createEncoderModule()]);
    return new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({ 'draco3d.decoder': decoder, 'draco3d.encoder': encoder });
  })().catch((err: unknown) => {
    io = undefined;
    throw err;
  });
  return io;
}

/** The CLI's `Session`: lossy compression on the input is decoded, not kept. */
function decodeCompression(document: Document): void {
  for (const name of ['KHR_draco_mesh_compression', 'EXT_meshopt_compression']) {
    const extension = document
      .getRoot()
      .listExtensionsUsed()
      .find((e) => e.extensionName === name);
    if (extension) extension.dispose();
  }
}

/** A document from a `.glb`'s bytes, compression decoded. */
export async function readGlb(bytes: Uint8Array): Promise<Document> {
  const document = await (await gltfIO()).readBinary(bytes);
  decodeCompression(document);
  return document;
}

/** A document from a file by path: a `.gltf` or a `.glb` with the files it names beside it resolved. */
export async function readGltfPath(path: string): Promise<Document> {
  const document = await (await gltfIO()).read(path);
  decodeCompression(document);
  return document;
}

/** The transforms run, then `unpartition()`, then the `.glb`'s bytes. */
export async function transformToGlb(document: Document, ...transforms: Transform[]): Promise<Uint8Array> {
  const { unpartition } = await import('@gltf-transform/functions');
  await document.transform(...transforms, unpartition());
  return (await gltfIO()).writeBinary(document);
}

/** The glTF steps' npm packages, for `built.tools`. */
export const GLTF_NPM = ['@gltf-transform/core', 'draco3dgltf'] as const;
