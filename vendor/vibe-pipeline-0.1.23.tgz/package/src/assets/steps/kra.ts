/**
 * `kra`: a Krita file's own composite, `mergedimage.png`, read out of the
 * `.kra` -- a zip -- by `../zip.ts` (Docs/assets.md §3). No tool needed; the
 * `image` step makes the WebP from it.
 */
import { writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { readZipEntry } from '../zip.ts';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'kra',
  version: 1,
  where: 'node',
  auto: true,
  needs: [],
  npm: [],
  async run(job) {
    const png = await readZipEntry(job.input, 'mergedimage.png');
    const out = join(job.dir, 'flat.png');
    await writeFile(out, png); // write-ok: the job's directory
    return { files: [out], line: "Krita's merged image" };
  },
};
