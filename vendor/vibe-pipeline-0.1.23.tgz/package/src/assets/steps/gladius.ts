/**
 * `gladius`: a Gladius script built into a plain `.glb` (Docs/assets.md §3).
 *
 *   gladius run --textures embedded --optimise-anim <anim> [--merge <merge>]
 *               [--cull-hidden --cull-method <m> [its knob]]
 *               [--param k=v]... --out <job>/plain.glb <src | .src.clean.lua>
 *
 * Both `--textures` and `--optimise-anim` are always passed, so the output never
 * depends on Gladius's own defaults (`external`, 5). Embedded, because the plain
 * build lives in the job's directory, where an `image.uri` would name nothing.
 * Parameters go in sorted by name: the same options, the same command. `clean`
 * runs the script under a wrapper, and a merge Gladius refuses is built again
 * unmerged -- both `gladius-export.ts`'s, which the Model tab's preview shares.
 * The step's line says what the build did: hidden surfaces removed, samples
 * dropped, a merge not made (Docs/modeler.md M41, M42).
 */
import { join } from 'node:path';
import { buildExport } from '../gladius-export.ts';
import { GLADIUS, run } from '../tools.ts';
import type { Step } from './step.ts';

export const step: Step = {
  name: 'gladius',
  version: 1,
  where: 'node',
  auto: true,
  needs: [GLADIUS],
  npm: [],
  async run(job) {
    const out = join(job.dir, 'plain.glb');
    const params = job.options.params as Readonly<Record<string, string>>;
    const built = await buildExport({
      input: job.input,
      out,
      options: job.options,
      params: Object.keys(params).sort().flatMap((name) => ['--param', `${name}=${params[name]}`]),
      run: async (args) => {
        const ran = await run(job.bin('gladius'), args, { cwd: job.root, signal: job.signal });
        if ('error' in ran) throw Object.assign(new Error(ran.error === 'missing' ? ran.message : `gladius: ${ran.message}`), { output: '' });
        return { code: ran.code, text: ran.stdout + ran.stderr };
      },
    });
    if (built.code !== 0) {
      // As `exec` says a failure: its first line of error, the whole output kept for the runs cache -- the script's name in it.
      const output = built.text.trim();
      const first = output.split('\n').find((l) => /error|fail|invalid|cannot|could not/i.test(l)) ?? '';
      throw Object.assign(new Error(`gladius exited ${built.code}: ${first.trim()}`), { output });
    }
    job.log(built.text);
    const wrote = built.text.split('\n').find((l) => l.startsWith('wrote ')) ?? '';
    const summary = /\((.*)\)/.exec(wrote)?.[1];
    return { files: [out], line: summary ? `gladius: ${summary}` : 'gladius', ...(built.notes.length > 0 ? { notes: built.notes } : {}) };
  },
};
