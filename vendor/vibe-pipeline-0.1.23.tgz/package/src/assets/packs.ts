/**
 * Every folder under `packs/` zipped into `public/packs/`, plus an
 * `index.json` (Docs/assets.md §5, "Packs"). Was `scripts/build-packs.mjs`;
 * now async (`fs.promises`, `zlib.deflateRaw`), so the dev server can run it in
 * a worker without stalling, and reading what to carry from `KINDS` (`packExt`
 * and `beside`), never a list of its own.
 *
 *   packs/reef/models/props/coral.glb  ->  public/packs/reef-a3f9c1e2.zip
 *
 * The file name carries a content hash, so a pack URL is immutable: a
 * downloaded pack can be cached forever, and a replacement never served stale.
 * The archive is built deterministically (fixed timestamps, sorted entries), so
 * unchanged content keeps its hash and its cache entries. A file is deflated
 * only when that wins: most game assets are compressed already.
 *
 * Output goes to `public/`, which Vite copies into `dist/` untouched, so packs
 * ride along in the build's upload. To serve them from a CDN instead, upload
 * the same files and point `VITE_PACK_BASE_URL` at them.
 *
 * A ZIP written by hand -- a local header per file, a central directory, a
 * record pointing at it -- rather than a dependency.
 */
import { createHash } from 'node:crypto';
import { mkdir, readFile, readdir, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { crc32, deflateRaw } from 'node:zlib';
import { exists, skipped, walk, writeAtomic } from './fs.ts';
import { KINDS, ROOTS, kindDef, packed, type KindName } from './kinds.ts';
import { scanUids, uidIndex } from './stamp.ts';
import { PACK_UIDS } from '@vibe/engine/uids';
import { isPointer } from './stats/lfs.ts';

const deflate = promisify(deflateRaw);

/** A pack's uids, at the top of its zip: the engine's name for it, which its `assets/uids.ts` reads it by. */
export { PACK_UIDS };

/** Where the zips go, under the project root. */
export const PACKS_OUT = 'public/packs';

/** 1980-01-01, so a rebuild of unchanged content gives an identical archive. */
const DOS_TIME = 0;
const DOS_DATE = 0x0021;

/** General-purpose flag bit 11: the name is UTF-8. Set only where a name is not ASCII, so an ASCII pack's bytes are as they were. */
const UTF8_NAME = 0x0800;

/** A ZIP of `[name, bytes]` pairs, in order: stored or deflated, whichever is smaller. */
export async function zip(files: ReadonlyArray<readonly [string, Uint8Array]>): Promise<Buffer> {
  const local: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const [name, data] of files) {
    const nameBytes = Buffer.from(name, 'utf8');
    // Without it, unzip, Explorer and Python read a name with é in it as CP437; the game reads UTF-8 either way.
    const flags = nameBytes.length === name.length ? 0 : UTF8_NAME;
    const sum = crc32(data);
    const deflated = await deflate(data, { level: 9 });
    const useDeflate = deflated.length < data.length * 0.95;
    const payload = useDeflate ? deflated : Buffer.from(data.buffer, data.byteOffset, data.byteLength);
    const method = useDeflate ? 8 : 0;

    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50, 0);
    header.writeUInt16LE(20, 4); // version needed
    header.writeUInt16LE(flags, 6);
    header.writeUInt16LE(method, 8);
    header.writeUInt16LE(DOS_TIME, 10);
    header.writeUInt16LE(DOS_DATE, 12);
    header.writeUInt32LE(sum, 14);
    header.writeUInt32LE(payload.length, 18);
    header.writeUInt32LE(data.length, 22);
    header.writeUInt16LE(nameBytes.length, 26);
    header.writeUInt16LE(0, 28); // extra length
    local.push(header, nameBytes, payload);

    const entry = Buffer.alloc(46);
    entry.writeUInt32LE(0x02014b50, 0);
    entry.writeUInt16LE(20, 4); // version made by
    entry.writeUInt16LE(20, 6); // version needed
    entry.writeUInt16LE(flags, 8);
    entry.writeUInt16LE(method, 10);
    entry.writeUInt16LE(DOS_TIME, 12);
    entry.writeUInt16LE(DOS_DATE, 14);
    entry.writeUInt32LE(sum, 16);
    entry.writeUInt32LE(payload.length, 20);
    entry.writeUInt32LE(data.length, 24);
    entry.writeUInt16LE(nameBytes.length, 28);
    entry.writeUInt16LE(0, 30); // extra
    entry.writeUInt16LE(0, 32); // comment
    entry.writeUInt16LE(0, 34); // disk
    entry.writeUInt16LE(0, 36); // internal attrs
    entry.writeUInt32LE(0, 38); // external attrs
    entry.writeUInt32LE(offset, 42);
    central.push(entry, nameBytes);
    offset += header.length + nameBytes.length + payload.length;
  }
  const directory = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(directory.length, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, directory, end]);
}

export type PackIndex = Record<string, { file: string; bytes: number }>;

/**
 * Every pack zipped, the index written; archives no pack names any more
 * removed. A zip already there is this one (its name is its hash) and is not
 * rewritten -- unless its size is not the archive's: one cut short (a Ctrl-C
 * mid-write, before writes were atomic) is written again; the index is written
 * only when it changed -- an unconditional write wakes any watcher on
 * `public/`. Both are written whole (`writeAtomic`). **An LFS pointer in a pack
 * throws**, every one named: zipped, it would ship 130 bytes of text and fail
 * only at `Packs.mount` in production.
 */
export async function buildPacks(root: string, log: (line: string) => void = console.log): Promise<PackIndex> {
  const packsDir = join(root, ROOTS.packs.dir);
  const out = join(root, PACKS_OUT);
  const names = (await exists(packsDir))
    ? (await readdir(packsDir, { withFileTypes: true }))
        .filter((e) => e.isDirectory() && !skipped(e.name))
        .map((e) => e.name)
        .sort()
    : [];
  await mkdir(out, { recursive: true });
  const kinds = (Object.keys(KINDS) as KindName[]).filter((k) => kindDef(k).inPacks);
  // Each pack's uids (Docs/asset-ids.md §2): `uids.json` at the top of its zip, its keys without its prefix -- merged under it as it mounts.
  const uids = uidIndex(scanUids(root)).packs;
  const index: PackIndex = {};
  const built: string[] = [];
  const pointers: string[] = [];
  for (const name of names) {
    const files: Array<[string, Uint8Array]> = [];
    for (const kind of kinds) {
      const dir = kindDef(kind).dir;
      const allowed = new Set(packed(kind));
      for (const relative of await walk(join(packsDir, name, dir))) {
        const ext = relative.slice(relative.lastIndexOf('.') + 1).toLowerCase();
        if (!allowed.has(ext)) continue;
        const bytes = await readFile(join(packsDir, name, dir, relative));
        if (isPointer(bytes)) pointers.push(`${ROOTS.packs.dir}/${name}/${dir}/${relative}`);
        files.push([`${dir}/${relative}`, bytes]);
      }
    }
    if (!files.length) {
      log(`[packs] ${name} has no assets in ${kinds.map((k) => kindDef(k).dir).join(', ')} -- skipped.`);
      continue;
    }
    const own = uids.get(name);
    if (own && own.size > 0) files.push([PACK_UIDS, new TextEncoder().encode(`${JSON.stringify(Object.fromEntries(own), null, 1)}\n`)]);
    const archive = await zip(files);
    const hash = createHash('sha256').update(archive).digest('hex').slice(0, 8);
    const file = `${name}-${hash}.zip`;
    if (pointers.length > 0) continue; // throws below, every pointer named
    const there = await stat(join(out, file)).catch(() => undefined);
    if (there?.size !== archive.length) await writeAtomic(join(out, file), archive);
    built.push(file);
    index[name] = { file, bytes: archive.length };
    log(`[packs] ${name}: ${files.length} files, ${(archive.length / 1024).toFixed(0)} kB -> ${file}`);
  }
  if (pointers.length > 0) {
    throw new Error(`[packs] ${pointers.length === 1 ? 'a file is a Git LFS pointer' : `${pointers.length} files are Git LFS pointers`}, not the file -- run git lfs install && git lfs pull: ${pointers.join(', ')}`);
  }
  for (const stale of (await readdir(out)).filter((f) => f.endsWith('.zip') && !built.includes(f))) await rm(join(out, stale));
  const indexFile = join(out, 'index.json');
  const json = JSON.stringify(index, null, 2) + '\n';
  const old = (await exists(indexFile)) ? await readFile(indexFile, 'utf8') : undefined;
  if (old !== json) await writeAtomic(indexFile, json);
  return index;
}
