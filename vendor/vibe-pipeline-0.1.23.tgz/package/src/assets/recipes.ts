/**
 * How a source becomes an export (Docs/assets.md §3): one table, `RECIPES`,
 * keyed `[kind][ext]`, with a `'*'` kind for the rows that are the same
 * everywhere; the option bundles and their schemas; `recipeFor(path)`, which
 * finds a file's row with the folder check first; and `resolveOptions`, which
 * merges the defaults, the folders' `export.json`s and the source's own record.
 *
 * A row says what it writes (`to`, the keyed file first, `same` for a copy),
 * the steps that write it (one file each in `steps/`), its options, and its
 * `deps` (`parts.ts`) when the source names other files. Every option has a
 * schema -- what the tool draws a field from and the API checks an override
 * against.
 *
 * **To change a default for one game**, write `AssetsSource/<folder>/export.json`,
 * never this file, which is the base's.
 *
 * Pure: it imports only the other pure modules, so the browser side shares it.
 */
import type { OptionSchema, OptionValue, Options } from './api-types.ts';
import { KINDS, ROOTS, kindDef, packed, shipped, type KindName } from './kinds.ts';
import { daeParts, fbxParts, gltfParts, glbParts, luaParts, objParts, sheetJson, type Deps } from './parts.ts';
import { baseName, locate, splitName } from './paths.ts';

/** Every step there is: one file each in `steps/`. */
export const STEP_NAMES = [
  'gladius',
  'blender',
  'browser-to-glb',
  'pack-gltf',
  'flatten',
  'kra',
  'finish',
  'webp-textures',
  'draco',
  'image',
  'aseprite',
  'ffmpeg',
  'copy',
] as const;

export type StepName = (typeof STEP_NAMES)[number];

export type { OptionSchema };

/** A bundle of options by name. */
export type Schemas = Readonly<Record<string, OptionSchema>>;

/** What the pipeline does to a source of one extension under one kind. */
export interface Row {
  /** The extensions written: the first is the file with the key, the rest go beside it. `same`: the source's own. */
  readonly to: readonly string[];
  readonly steps: readonly StepName[];
  readonly options?: Schemas;
  /** The files it reads besides the source, found by reading the source (§3, Parts). */
  readonly deps?: Deps;
  /** The first step cannot run on most machines: a person exports `_<stem>.glb` by hand (§3). */
  readonly byHand?: boolean;
}

/** A row that refuses the extension, saying why. */
export interface Refuse {
  readonly refuse: string;
}

export type Recipes = Readonly<Partial<Record<KindName | '*', Readonly<Record<string, Row | Refuse>>>>>;

/** A bundle with some defaults changed. */
export function defaults(bundle: Schemas, changes: Options): Schemas {
  const out: Record<string, OptionSchema> = { ...bundle };
  for (const [name, value] of Object.entries(changes)) {
    const schema = bundle[name];
    if (!schema) throw new Error(`defaults: no option '${name}' in the bundle`);
    out[name] = { ...schema, default: value };
  }
  return out;
}

// ---------------------------------------------------------------- the bundles

const MODEL: Schemas = {
  angle: {
    default: 70,
    type: 'number',
    min: 0,
    max: 180,
    step: 1,
    unit: '°',
    help: 'Faces meeting at under this angle are one smooth surface; sharper corners stay crisp.',
  },
  keepNormals: {
    default: true,
    type: 'boolean',
    help: "Keep the model's own normals -- an artist's hard and soft edges. `angle` is then unused.",
  },
  smoothColours: {
    default: false,
    type: 'boolean',
    help: 'Blend vertex colours across smooth faces too: a model painted a face at a time, like a rock.',
  },
  draco: {
    default: true,
    type: 'boolean',
    help: 'Compress geometry with Draco. Off: bigger, and decodes without the Draco chunk.',
  },
  textureMax: {
    default: 2048,
    type: 'number',
    min: 64,
    max: 8192,
    unit: 'px',
    help: 'Embedded textures larger than this are scaled down, aspect kept.',
  },
  textureQuality: {
    default: 80,
    type: 'number',
    min: 1,
    max: 100,
    help: "WebP quality of embedded textures (sharp's own default, which the old CLI path used).",
  },
};

const ANIM: OptionSchema = {
  default: 5,
  type: 'number',
  min: 0,
  max: 100,
  step: 1,
  unit: '%',
  help: 'Animation samples within this much error are dropped (`gladius --optimise-anim`); 0 keeps every sample.',
};

const MERGE: OptionSchema = {
  default: 'none',
  type: 'enum',
  values: ['none', 'compatible', 'all'],
  help:
    '`gladius --merge`: one draw call per material (`compatible`, lossless), or one for the whole model (`all`); `none` passes no flag. ' +
    'Gladius merges no skinned mesh (its skin would no longer fit) and no textured material: a rigged or textured model is exported unmerged, said on its build.',
};

/**
 * Hidden-surface removal and clean (Docs/modeler.md M41, M42; Vibe3D D48, D105-D107): export choices
 * Gladius makes after the script ran, so the model the script describes and every check stay as they
 * are. `inert`: at its default each does nothing, so it is left out of the recipe hash there -- adding
 * the options made no export stale.
 */
const CULL: Schemas = {
  cull: {
    default: 'none',
    type: 'enum',
    values: ['none', 'unseen', 'unreachable', 'coplanar', 'covered'],
    inert: true,
    help:
      'Remove hidden surfaces (`gladius --cull-hidden`): `unseen`, what no camera outside the model can see -- a prop, a distant building, never a room walked into; ' +
      '`unreachable`, what air poured in from outside cannot reach -- a room a door opens on survives; `coplanar`, a triangle sitting exactly on another (the seam where two solids butt); ' +
      '`covered` (Gladius 0.8.0), the ground a later part covers in the same plane -- a window drawn on its wall -- cut out from under it, so nothing flickers. ' +
      'A skinned mesh keeps every triangle. The build says how many went and which parts vanished.',
  },
  cullViews: {
    when: { option: 'cull', values: ['unseen'] },
    default: 64,
    type: 'number',
    min: 8,
    max: 512,
    step: 1,
    inert: true,
    help: '`unseen` only (`--cull-views`): camera directions spread over a sphere round the model. More find a triangle a few saw.',
  },
  cullResolution: {
    when: { option: 'cull', values: ['unseen'] },
    default: 512,
    type: 'number',
    min: 128,
    max: 4096,
    step: 1,
    unit: 'px',
    inert: true,
    help: '`unseen` only (`--cull-size`): each camera\'s buffer, a side. Finer removes more -- a coarse one lets a hidden triangle keep a pixel -- and takes longer.',
  },
  cullVoxel: {
    when: { option: 'cull', values: ['unreachable'] },
    default: 0,
    type: 'number',
    min: 0,
    max: 10,
    unit: 'm',
    inert: true,
    help: '`unreachable` only (`--cull-voxel`): the narrowest gap air flows through. Too coarse seals a doorway and takes the room behind it. 0: Gladius picks the longest side over 128.',
  },
};

const CLEAN: OptionSchema = {
  default: false,
  type: 'boolean',
  inert: true,
  help:
    '`clean()` on every mesh emitted -- degenerate triangles, duplicates and unused vertices dropped -- the script left as it is (a wrapper round `emit`). ' +
    'A skinned mesh is emitted as it is: clean() would drop its skin.',
};

const PARAMS: OptionSchema = {
  default: {},
  type: 'map',
  help: 'Script parameters (`gladius --param key=value`).',
};

const PICTURE: Schemas = {
  max: { default: 2048, type: 'number', min: 16, max: 8192, unit: 'px', help: 'The longer side at most this; never scaled up.' },
  quality: { default: 90, type: 'number', min: 1, max: 100, help: 'WebP quality, lossy.' },
  lossless: {
    default: false,
    type: 'boolean',
    help: 'Lossless WebP: UI art, anything with hard edges. `quality` is then unused.',
  },
  pow2: {
    default: false,
    type: 'boolean',
    help: 'Each side down to a power of two, for tiling with mipmaps on old GPUs.',
  },
};

const SHEET: Schemas = {
  scale: { default: 1, type: 'number', min: 1, max: 8, step: 1, help: '`--scale`: pixels made bigger in the sheet.' },
  padding: {
    default: 1,
    type: 'number',
    min: 0,
    max: 16,
    step: 1,
    unit: 'px',
    help: '`--shape-padding`: space between frames, so none bleeds into the next.',
  },
  trim: {
    default: false,
    type: 'boolean',
    help: '`--trim`: each frame cropped to its pixels (the `.json` keeps where it sat).',
  },
};

/** The audio bundle, with the defaults that differ between sounds and music. */
function sound(d: { quality: number; mono: 'auto' | 'always' | 'never'; trim: 'none' | 'lead' | 'both' }): Schemas {
  return {
    quality: { default: d.quality, type: 'number', min: -1, max: 10, step: 0.5, help: 'Vorbis quality (`-q:a`).' },
    mono: {
      default: d.mono,
      type: 'enum',
      values: ['auto', 'always', 'never'],
      help: '`auto`: mono when the two channels are the same (the peak of left minus right under `monoBelow`).',
    },
    monoBelow: {
      default: -60,
      type: 'number',
      min: -120,
      max: 0,
      unit: 'dB',
      help: "`auto`'s threshold: the peak of left minus right must be under this.",
    },
    trim: {
      default: d.trim,
      type: 'enum',
      values: ['none', 'lead', 'both'],
      help: 'Silence cut from the start, or from both ends. Music keeps its pre-delay and its tail.',
    },
    trimBelow: { default: -50, type: 'number', min: -90, max: 0, unit: 'dB', help: 'What counts as silence for `trim`.' },
  };
}

// ---------------------------------------------------------------- the table

const MODEL_STEPS = ['finish', 'webp-textures', 'draco'] as const;
const IMAGE: Row = { to: ['webp'], steps: ['image'], options: PICTURE };
const LAYERED: Row = { to: ['webp'], steps: ['flatten', 'image'], options: PICTURE }; // .psd .xcf: magick
const KRITA: Row = { to: ['webp'], steps: ['kra', 'image'], options: PICTURE }; // .kra: its own merged image
const ASEPRITE: Row = { to: ['png', 'json'], steps: ['aseprite'], options: SHEET };
const sheet = (ext: 'png' | 'webp'): Row => ({ to: [ext, 'json'], steps: ['copy'], deps: sheetJson });
const SFX: Row = { to: ['ogg'], steps: ['ffmpeg'], options: sound({ quality: 5, mono: 'auto', trim: 'lead' }) };
const MUSIC: Row = { to: ['ogg'], steps: ['ffmpeg'], options: sound({ quality: 6, mono: 'never', trim: 'none' }) };
const COPY: Row = { to: ['same'], steps: ['copy'] };

export const RECIPES: Recipes = {
  models: {
    lua: {
      to: ['glb'],
      steps: ['gladius', ...MODEL_STEPS],
      options: { ...defaults(MODEL, { keepNormals: false }), anim: ANIM, merge: MERGE, clean: CLEAN, ...CULL, params: PARAMS },
      deps: luaParts,
    },
    blend: { to: ['glb'], steps: ['blender', ...MODEL_STEPS], options: MODEL, byHand: true },
    fbx: { to: ['glb'], steps: ['browser-to-glb', ...MODEL_STEPS], options: MODEL, deps: fbxParts },
    obj: { to: ['glb'], steps: ['browser-to-glb', ...MODEL_STEPS], options: MODEL, deps: objParts },
    dae: { to: ['glb'], steps: ['browser-to-glb', ...MODEL_STEPS], options: MODEL, deps: daeParts },
    stl: { to: ['glb'], steps: ['browser-to-glb', ...MODEL_STEPS], options: defaults(MODEL, { keepNormals: false }) },
    gltf: { to: ['glb'], steps: ['pack-gltf', ...MODEL_STEPS], options: MODEL, deps: gltfParts },
    glb: { to: ['glb'], steps: ['pack-gltf', ...MODEL_STEPS], options: MODEL, deps: glbParts },
  },
  textures: { png: IMAGE, jpg: IMAGE, jpeg: IMAGE, webp: IMAGE, tif: IMAGE, tiff: IMAGE, psd: LAYERED, xcf: LAYERED, kra: KRITA },
  atlases: {
    aseprite: ASEPRITE,
    ase: ASEPRITE,
    png: sheet('png'),
    webp: sheet('webp'),
    json: { refuse: 'an atlas .json is part of the image beside it (fx.png with fx.json)' },
  },
  sfx: { wav: SFX, flac: SFX, aif: SFX, aiff: SFX },
  uiSfx: { wav: SFX, flac: SFX, aif: SFX, aiff: SFX },
  music: { wav: MUSIC, flac: MUSIC, aif: MUSIC, aiff: MUSIC },
  // Already in a shipping format: copied. A row here applies only under a kind that ships the extension.
  '*': {
    png: COPY,
    jpg: COPY,
    jpeg: COPY,
    webp: COPY,
    avif: COPY,
    ktx2: COPY,
    svg: COPY,
    woff2: COPY,
    woff: COPY,
    json: COPY,
    ogg: COPY,
    opus: COPY,
    mp3: COPY,
    m4a: COPY,
  },
};

/** Model sources: owners, imported before the files they name (§5, Importing). The `models` rows' extensions. */
export const MODEL_SOURCE_EXT: readonly string[] = Object.entries(RECIPES.models ?? {})
  .filter(([, row]) => 'to' in row)
  .map(([ext]) => ext);

// ---------------------------------------------------------------- finding a row

export interface Found {
  kind: KindName;
  ext: string;
  row: Row;
  /** A `'*'` row: the file is copied as it is. */
  copy: boolean;
}

export interface NotFound {
  kind?: KindName;
  ext: string;
  /** What a person is told: never just "no recipe". */
  refused: string;
  /** It ships as it is under this kind, but has no source recipe (`.ttf`): import it as delivered. */
  asDelivered?: boolean;
  /**
   * Refused only for want of a recipe -- not another kind's extension, not
   * `reference/`, not a record's name -- or by a row of its kind's own that
   * makes it a part (an atlas's `.json`): an import of it as a source writes it
   * to the Source side as an extra (§5, Importing), and queues nothing. The tool
   * and the server read this flag, not the words.
   */
  extra?: true;
}

export type RecipeAnswer = Found | NotFound;

export function isFound(answer: RecipeAnswer): answer is Found {
  return 'row' in answer;
}

/**
 * The kinds whose folder would take a file of this extension: `source`, as a
 * source (a row of its own, or a `'*'` copy of what it ships); `delivered`, as
 * it is, with no recipe (`.ttf` under fonts, a `.json` level).
 */
export function kindsTaking(ext: string): { source: KindName[]; delivered: KindName[] } {
  const source: KindName[] = [];
  const delivered: KindName[] = [];
  for (const kind of Object.keys(KINDS) as KindName[]) {
    const row = RECIPES[kind]?.[ext];
    if (row && 'refuse' in row) continue; // an atlas's .json: part of its image, never dropped alone
    const star = RECIPES['*']?.[ext];
    if (row || (kindDef(kind).source && star && 'to' in star && shipped(kind).includes(ext))) source.push(kind);
    else if (shipped(kind).includes(ext)) delivered.push(kind);
  }
  return { source, delivered };
}

function sayList(items: readonly string[]): string {
  if (items.length <= 1) return items.join('');
  return `${items.slice(0, -1).join(', ')} or ${items[items.length - 1]}`;
}

/**
 * A source's recipe, from its path: the kind from the folder, then
 * `RECIPES[kind][ext] ?? RECIPES['*'][ext]`. **The folder check comes first**:
 * an extension the kind neither ships nor converts is refused by name ("`.wav`
 * does not belong under models: drop it on audio/sfx, audio/ui or
 * audio/music"), and a `'*'` row applies only where its result ships.
 */
export function recipeFor(path: string): RecipeAnswer {
  const { ext } = splitName(baseName(path));
  const where = locate(path);
  if (where?.reference) return { ext, refused: 'reference/: nothing is made from these' };
  if (!where || !where.kind) {
    const kinds = Object.values(KINDS).map((k) => k.dir);
    return { ext, refused: `not in a kind's folder: put it under ${sayList(kinds)}` };
  }
  const kind = where.kind;
  const def = kindDef(kind);
  const dir = def.dir;
  if (!def.source) return { kind, ext, refused: `${dir}/ has no sources: its .json files are put in src/assets/${dir} as they are` };
  if (where.pack !== undefined && !def.inPacks) {
    return { kind, ext, refused: `a pack carries no ${dir}: they are URLs handed to the UI, and a pack has bytes` };
  }
  const own = RECIPES[kind]?.[ext];
  // Refused as a source of its own, but no other kind's: an atlas's `.json` dropped with its sheet is
  // written to the Source side like an extra, and is a part once the sheet beside it names it (§3, Parts).
  if (own && 'refuse' in own) return { kind, ext, refused: own.refuse, extra: true };
  if (own) return { kind, ext, row: own, copy: false };
  const ships = where.pack !== undefined ? packed(kind) : shipped(kind);
  const star = RECIPES['*']?.[ext];
  if (star && 'to' in star && ships.includes(ext)) return { kind, ext, row: star, copy: true };
  if (ships.includes(ext)) {
    return { kind, ext, refused: `.${ext} has no recipe under ${dir}: make a .${def.ext[0]}, or import this one as delivered`, asDelivered: true };
  }
  const taking = kindsTaking(ext);
  const asSource = taking.source.filter((k) => k !== kind).map((k) => KINDS[k].dir);
  const asIs = taking.delivered.filter((k) => k !== kind).map((k) => KINDS[k].dir);
  if (asSource.length > 0 || asIs.length > 0) {
    const ways = [...(asSource.length > 0 ? [`drop it on ${sayList(asSource)}`] : []), ...(asIs.length > 0 ? [`import it as delivered into ${sayList(asIs)}`] : [])];
    return { kind, ext, refused: `.${ext} does not belong under ${dir}: ${ways.join(', or ')}` };
  }
  return { kind, ext, refused: `no recipe for .${ext} under ${dir}`, extra: true };
}

// ---------------------------------------------------------------- options

/** Why a value does not fit its schema, or undefined when it does. */
export function checkOption(schema: OptionSchema, value: unknown): string | undefined {
  switch (schema.type) {
    case 'number': {
      if (typeof value !== 'number' || !Number.isFinite(value)) return 'a number';
      if (schema.min !== undefined && value < schema.min) return `at least ${schema.min}`;
      if (schema.max !== undefined && value > schema.max) return `at most ${schema.max}`;
      if (schema.step !== undefined) {
        const steps = (value - (schema.min ?? 0)) / schema.step;
        if (Math.abs(steps - Math.round(steps)) > 1e-9) return `in steps of ${schema.step}`;
      }
      return undefined;
    }
    case 'boolean':
      return typeof value === 'boolean' ? undefined : 'true or false';
    case 'enum':
      return typeof value === 'string' && (schema.values ?? []).includes(value) ? undefined : `one of ${(schema.values ?? []).join(', ')}`;
    case 'map': {
      if (typeof value !== 'object' || value === null || Array.isArray(value)) return 'a map of names to strings';
      for (const [k, v] of Object.entries(value)) if (typeof v !== 'string' || k === '') return 'a map of names to strings';
      return undefined;
    }
  }
}

/** Every problem with an override: an unknown option, or a value its schema refuses. */
export function checkOptions(schemas: Schemas, options: Readonly<Record<string, unknown>>): string[] {
  const problems: string[] = [];
  for (const [name, value] of Object.entries(options)) {
    const schema = schemas[name];
    if (!schema) problems.push(`${name}: no such option here`);
    else {
      const why = checkOption(schema, value);
      if (why) problems.push(`${name}: must be ${why}`);
    }
  }
  return problems;
}

/**
 * Every option any row of a kind has: what a folder's `export.json` under it
 * may set. One kind's alone -- its rows' options agree, name for name
 * (`recipes.test.ts` holds it) -- never merged with another's by name: an
 * `.aseprite`'s `trim` is a tick, a sound's a choice of three.
 */
export function kindOptions(kind: KindName): Schemas {
  const out: Record<string, OptionSchema> = {};
  for (const row of Object.values(RECIPES[kind] ?? {})) {
    if ('to' in row) for (const [name, schema] of Object.entries(row.options ?? {})) out[name] ??= schema;
  }
  return out;
}

/**
 * Why a folder above the kinds' folders -- the Source root, `audio/` -- has no
 * options of its own, in the words the tool's Options block and `PUT sidecar`
 * both say: sources of several kinds would read its `export.json`, and their
 * options share names, not meanings (`kindOptions`). The kinds under it with
 * options are named, where to set them instead.
 */
export function aboveKinds(folder: string): string {
  const top = ROOTS.source.dir;
  const inside = folder === top ? '' : folder.slice(top.length + 1);
  const dirs = (Object.keys(KINDS) as KindName[])
    .filter((k) => Object.keys(kindOptions(k)).length > 0)
    .map((k) => KINDS[k].dir)
    .filter((dir) => inside === '' || dir.startsWith(`${inside}/`));
  return `above the kinds' folders: set defaults in a kind's folder${dirs.length > 0 ? ` (${dirs.join(', ')})` : ''} -- their options share names, not meanings`;
}

/** A row's defaults. */
export function defaultOptions(row: Row): Options {
  const out: Options = {};
  for (const [name, schema] of Object.entries(row.options ?? {})) out[name] = schema.default;
  return out;
}

/**
 * A row's options: its defaults, then each layer in order -- the folders'
 * `export.json` from the root to the leaf, then the source's own record -- the
 * nearest winning. An option the row does not have is ignored for it (one
 * folder can set `angle` for `.lua` and `.fbx`, `params` for scripts only); a
 * value its schema refuses is a problem, and the default stands.
 */
export function resolveOptions(row: Row, layers: ReadonlyArray<Readonly<Record<string, unknown>> | undefined>): { options: Options; problems: string[] } {
  const options = defaultOptions(row);
  const problems: string[] = [];
  for (const layer of layers) {
    if (!layer) continue;
    for (const [name, value] of Object.entries(layer)) {
      const schema = row.options?.[name];
      if (!schema) continue;
      const why = checkOption(schema, value);
      if (why) problems.push(`${name}: must be ${why}`);
      else options[name] = value as OptionValue;
    }
  }
  return { options, problems };
}

/** Only what differs from a row's defaults: what a record keeps. */
export function overridesOf(row: Row, options: Options): Options {
  const out: Options = {};
  for (const [name, value] of Object.entries(options)) {
    const schema = row.options?.[name];
    if (schema && canonical(schema.default) !== canonical(value)) out[name] = value;
  }
  return out;
}

// ---------------------------------------------------------------- the recipe's identity

/** JSON with every object's keys sorted: the same value, the same text. */
export function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value !== null && typeof value === 'object') {
    const keys = Object.keys(value).sort();
    return `{${keys.map((k) => `${JSON.stringify(k)}:${canonical((value as Record<string, unknown>)[k])}`).join(',')}}`;
  }
  return JSON.stringify(value) ?? 'null';
}

/**
 * The text a recipe hash is taken of (§2, step 3): the resolved row -- kind,
 * extension, what it writes, its options -- its steps with each one's
 * `version`, and the version of every tool those steps use. `null` is a tool
 * not found here.
 */
export function recipeText(found: Pick<Found, 'kind' | 'ext' | 'row'>, options: Options, stepVersions: ReadonlyArray<readonly [string, number]>, tools: Readonly<Record<string, string | null>>): string {
  return canonical({
    kind: found.kind,
    ext: found.ext,
    to: found.row.to,
    steps: stepVersions.map(([name, version]) => `${name}@${version}`),
    options: hashedOptions(found.row, options),
    tools,
  });
}

/**
 * The options a recipe hash is taken of: all of them, but an `inert` one at its
 * default -- it does nothing there, so an option added since (hidden-surface
 * removal, clean) makes no export of before stale -- and one whose `when` is not
 * met (a cull method's knob while another method, or none, is chosen).
 */
export function hashedOptions(row: Row, options: Options): Options {
  const out: Options = {};
  for (const [name, value] of Object.entries(options)) {
    const schema = row.options?.[name];
    if (schema?.inert && canonical(schema.default) === canonical(value)) continue;
    if (!applies(schema, options)) continue;
    out[name] = value;
  }
  return out;
}

/** Does an option apply with these options: always, or -- `when` -- while its other option is one of its values. */
export function applies(schema: OptionSchema | undefined, options: Readonly<Record<string, unknown>>): boolean {
  if (!schema?.when) return true;
  return schema.when.values.includes(String(options[schema.when.option]));
}
