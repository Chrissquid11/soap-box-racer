/**
 * The committed records (Docs/assets.md §3): `<stem>.export.json` beside every
 * exported source -- the options that differ from the defaults, and what was
 * built -- and a folder's `export.json`, defaults for every source under it.
 * Options merge root -> leaf -> the source's own record, the nearest winning.
 *
 * A record is written by the pipeline after an export -- by `export.ts`, from
 * `recordText` through the job's directory and a rename, after the exports, so
 * a rollback can undo it with them -- **atomically** (the watcher never sees
 * half a file), and always in the same shape: `options`, then `built` with its
 * keys in one order and its maps sorted. **An export of the unchanged writes no
 * record**: when the new `built` is the old one but for `at`, the old one stays,
 * `at` and all, so `npm run export -- --force` on a current tree leaves git
 * clean; when it ran is in `runs.json`. `built.out` holds the sha1 of every
 * file written, by extension: what the shipped files are held to (§3).
 * Keys this pipeline does not know -- a newer one's -- are kept, in `built`
 * and at the top (`more`), not dropped the first time an older checkout writes.
 *
 * A record that does not parse is not an error that stops the world: it is a
 * `problem`, said in the source's status, and its options are the defaults.
 *
 * **In the build** (§3): a record may say `"include": false`, first, at the
 * top -- its source is then out of the build: never exported, never stale, in
 * no conflict. Absent means in; `true` is never written (`withInclude` takes
 * the flag off). The index reads it as it lists the record (`excludedBy`),
 * small as a record is, so a source is known to be out before it is hashed.
 *
 * **The asset's uid and its name** (Docs/asset-ids.md §1, rules 2 and 8): `"uid"`
 * after `include`, the export's, never changed -- every write here keeps it
 * (`identity`) -- and `"as"`, the stem the export ships as, read by the index
 * as it reads `include` (`exportAsIn`). A source's own record,
 * `<name>.export.json`, is its record when it is there (`ownRecordPath`).
 */
import { readFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import type { Built, ExportRecord, Options } from './api-types.ts';
import { code, sortedObject, writeAtomic } from './fs.ts';
import { asProblem, folderChain, folderRecordPath, recordPath } from './paths.ts';
import { resolveOptions, type Found } from './recipes.ts';
import { isUid } from './uid.ts';

/** A record read: what it says, or why it could not be read. Undefined record: there is none. */
export interface RecordRead {
  record?: ExportRecord;
  problem?: string;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** A record's text, checked for its shape. Throws with what is wrong. */
export function parseRecord(text: string): ExportRecord {
  const json = JSON.parse(text) as unknown;
  if (!isObject(json)) throw new Error('not an object');
  const options = json.options ?? {};
  if (!isObject(options)) throw new Error('`options` is not an object');
  if (json.include !== undefined && typeof json.include !== 'boolean') throw new Error('`include` is true or false');
  if (json.uid !== undefined && !isUid(json.uid)) throw new Error('`uid` is uid:// and 13 characters of a-z and 2-7 -- the pipeline writes it: take it out, and `vibe assets` stamps a new one');
  if (json.as !== undefined) {
    const problem = asProblem(json.as);
    if (problem) throw new Error(`\`as\` ${problem}`);
  }
  const record: ExportRecord = {
    ...(json.include === false ? { include: false as const } : {}),
    ...(json.uid !== undefined ? { uid: json.uid } : {}),
    ...(typeof json.as === 'string' ? { as: json.as } : {}),
    options: options as Options,
  };
  if (json.built !== undefined) {
    const b = json.built;
    if (!isObject(b) || typeof b.source !== 'string' || typeof b.recipe !== 'string' || !Array.isArray(b.to) || typeof b.at !== 'string' || !isObject(b.tools)) {
      throw new Error('`built` is not what the pipeline writes');
    }
    if (b.out !== undefined && (!isObject(b.out) || Object.values(b.out).some((v) => typeof v !== 'string'))) throw new Error('`built.out` is not what the pipeline writes');
    record.built = b as unknown as Built;
  }
  const more = Object.entries(json).filter(([k]) => !TOP.has(k));
  if (more.length > 0) record.more = Object.fromEntries(more);
  return record;
}

/** The keys of a record this pipeline writes; any other is a newer one's, kept (`more`). */
const TOP = new Set(['include', 'uid', 'as', 'options', 'built']);
/** The keys of `built` this pipeline writes, in its order; any other is kept after them. */
const BUILT = ['source', 'recipe', 'to', 'at', 'deps', 'tools', 'out'];

/**
 * The text a record is written as: always the same shape -- `include` first when it is out, then the asset's
 * `uid` and the stem it ships `as`, when it has them -- maps sorted, a newline at the end.
 */
export function recordText(record: ExportRecord): string {
  const sorted = (map: Readonly<Record<string, string>>): Record<string, string> => sortedObject(Object.entries(map));
  const out: Record<string, unknown> = {
    ...(record.include === false ? { include: false } : {}),
    ...(record.uid !== undefined ? { uid: record.uid } : {}),
    ...(record.as !== undefined ? { as: record.as } : {}),
    options: record.options,
  };
  if (record.built) {
    const b = record.built;
    out.built = {
      source: b.source,
      recipe: b.recipe,
      to: b.to,
      at: b.at,
      ...(b.deps && Object.keys(b.deps).length > 0 ? { deps: sorted(b.deps) } : {}),
      tools: sorted(b.tools),
      ...(b.out && Object.keys(b.out).length > 0 ? { out: sorted(b.out) } : {}),
      // What a newer pipeline wrote that this one does not know: kept, not dropped on the first re-save.
      ...Object.fromEntries(Object.entries(b).filter(([k]) => !BUILT.includes(k))),
    };
  }
  for (const [k, v] of Object.entries(record.more ?? {})) if (!TOP.has(k)) out[k] = v;
  return JSON.stringify(out, null, 2) + '\n';
}

/**
 * Does a record's text take its source out of the build (`"include": false`)?
 * Read leniently, as the index reads it while listing: a record that does not
 * parse says nothing here -- its source's status says what is wrong with it.
 */
export function excludedBy(text: string): boolean {
  try {
    const json = JSON.parse(text) as unknown;
    return typeof json === 'object' && json !== null && !Array.isArray(json) && (json as { include?: unknown }).include === false;
  } catch {
    return false;
  }
}

/**
 * A record with its source put in the build (`include` true: the flag taken
 * off) or out of it (`"include": false`), the rest as it was. Undefined when
 * what is left says nothing -- no flag, no options, no `built`, no uid, no `as` -- so a record
 * an untick made for a source never exported goes again with the tick.
 */
export function withInclude(record: ExportRecord | undefined, include: boolean): ExportRecord | undefined {
  const options = record?.options ?? {};
  const out: ExportRecord = { ...(include ? {} : { include: false as const }), ...identity(record), options, ...(record?.built ? { built: record.built } : {}), ...(record?.more ? { more: record.more } : {}) };
  return include && Object.keys(options).length === 0 && !out.built && out.uid === undefined && out.as === undefined ? undefined : out;
}

/**
 * What a record says of the asset rather than of its build -- its `uid` and the stem it ships `as` -- to spread
 * into a record written again from parts (`PUT sidecar`, `PUT record`, an export), so none of them drops it.
 */
export function identity(record: Pick<ExportRecord, 'uid' | 'as'> | undefined): Pick<ExportRecord, 'uid' | 'as'> {
  return { ...(record?.uid !== undefined ? { uid: record.uid } : {}), ...(record?.as !== undefined ? { as: record.as } : {}) };
}

/**
 * The stem a record names its export `as`, read leniently from its text, as the index reads `include`: undefined
 * for none, and for a record that does not parse or an `as` that is no stem (its source's status says what is wrong).
 */
export function exportAsIn(text: string): string | undefined {
  try {
    const json = JSON.parse(text) as unknown;
    if (typeof json !== 'object' || json === null || Array.isArray(json)) return undefined;
    const as = (json as { as?: unknown }).as;
    return typeof as === 'string' && asProblem(as) === undefined ? as : undefined;
  } catch {
    return undefined;
  }
}

async function readText(file: string): Promise<string | undefined> {
  try {
    return await readFile(file, 'utf8');
  } catch (err) {
    if (code(err) === 'ENOENT') return undefined;
    throw err;
  }
}

/** A source's record, if it has one: its stem's, or `path` -- its own (`ownRecordPath`), when the index says it has one. */
export async function readRecord(root: string, sourcePath: string, path: string = recordPath(sourcePath)): Promise<RecordRead> {
  const text = await readText(join(root, path));
  if (text === undefined) return {};
  try {
    return { record: parseRecord(text) };
  } catch (err) {
    return { problem: `${path}: ${(err as Error).message}` };
  }
}

/** A folder's `export.json`, if it has one: its `options`. */
export async function readFolderDefaults(root: string, dir: string): Promise<RecordRead> {
  const path = folderRecordPath(dir);
  const text = await readText(join(root, path));
  if (text === undefined) return {};
  try {
    const record = parseRecord(text);
    if (record.built) return { problem: `${path}: a folder's export.json has no \`built\`` };
    return { record };
  } catch (err) {
    return { problem: `${path}: ${(err as Error).message}` };
  }
}

/** A folder's defaults written; empty options remove the file. */
export async function writeFolderDefaults(root: string, dir: string, options: Options): Promise<void> {
  const file = join(root, folderRecordPath(dir));
  if (Object.keys(options).length === 0) await rm(file, { force: true });
  else await writeAtomic(file, recordText({ options }));
}

/** The folders whose `export.json` apply to a source, from `AssetsSource/` down to its own: `paths.ts`', which the tool reads too. */
export { folderChain } from './paths.ts';

/** A source's options worked out: defaults, folders root to leaf, its record. */
export interface SourceOptions {
  options: Options;
  /** Values a schema refused, and records that would not parse. */
  problems: string[];
  record?: ExportRecord;
}

/**
 * A source's options: its row's defaults, each folder's `export.json` from
 * `AssetsSource/` down, then its own record (`record`: the index's `recordOf`, its stem's by default). `folder` reads a folder's defaults --
 * the index hands in its own, which reads only the `export.json` files it
 * knows are there, once each while they stay as they are; by default, the disk.
 */
export async function sourceOptions(
  root: string,
  sourcePath: string,
  found: Found,
  folder: (dir: string) => Promise<RecordRead> = (dir) => readFolderDefaults(root, dir),
  record: string = recordPath(sourcePath),
): Promise<SourceOptions> {
  const problems: string[] = [];
  const layers: Array<Options | undefined> = [];
  for (const dir of folderChain(sourcePath)) {
    const read = await folder(dir);
    if (read.problem) problems.push(read.problem);
    layers.push(read.record?.options);
  }
  const own = await readRecord(root, sourcePath, record);
  if (own.problem) problems.push(own.problem);
  layers.push(own.record?.options);
  const resolved = resolveOptions(found.row, layers);
  problems.push(...resolved.problems);
  return { options: resolved.options, problems, ...(own.record ? { record: own.record } : {}) };
}
