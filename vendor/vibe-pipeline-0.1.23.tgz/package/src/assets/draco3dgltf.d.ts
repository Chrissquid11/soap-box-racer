/**
 * Types for `draco3dgltf`, which ships none: the two factories the glTF steps
 * call (`steps/gltf.ts`), each answering an Emscripten module glTF-Transform
 * takes as a dependency without looking inside it. Each module that imports it
 * references this file, so a program that reaches the pipeline from outside it (a
 * project's vite.config.ts) has it too.
 */
declare module 'draco3dgltf' {
  const draco3d: {
    createDecoderModule(options?: object): Promise<unknown>;
    createEncoderModule(options?: object): Promise<unknown>;
  };
  export default draco3d;
}
