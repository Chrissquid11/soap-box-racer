/**
 * The Vite plugin (Docs/assets.md §5): two plugins from one `assets()` call --
 * one port, one process, the websocket the page already holds.
 *
 * - **`assets:generate`** (serve and build): the generated files (`keys.ts`)
 *   at `buildStart`, before anything is transformed, and the packs -- directly
 *   in a build, where `buildStart` first fails on any file that ships and is an
 *   LFS pointer (`shippedPointers`; `buildPacks` refuses one in a pack), in a worker once a dev server is listening. In the dev server
 *   its watcher hook is **the one place `keys.d.ts` is regenerated** after
 *   startup (`add`, `unlink`, `addDir`, `unlinkDir` under `src/assets/` or
 *   `packs/`), never `hotUpdate` -- once per macrotask however many events it
 *   holds, as the index coalesces its own: a burst of events is one walk of
 *   the folders, not one each; and any event under `packs/` re-zips them in
 *   a `worker_threads` worker running `cli.ts packs`, debounced 2 s after the
 *   last and never while an export runs.
 * - **`assets:server`** (`apply: 'serve'`: none of it is in a build):
 *   `config()` keeps the watcher out of `.trash/` and `.cache/`;
 *   `configureServer` loads `server.ts` -- `await import()`, so a build never
 *   loads it -- mounts the API on Vite's own middleware stack (after its CORS
 *   and host checks, before its transforms) and starts the index; once
 *   listening, the tools, the prunes, the hashing. `load` (`order: 'pre'`,
 *   before `vite:asset`'s) names an LFS pointer in the page's error overlay;
 *   `hotUpdate` (`order: 'post'`, after the glob plugin's: the last word)
 *   answers §5's table for the client environment, and sends the reloads --
 *   for a file a glob takes, created or removed, Vite's set less the file's
 *   own modules: its stale `?url` node would be a dead end (`hotUpdateFor`).
 *   **That set is held for a burst** -- 200 files of one undo trashed -- and
 *   updated once, `burstMs` (80) after the last such event (`reloadModule`):
 *   an update each would have the page fetch `globs.ts` while the files it
 *   lists were still going, and Vite answer 500 for one gone in between.
 * - **`assets:prefab-json`** (serve and build): a `.prefab`, `.scene` or `.material` module
 *   -- JSON named so a prefab, a scene or a material is told apart from every other JSON
 *   file at a glance -- made `export default <its JSON>` as Vite's JSON plugin
 *   makes a `.json`, so `prefab-globs.ts`, `scene-globs.ts` and `material-globs.ts` stay eager with
 *   `import: 'default'`. A file that
 *   does not parse fails the build naming it and its line (`jsonProblem`); in
 *   the dev server `server.ts`' `hotUpdate` keeps one from the page first.
 *
 * **Nothing heavy at the top** (§4): this imports only `kinds.ts`, `paths.ts`,
 * `json-problem.ts`, `keys.ts`, `stamp.ts` (the uids: `record.ts`, `recipes.ts`' tables), `packs.ts`, `fs.ts` and `stats/lfs.ts` statically -- Node's
 * own modules besides -- and acts only inside the hooks: `vite.config.ts`
 * loads it for every `vite build`, bundled.
 */
import { relative, resolve } from 'node:path';
import { Worker } from 'node:worker_threads';
import type { DevEnvironment, EnvironmentModuleNode, Plugin } from 'vite';
import { generateKeys, isGenerated } from './keys.ts';
import { jsonProblem } from './json-problem.ts';
import { MATERIAL_SUFFIX, PREFAB_SUFFIX, ROOTS, SCENE_SUFFIX, type ProjectKinds } from './kinds.ts';
import { walk } from './fs.ts';
import { PACKS_OUT, buildPacks } from './packs.ts';
import { globbed, isRecordName, norm, under } from './paths.ts';
import { stampUids } from './stamp.ts';
import { peekPointer } from './stats/lfs.ts';
import type { AssetsServer, AssetsServerOptions } from './server.ts';
import { AGENT_KEY, type AgentHolder } from '../agent/vite.ts';
import type { TurnLink } from './turn-hold.ts';

export interface AssetsPluginOptions {
  /** Told the server once it is made: a test's handle on it. */
  onServer?: (server: AssetsServer) => void;
  /** Told each time the generated files are made again: a test's count. */
  onRegenerate?: () => void;
  /** More for the server: a test's clock, canned tools. */
  server?: Partial<Omit<AssetsServerOptions, 'root' | 'ws'>>;
  /** Milliseconds a burst of created and removed files is held for, before the glob files update once (80). */
  burstMs?: number;
  /** The link with the agent's plugin for a Claude turn (`turn-hold.ts`): Gladius exports held, scripts checked. None, nothing held. */
  link?: TurnLink;
  /** The project's own kinds (`vibe({ kinds })`, checked): their glob files written, their files listed by the server. */
  kinds?: ProjectKinds;
  /** The agent's `globalThis` key (`AGENT_KEY`) the server's work is handed to: a test's own. */
  agentKey?: symbol;
}

/** Milliseconds after the last change under `packs/` before they are zipped again. */
const PACKS_QUIET = 2000;

/** What `packsWorker` needs of a worker: told when it ends. */
export interface PacksZipper {
  on(event: 'error', listener: (err: Error) => void): unknown;
  on(event: 'exit', listener: (code: number) => void): unknown;
}

/**
 * The real zipper: `vibe packs` (`../cli.ts`) in a `worker_threads` worker, for the project at `root` -- the worker's cwd is the server's, whatever that is.
 * Its output is the worker's own `process.stdout`, which Node would pipe to the server's straight past `console`: taken
 * (`stdout`, `stderr`) and said again line by line through `console.log` and `console.error`, so what hears the server's
 * console -- the Studio's log (`studio/log.ts`) -- hears `[packs] …` too.
 */
function zipper(root: string): PacksZipper {
  const worker = new Worker(new URL('../cli.ts', import.meta.url), { argv: ['packs', '--root', root], execArgv: ['--disable-warning=ExperimentalWarning'], stdout: true, stderr: true });
  const forward = (stream: NodeJS.ReadableStream, say: (line: string) => void): void => {
    let rest = '';
    stream.setEncoding('utf8');
    stream.on('data', (chunk: string) => {
      const lines = (rest + chunk).split('\n');
      rest = lines.pop()!;
      for (const line of lines) say(line);
    });
    stream.on('end', () => {
      if (rest !== '') say(rest);
    });
  };
  forward(worker.stdout, (line) => console.log(line));
  forward(worker.stderr, (line) => console.error(line));
  return worker;
}

/**
 * `vibe packs` in a worker, debounced, never while an export runs, never two
 * at once: a change while one runs zips once more after it (`again`), and
 * `stop` ends the waiting. `new URL('../cli.ts', import.meta.url)` is the real
 * file even from the bundled config (`bundleConfigFile` rewrites each module's
 * `import.meta.url` to its own), run by Node with its types stripped;
 * `execArgv` replaces the parent's, so the warning flag is said again.
 * `root` is the project's (Vite's `config.root`); `options` are a test's: the quiet, and a stand-in for the worker.
 */
export function packsWorker(
  server: () => Pick<AssetsServer, 'idle'> | undefined,
  root: string,
  options: { quietMs?: number; spawn?: () => PacksZipper } = {},
): { schedule(ms?: number): void; stop(): Promise<void> } {
  const quiet = options.quietMs ?? PACKS_QUIET;
  const spawn = options.spawn ?? (() => zipper(root));
  let timer: ReturnType<typeof setTimeout> | undefined;
  let running = false;
  let again = false;
  let stopped = false;
  /** The zip running now, until its worker exits: what `stop` waits for. */
  let current: Promise<void> | null = null;
  const run = async (): Promise<void> => {
    timer = undefined;
    running = true;
    try {
      await server()?.idle();
      if (stopped) return;
      await (current = new Promise<void>((done) => {
        const worker = spawn();
        worker.on('error', (err: Error) => {
          console.error(`[packs] ${err.message}`);
          done();
        });
        worker.on('exit', (exit) => {
          if (exit !== 0) console.error(`[packs] the zipper ended with ${exit}`);
          done();
        });
      }));
    } finally {
      current = null;
      running = false;
      if (again && !stopped) {
        again = false;
        schedule();
      }
    }
  };
  const schedule = (ms = quiet): void => {
    if (stopped) return;
    if (running) {
      again = true;
      return;
    }
    if (timer !== undefined) clearTimeout(timer);
    timer = setTimeout(() => void run(), ms);
  };
  return {
    schedule,
    // No zip begun after it; resolves once the one running (its worker still writing into packs/) has ended.
    stop: async () => {
      stopped = true;
      if (timer !== undefined) clearTimeout(timer);
      await current;
    },
  };
}

/**
 * A `.prefab` or `.scene` module as JSON: `export default` its parsed contents, as Vite's
 * JSON plugin answers a `.json` (and with its `import: 'default'` glob). A file
 * that does not parse is an error naming it, relative to `root`, and its line.
 */
/**
 * Every file a build ships that is an LFS pointer, relative to the root: what the globs take under
 * `src/assets/`, and everything in `public/` (copied as it is) but the packs' zips, which `buildPacks`
 * makes -- and checks the pack files of -- itself.
 */
export async function shippedPointers(root: string): Promise<string[]> {
  const found: string[] = [];
  const look = async (dir: string, ships: (path: string) => boolean): Promise<void> => {
    for (const file of await walk(resolve(root, dir))) {
      const path = `${dir}/${file}`;
      if (ships(path) && (await peekPointer(resolve(root, path)).catch(() => false))) found.push(path);
    }
  };
  await look(ROOTS.boot.dir, globbed);
  await look('public', (path) => !under(path, PACKS_OUT));
  return found;
}

/**
 * A `.prefab`, `.scene` or `.material` read as JSON, an error naming the file (relative to the root) when it does
 * not parse -- and a file of a project's own data kind (`vibe({ kinds })`: a `.tilemap` under
 * `src/assets/tilemaps/`), JSON whatever its extension is called (a `.json` one is Vite's own). Its root
 * is its own config's: Vite calls `configResolved` on a worker's plugins too, with the worker's config.
 */
export function prefabJson(kinds: ProjectKinds = {}): Plugin {
  let root = resolve('.');
  /** Is `file` (absolute) one of a project kind's, by its folder and its extension? */
  const ownKind = (file: string): boolean => {
    const path = norm(relative(root, file));
    const ext = path.slice(path.lastIndexOf('.') + 1).toLowerCase();
    return ext !== 'json' && Object.values(kinds).some((kind) => path.startsWith(`${ROOTS.boot.dir}/${kind.dir}/`) && kind.ext.includes(ext));
  };
  return {
    name: 'assets:prefab-json',
    enforce: 'pre',
    configResolved(config) {
      root = config.root;
    },
    transform(code, id) {
      const file = id.split('?')[0]!;
      if (!file.endsWith(PREFAB_SUFFIX) && !file.endsWith(SCENE_SUFFIX) && !file.endsWith(MATERIAL_SUFFIX) && !ownKind(file)) return null;
      const problem = jsonProblem(code);
      if (problem) this.error(`${norm(relative(root, file))} does not parse${problem.line !== undefined ? ` (line ${problem.line})` : ''}: ${problem.message}`);
      return { code: `export default ${JSON.stringify(JSON.parse(code))};\n`, map: { mappings: '' }, moduleType: 'js' };
    },
  };
}

export function assets(options: AssetsPluginOptions = {}): Plugin[] {
  let root = resolve('.');
  let command: 'serve' | 'build' = 'serve';
  let api: AssetsServer | undefined;
  /** A path from the watcher, relative to the root with `/`; undefined outside it. */
  const rel = (file: string): string | undefined => {
    const r = norm(relative(root, file));
    return r === '' || r === '..' || r.startsWith('../') ? undefined : r;
  };
  /**
   * The generated files, written where they changed. A duplicate key is said, and the server stays up. In the dev
   * server every asset is given its uid first (`stampUids`, Docs/asset-ids.md §1; a path in `VIBE_STAMP_SKIP` left
   * alone): a build stamps nothing -- only an explicit run does (rule 6), and `vibe build`'s `vibe assets --no-stamp` is none.
   * While the server's move or export-as runs its repair passes (`repairing()`), it waits, and runs once after: a stamp
   * landing between the move and its second pass would write files outside what the move's step puts back.
   */
  const regenerate = (): void => {
    const held = api?.repairing();
    if (held !== undefined) {
      if (!waiting) {
        waiting = true;
        void held.then(() => {
          waiting = false;
          regenerateSoon();
        });
      }
      return;
    }
    options.onRegenerate?.();
    // The paths added since the last stamp: of two files with one uid, the one just added is the copy (rule 7).
    const added = new Set(justAdded);
    justAdded.clear();
    try {
      if (command !== 'build') stampUids(root, options.kinds, { added });
      generateKeys(root, options.kinds);
    } catch (err) {
      console.error(err instanceof Error ? err.message : err);
    }
  };
  /** A regenerate waiting for a move's repair passes to end. */
  let waiting = false;
  /** Paths (relative to the root) the watcher saw added since the last regenerate. */
  const justAdded = new Set<string>();
  /** `regenerate` once at the end of this macrotask, for every watcher event already in -- a boundary, not a wait. */
  let due = false;
  const regenerateSoon = (): void => {
    if (due) return;
    due = true;
    setImmediate(() => {
      due = false;
      regenerate();
    });
  };

  /** The dev server's zipper, once it is configured. */
  let zipping: ReturnType<typeof packsWorker> | undefined;
  const generate: Plugin = {
    name: 'assets:generate',
    configResolved(config) {
      root = config.root;
      command = config.command;
    },
    async buildStart() {
      regenerate();
      if (command !== 'build') return;
      // An LFS pointer would be fingerprinted and shipped as the file -- the game failing only in production,
      // at Assets.preload(). The dev server's `load` hook names one; a build stops on every one.
      const pointers = await shippedPointers(root);
      if (pointers.length > 0) this.error(`${pointers.length === 1 ? 'a file that ships is a Git LFS pointer' : `${pointers.length} files that ship are Git LFS pointers`}, not the file -- run git lfs install && git lfs pull: ${pointers.join(', ')}`);
      try {
        await buildPacks(root);
      } catch (err) {
        this.error((err as Error).message);
      }
    },
    configureServer(server) {
      const packs = (zipping = packsWorker(() => api, root));
      server.watcher.on('all', (event, file) => {
        const path = rel(file);
        if (path === undefined) return;
        const inPacks = under(path, ROOTS.packs.dir);
        if (event === 'add' && (inPacks || under(path, ROOTS.boot.dir) || under(path, ROOTS.source.dir))) justAdded.add(path);
        if ((inPacks || under(path, ROOTS.boot.dir)) && (event === 'add' || event === 'unlink' || event === 'addDir' || event === 'unlinkDir')) regenerateSoon();
        // A prefab's contents are in keys.d.ts too -- its node names, what each is made of, its views -- so its
        // change is one as well. Nothing imports keys.d.ts: the page does not reload, tsserver reads it again.
        // And any data file's, and a record's: its uid may have gone (a hand edit, a copy), or its references gone stale.
        else if (event === 'change' && (under(path, ROOTS.boot.dir) || inPacks) && !isGenerated(path)) regenerateSoon();
        else if (under(path, ROOTS.source.dir) && isRecordName(path.slice(path.lastIndexOf('/') + 1)) && (event === 'add' || event === 'change' || event === 'unlink')) regenerateSoon();
        if (inPacks) packs.schedule();
      });
      // Zipped once the server is listening -- `npm run dev` is not a second slower for it.
      server.httpServer?.once('listening', () => packs.schedule(0));
      server.httpServer?.once('close', () => void packs.stop());
    },
    // The server closed (`server.close()` awaits this): a zip still running ends before it resolves -- else its
    // worker writes into packs/ after the server is gone (a folder removed under it, a restart's two zippers).
    async closeBundle() {
      await zipping?.stop();
    },
  };

  /** The glob files a burst of creates and deletes asked to update, held until it is quiet, then updated once each. */
  const held = new Set<EnvironmentModuleNode>();
  let burst: ReturnType<typeof setTimeout> | undefined;
  const holdBurst = (environment: DevEnvironment, modules: readonly EnvironmentModuleNode[]): void => {
    for (const m of modules) held.add(m);
    if (burst !== undefined) clearTimeout(burst);
    burst = setTimeout(() => {
      burst = undefined;
      const now = [...held];
      held.clear();
      for (const m of now) environment.reloadModule(m).catch((err: unknown) => console.error('[assets] the glob update failed:', err));
    }, options.burstMs ?? 80);
  };

  const serve: Plugin = {
    name: 'assets:server',
    apply: 'serve',
    config: () => ({ server: { watch: { ignored: ['**/.trash/**', '**/.cache/**'] } } }),
    async configureServer(server) {
      const { createAssetsServer } = await import('./server.ts');
      const { allowedHosts } = await import('./http.ts');
      const made = createAssetsServer({ port: () => server.config.server.port, hosts: () => allowedHosts(server.config.server?.allowedHosts), ...(options.link ? { link: options.link } : {}), ...(options.kinds ? { kinds: options.kinds } : {}), ...options.server, root, ws: server.ws });
      api = made;
      options.onServer?.(made);
      // The routes' work for the studio's MCP tools (Docs/mcp.md M3), handed to the agent's holder: this bundle's, whichever plugin starts first.
      ((globalThis as unknown as Record<symbol, AgentHolder | undefined>)[options.agentKey ?? AGENT_KEY] ??= {}).assets = () => made.calls;
      // Added here, not from a returned hook: after Vite's CORS and host checks, before its transforms. Vite 8 adds its
      // host check (`hostValidationMiddleware`) before any `configureServer` runs, but only while `server.allowedHosts`
      // is not `true` and the server is not HTTPS: every route checks `Host` itself as well (`assets/http.ts`' `guardHost`).
      server.middlewares.use((req, res, next) => {
        made.handle(req, res).then((handled) => {
          if (!handled) next();
        }, next);
      });
      server.ws.on('connection', (socket, req) => made.connection(socket, req));
      server.watcher.on('all', (event, file) => made.watch(event, file));
      if (server.httpServer) {
        server.httpServer.once('listening', () => void made.listening());
        server.httpServer.once('close', () => void made.close());
      } else void made.listening();
    },
    load: {
      order: 'pre',
      async handler(id) {
        const pointer = await api?.pointer(id);
        if (pointer !== undefined) this.error(pointer);
        return undefined;
      },
    },
    hotUpdate: {
      order: 'post',
      handler({ type, file, modules }) {
        // Once, for the page: the `ssr` environment's set, empty here, is Vite's.
        if (this.environment.name !== 'client' || !api) return;
        const pass = api.hotUpdate(file, type);
        if (pass === 'none') return [];
        if (pass === 'vite') return undefined;
        if (pass === 'prefabGlob' || pass === 'materialGlob') {
          const glob = pass === 'prefabGlob' ? 'src/assets/prefab-globs.ts' : 'src/assets/material-globs.ts';
          holdBurst(this.environment, [...(this.environment.moduleGraph.getModulesByFile(resolve(root, glob)) ?? [])]);
          return [];
        }
        // A created or removed file a glob takes: its own `?url` node is stale -- once `globs.ts`
        // was read again without it, importer-less, a dead end to Vite, which would reload the
        // page. Vite's set less it: the glob file the glob plugin added is what updates -- once
        // the burst it is part of is quiet.
        holdBurst(this.environment, modules.filter((m) => m.file !== file));
        return [];
      },
    },
  };

  return [generate, prefabJson(options.kinds), serve];
}
