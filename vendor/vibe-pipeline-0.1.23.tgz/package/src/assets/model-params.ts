/**
 * `GET params` (Docs/modeler.md §3, M22): what a Gladius script's `params{}`
 * declares -- name, type, default, the value it builds at, bounds, choices, doc,
 * line -- from `gladius params --format json`, which stops the script the moment
 * `params{}` returns (Gladius ADR-088): milliseconds, no build (Vibe3D D111).
 *
 * - **Gladius is the parser** (Vibe3D D45): a spec built by a loop reports as
 *   one written out does, and there is no second reading of `params{}` here to
 *   drift from Gladius's.
 * - **Run with the source's resolved parameters**, as the export passes them
 *   (`steps/gladius.ts`): what the rows show is what the model is built at.
 * - **A refused override does not lose the rows** (D45, D47): Gladius rejects a
 *   bad `--param` before it reports the spec, so the report has no `params` --
 *   asked again at the script's own defaults, the overrides painted back on, and
 *   the refusal said. The panel stays, with the value that broke it in it.
 * - **No `params` and no error**: this Gladius predates the report (`params:
 *   null`, said as such).
 *
 * `readParams` and `paintBack` are pure (`model-params.test.ts`); `queryParams`
 * runs Gladius.
 */
import { dirname } from 'node:path';
import type { ModelDiagnostic, ParamSpec, ParamsAnswer } from './api-types.ts';
import { diagnosticOf, type RawDiagnostic } from './model-query.ts';
import { run } from './tools.ts';

/** `gladius params` is quick; one that has not answered in this long is a script that loops before `params{}`. */
export const PARAMS_MS = 20_000;

/** `--param name=value`, sorted by name: the export's order (`steps/gladius.ts`). */
export function paramArgs(params: Readonly<Record<string, string>>): string[] {
  const args: string[] = [];
  for (const name of Object.keys(params).sort()) args.push('--param', `${name}=${params[name]}`);
  return args;
}

const TYPES = ['number', 'integer', 'string', 'boolean'] as const;
const scalar = (v: unknown): number | string | boolean | undefined => (typeof v === 'number' || typeof v === 'string' || typeof v === 'boolean' ? v : undefined);

/** One reported parameter, narrowed: undefined for one without a name, a type, or a default. */
export function specOf(raw: Record<string, unknown>): ParamSpec | undefined {
  const name = raw.name;
  if (typeof name !== 'string' || name === '') return undefined;
  const type = TYPES.find((t) => t === raw.type);
  const fallback = scalar(raw.default);
  const value = scalar(raw.value) ?? fallback;
  if (!type || fallback === undefined || value === undefined) return undefined;
  const spec: ParamSpec = { name, type, default: fallback, value, overridden: raw.overridden === true };
  if (typeof raw.min === 'number') spec.min = raw.min;
  if (typeof raw.max === 'number') spec.max = raw.max;
  if (Array.isArray(raw.choices)) {
    const choices = raw.choices.filter((c): c is number | string => typeof c === 'number' || typeof c === 'string');
    if (choices.length > 0) spec.choices = choices;
  }
  if (typeof raw.doc === 'string' && raw.doc !== '') spec.doc = raw.doc;
  if (typeof raw.line === 'number') spec.line = raw.line;
  return spec;
}

/** What one `gladius params` printed, read: its specs (null for no `params` key), diagnostics, the first error -- or a `problem`. */
export interface ParamsReport {
  ok: boolean;
  params: ParamSpec[] | null;
  diagnostics: ModelDiagnostic[];
  error?: string;
  problem?: string;
}

/** Gladius's envelope, read (`text` its whole output: the JSON from its first `{`). */
export function readParams(text: string): ParamsReport {
  const start = text.indexOf('{');
  type Envelope = { ok?: unknown; params?: unknown; diagnostics?: unknown };
  let parsed: Envelope | null = null;
  if (start >= 0) {
    try {
      const read: unknown = JSON.parse(text.slice(start));
      if (typeof read === 'object' && read !== null) parsed = read as Envelope;
    } catch {
      parsed = null;
    }
  }
  if (!parsed) {
    const first = text.trim().split('\n')[0] ?? '';
    return { ok: false, params: null, diagnostics: [], problem: first ? `gladius said: ${first}` : 'gladius printed nothing' };
  }
  const diagnostics = Array.isArray(parsed.diagnostics) ? (parsed.diagnostics as RawDiagnostic[]).map(diagnosticOf) : [];
  const error = diagnostics.find((d) => d.severity === 'error');
  const params = Array.isArray(parsed.params) ? (parsed.params as Record<string, unknown>[]).map(specOf).filter((p): p is ParamSpec => p !== undefined) : null;
  return { ok: parsed.ok === true, params, diagnostics, ...(error ? { error: error.code ? `${error.code}: ${error.message}` : error.message } : {}) };
}

/**
 * The overrides spelled back onto specs reported at the script's defaults:
 * the rows show what is set, the value that was refused among them -- a
 * number that is no number kept as its text, so the row shows what was typed.
 */
export function paintBack(params: readonly ParamSpec[], set: Readonly<Record<string, string>>): ParamSpec[] {
  return params.map((spec) => {
    const text = set[spec.name];
    if (text === undefined) return spec;
    let value: number | string | boolean = text;
    if (spec.type === 'number' || spec.type === 'integer') {
      const n = Number(text);
      value = text.trim() !== '' && Number.isFinite(n) ? n : text;
    } else if (spec.type === 'boolean') value = text === 'true' || text === '1';
    return { ...spec, value, overridden: true };
  });
}

export interface ParamsOptions {
  bin: string;
  /** The source, absolute: run in its folder, as the export is. */
  input: string;
  /** Its resolved parameters, as the export passes them. */
  set: Readonly<Record<string, string>>;
  /** What its own record sets of them. */
  own: Readonly<Record<string, string>>;
  hint?: string;
  now?: () => number;
}

/** `gladius params` once: read, or why it could not run. */
async function ask(bin: string, input: string, set: Readonly<Record<string, string>>): Promise<ParamsReport | { missing: true } | { problem: string }> {
  const ran = await run(bin, ['params', '--format', 'json', ...paramArgs(set), input], { cwd: dirname(input), timeoutMs: PARAMS_MS });
  if ('error' in ran) return ran.error === 'missing' ? { missing: true } : { problem: `gladius ${ran.message}` };
  return readParams(ran.stdout.includes('{') ? ran.stdout : ran.stdout + ran.stderr);
}

/** The script's parameters with its overrides -- recovered at its defaults when an override is refused (D45). */
export async function queryParams({ bin, input, set, own, hint, now = Date.now }: ParamsOptions): Promise<ParamsAnswer> {
  const began = now();
  const base = { set: { ...set }, own: { ...own } };
  const first = await ask(bin, input, set);
  if ('missing' in first) return { ok: false, ms: now() - began, params: null, diagnostics: [], ...base, missing: 'gladius', ...(hint ? { hint } : {}) };
  if (!('params' in first)) return { ok: false, ms: now() - began, params: null, diagnostics: [], ...base, problem: first.problem };
  if (first.params !== null || first.error === undefined || Object.keys(set).length === 0) {
    return { ok: first.ok, ms: now() - began, params: first.params, diagnostics: first.diagnostics, ...base, ...(first.error ? { error: first.error } : {}), ...(first.problem ? { problem: first.problem } : {}) };
  }
  // Refused before the spec was reported: asked at the script's own defaults, the overrides painted back on.
  const clean = await ask(bin, input, {});
  const params = 'params' in clean && clean.params !== null ? paintBack(clean.params, set) : null;
  return { ok: false, ms: now() - began, params, diagnostics: first.diagnostics, ...base, error: first.error };
}
