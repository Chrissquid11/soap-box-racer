/**
 * What a path is, worked out from the path alone (Docs/assets.md §2, §5, §6):
 * its root, its kind, its key; a source's exports, record and intermediate,
 * and the twin folder either way; which names are the OS's leavings
 * (`IGNORED`); which names are fine (`validName`, `suggestName`); when two
 * files are a `conflict`; where a file goes in the trash and what it comes back
 * as; and what Vite's `hotUpdate` does with a watch event (`hotUpdateFor`).
 *
 * Every path here is relative to the project root, with `/`: the callers turn
 * an absolute or a Windows path into one with `norm()` first.
 *
 * Pure: no `node:` import, nothing read, so the browser side shares it and
 * every rule is a node test (`paths.test.ts`).
 */
import type { BesideReload, Expected, HotDecision, Refusal, WatchType } from './api-types.ts';
import { KINDS, MATERIAL_SUFFIX, PREFAB_SUFFIX, ROOTS, TRASH, isDataKind, kindAt, kindDef, shipped, type KindName, type RootName } from './kinds.ts';
import { caseKey } from '@vibe/engine/case-key';

// ---------------------------------------------------------------- plain path work

/** `/` separators, no `./` in front, no `/` behind. */
export function norm(path: string): string {
  let p = path.split('\\').join('/');
  while (p.startsWith('./')) p = p.slice(2);
  while (p.length > 1 && p.endsWith('/')) p = p.slice(0, -1);
  return p;
}

export function baseName(path: string): string {
  const at = path.lastIndexOf('/');
  return at < 0 ? path : path.slice(at + 1);
}

/** The folder a path is in; `''` for a name at the top. */
export function dirName(path: string): string {
  const at = path.lastIndexOf('/');
  return at < 0 ? '' : path.slice(0, at);
}

export function joinPath(...parts: string[]): string {
  return parts.filter((p) => p !== '').join('/');
}

/**
 * A name's stem and lowercase extension: `Crate.GLB` is `Crate` and `glb`.
 * The extension is what follows the last dot; a name with none, or only a
 * leading one (`.gitkeep`), has `''`.
 */
export function splitName(name: string): { stem: string; ext: string } {
  const dot = name.lastIndexOf('.');
  if (dot <= 0) return { stem: name, ext: '' };
  return { stem: name.slice(0, dot), ext: name.slice(dot + 1).toLowerCase() };
}

/** A path's lowercase extension, whichever separator it has: `C:\\art\\Crab.FBX` is `fbx`. */
export function extOf(path: string): string {
  return splitName(baseName(norm(path))).ext;
}

/**
 * `rel` resolved against the folder `dir`: `.` and `..` worked out, `/` only.
 * Undefined when `..` climbs above the project root, or `rel` is absolute.
 */
export function resolveRel(dir: string, rel: string): string | undefined {
  const r = rel.split('\\').join('/');
  if (r.startsWith('/') || /^[a-zA-Z]:\//.test(r)) return undefined;
  const out = dir === '' ? [] : norm(dir).split('/');
  for (const segment of r.split('/')) {
    if (segment === '' || segment === '.') continue;
    if (segment === '..') {
      if (out.length === 0) return undefined;
      out.pop();
    } else out.push(segment);
  }
  return out.join('/');
}

/** Is `path` `dir` itself or under it? */
export function under(path: string, dir: string): boolean {
  return path === dir || path.startsWith(dir + '/');
}

// ---------------------------------------------------------------- the path rule's half without the disk

/** What a call of the API may read (§5): the roots, and the Trash (`GET file`, `GET thumb`, `GET stats`). */
export const READ_DIRS: readonly string[] = [ROOTS.boot.dir, ROOTS.packs.dir, ROOTS.source.dir, TRASH];
/** What a call may write: the roots. */
export const WRITE_DIRS: readonly string[] = [ROOTS.boot.dir, ROOTS.packs.dir, ROOTS.source.dir];

/** A path argument refused before the disk is asked: `403`, or `422` for no path at all. */
export interface PathRefusal {
  status: 403 | 422;
  refused: string;
}

/**
 * The path rule (§5), as far as it goes without the disk: relative, `/` only,
 * every part a name, and under one of `dirs` -- the folder itself only where
 * `folder` allows. The path (a trailing `/` taken off), or why not. The dev
 * server goes on to the real paths (`http.ts`'s `checkPath`); the editor's
 * `api.ts` refuses with these same words before it calls, so the two never say
 * it differently.
 */
export function checkedPath(raw: unknown, dirs: readonly string[], options: { folder?: boolean } = {}): { path: string; home: string } | PathRefusal {
  if (typeof raw !== 'string' || raw === '') return { status: 422, refused: 'a path is needed' };
  if (raw.includes('\0') || raw.includes('\\')) return { status: 403, refused: `${JSON.stringify(raw)}: a path here has / between its names, and no \\ or NUL` };
  if (raw.startsWith('/') || /^[a-zA-Z]:/.test(raw)) return { status: 403, refused: `${raw}: a path is relative to the project root` };
  const path = raw.endsWith('/') ? raw.slice(0, -1) : raw;
  for (const segment of path.split('/')) {
    if (segment === '' || segment === '.' || segment === '..') return { status: 403, refused: `${raw}: a path has no empty, . or .. part` };
  }
  const home = dirs.find((dir) => under(path, dir));
  if (home === undefined || (path === home && !options.folder)) return { status: 403, refused: `${path} is not in ${dirs.join(', ')}` };
  return { path, home };
}

// ---------------------------------------------------------------- never listed

/**
 * The OS's and the art tools' leavings, as `.gitignore` lists them: never in
 * the index, never imported. One array, so what is hidden and what is refused
 * cannot drift.
 */
export const IGNORED: readonly RegExp[] = [
  /^\./, // .DS_Store, .gitkeep, ._* resource forks, the pipeline's dot-named temp files
  /~$/, // editor backups, *.psd~
  /^~\$/, // ~$* lock files
  /\.tmp$/i,
  /\.blend\d{1,2}$/i, // .blend1 ... .blend99
  /\.aseprite-backup$/i,
];

export function ignored(name: string): boolean {
  return IGNORED.some((re) => re.test(name));
}

// ---------------------------------------------------------------- roots and kinds

/** Where a path sits: its root, its pack, its kind and the path under the kind's folder. */
export interface Where {
  root: RootName;
  /** The path under the root's `dir`. */
  rel: string;
  /** The pack, under `packs/` or `AssetsSource/packs/`. */
  pack?: string;
  kind?: KindName;
  /** The path under the kind's folder: `props/crate.lua`. */
  under?: string;
  /** Under `AssetsSource/reference/`. */
  reference?: boolean;
}

/** The root, pack and kind of a path; undefined outside every root. */
export function locate(path: string): Where | undefined {
  const p = norm(path);
  // The longest `dir` first: none of today's roots nests in another's `dir`,
  // but `AssetsSource/packs` nests in `Source` as a source.
  for (const root of ['boot', 'packs', 'source'] as const) {
    const dir = ROOTS[root].dir;
    if (!under(p, dir) || p === dir) continue;
    const rel = p.slice(dir.length + 1);
    if (root === 'source') {
      if (under(p, ROOTS.source.reference)) return { root, rel, reference: true };
      if (under(p, ROOTS.packs.source)) {
        if (p === ROOTS.packs.source) return { root, rel };
        const inPacks = p.slice(ROOTS.packs.source.length + 1);
        const slash = inPacks.indexOf('/');
        if (slash < 0) return { root, rel, pack: inPacks };
        const pack = inPacks.slice(0, slash);
        const at = kindAt(inPacks.slice(slash + 1));
        return at ? { root, rel, pack, kind: at.kind, under: at.under } : { root, rel, pack };
      }
      const at = kindAt(rel);
      return at ? { root, rel, kind: at.kind, under: at.under } : { root, rel };
    }
    if (root === 'packs') {
      const slash = rel.indexOf('/');
      if (slash < 0) return { root, rel, pack: rel };
      const pack = rel.slice(0, slash);
      const at = kindAt(rel.slice(slash + 1));
      return at ? { root, rel, pack, kind: at.kind, under: at.under } : { root, rel, pack };
    }
    const at = kindAt(rel);
    return at ? { root, rel, kind: at.kind, under: at.under } : { root, rel };
  }
  return undefined;
}

/** Does any segment of the path under its kind's folder start with `_`? Then it never ships. */
export function underscored(underKind: string): boolean {
  return underKind.split('/').some((segment) => segment.startsWith('_'));
}

/**
 * The shipping root a source maps to: the one whose `source` is the longest
 * prefix of its path (`AssetsSource/packs/reef/...` is the pack's).
 */
export function shippingRootOf(sourcePath: string): 'boot' | 'packs' | undefined {
  const p = norm(sourcePath);
  if (under(p, ROOTS.source.reference)) return undefined;
  if (under(p, ROOTS.packs.source) && p !== ROOTS.packs.source) return 'packs';
  if (under(p, ROOTS.boot.source) && p !== ROOTS.boot.source) return 'boot';
  return undefined;
}

/**
 * A path's twin in the other side: `AssetsSource/models/props` is
 * `src/assets/models/props`, `packs/reef/models` is `AssetsSource/packs/reef/models`,
 * and back. Undefined for `reference/`, `levels/` (no twin) and anything
 * outside the roots.
 */
export function twin(path: string): string | undefined {
  const p = norm(path);
  // The roots themselves, which `locate` does not place.
  if (p === ROOTS.boot.dir) return ROOTS.boot.source;
  if (p === ROOTS.boot.source) return ROOTS.boot.dir;
  if (p === ROOTS.packs.dir) return ROOTS.packs.source;
  if (p === ROOTS.packs.source) return ROOTS.packs.dir;
  const where = locate(p);
  if (!where || where.reference) return undefined;
  if (where.kind && !kindDef(where.kind).source) return undefined;
  if (where.root === 'boot') return joinPath(ROOTS.boot.source, where.rel);
  if (where.root === 'packs') return joinPath(ROOTS.packs.source, where.rel);
  if (shippingRootOf(p) === 'packs') return joinPath(ROOTS.packs.dir, p.slice(ROOTS.packs.source.length + 1));
  return joinPath(ROOTS.boot.dir, where.rel);
}

// ---------------------------------------------------------------- a source's family

/**
 * `<stem>.export.json` beside a source: its options and what was built -- shared by two sources of one stem
 * (`crate.lua`, `crate.blend`), unless one has its own (`ownRecordPath`).
 */
export function recordPath(sourcePath: string): string {
  const p = norm(sourcePath);
  return joinPath(dirName(p), `${splitName(baseName(p)).stem}.export.json`);
}

/**
 * `<name>.export.json` beside a source -- `crate.blend.export.json` -- its own record, which is its record when it
 * is there (the index's `recordOf`): how one of two sources of one stem keeps its own options, build and uid, and
 * names its export (`"as"`, Docs/asset-ids.md §1, rule 8), so both ship.
 */
export function ownRecordPath(sourcePath: string): string {
  const p = norm(sourcePath);
  return joinPath(dirName(p), `${baseName(p)}.export.json`);
}

/** A folder's `export.json`: defaults for everything under it. */
export function folderRecordPath(dir: string): string {
  return joinPath(norm(dir), 'export.json');
}

/**
 * The folders whose `export.json` apply to a source, from `AssetsSource/` down to
 * its own: the layers `resolveOptions` merges, root first (§3, Folder
 * defaults). The tool's Options block reads the same list (part two, §6.5).
 */
export function folderChain(sourcePath: string): string[] {
  const dir = dirName(norm(sourcePath));
  const base = ROOTS.source.dir;
  if (!under(dir, base)) return [];
  const out: string[] = [base];
  const rest = dir === base ? [] : dir.slice(base.length + 1).split('/');
  for (let i = 0; i < rest.length; i++) out.push(`${base}/${rest.slice(0, i + 1).join('/')}`);
  return out;
}

/** Is this name a record of the pipeline's own: `export.json` or `<stem>.export.json`? */
export function isRecordName(name: string): boolean {
  return name === 'export.json' || /^[^/]+\.export\.json$/.test(name);
}

/** The stem whose record a name is: `crate.export.json` is `crate`'s; `export.json` is the folder's (`''`). */
export function recordStem(name: string): string | undefined {
  if (name === 'export.json') return '';
  const m = /^(.+)\.export\.json$/.exec(name);
  return m ? m[1] : undefined;
}

/** `_<stem>.glb` beside a source: the plain build a person or a game tab made (§3). */
export function intermediatePath(sourcePath: string): string {
  const p = norm(sourcePath);
  return joinPath(dirName(p), `_${splitName(baseName(p)).stem}.glb`);
}

/**
 * A source's exports, in its twin folder: one per extension of the recipe's
 * `to`, the keyed one first. `same` is the source's own extension (a copy).
 * Named by its stem, or by `as` -- the stem its record names its export as
 * (rule 8 of Docs/asset-ids.md §1: `crate.blend` `as` `crate-hi` ships `crate-hi.glb`).
 */
export function exportPaths(sourcePath: string, to: readonly string[], as?: string): string[] {
  const p = norm(sourcePath);
  const dir = twin(dirName(p));
  if (dir === undefined) return [];
  const { stem, ext } = splitName(baseName(p));
  return to.map((t) => joinPath(dir, `${as ?? stem}.${t === 'same' ? ext : t}`));
}

/**
 * What is wrong with `as` as the stem a record names its export (rule 8), or undefined for one that is fine:
 * a name with no folder and no extension, that ships -- `crate-hi`, not `props/crate`, `crate.glb` or `_crate`.
 */
export function asProblem(as: unknown): string | undefined {
  if (typeof as !== 'string' || as === '') return 'is a stem: a name, without its extension';
  if (as.includes('/') || as.includes('\\')) return `${JSON.stringify(as)} is a stem in the source's folder: no /`;
  if (as.includes('.')) return `${JSON.stringify(as)} is a stem: no extension, no dot`;
  if (as.startsWith('_')) return `${JSON.stringify(as)} would not ship: a stem with no _ in front`;
  const valid = validName(`${as}.x`);
  return 'refused' in valid ? `${JSON.stringify(as)}: ${valid.refused}` : undefined;
}

/** The extensions a recipe writes, `same` made the source's own. */
export function resolveTo(sourcePath: string, to: readonly string[]): string[] {
  const { ext } = splitName(baseName(norm(sourcePath)));
  return to.map((t) => (t === 'same' ? ext : t));
}

// ---------------------------------------------------------------- keys and globs

/**
 * Do the generated globs take this file -- is it in the build? Under a kind's
 * folder of a shipping root, no `_` on the way, and an extension the kind
 * ships (`ext` or `beside`). A pack's own lists are narrower (`packExt`).
 */
export function globbed(path: string): boolean {
  const where = locate(path);
  if (!where || !where.kind || !where.under || where.root === 'source') return false;
  if (underscored(where.under)) return false;
  const { ext } = splitName(baseName(where.under));
  if (where.root === 'packs') {
    const def = kindDef(where.kind);
    if (!def.inPacks) return false;
    return [...(def.packExt ?? def.ext), ...(def.beside ?? [])].includes(ext);
  }
  return shipped(where.kind).includes(ext);
}

/**
 * A shipped file's key, as `Assets` spells it: the path under its kind's folder
 * without the extension, a pack's with its prefix (`reef:props/crate`), in its
 * one spelling -- NFC, lowercase (`caseKey`): `models/props/Big Crate.glb` is
 * `props/big crate`.
 * Undefined for a file that is not a key: not globbed, or an extension its kind
 * ships beside its keys (a model's image, an atlas's `.json`).
 */
export function keyOf(path: string): string | undefined {
  const where = locate(path);
  if (!where || !where.kind || !where.under || where.root === 'source' || !globbed(path)) return undefined;
  const def = kindDef(where.kind);
  const { ext } = splitName(baseName(where.under));
  const keyed = where.root === 'packs' ? (def.packExt ?? def.ext) : def.ext;
  if (!keyed.includes(ext)) return undefined;
  const key = where.under.slice(0, where.under.length - ext.length - 1);
  return caseKey(where.root === 'packs' ? `${where.pack}:${key}` : key);
}

/** What a prefab file misnamed or misplaced is: the Assets tool's problem, and the name its one-click Rename gives. */
export interface StrayPrefab {
  problem: string;
  /** The name that makes it a prefab where it is; none for one in the wrong folder, which a move fixes. */
  renameTo?: string;
}

/**
 * A prefab file that is not one (Docs/prefabs.md §2): a `.json` under the boot
 * set's `prefabs/` -- never compiled, no key -- or a `.prefab` anywhere but
 * there. Undefined for anything else, a name under `_` included (it never ships).
 */
export function strayPrefab(path: string): StrayPrefab | undefined {
  return strayOf(path, 'prefabs', 'prefab', PREFAB_SUFFIX);
}

/**
 * A material file that is not one (Docs/render.md §4), as a stray prefab: a `.json` under the boot set's
 * `materials/` -- never compiled, no key -- or a `.material` anywhere but there (a pack's own `materials/` too).
 */
export function strayMaterial(path: string): StrayPrefab | undefined {
  return strayOf(path, 'materials', 'material', MATERIAL_SUFFIX);
}

/** A prefab or a material file that is none: the Assets tool's red mark and its one-click Rename. */
export function strayFile(path: string): StrayPrefab | undefined {
  return strayPrefab(path) ?? strayMaterial(path);
}

/** A data file of `kind` misnamed or misplaced: what `strayPrefab` and `strayMaterial` say. */
function strayOf(path: string, kind: 'prefabs' | 'materials', what: string, suffix: string): StrayPrefab | undefined {
  const p = norm(path);
  const name = baseName(p);
  const where = locate(p);
  // A material ships in a pack too: its `materials/` is a home of its own.
  const home = (where?.root === 'boot' || (kind === 'materials' && where?.root === 'packs')) && where.kind === kind && where.under !== undefined;
  if (where?.under !== undefined && underscored(where.under)) return undefined;
  if (name.startsWith('_')) return undefined;
  if (home && /\.json$/i.test(name)) {
    const stem = name.slice(0, -'.json'.length).replace(new RegExp(`\\${suffix}$`, 'i'), '');
    return { problem: `not a ${what}: ${what} files end in ${suffix} -- rename it`, renameTo: `${stem}${suffix}` };
  }
  if (!home && where !== undefined && name.toLowerCase().endsWith(suffix)) {
    // A material's other home is a pack's own `materials/`: named too.
    const homes = kind === 'materials' ? `${ROOTS.boot.dir}/${KINDS[kind].dir}/ or a pack's ${ROOTS.packs.dir}/<pack>/${KINDS[kind].dir}/` : `${ROOTS.boot.dir}/${KINDS[kind].dir}/`;
    return { problem: `not a ${what} here: ${what} files live under ${homes} -- move it there` };
  }
  return undefined;
}

/**
 * The key a source's export will have, worked out before it exists: the twin
 * of its first export (named `as`, when its record says). Undefined when its kind does not key that extension.
 */
export function exportKey(sourcePath: string, to: readonly string[], as?: string): string | undefined {
  const first = exportPaths(sourcePath, to, as)[0];
  return first === undefined ? undefined : keyOf(first);
}

/** The dev server's URL for a file under the project root: unhashed, so it serves the new bytes. */
export function devUrl(path: string): string {
  return '/' + norm(path);
}

// ---------------------------------------------------------------- one stem, one source

export interface ConflictSource {
  path: string;
  /** Its export paths. */
  exports: readonly string[];
  /** The key of its first export, if its kind keys it. */
  key?: string;
  /** Out of the build (its record says `"include": false`): it ships nothing, so it shares nothing. */
  excluded?: boolean;
}

export interface ConflictLoose {
  path: string;
  key?: string;
}

/**
 * Which files are `conflict` (§2, "One stem, one source"): two sources whose
 * exports would share a path or a key, or a source whose key a loose file in
 * the twin has. Only sources and loose files come in: a part, an `_` name, and
 * a file its kind does not key never are -- nor a source out of the build
 * (`excluded`), which ships nothing: unticking one of two is how a conflict is
 * resolved. Every file named gets its reason.
 */
export function conflicts(sources: readonly ConflictSource[], loose: readonly ConflictLoose[]): Map<string, string> {
  const out = new Map<string, string>();
  const byExport = new Map<string, string[]>();
  const byKey = new Map<string, string[]>();
  const add = (map: Map<string, string[]>, at: string, path: string): void => {
    const list = map.get(at) ?? [];
    if (!list.includes(path)) list.push(path);
    map.set(at, list);
  };
  for (const s of sources) {
    if (s.excluded) continue;
    for (const e of s.exports) add(byExport, e, s.path);
    if (s.key !== undefined) add(byKey, s.key, s.path);
  }
  for (const [at, paths] of byExport) {
    if (paths.length < 2) continue;
    for (const p of paths) {
      const others = paths.filter((o) => o !== p).map(baseName);
      out.set(p, `${baseName(p)} and ${others.join(', ')} would both ship as ${at}: keep one`);
    }
  }
  for (const [key, paths] of byKey) {
    if (paths.length < 2) continue;
    for (const p of paths) {
      if (out.has(p)) continue;
      const others = paths.filter((o) => o !== p).map(baseName);
      out.set(p, `${baseName(p)} and ${others.join(', ')} would both be the key ${key}: keep one`);
    }
  }
  for (const l of loose) {
    if (l.key === undefined) continue;
    const owners = byKey.get(l.key);
    if (!owners) continue;
    for (const p of owners) {
      if (!out.has(p)) out.set(p, `${baseName(l.path)}, already in ${dirName(l.path)}, has the key ${l.key} too: keep one`);
    }
    out.set(l.path, `${owners.map(baseName).join(', ')} would ship as the key ${l.key} too: keep one`);
  }
  return out;
}

// ---------------------------------------------------------------- names

/** What no name here holds: what a file system or a URL cannot carry safely, and control characters. */
const UNSAFE = /[/\\:*?"<>|#%\u0000-\u001f\u007f]/;
/** The same, every one, for `suggestName` to take out. */
const UNSAFE_ALL = /[/\\:*?"<>|#%\u0000-\u001f\u007f]+/g;
/** A file's extension: lowercase letters and digits -- the globs are case-sensitive, and list them lowercase. */
const EXT = /^[a-z0-9]+$/;

export type NameCheck = { ok: true; note?: string } | Refusal;

export interface NameContext {
  /** A folder's name, not a file's: no extension. */
  folder?: boolean;
  /** The names already in the folder. */
  siblings?: Iterable<string>;
  /** The names in its twin. */
  twinSiblings?: Iterable<string>;
}

/**
 * Every name the tool or the pipeline makes, or an import is given (§2,
 * "Names"): **any case, spaces too** -- `Big Crate.glb` -- since a key is the
 * path lowercased (`caseKey`), never the name as written. Refused: an empty
 * name; `/ \ : * ? " < > | # %` and control characters, which a file system
 * or a URL cannot carry safely; a space or a dot at either end; a second dot
 * (one, before the extension: a record is `<stem>.export.json`), and an
 * extension that is not lowercase letters and digits (the globs list them
 * so); a name not in Unicode NFC (macOS may give one decomposed: the
 * suggestion is the same name composed). A leading `_` is allowed and means
 * "will not ship", as ever. A folder the same, with no dot at all. **No name
 * that is another in the folder or its twin but for case** (`caseKey`): one
 * key, two files, and the live host is case-sensitive. Never a record's name.
 * A refusal carries a suggestion where one is different.
 */
export function validName(name: string, context: NameContext = {}): NameCheck {
  const folder = context.folder === true;
  const suggested = suggestName(name, folder);
  const refuse = (refused: string): Refusal => (suggested !== name ? { refused, suggested } : { refused });
  if (name === '' || name === '.' || name === '..' || /[/\\\0]/.test(name)) return refuse('a name is one path component, not empty');
  if (ignored(name)) return refuse(`${name} is the OS's or an art tool's leftover, never imported`);
  if (!folder && isRecordName(name)) return { refused: `${name} is the pipeline's own: options are set through the tool, not imported` };
  // `*.local` (and `*.local.json`, two dots, refused below): this machine's own settings' names -- guarded from Claude's
  // writes, never served by the dev server (`fs-deny.ts`) -- never an asset's.
  if (!folder && /\.local$/i.test(name)) return refuse(`${name} is named as this machine's own settings are (*.local): never an asset`);
  if (UNSAFE.test(name)) return refuse('a name holds no / \\ : * ? " < > | # % or control characters');
  if (name !== name.trim()) return refuse('a name starts and ends with something other than a space');
  if (name.normalize('NFC') !== name) return refuse('a name is written composed (Unicode NFC), as typed');
  if (folder) {
    if (name.includes('.')) return refuse('a folder name has no dot');
  } else {
    const dot = name.indexOf('.');
    if (dot <= (name.startsWith('_') ? 1 : 0) || dot !== name.lastIndexOf('.')) return refuse('a name has one dot, before its extension');
    if (!EXT.test(name.slice(dot + 1))) return refuse('an extension is lowercase letters and digits');
    if (name.slice(0, dot) !== name.slice(0, dot).trim()) return refuse('a name has no space before its extension');
  }
  const key = caseKey(name);
  for (const list of [context.siblings, context.twinSiblings]) {
    if (!list) continue;
    for (const other of list) {
      if (other !== name && caseKey(other) === key) {
        return { refused: `${name} is ${other} but for case: one key, and two files to the live host` };
      }
    }
  }
  return name.startsWith('_') ? { ok: true, note: 'will not ship' } : { ok: true };
}

/**
 * Any name made valid -- total: whatever comes in, `validName` takes what comes
 * out. Its case and spaces kept; Unicode composed (NFC); each run of what no
 * name holds (`/ \ : * ? " < > | # %`, control characters) and every dot but
 * the extension's one `-`; spaces, dashes and `~` trimmed at the ends, a leading
 * `_` kept: `Crate_Final v2.FBX` is `Crate_Final v2.fbx`, `a:b?.png` is
 * `a-b.png`. The extension is what follows the last dot, a leading one too
 * (`.png` is `file.png`, `_.png` `_file.png`), lowercase letters and digits;
 * a stem with nothing left is `file` (`folder`); a name with no extension
 * left gets `.bin`, since every file name here has one. A name the OS's
 * leavings or the pipeline's own records would take (`a.tmp`, `export.json`)
 * is moved off them: `a-tmp.bin`, `export-file.json`.
 */
export function suggestName(name: string, folder = false): string {
  const composed = name.normalize('NFC');
  const underscore = composed.startsWith('_');
  let stem = underscore ? composed.slice(1) : composed;
  let ext = '';
  if (!folder) {
    const dot = stem.lastIndexOf('.');
    if (dot >= 0) {
      ext = stem.slice(dot + 1).toLowerCase().replace(/[^a-z0-9]/g, '');
      stem = stem.slice(0, dot);
    }
  }
  stem = stem
    .replace(UNSAFE_ALL, '-')
    .replace(/\.+/g, '-')
    .replace(/^[\s~-]+|[\s~-]+$/g, '');
  if (stem.replace(/^_+/, '') === '') stem += folder ? 'folder' : 'file';
  const lead = underscore ? '_' : '';
  if (folder) return lead + stem;
  if (ext === '') ext = 'bin';
  let out = `${lead}${stem}.${ext}`;
  if (ignored(out)) out = `${lead}${stem}-${ext}.bin`;
  if (isRecordName(out)) out = `${lead}${stem}-file.${ext}`;
  if (ext === 'local') out = `${lead}${stem}-local.bin`;
  return out;
}

// ---------------------------------------------------------------- the trash

/** The folder of the slot automatic exports keep one previous export in (§6). */
export const AUTO_SLOT = 'auto';

/** An ISO time to the second, `2026-10-04T09:00:12Z`: a record's `built.at`, and what a slot is named for. */
export function isoSeconds(at: Date): string {
  return at.toISOString().replace(/\.\d+Z$/, 'Z');
}

/** A slot's name: an ISO time to the second, `-` for `:` (`2026-10-04T09-00-12Z`). */
export function slotName(at: Date): string {
  return isoSeconds(at).split(':').join('-');
}

/** The time a slot's name says, or undefined for the auto slot or a name that is not one. */
export function slotTime(slot: string): Date | undefined {
  const m = /^(\d{4}-\d\d-\d\d)T(\d\d)-(\d\d)-(\d\d)Z(?:-\d+)?$/.exec(slot);
  return m ? new Date(`${m[1]}T${m[2]}:${m[3]}:${m[4]}Z`) : undefined;
}

/** Where a project path goes in a slot. */
export function trashPath(slot: string, path: string): string {
  return joinPath(TRASH, slot, norm(path));
}

/** A path in the trash, as its slot and the path it had. */
export function fromTrash(path: string): { slot: string; path: string } | undefined {
  const p = norm(path);
  if (!under(p, TRASH)) return undefined;
  const rest = p.slice(TRASH.length + 1);
  const slash = rest.indexOf('/');
  if (slash <= 0) return undefined;
  return { slot: rest.slice(0, slash), path: rest.slice(slash + 1) };
}

/**
 * The stem a file's family is known by: its own, with a leading `_` (an
 * intermediate) and `.export` (a record) taken off. `_crate.glb`,
 * `crate.export.json`, `crate.lua` and `crate.glb` are all `crate`.
 */
export function familyStem(name: string): string {
  const record = recordStem(name);
  if (record !== undefined && record !== '') return record;
  const { stem } = splitName(name);
  return stem.startsWith('_') ? stem.slice(1) : stem;
}

/**
 * A family member under the number `n` (§6, restoring onto a taken name):
 * `crate.lua` is `crate-2.lua`, `_crate.glb` `_crate-2.glb`,
 * `crate.export.json` `crate-2.export.json`. `n` of 1 or less is the name itself.
 */
export function numbered(path: string, n: number): string {
  if (n <= 1) return norm(path);
  const p = norm(path);
  const name = baseName(p);
  const dir = dirName(p);
  const stem = familyStem(name);
  const rest = name.slice(name.indexOf(stem) + stem.length);
  const lead = name.startsWith('_') ? '_' : '';
  return joinPath(dir, `${lead}${stem}-${n}${rest}`);
}

// ---------------------------------------------------------------- what hotUpdate does

/**
 * Vite's `hotUpdate`, decided from the file alone and the one `expected` entry
 * the hook looked up (§5's table, first matching row). `pass` false means the
 * hook returns `[]`; true, `undefined` (Vite's own modules, as ever) -- but
 * with `globsOnly`, Vite's set less the file's own modules: a file a glob takes
 * (a level's too), created or removed. Its own `?url` node outlives a delete in
 * Vite's graph, and once `globs.ts` was read again without it, it has no
 * importer: a dead end to `propagateUpdate`, which reloads the page -- on the
 * file's next `create` (a restore, an undo, a same-name import) or a later
 * `delete` in a burst. What must update is the glob file `vite:import-glob`
 * added. A beside-image's `beside` names its folder: the hook makes one
 * `reload` for every model export the index has there.
 */
export function hotUpdateFor(file: string, type: WatchType, entry: Expected | undefined): HotDecision {
  const p = norm(file);
  const where = locate(p);
  // Under AssetsSource/ or packs/: the index has it, and the packs re-zip.
  if (where && (where.root === 'source' || where.root === 'packs')) return { pass: false };
  const inKind = where !== undefined && where.root === 'boot' && where.kind !== undefined && where.under !== undefined;
  // A level or a prefab: its glob is its own module's (`level-globs.ts`, `prefab-globs.ts`), which accepts it.
  const levels = inKind && isDataKind(where.kind!);
  const take = inKind && !levels && globbed(p);
  const reloadOf = (): HotDecision => {
    if (!take || !where || !where.kind || !where.under) return { pass: false };
    const kind = where.kind;
    const { ext } = splitName(baseName(where.under));
    const url = devUrl(p);
    const def = KINDS[kind] as { ext: readonly string[]; beside?: readonly string[] };
    if (def.ext.includes(ext)) return { pass: false, reload: { kind, key: where.under.slice(0, -ext.length - 1), url } };
    if (kind === 'atlases') {
      // The `.json` of an atlas: the atlas is what reloads.
      return { pass: false, reload: { kind, key: where.under.slice(0, -ext.length - 1), url } };
    }
    if (kind === 'models') {
      const beside: BesideReload = { kind: 'models', folder: dirName(where.under), image: where.under, url };
      return { pass: false, beside };
    }
    return { pass: false };
  };
  // A level or a prefab the server wrote itself (the Assets tool's New prefab, a pool's numbers): the page takes it
  // all the same -- its module accepts it, and a prefab compiles live (Docs/prefabs.md §7).
  if (levels && entry) return type === 'update' ? { pass: true } : { pass: true, globsOnly: true };
  if (entry && entry.replaced) return type === 'delete' ? { pass: false } : reloadOf();
  if (entry && !entry.replaced && type === 'update') return { pass: false };
  if (take) return type === 'update' ? reloadOf() : { pass: true, globsOnly: true };
  if (inKind && !levels) return { pass: false };
  if (levels && type !== 'update') return { pass: true, globsOnly: true };
  return { pass: true };
}

/**
 * A source's record's `"as"` for the name its export should ship as (`PUT export-as`'s `as`): null -- no `as`, the
 * source's own stem -- for its stem in any case, or for `null`; else the name. What the Assets panel's Rename the
 * export… and `asset_options`' `as` both send.
 */
export function exportAsValue(source: string, name: string | null): string | null {
  return name === null || caseKey(name) === caseKey(splitName(baseName(source)).stem) ? null : name;
}
