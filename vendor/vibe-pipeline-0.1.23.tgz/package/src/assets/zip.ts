/**
 * A zip's central directory, and one entry out of it (Docs/assets.md §3, the
 * `kra` step; §4, `stats/image.ts`): a Krita file is a zip, and its own
 * composite, `mergedimage.png`, is all the pipeline wants from it.
 *
 * Node's side of what the engine's `assets/zip.ts` does in the browser, which inflates
 * with `DecompressionStream` and which the pipeline does not import (§4: nothing
 * in the pipeline reaches into the engine but `@vibe/engine/testing` and `/case-key`). Here it
 * is `node:zlib`, and the file is read at offsets -- the end record, the
 * central directory, one entry -- never whole: a 300 MB `.kra` costs the bytes
 * of its composite.
 *
 * Only what a `.kra` needs: store (0) and deflate (8), no encryption, no Zip64,
 * no spanning; anything else throws by name. Every whole entry's CRC is checked.
 *
 * Nothing happens at module level: every read is inside a function.
 */
import { open, type FileHandle } from 'node:fs/promises';
import { createInflateRaw, crc32, inflateRawSync } from 'node:zlib';
import { readAt } from './fs.ts';

const EOCD_SIG = 0x06054b50;
const CENTRAL_SIG = 0x02014b50;
const LOCAL_SIG = 0x04034b50;

/** The end record plus the longest comment it may carry. */
const EOCD_MAX = 22 + 0xffff;

/** One file in the central directory. */
export interface ZipEntry {
  name: string;
  /** 0 stored, 8 deflated. */
  method: number;
  crc: number;
  compressedSize: number;
  size: number;
  /** Where its local header starts. */
  localOffset: number;
}

async function entriesOf(file: FileHandle, label: string): Promise<ZipEntry[]> {
  const { size } = await file.stat();
  const tailLength = Math.min(size, EOCD_MAX);
  const tail = await readAt(file, size - tailLength, tailLength);
  let eocd = -1;
  for (let i = tail.length - 22; i >= 0; i--) {
    if (tail.readUInt32LE(i) === EOCD_SIG) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error(`${label}: not a zip file (no end-of-central-directory record)`);
  const count = tail.readUInt16LE(eocd + 10);
  const length = tail.readUInt32LE(eocd + 12);
  const offset = tail.readUInt32LE(eocd + 16);
  if (count === 0xffff || offset === 0xffffffff || length === 0xffffffff) throw new Error(`${label}: zip64 archives are not supported`);
  const directory = await readAt(file, offset, length);
  const entries: ZipEntry[] = [];
  let at = 0;
  for (let i = 0; i < count; i++) {
    if (at + 46 > directory.length || directory.readUInt32LE(at) !== CENTRAL_SIG) throw new Error(`${label}: corrupt zip (bad central directory entry)`);
    const nameLength = directory.readUInt16LE(at + 28);
    const extraLength = directory.readUInt16LE(at + 30);
    const commentLength = directory.readUInt16LE(at + 32);
    entries.push({
      name: directory.subarray(at + 46, at + 46 + nameLength).toString('utf8'),
      method: directory.readUInt16LE(at + 10),
      crc: directory.readUInt32LE(at + 16),
      compressedSize: directory.readUInt32LE(at + 20),
      size: directory.readUInt32LE(at + 24),
      localOffset: directory.readUInt32LE(at + 42),
    });
    at += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}

/** Where an entry's data starts: its local header repeats the name and may carry other extra data. */
async function dataStart(file: FileHandle, entry: ZipEntry, label: string): Promise<number> {
  const header = await readAt(file, entry.localOffset, 30);
  if (header.length < 30 || header.readUInt32LE(0) !== LOCAL_SIG) throw new Error(`${label}: corrupt zip (bad local header for ${entry.name})`);
  return entry.localOffset + 30 + header.readUInt16LE(26) + header.readUInt16LE(28);
}

async function find(file: FileHandle, absPath: string, name: string): Promise<ZipEntry> {
  const entry = (await entriesOf(file, absPath)).find((e) => e.name === name);
  if (!entry) throw new Error(`${absPath}: no ${name} in the zip`);
  if (entry.method !== 0 && entry.method !== 8) throw new Error(`${absPath}: ${name} uses zip compression method ${entry.method}, not store or deflate`);
  return entry;
}

/** Every entry of the central directory: the end record and the directory read, nothing else. */
export async function zipEntries(absPath: string): Promise<ZipEntry[]> {
  const file = await open(absPath, 'r');
  try {
    return await entriesOf(file, absPath);
  } finally {
    await file.close();
  }
}

/** One entry, inflated and its CRC checked. Throws naming the entry when it is not there or not readable. */
export async function readZipEntry(absPath: string, name: string): Promise<Buffer> {
  const file = await open(absPath, 'r');
  try {
    const entry = await find(file, absPath, name);
    const raw = await readAt(file, await dataStart(file, entry, absPath), entry.compressedSize);
    if (raw.length !== entry.compressedSize) throw new Error(`${absPath}: ${name} is cut short`);
    const data = entry.method === 0 ? raw : inflateRawSync(raw);
    if (data.length !== entry.size) throw new Error(`${absPath}: ${name} should be ${entry.size} bytes, is ${data.length}`);
    if (crc32(data) >>> 0 !== entry.crc >>> 0) throw new Error(`${absPath}: ${name} fails its CRC check`);
    return data;
  } finally {
    await file.close();
  }
}

/**
 * The first `bytes` of an entry, uncompressed: a stored entry read for those
 * bytes alone, a deflated one inflated a piece at a time until there are enough
 * -- a PNG's header from a `.kra`'s composite without inflating the picture.
 * Shorter when the entry is.
 */
export async function readZipEntryHead(absPath: string, name: string, bytes: number): Promise<Buffer> {
  const file = await open(absPath, 'r');
  try {
    const entry = await find(file, absPath, name);
    const start = await dataStart(file, entry, absPath);
    if (entry.method === 0) return await readAt(file, start, Math.min(bytes, entry.compressedSize));
    const want = Math.min(bytes, entry.size);
    const inflate = createInflateRaw();
    const out: Buffer[] = [];
    let have = 0;
    let failure: Error | undefined;
    inflate.on('data', (chunk: Buffer) => {
      out.push(chunk);
      have += chunk.length;
    });
    inflate.on('error', (err: Error) => {
      failure = err;
    });
    const PIECE = 4096;
    for (let read = 0; read < entry.compressedSize && have < want && !failure; read += PIECE) {
      const piece = await readAt(file, start + read, Math.min(PIECE, entry.compressedSize - read));
      if (piece.length === 0) break;
      // The write's callback comes once the piece is inflated and its `data` handed over (measured:
      // a 64 KB head of a 1 MB incompressible entry reads 17 pieces with an extra tick here or without).
      await new Promise<void>((resolve) => inflate.write(piece, () => resolve()));
    }
    inflate.destroy();
    if (failure && have < want) throw new Error(`${absPath}: ${name} does not inflate: ${failure.message}`);
    return Buffer.concat(out).subarray(0, want);
  } finally {
    await file.close();
  }
}
