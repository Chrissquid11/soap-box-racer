/**
 * The index: the pipeline's picture of the three roots (Docs/assets.md §4,
 * "The index"). A `Map` of every path to its entry -- what it is (`role`), its
 * kind and key, a source's exports, parts and status -- rebuilt from the disk
 * at every start, with no database: the files and the committed records are
 * the truth.
 *
 * - **The walk** reads every folder and stats every file, at most 32 at once,
 *   and opens nothing but files of 200 bytes or less, to find an unfetched LFS
 *   pointer without reading anything big -- and the records, `<stem>.export.json`,
 *   small as they are, for `"include": false`: a source out of the build is
 *   known before it is hashed, and takes part in no conflict. A second walk ("Check again")
 *   starts from nothing: no name, timer or diff of the first is kept. It runs
 *   in turn with the settles, so none reads a half-built index.
 * - **Statuses settle afterwards**: sources are hashed two at a time (the
 *   CLI: a lane a core), model sources first (they own the images they name),
 *   through the hashes cache -- a warm start opens no file. Until its turn a
 *   source is `checking`, and so is an image a source not yet read might name.
 *   An owner tried and not readable for its names -- an LFS pointer, a `.gltf`
 *   that is not JSON -- counts as read: it names nothing that can be known, and
 *   its folder settles.
 * - **Its own writes are not news**: whatever the pipeline writes is put in
 *   `expected` first, with the stat it will have, and the first watch event
 *   matching it is consumed silently. An entry is dropped 2 s after its write;
 *   `writes` keeps it those 2 s whether consumed or not, for Vite's
 *   `hotUpdate` (§5), which hears the same events in its own order.
 * - **A file still being written is not finished**: every event updates the
 *   entry at once, but nothing is hashed until it has been quiet for 500 ms.
 *   A source's parts stay its parts while it changes: what it names is read
 *   again once it is quiet, not forgotten at the first event -- and a source
 *   that no longer parses (a `.gltf` saved mid-edit) keeps the parts it had,
 *   `failed` until it parses again. A part with parts of its own (an `.obj`'s
 *   `.mtl`) is read again for its names once it changed.
 * - **The disk has the last word**: the look once a file is quiet stats it
 *   again, so whatever order the events' reads finished in -- an `add` whose
 *   read ends after its `unlink`, a folder removed while its `addDir` was read
 *   -- an entry whose file is gone goes, and a file there gets its entry.
 *   `onEvent` never rejects: what fails is told to `onError`.
 * - **Every change has a number**: `seq` counts them, the last thousand diffs
 *   are kept, and `since(seq)` answers the diff -- or the whole tree, for a
 *   client further behind.
 * - **The Trash root is read from disk**, not watched: at the start and after
 *   each of the pipeline's own writes there. It goes to a client whole, on the
 *   tree and on every diff within which it was re-read and found changed.
 *
 * **Linear in the tree.** A `git pull` or a Finder copy is hundreds of watch
 * events into thousands of files, so nothing here looks at every entry per
 * entry: a folder index (`byDir`, kept by `put` and `drop`) answers what is in
 * a folder (`inFolder`), and a key index (`byKey`, the same) which paths give
 * a key (`withKey`); what a path is (`recipeFor` and its kin) is worked out once per
 * path and kept while the path is an entry -- an event for a path that never
 * becomes one (`.trash/`, `src/assets/*.ts`) keeps nothing; a source's parts
 * once per classify; whether an image might be named, by a count per folder.
 * Events are coalesced -- one classify and one commit per macrotask, however
 * many arrived -- and so are the settles after the quiet. A commit compares
 * only the entries touched since the last, by a fingerprint, but after a
 * classify, which may touch any.
 *
 * **In the build** (§2): a source whose record says `"include": false` is
 * `excluded` -- never hashed for its status, never exported, in no conflict
 * and no key's list for one; its parts, its intermediate and its record are
 * out with it (`Entry.included`), a loose file in always, an `_` name out. A
 * file at its export path is no export of it then: a loose file, delivered by
 * hand. A source the record takes out by a watch event -- a hand edit, a pull
 * -- has the export it had moved to the auto slot as it settles; the tool's
 * tick (`PUT sidecar`) moves it to a slot of its own first, for its undo.
 *
 * Background work (a settle after a watch event) never takes the server down
 * and never fails silently: it is told to `onError`. `settled()` resolves once
 * everything started has finished.
 *
 * The CLI uses it without a watcher: walk, settle, export. The dev server
 * (`server.ts`) feeds it Vite's watch events through `onEvent`, and hears
 * through `onQuiet` which sources a watch event moved once they settled --
 * what auto-export reads (§4).
 */
import { open, readdir, readFile, stat } from 'node:fs/promises';
import { isAbsolute, join, relative } from 'node:path';
import type { Diff, Entry, ExportRecord, Expected, Options, Status, ToolLook, TrashSlot, TreeAnswer } from './api-types.ts';
import { REAL_CLOCK, type Clock, type TimerHandle } from './clock.ts';
import type { Runs } from './export.ts';
import { code, readAt, sha1 } from './fs.ts';
import { HashCache, hashOf, type Hashed } from './hashes.ts';
import { ROOTS } from './kinds.ts';
import { IMPORT_EXT, PART_DEPS, type Deps } from './parts.ts';
import {
  AUTO_SLOT,
  baseName,
  conflicts as findConflicts,
  dirName,
  exportKey,
  exportPaths,
  folderRecordPath,
  globbed,
  ignored,
  intermediatePath,
  isRecordName,
  isoSeconds,
  joinPath,
  keyOf,
  locate,
  norm,
  ownRecordPath,
  recordPath,
  recordStem,
  resolveRel,
  resolveTo,
  splitName,
  strayPrefab,
  twin,
  under,
  underscored,
  type ConflictLoose,
  type ConflictSource,
  type Where,
} from './paths.ts';
import { MODEL_SOURCE_EXT, isFound, recipeFor, type Found, type RecipeAnswer } from './recipes.ts';
import { excludedBy, exportAsIn, readFolderDefaults, sourceOptions, type RecordRead } from './record.ts';
import { POINTER_MAX, isPointer } from './stats/lfs.ts';
import { EXCLUDED, statusOf, usesIntermediate, type PartState, type StatusResult } from './status.ts';
import { stepInfo } from './steps/index.ts';
import { prune, readTrash, toTrash } from './trash.ts';
import { isSidecar } from './uid.ts';
import { caseKey } from '@vibe/engine/case-key';

/** The model files a script may import (`parts.ts`), for a lookup. */
const IMPORTS: ReadonlySet<string> = new Set(IMPORT_EXT);

export interface CatalogOptions {
  /** The project root, absolute. */
  root: string;
  /**
   * The data kinds not in the table -- the engine's own (`physics-materials`) and a project's -- by their folder under
   * `src/assets/` (relative) and extensions: a file of one of them listed too, a loose file with its key, so the Assets
   * panel shows and edits them. Any other file there (a README) is not.
   */
  dataKinds?: readonly { dir: string; ext: readonly string[] }[];
  hashes?: HashCache;
  /** This machine's tools; undefined until looked for (and in `--check`). */
  tools?: ReadonlyMap<string, ToolLook>;
  /** npm packages' versions. */
  npm?: Readonly<Record<string, string>>;
  /** Who does a browser step: a connected tab, none, or this is the CLI. */
  browser?: 'tab' | 'none' | 'cli';
  /** Read every file; trust no cache (`--check`). */
  check?: boolean;
  runs?: Runs;
  /** Sources read at once while settling: 2 in the dev server (§4), the machine's cores in the CLI. */
  lanes?: number;
  /** A file is hashed once unchanged this long. Default 500. */
  quietMs?: number;
  /** An expected write's entry lives this long. Default 2000. */
  expectMs?: number;
  /** Diffs kept for `since`. Default 1000. */
  keepDiffs?: number;
  clock?: Clock;
  /** Told what changed, once per commit. */
  onChange?: (diff: Diff) => void;
  /** Told what failed in the background: a settle after a watch event, a folder that cannot be read. */
  onError?: (err: Error) => void;
  /**
   * Told, once they have settled, the paths a watch event changed that went
   * quiet together, each with the sources it moved: what auto-export reads
   * (§4). Never for the pipeline's own writes, which are not watch events.
   */
  onQuiet?: (moved: ReadonlyMap<string, readonly string[]>) => void;
}

/** Everything about one source, as `inspect` found it: what an export runs from. */
export interface SourceState extends StatusResult {
  source: string;
  found: Found;
  options: Options;
  /** Where its record is: its own (`<name>.export.json`) when it has one, else its stem's (`recordOf`). */
  recordPath: string;
  record?: ExportRecord;
  /** Its hash, and its parts', by path relative to the project root. */
  hash?: string;
  parts: string[];
  partHashes: Record<string, string>;
  exports: string[];
  /** The extensions of `to`, `same` resolved. */
  to: string[];
  intermediate?: string;
  intermediateHash?: string;
  /** The last attempt failed with these same inputs. */
  lastRunFailed: boolean;
}

/** What a source named, as its scanner found it: paths, or names to match (`search`). */
interface Named {
  names: string[];
  search: boolean;
}

/** One kept diff: what changed in one commit. */
interface DiffStep {
  seq: number;
  added: Map<string, Entry>;
  removed: Set<string>;
  updated: Map<string, Entry>;
}

/** What a path is, from the path alone: worked out once per path. */
interface PathInfo {
  where: Where | undefined;
  recipe: RecipeAnswer;
  /** A source's exports, if its recipe was found. */
  exports: string[];
  /** The key of its first export (a source), or its own (a shipped file). */
  key: string | undefined;
  /** In the generated globs: a shipped file the build takes. */
  globbed: boolean;
}

/** A file's hash for this run, with the stat it was taken at. */
interface Memo {
  mtime: number;
  size: number;
  withParts: boolean;
  hashed: Hashed;
}

/** Lowercase file name -> paths relative to a folder: its files, and those of a `textures/` under it. */
type FolderNames = Map<string, string[]>;

const PEEK_LIMIT = 32;

/** At most `limit` of `items` through `fn` at once. */
async function pool<T>(items: readonly T[], limit: number, fn: (item: T) => Promise<void>): Promise<void> {
  let next = 0;
  const lanes = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) await fn(items[next++]!);
  });
  await Promise.all(lanes);
}

/** Everything an entry says, as one string: two entries that print the same are the same to a client. */
function fingerprint(e: Entry): string {
  const list = (a: readonly string[] | undefined): string => (a === undefined ? '\u0001' : a.join('\n'));
  const opt = (v: string | number | boolean | undefined): string => (v === undefined ? '\u0001' : String(v));
  return [e.role, opt(e.kind), opt(e.key), e.size, e.mtime, opt(e.hash), opt(e.status), opt(e.reason), opt(e.note), list(e.exports), opt(e.source), list(e.parts), list(e.owners), opt(e.pointer), opt(e.included)].join('\0');
}

/** An entry a diff can hold: its own arrays, so the index changing it later changes nothing sent. */
function copyEntry(e: Entry): Entry {
  return { ...e, ...(e.exports ? { exports: [...e.exports] } : {}), ...(e.parts ? { parts: [...e.parts] } : {}), ...(e.owners ? { owners: [...e.owners] } : {}) };
}

const byPath = (a: string, b: string): number => (a < b ? -1 : a > b ? 1 : 0);

export class Catalog {
  readonly root: string;
  readonly hashes: HashCache;
  tools: ReadonlyMap<string, ToolLook> | undefined;
  npm: Readonly<Record<string, string>>;
  browser: 'tab' | 'none' | 'cli';
  readonly check: boolean;
  runs: Runs | undefined;
  readonly entries = new Map<string, Entry>();
  /** The pipeline's own writes, waiting for their watch events. */
  readonly expected = new Map<string, Expected>();
  /**
   * The same writes for their whole `expectMs`, consumed or not: what Vite's
   * `hotUpdate` looks a file up in (§5) -- it hears the events in its own
   * order, and a rename over a file may be two of them (`unlink`, `add`).
   */
  readonly writes = new Map<string, Expected>();
  /** The Trash root, as last read from disk. */
  trash: TrashSlot[] = [];
  /** What the 30-day prune removed, when it removed anything: for the Trash root's line. */
  pruned: { count: number; at: string } | undefined;
  seq = 0;
  private readonly lanes: number;
  private readonly quietMs: number;
  private readonly expectMs: number;
  private readonly keepDiffs: number;
  private readonly clock: Clock;
  private readonly onChange: ((diff: Diff) => void) | undefined;
  private readonly onError: (err: Error) => void;
  private readonly onQuiet: CatalogOptions['onQuiet'];
  private readonly dataKinds: readonly { dir: string; ext: readonly string[] }[];

  /** Folder -> the paths in it the index has. */
  private readonly byDir = new Map<string, Set<string>>();
  /** Key -> the paths whose path gives it (`infoOf(path).key`): what a second source for a key is looked up in. */
  private readonly byKey = new Map<string, Set<string>>();
  /** What each path is, by path: pure in the path, so kept while the path is. */
  private readonly info = new Map<string, PathInfo>();
  private readonly named = new Map<string, Named>();
  private readonly memo = new Map<string, Memo>();
  /** Folder `export.json` read, with the stat the index had for it. */
  private readonly folderReads = new Map<string, { mtime: number; size: number; read: Promise<RecordRead> }>();
  private readonly changedAt = new Map<string, number>();
  private readonly timers = new Map<string, TimerHandle>();
  private conflictReasons = new Map<string, string>();
  /** The records that say `"include": false`, as read with their entry: their sources are out of the build. */
  private readonly excludedRecords = new Set<string>();
  /** The records that name their export (`"as"`, Docs/asset-ids.md §1, rule 8), as read with their entry: the stem each says. */
  private readonly recordAs = new Map<string, string>();
  /** The sources out of the build at the last classify: one newly out is told by it. */
  private excludedSources = new Set<string>();
  /** The exports a source had as a watch event took it out of the build: to the auto slot as it settles. */
  private readonly leftBehind = new Set<string>();

  private diffs: DiffStep[] = [];
  /** The commit within which the Trash was last re-read and found changed: a diff over it carries the slots. */
  private trashSeq = 0;
  /** Re-read and changed since the last commit. */
  private trashMoved = false;
  /** Each entry's fingerprint at the last commit. */
  private readonly printed = new Map<string, string>();
  /** Paths touched since the last commit; all of them after a classify. */
  private readonly dirty = new Set<string>();
  private dirtyAll = false;

  /** Watch events waiting for this macrotask's classify, and the sources each moved before its entry went. */
  private readonly pending = new Set<string>();
  private readonly movedBefore = new Map<string, Set<string>>();
  private flushing: Promise<void> | undefined;
  /** Paths quiet for `quietMs`, waiting for one settle. */
  private readonly quietReady = new Set<string>();
  private quieting: Promise<void> | undefined;
  /** Serial work -- settles, a refresh, a learn -- one at a time: two would read and move the same files. */
  private settling: Promise<void> = Promise.resolve();
  /** Everything started and not finished, for `settled()`. */
  private readonly tasks = new Set<Promise<unknown>>();

  constructor(options: CatalogOptions) {
    this.root = options.root;
    this.hashes = options.hashes ?? new HashCache(options.root);
    this.tools = options.tools;
    this.npm = options.npm ?? {};
    this.browser = options.browser ?? 'cli';
    this.check = options.check === true;
    this.runs = options.runs;
    this.lanes = Math.max(1, options.lanes ?? 2);
    this.quietMs = options.quietMs ?? 500;
    this.expectMs = options.expectMs ?? 2000;
    this.keepDiffs = Math.max(1, options.keepDiffs ?? 1000);
    this.clock = options.clock ?? REAL_CLOCK;
    this.onChange = options.onChange;
    this.onError = options.onError ?? ((err) => console.error(`[assets] ${err.message}`));
    this.onQuiet = options.onQuiet;
    this.dataKinds = options.dataKinds ?? [];
  }

  // ---------------------------------------------------------------- the walk

  /**
   * Every file in the roots, stat'ed; pointers peeked. Replaces whatever the
   * index held -- its names, timers, waits and diffs too: after a second walk
   * every client's next diff is a gap, and `since` of any older `seq` is the
   * whole tree. In turn with the settles: one in flight finishes first, and
   * one asked for after reads the new index, never a half-built one.
   */
  walk(): Promise<void> {
    return this.serial(() => this.walkNow());
  }

  private async walkNow(): Promise<void> {
    const again = this.seq > 0;
    this.reset();
    const found: string[] = [];
    let level: string[] = [ROOTS.boot.dir, ROOTS.packs.dir, ROOTS.source.dir];
    while (level.length > 0) {
      const next: string[] = [];
      await pool(level, PEEK_LIMIT, async (dir) => {
        let list;
        try {
          list = await readdir(join(this.root, dir), { withFileTypes: true });
        } catch (err) {
          if (code(err) !== 'ENOENT' && code(err) !== 'ENOTDIR') this.onError(err as Error);
          return;
        }
        for (const d of list) {
          if (ignored(d.name)) continue;
          const path = joinPath(dir, d.name);
          if (d.isDirectory()) next.push(path);
          else if (d.isFile() && this.listed(path)) found.push(path);
        }
      });
      level = next;
    }
    found.sort();
    await pool(found, PEEK_LIMIT, async (path) => {
      const entry = await this.read(path);
      if (entry) this.put(entry);
    });
    this.classify();
    await this.readTrash();
    if (again) this.seq++; // a number no diff covers: the gap every client sees
    this.commit();
    if (again) this.diffs = [];
  }

  /** Everything a walk rebuilds, forgotten. */
  private reset(): void {
    for (const handle of this.timers.values()) this.clock.clearTimeout(handle);
    this.timers.clear();
    for (const map of [this.entries, this.byDir, this.byKey, this.info, this.named, this.memo, this.folderReads, this.changedAt, this.expected, this.writes, this.printed, this.movedBefore]) map.clear();
    for (const set of [this.dirty, this.pending, this.quietReady, this.excludedRecords, this.leftBehind, this.asChanged]) set.clear();
    this.recordAs.clear();
    this.excludedSources = new Set();
    this.conflictReasons = new Map();
    this.dirtyAll = false;
    this.diffs = [];
    this.trashMoved = false;
  }

  /**
   * Is a file in a root one the index lists? Everything under `AssetsSource/`; in
   * a shipping root, only what is in a kind's folder -- `src/assets/` also
   * holds the asset runtime's code.
   */
  listed(path: string): boolean {
    if (path.split('/').some(ignored)) return false;
    // A loose file's `.uid` (Docs/asset-ids.md §1): its uid, beside it -- never an asset of its own, never listed.
    if (isSidecar(path)) return false;
    const where = this.infoOf(path).where;
    if (!where) return false;
    if (where.root === 'source') return true;
    if (where.root === 'boot' && where.kind === undefined && this.dataKindOf(path) !== undefined) return true;
    return where.kind !== undefined && (where.root === 'boot' || where.pack !== undefined);
  }

  /**
   * A file's entry from its stat, a pointer peeked; undefined if it is not
   * there -- also when it goes between the stat and the peek (a rename, a
   * folder dragged in and out): a file gone is no entry, never an error.
   */
  private async read(path: string): Promise<Entry | undefined> {
    let st;
    try {
      st = await stat(join(this.root, path));
    } catch {
      return undefined; // not there (any more): no entry
    }
    if (!st.isFile()) return undefined;
    const where = this.infoOf(path).where!;
    const entry: Entry = { path, root: where.root, role: 'extra', size: st.size, mtime: st.mtimeMs, included: true };
    if (where.kind) entry.kind = where.kind;
    if (st.size <= POINTER_MAX) {
      try {
        if (await this.peek(path)) entry.pointer = true;
      } catch (err) {
        if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') return undefined;
        // There but not readable (EACCES): told, and listed as it stands -- its settle says what is wrong.
        this.onError(err as Error);
      }
    }
    // A source's record, small: does it take its source out of the build? Read with every listing of it.
    // And the stem it names its export `as`, which is where its source's exports go.
    if (where.root === 'source' && recordStem(baseName(path))) {
      let out = false;
      let as: string | undefined;
      try {
        const text = entry.pointer ? undefined : await this.readRecordText(path);
        out = text !== undefined && excludedBy(text);
        as = text !== undefined ? exportAsIn(text) : undefined;
      } catch (err) {
        if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') return undefined;
        this.onError(err as Error);
      }
      if (out) this.excludedRecords.add(path);
      else this.excludedRecords.delete(path);
      if (as !== this.recordAs.get(path)) {
        if (as === undefined) this.recordAs.delete(path);
        else this.recordAs.set(path, as);
        this.asChanged.add(path);
      }
    }
    return entry;
  }

  /** A record's text. Protected: a test watches what is read. */
  protected async readRecordText(path: string): Promise<string> {
    return readFile(join(this.root, path), 'utf8');
  }

  /** Is this small file an LFS pointer? Throws what `open` throws. Protected: a test removes the file under it. */
  protected async peek(path: string): Promise<boolean> {
    const file = await open(join(this.root, path), 'r');
    try {
      return isPointer(await readAt(file, 0, POINTER_MAX));
    } finally {
      await file.close();
    }
  }

  /**
   * A source's record: its own (`<name>.export.json`, `ownRecordPath`) when the index has one, else its stem's.
   * Its own is how one of two sources of one stem has a record apart, and names its export (`"as"`).
   */
  recordOf(source: string): string {
    const own = ownRecordPath(source);
    return this.entries.has(own) ? own : recordPath(source);
  }

  /** Records whose `as` changed, or that came or went, since their sources' exports were worked out: done at `put` and `drop`. */
  private readonly asChanged = new Set<string>();

  /**
   * The sources a record is the record of -- its stem's, or the one it is its own record of -- worked out again
   * (`infoOf`, kept by path) and filed under their new key: their exports and key follow its `as`.
   */
  private reinfo(record: string): void {
    this.asChanged.delete(record);
    const name = baseName(record);
    const stem = recordStem(name);
    if (!stem) return;
    for (const p of [...(this.byDir.get(dirName(record)) ?? [])]) {
      if (p === record || (baseName(p) !== stem && splitName(baseName(p)).stem !== stem)) continue;
      const old = this.info.get(p);
      if (!old) continue;
      if (old.key !== undefined) {
        const keyed = this.byKey.get(old.key);
        keyed?.delete(p);
        if (keyed?.size === 0) this.byKey.delete(old.key);
      }
      this.info.delete(p);
      const { key } = this.infoOf(p, true);
      if (key !== undefined) {
        let keyed = this.byKey.get(key);
        if (!keyed) this.byKey.set(key, (keyed = new Set()));
        keyed.add(p);
      }
      this.dirty.add(p);
    }
  }

  /** An entry in, and in its folder's list and its key's; what its path is kept with it. */
  private put(entry: Entry): void {
    const { key } = this.infoOf(entry.path, true);
    const isNew = !this.entries.has(entry.path);
    if (!this.entries.has(entry.path)) {
      const dir = dirName(entry.path);
      let paths = this.byDir.get(dir);
      if (!paths) this.byDir.set(dir, (paths = new Set()));
      paths.add(entry.path);
      if (key !== undefined) {
        let keyed = this.byKey.get(key);
        if (!keyed) this.byKey.set(key, (keyed = new Set()));
        keyed.add(entry.path);
      }
    }
    this.entries.set(entry.path, entry);
    this.dirty.add(entry.path);
    // A record come, or its `as` changed: its sources' exports are named again.
    if ((isNew && entry.root === 'source' && recordStem(baseName(entry.path))) || this.asChanged.has(entry.path)) this.reinfo(entry.path);
  }

  /** An entry out -- and what was read of it: its names, its hash for this run. False if it was not there. */
  private drop(path: string): boolean {
    if (!this.entries.delete(path)) return false;
    const dir = dirName(path);
    const paths = this.byDir.get(dir);
    paths?.delete(path);
    if (paths?.size === 0) this.byDir.delete(dir);
    const key = this.info.get(path)?.key;
    const keyed = key !== undefined ? this.byKey.get(key) : undefined;
    keyed?.delete(path);
    if (key !== undefined && keyed?.size === 0) this.byKey.delete(key);
    this.dirty.add(path);
    this.named.delete(path);
    this.memo.delete(path);
    this.info.delete(path);
    this.excludedRecords.delete(path);
    // A record gone: its sources' exports are named by their stem again (or by the record left).
    if (recordStem(baseName(path))) {
      this.recordAs.delete(path);
      this.reinfo(path);
    }
    return true;
  }

  // ---------------------------------------------------------------- what each file is

  /**
   * What a path is: where, its recipe, exports and key. Worked out once and
   * kept while the path is an entry (`keep`: `put`'s, about to be one), and
   * dropped with it -- never kept for a path that is not one, so a stream of
   * events for `.trash/` or `src/assets/*.ts` grows nothing.
   */
  private infoOf(path: string, keep = false): PathInfo {
    let info = this.info.get(path);
    if (!info) {
      const where = locate(path);
      const recipe = recipeFor(path);
      if (where?.root === 'source') {
        const found = isFound(recipe);
        // Named by its record's `as` when it says one (rule 8): kept with the path, worked out again by `reinfo` when the record changes.
        const as = found ? this.recordAs.get(this.recordOf(path)) : undefined;
        info = { where, recipe, exports: found ? exportPaths(path, recipe.row.to, as) : [], key: found ? exportKey(path, recipe.row.to, as) : undefined, globbed: false };
      } else if (where?.root === 'boot' && where.kind === undefined && this.dataKindOf(path) !== undefined && !underscored(path)) {
        // A data kind's beside the table's (`dataKinds`): its generated glob ships it, by its path under the kind's folder.
        const under = path.slice(this.dataKindOf(path)!.dir.length + 1);
        info = { where, recipe, exports: [], key: caseKey(under.slice(0, under.lastIndexOf('.'))), globbed: true };
      } else info = { where, recipe, exports: [], key: where ? keyOf(path) : undefined, globbed: where !== undefined && globbed(path) };
      if (keep || this.entries.has(path)) this.info.set(path, info);
    }
    return info;
  }

  /** The data kind beside the table's that `path` is a file of -- under its folder, of one of its extensions -- or undefined. */
  private dataKindOf(path: string): { dir: string; ext: readonly string[] } | undefined {
    const dot = path.lastIndexOf('.');
    const ext = dot > path.lastIndexOf('/') ? path.slice(dot + 1).toLowerCase() : '';
    return this.dataKinds.find((k) => path.startsWith(`${k.dir}/`) && k.ext.includes(ext));
  }

  /** The files of a folder, and of a `textures/` folder under it, by lowercase name: what a `search` scanner's names are matched against. */
  private folderNames(dir: string): FolderNames {
    const out: FolderNames = new Map();
    const add = (folder: string, prefix: string): void => {
      for (const path of this.byDir.get(folder) ?? []) {
        const name = baseName(path);
        const key = name.toLowerCase();
        const list = out.get(key);
        if (list) list.push(prefix + name);
        else out.set(key, [prefix + name]);
      }
    };
    add(dir, '');
    add(joinPath(dir, 'textures'), 'textures/');
    return out;
  }

  /**
   * A source's parts as paths, from what its scanner named: those there, and
   * those named but missing. `names` gives a folder's files by name -- a
   * classify's, worked out once a folder.
   */
  private partsOf(source: string, names: (dir: string) => FolderNames = (dir) => this.folderNames(dir)): { present: string[]; missing: string[] } {
    const named = this.named.get(source);
    if (!named) return { present: [], missing: [] };
    const dir = dirName(source);
    const present = new Set<string>();
    const missing: string[] = [];
    if (named.search) {
      // Case does not matter (an FBX written on Windows names `Robot-Diffuse.PNG`); the file's own spelling comes back.
      const index = names(dir);
      const matched: string[] = [];
      for (const name of named.names) for (const rel of index.get(name.toLowerCase()) ?? []) matched.push(joinPath(dir, rel));
      for (const path of matched.sort(byPath)) if (path !== source) present.add(path);
    } else {
      for (const name of named.names) {
        const path = resolveRel(dir, name);
        if (path !== undefined && this.entries.has(path)) {
          if (path !== source) present.add(path);
        } else missing.push(name);
      }
    }
    // A part with parts of its own: an `.obj`'s `.mtl` names its textures. (A Set visits what is added while it is walked.)
    for (const part of present) {
      const inner = this.named.get(part);
      if (!inner || inner.search) continue;
      for (const name of inner.names) {
        const path = resolveRel(dirName(part), name);
        if (path !== undefined && this.entries.has(path)) {
          if (path !== source) present.add(path);
        } else missing.push(name);
      }
    }
    return { present: [...present], missing };
  }

  /**
   * Every entry's role, kind, key, exports, source, parts and owners, from the
   * paths and what the sources were read to name. No I/O; linear in the
   * entries and the folders' sizes. Run after any change.
   */
  private classify(): void {
    this.dirtyAll = true;
    const candidates = new Map<string, Found>();
    const sourceSide: Entry[] = [];
    const shipSide: Entry[] = [];
    const was = new Map<string, Entry['role']>();
    /** An export's source before this classify: one its source has left the build for is left behind, then trashed. */
    const wasSource = new Map<string, string>();
    for (const e of this.entries.values()) {
      was.set(e.path, e.role);
      if (e.role === 'export' && e.source !== undefined) wasSource.set(e.path, e.source);
      delete e.key;
      delete e.exports;
      delete e.source;
      delete e.parts;
      delete e.owners;
      (e.root === 'source' ? sourceSide : shipSide).push(e);
    }
    // A role may be set twice on the way (a part is first a candidate source):
    // what it had is cleared below, once, only if its final role differs.
    const setRole = (e: Entry, role: Entry['role'], reason?: string): void => {
      e.role = role;
      // A source's reason is its status's; anything else's says what it is.
      if (role !== 'source') {
        if (reason !== undefined) e.reason = reason;
        else delete e.reason;
      }
    };

    for (const e of sourceSide) {
      const { where, recipe } = this.infoOf(e.path);
      const name = baseName(e.path);
      if (where?.reference) setRole(e, 'reference');
      else if (isRecordName(name)) setRole(e, 'record');
      else if (name.startsWith('_') || (where?.under !== undefined && underscored(where.under))) setRole(e, 'extra', 'will not ship');
      else if (isFound(recipe)) {
        candidates.set(e.path, recipe);
        setRole(e, 'source');
      } else setRole(e, 'extra', strayPrefab(e.path)?.problem ?? `kept, not converted: ${recipe.refused}`);
    }

    // Parts: what the sources named, worked out once a source. A part is never a source of its own.
    const folders = new Map<string, FolderNames>();
    const names = (dir: string): FolderNames => {
      let index = folders.get(dir);
      if (!index) folders.set(dir, (index = this.folderNames(dir)));
      return index;
    };
    const partsBy = new Map<string, string[]>();
    const owners = new Map<string, string[]>();
    for (const source of candidates.keys()) {
      const { present } = this.partsOf(source, names);
      partsBy.set(source, present);
      for (const part of present) {
        const list = owners.get(part);
        if (list) list.push(source);
        else owners.set(part, [source]);
      }
    }
    for (const [part, list] of owners) {
      const e = this.entries.get(part);
      if (!e || e.role === 'reference' || e.role === 'record') continue;
      candidates.delete(part);
      setRole(e, 'part');
      e.owners = list;
    }

    // Out of the build: a source its record (`<stem>.export.json`, `"include": false`) takes out.
    const excluded = new Set<string>();
    for (const source of candidates.keys()) if (this.excludedRecords.has(this.recordOf(source))) excluded.add(source);

    // Intermediates and records belong to the source of their stem in their folder -- one in the build first.
    const byStem = new Map<string, string>();
    for (const source of candidates.keys()) {
      const stem = joinPath(dirName(source), splitName(baseName(source)).stem);
      const had = byStem.get(stem);
      if (had === undefined || (excluded.has(had) && !excluded.has(source))) byStem.set(stem, source);
    }
    for (const e of sourceSide) {
      const name = baseName(e.path);
      if (e.role === 'record') {
        const stem = recordStem(name);
        // Its own record (`crate.blend.export.json`) is that source's; a stem's, the source of its stem.
        const own = stem ? joinPath(dirName(e.path), stem) : undefined;
        const source = own !== undefined && candidates.has(own) ? own : stem ? byStem.get(joinPath(dirName(e.path), stem)) : undefined;
        if (source) e.source = source;
        continue;
      }
      if (e.role !== 'extra' || !/^_.+\.glb$/i.test(name)) continue;
      const source = byStem.get(joinPath(dirName(e.path), splitName(name).stem.slice(1)));
      const found = source ? candidates.get(source) : undefined;
      if (source && found && usesIntermediate(found, found.row.steps.map(stepInfo))) {
        setRole(e, 'intermediate');
        e.source = source;
      }
    }

    // The shipping side: a source's exports, and what ships as it was delivered. A source out of the
    // build has none: a file at its export path is delivered by hand, a loose file.
    const exportOf = new Map<string, string>();
    for (const source of candidates.keys()) if (!excluded.has(source)) for (const path of this.infoOf(source).exports) exportOf.set(path, source);
    const loose: ConflictLoose[] = [];
    for (const e of shipSide) {
      const source = exportOf.get(e.path);
      const { key, globbed: shipped } = this.infoOf(e.path);
      if (source) {
        setRole(e, 'export');
        e.source = source;
      } else if (shipped) {
        setRole(e, 'loose', 'ships as delivered');
        loose.push(key !== undefined ? { path: e.path, key } : { path: e.path });
      } else setRole(e, 'extra', strayPrefab(e.path)?.problem ?? 'will not ship');
      if (key !== undefined) e.key = key;
    }
    for (const e of this.entries.values()) {
      if (was.get(e.path) === e.role) continue;
      delete e.status;
      delete e.note;
      if (e.role === 'source') delete e.reason;
    }

    const sources: ConflictSource[] = [];
    for (const source of candidates.keys()) {
      const e = this.entries.get(source)!;
      const { exports, key } = this.infoOf(source);
      e.exports = [...exports];
      if (key !== undefined) e.key = key;
      const present = partsBy.get(source)!;
      if (present.length > 0) e.parts = present;
      sources.push({ path: source, exports, ...(key !== undefined ? { key } : {}), ...(excluded.has(source) ? { excluded: true } : {}) });
    }
    this.conflictReasons = findConflicts(sources, loose);
    for (const [path, reason] of this.conflictReasons) {
      const e = this.entries.get(path);
      if (!e) continue;
      if (e.role === 'source') {
        e.status = 'conflict';
        e.reason = reason;
      } else e.reason = reason;
    }

    // An image a source not yet read might name is `checking`: one in that source's folder, or the folder above `textures/`.
    const unread = new Map<string, number>();
    /** The folders with a script not yet read: a `.glb` or `.fbx` there may be the copy it imports (Docs/modeler.md M38). */
    const unreadScripts = new Set<string>();
    const isUnread = (source: string): boolean => candidates.get(source)?.row.deps !== undefined && !this.named.has(source);
    for (const [source, recipe] of candidates) {
      if (recipe.row.deps === undefined || this.named.has(source)) continue;
      const dir = dirName(source);
      unread.set(dir, (unread.get(dir) ?? 0) + 1);
      if (recipe.ext === 'lua') unreadScripts.add(dir);
    }
    const mightBeNamed = (path: string): boolean => {
      // A model file: only where a script not yet read is beside it -- the folder asked first, the name only then.
      if (this.isModelSource(path)) return unreadScripts.has(dirName(path)) && IMPORTS.has(splitName(baseName(path)).ext);
      const dir = dirName(path);
      if ((unread.get(dir) ?? 0) - (isUnread(path) ? 1 : 0) > 0) return true;
      return baseName(dir) === 'textures' && (unread.get(dirName(dir)) ?? 0) > 0;
    };
    for (const source of candidates.keys()) {
      if (this.conflictReasons.has(source)) continue;
      const e = this.entries.get(source)!;
      // Out of the build: said at once, nothing to read for it -- never `checking`.
      if (excluded.has(source)) {
        e.status = 'excluded';
        e.reason = EXCLUDED;
        delete e.note;
        continue;
      }
      if (e.status === 'conflict' || e.status === 'excluded' || mightBeNamed(source)) {
        e.status = 'checking';
        delete e.reason;
        delete e.note;
      }
      e.status ??= 'checking';
    }

    // In the build: a source unless out; its record, intermediate and exports as it is; a part as any owner is;
    // a loose file always; whatever ships under no name it has -- a reference, an extra, an `_` name -- never.
    const inBuild = (source: string | undefined): boolean => source === undefined || !excluded.has(source);
    for (const e of this.entries.values()) {
      e.included =
        e.role === 'source' ? !excluded.has(e.path)
        : e.role === 'part' ? (e.owners ?? []).some(inBuild)
        : e.role === 'export' || e.role === 'intermediate' || e.role === 'record' ? inBuild(e.source)
        : e.role === 'loose';
    }
    // A source newly out of the build whose export is still there -- the record edited by hand, a pull: that
    // export, as it was its, is left behind, and goes to the auto slot as the source settles. A file at its
    // export path that was not its export (one delivered by hand) stays, loose.
    for (const source of excluded) {
      if (this.excludedSources.has(source)) continue;
      for (const path of this.infoOf(source).exports) if (was.get(path) === 'export' && wasSource.get(path) === source && this.entries.has(path)) this.leftBehind.add(path);
    }
    this.excludedSources = excluded;
  }

  /** A model source: an owner, read first (§4). */
  private isModelSource(path: string): boolean {
    return this.infoOf(path).where?.kind === 'models' && MODEL_SOURCE_EXT.includes(splitName(baseName(path)).ext);
  }

  // ---------------------------------------------------------------- hashing and status

  /**
   * A file's hash for this run: read once, through the cache (or not, with
   * `check`). With `deps`, what it names besides -- or, when it cannot be read
   * for that, the attempt (`attempted`).
   */
  private async hash(path: string, deps?: Deps): Promise<Hashed> {
    const e = this.entries.get(path);
    const hit = this.memo.get(path);
    if (hit && e && hit.mtime === e.mtime && hit.size === e.size && (deps === undefined || hit.withParts)) return hit.hashed;
    const hashed = await hashOf(this.hashes, this.root, path, { ...(deps ? { deps } : {}), check: this.check });
    // Read while events came: nothing is kept for a path the index no longer has, nor a hash onto an entry a newer event replaced.
    const now = this.entries.get(path);
    if (e && now === e) {
      this.memo.set(path, { mtime: e.mtime, size: e.size, withParts: deps !== undefined, hashed });
      if (e.hash !== hashed.sha1) {
        e.hash = hashed.sha1;
        this.dirty.add(path);
      }
    }
    if (deps && now) {
      if (hashed.parts) this.named.set(path, { names: hashed.parts, search: deps.search === true });
      else this.attempted(path, deps);
    }
    return hashed;
  }

  /**
   * An owner tried and not read for its names -- an LFS pointer, a `.gltf`
   * that is not JSON, a file it cannot open: it counts as read, so its folder's
   * images settle instead of staying `checking` after every event. What it
   * named before stands (a save mid-edit keeps its parts); one never read names
   * nothing.
   */
  private attempted(path: string, deps: Deps): void {
    if (!this.named.has(path) && this.entries.has(path)) this.named.set(path, { names: [], search: deps.search === true });
  }

  /** A part with parts of its own (an `.mtl`) not read for its names since it last changed. */
  private unreadPart(path: string): boolean {
    return !this.named.has(path) || this.memo.get(path)?.withParts !== true;
  }

  /** The sources to settle: given, or every one; model sources first. */
  private sourcesToSettle(paths?: readonly string[]): string[] {
    const all = paths ?? [...this.entries.values()].filter((e) => e.role === 'source').map((e) => e.path);
    return [...all].sort((a, b) => Number(this.isModelSource(b)) - Number(this.isModelSource(a)) || byPath(a, b));
  }

  /** The sources still `checking`: new ones, and those a classify made sources. */
  private sourcesWaiting(): string[] {
    const out: string[] = [];
    for (const e of this.entries.values()) if (e.role === 'source' && e.status === 'checking') out.push(e.path);
    return out;
  }

  /** `fn` after every serial job before it, and before every one after: a walk, settles, a refresh, a learn. */
  private serial<T>(fn: () => Promise<T>): Promise<T> {
    const run = this.settling.then(fn);
    // The chain goes on whatever this one ended as; its caller hears how it ended, from `run`.
    this.settling = run.then(
      () => undefined,
      () => undefined,
    );
    return this.track(run);
  }

  /** A promise counted in `settled()` until it ends. */
  private track<T>(promise: Promise<T>): Promise<T> {
    this.tasks.add(promise);
    const done = (): void => void this.tasks.delete(promise);
    promise.then(done, done);
    return promise;
  }

  /**
   * Statuses settled: every source (or those given) read for its parts, a
   * lane at a time, owners first; then the roles again; then each source's
   * status. A file that became a part after it was exported on its own has its
   * export and record moved to the auto slot.
   */
  settle(paths?: readonly string[]): Promise<void> {
    return this.serial(() => this.settleNow(paths));
  }

  /** Resolves once everything started -- events, quiet settles, serial jobs -- has finished. */
  async settled(): Promise<void> {
    while (this.tasks.size > 0) await Promise.allSettled([...this.tasks]);
  }

  private async settleNow(paths?: readonly string[]): Promise<void> {
    const now = this.clock.now();
    const quiet = (path: string): boolean => now - (this.changedAt.get(path) ?? -Infinity) >= this.quietMs;
    const first = this.sourcesToSettle(paths).filter(quiet);
    // Owners first: what they name decides what the rest are. A pointer cannot be read for it: tried, all the same.
    const owners: Array<[string, Deps]> = [];
    for (const p of first) {
      const recipe = this.infoOf(p).recipe;
      if (!isFound(recipe) || recipe.row.deps === undefined) continue;
      if (this.entries.get(p)?.pointer) this.attempted(p, recipe.row.deps);
      else owners.push([p, recipe.row.deps]);
    }
    await pool(owners, this.lanes, ([path, deps]) => this.hashOrGone(path, deps));
    // A `.mtl` (a part with parts) is read for its own, once it changed. Rare files, one at a time.
    const withParts = [...this.entries.values()].filter((e) => e.root === 'source' && PART_DEPS[splitName(baseName(e.path)).ext] && this.unreadPart(e.path));
    for (const e of withParts) await this.hashOrGone(e.path, PART_DEPS[splitName(baseName(e.path)).ext]);
    this.classify();
    if (await this.partsExportedAlone()) this.classify();
    if (await this.excludedExportsAway()) this.classify();
    // What this settle made a source -- an image its model or `.mtl` no longer names -- settles with it: nothing else would.
    const wanted = paths === undefined ? undefined : [...new Set([...paths, ...this.sourcesWaiting()])];
    const sources = this.sourcesToSettle(wanted).filter((p) => this.entries.get(p)?.role === 'source' && quiet(p));
    await pool(sources, this.lanes, async (path) => {
      try {
        this.apply(await this.inspect(path));
      } catch (err) {
        this.fail(path, err as Error);
      }
    });
    this.commit();
  }

  /**
   * An owner hashed and read for its names. One gone since it was listed
   * leaves the index now, as its `unlink` would have it (which then finds
   * nothing to do): an entry nobody can read would stay unread for good. One
   * there but unreadable is told, and counts as tried.
   */
  private async hashOrGone(path: string, deps: Deps): Promise<void> {
    try {
      await this.hash(path, deps);
    } catch (err) {
      if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') {
        if (this.entries.has(path)) await this.removed(path);
        return;
      }
      this.onError(err as Error);
      this.attempted(path, deps);
    }
  }

  /** One source's status worked out again (after its export, say), and the change committed. In turn with the settles. */
  refresh(source: string): Promise<void> {
    return this.serial(async () => {
      const path = norm(source);
      if (this.entries.get(path)?.role === 'source') {
        try {
          this.apply(await this.inspect(path));
        } catch (err) {
          this.fail(path, err as Error);
        }
      }
      this.commit();
    });
  }

  /** A source's state onto its entry. */
  private apply(state: SourceState): void {
    const e = this.entries.get(state.source);
    if (!e) return;
    e.status = state.status;
    if (state.reason) e.reason = state.reason;
    else delete e.reason;
    if (state.note) e.note = state.note;
    else delete e.note;
    if (state.hash) e.hash = state.hash;
    this.dirty.add(e.path);
  }

  /** A source that could not be worked out: `failed`, saying why. */
  private fail(path: string, err: Error): void {
    const e = this.entries.get(path);
    if (!e) return;
    e.status = 'failed';
    e.reason = err.message;
    this.dirty.add(path);
  }

  /** A folder's `export.json`, read only if the index has one, and again only once it changed. */
  private folderDefaults(dir: string): Promise<RecordRead> {
    const path = folderRecordPath(dir);
    const e = this.entries.get(path);
    if (!e) return Promise.resolve({});
    const hit = this.folderReads.get(path);
    if (hit && hit.mtime === e.mtime && hit.size === e.size) return hit.read;
    const read = readFolderDefaults(this.root, dir);
    this.folderReads.set(path, { mtime: e.mtime, size: e.size, read });
    return read;
  }

  /**
   * Everything about one source, read fresh (through the caches): its row and
   * options, hash and parts, intermediate, record, exports, and status. What an
   * export runs from.
   */
  async inspect(source: string): Promise<SourceState> {
    const path = norm(source);
    const answer = this.infoOf(path).recipe;
    if (!isFound(answer)) throw new Error(`${path}: ${answer.refused}`);
    const found = answer;
    const steps = found.row.steps.map(stepInfo);
    const recordFile = this.recordOf(path);
    const { options, problems, record } = await sourceOptions(this.root, path, found, (dir) => this.folderDefaults(dir), recordFile);
    // Out of the build: nothing of it read -- it is never exported, so neither its hash nor its parts' matter.
    if (this.excludedSources.has(path)) {
      const npm = this.npm;
      const out = statusOf({ source: path, excluded: true, found, options, parts: [], exportsMissing: [], steps, npm, browser: this.browser, digest: sha1 });
      const exports = [...this.infoOf(path).exports];
      return { ...out, source: path, found, options, recordPath: recordFile, ...(record ? { record } : {}), parts: [], partHashes: {}, exports, to: resolveTo(path, found.row.to), lastRunFailed: false };
    }
    const entry = this.entries.get(path);
    const pointer = entry?.pointer === true;
    let hash: string | undefined;
    let partsError: string | undefined;
    if (!pointer) {
      const hashed = await this.hash(path, found.row.deps);
      hash = hashed.sha1;
      partsError = hashed.partsError;
    } else if (found.row.deps) this.attempted(path, found.row.deps);
    // Parts with parts: read for their own names before they are resolved -- again once one changed.
    for (const part of this.partsOf(path).present) {
      const deps = PART_DEPS[splitName(baseName(part)).ext];
      if (deps && this.unreadPart(part)) await this.hash(part, deps);
    }
    const { present, missing } = this.partsOf(path);
    const dir = dirName(path);
    const rel = (p: string): string => (dir === '' ? p : p.slice(dir.length + 1));
    const parts: PartState[] = missing.map((name) => ({ name, missing: true }));
    const partHashes: Record<string, string> = {};
    for (const part of present) {
      const pe = this.entries.get(part);
      if (pe?.pointer) {
        parts.push({ name: rel(part), pointer: true });
        continue;
      }
      const h = await this.hash(part);
      partHashes[part] = h.sha1;
      parts.push({ name: rel(part), hash: h.sha1 });
    }
    let intermediate: string | undefined;
    let intermediateHash: string | undefined;
    if (usesIntermediate(found, steps)) {
      const ip = intermediatePath(path);
      if (this.entries.has(ip)) {
        intermediate = ip;
        if (!this.entries.get(ip)!.pointer) intermediateHash = (await this.hash(ip)).sha1;
        else parts.push({ name: baseName(ip), pointer: true });
      }
    }
    const exports = this.infoOf(path).exports;
    const exportsMissing = exports.filter((x) => !this.entries.has(x));
    // The exports there, held to the record's `built.out`: a pointer is known by its peek; a hash read only when there is one to hold it to.
    const to = resolveTo(path, found.row.to);
    const heldTo = record?.built?.out;
    const exportsThere: Array<{ path: string; ext: string; hash?: string; pointer?: boolean }> = [];
    for (let k = 0; k < exports.length; k++) {
      const x = exports[k]!;
      const xe = this.entries.get(x);
      if (!xe) continue;
      const ext = to[k] ?? '';
      if (xe.pointer) exportsThere.push({ path: x, ext, pointer: true });
      else if (heldTo?.[ext] !== undefined) exportsThere.push({ path: x, ext, hash: (await this.hash(x)).sha1 });
      else exportsThere.push({ path: x, ext });
    }
    // `--check` says what this checkout has, not what this machine last tried (`runs.json`): CI and a desk say the same.
    const last = this.check ? undefined : this.runs?.get(path);
    const result = statusOf({
      source: path,
      found,
      options,
      problems,
      ...(this.infoOf(path).where?.reference ? { reference: true } : {}),
      ...(this.conflictReasons.has(path) ? { conflict: this.conflictReasons.get(path)! } : {}),
      pointer,
      ...(hash !== undefined ? { hash } : {}),
      ...(partsError !== undefined ? { partsError } : {}),
      parts,
      ...(record ? { record } : {}),
      exportsMissing,
      exportsThere,
      ...(intermediate ? { intermediate: intermediateHash !== undefined ? { name: baseName(intermediate), hash: intermediateHash } : { name: baseName(intermediate) } } : {}),
      steps,
      ...(this.tools ? { tools: this.tools } : {}),
      npm: this.npm,
      browser: this.browser,
      ...(last ? { lastRun: last } : {}),
      digest: sha1,
    });
    const lastRunFailed = result.status === 'failed' && last !== undefined && !last.ok && (result.reason ?? '').startsWith('the last export failed');
    return {
      ...result,
      source: path,
      found,
      options,
      recordPath: recordFile,
      ...(record ? { record } : {}),
      ...(hash !== undefined ? { hash } : {}),
      parts: present,
      partHashes,
      exports: [...exports],
      to: resolveTo(path, found.row.to),
      ...(intermediate ? { intermediate } : {}),
      ...(intermediateHash ? { intermediateHash } : {}),
      lastRunFailed,
    };
  }

  /**
   * A file that became a part after it was exported on its own -- an image
   * dropped alone, its model a minute later -- has its export and record moved
   * to the auto slot (§3), and its entry says so -- but a record of its stem
   * that is a source's, its owner's (`mech.mtl` and `mech.obj`), is left. True
   * if anything moved: the roles are worked out again then.
   */
  private async partsExportedAlone(): Promise<boolean> {
    let moved = false;
    for (const e of [...this.entries.values()]) {
      if (e.role !== 'part' || e.root !== 'source') continue;
      const record = recordPath(e.path);
      // A part with its owner's stem -- `mech.mtl` beside `mech.obj` -- has its owner's record: that one stays.
      const rec = this.entries.get(record);
      if (!rec || (rec.source !== undefined && rec.source !== e.path)) continue;
      const leftovers = [record, ...this.infoOf(e.path).exports].filter((p) => this.entries.has(p));
      try {
        await toTrash(this.root, leftovers, AUTO_SLOT, 'move');
      } catch (err) {
        // Moved or removed meanwhile (the Finder, another process): the next walk says what is left.
        if (code(err) !== 'ENOENT') this.onError(err as Error);
      }
      for (const p of leftovers) {
        this.drop(p);
        this.unexpect(p);
        this.hashes.forget(p);
      }
      e.note = `exported before ${(e.owners ?? []).map(baseName).join(', ')} named it; moved to the trash`;
      moved = true;
    }
    if (moved) await this.readTrash();
    return moved;
  }

  /**
   * The exports a source had as a watch event took it out of the build (its
   * record edited to say `"include": false`, by hand or by a pull): moved to
   * the auto slot, as a part's export alone is -- an excluded source ships
   * nothing. True if anything moved: the roles are worked out again then.
   */
  private async excludedExportsAway(): Promise<boolean> {
    const away = [...this.leftBehind].filter((p) => this.entries.get(p)?.role === 'loose');
    this.leftBehind.clear();
    if (away.length === 0) return false;
    try {
      await toTrash(this.root, away, AUTO_SLOT, 'move');
    } catch (err) {
      // Moved or removed meanwhile (the Finder, another process): the next walk says what is left.
      if (code(err) !== 'ENOENT') this.onError(err as Error);
    }
    for (const p of away) {
      this.drop(p);
      this.unexpect(p);
      this.hashes.forget(p);
    }
    await this.readTrash();
    return true;
  }

  // ---------------------------------------------------------------- watch events

  /**
   * One of the pipeline's own writes, about to happen: the stat it will have,
   * and whether it replaces a file there. Its first matching watch event is
   * consumed; the entry goes after `expectMs`.
   */
  expect(path: string, stat: { mtimeMs: number; size: number }, replaced: boolean): void {
    const p = norm(path);
    const write = { mtimeMs: stat.mtimeMs, size: stat.size, replaced };
    this.expected.set(p, write);
    this.writes.set(p, write);
    const old = this.timers.get(`expect:${p}`);
    if (old !== undefined) this.clock.clearTimeout(old);
    this.timers.set(
      `expect:${p}`,
      this.clock.setTimeout(() => {
        this.expected.delete(p);
        this.writes.delete(p);
        this.timers.delete(`expect:${p}`);
      }, this.expectMs),
    );
  }

  /**
   * A path the pipeline is about to remove, with nothing put in its place: no
   * write of its own is waited for there any more, so its `unlink` is news to
   * `hotUpdate` (the key goes) -- an export undone straight after it was made.
   */
  unexpect(path: string): void {
    const p = norm(path);
    this.expected.delete(p);
    this.writes.delete(p);
    const old = this.timers.get(`expect:${p}`);
    if (old !== undefined) this.clock.clearTimeout(old);
    this.timers.delete(`expect:${p}`);
  }

  /**
   * Files the pipeline wrote (or removed), applied to the index at once: the
   * write is the news, its watch event is not. In turn with the settles. It
   * commits nothing: the caller does -- `refresh` after an export, `commit()`
   * after an import -- so the files and their source's new status go out in
   * one diff.
   *
   * `exact`: paths whose spelling only the folder's listing can tell -- both
   * ends of a rename that changed only the case. On a disk with one name for
   * both spellings (macOS) a `stat` finds the old spelling too; the listings
   * have the one the disk keeps -- each folder on the way, for a folder renamed
   * in case -- and a path not in them is gone. No walk.
   */
  learn(paths: readonly string[], exact: readonly string[] = []): Promise<void> {
    return this.serial(async () => {
      const spelled = new Set(exact.map(norm));
      const listings = new Map<string, Promise<Set<string>>>();
      const listing = (dir: string): Promise<Set<string>> => {
        let names = listings.get(dir);
        if (!names) {
          names = readdir(join(this.root, dir)).then(
            (list) => new Set(list),
            () => new Set<string>(),
          );
          listings.set(dir, names);
        }
        return names;
      };
      for (const path of paths.map(norm)) {
        if (!this.listed(path)) continue;
        let there = true;
        if (spelled.has(path)) {
          for (let at = path; at !== '' && there; at = dirName(at)) there = (await listing(dirName(at))).has(baseName(at));
        }
        const entry = there ? await this.read(path) : undefined;
        if (entry) {
          const old = this.entries.get(path);
          if (old?.hash !== undefined && old.mtime === entry.mtime && old.size === entry.size) entry.hash = old.hash;
          this.put(entry);
        } else {
          this.drop(path);
          this.unexpect(path);
        }
      }
      this.classify();
    });
  }

  /**
   * A watch event, as Vite's watcher reports it, for a path absolute or
   * relative to the root. The pipeline's own writes are consumed by their stat;
   * anything else updates the index at once -- one classify and one commit for
   * all the events of a macrotask -- and settles once quiet. Resolves once that
   * classify has run. **Never rejects**: the watcher's handler awaits nothing,
   * and a rejection there would take the server down -- what fails is told to
   * `onError`. Counted in `settled()`.
   */
  onEvent(type: 'add' | 'change' | 'unlink' | 'addDir' | 'unlinkDir', file: string): Promise<void> {
    return this.track(this.event(type, file).catch((err: unknown) => this.onError(err as Error)));
  }

  private async event(type: 'add' | 'change' | 'unlink' | 'addDir' | 'unlinkDir', file: string): Promise<void> {
    const path = norm(isAbsolute(file) || /^[a-zA-Z]:[\\/]/.test(file) ? relative(this.root, file) : file);
    if (path === '..' || path.startsWith('../') || !this.infoOf(path).where) return;
    if (type === 'unlinkDir') {
      const gone: string[] = [];
      for (const [dir, paths] of this.byDir) if (under(dir, path)) gone.push(...paths);
      await Promise.all(gone.map((p) => this.removed(p)));
      return;
    }
    if (type === 'addDir') {
      // A spelling a case-only rename just left (see below): nothing new there.
      if (!(await this.spelled(path))) return;
      const added = await this.walkUnder(path);
      await Promise.all(added.map((p) => this.changed(p)));
      return;
    }
    if (!this.listed(path)) return;
    if (type === 'unlink') {
      if (!this.entries.has(path)) return; // its own removal, applied already
      return this.removed(path);
    }
    let st;
    try {
      st = await stat(join(this.root, path));
    } catch (err) {
      if (code(err) !== 'ENOENT' && code(err) !== 'ENOTDIR') throw err;
      // Gone between the event and the look: as good as an unlink.
      if (this.entries.has(path)) await this.removed(path);
      return;
    }
    // On a disk with one name for both spellings (macOS) a watcher may tell of a spelling a case-only rename just
    // left, and `stat` finds it: only the listings say which the disk keeps. Not that one: as good as an unlink.
    if (!(await this.spelled(path))) {
      if (this.entries.has(path)) await this.removed(path);
      return;
    }
    const exp = this.expected.get(path);
    if (exp && exp.mtimeMs === st.mtimeMs && exp.size === st.size) {
      this.expected.delete(path); // consumed, once
      return;
    }
    const entry = await this.read(path);
    if (!entry) return;
    this.put(entry);
    await this.changed(path);
  }

  /** Is `path` spelled as the disk keeps it -- each part of it in its folder's listing, exactly? */
  private async spelled(path: string): Promise<boolean> {
    for (let at = path; at !== ''; at = dirName(at)) {
      const names = await readdir(join(this.root, dirName(at))).catch(() => [] as string[]);
      if (!names.includes(baseName(at))) return false;
    }
    return true;
  }

  /** The files under a new folder, read into the index; their paths. */
  private async walkUnder(dir: string): Promise<string[]> {
    let list;
    try {
      list = await readdir(join(this.root, dir), { withFileTypes: true, recursive: true });
    } catch {
      return []; // gone again already: its unlinkDir will come
    }
    const added: string[] = [];
    for (const d of list) {
      if (!d.isFile() || ignored(d.name)) continue;
      const path = norm(relative(this.root, join(d.parentPath, d.name)));
      if (!this.listed(path)) continue;
      const entry = await this.read(path);
      if (entry) {
        this.put(entry);
        added.push(path);
      }
    }
    return added;
  }

  /**
   * A file gone: the sources it moved worked out first -- its owners, its
   * source -- while its entry still says.
   *
   * Phase 3: a model renamed in the Finder (`unlink` of the old name, `add` of
   * the new) shows its images as sources, `checking`, from the `unlink`'s
   * commit until the new one is read once quiet, then parts again: the `unlink`
   * is applied at once and the `add` needs a stat and a read, so the two never
   * share a flush, and handing the names over within one would not help.
   * Keeping the parts would take the old owner's names held until its quiet
   * look, owning them meanwhile, and handed to a new file of its extension in
   * its folder -- if the tool shows the flicker.
   */
  private removed(path: string): Promise<void> {
    const before = this.affected(path);
    this.drop(path);
    this.hashes.forget(path);
    return this.changed(path, before);
  }

  /**
   * A real change: the roles again and the diff out -- once for every event of
   * this macrotask, however many -- and a settle once the file has been quiet.
   */
  private changed(path: string, before: readonly string[] = []): Promise<void> {
    this.changedAt.set(path, this.clock.now());
    this.memo.delete(path);
    this.pending.add(path);
    if (before.length > 0) {
      const moved = this.movedBefore.get(path) ?? new Set<string>();
      for (const source of before) moved.add(source);
      this.movedBefore.set(path, moved);
    }
    // The end of this macrotask -- a boundary, not a wait, so not the clock's: every event already in has joined.
    this.flushing ??= this.track(
      new Promise<void>((resolve) =>
        setImmediate(() => {
          this.flushing = undefined;
          try {
            this.flushEvents();
          } catch (err) {
            this.onError(err as Error);
          }
          resolve();
        }),
      ),
    );
    return this.flushing;
  }

  /** The events of one macrotask: one classify, their sources `checking`, one commit, a quiet timer each. */
  private flushEvents(): void {
    const paths = [...this.pending];
    this.pending.clear();
    this.classify();
    for (const path of paths) {
      for (const source of this.moved(path)) {
        const e = this.entries.get(source);
        // Out of the build: nothing of it is read, so nothing is checked -- it says so at once.
        if (e && e.role === 'source' && e.status !== 'checking' && e.status !== 'excluded') {
          e.status = 'checking';
          this.dirty.add(source);
        }
      }
      const key = `quiet:${path}`;
      const old = this.timers.get(key);
      if (old !== undefined) this.clock.clearTimeout(old);
      this.timers.set(
        key,
        this.clock.setTimeout(() => {
          this.timers.delete(key);
          this.quiet(path);
        }, this.quietMs),
      );
    }
    this.commit();
  }

  /** A file quiet for `quietMs`: settled with the others quiet in the same macrotask. */
  private quiet(path: string): void {
    this.quietReady.add(path);
    this.quieting ??= this.track(
      new Promise<void>((resolve) =>
        setImmediate(() => {
          this.quieting = undefined;
          // Nothing here may take the server down; nor may it fail without a word.
          this.settleQuiet()
            .catch((err: unknown) => this.onError(err as Error))
            .finally(resolve);
        }),
      ),
    );
  }

  /**
   * The quiet files looked at again, and the rest's sources settled, together.
   * The disk has the last word: a size or mtime moved is a change, and the
   * quiet starts over; an entry whose file is gone goes, and a file with no
   * entry gets one -- whatever order the events' reads finished in -- each
   * looked at again once quiet. One that cannot be stat'ed is told, and its
   * sources settle all the same (and say what failed): it holds up nothing.
   */
  private async settleQuiet(): Promise<void> {
    const paths = [...this.quietReady];
    this.quietReady.clear();
    const growing: string[] = [];
    const gone: string[] = [];
    const appeared: string[] = [];
    await Promise.all(
      paths.map(async (path) => {
        const e = this.entries.get(path);
        try {
          const st = await stat(join(this.root, path));
          if (!st.isFile()) {
            if (e) gone.push(path);
          } else if (!e) appeared.push(path);
          else if (st.size !== e.size || st.mtimeMs !== e.mtime) growing.push(path);
        } catch (err) {
          if (code(err) === 'ENOENT' || code(err) === 'ENOTDIR') {
            if (e) gone.push(path);
          } else this.onError(err as Error);
        }
      }),
    );
    await Promise.all([...growing.map((p) => this.onEvent('change', p)), ...gone.map((p) => this.removed(p)), ...appeared.map((p) => this.reread(p))]);
    const later = new Set([...growing, ...gone, ...appeared]);
    const sources = new Set<string>();
    const moved = new Map<string, string[]>();
    for (const path of paths) {
      if (later.has(path)) continue;
      this.changedAt.delete(path);
      const these = [...this.moved(path)].filter((source) => this.entries.has(source));
      moved.set(path, these);
      for (const source of these) sources.add(source);
      this.movedBefore.delete(path);
    }
    if (sources.size > 0) await this.settle([...sources]);
    if (moved.size > 0 && this.onQuiet) {
      try {
        this.onQuiet(moved);
      } catch (err) {
        this.onError(err as Error);
      }
    }
  }

  /** A file there with no entry -- an older event's "gone" applied after a newer one's read -- read in. Not through `onEvent`: no expected write is consumed. */
  private async reread(path: string): Promise<void> {
    if (!this.listed(path)) return;
    const entry = await this.read(path);
    if (!entry) return;
    this.put(entry);
    await this.changed(path);
  }

  /** The sources a change to `path` moves: as the index has it now, and as it had it before the file went. */
  private moved(path: string): Set<string> {
    const out = new Set(this.affected(path));
    for (const source of this.movedBefore.get(path) ?? []) out.add(source);
    return out;
  }

  /** The sources whose status a change to `path` may move. Looks at its folder (and the one above `textures/`), not the tree. */
  affected(path: string): string[] {
    const out = new Set<string>();
    const e = this.entries.get(path);
    if (e?.role === 'source') out.add(path);
    for (const owner of e?.owners ?? []) out.add(owner);
    if (e?.source) out.add(e.source);
    const name = baseName(path);
    const dir = dirName(path);
    const sourcesIn = (folder: string): Entry[] => {
      const out: Entry[] = [];
      for (const p of this.byDir.get(folder) ?? []) {
        const s = this.entries.get(p);
        if (s?.role === 'source') out.push(s);
      }
      return out;
    };
    if (name === 'export.json') {
      for (const [folder, paths] of this.byDir) {
        if (!under(folder, dir)) continue;
        for (const p of paths) if (this.entries.get(p)?.role === 'source') out.add(p);
      }
    }
    const stem = recordStem(name) ?? (name.startsWith('_') ? splitName(name).stem.slice(1) : undefined);
    // A stem's record its sources', a source's own record (`crate.blend.export.json`) that one's.
    if (stem) for (const s of sourcesIn(dir)) if (splitName(baseName(s.path)).stem === stem || baseName(s.path) === stem) out.add(s.path);
    // A new or changed image may be a part of a source in its folder (or above `textures/`).
    for (const folder of baseName(dir) === 'textures' ? [dir, dirName(dir)] : [dir]) {
      for (const s of sourcesIn(folder)) {
        const recipe = this.infoOf(s.path).recipe;
        if (isFound(recipe) && recipe.row.deps) out.add(s.path);
      }
    }
    // An export or a loose file: the sources in its twin folder that ship it -- also once it is gone.
    if (this.infoOf(path).where?.root !== 'source') {
      const source = twin(dir);
      if (source !== undefined) for (const s of sourcesIn(source)) if (this.infoOf(s.path).exports.includes(path)) out.add(s.path);
    }
    return [...out];
  }

  // ---------------------------------------------------------------- the trash

  /**
   * The Trash root, read from disk: at the start and after each of the
   * pipeline's own writes there. Found changed, it goes out with the next
   * commit's diff -- and every diff over it -- whole.
   */
  async readTrash(): Promise<TrashSlot[]> {
    const slots = await readTrash(this.root);
    if (JSON.stringify(slots) !== JSON.stringify(this.trash)) this.trashMoved = true;
    this.trash = slots;
    return this.trash;
  }

  /**
   * The trash pruned (30 days, `trash.ts`'s `prune`), and read again; the
   * count kept for the tree's `pruned`, when anything went. Once the server is
   * listening (§6).
   */
  async prune(options: { days?: number; now?: Date } = {}): Promise<number> {
    const count = await prune(this.root, options);
    if (count > 0) this.pruned = { count, at: isoSeconds(options.now ?? new Date()) };
    await this.readTrash();
    this.commit();
    return count;
  }

  // ---------------------------------------------------------------- diffs

  /**
   * The index's changes since the last commit, numbered and kept; told to
   * `onChange`. Only the entries touched since then are compared -- all of
   * them after a classify -- each by its fingerprint.
   */
  commit(): Diff | undefined {
    const paths = this.dirtyAll ? new Set([...this.entries.keys(), ...this.printed.keys()]) : this.dirty;
    const step: DiffStep = { seq: this.seq + 1, added: new Map(), removed: new Set(), updated: new Map() };
    for (const path of paths) {
      const e = this.entries.get(path);
      const before = this.printed.get(path);
      if (!e) {
        if (before !== undefined) {
          step.removed.add(path);
          this.printed.delete(path);
        }
        continue;
      }
      const now = fingerprint(e);
      if (before === now) continue;
      if (before === undefined) step.added.set(path, copyEntry(e));
      else step.updated.set(path, copyEntry(e));
      this.printed.set(path, now);
    }
    this.dirty.clear();
    this.dirtyAll = false;
    if (step.added.size + step.removed.size + step.updated.size === 0 && !this.trashMoved) return undefined;
    if (this.trashMoved) this.trashSeq = step.seq;
    this.trashMoved = false;
    this.seq = step.seq;
    this.diffs.push(step);
    if (this.diffs.length > this.keepDiffs) this.diffs.splice(0, this.diffs.length - this.keepDiffs);
    const diff = this.since(this.seq - 1) as Diff;
    this.onChange?.(diff);
    return diff;
  }

  /**
   * The diff over (`from`, `seq`] -- with the Trash's slots if they were re-read
   * within it -- or the whole tree when `from` is older than the diffs kept (or
   * ahead of `seq`: a client from another server's run). `GET tree?since=`.
   */
  since(from: number): Diff | TreeAnswer {
    if (from === this.seq) return { from, seq: this.seq, added: [], removed: [], updated: [] };
    const oldest = this.diffs[0]?.seq ?? this.seq + 1;
    if (from > this.seq || from < oldest - 1) return this.answer();
    const added = new Map<string, Entry>();
    const updated = new Map<string, Entry>();
    const removed = new Set<string>();
    for (const step of this.diffs) {
      if (step.seq <= from) continue;
      for (const [path, e] of step.added) {
        if (removed.delete(path)) updated.set(path, e);
        else added.set(path, e);
      }
      for (const [path, e] of step.updated) {
        if (added.has(path)) added.set(path, e);
        else updated.set(path, e);
      }
      for (const path of step.removed) {
        if (added.delete(path)) continue;
        updated.delete(path);
        removed.add(path);
      }
    }
    // The slots are read anew each time, never changed in place: sent as they are.
    const trash = this.trashSeq > from ? { trash: this.trash } : {};
    return { from, seq: this.seq, added: [...added.values()], removed: [...removed], updated: [...updated.values()], ...trash };
  }

  /** `GET tree`'s answer: every entry, the Trash's slots, and what the prune removed. */
  answer(): TreeAnswer {
    return { seq: this.seq, tree: this.tree(), trash: this.trash, ...(this.pruned ? { pruned: { ...this.pruned } } : {}) };
  }

  /** Every entry, by path. */
  tree(): Entry[] {
    return [...this.entries.values()].sort((a, b) => byPath(a.path, b.path)).map(copyEntry);
  }

  // ---------------------------------------------------------------- reading the index

  /** The paths the index has in a folder (not under it): its folder list, never a walk of every entry. */
  inFolder(dir: string): Iterable<string> {
    return this.byDir.get(norm(dir)) ?? [];
  }

  /**
   * The paths whose path gives `key` -- a source's export key, a shipping
   * file's own -- whatever their role: what "a second source for a key" (§2)
   * is looked up in, by the key's list, never a walk of every entry.
   */
  withKey(key: string): Iterable<string> {
    return this.byKey.get(key) ?? [];
  }

  /** Every source, by path. */
  sources(): string[] {
    return [...this.entries.values()]
      .filter((e) => e.role === 'source')
      .map((e) => e.path)
      .sort(byPath);
  }

  /** A source's status as the index has it. */
  status(path: string): Status | undefined {
    return this.entries.get(norm(path))?.status;
  }

  /**
   * The LFS pointers in every root, as the one terminal line said at the start:
   * the boot set's first and marked, since the game cannot boot on those.
   */
  pointerLine(): string | undefined {
    const pointers = [...this.entries.values()].filter((e) => e.pointer).map((e) => e.path).sort(byPath);
    if (pointers.length === 0) return undefined;
    const boot = pointers.filter((p) => under(p, ROOTS.boot.dir)).map((p) => `${p} (boot set: the game cannot start)`);
    const rest = pointers.filter((p) => !under(p, ROOTS.boot.dir));
    const n = pointers.length;
    return `[assets] ${n} file${n === 1 ? ' is an LFS pointer' : 's are LFS pointers'}, not the file${n === 1 ? '' : 's'} -- run git lfs install && git lfs pull: ${[...boot, ...rest].join(', ')}`;
  }
}
