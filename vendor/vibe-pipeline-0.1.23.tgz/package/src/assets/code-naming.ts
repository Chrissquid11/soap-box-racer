/**
 * What game code names, before a move or a rename (Docs/asset-ids.md rule 5): files name an asset by uid and follow
 * it wherever it goes, but code holds keys -- `prefab('crates/big')`, `Assets.instance('props/crate')`,
 * `Audio.sfx('ui/click')` -- so an asset any code names keeps its key until the code changes first. One check for
 * every kind, and for both of its callers: the Assets panel's rename and move (`@vibe/pipeline/code-naming`) and the
 * studio's `asset_move` run by the dev server with no tab (Docs/mcp.md M3).
 *
 * - **`entryKey`**: a row's key -- its own, else a source's first export's, else the one its recipe would give it.
 * - **`namedKeys`**: the keys a move or a rename of a path changes -- a file's own (a source's, each of its exports'),
 *   or every key under a folder and its twin, and each prefab's under it.
 * - **`codeNaming`**: each key's uses in `.ts` files (`GET uses`, matched in any case, as a lookup takes it), by file
 *   and line -- the refusal's words, or null.
 *
 * Pure and node-free, like `kinds.ts`: the editor imports it in the browser.
 */
import type { Entry, Use } from './api-types.ts';
import { KINDS, PREFAB_SUFFIX, ROOTS } from './kinds.ts';
import { exportKey, twin, under } from './paths.ts';
import { isFound, recipeFor } from './recipes.ts';
import { caseKey } from '@vibe/engine/case-key';

/** A row's key: its own, else a source's first export's, else what its recipe would key it as; none for a row with none. */
export function entryKey(row: Entry, entries: ReadonlyMap<string, Entry>): string | undefined {
  if (row.key !== undefined) return row.key;
  if (row.role !== 'source') return undefined;
  const first = row.exports?.[0];
  const made = first !== undefined ? entries.get(first)?.key : undefined;
  if (made !== undefined) return made;
  const recipe = recipeFor(row.path);
  return isFound(recipe) ? exportKey(row.path, recipe.row.to) : undefined;
}

/** Where the prefab files are: `src/assets/prefabs`. */
const PREFABS = `${ROOTS.boot.dir}/${KINDS.prefabs.dir}`;

/** A prefab file's key from its path -- `src/assets/prefabs/Crates/Big.prefab` is `crates/big` -- or undefined for any other. */
export function prefabKeyOf(path: string): string | undefined {
  if (!path.startsWith(`${PREFABS}/`) || !path.endsWith(PREFAB_SUFFIX)) return undefined;
  const key = path.slice(PREFABS.length + 1, -PREFAB_SUFFIX.length);
  return key.split('/').some((s) => s.startsWith('_')) ? undefined : caseKey(key);
}

/** A prefab the game has: its key, and its file's path. */
export interface PrefabAt {
  key: string;
  path: string;
}

/**
 * The keys a move or a rename of `path` changes: a file's own (a source's, each export's), or every key under a
 * folder and its twin, and every prefab's of `prefabs` (the game's, with their files) under it -- at most `cap`.
 */
export function namedKeys(path: string, isDir: boolean, entries: ReadonlyMap<string, Entry>, prefabs: readonly PrefabAt[], cap = Infinity): string[] {
  const keys = new Set<string>();
  const add = (row: Entry): void => {
    const key = entryKey(row, entries);
    if (key !== undefined) keys.add(key);
    for (const e of row.role === 'source' ? (row.exports ?? []) : []) {
      const made = entries.get(e)?.key;
      if (made !== undefined) keys.add(made);
    }
  };
  if (!isDir) {
    const row = entries.get(path);
    if (row) add(row);
    const prefab = prefabKeyOf(path);
    if (prefab !== undefined) keys.add(prefab);
    return [...keys];
  }
  const other = twin(path);
  for (const e of entries.values()) {
    if (keys.size >= cap) break;
    if (under(e.path, path) || (other !== undefined && under(e.path, other))) add(e);
  }
  for (const p of prefabs) if (keys.size < cap && under(p.path, path)) keys.add(p.key);
  return [...keys];
}

/**
 * Game code naming any of `keys`: each key's uses (`uses`, the API's `GET uses`) in `.ts` files, one ask a key in any
 * case -- the refusal's words, naming each file and line, or null when no code names them.
 */
export async function codeNaming(keys: readonly string[], uses: (key: string) => Promise<readonly Use[]>): Promise<string | null> {
  const seen = new Set<string>();
  const lines: string[] = [];
  for (const key of keys) {
    if (seen.has(caseKey(key))) continue;
    seen.add(caseKey(key));
    const named = (await uses(key).catch(() => [] as readonly Use[])).filter((u) => u.file.endsWith('.ts'));
    if (named.length > 0) lines.push(`${key} in ${named.map((u) => `${u.file}:${u.line}`).join(', ')}`);
  }
  return lines.length === 0 ? null : `game code names ${lines.length === 1 ? 'it' : 'them'}: change it there first -- ${lines.join('; ')}`;
}
