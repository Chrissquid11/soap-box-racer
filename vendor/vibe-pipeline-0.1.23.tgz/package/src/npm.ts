/**
 * npm as a program to spawn on a platform: on Windows `npm.cmd`, which Node runs only through the shell (a `.cmd`
 * spawned without one is refused, EINVAL), each argument with a space or a quote put in double quotes for
 * `cmd.exe`; `npm` itself elsewhere, the arguments as they are. Pure; `npm.test.ts`. `vibe pack`'s `npm pack` and
 * `vibe new`'s `npm install` go through it (the studio's tasks and the launcher spell theirs the same way).
 */

/** A word for `cmd.exe`: as it is when plain, else in double quotes (a `"` in it doubled). */
export const cmdQuote = (word: string): string => (/^[\w@%+=:,./\\-]+$/.test(word) ? word : `"${word.replace(/"/g, '""')}"`);

/** How to spawn `npm <args>` on `platform`. */
export function npmSpawn(args: readonly string[], platform: NodeJS.Platform = process.platform): { command: string; args: string[]; shell: boolean } {
  return platform === 'win32' ? { command: 'npm.cmd', args: args.map(cmdQuote), shell: true } : { command: 'npm', args: [...args], shell: false };
}
