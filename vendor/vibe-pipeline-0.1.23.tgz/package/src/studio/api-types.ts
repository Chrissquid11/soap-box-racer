/**
 * Studio's routes and push messages (Docs/studio.md): what the dev server
 * answers under `/__studio/` and pushes under the assets channel's event, to this machine's tabs alone, as
 * `{ type: 'studio', kind: 'studio:<name>', ... }`.
 * Types only, no `node:` import: the editor's studio cards (2.3) import them in the browser
 * (`@vibe/pipeline/studio-types`).
 *
 * | route                          | answer                                                        |
 * | ------------------------------ | ------------------------------------------------------------- |
 * | `GET  log?stream=&since=`      | `LogAnswer`                                                   |
 * | `GET  tasks`                   | `TasksAnswer`                                                 |
 * | `POST run { script, args? }`   | `{ name, from }`; 400 not allowed, 409 `{ running }`          |
 * | `POST cancel`                  | `{ cancelled }`; 409 when nothing runs                        |
 * | `GET  problems`                | `Problem[]`                                                   |
 * | `GET  checks`                  | `CheckRow[]`                                                  |
 * | `GET  dist`                    | `DistAnswer`; 404 when there is no `dist/`                    |
 * | `GET  preview`, `POST preview` | `{ url }`, `{ url: null }` when none runs (GET)               |
 * | `POST reveal { path }`         | `{ ok: true }`; 501 `{ why: 'no shell' }` in a browser; a path under dist/, src/, AssetsSource/, public/, packs/ |
 * | `GET  download?tool=ffmpeg`    | `DownloadState`                                               |
 * | `GET  tree`                    | `FilesAnswer`                                                 |
 * | `GET  file?path=&at=`          | `FileAnswer`; 400 a bad path or `at`, 404 missing (or not in `at`'s tree; `.git/` always), 413 over `FILE_LIMIT`, 415 binary |
 * | `PUT  file { path, text, ifMtime }` | `{ mtime }`; 412 `FileConflict`, 423 `FileLocked`, 403 read-only, 400, 413 |
 * | `GET  search?q=&glob=`         | `SearchAnswer`; 400 no `q`                                    |
 * | `POST files/new { path, folder? }` | `FileMade`; 409 `FileClash`, 403 read-only or generated, 404 no such folder, 400 |
 * | `POST files/move { from, to, replace? }` | `FilesMoved`: imports updated through TypeScript, an asset's through the assets' move; 409 `FileClash`, 403, 404, 423, 400 into itself |
 * | `POST files/copy { from, to, replace? }` | `FilesCopied`; 409 `FileClash`, 403, 404, 400 |
 * | `POST files/delete { paths, check? }` | `FilesDeleted`; `check: true` checks alone (the app's Trash does the rest); 403, 404, 423 |
 * | `POST download { tool }`       | `DownloadState` as it starts (`downloading`): `studio:download` and `GET download` carry the rest -- `done` with its `path`, or `failed` with `why` (a checksum that differs: the file removed); 400 a tool not offered, 501 no build pinned here, 409 `{ why }` while one runs |
 * | `GET  git/status`              | `GitStatus`: both repositories' branches and changes                    |
 * | `GET  git/log?count=`          | `GitLog[]`: the last `count` (20; at most 100) commits of each repository, with their files |
 * | `GET  git/branches`            | `GitBranches[]`                                               |
 * | `GET  git/diff?paths=&paths=`  | `GitDiff`: the unified diff of those paths against `HEAD`, untracked ones as new; cut at `GIT_DIFF_LIMIT` |
 * | `POST git/commit { message, paths, repo }` | `GitCommitted`; 400 no message or no paths, 409 `{ why }` git's refusal (an identity unset: `git config user.name`) |
 * | `POST git/checkout { branch, repo, create?, confirm? }` | `GitRan`, or `GitAsk` with local changes until `confirm: true`; 409 `{ why }` git's refusal |
 * | `POST git/push { repo, confirm? }` | `GitAsk` the first time, always; `confirm: true` pushes: `GitRan`; 409 `{ why, lines }` git's refusal |
 * | `POST git/pull { repo, confirm? }` | the same, `git pull --ff-only`: a pull that is no fast-forward is 409 with git's words, never a merge |
 * | `GET  debug/state`            | `DebugState`: attached to a studio tab in a Chrome with a debugging port, or not |
 * | `GET  debug/breakpoints`       | `DebugBreakpoint[]`                                           |
 * | `POST debug/breakpoints { file, line }` | `DebugBreakpoint[]`: toggled, answered once tried; 400 no place for one |
 * | `POST debug/open`              | `{ ok: true }`: the Debugger tab opened or brought forward; 409 not attached |
 * | `GET  debug/view`              | `DebugView`                                                   |
 * | `POST debug/command { command, arg? }` | `{ ok: true }`; 400 no such command, 409 not attached |
 * | `GET  debugger`                | the Debugger tab's page (HTML)                                |
 * | `GET  broken`                  | `BrokenAnswer`: the project's modules Vite cannot serve now, and the reloads held for them |
 * | `POST stack { stack }`         | `MappedStack`: a runtime error's stack, each frame of a project file at its TypeScript line; 400 no `stack` |
 * | `GET  probe?id=`               | the probe page (HTML) of a probe waiting: each file it asks about imported fresh in a realm of its own (`probe.ts`); 404 none |
 * | `POST probe { id, ack } \| { id, results }` | `{ ok: true }`: the editor's ack, or the probe page's `ProbeResult[]`; 404 no such probe waits |
 * | `POST unhold`                  | `BrokenAnswer`: the modules held for having thrown as they were evaluated let go ("Reload anyway"), the held reload sent if nothing else is broken |
 *
 * Every request is this machine's: from an address that is not loopback, `403`, a GET too. Every
 * mutating call goes through the pipeline's guards as well (`assets/http.ts`' `guardWrite`): this
 * server's own page if from a page, a POST as JSON.
 */

/** Where the studio's routes are mounted. */
export const STUDIO_PREFIX = '/__studio/';

/**
 * A project's Chrome debugging port is its dev server's port plus this (5190 -> 9222): two projects under VS Code's
 * F5 at once each have their own. `vibe new` writes it into the template's "Studio (dev)" (`__DEBUG_PORT__`).
 */
export const DEBUG_PORT_OFFSET = 4032;

/** One line of a stream: its number in the stream (from 1, never reused), when it came (ms since the epoch), its text with any ANSI kept. */
export interface LogLine {
  seq: number;
  at: number;
  text: string;
}

/** `GET log`: the lines after `since`, and the stream's last seq (`0` for a stream nothing has written to). */
export interface LogAnswer {
  seq: number;
  lines: LogLine[];
}

/** A task that ran: its script, its exit code (null when a signal ended it), the signal, when it ended. */
export interface TaskEnd {
  name: string;
  code: number | null;
  signal: string | null;
  at: number;
  /** Ended by a Stop (`tasks.cancel`: the cards' Stop, `POST cancel`, `job_cancel`), whatever its code or signal says. */
  stopped?: boolean;
}

/** `GET tasks`: the scripts a run may name (the allow-list that the project's `package.json` has), what runs, what ran last. */
export interface TasksAnswer {
  allowed: string[];
  running: string | null;
  last: TaskEnd | null;
}

/** One error tsc reported: the file relative to the root (posix), its line and column -- or the program's own file with `line: 0, col: 0` for an error of no file's (a bad tsconfig, no inputs) -- `TS2322`, the message, the program (`tsconfig.json`, `tsconfig.node.json`). */
export interface Problem {
  file: string;
  line: number;
  col: number;
  code: string;
  message: string;
  program: string;
}

/**
 * A module Vite cannot serve (Docs/studio.md §1, "Mid-session"): a syntax error, an import of a file that is not there --
 * its transform's error, the file relative to the root (posix), line and column from 1 (0 when Vite named none), the
 * message's first line that says something.
 */
export interface CodeError {
  file: string;
  line: number;
  col: number;
  message: string;
  /**
   * It transforms, but threw as the probe page evaluated it (`probe.ts`): `message` is what it threw, the place its
   * first project frame. Absent for Vite's errors.
   */
  evaluated?: true;
  /** An evaluated one's stack, mapped to the TypeScript (`mapStack`). */
  stack?: string;
}

/** The program the Problems card's rows of Vite's errors name (tsc's are `tsconfig.json`, `tsconfig.node.json`): `broken.ts`' rows. */
export const VITE_PROGRAM = 'vite';

/**
 * A studio page's word to the dev server as it connects (a custom event on Vite's websocket, no data): the editor's
 * hub (studio mode) and the Debugger tab say it. The studio pushes, the debugger's look for a studio tab and the
 * evaluation probe are for these sockets alone -- never the plain page's, nor the probe frame's own Vite client.
 */
export const STUDIO_HELLO = 'studio:hello';

/** The probe page's word to the editor that made its frame that it is done (`postMessage`'s `{ type, id }`). */
export const PROBE_DONE = 'vibebase:probe-done';

/** One file the probe page evaluated (`POST probe`'s `results`): what it threw, or null -- it evaluates. */
export interface ProbeResult {
  file: string;
  threw: { message: string; stack: string } | null;
}

/** `GET broken`, and `studio:broken`: every module broken now, and the files whose page reload waits until none is. */
export interface BrokenAnswer {
  errors: CodeError[];
  held: string[];
}

/** `POST stack`: the stack with each project frame at its TypeScript place, and the first such frame under `src/` (null: none). */
export interface MappedStack {
  stack: string;
  at: { file: string; line: number; col: number } | null;
}

/** `GET checks`: one row per thing the machine needs -- found and working (`ok`), its version, a sentence for a person. */
export interface CheckRow {
  name: string;
  ok: boolean;
  version?: string;
  detail: string;
}

/** `GET dist`: `dist/` measured -- every folder (recursive bytes and files), the ten largest files -- and when. */
export interface DistAnswer {
  at: number;
  folders: { path: string; bytes: number; files: number }[];
  largest: { path: string; bytes: number }[];
}

/** A download's state: idle, under way, done (the binary's `path`), or failed (`why`). */
export interface DownloadState {
  tool: string;
  state: 'idle' | 'downloading' | 'unpacking' | 'done' | 'failed';
  received: number;
  /** The archive's size, from the answer's `Content-Length`; null when it said none. */
  total: number | null;
  path?: string;
  why?: string;
}

/**
 * What the studio pushes, `kind` naming it. `studio:log` carries a stream's new lines -- a task's
 * output too, on `task:<name>`, so a task's lines ride the log push and `studio:task` says only
 * `started` (with `from`, the seq its first line will have) and `ended`. At most one `studio:log` per
 * stream per 50 ms; `studio:download` every 250 ms while one runs, and at each change of state.
 * `studio:file-changed` is sent for every file under the tree's roots the watcher sees change or go (the mtime
 * null when gone), the Code card matching it against what it has open -- never for `node_modules`.
 */
export type StudioMessage =
  | { kind: 'studio:log'; stream: string; seq: number; lines: LogLine[] }
  | { kind: 'studio:file-changed'; path: string; mtime: number | null; change: 'changed' | 'removed' }
  | { kind: 'studio:task'; name: string; state: 'started'; from: number; at: number }
  | { kind: 'studio:task'; name: string; state: 'ended'; code: number | null; signal: string | null; at: number }
  | { kind: 'studio:problems'; problems: Problem[]; at: number }
  | ({ kind: 'studio:broken' } & BrokenAnswer)
  | { kind: 'studio:probe'; id: string; url: string }
  | { kind: 'studio:dist'; dist: DistAnswer }
  | { kind: 'studio:preview'; url: string | null }
  | ({ kind: 'studio:download' } & DownloadState)
  | { kind: 'studio:debug-state'; state: DebugState }
  | { kind: 'studio:debug-breakpoints'; list: DebugBreakpoint[] }
  | { kind: 'studio:debug-hit'; file: string; line: number }
  | { kind: 'studio:debug-view'; view: DebugView };

// ---- The Code card: files (Docs/studio.md) ----

/** A file's text over this many bytes is not answered (`413`): the card is for source, not a model. */
export const FILE_LIMIT = 2 * 1024 * 1024;

/** `GET search` answers at most this many hits. */
export const SEARCH_LIMIT = 500;

/**
 * One file the Code card may show: its path from the project's root (posix, `src/game/x.ts`, the engine's
 * `engine/src/...` in source mode), whether a git tracks it, and whether the card may write it (false under
 * `node_modules/`, where a definition may land: a package's shipped source, read and never saved).
 */
export interface FileEntry {
  path: string;
  tracked: boolean;
  readOnly: boolean;
  /** Written by `vibe assets` (`keys.d.ts`, the globs, `live.ts`): shown, read-only, never moved, renamed or deleted. */
  generated?: true;
}

/** `GET tree`: every file the card may open (tracked, and untracked under the roots `src/`, `AssetsSource/`, `packs/`, `public/`, `engine/`; never `node_modules`, `.git`, `.cache`, `.trash`, `dist`), and when it was listed. */
export interface FilesAnswer {
  at: number;
  files: FileEntry[];
  /** The project's folder, absolute: the Code card's Copy Path. */
  root?: string;
}

/** `POST files/new`: a file made empty, or a folder. */
export interface FileMade {
  path: string;
  folder: boolean;
}

/** `POST files/move`, `files/copy`, `files/new`, 409: something is at `clash` already -- the card asks Replace, Keep both or Cancel. */
export interface FileClash {
  why: string;
  clash: string;
}

/**
 * `POST files/move`: what moved, from and to (an asset's family whole, a folder as one pair); the files whose imports
 * TypeScript rewrote (`edited`) or the assets' repair pass did (`rewritten`); `via` which way it went -- `files` (a rename
 * on disk, TypeScript's `workspace/willRenameFiles` first) or `assets` (the Assets panel's move: uids kept, keys
 * rewritten, refused while code names the asset). `imports` says why no import was updated, when none could be.
 */
export interface FilesMoved {
  via: 'files' | 'assets';
  moved: Array<[string, string]>;
  edited: string[];
  /**
   * Files a Code card tab has open whose imports changed: never written here -- the tab's model took the edits
   * (`vibe/applyEdits`) and saved them if it was clean (VS Code's `files.refactoring.autoSave`), else holds them unsaved.
   */
  held: string[];
  rewritten: string[];
  imports?: string;
}

/**
 * `vibe/applyEdits`, the bridge's notification to the tab that has a file open: a move's import edits for it (LSP text
 * edits, against that tab's text), `was` the path the tab opened it at and `path` where it is now.
 */
export interface ApplyEdits {
  path: string;
  was: string;
  edits: Array<{ range: { start: { line: number; character: number }; end: { line: number; character: number } }; newText: string }>;
}

/** `POST files/copy`: the copies made (an asset's through the assets' copy: a new uid, named by it). */
export interface FilesCopied {
  via: 'files' | 'assets';
  copies: string[];
}

/** `POST files/delete`: what went -- for good (`files`), to the project's `.trash/` (`assets`, its `slot`), or nothing yet (`checked`). */
export interface FilesDeleted {
  via: 'files' | 'assets' | 'checked';
  removed: string[];
  slot?: string;
}

/**
 * `GET file`: the text as it is on disk, with the mtime a save must quote (`ifMtime`) -- or, with `at`, as it was
 * at a turn's start (`at=<turn>`: the agent's snapshot of the turn, for a diff's "before") or as git last
 * committed it (`at=HEAD`); then `mtime` is null and `at` says which.
 */
export interface FileAnswer extends FileEntry {
  text: string;
  mtime: number | null;
  at?: string;
}

/** `PUT file`'s answer: the file's new mtime (ms), for the next save's `ifMtime`. */
export interface SavedAnswer {
  mtime: number;
}

/** `PUT file`, 412: the file changed since the `ifMtime` quoted -- the text on disk now, and its mtime, so the card may show both. */
export interface FileConflict {
  why: string;
  text: string;
  mtime: number;
}

/** `PUT file`, 423: a conversation's turn is writing this file; the card says which. */
export interface FileLocked {
  why: string;
  conversation: { id: string; title: string };
}

/** One hit of a search: the file, its line (from 1) and column (from 1, UTF-16 units), the line's text (trimmed of its newline). */
export interface SearchHit {
  path: string;
  line: number;
  col: number;
  text: string;
}

/** `GET search?q=&glob=`: the first `SEARCH_LIMIT` hits (`truncated` when there were more) over the tree's files, `q` a literal (case-insensitive), `glob` a filter on paths (`**\/*.lua`); by `rg` when the machine has it, else a walk -- the same hits either way. */
export interface SearchAnswer {
  hits: SearchHit[];
  truncated: boolean;
  by: 'rg' | 'walk';
}

// ---- The Code card: the TypeScript bridge (Docs/studio.md) ----

/**
 * The bridge's events on Vite's websocket. A tab sends `TS_REQ` with one LSP message -- a JSON-RPC request
 * (`id`, `method`, `params`) or a notification (no `id`): `textDocument/didChange`, `didClose`, and every
 * request the server lists in its capabilities -- and the bridge answers a request with `TS_RES` carrying the
 * JSON-RPC response (the tab's own `id`; ids are the tab's, renumbered on the way to the one server and back).
 * A notification the server sends (`textDocument/publishDiagnostics`, a `window/showMessage`) comes down as
 * `TS_EVENT` to the tab holding the file, or to every tab when it names none. The tab never sends
 * `initialize`: the bridge owns the handshake, and a tab's first message waits for it.
 *
 * Two methods are the bridge's own, not the server's: `vibe/open { uri, text, version, languageId }`
 * answers `TsOpenAnswer` -- the file opened on the server by this tab when no other tab holds it (then
 * `owner: true`; its `didChange`/`didClose` are forwarded) or read-only (`owner: false`, the holder's text the
 * server's: queries work, edits are not forwarded); the owner's `vibe/open` again with a newer `version` sends
 * the server its text whole (a buffer read again from the disk); `vibe/status` answers `TsStatus`. A tab's
 * files are closed when its socket goes.
 *
 * And one notification is the bridge's own: `{ method: 'vibe/status', params: TsStatus }`, as `TS_EVENT` to
 * every page socket of this machine at each change of state (starting, up, failed, off). The card relies on
 * it: `up` after `failed` means a server that has forgotten every file, and the tab opens its own again.
 *
 * A message from a tab that is not this machine's is answered with a JSON-RPC error `TS_REFUSED`; one unanswered
 * for `TS_TIMEOUT` ms with `TS_TIMED_OUT`; one sent while the server is down (failed to spawn, or crashed and not
 * yet back) with `TS_DOWN` and the reason.
 */
export const TS_REQ = 'vibe:ts:req';
export const TS_RES = 'vibe:ts:res';
export const TS_EVENT = 'vibe:ts:event';

/** How long a request to the server may take before the bridge answers an error. */
export const TS_TIMEOUT = 30_000;

/** The bridge's own JSON-RPC error codes. */
export const TS_REFUSED = -32000;
export const TS_TIMED_OUT = -32001;
export const TS_DOWN = -32002;

/** What `TS_REQ`, `TS_RES` and `TS_EVENT` carry: one LSP message, as the protocol has it. */
export interface TsEnvelope {
  message: unknown;
}

/** `vibe/open`'s answer. */
export interface TsOpenAnswer {
  owner: boolean;
  /** When not the owner: the tab that is, for the card's words. */
  heldBy?: string;
  /** A reader that never owns (`read: true`): the file opened on the server for it, owned by no tab -- `vibe/release` gives it back. */
  lent?: boolean;
}

/** `vibe/status`'s answer: the server's state, the project's root as an absolute path (what a tab's `file://` uris start with), TypeScript's version, the reason when `failed`. */
export interface TsStatus {
  state: 'off' | 'starting' | 'up' | 'failed';
  root: string;
  version?: string;
  why?: string;
}

// ---- The Git card (Docs/studio.md) ----

/** A repository of the project: its own (`project`), and the engine's submodule (`engine`) in source mode. */
export type GitRepo = 'project' | 'engine';

/** `GET git/log` answers at most this many commits a repository; `GIT_LOG_COUNT` when `count` says none. */
export const GIT_LOG_MAX = 100;
export const GIT_LOG_COUNT = 20;

/** `GET git/diff`'s text at most, in bytes: what a prompt can carry. */
export const GIT_DIFF_LIMIT = 100 * 1024;

/** One repository's head: its branch (null when `HEAD` is detached), its upstream (`origin/main`, null for none), how far ahead and behind it as last fetched, and no change of its in the project. */
export interface GitRepoStatus {
  repo: GitRepo;
  /** Where it is, as the project names its files: `''` the project's own, `engine/` the engine's. */
  root: string;
  branch: string | null;
  upstream: string | null;
  ahead: number;
  behind: number;
  clean: boolean;
}

/**
 * One changed file, its path the project's (relative to its root, `/`; the engine's under `engine/`): the kind of
 * change (`staged` when the index has it -- the card adds what it commits anyway), and for a rename the path it had.
 */
export interface GitChange {
  path: string;
  repo: GitRepo;
  kind: 'modified' | 'added' | 'deleted' | 'renamed' | 'untracked' | 'conflict';
  staged: boolean;
  from?: string;
}

/** `GET git/status`: no repository (no git at all) is `{ repos: [], changes: [] }`. */
export interface GitStatus {
  repos: GitRepoStatus[];
  changes: GitChange[];
}

/** One commit: its hash and the short one, the author, when (ISO 8601), its subject, and each file's lines added and deleted (null for a binary). */
export interface GitLogEntry {
  hash: string;
  short: string;
  author: string;
  date: string;
  subject: string;
  files: { path: string; added: number | null; deleted: number | null }[];
}

/** `GET git/log`: a repository's last commits, newest first; a repository with none, an empty list. */
export interface GitLog {
  repo: GitRepo;
  entries: GitLogEntry[];
}

/** `GET git/branches`: a repository's local branches, the current one said (none current when `HEAD` is detached). */
export interface GitBranches {
  repo: GitRepo;
  current: string | null;
  branches: { name: string; upstream: string | null; current: boolean }[];
}

/** `GET git/diff`: the diff's text, `truncated` when it was cut at `GIT_DIFF_LIMIT`. */
export interface GitDiff {
  diff: string;
  truncated: boolean;
}

/** `POST git/commit`: the commit made. */
export interface GitCommitted {
  hash: string;
  short: string;
}

/** A checkout, push or pull not run yet: what it would do, in words to confirm (the host's ask rule's voice). */
export interface GitAsk {
  ask: string;
  confirm: false;
}

/** A checkout, push or pull run: git's last lines (at most 20). */
export interface GitRan {
  ok: true;
  lines: string[];
}

// ---- The debugger (Docs/studio.md §11, §13, the dev server's debugger) ----

/** A breakpoint as the Code card and the Debugger are told it: the project's path, a 1-based line, set in the game now. */
export interface DebugBreakpoint {
  file: string;
  line: number;
  set: boolean;
}

/** A row of the call stack: the function, its TypeScript place, whether the file is the project's (its source shown). */
export interface DebugFrame {
  function: string;
  file: string;
  line: number;
  col: number;
  ours: boolean;
}

/** The source pane: the lines around the frame's, or why there are none. */
export type DebugSource = { file: string; line: number; first: number; lines: string[] } | { file: string; line: number; none: string };

/** What the Debugger draws: told whole at each change (the app's IPC, `studio:debug-view`, `GET debug/view`). */
export interface DebugView {
  project: string;
  /** The words of an attach that failed or was let go (DevTools has it, no Chrome to attach to), else null. */
  attachError: string | null;
  /** The project's breakpoints, each with whether the game has it set now. */
  breakpoints: DebugBreakpoint[];
  pauseOnExceptions: 'none' | 'uncaught';
  /** The state line: "Running", "Paused at src/game/systems/spin.ts:19 · breakpoint". */
  words: string;
  paused: null | {
    reason: string;
    /** Paused by another client (VS Code's js-debug, sharing the tab): shown read-only, its to resume. */
    other: boolean;
    frames: DebugFrame[];
    selected: number;
    locals: { name: string; value: string }[];
    more: number;
    /** The chosen frame's source around its line, or why there is none. */
    source: DebugSource;
  };
}

/**
 * `GET debug/state`: is the dev server's debugger attached to a studio tab -- a Chrome started with
 * `--remote-debugging-port` (VS Code's F5, "Studio (dev)") on `port` -- and the tab's url.
 */
export interface DebugState {
  attached: boolean;
  /** The debugging port it looks on: `VIBE_DEBUG_PORT`, else "Studio (dev)"'s `port` in `.vscode/launch.json`, else its own port + 4032. */
  port: number;
  /** The tab attached to, or null. */
  page: string | null;
}
