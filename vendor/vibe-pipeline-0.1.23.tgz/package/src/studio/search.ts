/**
 * The Code card's search (Docs/studio.md): `GET search?q=&glob=` over the tree's files (`files.ts`' `listTree`:
 * the same roots and exclusions), `q` a literal matched case-insensitively (Unicode's simple case folding, as
 * `rg -i` does), `glob` a filter on paths (`globRegExp`). Every match is a hit -- two on a line are two -- with
 * its line (from 1), its column (from 1, in UTF-16 units, what the card's editor counts) and the line's text.
 * The first `SEARCH_LIMIT` in path order (`comparePaths`), then line, then column; `truncated` when there were
 * more.
 *
 * - **By `rg`** when the machine has it (`lookFor(RG)`, looked for once per server): `--json --fixed-strings
 *   --ignore-case --sort path`, every file but the excluded folders (`--no-ignore --hidden`, `!node_modules`
 *   ...) -- the tree's own list decides what counts, so what git ignores is left out the same way both ways. Its
 *   `match` lines read as they come: a submatch's byte offset turned into UTF-16 units from the line's text;
 *   the output stops being read at `SEARCH_LIMIT + 1` and rg is killed.
 * - **Else a walk**: each file read (binary ones -- a NUL in the first 8 KB -- skipped), line by line.
 *
 * The glob: `*` any run of a name's characters, `**` any run of folders (`**\/` none too), `?` one character,
 * `{a,b}` either (nested too); everything else itself; case-insensitive. A glob with no `/` is matched against
 * the file's name alone (`*.lua` is every Lua file), as `rg --glob` does. Nothing at module level.
 */
import { spawn } from 'node:child_process';
import { open } from 'node:fs/promises';
import { join } from 'node:path';
import { Refused } from '../assets/http.ts';
import { lookFor, RG } from '../assets/tools.ts';
import { SEARCH_LIMIT, type SearchAnswer, type SearchHit } from './api-types.ts';
import { readLines } from './child.ts';
import { comparePaths, EXCLUDED, listTree, SNIFF, type FilesContext } from './files.ts';

// ---------------------------------------------------------------- the glob

const escape = (text: string): string => text.replace(/[.+^${}()|[\]\\*?]/g, '\\$&');

/** The index of the `}` closing the `{` at `at`, or -1. */
function closing(glob: string, at: number): number {
  let depth = 0;
  for (let i = at; i < glob.length; i++) {
    if (glob[i] === '{') depth++;
    else if (glob[i] === '}' && --depth === 0) return i;
  }
  return -1;
}

/** `{a,b{c,d}}`'s top-level parts. */
function alternatives(inner: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let start = 0;
  for (let i = 0; i < inner.length; i++) {
    if (inner[i] === '{') depth++;
    else if (inner[i] === '}') depth--;
    else if (inner[i] === ',' && depth === 0) {
      parts.push(inner.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(inner.slice(start));
  return parts;
}

function globSource(glob: string): string {
  let out = '';
  for (let i = 0; i < glob.length; ) {
    const c = glob[i]!;
    if (c === '*' && glob[i + 1] === '*') {
      const atStart = i === 0 || glob[i - 1] === '/';
      if (atStart && glob[i + 2] === '/') {
        out += '(?:[^/]*/)*';
        i += 3;
      } else {
        out += '.*';
        i += 2;
      }
    } else if (c === '*') {
      out += '[^/]*';
      i++;
    } else if (c === '?') {
      out += '[^/]';
      i++;
    } else if (c === '{' && closing(glob, i) > i) {
      const end = closing(glob, i);
      out += `(?:${alternatives(glob.slice(i + 1, end)).map(globSource).join('|')})`;
      i = end + 1;
    } else {
      out += escape(c);
      i++;
    }
  }
  return out;
}

/** A glob as a test of a project path (module header). */
export function globRegExp(glob: string): (path: string) => boolean {
  const re = new RegExp(`^${globSource(glob)}$`, 'i');
  if (glob.includes('/')) return (path) => re.test(path);
  return (path) => re.test(path.slice(path.lastIndexOf('/') + 1));
}

// ---------------------------------------------------------------- the search

/** A literal, case-insensitive, every match on a line. */
const literal = (q: string): RegExp => new RegExp(escape(q), 'giu');

/** One line's hits. */
function lineHits(path: string, line: number, text: string, re: RegExp, into: SearchHit[]): void {
  re.lastIndex = 0;
  for (let m = re.exec(text); m !== null; m = re.exec(text)) into.push({ path, line, col: m.index + 1, text });
}

const byPlace = (a: SearchHit, b: SearchHit): number => comparePaths(a.path, b.path) || a.line - b.line || a.col - b.col;

/** The walk: each file of `files` (in order) read, binary ones skipped, until `limit + 1` hits. */
export async function searchWalk(root: string, files: readonly string[], q: string, limit = SEARCH_LIMIT): Promise<SearchHit[]> {
  const re = literal(q);
  const hits: SearchHit[] = [];
  for (const path of files) {
    let bytes: Buffer;
    try {
      const handle = await open(join(root, path), 'r');
      try {
        const head = Buffer.alloc(SNIFF);
        const { bytesRead } = await handle.read(head, 0, SNIFF, 0);
        if (head.subarray(0, bytesRead).includes(0)) continue;
        // From the start: a read at a given position moves no file position.
        bytes = await handle.readFile();
      } finally {
        await handle.close();
      }
    } catch {
      continue;
    }
    const lines = bytes.toString('utf8').split('\n');
    for (let i = 0; i < lines.length; i++) {
      const text = lines[i]!.endsWith('\r') ? lines[i]!.slice(0, -1) : lines[i]!;
      lineHits(path, i + 1, text, re, hits);
      if (hits.length > limit) return hits;
    }
  }
  return hits;
}

/** The bytes before `start` of `text`'s UTF-8, in UTF-16 units. */
export function utf16Column(text: string, byteStart: number): number {
  return Buffer.from(text, 'utf8').subarray(0, byteStart).toString('utf8').length;
}

/** rg's `--json` output, a line at a time: the hits of a `match` among `wanted`. */
export function rgHits(line: string, wanted: (path: string) => boolean, into: SearchHit[]): void {
  let event: { type?: string; data?: { path?: { text?: string }; lines?: { text?: string }; line_number?: number; submatches?: { start: number }[] } };
  try {
    event = JSON.parse(line) as typeof event;
  } catch {
    return;
  }
  if (event.type !== 'match' || !event.data) return;
  const raw = event.data.path?.text;
  const text = event.data.lines?.text;
  const number = event.data.line_number;
  if (raw === undefined || text === undefined || number === undefined) return;
  const path = raw.startsWith('./') ? raw.slice(2) : raw;
  if (!wanted(path)) return;
  const clean = text.replace(/\r?\n$/, '');
  for (const sub of event.data.submatches ?? []) into.push({ path, line: number, col: utf16Column(clean, sub.start) + 1, text: clean });
}

/** rg in the root: hits among `wanted` until `limit + 1`, then killed. Null when it could not run. */
export function searchRg(rg: string, root: string, q: string, wanted: (path: string) => boolean, limit = SEARCH_LIMIT): Promise<SearchHit[] | null> {
  const args = ['--json', '--fixed-strings', '--ignore-case', '--no-ignore', '--hidden', '--no-config', '--sort', 'path', ...[...EXCLUDED].flatMap((name) => ['--glob', `!${name}`]), '--', q];
  return new Promise((done) => {
    const hits: SearchHit[] = [];
    let child;
    try {
      child = spawn(rg, args, { cwd: root, stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true });
    } catch {
      done(null);
      return;
    }
    let enough = false;
    let failed = false;
    child.on('error', () => {
      failed = true;
    });
    readLines(child.stdout, (line) => {
      if (enough) return;
      rgHits(line, wanted, hits);
      if (hits.length > limit) {
        enough = true;
        child.kill('SIGTERM');
      }
    });
    child.on('close', () => done(failed ? null : hits));
  });
}

/** rg, once looked for: its path or null. */
export type RgLook = () => Promise<string | null>;

/** The look, made once (a server's). */
export function rgLook(root: string): RgLook {
  let look: Promise<string | null> | undefined;
  return () => (look ??= lookFor(RG, { root }).then((l) => (l.state === 'found' && l.path ? l.path : null), () => null));
}

/** `GET search?q=&glob=`. */
export async function search(context: FilesContext & { rg?: RgLook; limit?: number }, q: string | null, glob: string | null): Promise<SearchAnswer> {
  if (q === null || q === '') throw new Refused(400, 'q is what to find: one character at least');
  const limit = context.limit ?? SEARCH_LIMIT;
  const match = glob ? globRegExp(glob) : () => true;
  const files = (await listTree(context)).files.map((f) => f.path).filter(match);
  const rg = (await context.rg?.()) ?? null;
  let hits: SearchHit[] | null = null;
  let by: SearchAnswer['by'] = 'walk';
  if (rg !== null) {
    const wanted = new Set(files);
    hits = await searchRg(rg, context.root, q, (p) => wanted.has(p), limit);
    if (hits !== null) by = 'rg';
  }
  hits ??= await searchWalk(context.root, files, q, limit);
  hits.sort(byPlace);
  return { hits: hits.slice(0, limit), truncated: hits.length > limit, by };
}
