/**
 * ffmpeg for a machine without one that has libvorbis (Docs/studio.md): the
 * Tools page's Download (`POST /__studio/download { tool: 'ffmpeg' }`). An `.ogg` export needs an
 * ffmpeg with libvorbis (`assets/tools.ts`' `FFMPEG`), which Homebrew's lacks; a static build has it.
 *
 * - **A pinned table** (`FFMPEG_BUILDS`): per platform, a static build's URL, its sha256, the binary's
 *   path inside the archive, its licence and a notice of where it and its source come from. Pinned on
 *   2026-10-11, each file fetched once and its sha256 recorded (and compared with the publisher's
 *   `.sha256` where it has one). The macOS and Linux builds are Martin Riedl's (ffmpeg.martin-riedl.de,
 *   release 9.0.2), the Windows one gyan.dev's essentials build (8.1.2): each a `.zip`, so the unpack is
 *   `assets/zip.ts`' `readZipEntry` and the pipeline gains no dependency (a `.tar.xz` -- the usual Linux
 *   static build -- would need an xz reader node lacks). The table is re-pinned at each release of the
 *   studio, and the macOS and Windows files will be the studio's own release files then (the same table,
 *   other URLs), so a publisher's moving or removing a file cannot break a release. **linux-x64 stays a
 *   publisher download**: Riedl's Linux build is configured `--enable-nonfree` (usable, not
 *   redistributable), he offers no GPL-only variant, and the GPL-only Linux builds (johnvansickle.com,
 *   BtbN's) are `.tar.xz`.
 * - **The licence's text** ships once in the package (`licences/gpl-3.0.txt`: FFmpeg's own
 *   `COPYING.GPLv3`, in the tarball through `pack.ts`' `FILES`) and is copied beside the binary as
 *   `LICENCE.txt`, the build's notice as `NOTICE.txt`.
 * - **The download** (`downloadTool`): streamed to `<appData>/squidwright/tools/ffmpeg/<archive>`
 *   (`app-data.ts`), hashed as it comes, `studio:download { received, total, state }` pushed every
 *   250 ms; a checksum that differs removes the file and fails (`why`; `downloadTool` throws it as `409`); the binary taken out of
 *   the zip into a folder named for its version, made executable, `LICENCE.txt` and `NOTICE.txt` beside it, the archive
 *   removed, and its path written to the project's `assets.local.json` as the Tools page's "Set its
 *   path" does (`setLocalTool`) -- found first from then on (`lookFor`'s order).
 *
 * One download at a time, its state on the holder (`vite.ts`); the route answers as it starts, and the
 * pushes and `GET download` carry the rest. Nothing at module level.
 */
import { createHash } from 'node:crypto';
import { createWriteStream } from 'node:fs';
import { chmod, copyFile, mkdir, rm, writeFile } from 'node:fs/promises';
import { basename, join } from 'node:path';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import type { ReadableStream as WebReadableStream } from 'node:stream/web';
import { fileURLToPath } from 'node:url';
import { Refused } from '../assets/http.ts';
import { setLocalTool } from '../assets/tools.ts';
import { readZipEntry } from '../assets/zip.ts';
import type { DownloadState } from './api-types.ts';

/** The platforms a build is pinned for: `${process.platform}-${process.arch}`. */
export type ToolPlatform = 'darwin-arm64' | 'darwin-x64' | 'linux-x64' | 'win32-x64';

/** A static build: where it is, what it hashes to, where the binary is inside it, its licence, its notice. */
export interface ToolBuild {
  url: string;
  sha256: string;
  /** The binary's path inside the zip. */
  inArchive: string;
  /** Its licence's text: a file of the package's `licences/`, copied beside the binary as `LICENCE.txt`. */
  licence: string;
  /** Who built it, how, and where its source is: written beside the binary as `NOTICE.txt`. */
  notice: string;
  version: string;
}

/** The package's `licences/`: two folders up from here in both forms (`src/studio/`, `dist/studio/`). */
export const licencesDir = (): string => fileURLToPath(new URL('../../licences/', import.meta.url));

const GPL3 = 'the GNU General Public License, version 3 or later (https://www.gnu.org/licenses/gpl-3.0.txt)';

/** Riedl's builds: the same configuration on each platform, so the same words. */
const riedl = (platform: string, extra = ''): string =>
  `FFmpeg 9.0.2, a static build for ${platform} by Martin Riedl (https://ffmpeg.martin-riedl.de), configured with --enable-gpl --enable-version3${extra}: ` +
  `licensed under ${GPL3}. FFmpeg's source: https://ffmpeg.org/releases/ffmpeg-9.0.2.tar.xz; the libraries' versions: the build's versions.txt on the page above.\n`;

/** The pinned static builds (the module's comment: what, from where, re-pinned at each release). */
export const FFMPEG_BUILDS: Record<ToolPlatform, ToolBuild> = {
  'darwin-arm64': {
    url: 'https://ffmpeg.martin-riedl.de/download/macos/arm64/1789931890_9.0.2/ffmpeg.zip',
    sha256: 'c8ed4c4e6978a03c485edbfe4e0a5dc2380f8a30bba5150531b31b094492d924',
    inArchive: 'ffmpeg',
    licence: 'gpl-3.0.txt',
    notice: riedl('macOS on Apple silicon'),
    version: '9.0.2',
  },
  'darwin-x64': {
    url: 'https://ffmpeg.martin-riedl.de/download/macos/amd64/1789931006_9.0.2/ffmpeg.zip',
    sha256: '7c6b4125b191cbf773832dc51f424cf2b6bb7da43007d1e066f95909e47cacd4',
    inArchive: 'ffmpeg',
    licence: 'gpl-3.0.txt',
    notice: riedl('macOS on Intel'),
    version: '9.0.2',
  },
  'linux-x64': {
    url: 'https://ffmpeg.martin-riedl.de/download/linux/amd64/1789931100_9.0.2/ffmpeg.zip',
    sha256: 'fa8ecf4abbd290d98f7d188b8649cc6b391ae209a98452be955a15aab1909d7f',
    inArchive: 'ffmpeg',
    licence: 'gpl-3.0.txt',
    notice: riedl('Linux on x86-64', ' --enable-nonfree (so it may be used, not redistributed)'),
    version: '9.0.2',
  },
  'win32-x64': {
    url: 'https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-8.1.2-essentials_build.zip',
    sha256: 'db580001caa24ac104c8cb856cd113a87b0a443f7bdf47d8c12b1d740584a2ec',
    inArchive: 'ffmpeg-8.1.2-essentials_build/bin/ffmpeg.exe',
    licence: 'gpl-3.0.txt',
    notice: `FFmpeg 8.1.2, the essentials build for Windows by Gyan Doshi (https://www.gyan.dev/ffmpeg/builds/): licensed under ${GPL3}. FFmpeg's source: https://ffmpeg.org/releases/ffmpeg-8.1.2.tar.xz.\n`,
    version: '8.1.2',
  },
};

/** This machine's key in the table; undefined where nothing is pinned. */
export function toolPlatform(platform: string = process.platform, arch: string = process.arch): ToolPlatform | undefined {
  const key = `${platform}-${arch}`;
  return Object.hasOwn(FFMPEG_BUILDS, key) ? (key as ToolPlatform) : undefined;
}

/** What the routes offer to download. */
export const DOWNLOADS = ['ffmpeg'] as const;

export const idleDownload = (tool: string): DownloadState => ({ tool, state: 'idle', received: 0, total: null });

export interface DownloadOptions {
  /** The project's root: its `assets.local.json` gets the path. */
  root: string;
  tool: string;
  build: ToolBuild;
  /** The folder it goes in: `<appData>/squidwright/tools/<tool>`. */
  dir: string;
  /** The holder's: changed in place as it goes. */
  state: DownloadState;
  /** The state to every page. */
  send(state: DownloadState): void;
  fetch?: typeof fetch;
  progressMs?: number;
}

/** A download, start to end: the state done (its `path`), or a refusal thrown with the state failed. */
export async function downloadTool(options: DownloadOptions): Promise<DownloadState> {
  const { build, state, dir } = options;
  const fetcher = options.fetch ?? fetch;
  const say = (): void => options.send({ ...state });
  const set = (next: Partial<DownloadState>): void => {
    Object.assign(state, next);
    if (next.state !== 'failed') delete state.why;
    say();
  };
  delete state.path;
  set({ state: 'downloading', received: 0, total: null });
  const archive = join(dir, `${options.tool}-${build.version}.zip`);
  let ticker: ReturnType<typeof setInterval> | undefined;
  try {
    await mkdir(dir, { recursive: true });
    const res = await fetcher(build.url, { redirect: 'follow' });
    if (!res.ok || !res.body) throw new Refused(502, `${build.url} answered ${res.status} ${res.statusText}`.trim(), { why: `the download answered ${res.status}` });
    const length = Number(res.headers.get('content-length'));
    state.total = Number.isFinite(length) && length > 0 ? length : null;
    ticker = setInterval(say, options.progressMs ?? 250);
    const hash = createHash('sha256');
    const tap = new Transform({
      transform(chunk: Buffer, _encoding, done) {
        hash.update(chunk);
        state.received += chunk.length;
        done(null, chunk);
      },
    });
    await pipeline(Readable.fromWeb(res.body as WebReadableStream<Uint8Array>), tap, createWriteStream(archive)); // write-ok: the archive, in the app's own folder, removed after the unpack
    clearInterval(ticker);
    ticker = undefined;
    const got = hash.digest('hex');
    if (got !== build.sha256) {
      await rm(archive, { force: true });
      const why = `the download's sha256 is ${got}, not the ${build.sha256} pinned for it: the file was removed`;
      throw new Refused(409, why, { why });
    }
    set({ state: 'unpacking' });
    const binary = await readZipEntry(archive, build.inArchive);
    const home = join(dir, build.version);
    await mkdir(home, { recursive: true });
    const path = join(home, basename(build.inArchive));
    await writeFile(path, binary, { mode: 0o755 }); // write-ok: the binary, in the app's own folder
    await chmod(path, 0o755);
    await copyFile(join(licencesDir(), build.licence), join(home, 'LICENCE.txt'));
    await writeFile(join(home, 'NOTICE.txt'), build.notice); // write-ok: beside the binary
    await rm(archive, { force: true });
    await setLocalTool(options.root, options.tool, path);
    set({ state: 'done', path });
    return { ...state };
  } catch (err) {
    if (ticker) clearInterval(ticker);
    const why = err instanceof Refused ? String(err.body.why ?? err.message) : (err as Error).message;
    set({ state: 'failed', why });
    await rm(archive, { force: true }).catch(() => {});
    if (err instanceof Refused) throw err;
    throw new Refused(502, why, { why });
  }
}
