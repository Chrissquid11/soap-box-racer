/**
 * The debugger's core (Docs/studio.md §13): one project's breakpoints and pauses over Chrome's debugging protocol,
 * whatever carries it -- a `Cdp`. Two transports: the app's, `webContents.debugger` of a project's window
 * (`packages/studio/electron/debugger.ts`), and the dev server's, a WebSocket to the game's tab in a Chrome started
 * with `--remote-debugging-port` (`socket.ts`, `server.ts`: VS Code's F5). The pure parts are `model.ts`'.
 *
 * - **Attached** (`attach(cdp, origin)`): `Runtime.enable`, `Debugger.enable` -- which replays every script already
 *   parsed -- and the pause-on-exceptions state. **Let go** (`letGo(words)`): none is set, nothing is paused; the
 *   words (DevTools has it, the tab went) are the state line's until it attaches again (`failed(words)` the same for
 *   an attach that never took).
 * - **The breakpoints**: the host's store (`BreakpointStore`: the app's `breakpoints.json`, the dev server's
 *   `.cache/studio/breakpoints.json`), read once and replaced as it is written. Each is set with
 *   `Debugger.setBreakpointByUrl` once the script of its file has been parsed (`Debugger.scriptParsed`): the url the
 *   script was served at (a regex, any `?t=`/`?v=` query after it), the line mapped through the script's inline
 *   source map to its first code (`generatedFor`). A breakpoint set by url outlives a reload; a script parsed again
 *   is mapped again, and the breakpoint moved when its place changed. One the map cannot place is kept and not set:
 *   each is shown with its `set` (`ShownBreakpoint`).
 * - **Only our pauses are ours** (`isOurPause`, with `shared`): Chrome tells every client of every pause, and VS
 *   Code's js-debug shares the dev server's tab; the app's window has one client, and every pause there is ours. Another's is told to a Debugger already open, read-only ("Paused by another
 *   debugger"), and nothing else: no Debugger opened, no resume at its close, no hit for the page.
 * - **A pause** (`Debugger.paused`): the view -- the stack mapped back to the TypeScript, the chosen frame's locals
 *   (`Runtime.getProperties` of its block scopes and its function's: `localScopes`), its source around the line
 *   (`source`, the host's), the state line -- told (`tellView`), then the host's `paused` (open or bring forward its
 *   Debugger). A pause over before it was read (a step's) tells nothing. **Resumed**: the view told, and the game's
 *   page the place it last stopped at (`tellHit`), never between a step's pauses.
 * - **The commands** (`command`): `continue`, `stepOver`, `stepInto`, `stepOut`, `pause`, `pauseOnExceptions`
 *   (`'uncaught'` or `'none'`), `frame` (a frame of the stack chosen), `remove` (a breakpoint). `resumeIfPaused`: the
 *   Debugger closed while the game is stopped -- nothing else could resume it.
 *
 * Work on the session runs one after another (`later`: the breakpoints' set and remove, a pause's reading). Nothing
 * here knows Electron, a socket or a window: node's `fs` alone, for a project's real folder and its linked packages.
 */
import { existsSync, lstatSync, readdirSync, realpathSync } from 'node:fs';
import { join } from 'node:path';
import {
  breakpointKey,
  fileOfScript,
  frameRows,
  generatedFor,
  inlineMap,
  isBreakpoint,
  localRows,
  localScopes,
  mergeScopes,
  normalBreakpoints,
  parseMap,
  pausedWords,
  pauseReason,
  removeBreakpoint,
  shownBreakpoints,
  sourceAround,
  toggleBreakpoint,
  urlRegexFor,
  type Breakpoint,
  type FrameRow,
  type LinkedPackage,
  type LocalRow,
  type PausedEvent,
  type ProjectPlace,
  type PropertyDescriptor,
  type ScriptInfo,
  type ShownBreakpoint,
} from './model.ts';
import type { DebugSource, DebugView } from '../api-types.ts';

/** Chrome's debugging protocol, whatever carries it: a command answered, its events heard, let go. */
export interface Cdp {
  /** A command; its result, or a rejection with the protocol's words. */
  send<T = unknown>(method: string, params?: Record<string, unknown>): Promise<T>;
  /** Each event, `Debugger.paused` and the rest; the unsubscribe. */
  on(event: 'event', fn: (method: string, params: Record<string, unknown>) => void): () => void;
  /** The transport gone (the target closed, another client took it, the socket dropped), with its reason; the unsubscribe. */
  on(event: 'close', fn: (reason: string) => void): () => void;
  /** Let go. */
  close(): void;
}

export type { DebugSource, DebugView };

/** The state line while another client (VS Code's js-debug) has the game paused. */
export const OTHER_PAUSE = 'Paused by another debugger (VS Code)';

/**
 * Is this pause ours? Chrome sends `Debugger.paused` to every client with the debugger on. Ours: one of the breakpoints
 * we set (`hitBreakpoints`, by the ids `setBreakpointByUrl` gave), the pause our last command (`pause`, a step) led to,
 * or an exception while our pause on exceptions is `'uncaught'`.
 */
export function isOurPause(event: Pick<PausedEvent, 'reason' | 'hitBreakpoints'>, lastCommand: string | null, ids: ReadonlySet<string>, pauseOnExceptions: 'none' | 'uncaught'): boolean {
  if (event.hitBreakpoints?.some((id) => ids.has(id))) return true;
  if (lastCommand === 'pause' || lastCommand === 'stepOver' || lastCommand === 'stepInto' || lastCommand === 'stepOut') return true;
  return (event.reason === 'exception' || event.reason === 'promiseRejection') && pauseOnExceptions === 'uncaught';
}

/** The Debugger's commands. */
export const DEBUGGER_COMMANDS = ['continue', 'stepOver', 'stepInto', 'stepOut', 'pause', 'pauseOnExceptions', 'frame', 'remove'] as const;
export type DebuggerCommand = (typeof DEBUGGER_COMMANDS)[number];

/** Is `value` one of the Debugger's commands? */
export const isCommand = (value: unknown): value is DebuggerCommand => (DEBUGGER_COMMANDS as readonly unknown[]).includes(value);

/** Where a project's breakpoints are kept: read once by the session, written whole. */
export interface BreakpointStore {
  read(): Breakpoint[];
  write(list: readonly Breakpoint[]): void;
}

export interface SessionOptions {
  /** The project's folder, as named (made real for the scripts' `/@fs/` urls). */
  dir: string;
  /** Its name, the view's. */
  name: string;
  store: BreakpointStore;
  /** The packages under `node_modules/` linked from outside the project: asked once (`linkedPackages` by default). */
  links?(): LinkedPackage[];
  /** A project file's text, for the source pane (`sourceFromServer`: the dev server's `GET /__studio/file`). */
  source(path: string, origin: string): Promise<string>;
  /** The view, to the Debugger (its window, its tab). */
  tellView(view: DebugView): void;
  /** The breakpoints, each set or not, to the game's page (the Code card's dots). */
  tellBreakpoints(list: ShownBreakpoint[]): void;
  /** Where the game last stopped, to its page, once it runs on. */
  tellHit(at: Breakpoint): void;
  /** A pause read and told: the Debugger opened, or brought forward. Ours only (`shared`). */
  paused(): void;
  /**
   * Other clients share the tab's debugger (the dev server's: VS Code's js-debug): only our own pauses are ours
   * (`isOurPause`). Not shared (the app's window, its one client): every pause is ours, a `debugger;` too.
   */
  shared?: boolean;
  log?(line: string): void;
}

export interface DebugSession {
  /** Is the protocol attached? */
  readonly attached: boolean;
  /**
   * Attached over `cdp` to the page whose origin `origin` answers (`http://localhost:5196`; asked at each script, as
   * an app's window may load its project again on a new port): enabled, its breakpoints set as its scripts parse.
   */
  attach(cdp: Cdp, origin: () => string | null): void;
  /** An attach that did not take: `words` on the state line. */
  failed(words: string): void;
  /** The transport gone: none set, nothing paused, `words` (null: none) on the state line. `quiet`: nothing told. */
  letGo(words: string | null, quiet?: boolean): void;
  /** The view now. */
  view(): DebugView;
  /** The breakpoints as shown: each with whether the game has it set. */
  shown(): ShownBreakpoint[];
  /** A breakpoint added, or taken away when it is there; the list after, once set (or found unplaceable). */
  toggle(at: Breakpoint): Promise<ShownBreakpoint[]>;
  /** A Debugger's command; rejects for one that is none, or while not attached (but `remove`). */
  command(name: unknown, arg?: unknown): Promise<void>;
  /** The Debugger closed: a game stopped at a breakpoint resumed, nothing else could. */
  resumeIfPaused(): void;
}

interface Applied {
  id: string;
  regex: string;
  lineNumber: number;
  columnNumber: number;
}

interface Paused {
  event: PausedEvent;
  /** Ours (`isOurPause`): one of our breakpoints, our pause or step, our pause on exceptions. Another client's is shown, read-only, and nothing more. */
  ours: boolean;
  reason: string;
  rows: FrameRow[];
  selected: number;
  locals: LocalRow[];
  more: number;
  source: DebugSource;
}

/** A project file's text from its dev server at `origin` (`GET /__studio/file`, on loopback). */
export async function sourceFromServer(path: string, origin: string): Promise<string> {
  const res = await fetch(`${origin}/__studio/file?path=${encodeURIComponent(path)}`);
  const body = (await res.json().catch(() => ({}))) as { text?: unknown; refused?: unknown };
  if (!res.ok || typeof body.text !== 'string') throw new Error(typeof body.refused === 'string' ? body.refused : `the dev server answered ${res.status}`);
  return body.text;
}

export function createSession(options: SessionOptions): DebugSession {
  const log = options.log ?? ((line: string) => console.log(line));
  let cdp: Cdp | null = null;
  let offs: (() => void)[] = [];
  let originOf: () => string | null = () => null;
  let attachError: string | null = null;
  let links: LinkedPackage[] | null = null;
  let list: Breakpoint[] | null = null;
  const scripts = new Map<string, ScriptInfo>();
  /** The latest script parsed for each file. */
  const latest = new Map<string, string>();
  /** The breakpoints set in the game, by `breakpointKey`: a listed one not here is not set. */
  const applied = new Map<string, Applied>();
  let paused: Paused | null = null;
  let lastCommand: string | null = null;
  let pauseOnExceptions: 'none' | 'uncaught' = 'none';
  let queue: Promise<void> = Promise.resolve();

  const listOf = (): Breakpoint[] => (list ??= normalBreakpoints(options.store.read()));
  const writeList = (next: readonly Breakpoint[]): void => {
    options.store.write(next);
    list = normalBreakpoints(next);
  };
  const shown = (): ShownBreakpoint[] => shownBreakpoints(listOf(), applied);

  const send = <T = unknown>(method: string, params: Record<string, unknown> = {}): Promise<T> => {
    if (!cdp) return Promise.reject(new Error('the debugger is not attached'));
    return cdp.send<T>(method, params);
  };
  /** `work` queued; the queue's promise, which settles once it has run (never rejecting). */
  const later = (work: () => Promise<void>): Promise<void> => {
    queue = queue.then(work).catch((err: unknown) => log(`[debugger] debugger (${options.dir}): ${err instanceof Error ? err.message : String(err)}`));
    return queue;
  };

  const placeOf = (): ProjectPlace | null => {
    const origin = originOf();
    if (origin === null) return null;
    let dir = options.dir;
    try {
      dir = realpathSync(options.dir);
    } catch {
      // Gone: the folder as named.
    }
    links ??= options.links ? options.links() : linkedPackages(options.dir);
    return { origin, dir, links };
  };

  /**
   * The breakpoints of `path` set where its latest script puts them, and the ones no longer listed removed; one the
   * map cannot place is left unset (not in `applied`), and shown so.
   */
  async function applyFile(path: string): Promise<void> {
    if (!cdp) return;
    const mine = listOf().filter((b) => b.file === path);
    const wanted = new Set(mine.map(breakpointKey));
    for (const [key, had] of applied) {
      if (key.startsWith(`${path}\n`) && !wanted.has(key)) {
        applied.delete(key);
        await send('Debugger.removeBreakpoint', { breakpointId: had.id }).catch(() => undefined);
      }
    }
    const scriptId = latest.get(path);
    const script = scriptId === undefined ? undefined : scripts.get(scriptId);
    if (!script) return;
    const regex = urlRegexFor(script.url);
    for (const b of mine) {
      const placed = generatedFor(script.map, b.line);
      const had = applied.get(breakpointKey(b));
      if (had && placed && had.regex === regex && had.lineNumber === placed.lineNumber && had.columnNumber === placed.columnNumber) continue;
      if (had) {
        applied.delete(breakpointKey(b));
        await send('Debugger.removeBreakpoint', { breakpointId: had.id }).catch(() => undefined);
      }
      if (!placed) continue;
      try {
        const { breakpointId } = await send<{ breakpointId: string }>('Debugger.setBreakpointByUrl', { urlRegex: regex, lineNumber: placed.lineNumber, columnNumber: placed.columnNumber });
        applied.set(breakpointKey(b), { id: breakpointId, regex, lineNumber: placed.lineNumber, columnNumber: placed.columnNumber });
      } catch (err) {
        log(`[debugger] breakpoint ${b.file}:${b.line} not set: ${err instanceof Error ? err.message : String(err)}`);
      }
    }
  }

  /** The chosen frame's locals and source read into the pause. */
  async function readFrame(): Promise<void> {
    const p = paused;
    if (!p) return;
    const frame = p.event.callFrames[p.selected];
    const row = p.rows[p.selected];
    if (!frame || !row) return;
    // The block scopes (a loop's `n`, its body's `e`) and the function's own, innermost first.
    const ids = localScopes(frame.scopeChain).flatMap((scope) => (scope.objectId ? [scope.objectId] : []));
    try {
      const lists = await Promise.all(ids.map((objectId) => send<{ result: PropertyDescriptor[] }>('Runtime.getProperties', { objectId, ownProperties: true, generatePreview: true }).then((answer) => answer.result)));
      const locals = localRows(mergeScopes(lists));
      p.locals = locals.rows;
      p.more = locals.more;
    } catch {
      p.locals = [];
      p.more = 0;
    }
    const origin = originOf();
    if (!row.ours) p.source = { file: row.file, line: row.line, none: 'not a file of the project' };
    else if (origin === null) p.source = { file: row.file, line: row.line, none: 'the project is not loaded' };
    else {
      try {
        p.source = { file: row.file, line: row.line, ...sourceAround(await options.source(row.file, origin), row.line) };
      } catch (err) {
        p.source = { file: row.file, line: row.line, none: err instanceof Error ? err.message : String(err) };
      }
    }
  }

  function view(): DebugView {
    const p = paused;
    return {
      project: options.name,
      attachError,
      breakpoints: shown(),
      pauseOnExceptions,
      // Where it stopped: the top frame's place, whichever frame is chosen.
      words: attachError ?? (p && !p.ours ? OTHER_PAUSE : pausedWords(p?.rows[0], p?.reason ?? null)),
      paused: p ? { reason: p.reason, other: !p.ours, frames: p.rows, selected: p.selected, locals: p.locals, more: p.more, source: p.source } : null,
    };
  }

  const tell = (): void => options.tellView(view());
  /** The breakpoints, each set or not, told to the game's page and the Debugger. */
  const publish = (): void => {
    options.tellBreakpoints(shown());
    tell();
  };

  function onEvent(method: string, params: Record<string, unknown>): void {
    switch (method) {
      case 'Debugger.scriptParsed': {
        const url = String(params.url ?? '');
        const scriptId = String(params.scriptId);
        const place = url === '' ? null : placeOf();
        const path = place ? fileOfScript(url, place) : null;
        const map = path === null ? null : parseMap(inlineMap(typeof params.sourceMapURL === 'string' ? params.sourceMapURL : undefined));
        scripts.set(scriptId, { url, file: path, map });
        if (path !== null) {
          latest.set(path, scriptId);
          if (listOf().some((b) => b.file === path)) {
            void later(async () => {
              await applyFile(path);
              publish();
            });
          }
        }
        return;
      }
      case 'Runtime.executionContextsCleared':
        // A reload: the scripts are gone; the breakpoints set by url stay, and find the new ones.
        scripts.clear();
        latest.clear();
        if (paused) {
          paused = null;
          tell();
        }
        return;
      case 'Debugger.paused': {
        const event = params as unknown as PausedEvent;
        const rows = frameRows(event.callFrames, (id) => scripts.get(id));
        const reason = pauseReason(event, lastCommand);
        // Chrome tells every client with the debugger on of every pause: VS Code's breakpoints and steps, a `debugger;`.
        const ours = !options.shared || isOurPause(event, lastCommand, new Set([...applied.values()].map((a) => a.id)), pauseOnExceptions);
        lastCommand = null;
        const p: Paused = (paused = { event, ours, reason, rows, selected: 0, locals: [], more: 0, source: { file: rows[0]?.file ?? '', line: rows[0]?.line ?? 0, none: 'reading…' } });
        void later(async () => {
          await readFrame();
          // Over before it was read (a step's pause, resumed at once): nothing to open or bring forward.
          if (paused !== p) return;
          tell();
          // Another client's: shown in a Debugger already open, read-only; nothing opened.
          if (p.ours) options.paused();
        });
        return;
      }
      case 'Debugger.resumed': {
        const was = paused;
        const top = was?.rows[0];
        paused = null;
        tell();
        // A step resumes for a moment only: the page hears where it stopped once it runs on; never of another's pause.
        const stepping = lastCommand === 'stepOver' || lastCommand === 'stepInto' || lastCommand === 'stepOut';
        if (was?.ours && top?.ours && !stepping) options.tellHit({ file: top.file, line: top.line });
        return;
      }
    }
  }

  /** The breakpoints of `files` changed: set or removed in the game, then told. Settles once they are. */
  async function changed(files: readonly string[]): Promise<void> {
    for (const path of new Set(files)) void later(() => applyFile(path));
    await later(async () => publish());
  }

  function letGo(words: string | null, quiet = false): void {
    for (const off of offs) off();
    offs = [];
    cdp = null;
    applied.clear();
    paused = null;
    if (quiet) return;
    attachError = words;
    // None is set while it is let go.
    publish();
  }

  return {
    get attached() {
      return cdp !== null;
    },
    attach(next, at) {
      if (cdp) letGo(null, true);
      cdp = next;
      originOf = at;
      attachError = null;
      applied.clear();
      scripts.clear();
      latest.clear();
      paused = null;
      offs = [next.on('event', onEvent)];
      void later(async () => {
        await send('Runtime.enable');
        // Enabling replays every script already parsed (`scriptParsed`): their breakpoints are set as each comes.
        await send('Debugger.enable');
        await send('Debugger.setPauseOnExceptions', { state: pauseOnExceptions });
      });
      tell();
    },
    failed(words) {
      attachError = words;
      tell();
    },
    letGo,
    view,
    shown,
    async toggle(at) {
      if (!isBreakpoint(at)) throw new Error(`toggle: ${String((at as Partial<Breakpoint>).file)}:${String((at as Partial<Breakpoint>).line)} is no place for a breakpoint`);
      writeList(toggleBreakpoint(listOf(), at));
      // Answered once it is set (or found unplaceable), so the dot drawn from the answer is the true one.
      await changed([at.file]);
      return shown();
    },
    async command(name, arg) {
      if (!isCommand(name)) throw new Error(`no such command: ${String(name)}`);
      if (!cdp && name !== 'remove') throw new Error(attachError ?? 'the debugger is not attached');
      switch (name) {
        case 'continue':
          // Another debugger's pause is its own to resume.
          if (paused?.ours) await send('Debugger.resume');
          return;
        case 'stepOver':
        case 'stepInto':
        case 'stepOut':
          if (!paused?.ours) return;
          lastCommand = name;
          await send(`Debugger.${name}`);
          return;
        case 'pause':
          if (paused) return;
          lastCommand = 'pause';
          await send('Debugger.pause');
          return;
        case 'pauseOnExceptions':
          pauseOnExceptions = arg === 'uncaught' ? 'uncaught' : 'none';
          await send('Debugger.setPauseOnExceptions', { state: pauseOnExceptions });
          tell();
          return;
        case 'frame': {
          const p = paused;
          if (!p || typeof arg !== 'number' || !Number.isInteger(arg) || arg < 0 || arg >= p.rows.length) return;
          p.selected = arg;
          await readFrame();
          tell();
          return;
        }
        case 'remove': {
          if (!isBreakpoint(arg)) return;
          writeList(removeBreakpoint(listOf(), arg));
          await changed([arg.file]);
          return;
        }
      }
    },
    resumeIfPaused() {
      // Only our own pause: another debugger's (VS Code's) stays its to resume.
      if (paused?.ours && cdp) void send('Debugger.resume').catch(() => undefined);
    },
  };
}

/** The packages under `<dir>/node_modules/@vibe/` that are links out of the project (source mode, the workspace). */
export function linkedPackages(dir: string): LinkedPackage[] {
  const scope = join(dir, 'node_modules', '@vibe');
  if (!existsSync(scope)) return [];
  const out: LinkedPackage[] = [];
  for (const name of readdirSync(scope)) {
    try {
      if (!lstatSync(join(scope, name)).isSymbolicLink()) continue;
      out.push({ real: realpathSync(join(scope, name)), as: `node_modules/@vibe/${name}` });
    } catch {
      // A link to nothing: no files of it are served.
    }
  }
  return out;
}
