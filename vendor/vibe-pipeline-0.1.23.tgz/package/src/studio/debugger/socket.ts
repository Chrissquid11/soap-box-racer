/**
 * The dev server's transport for the debugger's core (`session.ts`): Chrome's debugging protocol over a WebSocket to
 * a Chrome started with `--remote-debugging-port` -- the one VS Code's js-debug starts for "Studio (dev)" (its
 * launch configuration's `"port"`). Node 24's global `WebSocket`; nothing to install.
 *
 * - **The targets** (`listTargets`): `GET http://127.0.0.1:<port>/json/list`, each tab's id, type, url and
 *   `webSocketDebuggerUrl`; the browser's own socket (`browserSocket`, `/json/version`) for the `Target` domain --
 *   a tab made, brought forward, or heard closing. No Chrome there is no error: an empty list, `null`.
 * - **A studio tab of this server** (`studioTarget`): a page on loopback (`localhost`, `127.0.0.1`, `[::1]`) at this
 *   server's port with `?studio` -- never a LAN page; the first such Chrome lists (its newest).
 * - **The socket's address checked** (`isLocalSocket`): the `webSocketDebuggerUrl` the lists give is used only when it
 *   is `ws://` on loopback at the debugging port with a `/devtools/` path -- anything else refused, as a LAN tab is.
 * - **The socket** (`connectCdp`): a command is `{ id, method, params }`, answered by the message with its `id`
 *   (`result`, or `error.message` as the rejection); any message with a `method` is an event. Closed -- by Chrome,
 *   the tab gone, or `close()` -- every waiting command is rejected and `close` heard once.
 */
import type { Cdp } from './session.ts';

/** A target of `/json/list`, what of it is read here. */
export interface CdpTarget {
  id: string;
  type: string;
  url: string;
  webSocketDebuggerUrl?: string;
}

/** How long Chrome's HTTP endpoint has to answer: none there is found quickly. */
const ASK_MS = 1500;

async function askJson(port: number, path: string, fetcher: typeof fetch): Promise<unknown> {
  const res = await fetcher(`http://127.0.0.1:${port}${path}`, { signal: AbortSignal.timeout(ASK_MS) });
  if (!res.ok) throw new Error(`${path} answered ${res.status}`);
  return (await res.json()) as unknown;
}

/** The targets of the Chrome on `port`; none when there is no Chrome there. */
export async function listTargets(port: number, fetcher: typeof fetch = fetch): Promise<CdpTarget[]> {
  try {
    const list = await askJson(port, '/json/list', fetcher);
    if (!Array.isArray(list)) return [];
    return list.filter((t): t is CdpTarget => typeof t === 'object' && t !== null && typeof t.id === 'string' && typeof t.type === 'string' && typeof t.url === 'string');
  } catch {
    return [];
  }
}

/** The browser's own socket url (`/json/version`), or null with no Chrome there. */
export async function browserSocket(port: number, fetcher: typeof fetch = fetch): Promise<string | null> {
  try {
    const version = (await askJson(port, '/json/version', fetcher)) as { webSocketDebuggerUrl?: unknown };
    return typeof version.webSocketDebuggerUrl === 'string' && isLocalSocket(version.webSocketDebuggerUrl, port) ? version.webSocketDebuggerUrl : null;
  } catch {
    return null;
  }
}

const LOOPBACK = new Set(['localhost', '127.0.0.1', '[::1]']);

/** Is `url` a studio page of the dev server on `port` (loopback, `?studio`)? */
export function isStudioPage(url: string, port: number): boolean {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }
  return parsed.protocol === 'http:' && LOOPBACK.has(parsed.hostname) && parsed.port === String(port) && parsed.searchParams.has('studio');
}

/** Is `url` a debugging socket of the Chrome on `debugPort` (`ws://`, loopback, that port, a `/devtools/` path)? */
export function isLocalSocket(url: string, debugPort: number): boolean {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }
  return parsed.protocol === 'ws:' && LOOPBACK.has(parsed.hostname) && parsed.port === String(debugPort) && parsed.pathname.startsWith('/devtools/');
}

/**
 * The studio tab of the dev server on `port` among `targets` -- the first Chrome lists, its newest -- whose socket
 * is the Chrome's own on `debugPort` (`isLocalSocket`), or null.
 */
export function studioTarget(targets: readonly CdpTarget[], port: number, debugPort: number): CdpTarget | null {
  return targets.find((t) => t.type === 'page' && t.webSocketDebuggerUrl !== undefined && isLocalSocket(t.webSocketDebuggerUrl, debugPort) && isStudioPage(t.url, port)) ?? null;
}

/** What `connectCdp` needs of a WebSocket: the standard one's. */
export type SocketMaker = (url: string) => WebSocket;

/** Chrome's debugging protocol over a WebSocket at `url`: resolved once it is open, rejected if it never opens. */
export function connectCdp(url: string, make: SocketMaker = (at) => new WebSocket(at)): Promise<Cdp> {
  return new Promise((resolve, reject) => {
    const socket = make(url);
    const waiting = new Map<number, { resolve(value: unknown): void; reject(err: Error): void }>();
    const events = new Set<(method: string, params: Record<string, unknown>) => void>();
    const closes = new Set<(reason: string) => void>();
    let next = 0;
    let open = false;
    let closed = false;

    const ended = (reason: string): void => {
      if (closed) return;
      closed = true;
      for (const w of waiting.values()) w.reject(new Error(`the debugger's socket closed (${reason})`));
      waiting.clear();
      if (!open) reject(new Error(`no debugger at ${url}: ${reason}`));
      for (const fn of closes) fn(reason);
    };

    socket.addEventListener('open', () => {
      open = true;
      resolve(cdp);
    });
    socket.addEventListener('message', (event: MessageEvent) => {
      let message: { id?: unknown; result?: unknown; error?: { message?: unknown }; method?: unknown; params?: unknown };
      try {
        message = JSON.parse(String(event.data)) as typeof message;
      } catch {
        return;
      }
      if (typeof message.id === 'number') {
        const w = waiting.get(message.id);
        if (!w) return;
        waiting.delete(message.id);
        if (message.error) w.reject(new Error(typeof message.error.message === 'string' ? message.error.message : 'the protocol refused it'));
        else w.resolve(message.result ?? {});
        return;
      }
      if (typeof message.method === 'string') {
        const params = (typeof message.params === 'object' && message.params !== null ? message.params : {}) as Record<string, unknown>;
        for (const fn of events) fn(message.method, params);
      }
    });
    socket.addEventListener('close', (event: CloseEvent) => ended(event.reason || `code ${event.code}`));
    socket.addEventListener('error', () => ended('a socket error'));

    const cdp: Cdp = {
      send<T = unknown>(method: string, params: Record<string, unknown> = {}): Promise<T> {
        if (closed) return Promise.reject(new Error("the debugger's socket is closed"));
        const id = ++next;
        return new Promise<T>((done, fail) => {
          waiting.set(id, { resolve: done as (value: unknown) => void, reject: fail });
          socket.send(JSON.stringify({ id, method, params }));
        });
      },
      on: ((event: 'event' | 'close', fn: never) => {
        const set = (event === 'event' ? events : closes) as Set<unknown>;
        set.add(fn);
        return () => void set.delete(fn);
      }) as Cdp['on'],
      close() {
        if (closed) return;
        socket.close();
        ended('let go');
      },
    };
  });
}
