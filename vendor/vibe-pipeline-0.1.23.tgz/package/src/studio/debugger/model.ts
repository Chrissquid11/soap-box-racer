/**
 * The debugger's pure parts (`session.ts` acts on them, over either transport: the app's `webContents.debugger`,
 * the dev server's WebSocket to Chrome's debugging port): importing nothing of Electron or of a socket, for
 * `model.test.ts`.
 *
 * - **The breakpoint list** (`toggleBreakpoint`, `normalBreakpoints`, `breakpointsOf`, `withBreakpoints`):
 *   `{ file, line }`, the file the project's path (relative, `/`), the line 1-based in the TypeScript; sorted by
 *   file then line, one of each; the app's `breakpoints.json` in its app-data folder holds every project's, keyed
 *   by its folder (`breakpointsOf`, `withBreakpoints`), the dev server's `.cache/studio/breakpoints.json` the
 *   project's own list. As shown (`shownBreakpoints`), each says whether it is `set` in the game: one the map cannot place (a
 *   line past the end, a comment run longer than `LINE_REACH`, a module not parsed yet) is listed and not set.
 * - **Which file a served script is** (`fileOfScript`): the dev server serves a project's file at its own path
 *   (`/src/game/systems/spin.ts`); the engine's shipped source, in a published-mode project, at
 *   `/node_modules/@vibe/engine/dist/x.js` -- its type-stripped twin of `src/x.ts`, line for line, which is the
 *   file the Code card opens (a definition lands there); a package linked from outside the project (source mode,
 *   the workspace) at `/@fs/<its real path>/...`, named back through the link (`node_modules/@vibe/engine/...`).
 * - **The url a breakpoint is set on** (`urlRegexFor`): the script's own url, escaped, any query after it -- an
 *   HMR swap serves the module again as `?t=<time>`, a dependency as `?v=<hash>`.
 * - **The line, both ways** (`generatedFor`, `originalFor`): through the script's inline source map (`inlineMap`
 *   reads the `data:` url `Debugger.scriptParsed` gives as `sourceMapURL`), `@jridgewell/trace-mapping`; a line
 *   with no code (a comment, a blank) moves down to the next that has some, as every debugger does.
 * - **A pause, as the Debugger window shows it** (`frameRows`, `valueWords`, `localRows`, `pausedWords`,
 *   `sourceAround`): a row per frame with its function and its TypeScript file:line; a local's value in words --
 *   primitives as their JSON, an object as its class and its first properties one level deep (`Vec3 {x: 1, y:
 *   0, …}`), a nested one as `Object {…}`, an array's first `PREVIEW_CAP` elements then `…` -- at most
 *   `LOCALS_CAP` rows.
 */
import { generatedPositionFor, LEAST_UPPER_BOUND, originalPositionFor, TraceMap } from '@jridgewell/trace-mapping';

/** A breakpoint: the project's path of a file and a 1-based line in it. */
export interface Breakpoint {
  file: string;
  line: number;
}

/** Is `value` a breakpoint a list may hold: a relative `/` path with no `..` and a line from 1? */
export function isBreakpoint(value: unknown): value is Breakpoint {
  if (typeof value !== 'object' || value === null) return false;
  const { file, line } = value as Record<string, unknown>;
  if (typeof file !== 'string' || file === '' || file.startsWith('/') || file.includes('\\') || file.includes('\0')) return false;
  if (file.split('/').some((part) => part === '' || part === '.' || part === '..')) return false;
  return typeof line === 'number' && Number.isInteger(line) && line >= 1;
}

/** A list as kept: the breakpoints of `list` that are ones, sorted by file then line, each once. */
export function normalBreakpoints(list: readonly unknown[]): Breakpoint[] {
  const seen = new Set<string>();
  const out: Breakpoint[] = [];
  for (const item of list) {
    if (!isBreakpoint(item)) continue;
    const key = `${item.file}\n${item.line}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ file: item.file, line: item.line });
  }
  return out.sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : a.line - b.line));
}

/** `list` with `at` added, or without it when it is there. */
export function toggleBreakpoint(list: readonly Breakpoint[], at: Breakpoint): Breakpoint[] {
  const there = list.some((b) => b.file === at.file && b.line === at.line);
  return normalBreakpoints(there ? list.filter((b) => b.file !== at.file || b.line !== at.line) : [...list, at]);
}

/** `list` without `at`. */
export function removeBreakpoint(list: readonly Breakpoint[], at: Breakpoint): Breakpoint[] {
  return list.filter((b) => b.file !== at.file || b.line !== at.line);
}

/** A breakpoint's key in a set or map: `file\nline`. */
export const breakpointKey = (b: Breakpoint): string => `${b.file}\n${b.line}`;

/** A breakpoint as the Code card and the Debugger window are told it: whether it is set in the game now. */
export interface ShownBreakpoint extends Breakpoint {
  set: boolean;
}

/** `list` as shown: each `set` when its key is in `setKeys` (the breakpoints the game has, by `breakpointKey`). */
export function shownBreakpoints(list: readonly Breakpoint[], setKeys: { has(key: string): boolean }): ShownBreakpoint[] {
  return list.map((b) => ({ file: b.file, line: b.line, set: setKeys.has(breakpointKey(b)) }));
}

/** `breakpoints.json`'s content: every project's list, by its folder. */
export type BreakpointsFile = Record<string, Breakpoint[]>;

/** A project's list out of `breakpoints.json`'s parsed content (anything else: none). */
export function breakpointsOf(content: unknown, dir: string): Breakpoint[] {
  if (typeof content !== 'object' || content === null || Array.isArray(content)) return [];
  const list = (content as Record<string, unknown>)[dir];
  return Array.isArray(list) ? normalBreakpoints(list) : [];
}

/** `breakpoints.json`'s content with a project's list replaced (an empty one dropped). */
export function withBreakpoints(content: unknown, dir: string, list: readonly Breakpoint[]): BreakpointsFile {
  const out: BreakpointsFile = {};
  if (typeof content === 'object' && content !== null && !Array.isArray(content)) {
    for (const [key, value] of Object.entries(content)) if (key !== dir && Array.isArray(value)) out[key] = normalBreakpoints(value);
  }
  const kept = normalBreakpoints(list);
  if (kept.length > 0) out[dir] = kept;
  return out;
}

// ---------------------------------------------------------------- scripts and urls

/** A package linked from outside the project: its real folder and the project's path to it (`node_modules/@vibe/engine`). */
export interface LinkedPackage {
  real: string;
  as: string;
}

/** What `fileOfScript` knows of the project. */
export interface ProjectPlace {
  /** The dev server's origin, `http://localhost:5196`. */
  origin: string;
  /** The project's folder, real, no trailing `/`. */
  dir: string;
  /** The packages under `node_modules/` that are links elsewhere. */
  links: readonly LinkedPackage[];
}

/**
 * A path as Vite's `/@fs/` and a folder of node's compare: `/` between the names, a Windows drive (`/D:/…` in a URL,
 * `D:\…` from node) as one lowercase `d:/…`. A POSIX path is as it was.
 */
export const fsPath = (path: string): string => path.replace(/\\/g, '/').replace(/^\/?([A-Za-z]):\//, (_, drive: string) => `${drive.toLowerCase()}:/`);

const inside = (path: string, folder: string): string | null => {
  const at = fsPath(path);
  const base = fsPath(folder).replace(/\/$/, '');
  return at.startsWith(`${base}/`) ? at.slice(base.length + 1) : null;
};

/** The project's path of the file a script served at `url` is, or null for one of no file of it (Vite's client, a dependency bundle). */
export function fileOfScript(url: string, place: ProjectPlace): string | null {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (parsed.origin !== place.origin) return null;
  const path = decodeURIComponent(parsed.pathname);
  if (path.startsWith('/@fs/')) {
    const real = path.slice('/@fs'.length);
    const own = inside(real, place.dir);
    if (own !== null) return own;
    for (const link of place.links) {
      const rest = inside(real, link.real);
      if (rest !== null) return `${link.as}/${rest}`;
    }
    return null;
  }
  if (path.startsWith('/@') || path.startsWith('/node_modules/.vite/') || !/\.[cm]?[jt]sx?$/.test(path)) return null;
  // A package's shipped JS twin of its source (published mode): `dist/x.js` is `src/x.ts` with the types blanked.
  const shipped = /^\/(node_modules\/(?:@[^/]+\/)?[^/]+)\/dist\/(.+)\.js$/.exec(path);
  if (shipped) return `${shipped[1]}/src/${shipped[2]}.ts`;
  return path.slice(1);
}

/** `url` without its query or hash. */
export const bareUrl = (url: string): string => url.replace(/[?#].*$/, '');

/** The `urlRegex` a breakpoint in the script at `url` is set with: the url itself, any query after it. */
export function urlRegexFor(url: string): string {
  return `^${bareUrl(url).replace(/[.*+?^${}()|[\]\\/]/g, '\\$&')}(?:[?#].*)?$`;
}

/** The JSON of an inline source map (`data:application/json;base64,...` or not base64), else null. */
export function inlineMap(sourceMapURL: string | undefined): string | null {
  if (!sourceMapURL?.startsWith('data:')) return null;
  const comma = sourceMapURL.indexOf(',');
  if (comma < 0) return null;
  const head = sourceMapURL.slice(5, comma);
  const body = sourceMapURL.slice(comma + 1);
  try {
    return head.endsWith(';base64') ? Buffer.from(body, 'base64').toString('utf8') : decodeURIComponent(body);
  } catch {
    return null;
  }
}

/** A script's source map, parsed; null when there is none or it is not one. */
export function parseMap(json: string | null): TraceMap | null {
  if (json === null) return null;
  try {
    const map = new TraceMap(json);
    return map.sources.length > 0 ? map : null;
  } catch {
    return null;
  }
}

/** How far down a breakpoint on a line of no code moves to find one. */
export const LINE_REACH = 20;

/** Where a breakpoint lands in the served script: 0-based line and column for CDP, and the 1-based line of the source it is on. */
export interface Placed {
  lineNumber: number;
  columnNumber: number;
  line: number;
}

/**
 * The served script's place for the source's 1-based `line`: its first code on that line, else on the next line
 * that has code (`LINE_REACH`); with no map, the line itself (a script served as it is). Null when none is found.
 */
export function generatedFor(map: TraceMap | null, line: number): Placed | null {
  if (!map) return { lineNumber: line - 1, columnNumber: 0, line };
  const source = map.sources[0]!;
  for (let at = line; at < line + LINE_REACH; at++) {
    const found = generatedPositionFor(map, { source, line: at, column: 0, bias: LEAST_UPPER_BOUND });
    if (found.line !== null) return { lineNumber: found.line - 1, columnNumber: found.column, line: at };
  }
  return null;
}

/** The source's 1-based line and column of a served script's 0-based place; with no map (or none there), the place itself. */
export function originalFor(map: TraceMap | null, lineNumber: number, columnNumber: number): { line: number; col: number } {
  if (map) {
    const found = originalPositionFor(map, { line: lineNumber + 1, column: columnNumber });
    if (found.line !== null) return { line: found.line, col: found.column + 1 };
  }
  return { line: lineNumber + 1, col: columnNumber + 1 };
}

// ---------------------------------------------------------------- a pause

/** CDP's `Runtime.RemoteObject`, what of it is read here. */
export interface RemoteObject {
  type: string;
  subtype?: string;
  className?: string;
  value?: unknown;
  unserializableValue?: string;
  description?: string;
  objectId?: string;
  preview?: ObjectPreview;
}

export interface ObjectPreview {
  type: string;
  subtype?: string;
  description?: string;
  overflow: boolean;
  properties: { name: string; type: string; value?: string; subtype?: string }[];
}

/** CDP's `Runtime.PropertyDescriptor`, what of it is read here. */
export interface PropertyDescriptor {
  name: string;
  value?: RemoteObject;
  get?: RemoteObject;
}

/** CDP's `Debugger.CallFrame`, what of it is read here. */
export interface CallFrame {
  callFrameId: string;
  functionName: string;
  location: { scriptId: string; lineNumber: number; columnNumber?: number };
  url: string;
  scopeChain: { type: string; object: RemoteObject }[];
}

/** CDP's `Debugger.paused` parameters, what of them is read here. */
export interface PausedEvent {
  reason: string;
  hitBreakpoints?: string[];
  callFrames: CallFrame[];
}

/** A script `Debugger.scriptParsed` told of, as the debugger keeps it. */
export interface ScriptInfo {
  url: string;
  /** The project's path of its file (`fileOfScript`), or null. */
  file: string | null;
  map: TraceMap | null;
}

/** A row of the call stack. */
export interface FrameRow {
  function: string;
  /** The project's path, or the script's url for one of no file of the project's. */
  file: string;
  line: number;
  col: number;
  /** Is it a file of the project's (its source can be shown)? */
  ours: boolean;
}

/** The call stack's rows: each frame's function and its place mapped back to the source. */
export function frameRows(frames: readonly CallFrame[], scriptOf: (id: string) => ScriptInfo | undefined): FrameRow[] {
  return frames.map((frame) => {
    const script = scriptOf(frame.location.scriptId);
    const at = originalFor(script?.map ?? null, frame.location.lineNumber, frame.location.columnNumber ?? 0);
    const file = script?.file ?? null;
    return { function: frame.functionName || '(anonymous)', file: file ?? (bareUrl(script?.url || frame.url) || `script ${frame.location.scriptId}`), line: at.line, col: at.col, ours: file !== null };
  });
}

const quote = (text: string): string => JSON.stringify(text);

/** A function's words: `ƒ name()`. */
function functionWords(description: string | undefined): string {
  const name = /^(?:async\s+)?(?:function\s*\*?\s*|class\s+)?([\w$]*)/.exec(description ?? '')?.[1] ?? '';
  return `ƒ ${name}()`;
}

/** A property of a preview, one level in: primitives as their JSON, an object as its class and `{…}`. */
function previewValue(p: ObjectPreview['properties'][number]): string {
  switch (p.type) {
    case 'string':
      return quote(p.value ?? '');
    case 'function':
      return 'ƒ';
    case 'object':
      return p.subtype === 'null' ? 'null' : `${p.value ?? 'Object'} {…}`;
    default:
      return p.value ?? p.type;
  }
}

/** At most this many of an array's elements are shown in its preview, then `…`. */
export const PREVIEW_CAP = 8;

/** A value in words, as the locals show it. */
export function valueWords(o: RemoteObject | undefined): string {
  if (!o) return 'undefined';
  switch (o.type) {
    case 'undefined':
      return 'undefined';
    case 'string':
      return quote(String(o.value ?? ''));
    case 'number':
    case 'boolean':
    case 'bigint':
      return o.unserializableValue ?? String(o.value);
    case 'symbol':
      return o.description ?? 'Symbol()';
    case 'function':
      return functionWords(o.description);
    case 'object': {
      if (o.subtype === 'null') return 'null';
      const head = o.description ?? o.className ?? 'Object';
      const preview = o.preview;
      if (!preview) return `${head} {…}`;
      // An array's, a typed array's: its elements alone (not its buffer, its length, its tag).
      const isList = o.subtype === 'array' || o.subtype === 'typedarray';
      const listed = isList ? preview.properties.filter((p) => /^\d+$/.test(p.name)) : preview.properties;
      // Chrome previews up to 100 of an array's elements: the first few say enough.
      const shown = isList ? listed.slice(0, PREVIEW_CAP) : listed;
      const parts = shown.map((p) => `${p.name}: ${previewValue(p)}`);
      if (preview.overflow || shown.length < listed.length) parts.push('…');
      return `${head} {${parts.join(', ')}}`;
    }
    default:
      return o.description ?? o.type;
  }
}

/**
 * The scopes a frame's locals are read from, innermost first: its block scopes (a `for`'s `let`, a block's `const`)
 * down to its function's own (`local`); a frame with no function scope (a module's top level) takes the scopes before
 * the first closure, module or global one, else the first that is not the global.
 */
export function localScopes(chain: CallFrame['scopeChain']): RemoteObject[] {
  const out: RemoteObject[] = [];
  for (const scope of chain) {
    if (scope.type === 'closure' || scope.type === 'module' || scope.type === 'global' || scope.type === 'script') break;
    out.push(scope.object);
    if (scope.type === 'local') break;
  }
  if (out.length === 0) {
    const first = chain.find((scope) => scope.type !== 'global');
    if (first) out.push(first.object);
  }
  return out;
}

/** The properties of several scopes, innermost first, as one list: a name shadowed further out left out. */
export function mergeScopes(lists: readonly (readonly PropertyDescriptor[])[]): PropertyDescriptor[] {
  const seen = new Set<string>();
  const out: PropertyDescriptor[] = [];
  for (const list of lists) {
    for (const p of list) {
      if (seen.has(p.name)) continue;
      seen.add(p.name);
      out.push(p);
    }
  }
  return out;
}

/** At most this many locals are shown. */
export const LOCALS_CAP = 40;

/** A row of the locals. */
export interface LocalRow {
  name: string;
  value: string;
}

/** A scope's properties as the locals' rows: at most `LOCALS_CAP`, and how many more there were. */
export function localRows(props: readonly PropertyDescriptor[]): { rows: LocalRow[]; more: number } {
  const rows = props.slice(0, LOCALS_CAP).map((p) => ({ name: p.name, value: p.value ? valueWords(p.value) : p.get ? '(getter)' : 'undefined' }));
  return { rows, more: Math.max(0, props.length - LOCALS_CAP) };
}

/** Why the game stopped, in a word: a breakpoint, an exception, a step, or a pause asked for. */
export function pauseReason(event: Pick<PausedEvent, 'reason' | 'hitBreakpoints'>, lastCommand: string | null): string {
  if ((event.hitBreakpoints?.length ?? 0) > 0) return 'breakpoint';
  if (event.reason === 'exception' || event.reason === 'promiseRejection') return 'exception';
  if (event.reason === 'debugCommand') return 'debugger statement';
  if (lastCommand === 'stepOver' || lastCommand === 'stepInto' || lastCommand === 'stepOut') return 'step';
  return 'paused';
}

/** The Debugger window's state line. */
export function pausedWords(top: FrameRow | undefined, reason: string | null): string {
  if (reason === null) return 'Running';
  return top ? `Paused at ${top.file}:${top.line} · ${reason}` : `Paused · ${reason}`;
}

/** How many lines either side of the frame's the source pane shows. */
export const SOURCE_REACH = 12;

/** The lines of `text` around the 1-based `line`: the first one's number and the lines. */
export function sourceAround(text: string, line: number, reach = SOURCE_REACH): { first: number; lines: string[] } {
  const all = text.split(/\r?\n/);
  const first = Math.max(1, line - reach);
  const last = Math.min(all.length, line + reach);
  return { first, lines: all.slice(first - 1, last) };
}
