/**
 * The dev server's debugger (Docs/studio.md §11, "The dev server's debugger"): the Code card's breakpoints in a
 * browser tab, when that tab runs in a Chrome started with a debugging port -- VS Code's F5, "Studio (dev)", whose
 * launch configuration says `"port": <its dev port + 4032>`. The core is `session.ts`' (the app's too); its transport here is a
 * WebSocket to that Chrome (`socket.ts`), its Debugger a second tab of this server (`/__studio/debugger`).
 *
 * - **The port** (`debugPort`): `VIBE_DEBUG_PORT` when set (a test's own Chrome), else the `port` of the project's
 *   own `.vscode/launch.json`'s "Studio (dev)" (`launchPort`), else this server's port + 4032 (5190 -> 9222) -- what
 *   `vibe new` writes there, so two projects under F5 at once each have their own Chrome.
 *
 * - **Found quietly** (`poke`): each time a page of this machine connects its socket (the studio tab, and again on
 *   its reload), the debugging port is asked for its targets, and the newest studio tab of
 *   this server (`studioTarget`: loopback, this port, `?studio`) attached -- one at a time, a newer one taking it.
 *   No Chrome there is no error: not attached (`state()`), and the Code card says what would attach it. Never a LAN
 *   page: the targets are this machine's Chrome's, and only a loopback url is taken -- and only a socket on loopback
 *   at the debugging port (`isLocalSocket`), whatever the list names.
 * - **Two clients share the tab**: VS Code's js-debug has it too. A pause by one of ours pauses VS Code as well (it
 *   shows paused), a resume from either side resumes. Our breakpoints are this session's `setBreakpointByUrl`; VS
 *   Code's are its own. Only our pauses are ours (the session's `shared`): VS Code's breakpoint, a `debugger;` or its
 *   exception breakpoints open no Debugger tab, are not resumed at its close, and tell the Code card no hit.
 * - **The breakpoints**: the project's `.cache/studio/breakpoints.json` (`.cache/` is gitignored), `{ file, line }[]`.
 * - **The Debugger tab** (`open`): made through the browser's `Target.createTarget` -- the game's tab is frozen at a
 *   pause and could open nothing -- brought forward at each pause (`Target.activateTarget`), reused while it is
 *   open; heard closing (`Target.targetDestroyed`), and closed while the game is paused, the game resumed.
 * - **The pushes**: `studio:debug-view` (the Debugger tab's), `studio:debug-breakpoints` and `studio:debug-hit` (the
 *   Code card's), `studio:debug-state` (attached or not), through `send` -- the studio's, to this machine's tabs.
 *
 * Not debugged: worker threads (`?workers=`), Firefox and Safari, an everyday Chrome with no debugging port.
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { DEBUG_PORT_OFFSET, type DebugBreakpoint, type DebugState, type DebugView, type StudioMessage } from '../api-types.ts';
import { normalBreakpoints, type Breakpoint } from './model.ts';
import { createSession, type BreakpointStore, type Cdp, type DebugSession } from './session.ts';
import { browserSocket, connectCdp, listTargets, studioTarget, type SocketMaker } from './socket.ts';

/** The debugging port looked on with nothing else to go by (the dev server's port not known yet): the sandbox's, 5190's. */
export const DEBUG_PORT = 9222;

/** Where the dev server keeps a project's breakpoints, under its root. */
export const BREAKPOINTS_FILE = '.cache/studio/breakpoints.json';

/** The state line while nothing is attached. */
export const NOT_ATTACHED = "Not attached: breakpoints need the app, or VS Code's F5 (Studio (dev)) -- a Chrome with a debugging port";

const isPort = (n: unknown): n is number => typeof n === 'number' && Number.isInteger(n) && n > 0 && n < 65536;

/**
 * The debugging port: `VIBE_DEBUG_PORT` when it names one, else "Studio (dev)"'s `port` in `root`'s
 * `.vscode/launch.json` (`launchPort`), else the dev server's own port + `DEBUG_PORT_OFFSET`, else `DEBUG_PORT`.
 */
export function debugPort(env: NodeJS.ProcessEnv = process.env, root?: string, own?: number): number {
  const n = Number(env.VIBE_DEBUG_PORT);
  if (env.VIBE_DEBUG_PORT !== undefined && isPort(n)) return n;
  const launch = root === undefined ? null : launchPort(root);
  if (launch !== null) return launch;
  return own !== undefined && isPort(own + DEBUG_PORT_OFFSET) ? own + DEBUG_PORT_OFFSET : DEBUG_PORT;
}

/** JSON with comments made JSON: `//` and `/* *\/` comments outside strings, and trailing commas, taken out. */
export function stripJsonComments(text: string): string {
  let out = '';
  for (let i = 0; i < text.length; i++) {
    const c = text[i]!;
    if (c === '"') {
      // A string, escapes and all, as it is.
      let j = i + 1;
      while (j < text.length && text[j] !== '"') j += text[j] === '\\' ? 2 : 1;
      out += text.slice(i, j + 1);
      i = j;
    } else if (c === '/' && text[i + 1] === '/') {
      while (i < text.length && text[i] !== '\n') i++;
      out += '\n';
    } else if (c === '/' && text[i + 1] === '*') {
      const end = text.indexOf('*/', i + 2);
      i = end === -1 ? text.length : end + 1;
    } else out += c;
  }
  return out.replace(/,(\s*[}\]])/g, '$1');
}

/** The `port` of "Studio (dev)" in `root`'s `.vscode/launch.json`, or null: no file, no such configuration, no port, or a file that does not parse. */
export function launchPort(root: string): number | null {
  try {
    const launch = JSON.parse(stripJsonComments(readFileSync(join(root, '.vscode', 'launch.json'), 'utf8'))) as { configurations?: unknown };
    if (!Array.isArray(launch.configurations)) return null;
    const studio = launch.configurations.find((c: unknown): c is { name: string; port?: unknown } => typeof c === 'object' && c !== null && (c as { name?: unknown }).name === 'Studio (dev)');
    return studio && isPort(studio.port) ? studio.port : null;
  } catch {
    return null;
  }
}

/** A project's breakpoints in `.cache/studio/breakpoints.json`. */
export function fileStore(root: string): BreakpointStore {
  const file = join(root, BREAKPOINTS_FILE);
  return {
    read() {
      try {
        const list = JSON.parse(readFileSync(file, 'utf8')) as unknown;
        return Array.isArray(list) ? normalBreakpoints(list) : [];
      } catch {
        return [];
      }
    },
    write(list) {
      mkdirSync(dirname(file), { recursive: true });
      writeFileSync(file, `${JSON.stringify(normalBreakpoints(list), null, 2)}\n`);
    },
  };
}

export interface ServerDebuggerOptions {
  root: string;
  /** The project's name, the view's. */
  name: string;
  /** This dev server's port: a studio tab of it is one at this port. */
  port(): number | undefined;
  /** The Chrome's debugging port (`debugPort` of the project and this server's port by default, asked each time). */
  debugPort?: number;
  /** The studio's pushes, to this machine's tabs. */
  send(message: StudioMessage): void;
  /** A project file's text (the source pane). */
  source(path: string): Promise<string>;
  /** Test stand-ins: Chrome's HTTP endpoint and its sockets. */
  fetch?: typeof fetch;
  socket?: SocketMaker;
  store?: BreakpointStore;
  log?(line: string): void;
}

/** What the routes ask of the dev server's debugger. */
export interface ServerDebugger {
  state(): DebugState;
  /** A page of this machine connected its socket: look for a studio tab to attach to, quietly. Settles once looked. */
  poke(): Promise<void>;
  breakpoints(): DebugBreakpoint[];
  toggle(at: Breakpoint): Promise<DebugBreakpoint[]>;
  view(): DebugView;
  command(name: unknown, arg?: unknown): Promise<void>;
  /** The Debugger tab, made or brought forward; rejects while not attached. */
  open(): Promise<void>;
  /** Everything let go: the server closing. */
  close(): void;
}

export function createServerDebugger(options: ServerDebuggerOptions): ServerDebugger {
  const log = options.log ?? ((line: string) => console.log(line));
  /** The debugging port now: the dev server's port is known once it listens, and launch.json may change. */
  const debugPortNow = (): number => options.debugPort ?? debugPort(process.env, options.root, options.port());
  const fetcher = options.fetch ?? fetch;
  const make = options.socket;
  /** The tab attached: its id and url, the transport. */
  let page: { id: string; url: string; cdp: Cdp } | null = null;
  /** The browser's own socket, for the Debugger tab (`Target.*`), made at the first open. */
  let browser: Cdp | null = null;
  let debuggerTab: string | null = null;
  let looking: Promise<void> = Promise.resolve();

  const pushState = (): void => options.send({ kind: 'studio:debug-state', state: state() });
  const state = (): DebugState => ({ attached: page !== null, port: debugPortNow(), page: page?.url ?? null });

  const session: DebugSession = createSession({
    dir: options.root,
    name: options.name,
    store: options.store ?? fileStore(options.root),
    source: (path) => options.source(path),
    tellView: (view) => options.send({ kind: 'studio:debug-view', view }),
    tellBreakpoints: (list) => options.send({ kind: 'studio:debug-breakpoints', list }),
    tellHit: (at) => options.send({ kind: 'studio:debug-hit', file: at.file, line: at.line }),
    // VS Code's js-debug has the tab too: its pauses are not ours to open, resume or tell.
    shared: true,
    paused: () => void open().catch((err: unknown) => log(`[studio] the Debugger tab did not open: ${err instanceof Error ? err.message : String(err)}`)),
    log,
  });
  session.failed(NOT_ATTACHED);

  async function look(): Promise<void> {
    const own = options.port();
    if (own === undefined) return;
    const port = debugPortNow();
    const found = studioTarget(await listTargets(port, fetcher), own, port);
    // None found: the one attached (if any) stays until its socket closes.
    if (!found || found.id === page?.id) return;
    let cdp: Cdp;
    try {
      cdp = await connectCdp(found.webSocketDebuggerUrl!, make);
    } catch (err) {
      log(`[studio] the debugger did not attach to ${found.url}: ${err instanceof Error ? err.message : String(err)}`);
      return;
    }
    const was = page;
    const mine = (page = { id: found.id, url: found.url, cdp });
    if (was) {
      session.letGo(null, true);
      was.cdp.close();
    }
    cdp.on('close', () => {
      if (page !== mine) return;
      page = null;
      session.letGo(NOT_ATTACHED);
      pushState();
    });
    const origin = new URL(found.url).origin;
    session.attach(cdp, () => origin);
    log(`[studio] the debugger attached to ${found.url} (port ${port})`);
    pushState();
  }

  /** The browser's socket, made once and kept: the `Target` domain, and the Debugger tab heard closing. */
  async function browserCdp(): Promise<Cdp> {
    if (browser) return browser;
    const port = debugPortNow();
    const url = await browserSocket(port, fetcher);
    if (url === null) throw new Error(`no Chrome on port ${port}`);
    const cdp = await connectCdp(url, make);
    browser = cdp;
    cdp.on('close', () => {
      if (browser === cdp) browser = null;
    });
    cdp.on('event', (method, params) => {
      if (method === 'Target.targetDestroyed' && params.targetId === debuggerTab) {
        debuggerTab = null;
        // Closed while the game is stopped: nothing else could resume it.
        session.resumeIfPaused();
      }
    });
    await cdp.send('Target.setDiscoverTargets', { discover: true });
    return cdp;
  }

  async function open(): Promise<void> {
    if (!page) throw new Error(NOT_ATTACHED);
    const cdp = await browserCdp();
    if (debuggerTab !== null) {
      try {
        await cdp.send('Target.activateTarget', { targetId: debuggerTab });
        return;
      } catch {
        debuggerTab = null;
      }
    }
    const { targetId } = await cdp.send<{ targetId: string }>('Target.createTarget', { url: `${new URL(page.url).origin}/__studio/debugger` });
    debuggerTab = targetId;
  }

  return {
    state,
    poke() {
      looking = looking.then(look).catch((err: unknown) => log(`[studio] debugger: ${err instanceof Error ? err.message : String(err)}`));
      return looking;
    },
    breakpoints: () => session.shown(),
    toggle: (at) => session.toggle(at),
    view: () => session.view(),
    command: (name, arg) => session.command(name, arg),
    open,
    close() {
      const was = page;
      page = null;
      if (was) {
        session.letGo(null, true);
        was.cdp.close();
      }
      browser?.close();
      browser = null;
    },
  };
}

/**
 * The Debugger tab's page (`GET /__studio/debugger`): the editor's Debugger page module (`@vibe/editor/debugger`,
 * served by the project's Vite at `moduleUrl`), mounted over this server's routes and pushes (`serverTransport`,
 * `event` the push channel's). Its keys -- F5, F6, F10, F11, Shift+F11 -- are this page's own `keydown`, as the app's
 * Debugger window's are: it is no game's page, and MrDebug is the game's.
 */
export function debuggerHtml(moduleUrl: string, event: string): string {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Debugger</title>
  </head>
  <body class="debugger">
    <script type="module">
      import { mountDebugger, serverTransport } from ${JSON.stringify(moduleUrl)};
      const page = mountDebugger(serverTransport(${JSON.stringify(event)}), '');
      window.addEventListener('keydown', (e) => page.key(e));
    </script>
  </body>
</html>
`;
}
