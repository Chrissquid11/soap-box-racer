/**
 * Studio mode mid-session (Docs/studio.md §1, "Mid-session"): **does a module evaluate?** -- asked before a page reload
 * goes out, so a module that transforms but throws as it runs (`throw` at the top of `src/main.ts`, of `src/ui/hud.ts`)
 * holds the reload as a syntax error does, instead of reloading studio mode into a page that cannot boot.
 *
 * - **Why a page, and why its own**: only a browser evaluates the project's code as the page does (three, Pixi, the
 *   DOM at import time); a node run (`ssrLoadModule`) would throw for want of `document` where the page is fine, and
 *   hold good reloads. Importing the module into the live page would evaluate it a second time there -- a debug action
 *   registered twice throws, `main.ts` boots a second game. So the editor (studio mode) makes a hidden iframe of the
 *   **probe page** (`GET probe?id=`): the project's `index.html` markup, its scripts out, and one module script that
 *   imports Vite's client (the config's defines, `DEBUG_BUILD`, as the page has them) and then each file fresh (`?t=`)
 *   in a realm of its own -- the whole graph under it evaluated as a first load would --
 *   then `POST probe` with what each threw. **An import that has not settled in `PROBE_IMPORT_MS`** (a top-level
 *   `await` that never ends: an entry awaiting `boot()`, which never settles there) counts as clean: still evaluating
 *   is no throw, and the reload goes at once instead of waiting out the server's patience (`EVALUATE_ONE`). The entry's `boot()` does nothing there: the page sets
 *   `globalThis[Symbol.for('vibebase.probe')]` first, which the engine's `boot` reads (`ENTRY_PROBE`).
 * - **Asked, then waited for** (`createProbes`): the studio tabs told `studio:probe { id, url }`; an editor acks at
 *   once (`POST probe { id, ack: true }`), else after `ackMs` nobody probes (the plain page alone, no tab): the answer
 *   is null and the reload goes as Vite sends it. Acked, the results are waited for until `doneMs`.
 * - **A throw is a `CodeError`** (`evaluatedError`): where its mapped stack's first project frame is, the words it
 *   threw, `evaluated: true`, the mapped stack -- kept and held like a syntax error until a later probe evaluates clean.
 *
 * No Vite, no `node:` import: `probe.test.ts` runs it.
 */
import { PROBE_DONE, type CodeError, type MappedStack, type ProbeResult } from './api-types.ts';

/** The global the probe page sets before it imports: the engine's `boot` (`ENTRY_PROBE`) does nothing when it is. */
export const PROBE_GLOBAL = 'vibebase.probe';

/** How long the probe page waits for one module's import to settle: past it, still evaluating, it counts as clean. */
export const PROBE_IMPORT_MS = 3000;

/**
 * The probe page's one evaluation, as source (the page's script holds it; `probe.test.ts` runs the same text): `load(url)`
 * raced against `ms` -- what it threw (`{ message, stack }`), else null, whether it evaluated or is still evaluating.
 */
export const EVALUATE_ONE = `async function evaluateOne(load, url, ms) {
  let timer;
  const slow = new Promise((resolve) => { timer = setTimeout(() => resolve(null), ms); });
  try {
    return await Promise.race([load(url).then(() => null), slow]);
  } catch (e) {
    return { message: String(e && e.message !== undefined ? e.message : e), stack: e && typeof e.stack === 'string' ? e.stack : '' };
  } finally {
    clearTimeout(timer);
  }
}`;

/** JSON safe inside a `<script>`: no `</script>` can end it. */
const scriptJson = (value: unknown): string => JSON.stringify(value).replace(/</g, '\\u003c');

/**
 * The probe page for `files` (relative, posix): `index.html`'s body with its scripts out (the ids the page's code
 * looks up are there), and the module script that imports each at `base` fresh and posts what each threw to
 * `STUDIO`'s `probe`, then tells the editor it is done (`PROBE_DONE`, `postMessage`).
 */
export function probePage(indexHtml: string, base: string, studio: string, id: string, files: readonly string[]): string {
  const body = /<body[^>]*>([\s\S]*?)<\/body>/i.exec(indexHtml)?.[1] ?? '';
  const markup = body.replace(/<script\b[\s\S]*?<\/script>/gi, '');
  const script = `globalThis[Symbol.for(${scriptJson(PROBE_GLOBAL)})] = true;
const id = ${scriptJson(id)};
const files = ${scriptJson(files)};
const results = [];
${EVALUATE_ONE}
// Vite's client first, as the page's own index.html has it: it brings the config's defines (DEBUG_BUILD ...).
await import(${scriptJson(`${base}@vite/client`)});
for (const file of files) {
  // Still evaluating after ${PROBE_IMPORT_MS} ms (a top-level await that never ends): no throw, counted clean.
  results.push({ file, threw: await evaluateOne((url) => import(url), ${scriptJson(base)} + file + '?t=' + Date.now(), ${PROBE_IMPORT_MS}) });
}
try {
  await fetch(${scriptJson(`${studio}probe`)}, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, results }) });
} finally {
  parent.postMessage({ type: ${scriptJson(PROBE_DONE)}, id }, location.origin);
}`;
  return `<!doctype html>\n<html><head><meta charset="utf-8"><title>probe</title></head><body>${markup}\n<script type="module">\n${script}\n</script></body></html>\n`;
}

/** A module that threw as the probe evaluated it, as the broken list keeps it: at its first project frame, else the file. */
export function evaluatedError(file: string, thrown: { message: string }, mapped: MappedStack): CodeError {
  const at = mapped.at;
  const message = (thrown.message.split('\n').find((l) => l.trim() !== '') ?? 'threw').trim();
  return { ...(at ? { file: at.file, line: at.line, col: at.col } : { file, line: 0, col: 0 }), message, evaluated: true, stack: mapped.stack };
}

export interface ProbesOptions {
  /** `studio:probe` to the studio tabs. */
  tell(id: string, files: readonly string[]): void;
  /** No ack by then: nobody probes. */
  ackMs: number;
  /** No results by then: as if nobody probed. */
  doneMs: number;
  later(run: () => void, ms: number): unknown;
  cancel(timer: unknown): void;
  /** A new probe's id. */
  id(): string;
  /** A probe over, answered or not: its page goes. */
  ended?(id: string): void;
}

/** What the probe page posted: each file's throw, or null -- the page's origin with it, for the stacks' urls. */
export interface Probed {
  results: ProbeResult[];
  origin: string;
}

export interface Probes {
  /** Each file evaluated in the probe page: what each threw, or null when nobody probed (no tab acked, or too late). */
  ask(files: readonly string[]): Promise<Probed | null>;
  /** `POST probe`'s body heard: an ack or the results. False: no such probe waits (late, or another's). */
  heard(body: unknown, origin: string): boolean;
}

const isResult = (r: unknown): r is ProbeResult => {
  if (typeof r !== 'object' || r === null || typeof (r as ProbeResult).file !== 'string') return false;
  const threw = (r as ProbeResult).threw;
  return threw === null || (typeof threw === 'object' && typeof threw.message === 'string' && typeof threw.stack === 'string');
};

export function createProbes(options: ProbesOptions): Probes {
  const waiting = new Map<string, { acked: boolean; done(answer: Probed | null): void }>();
  return {
    ask(files) {
      return new Promise((resolve) => {
        const id = options.id();
        const finish = (answer: Probed | null): void => {
          if (!waiting.delete(id)) return;
          options.ended?.(id);
          options.cancel(ackTimer);
          options.cancel(doneTimer);
          resolve(answer);
        };
        const ackTimer = options.later(() => {
          if (!waiting.get(id)?.acked) finish(null);
        }, options.ackMs);
        const doneTimer = options.later(() => finish(null), options.doneMs);
        waiting.set(id, { acked: false, done: finish });
        options.tell(id, files);
      });
    },
    heard(body, origin) {
      if (typeof body !== 'object' || body === null) return false;
      const { id, ack, results } = body as { id?: unknown; ack?: unknown; results?: unknown };
      const probe = typeof id === 'string' ? waiting.get(id) : undefined;
      if (!probe) return false;
      if (ack === true) {
        probe.acked = true;
        return true;
      }
      if (!Array.isArray(results) || !results.every(isResult)) return false;
      probe.done({ results, origin });
      return true;
    },
  };
}
