/**
 * The studio routes' work in-process (Docs/mcp.md §3, M5): what the Studio tab's cards reach over `/__studio/`, as
 * functions the studio's MCP tools call -- never HTTP from node to itself, never a second path. Made by the studio
 * plugin (`vite.ts`) from the very parts its route handler has, and handed to the agent's holder as it starts
 * (`AgentHolder.studio`), as the assets plugin hands its own (`AssetsCalls`).
 *
 * - **The problems** (`problems()`): tsc's lists and Vite's broken modules, merged as `GET problems` answers.
 * - **The log** (`log`, `streams`): a stream's ring, as `GET log` reads it -- the Console's.
 * - **The tasks** (`tasks`, `ended`): the allow-listed npm scripts as `POST run` and `POST cancel` start and stop
 *   them -- the Tests and Build cards hear the same `studio:task` pushes -- and each end told to whoever follows it.
 * - **The preview** (`preview`): `vite preview` as `POST preview` starts it, and stopped as a build's start stops it.
 * - **Git** (`git`): the Git card's context -- its `git` stream, its one-at-a-time serial -- for `git.ts`' functions.
 * - **Search** (`search`): `GET search`'s.
 * - **A download** (`download`): `POST download`'s start and `GET download`'s state -- the Tools page's Download ffmpeg.
 * - **TypeScript** (`ts()`): the Code card's bridge (`tsserver.ts`), made at the first call as a tab's first message
 *   makes it, spoken to by a socket of the dev server's own (`ts-client.ts`).
 *
 * Types and a small maker; nothing at module level.
 */
import type { DownloadState, LogLine, Problem, SearchAnswer, TaskEnd } from './api-types.ts';
import type { GitContext } from './git.ts';
import type { Tasks, TaskState } from './tasks.ts';
import type { TsClient } from './ts-client.ts';

export interface StudioCalls {
  /** The project's root, absolute. */
  readonly root: string;
  /** tsc's problems and Vite's broken modules, merged (`GET problems`), and when they were last said. */
  problems(): { problems: Problem[]; at: number };
  /** A stream's lines after `since` still kept, and its last seq (`GET log`). */
  log(stream: string, since: number): { seq: number; lines: LogLine[] };
  /** The streams written to, in the order made. */
  streams(): string[];
  /** The allow-listed scripts: run, cancelled, answered (`POST run`, `POST cancel`, `GET tasks`). */
  readonly tasks: Tasks;
  /** What runs and what ran last. */
  task(): TaskState;
  /** Each task's end, told as it ends: the undo. */
  ended(listener: (end: TaskEnd) => void): () => void;
  /** `vite preview`: its url now, started (the running one's), stopped (true: one was). */
  readonly preview: { url(): string | null; start(port?: number): Promise<string>; stop(): Promise<boolean> };
  /** The Git card's context: its `git` stream and its serial. */
  readonly git: GitContext;
  /** `GET search`'s. */
  search(q: string, glob: string | null): Promise<SearchAnswer>;
  /** The tools the studio downloads (ffmpeg): one started as `POST download` starts it (`startDownload`), and how it stands (`GET download`). */
  readonly download: { tools: readonly string[]; start(tool: string): DownloadState; state(tool: string): DownloadState };
  /** The Code card's TypeScript bridge, from node's side. */
  ts(): TsClient;
}
