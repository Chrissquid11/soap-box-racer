/**
 * The TypeScript bridge (`tsserver.ts`, Docs/studio.md §12) from node's side: the studio's MCP tools
 * (`ts_diagnostics`, `ts_definition`, `ts_references`, `ts_hover`, Docs/mcp.md M5) speak to the same one language
 * server the Code card does, through the bridge's own `request` -- a socket of the dev server's own, never a page's
 * -- so a query is answered as the card's are, with no second server.
 *
 * - **A socket of its own**: `send` parses the bridge's envelope (`{ event, data: { message } }`) and answers the
 *   request waiting for that id; the server's notifications are ignored (diagnostics are pulled, not pushed).
 * - **A file read for a call, never owned** (`withFile`): `vibe/open` with `read: true` and its text as the file
 *   route reads it. A Code card tab owning the file: its queries answered for that tab's text, unsaved edits and all.
 *   None: lent by the bridge for the call and given back after (`vibe/release`) -- a tab opening it meanwhile owns
 *   it at once, so no tab is ever left a reader behind a tool's call.
 * - **Positions** are LSP's: a line and a UTF-16 character from 0. The tools take a line and a column from 1, as an
 *   editor shows them, and turn them here.
 *
 * Node only: no page.
 */
import { join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { TS_RES, type TsOpenAnswer } from './api-types.ts';
import type { BridgeSocket, TsBridge } from './tsserver.ts';

/** An LSP error answered for a request: its code and words. */
export class TsError extends Error {
  code: number;
  constructor(code: number, message: string) {
    super(message);
    this.code = code;
  }
}

export interface TsClient {
  /** A request through the bridge, its result; an LSP error thrown as a `TsError`. */
  request(method: string, params: unknown): Promise<unknown>;
  /** A notification (`textDocument/didClose`). */
  notify(method: string, params: unknown): void;
  /** `work` with `path` (project-relative) open on the server: a tab's text while one owns it, else lent at `text` and given back after. */
  withFile<T>(path: string, text: string, work: (uri: string, opened: TsOpenAnswer) => Promise<T>): Promise<T>;
  /** A notification to the tab that has `path` open (`TsBridge.toOwner`): false when none has. */
  toHolder(path: string, method: string, params: unknown): boolean;
  /** A project-relative path's `file://` uri, and back (null: outside the project). */
  uriOf(path: string): string;
  pathOf(uri: string): string | null;
}

/** The language of a file, as `vibe/open` names it. */
const languageOf = (path: string): string => (/\.(?:js|mjs|cjs)$/.test(path) ? 'javascript' : 'typescript');

export function createTsClient(bridge: TsBridge, root: string): TsClient {
  let next = 0;
  const waiting = new Map<number, { resolve(value: unknown): void; reject(err: Error): void }>();
  const socket: BridgeSocket = {
    send(text) {
      let parsed: { event?: unknown; data?: { message?: { id?: unknown; result?: unknown; error?: { code?: unknown; message?: unknown } } } };
      try {
        parsed = JSON.parse(text);
      } catch {
        return;
      }
      if (parsed.event !== TS_RES) return;
      const m = parsed.data?.message;
      if (!m || typeof m.id !== 'number') return;
      const w = waiting.get(m.id);
      if (!w) return;
      waiting.delete(m.id);
      if (m.error) w.reject(new TsError(typeof m.error.code === 'number' ? m.error.code : -1, typeof m.error.message === 'string' ? m.error.message : 'TypeScript\'s server refused it'));
      else w.resolve(m.result ?? null);
    },
  };
  const rootUri = pathToFileURL(root).href.replace(/\/$/, '');
  const client: TsClient = {
    request(method, params) {
      const id = ++next;
      return new Promise((resolve, reject) => {
        waiting.set(id, { resolve, reject });
        // The dev server's own socket: always this machine's.
        bridge.request(socket, { message: { jsonrpc: '2.0', id, method, params } }, true);
      });
    },
    notify(method, params) {
      bridge.request(socket, { message: { jsonrpc: '2.0', method, params } }, true);
    },
    async withFile(path, text, work) {
      const uri = client.uriOf(path);
      const opened = (await client.request('vibe/open', { uri, text, version: 1, languageId: languageOf(path), read: true })) as TsOpenAnswer;
      try {
        return await work(uri, opened);
      } finally {
        if (opened.lent) client.notify('vibe/release', { uri });
      }
    },
    toHolder: (path, method, params) => bridge.toOwner(client.uriOf(path), method, params),
    uriOf: (path) => pathToFileURL(join(root, path)).href,
    pathOf(uri) {
      if (!uri.startsWith('file:')) return null;
      const abs = fileURLToPath(uri);
      const base = fileURLToPath(`${rootUri}/`);
      return abs.startsWith(base) ? abs.slice(base.length).split('\\').join('/') : null;
    },
  };
  return client;
}
