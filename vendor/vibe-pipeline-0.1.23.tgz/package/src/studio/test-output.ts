/**
 * The Tests card's parser (the editor's `tests-card.ts`, and the studio's `tests_run` tool, Docs/mcp.md M5): `vibe test`'s output, as it streams in, into a row per test file
 * (`parseTestOutput`). No DOM: node tests it over the sandbox's real output (`tests.test.ts`).
 *
 * What the runner prints (`@vibe/pipeline`'s `test-runner.ts`, each file's `suite()` from `@vibe/engine/testing`):
 *
 * ```
 * > @vibe/sandbox@0.1.0 test          npm's header (and `$ npm run test`, the studio's own first line)
 * > vibe test
 *
 * game: built from prefabs            a file: its suite's title, a blank line,
 * skipped: … -- …                       what it says,
 * 19 passed, 1 failed                   its count,
 *   FAIL the name                       each failure (its got/expected indented under it),
 *                                     then the runner's blank line
 * 5 of 6 test files passed            the end: the count of files,
 *   FAILED src/game/x.test.ts           each failing file's path, in the order run
 * [checks] 2 findings                 then the checks: clean, or findings and each under it
 * [test exited 1]                     the studio's last line (`tasks.ts`)
 * ```
 *
 * The runner names a file only when it fails (`FAILED <path>`): a row's `path` is null until then, and the
 * failing rows -- a count with failures, or none at all (it crashed) -- take the `FAILED` paths in order. A file
 * that crashed prints no count: the next title -- a line between blank ones -- is what ends it.
 */

/** A test file's row. */
export interface TestFile {
  /** Its suite's title: the first line it printed. */
  title: string;
  /** Its path, from the `FAILED` lines: only a failing file's is ever printed. */
  path: string | null;
  passed: number;
  failed: number;
  skipped: number;
  /** Every line it printed after its title, the blank ones left out. */
  lines: string[];
  /** Its count is in: it finished (a crash never prints one). */
  done: boolean;
}

export interface TestRun {
  files: TestFile[];
  /** `N of M test files passed`, once printed. */
  total: { passed: number; files: number } | null;
  /** The checks after the tests: clean, or the findings (each `  file:line  rule` and its fix in `lines`). */
  checks: { clean: boolean; findings: number; lines: string[] } | null;
  /** `[test exited N]` (`'1'`), `[test stopped by SIGTERM]` (`'SIGTERM'`); null while it runs. */
  exit: string | null;
}

const COUNT = /^(\d+) passed, (\d+) failed(?:, (\d+) skipped)?$/;
const TOTAL = /^(\d+) of (\d+) test files passed$/;
const FAILED = /^\s+FAILED (.+)$/;
const CHECKS = /^\[checks\] (?:(clean)|(\d+) findings?)$/;
const EXIT = /^\[[\w:-]+ (?:exited (-?\d+|null)|stopped by (\w+))\]$/;

/** The lines of one run of `vibe test` -- the studio's `$ npm run test` line onward, or a terminal's -- as rows. */
export function parseTestOutput(lines: readonly string[]): TestRun {
  const run: TestRun = { files: [], total: null, checks: null, exit: null };
  /** The file being printed: from its title to the blank line after its count. */
  let open: TestFile | null = null;
  const failedPaths: string[] = [];
  /** In the checks' part: their lines. */
  let inChecks = false;

  const trimmed = lines.map((raw) => raw.replace(/\s+$/, ''));
  for (let n = 0; n < trimmed.length; n++) {
    const line = trimmed[n]!;
    const exit = EXIT.exec(line);
    if (exit) {
      run.exit = exit[1] ?? exit[2] ?? null;
      open = null;
      continue;
    }
    if (line.startsWith('$ npm ') || line.startsWith('> ')) continue;
    const total = TOTAL.exec(line);
    if (total) {
      run.total = { passed: Number(total[1]), files: Number(total[2]) };
      open = null;
      continue;
    }
    const failed = run.total ? FAILED.exec(line) : null;
    if (failed) {
      failedPaths.push(failed[1]!);
      continue;
    }
    const checks = CHECKS.exec(line);
    if (checks) {
      run.checks = { clean: checks[1] !== undefined, findings: checks[1] !== undefined ? 0 : Number(checks[2]), lines: run.checks?.lines ?? [] };
      inChecks = true;
      open = null;
      continue;
    }
    if (line.startsWith('[checks] ') || (inChecks && line !== '')) {
      run.checks ??= { clean: false, findings: 0, lines: [] };
      run.checks.lines.push(line.startsWith('[checks] ') ? line.slice(9) : line);
      inChecks = true;
      continue;
    }
    if (run.total) continue;
    if (line === '') {
      // The runner's blank line after a file's count closes it; the one after its title does not.
      if (open?.done) open = null;
      continue;
    }
    // A file that crashed prints no count: the next file's title -- after a blank line, a blank line after it
    // (the suite's own) -- ends it. Node's last line of a crash, `Node.js v24.2.0`, is the crash's.
    if (open && !open.done && open.lines.length > 0 && trimmed[n - 1] === '' && (trimmed[n + 1] ?? '') === '' && !/^Node\.js v\d/.test(line)) open = null;
    if (!open) {
      open = { title: line, path: null, passed: 0, failed: 0, skipped: 0, lines: [], done: false };
      run.files.push(open);
      continue;
    }
    const count = COUNT.exec(line);
    if (count && !open.done) {
      open.passed = Number(count[1]);
      open.failed = Number(count[2]);
      open.skipped = Number(count[3] ?? 0);
      open.done = true;
      continue;
    }
    open.lines.push(line);
  }

  // The failing files' paths, in the order run: those with failures, and those that never printed a count.
  const failing = run.files.filter((f) => f.failed > 0 || (!f.done && run.total !== null));
  failing.forEach((f, i) => (f.path = failedPaths[i] ?? null));
  return run;
}

/** A row's words: `game: built from prefabs  19 passed`, `… 18 passed, 1 failed`, `… did not finish`. */
export function fileWords(file: TestFile, running: boolean): string {
  if (!file.done) return running ? 'running…' : 'did not finish';
  return `${file.passed} passed${file.failed ? `, ${file.failed} failed` : ''}${file.skipped ? `, ${file.skipped} skipped` : ''}`;
}
