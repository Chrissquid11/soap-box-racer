/**
 * The Code card's file operations (Docs/studio.md §3, §11): `POST files/new`, `files/move`, `files/copy` and
 * `files/delete` for `vite.ts`' routes, and the same work for the studio's `code_move` and `code_delete` tools
 * (`mcp/tools/code.ts`) -- one implementation.
 *
 * - **What may change** is what the card may write (`files.ts`' `access`): a path of the tree's form (`pathForm`), inside
 *   the project (`staysInside`), tracked or under the tree's roots, never ignored, excluded (`node_modules`, `dist`, ...)
 *   or generated (`isGenerated`: `keys.d.ts`, the globs, `live.ts` -- 403 with words saying so). A folder may not hold a
 *   generated file (moving `src/assets/` would take `keys.d.ts` with it) or a repository (`engine/`, a `.git` in it).
 * - **A clash** -- something at the destination already -- is `409 FileClash { why, clash }`: the card asks Replace, Keep
 *   both or Cancel. `replace: true` puts a file there in its place (a folder is never replaced). A case-only rename
 *   (`Spin.ts` → `spin.ts`) is no clash with itself: it goes through a dot-named temp name, as a case-insensitive disk needs.
 * - **Into itself** -- a folder moved or copied into itself or under it -- is 400.
 * - **A running turn's file** (`writingNow`): 423 `FileLocked`, as a save is.
 * - **Under the assets** (`src/assets/`, `AssetsSource/`, `packs/`: `WRITE_DIRS`) nothing is renamed on disk here: the
 *   move is the Assets panel's own (`mcp/assets.ts`' `moveOffline` -- uids kept, the keys in files rewritten by the repair
 *   pass, refused while game code names the asset), a copy its copy (a new uid, named by it), a delete its delete (to the
 *   project's `.trash/`, refused while a data file names it). An asset never leaves the assets this way, nor comes in.
 * - **A script moved or renamed** (`.ts`, `.js` ... or a folder): TypeScript's `workspace/willRenameFiles` through the
 *   Code card's bridge (`ts-client.ts`) first -- the imports of it and its own relative imports, as VS Code does -- then
 *   the rename, then the edits at the files' new places. A file a Code card tab has open is never written: TypeScript
 *   answered for that tab's text, so its edits go to the tab (`vibe/applyEdits`, the bridge's `toOwner`), whose model
 *   takes them -- and saves them where it was clean, as VS Code's `files.refactoring.autoSave`, else holds them unsaved (`held`). Any other is written atomically, and only where each range replaced is a
 *   relative specifier between matching quotes (`applySpecifierEdits`); else it is left alone and named in `imports`.
 *   TypeScript down: moved all the same, `imports` saying why none was updated.
 * - **A copy's source** is checked too: inside the project by its real path (`node_modules` no exception), never
 *   excluded, ignored or generated.
 * - **Writes are atomic**: a file's text through `writeAtomic`; a rename is one (over a file replaced, too); a folder copied beside its destination
 *   under a dot-name first, then renamed into place.
 *
 * Nothing at module level.
 */
import { cp, mkdir, readdir, readFile, rename, rm, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { tempBeside, writeAtomic } from '../assets/fs.ts';
import { Refused } from '../assets/http.ts';
import { isGenerated } from '../assets/keys.ts';
import { WRITE_DIRS } from '../assets/paths.ts';
import type { AssetsCalls } from '../assets/server.ts';
import { copyOffline, deleteOffline, moveOffline } from '../mcp/assets.ts';
import { access, excluded, pathForm, staysInside, underRoots, type FilesContext, type WritingNow } from './files.ts';
import type { FileClash, FileLocked, FileMade, FilesCopied, FilesDeleted, FilesMoved } from './api-types.ts';
import type { TsClient } from './ts-client.ts';

export interface FileOpsContext extends FilesContext {
  /** The conversations' running turns' files: one of them changed is 423. */
  writingNow?: WritingNow;
  /** The assets server's work in-process: a move, copy or delete under the assets goes through it. None: refused there. */
  assets?: () => AssetsCalls | null | undefined;
  /** The Code card's TypeScript bridge from node's side: a script's imports updated as it moves. None: not updated. */
  ts?: () => TsClient | null;
}

/** Is the path one of the assets' (`src/assets/`, `AssetsSource/`, `packs/`), or one of their folders itself. */
export const underAssets = (path: string): boolean => WRITE_DIRS.some((d) => path === d || path.startsWith(`${d}/`));

/** Does TypeScript's server read it: a script. */
export const isScriptPath = (path: string): boolean => /\.(?:[cm]?ts|tsx|[cm]?js|jsx)$/i.test(path);

/** The folder a path is in (`''`: the root). */
const parentOf = (path: string): string => (path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '');
const baseOf = (path: string): string => path.slice(path.lastIndexOf('/') + 1);

/** What is at a path: a file, a folder, or nothing. */
async function kindAt(root: string, path: string): Promise<'file' | 'folder' | null> {
  try {
    const info = await stat(join(root, path));
    return info.isDirectory() ? 'folder' : info.isFile() ? 'file' : null;
  } catch {
    return null;
  }
}

/** Are two paths the one file (a disk that ignores case): the same inode. */
async function sameFile(root: string, a: string, b: string): Promise<boolean> {
  try {
    const [x, y] = await Promise.all([stat(join(root, a)), stat(join(root, b))]);
    return x.ino === y.ino && x.dev === y.dev;
  } catch {
    return false;
  }
}

/** Every file under a folder, project-relative (excluded folders skipped). */
export async function filesUnder(root: string, dir: string): Promise<string[]> {
  const out: string[] = [];
  const walk = async (d: string): Promise<void> => {
    const names = await readdir(join(root, d), { withFileTypes: true }).catch(() => []);
    for (const entry of names) {
      const path = `${d}/${entry.name}`;
      if (entry.isDirectory()) {
        if (entry.name === '.git') throw new Refused(403, `${d} is a repository of its own: not moved, copied or deleted here`);
        if (!excluded(`${path}/x`)) await walk(path);
      } else if (entry.isFile()) out.push(path);
    }
  };
  await walk(dir);
  return out;
}

/** A path the card may write or take away: its form, inside the project, not read-only nor generated. */
async function changeable(ctx: FileOpsContext, raw: unknown, what: string): Promise<string> {
  const path = pathForm(raw);
  await staysInside(ctx.root, path);
  if (isGenerated(path)) throw new Refused(403, `${path} is generated by vibe assets: never ${what} by hand`);
  return path;
}

/** A file's path writable, or 403 in words. */
async function writableFile(ctx: FileOpsContext, path: string, what: string): Promise<void> {
  if ((await access(ctx, path)).readOnly) throw new Refused(403, `${path} is read-only here: not ${what}`);
}

/** A folder's path writable: under the tree's roots, no excluded folder on it, no repository or generated file in it. */
async function writableFolder(ctx: FileOpsContext, path: string, what: string, existing: boolean): Promise<void> {
  if (excluded(`${path}/x`) || !underRoots(`${path}/x`)) throw new Refused(403, `${path} is not a folder the card ${what}`);
  if (!existing) return;
  if (existsSync(join(ctx.root, path, '.git'))) throw new Refused(403, `${path} is a repository of its own: not ${what} here`);
  const generated = (await filesUnder(ctx.root, path)).find(isGenerated);
  if (generated) throw new Refused(403, `${path} holds ${generated}, which vibe assets generates: not ${what}`);
}

/** A running turn writes it: 423, as a save is. */
function notLocked(ctx: FileOpsContext, paths: readonly string[]): void {
  const now = ctx.writingNow?.();
  if (!now) return;
  for (const p of paths) {
    const writer = [...now].find(([w]) => w === p || w.startsWith(`${p}/`))?.[1];
    if (writer) {
      const locked: FileLocked = { why: `"${writer.title}" is writing ${p}: try again once its turn ends`, conversation: writer };
      throw new Refused(423, locked.why, locked as unknown as Record<string, unknown>);
    }
  }
}

/** Something is at `to`: 409 with it named. */
function clash(to: string, kind: 'file' | 'folder'): never {
  const body: FileClash = { why: `${to} is there already (a ${kind})`, clash: to };
  throw new Refused(409, body.why, body as unknown as Record<string, unknown>);
}

/** Its folder must be there: the card makes folders through New Folder, never by a path typed. */
async function folderThere(ctx: FileOpsContext, path: string): Promise<void> {
  const dir = parentOf(path);
  if (dir !== '' && (await kindAt(ctx.root, dir)) !== 'folder') throw new Refused(404, `${dir} is not there`);
}

/** A folder moved or copied into itself, or under itself: 400. */
function notIntoItself(from: string, to: string, kind: 'file' | 'folder'): void {
  if (kind === 'folder' && (to === from || to.startsWith(`${from}/`))) throw new Refused(400, `${from} cannot go into itself`);
}

/** An asset's tool's refusal (`ToolRefusal`, a route's `Refused`) as a route's. */
async function asAssets<T>(work: () => Promise<T>): Promise<T> {
  try {
    return await work();
  } catch (err) {
    if (err instanceof Refused) throw err;
    throw new Refused(409, err instanceof Error ? err.message : String(err));
  }
}

/** The assets server, or 503 in words: an asset is only ever moved through it. */
function assetsOrRefused(ctx: FileOpsContext, path: string): AssetsCalls {
  const calls = ctx.assets?.();
  if (!calls) throw new Refused(503, `${path} is an asset: the assets server moves it, and none runs here`);
  return calls;
}

/** Both ends among the assets, or neither: an asset never leaves them this way, nor comes in. */
function sameSide(from: string, to: string): boolean {
  const a = underAssets(from);
  const b = underAssets(to);
  if (a !== b) throw new Refused(400, a ? `${from} is an asset: it stays under src/assets/, AssetsSource/ or packs/ (the Assets panel's move)` : `${to} is among the assets: a file comes in through the Assets panel's import, never a move`);
  return a;
}

// ---------------------------------------------------------------- new

/** `POST files/new { path, folder? }`: an empty file, or a folder. */
export async function makeEntry(ctx: FileOpsContext, body: Record<string, unknown>): Promise<FileMade> {
  const folder = body.folder === true;
  const path = await changeable(ctx, body.path, 'made');
  notLocked(ctx, [path]);
  if (folder) await writableFolder(ctx, path, 'makes', false);
  else await writableFile(ctx, path, 'made');
  const there = await kindAt(ctx.root, path);
  if (there) clash(path, there);
  await folderThere(ctx, path);
  if (folder) await mkdir(join(ctx.root, path));
  else await writeAtomic(join(ctx.root, path), '', { sync: true });
  return { path, folder };
}

// ---------------------------------------------------------------- move

/** One text edit as LSP has it: a range of lines and UTF-16 characters from 0, and the text for it. */
interface Edit {
  range: { start: { line: number; character: number }; end: { line: number; character: number } };
  newText: string;
}

/** An offset in `text` of an LSP position (a line past the end: the end). */
function offsetOf(text: string, line: number, character: number): number {
  let at = 0;
  for (let l = 0; l < line; l++) {
    const next = text.indexOf('\n', at);
    if (next < 0) return text.length;
    at = next + 1;
  }
  const end = text.indexOf('\n', at);
  return Math.min(at + character, end < 0 ? text.length : end);
}

const QUOTES = new Set(['\'', '"', '`']);

/**
 * `edits` applied to `text`, last first -- or null when one of them replaces no module specifier: the text replaced
 * must sit inside a matching pair of quotes (`text[from - 1]` and `text[to]` the same quote) and start with `.` (a
 * relative specifier, the only kind a move changes). A range that lands anywhere else -- `obj.prop`, a shifted line --
 * means the text is not what TypeScript read, and the file is left alone.
 */
export function applySpecifierEdits(text: string, edits: readonly Edit[]): string | null {
  const at = edits.map((e) => ({ from: offsetOf(text, e.range.start.line, e.range.start.character), to: offsetOf(text, e.range.end.line, e.range.end.character), text: e.newText }));
  for (const e of at) {
    const quote = text[e.from - 1];
    if (e.to <= e.from || quote === undefined || !QUOTES.has(quote) || text[e.to] !== quote || text[e.from] !== '.' || /[\n'"`]/.test(text.slice(e.from, e.to))) return null;
  }
  at.sort((a, b) => b.from - a.from);
  let out = text;
  for (const e of at) out = out.slice(0, e.from) + e.text + out.slice(e.to);
  return out;
}

/** The edits of a `WorkspaceEdit` by uri: its `changes`, or its `documentChanges`' text edits. */
function editsOf(answer: unknown): Map<string, Edit[]> {
  const out = new Map<string, Edit[]>();
  const a = answer as { changes?: Record<string, Edit[]>; documentChanges?: Array<{ textDocument?: { uri?: string }; edits?: Edit[] }> } | null;
  for (const [uri, edits] of Object.entries(a?.changes ?? {})) out.set(uri, [...(out.get(uri) ?? []), ...edits]);
  for (const d of a?.documentChanges ?? []) if (d.textDocument?.uri && d.edits) out.set(d.textDocument.uri, [...(out.get(d.textDocument.uri) ?? []), ...d.edits]);
  return out;
}

/** The edited paths as they are after the move: one inside what moved follows it. */
const after = (path: string, from: string, to: string): string => (path === from ? to : path.startsWith(`${from}/`) ? to + path.slice(from.length) : path);

/** TypeScript's edits for `from` becoming `to`, by the files' paths before the move -- asked before the rename. */
async function askEdits(ctx: FileOpsContext, from: string, to: string, kind: 'file' | 'folder'): Promise<{ ts: TsClient; edits: Map<string, Edit[]> } | { why: string } | null> {
  const scripts = kind === 'file' ? (isScriptPath(from) ? [from] : []) : (await filesUnder(ctx.root, from)).filter(isScriptPath);
  if (scripts.length === 0) return null;
  const ts = ctx.ts?.();
  if (!ts) return { why: 'no TypeScript bridge here' };
  const opened = scripts[0]!;
  try {
    const text = await readFile(join(ctx.root, opened), 'utf8');
    const answer = await ts.withFile(opened, text, () => ts.request('workspace/willRenameFiles', { files: [{ oldUri: ts.uriOf(from), newUri: ts.uriOf(to) }] }));
    const edits = new Map<string, Edit[]>();
    for (const [uri, list] of editsOf(answer)) {
      const path = ts.pathOf(uri);
      if (path !== null && list.length > 0) edits.set(path, list);
    }
    return { ts, edits };
  } catch (err) {
    return { why: `TypeScript: ${err instanceof Error ? err.message : String(err)}` };
  }
}

/**
 * The edits written, after the rename, each at its file's place now. A file a Code card tab has open is never written
 * here -- TypeScript answered for that tab's text, unsaved changes and all -- its edits go to the tab
 * (`vibe/applyEdits`), whose model takes them -- saved there if it was clean, held unsaved if not (`held`). Any other is written
 * atomically, an edit whose range is no relative specifier on disk leaving its file alone and named.
 */
async function writeEdits(ctx: FileOpsContext, ts: TsClient, edits: Map<string, Edit[]>, from: string, to: string): Promise<{ edited: string[]; held: string[]; why?: string }> {
  const edited: string[] = [];
  const held: string[] = [];
  const skipped: string[] = [];
  for (const [was, list] of edits) {
    const path = after(was, from, to);
    // The tab holds the path it opened: the old one, until the card follows the move.
    if (ts.toHolder(was, 'vibe/applyEdits', { path, was, edits: list })) {
      held.push(path);
      continue;
    }
    if ((await access(ctx, path)).readOnly) {
      skipped.push(`${path} (read-only)`);
      continue;
    }
    const file = join(ctx.root, path);
    try {
      const text = await readFile(file, 'utf8');
      const now = applySpecifierEdits(text, list);
      if (now === null) {
        skipped.push(`${path} (its text is not what TypeScript read)`);
        continue;
      }
      if (now === text) continue;
      await writeAtomic(file, now, { mode: (await stat(file)).mode, sync: true });
      edited.push(path);
    } catch (err) {
      skipped.push(`${path} (${err instanceof Error ? err.message : String(err)})`);
    }
  }
  return skipped.length > 0 ? { edited, held, why: `not updated: ${skipped.join(', ')}` } : { edited, held };
}

/** `POST files/move { from, to, replace? }`. */
export async function moveEntry(ctx: FileOpsContext, body: Record<string, unknown>): Promise<FilesMoved> {
  const from = await changeable(ctx, body.from, 'moved');
  const to = await changeable(ctx, body.to, 'moved');
  const kind = await kindAt(ctx.root, from);
  if (!kind) throw new Refused(404, `${from} is not there`);
  if (from === to) return { via: underAssets(from) ? 'assets' : 'files', moved: [], edited: [], held: [], rewritten: [] };
  notIntoItself(from, to, kind);
  notLocked(ctx, [from, to]);
  // A case-only rename on a disk that ignores case finds `from` at `to`: the same file (its inode), no clash.
  const caseOnly = from.toLowerCase() === to.toLowerCase() && (await sameFile(ctx.root, from, to));
  if (kind === 'file') {
    await writableFile(ctx, from, 'moved');
    await writableFile(ctx, to, 'moved there');
  } else {
    await writableFolder(ctx, from, 'moves', true);
    await writableFolder(ctx, to, 'moves into', false);
  }
  await folderThere(ctx, to);
  const there = caseOnly ? null : await kindAt(ctx.root, to);
  if (there && (body.replace !== true || there === 'folder' || kind === 'folder')) clash(to, there);

  if (sameSide(from, to)) {
    const calls = assetsOrRefused(ctx, from);
    if (there) throw new Refused(409, `${to} is there already: the Assets panel replaces an asset, not a move`);
    // The panel's move: into a folder keeping its name, or a rename in its folder -- one at a time.
    const args = parentOf(from) === parentOf(to) ? { paths: [from], name: baseOf(to) } : baseOf(from) === baseOf(to) ? { paths: [from], to: parentOf(to) } : null;
    if (!args) throw new Refused(400, `${from} to ${to}: an asset is moved into a folder or renamed in its own, one at a time`);
    const done = await asAssets(() => moveOffline(calls, args));
    return { via: 'assets', moved: done.moved, edited: [], held: [], rewritten: done.rewritten };
  }

  // TypeScript asked first (it reads the old paths), then the rename -- over a file there with `replace`: a rename is
  // atomic -- and only then the edits, at the files' new places: a rename that fails has written nothing.
  const asked = await askEdits(ctx, from, to, kind);
  if (caseOnly) {
    const temp = tempBeside(join(ctx.root, to));
    await rename(join(ctx.root, from), temp);
    await rename(temp, join(ctx.root, to));
  } else await rename(join(ctx.root, from), join(ctx.root, to));
  let written: { edited: string[]; held: string[]; why?: string } = { edited: [], held: [] };
  if (asked && 'why' in asked) written.why = asked.why;
  else if (asked) {
    written = await writeEdits(ctx, asked.ts, asked.edits, from, to);
    // The server told, as an editor tells it: its own watch may be behind.
    try {
      asked.ts.notify('workspace/didRenameFiles', { files: [{ oldUri: asked.ts.uriOf(from), newUri: asked.ts.uriOf(to) }] });
    } catch {
      // The bridge is down: it starts afresh from the disk.
    }
  }
  return { via: 'files', moved: [[from, to]], edited: written.edited, held: written.held, rewritten: [], ...(written.why !== undefined ? { imports: written.why } : {}) };
}

// ---------------------------------------------------------------- copy

/** `POST files/copy { from, to, replace? }`: a file or a folder copied whole; an asset through the assets' copy. */
export async function copyEntry(ctx: FileOpsContext, body: Record<string, unknown>): Promise<FilesCopied> {
  const from = pathForm(body.from);
  // Its real place inside the project, `node_modules` no exception: nothing outside the project is copied in.
  await staysInside(ctx.root, from, true);
  const to = await changeable(ctx, body.to, 'written');
  const kind = await kindAt(ctx.root, from);
  if (!kind) throw new Refused(404, `${from} is not there`);
  // What the card may read and write, never what is excluded, ignored or generated.
  if (excluded(kind === 'folder' ? `${from}/x` : from) || (await access(ctx, from)).readOnly) throw new Refused(403, `${from} is not the project's to copy: read-only, ignored, generated or excluded`);
  notIntoItself(from, to, kind);
  notLocked(ctx, [to]);
  if (kind === 'file') await writableFile(ctx, to, 'written');
  else {
    await writableFolder(ctx, to, 'copies into', false);
    if (existsSync(join(ctx.root, from, '.git'))) throw new Refused(403, `${from} is a repository of its own: not copied here`);
  }
  await folderThere(ctx, to);
  const there = await kindAt(ctx.root, to);
  if (there && (body.replace !== true || there === 'folder' || kind === 'folder')) clash(to, there);

  if (sameSide(from, to)) {
    const calls = assetsOrRefused(ctx, from);
    // The assets' copy names its copy itself (a new uid, `-2` where the name is taken): into the folder asked.
    const done = await asAssets(() => copyOffline(calls, { paths: [from], to: parentOf(to) === '' ? '.' : parentOf(to) }));
    return { via: 'assets', copies: done.copies };
  }
  const dest = join(ctx.root, to);
  if (kind === 'file') {
    const info = await stat(join(ctx.root, from));
    await writeAtomic(dest, await readFile(join(ctx.root, from)), { mode: info.mode, sync: true });
  } else {
    // Whole or not at all: beside it under a dot-name, then renamed into place.
    const temp = tempBeside(dest);
    try {
      await cp(join(ctx.root, from), temp, { recursive: true, errorOnExist: true, force: false });
      await rename(temp, dest);
    } catch (err) {
      await rm(temp, { recursive: true, force: true });
      throw err;
    }
  }
  return { via: 'files', copies: [to] };
}

// ---------------------------------------------------------------- delete

/** `POST files/delete { paths, check? }`: each taken away for good -- an asset to the project's `.trash/` -- or, `check`, only checked. */
export async function deleteEntries(ctx: FileOpsContext, body: Record<string, unknown>): Promise<FilesDeleted> {
  const raw = Array.isArray(body.paths) ? body.paths : [body.paths];
  if (raw.length === 0) throw new Refused(400, 'paths: at least one');
  const paths: string[] = [];
  for (const r of raw) paths.push(await changeable(ctx, r, 'deleted'));
  notLocked(ctx, paths);
  for (const path of paths) {
    const kind = await kindAt(ctx.root, path);
    if (!kind) throw new Refused(404, `${path} is not there`);
    if (kind === 'file') await writableFile(ctx, path, 'deleted');
    else await writableFolder(ctx, path, 'deletes', true);
  }
  const assets = paths.filter(underAssets);
  if (assets.length > 0 && assets.length !== paths.length) throw new Refused(400, 'assets and other files are deleted apart: the assets go to the project\'s .trash/');
  if (body.check === true) return { via: 'checked', removed: [] };
  if (assets.length > 0) {
    const calls = assetsOrRefused(ctx, assets[0]!);
    const done = await asAssets(() => deleteOffline(calls, { paths: assets }));
    return { via: 'assets', removed: done.removed, ...(done.slot ? { slot: done.slot } : {}) };
  }
  for (const path of paths) await rm(join(ctx.root, path), { recursive: true, force: true });
  return { via: 'files', removed: paths };
}
