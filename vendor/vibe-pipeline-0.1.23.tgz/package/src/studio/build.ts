/**
 * After a build (Docs/studio.md), for the Build card:
 *
 * - **`dist/` measured** (`distSizes`): every folder with the bytes and files under it, and the ten
 *   largest files -- once per build that ends 0 (pushed as `studio:dist`) and on demand (`GET dist`).
 * - **A preview** (`startPreview`): `vite preview` through Vite's API, as `vibe preview` runs it
 *   (`commands.ts`), in this process, on the project's preview port (or the one a call names). One at a
 *   time: a second call answers the running one's url. Stopped when a build task starts (its `dist/` is
 *   about to go) and with the server.
 * - **Reveal in the Finder** is the shell's (phase 5): it puts a function on the holder (`reveal`); a
 *   browser has none, and `POST reveal` is `501 { why: 'no shell' }`.
 *
 * Nothing at module level.
 */
import { lstat, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import type { DistAnswer } from './api-types.ts';

/** How many of the largest files are named. */
export const LARGEST = 10;

/** `dist/` under `root` measured; null when there is none. Links are not followed. */
export async function distSizes(root: string, now: () => number = Date.now): Promise<DistAnswer | null> {
  const top = join(root, 'dist');
  try {
    if (!(await lstat(top)).isDirectory()) return null;
  } catch {
    return null;
  }
  const folders = new Map<string, { bytes: number; files: number }>();
  const files: { path: string; bytes: number }[] = [];
  const walk = async (abs: string, rel: string): Promise<void> => {
    folders.set(rel, { bytes: 0, files: 0 });
    for (const entry of await readdir(abs, { withFileTypes: true })) {
      const childAbs = join(abs, entry.name);
      const childRel = `${rel}/${entry.name}`;
      if (entry.isDirectory()) await walk(childAbs, childRel);
      else if (entry.isFile()) files.push({ path: childRel, bytes: (await lstat(childAbs)).size });
    }
  };
  await walk(top, 'dist');
  for (const file of files) {
    // Each folder on its way counts it: dist, dist/assets, dist/assets/models …
    for (let cut = file.path.lastIndexOf('/'); cut > 0; cut = file.path.lastIndexOf('/', cut - 1)) {
      const folder = folders.get(file.path.slice(0, cut))!;
      folder.bytes += file.bytes;
      folder.files += 1;
    }
  }
  return {
    at: now(),
    folders: [...folders].map(([path, size]) => ({ path, ...size })).sort((a, b) => (a.path < b.path ? -1 : 1)),
    largest: files.sort((a, b) => b.bytes - a.bytes || (a.path < b.path ? -1 : 1)).slice(0, LARGEST),
  };
}

/** What Vite's `preview()` answers, as far as this module uses it. */
export interface PreviewServerLike {
  resolvedUrls: { local: string[]; network: string[] } | null;
  close(): Promise<void>;
}

/** The preview the holder keeps: the server, its url, and a start under way (a second call waits for it). */
export interface PreviewState {
  server: PreviewServerLike | null;
  url: string | null;
  starting: Promise<string> | null;
}

export const freshPreview = (): PreviewState => ({ server: null, url: null, starting: null });

/** Vite's `preview()` over the project's config, on `port` when one is said. */
export async function vitePreview(root: string, port?: number): Promise<PreviewServerLike> {
  const { preview } = await import('vite');
  return preview({ root, configFile: join(root, 'vite.config.ts'), ...(port ? { preview: { port } } : {}) });
}

/** The preview's url: the running one's, or a new one's (its first local url). */
export function startPreview(state: PreviewState, start: () => Promise<PreviewServerLike>): Promise<string> {
  if (state.url !== null) return Promise.resolve(state.url);
  state.starting ??= (async () => {
    try {
      const server = await start();
      const url = server.resolvedUrls?.local[0];
      if (!url) {
        await server.close();
        throw new Error('the preview started with no local url');
      }
      state.server = server;
      state.url = url;
      return url;
    } finally {
      state.starting = null;
    }
  })();
  return state.starting;
}

/** The preview stopped, if one runs; true when one did. */
export async function stopPreview(state: PreviewState): Promise<boolean> {
  const server = state.server;
  if (!server) return false;
  state.server = null;
  state.url = null;
  await server.close();
  return true;
}
