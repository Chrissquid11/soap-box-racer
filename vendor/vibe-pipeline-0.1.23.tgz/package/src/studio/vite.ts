/**
 * The studio's server side (Docs/studio.md): everything the terminal showed a
 * developer -- the dev server's log, the npm scripts, tsc's errors, the tools found or missing, the
 * build's sizes, a preview -- as routes under `/__studio/` and pushes to this machine's tabs under the
 * assets channel's event, for the Studio tab's cards (Docs/studio.md). The route table is `api-types.ts`'.
 *
 * - **`apply: 'serve'`**, mounted by `vibe()` after the agent's plugin: none of it is in a build.
 * - **This machine's alone**: every request from an address that is not loopback is `403`, a GET too --
 *   the log, the task output and tsc's problems name the project's files, and the editor that reads them
 *   runs here; a phone on the LAN shows the game only. A mutating call goes through the pipeline's guards
 *   as well (`assets/http.ts`' `guardWrite`: this server's own page, a POST as JSON); a refusal thrown as
 *   `Refused` is answered with its status.
 * - **Pushes to this machine's studio pages only** (`studioSockets`): each `{ type: 'studio', kind:
 *   'studio:<name>', ... }` under the assets channel's event (`PUSH_EVENT`), but sent socket by socket to
 *   the page websockets from loopback (`mayWrite`) that said `STUDIO_HELLO` (the editor's hub, the Debugger tab)
 *   -- never `server.ws.send`, which reaches every page, a LAN phone's included, and never the plain page or the
 *   probe frame's own Vite client. The debugger looks for a studio tab, and a reload is probed, only for these.
 * - **Signals caught**: node emits no `exit` on a death by signal, so `SIGINT` and `SIGTERM` are heard
 *   (once, first, `prependOnceListener`) to stop a running task's process group and the tsc watchers; then,
 *   when no other listener is left to end the process (Vite's own SIGTERM closes the server and exits), the
 *   signal is raised again for the default death. A Ctrl-C, or the supervisor's SIGTERM to its child
 *   (`commands.ts`), leaves nothing running.
 * - **The Code card's files** (`files.ts`, `search.ts`): `GET tree`, `GET file`, `PUT file`, `GET search`, and
 *   `studio:file-changed` from Vite's watcher, a path's events coalesced over 50 ms.
 * - **The Git card's routes** (`git.ts`): `git/status`, `git/log`, `git/branches`, `git/diff`, and `git/commit`,
 *   `git/checkout`, `git/push`, `git/pull` -- the last three asking first (`{ ask }`) -- over the project's
 *   repositories, their lines to the log's `git` stream.
 * - **The TypeScript bridge** (`tsserver.ts`, `TS_REQ` on Vite's websocket): the Code card's language server,
 *   spawned at a tab's first message, answering this machine's page sockets alone (`studioSockets().has`); a
 *   socket's close closes its files. Stopped with the server's close and the process's exit, as tsc's watch is.
 * - **A module that breaks mid-session** (`broken.ts`, Docs/studio.md §1 "Mid-session"): each change of the project's
 *   own code transformed as it comes (`hotUpdate`, after the agent's hold), and every module broken before it; a page
 *   reload Vite would send while any is broken held, and sent once none is; the broken ones `studio:broken`, `GET
 *   broken`, and the Problems card's rows (`VITE_PROGRAM`) -- and to every page as Vite's own `error`, the plain
 *   page's overlay. `POST stack` maps a runtime error's stack to the TypeScript through the served modules' maps.
 * - **Its state on `globalThis`** (`STUDIO_KEY`, `StudioHolder`), as the agent's is: Vite restarts the dev
 *   server in-process when `vite.config.ts` changes, and the rings and a running task outlive it; the new
 *   server's handler answers for them and the pushes go out on its channel.
 *
 * `studioHandler` is the plumbing, Node's own `http` types and nothing of Vite's, so `routes.test.ts`
 * runs it on a bare `http.createServer`; `studio` is the plugin. Nothing at module level.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import { randomUUID } from 'node:crypto';
import { readFileSync, realpathSync } from 'node:fs';
import { basename, join, posix, relative, sep } from 'node:path';
import { TraceMap } from '@jridgewell/trace-mapping';
import type { EnvironmentModuleNode, Plugin } from 'vite';
import type { PushMessage } from '../assets/api-types.ts';
import { Refused, authority, checkPath, drain, guardHost, guardWrite, isLoopback, mayWrite, mutating, readJson, sendJson, allowedHosts } from '../assets/http.ts';
import { PUSH_EVENT } from '../assets/kinds.ts';
import type { TabSocket } from '../assets/server.ts';
import { FILE_LIMIT, STUDIO_HELLO, STUDIO_PREFIX, TS_REQ, VITE_PROGRAM, type BrokenAnswer, type CodeError, type DownloadState, type MappedStack, type StudioMessage, type TaskEnd } from './api-types.ts';
import { asProblems, brokenAnswer, codeError, entriesOf, freshBroken, isProjectCode, mapStack, orphaned, reloads, settle, unhold, type BrokenState } from './broken.ts';
import { createProbes, evaluatedError, probePage } from './probe.ts';
import { appData } from './app-data.ts';
import { distSizes, freshPreview, startPreview, stopPreview, vitePreview, type PreviewServerLike, type PreviewState } from './build.ts';
import { AGENT_KEY, type AgentHolder } from '../agent/vite.ts';
import { writingNow as agentWriting } from '../agent/conversations.ts';
import { serially, type Git, type Serial } from '../agent/changes.ts';
import { projectTsc } from '../project-tsc.ts';
import { claudeProbe, createChecks, type AccountHeard } from './checks.ts';
import { DOWNLOADS, FFMPEG_BUILDS, downloadTool, idleDownload, toolPlatform } from './ffmpeg.ts';
import { createLogs, teeConsole, teeLogger, type TeeHolder } from './log.ts';
import { fileChanges, listTree, readProjectFile, writeProjectFile, type WritingNow } from './files.ts';
import { copyEntry, deleteEntries, makeEntry, moveEntry, type FileOpsContext } from './file-ops.ts';
import type { AssetsCalls } from '../assets/server.ts';
import { GIT_STREAM, gitBranches, gitCheckout, gitCommit, gitDiff, gitLog, gitPull, gitPush, gitStatus, type GitStream } from './git.ts';
import { freshProblems, merge, problemCount, stopProblems, watchProblems, type ProblemsState } from './problems.ts';
import { rgLook, search, type RgLook } from './search.ts';
import { createTasks, killTask, type TaskState, type Tasks } from './tasks.ts';
import { createBridge, type TsBridge } from './tsserver.ts';
import type { StudioCalls } from './calls.ts';
import { createTsClient, type TsClient } from './ts-client.ts';
import { isBreakpoint } from './debugger/model.ts';
import { isCommand, linkedPackages } from './debugger/session.ts';
import { createServerDebugger, debuggerHtml, type ServerDebugger } from './debugger/server.ts';

/** Where the studio's state is kept across Vite's in-process restarts. */
export const STUDIO_KEY = Symbol.for('vibebase.studio');

/** What `globalThis[STUDIO_KEY]` holds: data and running processes, the code always this bundle's. */
export interface StudioHolder extends TeeHolder {
  tasks: TaskState;
  /** tsc's watch: each program's list and its processes. */
  problems: ProblemsState;
  /** Which server started the watch: an old server's close stops nothing of a newer one's. */
  generation: number;
  /** `vite preview`, one at a time. */
  preview: PreviewState;
  /** Reveal in the Finder (or Explorer): the shell's (phase 5) puts its function here; null in a browser. */
  reveal: ((path: string) => Promise<void>) | null;
  /** Each tool's download, as it last stood. */
  downloads: Record<string, DownloadState>;
  /** The Code card's TypeScript bridge (`tsserver.ts`) and its language server: made at the first `TS_REQ`, kept across a restart. */
  ts?: TsBridge;
  /** Its process's exit stops what it started: hooked once. */
  exitHooked?: boolean;
  /** The dev server's debugger (`debugger/server.ts`): made once, kept across a restart -- attached to a studio tab while there is one. */
  debug?: ServerDebugger;
  /** The newest server's port: the debugger, kept across a restart, matches a studio tab by it. */
  devPort?: () => number | undefined;
  /** The modules Vite cannot serve now, and the reloads held for them (`broken.ts`): kept across a restart. */
  broken?: BrokenState;
}

/**
 * The preview's one start -- `POST preview`'s and `preview_start`'s (`StudioCalls.preview.start`): `vite preview`
 * started (the running one's url when one runs) and its url pushed to the tabs (`studio:preview`).
 */
export function previewStarter(state: PreviewState, make: (port?: number) => Promise<PreviewServerLike>, send: (message: StudioMessage) => void): (port?: number) => Promise<string> {
  return async (port) => {
    const url = await startPreview(state, () => make(port));
    send({ kind: 'studio:preview', url });
    return url;
  };
}

/** The process's holder: made the first time, the same one after a restart. `key`, a test's own. */
export function studioHolder(key: symbol = STUDIO_KEY): StudioHolder {
  const g = globalThis as unknown as Record<symbol, StudioHolder | undefined>;
  return (g[key] ??= { tasks: { running: null, last: null }, problems: freshProblems(), generation: 0, preview: freshPreview(), reveal: null, downloads: {} });
}

/** What the routes answer from. */
export interface StudioParts {
  /** The project's root. */
  root: string;
  holder: StudioHolder;
  tasks: Tasks;
  checks: { get(): Promise<unknown> };
  /** A preview started on `port`, or the config's preview port (`vitePreview`; a test's stand-in). */
  preview?: (port?: number) => Promise<PreviewServerLike>;
  /** The preview's one start (`previewStarter`), shared with the MCP tools' `calls.preview.start`: none, made from `preview`. */
  startPreview?: (port?: number) => Promise<string>;
  /** The download's fetch: a test's stand-in. */
  fetch?: typeof fetch;
  /** The machine's key in `FFMPEG_BUILDS`: a test's. */
  platform?: string;
  /** The studio's pushes. */
  send?: (message: StudioMessage) => void;
  /** The dev server's port: its turns' snapshot refs (`GET file?at=<turn>`). */
  port?: () => number;
  /** The files the conversations' running turns write: a save of one is `423` (none: never locked). */
  writingNow?: WritingNow;
  /** The git of a repository's folder: a test's stand-in (`gitIn`). */
  git?: (dir: string) => Git;
  /** The assets server's work in-process: the Code card's move, copy and delete of an asset go through it (`file-ops.ts`). */
  assets?: () => AssetsCalls | null | undefined;
  /** The TypeScript bridge from node's side: a script's imports updated as the Code card moves it. */
  ts?: () => TsClient | null;
  /** `rg`, looked for once (`rgLook`); none, the search walks. */
  rg?: RgLook;
  /** A push's and a pull's run: a test's stand-in (`git.ts`' `streamGit`). */
  gitStream?: GitStream;
  /** The dev server's debugger: the holder's by default; a test's stand-in. */
  debug?: ServerDebugger;
  /** The Debugger tab's page (`debuggerHtml` over the editor's module as the project's Vite serves it). */
  debuggerPage?: () => Promise<string>;
  /** A runtime error's stack mapped to the TypeScript (`mapStack` over the served modules' maps); none, as it is. */
  mapStack?: (stack: string, origin: string) => Promise<MappedStack>;
  /** The probe page of a probe waiting (`probe.ts`), with the headers a page of this server has; null: none waits. */
  probePage?: (id: string) => { html: string; headers: Record<string, string> } | null;
  /** `POST probe`'s body (an ack, or the probe page's results) from a page at `origin`: false, no such probe waits. */
  probed?: (body: unknown, origin: string) => boolean;
  /** "Reload anyway": the modules held for a throw let go (`unhold`). */
  unhold?: () => BrokenAnswer;
  /** The Git card's one-at-a-time serial: shared with the studio's MCP tools (`calls.ts`), so a tool's commit never meets a card's. */
  gitSerial?: Serial;
}

export interface StudioHandlerOptions {
  /** The port a refusal names. */
  port?: () => number | undefined;
  /** This server's `server.allowedHosts` (`assets/http.ts`' `allowedHosts`): `Host` names trusted beside this machine's. None: none. */
  hosts?: () => readonly string[];
}

/** The folders a path to reveal may be under. */
const REVEALABLE = ['dist', 'src', 'AssetsSource', 'public', 'packs'];

/** The page websockets of this machine, those of them studio pages, and a push to those alone. */
export interface StudioSockets {
  /** A page's websocket: kept when it is this machine's, from this server's own page. */
  connection(socket: TabSocket, req: IncomingMessage): void;
  /** `STUDIO_HELLO` heard on `socket`: a studio page, if it is one of this machine's. True when it is (newly or again). */
  hello(socket: unknown): boolean;
  /** A push to the studio pages alone. */
  send(message: StudioMessage): void;
  /** How many studio pages are connected: none, nothing to probe a reload with. */
  readonly studios: number;
  /** Is this one of them: the TypeScript bridge answers these alone. */
  has(socket: unknown): boolean;
  /** Every one, for a notification to every tab. */
  all(): Iterable<TabSocket>;
  readonly size: number;
}

export function studioSockets(hosts: () => readonly string[] = () => []): StudioSockets {
  const tabs = new Set<TabSocket>();
  const studio = new Set<TabSocket>();
  return {
    connection(socket, req) {
      if (!mayWrite(req, hosts())) return;
      tabs.add(socket);
      socket.on('close', () => {
        tabs.delete(socket);
        studio.delete(socket);
      });
    },
    hello(socket) {
      if (!tabs.has(socket as TabSocket)) return false;
      studio.add(socket as TabSocket);
      return true;
    },
    send(message) {
      if (studio.size === 0) return;
      const text = JSON.stringify({ type: 'custom', event: PUSH_EVENT, data: { type: 'studio', ...message } as PushMessage });
      for (const socket of studio) {
        try {
          socket.send(text);
        } catch {
          studio.delete(socket);
          tabs.delete(socket);
        }
      }
    },
    get studios() {
      return studio.size;
    },
    has: (socket) => tabs.has(socket as TabSocket),
    all: () => tabs,
    get size() {
      return tabs.size;
    },
  };
}

/**
 * A tool downloaded -- `POST download`'s work, and `tools_download`'s (`StudioCalls.download`): its build for this
 * machine (`FFMPEG_BUILDS`) fetched into the app's data folder, its state the holder's, pushed as it goes. Answered as
 * it starts; a refusal said into the state (`failed`, `why`). Refused for no build pinned here, or one under way.
 */
export function startDownload(o: { root: string; holder: StudioHolder; tool: string; platform?: string; fetch?: typeof fetch; send(message: StudioMessage): void }): DownloadState {
  const key = toolPlatform(o.platform?.split('-')[0], o.platform?.split('-')[1]);
  if (!key) throw new Refused(501, `no ${o.tool} build is pinned for ${o.platform ?? `${process.platform}-${process.arch}`}`, { why: 'no build for this machine' });
  const state = (o.holder.downloads[o.tool] ??= idleDownload(o.tool));
  if (state.state === 'downloading' || state.state === 'unpacking') throw new Refused(409, `${o.tool} is downloading`, { why: 'a download is under way' });
  void downloadTool({
    root: o.root,
    tool: o.tool,
    build: FFMPEG_BUILDS[key],
    dir: join(appData(), 'squidwright', 'tools', o.tool),
    state,
    send: (s) => o.send({ kind: 'studio:download', ...s }),
    ...(o.fetch ? { fetch: o.fetch } : {}),
  }).catch((err: unknown) => console.warn(`[studio] the download failed: ${err instanceof Error ? err.message : String(err)}`)); // the state carries `why`; this is the log's copy
  return { ...state };
}

/** A non-negative integer from a query value; `fallback` when it is none. */
function count(value: string | null, fallback: number): number {
  if (value === null || value === '') return fallback;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0) throw new Refused(400, `${value} is no count: a whole number, 0 or more`);
  return n;
}

/** A request under `/__studio/` answered; false for anything else (the next middleware's). A route there is none of is `404`. */
export function studioHandler(parts: StudioParts, options: StudioHandlerOptions = {}): (req: IncomingMessage, res: ServerResponse) => Promise<boolean> {
  const { root, holder, tasks, checks } = parts;
  const send = (message: StudioMessage): void => (parts.send ?? holder.logs?.send ?? (() => {}))(message);
  /** A tool name from a body or a query, one the routes offer. */
  const offered = (tool: unknown): string => {
    if (typeof tool !== 'string' || !(DOWNLOADS as readonly string[]).includes(tool)) throw new Refused(400, `tool is what to download: ${DOWNLOADS.join(', ')}`, { why: `${String(tool)} is not offered` });
    return tool;
  };
  const files = { root, ...(parts.git ? { git: parts.git } : {}) };
  /** The Code card's file operations' context: the files', the running turns', the assets server, TypeScript. */
  const ops = (): FileOpsContext => ({ ...files, ...(parts.writingNow ? { writingNow: parts.writingNow } : {}), ...(parts.assets ? { assets: parts.assets } : {}), ...(parts.ts ? { ts: parts.ts } : {}) });
  const start = parts.startPreview ?? previewStarter(holder.preview, parts.preview ?? ((p) => vitePreview(root, p)), send);
  // The Git card's: its lines to the log's `git` stream (the Console's), its mutating calls one at a time.
  const git = {
    ...files,
    log: (text: string) => holder.logs?.write(GIT_STREAM, text),
    serial: parts.gitSerial ?? serially(),
    ...(parts.gitStream ? { stream: parts.gitStream } : {}),
  };
  /** The debugger: the test's, else the holder's. */
  const debug = (): ServerDebugger => {
    const found = parts.debug ?? holder.debug;
    if (!found) throw new Refused(404, 'no debugger on this server');
    return found;
  };
  /** `work` done, a failure of it a refusal with `status` and its words. */
  const refusedAs = async (status: number, work: () => Promise<void>): Promise<void> => {
    try {
      await work();
    } catch (err) {
      throw new Refused(status, err instanceof Error ? err.message : String(err));
    }
  };
  return async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost');
    if (!url.pathname.startsWith(STUDIO_PREFIX)) return false;
    const route = `${req.method} ${url.pathname.slice(STUDIO_PREFIX.length)}`;
    try {
      if (!isLoopback(req.socket.remoteAddress)) throw new Refused(403, `the studio answers this machine only, at localhost:${options.port?.() ?? 5190}`);
      const allowed = options.hosts?.() ?? [];
      guardHost(req, allowed);
      if (mutating(req)) guardWrite(req, options.port?.(), allowed);
      switch (route) {
        case 'GET log': {
          const stream = url.searchParams.get('stream') ?? 'server';
          const logs = holder.logs;
          sendJson(res, 200, logs ? logs.ring(stream).since(count(url.searchParams.get('since'), 0)) : { seq: 0, lines: [] });
          break;
        }
        case 'GET tasks':
          sendJson(res, 200, tasks.answer());
          break;
        case 'POST run':
          sendJson(res, 200, await tasks.run(await readJson(req)));
          break;
        case 'POST cancel':
          await drain(req);
          if (!tasks.cancel()) throw new Refused(409, 'no task is running');
          sendJson(res, 200, { cancelled: holder.tasks.running?.name ?? null });
          break;
        case 'GET problems':
          sendJson(res, 200, merge(holder.problems.lists));
          break;
        case 'GET checks':
          sendJson(res, 200, await checks.get());
          break;
        case 'GET broken':
          sendJson(res, 200, brokenAnswer(holder.broken ?? freshBroken()));
          break;
        case 'POST stack': {
          const body = await readJson(req);
          if (typeof body.stack !== 'string') throw new Refused(400, 'stack is the error\'s stack, a string');
          // The page's own origin: the frames' urls are the page's.
          const origin = `http://${authority(req) ?? 'localhost'}`;
          sendJson(res, 200, parts.mapStack ? await parts.mapStack(body.stack, origin) : { stack: body.stack, at: null });
          break;
        }
        case 'GET probe': {
          const page = parts.probePage?.(url.searchParams.get('id') ?? '') ?? null;
          if (!page) throw new Refused(404, 'no such probe waits');
          res.writeHead(200, { ...page.headers, 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
          res.end(page.html);
          break;
        }
        case 'POST probe': {
          const body = await readJson(req);
          if (!parts.probed?.(body, `http://${authority(req) ?? 'localhost'}`)) throw new Refused(404, 'no such probe waits');
          sendJson(res, 200, { ok: true });
          break;
        }
        case 'POST unhold':
          await drain(req);
          sendJson(res, 200, parts.unhold ? parts.unhold() : brokenAnswer(holder.broken ?? freshBroken()));
          break;
        case 'GET dist': {
          const dist = await distSizes(root);
          if (!dist) throw new Refused(404, 'no dist/ here: build first');
          sendJson(res, 200, dist);
          break;
        }
        case 'GET preview':
          sendJson(res, 200, { url: holder.preview.url });
          break;
        case 'POST preview': {
          const body = await readJson(req);
          const port = body.port === undefined ? undefined : Number(body.port);
          if (port !== undefined && (!Number.isInteger(port) || port <= 0 || port > 65535)) throw new Refused(400, 'port is a port number');
          let url: string;
          try {
            url = await start(port);
          } catch (err) {
            throw new Refused(409, `the preview did not start: ${(err as Error).message}`, { why: (err as Error).message });
          }
          sendJson(res, 200, { url });
          break;
        }
        case 'POST reveal': {
          const body = await readJson(req);
          if (!holder.reveal) {
            sendJson(res, 501, { why: 'no shell' });
            break;
          }
          const path = await checkPath(root, body.path, REVEALABLE, { folder: true });
          await holder.reveal(join(root, path));
          sendJson(res, 200, { ok: true });
          break;
        }
        case 'GET tree':
          sendJson(res, 200, await listTree(files));
          break;
        case 'GET file':
          sendJson(res, 200, await readProjectFile({ ...files, port: parts.port?.() ?? 5190 }, url.searchParams.get('path'), url.searchParams.get('at')));
          break;
        case 'PUT file':
          // JSON escapes may grow a text up to six times: the text's own limit is checked once parsed.
          sendJson(res, 200, await writeProjectFile({ ...files, ...(parts.writingNow ? { writingNow: parts.writingNow } : {}) }, await readJson(req, 6 * FILE_LIMIT + 4096)));
          break;
        case 'POST files/new':
          sendJson(res, 200, await makeEntry(ops(), await readJson(req)));
          break;
        case 'POST files/move':
          sendJson(res, 200, await moveEntry(ops(), await readJson(req)));
          break;
        case 'POST files/copy':
          sendJson(res, 200, await copyEntry(ops(), await readJson(req)));
          break;
        case 'POST files/delete':
          sendJson(res, 200, await deleteEntries(ops(), await readJson(req)));
          break;
        case 'GET search':
          sendJson(res, 200, await search({ ...files, ...(parts.rg ? { rg: parts.rg } : {}) }, url.searchParams.get('q'), url.searchParams.get('glob')));
          break;
        case 'GET git/status':
          sendJson(res, 200, await gitStatus(git));
          break;
        case 'GET git/log':
          sendJson(res, 200, await gitLog(git, url.searchParams.get('count')));
          break;
        case 'GET git/branches':
          sendJson(res, 200, await gitBranches(git));
          break;
        case 'GET git/diff':
          sendJson(res, 200, await gitDiff(git, url.searchParams.getAll('paths')));
          break;
        case 'POST git/commit':
          sendJson(res, 200, await gitCommit(git, await readJson(req, 1024 * 1024)));
          break;
        case 'POST git/checkout':
          sendJson(res, 200, await gitCheckout(git, await readJson(req)));
          break;
        case 'POST git/push':
          sendJson(res, 200, await gitPush(git, await readJson(req)));
          break;
        case 'POST git/pull':
          sendJson(res, 200, await gitPull(git, await readJson(req)));
          break;
        case 'GET debug/state':
          sendJson(res, 200, debug().state());
          break;
        case 'GET debug/breakpoints':
          sendJson(res, 200, debug().breakpoints());
          break;
        case 'POST debug/breakpoints': {
          const body = await readJson(req);
          const at = { file: body.file, line: body.line };
          if (!isBreakpoint(at)) throw new Refused(400, `${String(body.file)}:${String(body.line)} is no place for a breakpoint: a project's path and a line from 1`);
          sendJson(res, 200, await debug().toggle(at));
          break;
        }
        case 'POST debug/open':
          await readJson(req);
          await refusedAs(409, () => debug().open());
          sendJson(res, 200, { ok: true });
          break;
        case 'GET debug/view':
          sendJson(res, 200, debug().view());
          break;
        case 'POST debug/command': {
          const body = await readJson(req);
          if (!isCommand(body.command)) throw new Refused(400, `no such command: ${String(body.command)}`);
          await refusedAs(409, () => debug().command(body.command, body.arg));
          sendJson(res, 200, { ok: true });
          break;
        }
        case 'GET debugger': {
          if (!parts.debuggerPage) throw new Refused(404, 'no Debugger page here');
          const html = await parts.debuggerPage();
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
          res.end(html);
          break;
        }
        case 'GET download': {
          const tool = offered(url.searchParams.get('tool'));
          sendJson(res, 200, holder.downloads[tool] ?? idleDownload(tool));
          break;
        }
        case 'POST download': {
          const tool = offered((await readJson(req)).tool);
          // Answered as it starts: the pushes and GET download carry the rest, a refusal into the state (`failed`, `why`).
          sendJson(res, 200, startDownload({ root, holder, tool, ...(parts.platform !== undefined ? { platform: parts.platform } : {}), ...(parts.fetch ? { fetch: parts.fetch } : {}), send }));
          break;
        }
        default:
          throw new Refused(404, `no route ${route} under ${STUDIO_PREFIX}`);
      }
    } catch (err) {
      if (res.headersSent || res.destroyed) {
        res.destroy();
      } else if (err instanceof Refused) {
        await drain(req);
        sendJson(res, err.status, err.body);
      } else {
        console.error(`[studio] ${route}:`, err);
        sendJson(res, 500, { refused: (err as Error).message });
      }
    }
    return true;
  };
}

export interface StudioOptions {
  /** The project's own tasks (`vibe({ tasks })`). */
  tasks?: readonly string[];
  /** The `globalThis` key: a test's own. */
  key?: symbol;
  /** The agent's `globalThis` key (`AGENT_KEY`): a test's own, whose turn runs or not. */
  agentKey?: symbol;
  /** The probe (`probe.ts`) as the hook asks it: a test's stand-in for the studio tab's probe page. */
  probe?: (files: readonly string[]) => Promise<Map<string, CodeError | null> | null>;
}

/** The editor's Debugger page module, served to the Debugger tab by the project's Vite. */
const DEBUGGER_MODULE = '@vibe/editor/debugger';

/** The project's folder as the debugger names it: real, so a `/@fs/` url under it is the project's. */
function realRoot(root: string): string {
  try {
    return realpathSync(root);
  } catch {
    return root;
  }
}

/** The project's `index.html`; none readable, the template's entry alone. */
function pageHtml(root: string): string {
  try {
    return readFileSync(join(root, 'index.html'), 'utf8');
  } catch {
    return '<body><script type="module" src="/src/main.ts"></script></body>';
  }
}

/** The page's entry modules, from the project's `index.html` (`entriesOf`). */
const pageEntries = (root: string): Set<string> => entriesOf(pageHtml(root));

/** How long a studio tab has to ack a probe (`probe.ts`), and to answer it: past these, nobody probed and the reload goes. */
const PROBE_ACK_MS = 1500;
const PROBE_DONE_MS = 15_000;

/** The project's name: its `package.json`'s, else its folder's. */
function projectName(root: string): string {
  try {
    const name = (JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')) as { name?: unknown }).name;
    if (typeof name === 'string' && name !== '') return name;
  } catch {
    // No package.json: the folder's name.
  }
  return basename(root);
}

/** The account as the agent's sessions last heard it (`initializationResult`, in each session's state); null before one has come up. */
function accountHeard(): AccountHeard | null {
  const agent = (globalThis as unknown as Record<symbol, AgentHolder | undefined>)[AGENT_KEY];
  for (const conversation of agent?.open ?? []) {
    const account = conversation.session.state().account;
    if (account) return { loggedIn: account.loggedIn, email: account.email };
  }
  return null;
}

/** The plugin: the routes on the dev server, the log tee'd, tsc watched, the pushes to this machine's tabs, a broken module's reload held. */
export function studio(options: StudioOptions = {}): Plugin {
  /** The project's root, as configured. */
  let root = '';
  /** The broken modules said again: the Problems card's rows and `studio:broken` (set as the server is configured). */
  let tellBroken = (): void => {};
  /**
   * Each file evaluated in the probe page (`probe.ts`), what it threw as a `CodeError` or null; null for the whole when
   * nobody probed (no studio tab, too late). Set as the server is configured.
   */
  let probe: ((files: readonly string[]) => Promise<Map<string, CodeError | null> | null>) | null = options.probe ?? null;
  /** One change at a time, through to its settle: a probe in flight (up to `PROBE_DONE_MS`) never settles after a later save's. */
  const oneAtATime = serially();
  /** A path from the watcher, relative to the root with `/`. */
  const rel = (file: string): string => {
    const r = relative(root, file);
    return r === '' || r.startsWith('..') ? file.split(sep).join('/') : r.split(sep).join('/');
  };
  return {
    name: 'studio',
    apply: 'serve',
    configResolved(config) {
      root = config.root;
    },
    /**
     * A change of the project's own code (Docs/studio.md §1, "Mid-session"): the changed module transformed now, and
     * every module broken before it (`broken.ts`); a reload while any is broken held, the held one sent once none is.
     * After the agent's hold (`order: 'post'`, mounted after it): a change it holds for a turn comes here as no
     * modules, and again as its replay at the turn's end. The page's alone: the `ssr` environment's set is Vite's.
     * One change at a time (`oneAtATime`): two quick saves -- a throw, then its fix -- each checked, probed and settled
     * in turn, each over the state the one before left, so a slow probe's stale throw never holds after the fix.
     */
    hotUpdate: {
      order: 'post',
      async handler({ file, modules, type }) {
        if (this.environment.name !== 'client') return;
        const changed = rel(file);
        if (!isProjectCode(changed)) return;
        const env = this.environment;
        return oneAtATime(async () => {
          const holder = studioHolder(options.key);
          const state = (holder.broken ??= freshBroken());
          /** A module served now, or its transform's error. Errors are not cached by Vite: a broken one is tried again. */
          const check = async (url: string, of: string): Promise<CodeError | null> => {
            try {
              await env.transformRequest(url);
              return null;
            } catch (err) {
              return codeError(err, root, of);
            }
          };
          const checked: { file: string; error: CodeError | null }[] = [];
          const own = type === 'delete' ? [] : modules.filter((m): m is EnvironmentModuleNode & { file: string } => m.file !== null && isProjectCode(rel(m.file)));
          let entries: Set<string> | undefined;
          /** The files let go this change: never held again for a throw kept from before, never probed. */
          const dropped = new Set<string>();
          /** Nothing imports it now (its importer dropped it): not the page's, let go -- else it would hold every later reload forever. */
          const letGo = (file: string): boolean => {
            entries ??= pageEntries(root);
            // The graph's files are Vite's, with `/` on Windows too: never a `\` of node's `join`.
            if (!orphaned(file, env.moduleGraph.getModulesByFile(posix.join(root, file)), entries)) return false;
            if (state.errors.has(file)) env.logger.info(`[studio] ${file} is broken, but nothing imports it now: let go`);
            dropped.add(file);
            return true;
          };
          for (const m of own) checked.push({ file: rel(m.file), error: letGo(rel(m.file)) ? null : await check(m.url, rel(m.file)) });
          for (const before of [...state.errors.keys()]) {
            if (checked.some((c) => c.file === before) || (type === 'delete' && before === changed)) continue;
            checked.push({ file: before, error: letGo(before) ? null : await check(`/${before}`, before) });
          }
          // A Claude turn running (any conversation's): a reload owed now waits for its end, as the agent's hold makes it.
          const agentHolder = (globalThis as unknown as Record<symbol, AgentHolder | undefined>)[options.agentKey ?? AGENT_KEY];
          const turnRuns = (): boolean => (agentHolder?.open ?? []).some((c) => c.session.running());
          let turn = turnRuns();
          const reloading = reloads(modules);
          // A module that threw as it was evaluated transforms: still broken until a probe says otherwise -- but one let go.
          for (const c of checked) if (c.error === null && !dropped.has(c.file) && state.errors.get(c.file)?.evaluated) c.error = state.errors.get(c.file)!;
          // Everything transforms: does it evaluate? (`probe.ts`) -- each module held for a throw, and the changed ones of a
          // change that would reload the page now. A transform still broken holds the reload whatever they do.
          if (probe && checked.every((c) => c.error === null || c.error.evaluated)) {
            const asked = new Set(checked.filter((c) => c.error?.evaluated).map((c) => c.file));
            if (reloading && !turn) for (const c of checked) if (!dropped.has(c.file) && own.some((m) => rel(m.file) === c.file)) asked.add(c.file);
            if (asked.size > 0) {
              const found = await probe([...asked]);
              // Nobody probed (no studio tab): as Vite would, nothing held for a throw.
              for (const c of checked) if (asked.has(c.file)) c.error = found?.get(c.file) ?? null;
              const thrown = [...(found?.values() ?? [])].find((e) => e !== null);
              if (thrown) env.logger.warn(`[studio] ${thrown.file}:${thrown.line} threw as it was evaluated: ${thrown.message} -- the page stays as it was`);
              // A turn begun while the probe ran: the reload owed waits for its end.
              turn = turnRuns();
            }
          }
          const done = settle(state, { file: changed, checked, reloads: reloading, removed: type === 'delete', turn });
          if (done.changed) tellBroken();
          if (done.afterTurn) {
            // The turn's end replays the files the agent held, and the replay comes back here with no turn running: this
            // one among them (the agent held it already, unless it was applied in place), so the held reload goes then.
            const list = (agentHolder!.held ??= []);
            if (!list.includes(changed)) list.push(changed);
            env.logger.info(`[studio] nothing is broken now: the page reload held for it goes at the Claude turn's end`);
            return;
          }
          if (done.reloadNow) {
            env.logger.info(`[studio] nothing is broken now: the page reload held for it goes`);
            env.hot.send({ type: 'full-reload', path: '*' });
            return [];
          }
          if (done.pass) return;
          // Held: the plain page's overlay says why (Vite's own `error`); studio mode's editor says it as a notice.
          const first = state.errors.values().next().value as CodeError;
          env.logger.warn(`[studio] ${changed} changed: its page reload waits while ${first.file}:${first.line}:${first.col} is broken -- ${first.message}`);
          env.hot.send({ type: 'error', err: { message: `${first.file}:${first.line}:${first.col}: ${first.message}\n\nThe page reloads once nothing is broken (${[...state.held].join(', ')} changed meanwhile).`, stack: '', id: first.file, loc: { file: first.file, line: first.line, column: Math.max(0, first.col - 1) } } });
          return [];
        });
      },
    },
    configureServer(server) {
      const root = server.config.root;
      /** This server's own `server.allowedHosts`, as every route's `Host` check reads it. */
      const hosts = (): readonly string[] => allowedHosts(server.config.server?.allowedHosts);
      const holder = studioHolder(options.key);
      const logs = (holder.logs ??= createLogs());
      // The Problems card's count for the studio's MCP tools (`studio_state`), handed to the agent's holder: typed, and
      // this bundle's -- whichever plugin starts first.
      ((globalThis as unknown as Record<symbol, AgentHolder | undefined>)[options.agentKey ?? AGENT_KEY] ??= {}).problems = () => problemCount(holder.problems.lists);
      // Each new server's tabs: a page reconnects to the new socket server after a restart.
      const sockets = studioSockets(hosts);
      // The dev server's debugger: made once, kept across a restart; its pushes go out on the newest server's sockets.
      const port = (): number | undefined => {
        const address = server.httpServer?.address();
        return typeof address === 'object' && address !== null ? address.port : server.config.server.port;
      };
      holder.devPort = port;
      const debug = (holder.debug ??= createServerDebugger({
        root,
        name: projectName(root),
        port: () => holder.devPort?.(),
        send: (message) => holder.logs?.send(message),
        source: async (path) => (await readProjectFile({ root, port: holder.devPort?.() ?? 5190 }, path)).text,
      }));
      server.ws.on('connection', (socket, req) => {
        sockets.connection(socket, req);
        socket.on('close', () => holder.ts?.closed(socket));
      });
      // A studio page says so as it connects (the editor's hub, the Debugger tab; again on its reload): a studio tab looked for, quietly.
      server.ws.on(STUDIO_HELLO, (_data: unknown, client) => {
        if (sockets.hello(client.socket)) void debug.poke();
      });
      // The Code card's bridge: made once, kept across a restart; each new server's sockets are the pages it tells.
      server.ws.on(TS_REQ, (data: unknown, client) => {
        const bridge = (holder.ts ??= createBridge({ root }));
        bridge.setPages(() => sockets.all());
        bridge.request(client.socket, data, sockets.has(client.socket));
      });
      holder.ts?.setPages(() => sockets.all());
      logs.send = (message: StudioMessage) => sockets.send(message);
      // The broken modules said: the Problems card's rows beside tsc's, and the editor's notices.
      tellBroken = () => {
        const state = (holder.broken ??= freshBroken());
        holder.problems.lists[VITE_PROGRAM] = asProblems(state.errors.values());
        holder.problems.at = Date.now();
        logs.send({ kind: 'studio:problems', problems: merge(holder.problems.lists), at: holder.problems.at });
        logs.send({ kind: 'studio:broken', ...brokenAnswer(state) });
      };
      // The probe (`probe.ts`): the files of each probe waiting, for its page; the throws mapped to the TypeScript.
      const probing = new Map<string, readonly string[]>();
      const probes = createProbes({
        tell: (id, files) => {
          probing.set(id, files);
          logs.send({ kind: 'studio:probe', id, url: `${STUDIO_PREFIX}probe?id=${encodeURIComponent(id)}` });
        },
        ackMs: PROBE_ACK_MS,
        doneMs: PROBE_DONE_MS,
        later: (run, ms) => setTimeout(run, ms),
        cancel: (timer) => clearTimeout(timer as ReturnType<typeof setTimeout>),
        id: () => randomUUID(),
        ended: (id) => probing.delete(id),
      });
      const mapThrown = (stack: string, origin: string): Promise<MappedStack> => mapStack(stack, { origin, dir: realRoot(root), links: linkedPackages(root) }, async (url) => {
        const mod = await server.environments.client.moduleGraph.getModuleByUrl(decodeURIComponent(new URL(url).pathname));
        const map = mod?.transformResult?.map;
        return map && 'version' in map ? new TraceMap(map as unknown as ConstructorParameters<typeof TraceMap>[0]) : null;
      });
      probe = options.probe ?? (async (files) => {
        // No studio page (the plain page alone, the probe frame's own client): nobody would ack -- the reload goes at once.
        if (sockets.studios === 0) return null;
        const answer = await probes.ask(files);
        if (!answer) return null;
        const found = new Map<string, CodeError | null>();
        for (const r of answer.results) found.set(r.file, r.threw ? evaluatedError(r.file, r.threw, await mapThrown(r.threw.stack, answer.origin).catch(() => ({ stack: r.threw!.stack, at: null }))) : null);
        return found;
      });
      teeConsole(holder);
      teeLogger(holder, server.config.logger);
      if (!holder.exitHooked) {
        holder.exitHooked = true;
        process.once('exit', () => {
          killTask(holder.tasks);
          stopProblems(holder.problems);
          holder.ts?.stop();
          // A preview's server is this process's own sockets: they go with it.
        });
        // No `exit` on a death by signal: heard first, what was started stopped, then the default death if nobody else ends it.
        for (const signal of ['SIGINT', 'SIGTERM'] as const) {
          process.prependOnceListener(signal, () => {
            killTask(holder.tasks);
            stopProblems(holder.problems);
            holder.ts?.stop();
            if (process.listenerCount(signal) === 0) process.kill(process.pid, signal);
          });
        }
      }
      const isBuild = (name: string): boolean => name === 'build' || name === 'build:debug';
      /** Who follows a task's end: the studio's MCP tools (`tests_run`, `build_run`). */
      const taskEnds = new Set<(end: TaskEnd) => void>();
      const tasks = createTasks({
        root,
        extra: options.tasks ?? [],
        logs,
        state: holder.tasks,
        // A build is about to replace dist/: the preview of the old one goes.
        onStart: (name) => {
          if (isBuild(name)) void stopPreview(holder.preview).then((was) => was && logs.send({ kind: 'studio:preview', url: null }));
        },
        // A build that ended 0: its sizes, measured once and pushed.
        onEnd: (end) => {
          for (const listener of [...taskEnds]) listener(end);
          if (!isBuild(end.name) || end.code !== 0) return;
          void distSizes(root).then(
            (dist) => dist && logs.send({ kind: 'studio:dist', dist }),
            (err: Error) => console.warn(`[studio] dist/ not measured: ${err.message}`),
          );
        },
      });
      const checks = createChecks({ root, claude: claudeProbe(accountHeard) });
      const gitSerial = serially();
      const rg = rgLook(root);
      // The routes' work in-process, for the studio's MCP tools (Docs/mcp.md M5): the same parts as the handler's.
      let tsClient: { bridge: TsBridge; client: TsClient } | null = null;
      // The preview's one start, the route's and the tools' (`previewStarter`).
      const startOnce = previewStarter(holder.preview, (port) => vitePreview(root, port), (m) => logs.send(m));
      const calls: StudioCalls = {
        root,
        problems: () => ({ problems: merge(holder.problems.lists), at: holder.problems.at }),
        log: (stream, since) => logs.ring(stream).since(since),
        streams: () => logs.streams(),
        tasks,
        task: () => holder.tasks,
        ended(listener) {
          taskEnds.add(listener);
          return () => void taskEnds.delete(listener);
        },
        preview: {
          url: () => holder.preview.url,
          start: startOnce,
          async stop() {
            const was = await stopPreview(holder.preview);
            if (was) logs.send({ kind: 'studio:preview', url: null });
            return was;
          },
        },
        git: { root, log: (text) => holder.logs?.write(GIT_STREAM, text), serial: gitSerial },
        search: (q, glob) => search({ root, rg }, q, glob),
        download: {
          tools: DOWNLOADS,
          start: (tool) => startDownload({ root, holder, tool, send: (m) => logs.send(m) }),
          state: (tool) => ({ ...(holder.downloads[tool] ?? idleDownload(tool)) }),
        },
        ts() {
          const bridge = (holder.ts ??= createBridge({ root }));
          bridge.setPages(() => sockets.all());
          if (tsClient?.bridge !== bridge) tsClient = { bridge, client: createTsClient(bridge, root) };
          return tsClient.client;
        },
      };
      ((globalThis as unknown as Record<symbol, AgentHolder | undefined>)[options.agentKey ?? AGENT_KEY] ??= {}).studio = () => calls;
      const handle = studioHandler(
        {
          root,
          holder,
          tasks,
          checks,
          gitSerial,
          startPreview: startOnce,
          port: () => server.config.server.port ?? 5190,
          writingNow: () => agentWriting((globalThis as unknown as Record<symbol, AgentHolder | undefined>)[AGENT_KEY]),
          // The assets plugin's work, handed to the agent's holder as it starts; the bridge as the tools speak to it.
          assets: () => (globalThis as unknown as Record<symbol, AgentHolder | undefined>)[options.agentKey ?? AGENT_KEY]?.assets?.() ?? null,
          ts: () => calls.ts(),
          rg,
          // A frame's map is its module's last transform's, as the dev server served it.
          mapStack: mapThrown,
          probePage: (id) => {
            const files = probing.get(id);
            if (!files) return null;
            const headers: Record<string, string> = {};
            // A page of this server's (`dev:isolated`'s COEP and COOP): a frame of a cross-origin isolated page must have them.
            for (const [name, value] of Object.entries(server.config.server.headers ?? {})) if (value !== undefined) headers[name] = String(value);
            return { html: probePage(pageHtml(root), server.config.base, STUDIO_PREFIX, id, files), headers };
          },
          probed: (body, origin) => probes.heard(body, origin),
          unhold: () => {
            const state = (holder.broken ??= freshBroken());
            const now = unhold(state);
            tellBroken();
            if (now) {
              server.config.logger.info('[studio] the modules that threw let go ("Reload anyway"): the page reload held for them goes');
              server.environments.client.hot.send({ type: 'full-reload', path: '*' });
            }
            return brokenAnswer(state);
          },
          debuggerPage: async () => {
            const resolved = await server.pluginContainer.resolveId(DEBUGGER_MODULE, join(root, 'index.html'));
            if (!resolved) throw new Refused(404, `${DEBUGGER_MODULE} is not installed here`);
            const id = resolved.id.split('?')[0]!.replace(/\\/g, '/');
            return debuggerHtml(`/@fs${id.startsWith('/') ? '' : '/'}${id}`, PUSH_EVENT);
          },
        },
        { port: () => server.config.server.port, hosts },
      );
      // A file under the root changed, made or gone (never node_modules, .git, ...): pushed once per 50 ms a path.
      const changes = fileChanges({ root, changed: (path, mtime) => logs.send({ kind: 'studio:file-changed', path, mtime, change: mtime === null ? 'removed' : 'changed' }) });
      for (const event of ['change', 'add', 'unlink'] as const) server.watcher.on(event, (file: string) => changes.saw(file));
      // tsc's watch once the server listens, the old server's stopped first (`watchProblems`); stopped as this one closes.
      const generation = ++holder.generation;
      server.httpServer?.once('listening', () => {
        let tsc: string;
        try {
          tsc = projectTsc(root);
        } catch (err) {
          console.warn(`[studio] no tsc to watch for problems: ${(err as Error).message}`);
          return;
        }
        watchProblems({ root, tsc, state: holder.problems, changed: (problems, at) => logs.send({ kind: 'studio:problems', problems, at }) });
      });
      server.httpServer?.once('close', () => {
        changes.stop();
        if (holder.generation !== generation) return;
        stopProblems(holder.problems);
        holder.ts?.stop();
        void stopPreview(holder.preview);
      });
      // Added here, not from a returned hook: after Vite's CORS and host checks, before its transforms. Vite 8 adds its
      // host check (`hostValidationMiddleware`) before any `configureServer` runs, but only while `server.allowedHosts`
      // is not `true` and the server is not HTTPS: every route checks `Host` itself as well (`assets/http.ts`' `guardHost`).
      server.middlewares.use((req, res, next) => {
        handle(req, res).then((handled) => {
          if (!handled) next();
        }, next);
      });
    },
  };
}
