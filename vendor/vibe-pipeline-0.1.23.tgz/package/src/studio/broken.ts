/**
 * Studio mode mid-session (Docs/studio.md §1, "Mid-session"): what the dev server does with a project module that
 * breaks while the page is up -- the pure part, which `vite.ts`' plugin runs from its `hotUpdate` and its routes.
 *
 * - **Broken is what Vite cannot serve**: each changed module of the project's own code is transformed as it changes
 *   (`this.environment.transformRequest`), and so is every module broken before it -- a syntax error, an import of a
 *   file that is not there. Its error, in words (`codeError`), is kept by file until a transform of it passes or the
 *   file goes (`settle`), or nothing imports it any more (`orphaned`: let go, the page never loads it).
 * - **A module that transforms but throws as it is evaluated**: a game module's swap says it (the engine's `liveGame`,
 *   `onFailed`); any other's reload is asked first of the probe page (`probe.ts`), and a throw there is kept and held
 *   like a syntax error (`evaluated`) until a later probe evaluates clean, or "Reload anyway" (`unhold`). A type
 *   error transforms and evaluates fine: tsc's, the Problems card's, and the game runs on.
 * - **A reload waits while anything is broken**: a change Vite would answer with a page reload (`reloads`: Vite's own
 *   walk up the importers, `hmr-walk.ts` -- a dead end on some path, no boundary of its own, an importer's accept or
 *   the game's `live.ts` taking it) is held, its file kept, while any module is broken -- the page would reload
 *   into a module it cannot load, a blank page and Vite's overlay, the editor gone. Once none is, the held reload
 *   goes (`reloadNow`), taking the change that mended it along. A change applied in place passes as ever: the game's
 *   swap fails on a broken module and keeps the last good code (Docs/ecs.md §22), and swaps on the next good save.
 *   Mended while a Claude turn runs, the held reload waits for the turn's end (`afterTurn`), as every reload of a
 *   turn does.
 * - **Said as problems**: the broken modules are the Problems card's rows beside tsc's (`asProblems`, the program
 *   `VITE_PROGRAM`), and the editor's notices (`studio:broken`).
 * - **A runtime error's stack, mapped** (`mapStack`): each frame of a module the dev server served at its place in
 *   the TypeScript, through that module's source map (the debugger's `fileOfScript` and `originalFor`), and the first
 *   frame under `src/` named -- what the editor's notice opens in the Code card.
 *
 * No Vite, no `node:` import: `broken.test.ts` runs it.
 */
import type { TraceMap } from '@jridgewell/trace-mapping';
import { VITE_PROGRAM, type BrokenAnswer, type CodeError, type MappedStack, type Problem } from './api-types.ts';
import { fileOfScript, originalFor, type ProjectPlace } from './debugger/model.ts';
import { hmrWalk, type HmrNode } from '../hmr-walk.ts';

/** Is a project file (relative, posix) code Vite transforms and the hold watches: under `src/`, a script, never a dependency's. */
export function isProjectCode(file: string): boolean {
  return file.startsWith('src/') && !file.split('/').includes('node_modules') && /\.[cm]?[jt]sx?$/.test(file);
}

/** What `codeError` reads of Vite's error: a transform's (oxc's parse error) or the import analysis' (an import of no file). */
interface ViteLikeError {
  message?: unknown;
  id?: unknown;
  loc?: { file?: unknown; line?: unknown; column?: unknown };
}

/** `path` relative to `root` (both posix, `root` without a trailing `/`), its query off; a path outside it as it is. */
function relativeTo(root: string, path: string): string {
  const bare = path.split('?')[0]!.replace(/\\/g, '/');
  return bare.startsWith(`${root}/`) ? bare.slice(root.length + 1) : bare.replace(/^\//, '');
}

/**
 * Vite's error for `file` (relative) as a `CodeError`: where -- its `loc` (a 0-based column, made 1-based), else the
 * `file:line:col` its message names (oxc's code frame, 1-based), else the file alone -- and the message's first line
 * that says something (not "Transform failed with 1 error:"), a leading `[PARSE_ERROR]` and the terminal's colours off.
 */
export function codeError(err: unknown, root: string, file: string): CodeError {
  const e = (typeof err === 'object' && err !== null ? err : { message: String(err) }) as ViteLikeError;
  // Without the terminal's colours: oxc paints its code red.
  const message = (typeof e.message === 'string' ? e.message : String(err)).replace(/\u001b\[[0-9;]*m/g, '');
  const lines = message.split('\n').map((l) => l.trim()).filter((l) => l !== '');
  const headline = (lines.find((l) => !/^Transform failed with \d+ errors?:?$/i.test(l)) ?? lines[0] ?? 'failed to transform').replace(/^\[[A-Z_]+\]\s*/, '');
  const root_ = root.replace(/\\/g, '/').replace(/\/$/, '');
  const loc = e.loc;
  if (loc && typeof loc.line === 'number') {
    const where = typeof loc.file === 'string' ? relativeTo(root_, loc.file) : file;
    return { file: where, line: loc.line, col: typeof loc.column === 'number' ? loc.column + 1 : 0, message: headline };
  }
  const named = /([\w./@-]+\.[cm]?[jt]sx?):(\d+):(\d+)/.exec(message);
  if (named) return { file: relativeTo(root_, named[1]!), line: Number(named[2]), col: Number(named[3]), message: headline };
  return { file, line: 0, col: 0, message: headline };
}

/** The page's entry modules (relative): each `<script type="module" src="/…">` of `index.html` -- `src/main.ts`. */
export function entriesOf(html: string): Set<string> {
  const out = new Set<string>();
  for (const tag of html.matchAll(/<script\b[^>]*>/gi)) {
    if (!/\btype\s*=\s*["']module["']/i.test(tag[0])) continue;
    const src = /\bsrc\s*=\s*["']([^"']+)["']/i.exec(tag[0])?.[1];
    if (src && !/^[a-z]+:\/\//i.test(src)) out.add(src.replace(/^\.?\//, '').split('?')[0]!);
  }
  return out;
}

/**
 * Is a broken file let go -- nothing imports it any more? Its file has no module in the graph (`getModulesByFile`), or
 * none of them has an importer, and it is no entry of the page. Then the page never loads it: kept as broken it would
 * hold every later reload behind it, forever (and recovery's reload, `held()`).
 */
export function orphaned(file: string, modules: Iterable<{ importers: { size: number } }> | undefined, entries: ReadonlySet<string>): boolean {
  if (entries.has(file)) return false;
  for (const m of modules ?? []) if (m.importers.size > 0) return false;
  return true;
}

/** The broken modules as the Problems card's rows, by file then line. */
export function asProblems(errors: Iterable<CodeError>): Problem[] {
  return [...errors].map((e) => ({ file: e.file, line: e.line, col: e.col, code: 'vite', message: e.message, program: VITE_PROGRAM })).sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : a.line - b.line));
}

/** What is broken, by the file whose transform failed, and the files whose reload is held. */
export interface BrokenState {
  errors: Map<string, CodeError>;
  held: Set<string>;
}

export const freshBroken = (): BrokenState => ({ errors: new Map(), held: new Set() });

/** The state as the routes and the push say it. */
export function brokenAnswer(state: BrokenState): BrokenAnswer {
  return { errors: [...state.errors.values()], held: [...state.held] };
}

/** One change as the plugin saw it. */
export interface Change {
  /** The changed file, relative. */
  file: string;
  /** Each module transformed now -- the changed one's and every one broken before -- with its error, or null: it serves. */
  checked: readonly { file: string; error: CodeError | null }[];
  /** Would Vite answer it with a page reload (`reloads`)? */
  reloads: boolean;
  /** The file went. */
  removed?: boolean;
  /** A Claude turn runs: a reload owed now waits for its end, as the agent's hold makes every reload wait. */
  turn?: boolean;
}

/** What the plugin does with the change. */
export interface Settled {
  /** Let Vite handle it as ever (else the hook answers `[]`: nothing sent for it). */
  pass: boolean;
  /** Send the held reload now: nothing is broken any more. */
  reloadNow: boolean;
  /** The broken list or the held list changed: told again (`studio:broken`, the problems). */
  changed: boolean;
  /**
   * Nothing is broken now, but a turn runs: the held reload stays held, sent by the turn's end -- its replay of the
   * files it held comes back through the hook with no turn running (`reloadNow` then). Present only when so.
   */
  afterTurn?: true;
}

const same = (a: CodeError | undefined, b: CodeError): boolean => !!a && a.file === b.file && a.line === b.line && a.col === b.col && a.message === b.message;

/** The change taken into `state`, and what to do with it. */
export function settle(state: BrokenState, change: Change): Settled {
  let changed = false;
  for (const { file, error } of change.checked) {
    if (error === null) changed = state.errors.delete(file) || changed;
    else if (!same(state.errors.get(file), error)) {
      state.errors.set(file, error);
      changed = true;
    }
  }
  if (change.removed) {
    changed = state.errors.delete(change.file) || changed;
    changed = state.held.delete(change.file) || changed;
  }
  if (state.errors.size > 0) {
    if (!change.reloads) return { pass: true, reloadNow: false, changed };
    if (!state.held.has(change.file)) {
      state.held.add(change.file);
      changed = true;
    }
    return { pass: false, reloadNow: false, changed };
  }
  if (state.held.size > 0) {
    // Mended in the middle of a turn (its first write, say): never a reload under it -- the agent's hold exists for that.
    if (change.turn) return { pass: true, reloadNow: false, changed, afterTurn: true };
    state.held.clear();
    return { pass: false, reloadNow: true, changed: true };
  }
  return { pass: true, reloadNow: false, changed };
}

/**
 * "Reload anyway" (`POST unhold`): the modules held for having thrown as the probe evaluated them let go -- the person
 * knows better (a module that throws in the probe page alone) -- and true if the held reload goes now: nothing else
 * is broken. A syntax error still holds it: that page would not load.
 */
export function unhold(state: BrokenState): boolean {
  for (const [file, e] of state.errors) if (e.evaluated) state.errors.delete(file);
  if (state.errors.size > 0 || state.held.size === 0) return false;
  state.held.clear();
  return true;
}

/**
 * Would Vite answer a change of these modules with a page reload? Its own walk over the module graph (`hmr-walk.ts`,
 * shared with the agent's hold): a dead end on any importer path. A game module the HUD imports by value reloads; a
 * module only the game imports reaches the game's boundary (`live.ts`) and swaps, whatever its folder. No modules (a
 * file nothing imports): no.
 */
export const reloads = (modules: readonly HmrNode[]): boolean => hmrWalk(modules).reload;

/** One frame's place in a stack: `http://host/src/x.ts?t=1:12:5`, as Chrome, Safari and Firefox write it. */
const FRAME_PLACE = /(https?:\/\/[^\s()]+?):(\d+):(\d+)/g;

/**
 * `stack` with each frame of a module the dev server served at its TypeScript place (`src/game/systems/spin.ts:21:5`),
 * through `mapOf` (that url's source map, or null: the place as it is, the file still named); a frame of no project
 * file (Vite's client, a dependency's bundle) left as it is. `at`: the first frame under `src/`.
 */
export async function mapStack(stack: string, place: ProjectPlace, mapOf: (url: string) => Promise<TraceMap | null>): Promise<MappedStack> {
  const found: { whole: string; url: string; line: number; col: number }[] = [];
  for (const m of stack.matchAll(FRAME_PLACE)) found.push({ whole: m[0], url: m[1]!, line: Number(m[2]), col: Number(m[3]) });
  const mapped = new Map<string, string>();
  let at: MappedStack['at'] = null;
  for (const f of found) {
    if (mapped.has(f.whole)) continue;
    const file = fileOfScript(f.url, place);
    if (file === null) continue;
    const map = await mapOf(f.url).catch(() => null);
    const { line, col } = originalFor(map, f.line - 1, f.col - 1);
    mapped.set(f.whole, `${file}:${line}:${col}`);
    if (at === null && file.startsWith('src/')) at = { file, line, col };
  }
  return { stack: stack.replace(FRAME_PLACE, (whole) => mapped.get(whole) ?? whole), at };
}
