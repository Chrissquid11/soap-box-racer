/**
 * Where the studio keeps what is this machine's and no project's -- a downloaded ffmpeg
 * (`ffmpeg.ts`), later the launcher's list of projects: the platform's folder for an app's data,
 * `squidwright/` inside it (the caller adds that). `VIBE_APP_DATA` overrides it, for the tests and a
 * check that must not touch the real one. Nothing at module level.
 */
import { homedir } from 'node:os';
import { posix, win32 } from 'node:path';

/** `~/Library/Application Support` on a Mac, `%APPDATA%` on Windows, `$XDG_CONFIG_HOME` else `~/.config` elsewhere; `VIBE_APP_DATA` over all. */
export function appData(env: Readonly<Record<string, string | undefined>> = process.env, platform: NodeJS.Platform = process.platform, home: string = homedir()): string {
  if (env.VIBE_APP_DATA) return env.VIBE_APP_DATA;
  // The platform's own separator, whatever this machine's (the platform is a test's to give).
  if (platform === 'darwin') return posix.join(home, 'Library', 'Application Support');
  if (platform === 'win32') return env.APPDATA ?? win32.join(home, 'AppData', 'Roaming');
  return env.XDG_CONFIG_HOME || posix.join(home, '.config');
}
