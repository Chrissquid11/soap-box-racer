/**
 * The studio's log (Docs/studio.md): what the terminal showed, kept for the
 * Console card.
 *
 * - **A ring per stream** (`Ring`): the last 2000 lines, each `{ seq, at, text }`, its seq counting
 *   from 1 for the life of the stream (a line pushed out of the ring keeps its number gone, so a card
 *   asking `since` an older seq sees the gap). Streams: `server`, the dev server's own, and
 *   `task:<name>` for each task (`tasks.ts`), each made on its first write.
 * - **Pushed in batches** (`Logs`): a stream's new lines go out as one `studio:log` at most every 50 ms --
 *   a build's thousand lines are a handful of messages.
 * - **The dev server's own lines tee'd in** (`teeConsole`, `teeLogger`): `console.log/info/warn/error`
 *   wrapped once in the process -- the plugins' `[assets]`/`[agent]`/`[vibe]` lines are `console` calls --
 *   and Vite's logger (`server.config.logger`: `info`/`warn`/`warnOnce`/`error`), each calling through
 *   first, then writing the text. Never `process.stdout.write`. Vite's logger prints through `console`,
 *   so a line it writes is taken from the logger and the console wrapper skips it (`inLogger`). ANSI is
 *   kept: the card strips it.
 *
 * The wrapping is idempotent across Vite's in-process restart: the console's is flagged on the holder
 * (`globalThis`, `vite.ts`), a logger object by a symbol on it, and both write through the holder's
 * current `Logs`, so the new server's rings are the old one's. Nothing at module level.
 */
import { format } from 'node:util';
import type { LogLine, StudioMessage } from './api-types.ts';

/** Lines a stream keeps. */
export const RING_SIZE = 2000;

/** How long a stream's new lines wait to go out together. */
export const BATCH_MS = 50;

/** The server's own stream. */
export const SERVER_STREAM = 'server';

/** A task's stream. */
export const taskStream = (name: string): string => `task:${name}`;

/** One stream's last lines. */
export interface Ring {
  /** A line in; its seq. */
  push(text: string, at: number): number;
  /** The lines after `since` that are still kept, and the last seq. */
  since(seq: number): { seq: number; lines: LogLine[] };
  /** Lines kept now. */
  readonly size: number;
  /** The last seq written: `0` before any. */
  readonly seq: number;
}

/** A ring of at most `capacity` lines: a fixed array written round, nothing copied as it fills. */
export function createRing(capacity = RING_SIZE): Ring {
  const lines: LogLine[] = [];
  let next = 0;
  let seq = 0;
  return {
    push(text, at) {
      seq += 1;
      const line = { seq, at, text };
      if (lines.length < capacity) lines.push(line);
      else lines[next] = line;
      next = (next + 1) % capacity;
      return seq;
    },
    since(after) {
      const out: LogLine[] = [];
      // Oldest first: from `next` round, once the ring is full.
      const start = lines.length < capacity ? 0 : next;
      for (let i = 0; i < lines.length; i++) {
        const line = lines[(start + i) % lines.length]!;
        if (line.seq > after) out.push(line);
      }
      return { seq, lines: out };
    },
    get size() {
      return lines.length;
    },
    get seq() {
      return seq;
    },
  };
}

/** The timers the batching uses: the real ones, or a test's. */
export interface LogClock {
  now(): number;
  setTimeout(fn: () => void, ms: number): unknown;
  clearTimeout(handle: unknown): void;
}

export const REAL_LOG_CLOCK: LogClock = {
  now: () => Date.now(),
  setTimeout: (fn, ms) => setTimeout(fn, ms),
  clearTimeout: (handle) => clearTimeout(handle as ReturnType<typeof setTimeout>),
};

/** Every stream, written to and pushed. */
export interface Logs {
  /** Text in, split into lines (a trailing newline makes no empty line); each kept, the stream's push scheduled. */
  write(stream: string, text: string): void;
  /** A stream's ring; an empty one for a stream nothing wrote to (not kept). */
  ring(stream: string): Ring;
  /** The streams written to, in the order made. */
  streams(): string[];
  /** A stream's waiting lines pushed now (a task's, before its `ended`). */
  flush(stream: string): void;
  /** Where pushes go: re-pointed by each new server. */
  send: (message: StudioMessage) => void;
}

/** The rings, and their pushes through `send` at most once per `batchMs` per stream. */
export function createLogs(options: { send?: (message: StudioMessage) => void; clock?: LogClock; batchMs?: number; capacity?: number } = {}): Logs {
  const clock = options.clock ?? REAL_LOG_CLOCK;
  const batchMs = options.batchMs ?? BATCH_MS;
  const rings = new Map<string, Ring>();
  /** Per stream: the lines not pushed yet, and its timer. */
  const waiting = new Map<string, { lines: LogLine[]; timer: unknown }>();
  const logs: Logs = {
    send: options.send ?? (() => {}),
    write(stream, text) {
      let ring = rings.get(stream);
      if (!ring) {
        ring = createRing(options.capacity);
        rings.set(stream, ring);
      }
      const at = clock.now();
      const parts = text.replace(/\r\n/g, '\n').split('\n');
      if (parts.length > 1 && parts[parts.length - 1] === '') parts.pop();
      let batch = waiting.get(stream);
      if (!batch) {
        batch = { lines: [], timer: clock.setTimeout(() => logs.flush(stream), batchMs) };
        waiting.set(stream, batch);
      }
      for (const part of parts) batch.lines.push({ seq: ring.push(part, at), at, text: part });
      // A ring's worth waiting is all a card can use: older ones would be gone from the ring as well.
      if (batch.lines.length > (options.capacity ?? RING_SIZE)) batch.lines.splice(0, batch.lines.length - (options.capacity ?? RING_SIZE));
    },
    ring(stream) {
      return rings.get(stream) ?? createRing(1);
    },
    streams() {
      return [...rings.keys()];
    },
    flush(stream) {
      const batch = waiting.get(stream);
      if (!batch) return;
      waiting.delete(stream);
      clock.clearTimeout(batch.timer);
      if (batch.lines.length === 0) return;
      logs.send({ kind: 'studio:log', stream, seq: batch.lines[batch.lines.length - 1]!.seq, lines: batch.lines });
    },
  };
  return logs;
}

/** What the tee keeps on the holder (`vite.ts`): the logs it writes to, and its flags. */
export interface TeeHolder {
  logs?: Logs;
  /** `console` wrapped: once per process. */
  teed?: boolean;
  /** Inside a wrapped logger's call: its `console` output is the logger's line, already taken. */
  inLogger?: number;
  /** Inside a write: a `console` call the push itself makes is not taken again. */
  writing?: boolean;
}

const METHODS = ['log', 'info', 'warn', 'error'] as const;

/** One line in from the tee, unless it is the tee's own doing. */
function take(holder: TeeHolder, text: string): void {
  if (holder.writing || !holder.logs) return;
  holder.writing = true;
  try {
    holder.logs.write(SERVER_STREAM, text);
  } catch {
    // The log is a convenience: a failure here never breaks the call it watched.
  } finally {
    holder.writing = false;
  }
}

/** `console.log/info/warn/error` wrapped, once in the process: each calls through, then its text goes to the server stream. */
export function teeConsole(holder: TeeHolder, target: Console = console): void {
  if (holder.teed) return;
  holder.teed = true;
  for (const method of METHODS) {
    const original = target[method].bind(target);
    target[method] = (...args: unknown[]) => {
      original(...args);
      if (!holder.inLogger) take(holder, format(...args));
    };
  }
}

/** The mark on a logger already wrapped. */
const WRAPPED = Symbol.for('vibebase.studio.logger');

/** The parts of Vite's `Logger` the tee wraps. */
export interface TeeLogger {
  info(msg: string, options?: unknown): void;
  warn(msg: string, options?: unknown): void;
  warnOnce(msg: string, options?: unknown): void;
  error(msg: string, options?: unknown): void;
}

/**
 * Vite's logger wrapped (each server's own object, wrapped once): each method calls through, then its
 * text goes to the server stream -- `warnOnce` only the first time it prints, as Vite's does.
 */
export function teeLogger(holder: TeeHolder, logger: TeeLogger): void {
  const marked = logger as TeeLogger & { [WRAPPED]?: true };
  if (marked[WRAPPED]) return;
  marked[WRAPPED] = true;
  const seenOnce = new Set<string>();
  for (const method of ['info', 'warn', 'warnOnce', 'error'] as const) {
    const original = logger[method].bind(logger);
    logger[method] = (msg: string, options?: unknown) => {
      holder.inLogger = (holder.inLogger ?? 0) + 1;
      try {
        original(msg, options);
      } finally {
        holder.inLogger = (holder.inLogger ?? 1) - 1;
      }
      if (method === 'warnOnce') {
        if (seenOnce.has(msg)) return;
        seenOnce.add(msg);
      }
      take(holder, msg);
    };
  }
}
