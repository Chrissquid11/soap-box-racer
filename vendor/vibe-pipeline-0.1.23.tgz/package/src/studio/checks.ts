/**
 * The machine, checked for the studio (Docs/studio.md, `GET /__studio/checks`):
 * one row per thing a project needs of it, for the Tools page and the top bar.
 *
 * - **node**: `process.version` against `engines.node` -- the project's `package.json`, or the nearest
 *   folder's above it that says one (a workspace's root says it for its examples).
 * - **claude**: `claude --version` (the CLI the agent runs: `findClaude` over `agentEnv`'s PATH, through
 *   `tools.ts`' `run`), and whether it is logged in as the agent's sessions last heard it
 *   (`initializationResult`'s account, kept in each session's state) -- "not asked yet" before a session
 *   has come up.
 * - **gladius**, **ffmpeg**: `lookFor` with the pipeline's own `Need`s (`mergeNeeds`), so the same
 *   look-up order and the same words as the Tools page (`sayLook`).
 * - **git lfs**: `git lfs version`, a `Need` of its own here.
 *
 * **With no project** (`root: null`: the launcher, `packages/studio/`, before a project is open): node's
 * version alone (no `package.json` to read `engines` from), claude's version without the login state (that
 * is a session's, and the launcher runs none), and the tools looked up with no `assets.local.json` (a path
 * set there is a project's).
 *
 * Answers are kept ten seconds: the card asks as it is shown, and a look runs programs. Nothing at
 * module level.
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import type { ToolLook } from '../assets/api-types.ts';
import { FFMPEG, GLADIUS, lookFor as realLookFor, mergeNeeds, runProgram, sayLook, type LookContext, type Need } from '../assets/tools.ts';
import { agentEnv, findClaude } from '../agent/env.ts';
import type { CheckRow } from './api-types.ts';

/** Git LFS: binary assets go through it (CLAUDE.md), so a clone without it has pointers for models. */
export const GIT_LFS: Need = {
  tool: 'git lfs',
  bin: ['git'],
  version: ['lfs', 'version'],
  match: /git-lfs\/(\S+)/,
  hint: {
    darwin: 'brew install git-lfs, then git lfs install',
    win32: 'Git for Windows carries it: git lfs install',
    linux: 'apt install git-lfs, then git lfs install',
  },
};

/** How long an answer is kept. */
export const CHECKS_MS = 10_000;

/** A `>=24`, `^24.1.0`, `24.x`, `>=22 <25 || >=26` range against `version` (`v24.3.0`); null when the range cannot be read. */
export function satisfies(version: string, range: string): boolean | null {
  const parse = (v: string): number[] | null => {
    const m = /^v?(\d+|x|\*)(?:\.(\d+|x|\*))?(?:\.(\d+|x|\*))?$/.exec(v.trim());
    if (!m) return null;
    return [m[1], m[2], m[3]].map((p) => (p === undefined || p === 'x' || p === '*' ? -1 : Number(p)));
  };
  const have = parse(version.replace(/-.*$/, ''));
  if (!have) return null;
  const cmp = (a: number[], b: number[]): number => {
    for (let i = 0; i < 3; i++) if ((b[i] ?? -1) >= 0 && a[i] !== b[i]) return a[i]! - b[i]!;
    return 0;
  };
  let readable = true;
  const one = (comparator: string): boolean => {
    const m = /^(>=|<=|>|<|=|\^|~)?\s*(.+)$/.exec(comparator);
    const want = m ? parse(m[2]!) : null;
    if (!m || !want) {
      readable = false;
      return false;
    }
    const c = cmp(have, want);
    switch (m[1]) {
      case '>=':
        return c >= 0;
      case '>':
        return c > 0;
      case '<=':
        return c <= 0;
      case '<':
        return c < 0;
      case '^':
        return c >= 0 && have[0] === want[0];
      case '~':
        return c >= 0 && have[0] === want[0] && (want[1]! < 0 || have[1] === want[1]);
      default:
        return c === 0;
    }
  };
  const ok = range.split('||').some((set) => {
    const parts = set.trim().split(/\s+/).filter((p) => p !== '');
    return parts.length > 0 && parts.map(one).every(Boolean);
  });
  return readable ? ok : null;
}

/** The nearest `engines.node` at or above `root`, and the folder that says it; undefined when none does. */
export function enginesNode(root: string): { range: string; dir: string } | undefined {
  for (let dir = root; ; dir = dirname(dir)) {
    try {
      const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as { engines?: { node?: unknown } };
      if (typeof pkg.engines?.node === 'string') return { range: pkg.engines.node, dir };
    } catch {
      // No package.json here, or not JSON: on up.
    }
    if (dirname(dir) === dir) return undefined;
  }
}

/** node's row: its version against the range; with no project (`root` null), its version alone. */
export function nodeRow(root: string | null, version = process.version): CheckRow {
  if (root === null) return { name: 'node', ok: true, version, detail: `node ${version}` };
  const engines = enginesNode(root);
  if (!engines) return { name: 'node', ok: true, version, detail: `node ${version}; no package.json here names engines.node` };
  const ok = satisfies(version, engines.range);
  if (ok === null) return { name: 'node', ok: true, version, detail: `node ${version}; engines.node '${engines.range}' is a range this does not read` };
  return { name: 'node', ok, version, detail: ok ? `node ${version} (engines.node ${engines.range})` : `node ${version} is not ${engines.range}, which the project's package.json asks for: install a node that is` };
}

/** What the agent's sessions last heard of the account: logged in, who, or nothing yet. */
export interface AccountHeard {
  loggedIn: boolean;
  email: string | null;
}

/** `claude --version`, and the account as the sessions heard it. */
export interface ClaudeProbe {
  version(): Promise<string | null>;
  account(): AccountHeard | null;
}

/** The real probe: the CLI on `agentEnv`'s PATH, its version through `run`; the account from the agent's holder (`agent/vite.ts`). */
export function claudeProbe(account: () => AccountHeard | null): ClaudeProbe {
  return {
    async version() {
      const env = agentEnv();
      const claude = await findClaude(env);
      if (claude === undefined) return null;
      const ran = await runProgram(claude, ['--version'], 5000);
      return 'error' in ran ? null : (/\d+\.\d+\.\d+/.exec(ran.stdout)?.[0] ?? null);
    },
    account,
  };
}

/** claude's row; without `asked` (no project: no session to have heard the account), its version alone. */
export async function claudeRow(probe: ClaudeProbe, asked = true): Promise<CheckRow> {
  const version = await probe.version();
  if (version === null) return { name: 'claude', ok: false, detail: 'the Claude Code CLI is not found (the agent runs the SDK\'s own): install it from claude.com/claude-code, then `claude` and /login' };
  if (!asked) return { name: 'claude', ok: true, version, detail: `Claude Code ${version}` };
  const account = probe.account();
  const login = account === null ? 'logged in: not asked yet (a Claude card asks as it opens)' : account.loggedIn ? `logged in${account.email ? ` as ${account.email}` : ''}` : 'not logged in: `claude`, then /login';
  return { name: 'claude', ok: account?.loggedIn !== false, version, detail: `Claude Code ${version}; ${login}` };
}

/** A tool's row, from its look. */
export function lookRow(name: string, look: ToolLook): CheckRow {
  return { name, ok: look.state === 'found', ...(look.version ? { version: look.version } : {}), detail: sayLook(look) };
}

export interface ChecksOptions {
  /** The project's folder; null for none (the launcher): see the module's comment. */
  root: string | null;
  claude: ClaudeProbe;
  /** A test's stand-in looks. */
  lookFor?: (need: Need, context: LookContext) => Promise<ToolLook>;
  nodeVersion?: string;
  now?: () => number;
}

/** `GET checks`, kept `CHECKS_MS`. */
export function createChecks(options: ChecksOptions): { get(): Promise<CheckRow[]> } {
  const now = options.now ?? Date.now;
  const lookFor = options.lookFor ?? realLookFor;
  let kept: { at: number; rows: Promise<CheckRow[]> } | undefined;
  const fresh = async (): Promise<CheckRow[]> => {
    const needs = mergeNeeds([[GLADIUS, FFMPEG], [GIT_LFS]]);
    const { root } = options;
    const context: LookContext = root === null ? { root: '', local: {} } : { root };
    const [claude, ...looks] = await Promise.all([claudeRow(options.claude, root !== null), ...needs.map((need) => lookFor(need, context))]);
    return [nodeRow(root, options.nodeVersion), claude!, ...looks.map((look, i) => lookRow(needs[i]!.tool, look as ToolLook))];
  };
  return {
    get() {
      if (!kept || now() - kept.at >= CHECKS_MS) {
        const rows = fresh();
        kept = { at: now(), rows };
        // A failure is not kept: the next call looks again.
        rows.catch(() => (kept = undefined));
      }
      return kept.rows;
    },
  };
}
