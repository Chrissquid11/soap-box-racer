/**
 * The Git card's routes (Docs/studio.md): `git/status`, `git/log`, `git/branches`, `git/diff`, `git/commit`,
 * `git/checkout`, `git/push` and `git/pull` under `/__studio/`, for `vite.ts`' handler -- loopback alone, as every
 * studio route, and the mutating ones through `guardWrite` there.
 *
 * - **Both repositories** (`changes.ts`' `gitRoots`): the project's, and in source mode the engine's `engine/`,
 *   each answer naming a row's (`repo: 'project' | 'engine'`), every path the project's (relative to its root,
 *   `/`; the engine's prefixed `engine/`). What the project's own git says of `engine` itself -- its gitlink, or
 *   the folder untracked -- is left out: the engine's git says it file by file, as `changes.ts`' `reposOf` does.
 * - **A project inside a larger repository** (the workspace's sandbox) sees its own folder alone: status and log
 *   are asked with the pathspec `.`, and git's paths, which are the top's, have the project's prefix
 *   (`rev-parse --show-prefix`) taken off -- `takeBaseline`'s way, with `--untracked-files=all` as it asks: a
 *   new folder's files one by one, never the folder.
 * - **Status** is one `git status --porcelain=v2 -z --branch` a repository: the branch, its upstream, ahead and
 *   behind and each change, renames with the path they had, in one call. Its `-z` fields are split as
 *   `changes.ts`' are (`fields`).
 * - **A commit takes exactly the paths ticked**: `git add -- <paths>` (never `-A`; a deleted file's path stages
 *   its removal, as `git add` of a path gone from the disk does; one neither on the disk nor in the index -- a
 *   `git mv`'s old name, its removal staged already -- is left to the commit), then `git commit -F - -- <paths>` with the
 *   message on stdin -- several lines, any quotes -- and the same paths, so nothing staged before by hand goes in
 *   with it. Every path is a literal (`--literal-pathspecs`): a `*` in a name is that name.
 * - **What can lose work, or reach another machine, asks first**: a checkout with local changes, every push and
 *   every pull answer `{ ask, confirm: false }` -- words in the voice of the host's ask rule for `git push`
 *   (`agent/permissions.ts`' `HOST_ASK`) -- and only the same call with `confirm: true` runs it, as Update
 *   engine's preview and confirm. A pull is `--ff-only`: one that would merge is git's refusal, said, never a
 *   merge from a card. A push is never forced; a branch with no upstream is pushed `--set-upstream` to
 *   `origin` (or the one remote there is), and the words say so.
 * - **Their output is the Console's**: a push's, a pull's, a checkout's and a commit's lines go to the log's
 *   stream `git` as they come (`$ git push …` first), and their last lines are the answer's.
 * - **One at a time** (`changes.ts`' `serially`): two mutating calls never run git over one index at once.
 * - **Never a prompt**: `GIT_TERMINAL_PROMPT=0`, stdin closed, and a push or a pull stopped after
 *   `NETWORK_MS` -- a remote asking for a password fails, saying so, rather than hang the route.
 *
 * Every read goes through a `Git` (`gitIn`, `GIT_OPTIONAL_LOCKS=0`); a push's and a pull's lines through `stream`
 * (spawned here, a test's real git too). Nothing at module level.
 */
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { Refused } from '../assets/http.ts';
import { fields, gitIn, gitRoots, serially, type Git, type GitRoot, type Serial } from '../agent/changes.ts';
import {
  GIT_DIFF_LIMIT,
  GIT_LOG_COUNT,
  GIT_LOG_MAX,
  type GitAsk,
  type GitBranches,
  type GitChange,
  type GitCommitted,
  type GitDiff,
  type GitLog,
  type GitLogEntry,
  type GitRan,
  type GitRepo,
  type GitRepoStatus,
  type GitStatus,
} from './api-types.ts';
import { pathForm } from './files.ts';

/** The log's stream for git's own lines. */
export const GIT_STREAM = 'git';

/** A push or a pull stopped after this long: a remote waiting on a password it will never get. */
export const NETWORK_MS = 120_000;

/** Paths one commit or one diff may name. */
export const GIT_PATHS_MAX = 2000;

/** Lines of git's output an answer carries. */
export const GIT_LINES = 20;

/** A command run with its lines told as they come: its code and every line. */
export type GitStream = (dir: string, args: readonly string[], line: (text: string) => void) => Promise<{ code: number; lines: string[] }>;

/** What the routes need: the project's root, its git (`gitIn`, a test's), the log's stream, the network commands' runner. */
export interface GitContext {
  root: string;
  git?: (dir: string) => Git;
  /** A line to the log's `git` stream (the Console's); none, nowhere. */
  log?: (text: string) => void;
  /** A push's or a pull's run (`streamGit`). */
  stream?: GitStream;
  /** The mutating calls one at a time: kept by the caller across requests. */
  serial?: Serial;
}

/** A repository of the project, with its git and its name. */
interface Repo extends GitRoot {
  name: GitRepo;
  git: Git;
}

const reposOf = (context: GitContext): Repo[] =>
  gitRoots(context.root).map((r) => ({ ...r, name: r.prefix === '' ? 'project' : 'engine', git: (context.git ?? gitIn)(r.root) }));

/** The repository a body names (`project` when it names none); 400 one the project has not. */
function repoNamed(context: GitContext, raw: unknown): Repo {
  const name = raw === undefined || raw === null ? 'project' : raw;
  if (name !== 'project' && name !== 'engine') throw new Refused(400, 'repo is project or engine');
  const repo = reposOf(context).find((r) => r.name === name);
  if (!repo) throw new Refused(400, 'this project has no engine/ repository: it is in published mode');
  return repo;
}

/** The project's folder under the repository's top (`''` at it), or null: no repository, or no git. */
async function prefixOf(git: Git): Promise<string | null> {
  const r = await git(['rev-parse', '--show-prefix']);
  return r.code === 0 ? r.stdout.trim() : null;
}

/** Git's words for a person: its stderr (or stdout) trimmed, `hint:` lines dropped. */
const gitWords = (r: { stdout: string; stderr: string }): string =>
  (r.stderr.trim() || r.stdout.trim())
    .split('\n')
    .filter((l) => !l.startsWith('hint:'))
    .join('\n')
    .trim() || 'git refused';

/** A refusal in git's words, with an identity's missing said the way to fix it. */
function refusedBy(r: { stdout: string; stderr: string }, lines?: string[]): Refused {
  let why = gitWords(r);
  if (/tell me who you are|author identity unknown|empty ident/i.test(why)) why = `git does not know who you are: set git config user.name and git config user.email (${why.split('\n').pop()})`;
  return new Refused(409, why, { why, ...(lines ? { lines } : {}) });
}

// ---------------------------------------------------------------- status

/** A status line's `XY` letter as the card's kind. */
function kindOf(letter: string): GitChange['kind'] {
  switch (letter) {
    case 'A':
      return 'added';
    case 'D':
      return 'deleted';
    case 'R':
    case 'C':
      return 'renamed';
    default:
      return 'modified';
  }
}

/** One repository's head and changes, from `git status --porcelain=v2 -z --branch` (paths as git names them, from its top). */
export function parseStatus(out: string): { branch: string | null; upstream: string | null; ahead: number; behind: number; changes: Omit<GitChange, 'repo'>[] } {
  let branch: string | null = null;
  let upstream: string | null = null;
  let ahead = 0;
  let behind = 0;
  const changes: Omit<GitChange, 'repo'>[] = [];
  const parts = fields(out);
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i]!;
    if (part.startsWith('# branch.head ')) {
      const head = part.slice('# branch.head '.length);
      branch = head === '(detached)' ? null : head;
    } else if (part.startsWith('# branch.upstream ')) upstream = part.slice('# branch.upstream '.length);
    else if (part.startsWith('# branch.ab ')) {
      const m = /^# branch\.ab \+(\d+) -(\d+)$/.exec(part);
      if (m) [ahead, behind] = [Number(m[1]), Number(m[2])];
    } else if (part.startsWith('1 ') || part.startsWith('2 ')) {
      // `1 XY sub mH mI mW hH hI path`; `2 XY sub mH mI mW hH hI Xscore path`, then the path it had as a field of its own.
      const words = part.split(' ');
      const xy = words[1]!;
      const path = words.slice(part[0] === '1' ? 8 : 9).join(' ');
      const letter = xy[0] !== '.' ? xy[0]! : xy[1]!;
      const change: Omit<GitChange, 'repo'> = { path, kind: kindOf(letter), staged: xy[0] !== '.' };
      if (part[0] === '2') change.from = parts[++i]!;
      changes.push(change);
    } else if (part.startsWith('u ')) {
      changes.push({ path: part.split(' ').slice(10).join(' '), kind: 'conflict', staged: false });
    } else if (part.startsWith('? ')) changes.push({ path: part.slice(2), kind: 'untracked', staged: false });
  }
  return { branch, upstream, ahead, behind, changes };
}

/** A repository's status, its paths the project's; null where git has none (not a repository). */
async function repoStatus(repo: Repo, nested: readonly string[]): Promise<{ head: GitRepoStatus; changes: GitChange[] } | null> {
  const prefix = await prefixOf(repo.git);
  if (prefix === null) return null;
  const r = await repo.git(['status', '--porcelain=v2', '-z', '--branch', '--untracked-files=all', '--', '.']);
  if (r.code !== 0) throw new Refused(500, `git status: ${gitWords(r)}`);
  const parsed = parseStatus(r.stdout);
  const strip = (p: string): string => repo.prefix + (prefix !== '' && p.startsWith(prefix) ? p.slice(prefix.length) : p);
  /** The project's own git on a nested repository -- its gitlink, its folder untracked: that one answers for it. */
  const theirs = (p: string): boolean => nested.some((n) => p === n.slice(0, -1) || p.startsWith(n));
  const changes: GitChange[] = [];
  for (const c of parsed.changes) {
    const path = strip(c.path);
    if (repo.name === 'project' && theirs(path)) continue;
    changes.push({ ...c, path, repo: repo.name, ...(c.from !== undefined ? { from: strip(c.from) } : {}) });
  }
  return {
    head: { repo: repo.name, root: repo.prefix, branch: parsed.branch, upstream: parsed.upstream, ahead: parsed.ahead, behind: parsed.behind, clean: changes.length === 0 },
    changes,
  };
}

/** `GET git/status`. */
export async function gitStatus(context: GitContext): Promise<GitStatus> {
  const repos = reposOf(context);
  const nested = repos.slice(1).map((r) => r.prefix);
  const each = await Promise.all(repos.map((r) => repoStatus(r, nested)));
  const out: GitStatus = { repos: [], changes: [] };
  for (const one of each) {
    if (!one) continue;
    out.repos.push(one.head);
    out.changes.push(...one.changes);
  }
  out.changes.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  return out;
}

// ---------------------------------------------------------------- log, branches, diff

/** A commit's fields, apart: a separator no subject has. */
const RECORD = '\x1e';
const FIELD = '\x1f';

/** `git log -z --numstat --format=<RECORD>%H<FIELD>%h<FIELD>%an<FIELD>%aI<FIELD>%s`'s output as entries. */
export function parseLog(out: string, prefix = ''): GitLogEntry[] {
  const entries: GitLogEntry[] = [];
  for (const record of out.split(RECORD)) {
    if (record === '') continue;
    const end = record.indexOf('\0');
    const head = end < 0 ? record : record.slice(0, end);
    const [hash, short, author, date, ...subject] = head.split(FIELD);
    if (!hash || !short) continue;
    const files: GitLogEntry['files'] = [];
    for (const row of fields(end < 0 ? '' : record.slice(end + 1))) {
      const [a, d, ...rest] = row.replace(/^\n/, '').split('\t');
      const path = rest.join('\t');
      if (path === '' || a === undefined || d === undefined) continue;
      files.push({ path: prefix + path, added: a === '-' ? null : Number(a), deleted: d === '-' ? null : Number(d) });
    }
    entries.push({ hash, short, author: author ?? '', date: date ?? '', subject: subject.join(FIELD), files });
  }
  return entries;
}

/** `GET git/log?count=`: each repository's last commits touching the project, with their files. */
export async function gitLog(context: GitContext, raw: string | null): Promise<GitLog[]> {
  let count = GIT_LOG_COUNT;
  if (raw !== null && raw !== '') {
    count = Number(raw);
    if (!Number.isInteger(count) || count < 1) throw new Refused(400, `count is a whole number from 1 to ${GIT_LOG_MAX}`);
    count = Math.min(count, GIT_LOG_MAX);
  }
  const out: GitLog[] = [];
  for (const repo of reposOf(context)) {
    if ((await prefixOf(repo.git)) === null) continue;
    // A repository with no commit yet: git says so on stderr, and the list is empty.
    const head = await repo.git(['rev-parse', '--verify', '--quiet', 'HEAD']);
    if (head.code !== 0) {
      out.push({ repo: repo.name, entries: [] });
      continue;
    }
    const r = await repo.git(['log', '-n', String(count), '-z', '--numstat', '--no-renames', '--relative', `--format=${RECORD}%H${FIELD}%h${FIELD}%an${FIELD}%aI${FIELD}%s`, '--', '.']);
    if (r.code !== 0) throw new Refused(500, `git log: ${gitWords(r)}`);
    out.push({ repo: repo.name, entries: parseLog(r.stdout, repo.prefix) });
  }
  return out;
}

/** `git branch --format=%(refname:short)%00%(upstream:short)%00%(HEAD)`'s lines as branches. */
export function parseBranches(out: string): GitBranches['branches'] {
  const branches: GitBranches['branches'] = [];
  for (const line of out.split('\n')) {
    if (line === '') continue;
    const [name, upstream, head] = line.split('\0');
    // A detached HEAD's own line, `(HEAD detached at …)`, is no branch.
    if (!name || name.startsWith('(')) continue;
    branches.push({ name, upstream: upstream ? upstream : null, current: head === '*' });
  }
  return branches;
}

/** `GET git/branches`. */
export async function gitBranches(context: GitContext): Promise<GitBranches[]> {
  const out: GitBranches[] = [];
  for (const repo of reposOf(context)) {
    if ((await prefixOf(repo.git)) === null) continue;
    const r = await repo.git(['branch', '--format=%(refname:short)%00%(upstream:short)%00%(HEAD)']);
    if (r.code !== 0) throw new Refused(500, `git branch: ${gitWords(r)}`);
    const branches = parseBranches(r.stdout);
    out.push({ repo: repo.name, current: branches.find((b) => b.current)?.name ?? null, branches });
  }
  return out;
}

/** Paths from a body or a query: each the project's form (`files.ts`' `pathForm`), at least one, at most `GIT_PATHS_MAX`. */
function pathList(raw: unknown): string[] {
  if (!Array.isArray(raw) || raw.length === 0) throw new Refused(400, 'paths is the files, a list of at least one');
  if (raw.length > GIT_PATHS_MAX) throw new Refused(400, `paths is ${GIT_PATHS_MAX} files at most`);
  return [...new Set(raw.map((p) => pathForm(p)))];
}

/** The paths split by repository, each as its git names it from the project's folder (the engine's without `engine/`). */
function byRepo(context: GitContext, paths: readonly string[]): Map<Repo, string[]> {
  const repos = reposOf(context);
  const out = new Map<Repo, string[]>();
  for (const path of paths) {
    let repo = repos[0]!;
    for (let i = repos.length - 1; i > 0; i--) if (path.startsWith(repos[i]!.prefix)) repo = repos[i]!;
    const list = out.get(repo) ?? [];
    list.push(path.slice(repo.prefix.length));
    out.set(repo, list);
  }
  return out;
}

/** The tree of no files: what a repository with no commit is diffed against. */
const EMPTY_TREE = '4b825dc642cb6eb9a060e54bf8d69288fbee4904';

/**
 * `GET git/diff?paths=`: the unified diff of those paths against `HEAD` (staged and not), an untracked one as a new
 * file, in each repository; cut at `limit` bytes (`GIT_DIFF_LIMIT`; a test passes a smaller one) on the last whole
 * line before it, so no character is split.
 */
export async function gitDiff(context: GitContext, raw: readonly string[], limit = GIT_DIFF_LIMIT): Promise<GitDiff> {
  const paths = pathList(raw);
  let diff = '';
  for (const [repo, list] of byRepo(context, paths)) {
    if ((await prefixOf(repo.git)) === null) continue;
    const head = (await repo.git(['rev-parse', '--verify', '--quiet', 'HEAD'])).code === 0 ? 'HEAD' : EMPTY_TREE;
    const named = repo.prefix === '' ? [] : [`--src-prefix=a/${repo.prefix}`, `--dst-prefix=b/${repo.prefix}`];
    const tracked = await repo.git(['--literal-pathspecs', 'diff', '--no-color', '--no-ext-diff', '--relative', ...named, head, '--', ...list]);
    if (tracked.code !== 0) throw new Refused(500, `git diff: ${gitWords(tracked)}`);
    diff += tracked.stdout;
    // What git does not track yet: each a new file, as `--no-index` against nothing words it.
    const others = await repo.git(['--literal-pathspecs', 'ls-files', '-z', '--others', '--exclude-standard', '--', ...list]);
    for (const path of fields(others.stdout)) {
      if (diff.length > limit) break;
      const made = await repo.git(['diff', '--no-color', '--no-ext-diff', '--no-index', ...named, '--', '/dev/null', path]);
      diff += made.stdout;
    }
    if (diff.length > limit) break;
  }
  const bytes = Buffer.from(diff, 'utf8');
  if (bytes.length <= limit) return { diff, truncated: false };
  // The last `\n` within the limit ends the cut: a whole line, never half a multibyte character.
  const end = bytes.lastIndexOf(0x0a, limit - 1) + 1;
  return { diff: bytes.subarray(0, end).toString('utf8'), truncated: true };
}

// ---------------------------------------------------------------- what changes something

/** The real runner: git spawned with no stdin and no prompt, each line of stdout and stderr told as it comes (a `\r` progress line too), stopped after `NETWORK_MS`. */
export const streamGit: GitStream = (dir, args, line) =>
  new Promise((done) => {
    const lines: string[] = [];
    const tell = (text: string): void => {
      const t = text.trimEnd();
      if (t === '') return;
      lines.push(t);
      line(t);
    };
    const child = spawn('git', [...args], { cwd: dir, env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GIT_OPTIONAL_LOCKS: '0' }, stdio: ['ignore', 'pipe', 'pipe'] });
    const timer = setTimeout(() => {
      tell(`[git] no answer in ${NETWORK_MS / 1000} s: stopped`);
      child.kill('SIGTERM');
    }, NETWORK_MS);
    for (const pipe of [child.stdout, child.stderr]) {
      let rest = '';
      pipe.setEncoding('utf8');
      pipe.on('data', (chunk: string) => {
        const parts = (rest + chunk).split(/\r\n|\r|\n/);
        rest = parts.pop() ?? '';
        for (const p of parts) tell(p);
      });
      pipe.on('end', () => {
        if (rest !== '') tell(rest);
        rest = '';
      });
    }
    child.on('error', (err) => tell(`git: ${err.message}`));
    child.on('close', (code) => {
      clearTimeout(timer);
      done({ code: typeof code === 'number' ? code : 1, lines });
    });
  });

/** Lines to the log's stream, the command first. */
function told(context: GitContext, repo: Repo, args: readonly string[]): (text: string) => void {
  const log = context.log ?? (() => {});
  log(`$ git ${args.join(' ')}${repo.prefix === '' ? '' : `   (in ${repo.prefix})`}`);
  return log;
}

/** A git call whose output goes to the log too: its result. */
async function logged(context: GitContext, repo: Repo, args: readonly string[], input?: string): Promise<{ code: number; stdout: string; stderr: string }> {
  const log = told(context, repo, args);
  const r = await repo.git(args, input === undefined ? {} : { input });
  const text = `${r.stdout}${r.stderr}`.trim();
  if (text !== '') log(text);
  return r;
}

const lastLines = (text: string): string[] =>
  text
    .split(/\r\n|\r|\n/)
    .map((l) => l.trimEnd())
    .filter((l) => l !== '')
    .slice(-GIT_LINES);

/** `POST git/commit { message, paths, repo }`. */
export async function gitCommit(context: GitContext, body: Record<string, unknown>): Promise<GitCommitted> {
  const repo = repoNamed(context, body.repo);
  if (typeof body.message !== 'string' || body.message.trim() === '') throw new Refused(400, 'message is the commit\'s message: it needs words');
  const message = body.message.replace(/\r\n/g, '\n').trim() + '\n';
  const paths = pathList(body.paths);
  const theirs = paths.filter((p) => (repo.prefix === '' ? reposOf(context).slice(1).some((r) => p.startsWith(r.prefix)) : !p.startsWith(repo.prefix)));
  if (theirs.length > 0) throw new Refused(400, `${theirs[0]} is not in the ${repo.name}'s repository: one commit a repository`);
  const own = paths.map((p) => p.slice(repo.prefix.length));
  return (context.serial ?? serially())(async () => {
    // A path neither on the disk nor in the index is a removal staged already (a `git mv`'s old name): `git add`
    // would refuse it as matching nothing, and the commit's own pathspec takes it from HEAD.
    const indexed = new Set(fields((await repo.git(['--literal-pathspecs', 'ls-files', '-z', '--cached', '--', ...own])).stdout));
    const toAdd = own.filter((p) => indexed.has(p) || existsSync(join(repo.root, p)));
    if (toAdd.length > 0) {
      const added = await logged(context, repo, ['--literal-pathspecs', 'add', '--', ...toAdd]);
      if (added.code !== 0) throw refusedBy(added);
    }
    const made = await logged(context, repo, ['--literal-pathspecs', 'commit', '-F', '-', '--', ...own], message);
    if (made.code !== 0) throw refusedBy(made);
    const hash = await repo.git(['rev-parse', 'HEAD']);
    const short = await repo.git(['rev-parse', '--short', 'HEAD']);
    return { hash: hash.stdout.trim(), short: short.stdout.trim() };
  });
}

/** The repository's changes that a checkout or a pull could clash with: tracked files changed, or a conflict. */
async function localChanges(context: GitContext, repo: Repo): Promise<number> {
  const nested = reposOf(context)
    .slice(1)
    .map((r) => r.prefix);
  const status = await repoStatus(repo, nested);
  return status?.changes.filter((c) => c.kind !== 'untracked').length ?? 0;
}

const filesWord = (n: number): string => `${n} ${n === 1 ? 'file' : 'files'}`;
const commitsWord = (n: number): string => `${n} ${n === 1 ? 'commit' : 'commits'}`;

/** `POST git/checkout { branch, repo, create?, confirm? }`. */
export async function gitCheckout(context: GitContext, body: Record<string, unknown>): Promise<GitAsk | GitRan> {
  const repo = repoNamed(context, body.repo);
  const branch = body.branch;
  if (typeof branch !== 'string' || branch === '' || branch.startsWith('-')) throw new Refused(400, 'branch is a branch\'s name');
  const form = await repo.git(['check-ref-format', '--branch', branch]);
  if (form.code !== 0) throw new Refused(400, `${branch} is no branch name git takes`);
  const create = body.create === true;
  if (body.confirm !== true) {
    const changed = await localChanges(context, repo);
    if (changed > 0) {
      return { ask: `${create ? 'start the branch' : 'switch to'} ${branch} with ${filesWord(changed)} changed and not committed? They come along (git refuses if they clash with ${branch}).`, confirm: false };
    }
  }
  const args = create ? ['switch', '-c', branch] : ['switch', branch];
  return (context.serial ?? serially())(async () => {
    const r = await logged(context, repo, args);
    if (r.code !== 0) throw refusedBy(r);
    return { ok: true as const, lines: lastLines(`${r.stdout}${r.stderr}`) };
  });
}

/** Where a branch pushes: its upstream's remote and branch, or `origin` (else the one remote) to be set. */
async function pushTarget(repo: Repo): Promise<{ branch: string; remote: string; merge: string | null; upstream: string | null; ahead: number; behind: number }> {
  const status = await repo.git(['status', '--porcelain=v2', '-z', '--branch', '--untracked-files=no']);
  if (status.code !== 0) throw refusedBy(status);
  const head = parseStatus(status.stdout);
  if (head.branch === null) throw new Refused(409, 'HEAD is detached: no branch to push or pull', { why: 'HEAD is detached: check a branch out first' });
  const remote = (await repo.git(['config', '--get', `branch.${head.branch}.remote`])).stdout.trim();
  const merge = (await repo.git(['config', '--get', `branch.${head.branch}.merge`])).stdout.trim();
  if (head.upstream !== null && remote !== '' && merge !== '') return { branch: head.branch, remote, merge, upstream: head.upstream, ahead: head.ahead, behind: head.behind };
  const remotes = (await repo.git(['remote'])).stdout.split('\n').filter((r) => r !== '');
  const chosen = remotes.includes('origin') ? 'origin' : remotes.length === 1 ? remotes[0]! : null;
  if (chosen === null) throw new Refused(409, `${head.branch} has no upstream, and no remote is named origin`, { why: remotes.length === 0 ? 'no remote: add one (git remote add origin <url>)' : `no remote is named origin (${remotes.join(', ')}): set the upstream once in a terminal` });
  return { branch: head.branch, remote: chosen, merge: null, upstream: null, ahead: head.ahead, behind: head.behind };
}

/** A push or a pull run: its lines to the log as they come, the answer's last ones; git's refusal a 409 with them. */
async function network(context: GitContext, repo: Repo, args: readonly string[]): Promise<GitRan> {
  const log = told(context, repo, args);
  const r = await (context.stream ?? streamGit)(repo.root, args, log);
  const lines = r.lines.slice(-GIT_LINES);
  log(`[git ${args[0]} exited ${r.code}]`);
  if (r.code !== 0) {
    const why = lines.filter((l) => !l.startsWith('hint:')).slice(-3).join('\n') || `git ${args[0]} exited ${r.code}`;
    throw new Refused(409, why, { why, lines });
  }
  return { ok: true, lines };
}

/** `POST git/push { repo, confirm? }`: never forced. */
export async function gitPush(context: GitContext, body: Record<string, unknown>): Promise<GitAsk | GitRan> {
  const repo = repoNamed(context, body.repo);
  const target = await pushTarget(repo);
  if (body.confirm !== true) {
    if (target.upstream === null) return { ask: `push ${target.branch} to ${target.remote}? It has no upstream yet: pushed with --set-upstream ${target.remote} ${target.branch}, as ${target.remote}/${target.branch}.`, confirm: false };
    const behind = target.behind > 0 ? ` ${target.upstream} has ${commitsWord(target.behind)} ${target.branch} lacks, as last fetched: git refuses the push until it is pulled.` : '';
    const ask = target.ahead > 0 ? `push ${commitsWord(target.ahead)} on ${target.branch} to ${target.upstream}?${behind}` : `push ${target.branch} to ${target.upstream}? It has no commit ${target.upstream} lacks, as last fetched.${behind}`;
    return { ask, confirm: false };
  }
  const args = target.merge === null ? ['push', '--set-upstream', target.remote, target.branch] : ['push', target.remote, `refs/heads/${target.branch}:${target.merge}`];
  return (context.serial ?? serially())(() => network(context, repo, args));
}

/** `POST git/pull { repo, confirm? }`: a fast-forward or nothing. */
export async function gitPull(context: GitContext, body: Record<string, unknown>): Promise<GitAsk | GitRan> {
  const repo = repoNamed(context, body.repo);
  const target = await pushTarget(repo);
  if (target.upstream === null) throw new Refused(409, `${target.branch} has no upstream to pull from`, { why: `${target.branch} has no upstream: push it first, which sets one` });
  if (body.confirm !== true) {
    const changed = await localChanges(context, repo);
    const local = changed > 0 ? ` ${filesWord(changed)} changed and not committed: git refuses if the pull touches them.` : '';
    return { ask: `pull ${target.upstream} into ${target.branch}, fast-forward only?${local}`, confirm: false };
  }
  return (context.serial ?? serially())(() => network(context, repo, ['pull', '--ff-only']));
}
