/**
 * A child process as the studio and the launcher run one (Docs/studio.md §4, §10): `spawnChild` -- no stdin,
 * its pipes, on POSIX the leader of a process group of its own (`group`) so a signal reaches everything it
 * started -- `signalGroup` to send that signal (on Windows, which has neither groups nor signals, `taskkill /T /F`
 * over the child's tree where `group`: `treeKill` says which command), and `readLines` to take a pipe line by line. The studio's
 * tasks (`tasks.ts`), the launcher's projects and its Update engine (`@vibe/studio`, through
 * `@vibe/pipeline/launcher`) all go through these. Nothing at module level.
 */
import { ChildProcess, spawn as nodeSpawn } from 'node:child_process';
import type { Readable } from 'node:stream';

/** What a child is to its runner: Node's `ChildProcess`, or a test's stand-in. */
export interface Child {
  readonly pid?: number | undefined;
  readonly stdout: Readable | null;
  readonly stderr: Readable | null;
  on(event: 'close', listener: (code: number | null, signal: NodeJS.Signals | null) => void): unknown;
  on(event: 'error', listener: (err: Error) => void): unknown;
  kill(signal?: NodeJS.Signals): boolean;
}

export type ChildSpawn = (command: string, args: readonly string[], options: { cwd: string; env: Record<string, string>; group: boolean; shell: boolean }) => Child;

/**
 * Node's `spawn`: no stdin, its pipes, its own process group where `group` (POSIX: `detached`; on Windows
 * `detached` would give it a console of its own, so never there -- its tree is stopped by `taskkill` instead), no
 * window on Windows.
 */
export const spawnChild: ChildSpawn = (command, args, { cwd, env, group, shell }) => nodeSpawn(command, [...args], { cwd, env, stdio: ['ignore', 'pipe', 'pipe'], detached: group && process.platform !== 'win32', shell, windowsHide: true });

/**
 * How a child's whole tree is stopped on `platform` where no signal can do it: Windows, `taskkill /pid <pid> /T /F`
 * -- the tree (`npm.cmd` runs under `cmd.exe`, which starts node, which starts Vite's workers: a kill of the first
 * leaves the rest), forced, since a console process takes no gentler ask. Null on POSIX: a signal to the group. Pure.
 */
export function treeKill(pid: number, platform: NodeJS.Platform): { command: string; args: string[] } | null {
  return platform === 'win32' ? { command: 'taskkill', args: ['/pid', String(pid), '/T', '/F'] } : null;
}

/**
 * A signal to a child: its whole group where it leads one (`group`), else the process. On Windows (`platform`) a
 * `group` child's tree is ended by `treeKill`'s command whatever the signal -- but only for a real process Node
 * spawned, never a test's stand-in (whose pid is made up), which hears `kill` as anywhere. Gone already is no error.
 */
export function signalGroup(child: Child, signal: NodeJS.Signals, group: boolean, platform: NodeJS.Platform = process.platform): void {
  try {
    const tree = group && child.pid !== undefined ? treeKill(child.pid, platform) : null;
    if (tree && child instanceof ChildProcess) {
      const killer = nodeSpawn(tree.command, tree.args, { stdio: 'ignore', windowsHide: true });
      // taskkill missing, or the tree gone already: the process itself, as a last word.
      killer.on('error', () => child.kill(signal));
    } else if (tree) child.kill(signal);
    else if (group && child.pid !== undefined) process.kill(-child.pid, signal);
    else child.kill(signal);
  } catch {
    // Gone already.
  }
}

/**
 * A pipe's text, line by line into `line` (a last line with no newline at its end; `\r\n` and `\r` taken as
 * ends too). The one splitter: the studio's tasks, the launcher's projects and its Update engine read through
 * it. A `\r` ending a chunk is held back until the next, so a `\r\n` split between two chunks is one end.
 */
export function readLines(stream: Readable | null, line: (text: string) => void): void {
  if (!stream) return;
  let rest = '';
  stream.setEncoding('utf8');
  stream.on('data', (chunk: string) => {
    let text = rest + chunk;
    let held = '';
    if (text.endsWith('\r')) {
      held = '\r';
      text = text.slice(0, -1);
    }
    const parts = text.split(/\r?\n|\r/);
    rest = parts.pop()! + held;
    for (const part of parts) line(part);
  });
  stream.on('end', () => {
    const last = rest.endsWith('\r') ? rest.slice(0, -1) : rest;
    if (last !== '') line(last);
    rest = '';
  });
}
