/**
 * The Code card's files (Docs/studio.md): `GET tree`, `GET file` (now, at a turn's start, at `HEAD`) and `PUT
 * file`, for `vite.ts`' routes, and the coalescing behind `studio:file-changed`.
 *
 * - **The tree** is what git says, in every repository of the project (`gitRoots`: its own, and the engine's in
 *   source mode, its paths prefixed `engine/`): every tracked file (`git ls-files`; a submodule's gitlink and a
 *   tracked file deleted from the disk left out), and the untracked ones -- ignored never -- under the roots
 *   `src/`, `AssetsSource/`, `packs/`, `public/`, `engine/`, `.claude/skills/` and `.claude/agents/` (a project's
 *   own skill or agent, Config ▸ Claude ▸ Skills'; `vibe sync`'s copies are ignored, so read-only; the rest of
 *   `.claude/` -- `settings.local.json`, `worktrees/` -- is no root: `settings.json` is writable when tracked) --
 *   and `CLAUDE.md` at the root (`TREE_FILES`). Never anything under `node_modules`, `.git`,
 *   `.cache`, `.trash` or `dist`, at any depth. Sorted by path, name by name (`comparePaths`: a folder's files
 *   before a sibling whose name only starts with the folder's, as a tree shows them and `rg --sort path` finds
 *   them). **A project with no git** at all: a walk of the roots, and each of `TREE_FILES` that is a file, every
 *   one `tracked: false`.
 * - **A file's path** is the project's: relative, `/` only, no empty, `.` or `..` part; the real path of the
 *   deepest folder of it that exists inside the root's -- a link cannot lead out -- but under `node_modules/`,
 *   where a workspace's packages are links and every file is read-only anyway. `.git/` is 404 always.
 * - **Writable** (`readOnly: false`) is a file the tree lists or would: tracked, or untracked and not ignored
 *   under a root, and under none of the excluded folders. A file under `node_modules/` is readable (a definition
 *   lands in a package's shipped source) and read-only; so is any other file of the project's outside the tree
 *   -- and every file `vibe assets` generates (`isGenerated`: `src/assets/keys.d.ts`, the globs, `src/game/live.ts`),
 *   which the tree lists (`generated: true`, as each is there) though git ignores them: read, never written, moved,
 *   renamed or deleted (`file-ops.ts`).
 * - **`GET file`** answers the text and its mtime (ms): 404 missing, 413 over `FILE_LIMIT`, 415 when its first
 *   8 KB hold a NUL (binary). With `at=HEAD`, the text as git last committed it -- or at any commit the Git
 *   card's log names (`at=<hash>`, `<hash>^` the one before it: `COMMIT_AT`); with `at=<turn>`, as the turn's
 *   snapshot (`changes.ts`' `refs/vibebase/turns/<port>/<turn>`) has it, in the repository the path belongs to
 *   -- 404 when the ref or the path in it is missing (a file the turn made); then `mtime: null`, read-only. The
 *   blob is read as bytes (its size from `git cat-file -s` first, then `git cat-file blob` into a temp file: no
 *   textconv, and a folder is no blob, 404 as on disk), so the 413 and 415 are the blob's own, as a file on disk
 *   would have them.
 * - **`PUT file { path, text, ifMtime }`**: written whole or not at all (`fs.ts`' `writeAtomic`: a dot-named
 *   temp file beside it, its mode copied, flushed, renamed over), answering the new mtime (`SavedAnswer`); 412
 *   `FileConflict` with the text on disk when its mtime is not `ifMtime` (`ifMtime: null` is a new file, which
 *   must not be there); 423 `FileLocked` while a conversation's running turn has written or is writing that path
 *   (`writingNow`, the agent's); 403 a read-only path; 413 over `FILE_LIMIT`; 404 when its folder is not there
 *   (a folder that is a link inside the root is one).
 *
 * Every git call goes through a `Git` (`changes.ts`' `gitIn`, a test's stand-in) with `GIT_OPTIONAL_LOCKS=0`:
 * a read never contends for the index lock. Nothing at module level.
 */
import { randomUUID } from 'node:crypto';
import { readdir, readFile, realpath, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve, sep } from 'node:path';
import { isTempName, writeAtomic } from '../assets/fs.ts';
import { isGenerated } from '../assets/keys.ts';
import { Refused } from '../assets/http.ts';
import { gitIn, gitRoots, snapshotsOf, type Git, type GitRoot } from '../agent/changes.ts';
import { FILE_LIMIT, type FileAnswer, type FileConflict, type FileEntry, type FileLocked, type FilesAnswer, type SavedAnswer } from './api-types.ts';

/** The folders whose untracked files the tree lists. */
export const TREE_ROOTS: readonly string[] = ['src', 'AssetsSource', 'packs', 'public', 'engine', '.claude/skills', '.claude/agents'];

/** The files at the root an untracked one of may be listed and written: a project's `CLAUDE.md`, made by Config ▸ Claude ▸ CLAUDE.md. */
export const TREE_FILES: readonly string[] = ['CLAUDE.md'];

/** Folder names never listed, at any depth. */
export const EXCLUDED: ReadonlySet<string> = new Set(['node_modules', '.git', '.cache', '.trash', 'dist']);

/** How much of a file is looked at for a NUL: binary. */
export const SNIFF = 8 * 1024;

/** Is any folder on the path one of `EXCLUDED` (a file of such a name is a file). */
export function excluded(path: string): boolean {
  const parts = path.split('/');
  for (let i = 0; i < parts.length - 1; i++) if (EXCLUDED.has(parts[i]!)) return true;
  return false;
}

/** Is the path under one of `TREE_ROOTS`, or one of `TREE_FILES`. */
export const underRoots = (path: string): boolean => TREE_FILES.includes(path) || TREE_ROOTS.some((r) => path.startsWith(`${r}/`));

/** Paths in a tree's order: name by name, each compared by its UTF-16 units. */
export function comparePaths(a: string, b: string): number {
  const x = a.split('/');
  const y = b.split('/');
  for (let i = 0; i < Math.min(x.length, y.length); i++) {
    if (x[i] === y[i]) continue;
    // A folder against a file at one level: the strings decide, as rg's walk does entry by entry.
    return x[i]! < y[i]! ? -1 : 1;
  }
  return x.length - y.length;
}

/** The project's repositories with their git: `gitIn` each, or a test's. */
export interface FilesContext {
  root: string;
  /** The git of a repository's folder (`gitIn`). */
  git?: (dir: string) => Git;
}

const gitOf = (context: FilesContext, dir: string): Git => (context.git ?? gitIn)(dir);

/** NUL-separated output, its empty last entry dropped. */
const zsplit = (out: string): string[] => out.split('\0').filter((p) => p !== '');

/** Is `root` inside a git work tree at all. */
async function isRepo(git: Git): Promise<boolean> {
  const r = await git(['rev-parse', '--is-inside-work-tree']);
  return r.code === 0 && r.stdout.trim() === 'true';
}

/** A folder's files, walked: excluded folders and links to folders skipped. Paths relative to `root`. */
async function walkFiles(root: string, dir: string, out: string[]): Promise<void> {
  let names;
  try {
    names = await readdir(join(root, dir), { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of names) {
    const path = dir === '' ? entry.name : `${dir}/${entry.name}`;
    if (entry.isDirectory()) {
      if (!EXCLUDED.has(entry.name)) await walkFiles(root, path, out);
    } else if (entry.isFile()) out.push(path);
  }
}

/** The generated files there now (`isGenerated`): `src/assets/`'s and `src/game/live.ts`. */
async function generatedThere(root: string): Promise<string[]> {
  const out: string[] = [];
  for (const dir of ['src/assets', 'src/game']) {
    const names = await readdir(join(root, dir), { withFileTypes: true }).catch(() => []);
    for (const entry of names) if (entry.isFile() && isGenerated(`${dir}/${entry.name}`)) out.push(`${dir}/${entry.name}`);
  }
  return out;
}

/** A tree's entry: a generated file read-only and marked. */
const entryOf = (path: string, tracked: boolean): FileEntry => (isGenerated(path) ? { path, tracked, readOnly: true, generated: true } : { path, tracked, readOnly: false });

/** `GET tree`. */
export async function listTree(context: FilesContext, now = Date.now): Promise<FilesAnswer> {
  const { root } = context;
  const repos = gitRoots(root);
  if (!(await isRepo(gitOf(context, root)))) {
    const files: string[] = [];
    for (const r of TREE_ROOTS) await walkFiles(root, r, files);
    for (const f of TREE_FILES) if (await stat(join(root, f)).then((info) => info.isFile(), () => false)) files.push(f);
    return { at: now(), root, files: files.filter((p) => !excluded(p)).sort(comparePaths).map((path) => entryOf(path, false)) };
  }
  const nested = repos.slice(1).map((r) => r.prefix);
  const entries = new Map<string, boolean>();
  await Promise.all(
    repos.map(async (repo, i) => {
      const git = gitOf(context, repo.root);
      const [staged, deleted, others] = await Promise.all([git(['ls-files', '-z', '--stage']), git(['ls-files', '-z', '--deleted']), git(['ls-files', '-z', '--others', '--exclude-standard'])]);
      const gone = new Set(zsplit(deleted.stdout));
      const own = (p: string): string => repo.prefix + p;
      /** The project's own repository says nothing of a nested one's files: that one does. */
      const theirs = (p: string): boolean => i === 0 && nested.some((n) => p === n.slice(0, -1) || p.startsWith(n));
      for (const line of zsplit(staged.stdout)) {
        const tab = line.indexOf('\t');
        const mode = line.slice(0, line.indexOf(' '));
        const path = line.slice(tab + 1);
        // A gitlink (a submodule) is no file; one deleted from the disk is nothing to open.
        if (mode === '160000' || gone.has(path) || theirs(path)) continue;
        entries.set(own(path), true);
      }
      for (const path of zsplit(others.stdout)) {
        const p = own(path);
        if (theirs(path) || !underRoots(p) || entries.has(p)) continue;
        entries.set(p, false);
      }
    }),
  );
  // The generated files git ignores, listed read-only all the same: the person may read keys.d.ts.
  for (const path of await generatedThere(root)) if (!entries.has(path)) entries.set(path, false);
  const files: FileEntry[] = [...entries]
    .filter(([p]) => !excluded(p))
    .sort(([a], [b]) => comparePaths(a, b))
    .map(([path, tracked]) => entryOf(path, tracked));
  return { at: now(), root, files };
}

// ---------------------------------------------------------------- one file

/** A path's form: relative, `/` only, no empty, `.` or `..` part, no `\` or NUL. 400 else; `.git` anywhere is 404. */
export function pathForm(raw: unknown): string {
  if (typeof raw !== 'string' || raw === '') throw new Refused(400, 'path is the file, relative to the project root');
  if (raw.includes('\0') || raw.includes('\\')) throw new Refused(400, `${JSON.stringify(raw)}: a path here has / between its names, and no \\ or NUL`);
  if (raw.startsWith('/') || /^[a-zA-Z]:/.test(raw)) throw new Refused(400, `${raw}: a path is relative to the project root`);
  for (const segment of raw.split('/')) {
    if (segment === '' || segment === '.' || segment === '..') throw new Refused(400, `${raw}: a path has no empty, . or .. part`);
    if (segment === '.git') throw new Refused(404, `${raw}: not a file the card shows`);
  }
  return raw;
}

const inside = (path: string, dir: string): boolean => path === dir || path.startsWith(dir.endsWith(sep) ? dir : dir + sep);

/** The path's real place inside the root, a link followed: 403 when it leads out (but under `node_modules/`, read-only anyway, unless `strict`). */
export async function staysInside(root: string, path: string, strict = false): Promise<void> {
  // `strict` (a copy's source): no exemption -- nothing outside the project is copied in.
  if (!strict && path.split('/').includes('node_modules')) return;
  const realRoot = await realpath(root);
  let probe = path;
  for (;;) {
    try {
      const real = await realpath(join(root, probe));
      if (!inside(real, realRoot)) throw new Refused(403, `${path} leads out of the project`);
      return;
    } catch (err) {
      if (err instanceof Refused) throw err;
      if (!probe.includes('/')) return;
      probe = probe.slice(0, probe.lastIndexOf('/'));
    }
  }
}

/** The repository a project path belongs to, and the path as that repository's folder names it. */
function repoOf(root: string, path: string): { repo: GitRoot; rel: string } {
  const repos = gitRoots(root);
  for (let i = repos.length - 1; i > 0; i--) if (path.startsWith(repos[i]!.prefix)) return { repo: repos[i]!, rel: path.slice(repos[i]!.prefix.length) };
  return { repo: repos[0]!, rel: path };
}

/** Is the path tracked by its repository's git, and ignored by it. */
async function gitSays(context: FilesContext, path: string): Promise<{ tracked: boolean; ignored: boolean; git: boolean }> {
  const { repo, rel } = repoOf(context.root, path);
  const git = gitOf(context, repo.root);
  const tracked = await git(['ls-files', '--error-unmatch', '--', rel]);
  if (tracked.code === 0) return { tracked: true, ignored: false, git: true };
  if (tracked.code === 127 || /not a git repository/i.test(tracked.stderr)) return { tracked: false, ignored: false, git: false };
  const ignored = await git(['check-ignore', '-q', '--', rel]);
  return { tracked: false, ignored: ignored.code === 0, git: true };
}

/** What the card may do with a path: tracked, and read-only. */
export async function access(context: FilesContext, path: string): Promise<{ tracked: boolean; readOnly: boolean }> {
  const said = await gitSays(context, path);
  if (excluded(path) || isGenerated(path)) return { tracked: said.tracked, readOnly: true };
  if (said.tracked) return { tracked: true, readOnly: false };
  return { tracked: false, readOnly: !underRoots(path) || said.ignored };
}

/** Text from bytes, or why not: 413 over the limit, 415 a NUL in its first 8 KB. */
function textOf(path: string, bytes: Buffer): string {
  if (bytes.length > FILE_LIMIT) throw new Refused(413, `${path} is over ${FILE_LIMIT / (1024 * 1024)} MB: not for the card`);
  if (bytes.subarray(0, SNIFF).includes(0)) throw new Refused(415, `${path} is binary`);
  return bytes.toString('utf8');
}

/** The ref of a turn's snapshot: a turn id is a UUID (`changes.ts`' `turnId`). */
export function turnRef(turn: string, port: number): string {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(turn)) throw new Refused(400, `at is HEAD, a commit or a turn's id, not ${turn}`);
  return `${snapshotsOf(port)}${turn}`;
}

/**
 * A commit `at` may name (the Git card's log): `HEAD`, or a hash of 7 to 40 hex digits, either followed by `^` or
 * `~<n>` steps back (`a1b2c3d^`, the commit before) -- no `/`, no `..`, no ref's name, nothing git would read as
 * an option or a range. The words alone; whether the repository has it, `git rev-parse --verify` says.
 */
export const COMMIT_AT = /^(?:HEAD|[0-9a-f]{7,40})(?:\^|~[0-9]{1,4})*$/i;

/** `at` as the object git reads the path from: a commit (`COMMIT_AT`), or a turn's snapshot ref; 400 anything else. */
export function atRef(at: string, port: number): string {
  return COMMIT_AT.test(at) ? at : turnRef(at, port);
}

/** `GET file?path=&at=`. `port`, the dev server's: its turns' refs. */
export async function readProjectFile(context: FilesContext & { port: number }, raw: unknown, at?: string | null): Promise<FileAnswer> {
  const path = pathForm(raw);
  await staysInside(context.root, path);
  const { tracked, readOnly } = await access(context, path);
  if (at !== undefined && at !== null && at !== '') {
    const ref = atRef(at, context.port);
    const { repo, rel } = repoOf(context.root, path);
    const git = gitOf(context, repo.root);
    // `./` is the repository's own working folder: a project inside a larger repository names its paths from its own root.
    const shown = await blobBytes(git, path, `${ref}:./${rel}`);
    if (shown === null) throw new Refused(404, `${path} is not in ${COMMIT_AT.test(at) ? at : `the turn's snapshot`}`);
    return { path, tracked, readOnly: true, text: textOf(path, shown), mtime: null, at };
  }
  let bytes: Buffer;
  let mtime: number;
  try {
    const info = await stat(join(context.root, path));
    if (!info.isFile()) throw new Refused(404, `${path} is no file`);
    if (info.size > FILE_LIMIT) throw new Refused(413, `${path} is over ${FILE_LIMIT / (1024 * 1024)} MB: not for the card`);
    bytes = await readFile(join(context.root, path));
    mtime = info.mtimeMs;
  } catch (err) {
    if (err instanceof Refused) throw err;
    throw new Refused(404, `${path} is not there`);
  }
  return { path, tracked, readOnly, text: textOf(path, bytes), mtime };
}

/**
 * A blob's bytes (`<ref>:<path>`), never through a string -- it may be binary, or text in no UTF-8: its size
 * first (413 over `FILE_LIMIT`, before any of it is read), then `git cat-file blob` into a temp file, read and
 * taken away -- raw, with no textconv, and a tree refused by git, where `git show` would print its listing
 * (404 "is no file"). Null when git has no such object.
 */
async function blobBytes(git: Git, path: string, object: string): Promise<Buffer | null> {
  const size = await git(['cat-file', '-s', object]);
  if (size.code !== 0) return null;
  if (Number(size.stdout.trim()) > FILE_LIMIT) throw new Refused(413, `${path} is over ${FILE_LIMIT / (1024 * 1024)} MB: not for the card`);
  // In the OS's temp folder, not the project's: no watcher sees it.
  const temp = join(tmpdir(), `vibe-blob-${randomUUID()}`);
  try {
    const shown = await git(['cat-file', 'blob', object], { out: temp });
    // The object is there (its size was): no blob of it is a folder ("bad file"), 404 as the disk's.
    if (shown.code !== 0) throw new Refused(404, `${path} is no file`);
    return await readFile(temp);
  } finally {
    await rm(temp, { force: true });
  }
}

/** The conversations' running turns' files: path (the project's) to the conversation writing it. */
export type WritingNow = () => ReadonlyMap<string, { id: string; title: string }>;

/** `PUT file { path, text, ifMtime }`: the new mtime. */
export async function writeProjectFile(context: FilesContext & { writingNow?: WritingNow }, body: Record<string, unknown>): Promise<SavedAnswer> {
  const path = pathForm(body.path);
  if (typeof body.text !== 'string') throw new Refused(400, 'text is the file, whole');
  const ifMtime = body.ifMtime;
  if (ifMtime !== null && typeof ifMtime !== 'number') throw new Refused(400, 'ifMtime is the mtime the text was read at, or null for a new file');
  if (Buffer.byteLength(body.text, 'utf8') > FILE_LIMIT) throw new Refused(413, `the text is over ${FILE_LIMIT / (1024 * 1024)} MB`);
  await staysInside(context.root, path);
  const { readOnly } = await access(context, path);
  if (readOnly) throw new Refused(403, `${path} is read-only here`);
  const writer = context.writingNow?.().get(path);
  if (writer) {
    const locked: FileLocked = { why: `"${writer.title}" is writing ${path}: save once its turn ends`, conversation: writer };
    throw new Refused(423, locked.why, locked as unknown as Record<string, unknown>);
  }
  const file = join(context.root, path);
  let now: { mtime: number; mode: number } | null = null;
  try {
    const info = await stat(file);
    if (!info.isFile()) throw new Refused(403, `${path} is no file`);
    now = { mtime: info.mtimeMs, mode: info.mode };
  } catch (err) {
    if (err instanceof Refused) throw err;
  }
  if (now === null ? ifMtime !== null : ifMtime !== now.mtime) {
    const text = now === null ? '' : await readFile(file, 'utf8');
    const conflict: FileConflict = { why: now === null ? `${path} is gone since it was read` : ifMtime === null ? `${path} is there already` : `${path} changed since it was read`, text, mtime: now?.mtime ?? 0 };
    throw new Refused(412, conflict.why, conflict as unknown as Record<string, unknown>);
  }
  // A new file's folder must be there: the card saves files, it does not make folders. `stat`, not `lstat`: a
  // folder that is a link inside the root (`staysInside` let it by) is a folder.
  try {
    if (!(await stat(dirname(file))).isDirectory()) throw new Error('no folder');
  } catch {
    throw new Refused(404, `${dirname(path)} is not there`);
  }
  await writeAtomic(file, body.text, { mode: now?.mode, sync: true });
  return { mtime: (await stat(file)).mtimeMs };
}

// ---------------------------------------------------------------- the push

/**
 * A watcher's paths, coalesced: a path's events within `ms` are one `changed` call, with its mtime then (null:
 * gone) -- and none when that is what was told last for it (the watcher may say one write twice, apart).
 */
export interface FileChanges {
  /** A watcher event for an absolute path. */
  saw(file: string): void;
  /** Nothing waiting any more: the server closing. */
  stop(): void;
}

export function fileChanges(options: {
  root: string;
  changed(path: string, mtime: number | null): void;
  ms?: number;
  setTimer?: (run: () => void, ms: number) => unknown;
  clearTimer?: (timer: unknown) => void;
  stat?: (file: string) => Promise<{ mtimeMs: number; isFile(): boolean }>;
}): FileChanges {
  const { root } = options;
  const ms = options.ms ?? 50;
  const setTimer = options.setTimer ?? ((run, t) => setTimeout(run, t));
  const clearTimer = options.clearTimer ?? ((t) => clearTimeout(t as ReturnType<typeof setTimeout>));
  const statOf = options.stat ?? stat;
  const waiting = new Map<string, unknown>();
  /** What each path was last told as. */
  const told = new Map<string, number | null>();
  const tell = (path: string, mtime: number | null): void => {
    if (told.has(path) && told.get(path) === mtime) return;
    told.set(path, mtime);
    options.changed(path, mtime);
  };
  // One spelling of both (`resolve`): a watcher's path on Windows may come with `/` or `\`.
  const base = resolve(root);
  const prefix = base.endsWith(sep) ? base : base + sep;
  return {
    saw(file) {
      const full = resolve(file);
      if (!full.startsWith(prefix)) return;
      const path = full.slice(prefix.length).split(sep).join('/');
      if (path === '' || excluded(path) || path.split('/').includes('.git')) return;
      // A save's own temp file (`writeAtomic`'s), there for a moment: a name the card never heard of.
      if (isTempName(path.slice(path.lastIndexOf('/') + 1))) return;
      if (waiting.has(path)) return;
      waiting.set(
        path,
        setTimer(() => {
          waiting.delete(path);
          statOf(file).then(
            (info) => info.isFile() && tell(path, info.mtimeMs),
            () => tell(path, null),
          );
        }, ms),
      );
    },
    stop() {
      for (const t of waiting.values()) clearTimer(t);
      waiting.clear();
    },
  };
}
