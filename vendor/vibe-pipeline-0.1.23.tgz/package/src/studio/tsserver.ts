/**
 * The Code card's TypeScript bridge (Docs/studio.md): one language server for the project, shared by this
 * machine's tabs over Vite's websocket (`TS_REQ`/`TS_RES`/`TS_EVENT`, `api-types.ts`).
 *
 * **Named `tsserver.ts`, speaking LSP.** TypeScript 7 -- the native build, this workspace's and every
 * template project's -- has no `tsserver.js`: its language server is the platform binary (`@typescript/
 * typescript-<platform>-<arch>/lib/tsc`, found through the project's own `typescript/lib/getExePath.js`) run with
 * `--lsp --stdio`, which speaks the Language Server Protocol -- JSON-RPC in `Content-Length` frames on stdio.
 * A project on an older TypeScript (no `getExePath.js`) gets `TsStatus { state: 'failed', why }`, never a crash.
 *
 * - **Spawned at the first message that needs it**, never at the server's start: `vibe/status` answers with
 *   nothing spawned (`off`). In the project's root. The bridge owns the handshake -- `initialize` (the root as
 *   `rootUri` and the one workspace folder, the capabilities the card uses), then `initialized` -- and a tab's
 *   messages wait for it (`starting`) and go in order once it is `up`; no answer to `initialize` within
 *   `INIT_TIMEOUT` of the spawn stops it, `failed`. The server's own requests are the bridge's to answer
 *   (`client/registerCapability` and `window/workDoneProgress/create` with null, `workspace/configuration` with a
 *   null per item asked); its `window/logMessage` and `telemetry/event` are dropped (the `debug` sink).
 * - **Ids per socket**: a tab's request ids are renumbered to the bridge's own seq on the way to the server and
 *   restored on the way back (`createIdMap`), so two tabs' `id: 1` never meet; `$/cancelRequest` goes through
 *   the same map. A request unanswered for `TS_TIMEOUT` ms is answered `TS_TIMED_OUT` (and cancelled on the
 *   server). A socket closed: its requests dropped (cancelled), its files closed on the server.
 * - **Ownership** (`createOwners`): `vibe/open` makes a tab a file's owner when nobody holds it (its `didOpen`
 *   forwarded) or a reader (`heldBy: 'tab N'`, nothing forwarded); the owner's `vibe/open` again forwards no
 *   `didOpen` but, when its version is newer than the last the server was sent, the text whole in a `didChange`.
 *   Only the owner's `didChange` and `didClose` reach the server; `didClose` (or the owner's socket closing) lets
 *   the file go, and the next `vibe/open` of it -- a former reader's -- owns it. Every other notification from a
 *   tab is dropped.
 * - **A reader that never owns** (`vibe/open` with `read: true`: the studio's MCP tools, `ts-client.ts`): a file a
 *   tab owns is read as that tab's text; one nobody owns is lent -- opened on the server with the reader's text,
 *   owned by no socket -- until its `vibe/release`. A tab opening a lent file owns it as ever (the server's copy
 *   closed and opened again at the tab's text and version); an owner letting go of a file still lent opens it again
 *   at the lent text. So a tab never waits on such a reader, and never stays one behind it.
 * - **To a file's owner** (`toOwner`): the bridge's own `vibe/applyEdits`, a move's import edits for a file a tab holds
 *   (`file-ops.ts`), to that tab alone -- the server answered for its text, so its model takes them.
 * - **Events down**: `textDocument/publishDiagnostics` to the owner of its `uri` alone; a notification naming no
 *   file to every page socket. The bridge's own `vibe/status` notification (`params` a `TsStatus`) goes to every
 *   page socket at each change of state: a tab hearing `up` after a `failed` opens its files again (a crashed
 *   server forgot them, and the ownership table is cleared with it).
 * - **The server gone** (spawn failed, crashed): every pending request answered `TS_DOWN` with the reason,
 *   `failed`; the next message respawns it -- at most once a minute -- and a crash is logged
 *   (`[studio] TypeScript's server exited (code N)`).
 * - **Only this machine's page sockets** may use it: a `TS_REQ` from any other is answered `TS_REFUSED` (the
 *   caller says which are, `vite.ts`' `studioSockets().has`).
 *
 * The bridge and its child live on the studio holder (`vite.ts`), so an in-process restart keeps the server;
 * the server's close (of the current generation) and the process's exit stop it. The pure parts -- the frame
 * reader and writer, the id map, the ownership table -- are exported and tested on their own
 * (`tsserver.test.ts`), and the bridge runs over a stand-in child and sockets there. Nothing at module level.
 */
import { spawn as nodeSpawn } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { basename, dirname, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { TS_DOWN, TS_EVENT, TS_REFUSED, TS_RES, TS_TIMED_OUT, TS_TIMEOUT, type TsOpenAnswer, type TsStatus } from './api-types.ts';

// ---------------------------------------------------------------- framing

/**
 * A reader of `Content-Length` framed messages: fed the bytes as they come, it calls `message` with each
 * whole message, parsed. A frame split across chunks waits for the rest; two in one chunk are two calls. The
 * headers end at a blank line (`\r\n\r\n`, or `\n\n` from a lax writer). A frame whose body is no JSON is
 * passed to `bad` and skipped. The chunks are kept in a list, not joined at each one: a frame's headers are
 * searched for in the new bytes alone (and the three before them), and its body joined once, when whole -- a
 * multi-MB answer in 64 KB chunks is read in linear time.
 */
export function createFrameReader(message: (value: unknown) => void, bad: (why: string) => void = () => {}): (chunk: Buffer | string) => void {
  /** The bytes not yet read, in the chunks they came in. */
  let chunks: Buffer[] = [];
  let held = 0;
  /** How far the head of `chunks` has been searched for the headers' end, with no end found. */
  let scanned = 0;
  /** The size of the body being read, once its frame's headers are read. */
  let body: number | null = null;
  /** The first `n` bytes held, as one buffer (the list joined into one chunk, kept so). */
  const head = (n: number): Buffer => {
    if (n === 0) return Buffer.alloc(0);
    if (chunks[0]!.length < n) chunks = [Buffer.concat(chunks)];
    return chunks[0]!.subarray(0, n);
  };
  /** The first `n` bytes dropped. */
  const drop = (n: number): void => {
    held -= n;
    while (n > 0) {
      const first = chunks[0]!;
      if (first.length <= n) {
        chunks.shift();
        n -= first.length;
      } else {
        chunks[0] = first.subarray(n);
        n = 0;
      }
    }
  };
  /** The end of the headers and the blank line's length, searched for from `scanned` on; null when not there yet. */
  const headersEnd = (): { end: number; skip: number } | null => {
    // Only the headers are searched: a list of small chunks is joined until they end. They are short.
    const all = head(held);
    const from = Math.max(0, scanned - 3);
    const crlf = all.indexOf('\r\n\r\n', from);
    const lf = all.indexOf('\n\n', from);
    scanned = all.length;
    if (crlf >= 0 && (lf < 0 || crlf < lf)) return { end: crlf, skip: 4 };
    if (lf >= 0) return { end: lf, skip: 2 };
    return null;
  };
  return (chunk) => {
    const bytes = typeof chunk === 'string' ? Buffer.from(chunk, 'utf8') : chunk;
    if (bytes.length === 0) return;
    chunks.push(bytes);
    held += bytes.length;
    for (;;) {
      if (body === null) {
        if (held === 0) return;
        const found = headersEnd();
        if (found === null) return;
        const headers = head(found.end).toString('ascii');
        const length = /(?:^|\n)\s*content-length\s*:\s*(\d+)/i.exec(headers);
        drop(found.end + found.skip);
        scanned = 0;
        if (!length) {
          bad(`a frame with no Content-Length: ${JSON.stringify(headers.slice(0, 80))}`);
          continue;
        }
        body = Number(length[1]);
      }
      if (held < body) return;
      const text = head(body).toString('utf8');
      drop(body);
      body = null;
      try {
        message(JSON.parse(text));
      } catch {
        bad(`a frame whose body is no JSON: ${JSON.stringify(text.slice(0, 80))}`);
      }
    }
  };
}

/** One message as a frame: its `Content-Length` (bytes, UTF-8) header, a blank line, the JSON. */
export function frame(message: unknown): Buffer {
  const body = Buffer.from(JSON.stringify(message), 'utf8');
  return Buffer.concat([Buffer.from(`Content-Length: ${body.length}\r\n\r\n`, 'ascii'), body]);
}

// ---------------------------------------------------------------- the id map

/** A JSON-RPC id, as a tab may send one. */
export type RpcId = number | string;

/** Each tab's request ids against the bridge's own seq: out to the server renumbered, back restored. */
export interface IdMap<S> {
  /** A tab's request going out: the seq the server sees. */
  out(socket: S, id: RpcId): number;
  /** The server's answer coming back: whose, and the tab's id; undefined for a seq the map has none of (gone, or the bridge's own). The entry is spent. */
  back(seq: number): { socket: S; id: RpcId } | undefined;
  /** The seq a tab's id went out as, while it is pending (`$/cancelRequest`, a timeout). */
  seqOf(socket: S, id: RpcId): number | undefined;
  /** A seq given up (timed out): forgotten. */
  forget(seq: number): void;
  /** A socket gone: its pending seqs, forgotten. */
  drop(socket: S): number[];
  /** The bridge's own next seq, for a request of its own (`initialize`). */
  next(): number;
  /** Everything pending, forgotten: the server went. */
  clear(): { socket: S; id: RpcId; seq: number }[];
}

export function createIdMap<S>(): IdMap<S> {
  let seq = 0;
  const bySeq = new Map<number, { socket: S; id: RpcId }>();
  const bySocket = new Map<S, Map<RpcId, number>>();
  const forget = (n: number): void => {
    const entry = bySeq.get(n);
    if (!entry) return;
    bySeq.delete(n);
    const mine = bySocket.get(entry.socket);
    mine?.delete(entry.id);
    if (mine?.size === 0) bySocket.delete(entry.socket);
  };
  return {
    out(socket, id) {
      const old = bySocket.get(socket)?.get(id);
      if (old !== undefined) forget(old);
      const n = ++seq;
      bySeq.set(n, { socket, id });
      let mine = bySocket.get(socket);
      if (!mine) bySocket.set(socket, (mine = new Map()));
      mine.set(id, n);
      return n;
    },
    back(n) {
      const entry = bySeq.get(n);
      if (entry) forget(n);
      return entry;
    },
    seqOf: (socket, id) => bySocket.get(socket)?.get(id),
    forget,
    drop(socket) {
      const seqs = [...(bySocket.get(socket)?.values() ?? [])];
      for (const n of seqs) forget(n);
      return seqs;
    },
    next: () => ++seq,
    clear() {
      const all = [...bySeq].map(([n, e]) => ({ ...e, seq: n }));
      bySeq.clear();
      bySocket.clear();
      return all;
    },
  };
}

// ---------------------------------------------------------------- ownership

/** Which tab holds each open file: the one whose `didOpen` the server has, whose edits it hears. */
export interface Owners<S> {
  /** `vibe/open`: this socket owns the file now (`owner: true`, open it on the server), or another does (`holder`). */
  open(uri: string, socket: S): { owner: true } | { owner: false; holder: S };
  owner(uri: string): S | undefined;
  /** The owner's `didClose`: let go; false when `socket` is not its owner (nothing to forward). */
  release(uri: string, socket: S): boolean;
  /** A socket gone: the files it owned, let go. */
  drop(socket: S): string[];
  /** Everything let go: the server went, and forgot every file. */
  clear(): void;
}

export function createOwners<S>(): Owners<S> {
  const owners = new Map<string, S>();
  return {
    open(uri, socket) {
      const holder = owners.get(uri);
      if (holder !== undefined && holder !== socket) return { owner: false, holder };
      owners.set(uri, socket);
      return { owner: true };
    },
    owner: (uri) => owners.get(uri),
    release(uri, socket) {
      if (owners.get(uri) !== socket) return false;
      owners.delete(uri);
      return true;
    },
    drop(socket) {
      const mine = [...owners].filter(([, s]) => s === socket).map(([uri]) => uri);
      for (const uri of mine) owners.delete(uri);
      return mine;
    },
    clear: () => owners.clear(),
  };
}

// ---------------------------------------------------------------- the server's process

/** The language server's process, as the bridge uses it: Node's `ChildProcess`, or a test's stand-in. */
export interface TsChild {
  readonly stdin: { write(chunk: Buffer): unknown } | null;
  readonly stdout: { on(event: 'data', listener: (chunk: Buffer) => void): unknown } | null;
  readonly stderr?: { on(event: 'data', listener: (chunk: Buffer) => void): unknown } | null;
  on(event: 'exit', listener: (code: number | null, signal: NodeJS.Signals | null) => void): unknown;
  on(event: 'error', listener: (err: Error) => void): unknown;
  kill(signal?: NodeJS.Signals): boolean;
}

/** The project's TypeScript: its version, and the language server's executable -- or why there is none. */
export async function projectLsp(root: string): Promise<{ exe: string; version?: string }> {
  let pkg: string;
  try {
    pkg = createRequire(join(root, 'package.json')).resolve('typescript/package.json');
  } catch {
    throw new Error('TypeScript 7 is needed for the Code card: this project has no typescript installed (npm install)');
  }
  const version = typescriptVersion(pkg);
  const getExePath = join(dirname(pkg), 'lib', 'getExePath.js');
  if (!existsSync(getExePath)) throw new Error(`TypeScript 7 is needed for the Code card's language server: this project has TypeScript ${version ?? '(unknown)'}`);
  const module = (await import(pathToFileURL(getExePath).href)) as { default: () => string };
  return { exe: module.default(), ...(version ? { version } : {}) };
}

function typescriptVersion(pkg: string): string | undefined {
  try {
    return (JSON.parse(readFileSync(pkg, 'utf8')) as { version?: string }).version;
  } catch {
    return undefined;
  }
}

/** The project's TypeScript version alone, for `vibe/status` with nothing spawned. */
export function projectTsVersion(root: string): string | undefined {
  try {
    return typescriptVersion(createRequire(join(root, 'package.json')).resolve('typescript/package.json'));
  } catch {
    return undefined;
  }
}

/** The real server: the project's TypeScript 7 binary with `--lsp --stdio`, in the root. */
export async function spawnLsp(root: string): Promise<TsChild> {
  const { exe } = await projectLsp(root);
  return nodeSpawn(exe, ['--lsp', '--stdio'], { cwd: root, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
}

// ---------------------------------------------------------------- the bridge

/** A page's websocket, as the bridge uses it: the raw socket Vite's `client.socket` is. */
export interface BridgeSocket {
  send(text: string): void;
}

export interface BridgeOptions {
  /** The project's root, absolute. */
  root: string;
  /** The server started (`spawnLsp`; a test's stand-in). A throw is `failed` with its message. */
  spawn?: (root: string) => Promise<TsChild>;
  /** The project's TypeScript version (`projectTsVersion`). */
  version?: () => string | undefined;
  /** The page sockets of this machine, for a notification to every tab. Re-pointed by each new server (`setPages`). */
  pages?: () => Iterable<BridgeSocket>;
  /** How long a request may take (`TS_TIMEOUT`). */
  timeout?: number;
  /**
   * How long the server may take to answer `initialize`, from its spawn (`INIT_TIMEOUT`): past it, it is stopped
   * and `failed`, and the next message respawns it (at most once a minute).
   */
  initTimeout?: number;
  /** A test's clock. */
  now?: () => number;
  setTimer?: (run: () => void, ms: number) => unknown;
  clearTimer?: (timer: unknown) => void;
  /** The log's line (`console.warn`): a crash. */
  log?: (line: string) => void;
  /** What the server said to its log, and what was dropped: nowhere unless given. */
  debug?: (line: string) => void;
  /** The least time between two spawns, ms (a minute). */
  respawnAfter?: number;
}

export interface TsBridge {
  /** A `TS_REQ` from `socket`; `allowed` when it is one of this machine's page sockets. */
  request(socket: BridgeSocket, data: unknown, allowed: boolean): void;
  /** A socket gone: its files closed on the server, its requests dropped. */
  closed(socket: BridgeSocket): void;
  status(): TsStatus;
  /** Re-pointed by a new dev server (an in-process restart). */
  setPages(pages: () => Iterable<BridgeSocket>): void;
  /**
   * A notification of the bridge's own to the tab that owns `uri` (`vibe/applyEdits`: a move's import edits for a file a
   * tab has open, which the server never writes under it); false when no tab owns it.
   */
  toOwner(uri: string, method: string, params: unknown): boolean;
  /** The server stopped (the dev server closing, the process's exit): `off`. */
  stop(): void;
}

/** A JSON-RPC message, loosely: what the wire carries. */
interface Rpc {
  jsonrpc?: string;
  id?: RpcId | null;
  method?: string;
  params?: unknown;
  result?: unknown;
  error?: unknown;
}

const isRpc = (value: unknown): value is Rpc => typeof value === 'object' && value !== null && !Array.isArray(value);
const hasId = (m: Rpc): m is Rpc & { id: RpcId } => typeof m.id === 'number' || typeof m.id === 'string';
const paramsOf = (m: Rpc): Record<string, unknown> => (isRpc(m.params) ? (m.params as Record<string, unknown>) : {});
/** The file a message names: `params.textDocument.uri`, or `params.uri` (publishDiagnostics). */
function uriOf(m: Rpc): string | undefined {
  const p = paramsOf(m);
  const doc = p.textDocument;
  if (isRpc(doc) && typeof (doc as { uri?: unknown }).uri === 'string') return (doc as { uri: string }).uri;
  return typeof p.uri === 'string' ? p.uri : undefined;
}

/** The capabilities the card uses, said in `initialize`. */
const CLIENT_CAPABILITIES = {
  textDocument: {
    synchronization: { dynamicRegistration: false, didSave: false },
    publishDiagnostics: { relatedInformation: true, versionSupport: true },
    completion: { completionItem: { snippetSupport: false, documentationFormat: ['markdown', 'plaintext'], resolveSupport: { properties: ['documentation', 'detail', 'additionalTextEdits'] } }, contextSupport: true },
    hover: { contentFormat: ['markdown', 'plaintext'] },
    signatureHelp: { signatureInformation: { documentationFormat: ['markdown', 'plaintext'], parameterInformation: { labelOffsetSupport: true } } },
    definition: { linkSupport: false },
    typeDefinition: { linkSupport: false },
    references: {},
    rename: { prepareSupport: true },
    codeAction: { codeActionLiteralSupport: { codeActionKind: { valueSet: ['', 'quickfix', 'refactor', 'source', 'source.organizeImports'] } }, resolveSupport: { properties: ['edit'] } },
    formatting: {},
    diagnostic: { dynamicRegistration: false, relatedDocumentSupport: false },
  },
  // `workspace/willRenameFiles`: a file moved or renamed in the Code card, its imports and the imports of it updated (`file-ops.ts`).
  workspace: { configuration: true, workspaceFolders: true, fileOperations: { willRename: true, didRename: true } },
  window: { workDoneProgress: false },
  general: { positionEncodings: ['utf-16'] },
};

/** Notifications of the server's that no tab hears. */
const DROPPED = new Set(['window/logMessage', 'telemetry/event', '$/logTrace']);

/** A tab's notifications that reach the server, from the file's owner alone. */
const OWNER_NOTIFICATIONS = new Set(['textDocument/didChange', 'textDocument/didClose']);

/** Methods a tab may never send: the handshake and the shutdown are the bridge's. */
const BRIDGE_ONLY = new Set(['initialize', 'initialized', 'shutdown', 'exit']);

/**
 * The time a spawned server has to answer `initialize`, ms: a minute, not `TS_TIMEOUT`'s 30 s -- a cold start
 * (the binary's first load from a cold disk, the project's tsconfig and its files read before the answer) is
 * slower than any one request, and a server that is merely slow must not be killed and refused for a minute.
 * A tab's requests queued behind it still time out at `TS_TIMEOUT` each.
 */
export const INIT_TIMEOUT = 60_000;

export function createBridge(options: BridgeOptions): TsBridge {
  const { root } = options;
  const spawn = options.spawn ?? spawnLsp;
  const timeout = options.timeout ?? TS_TIMEOUT;
  const initTimeout = options.initTimeout ?? INIT_TIMEOUT;
  const now = options.now ?? Date.now;
  const setTimer = options.setTimer ?? ((run, ms) => setTimeout(run, ms));
  const clearTimer = options.clearTimer ?? ((t) => clearTimeout(t as ReturnType<typeof setTimeout>));
  const log = options.log ?? ((line) => console.warn(line));
  const debug = options.debug ?? (() => {});
  const respawnAfter = options.respawnAfter ?? 60_000;
  let pages = options.pages ?? (() => []);

  const ids = createIdMap<BridgeSocket>();
  const owners = createOwners<BridgeSocket>();
  /** Files lent to readers that never own (`read: true`) while no tab owned them: by uri, how many hold them and the text the first gave. */
  const lent = new Map<string, { count: number; text: string; languageId: string }>();
  const openOnServer = (uri: string, text: string, version: number, languageId: string): void => {
    versions.set(uri, version);
    toServer({ jsonrpc: '2.0', method: 'textDocument/didOpen', params: { textDocument: { uri, text, version, languageId } } });
  };
  /** An owner let go of `uri` (its didClose forwarded): a file still lent is opened again at the lent text. */
  const relend = (uri: string): void => {
    const l = lent.get(uri);
    if (l) openOnServer(uri, l.text, 0, l.languageId);
  };
  /** The last version the server was sent of each open file (`didOpen`, the owner's `didChange`), by uri. */
  const versions = new Map<string, number>();
  /** Each request's timer, by seq. */
  const timers = new Map<number, unknown>();
  /** A short name for each socket, by the order it was first heard: `tab 1`, `tab 2`. */
  const names = new Map<BridgeSocket, string>();
  let named = 0;
  let state: TsStatus['state'] = 'off';
  let why: string | undefined;
  let child: TsChild | null = null;
  /** Messages for the server while it starts, in order. */
  let queue: Rpc[] = [];
  let lastSpawn = -Infinity;
  /** The seq of the bridge's `initialize`. */
  let initSeq = -1;
  /** The deadline of the `initialize` answer (`initTimeout`), while it is awaited. */
  let initTimer: unknown;
  /** Which spawn the events are of: a dead child's late output is not the new one's. */
  let generation = 0;
  /** The last 20 lines the server wrote to stderr, for a crash's words. */
  let stderr: string[] = [];

  const nameOf = (socket: BridgeSocket): string => {
    let name = names.get(socket);
    if (!name) names.set(socket, (name = `tab ${++named}`));
    return name;
  };
  const sendTo = (socket: BridgeSocket, event: string, message: unknown): void => {
    try {
      socket.send(JSON.stringify({ type: 'custom', event, data: { message } }));
    } catch {
      // Gone: its close says so.
    }
  };
  const answer = (socket: BridgeSocket, id: RpcId, result: unknown): void => sendTo(socket, TS_RES, { jsonrpc: '2.0', id, result });
  const fail = (socket: BridgeSocket, id: RpcId, code: number, message: string): void => sendTo(socket, TS_RES, { jsonrpc: '2.0', id, error: { code, message } });
  const status = (): TsStatus => {
    const version = (options.version ?? (() => projectTsVersion(root)))();
    return { state, root, ...(version ? { version } : {}), ...(state === 'failed' && why ? { why } : {}) };
  };
  const broadcast = (message: unknown): void => {
    for (const socket of pages()) sendTo(socket, TS_EVENT, message);
  };
  const announce = (): void => broadcast({ jsonrpc: '2.0', method: 'vibe/status', params: status() });

  const write = (message: Rpc): void => {
    try {
      child?.stdin?.write(frame(message));
    } catch (err) {
      debug(`[studio] writing to TypeScript's server: ${(err as Error).message}`);
    }
  };
  /** To the server: now when it is up, queued while it starts, nowhere when it is down (pending requests are answered by the down). */
  const toServer = (message: Rpc): void => {
    if (state === 'up') write(message);
    else if (state === 'starting') queue.push(message);
  };

  const clearInit = (): void => {
    if (initTimer !== undefined) clearTimer(initTimer);
    initTimer = undefined;
  };

  /** The server gone: every pending request answered `TS_DOWN`, the files forgotten, `failed`. */
  const down = (reason: string): void => {
    generation++;
    child = null;
    state = 'failed';
    why = reason;
    queue = [];
    clearInit();
    owners.clear();
    lent.clear();
    versions.clear();
    for (const t of timers.values()) clearTimer(t);
    timers.clear();
    for (const p of ids.clear()) fail(p.socket, p.id, TS_DOWN, reason);
    announce();
  };

  const fromServer = (m: Rpc): void => {
    if (m.method !== undefined && hasId(m)) {
      // The server's own request: the bridge answers.
      if (m.method === 'workspace/configuration') {
        const items = paramsOf(m).items;
        write({ jsonrpc: '2.0', id: m.id, result: Array.isArray(items) ? items.map(() => null) : [] });
      } else if (m.method === 'client/registerCapability' || m.method === 'client/unregisterCapability' || m.method === 'window/workDoneProgress/create') {
        write({ jsonrpc: '2.0', id: m.id, result: null });
      } else {
        debug(`[studio] TypeScript's server asked ${m.method}: refused`);
        write({ jsonrpc: '2.0', id: m.id, error: { code: -32601, message: `${m.method} is not handled by the bridge` } });
      }
      return;
    }
    if (m.method !== undefined) {
      // A notification.
      if (DROPPED.has(m.method)) {
        const message = paramsOf(m).message;
        if (typeof message === 'string') debug(`[tsserver] ${message}`);
        return;
      }
      const uri = uriOf(m);
      if (uri !== undefined) {
        const owner = owners.owner(uri);
        if (owner) sendTo(owner, TS_EVENT, m);
        return;
      }
      broadcast(m);
      return;
    }
    if (typeof m.id !== 'number') return;
    // An answer.
    const seq = m.id;
    if (seq === initSeq) {
      initSeq = -1;
      clearInit();
      if (m.error !== undefined) {
        const reason = `TypeScript's server refused initialize: ${JSON.stringify(m.error)}`;
        stopChild();
        down(reason);
        return;
      }
      state = 'up';
      why = undefined;
      write({ jsonrpc: '2.0', method: 'initialized', params: {} });
      const waiting = queue;
      queue = [];
      for (const q of waiting) write(q);
      announce();
      return;
    }
    const timer = timers.get(seq);
    if (timer !== undefined) {
      clearTimer(timer);
      timers.delete(seq);
    }
    const to = ids.back(seq);
    if (!to) return; // Gone, or timed out: dropped.
    sendTo(to.socket, TS_RES, { ...m, id: to.id });
  };

  const stopChild = (): void => {
    const c = child;
    child = null;
    generation++;
    if (!c) return;
    try {
      c.kill('SIGTERM');
    } catch {
      // Gone already.
    }
  };

  /** Started when it is off or failed (at most once a minute): false when it cannot be, now. */
  const ensure = (): boolean => {
    if (state === 'up' || state === 'starting') return true;
    if (now() - lastSpawn < respawnAfter) return false;
    lastSpawn = now();
    state = 'starting';
    why = undefined;
    stderr = [];
    const mine = ++generation;
    initSeq = ids.next();
    // The initialize first, before anything a tab sends: the queue begins after it.
    queue = [];
    // From the spawn, not the initialize's write: a spawn that hangs is as stuck as a server that never answers.
    clearInit();
    initTimer = setTimer(() => {
      initTimer = undefined;
      if (mine !== generation || state !== 'starting') return;
      stopChild();
      down(`TypeScript's server did not initialize in ${Math.round(initTimeout / 1000)} s`);
    }, initTimeout);
    announce();
    spawn(root).then(
      (c) => {
        if (mine !== generation) {
          // Stopped while it was spawning.
          try {
            c.kill('SIGTERM');
          } catch {
            // Gone.
          }
          return;
        }
        child = c;
        const read = createFrameReader(
          (value) => {
            if (mine === generation && isRpc(value)) fromServer(value);
          },
          (bad) => debug(`[studio] TypeScript's server: ${bad}`),
        );
        c.stdout?.on('data', read);
        c.stderr?.on('data', (chunk: Buffer) => {
          for (const line of chunk.toString('utf8').split('\n')) if (line.trim() !== '') stderr.push(line);
          if (stderr.length > 20) stderr = stderr.slice(-20);
        });
        c.on('error', (err) => {
          if (mine !== generation) return;
          down(`TypeScript's server did not start: ${err.message}`);
        });
        c.on('exit', (code, signal) => {
          if (mine !== generation) return;
          const said = `TypeScript's server exited (${signal ? `signal ${signal}` : `code ${code}`})`;
          log(`[studio] ${said}${stderr.length > 0 ? `: ${stderr[stderr.length - 1]}` : ''}`);
          down(said);
        });
        const rootUri = pathToFileURL(root).href;
        write({
          jsonrpc: '2.0',
          id: initSeq,
          method: 'initialize',
          params: { processId: process.pid, clientInfo: { name: 'squidwright' }, rootUri, workspaceFolders: [{ uri: rootUri, name: basename(root) }], capabilities: CLIENT_CAPABILITIES },
        });
      },
      (err: unknown) => {
        if (mine !== generation) return;
        down(err instanceof Error ? err.message : String(err));
      },
    );
    return true;
  };

  /** A tab's request, out to the server: renumbered, timed. */
  const forward = (socket: BridgeSocket, m: Rpc & { id: RpcId }): void => {
    const seq = ids.out(socket, m.id);
    timers.set(
      seq,
      setTimer(() => {
        timers.delete(seq);
        const to = ids.back(seq);
        if (!to) return;
        fail(to.socket, to.id, TS_TIMED_OUT, `${m.method ?? 'the request'}: no answer in ${Math.round(timeout / 1000)} s`);
        toServer({ jsonrpc: '2.0', method: '$/cancelRequest', params: { id: seq } });
      }, timeout),
    );
    toServer({ ...m, id: seq });
  };

  return {
    toOwner(uri, method, params) {
      const owner = owners.owner(uri);
      if (owner === undefined) return false;
      sendTo(owner, TS_EVENT, { jsonrpc: '2.0', method, params });
      return true;
    },
    request(socket, data, allowed) {
      const m = isRpc(data) ? (data as { message?: unknown }).message : undefined;
      if (!isRpc(m)) return;
      if (!allowed) {
        if (hasId(m)) fail(socket, m.id, TS_REFUSED, 'the TypeScript bridge answers this machine only, from its own page');
        return;
      }
      // Named by the order first heard, of this machine's sockets alone: a refused one takes no `tab N`.
      nameOf(socket);
      if (m.method === undefined) return; // A response of a tab's: the bridge answers the server's requests itself.
      if (m.method === 'vibe/status') {
        if (hasId(m)) answer(socket, m.id, status());
        return;
      }
      if (BRIDGE_ONLY.has(m.method)) {
        if (hasId(m)) fail(socket, m.id, TS_REFUSED, `${m.method} is the bridge's: it owns the handshake`);
        return;
      }
      if (!hasId(m)) {
        // A notification: the owner's edits, a cancel, a lent file given back; nothing else.
        if (m.method === 'vibe/release') {
          const uri = paramsOf(m).uri;
          const l = typeof uri === 'string' ? lent.get(uri) : undefined;
          if (!l || typeof uri !== 'string') return;
          if (--l.count > 0) return;
          lent.delete(uri);
          // Nobody else's: the server lets it go too. A tab that took it since keeps it.
          if (owners.owner(uri) === undefined) {
            versions.delete(uri);
            toServer({ jsonrpc: '2.0', method: 'textDocument/didClose', params: { textDocument: { uri } } });
          }
          return;
        }
        if (m.method === '$/cancelRequest') {
          const id = paramsOf(m).id;
          const seq = typeof id === 'number' || typeof id === 'string' ? ids.seqOf(socket, id) : undefined;
          if (seq !== undefined) toServer({ jsonrpc: '2.0', method: '$/cancelRequest', params: { id: seq } });
          return;
        }
        if (!OWNER_NOTIFICATIONS.has(m.method)) return;
        const uri = uriOf(m);
        if (uri === undefined || owners.owner(uri) !== socket) return;
        if (m.method === 'textDocument/didClose') {
          owners.release(uri, socket);
          versions.delete(uri);
        } else {
          const version = (paramsOf(m).textDocument as { version?: unknown } | undefined)?.version;
          if (typeof version === 'number') versions.set(uri, version);
        }
        toServer(m);
        if (m.method === 'textDocument/didClose') relend(uri);
        return;
      }
      if (!ensure()) {
        fail(socket, m.id, TS_DOWN, why ?? "TypeScript's server is down");
        return;
      }
      if (m.method === 'vibe/open') {
        const p = paramsOf(m);
        if (typeof p.uri !== 'string' || typeof p.text !== 'string') {
          fail(socket, m.id, -32602, 'vibe/open takes { uri, text, version, languageId }');
          return;
        }
        const languageId = typeof p.languageId === 'string' ? p.languageId : 'typescript';
        if (p.read === true) {
          // A reader that never owns: a tab's file read as its text; else lent, owned by no socket.
          const holder = owners.owner(p.uri);
          if (holder !== undefined) {
            answer(socket, m.id, { owner: false, heldBy: nameOf(holder) } satisfies TsOpenAnswer);
            return;
          }
          const l = lent.get(p.uri);
          if (l) l.count++;
          else {
            lent.set(p.uri, { count: 1, text: p.text, languageId });
            openOnServer(p.uri, p.text, 0, languageId);
          }
          answer(socket, m.id, { owner: false, lent: true } satisfies TsOpenAnswer);
          return;
        }
        if (owners.owner(p.uri) === socket) {
          // Its own again: the server has the file open already, and a second didOpen is an error in LSP. A
          // newer version than the server was sent (the tab read the file again from the disk) goes as the
          // whole text in a didChange, so the server is not left on the old one.
          const last = versions.get(p.uri);
          if (typeof p.version === 'number' && (last === undefined || p.version > last)) {
            versions.set(p.uri, p.version);
            toServer({ jsonrpc: '2.0', method: 'textDocument/didChange', params: { textDocument: { uri: p.uri, version: p.version }, contentChanges: [{ text: p.text }] } });
          }
          answer(socket, m.id, { owner: true } satisfies TsOpenAnswer);
          return;
        }
        const held = owners.open(p.uri, socket);
        if (held.owner) {
          // Lent to a reader just now: the server's copy is the reader's, closed for the tab's own text and version.
          if (lent.has(p.uri)) toServer({ jsonrpc: '2.0', method: 'textDocument/didClose', params: { textDocument: { uri: p.uri } } });
          openOnServer(p.uri, p.text, typeof p.version === 'number' ? p.version : 0, languageId);
          answer(socket, m.id, { owner: true } satisfies TsOpenAnswer);
        } else {
          answer(socket, m.id, { owner: false, heldBy: nameOf(held.holder) } satisfies TsOpenAnswer);
        }
        return;
      }
      forward(socket, m);
    },
    closed(socket) {
      for (const seq of ids.drop(socket)) {
        const t = timers.get(seq);
        if (t !== undefined) clearTimer(t);
        timers.delete(seq);
        toServer({ jsonrpc: '2.0', method: '$/cancelRequest', params: { id: seq } });
      }
      for (const uri of owners.drop(socket)) {
        versions.delete(uri);
        toServer({ jsonrpc: '2.0', method: 'textDocument/didClose', params: { textDocument: { uri } } });
        relend(uri);
      }
      names.delete(socket);
    },
    status,
    setPages(next) {
      pages = next;
    },
    stop() {
      const had = child !== null || state === 'starting';
      stopChild();
      clearInit();
      for (const t of timers.values()) clearTimer(t);
      timers.clear();
      for (const p of ids.clear()) fail(p.socket, p.id, TS_DOWN, "TypeScript's server was stopped");
      owners.clear();
      lent.clear();
      versions.clear();
      queue = [];
      state = 'off';
      why = undefined;
      lastSpawn = -Infinity;
      if (had) announce();
    },
  };
}
