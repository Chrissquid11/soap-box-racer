/**
 * Studio mode's cold start (Docs/studio.md §1, "Recovery"): **the editor comes up even when `src/main.ts`' own module
 * graph fails.** Boot's recovery catches what fails once `boot()` runs -- the game's import, the preload, the compile.
 * But a link error (`does not provide an export named 'FULL'`), a top-level throw, or a module the dev server could not
 * serve anywhere in `main.ts`' static imports means `main.ts` never runs, so `boot()` never does, and the page sits on
 * its loader. The probe frame covers a reload mid-session; this covers the page opened, or reloaded by hand, cold.
 *
 * - **The guard** (`COLD_GUARD`, an inline classic script put first in the page's `<head>` by `transformIndexHtml`, the
 *   dev server's alone): it imports nothing of the project and runs before any module. On a `?studio` page alone it
 *   hears the window's `error` events that could be the entry's (`counts`) -- a same-origin module's link or evaluation
 *   error, and (captured) a module script's own `error`, a fetch that failed; never an image's or a stylesheet's 404, nor
 *   a foreign script's -- until boot starts (the engine's `BOOT_STARTED`, which `boot()` sets first). Once the page has
 *   loaded, such an error heard and no boot started: the entry failed, and the guard imports the recovery module with
 *   the first one. A `boot()` coming after all (`main.ts` late, a top-level await) is refused by the engine: one game.
 * - **The recovery module** (`COLD_RECOVERY_ID`, served virtual, `recoveryModule`): the project's `bundle.ts` (its
 *   assets, a failure of its own let go), then the engine's own `boot()` called with what `main.ts` would have handed it
 *   -- its name the package's (`package.json`'s `name`: a guess at what `main.ts` says, only the settings' key and the
 *   editor's title hang on it), its title the page's `<title>` (`pageTitle`), the editor's import, the project's tools where it has them
 *   -- and the error as the game's import's rejection. That is boot's recovery, as it is for a game that does not load:
 *   the stand-in game, the editor with the error as its boot notice, the Code card and Claude to fix it, the reload
 *   when the fix lands. Nothing of a second recovery.
 * - **Not otherwise**: a release build has no dev server and so no guard; a plain dev page (no `?studio`) is as ever --
 *   the guard returns at once. It is no key listener, and the editor's import is the virtual module's, served by the
 *   dev server, never in the project's bundle (`debugGuard`, the `routes` check).
 *
 * No Vite at run time, no DOM: `cold-start.test.ts` runs the guard's own text over a stand-in window.
 */
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { Plugin } from 'vite';

/** The global `boot()` sets as it starts: the engine's `BOOT_STARTED` (`boot-steps.ts`) is `Symbol.for` this name. */
export const BOOT_GLOBAL = 'vibebase.boot';

/** The recovery module's id (`recoveryModule`): served at `<base>@id/__x00__<id>`, Vite's form for a virtual module. */
export const COLD_RECOVERY_ID = 'vibe:cold-recovery';

/**
 * The guard, as source: `coldGuard(win, load, url)` -- `win` the window, `load` the page's `import()`, `url` the
 * recovery module's. Its decision is `decide`: recover once, after the page's load, an error heard and no boot started.
 * Only an error that could be the entry's counts (`counts`), and the first is said. An error's words name where (`at <file>:<line>`), the page's origin and a `?t=` taken off: the browser's own for a
 * link error name the module asked of, not the one asking. A recovery module that does not load says so in the loader.
 */
export const COLD_GUARD = `function coldGuard(win, load, url) {
  if (!new URLSearchParams(win.location.search).has('studio')) return;
  const BOOT = Symbol.for(${JSON.stringify(BOOT_GLOBAL)});
  const errors = [];
  let loaded = false;
  let recovering = false;
  const started = () => win[BOOT] === true;
  const decide = () => !recovering && loaded && errors.length > 0 && !started();
  const where = (file, line) => {
    const path = String(file || '').replace(win.location.origin, '').replace(/[?&]t=\\d+/, '');
    return path ? ' -- at ' + path + (line ? ':' + line : '') : '';
  };
  const counts = (e) => {
    const t = e.target;
    if (t && t !== win) return t.tagName === 'SCRIPT' && t.type === 'module';
    return typeof e.filename === 'string' && e.filename.startsWith(win.location.origin + '/');
  };
  const words = (e) => {
    const t = e.target;
    if (t && t !== win && t.tagName === 'SCRIPT') {
      const failed = new Error('Importing a module script failed: ' + where(t.src).replace(' -- at ', ''));
      failed.stack = 'Error: ' + failed.message;
      return failed;
    }
    const thrown = e.error;
    const message = thrown && thrown.message !== undefined ? thrown.message : String(e.message || thrown);
    const error = new Error(message + where(e.filename, e.lineno));
    if (thrown && thrown.name) error.name = thrown.name;
    if (thrown && thrown.stack) error.stack = error.name + ': ' + error.message + '\\n' + String(thrown.stack).split('\\n').slice(1).join('\\n');
    return error;
  };
  const go = () => {
    if (!decide()) return;
    recovering = true;
    win.console.error("[boot] the page's entry did not run (src/main.ts' imports): studio mode's recovery, the editor over a stand-in game", errors[0]);
    load(url).then((m) => m.recover(errors[0])).catch((err) => {
      win.console.error('[boot] the recovery did not load', err);
      const said = win.document.querySelector('#loader-error');
      const bar = win.document.querySelector('#loader-bar');
      if (said) { said.textContent = 'The game could not load -- ' + errors[0].message + ' (and the editor did not come up: ' + (err && err.message ? err.message : String(err)) + ')'; said.hidden = false; }
      if (bar) bar.hidden = true;
    });
  };
  win.addEventListener('error', (e) => {
    if (started() || recovering || !counts(e)) return;
    errors.push(words(e));
    if (loaded) win.setTimeout(go, 0);
  }, true);
  win.addEventListener('load', () => { loaded = true; win.setTimeout(go, 0); });
}`;

/** The guard's script tag's text: the guard called at once with this page's window and `import()`. */
export const guardScript = (url: string): string => `(${COLD_GUARD})(window, (u) => import(u), ${JSON.stringify(url)});`;

/** The page's title, its `index.html`'s `<title>`: the editor's title in recovery. None, none. */
export function pageTitle(html: string): string | undefined {
  const title = /<title[^>]*>([^<]*)<\/title>/i.exec(html)?.[1]?.trim();
  return title ? title : undefined;
}

export interface RecoveryParts {
  name: string;
  title?: string;
  /** The project's tools' entry and components, as served paths (`/src/tools/index.ts`), where it has them. */
  tools?: string;
  components?: string;
}

/**
 * The recovery module's source: `recover(error)`, which hands the project's assets in (its `bundle.ts`, a failure let
 * go: the editor comes up without them) and calls the engine's `boot()` as `main.ts` would, the error as the game's.
 */
export function recoveryModule(parts: RecoveryParts): string {
  const j = JSON.stringify;
  return `import { boot } from '@vibe/engine/boot';
export async function recover(error) {
  try {
    await import('/src/assets/bundle.ts');
  } catch (err) {
    console.error("[boot] the project's assets did not load (src/assets/bundle.ts): the editor comes up without them", err);
  }
  return boot({
    canvas: '#game',
    name: ${j(parts.name)},${parts.title !== undefined ? `\n    title: ${j(parts.title)},` : ''}
    game: () => Promise.reject(error),
    editor: () => import('@vibe/editor'), // page-code: this module is the page's, served by the dev server in main.ts' stead${parts.tools ? `\n    tools: () => import(${j(parts.tools)}),` : ''}${parts.components ? `\n    components: () => import(${j(parts.components)}),` : ''}
  });
}
`;
}

/** The parts for a project at `root`: its package's name, its page's title, its first tool folder's entry and components where they are. */
export function recoveryParts(root: string, tools: readonly string[]): RecoveryParts {
  let name = 'game';
  try {
    name = (JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')) as { name?: string }).name ?? name;
  } catch {
    // No package.json: 'game'.
  }
  const html = join(root, 'index.html');
  const title = existsSync(html) ? pageTitle(readFileSync(html, 'utf8')) : undefined;
  const names = title === undefined ? { name } : { name, title };
  const dir = tools[0];
  const served = (file: string): string | undefined => (dir !== undefined && existsSync(join(root, dir, file)) ? `/${dir.replace(/^\.?\/+|\/+$/g, '')}/${file}` : undefined);
  const index = served('index.ts');
  const components = served('components.ts');
  return { ...names, ...(index ? { tools: index } : {}), ...(components ? { components } : {}) };
}

/** The plugin, the dev server's alone: the guard first in every page's `<head>`, and the recovery module it imports. */
export function coldStart(tools: readonly string[]): Plugin {
  const resolved = `\0${COLD_RECOVERY_ID}`;
  let root = process.cwd();
  let base = '/';
  return {
    name: 'vibe:cold-start',
    apply: 'serve',
    configResolved(config) {
      root = config.root;
      base = config.base.endsWith('/') ? config.base : `${config.base}/`;
    },
    resolveId(id) {
      return id === COLD_RECOVERY_ID || id === resolved ? resolved : null;
    },
    load(id) {
      return id === resolved ? recoveryModule(recoveryParts(root, tools)) : null;
    },
    transformIndexHtml() {
      return [{ tag: 'script', children: guardScript(`${base}@id/__x00__${COLD_RECOVERY_ID}`), injectTo: 'head-prepend' }];
    },
  };
}
