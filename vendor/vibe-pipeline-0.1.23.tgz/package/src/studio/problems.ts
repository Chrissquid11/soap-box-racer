/**
 * tsc's errors, live (Docs/studio.md), for the Problems card and the top bar's
 * count: the project's own tsc (`projectTsc`, the one `vibe typecheck` runs) in watch mode, once per
 * program -- `tsconfig.json`, and `tsconfig.node.json` when the project has one -- with `--noEmit
 * --pretty false --preserveWatchOutput`, spawned once the dev server listens.
 *
 * Each line is read (`createParser`): `file(line,col): error TSxxxx: message` is a problem (the file made
 * relative to the root, posix) -- `error TSxxxx: message`, of no file, is the program's own (`file` the
 * tsconfig, line and column 0) -- an indented line after it more of its message, and `Found N error(s)`
 * ends a round -- that program's list replaced, both programs' merged and sorted by file, line and
 * column (`merge`), pushed as `studio:problems`. A round's start ("Starting compilation", "File change
 * detected") drops a half-read one.
 *
 * Always on in `vibe dev`: the cost is a tsc watch per program, tens of MB each and a recheck on a save
 * (the incremental one, fast). The processes are the holder's (`vite.ts`): stopped when the server
 * closes, and on Vite's in-process restart the old ones are stopped before the new ones start. Nothing
 * at module level.
 */
import { spawn as nodeSpawn, type ChildProcess } from 'node:child_process';
import { existsSync } from 'node:fs';
import { isAbsolute, join, relative, sep } from 'node:path';
import type { Problem } from './api-types.ts';

/** One error line of tsc's `--pretty false` output. */
export const TSC_ERROR = /^(.+?)\((\d+),(\d+)\): error (TS\d+): (.*)$/;

/** An error of no file's (a bad tsconfig, no inputs): `error TS18003: No inputs were found in config file …`. */
export const TSC_GLOBAL_ERROR = /^error (TS\d+): (.*)$/;

/** The line that ends a round: `03:12:51 AM - Found 2 errors. Watching for file changes.` */
export const TSC_FOUND = /\bFound (\d+) errors?\b/;

/** A round beginning: what was half read is dropped. */
const TSC_START = /Starting compilation|File change detected/;

/** One program's output, read a line at a time: the program's new list at each `Found` line, else null. */
export interface Parser {
  line(text: string): Problem[] | null;
}

/** A file as tsc printed it, relative to `root` with `/`. */
function relativeFile(root: string, file: string): string {
  const rel = isAbsolute(file) ? relative(root, file) : file;
  return rel.split(sep).join('/').replace(/\\/g, '/');
}

export function createParser(program: string, root: string): Parser {
  let round: Problem[] = [];
  let last: Problem | null = null;
  return {
    line(raw) {
      const text = raw.replace(/\r$/, '');
      const error = TSC_ERROR.exec(text);
      if (error) {
        last = { file: relativeFile(root, error[1]!), line: Number(error[2]), col: Number(error[3]), code: error[4]!, message: error[5]!, program };
        round.push(last);
        return null;
      }
      // Counted as tsc counts it, against the program's own file, so the list is never empty while tsc says 1.
      const global = TSC_GLOBAL_ERROR.exec(text);
      if (global) {
        last = { file: program, line: 0, col: 0, code: global[1]!, message: global[2]!, program };
        round.push(last);
        return null;
      }
      if (TSC_FOUND.test(text)) {
        const done = round;
        round = [];
        last = null;
        return done;
      }
      if (TSC_START.test(text)) {
        round = [];
        last = null;
        return null;
      }
      // More of the last error's message: tsc indents what follows its first line.
      if (last && /^\s+\S/.test(text)) last.message += `\n${text.trim()}`;
      else if (text.trim() === '') last = null;
      return null;
    },
  };
}

/** How many problems the lists hold: the Problems card's count. */
export const problemCount = (lists: Readonly<Record<string, readonly Problem[]>>): number => Object.values(lists).reduce((n, list) => n + list.length, 0);

/** Every program's list in one, by file, then line, then column. */
export function merge(lists: Readonly<Record<string, readonly Problem[]>>): Problem[] {
  return Object.values(lists)
    .flat()
    .sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : a.line - b.line || a.col - b.col));
}

/** What the holder keeps of the watch: each program's last list, its processes, when the list last changed. */
export interface ProblemsState {
  lists: Record<string, Problem[]>;
  children: ChildProcess[];
  at: number;
}

export const freshProblems = (): ProblemsState => ({ lists: {}, children: [], at: 0 });

/** The programs a project has: `tsconfig.json`'s always, `tsconfig.node.json`'s when it is there. */
export function programs(root: string): string[] {
  return ['tsconfig.json', ...(existsSync(join(root, 'tsconfig.node.json')) ? ['tsconfig.node.json'] : [])];
}

export interface WatchOptions {
  root: string;
  /** The project's tsc (its `bin/tsc`, run by node). */
  tsc: string;
  state: ProblemsState;
  /** Told the merged list each time a program's round ends. */
  changed(problems: Problem[], at: number): void;
  spawn?: (command: string, args: readonly string[], cwd: string) => ChildProcess;
  now?: () => number;
}

/** The old watchers stopped. */
export function stopProblems(state: ProblemsState): void {
  for (const child of state.children) child.kill('SIGTERM');
  state.children = [];
}

/** A tsc watch per program, after the old ones are stopped; their rounds merged into `state` and told. */
export function watchProblems(options: WatchOptions): void {
  const { root, state } = options;
  const spawn = options.spawn ?? ((command, args, cwd) => nodeSpawn(command, [...args], { cwd, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true }));
  const now = options.now ?? Date.now;
  stopProblems(state);
  // tsc's lists start again; another's -- Vite's broken modules (`broken.ts`, `VITE_PROGRAM`) -- is kept.
  const own = programs(root);
  state.lists = Object.fromEntries(Object.entries(state.lists).filter(([program]) => !own.includes(program)));
  for (const program of own) {
    const child = spawn(process.execPath, [options.tsc, '--noEmit', '--watch', '--pretty', 'false', '--preserveWatchOutput', '-p', program === 'tsconfig.json' ? '.' : program], root);
    state.children.push(child);
    const parser = createParser(program, root);
    let rest = '';
    const read = (chunk: string): void => {
      const lines = (rest + chunk).split('\n');
      rest = lines.pop()!;
      for (const line of lines) {
        const list = parser.line(line);
        if (list === null) continue;
        state.lists[program] = list;
        state.at = now();
        options.changed(merge(state.lists), state.at);
      }
    };
    child.stdout?.setEncoding('utf8').on('data', read);
    child.stderr?.setEncoding('utf8').on('data', read);
    child.on('error', (err) => console.error(`[studio] tsc --watch for ${program}: ${err.message}`));
    child.on('close', () => {
      const at = state.children.indexOf(child);
      if (at >= 0) state.children.splice(at, 1);
    });
  }
}
