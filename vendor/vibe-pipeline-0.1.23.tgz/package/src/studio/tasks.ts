/**
 * The studio's tasks (Docs/studio.md): `npm run <script>` from a card, for a
 * script on an allow-list -- never a free command.
 *
 * - **The allow-list**: `test`, `typecheck`, `build`, `build:debug`, `export`, `packs`, and the names a
 *   project adds with `vibe({ tasks: ['bake'] })`; a run names one that the project's `package.json`
 *   `scripts` also has (a name it lacks is refused `400`, naming it). The body carries a name and nothing
 *   else -- but for `test`, which takes one test file (`args: ['src/game/spin.test.ts']`, the Tests
 *   card's Run one): a path under `src/` (`checkPath`: no `..`, nothing leading out by a link), a
 *   `.test.ts` that is there, spelt plainly (`SAFE`: Windows runs `npm.cmd` through its shell).
 * - **One at a time**: a run while one runs is `409 { running }`.
 * - **The run**: `npm run <script> [-- <file>]` in the root, its environment the dev server's less what
 *   the dev server and the `npm run dev` that started it set (`devServerEnv`), stdout and stderr line by
 *   line into the task's stream (`task:<name>`, `log.ts`), whose push carries them; `studio:task`
 *   `started` (with `from`, the stream's seq of its first line) and `ended` (code, signal) pushed of
 *   their own. On POSIX the npm is the leader of a process group of its own, so a cancel reaches what it
 *   started (`vibe`, tsc, Vite) and not npm alone; on Windows its tree is ended by `taskkill /T /F` (`signalGroup`).
 * - **Cancel**: SIGTERM to the group, SIGKILL after 5 s if it is still there; `ended` says the signal.
 *
 * What runs and what ran last are kept on the holder (`vite.ts`), so a task outlives Vite's in-process
 * restart and the new server answers for it. Nothing at module level.
 */
import { readFileSync } from 'node:fs';
import { stat } from 'node:fs/promises';
import { join } from 'node:path';
import { devServerEnv } from '../agent/env.ts';
import { Refused, checkPath } from '../assets/http.ts';
import type { TaskEnd, TasksAnswer } from './api-types.ts';
import { readLines, signalGroup, spawnChild, type Child, type ChildSpawn } from './child.ts';
import { taskStream, type Logs } from './log.ts';

/** The scripts a card may run in every project. */
export const ALLOWED: readonly string[] = ['test', 'typecheck', 'build', 'build:debug', 'export', 'packs'];

/** A task's name in `vibe({ tasks })`: an npm script's name, plainly. */
const TASK_NAME = /^[a-z0-9][a-z0-9:_-]*$/i;

/** A test file's path, as `test`'s one argument: plain characters only (no shell meaning on Windows). */
const SAFE = /^[A-Za-z0-9._/-]+$/;

/** Throws naming each name of `vibe({ tasks })` that is no script's name. */
export function checkTasks(tasks: readonly string[]): void {
  const bad = tasks.filter((name) => typeof name !== 'string' || !TASK_NAME.test(name));
  if (bad.length > 0) throw new Error(`vibe({ tasks }): ${bad.map((name) => `'${String(name)}'`).join(', ')} -- a task is an npm script's name (letters, digits, ':', '_', '-')`);
}

/** What a task's process is to this module (`child.ts`' `Child`): Node's `ChildProcess`, or a test's stand-in. */
export type TaskChild = Child;

export type TaskSpawn = ChildSpawn;

const signalTask = signalGroup;

/** What runs, and what ran last: kept on the holder across Vite's in-process restart. */
export interface TaskState {
  running: { name: string; child: TaskChild; group: boolean; platform: NodeJS.Platform; killTimer?: ReturnType<typeof setTimeout>; stopped?: boolean } | null;
  last: TaskEnd | null;
}

export interface TasksOptions {
  root: string;
  /** The project's own (`vibe({ tasks })`). */
  extra?: readonly string[];
  /** Where a task's lines go, and its pushes (`logs.send`). */
  logs: Logs;
  /** Kept on the holder. */
  state: TaskState;
  spawn?: TaskSpawn;
  /** The environment the task's is made from: the process's. */
  env?: Readonly<Record<string, string | undefined>>;
  platform?: NodeJS.Platform;
  /** The project's `scripts`: read from its `package.json` at each call when not given. */
  scripts?: () => Record<string, string>;
  /** How long after SIGTERM a cancelled task gets SIGKILL. */
  killMs?: number;
  now?: () => number;
  /** Told as a task starts (the preview stopped by a build), and as it ends (`dist/` measured after one). */
  onStart?: (name: string) => void;
  onEnd?: (end: TaskEnd) => void;
}

export interface Tasks {
  /** The allow-list the project's `package.json` has, in the list's order. */
  allowed(): string[];
  answer(): TasksAnswer;
  /** A run's body checked and started: its name and the seq its first line has. */
  run(body: Record<string, unknown>): Promise<{ name: string; from: number }>;
  /** The running task signalled; false when none runs. */
  cancel(): boolean;
}

/** The project's `scripts`, from its `package.json`; none when it cannot be read. */
export function projectScripts(root: string): Record<string, string> {
  try {
    const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')) as { scripts?: Record<string, string> };
    return pkg.scripts && typeof pkg.scripts === 'object' ? pkg.scripts : {};
  } catch {
    return {};
  }
}

export function createTasks(options: TasksOptions): Tasks {
  const { root, logs, state } = options;
  const list = [...new Set([...ALLOWED, ...(options.extra ?? [])])];
  const scripts = options.scripts ?? (() => projectScripts(root));
  const platform = options.platform ?? process.platform;
  const spawn = options.spawn ?? spawnChild;
  const now = options.now ?? Date.now;
  const killMs = options.killMs ?? 5000;

  /** A test file for `test`'s one argument, checked; the path as given. */
  async function testFile(args: unknown): Promise<string> {
    if (!Array.isArray(args) || args.length !== 1 || typeof args[0] !== 'string') throw new Refused(400, "args is one test file's path: ['src/…/name.test.ts']");
    const raw = args[0];
    if (!raw.endsWith('.test.ts')) throw new Refused(400, `${raw} is no test file: a test file's name ends .test.ts`);
    if (!SAFE.test(raw)) throw new Refused(400, `${raw}: a test file's path here is letters, digits, '.', '_', '-' and '/'`);
    const path = await checkPath(root, raw, ['src']);
    const found = await stat(join(root, path)).catch(() => undefined);
    if (!found?.isFile()) throw new Refused(404, `${path}: no such test file`);
    return path;
  }

  const tasks: Tasks = {
    allowed() {
      const has = scripts();
      return list.filter((name) => Object.hasOwn(has, name));
    },
    answer() {
      return { allowed: tasks.allowed(), running: state.running?.name ?? null, last: state.last };
    },
    async run(body) {
      const script = body.script;
      if (typeof script !== 'string' || script === '') throw new Refused(400, 'script names the npm script to run: { "script": "build" }');
      if (!list.includes(script)) throw new Refused(400, `'${script}' is not a task the studio runs: ${list.join(', ')} (a project adds its own with vibe({ tasks }))`, { script });
      if (!Object.hasOwn(scripts(), script)) throw new Refused(400, `'${script}' is not a script in package.json`, { script });
      if (body.args !== undefined && script !== 'test') throw new Refused(400, `args are only for test (one test file), not ${script}`);
      const file = body.args === undefined ? undefined : await testFile(body.args);
      if (state.running) throw new Refused(409, `${state.running.name} is running: one task at a time`, { running: state.running.name });

      const stream = taskStream(script);
      // POSIX: a group of its own; Windows: its tree, by taskkill (`signalGroup`).
      const group = true;
      const npm = platform === 'win32' ? 'npm.cmd' : 'npm';
      const args = ['run', script, ...(file !== undefined ? ['--', file] : [])];
      const from = logs.ring(stream).seq + 1;
      logs.write(stream, `$ npm ${args.join(' ')}`);
      // Windows runs a .cmd only through its shell (Node refuses it otherwise); the arguments are a name off the list and a checked path.
      const child = spawn(npm, args, { cwd: root, env: devServerEnv(options.env ?? process.env), group, shell: platform === 'win32' });
      const running: NonNullable<TaskState['running']> = { name: script, child, group, platform };
      state.running = running;
      options.onStart?.(script);
      logs.send({ kind: 'studio:task', name: script, state: 'started', from, at: now() });

      // Each pipe, line by line (`readLines`, a last line with no newline at its end); the pushes are batched
      // by the log itself (`log.ts`, every 50 ms per stream), not by how a chunk arrived.
      const write = (text: string): void => logs.write(stream, text);
      readLines(child.stdout, write);
      readLines(child.stderr, write);
      let ended = false;
      const end = (code: number | null, signal: string | null): void => {
        if (ended) return;
        ended = true;
        if (running.killTimer) clearTimeout(running.killTimer);
        logs.write(stream, signal ? `[${script} stopped by ${signal}]` : `[${script} exited ${code}]`);
        logs.flush(stream);
        const said: TaskEnd = { name: script, code, signal, at: now(), ...(running.stopped === true ? { stopped: true } : {}) };
        if (state.running === running) state.running = null;
        state.last = said;
        logs.send({ kind: 'studio:task', name: script, state: 'ended', code, signal, at: said.at });
        options.onEnd?.(said);
      };
      child.on('error', (err) => {
        logs.write(stream, `${npm}: ${err.message}`);
        end(null, null);
      });
      child.on('close', (code, signal) => end(code, signal));
      return { name: script, from };
    },
    cancel() {
      const running = state.running;
      if (!running) return false;
      // Said so as it ends (`TaskEnd.stopped`): a Stop, not the timer that may follow it.
      running.stopped = true;
      signalTask(running.child, 'SIGTERM', running.group, running.platform);
      if (!running.killTimer) {
        running.killTimer = setTimeout(() => {
          if (state.running === running) signalTask(running.child, 'SIGKILL', running.group, running.platform);
        }, killMs);
        running.killTimer.unref?.();
      }
      return true;
    },
  };
  return tasks;
}

/** The running task stopped at once, with its group: the process exits. */
export function killTask(state: TaskState): void {
  if (state.running) signalTask(state.running.child, 'SIGKILL', state.running.group, state.running.platform);
}
