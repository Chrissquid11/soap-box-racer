/**
 * A project's two modes (Docs/packages.md §5), read off where its packages are.
 *
 * The switch is the project's `package.json` alone: in **source mode** it names the packages by path
 * (`"@vibe/engine": "file:./engine/packages/engine"`, the engine a git submodule at `engine/`, or
 * `file:../VibeBase/packages/engine` for a sibling checkout) and npm links each into `node_modules`;
 * in **published mode** it names tarballs or versions, and npm installs a copy. Nothing else changes:
 * node, Vite and TypeScript follow the link to the real path, so the packages are resolved the same
 * way in both, and the mode is only told by that real path -- under a `node_modules` segment, a copy;
 * anywhere else, a source checkout. Defines only: nothing is read until a function is called.
 */
import { existsSync, realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, sep } from 'node:path';

/** The three packages' names, as a project's `package.json` names them. */
export const PACKAGES = { engine: '@vibe/engine', editor: '@vibe/editor', pipeline: '@vibe/pipeline' } as const;

export interface Mode {
  /** `source`: the engine's real path is outside every `node_modules` (a submodule's, a sibling's, the workspace's link); `published`: an installed copy. */
  mode: 'source' | 'published';
  /** Each package's folder, by its real path; `editor` undefined when the project has none installed (a game built without its tools). */
  packages: { engine: string; editor?: string; pipeline: string };
}

/**
 * The folder of the package `name` as the project at `root` resolves it -- from its own `package.json`,
 * through a link to the real path -- or undefined when it is not installed. Up from the entry its
 * exports map gives to the nearest `package.json` (the map does not name the manifest itself).
 * Anything but a missing package (a broken exports map, a bad manifest) throws.
 */
export function packageDir(root: string, name: string): string | undefined {
  let entry: string;
  try {
    entry = createRequire(join(root, 'package.json')).resolve(name);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'MODULE_NOT_FOUND') throw err;
    return undefined;
  }
  // `resolve` gives the real path already (a link followed); `realpathSync` is for a node run with --preserve-symlinks.
  let dir = dirname(realpathSync(entry));
  while (!existsSync(join(dir, 'package.json'))) {
    const up = dirname(dir);
    if (up === dir) throw new Error(`${name}: no package.json above ${entry}`);
    dir = up;
  }
  return dir;
}

/** Is `path` under a `node_modules` folder? */
const installed = (path: string): boolean => `${path}${sep}`.includes(`${sep}node_modules${sep}`);

/** The project's mode and its packages' folders. The engine and the pipeline must be installed: a project without them is none. */
export function detectMode(root: string): Mode {
  const engine = packageDir(root, PACKAGES.engine);
  const pipeline = packageDir(root, PACKAGES.pipeline);
  if (engine === undefined || pipeline === undefined) {
    throw new Error(`${root}: ${engine === undefined ? PACKAGES.engine : PACKAGES.pipeline} is not installed -- run npm install in the project`);
  }
  const editor = packageDir(root, PACKAGES.editor);
  return { mode: installed(engine) ? 'published' : 'source', packages: { engine, ...(editor === undefined ? {} : { editor }), pipeline } };
}
