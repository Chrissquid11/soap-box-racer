/**
 * `vibe()`: a project's whole Vite config, so its `vite.config.ts` is one line
 * (Docs/packages.md §2):
 *
 * ```ts
 * import { defineConfig } from 'vite';
 * import { vibe } from '@vibe/pipeline';
 * export default defineConfig(vibe({ port: 5190 }));
 * ```
 *
 * Every path is the project's: Vite's `config.root` (the folder `vibe` runs in, or its `--root`),
 * read in `configResolved` by each plugin that needs it. Defines only, loads nothing heavy (§4).
 */
import { createHash } from 'node:crypto';
import { realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, relative, sep } from 'node:path';
import type { Plugin, UserConfig } from 'vite';
import { agent } from './agent/vite.ts';
import { FS_DENY } from './agent/fs-deny.ts';
import { assets, prefabJson } from './assets/vite.ts';
import { checkKinds, type ProjectKinds } from './assets/kinds.ts';
import { toolDirs } from './assets/project-kinds.ts';
import { checkRoutes, toolRoutes, type ToolRoute } from './tools/tools.ts';
import { checkTasks } from './studio/tasks.ts';
import { studio } from './studio/vite.ts';
import { coldStart } from './studio/cold-start.ts';
import { physics } from './physics/vite.ts';

// What a project's own route (`vibe({ routes })`) is written with: its shape, and the pipeline's guards and answers.
export { TOOLS_PREFIX, type ToolContext, type ToolRoute } from './tools/tools.ts';
export { Refused, checkPath, readJson, sendJson } from './assets/http.ts';
export { writeAtomic } from './assets/fs.ts';
export { keepUid } from './assets/uid.ts';
export type { ProjectKind, ProjectKinds } from './assets/kinds.ts';
import { turnLink } from './assets/turn-hold.ts';
import { swap } from './swap/vite.ts';
import { PACKAGES, packageDir } from './modes.ts';
import { packageEntries, packageImports, resolvable } from './package-deps.ts';

/**
 * What a project says of its config. Kept on the config `vibe()` returns, as `vibe` (a key Vite
 * ignores): the CLI reads the project's kinds from there before Vite runs (`project-kinds.ts`).
 */
export interface VibeOptions {
  /**
   * The project's own asset kinds, by name (`ProjectKind`): data kinds, as `levels` is -- a folder under
   * `src/assets/`, its key union, its glob, `Assets.data(name, key)`. Checked as the config is made.
   */
  kinds?: ProjectKinds;
  /**
   * The project's own dev-server routes (`ToolRoute`): each answers `/__tools/<name>/…` through the
   * pipeline's guards (a write from this machine only), and pushes to the page on the assets channel.
   * Dev server only.
   */
  routes?: ToolRoute[];
  /**
   * The project's own editor tools, relative to its root -- a folder, or several (the sandbox's `src/tools` and
   * the example tools' package, `../tools`); `src/tools` when not said. Debug code,
   * as the editor is: `debugGuard` fails a release build with any module from it.
   */
  tools?: string | readonly string[];
  /**
   * The project's own npm scripts the Studio tab may run (`POST /__studio/run`), beside the ones every
   * project's may -- `test`, `typecheck`, `build`, `build:debug`, `export`, `packs`: `['bake']` for a
   * `"bake"` script in its `package.json`. Names only; a run names one of these, never a command.
   */
  tasks?: string[];
  /** The dev server's port, held to (`strictPort`). */
  port: number;
  /** The preview's; `port - 1000` when not said (5190 -> 4190). */
  previewPort?: number;
  /** The headers `--mode isolated` sends; `ISOLATION` when not said. */
  isolation?: Record<string, string>;
}

/**
 * The literals a build's `--mode` sets: words joined by `+`, each switching
 * one thing. Each is a global constant Vite writes into every module as a
 * literal (`src/env.d.ts` types them), so the other branch folds away right
 * where it is written.
 *
 *   `DEBUG_BUILD`  the debug tools are allowed: the dev server, and
 *                  a build in the `debug` mode (`vibe build --debug`, `npm run build:debug`).
 *   `PROJECT_ID`   the project's id where pages of several projects may share an origin (`projectId`):
 *                  written by the `project-id` plugin, which knows the root; `''` in a release.
 *
 * **A literal at every use, not a constant exported from one module.** Vite 8's
 * bundler does not fold a constant across an import: `if (DEBUG)` with `DEBUG`
 * imported from elsewhere keeps its branch, and a release build would carry the
 * debug tools (unreachable, but downloaded). `debugGuard` below fails that build.
 *
 * A mode rather than `VITE_DEBUG=true vite build`, because that prefix is POSIX
 * shell syntax and npm runs scripts through `cmd.exe` on Windows, where it fails.
 * A mode does not make this a development build: Vite fixes NODE_ENV to
 * `production` for every build with NODE_ENV unset, so
 * `import.meta.env.DEV` stays false. A NODE_ENV=development already set wins,
 * which is why the editor's Claude card takes the dev server's out of its
 * CLI's environment (packages/pipeline/src/agent/env.ts).
 */
function modeDefines(mode: string, command: 'serve' | 'build'): Record<string, string> {
  const words = mode.split('+');
  return {
    DEBUG_BUILD: JSON.stringify(command === 'serve' || words.includes('debug')),
  };
}

/**
 * The project's id: a short hash of its root folder's real path, the same at every run from that
 * folder, another for every other project -- so what a page keeps in browser storage is the project's
 * (`@vibe/engine/project-key`), even where two run on the same port one after the other and so share
 * an origin. A link to the folder is the folder. Pure but for `realpathSync`; tested in config.test.ts.
 */
export function projectId(root: string): string {
  let real = root;
  try {
    real = realpathSync(root);
  } catch {
    // Not there (a test's made-up root): the path as given.
  }
  return createHash('sha256').update(real).digest('hex').slice(0, 8);
}

/**
 * `PROJECT_ID` (`modeDefines`' words), from Vite's `config.root` -- the folder `vibe` runs in, or its
 * `--root`, which the config's own function is not told: the dev server and a debug build. A release
 * build writes `''`: the game is its origin's alone there, and an id that hung on the folder it was
 * built in would lose a player's settings at each move.
 */
function projectIdDefine(): Plugin {
  return {
    name: 'project-id',
    config(config, { mode, command }) {
      const debug = command === 'serve' || mode.split('+').includes('debug');
      return { define: { PROJECT_ID: JSON.stringify(debug ? projectId(config.root ?? process.cwd()) : '') } };
    },
  };
}

/** Where debug code lives, for `forbidden`: every folder ends in the path separator. */
export interface GuardPlaces {
  /** The editor's `src/` (the panel's `panel.ts` is in it), or null when the project has no `@vibe/editor`. */
  editor: string | null;
  /** The engine's `debug/` folder: nothing of it in a release but `mrDebug`. */
  engineDebug: string;
  /** The one file of `engineDebug` a release may carry: MrDebug, an inert stub there. */
  mrDebug: string;
  /** The project's own editor tools' folders (`vibe({ tools })`, `src/tools/` by default). */
  tools: readonly string[];
  /** The project's `src/debug/`. */
  debugDir: string;
  /** A release build (no `debug` in the mode), or a debug build. */
  release: boolean;
}

/**
 * Is the module `id` somewhere it must not be, in a chunk that is an entry or not? A release carries
 * nothing of the editor, the project's tools or its `src/debug/`, and of the engine's `debug/` only
 * MrDebug; a debug build carries the editor only lazily, never in an entry chunk. The same paths in
 * both modes: each place is a real path, which is the one Vite gives a module (`packages/editor/src/`
 * through a source link, `node_modules/@vibe/editor/src/` for an installed copy).
 */
export function forbidden(id: string, entry: boolean, places: GuardPlaces): boolean {
  const path = id.replace(/^\0/, '').split('?')[0]!;
  const inEditor = places.editor !== null && path.startsWith(places.editor);
  if (places.release) {
    return (
      inEditor ||
      places.tools.some((dir) => path.startsWith(dir)) ||
      path.startsWith(places.debugDir) ||
      (path.startsWith(places.engineDebug) && path !== places.mrDebug)
    );
  }
  return entry && inEditor;
}

/**
 * Fails a build that carries debug code where it must not be (CLAUDE.md).
 *
 * The editor (the package `@vibe/editor`, its `src/`: studio mode's) and the debug panel
 * (`@vibe/editor/panel`, its `src/panel.ts`) are each reached through one `DEBUG`-gated dynamic
 * import in the project's main.ts, so a release build drops them and a debug build has each
 * as a chunk of its own. A project's own editor tools (`vibe({ tools })`) are the editor's too, and
 * reached only through it. MrDebug (the engine's `debug/mr-debug.ts`,
 * `@vibe/engine/debug`) is imported by the game everywhere, and folds to an
 * inert stub in a release. Any other reference breaks that silently -- the
 * build passes, and a player downloads the debug tools. So, checking what
 * Rollup actually put in each chunk (`forbidden`):
 *
 *   - a release build: nothing from the editor's `src/` (the panel is in it), the project's tools or
 *     its own `src/debug/`, nor from the engine's `debug/` but `mr-debug.ts` itself (the stub);
 *   - a debug build: neither the editor nor the panel in an entry chunk --
 *     those only ever lazily.
 *
 * Every path is the project root's (Vite's `config.root`, taken in `configResolved`). The editor and
 * the engine's `debug/` are found by resolving `@vibe/editor` (its `src/` is the folder its entry is
 * in, the panel's `src/panel.ts` among it) and `@vibe/engine/debug` as the project does -- from its own
 * `package.json` -- since a project outside the workspace has its own `node_modules` and its own
 * copies; the resolution follows the link to the real path, which is the one Vite gives each module
 * (`packages/editor/src/` in the workspace, `engine/packages/editor/src/` through a project's
 * submodule, `node_modules/@vibe/editor/src/` installed): the same in both modes by construction. A
 * project without `@vibe/editor` has none of it to guard.
 * The editor's chunk is named `editor` here too: its entry is an `index.ts`, which the bundler
 * would name for its folder, `src`.
 */
function debugGuard(mode: string, tools: readonly string[]): Plugin {
  /** The editor's entry, or null when the project has no @vibe/editor. */
  let editorEntry: string | null = null;
  let places: GuardPlaces | undefined;
  let ROOT = '';
  const release = !mode.split('+').includes('debug');
  return {
    name: 'debug-guard',
    apply: 'build',
    configResolved(config) {
      ROOT = config.root;
      const project = createRequire(join(config.root, 'package.json'));
      try {
        editorEntry = project.resolve(PACKAGES.editor);
      } catch (err) {
        // A project without the editor installed (a game built without its tools): nothing of it to guard --
        // known by its code; anything else (a broken exports map, a bad package.json) is a real failure and stops the build.
        if ((err as NodeJS.ErrnoException).code !== 'MODULE_NOT_FOUND') throw err;
        editorEntry = null;
      }
      const mrDebug = project.resolve(`${PACKAGES.engine}/debug`);
      places = {
        editor: editorEntry === null ? null : dirname(editorEntry) + sep,
        engineDebug: dirname(mrDebug) + sep,
        mrDebug,
        tools: tools.map((dir) => join(config.root, dir) + sep),
        debugDir: join(config.root, 'src/debug') + sep,
        release,
      };
    },
    outputOptions(options) {
      // Vite sets chunkFileNames before this hook runs; the fallback is its own default, for the day it does not.
      const named = options.chunkFileNames ?? 'assets/[name]-[hash].js';
      return {
        ...options,
        chunkFileNames: (chunk) => {
          const pattern = typeof named === 'function' ? named(chunk) : named;
          // Its facade, or -- a project's tools importing the editor too, so the two share it -- the chunk holding its entry.
          const editor = editorEntry !== null && (chunk.facadeModuleId === editorEntry || chunk.moduleIds.includes(editorEntry));
          return editor ? pattern.replace('[name]', 'editor') : pattern;
        },
      };
    },
    generateBundle(_options, bundle) {
      const leaks: string[] = [];
      for (const chunk of Object.values(bundle)) {
        if (chunk.type !== 'chunk') continue;
        for (const id of chunk.moduleIds) {
          if (forbidden(id, chunk.isEntry, places!)) leaks.push(`  ${relative(ROOT, id.replace(/^\0/, ''))}  in  ${chunk.fileName}`);
        }
      }
      if (leaks.length === 0) return;
      this.error(
        `debug code leaked into ${release ? 'a release build' : "the debug build's main bundle"}:\n${leaks.join('\n')}\n` +
          "The editor and the debug panel (@vibe/editor, @vibe/editor/panel) are reached only by main.ts's DEBUG-gated import()s, the project's own tools only through the editor, and debug keys and buttons only through MrDebug (CLAUDE.md).",
      );
    },
  };
}

/**
 * The headers that make a page cross-origin isolated, which is what lets it
 * share memory with worker threads (Docs/ecs.md §10). Only under `--mode
 * isolated` (`vibe dev --isolated`, `npm run dev:isolated`): isolation also stops the page loading
 * anything from another origin that does not opt in, which a portal's SDK or
 * an ad script will not. A live host has to send the same two headers.
 */
export const ISOLATION: Readonly<Record<string, string>> = {
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Embedder-Policy': 'require-corp',
};

/**
 * The packages' dependencies pre-bundled. Vite's scanner reads the project's own source from `index.html` and
 * pre-bundles the bare imports it finds there; the engine and the editor are excluded (served as modules) and
 * not the project's, so what only they import -- pixi's events, three's loaders, controls and lil-gui -- it
 * would never see. Two halves:
 *
 * - `entries`: every file a package's `exports` map names is an entry, so the scanner crawls them as it crawls
 *   `main.ts` -- in source mode, where the packages are outside `node_modules`. A path (the source form) or
 *   `{ types, default }` (the published form, `vibe pack`): the code is `default`.
 * - `include`: every bare import of the packages' modules (`package-deps.ts`) that resolves from the project.
 *   The scanner reads nothing under `node_modules`, so in published mode the entries find nothing, and
 *   `pixi.js` and `three` were served raw (pixi's CommonJS `eventemitter3` then broke the page); named here,
 *   they are pre-bundled in both modes.
 *
 * A package not installed (a game without the editor) adds nothing.
 */
function packageDeps(): Plugin {
  return {
    name: 'package-deps',
    apply: 'serve',
    config(config) {
      const root = config.root ?? process.cwd();
      const entries: string[] = ['index.html'];
      const imports = new Set<string>();
      for (const name of [PACKAGES.engine, PACKAGES.editor]) {
        const dir = packageDir(root, name);
        if (dir === undefined) continue;
        entries.push(...packageEntries(root, dir));
        for (const spec of packageImports(dir)) imports.add(spec);
      }
      return { optimizeDeps: { entries, include: resolvable(root, [...imports].sort()) } };
    },
  };
}

/**
 * The dev server may read the packages wherever they are. Vite serves a file outside the project's
 * `src/` through `/@fs/`, and only under `server.fs.allow` -- by default the workspace root it finds
 * above the project (`searchForWorkspaceRoot`: the project itself, with its `.git`, or the workspace
 * the sandbox sits in). Linked packages are served by their real path: in the workspace, under its
 * root; through a project's submodule (`engine/packages/*`), under the project -- both allowed
 * already, and then this adds nothing and leaves Vite's default alone. A **sibling** checkout
 * (`"file:../VibeBase/packages/engine"`) is outside both, so each package's folder outside the
 * default joins it. Taken from where the packages resolve, so the project's `package.json` stays the
 * one switch (no file says where the checkout is). Installed copies are under the project's
 * `node_modules`: inside it.
 */
/** The package folders the dev server may not read by default: those outside Vite's workspace root (a sibling checkout's). Pure, tested in modes.test.ts. */
export function outsideWorkspace(workspace: string, dirs: readonly (string | undefined)[]): string[] {
  return dirs.filter((dir): dir is string => dir !== undefined && !`${dir}${sep}`.startsWith(`${workspace}${sep}`));
}

function packageFs(): Plugin {
  return {
    name: 'package-fs',
    apply: 'serve',
    async config(config) {
      const root = config.root ?? process.cwd();
      // Vite's own function, loaded here and not with this module: vibe() defines only (§4).
      const { searchForWorkspaceRoot } = await import('vite');
      const workspace = searchForWorkspaceRoot(root);
      const outside = outsideWorkspace(workspace, Object.values(PACKAGES).map((name) => packageDir(root, name)));
      // Setting `allow` replaces Vite's default, so the workspace root is named again.
      return outside.length === 0 ? null : { server: { fs: { allow: [workspace, ...outside] } } };
    },
  };
}

/** The project's Vite config, as a function of Vite's `{ mode, command }`: what `defineConfig` takes. */
export function vibe(options: VibeOptions): (env: { mode: string; command: 'serve' | 'build' }) => UserConfig & { vibe: VibeOptions } {
  const isolation = options.isolation ?? ISOLATION;
  const kinds = checkKinds(options.kinds);
  const routes = options.routes ?? [];
  checkRoutes(routes);
  const tasks = options.tasks ?? [];
  checkTasks(tasks);
  return ({ mode, command }) => {
    const headers = mode.split('+').includes('isolated') ? { ...isolation } : {};
    return {
      // Physics (Docs/physics.md §3): the project's physics.json as `PHYSICS_BUILD` and `virtual:vibe/physics`, and the
      // guard that a build with it off carries no Ammo. Ammo's wasm is a plain asset (a `?url` import), so no wasm plugin.
      // The asset pipeline's plugin (Docs/assets.md §5): the generated files and the packs, and in the dev
      // server the API under /__assets/, the push channel, the index on the watcher and the hot updates
      // that keep an asset's change from reloading the page. Its modules load nothing heavy (§4).
      // Then the editor's agent (Docs/agent.md §2), in the dev server only: Claude Code hosted for the
      // prompt panel under /__agent/, and a hotUpdate after the assets one that holds code for a turn.
      // The SDK loads when the editor first attaches, never with this config.
      // The two share a link for a Claude turn (Docs/modeler.md M21): a Gladius script's export held while one runs, and
      // its build checked as it ends (D110) -- kept on globalThis, so an in-process restart mid-turn keeps what is held.
      // And the game's swap (Docs/ecs.md §22), dev server only: a page whose swap fell
      // back to a reload asks for it, and gets Vite's own `full-reload`, so the editor resumes after it.
      // A project's own routes beside it (`tools/tools.ts`), their pushes on its channel through the same link.
      // Then the studio's (`studio/vite.ts`), dev server only: the log, the tasks, tsc's problems, the checks,
      // the build's sizes, the preview and the ffmpeg download under /__studio/, pushed to this machine's tabs alone.
      // And studio mode's cold start (`studio/cold-start.ts`, dev server only): a guard before main.ts that boots the
      // editor in recovery when main.ts' own imports fail and boot() never runs.
      plugins: [...assets({ link: turnLink(), kinds }), toolRoutes(routes, { link: turnLink() }), agent({ link: turnLink(), tools: toolDirs(options.tools) }), studio({ tasks }), coldStart(toolDirs(options.tools)), swap(), debugGuard(mode, toolDirs(options.tools)), physics(), packageDeps(), packageFs(), projectIdDefine()],

      define: modeDefines(mode, command),

      // The engine is source in the workspace and in a project's source mode (linked into node_modules), and a
      // copy of the source in published mode: in both served as its own modules, never pre-bundled, so its
      // `import.meta.hot` is live and `define` writes DEBUG_BUILD into it as into the project's own. The editor
      // the same: its resume, its agent push and the asset channel ride on `import.meta.hot`.
      optimizeDeps: { exclude: ['@vibe/engine', '@vibe/editor'] },

      // Relative URLs: a portal serves the game from a nested path inside an
      // iframe, and absolute asset paths 404 there.
      base: './',

      // Ports of its own, so this runs beside the other projects' dev servers
      // (CrabParty and most of the rest sit on Vite's 5173/4173, Xan2k on
      // 5180/4180). A game picks its own pair: in its vite.config.ts, and in its
      // .vscode/launch.json and README.md.
      server: {
        host: true, // also on the LAN, to test on a phone
        port: options.port,
        strictPort: true,
        open: false,
        headers,
        // On the LAN, so never a file of the transcripts, .claude/, the trash or the caches: Vite's defaults and those
        // (agent/fs-deny.ts; a deny here replaces Vite's list, so it names them again).
        fs: { deny: [...FS_DENY] },
      },

      preview: {
        port: options.previewPort ?? options.port - 1000,
        strictPort: true,
        headers,
      },

      // The game's worker (src/game/worker.ts) is a module, like the rest. It compiles the prefabs too,
      // so it reads a `.prefab` as JSON as the page does: worker bundles get none of `plugins` above.
      worker: { format: 'es', plugins: () => [prefabJson(kinds)] },

      build: {
        outDir: 'dist',
        // es2022 for top-level await (a node test's, a module's that awaits as it loads), which an older target only
        // emits anyway (TOLERATED_TRANSFORM) and fails to parse on the browsers it claims to support. Costs browsers
        // older than 2021.
        target: 'es2022',
        assetsInlineLimit: 0, // every asset a file of its own: cached better, never base64
        sourcemap: false, // `vibe build --debug` turns this on
        chunkSizeWarningLimit: 800, // three alone is ~450 kB minified
      },

      // What the project said, for the CLI, which reads it before Vite runs (`project-kinds.ts`). Vite ignores the key.
      vibe: options,
    };
  };
}
