/**
 * The project's `tsc`: TypeScript is a peer, so the project's own copy, found from its `package.json`
 * and run by node -- `vibe typecheck` (`commands.ts`), `vibe pack`, and the studio's watch
 * (`studio/problems.ts`). Its path by TypeScript's `package.json`'s `bin` (its exports map does not
 * export `bin/tsc`). Nothing at module level.
 */
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';

/** The absolute path of the project's `bin/tsc`. Throws when the project has no TypeScript. */
export function projectTsc(root: string): string {
  const pkg = createRequire(join(root, 'package.json')).resolve('typescript/package.json');
  const bin = (JSON.parse(readFileSync(pkg, 'utf8')) as { bin: { tsc: string } }).bin.tsc;
  return join(dirname(pkg), bin);
}
