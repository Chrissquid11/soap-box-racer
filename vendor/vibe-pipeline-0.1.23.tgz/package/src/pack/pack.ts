/**
 * `vibe pack [--version <x.y.z>] [--out <dir>]` (Docs/packages.md §6): the
 * workspace's packages as the tarballs a project installs -- its **published mode**, where node will
 * not strip types (`ERR_UNSUPPORTED_NODE_MODULES_TYPE_STRIPPING` under `node_modules`).
 *
 * Each package under `<root>/packages/` is staged at `<out>/stage/<name without the scope>/` (the
 * doc's `packages/<p>/dist/` lives there instead: nothing is written under `packages/`) and packed
 * from it by `npm pack` into `<out>/` (`release/` by default):
 *
 * - `dist/`: every `.ts` of `src/` stripped (`strip.ts`) to the same path's `.js`, line for line; the
 *   declarations beside it, by the workspace's `tsc --emitDeclarationOnly --declarationMap`, their maps
 *   pointing at `../src/<path>.ts`; every other file of `src/` (a `.d.ts`, a stylesheet the editor
 *   imports `?inline`, the Blender script `steps/blender.ts` finds beside itself) copied as it is, so a
 *   path the code reads by `import.meta.url` holds from `dist/` as from `src/`. A bin's `#!` line is
 *   node's, plain, and the file executable.
 * - `src/`: the sources, so a project's go-to-definition lands on TypeScript.
 * - `claude/` (the pipeline's plugin, found by `agent/plugin.ts` at `../../claude` from
 *   `dist/agent/plugin.js` as from `src/`) and `template/` (what `vibe new` copies, found by `new/new.ts`
 *   at `../../template` the same way), `README.md` and `CHANGELOG.md` (the package's, or the root's).
 *   The template is copied from the working tree, so a workspace cloned with `GIT_LFS_SKIP_SMUDGE=1`
 *   would ship LFS pointer text as its `crate.glb` and its font (CI checks LFS out).
 * - `package.json`: the source one with `exports`, `bin` and `sideEffects` pointing into `dist/`
 *   (`types` and `default` for each export), `files`, the version, the `@vibe/*` ranges exact, no `private`.
 *
 * Neither form ships the tests, the fixtures (`*.fixture.json`, anything under a `fixtures/`, where a
 * helper a test starts lives too), a test helper (a `testing.ts` the exports map does not name: a file the
 * map names ships -- the engine's `testing.ts` is `@vibe/engine/testing` -- and one it does not is the
 * tests' alone, the editor's `WORKSPACE` among them; `testHelper` is the one place that says so) or an
 * `asset-keys.d.ts`: that stub (every key a `string`) is for a package's own program, and in a project's
 * it would widen the generated keys. The declarations are compiled with it, so they say
 * `AssetKeys.Model` as the source does, resolved by the project's `keys.d.ts`.
 *
 * **The studio (`@vibe/studio`, the launcher) is packed last, with a step of its own**: it carries the
 * three tarballs just packed, under `template-packages/` -- what its New project hands `vibe new
 * --tarballs` -- and its launcher page (`src/launcher/`, plain TS for the browser) is never stripped or
 * declared but built by Vite (its `src/launcher/vite.config.ts`) into the stage's `dist/launcher/`,
 * where its server serves it from, both before `npm pack`.
 *
 * Defines only; `commands.ts` imports this module when `pack` runs.
 */
import { spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { chmodSync, copyFileSync, cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { basename, dirname, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { PACKAGES } from '../modes.ts';
import { npmSpawn } from '../npm.ts';
import { respellDeclarations, stripFile } from './strip.ts';

/** The fields of a package's manifest `vibe pack` reads or writes; the rest is carried as it is. */
export interface Manifest {
  name: string;
  version: string;
  private?: boolean;
  exports?: Record<string, string>;
  bin?: Record<string, string>;
  sideEffects?: boolean | string[];
  dependencies?: Record<string, string>;
  peerDependencies?: Record<string, string>;
  [field: string]: unknown;
}

/** The published manifest's export entry: the declarations and the code. */
export interface PublishedExport {
  types: string;
  default: string;
}

/** What goes in a tarball, `files` of the written manifest. */
export const FILES = ['dist', 'src', 'claude', 'template', 'licences', 'README.md', 'CHANGELOG.md'];

/** The studio's `files`: the common ones and the tarballs it carries. */
export const STUDIO_FILES = [...FILES, 'template-packages'];

/** The launcher's package, packed last (the module's comment). */
export const STUDIO = '@vibe/studio';

/** The launcher's page, under the studio's `src/`: built by Vite, never stripped or declared. */
export const LAUNCHER_PAGE = 'launcher';

/** One version for the packages: `1.2.0`, `0.1.0-rc.1`. */
export const VERSION = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;

/**
 * Is the file at `path` (relative to a package's `src/`, `/`-separated) left out of both forms: a test, a
 * fixture, a `testing.ts` that is not in `exported` (the `src/`-relative paths the exports map and the bin
 * name), the keys stub?
 */
export function leftOut(path: string, exported: ReadonlySet<string> = new Set()): boolean {
  const name = path.split('/').pop()!;
  if (testHelper(path, exported)) return true;
  return name.endsWith('.test.ts') || name.endsWith('.fixture.json') || name === 'asset-keys.d.ts' || path.split('/').slice(0, -1).includes('fixtures');
}

/** A `testing.ts` the exports map does not name: the tests' alone. */
export const testHelper = (path: string, exported: ReadonlySet<string>): boolean => path.split('/').pop() === 'testing.ts' && !exported.has(path);

/** A manifest's `./src/x.ts` as `x.ts`; anything else as it is. */
const srcRelative = (path: string): string => path.replace(/^\.\/src\//, '');

/** The `src/`-relative paths a manifest's exports map (the source form) and bin name. */
export function exportedPaths(manifest: Manifest): Set<string> {
  return new Set([...Object.values(manifest.exports ?? {}), ...Object.values(manifest.bin ?? {})].filter((path) => path.startsWith('./src/')).map(srcRelative));
}

/** Every file under `dir`, relative and `/`-separated, in name order. */
function walk(dir: string, under = ''): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(join(dir, under), { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
    const path = under === '' ? entry.name : `${under}/${entry.name}`;
    if (entry.isDirectory()) out.push(...walk(dir, path));
    else out.push(path);
  }
  return out;
}

/** `./src/x.ts` as published: `./dist/x.js` (or `x.d.ts` for `types`); a pattern (`./src/ecs/**`) its folder moved; anything else as it was. */
export function distPath(path: string, ext: '.js' | '.d.ts' = '.js'): string {
  if (!path.startsWith('./src/')) return path;
  const moved = `./dist/${path.slice('./src/'.length)}`;
  return moved.endsWith('.ts') && !moved.endsWith('.d.ts') ? `${moved.slice(0, -3)}${ext}` : moved;
}

/** Each `@vibe/*` range of `ranges` set to `version`. */
function exact(ranges: Record<string, string> | undefined, version: string): Record<string, string> | undefined {
  if (ranges === undefined) return undefined;
  return Object.fromEntries(Object.entries(ranges).map(([name, range]) => [name, name.startsWith('@vibe/') ? version : range]));
}

/** The published manifest, from the source one: see the module's comment. Key order kept, `files` after `bin`/`exports`. */
export function publishedManifest(source: Manifest, version: string, files: readonly string[] = FILES): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(source)) {
    if (key === 'private') continue;
    if (key === 'version') out.version = version;
    else if (key === 'exports') {
      const map: Record<string, PublishedExport> = {};
      for (const [entry, path] of Object.entries(source.exports!)) map[entry] = { types: distPath(path, '.d.ts'), default: distPath(path) };
      out.exports = map;
    } else if (key === 'bin') out.bin = Object.fromEntries(Object.entries(source.bin!).map(([name, path]) => [name, distPath(path)]));
    else if (key === 'sideEffects') out.sideEffects = Array.isArray(value) ? value.map((path: string) => distPath(path)) : value;
    else if (key === 'dependencies' || key === 'peerDependencies') out[key] = exact(value as Record<string, string>, version);
    else out[key] = value;
  }
  out.files = files;
  return out;
}

const readManifest = (dir: string): Manifest => JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as Manifest;
const writeJson = (file: string, value: unknown): void => writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`);

/**
 * The tsconfig the declarations are emitted by: the package's own, emitting, over its `src/` but the tests,
 * fixtures, the test helpers in `helpers` and a `page` folder (`src/`-relative); no `files` of its own (the
 * studio's names its page's `vite.config.ts`, which is no declaration).
 */
function packTsconfig(dir: string, dist: string, helpers: readonly string[], page?: string): Record<string, unknown> {
  const src = join(dir, 'src');
  return {
    extends: join(dir, 'tsconfig.json'),
    compilerOptions: { noEmit: false, emitDeclarationOnly: true, declaration: true, declarationMap: true, sourceMap: false, outDir: dist, rootDir: src },
    files: [],
    include: [src],
    exclude: [join(src, '**/*.test.ts'), join(src, '**/fixtures'), ...helpers.map((path) => join(src, path)), ...(page === undefined ? [] : [join(src, page)])],
  };
}

/** A declaration map's `sources` moved from the package's `src/` to the stage's, relative to the map: `../src/<path>.ts`. */
/** A path under the root as the log says it: relative, with `/` on every platform. */
const shown = (root: string, path: string): string => relative(root, path).split(sep).join('/');

function rebaseMap(map: string, packageSrc: string, stageSrc: string): void {
  const json = JSON.parse(readFileSync(map, 'utf8')) as { sources: string[]; sourceRoot?: string };
  const from = dirname(map);
  json.sources = json.sources.map((source) => {
    // A source on another drive than the map (Windows: the package on D:, the stage under C:'s temp) is no relative
    // path tsc can write: it writes a file URL.
    const file = source.startsWith('file:') ? fileURLToPath(source) : resolve(from, json.sourceRoot ?? '', source);
    return relative(from, join(stageSrc, relative(packageSrc, file))).split(sep).join('/');
  });
  delete json.sourceRoot;
  writeFileSync(map, JSON.stringify(json));
}

/**
 * A declaration's `/// <reference path>` lines (kept by `preserve="true"`: how a project's program reaches the
 * engine's `env.d.ts`) moved from the package's `src/` to `dist/`, where the `.d.ts` is copied: tsc writes each
 * relative to the folder it emitted into, so to the source's. One line each, no mapping on it: the map holds.
 */
export function rebaseReferences(text: string, file: string, packageSrc: string, dist: string): string {
  return text.replace(/^(\/\/\/ <reference path=")([^"]+)(")/gm, (line, head: string, path: string, tail: string) => {
    const target = resolve(dirname(file), path);
    const under = relative(packageSrc, target);
    if (under.startsWith('..') || resolve(packageSrc, under) !== target) return line;
    const moved = relative(dirname(file), join(dist, under)).split(sep).join('/');
    return `${head}${moved.startsWith('.') ? moved : `./${moved}`}${tail}`;
  });
}

export interface PackOptions {
  /** The folder the tarball goes to; the stage is under its `stage/`. */
  out: string;
  /** The version written into the manifest, and the `@vibe/*` ranges. */
  version: string;
  /** The `tsc` the declarations are emitted by (a path node runs). */
  tsc: string;
  /** Where a `README.md` or `CHANGELOG.md` the package has none of comes from: the workspace's root. */
  root: string;
  /** A folder of `src/` that is a page Vite builds (the studio's `launcher`): copied into the stage's `src/`, never stripped into `dist/` or declared. */
  page?: string;
  /** Run on the stage before `npm pack` (the studio's step). */
  before?: (stage: string) => Promise<void>;
}

/** One package staged and packed; the stage's folder and the tarball's path. Throws on a failure, saying what. */
export async function packPackage(dir: string, { out, version, tsc, root, page, before }: PackOptions): Promise<{ stage: string; tarball: string }> {
  const manifest = readManifest(dir);
  const stage = join(out, 'stage', manifest.name.replace(/^@[^/]+\//, ''));
  rmSync(stage, { recursive: true, force: true });
  const src = join(dir, 'src');
  const dist = join(stage, 'dist');
  const bins = new Set(Object.values(manifest.bin ?? {}).map(srcRelative));
  const exported = exportedPaths(manifest);
  const files = walk(src);
  const helpers = files.filter((file) => testHelper(file, exported));
  for (const path of files.filter((file) => !leftOut(file, exported))) {
    const from = join(src, path);
    mkdirSync(dirname(join(stage, 'src', path)), { recursive: true });
    copyFileSync(from, join(stage, 'src', path));
    if (page !== undefined && path.startsWith(`${page}/`)) continue;
    mkdirSync(dirname(join(dist, path)), { recursive: true });
    if (path.endsWith('.ts') && !path.endsWith('.d.ts')) {
      const js = join(dist, `${path.slice(0, -3)}.js`);
      writeFileSync(js, await stripFile(readFileSync(from, 'utf8'), from, bins.has(path)));
      if (bins.has(path)) chmodSync(js, 0o755);
    } else copyFileSync(from, join(dist, path));
  }

  // Under the package's own folder, not the stage: tsc resolves the `types` the package's tsconfig names
  // (`vite/client`, `node`) from the folder of the config it runs, so a stage outside the workspace
  // (`--out /elsewhere`) would find none. `node_modules/.cache/` is gitignored, and the file goes after.
  // A name of its own: two packs at once (`pack.test.ts` and `new.test.ts` under `vibe test`) wrote one
  // file and emitted into each other's dist, one of them then with no declarations.
  const config = join(dir, 'node_modules', '.cache', 'vibe-pack', `tsconfig-${randomUUID()}.json`);
  mkdirSync(dirname(config), { recursive: true });
  writeJson(config, packTsconfig(dir, dist, helpers, page));
  const emitted = spawnSync(process.execPath, [tsc, '-p', config], { stdio: 'inherit' });
  rmSync(config, { force: true });
  if (emitted.status !== 0) throw new Error(`${manifest.name}: tsc's declarations failed`);
  for (const path of walk(dist)) {
    const file = join(dist, path);
    if (path.endsWith('.d.ts.map')) rebaseMap(file, src, join(stage, 'src'));
    else if (path.endsWith('.d.ts')) writeFileSync(file, await respellDeclarations(rebaseReferences(readFileSync(file, 'utf8'), file, src, dist), file));
  }

  for (const folder of ['claude', 'template', 'licences']) if (existsSync(join(dir, folder))) cpSync(join(dir, folder), join(stage, folder), { recursive: true });
  for (const name of ['README.md', 'CHANGELOG.md']) {
    const from = [join(dir, name), join(root, name)].find((file) => existsSync(file));
    if (from) copyFileSync(from, join(stage, name));
  }
  // A package with a step of its own (the studio's) ships what the step adds: template-packages/.
  writeJson(join(stage, 'package.json'), publishedManifest(manifest, version, page !== undefined || before !== undefined ? STUDIO_FILES : FILES));
  if (before) await before(stage);

  const npm = npmSpawn(['pack', '--pack-destination', out]);
  const packed = spawnSync(npm.command, npm.args, { cwd: stage, encoding: 'utf8', shell: npm.shell });
  if (packed.status !== 0) throw new Error(`${manifest.name}: npm pack failed\n${packed.stderr}`);
  const name = packed.stdout.trim().split(/\r?\n/).pop()!;
  return { stage, tarball: join(out, basename(name)) };
}

/** The workspace's packages: each folder of `<root>/packages/` with a `package.json`, in name order. */
export function workspacePackages(root: string): string[] {
  const dir = join(root, 'packages');
  return readdirSync(dir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && existsSync(join(dir, entry.name, 'package.json')))
    .map((entry) => join(dir, entry.name))
    .sort();
}

/** `version` written into each package's manifest, and into its `@vibe/*` ranges. */
export function writeVersion(dirs: readonly string[], version: string): void {
  for (const dir of dirs) {
    const manifest = readManifest(dir);
    manifest.version = version;
    for (const key of ['dependencies', 'peerDependencies'] as const) if (manifest[key]) manifest[key] = exact(manifest[key], version);
    writeJson(join(dir, 'package.json'), manifest);
  }
}

/**
 * `## <version> -- <date>` at the top of the changelog's sections when no heading names the version: an
 * `## Unreleased` section (the lines written as the work landed) becomes it, else the heading goes in before the
 * first `## `. True when written.
 */
export function headChangelog(file: string, version: string, date: string): boolean {
  const text = existsSync(file) ? readFileSync(file, 'utf8') : '# Changelog\n';
  if (text.split('\n').some((line) => line === `## ${version}` || line.startsWith(`## ${version} `))) return false;
  const heading = `## ${version} -- ${date}`;
  const unreleased = text.search(/^## Unreleased[^\n]*$/im);
  if (unreleased >= 0) {
    writeFileSync(file, text.replace(/^## Unreleased[^\n]*$/im, heading));
    return true;
  }
  const at = text.search(/^## /m);
  writeFileSync(file, at < 0 ? `${text.replace(/\n*$/, '\n\n')}${heading}\n\n` : `${text.slice(0, at)}${heading}\n\n${text.slice(at)}`);
  return true;
}

/** `vibe pack`'s arguments. */
export function parsePackArgs(args: readonly string[], root: string): { version?: string; out: string } {
  let version: string | undefined;
  let out = join(root, 'release');
  for (let i = 0; i < args.length; i++) {
    const arg = args[i]!;
    const value = args[i + 1];
    if (arg === '--version' || arg === '--out') {
      if (value === undefined || value.startsWith('--')) throw new Error(`${arg} takes a value`);
      if (arg === '--version') version = value;
      else out = resolve(root, value);
      i++;
    } else throw new Error(`vibe pack: no such argument ${arg}`);
  }
  if (version !== undefined && !VERSION.test(version)) throw new Error(`--version takes x.y.z, not ${version}`);
  return { version, out };
}

/** The launcher's page built by Vite (the studio's `src/launcher/vite.config.ts`) into `outDir`. Vite is the pipeline's peer, loaded here alone. */
export async function buildLauncherPage(studio: string, outDir: string): Promise<void> {
  const { build } = await import('vite');
  await build({ configFile: join(studio, 'src', LAUNCHER_PAGE, 'vite.config.ts'), build: { outDir, emptyOutDir: true }, logLevel: 'warn' });
}

/** The packages in packing order: by name, the studio last (it carries the others' tarballs). */
export function packOrder(dirs: readonly string[]): string[] {
  const studio = dirs.filter((dir) => readManifest(dir).name === STUDIO);
  return [...dirs.filter((dir) => !studio.includes(dir)), ...studio];
}

export interface PackWorkspaceOptions {
  /** Build the launcher's page (false in a test: the stage's `dist/launcher/` is then left out). */
  buildLauncher?: boolean;
}

/** `vibe pack` over the workspace at `root`; the exit code. `tsc` is the workspace's. */
export async function packWorkspace(root: string, args: readonly string[], tsc: () => string, log: (line: string) => void = console.log, options: PackWorkspaceOptions = {}): Promise<number> {
  if (!existsSync(join(root, 'packages', 'engine', 'package.json'))) {
    console.error(`${root} is no workspace: no packages/engine here -- run vibe pack from the engine's checkout, or with --root`);
    return 2;
  }
  let parsed: ReturnType<typeof parsePackArgs>;
  try {
    parsed = parsePackArgs(args, root);
  } catch (err) {
    console.error((err as Error).message);
    return 2;
  }
  const dirs = workspacePackages(root);
  let version = parsed.version;
  if (version === undefined) {
    const manifests = dirs.map(readManifest);
    if (new Set(manifests.map((manifest) => manifest.version)).size > 1) {
      console.error(`the packages' versions disagree (${manifests.map((m) => `${m.name} ${m.version}`).join(', ')}): one version for all -- vibe pack --version <x.y.z> sets it`);
      return 2;
    }
    version = manifests[0]!.version;
  } else {
    writeVersion(dirs, version);
    log(`[pack] version ${version} written into ${dirs.map((dir) => shown(root, join(dir, 'package.json'))).join(', ')}`);
    if (headChangelog(join(root, 'CHANGELOG.md'), version, new Date().toISOString().slice(0, 10))) log(`[pack] CHANGELOG.md: ## ${version} added`);
  }
  mkdirSync(parsed.out, { recursive: true });
  const compiler = tsc();
  const three = new Set<string>(Object.values(PACKAGES));
  const packed: string[] = [];
  for (const dir of packOrder(dirs)) {
    const name = readManifest(dir).name;
    const studio = name === STUDIO;
    const before = async (stage: string): Promise<void> => {
      if (packed.length !== three.size) throw new Error(`${STUDIO}: it carries the three packages' tarballs, and ${packed.length} were packed`);
      const into = join(stage, 'template-packages');
      mkdirSync(into, { recursive: true });
      for (const tarball of packed) copyFileSync(tarball, join(into, basename(tarball)));
      log(`[pack] ${STUDIO}: ${packed.map((tarball) => basename(tarball)).join(', ')} into template-packages/`);
      if (options.buildLauncher !== false) {
        await buildLauncherPage(dir, join(stage, 'dist', LAUNCHER_PAGE));
        log(`[pack] ${STUDIO}: the launcher page built into dist/${LAUNCHER_PAGE}/`);
      }
    };
    const { stage, tarball } = await packPackage(dir, { out: parsed.out, version, tsc: compiler, root, ...(studio ? { page: LAUNCHER_PAGE, before } : {}) });
    if (three.has(name)) packed.push(tarball);
    log(`[pack] ${shown(root, tarball)} (staged in ${shown(root, stage)})`);
  }
  return 0;
}
