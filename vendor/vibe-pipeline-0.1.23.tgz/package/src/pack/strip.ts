/**
 * The published form of one source file (Docs/squidwright-implementation.md 1.9): a package's `.ts`
 * becomes `.js` by `ts-blank-space`, which puts blanks where the types were -- every line where it
 * was, so a stack trace's line is the source's -- and every relative path the code spells to a `.ts`
 * file is spelled `.js`. The paths are found by TypeScript's parser (the one `ts-blank-space` itself
 * parses with), never by a pattern over the text: a template literal holding a whole generated file
 * (`assets/keys.ts`' `live.ts`, with its `from './index.ts'`) is text, and stays as it is.
 *
 * What is a path: an `import` or `export ... from` specifier, an `import('...')`'s argument, an
 * `import('...')` type's (in a `.d.ts`), and the first argument of `new URL('...', import.meta.url)`
 * -- each a string literal starting `./` or `../` and ending `.ts` (not `.d.ts`). `.ts` and `.js` are
 * the same length, so every column stays too, and a declaration map's mappings with it.
 *
 * Defines only. TypeScript (some megabytes) is loaded at the first call, not when this module is.
 */
import { createRequire } from 'node:module';

/** The parts of TypeScript's API used here: `ts-blank-space`'s own copy (5.x or 6.0), whose types the workspace's TypeScript 7 does not carry. */
interface TsNode {
  kind: number;
  getStart(): number;
  getEnd(): number;
  getText(): string;
}
interface TsCall extends TsNode {
  expression: TsNode;
  arguments?: readonly TsNode[];
}
interface TsApi {
  createSourceFile(file: string, text: string, target: number, setParentNodes: boolean, kind: number): TsNode;
  forEachChild(node: TsNode, visit: (child: TsNode) => void): void;
  SyntaxKind: Record<string, number>;
  ScriptTarget: { ESNext: number };
  ScriptKind: { TS: number };
}

interface Loaded {
  ts: TsApi;
  /** `blankSourceFile`, over a source file of `ts`; `refused` told each node it cannot blank. */
  blank(source: TsNode, refused: (node: TsNode) => void): string;
}

let loaded: Loaded | undefined;

/** `ts-blank-space`, and the TypeScript it resolves (its dependency, so the AST it is given is one it knows). */
async function load(): Promise<Loaded> {
  if (loaded) return loaded;
  const require = createRequire(import.meta.url);
  const ts = createRequire(require.resolve('ts-blank-space'))('typescript') as TsApi;
  const { blankSourceFile } = await import('ts-blank-space');
  type Source = Parameters<typeof blankSourceFile>[0];
  loaded = { ts, blank: (source, refused) => blankSourceFile(source as unknown as Source, (node) => refused(node as unknown as TsNode)) };
  return loaded;
}

/** A relative path to a TypeScript file, as written in a string literal: `'./x.ts'`, `"../y/z.ts"` -- not a `.d.ts`. */
const TS_PATH = /^(['"`])\.\.?\/.*(?<!\.d)\.ts\1$/;

/** The offsets (of the `t` in `.ts`) of every relative `.ts` path the code spells in `source`, by its AST. */
function pathOffsets(ts: TsApi, source: TsNode): number[] {
  const K = ts.SyntaxKind;
  const found: number[] = [];
  const literal = (node: TsNode | undefined): void => {
    if (node === undefined) return;
    if (node.kind !== K.StringLiteral && node.kind !== K.NoSubstitutionTemplateLiteral) return;
    const text = node.getText();
    if (TS_PATH.test(text)) found.push(node.getEnd() - 3);
  };
  const visit = (node: TsNode): void => {
    const kind = node.kind;
    if (kind === K.ImportDeclaration || kind === K.ExportDeclaration) {
      literal((node as TsNode & { moduleSpecifier?: TsNode }).moduleSpecifier);
    } else if (kind === K.CallExpression) {
      const call = node as TsCall;
      if (call.expression.kind === K.ImportKeyword) literal(call.arguments?.[0]);
    } else if (kind === K.NewExpression) {
      const call = node as TsCall;
      if (call.expression.getText() === 'URL' && call.arguments?.[1]?.getText().replace(/\s/g, '') === 'import.meta.url') literal(call.arguments[0]);
    } else if (kind === K.ImportType) {
      const argument = (node as TsNode & { argument?: TsNode & { literal?: TsNode } }).argument;
      literal(argument?.literal);
    }
    ts.forEachChild(node, visit);
  };
  visit(source);
  return found;
}

/** `text` with the `ts` of each `.ts` at `offsets` made `js` -- but where the stripping blanked it (an `import('./x.ts')` type in a stripped annotation). */
function respell(text: string, offsets: readonly number[]): string {
  let out = text;
  for (const at of offsets) {
    if (out.slice(at, at + 2) === '  ') continue;
    if (out.slice(at, at + 2) !== 'ts') throw new Error(`a path at ${at} is not where the parse put it`);
    out = `${out.slice(0, at)}js${out.slice(at + 2)}`;
  }
  return out;
}

/** The node shebang a published bin is run by: no type stripping to quiet the warning of. */
export const NODE_SHEBANG = '#!/usr/bin/env node';

/**
 * A `.ts` file's published `.js`: types blanked, relative `.ts` paths spelled `.js`, and -- for a bin --
 * a first `#!` line made `NODE_SHEBANG`. Throws on syntax `ts-blank-space` cannot blank (an enum, a
 * parameter property: what `erasableSyntaxOnly` refuses already), naming `file`.
 */
export async function stripFile(text: string, file: string, bin = false): Promise<string> {
  const { ts, blank } = await load();
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS);
  const offsets = pathOffsets(ts, source);
  const refused: string[] = [];
  const js = blank(source, (node) => void refused.push(node.getText().split('\n')[0]!));
  if (refused.length > 0) throw new Error(`${file}: ts-blank-space cannot strip ${refused.join('; ')}`);
  const out = respell(js, offsets);
  return bin ? out.replace(/^#!.*/, NODE_SHEBANG) : out;
}

/** A declaration file's text with its relative `.ts` paths spelled `.js` (tsc writes them as the source spells them). */
export async function respellDeclarations(text: string, file: string): Promise<string> {
  const { ts } = await load();
  return respell(text, pathOffsets(ts, ts.createSourceFile(file, text, ts.ScriptTarget.ESNext, true, ts.ScriptKind.TS)));
}
