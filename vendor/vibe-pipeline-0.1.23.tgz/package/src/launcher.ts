/**
 * `@vibe/pipeline/launcher`: what the launcher (`@vibe/studio`, `packages/studio/`) takes of the
 * pipeline -- node's side, never the browser's. A subpath of its own rather than the index: `.` is
 * `vibe()`, a project's `vite.config.ts`'s, and loads every plugin; the launcher needs none of them,
 * only the machine's checks with no project (`studio/checks.ts`, `root: null`), where an app keeps its
 * data (`studio/app-data.ts`), `vibe new` as a function whose long steps stream into a sink
 * (`new/new.ts`' `newProject`), the dev server's guards and answers (`assets/http.ts`), and for a project's
 * dev server and an engine update run as children: the environment a script gets (`agent/env.ts`'
 * `devServerEnv`), the studio's way to run a child (`studio/child.ts`: the spawn in a process group of its
 * own, the signal to that group, a pipe read line by line) and the studio log's ring (`studio/log.ts`'
 * `createRing`), the last lines kept.
 *
 * Defines only.
 */
export { appData } from './studio/app-data.ts';
export { claudeProbe, createChecks, type ChecksOptions, type ClaudeProbe } from './studio/checks.ts';
export type { CheckRow } from './studio/api-types.ts';
export { findTarballs, folderName, freePort, newProject, NewError, NAME, npmName, npmNameProblem } from './new/new.ts';
export { PACKAGES } from './modes.ts';
export { devServerEnv } from './agent/env.ts';
export { readLines, signalGroup, spawnChild, type Child, type ChildSpawn } from './studio/child.ts';
export { cmdQuote } from './npm.ts';
export { createRing, type Ring } from './studio/log.ts';
export { Refused, guardWrite, isLoopback, mayWrite, readJson, sendJson } from './assets/http.ts';
