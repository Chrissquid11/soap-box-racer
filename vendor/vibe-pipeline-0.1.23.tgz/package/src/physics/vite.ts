/**
 * `vibe()`'s `physics` plugin (Docs/physics.md §3, D3, D4, D20): the project's `physics.json` as the build's and the
 * page's.
 *
 * - **`PHYSICS_BUILD`**, a literal written into every module -- the packages' too, as `DEBUG_BUILD` is -- from the
 *   file's `enabled` (on with no file). `boot()` imports Ammo only `if (PHYSICS_BUILD)`, so a build with it `false`
 *   folds the branch away and Rollup drops the loader, the glue and the wasm.
 * - **`virtual:vibe/physics`**, the settings as the page has them: the generated `bundle.ts` imports it and hands it
 *   to the engine (`usePhysicsSettings`). In the dev server the file is watched: an edit is that module updated
 *   (`bundle.ts` accepts its own updates, so the running physics takes it live, no reload); `enabled` changed is a
 *   restart of the dev server, since a define cannot change under it.
 * - **The guard**: a build with physics off that still carries a module of `ammojs-typed`, or the engine's own Ammo
 *   loader (`physics/ammo.page.*`, `physics/ammo-start.*`), fails and names each. Something imported Ammo past the
 *   `PHYSICS_BUILD` branch, and a player would download it.
 * - **`/__physics/settings`** (`route.ts`): the file read and written for the editor's Config ▸ Physics.
 * - Vite's two warnings that the glue's node branch (`fs`, `path`) was left out of a browser build: silenced for that
 *   module alone -- the branch never runs on a page.
 */
import { createRequire } from 'node:module';
import { dirname, join, relative, resolve } from 'node:path';
import type { Plugin } from 'vite';
import type { PhysicsSettings } from '@vibe/engine/physics-settings';
import { allowedHosts } from '../assets/http.ts';
import { physicsRoute } from './route.ts';
import { PHYSICS_FILE, readPhysicsSettings } from './settings.ts';

/** The page's import of the settings, and its id once resolved. */
export const PHYSICS_MODULE = 'virtual:vibe/physics';
const RESOLVED = `\0${PHYSICS_MODULE}`;

/** Where Ammo lives, for the guard: `ammojs-typed`'s folder, and the engine's `physics/` with the two files of it that load Ammo. */
export interface AmmoPlaces {
  ammo: string | null;
  enginePhysics: string | null;
}

/** A path with `/` between its names: Rollup's module ids are so on Windows too, where node's paths have `\`. */
const slashed = (path: string): string => path.replace(/\\/g, '/');

/** Is the module `id` Ammo's, or the engine's loader of it? Pure, tested. The places with `/` (`ammoPlaces`). */
export function ammoModule(id: string, places: AmmoPlaces): boolean {
  const path = slashed(id.replace(/^\0/, '').split('?')[0]!);
  if (places.ammo !== null && path.startsWith(places.ammo)) return true;
  if (places.enginePhysics === null || !path.startsWith(places.enginePhysics)) return false;
  const name = path.slice(places.enginePhysics.length);
  return name.startsWith('ammo.page.') || name.startsWith('ammo-start.');
}

/** Ammo's folder and the engine's `physics/`, resolved as the project resolves them; null for what is not installed. */
function ammoPlaces(root: string): AmmoPlaces {
  const project = createRequire(join(root, 'package.json'));
  let enginePhysics: string | null = null;
  let ammo: string | null = null;
  try {
    const settings = project.resolve('@vibe/engine/physics-settings');
    enginePhysics = `${slashed(dirname(settings))}/`;
    ammo = `${slashed(dirname(createRequire(settings).resolve('ammojs-typed/package.json')))}/`;
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'MODULE_NOT_FOUND') throw err;
  }
  return { ammo, enginePhysics };
}

export function physics(): Plugin {
  let root = process.cwd();
  let settings: PhysicsSettings;
  let places: AmmoPlaces = { ammo: null, enginePhysics: null };
  return {
    name: 'vibe-physics',
    config(config) {
      root = resolve(config.root ?? process.cwd());
      // A bad file stops here, before anything is served or built, naming the field.
      settings = readPhysicsSettings(root);
      const onwarn = config.build?.rollupOptions?.onwarn;
      return {
        define: { PHYSICS_BUILD: JSON.stringify(settings.enabled) },
        build: {
          rollupOptions: {
            onwarn(warning, warn) {
              if (/ammojs-typed/.test(warning.message) && /externalized for browser compatibility/.test(warning.message)) return;
              if (onwarn) onwarn(warning, warn);
              else warn(warning);
            },
          },
        },
      };
    },
    configResolved(config) {
      root = config.root;
      places = ammoPlaces(root);
    },
    resolveId(id) {
      return id === PHYSICS_MODULE ? RESOLVED : null;
    },
    load(id) {
      return id === RESOLVED ? `export default ${JSON.stringify(settings)};\n` : null;
    },
    configureServer(server) {
      const file = join(root, PHYSICS_FILE);
      server.watcher.add(file);
      const changed = (path: string): void => {
        if (resolve(path) !== file) return;
        let next: PhysicsSettings;
        try {
          next = readPhysicsSettings(root);
        } catch (err) {
          server.config.logger.error(`[physics] ${(err as Error).message} -- the last good settings kept`);
          return;
        }
        if (next.enabled !== settings.enabled) {
          server.config.logger.info(`[physics] ${PHYSICS_FILE}: physics turned ${next.enabled ? 'on' : 'off'} -- restarting the dev server`);
          void server.restart();
          return;
        }
        settings = next;
        const mod = server.moduleGraph.getModuleById(RESOLVED);
        if (mod) void server.reloadModule(mod);
      };
      server.watcher.on('change', changed);
      server.watcher.on('add', changed);
      server.watcher.on('unlink', changed);
      // Config ▸ Physics' and `physics_settings_set`'s reads and writes (`route.ts`); a write reaches the page through the watcher.
      const handle = physicsRoute({ root, port: () => server.config.server.port, hosts: () => allowedHosts(server.config.server?.allowedHosts) });
      server.middlewares.use((req, res, next) => {
        handle(req, res).then((handled) => {
          if (!handled) next();
        }, next);
      });
    },
    generateBundle(_options, bundle) {
      if (settings.enabled) return;
      const leaks: string[] = [];
      for (const chunk of Object.values(bundle)) {
        if (chunk.type !== 'chunk') continue;
        for (const id of chunk.moduleIds) if (ammoModule(id, places)) leaks.push(`  ${relative(root, id.replace(/^\0/, ''))}  in  ${chunk.fileName}`);
      }
      if (leaks.length === 0) return;
      this.error(
        `Ammo leaked into a build with physics off (${PHYSICS_FILE}: "enabled": false):\n${leaks.join('\n')}\n` +
          'The engine loads Ammo only behind PHYSICS_BUILD, in boot(); nothing else may import ammojs-typed or the engine\'s physics/ammo.page.ts (Docs/physics.md D20).',
      );
    },
  };
}
