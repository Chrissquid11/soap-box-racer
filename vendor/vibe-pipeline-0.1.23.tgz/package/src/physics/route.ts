/**
 * The dev server's `/__physics/settings` (Docs/physics.md §7): the project's `physics.json` as the editor's Config ▸
 * Physics and `physics_settings_set` read and write it.
 *
 * - **GET** answers `{ settings, file }`: the settings as the file has them (every default with none), and whether
 *   there is a file.
 * - **PUT** `{ set }` lays the change over the file as it is now (`patchPhysicsSettings`), checks it as a file is
 *   checked, and writes it whole (`physicsFileText`): `{ settings, restart }` -- `restart` when `enabled` changed,
 *   which the `physics` plugin's watcher answers by restarting the dev server (a define cannot change under it); any
 *   other change reaches the running page live, through the watcher too. A change that will not do is `422`, its
 *   field named, the file untouched.
 * - **One write at a time**: each PUT reads the file the one before it wrote, and writes it whole (`writeAtomic`).
 * - Through the pipeline's guards (`assets/http.ts`): only this machine's names, and a write only from this machine,
 *   as JSON.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { writeAtomic } from '../assets/fs.ts';
import { Refused, drain, guardHost, guardWrite, mutating, readJson, sendJson } from '../assets/http.ts';
import { PHYSICS_FILE, PhysicsFileError, patchPhysicsSettings, physicsFileText, readPhysicsSettings } from './settings.ts';

/** The route's path. */
export const PHYSICS_ROUTE = '/__physics/settings';

export interface PhysicsRouteOptions {
  /** The project's root: where `physics.json` is. */
  root: string;
  /** This server's port, for the write guard's `Origin` check. */
  port?(): number | undefined;
  /** This server's `allowedHosts`, as `allowedHosts` reads them. */
  hosts?(): readonly string[];
}

/** The handler: true when it answered (the path was its own), false for the next middleware's. */
export function physicsRoute(options: PhysicsRouteOptions): (req: IncomingMessage, res: ServerResponse) => Promise<boolean> {
  /** The PUTs one after another: each reads the file the last one wrote, so two in flight are both kept. */
  let queue: Promise<unknown> = Promise.resolve();
  const serially = <T>(work: () => Promise<T>): Promise<T> => {
    const next = queue.then(work, work);
    queue = next.catch(() => undefined);
    return next;
  };
  return async (req, res) => {
    const path = new URL(req.url ?? '/', 'http://localhost').pathname;
    if (path !== PHYSICS_ROUTE) return false;
    try {
      const allowed = options.hosts?.() ?? [];
      guardHost(req, allowed);
      const file = join(options.root, PHYSICS_FILE);
      const current = (): ReturnType<typeof readPhysicsSettings> => {
        try {
          return readPhysicsSettings(options.root);
        } catch (err) {
          throw new Refused(422, `${(err as Error).message} -- fix the file by hand first`);
        }
      };
      if (req.method === 'GET' || req.method === 'HEAD') {
        sendJson(res, 200, { settings: current(), file: existsSync(file) });
        return true;
      }
      if (!mutating(req) || req.method !== 'PUT') throw new Refused(405, `${PHYSICS_ROUTE}: GET reads it, PUT { set } changes it`);
      guardWrite(req, options.port?.(), allowed);
      const body = await readJson(req);
      const done = await serially(async () => {
        const was = current();
        let next;
        try {
          next = patchPhysicsSettings(was, body.set);
        } catch (err) {
          if (err instanceof PhysicsFileError) throw new Refused(422, err.message);
          throw err;
        }
        // Whole or not at all: the plugin's watcher never reads half a file.
        await writeAtomic(file, physicsFileText(next));
        return { settings: next, restart: next.enabled !== was.enabled };
      });
      sendJson(res, 200, done);
    } catch (err) {
      if (res.headersSent || res.destroyed) res.destroy();
      else if (err instanceof Refused) {
        await drain(req);
        sendJson(res, err.status, err.body);
      } else sendJson(res, 500, { refused: (err as Error).message });
    }
    return true;
  };
}
