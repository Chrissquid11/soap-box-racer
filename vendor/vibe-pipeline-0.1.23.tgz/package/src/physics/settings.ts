/**
 * The project's `physics.json` (Docs/physics.md §3), read and checked in one place: beside `vite.config.ts` at the
 * project's root, every field optional, a missing file every default with physics on. `vibe()`'s `physics` plugin
 * (`vite.ts`) makes `enabled` the build's `PHYSICS_BUILD` and serves the rest to the page; the editor's Config ▸
 * Physics writes it (F5).
 *
 * ```json
 * { "enabled": true, "gravity": [0, -9.81, 0], "substeps": 1, "iterations": 10,
 *   "sleep": { "linear": 0.8, "angular": 1 }, "defaultMaterial": { "friction": 0.5, "restitution": 0 },
 *   "layers": ["Default", "Props", "Triggers"], "ignore": [["Triggers", "Props"]] }
 * ```
 *
 * Pure but for `readPhysicsSettings`' one read; `settings.test.ts` holds it.
 */
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { PHYSICS_DEFAULTS, type PhysicsSettings } from '@vibe/engine/physics-settings';

/** The file's name, at the project's root. */
export const PHYSICS_FILE = 'physics.json';

/** The most physics layers: this Ammo's collision filters are 16 bits, and the last is the queries' (Docs/physics.md D9). */
export const MAX_LAYERS = 15;

/** A `physics.json` that does not say what it should: the field, and why. */
export class PhysicsFileError extends Error {}

const isNumber = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

/**
 * `json` (the file's parsed text, or undefined for no file) checked and filled in from the defaults. Throws a
 * `PhysicsFileError` naming the first field that is wrong, and how it should be.
 */
export function physicsSettingsFrom(json: unknown): PhysicsSettings {
  if (json === undefined) return PHYSICS_DEFAULTS;
  if (typeof json !== 'object' || json === null || Array.isArray(json)) throw new PhysicsFileError(`${PHYSICS_FILE}: an object, { "enabled": true, ... }`);
  const o = json as Record<string, unknown>;
  const known = ['enabled', 'gravity', 'substeps', 'iterations', 'sleep', 'defaultMaterial', 'layers', 'ignore'];
  for (const k of Object.keys(o)) if (!known.includes(k)) throw new PhysicsFileError(`${PHYSICS_FILE}: "${k}" is no setting (${known.join(', ')})`);
  const d = PHYSICS_DEFAULTS;
  const enabled = o.enabled ?? d.enabled;
  if (typeof enabled !== 'boolean') throw new PhysicsFileError(`${PHYSICS_FILE}: "enabled" is true or false`);
  const gravity = o.gravity ?? d.gravity;
  if (!Array.isArray(gravity) || gravity.length !== 3 || !gravity.every(isNumber)) throw new PhysicsFileError(`${PHYSICS_FILE}: "gravity" is three numbers, metres a second squared: [0, -9.81, 0]`);
  const whole = (name: string, v: unknown, lo: number, hi: number): number => {
    if (!isNumber(v) || !Number.isInteger(v) || v < lo || v > hi) throw new PhysicsFileError(`${PHYSICS_FILE}: "${name}" is a whole number from ${lo} to ${hi}`);
    return v;
  };
  const substeps = whole('substeps', o.substeps ?? d.substeps, 1, 8);
  const iterations = whole('iterations', o.iterations ?? d.iterations, 1, 50);
  const pair = <K extends string>(name: string, v: unknown, keys: readonly K[], fallback: Record<K, number>): Record<K, number> => {
    if (v === undefined) return fallback;
    if (typeof v !== 'object' || v === null || Array.isArray(v)) throw new PhysicsFileError(`${PHYSICS_FILE}: "${name}" is { ${keys.map((k) => `"${k}": n`).join(', ')} }`);
    const r = v as Record<string, unknown>;
    const out = { ...fallback };
    for (const k of Object.keys(r)) if (!keys.includes(k as K)) throw new PhysicsFileError(`${PHYSICS_FILE}: "${name}.${k}" is none of ${keys.join(', ')}`);
    for (const k of keys) {
      const n = r[k] ?? fallback[k];
      if (!isNumber(n) || n < 0) throw new PhysicsFileError(`${PHYSICS_FILE}: "${name}.${k}" is a number, 0 or more`);
      out[k] = n;
    }
    return out;
  };
  const sleep = pair('sleep', o.sleep, ['linear', 'angular'] as const, d.sleep);
  const defaultMaterial = pair('defaultMaterial', o.defaultMaterial, ['friction', 'restitution'] as const, d.defaultMaterial);
  const layers = o.layers ?? d.layers;
  if (!Array.isArray(layers) || layers.length === 0 || layers.length > MAX_LAYERS || !layers.every((n) => typeof n === 'string' && n.trim() !== '')) {
    throw new PhysicsFileError(`${PHYSICS_FILE}: "layers" is 1 to ${MAX_LAYERS} names, the first layer 0: ["Default", ...]`);
  }
  const names = layers as string[];
  if (new Set(names.map((n) => n.toLowerCase())).size !== names.length) throw new PhysicsFileError(`${PHYSICS_FILE}: "layers" names one layer twice`);
  const ignore = o.ignore ?? d.ignore;
  if (!Array.isArray(ignore)) throw new PhysicsFileError(`${PHYSICS_FILE}: "ignore" is a list of pairs of layers that pass through each other: [["Triggers", "Static"]]`);
  for (const p of ignore) {
    if (!Array.isArray(p) || p.length !== 2 || !p.every((n) => typeof n === 'string')) throw new PhysicsFileError(`${PHYSICS_FILE}: "ignore" holds pairs of layer names: ["A", "B"]`);
    for (const n of p as string[]) if (!names.includes(n)) throw new PhysicsFileError(`${PHYSICS_FILE}: "ignore" names "${n}", which is none of "layers" (${names.join(', ')})`);
  }
  return {
    enabled,
    gravity: [gravity[0], gravity[1], gravity[2]] as [number, number, number],
    substeps,
    iterations,
    sleep: { linear: sleep.linear, angular: sleep.angular },
    defaultMaterial: { friction: defaultMaterial.friction, restitution: defaultMaterial.restitution },
    layers: names,
    ignore: (ignore as [string, string][]).map(([a, b]) => [a, b] as const),
  };
}

/** The settings of the project at `root`: its `physics.json` read and checked, or every default if it has none. */
export function readPhysicsSettings(root: string): PhysicsSettings {
  const file = join(root, PHYSICS_FILE);
  if (!existsSync(file)) return PHYSICS_DEFAULTS;
  let json: unknown;
  try {
    json = JSON.parse(readFileSync(file, 'utf8'));
  } catch (err) {
    throw new PhysicsFileError(`${PHYSICS_FILE}: not JSON (${(err as Error).message})`);
  }
  return physicsSettingsFrom(json);
}

/** What the editor's Config ▸ Physics and `physics_settings_set` may change: any field, the two pairs field by field. */
export interface PhysicsSettingsPatch {
  enabled?: boolean;
  gravity?: readonly [number, number, number];
  substeps?: number;
  iterations?: number;
  sleep?: Partial<PhysicsSettings['sleep']>;
  defaultMaterial?: Partial<PhysicsSettings['defaultMaterial']>;
  layers?: readonly string[];
  ignore?: readonly (readonly [string, string])[];
}

/**
 * `patch` laid over `current` and checked as a file is (`physicsSettingsFrom`): the settings it makes, or a
 * `PhysicsFileError` naming what is wrong -- nothing half applied. A field the patch leaves out is kept; `sleep` and
 * `defaultMaterial` field by field. A pair of the matrix naming a layer renamed or gone is taken out with it, so
 * renaming a layer never strands the file.
 */
export function patchPhysicsSettings(current: PhysicsSettings, patch: unknown): PhysicsSettings {
  if (typeof patch !== 'object' || patch === null || Array.isArray(patch)) throw new PhysicsFileError('the change is an object: { "substeps": 2 }');
  const p = patch as Record<string, unknown>;
  const pairOf = (name: 'sleep' | 'defaultMaterial'): unknown => {
    const v = p[name];
    if (v === undefined) return current[name];
    if (typeof v !== 'object' || v === null || Array.isArray(v)) return v;
    return { ...current[name], ...(v as object) };
  };
  const layers = p.layers ?? current.layers;
  let ignore = p.ignore ?? current.ignore;
  if (p.ignore === undefined && Array.isArray(layers)) {
    const names = layers as unknown[];
    ignore = current.ignore.filter(([a, b]) => names.includes(a) && names.includes(b));
  }
  return physicsSettingsFrom({ ...current, ...p, sleep: pairOf('sleep'), defaultMaterial: pairOf('defaultMaterial'), layers, ignore });
}

/**
 * The file's text for `settings`: every field written, two spaces, a list of numbers or names on one line (`gravity`,
 * `layers`, each `ignore` pair), a newline at the end -- what Config ▸ Physics writes.
 */
export function physicsFileText(settings: PhysicsSettings): string {
  const { enabled, gravity, substeps, iterations, sleep, defaultMaterial, layers, ignore } = settings;
  const text = JSON.stringify({ enabled, gravity, substeps, iterations, sleep, defaultMaterial, layers, ignore }, null, 2);
  // A list holding no list or object: on one line.
  return `${text.replace(/\[\s*([^[\]{}]*?)\s*\]/g, (_all, inner: string) => `[${inner.split(/,\s*\n\s*/).join(', ')}]`)}\n`;
}
