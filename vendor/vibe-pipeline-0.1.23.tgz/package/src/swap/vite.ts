/**
 * The game's swap's Vite plugin (Docs/squidwright-implementation.md 0.4): a
 * page whose hot swap could not be done in place asks the dev server for a
 * reload, and gets one.
 *
 * - **`apply: 'serve'`**: none of it is in a build, and it imports nothing but
 *   Vite's types.
 * - **`vibebase:swap:reload` is answered with `full-reload`, to the asking page
 *   alone.** The game's boundary (the project's generated `src/game/live.ts`,
 *   through the engine's `liveGame`) sends it when `Game.rebuild` says
 *   `'reload'` or throws. Every page ran its own rebuild and decides for
 *   itself: another page that swapped fine is left alone.
 * - **The terminal says why**: the page's `{ why }` is logged as
 *   `[swap] <why>: the page reloads` (a default when it sends none).
 * - **Why the server, and not the page reloading itself**: `hot.invalidate()`
 *   is honoured by Vite's server only from a module that accepts itself, and
 *   `live.ts` accepts its dep, so the message would be dropped; and a bare
 *   `location.reload()` skips `vite:beforeFullReload`, which only the server's
 *   `full-reload` brings and on which the editor writes what it resumes from
 *   (`packages/editor/src/resume.ts`). Vite's own reload message is the one reload the
 *   page treats as Vite's.
 * - **Round the agent's held reload, and safe**: `packages/pipeline/src/agent/vite.ts` holds
 *   every code update while a Claude turn runs, a game module's included, so no
 *   swap runs mid-turn and no page asks for this reload then; the held files
 *   are replayed when the turn ends (0.6), and a swap that fails then asks as
 *   any other. The one window is a turn starting between an update sent and
 *   the page's ask, milliseconds wide, and a reload the editor survives.
 */
import type { Plugin } from 'vite';

/** The custom event a page sends to ask for its reload. */
export const SWAP_RELOAD = 'vibebase:swap:reload';

export function swap(): Plugin {
  return {
    name: 'swap',
    apply: 'serve',
    configureServer(server) {
      server.ws.on(SWAP_RELOAD, (data: unknown, client) => {
        const why = typeof (data as { why?: unknown } | null)?.why === 'string' ? (data as { why: string }).why : 'a swap asked for it';
        server.config.logger.info(`[swap] ${why}: the page reloads`);
        client.send({ type: 'full-reload', path: '*' });
      });
    },
  };
}
