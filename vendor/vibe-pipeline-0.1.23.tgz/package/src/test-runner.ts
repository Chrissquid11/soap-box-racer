/**
 * `vibe test`: every `*.test.ts` under each folder given, in the order given (the
 * workspace's root runs the packages', then the examples', then the pipeline's own) --
 * or a `*.test.ts` file given itself, run alone (the Studio's Tests card's Run one),
 * each run by node directly (node strips the types itself), one after another. A new
 * test file is picked up by being there -- nothing to register, the same bargain as
 * the asset folders.
 *
 * A file that has not exited after `VIBE_TEST_TIMEOUT_MS` (10 minutes by default: `vibe new`'s end to end takes over
 * 5 on a Windows runner) is killed and fails, named as timed out -- something it opened (a server, a PTY, a timer)
 * kept it up -- and the run goes on to the next.
 *
 * Returns 1 if any file fails, after running them all. The checks (`checks/`) run after it,
 * from `commands.ts`. Defines only: `cli.ts` is the
 * one module of the pipeline that acts when it is loaded.
 */
import { existsSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

/** Every `*.test.ts` under `dir`, in name order, skipping dot folders, `node_modules` and `fixtures` (a fixture package's own tests are data: `pack/fixtures/pkg/`). */
function find(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true }).sort((a, b) => (a.name < b.name ? -1 : 1))) {
    if (entry.name.startsWith('.') || entry.name === 'node_modules' || (entry.name === 'fixtures' && entry.isDirectory())) continue;
    const full = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...find(full));
    else if (entry.name.endsWith('.test.ts')) out.push(full);
  }
  return out;
}

/** A file's time to exit, in ms: `VIBE_TEST_TIMEOUT_MS` when it is a positive number, else 10 minutes. Pure. */
export function testTimeout(given: string | undefined): number {
  const ms = Number(given);
  return given !== undefined && given !== '' && Number.isFinite(ms) && ms > 0 ? ms : 10 * 60_000;
}

/** A test file given itself: that file alone. */
const isTestFile = (path: string): boolean => path.endsWith('.test.ts') && statSync(path).isFile();

/** Runs every test file under `folders` (absolute, or relative to the cwd), or a `.test.ts` file named there itself; the exit code. */
export function runTests(folders: string[]): number {
  const missing = folders.filter((folder) => !existsSync(folder));
  if (missing.length > 0) {
    console.error(`no such folder: ${missing.join(', ')}`);
    return 2;
  }
  const files = folders.flatMap((path) => (isTestFile(path) ? [path] : find(path)));
  const failed: string[] = [];
  const timeout = testTimeout(process.env.VIBE_TEST_TIMEOUT_MS);
  for (const file of files) {
    // Type stripping still announces itself as experimental on some node 24s.
    const run = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', file], { stdio: 'inherit', timeout, killSignal: 'SIGKILL' });
    const timedOut = (run.error as NodeJS.ErrnoException | undefined)?.code === 'ETIMEDOUT';
    if (timedOut) console.log(`  TIMED OUT after ${Math.round(timeout / 1000)} s, killed: ${file} (VIBE_TEST_TIMEOUT_MS to change it)`);
    if (run.status !== 0 || timedOut) failed.push(timedOut ? `${file} (timed out)` : file);
    console.log('');
  }
  console.log(`${files.length - failed.length} of ${files.length} test files passed`);
  for (const file of failed) console.log(`  FAILED ${file}`);
  return failed.length > 0 ? 1 : 0;
}
