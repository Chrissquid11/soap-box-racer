/**
 * The open conversations (Docs/agent.md §2, "The conversations"): the card's
 * tabs, each what the one session was -- its own query, session id, log,
 * settings, review loop, cards, turn and Undo this turn (`session.ts`) -- and
 * what they share, handled here.
 *
 * - **A registry, in order**: up to `MAX_CONVERSATIONS` (6), a seventh
 *   refused with a line. Each has an id -- its folder, `.cache/agent/<port>/
 *   <id>/` (`store.ts`) -- and a title: "New conversation" until its first
 *   prompt names it (`titleOf`: the first four words or so, 24 characters at
 *   most), or the person renames it. The index of the open ones, in order,
 *   with their titles, is `<port>/conversations.json`; the one conversation
 *   of before (`<port>/{session.json,log.jsonl}`) is moved into the first's
 *   folder the first time, its session id with it, and resumes.
 * - **Kept on `globalThis`** (`vite.ts`' holder): the sessions and the list,
 *   plain data, which every plugin instance -- an in-process restart -- runs
 *   this module's code over, so a restart adopts every conversation. A
 *   holder from before conversations (`{ session }`) is adopted as the first,
 *   its files where its store keeps them (`legacy`) until the next start. A
 *   new `npm run dev` makes each conversation's session from its folder; a
 *   session starts its CLI only on its first attach (the tab shown) or Send.
 * - **They run at the same time.** A turn in one never waits on another.
 *   What they share:
 *   - **Code held for a turn** (`hold`): held while any conversation's turn
 *     runs, and replayed through Vite's watcher when the last running turn ends
 *     (Vite then swaps or reloads, `vite.ts`) -- seen in the state each
 *     session pushes; "Reload now" (`reload`) replays it early.
 *     Every state is pushed with the held list, the registry's.
 *   - **Snapshots**: the port's kept index is everyone's, so its work goes
 *     one at a time (`serially`). Each conversation's Clear or close lets
 *     go of its own turns' snapshots alone.
 *   - **Undo this turn** counts every conversation's turns after it in time
 *     (`later`): a file another's later turn named is listed, by its title.
 *   - **The editor tools' steps**, while more than one is open, say whose
 *     (`McpCall.title`).
 * - **Create** copies the settings of the conversation it was made from;
 *   **close** ends one -- a turn running interrupted, its cards denied, its
 *   query closed -- and removes its folder; the last open one is cleared
 *   instead. It leaves the list before its first await, so two closes at
 *   once see each other (never both "not the last" and none left). Clear leaves the tab, untitled, a new conversation in it. Rename and reorder change the list, which is pushed
 *   whole (`{ conversations }`) whenever it, or a tab's running, waiting or
 *   last result, changes.
 *
 * Nothing at module level.
 */
import type { AssetsCalls } from '../assets/server.ts';
import type { StudioCalls } from '../studio/calls.ts';
import { randomUUID } from 'node:crypto';
import { Refused } from '../assets/http.ts';
import { AWAY, TURN_STALE_MS, type AgentSettings, type AgentState, type ConversationInfo, type ConversationMessage, type Entry, type McpCallOut, type OutsideLevel, type ProjectToolDecl, type PushMessage, type TerminalState } from './api-types.ts';
import { serially, type Serial } from './changes.ts';
import type { Jobs } from '../mcp/jobs.ts';
import type { LateAnswer, PageAnswer } from '../mcp/words.ts';
import type { Carry, Session } from './session.ts';
import { moveIntoConversation, readIndex, removeConversation, writeIndex, type IndexEntry, type Store } from './store.ts';

/** Open conversations at most: a seventh is refused with a line. */
export const MAX_CONVERSATIONS = 6;

/** A conversation's title until its first prompt names it. */
export const NEW_TITLE = 'New conversation';

/** A title's length at most, in characters. */
export const TITLE_MAX = 24;

/** The words of a title from a prompt, at most. */
const TITLE_WORDS = 4;

/**
 * A title from the first prompt: its first four words or so, as long as they
 * fit 24 characters -- a word that would not fit ends it, and a first word
 * longer than that is cut with an ellipsis. Nothing usable, "New conversation".
 */
export function titleOf(prompt: string): string {
  const words = prompt.replace(/[`*_#>]/g, ' ').trim().split(/\s+/).filter((w) => w !== '');
  if (words.length === 0) return NEW_TITLE;
  let title = '';
  for (const word of words.slice(0, TITLE_WORDS)) {
    const next = title === '' ? word : `${title} ${word}`;
    if (next.length > TITLE_MAX) break;
    title = next;
  }
  if (title === '') title = `${words[0]!.slice(0, TITLE_MAX - 1)}…`;
  return title;
}

/** A title as the person typed it: one line, trimmed, at most `TITLE_MAX * 2`; empty is none. */
export function cleanTitle(title: string): string | null {
  const one = title.replace(/\s+/g, ' ').trim();
  return one === '' ? null : one.slice(0, TITLE_MAX * 2);
}

/** One open conversation: its session, and what its tab shows. */
export interface Conversation {
  id: string;
  title: string;
  /** Named -- by its first prompt or the person: no later prompt renames it. */
  titled: boolean;
  session: Session;
  /** Its files are where the one conversation of before kept them: a session adopted live from an older bundle. */
  legacy?: boolean;
  /** Its store, where this registry made it: its writes done before its folder goes. */
  store?: Store;
}

/** What `globalThis` keeps across Vite's in-process restarts (`vite.ts`): plain data and sessions, the code always this bundle's. */
export interface ConversationsHolder {
  /** A holder from before conversations: its one session, adopted as the first. Kept pointing at the first, for an old exit hook. */
  session?: Session;
  open?: Conversation[];
  /** Code held for the turns running, every conversation's. */
  held?: string[];
  /** A session asked for its reload with another conversation's turn running: sent when the last ends. */
  owed?: boolean;
  /** The port's kept index, one piece of work at a time. */
  serial?: Serial;
  /**
   * The project's `fixBoot` (Docs/studio.md §1, "Claude tries first"): one value, not a conversation's -- kept on the
   * index beside the entries, every conversation's state saying it. Undefined until read or set: on.
   */
  fixBoot?: boolean;
  /** What outside clients of `/__mcp` may do (Docs/mcp.md M7): the project's, kept on the index as `fixBoot` is. Undefined until read or set: read-only. */
  outside?: OutsideLevel;
  /** The dev server's jobs (`../mcp/jobs.ts`): made once, kept across a restart, every conversation's studio tools reading them. */
  jobs?: Jobs;
  /** The Problems card's count now: handed over by the studio routes' plugin (`studio/vite.ts`) as it starts; none, not known. */
  problems?: () => number;
  /** The assets server's work in-process (Docs/mcp.md M3): handed over by the assets plugin (`assets/vite.ts`) as it starts; none, no asset tool runs here. */
  assets?: () => AssetsCalls;
  /** The studio routes' work in-process (Docs/mcp.md M5): handed over by the studio plugin (`studio/vite.ts`) as it starts; none, no studio tool runs here. */
  studio?: () => StudioCalls;
}

/** What a session is made with, here: its store (none, nothing kept), and the conversation's own options. */
export interface MakeSession {
  store?: Store;
  settings?: Partial<AgentSettings>;
  title: () => string;
  serial: Serial;
  later: (since: number) => { path: string; by: string }[];
  /** The files other conversations' running turns are writing: D110 leaves their scripts to them. */
  others: () => string[];
  /** Another conversation running a turn, its title; else null: Undo this turn waits for it. */
  busy: () => string | null;
  /** A session of an older bundle's, replaced after its Clear: its log, epoch and settings. */
  carry?: Carry;
}

/** Where the registry's pushes go: the dev server now (`server.ts`), re-pointed on a restart. */
export interface ConversationsHost {
  push(message: PushMessage): void;
  /**
   * The held code let go: each file -- relative to the root, as `hold` stored
   * it -- replayed through Vite's watcher, which swaps or reloads; with none
   * (a session of an older bundle owed its reload), one full reload to every page.
   */
  reload(files: readonly string[]): void;
  /** A page tool's call relayed to a studio tab within `deadline` ms (`server.ts`' `relay`): `tab`, else its pick. */
  editor?(tab: string | null, call: McpCallOut, deadline: number, late?: LateAnswer): Promise<PageAnswer & { tab?: string }>;
  /** The dev server's jobs (`../mcp/jobs.ts`), every conversation's tools reading them. */
  jobs?: Jobs;
  /** The Problems card's count now (the studio routes'). */
  problems?(): number | null;
  /** The assets server's work in-process (the assets plugin's): the asset tools' server path. Null where there is none. */
  assets?(): AssetsCalls | null;
  /** The studio routes' work in-process (the studio plugin's): the studio tools'. Null where there is none. */
  studio?(): StudioCalls | null;
  /** The project's own MCP tools (Docs/mcp.md M7), as the last studio tab declared them (`server.ts`' `projectTools`). None: none. */
  projectTools?(): ProjectToolDecl[];
  /**
   * No conversation's turn runs any more: the Gladius exports held for the turns made now (`turn-hold.ts`, Docs/modeler.md
   * M21) -- a promise once they have ended and their files are seen, and only then is the held code replayed.
   */
  turnsOver?(): Promise<string[] | void> | string[] | void;
  /** Exports still being made (`TurnLink.exporting`): what "Reload now" waits for before the replay. */
  exporting?(): Promise<void> | null;
}

export interface ConversationsOptions {
  root: string;
  port: () => number;
  /** A conversation's session: `createSession` with these. */
  make(made: MakeSession): Session;
  /** The function a session of this bundle is made by (`createSession`): one an older bundle made gives way at its Clear. */
  current?: unknown;
  /** Kept on disk (`.cache/agent/<port>/`); false, nothing is (a test's). */
  disk?: boolean;
  /** A conversation's store, by id (`createStore(root, port, { id })`). */
  store?: (id: string, moved: boolean) => Store;
  log?: (line: string) => void;
  /** The clock a terminal turn's age is read by (`TURN_STALE_MS`); `Date.now` by default. */
  now?: () => number;
}

export interface Conversations {
  /** The index read, the sessions made: every call waits for it. */
  readonly ready: Promise<void>;
  host: ConversationsHost | null;
  /** The open conversations, as the tab row shows them, in order. */
  list(): ConversationInfo[];
  /** One by id -- none, the first: what an old page's calls without an id act on. `404` for one not open. */
  get(id?: string | null): Conversation;
  /** A conversation's state, with the held list -- every conversation's -- and the project's `fixBoot` in its settings. */
  state(c: Conversation): AgentState;
  /** The project's `fixBoot` set (`POST settings { fixBoot }`, whichever conversation it names): kept on the index, every state pushed. */
  setFixBoot(on: boolean): void;
  /** What outside clients of `/__mcp` may do set (`POST settings { outside }`): kept on the index, every state pushed. */
  setOutside(level: OutsideLevel): void;
  /** What outside clients may do now: read off the index once it is read. */
  outside(): OutsideLevel;
  /** A new conversation, after the others, with the settings of `from` (or the first's). `409` past six. */
  create(from?: string | null): Promise<Conversation>;
  /** Closed: its turn stopped, its query closed, its folder gone; the last one cleared instead. */
  close(id: string): Promise<void>;
  /** Its Clear: and one of this bundle's in place of a session an older bundle made. */
  clear(id: string): Promise<void>;
  rename(id: string, title: string): void;
  /** The tabs in this order: every open id, once. */
  order(ids: readonly string[]): void;
  /** Its first prompt names it, unless named already. */
  named(c: Conversation, prompt: string): void;
  /** Any conversation's turn in flight: code is held while one is. */
  running(): boolean;
  hold(file: string): void;
  /** "Reload now": the held code replayed, a turn running or not -- after any exports being made, so then a promise. True if there was any. */
  reload(): boolean | Promise<boolean>;
  /** The process is exiting: every session's cards denied, its CLI closed. */
  closeAll(): void;
  /** Every write queued so far done: each open conversation's store, and the index's (a restart's exit waits for it). */
  flushed(): Promise<void>;
}

/**
 * The files the open conversations' running turns have written or are writing (each session's `writes()`: its
 * `Edit` and `Write` calls, as `projectPath` names them), by path, with the conversation: the Code card's save
 * is refused while one is (`studio/files.ts`, 423). A holder with none open, or a session of an older bundle
 * that has no `writes`, writes nothing.
 */
export function writingNow(holder: ConversationsHolder | undefined): Map<string, { id: string; title: string }> {
  const out = new Map<string, { id: string; title: string }>();
  for (const c of holder?.open ?? []) for (const path of c.session.writes?.() ?? []) if (!out.has(path)) out.set(path, { id: c.id, title: c.title });
  return out;
}

/** A conversation's id: short, and its folder's name. */
const newId = (): string => `c${randomUUID().replace(/-/g, '').slice(0, 10)}`;

/** A terminal's turn as the tab row shows it: none once told nothing of for `TURN_STALE_MS` (an end no hook said). */
export function shownTurn(away: Pick<TerminalState, 'turn' | 'turnAt'>, now: number): TerminalState['turn'] {
  return away.turn !== undefined && now - (away.turnAt ?? 0) < TURN_STALE_MS ? away.turn : undefined;
}

export function createConversations(holder: ConversationsHolder, options: ConversationsOptions): Conversations {
  const say = options.log ?? ((line: string) => console.error(line));
  const now = options.now ?? Date.now;
  const disk = options.disk !== false;
  const root = options.root;
  holder.held ??= [];
  holder.serial ??= serially();
  const held = holder.held;
  const serial = holder.serial;
  /** The list last pushed, as text: pushed again only when it changes. */
  let pushed = '';
  /** Index writes, in order. */
  let writing: Promise<void> = Promise.resolve();

  const open = (): Conversation[] => holder.open ?? [];
  /** Taken out of the list, their turns still being stopped: counted as running until they are. */
  const closing = new Set<Conversation>();

  const registry: Conversations = {
    ready: Promise.resolve(),
    host: null,
    list,
    get,
    state: stateOf,
    create,
    close,
    clear,
    rename,
    order,
    named,
    setFixBoot(on) {
      holder.fixBoot = on;
      saveIndex();
      pushStates();
    },
    setOutside(level) {
      holder.outside = level;
      saveIndex();
      pushStates();
    },
    outside: () => holder.outside ?? 'read',
    running: () => open().some((c) => c.session.running()) || [...closing].some((c) => c.session.running()),
    hold(file) {
      if (!registry.running() || held.includes(file)) return;
      held.push(file);
      pushStates();
    },
    reload() {
      // Exports in flight (a turn's end's, or a server's start's): the replay waits for them, never lands before the file.
      const wait = ending ?? registry.host?.exporting?.() ?? null;
      if (!wait) return release(true);
      return wait.then(
        () => registry.host?.exporting?.(),
        () => undefined,
      ).then(() => release(true), () => release(true));
    },
    async flushed() {
      // The closing ones too: a close past its session's clear is still writing its store away.
      await Promise.all([...open(), ...closing].map((c) => c.store?.flushed()));
      await writing;
    },
    closeAll() {
      for (const c of open()) c.session.close();
      for (const c of closing) c.session.close();
    },
  };

  // ---------------------------------------------------------------- the list

  function infoOf(c: Conversation): ConversationInfo {
    const state = c.session.state();
    let ended = 0;
    let failed = false;
    const entries = c.session.since(0);
    for (let i = entries.length - 1; i >= 0; i--) {
      const e = entries[i]!;
      if (e.kind === 'result') {
        ended = e.seq;
        failed = e.how === 'error';
        break;
      }
    }
    // In the terminal (Docs/ai-panel.md §8): its turn as the run's hooks tell it, and when one last ended there -- that one's failure the last.
    const away = state.terminal;
    if (away?.ended) failed = away.failed === true;
    // A turn told nothing of for long (an end no hook said: interrupted, declined, quit elsewhere) is shown no more.
    const turn = away ? shownTurn(away, now()) : undefined;
    return {
      id: c.id,
      title: c.title,
      running: state.running !== null,
      waiting: state.pending.length > 0,
      ended,
      ...(failed ? { failed: true as const } : {}),
      ...(turn ? { terminalTurn: turn } : {}),
      ...(away?.ended ? { terminalEnded: away.ended } : {}),
    };
  }

  function list(): ConversationInfo[] {
    return open().map(infoOf);
  }

  /** The list pushed to the pages, if it changed. */
  function pushList(): void {
    const now = list();
    const text = JSON.stringify(now);
    if (text === pushed) return;
    pushed = text;
    registry.host?.push({ conversations: now });
  }

  function get(id?: string | null): Conversation {
    const all = open();
    if (id === undefined || id === null || id === '') {
      const first = all[0];
      if (!first) throw new Refused(503, 'no conversation is open yet');
      return first;
    }
    const found = all.find((c) => c.id === id);
    if (!found) throw new Refused(404, 'no such conversation: it was closed');
    return found;
  }

  function stateOf(c: Conversation): AgentState {
    const state = c.session.state();
    // The held list is every conversation's: replayed when the last turn ends. A session of an older bundle may hold its own too.
    // And fixBoot is the project's: the registry's one value, whatever the session's own settings say.
    return { ...state, settings: { ...state.settings, fixBoot: holder.fixBoot ?? true, outside: holder.outside ?? 'read' }, held: [...new Set([...held, ...state.held])] };
  }

  /** Every conversation's state, pushed: the held list changed. */
  function pushStates(): void {
    for (const c of open()) registry.host?.push({ state: stateOf(c), conversation: c.id });
  }

  function saveIndex(): void {
    if (!disk) return;
    const entries: IndexEntry[] = open().map((c) => ({ id: c.id, title: c.title, titled: c.titled, ...(c.legacy ? { legacy: true } : {}) }));
    const { fixBoot, outside } = holder;
    writing = writing.then(() => writeIndex(root, options.port(), { open: entries, ...(fixBoot !== undefined ? { fixBoot } : {}), ...(outside !== undefined ? { outside } : {}) })).catch((err: unknown) => say(`[agent] the conversations' index: ${(err as Error).message}`));
  }

  // ---------------------------------------------------------------- the sessions, hosted

  /** Where a conversation's session pushes: its messages tagged with its id, its states with the held list, its reload the registry's. */
  function host(c: Conversation): void {
    c.session.host = {
      push(message) {
        const tagged: ConversationMessage = 'state' in message ? { state: stateOf(c), conversation: c.id } : { ...(message as ConversationMessage), conversation: c.id };
        registry.host?.push(tagged);
        if ('state' in message) {
          // A turn ended, or began, or a card came: the tab row's flags; and the held code replayed, once no turn runs.
          pushList();
          if (!registry.running()) turnsEnded(c);
        } else if ('entry' in message && message.entry.kind === 'result') pushList();
      },
      // A session's own reload (a session of an older bundle, which held code itself): owed until the last turn ends.
      reload() {
        if (registry.running()) holder.owed = true;
        else registry.host?.reload([]);
      },
      editor(tab, call, deadline, late) {
        const relay = registry.host?.editor;
        if (!relay) return Promise.resolve({ away: 'gone' as const });
        // Whose step it is, while there are several to tell apart.
        return relay(tab, open().length > 1 ? { ...call, title: c.title } : call, deadline, late);
      },
      get jobs() {
        return registry.host?.jobs;
      },
      problems: () => registry.host?.problems?.() ?? null,
      // The asset and studio tools' server work (M3, M5): every session's, as the jobs are.
      assets: () => registry.host?.assets?.() ?? null,
      studio: () => registry.host?.studio?.() ?? null,
    };
  }

  /** A turn's end in flight: the host's `turnsOver` awaited (the held exports being made) before the replay. */
  let ending: Promise<void> | null = null;

  /**
   * No conversation's turn runs: the host told first (`turnsOver`: the held Gladius exports made, and
   * whoever waits for the turns' end), and once those exports have ended and their files are seen, the
   * held code replayed -- so a page the replay reloads finds the model a prefab of the turn names. A turn
   * begun meanwhile keeps the code held (`release` waits for no turn running). Its one caller for both the
   * session's state push and a close that stopped the last turn; a call while one is in flight runs after
   * it. What became of the exports is said in `c`, the conversation whose turn was the last to end; after a
   * close, nowhere -- the exports made all the same. A session an older bundle made (until its Clear) has
   * no `note`: the lines go unsaid there too.
   */
  function turnsEnded(c?: Conversation): void {
    if (ending) {
      void ending.then(() => {
        if (!registry.running()) turnsEnded(c);
      });
      return;
    }
    const over = registry.host?.turnsOver?.();
    const done = (lines: string[] | void): void => {
      for (const line of lines ?? []) c?.session.note?.(line);
      release(false);
    };
    if (!(over instanceof Promise)) return done(over);
    const run = over.then(
      (lines) => {
        ending = null;
        done(lines);
      },
      (err: unknown) => {
        ending = null;
        say(`[agent] the held exports: ${(err as Error).message}`);
        done([]);
      },
    );
    ending = run;
  }

  /** The held code let go, its files handed to the host to replay -- once no conversation's turn runs, or `now` ("Reload now"). True if there was any. */
  function release(now: boolean): boolean {
    if (held.length === 0 && !holder.owed) return false;
    if (!now && registry.running()) return false;
    const files = held.slice();
    const owed = holder.owed === true;
    held.length = 0;
    holder.owed = false;
    // The files replayed, and an owed reload (a session of an older bundle's own held code, no file list) kept beside them.
    if (files.length > 0) registry.host?.reload(files);
    if (owed) registry.host?.reload([]);
    pushStates();
    return true;
  }

  /** Files other conversations' turns named in their results since `since`, each by its title. */
  function laterThan(c: Conversation): (since: number) => { path: string; by: string }[] {
    return (since) => {
      const out: { path: string; by: string }[] = [];
      for (const o of open()) {
        if (o === c) continue;
        for (const e of o.session.since(0) as Entry[]) {
          if (e.kind !== 'result' || e.at < since) continue;
          for (const f of e.files) out.push({ path: f.path, by: o.title });
        }
      }
      return out;
    };
  }

  /** A conversation's session made, hosted. */
  function made(id: string, title: string, titled: boolean, more: { settings?: Partial<AgentSettings>; moved?: boolean } = {}): Conversation {
    const c = { id, title, titled } as Conversation;
    renew(c, more);
    return c;
  }

  /** Its session (again): a store of its folder, its options, hosted. */
  function renew(c: Conversation, more: { settings?: Partial<AgentSettings>; moved?: boolean; carry?: Carry } = {}): void {
    const store = disk && options.store ? options.store(c.id, more.moved === true) : undefined;
    if (store) c.store = store;
    else delete c.store;
    c.session = options.make({
      ...(store ? { store } : {}),
      ...(more.settings ? { settings: more.settings } : {}),
      ...(more.carry ? { carry: more.carry } : {}),
      title: () => c.title,
      serial,
      later: laterThan(c),
      others: () => open().filter((o) => o !== c).flatMap((o) => o.session.writes?.() ?? []),
      busy: () => [...open(), ...closing].find((o) => o !== c && o.session.running())?.title ?? null,
    });
    host(c);
  }

  // ---------------------------------------------------------------- what a previous process, or bundle, left

  /** A title from a log: its first prompt's. */
  const titleFromLog = (entries: readonly Entry[]): { title: string; titled: boolean } => {
    const first = entries.find((e) => e.kind === 'prompt');
    return first && first.kind === 'prompt' ? { title: titleOf(first.text), titled: true } : { title: NEW_TITLE, titled: false };
  };

  (registry as { ready: Promise<void> }).ready = (async () => {
    if (holder.open) {
      // An in-process restart: every conversation adopted, re-hosted by this bundle's code.
      for (const c of holder.open) host(c);
      return;
    }
    if (holder.session) {
      // A dev server of before conversations, restarted onto this code: its one session is the first conversation, live.
      const session = holder.session;
      const c: Conversation = { id: newId(), ...titleFromLog(session.since(0)), session, legacy: true };
      holder.open = [c];
      host(c);
      saveIndex();
      return;
    }
    holder.open = [];
    if (disk) {
      const port = options.port();
      const kept = await readIndex(root, port);
      if (kept?.fixBoot !== undefined) holder.fixBoot ??= kept.fixBoot;
      if (kept?.outside !== undefined) holder.outside ??= kept.outside;
      let index = kept?.open ?? null;
      let moved = false;
      if (index === null) {
        // The first start with conversations: the one of before, if any, moved into the first one's folder.
        const id = newId();
        const move = await moveIntoConversation(root, port, id).catch((err: unknown) => {
          say(`[agent] the conversation of before could not be moved into ${id}/: ${(err as Error).message}`);
          return { had: false, moved: false };
        });
        moved = move.moved;
        index = move.had ? [{ id, title: NEW_TITLE, titled: false }] : [];
      }
      for (const entry of index.slice(0, MAX_CONVERSATIONS)) {
        if (entry.legacy) {
          // Adopted live last time, writing where the one of before did: moved now, no session holding it.
          await moveIntoConversation(root, port, entry.id).catch(() => null);
        }
        const c = made(entry.id, entry.title, entry.titled, { moved: moved && entry === index[0] });
        holder.open.push(c);
      }
      // A conversation moved in from before has its title from its first prompt.
      for (const c of holder.open) {
        if (c.titled) continue;
        await c.session.ready;
        const named = titleFromLog(c.session.since(0));
        c.title = named.title;
        c.titled = named.titled;
      }
    }
    if (holder.open.length === 0) holder.open.push(made(newId(), NEW_TITLE, false));
    holder.session = holder.open[0]!.session;
    saveIndex();
  })();

  // ---------------------------------------------------------------- what the person does

  async function create(from?: string | null): Promise<Conversation> {
    await registry.ready;
    if (open().length >= MAX_CONVERSATIONS) throw new Refused(409, `${MAX_CONVERSATIONS} conversations are open, the most there may be: close one first`);
    const source = get(from ?? null);
    const c = made(newId(), NEW_TITLE, false, { settings: source.session.state().settings });
    open().push(c);
    // Its settings kept with it from the start: a restart before its first turn keeps them.
    await c.session.settings({}).catch(() => {});
    saveIndex();
    pushList();
    return c;
  }

  /** A store's writes all done, those asked for while the earlier landed too: until its queue stays as it was. */
  async function settled(store: Store): Promise<void> {
    for (let queued = store.flushed(); ; ) {
      await queued;
      const now = store.flushed();
      if (now === queued) return;
      queued = now;
    }
  }

  async function close(id: string): Promise<void> {
    await registry.ready;
    const c = get(id);
    // In the terminal (Docs/terminal.md D1): the CLI's session is not forgotten under it -- Back first.
    if (c.session.state().terminal) throw new Refused(409, AWAY);
    // The last tab's ×: Clear -- the tab stays, a new conversation in it.
    if (open().length === 1) return clear(id);
    // Out of the list before the first await: a second close, of this one or another, sees the list without it -- two at
    // once never both pass the last-one check and leave none (a second close of this one is a 404, it is gone).
    holder.open = open().filter((o) => o !== c);
    holder.session = holder.open[0]!.session;
    closing.add(c);
    saveIndex();
    pushList();
    // Its turn interrupted and its query closed (Clear's way: closing the input alone would let the CLI finish the turn), its snapshots let go.
    // Out of the list already, it is closed even if that fails.
    await c.session.clear().catch((err: unknown) => say(`[agent] ${c.id} was not cleared as it closed: ${(err as Error).message}`));
    closing.delete(c);
    c.session.close();
    c.session.host = null;
    if (disk && !c.legacy) {
      // Its log is not needed: the folder goes, once its last writes are done.
      const port = options.port();
      const store = c.store;
      writing = writing
        .then(async () => {
          // Every write its session's store has pending, and any asked for while those land: one after the remove would
          // make the folder again.
          if (store) await settled(store);
          await removeConversation(root, port, c.id);
        })
        .catch((err: unknown) => say(`[agent] ${c.id}/ was not removed: ${(err as Error).message}`));
    }
    saveIndex();
    pushList();
    // A turn of its own was the last running: its held code goes now, and the turns' end is told.
    if (!registry.running()) turnsEnded();
  }

  async function clear(id: string): Promise<void> {
    await registry.ready;
    const c = get(id);
    if (c.session.state().terminal) throw new Refused(409, AWAY);
    await c.session.clear();
    // A new conversation in its tab: untitled until its first prompt.
    c.title = NEW_TITLE;
    c.titled = false;
    saveIndex();
    // Kept across a restart, a session runs the bundle that made it; after a Clear, this one's -- its log, epoch and settings carried.
    if (options.current !== undefined && c.session.made !== options.current) {
      const old = c.session;
      renew(c, { carry: old.carry() });
      old.host = null;
      if (c.legacy) {
        c.legacy = false;
        saveIndex();
      }
      if (open()[0] === c) holder.session = c.session;
    }
    pushList();
  }

  function rename(id: string, title: string): void {
    const c = get(id);
    const clean = cleanTitle(title);
    if (clean === null) throw new Refused(422, 'a title needs words');
    c.title = clean;
    c.titled = true;
    saveIndex();
    pushList();
  }

  function order(ids: readonly string[]): void {
    const all = open();
    if (ids.length !== all.length || new Set(ids).size !== ids.length || !ids.every((id) => all.some((c) => c.id === id))) throw new Refused(422, 'the order names every open conversation once');
    holder.open = ids.map((id) => all.find((c) => c.id === id)!);
    holder.session = holder.open[0]!.session;
    saveIndex();
    pushList();
  }

  function named(c: Conversation, prompt: string): void {
    if (c.titled) return;
    const title = titleOf(prompt);
    if (title === NEW_TITLE) return;
    c.title = title;
    c.titled = true;
    saveIndex();
    pushList();
  }

  return registry;
}
