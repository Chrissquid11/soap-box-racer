/**
 * What `/usage` shows, as facts (Docs/agent.md §2, "Usage"): pure, so node tests it.
 *
 * - **The plan's limits** come two ways. A `rate_limit_event` (`withRate`) says one limit at a time -- its type, its
 *   status, how much of it is used (a fraction: `utilization` 0.34 is 34 %) and when it resets (seconds) -- whenever the
 *   CLI hears of a change. The CLI's own usage call (`usage_EXPERIMENTAL_MAY_CHANGE_DO_NOT_RELY_ON_THIS_API_YET`, SDK
 *   0.3.220; what Claude Code's `/usage` reads) says every window at once, in percent, resetting at an ISO time
 *   (`fromUsageCall`). Each limit is kept by its kind, the newest heard winning.
 * - **This conversation's cost and tokens**: the CLI's running total (`total_cost_usd`) and its per-model usage
 *   (`modelUsage`, summed: `tokensOf`), both the session's whole -- restored on a resume -- at each result.
 * - **The context window**: `getContextUsage()`'s tokens, its window, its percent, after each turn.
 *
 * Nothing is guessed: a part not heard yet is null, and the card says "not known yet".
 */
import type { UsageFacts, UsageLimit } from './api-types.ts';

/** Nothing heard yet. */
export const NO_USAGE: UsageFacts = { limits: [], plan: null, subscription: null, cost: null, tokens: null, context: null, at: null };

/** A limit's words, by the SDK's `rateLimitType`. */
const LABELS: Record<string, string> = {
  five_hour: 'Session (5 hours)',
  seven_day: 'Week, all models',
  seven_day_opus: 'Week, Opus',
  seven_day_sonnet: 'Week, Sonnet',
  seven_day_oauth_apps: 'Week, apps',
  seven_day_overage_included: 'Week, with extra usage',
  overage: 'Extra usage',
};

/** The order the card lists them in: the session's first, then the weeks. */
const ORDER = ['five_hour', 'seven_day', 'seven_day_opus', 'seven_day_sonnet', 'seven_day_overage_included', 'seven_day_oauth_apps', 'overage'];

export const limitLabel = (kind: string): string => LABELS[kind] ?? (kind.startsWith('model:') ? `Week, ${kind.slice(6)}` : kind.replace(/_/g, ' '));

/** The limits in the card's order: the known kinds as `ORDER` has them, the rest (per-model) after, by name. */
export function sortLimits(limits: readonly UsageLimit[]): UsageLimit[] {
  const rank = (kind: string): number => {
    const at = ORDER.indexOf(kind);
    return at >= 0 ? at : ORDER.length;
  };
  return [...limits].sort((a, b) => rank(a.kind) - rank(b.kind) || a.kind.localeCompare(b.kind));
}

/** `limits` with `next` in place of any of its kind. */
function put(limits: readonly UsageLimit[], next: UsageLimit): UsageLimit[] {
  return sortLimits([...limits.filter((l) => l.kind !== next.kind), next]);
}

/** A `rate_limit_event`'s `rate_limit_info`, as much of it as is read. */
export interface RateInfo {
  status: 'allowed' | 'allowed_warning' | 'rejected';
  resetsAt?: number;
  rateLimitType?: string;
  utilization?: number;
}

/**
 * A `rate_limit_event` heard: its limit kept, the others as they were. One naming no type is the session's (the
 * five-hour window: what the CLI reports by default). `utilization` is a fraction; past 1, read as a percent already.
 */
export function withRate(usage: UsageFacts, info: RateInfo, now: number): UsageFacts {
  const kind = info.rateLimitType ?? 'five_hour';
  const u = typeof info.utilization === 'number' && Number.isFinite(info.utilization) ? info.utilization : null;
  const used = u === null ? null : Math.round((u <= 1 ? u * 100 : u) * 10) / 10;
  const resets = typeof info.resetsAt === 'number' && info.resetsAt > 0 ? info.resetsAt * 1000 : null;
  const had = usage.limits.find((l) => l.kind === kind);
  // An event that says less than was known keeps the rest: a status alone leaves the percent and the reset.
  const limit: UsageLimit = {
    kind,
    label: limitLabel(kind),
    used: used ?? (had && (had.resets === null || had.resets > now) ? had.used : null),
    resets: resets ?? had?.resets ?? null,
    status: info.status,
    at: now,
    from: 'event',
  };
  return { ...usage, limits: put(usage.limits, limit), at: now };
}

/** A window of the usage call: percent used, and when it resets (ISO). */
interface Window {
  utilization: number | null;
  resets_at: string | null;
}

/** The usage call's answer, as much of it as is read (`SDKControlGetUsageResponse`). */
export interface UsageCall {
  session?: { total_cost_usd?: number; model_usage?: Record<string, ModelTokens> };
  subscription_type?: string | null;
  rate_limits_available?: boolean;
  /** Each window by its kind (`five_hour`, `seven_day` …), and `model_scoped`, a list of per-model ones. */
  rate_limits?: Record<string, unknown> | null;
}

/** A model's usage as `modelUsage` has it. */
export interface ModelTokens {
  inputTokens?: number;
  outputTokens?: number;
  cacheReadInputTokens?: number;
  cacheCreationInputTokens?: number;
}

const iso = (text: string | null | undefined): number | null => {
  if (typeof text !== 'string') return null;
  const t = Date.parse(text);
  return Number.isFinite(t) ? t : null;
};

/**
 * The usage call's answer taken in: every window it names (in place of what events said of the same kind), whether plan
 * limits apply at all, the plan's name, and the session's cost and tokens.
 */
export function fromUsageCall(usage: UsageFacts, call: UsageCall, now: number): UsageFacts {
  let limits = usage.limits;
  const windows = call.rate_limits ?? null;
  if (windows) {
    for (const [kind, w] of Object.entries(windows)) {
      if (kind === 'model_scoped' || kind === 'extra_usage' || w === null || typeof w !== 'object' || Array.isArray(w)) continue;
      const window = w as Partial<Window>;
      if (typeof window.utilization !== 'number' && typeof window.resets_at !== 'string') continue;
      const had = limits.find((l) => l.kind === kind);
      limits = put(limits, { kind, label: limitLabel(kind), used: typeof window.utilization === 'number' ? window.utilization : null, resets: iso(window.resets_at), status: had?.status ?? null, at: now, from: 'usage' });
    }
    const scoped = Array.isArray(windows.model_scoped) ? (windows.model_scoped as { display_name?: unknown; utilization?: number | null; resets_at?: string | null }[]) : [];
    for (const m of scoped) {
      if (typeof m?.display_name !== 'string') continue;
      const kind = `model:${m.display_name}`;
      limits = put(limits, { kind, label: limitLabel(kind), used: typeof m.utilization === 'number' ? m.utilization : null, resets: iso(m.resets_at), status: null, at: now, from: 'usage' });
    }
  }
  const cost = typeof call.session?.total_cost_usd === 'number' ? call.session.total_cost_usd : usage.cost;
  const tokens = call.session?.model_usage ? (tokensOf(call.session.model_usage) ?? usage.tokens) : usage.tokens;
  return {
    ...usage,
    limits,
    plan: typeof call.rate_limits_available === 'boolean' ? call.rate_limits_available : usage.plan,
    subscription: call.subscription_type ?? usage.subscription,
    cost,
    tokens,
    at: now,
  };
}

/** Every model's tokens together; null where there is no model (nothing used yet). */
export function tokensOf(models: Record<string, ModelTokens> | undefined | null): UsageFacts['tokens'] {
  if (!models) return null;
  const all = Object.values(models);
  if (all.length === 0) return null;
  const sum = (pick: (m: ModelTokens) => number | undefined): number => all.reduce((n, m) => n + (typeof pick(m) === 'number' ? pick(m)! : 0), 0);
  return { input: sum((m) => m.inputTokens), output: sum((m) => m.outputTokens), cacheRead: sum((m) => m.cacheReadInputTokens), cacheWrite: sum((m) => m.cacheCreationInputTokens) };
}

/** A result heard: the running total and the session's tokens, where it says them. */
export function withResult(usage: UsageFacts, total: number | null, models: Record<string, ModelTokens> | undefined, now: number): UsageFacts {
  return { ...usage, cost: total ?? usage.cost, tokens: tokensOf(models) ?? usage.tokens, at: now };
}

/** `getContextUsage()`'s answer taken in. */
export function withContext(usage: UsageFacts, answer: { totalTokens?: number; maxTokens?: number; percentage?: number }, now: number): UsageFacts {
  if (typeof answer.percentage !== 'number') return usage;
  const used = typeof answer.totalTokens === 'number' ? answer.totalTokens : 0;
  const max = typeof answer.maxTokens === 'number' ? answer.maxTokens : 0;
  return { ...usage, context: { used, max, percent: Math.round(answer.percentage) }, at: now };
}

/** As `session.json` kept it, read: anything odd dropped, never thrown. */
export function readUsage(kept: unknown): UsageFacts {
  if (typeof kept !== 'object' || kept === null) return NO_USAGE;
  const k = kept as Record<string, unknown>;
  const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);
  const limits = Array.isArray(k.limits)
    ? k.limits.flatMap((l): UsageLimit[] => {
        if (typeof l !== 'object' || l === null) return [];
        const r = l as Record<string, unknown>;
        if (typeof r.kind !== 'string') return [];
        const status = r.status === 'allowed' || r.status === 'allowed_warning' || r.status === 'rejected' ? r.status : null;
        return [{ kind: r.kind, label: limitLabel(r.kind), used: num(r.used), resets: num(r.resets), status, at: num(r.at) ?? 0, from: r.from === 'usage' ? 'usage' : 'event' }];
      })
    : [];
  const t = typeof k.tokens === 'object' && k.tokens !== null ? (k.tokens as Record<string, unknown>) : null;
  const c = typeof k.context === 'object' && k.context !== null ? (k.context as Record<string, unknown>) : null;
  return {
    limits: sortLimits(limits),
    plan: typeof k.plan === 'boolean' ? k.plan : null,
    subscription: typeof k.subscription === 'string' ? k.subscription : null,
    cost: num(k.cost),
    tokens: t ? { input: num(t.input) ?? 0, output: num(t.output) ?? 0, cacheRead: num(t.cacheRead) ?? 0, cacheWrite: num(t.cacheWrite) ?? 0 } : null,
    context: c && num(c.percent) !== null ? { used: num(c.used) ?? 0, max: num(c.max) ?? 0, percent: num(c.percent)! } : null,
    at: num(k.at),
  };
}
