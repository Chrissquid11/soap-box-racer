/**
 * The session's `PreToolUse` hook (Docs/agent.md §3): what the critic is told,
 * and what it may do.
 *
 * - **What the critic is told is the host's.** An `Agent` call for
 *   `code-critic` (or the plugin's `vibe:code-critic`, `review.ts`' `isCritic`)
 *   is allowed with an `updatedInput`: its prompt replaced by the
 *   request verbatim and the turn's files (`turn.ts`' `criticRequest`), and
 *   `run_in_background: false` -- the SDK runs an agent in the background by
 *   default, and its `tool_use_result` is then `async_launched`, not the
 *   report. The author's own prompt is dropped: the critic hears no bar, no
 *   round, no opinion of the work, and it is a fresh critic every round. The
 *   request failing to be made (it never should: git not answering words it
 *   without the file list) leaves the author's prompt, still in the
 *   foreground: a hook that throws would fail the launch.
 * - **Its tools are enforced.** `AgentDefinition.tools` names tools, not
 *   patterns, and Auto narrows nothing; so every call with
 *   the critic's `agent_type` (either name) is held to the tools its file names, and a
 *   `Bash` to `npm test`, `npm run typecheck`, `git diff …` or `git status …`,
 *   alone: no `;`, `&`, `|`, `$(`, backtick, redirect or newline, and no
 *   `git diff --output`, which writes a file. Not `npm run build`: it writes
 *   `dist/` and `public/packs/`, and the checks already say whether it is
 *   right. A refusal is a reason the critic reads.
 * - **A Bash line the host's rules or Auto's line name asks**, whoever's
 *   rules allow it: the CLI decides on rules before `canUseTool` is asked,
 *   and its matcher is literal -- a person's own `allow` of `Bash(git:*)`
 *   would let `git -C . checkout` or `bash -c "git reset --hard"` by unseen.
 *   Hooks run before rules, so this one runs the same matcher
 *   (`permissions.ts`): `HOST_ASK`, git that only reads spared; a file it
 *   writes under `.git/` or `.claude/`; the person's own `ask` rules; and,
 *   under Auto, `autoAsks` -- and answers `permissionDecision: 'ask'` on a
 *   match, which sends the call to `canUseTool` and its card (checked with
 *   the CLI: a hook's `ask` reaches it past a broad `allow`).
 * - **A `Write`, `Edit`, `MultiEdit` or `NotebookEdit` under `.git/` or
 *   `.claude/`, or of this machine's settings (`*.local.json`), asks** too, Auto or not (`guardOf`, case ignored as the volume
 *   does): a person's `allow` of `Edit` or `Write` would let it by unseen.
 * - **A tool the turn refuses** (`TurnRequest.deny`, `HookContext.denied`) is denied first, whoever's rules
 *   allow it: "not in this turn" (`permissions.ts`' `notInTurn`).
 * - Anything else is no decision: the user's rules and `canUseTool` decide.
 *
 * Its types are the SDK's, as types only: nothing of the SDK is loaded here.
 */
import type { HookCallbackMatcher, HookInput, SyncHookJSONOutput } from '@anthropic-ai/claude-agent-sdk';
import { autoAsks, guardOf, guardReason, hostAsk, hostReason, ruleMatches, type At, type Ignored, type ShellPlace } from './permissions.ts';
import { isCritic, isCriticLaunch } from './review.ts';

/** What the hook needs of the session. */
export interface HookContext {
  /** The critic's request for the turn running now: the host's words. Undefined with no turn. Never rejects but by a bug. */
  criticRequest(): Promise<string | undefined>;
  /** The tools the critic's file names (`review.ts`). */
  criticTools(): readonly string[];
  /** The project root: paths are named relative to it. */
  root: string;
  /** Is the Auto tick on, now. */
  auto(): boolean;
  /** The user's own `ask` rules, as the CLI resolves them now; unreadable, none here (`canUseTool` asks then). */
  askRules(): Promise<readonly string[]>;
  /** Is a path, relative to the root, ignored by git. */
  ignored: Ignored;
  /** Is the tool refused for the turn running (`TurnRequest.deny`): its refusal's words, or null. */
  denied?(tool: string): string | null;
  /** Is `engine` under the root a folder of its own (`engineDir`): `git -C engine` is then plain. */
  engine?: boolean;
  /** Where the session's shells may be (`ShellPlace`), shared with `canUseTool`: every line seen here marks where it may leave them. */
  shell?: ShellPlace;
  /** The project's remotes (`gitRemotes`), read as the session starts. */
  remotes?: readonly string[];
  /** The engine's checkout's remotes (`gitRemotes` of `engine/`), read as the session starts. */
  engineRemotes?: readonly string[];
}

/** The commands the critic may run: the checks, and git's view of the change. */
export function criticBash(command: string): boolean {
  const c = command.trim();
  if (/[;&|`<>\n\r]|\$\(/.test(c)) return false;
  if (/^npm\s+test$/.test(c) || /^npm\s+run\s+typecheck$/.test(c)) return true;
  return /^git\s+(diff|status)(\s|$)/.test(c) && !/--output\b|--ext-diff\b/.test(c);
}

/** The refusal the critic reads. */
export function criticRefusal(tool: string, tools: readonly string[]): string {
  const others = tools.filter((name) => name !== 'Bash');
  const bash = tools.includes('Bash') ? ' and run `npm test`, `npm run typecheck`, `git diff …` or `git status …`, each alone (no `;`, `&&`, `|`, `$(`, backticks or redirects)' : '';
  return `${tool} is refused: the critic may use ${others.length > 0 ? others.join(', ') : 'nothing else'}${bash}. It reviews; it never changes anything.`;
}

const deny = (reason: string): SyncHookJSONOutput => ({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: reason } });
const ask = (reason: string): SyncHookJSONOutput => ({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'ask', permissionDecisionReason: reason } });

/**
 * Why a Bash line asks whoever's rules allow it: the host's rule that names
 * it, a file it writes under `.git/` or `.claude/` (`guardOf`), the person's
 * own `ask` rule, or Auto's line -- with where the session's shell may be
 * (`ShellPlace`), which the line then marks -- in flight, by its call's `id`,
 * until the call completes (`postToolUse`); null for none.
 */
export async function bashAsks(input: Record<string, unknown>, context: HookContext, id?: string): Promise<string | null> {
  const command = input.command;
  if (typeof command !== 'string') return null;
  const at: At = { engine: context.engine ?? false, away: context.shell?.away() ?? false, remotes: context.remotes ?? [], engineRemotes: context.engineRemotes ?? [] };
  context.shell?.saw(command, context.root, id);
  const host = await hostAsk('Bash', input, context.root, context.auto(), context.ignored, at);
  if (host !== undefined) return hostReason(host);
  const guard = guardOf('Bash', input, context.root);
  if (guard !== null) return guardReason(guard);
  const mine = (await context.askRules().catch((): readonly string[] => [])).find((r) => ruleMatches(r, 'Bash', input, context.root));
  if (mine !== undefined) return `Your ask rule ${mine} names it.`;
  return context.auto() ? autoAsks(command, context.root, context.ignored, at) : null;
}

/** The hook's answer for one `PreToolUse` (exported for the tests). */
export async function preToolUse(input: HookInput, context: HookContext): Promise<SyncHookJSONOutput> {
  if (input.hook_event_name !== 'PreToolUse') return {};
  const tool = input.tool_name;
  const toolInput = typeof input.tool_input === 'object' && input.tool_input !== null ? (input.tool_input as Record<string, unknown>) : {};
  // A tool refused for this turn (the Git card's draft): denied before the rules, a person's allow of it or not.
  const refused = context.denied?.(tool) ?? null;
  if (refused !== null) return deny(refused);
  if (isCritic(input.agent_type)) {
    const tools = context.criticTools();
    if (tool === 'Bash') {
      const command = typeof toolInput.command === 'string' ? toolInput.command : '';
      return tools.includes('Bash') && criticBash(command) ? {} : deny(criticRefusal(`\`${command}\``, tools));
    }
    return tools.includes(tool) ? {} : deny(criticRefusal(tool, tools));
  }
  if (tool === 'Bash') {
    const why = await bashAsks(toolInput, context, input.tool_use_id);
    return why === null ? {} : ask(why);
  }
  // A Write, Edit, MultiEdit or NotebookEdit under .git/ or .claude/: asked, Auto or not, whoever's allow would let it by.
  const guard = guardOf(tool, toolInput, context.root);
  if (guard !== null) return ask(guardReason(guard));
  if (isCriticLaunch(tool, toolInput)) {
    const request = await context.criticRequest().catch(() => undefined);
    return {
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'allow',
        updatedInput: { ...toolInput, ...(request === undefined ? {} : { prompt: request }), run_in_background: false },
      },
    };
  }
  return {};
}

/**
 * A call completed, run or failed (`PostToolUse`, `PostToolUseFailure`):
 * where the session's shells may be learns it (`ShellPlace.done`) -- a line
 * that may leave the root marks it away again, a `cd <root>` brings it back
 * once no leaving line is in flight. Decides nothing (exported for the tests).
 */
export function postToolUse(input: HookInput, context: HookContext): SyncHookJSONOutput {
  if ((input.hook_event_name === 'PostToolUse' || input.hook_event_name === 'PostToolUseFailure') && input.tool_name === 'Bash') context.shell?.done(input.tool_use_id);
  return {};
}

/** The `hooks` option of the session's query. */
export function createHooks(context: HookContext): { PreToolUse: HookCallbackMatcher[]; PostToolUse: HookCallbackMatcher[]; PostToolUseFailure: HookCallbackMatcher[] } {
  const done: HookCallbackMatcher[] = [{ hooks: [async (input) => postToolUse(input, context)] }];
  return { PreToolUse: [{ hooks: [(input) => preToolUse(input, context)] }], PostToolUse: done, PostToolUseFailure: done };
}
