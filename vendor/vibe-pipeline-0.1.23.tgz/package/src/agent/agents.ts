/**
 * The subagents and background tasks a turn started, from the message stream (Docs/agent.md §2, "Subagents"): pure,
 * so node tests it -- `session.ts` hands it every message its query sends.
 *
 * - **An `Agent` call** (or `Task`, its older name) is a row from its `tool_use`: its `subagent_type`, its
 *   `description`, running. Each message whose `parent_tool_use_id` is that call's id is its own work: a `tool_use` in
 *   it counts as a call and is its last activity ("Read src/game/hop.ts"); a `tool_progress` naming it as parent is
 *   activity too. Its `tool_result` ends it -- done, or failed with `is_error` -- unless it went to the background
 *   (`run_in_background`, or a result whose `status` is `async_launched`): then a `task_notification` ends it.
 * - **The `task_*` system messages** say more: `task_started` gives a call its task id (or, naming no call we know, is a
 *   background task of its own -- a shell when its type says bash); `task_progress` its tokens, its calls and the CLI's
 *   summary; `task_updated` its status; `task_notification` its end, its tokens and calls. One marked `skip_transcript`
 *   is the CLI's housekeeping: not listed. `background_tasks_changed`, the live set whole, lists one never heard start;
 *   a background row it leaves out waits `DROP_GRACE_MS` for its notification, then is stopped (`sweep`, the session's
 *   timer or the next message) -- at once, left out of a second set.
 * - **What is kept**: the rows of the turn running, or the last one, until the next turn begins (`begin`), which keeps
 *   only those still running; at most `MAX_AGENTS`, the oldest finished going first. A dev server's restart finds every
 *   running row ended with its CLI (`restore`).
 */
import { AGENT_TOOLS, type AgentRow } from './api-types.ts';

/** Rows kept, at most. */
export const MAX_AGENTS = 30;

/**
 * A background task gone from `background_tasks_changed`'s live set while we hold it running waits this long for its
 * `task_notification` (the level may come before the edge, `sdk.d.ts` says), then is stopped -- or at once, gone from a
 * second set too. So a notification the CLI never sends leaves no row running for good, nor the card's clock ticking.
 */
export const DROP_GRACE_MS = 10_000;

/** What changed: a row came or went or changed state (`shape`: worth keeping on disk), or only its progress, or nothing. */
export type Heard = 'shape' | 'progress' | null;

type Block = { type?: string; id?: string; name?: string; input?: unknown; tool_use_id?: string; is_error?: boolean };

/** A message as much as the tracker reads of it: the SDK's `SDKMessage`, loosely. */
export interface StreamMessage {
  type: string;
  subtype?: string;
  parent_tool_use_id?: string | null;
  message?: { content?: unknown };
  tool_use_result?: unknown;
  [key: string]: unknown;
}

const str = (v: unknown): string | null => (typeof v === 'string' && v !== '' ? v : null);
const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

/** What a row ended so says it did last. */
export const GONE = 'gone from the running tasks, with no word of its end';

/** One line of what a call was: its tool, and its most telling argument. */
export function activity(tool: string, input: unknown): string {
  const r = typeof input === 'object' && input !== null ? (input as Record<string, unknown>) : {};
  const arg = str(r.file_path) ?? str(r.path) ?? str(r.pattern) ?? str(r.command) ?? str(r.url) ?? str(r.query) ?? str(r.description) ?? str(r.prompt);
  const one = arg === null ? '' : ` ${arg.split('\n')[0]!}`;
  const line = `${tool}${one}`;
  return line.length > 120 ? `${line.slice(0, 119)}…` : line;
}

export class AgentTracker {
  private list: AgentRow[] = [];
  /** Rows running that a live set left out, by id: when it first did. */
  private readonly dropped = new Map<string, number>();

  /** The rows, oldest first. */
  get rows(): readonly AgentRow[] {
    return this.list;
  }

  /** Copies, for the state and the disk. */
  snapshot(): AgentRow[] {
    return this.list.map((r) => ({ ...r }));
  }

  /** Is any still running: the card's clock ticks for it. */
  running(): boolean {
    return this.list.some((r) => r.state === 'running');
  }

  /** Rows dropped from the live set and waiting for their end: `sweep` will end them past the grace. */
  dropping(): boolean {
    return this.dropped.size > 0;
  }

  /** Each row the live set dropped more than `DROP_GRACE_MS` ago and still running: stopped. True: one was. */
  sweep(now: number): boolean {
    let any = false;
    for (const [id, at] of this.dropped) {
      if (now - at < DROP_GRACE_MS) continue;
      const row = this.byId(id);
      if (row && row.state === 'running') {
        this.end(row, 'stopped', now);
        row.last = GONE;
        any = true;
      }
      this.dropped.delete(id);
    }
    return any;
  }

  /** A person's turn begins: the last turn's finished rows go, those still running stay. */
  begin(): boolean {
    const before = this.list.length;
    this.list = this.list.filter((r) => r.state === 'running');
    return this.list.length !== before;
  }

  /** Clear: none. */
  reset(): void {
    this.list = [];
    this.dropped.clear();
  }

  /**
   * As kept on disk, read back by a new dev server: the CLI that ran them is gone, so a row still running was stopped
   * with it.
   */
  restore(kept: unknown, now: number): void {
    this.list = [];
    if (!Array.isArray(kept)) return;
    for (const k of kept.slice(-MAX_AGENTS)) {
      if (typeof k !== 'object' || k === null) continue;
      const r = k as Record<string, unknown>;
      const id = str(r.id);
      if (id === null) continue;
      const state = r.state === 'done' || r.state === 'failed' || r.state === 'stopped' ? r.state : 'stopped';
      const ran = r.state === 'running';
      this.list.push({
        id,
        kind: r.kind === 'shell' || r.kind === 'task' ? r.kind : 'agent',
        type: str(r.type),
        description: typeof r.description === 'string' ? r.description : '',
        state,
        background: r.background === true,
        startedAt: num(r.startedAt) ?? now,
        endedAt: ran ? now : num(r.endedAt),
        tools: num(r.tools) ?? 0,
        last: ran ? 'stopped: the dev server restarted' : str(r.last),
        tokens: num(r.tokens),
        turn: str(r.turn),
        ...(str(r.task) !== null ? { task: str(r.task)! } : {}),
      });
    }
  }

  private byId(id: string | null | undefined): AgentRow | undefined {
    return id ? this.list.find((r) => r.id === id) : undefined;
  }

  private byTask(task: string | null, use: string | null): AgentRow | undefined {
    return this.byId(use) ?? (task !== null ? this.list.find((r) => r.task === task || r.id === task) : undefined);
  }

  private add(row: AgentRow): void {
    this.list.push(row);
    // Past the cap: the oldest finished go first; never one running.
    while (this.list.length > MAX_AGENTS) {
      const at = this.list.findIndex((r) => r.state !== 'running');
      this.list.splice(at >= 0 ? at : 0, 1);
    }
  }

  private end(row: AgentRow, state: AgentRow['state'], now: number): void {
    row.state = state;
    row.endedAt = now;
    this.dropped.delete(row.id);
  }

  /** One message of the stream heard: what changed. `turn`, the turn running (its rows say which they began in). */
  hear(m: StreamMessage, now: number, turn: string | null): Heard {
    // A row dropped past its grace ends with whatever comes next, as the session's own timer ends it with nothing.
    if (this.sweep(now)) {
      this.hearOne(m, now, turn);
      return 'shape';
    }
    return this.hearOne(m, now, turn);
  }

  private hearOne(m: StreamMessage, now: number, turn: string | null): Heard {
    if (m.type === 'assistant') return this.assistant(m, now, turn);
    if (m.type === 'user') return this.user(m, now);
    if (m.type === 'tool_progress') {
      const row = this.byId(str(m.parent_tool_use_id));
      const tool = str(m.tool_name);
      if (!row || row.state !== 'running' || tool === null || row.last === tool) return null;
      row.last = tool;
      return 'progress';
    }
    if (m.type === 'system') return this.system(m, now, turn);
    return null;
  }

  private assistant(m: StreamMessage, now: number, turn: string | null): Heard {
    const content = Array.isArray(m.message?.content) ? (m.message!.content as Block[]) : [];
    const parent = this.byId(str(m.parent_tool_use_id));
    let heard: Heard = null;
    for (const block of content) {
      if (block.type !== 'tool_use' || typeof block.id !== 'string' || typeof block.name !== 'string') continue;
      if (parent) {
        parent.tools++;
        parent.last = activity(block.name, block.input);
        heard ??= 'progress';
      }
      if (AGENT_TOOLS.has(block.name) && !this.byId(block.id)) {
        const input = typeof block.input === 'object' && block.input !== null ? (block.input as Record<string, unknown>) : {};
        this.add({
          id: block.id,
          kind: 'agent',
          type: str(input.subagent_type),
          description: str(input.description) ?? '',
          state: 'running',
          background: input.run_in_background === true,
          startedAt: now,
          endedAt: null,
          tools: 0,
          last: null,
          tokens: null,
          turn,
        });
        heard = 'shape';
      }
    }
    return heard;
  }

  private user(m: StreamMessage, now: number): Heard {
    const content = Array.isArray(m.message?.content) ? (m.message!.content as Block[]) : [];
    const results = content.filter((b) => b.type === 'tool_result');
    let heard: Heard = null;
    for (const block of results) {
      const row = this.byId(block.tool_use_id);
      if (!row || row.state !== 'running') continue;
      const structured = (results.length === 1 ? m.tool_use_result : undefined) as Record<string, unknown> | undefined;
      // Sent to the background: answered at once, ended by its notification.
      if (structured?.status === 'async_launched') row.background = true;
      if (row.background) continue;
      const tokens = num(structured?.totalTokens);
      const calls = num(structured?.totalToolUseCount);
      if (tokens !== null) row.tokens = tokens;
      if (calls !== null) row.tools = Math.max(row.tools, calls);
      this.end(row, block.is_error === true ? 'failed' : 'done', now);
      heard = 'shape';
    }
    return heard;
  }

  private system(m: StreamMessage, now: number, turn: string | null): Heard {
    const task = str(m.task_id);
    const use = str(m.tool_use_id);
    switch (m.subtype) {
      case 'task_started': {
        if (m.skip_transcript === true || task === null) return null;
        const row = this.byTask(task, use);
        if (row) {
          row.task = task;
          return 'progress';
        }
        const type = str(m.task_type);
        this.add({
          id: use ?? task,
          kind: str(m.subagent_type) !== null ? 'agent' : type !== null && /bash|shell/i.test(type) ? 'shell' : 'task',
          type: str(m.subagent_type) ?? type,
          description: typeof m.description === 'string' ? m.description : '',
          state: 'running',
          background: use === null,
          startedAt: now,
          endedAt: null,
          tools: 0,
          last: null,
          tokens: null,
          turn,
          task,
        });
        return 'shape';
      }
      case 'task_progress': {
        const row = this.byTask(task, use);
        if (!row) return null;
        const usage = (m.usage ?? {}) as Record<string, unknown>;
        const tokens = num(usage.total_tokens);
        const calls = num(usage.tool_uses);
        if (tokens !== null) row.tokens = tokens;
        if (calls !== null) row.tools = Math.max(row.tools, calls);
        const said = str(m.summary) ?? str(m.last_tool_name);
        if (said !== null) row.last = said;
        return 'progress';
      }
      case 'task_updated': {
        const row = this.byTask(task, use);
        const patch = (m.patch ?? {}) as Record<string, unknown>;
        if (!row) return null;
        if (patch.is_backgrounded === true) row.background = true;
        if (typeof patch.description === 'string' && patch.description !== '') row.description = patch.description;
        const status = patch.status;
        if (status === 'completed' || status === 'failed' || status === 'killed') {
          if (row.state !== 'running') return 'progress';
          this.end(row, status === 'completed' ? 'done' : status === 'failed' ? 'failed' : 'stopped', now);
          if (typeof patch.error === 'string' && patch.error !== '') row.last = patch.error;
          return 'shape';
        }
        return 'progress';
      }
      case 'task_notification': {
        const row = this.byTask(task, use);
        if (!row) return null;
        const usage = (m.usage ?? {}) as Record<string, unknown>;
        const tokens = num(usage.total_tokens);
        const calls = num(usage.tool_uses);
        if (tokens !== null) row.tokens = tokens;
        if (calls !== null) row.tools = Math.max(row.tools, calls);
        const said = str(m.summary);
        if (said !== null) row.last = said.length > 160 ? `${said.slice(0, 159)}…` : said;
        if (row.state === 'running') this.end(row, m.status === 'completed' ? 'done' : m.status === 'failed' ? 'failed' : 'stopped', now);
        return 'shape';
      }
      case 'background_tasks_changed': {
        // The live set, whole: a background task we never heard start is listed; one we hold running and the set lacks
        // waits `DROP_GRACE_MS` for its notification (the level may come before the edge) -- left out of a second set,
        // it is stopped now.
        const tasks = Array.isArray(m.tasks) ? (m.tasks as Record<string, unknown>[]) : [];
        const live = new Set(tasks.map((t) => str(t.task_id)).filter((id): id is string => id !== null));
        let heard: Heard = null;
        for (const row of this.list) {
          if (row.state !== 'running' || !row.background || row.task === undefined) continue;
          if (live.has(row.task)) {
            this.dropped.delete(row.id);
            continue;
          }
          if (this.dropped.has(row.id)) {
            this.end(row, 'stopped', now);
            row.last = GONE;
            heard = 'shape';
          } else this.dropped.set(row.id, now);
        }
        for (const t of tasks) {
          const id = str(t.task_id);
          if (id === null || this.byTask(id, null)) continue;
          const type = str(t.task_type);
          this.add({ id, kind: type !== null && /bash|shell/i.test(type) ? 'shell' : 'task', type, description: typeof t.description === 'string' ? t.description : '', state: 'running', background: true, startedAt: now, endedAt: null, tools: 0, last: null, tokens: null, turn, task: id });
          heard = 'shape';
        }
        return heard;
      }
      default:
        return null;
    }
  }
}
