/**
 * `vibe sync` (Docs/packages.md §9): the package's Claude files (`plugin.ts`'
 * `SYNCED`, from `CLAUDE_DIR`) written into a project's `.claude/`, so a terminal `claude` in the
 * project loads the `vibe` and `gladius` skills and the critic as it loads any project's -- the
 * editor's Claude has them already, as the plugin.
 *
 * - **Written, never edited**: each copy carries `SYNC_HEADER`, a Markdown comment, and is
 *   overwritten whole on every run -- the project's `postinstall` (`vibe assets --no-stamp && vibe sync`), so
 *   a new engine brings new rules at the next install. The copies are gitignored in a project.
 * - **The frontmatter stays first**: Claude Code reads a skill's or an agent's `---` block only at
 *   the top of its file, so the header goes on the line after that block; a file with none (the
 *   skill's `api.md`) has it as its first line.
 * - **Written whole or not at all** (`writeWhole`): to a temp file beside the copy, then renamed over it, so a
 *   terminal's `vibe sync` and the dev server writing the same skills never leave a reader half a file.
 * - **A temp file left by a process that died is swept** (`sweepTemps`): the next sync removes a
 *   `.<name>.<pid>.<rand>.tmp` in a folder it writes whose pid runs no more; a live writer's stays its own.
 * - **Nothing else under `.claude/` is touched**: `settings.json`, `settings.local.json`, a
 *   project's own skills and agents stay as they are.
 *
 * Nothing at module level but constants.
 */
import { mkdirSync, readdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { CLAUDE_DIR, SYNCED } from './plugin.ts';

/** The line each copy carries. */
export const SYNC_HEADER = '<!-- written by vibe sync from @vibe/pipeline; do not edit: your edits go when it runs again -->';

/** A file's text with the header in: after its frontmatter block when it opens with one, else first. */
export function withHeader(text: string): string {
  const front = /^---\r?\n[\s\S]*?\r?\n---\r?\n/.exec(text);
  return front ? `${front[0]}${SYNC_HEADER}\n${text.slice(front[0].length)}` : `${SYNC_HEADER}\n${text}`;
}

/**
 * `text` written to `file` at once: to a temp file beside it (a dot name of this process's, so a reader listing the
 * folder for `.md` passes it by), then renamed over it -- a rename within a folder replaces the file whole, so a reader
 * sees the old text or the new, never half of one. A temp file a failed write left is removed.
 */
export function writeWhole(file: string, text: string): void {
  const temp = join(dirname(file), `.${basename(file)}.${process.pid}.${Math.random().toString(36).slice(2, 8)}.tmp`);
  try {
    writeFileSync(temp, text);
    renameSync(temp, file);
  } catch (err) {
    try {
      unlinkSync(temp);
    } catch {
      // Never made, or renamed already.
    }
    throw err;
  }
}

/** `writeWhole`'s temp file's name: `.<name>.<pid>.<rand>.tmp`; the pid its writer's. */
export const TEMP_NAME = /^\..+\.(\d+)\.[a-z0-9]+\.tmp$/;

/** Whether a process of this pid runs (on this machine): `kill(pid, 0)` throws ESRCH for none, EPERM for one not ours. */
export function pidAlive(pid: number): boolean {
  if (!Number.isSafeInteger(pid) || pid <= 0) return false;
  if (pid === process.pid) return true;
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return (err as NodeJS.ErrnoException).code === 'EPERM';
  }
}

/**
 * A folder's temp files (`TEMP_NAME`) whose writer is dead removed: a write killed between its temp file and its rename
 * left it. Another writer's, still running, is its own to rename. The names removed; a folder not there has none.
 * `alive` is for a test.
 */
export function sweepTemps(dir: string, alive: (pid: number) => boolean = pidAlive): string[] {
  const gone: string[] = [];
  let names: string[];
  try {
    names = readdirSync(dir);
  } catch {
    return gone;
  }
  for (const name of names) {
    const m = TEMP_NAME.exec(name);
    if (m === null || alive(Number(m[1]))) continue;
    try {
      unlinkSync(join(dir, name));
      gone.push(name);
    } catch {
      // Renamed or removed meanwhile.
    }
  }
  return gone;
}

/** The package's Claude files written into `<root>/.claude/`, each overwritten; the paths written, relative to the root. */
export function syncClaude(root: string, from: string = CLAUDE_DIR): string[] {
  const wrote: string[] = [];
  for (const file of SYNCED) {
    const to = join(root, '.claude', file);
    mkdirSync(dirname(to), { recursive: true });
    sweepTemps(dirname(to));
    writeWhole(to, withHeader(readFileSync(join(from, file), 'utf8')));
    wrote.push(`.claude/${file}`);
  }
  return wrote;
}
