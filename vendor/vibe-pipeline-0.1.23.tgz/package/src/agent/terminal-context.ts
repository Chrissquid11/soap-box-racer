/**
 * What a terminal run's prompt is told of the editor (Docs/terminal.md D7): the run's `UserPromptSubmit` hook asks
 * `GET /__agent/terminal/context` with the run's token, and the dev server relays `studio_context` to the studio tab --
 * the same `gather(true)` a column turn sends -- and words it with the column's own `wordContext`, then a line saying the
 * picture is `view_shot`'s. A text, never an image: the hook's stdout becomes context, and a picture is a call away.
 *
 * Pure but for the models' files (`resolveModels`, handed in): node tests it.
 */
import { studioContextWords } from '../mcp/tools/studio.ts';
import { awayOf, awayWords, type ModelsOf, type PageAnswer } from '../mcp/words.ts';

/** How long the hook's ask waits for the tab, in milliseconds: a prompt is not held up for long. */
export const CONTEXT_MS = 4000;

/** The words for a prompt from what the tab answered `studio_context` with. */
export async function promptContext(answer: PageAnswer, models: ModelsOf, url: string): Promise<string> {
  if ('result' in answer) {
    if (answer.result.tool !== 'studio_context') return 'The editor\'s context could not be read: the tab answered something else.';
    return (await studioContextWords(answer.result.context, models)).words;
  }
  if ('error' in answer) return `The editor's context could not be read: ${answer.error}`;
  return `The editor's context could not be read. ${awayWords(awayOf(answer), 'studio_context', CONTEXT_MS, url)}`;
}
