/**
 * `canUseTool` (Docs/agent.md §2, Permissions): every tool call is permitted
 * here, or by rule. The session runs with `permissionMode: 'default'`, so a
 * call the user's settings do not allow reaches this.
 *
 * - **Nothing under `.git/` or `.claude/` is written unasked** (`GUARDED`,
 *   `guardOf`), nor this machine's settings (`*.local.json`, `*.local`:
 *   `LOCAL_FILES`), Auto or not: a `Write`, `Edit`, `MultiEdit` or
 *   `NotebookEdit` of a file there, or a command line that writes one -- a
 *   redirect, `cp`, `mv`, `tee`, `touch`, `sed -i` … -- is a card, the path
 *   matched ignoring case as the volume does, and as its real path where it
 *   exists; a source copied or moved into a folder (`cp x .`) by its name
 *   there; a fetch to a dev server route that writes one (`FLOOR_ROUTES`:
 *   `PUT /__assets/tools`, `tools_set`'s) is that write. An archive unpacked
 *   whole or a patch applied (`writesUnnamed`) asks under Auto and Unsafe
 *   auto: what it writes is not named. The hook asks it past any
 *   `allow`. git's own store runs programs (its config, its hooks) and no
 *   snapshot has it; Claude Code's settings hold the person's own rules. Such
 *   a card has no Always (it would allow the folder for good), and its Deny
 *   tells the agent not to write there another way.
 * - **Auto** allows at once -- unless a rule names the call, it is a git
 *   command that does more than read, or `blockedPath` says it reaches
 *   outside the allowed folders. Those are cards. A `blockedPath` inside the
 *   project -- the CLI names one for an `rm -r`'s folder and a `> file`'s
 *   file there too -- is Auto's own rules' to decide, as an Edit is, but
 *   under `GUARDED`. A read the CLI names outside because it goes through
 *   one of the engine's links (`linkedRoots`: `node_modules/@vibe/*` into an
 *   npm workspace, the engine's checkout in source mode, read once as the
 *   session starts) goes by under Auto -- a reading tool, or a plain line
 *   each of whose commands is on `readsOnly`'s allow-list; a write there is a card.
 * - **Auto's own allowances only on a plain line** (`notPlain`, `withheld`):
 *   the host's `Bash(rm -rf:*)` spared for what is made again, git beyond its
 *   reading commands (`rm`, `mv`, `add`, `commit`, a new branch, `fetch`) and
 *   a read through the engine's link are given only to a line every word of
 *   which is a literal, every program on a short list run as itself, `cd` only
 *   to the root -- and only while the shell is at the root (`ShellPlace`: Claude
 *   Code keeps its folder from call to call). Anything else asks, as before
 *   Auto spared any: matching each dangerous spelling did not converge.
 * - **The rules**: the host's own (`HOST_ASK`: the commands that can wipe
 *   uncommitted work) and the user's `ask` rules, every settings file's, as
 *   the CLI resolves them (`askRules()`), matched as `[...HOST_ASK,
 *   ...userAskRules]`. `HOST_ASK` reaches the CLI too, but only this session's:
 *   `session.ts` passes it through `Options.settings`, the flag layer, so a
 *   terminal session in the project never sees it, and it is written to no
 *   file. The SDK's `matchedAskRule` says "rule-forced" only for a rule on a
 *   whole tool (checked in 0.3.220: a `Bash(git checkout:*)` ask arrives with
 *   neither it nor a reason), so the rules are matched here as well. A match
 *   too many is a card; one too few would be a `git checkout` run unasked.
 * - **A line is read as the shell runs it** (`commandsOf`): every command of
 *   it -- `;`, `&&`, `|`, `$(…)`, `sh -c '…'`, `eval`, `find -exec`, `watch`,
 *   `function f { … }`, a heredoc, a here-string, an `echo`/`printf` piped in
 *   or a process substitution (`bash <(echo …)`, `sh < <(…)`) that a shell
 *   reads its script from; one fed by a pipe or a substitution that is not
 *   literal (`base64 -d | sh`) is a card under Auto -- each matched as written
 *   and as run: the program's name lowercased (`GIT` runs git on this
 *   volume), quotes off (`$'…'` with its escapes), a heredoc's text not commands,
 *   `VAR=…` and the wrappers (`env`, `command`, `sudo`, `xargs`, `time`,
 *   `nice`, `busybox` …) taken off -- and kept as what the command ran
 *   under, a nested line's too (`find -exec sh -c 'rm …'` is `find`'s `rm`) --
 *   the program by its own name, git's global options
 *   (`-C <dir>`, `-c <k=v>`, `--no-pager` …) gone, `rm -fr`, `-Rf` and
 *   `-r -f` all `rm -rf`. A rule for `git checkout` names `git -C . checkout`
 *   and `bash -c "git checkout"`.
 * - **git, under Auto, only reads unasked** (`gitAsks`), each command by an
 *   allow-list of its forms: `status`, `diff`, `log`, `show`, `branch` and `tag`
 *   only listing (a new branch too), `remote` only getting, `config` only
 *   getting the project's own (`--local`), `grep` with its known options,
 *   `rev-parse`, `ls-files`, `stash list` … -- every read held in the project
 *   (`readsHere`: no `--no-index`, `--contents`, `--output`, `--ext-diff`,
 *   path outside the root as a word or an option's value; a short option read
 *   as getopt reads a bundle) -- and `fetch` from a remote the repository has, `add` of paths in it
 *   and `commit` (not `--amend`), `rm` and `mv` unforced, and
 *   a new branch or a move to one (`switch -c`, `checkout -b`), which git
 *   refuses where a change not committed would be lost -- `rm`, `mv` and
 *   `commit` with only the options on their lists, any other flag check
 *   taking git's prefixes (`--f` is `--force`). Any other git command is a
 *   card, and so is a `-c` setting that could run a program, git pointed at
 *   anything but the project (`-C`, `--git-dir`, `--work-tree`: `gitPlace`),
 *   and git doing more than read on a line that is not plain -- a git or rm
 *   hidden among a command's words (`noglob git …`, `hiddenIn`) read too. The host's rules
 *   never name a git command that only reads: `git stash list` goes by; the
 *   user's own rules name what they name.
 * - **Deletions it can read are cards under Auto** (`deletes`): a recursive
 *   `rm` of anything but `REMADE` (`dist/`, `node_modules/`, `.cache/assets/`
 *   …) and what git ignores, as plain paths on a plain line nothing before
 *   could change them in (`sparedRms`, `remadeTarget`) -- never `KEPT` (`.trash/`, `.cache/agent/`,
 *   `.claude/`, `*.local*`, `.env*`), which nothing makes again; under Auto,
 *   the host's `Bash(rm -rf:*)` spares what this lets by (`hostAsk`); `xargs rm`, `find -exec rm`, `find -delete`, `rsync --delete`,
 *   `truncate`, `shred`, `rimraf`; and a program that is no plain word
 *   (`$g`, `git${IFS}checkout`, `{git,reset}`).
 * - **What it cannot read goes by**: an interpreter's code (`python3 -c`,
 *   `node -e`, `perl -e`), a script (`bash x.sh`, `./x.sh`, `npm run x`), a
 *   person's aliases and shell functions, `> file` into the project but under
 *   `GUARDED`, `mv x /dev/null`. This is
 *   a seatbelt for a cooperative model's habits, not a sandbox: Undo this turn
 *   (`changes.ts`' snapshot) puts back what a command changed or deleted.
 * - **The same matcher runs before the rules** (`hooks.ts`): a person's own
 *   broad `allow` (`Bash(git:*)`) decides before `canUseTool` is asked, so
 *   the `PreToolUse` hook answers `ask` for what the host's rules or Auto's
 *   line name, and the call comes here.
 * - **A card** has the SDK's `title` as its line when it gives one, else one
 *   made here ("Claude wants to edit crate.lua"); its description; under
 *   Auto, the rule that made it a card in a line ("Auto still asks: git
 *   push"), so it does not read as Auto being broken; why it is asked; and the input's 160-character summary. An editor tool's card
 *   (`mcp__studio__scene_set`, §8) is always the tool's name, and its detail
 *   the call in a line: "set Transform.px = 3 on 2 entities". Answers go back with a
 *   `decisionClassification`: Allow `user_temporary`, Always `user_permanent`,
 *   Deny `user_reject`.
 * - **Always** returns the SDK's `suggestions` as `updatedPermissions`, kept
 *   where the person picks: this conversation (`session`), this machine
 *   (`localSettings`) -- and, behind More…, the project (`projectSettings`,
 *   committed) or everywhere (`userSettings`). A `setMode` suggestion is
 *   dropped (it would move the session to `acceptEdits` and make the Auto
 *   tick lie): an `Edit`, whose only suggestion it is, has no Always. Nor has
 *   a card a rule asked for, or Auto's own line: an `ask` rule outranks an
 *   `allow`, and the hook asks before the rules, so an Always there would keep
 *   nothing.
 * - **AskUserQuestion is a question card**, Auto or not: its answers go back
 *   as `updatedInput: { ...input, answers }`, question to label, several
 *   joined by ", ". Skip denies: "The user chose not to answer."
 * - **A turn may refuse tools for its length** (`TurnRequest.deny`; the Git card's draft sends `DRAFT_DENY`,
 *   `@vibe/editor`'s `studio/git/draft.ts`: the editing tools, Bash, the editor's writers): `context.denied` says so first, and the call is denied "not in this turn"
 *   (`notInTurn`) -- before any card, rule or Auto. The hook (`hooks.ts`) denies it as well, before the rules,
 *   so a person's `allow` of `Edit` lets nothing by.
 * - **A card waits**: no timeout. Only Stop, Clear, the server's exit or the
 *   call's `signal` deny it ("stopped"); a page going away denies nothing.
 */
import type { CanUseTool, PermissionResult, PermissionUpdate } from '@anthropic-ai/claude-agent-sdk';
import { execFileSync } from 'node:child_process';
import { lstatSync, readdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { homedir } from 'node:os';
import { basename, dirname, isAbsolute, join, posix, relative, resolve, sep } from 'node:path';
import { callKind, metaOf, type ToolMeta } from '../mcp/catalog.ts';
import type { AlwaysChoice, AlwaysDestination, Card, PermissionLevel, Question } from './api-types.ts';
import { clip, STUDIO_TOOLS, summarise } from './log.ts';

/** How a card was answered. */
export type CardAnswer =
  | { outcome: 'allowed' }
  | { outcome: 'always'; destination: AlwaysDestination }
  | { outcome: 'denied' }
  | { outcome: 'answered'; answers: Record<string, string | string[]> }
  | { outcome: 'skipped' }
  | { outcome: 'stopped' };

/** What `canUseTool` needs of the session. */
export interface PermissionContext {
  /** The project root: paths are named relative to it, and rules with a leading `/` are under it. */
  root: string;
  /** The permission level now (Docs/mcp.md §7 D3): `ask`, `auto` or `unsafe` -- read at every call, so a change mid-turn counts from the next. */
  level(): PermissionLevel;
  /** A studio tool's catalogue entry, by its name (`../mcp/catalog.ts`' `metaOf`): a test's own. */
  metaOf?(tool: string): ToolMeta | undefined;
  /** The user's own `ask` rules, every settings file's, as the CLI resolves them now (not `HOST_ASK`). */
  askRules(): Promise<readonly string[]>;
  /** Is a path, relative to the root, ignored by git: a recursive `rm` of one goes by under Auto. */
  ignored: Ignored;
  /** A card shown; resolves with its answer, `stopped` when Stop, Clear, the exit or `signal` ends it. */
  open(card: Card, signal: AbortSignal): Promise<CardAnswer>;
  /** A card's id. */
  newId(): string;
  /** Is the tool refused for the turn running (`TurnRequest.deny`): its refusal's words, or null. Before anything else. */
  denied?(tool: string): string | null;
  /** Where links in the project lead (`linkedRoots`): a read there, named outside, goes by under Auto. None given, none. */
  linked?(): readonly string[];
  /** Is `engine` under the root a folder of its own (`engineDir`), read as the session starts: `git -C engine` is then plain. */
  engine?: boolean;
  /** Where the session's shells may be (`ShellPlace`): shared with the hook. None given, always at the root. */
  shell?: ShellPlace;
  /** The project's remotes (`gitRemotes`), read as the session starts: `git fetch` from one goes by under Auto. None given, none. */
  remotes?: readonly string[];
  /** The engine's checkout's remotes (`gitRemotes` of `engine/`), read as the session starts: `git -C engine fetch` from one goes by. None given, none. */
  engineRemotes?: readonly string[];
  /** The dev server's port: a `curl` to its own routes there asks under Auto (`devRouteOf`). None given, any loopback port. */
  port?(): number | undefined;
  /** The files the running turn wrote, project-relative (a studio tool's `Place.written`: `git_commit`). None given, none. */
  written?(): readonly string[];
}

/**
 * The host's own `ask` rules: what can wipe work that is not committed --
 * and undoing a worse review round (§3) makes `git checkout -- <file>` likely.
 * This session's alone (`session.ts`' `settings`), never a file's: a terminal
 * session in the project is not asked about them.
 */
export const HOST_ASK: readonly string[] = [
  'Bash(git checkout:*)',
  'Bash(git restore:*)',
  'Bash(git reset:*)',
  'Bash(git clean:*)',
  'Bash(git stash:*)',
  'Bash(git switch:*)',
  'Bash(git push:*)',
  'Bash(rm -rf:*)',
];

/** Where an Always can be kept, in the menu's order, what each says, and which wait behind More…. */
export const DESTINATIONS: readonly { destination: AlwaysDestination; label: string; more: boolean }[] = [
  { destination: 'session', label: 'This conversation', more: false },
  { destination: 'localSettings', label: 'On this machine', more: false },
  { destination: 'projectSettings', label: 'For the project, committed', more: true },
  { destination: 'userSettings', label: 'Everywhere, in your own settings', more: true },
];

// ---------------------------------------------------------------- rules

/** A rule as written: `Bash(git checkout:*)` is `Bash` and `git checkout:*`. */
export function parseRule(rule: string): { tool: string; content: string | null } {
  const m = /^\s*([^()\s]+)\s*(?:\(([\s\S]*)\))?\s*$/.exec(rule);
  return m ? { tool: m[1]!, content: m[2] ?? null } : { tool: rule.trim(), content: null };
}

/** A rule written back: the tooltip's words. */
export function ruleText(rule: { toolName: string; ruleContent?: string }): string {
  return rule.ruleContent === undefined ? rule.toolName : `${rule.toolName}(${rule.ruleContent})`;
}

// ---------------------------------------------------------------- a command line, as the shell runs it

/** One command a line runs, read two ways: a rule matching either names it. */
export interface Command {
  /** As written: its words, quotes off, the `VAR=…` before it dropped. */
  written: string;
  /** As run (`normalise`): wrappers, git's global options and folders gone, `rm`'s flags in one order. */
  run: string;
  /** `run`'s words. */
  words: readonly string[];
  /** The program's word as written, quotes off, folder and all: `$g`, `git${IFS}checkout`, `/usr/bin/git`. */
  program: string;
  /** The wrappers it ran under, outermost first (`sudo`, `xargs` …), and `find` for a `find -exec`'s command. */
  via: readonly string[];
  /** For git: the settings its `-c` and `--config-env` gave, by key. */
  config: readonly string[];
  /**
   * For git: where its own options point it -- `-C <dir>`, `--git-dir`,
   * `--work-tree` -- in order, and any other of its own options not known to
   * change nothing (`GIT_GLOBAL_SAFE`; `--bare` …), value ''. Auto asks
   * unless each names the project or its engine (`gitPlace`).
   */
  places?: readonly { option: string; value: string }[];
  /** The variables set for it (`VAR=…` before it, after a wrapper or through `env`), as written: a reader given one may read its options from elsewhere. */
  assigned?: readonly string[];
  /** The files its redirections write (`> f`, `>> f`, `&> f`), as written. */
  outs?: readonly string[];
  /** For git: a `GIT_*` its line sets for it elsewhere than on it, or `set -a` (`lineGitEnv`): Auto asks. */
  lineEnv?: string;
  /**
   * What it runs cannot be read, and why, for Auto's card: nested too deep
   * (`DEPTH`), or a shell whose script comes from a pipe or a process
   * substitution whose text is not literal (`base64 -d | sh`, `bash <(curl …)`).
   */
  unread?: string;
}

/** Lines in lines (`sh -c`, `eval`, `$(…)`) are read this deep, at most: deeper, the line asks. */
const DEPTH = 8;

/** A word that sets a variable for the command after it: `FOO=1`. */
const ASSIGNS = /^[A-Za-z_][A-Za-z0-9_]*=/;

/** Words that open or close a shell construct, not a program: `if git diff; then git stash; fi`. */
const KEYWORDS = new Set(['if', 'then', 'else', 'elif', 'fi', 'do', 'done', 'while', 'until', '!', '{', '}', 'esac']);

/** ANSI-C quoting's escapes (`$'…'`) that stand for one character. */
const ANSI_C: Record<string, string> = { n: '\n', t: '\t', r: '\r', a: '\x07', b: '\b', e: '\x1b', E: '\x1b', f: '\f', v: '\v', '\\': '\\', "'": "'", '"': '"', '?': '?' };

/**
 * An ANSI-C quoted word's text (`$'…'`), from just inside its opening quote:
 * `\'` a quote, not its end; `\n`, `\x63`, `\143`, `\u0063` and the rest the
 * characters they stand for -- `$'\x63heckout'` is `checkout`. Its end: the
 * closing quote's index, or the line's length.
 */
function ansiC(line: string, from: number): { text: string; end: number } {
  let text = '';
  let i = from;
  for (; i < line.length && line[i] !== "'"; i++) {
    const ch = line[i]!;
    if (ch !== '\\' || i + 1 >= line.length) {
      text += ch;
      continue;
    }
    const n = line[++i]!;
    const hex = n === 'x' ? /^[0-9a-fA-F]{1,2}/ : n === 'u' ? /^[0-9a-fA-F]{1,4}/ : n === 'U' ? /^[0-9a-fA-F]{1,8}/ : null;
    if (ANSI_C[n] !== undefined) text += ANSI_C[n];
    else if (hex) {
      const m = hex.exec(line.slice(i + 1));
      const code = m ? parseInt(m[0], 16) : -1;
      text += code >= 0 && code <= 0x10ffff ? String.fromCodePoint(code) : `\\${n}`;
      if (m) i += m[0].length;
    } else if (n >= '0' && n <= '7') {
      const m = /^[0-7]{1,3}/.exec(line.slice(i))!;
      text += String.fromCharCode(parseInt(m[0], 8) & 0xff);
      i += m[0].length - 1;
    } else if (n === 'c' && i + 1 < line.length) text += String.fromCharCode(line[++i]!.charCodeAt(0) & 0x1f);
    else text += `\\${n}`;
  }
  return { text, end: i };
}

/**
 * One simple command of a line, lexed: its words -- a process substitution
 * (`<(…)`, `>(…)`) one word, as written; whether a pipe feeds it (`a | b`'s
 * `b`); its here-string's word (`<<< word`), if it has one; the substitution
 * its input is redirected from (`sh < <(…)`), if it is; and the files its
 * redirections write (`> f`, `>> f`, `&> f`; never `2>&1`).
 */
interface LexedCommand {
  words: string[];
  piped: boolean;
  here: string | null;
  fed: string | null;
  outs: string[];
  /** It opens a heredoc: its text is read where a shell reads it (`Lexed.bodies`). */
  doc: boolean;
}

/** A process substitution's text, from a word that is one (`<(echo x)`), else null. */
const substitution = (word: string): string | null => (/^[<>]\(/.test(word) && word.endsWith(')') ? word.slice(2, -1) : null);

/** A line, lexed: its simple commands, the lines held in it, and its heredocs' text. */
interface Lexed {
  commands: LexedCommand[];
  /** What `$(…)`, `<(…)`, `>(…)` and backticks hold, in the line and in a heredoc whose delimiter is unquoted: lines of their own. */
  inner: string[];
  /** Each heredoc's text: lines of their own only where a shell reads its script from them (`lines`). */
  bodies: string[];
}

/**
 * A line's simple commands as words, the way the shell splits them: quotes
 * (`'…'` literal, `"…"` with `\` escapes, `$'…'` with C escapes) taken off, a
 * `\` escaping the next character, `#` at a word's start a comment; split on
 * `;`, `&`, `&&`, `|`, `||`, newlines and parentheses, a command a pipe feeds
 * marked so; a redirection and its target dropped, but a here-string's word
 * (`<<< word`), kept as its command's input. A heredoc (`<<`, `<<-`) is text, not commands: from the end
 * of the line that opens it to its delimiter's line, whatever quotes it holds
 * -- an apostrophe in it opens nothing. What `$(…)`, `<(…)`, `>(…)` and
 * backticks hold is a line of its own as well, found wherever the shell runs
 * it: in the line, in double quotes too, and in a heredoc whose delimiter is
 * not quoted.
 */
function lex(line: string): Lexed {
  const commands: LexedCommand[] = [];
  let words: string[] = [];
  let word: string | null = null;
  /**
   * The next word is a redirection's target: read (`<`), dropped; written
   * (`>`), kept among the files the command writes -- a duplicated descriptor
   * (`>&2`) not; or a here-string's, kept as the command's input.
   */
  let target: false | 'drop' | 'out' | 'dup' | 'here' = false;
  /** The command under way's here-string, the substitution its input comes from, the files it writes, and whether a pipe feeds it. */
  let here: string | null = null;
  let fed: string | null = null;
  let outs: string[] = [];
  let doc = false;
  let piped = false;
  /** Heredocs opened on the line under way, read when it ends: each one's delimiter, a quoted one's body literal, `<<-`'s tabs. */
  const pending: { delim: string; quoted: boolean; tabs: boolean }[] = [];
  const bodies: string[] = [];
  /** The line less every heredoc's body, and the unquoted bodies: where `$(…)` and backticks run. */
  let scanned = '';
  let from = 0;
  const endWord = (): void => {
    if (word === null) return;
    if (target === 'here') here = word;
    else if (target === 'out' || (target === 'dup' && !/^(\d+|-)$/.test(word))) outs.push(word);
    else if (target === false) words.push(word);
    target = false;
    word = null;
  };
  const endCommand = (): void => {
    endWord();
    if (words.length > 0 || outs.length > 0 || fed !== null) commands.push({ words, piped, here, fed, outs, doc });
    words = [];
    here = null;
    fed = null;
    outs = [];
    doc = false;
    target = false;
  };
  for (let i = 0; i < line.length; i++) {
    const c = line[i]!;
    if ((c === '<' || c === '>') && line[i + 1] === '(') {
      // A process substitution: a word of its own, as written -- or, after a `<`, what the command's input comes from (`sh < <(…)`).
      let depth = 0;
      let j = i + 1;
      for (; j < line.length; j++) {
        if (line[j] === '(') depth++;
        else if (line[j] === ')' && --depth === 0) break;
      }
      const text = line.slice(i, Math.min(j + 1, line.length));
      if (target === 'drop' && word === null) {
        fed = text.slice(2, -1);
        target = false;
      } else word = (word ?? '') + text;
      i = j;
    } else if (c === "'") {
      const close = line.indexOf("'", i + 1);
      word = (word ?? '') + line.slice(i + 1, close < 0 ? line.length : close);
      i = close < 0 ? line.length : close;
    } else if (c === '$' && line[i + 1] === "'") {
      const { text, end } = ansiC(line, i + 2);
      word = (word ?? '') + text;
      i = end;
    } else if (c === '$' && line[i + 1] === '"') {
      // `$"…"`, a translated string: double quotes.
      word ??= '';
    } else if (c === '"') {
      word ??= '';
      for (i++; i < line.length && line[i] !== '"'; i++) {
        if (line[i] === '\\' && i + 1 < line.length && '"\\$`\n'.includes(line[i + 1]!)) i++;
        word += line[i];
      }
    } else if (c === '\\') {
      if (line[i + 1] === '\n') i++;
      else if (i + 1 < line.length) word = (word ?? '') + line[++i];
    } else if (c === '#' && word === null) {
      const nl = line.indexOf('\n', i);
      i = nl < 0 ? line.length : nl - 1;
    } else if (c === ' ' || c === '\t') endWord();
    else if (c === '<' && line[i + 1] === '<' && line[i + 2] !== '<') {
      // A heredoc: its delimiter, one word -- quoted anywhere, its body is literal -- and the body after this line.
      if (word !== null && /^\d+$/.test(word)) word = null;
      endWord();
      i += 2;
      const tabs = line[i] === '-';
      if (tabs) i++;
      while (line[i] === ' ' || line[i] === '\t') i++;
      let raw = '';
      while (i < line.length && !' \t\n;&|<>()'.includes(line[i]!)) {
        const ch = line[i]!;
        if (ch === "'" || ch === '"') {
          const close = line.indexOf(ch, i + 1);
          const end = close < 0 ? line.length : close + 1;
          raw += line.slice(i, end);
          i = end;
        } else if (ch === '\\' && i + 1 < line.length) {
          raw += line.slice(i, i + 2);
          i += 2;
        } else raw += line[i++];
      }
      i--;
      pending.push({ delim: raw.replace(/['"\\]/g, ''), quoted: /['"\\]/.test(raw), tabs });
      doc = true;
    } else if (c === '>' || c === '<' || (c === '&' && line[i + 1] === '>')) {
      // `2>&1`, `>out`, `&>log`, `<in`: the fd before it, the operator, and its target are no words of the command;
      // `<<<word`, a here-string, is its input, kept.
      if (word !== null && /^\d+$/.test(word)) word = null;
      endWord();
      const herestring = c === '<' && line[i + 1] === '<' && line[i + 2] === '<';
      let op = c;
      while ('<>&|'.includes(line[i + 1] ?? ' ') && !(line[i + 1] === '&' && line[i + 2] === '&') && !(line[i + 1] === '<' && line[i + 2] === '(')) op += line[++i];
      target = herestring ? 'here' : !op.includes('>') ? 'drop' : op.endsWith('&') ? 'dup' : 'out';
    } else if (';&|\n()'.includes(c)) {
      const had = words.length > 0 || word !== null;
      endCommand();
      // What feeds the next command: a pipe (`|`, `|&`), never `||`; a newline after a `|` goes on with it.
      if (c === '|') {
        if (line[i + 1] === '|') {
          i++;
          piped = false;
        } else {
          if (line[i + 1] === '&') i++;
          piped = true;
        }
      } else if (c !== '\n' || had) piped = false;
      if (c !== '\n' || pending.length === 0) continue;
      // The line that opened heredocs has ended: each body runs to its delimiter's line (`<<-`: tabs before it off).
      scanned += line.slice(from, i + 1);
      let at = i + 1;
      for (const doc of pending) {
        const text: string[] = [];
        while (at < line.length) {
          const nl = line.indexOf('\n', at);
          const end = nl < 0 ? line.length : nl;
          const one = line.slice(at, end);
          at = end + 1;
          if ((doc.tabs ? one.replace(/^\t+/, '') : one) === doc.delim) break;
          text.push(one);
        }
        const body = text.join('\n');
        bodies.push(body);
        if (!doc.quoted) scanned += `${body}\n`;
      }
      pending.length = 0;
      i = at - 1;
      from = at;
    } else word = (word ?? '') + c;
  }
  endCommand();
  scanned += line.slice(from);
  const inner: string[] = [];
  for (let i = 0; i < scanned.length; i++) {
    const c = scanned[i]!;
    if ((c === '$' || c === '<' || c === '>') && scanned[i + 1] === '(') {
      let depth = 0;
      let j = i + 1;
      for (; j < scanned.length; j++) {
        if (scanned[j] === '(') depth++;
        else if (scanned[j] === ')' && --depth === 0) break;
      }
      inner.push(scanned.slice(i + 2, j));
      i = j;
    } else if (c === '`') {
      const close = scanned.indexOf('`', i + 1);
      inner.push(scanned.slice(i + 1, close < 0 ? scanned.length : close));
      i = close < 0 ? scanned.length : close;
    }
  }
  return { commands, inner, bodies };
}

/**
 * The index of the first word after a wrapper's own options, from `i`:
 * `--` ends them; an option in `takes` takes the next word too -- a long one
 * by any prefix of it (`sudo --us root`, getopt's unique prefix), a short one
 * last in a bundle (`sudo -nu root`), or the rest of its word (`-Dsrc`). The
 * values of the options in `chdir` -- where the wrapper runs the program
 * (`sudo -D <dir>`, `--chdir=<dir>`) -- go into `dirs`.
 */
function pastOptions(words: readonly string[], i: number, takes: ReadonlySet<string>, chdir: ReadonlySet<string> = new Set(), dirs: string[] = []): number {
  const long = [...takes].filter((o) => o.startsWith('--'));
  while (i < words.length) {
    const w = words[i]!;
    if (w === '--') return i + 1;
    if (!w.startsWith('-') || w === '-') return i;
    if (takes.has(w)) {
      if (chdir.has(w)) dirs.push(words[i + 1] ?? '');
      i += 2;
    } else if (w.startsWith('--')) {
      const eq = w.indexOf('=');
      const name = eq < 0 ? w : w.slice(0, eq);
      const option = long.find((o) => longFlag(name, o));
      if (option !== undefined && chdir.has(option)) dirs.push(eq < 0 ? (words[i + 1] ?? '') : w.slice(eq + 1));
      i += option !== undefined && eq < 0 ? 2 : 1;
    } else {
      let step = 1;
      for (let k = 1; k < w.length; k++) {
        const option = `-${w[k]}`;
        if (!takes.has(option)) continue;
        const rest = w.slice(k + 1);
        if (rest === '') step = 2;
        if (chdir.has(option)) dirs.push(rest === '' ? (words[i + 1] ?? '') : rest);
        break;
      }
      i += step;
    }
  }
  return i;
}

/** Each wrapper's options that run the program in another folder: `sudo -D <dir>`. `env -C` is read with env's own. */
const WRAPPER_CHDIR: Record<string, ReadonlySet<string>> = { sudo: new Set(['-D', '--chdir']) };

/** env's options that take a word: `-u <name>`, `-C <dir>` (`--chdir`), `-S <line>` (`--split-string`), macOS's `-P <path>`. */
const ENV_TAKES = 'uCSP';
const ENV_LONG = ['--unset', '--chdir', '--split-string'];

/** What each wrapper's options are that take a word: the program it runs is after them. */
const WRAPPERS: Record<string, ReadonlySet<string>> = {
  command: new Set(),
  builtin: new Set(),
  nohup: new Set(),
  exec: new Set(['-a']),
  time: new Set(['-o', '-f', '--output', '--format']),
  nice: new Set(['-n', '--adjustment']),
  sudo: new Set(['-u', '-g', '-C', '-D', '-h', '-p', '-r', '-t', '-T', '-U', '-R', '--user', '--group', '--chdir', '--host', '--prompt', '--role', '--type', '--close-from', '--other-user', '--chroot', '--command-timeout']),
  xargs: new Set(['-I', '-J', '-L', '-n', '-P', '-R', '-S', '-s', '-d', '-E', '-a', '--arg-file', '--delimiter', '--eof', '--max-args', '--max-procs', '--max-chars', '--max-lines', '--replace', '--process-slot-var']),
  timeout: new Set(['-s', '-k', '--signal', '--kill-after']),
  busybox: new Set(),
  // Each runs the program after its options as it is (review F): `stdbuf -oL git checkout …`, `arch -arm64 git reset …`.
  stdbuf: new Set(['-i', '-o', '-e', '--input', '--output', '--error']),
  arch: new Set(['-arch', '-e']),
  caffeinate: new Set(['-t', '-w']),
  doas: new Set(['-u', '-C']),
  unbuffer: new Set(),
  setsid: new Set(),
  ionice: new Set(['-c', '-n', '-p', '-P', '-u', '--class', '--classdata', '--pid', '--pgid', '--uid']),
  chrt: new Set(['-T', '-P', '-D', '--sched-runtime', '--sched-period', '--sched-deadline']),
  flock: new Set(['-w', '-E', '--wait', '--timeout', '--conflict-exit-code']),
};

/** Wrappers whose first word after their options is no program: `timeout`'s duration, `chrt`'s priority, `flock`'s lock file. */
const WRAPPER_ARG = new Set(['timeout', 'chrt', 'flock']);

/** git's environment that changes nothing it runs: any other `GIT_*` set before git is a setting, as `-c` is (`GIT_CONFIG_*`, `GIT_PAGER=…`, `GIT_EXTERNAL_DIFF`, `GIT_SSH_COMMAND` …). */
const SAFE_GIT_ENV = /^(GIT_OPTIONAL_LOCKS=|GIT_TERMINAL_PROMPT=|GIT_PAGER=(cat)?$)/;

/** `watch`'s options that take a word: the line it runs, through `sh -c`, is the rest. */
const WATCH_TAKES = new Set(['-n', '--interval', '-q', '--equexit']);

/** Shells whose `-c` runs the line after it. */
const SHELLS = new Set(['sh', 'bash', 'zsh', 'dash', 'ksh', 'fish']);

/** A shell's options that take a word. */
const SHELL_TAKES = new Set(['-o', '-O', '+o', '+O', '--rcfile', '--init-file']);

/** git's own options before its command that take a word. */
const GIT_TAKES = new Set(['-C', '-c', '--git-dir', '--work-tree', '--namespace', '--config-env']);

/** git's own options that point it at a repository or a tree: Auto asks unless they name the project (`gitPlace`). */
const GIT_PLACES = new Set(['-C', '--git-dir', '--work-tree']);

/** git's own options that change nothing it runs, or are read as settings (`-c`, `--config-env`, `--exec-path`): any other is a place Auto asks about. */
const GIT_GLOBAL_SAFE = new Set(['-c', '--config-env', '--exec-path', '--no-pager', '-P', '-p', '--paginate', '--no-optional-locks', '--literal-pathspecs', '--glob-pathspecs', '--noglob-pathspecs', '--icase-pathspecs', '--no-replace-objects', '--no-advice', '--namespace', '--version', '--help', '-v', '-h']);

/**
 * A program's name as run: `/usr/bin/git` is `git` -- and `GIT` and `Git` are
 * too: on a volume that ignores case, macOS's own default and this project's,
 * `GIT reset` runs git. Lowercased everywhere: a match too many is a card.
 */
const programOf = (word: string): string => word.slice(word.lastIndexOf('/') + 1).toLowerCase();

/**
 * One simple command as it runs (§2, Permissions): what goes before the
 * program it runs taken off -- `VAR=…`, shell keywords, and the wrappers
 * `env`, `command`, `builtin`, `exec`, `nohup`, `time`, `nice`, `sudo`,
 * `xargs`, `timeout`, `stdbuf`, `arch`, `caffeinate`, `doas`, `unbuffer`,
 * `setsid`, `ionice`, `chrt` and `flock` with their options -- the program by
 * its own name, not its folder -- a wrapper's options as getopt reads them,
 * by a long one's prefix and bundled; where a wrapper runs it in another folder
 * (`env -C <dir>`, `sudo -D <dir>`), for git that folder is a
 * `-C` place before its own; for git, its global options (`-C <dir>`,
 * `-c <k=v>`, `--no-pager` …) gone, the settings they gave kept apart, with
 * any `GIT_*` set for it (`GIT_CONFIG_COUNT=1 …`, `GIT_PAGER=…`) but the few
 * that run nothing (`SAFE_GIT_ENV`); for `rm`, `-r`,
 * `-R` or `--recursive` with `-f` or `--force`, however bundled or ordered,
 * as `rm -rf`. A shell's `-c '<line>'`, `eval`, `env -S`, `watch` and `find
 * -exec` run a line or a command of their own: each is read as well, under
 * what this one ran under (`via`: `find -exec sh -c 'rm …'` is `find`'s `rm`,
 * `xargs sh -c 'rm …'` `xargs`').
 */
function normalise(raw: readonly string[], depth: number, out: Command[], outer: readonly string[] = [], set: readonly string[] = []): void {
  const at = out.length;
  const dirs: string[] = [];
  normaliseIn(raw, depth, out, outer, set, dirs);
  if (dirs.length === 0) return;
  // A wrapper ran it -- and every command of a line it ran -- in another folder: git's is a `-C` place there.
  for (const command of out.slice(at)) if (command.words[0] === 'git') command.places = [...dirs.map((value) => ({ option: '-C', value })), ...(command.places ?? [])];
}

/** `normalise`, the folders a wrapper ran it in (`env -C`, `sudo -D`) into `dirs`. */
function normaliseIn(raw: readonly string[], depth: number, out: Command[], outer: readonly string[], set: readonly string[], dirs: string[]): void {
  let words = [...raw];
  const via = [...outer];
  // `VAR=…` set for the program -- before it (`set`, taken off by the line), after a wrapper or through `env`: git's are read as settings.
  const assigned: string[] = [...set];
  for (let guard = 0; guard < 16; guard++) {
    let i = 0;
    for (;;) {
      if (i < words.length && ASSIGNS.test(words[i]!)) assigned.push(words[i++]!);
      else if (i < words.length && KEYWORDS.has(words[i]!)) i++;
      // `function f { …; }` as `f() { …; }`: the keyword and the name are no program.
      else if (words[i] === 'function') i += 2;
      else break;
    }
    words = words.slice(i);
    const program = programOf(words[0] ?? '');
    if (program === 'env' || program in WRAPPERS) via.push(program);
    if (program === 'env') {
      let j = 1;
      for (; j < words.length; j++) {
        const w = words[j]!;
        if (w === '--') {
          j++;
          break;
        }
        if (ASSIGNS.test(w)) {
          assigned.push(w);
          continue;
        }
        if (!w.startsWith('-')) break;
        // Its options as getopt reads them: a long one by any prefix (`--ch=..`), short ones bundled (`-iC ..`, `-C..`).
        let option: string | null = null;
        let value = '';
        if (w.startsWith('--')) {
          const eq = w.indexOf('=');
          option = ENV_LONG.find((o) => longFlag(eq < 0 ? w : w.slice(0, eq), o)) ?? null;
          if (option !== null) value = eq < 0 ? (words[++j] ?? '') : w.slice(eq + 1);
        } else {
          for (let k = 1; k < w.length; k++) {
            if (!ENV_TAKES.includes(w[k]!)) continue;
            option = { u: '--unset', C: '--chdir', S: '--split-string', P: '--path' }[w[k] as 'u' | 'C' | 'S' | 'P'];
            value = w.slice(k + 1) === '' ? (words[++j] ?? '') : w.slice(k + 1);
            break;
          }
        }
        if (option === '--chdir') dirs.push(value);
        if (option === '--split-string') {
          words = [...lex(value).commands.flatMap((command) => command.words), ...words.slice(j + 1)];
          j = -1;
          break;
        }
      }
      if (j >= 0) words = words.slice(j);
      continue;
    }
    if (program in WRAPPERS) {
      let j = pastOptions(words, 1, WRAPPERS[program]!, WRAPPER_CHDIR[program], dirs);
      // `timeout 10 git …`: its duration first; `chrt 5 git …` its priority, `flock x.lock git …` its lock file.
      if (WRAPPER_ARG.has(program)) j++;
      // `flock x.lock -c '<line>'`: a line a shell runs.
      if (program === 'flock' && (words[j] === '-c' || words[j] === '--command')) {
        lines(words[j + 1] ?? '', depth + 1, out, via);
        return;
      }
      words = words.slice(j);
      continue;
    }
    if (program === 'eval') {
      lines(words.slice(1).join(' '), depth + 1, out, via);
      return;
    }
    if (program === 'watch') {
      // Its words, joined, are a line `sh -c` runs again and again.
      via.push(program);
      lines(words.slice(pastOptions(words, 1, WATCH_TAKES)).join(' '), depth + 1, out, via);
      return;
    }
    if (SHELLS.has(program)) {
      let c = false;
      let j = 1;
      for (; j < words.length; j++) {
        const w = words[j]!;
        if (w === '--') continue;
        if (SHELL_TAKES.has(w)) j++;
        else if (/^-[A-Za-z]*c/.test(w)) c = true;
        else if (!w.startsWith('-') && !w.startsWith('+')) break;
      }
      if (c && j < words.length) lines(words[j]!, depth + 1, out, via);
      break;
    }
    // `npx -c '<line>'`, `npm exec -c '<line>'`: a line npm runs through a shell, read as `sh -c`'s is.
    for (const line of packageLines(words)) lines(line, depth + 1, out, via);
    break;
  }
  // A bare assignment (`GIT_DIR=x`) sets the shell's own variable: a command of no words, what it set kept (`lineGitEnv`).
  if (words.length === 0) {
    if (assigned.length > 0) out.push({ written: '', run: '', words: [], program: '', via, config: [], assigned });
    return;
  }
  const program = programOf(words[0]!);
  let run = [program, ...words.slice(1)];
  const config: string[] = [];
  const places: { option: string; value: string }[] = [];
  if (program === 'git') {
    for (const a of assigned) if (a.startsWith('GIT_') && !SAFE_GIT_ENV.test(a)) config.push(a.slice(0, a.indexOf('=')));
    let i = 1;
    while (i < words.length && words[i]!.startsWith('-')) {
      const w = words[i]!;
      const eq = w.indexOf('=');
      const name = eq < 0 ? w : w.slice(0, eq);
      const value = eq < 0 ? (GIT_TAKES.has(w) ? (words[i + 1] ?? '') : null) : w.slice(eq + 1);
      if (name === '-c' || name === '--config-env') config.push((value ?? '').split('=')[0]!.toLowerCase());
      // `--exec-path=<dir>` runs git's commands from elsewhere: as untrusted as a setting.
      if (name === '--exec-path' && value !== null) config.push('--exec-path');
      if (GIT_PLACES.has(name) || !GIT_GLOBAL_SAFE.has(name)) places.push({ option: name, value: value ?? '' });
      i += eq < 0 && GIT_TAKES.has(w) ? 2 : 1;
    }
    run = ['git', ...words.slice(i)];
  } else if (program === 'rm') {
    const end = words.indexOf('--');
    const flags = (end < 0 ? words : words.slice(0, end)).slice(1).filter((w) => w.startsWith('-') && w !== '-');
    const recursive = flags.some((f) => f === '--recursive' || /^-[^-]*[rR]/.test(f));
    const force = flags.some((f) => f === '--force' || /^-[^-]*f/.test(f));
    if (recursive && force) run = ['rm', '-rf', ...words.slice(1).filter((w, n) => !(w.startsWith('-') && w !== '-' && (end < 0 || n + 1 < end)))];
  } else if (program === 'find') {
    // `-exec cmd {} ;`, `-execdir`, `-ok`: a command of its own, to the `;` or `+`.
    for (let i = 1; i < words.length; i++) {
      if (!/^-(exec|execdir|ok|okdir)$/.test(words[i]!)) continue;
      let j = i + 1;
      while (j < words.length && words[j] !== ';' && words[j] !== '+') j++;
      normalise(words.slice(i + 1, j), depth + 1, out, [...via, 'find']);
      i = j;
    }
  }
  out.push({ written: raw.filter((w, n) => !(n === 0 && ASSIGNS.test(w))).join(' '), run: run.join(' '), words: run, program: words[0]!, via, config, ...(places.length > 0 ? { places } : {}), ...(assigned.length > 0 ? { assigned } : {}) });
}

/**
 * The lines a package runner runs through a shell: `npx -c '<line>'`, `npm
 * exec -c` and `npm x -c` (`--call`, `--call=…`, any prefix of it npm takes),
 * pnpm's `exec`/`dlx -c` (`--shell-mode`). Every such option is read wherever
 * it stands -- after the package's name too (`npx prettier -c src` reads `src`
 * as a line): a match too many is a card. None for any other command.
 */
function packageLines(words: readonly string[]): string[] {
  const program = programOf(words[0] ?? '');
  const runs = program === 'npx' || ((program === 'npm' || program === 'pnpm') && words.slice(1).some((w) => w === 'exec' || w === 'x' || w === 'dlx'));
  if (!runs) return [];
  const out: string[] = [];
  for (let i = 1; i < words.length; i++) {
    const w = words[i]!;
    if (w.startsWith('--')) {
      const eq = w.indexOf('=');
      const name = eq < 0 ? w : w.slice(0, eq);
      if (!longFlag(name, '--call') && !longFlag(name, '--shell-mode')) continue;
      if (eq >= 0) out.push(w.slice(eq + 1));
      else if (i + 1 < words.length) out.push(words[++i]!);
    } else if (/^-[A-Za-z]*c/.test(w)) {
      // getopt's bundle: a value attached after the `c` (`-c'git …'` is one word), else the next word -- each read, a line too many a card.
      const rest = w.slice(w.indexOf('c') + 1);
      if (rest !== '') out.push(rest);
      if (i + 1 < words.length) out.push(words[++i]!);
    }
  }
  return out;
}

/** The process substitution a shell, `source` or `.` takes its script file from (`bash <(…)`, `. <(…)`): its text, else null. */
function scriptSubstitution(command: Command): string | null {
  const [program, first] = command.words;
  if (program === 'source' || program === '.') return first === undefined ? null : substitution(first);
  if (!SHELLS.has(program!)) return null;
  for (let j = 1; j < command.words.length; j++) {
    const w = command.words[j]!;
    if (SHELL_TAKES.has(w)) j++;
    else if (/^-[A-Za-z]*c/.test(w)) return null;
    else if (w !== '--' && !w.startsWith('-') && !w.startsWith('+')) return substitution(w);
  }
  return null;
}

/** A shell, `source` or `.` that reads its script from its input: no `-c`, no script file named (`bash`, `sh -s`, `zsh -x`); `source /dev/stdin`, `. -`. */
function readsInput(command: Command): boolean {
  const [program, first] = command.words;
  if (program === 'source' || program === '.') return first === '/dev/stdin' || first === '-';
  if (!SHELLS.has(program!)) return false;
  for (let j = 1; j < command.words.length; j++) {
    const w = command.words[j]!;
    if (SHELL_TAKES.has(w)) j++;
    else if (/^-[A-Za-z]*c/.test(w)) return false;
    else if (/^-[A-Za-z]*s/.test(w) || w === '--') return true;
    else if (!w.startsWith('-') && !w.startsWith('+')) return false;
  }
  return true;
}

/** `\n` and `\t` as `echo -e` and `printf` make them: a line break is another command. */
const escapes = (text: string): string => text.replace(/\\n/g, '\n').replace(/\\t/g, '\t');

/**
 * The literal text a command writes, where it can be read -- `echo`'s and
 * `printf`'s words, `cat`'s here-string: a shell's script, piped into one
 * (`echo 'git reset --hard' | sh`). Null for anything else.
 */
function literal(command: LexedCommand): string | null {
  let i = 0;
  while (i < command.words.length && ASSIGNS.test(command.words[i]!)) i++;
  const [first, ...args] = command.words.slice(i);
  const program = programOf(first ?? '');
  if (program === 'cat') return command.here;
  if (program === 'echo') {
    let j = 0;
    while (j < args.length && /^-[neE]+$/.test(args[j]!)) j++;
    return escapes(args.slice(j).join(' '));
  }
  // The format and its arguments, `%s` and all: a match too many is a card.
  if (program === 'printf') return escapes(args.join(' '));
  return null;
}

/** A command that runs a line nobody can read: Auto asks about it, saying why (`unread`). */
const unreadCommand = (line: string, via: readonly string[], why: string): Command => ({ written: line, run: line, words: ['sh', '-c', line], program: 'sh', via: [...via], config: [], unread: why });

/**
 * A shell's script from a process substitution (`bash <(echo …)`, `. <(…)`,
 * `sh < <(…)`): the literal text the substitution's one command writes, read
 * as lines -- else nobody can read it, and Auto asks.
 */
function scriptFrom(text: string, depth: number, out: Command[], via: readonly string[]): void {
  const made = lex(text).commands;
  const script = made.length === 1 ? literal(made[0]!) : null;
  if (script !== null) lines(script, depth + 1, out, via);
  else out.push(unreadCommand(text, via, 'Auto asks: a shell reads its script from a process substitution whose text is not literal, so what it runs cannot be read.'));
}

/**
 * Every command of a line, `sh -c`'s and `$(…)`'s too; and where a shell in
 * the line reads its script from its input (`readsInput`), that script: a
 * heredoc's text (`bash <<'EOF'`, `cat <<EOF | sh`), its here-string (`bash
 * <<< '…'`), the literal text a pipe feeds it (`echo '…' | sh`, `printf
 * '…' | bash`, `cat <<< '…' | sh`) or a process substitution does (`bash
 * <(echo …)`, `. <(…)`, `sh < <(…)`). A pipe or a substitution that is not
 * literal (`base64 -d | sh`, `… | tee | sh`, `bash <(curl …)`) is a command
 * nobody can read (`unread`). `via`, what the line runs under -- a nested
 * line's commands are its too. Past `DEPTH`, the line itself, as a command
 * that runs everything. Each command keeps the files its redirections write
 * (`outs`): one with no words (`> f`) is a command of its own.
 */
function lines(line: string, depth: number, out: Command[], via: readonly string[] = []): void {
  if (depth > DEPTH) {
    out.push(unreadCommand(line, via, 'Auto asks: the command nests too deep to read.'));
    return;
  }
  const { commands, inner, bodies } = lex(line);
  const first = out.length;
  let before: LexedCommand | null = null;
  for (const command of commands) {
    let i = 0;
    while (i < command.words.length && ASSIGNS.test(command.words[i]!)) i++;
    const at = out.length;
    normalise(command.words.slice(i), depth, out, via, command.words.slice(0, i));
    // The command itself is the last made (what it ran is made before it).
    let main = out.length > at ? out[out.length - 1]! : null;
    if (main === null && command.outs.length > 0) {
      main = { written: '', run: '', words: [], program: '', via: [...via], config: [] };
      out.push(main);
    }
    if (main !== null && command.outs.length > 0) main.outs = [...command.outs];
    if (main !== null && readsInput(main)) {
      if (command.here !== null) lines(command.here, depth + 1, out, main.via);
      if (command.fed !== null) scriptFrom(command.fed, depth, out, main.via);
      else if (command.piped && before !== null) {
        const fed = literal(before);
        if (fed !== null) lines(fed, depth + 1, out, main.via);
        // A heredoc's text is read below; anything else feeding a shell is not literal.
        else if (!before.doc) out.push(unreadCommand(line, main.via, 'Auto asks: a shell reads its script from a pipe whose text is not literal, so what it runs cannot be read.'));
      }
    }
    const script = main === null ? null : scriptSubstitution(main);
    if (script !== null) scriptFrom(script, depth, out, main!.via);
    before = command;
  }
  if (bodies.length > 0 && out.slice(first).some(readsInput)) for (const body of bodies) lines(body, depth + 1, out, via);
  for (const text of inner) lines(text, depth + 1, out, via);
}

/** The commands that set a variable in the shell, for what runs after them: their operands `NAME=…` or `NAME`. */
const DECLARES = new Set(['export', 'declare', 'typeset', 'local', 'readonly']);

/**
 * What a line does to the environment of every git command in it, not on git
 * itself (`GIT_DIR=x git …` is git's own, `assigned`): a `GIT_*` name not
 * `SAFE_GIT_ENV` set anywhere -- an operand of `export`, `declare`,
 * `typeset`, `local` or `readonly` (`export GIT_DIR=~/other; git rm -r src`,
 * `declare -x GIT_WORK_TREE=…`, `export GIT_DIR` after it was set), a bare
 * assignment (`GIT_DIR=…; …`, which `set -a` exports), one given to another
 * program a git may run under (`GIT_DIR=x sh -c 'git …'`) -- or `set -a`/`set -o
 * allexport`, which exports every assignment after it. Null for none. A
 * `GIT_*` in the session's own environment is not the line's: the host's, set
 * before Claude Code started, as every other variable it inherits.
 */
function lineGitEnv(commands: readonly Command[]): string | null {
  for (const c of commands) {
    const [p = '', ...args] = c.words;
    const named = [...(c.assigned ?? []), ...(DECLARES.has(p) ? args : [])].find((w) => /^GIT_[A-Za-z0-9_]*(=|$)/.test(w) && !SAFE_GIT_ENV.test(w.includes('=') ? w : `${w}=?`));
    if (named !== undefined) return named.split('=')[0]!;
    if (p === 'set' && args.some((a) => /^[-+][A-Za-z]*a[A-Za-z]*$/.test(a) || /allexport$/.test(a))) return 'set -a';
  }
  return null;
}

/** The commands a command line runs, each as written and as run (`normalise`); each git one marked with what the line sets for it (`lineGitEnv`). */
export function commandsOf(line: string): Command[] {
  const out: Command[] = [];
  lines(line, 0, out);
  const env = lineGitEnv(out);
  if (env !== null) for (const command of out) if (command.words[0] === 'git') command.lineEnv = env;
  return out;
}

// ---------------------------------------------------------------- git, read only

/**
 * Is a word a long flag in any spelling git takes: `--delete`, `--delete=…`,
 * or a prefix of it (`--del`, `--f` for `--force`) -- git takes a unique
 * prefix of any long option. A match too many is a card.
 */
function longFlag(word: string, flag: string): boolean {
  const name = word.includes('=') ? word.slice(0, word.indexOf('=')) : word;
  return name === flag || (name.length > 2 && name.startsWith('--') && flag.startsWith(name));
}

/**
 * A short option word's letters as getopt reads a bundle: the leading run of
 * letters after one `-`, whatever follows attached as a value -- `-dr` is d
 * and r, `-uorigin/main` is u (and o, r, i, g, i, n: a letter too many is a
 * card), `-O/bin/rm` and `-iO/bin/rm` have O. None for a long one or a word
 * that is no option.
 */
const shortLetters = (word: string): string => (word.startsWith('-') && !word.startsWith('--') ? /^-([A-Za-z]*)/.exec(word)![1]! : '');

/**
 * The values a word that is an option may carry attached: after `=` for a
 * long one (`--exclude-from=/abs`); for a short one, the rest of the word
 * after each letter of its leading run (`-O/abs`, `-iO/abs`: whichever letter
 * takes it). None for a word that is no option.
 */
function attachedValues(word: string): string[] {
  if (!word.startsWith('-') || word === '-' || word === '--') return [];
  if (word.startsWith('--')) return word.includes('=') ? [word.slice(word.indexOf('=') + 1)] : [];
  const out: string[] = [];
  for (let k = 2; k <= shortLetters(word).length + 1; k++) if (k < word.length) out.push(word.slice(k));
  return out;
}

/** A flag among a command's words: `-d`, or `--delete`, `--delete=…` or a prefix of it (`longFlag`); a short one in a bundle, or with its value attached (`shortLetters`: `-dr`, `-O/x`). */
function hasFlag(args: readonly string[], short: string, long: readonly string[]): boolean {
  return args.some((a) => long.some((l) => longFlag(a, l)) || (short !== '' && [...shortLetters(a)].some((ch) => short.includes(ch))));
}

/**
 * A git command whose every option, before `--`, is on its allow-list: a
 * short one, alone or bundled, among `short`'s letters; a long one exactly as
 * `long` names it, with or without `=…` -- no prefix, no other. The value of
 * one that takes a word (`takes`' letters, last in a bundle or with the rest
 * of its word: `-m msg`, `-am msg`, `-mmsg`; `longTakes` without `=`) is no
 * option: `git commit -m "- fix"`. Any other value that starts with `-` is
 * read as an option: a card too many.
 */
function onlyOptions(short: string, long: readonly string[], takes = '', longTakes: readonly string[] = []): (args: readonly string[]) => boolean {
  return (args) => {
    for (let i = 0; i < args.length; i++) {
      const a = args[i]!;
      if (a === '--') return true;
      if (!a.startsWith('-') || a === '-') continue;
      if (a.startsWith('--')) {
        if (!long.includes(a.includes('=') ? a.slice(0, a.indexOf('=')) : a)) return false;
        if (!a.includes('=') && longTakes.includes(a)) i++;
        continue;
      }
      for (let k = 1; k < a.length; k++) {
        if (!short.includes(a[k]!)) return false;
        if (!takes.includes(a[k]!)) continue;
        // Its value: the rest of the word, or the next one.
        if (k === a.length - 1) i++;
        break;
      }
    }
    return true;
  };
}

/** `git rm` unforced: `-r`, `-q`, `-n`, `--cached` and the like -- never `-f`, `--force` or a prefix of it. */
const GIT_RM = onlyOptions('rqn', ['--quiet', '--cached', '--dry-run', '--ignore-unmatch', '--sparse']);

/** `git mv` unforced: `-k`, `-n`, `-v` -- never `-f`, `--force` or a prefix of it. */
const GIT_MV = onlyOptions('knv', ['--dry-run', '--verbose']);

/**
 * `git commit` making a new commit: never `--amend` (nor `--am`), `--fixup`,
 * `--squash`, `-c`/`-C`, `--no-verify` -- nor `-F`/`--file`: its message from a
 * file, which may be read from outside the project (`-m` takes a drafted one).
 */
const GIT_COMMIT = onlyOptions('amqvsio', ['--message', '--all', '--quiet', '--verbose', '--signoff', '--allow-empty', '--allow-empty-message', '--no-edit', '--author', '--date', '--cleanup', '--trailer', '--only', '--include', '--dry-run', '--short', '--porcelain', '--long', '--status', '--no-status', '--untracked-files'], 'm', ['--message', '--author', '--date', '--cleanup', '--trailer']);

/** What a git command's allow-list needs beyond its words: the root its paths must be in, and the remotes of the repository it runs in (the project's, or the engine's for `-C engine`). */
interface GitAt {
  root?: string;
  remotes: readonly string[];
}

/**
 * Is a word a path outside the root, as far as it can be told: `~…`, an
 * absolute path not under the root, or one whose `..` climbs out of it --
 * every absolute one with no root to judge by. A `rev:path` (`HEAD:a.ts`) and
 * pathspec magic (`:/`) name what is in the repository, not a file: none --
 * but a `..` that climbs out is read first, `:` or not (`../x:y`).
 */
function outsideRoot(word: string, root: string | undefined): boolean {
  if (word.startsWith('~')) return true;
  if (!isAbsolute(word) && word.split('/').includes('..')) return root === undefined || !inside(root, resolve(root, word));
  if (word.includes(':') && !isAbsolute(word)) return false;
  return isAbsolute(word) && (root === undefined || !inside(root, word));
}

/**
 * The options of git's reading commands that read or write a file named
 * anywhere (`--no-index`: two files, wherever they are; `--contents`,
 * `--file`, `--blob`, `--output`, `--ignore-revs-file`, `--exclude-from`,
 * `--exclude-per-directory`) or run a program (`--ext-diff`, `--textconv`,
 * `--filters`, `--open-files-in-pager`), in any prefix git takes: a card on
 * any line.
 */
const READ_ELSEWHERE = ['--no-index', '--contents', '--file', '--blob', '--output', '--ext-diff', '--textconv', '--filters', '--open-files-in-pager', '--ignore-revs-file', '--exclude-from', '--exclude-per-directory'];

/**
 * Does a git read stay in the project (`READ_ELSEWHERE`): none of those
 * options, nor `-f` (a file: `config -f`, `grep -f`) or `-O` (grep's pager,
 * diff's and log's order file) -- in a bundle or with a value attached too
 * (`hasFlag`: `-iO/bin/rm`) -- no option's value a path outside the root
 * (`attachedValues`: `--ignore-revs-file=/abs`, `-O/abs`; one given as the
 * next word is a word like any other), and no word a path outside the root
 * (`outsideRoot`) -- grep's pattern, its first word with no `-e`, is no path.
 */
function readsHere(sub: string, args: readonly string[], root: string | undefined): boolean {
  if (hasFlag(args, 'fO', READ_ELSEWHERE)) return false;
  const end = args.indexOf('--');
  if (args.some((a, n) => (end < 0 || n < end) && attachedValues(a).some((v) => outsideRoot(v, root)))) return false;
  const words = args.filter((a, n) => (end >= 0 && n > end) || ((end < 0 || n < end) && !a.startsWith('-')));
  const paths = sub === 'grep' && !args.some((a) => a === '-e' || longFlag(a, '--regexp')) && (end < 0 || args.findIndex((a) => !a.startsWith('-')) < end) ? words.slice(1) : words;
  return !paths.some((w) => outsideRoot(w, root));
}

/**
 * `git grep` by allow-list: `-n`, `-i`, `-w`, `-l`, `-L`, `-c`, `-e <pattern>`,
 * `-E`, `-F`, `-P`, `-v`, `-h`, `-H`, `-I` and their long names, `--count`,
 * `--name-only`, `--untracked`, `--cached` -- never `-O`/`--open-files-in-pager`
 * (its value run by `sh -c`: `git grep -O/bin/rm`), `-f`/`--file`,
 * `--exclude-from` or any other. Its paths held in the project (`readsHere`).
 */
const GREP_OPTIONS = onlyOptions('niwlLcEFPvhHIe', ['--line-number', '--ignore-case', '--word-regexp', '--files-with-matches', '--name-only', '--files-without-match', '--count', '--extended-regexp', '--fixed-strings', '--perl-regexp', '--invert-match', '--untracked', '--cached', '--regexp', '--full-name'], 'e', ['--regexp']);

/** `git help` by allow-list: `-a`, `-g`, `-m`, `-c` and their long names -- never `-w`/`--web` (a browser) or `-i`/`--info`. */
const HELP_OPTIONS = onlyOptions('agmc', ['--all', '--guides', '--man', '--config', '--verbose', '--no-verbose', '--no-external-commands', '--no-aliases', '--user-interfaces', '--developer-interfaces']);

/** `git fetch`'s options Auto knows: none that moves a ref by force, prunes, deepens or runs a program elsewhere (`--upload-pack`). */
const FETCH_OPTIONS = onlyOptions('qv', ['--all', '--tags', '--no-tags', '--quiet', '--verbose', '--dry-run']);

/**
 * A `git fetch` by allow-list: `--all`, `--tags`, `--no-tags`, `-q`, `-v`,
 * `--dry-run`, and a remote the project has (`git remote`, read as the
 * session starts) or none -- no refspec, URL or path, no `--refmap`,
 * `--set-upstream`, `--depth`, `--deepen`, `--shallow-*`, `--unshallow`,
 * `--prune*`, `--force`, `--update-head-ok`, `--upload-pack`, no `--`.
 */
function fetchReads(args: readonly string[], { remotes }: GitAt): boolean {
  if (args.includes('--') || !FETCH_OPTIONS(args)) return false;
  const named = args.filter((a) => !a.startsWith('-'));
  return named.length === 0 || (named.length === 1 && remotes.includes(named[0]!));
}

/**
 * A `git remote` that only reads: `remote`, `remote -v`, `remote show <name>`,
 * `remote get-url <name>`, the name a remote the project has -- nothing after.
 */
function remoteReads(args: readonly string[], { remotes }: GitAt): boolean {
  if (args.length === 0) return true;
  if (args.length === 1) return args[0] === '-v';
  return args.length === 2 && (args[0] === 'show' || args[0] === 'get-url') && remotes.includes(args[1]!);
}

/**
 * A `git tag` that only lists: `-l`/`--list`, `-n<lines>`, `--contains`,
 * `--points-at` (each implies the list), `--sort=` -- a name with none of
 * them makes a tag, a card. Never `-a`, `-m`, `-F`/`--file`, `-e`, `-d`, `-f`,
 * `-s`, `-u` or any other option.
 */
function tagLists(args: readonly string[]): boolean {
  let list = false;
  let named = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i]!;
    if (a === '-l' || a === '--list' || /^-n\d*$/.test(a)) list = true;
    else if (a === '--contains' || a === '--points-at') {
      list = true;
      i++;
    } else if (a.startsWith('--contains=') || a.startsWith('--points-at=')) list = true;
    else if (a.startsWith('--sort=')) continue;
    else if (a.startsWith('-')) return false;
    else named = true;
  }
  return list || !named;
}

/** `git add`'s options Auto knows: `-A`, `-u`, `-N`, `-v`, `-n` -- never `-f`, `-p`, `-i`, `-e`, `--chmod`, `--pathspec-from-file`. */
const ADD_OPTIONS = onlyOptions('AuNvn', ['--all', '--update', '--intent-to-add', '--verbose', '--dry-run']);

/** A `git add` by allow-list (`ADD_OPTIONS`), every path inside the root -- no pathspec magic (`:/`, `:(…)`). */
function addReads(args: readonly string[], { root }: GitAt): boolean {
  if (!ADD_OPTIONS(args)) return false;
  const end = args.indexOf('--');
  const paths = args.filter((a, n) => (end >= 0 && n > end) || ((end < 0 || n < end) && !a.startsWith('-')));
  return paths.every((p) => !p.startsWith(':') && !outsideRoot(p, root));
}

/** `git config`'s options that only read the project's own settings: no `--file`, `--blob`, `--global`, `--system`, no `--add`, `--unset` or any writer. */
const CONFIG_OPTIONS = onlyOptions('lz', ['--get', '--get-all', '--get-regexp', '--list', '--local', '--show-origin', '--show-scope', '--null', '--name-only', '--type', '--bool', '--int', '--path', '--default', '--all', '--regexp'], '', ['--type', '--default']);

/**
 * A `git config` that reads the project's own settings: `--get`, `--get-all`,
 * `--get-regexp`, `--list`/`-l`, or the `get`/`list` subcommands, with only
 * `CONFIG_OPTIONS` -- and `--local`: without it git reads `~/.gitconfig`, the
 * system's and every file they include, which are no business of the project.
 */
const configReads = (a: readonly string[]): boolean =>
  !a.includes('--') && a.includes('--local') && CONFIG_OPTIONS(a) && (a[0] === 'get' || a[0] === 'list' || a.some((w) => w === '--get' || w === '--get-all' || w === '--get-regexp' || w === '--list' || /^-z*lz*$/.test(w)));

/** `git branch`'s listing options: `-a`, `-r`, `-v`, `-vv`, `-l` (bundled too), their long names, `--show-current`. */
const BRANCH_LISTS = new Set(['--list', '--all', '--remotes', '--verbose', '--show-current']);

/**
 * A `git branch` by allow-list of its forms: one that lists (`branch`, `-a`,
 * `-r`, `-v`, `-vv`, `--list`, `--show-current`, `--contains`, `--merged`,
 * `--no-merged`, `--no-contains`, each with its commit) or makes a branch
 * (`branch <name> [<start>]`, which git refuses over one that exists) -- never
 * `-u`/`--set-upstream-to`, `--unset-upstream`, `-d`, `-D`, `-m`, `-M`, `-c`,
 * `-C`, `-f`, `-t`, `--edit-description` or any other option.
 */
function branchReads(args: readonly string[]): boolean {
  let named = 0;
  for (const a of args) {
    if (/^-[arvl]+$/.test(a) || BRANCH_LISTS.has(a) || /^--(no-)?(contains|merged)(=|$)/.test(a)) continue;
    if (a.startsWith('-')) return false;
    named++;
  }
  return named <= 2;
}

/**
 * A `git switch` or `git checkout` that only makes a branch, or moves to one,
 * as git does it unforced: it refuses to overwrite a change not committed, so
 * nothing is lost. Not `-f`, `--discard-changes`, `-m` (a merge of the changes
 * into the new tree), `-C`/`-B` (a branch reset), `--orphan` (the tree
 * emptied), `--` or a path; `checkout` only as `-b <name> [<start>]`, its
 * other forms being the ones that put files back.
 */
function branchOnly(sub: 'switch' | 'checkout'): (args: readonly string[]) => boolean {
  const safe = sub === 'switch' ? new Set(['-c', '--create', '-q', '--quiet', '-t', '--track', '--no-track', '-d', '--detach', '--guess', '--no-guess']) : new Set(['-b', '-q', '--quiet', '-t', '--track', '--no-track']);
  return (args) => {
    if (args.some((a) => a.startsWith('-') && !safe.has(a))) return false;
    const positional = args.filter((a) => !a.startsWith('-'));
    return sub === 'switch' ? positional.length >= 1 && positional.length <= 2 : args.includes('-b') && positional.length >= 1 && positional.length <= 2;
  };
}

/**
 * git's commands Auto lets by without a card (§2, Permissions), each by an
 * allow-list of its forms: those that only read -- `remote`, `tag`, `config`
 * only as they list or get (`remoteReads`, `tagLists`, `configReads`), every
 * read held in the project (`readsHere`, in `gitAsksWhy`) -- and `fetch`, `add`
 * and `commit`, which change no file of the tree: `fetch` only from a remote
 * the project has, with options that move no ref (`fetchReads`), `add` only
 * of paths in the project (`addReads`), not `commit --amend`. And, as
 * built after the Auto review, `rm` and `mv` unforced -- git refuses to remove
 * a file with changes not committed, or to move onto one -- and a new branch
 * or a move to one (`branchOnly`), which git refuses where it would lose a
 * change. Every
 * other is a card under Auto: a git command is the quickest way to lose work
 * that is not committed.
 */
const GIT_READS: Record<string, (args: readonly string[], at: GitAt) => boolean> = {
  status: () => true,
  diff: () => true,
  log: () => true,
  show: () => true,
  branch: branchReads,
  'rev-parse': () => true,
  'ls-files': () => true,
  'check-attr': () => true,
  blame: () => true,
  describe: () => true,
  tag: tagLists,
  remote: remoteReads,
  stash: (a) => a[0] === 'list' || a[0] === 'show',
  worktree: (a) => a[0] === 'list',
  config: configReads,
  fetch: fetchReads,
  add: addReads,
  commit: GIT_COMMIT,
  rm: GIT_RM,
  mv: GIT_MV,
  switch: branchOnly('switch'),
  checkout: branchOnly('checkout'),
  'ls-tree': () => true,
  'cat-file': () => true,
  'merge-base': () => true,
  'rev-list': () => true,
  shortlog: () => true,
  'show-ref': () => true,
  'for-each-ref': () => true,
  'check-ignore': () => true,
  'name-rev': () => true,
  'diff-tree': () => true,
  'diff-index': () => true,
  'diff-files': () => true,
  grep: GREP_OPTIONS,
  version: () => true,
  help: HELP_OPTIONS,
};

/** Settings a `git -c` may give and run nothing by: colour, advice, how paths are quoted. */
const SAFE_GIT_CONFIG = /^(color\.|advice\.|i18n\.|core\.quotepath$)/;

/** git's commands that only read, whatever repository they read: what a line that `cd`s away may run, and what `readsOnly` takes. */
const PURE_GIT_READS: ReadonlySet<string> = new Set(['status', 'diff', 'log', 'show', 'rev-parse', 'ls-files', 'ls-tree', 'cat-file', 'blame', 'describe', 'grep', 'shortlog', 'show-ref', 'for-each-ref', 'check-ignore', 'check-attr', 'merge-base', 'rev-list', 'name-rev', 'diff-tree', 'diff-index', 'diff-files', 'version', 'help']);

/** git's commands whose every form is held in the project (`readsHere`): its reading commands, and those that list or get. */
const READS_HELD: ReadonlySet<string> = new Set([...PURE_GIT_READS, 'config', 'remote', 'tag', 'branch', 'stash', 'worktree']);

/**
 * Does `at` (where git's option leads, its real path where it exists) name
 * `place`, a folder of the project's: `place` reached from the root through
 * no symbolic link (`throughLink`), and `at` that folder as written or its
 * real path. A `.git` the person made a link is no place of the project's.
 */
function namesPlace(root: string, place: string, at: string): boolean {
  const rel = relative(root, place).split(sep).join('/');
  if (rel !== '' && throughLink(root, rel)) return false;
  // `resolve`: one spelling of a path (on Windows a `/p` is `D:\p`, a `/` a `\`).
  if (place === at || resolve(place) === at) return true;
  try {
    return realpathSync.native(place) === at;
  } catch {
    return false;
  }
}

/**
 * Where git's option leads, as git goes there: the real path of the folder as
 * the shell names it, `..` taken after the folder before it, a link followed
 * (`foo/..` is the parent of where `foo` leads, not the root); one that does
 * not exist, as written -- but with a `..` in it, nowhere (null).
 */
function gitDirAt(cwd: string, value: string): string | null {
  const raw = isAbsolute(value) ? value : `${cwd}${sep}${value}`;
  try {
    return realpathSync.native(raw);
  } catch {
    return value.split('/').includes('..') ? null : resolve(cwd, value);
  }
}

/**
 * The first of git's own options that points it anywhere but the project
 * (`places`): a `-C <dir>`, `--git-dir` or `--work-tree` naming another
 * folder -- the project's root, or its engine's checkout in source mode
 * (`engine/`, its git dir), are the project -- one that is no plain path
 * (`$`, `~`, a glob), a relative one after a `cd` away, any other option not
 * known to change nothing (`--bare` …), or any at all with no root to judge by.
 * `git -C ~/other rm -r src` is another repository, which the turn's Undo does
 * not cover. And `--git-dir` and `--work-tree` only as a pair of one
 * repository: both the project's, or both the engine's -- one given alone is
 * paired with where git runs (`-C`, else the root), whose repository the other
 * then is; mixed (`--git-dir=.git --work-tree=engine`, the project's index over
 * the engine's files), a card. A relative one before a later `-C`, which git
 * reads from where `-C` leaves it, a card too. The engine checked as it is
 * used, not as the session started (`engineDir`): a folder of its own under the
 * root, no link -- `ln -s ~/other engine` in an earlier call makes `-C engine`
 * another repository. Every place by where git would go (`gitDirAt`, `..`
 * after a link where the link leads), and through no link from the root
 * (`namesPlace`). `{ elsewhere }` for one, else the repository git runs in:
 * the project's, or the engine's.
 */
function gitPlace(command: Command, root: string | undefined, moved: boolean): { elsewhere: string } | { repo: 'project' | 'engine' } {
  let cwd = root;
  let here: 'project' | 'engine' = 'project';
  let gitDir: { repo: 'project' | 'engine'; text: string } | null = null;
  let tree: { repo: 'project' | 'engine'; text: string } | null = null;
  let relative = false;
  for (const { option, value } of command.places ?? []) {
    const text = `${option}${value === '' ? '' : ` ${value}`}`;
    if (root === undefined || cwd === undefined || !GIT_PLACES.has(option)) return { elsewhere: text };
    if (value === '' || /[$`~*?[\]{}]/.test(value) || (moved && !isAbsolute(value))) return { elsewhere: text };
    if (option === '-C' && relative) return { elsewhere: text };
    const at = gitDirAt(cwd, value);
    if (at === null) return { elsewhere: text };
    const project = option === '--git-dir' ? [join(root, '.git')] : [root];
    const engine = !engineDir(root) ? [] : option === '--git-dir' ? [join(root, 'engine', '.git'), join(root, '.git', 'modules', 'engine')] : [join(root, 'engine')];
    const repo = project.some((d) => namesPlace(root, d, at)) ? 'project' : engine.some((d) => namesPlace(root, d, at)) ? 'engine' : null;
    if (repo === null) return { elsewhere: text };
    if (option === '-C') {
      cwd = at;
      here = repo;
    } else {
      if (!isAbsolute(value)) relative = true;
      if (option === '--git-dir') gitDir = { repo, text };
      else tree = { repo, text };
    }
  }
  if ((gitDir?.repo ?? here) !== (tree?.repo ?? here)) return { elsewhere: [gitDir?.text, tree?.text].filter((t) => t !== undefined).join(' ') };
  return { repo: gitDir?.repo ?? tree?.repo ?? here };
}

/**
 * Why Auto asks about this command, and what it is in a few words: a git
 * command given a setting that can run a program (`-c core.pager=…`), one
 * pointed anywhere but the project (`gitPlace`), one not among `GIT_READS`'
 * forms, or -- where Auto's allowances give nothing (`withheld`: a line that
 * is not plain, a shell maybe away from the root) -- any that does more than
 * read (`PURE_GIT_READS`). Null for any other command, and for git reading.
 * With no `root`, any `-C` asks. `moved`: the line `cd`s away first, so a
 * relative `-C` is not the project's. `remotes`: the project's, and the
 * engine's (`gitRemotes` of each, read as the session starts) -- `git -C engine
 * fetch <name>` only from one the engine has.
 */
function gitAsksWhy(command: Command, root?: string, moved = false, held: string | null = null, remotes: GitRemotes = {}): { reason: string; what: string } | null {
  if (command.words[0] !== 'git') return null;
  const bad = command.config.find((key) => !SAFE_GIT_CONFIG.test(key));
  if (bad !== undefined) return { reason: `Auto asks before git is given a setting (${bad}): one can run a program.`, what: `a git setting (${bad})` };
  if (command.lineEnv !== undefined) return { reason: `Auto asks before git in a line that sets its environment (${command.lineEnv}): it can point git at another repository or run a program.`, what: `git after ${command.lineEnv}` };
  const place = gitPlace(command, root, moved);
  if ('elsewhere' in place) return { reason: `Auto asks before git is pointed elsewhere (${clip(place.elsewhere, 60)}): another repository is not the project's, and Undo this turn does not cover it.`, what: `git ${clip(place.elsewhere, 60)}` };
  const sub = command.words[1];
  if (sub === undefined) return null;
  const what = `git ${sub}`;
  const args = command.words.slice(2);
  // A read that reads a file elsewhere or runs a program: a card on any line.
  if (READS_HELD.has(sub) && !readsHere(sub, args, root)) return { reason: `Auto asks before \`git ${sub}\` in this form: it reads or writes a file outside the project, or runs a program (\`--no-index\`, \`--contents\`, \`--file\`, \`--output\`, \`--ext-diff\`, \`--textconv\` …).`, what };
  if (held !== null && !PURE_GIT_READS.has(sub)) return { reason: `Auto asks before \`git ${sub}\` here (${held}): beyond git's reading commands, Auto lets git by only on a plain line, run at the project's root.`, what: `${what} (${clip(held, 80)})` };
  const reads = Object.hasOwn(GIT_READS, sub) ? GIT_READS[sub] : undefined;
  if (reads?.(args, { ...(root === undefined ? {} : { root }), remotes: (place.repo === 'engine' ? remotes.engine : remotes.project) ?? [] })) return null;
  if (sub === 'commit' || sub === 'fetch') return { reason: `Auto asks before \`git ${sub}\` in this form: it rewrites a ref (\`--amend\`, a refspec), fetches from where the project has no remote, or has an option Auto does not know.`, what };
  return { reason: `Auto asks before \`git ${sub}\`${reads === undefined ? '' : ' in this form'}: only git's reading commands, fetch, add, commit, rm and mv unforced, and a new branch go ahead unasked.`, what };
}

/** The remotes `git fetch` and `git remote show` may name unasked: the project's, and the engine's checkout's (source mode). */
export interface GitRemotes {
  project?: readonly string[];
  engine?: readonly string[];
}

/** Why Auto asks about this command (`gitAsksWhy`): null for any other command, and for git reading. */
export const gitAsks = (command: Command, root?: string, moved = false, remotes: GitRemotes = {}): string | null => gitAsksWhy(command, root, moved, null, remotes)?.reason ?? null;

/** Is this a git command that only reads (`gitAsks` has nothing against it)? The host's rules never name one. */
export const gitReads = (command: Command, root?: string): boolean => command.words[0] === 'git' && gitAsks(command, root) === null;

// ---------------------------------------------------------------- a plain line, under Auto

/**
 * The programs a plain line may run (`notPlain`): none a wrapper, none that
 * sets a variable, changes directory but to the root, makes a link or moves
 * a file, none that runs code nobody reads -- not `node`, `npm`, `npx` or
 * `vibe` (a script, `npm run`, `npx --yes`, `--prefix` elsewhere, `-c '<line>'`).
 *
 * What is read here: the line as the person wrote it, word by word
 * (`plainRead`); each program's name, as written; `cd`'s one operand (the
 * root); git's options before its command (`-C` to the root or the engine
 * only) and, after it, its command's forms (`GIT_READS`' allow-lists, `gitPlace`,
 * `readsHere`); `rg` without `--pre`, `sed` only printing (`sedReads`), `printf`
 * without `-v`; an `rm -r`'s targets (`remadeTarget`).
 *
 * What is not: the paths `cat`, `head`, `grep -r`, `ls`, `mkdir` or an `rm`
 * that is not recursive name -- the CLI's own path check (`blockedPath`) asks
 * about one outside the project, not this code; the person's own shell setup,
 * which the CLI's shell snapshot loads before every line (an alias, a
 * function, `setopt`): a plain word may run something else there; what git
 * runs of the project's own (`.git/config`, its hooks: written only with a
 * card, `GUARDED`); and what is on disk after the check (`throughLink`'s gap).
 */
const PLAIN_PROGRAMS = new Set(['git', 'rm', 'mkdir', 'cat', 'head', 'tail', 'wc', 'ls', 'grep', 'rg', 'sed', 'echo', 'printf', 'true', 'test', '[', 'cd']);

/** What a pipe in a plain line may feed: a reader of its input, nothing that runs or writes. */
const PLAIN_PIPE = new Set(['head', 'tail', 'wc', 'grep']);

/** A character a plain word may hold outside quotes: no expansion, glob, brace, tilde, escape, redirection or control. */
const PLAIN_CHAR = /^[A-Za-z0-9._@+=,:/%-]$/;

/** One word of a plain line, as written: its pieces, each quoted or not. */
type PlainWord = { text: string; quoted: boolean }[];

/** A word's text when it is one piece outside quotes, else ''. */
const plainText = (word: PlainWord | null): string => (word !== null && word.length === 1 && !word[0]!.quoted ? word[0]!.text : '');

/** The commands of a line read as a plain line (`notPlain`), up to the first thing that is not plain; why it is not, or null. */
interface PlainRead {
  commands: { words: string[]; pieces: PlainWord[]; piped: boolean; end: string }[];
  why: string | null;
}

/**
 * A line lexed the plain way: words of `PLAIN_CHAR`s and quoted strings with
 * no `$`, backtick or `\`; commands split on `;`, `&&`, `||`, `|` and new
 * lines; `2>&1` and a redirection of 1, 2 or both to `/dev/null` dropped.
 * Anything else ends it, said why.
 */
function plainRead(line: string): PlainRead {
  const commands: PlainRead['commands'] = [];
  let pieces: PlainWord[] = [];
  let word: PlainWord | null = null;
  let piped = false;
  const fail = (why: string): PlainRead => ({ commands, why });
  const endWord = (): void => {
    if (word !== null) pieces.push(word);
    word = null;
  };
  const endCommand = (end: string): void => {
    endWord();
    if (pieces.length === 0) return;
    commands.push({ words: pieces.map((w) => w.map((p) => p.text).join('')), pieces, piped, end });
    pieces = [];
    piped = false;
  };
  const add = (text: string, quoted: boolean): void => {
    word ??= [];
    const last = word.at(-1);
    if (last !== undefined && !last.quoted && !quoted) last.text += text;
    else word.push({ text, quoted });
  };
  const boundary = (k: number): boolean => k >= line.length || ' \t\n;&|'.includes(line[k]!);
  for (let i = 0; i < line.length; i++) {
    const c = line[i]!;
    if (c === ' ' || c === '\t') endWord();
    else if (c === "'" || c === '"') {
      const close = line.indexOf(c, i + 1);
      if (close < 0) return fail('a quote not closed');
      const text = line.slice(i + 1, close);
      if (/[$`\\]/.test(text)) return fail(`\`${/[$`\\]/.exec(text)![0]}\` in quotes`);
      add(text, true);
      i = close;
    } else if (c === '\n' || c === ';') endCommand(c);
    else if ((c === '&' || c === '|') && line[i + 1] === c) {
      endCommand(c + c);
      i++;
    } else if (c === '|') {
      if (line[i + 1] === '&') return fail('`|&`');
      endWord();
      if (pieces.length === 0) return fail('a pipe from nothing');
      endCommand(c);
      piped = true;
    } else if (c === '>' || (c === '&' && line[i + 1] === '>')) {
      // `2>&1`, and `>`, `1>`, `2>` or `&>` to /dev/null: nothing else.
      let fd = '1';
      if (c === '&') {
        endWord();
        fd = '&';
        i++;
      } else if (/^[12]$/.test(plainText(word as PlainWord | null))) {
        fd = plainText(word as PlainWord | null);
        word = null;
      } else endWord();
      let j = i + 1;
      if (line[j] === '>') return fail('`>>`');
      if (line[j] === '&') {
        if (fd !== '2' || line[j + 1] !== '1' || !boundary(j + 2)) return fail('a redirection but `2>&1` or to /dev/null');
        i = j + 1;
        continue;
      }
      while (line[j] === ' ' || line[j] === '\t') j++;
      if (!line.startsWith('/dev/null', j) || !boundary(j + 9)) return fail('a redirection but `2>&1` or to /dev/null');
      i = j + 8;
    } else if (c === '&') return fail('`&`, a command in the background');
    else if ((c === '[' || c === ']') && word === null && boundary(i + 1)) add(c, false);
    // zsh's `=cmd` is the path of cmd (`rm -rf =node`).
    else if (c === '=' && word === null) return fail('`=` starting a word');
    else if (PLAIN_CHAR.test(c)) add(c, false);
    else return fail(`\`${c}\` outside quotes`);
  }
  endCommand('');
  if (piped) return fail('a pipe into nothing');
  return { commands, why: null };
}

/** The root as a plain `cd` or `git -C` may name it: as written, or its real path. */
function rootNames(root: string): string[] {
  let names = [root];
  try {
    names.push(realpathSync.native(root));
  } catch {
    // Not there: as written.
  }
  // Windows: Git Bash's spellings of it too -- `C:/Users/me/game` and `/c/Users/me/game`.
  if (sep === '\\') names = names.flatMap((n) => [n, slashed(n), slashed(n).replace(/^([A-Za-z]):\//, (_, d: string) => `/${d.toLowerCase()}/`)]);
  return [...new Set(names)];
}

/** A Windows path compared: `/` between the names, Git Bash's `/c/…` as `c:/…`, no case (Windows' names have none). */
const windowsKey = (path: string): string => slashed(path).replace(/\\/g, '/').replace(/^\/([A-Za-z])\//, '$1:/').replace(/\/+$/, '').toLowerCase();

/**
 * Does a plain `cd`'s or `git -C`'s word name the root (`rootNames`)? As written or by its real path; on Windows by
 * `windowsKey` too -- and, for an absolute word, by the real path of each (an 8.3 short name and its long one, `C:\…`
 * and `c:/…`, are one folder).
 */
export function namesRoot(word: string, root: string, windows = sep === '\\'): boolean {
  const names = rootNames(root);
  if (names.includes(word)) return true;
  if (!windows) return false;
  const keys = new Set(names.map(windowsKey));
  if (keys.has(windowsKey(word))) return true;
  const at = /^[A-Za-z]:[\\/]/.test(word) ? word : /^\/[A-Za-z]\//.test(word) ? windowsKey(word) : null;
  if (at === null) return false;
  try {
    return keys.has(windowsKey(realpathSync.native(at)));
  } catch {
    return false;
  }
}

/**
 * Why a line is not plain, or null when it is (§2, Permissions): only on a
 * plain line does Auto give its own allowances -- the host's `Bash(rm -rf:*)`
 * spared for what is made again (`sparedRms`), git beyond its reading commands
 * (`GIT_READS`), a read through the engine's link (`linkedRead`). Plain: every
 * word a literal (`PLAIN_CHAR`s, quoted strings with no `$`, backtick, `\`, `!`,
 * glob, `{` or `~` -- a git commit's message may hold any of those but `$`,
 * backtick and `\`); every program on `PLAIN_PROGRAMS`, run as itself -- no
 * wrapper, assignment, function, subshell, group, background, redirection but
 * `2>&1` and to `/dev/null`, pipe but into `PLAIN_PIPE`; `cd` with one operand,
 * the root (`rootNames`); git with no option before its command but `-C` to
 * the root or to `engine` -- only where `engine` is a folder of its own, not a
 * link (`engine`, read as the session starts: `engineDir`). Anything else, the
 * allowances give nothing: matching each dangerous spelling did not converge.
 */
export function notPlain(line: string, root: string, engine = false): string | null {
  const read = plainRead(line);
  if (read.why !== null) return read.why;
  for (const { words, pieces, piped } of read.commands) {
    const [program = '', ...args] = words;
    if (!PLAIN_PROGRAMS.has(program)) return `\`${clip(program, 30)}\``;
    if (piped && !PLAIN_PIPE.has(program)) return `a pipe into \`${program}\``;
    // A commit's message is text: the word after -m (-am …) or --message, or the rest of -m's own word.
    const message = (n: number): boolean => program === 'git' && args.includes('commit') && n > 0 && (/^-[A-Za-z]*m$|^--message$/.test(words[n - 1]!) || (pieces[n]![0]!.quoted === false && /^-[A-Za-z]*m$|^--message=$/.test(pieces[n]![0]!.text)));
    for (let n = 0; n < pieces.length; n++) {
      const glob = pieces[n]!.find((p) => p.quoted && /[!*?[{~]/.test(p.text));
      if (glob !== undefined && !message(n)) return `\`${/[!*?[{~]/.exec(glob.text)![0]}\` in quotes`;
    }
    if (program === 'cd' && (args.length !== 1 || !namesRoot(args[0]!, root))) return `\`cd ${clip(args.join(' '), 40)}\`, not to the project's root`;
    if (program === 'rg' && args.some((a) => a.startsWith('--pre') || a.startsWith('--hostname-bin'))) return '`rg --pre`';
    if (program === 'sed' && !sedReads(args)) return 'a `sed` that does more than print';
    if (program === 'printf' && args[0]?.startsWith('-')) return '`printf -v`';
    if (program === 'git') {
      for (let n = 0; n < args.length && args[n]!.startsWith('-'); n += 2) {
        const to = args[n + 1] ?? '';
        if (args[n] !== '-C') return `git ${clip(args[n]!, 30)}`;
        if (!namesRoot(to, root) && !(to === 'engine' && engine)) return `git -C ${clip(to, 40)}`;
      }
    }
  }
  return null;
}

/** Is a line plain (`notPlain`): only then Auto's own allowances. */
export const plainLine = (line: string, root: string, engine = false): boolean => notPlain(line, root, engine) === null;

/**
 * Is `engine` under the root a folder of its own (source mode's checkout) and
 * not a link: `git -C engine` in a plain line names it then. Read once, as the
 * session starts.
 */
export function engineDir(root: string): boolean {
  try {
    const at = join(root, 'engine');
    return !lstatSync(at).isSymbolicLink() && lstatSync(at).isDirectory() && realpathSync.native(at) === join(realpathSync.native(root), 'engine');
  } catch {
    return false;
  }
}

/** What Auto's allowances need beyond the line: is `engine` a folder of its own (`engineDir`), may the shell be away from the root (`ShellPlace`), the project's remotes and the engine's (`gitRemotes`). */
export interface At {
  engine?: boolean;
  away?: boolean;
  remotes?: readonly string[];
  engineRemotes?: readonly string[];
  /** The dev server's port (`devRouteOf`); none, any loopback port. */
  port?: number;
}

/** A URL to the dev server's own routes on this machine: its host, its port (none: 80), its route's area. */
const DEV_ROUTE = /^(?:https?:\/\/)?(?:localhost|127\.0\.0\.1|\[::1\]|0\.0\.0\.0)(?::(\d+))?\/__(assets|studio|agent)(?:[/?#]|$)/i;
/** The programs that fetch a URL: what a call to a route is made with. */
const FETCHERS = new Set(['curl', 'wget', 'http', 'https', 'xh']);

/**
 * The dev server's route a command calls -- `curl localhost:5190/__assets/move …`, `/__studio/`, `/__agent/` on a
 * loopback host at the dev server's port (`port`; none known, any) -- as `/__assets/`, or null. The studio's tools do
 * that work (Docs/mcp.md §9 M3: the brief says never curl them), with their checks, their steps and their undo; Auto
 * asks before a call that goes round them.
 */
export function devRouteOf(command: Pick<Command, 'words'>, port: number | undefined): string | null {
  if (!FETCHERS.has(command.words[0] ?? '')) return null;
  for (const word of command.words.slice(1)) {
    const m = DEV_ROUTE.exec(word.replace(/^--url=/, ''));
    if (!m) continue;
    const at = m[1] === undefined ? 80 : Number(m[1]);
    if (port === undefined || at === port) return `/__${m[2]!.toLowerCase()}/`;
  }
  return null;
}

/** The remotes in `at`, as `gitAsksWhy` takes them. */
const remotesAt = (at: At): GitRemotes => ({ ...(at.remotes === undefined ? {} : { project: at.remotes }), ...(at.engineRemotes === undefined ? {} : { engine: at.engineRemotes }) });

/**
 * A repository's remotes, by name (`git remote` in `root`), read once as the
 * session starts -- the project's, and the engine's checkout's (`engine/`):
 * the only ones `git fetch` and `git remote show` go to unasked, each in its
 * own repository. None read, none.
 */
export function gitRemotes(root: string): string[] {
  try {
    const out = execFileSync('git', ['remote'], { cwd: root, encoding: 'utf8', timeout: 5000, stdio: ['ignore', 'pipe', 'ignore'] });
    return out.split('\n').filter((name) => /^[A-Za-z0-9._-]+$/.test(name) && !name.startsWith('-'));
  } catch {
    return [];
  }
}

/**
 * The engine's checkout's remotes (`git -C engine remote`), in source mode:
 * only where `engine/` is a folder of its own (`engineDir`) and the top of a
 * repository of its own -- a folder with no `.git` would give the project's
 * (git looks up from it), which are not the engine's. None else.
 */
export function engineRemotes(root: string): string[] {
  if (!engineDir(root)) return [];
  try {
    const top = execFileSync('git', ['rev-parse', '--show-toplevel'], { cwd: join(root, 'engine'), encoding: 'utf8', timeout: 5000, stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    return realpathSync.native(top) === realpathSync.native(join(root, 'engine')) ? gitRemotes(join(root, 'engine')) : [];
  } catch {
    return [];
  }
}

/**
 * Why Auto's own allowances give nothing on this line (null: they give):
 * it is not plain (`notPlain`), or the shell may be away from the root after
 * an earlier line (`ShellPlace`) and this one does not start with a plain `cd`
 * there (`startsAtRoot`).
 */
export function withheld(line: string, root: string, at: At = {}): string | null {
  const why = notPlain(line, root, at.engine);
  if (why !== null) return `not a plain line: ${why}`;
  return at.away === true && !startsAtRoot(line, root) ? "an earlier line may have left the project's root" : null;
}

/** Does a line start with a plain `cd <root>`, run by the shell itself -- then `;`, `&&`, a new line or its end, never a pipe, `||` or `&`. */
export function startsAtRoot(line: string, root: string): boolean {
  const first = plainRead(line).commands[0];
  return first !== undefined && !first.piped && ['', ';', '&&', '\n'].includes(first.end) && first.words.length === 2 && first.words[0] === 'cd' && namesRoot(first.words[1]!, root);
}

/**
 * Programs that cannot move the shell they run in, with `READERS` but `cd`:
 * what a line runs besides them -- `cd`, `pushd`, `popd`, zsh's `chdir`, `source`, `.`, `eval`, `exec`,
 * a function or an alias of the person's, a program that is no plain word --
 * may leave it somewhere else (`leavesRoot`).
 */
const STAYS = new Set([...PLAIN_PROGRAMS, 'node', 'npm', 'npx', 'vibe', 'find', 'sed', 'awk', 'python', 'python3', 'tsc', 'tsx', 'vite', 'pnpm', 'yarn', 'bun', 'bunx', 'make', 'touch', 'cp', 'mv', 'ln', 'tee', 'sort', 'uniq', 'date', 'sleep', 'curl', 'jq', 'sh', 'bash', 'zsh', 'gladius', 'ffmpeg', 'open', 'kill', 'ps', 'lsof', 'tar', 'unzip', 'zip', 'gh', 'env', 'sudo', 'xargs']);

/**
 * May a line leave its shell outside the root, for the calls after it (Claude
 * Code keeps the Bash tool's folder from one call to the next): a `cd` or
 * `chdir` anywhere but to the root (`rootNames`, one operand), or anything not
 * known to stay (`STAYS`), run by `exec` or nested too deep to read. A match
 * too many is a card: the next line must start with a plain `cd <root>`.
 */
export function leavesRoot(line: string, root: string): boolean {
  return commandsOf(line).some((c) => {
    const [p = '', ...args] = c.words;
    if (c.unread !== undefined || c.via.includes('exec') || unplain(c.program)) return true;
    if (p === 'cd' || p === 'chdir') return !(args.length === 1 && namesRoot(args[0]!, root));
    return p !== '' && !STAYS.has(p) && !READERS.has(p);
  });
}

/**
 * Where the session's shell may be, across calls (§2, Permissions): Claude
 * Code keeps the Bash tool's folder from one call to the next, so a `cd ..` in
 * one line moves the next. One state for the session, not one per agent --
 * whose shell a subagent's line moves is the CLI's to say, so any agent's is
 * every agent's: a line that may leave the root (`leavesRoot`), any agent's,
 * marks it away; while it may be, Auto's allowances give nothing (`withheld`)
 * until a line that is run, any agent's, starts with a plain `cd <root>`
 * (`startsAtRoot`, not in the background: a shell of its own). The hook sees
 * every line (`saw`), allowed or not; `canUseTool` the ones it lets run
 * (`ran`) -- one a person's own `allow` runs never brings it back.
 *
 * By completion, not approval (round 6): a line let run has not run yet, and
 * another agent's may run before it or alongside. Each leaving line is held
 * in flight, by its call's id, from when it is seen until its call completes
 * (`done`: the `PostToolUse`/`PostToolUseFailure` hook, or its tool result
 * through the session), and marks it away again as it completes; a `cd
 * <root>` line brings the shell back only as it completes, and only while no
 * leaving line is in flight. A line with no id never brings it back.
 */
export class ShellPlace {
  private away_ = false;
  /** Lines that may leave the root, seen or let run, whose calls have not completed: their ids. */
  private readonly leaving = new Set<string>();
  /** Lines that start with a plain `cd <root>`, let run, whose calls have not completed: their ids. */
  private readonly back = new Set<string>();

  /** May the shell be away from the root now. */
  away(): boolean {
    return this.away_;
  }

  /** A line seen, run or not: one that may leave the root marks it away, and is in flight until its call completes. */
  saw(line: string, root: string, id?: string): void {
    if (!leavesRoot(line, root)) return;
    this.away_ = true;
    if (id !== undefined) this.leaving.add(id);
  }

  /** A line let run: marked as `saw` does -- else one that starts at the root, not in the background, waits to bring it back as it completes. */
  ran(line: string, root: string, background = false, id?: string): void {
    if (leavesRoot(line, root)) this.saw(line, root, id);
    else if (!background && id !== undefined && startsAtRoot(line, root)) this.back.add(id);
  }

  /** A call completed, run or refused: a leaving line marks it away again; a `cd <root>` line brings it back, while no leaving line is in flight. */
  done(id: string): void {
    if (this.leaving.delete(id)) {
      this.back.delete(id);
      this.away_ = true;
    } else if (this.back.delete(id) && this.leaving.size === 0) this.away_ = false;
  }

  /** The CLI gone (a new query): its calls never complete -- forgotten, the shell as it was marked. */
  settle(): void {
    this.leaving.clear();
    this.back.clear();
  }
}

// ---------------------------------------------------------------- deletions, under Auto

/** Folders a recursive `rm` empties unasked under Auto: what a build, an install or a cache makes again. */
export const REMADE = ['dist', 'node_modules', '.vite', 'coverage', 'public/packs', '.cache/assets'];

/**
 * What git ignores but nothing makes again, and no snapshot holds: a recursive `rm` of it, in it, or of a folder
 * holding it, asks under Auto -- Undo this turn could not bring it back. The Assets tool's restorable deletions
 * (`.trash/`), the conversations' logs and index (`.cache/agent/`), Claude Code's own (`.claude/`), the engine's
 * checkout's link to its repository in source mode (`engine/.git`: the submodule's, which the project's snapshot
 * holds only as a gitlink), and this machine's settings and secrets (a name with `.local` in it, `.env…`).
 */
export const KEPT = ['.trash', '.cache/agent', '.claude', 'engine/.git'];

/** Does removing `rel` (relative to the root, `/`-separated) take something `KEPT` with it? */
function keeps(rel: string): boolean {
  const lower = rel.toLowerCase();
  if (KEPT.some((d) => lower === d || lower.startsWith(`${d}/`) || d.startsWith(`${lower}/`))) return true;
  return lower.split('/').some((name) => /\.local\b/.test(name) || /^\.env/.test(name));
}

/** Is a path under the project's gitignore (`git check-ignore -q`), relative to the root: the session's, cached per turn. */
export type Ignored = (path: string) => Promise<boolean>;

/** Programs that run the package named after them, and where that name is: `npx rimraf`, `npm exec rimraf`, `pnpm dlx rimraf`. */
function packageRun(words: readonly string[]): string | null {
  const [p, sub] = words;
  const at = p === 'npx' || p === 'bunx' ? 1 : (p === 'npm' && sub === 'exec') || ((p === 'pnpm' || p === 'yarn') && (sub === 'dlx' || sub === 'exec')) ? 2 : -1;
  if (at < 0) return null;
  const name = words.slice(at).find((w) => !w.startsWith('-'));
  return name === undefined ? null : programOf(name).replace(/@[^/]*$/, '');
}

/** A program's word that is no plain word: an expansion, a substitution, braces or a glob decide what runs (`$g`, `git${IFS}checkout`, `{git,reset}`). */
const unplain = (program: string): boolean => program !== '[' && program !== '[[' && /[$`{}*?[\]]/.test(program);

/** A word of a path an `rm` may name and Auto spare: letters, digits and `._@+=,-` -- no expansion, brace, `~`, quote or space. */
const PLAIN_PART = /^[A-Za-z0-9._@+=,-]+$/;

/** Is any folder from the root down to `rel` (relative, `/`-separated) a symbolic link? What does not exist yet is none. */
function throughLink(root: string, rel: string): boolean {
  let at = root;
  for (const part of rel.split('/')) {
    at = join(at, part);
    try {
      if (lstatSync(at).isSymbolicLink()) return true;
    } catch {
      return false;
    }
  }
  return false;
}

/**
 * Is a recursive `rm`'s target one Auto spares (§2, Permissions): under one
 * of `REMADE`, or ignored by git -- never `KEPT` (`.trash/`, `.cache/agent/`,
 * `.claude/`, `*.local*`, `.env*`), which git ignores and nothing remakes,
 * nor a folder holding one (`rm -r .cache`). Strictly a plain path, on a
 * plain line (`withheld`): every word of it `PLAIN_PART`s -- no `$`, backtick,
 * `{`, `}`, `~`, glob, quote or `..` anywhere (`dist/{,../src}`, `dist*`,
 * `"$HOME"`: bash expands it first). Inside the root, never the root itself,
 * never through a symbolic link
 * from the root down (`throughLink`: the longest prefix that exists is then
 * where its words say, in the folder they name), never anywhere under
 * `node_modules/@vibe/` -- the engine, in source mode a link to its checkout
 * -- nor a worktree under
 * `.claude/worktrees/` (another checkout, ignored but in no snapshot), nor
 * anything `GUARDED`. A known gap, between the check and the use: `throughLink`
 * and `sparedRms` look at the disk as Auto decides, and a command still running
 * from an earlier call (`run_in_background`) could swap `dist` for a link to
 * `src` before this `rm` runs -- nothing here can close that; the agent's own
 * earlier line, under Auto, was read too.
 */
async function remadeTarget(target: string, root: string, ignored: Ignored): Promise<boolean> {
  const rel = plainRmTarget(target, root);
  if (rel === null) return false;
  if (REMADE.some((d) => rel === d || rel.startsWith(`${d}/`))) return true;
  return ignored(rel);
}

/**
 * A recursive `rm`'s target as a path in the project (relative, `/`-separated), when it is one Auto or Unsafe auto
 * could spare: a plain path (`PLAIN_PART` words, no `..`), inside the root but not the root, not the engine's
 * checkout (`node_modules/@vibe/`), not a worktree, nothing `GUARDED` or `KEPT`, through no link from the root down.
 * Null for any other.
 */
function plainRmTarget(target: string, root: string): string | null {
  const parts = target.split('/');
  // A leading `/` and a trailing one are empty words.
  const words = parts.filter((w, n) => !(w === '' && (n === 0 || n === parts.length - 1)));
  if (words.length === 0 || words.some((w) => w === '..' || !PLAIN_PART.test(w))) return null;
  const plain = (isAbsolute(target) ? '/' : '') + words.join('/');
  const rel = relative(root, resolve(root, plain)).split(sep).join('/');
  if (rel === '' || rel === '..' || rel.startsWith('../') || isAbsolute(rel)) return null;
  const lower = rel.toLowerCase();
  // The engine: in source mode node_modules/@vibe/engine is its checkout.
  if (lower === 'node_modules/@vibe' || lower.startsWith('node_modules/@vibe/')) return null;
  // A worktree under .claude/worktrees/ is another checkout, ignored by git here and in no snapshot: nothing remakes it.
  if (lower === WORKTREES.slice(0, -1) || lower.startsWith(WORKTREES) || guarded(resolve(root, plain), root) !== null) return null;
  if (keeps(rel)) return null;
  if (throughLink(root, rel)) return null;
  return rel;
}

/** Programs before a spared `rm` in a line that cannot have made a folder a link or moved one into place: what runs first is then what is there. */
const SAFE_BEFORE = new Set(['cd', 'rm', 'echo', 'printf', 'true', ':', 'pwd', 'ls', 'mkdir', 'test', '[', '[[']);

/**
 * The recursive `rm`s of a plain line (`withheld` gives nothing against it)
 * that Auto spares (§2, Permissions), the rest of `deletes` and the host's
 * `Bash(rm -rf:*)` deciding the others -- by identity, among `commands`
 * (`commandsOf(line)`). One is spared only when every target is
 * (`remadeTarget`) and before it only `SAFE_BEFORE` ran (`npm run x`, `git mv
 * src dist` first is not): nothing could have changed what its path is by the
 * time it runs. The plain line has seen to the rest -- no wrapper, no `$(…)`,
 * no `&`, no pipe but into a reader, no `ln`, `cp` or `mv`.
 */
async function sparedRms(commands: readonly Command[], root: string, ignored: Ignored): Promise<Set<Command>> {
  const spared = new Set<Command>();
  for (const c of commands) {
    const [p = '', ...args] = c.words;
    if (p === 'rm' && rmRecursive(args)) {
      for (const target of rmTargets(args)) if (!(await remadeTarget(target, root, ignored))) return spared;
      spared.add(c);
    } else if (!SAFE_BEFORE.has(p)) break;
  }
  return spared;
}

/**
 * Does a line `cd` somewhere, so that a relative path after it may not be the
 * project's: any `pushd` or `popd`, or a `cd` anywhere but the root -- Claude
 * Code starts many a line with `cd <the project>;`, which moves nowhere.
 */
function movesAway(commands: readonly Command[], root: string): boolean {
  return commands.some((c) => {
    if (c.words[0] === 'pushd' || c.words[0] === 'popd') return true;
    if (c.words[0] !== 'cd') return false;
    const to = c.words.slice(1).find((a) => !a.startsWith('-'));
    return to === undefined || /[$`~]/.test(to) || resolve(root, to) !== resolve(root);
  });
}

/** An `rm`'s operands: every word after `--`, and every word before it that is no option. */
function rmTargets(args: readonly string[]): string[] {
  const end = args.indexOf('--');
  return args.filter((w, n) => (end >= 0 && n > end) || ((end < 0 || n < end) && !(w.startsWith('-') && w !== '-')));
}

/** Is an `rm` recursive: `-r`, `-R` or `--recursive`, bundled or not, before any `--`. */
function rmRecursive(args: readonly string[]): boolean {
  const end = args.indexOf('--');
  return (end < 0 ? args : args.slice(0, end)).some((f) => f === '--recursive' || /^-[^-]*[rR]/.test(f));
}

/** What a deleting command is, in a few words, for the card's "Auto still asks" line. */
function deleteWhat(command: Command): string {
  const [p = '', ...args] = command.words;
  if (unplain(command.program)) return `a program that is not a plain word (${clip(command.program, 40)})`;
  if (p === 'rm' && command.via.includes('xargs')) return '`xargs rm`';
  if (p === 'rm' && command.via.includes('find')) return '`find -exec rm`';
  if (p === 'rm') return `a recursive delete of ${clip(rmTargets(args).join(' ') || 'nothing named', 80)}`;
  if (p === 'find') return '`find -delete`';
  if (p === 'rsync') return '`rsync --delete`';
  if (p === 'truncate' || p === 'shred') return `\`${p}\``;
  return 'rimraf, a recursive delete';
}

/**
 * Why Auto asks before a command that deletes in a way it can read
 * (§2, Permissions): a recursive `rm` the line's `sparedRms` does not spare
 * -- anything but `REMADE` and what git ignores, as plain paths, never
 * `KEPT`; `rm` fed by `xargs` or a
 * `find -exec`; `find -delete`; `rsync --delete…`; `truncate`; `shred`;
 * `rimraf`, run or fetched; and a program that is no plain word, which could
 * be any of them. Null for any other. What it cannot read -- an interpreter's
 * code, a script, `npm run`, `make`, an alias -- goes by unread, and can do
 * anything: Undo this turn puts back the project's files and the engine's,
 * nothing else (Docs/agent.md §2: these lists are no boundary).
 */
export function deletes(command: Command, spared: ReadonlySet<Command>, held: string | null = null): string | null {
  if (unplain(command.program)) return `Auto asks: the program is not a plain word (${clip(command.program, 40)}), so what it runs cannot be read.`;
  const [p, ...args] = command.words;
  if (p === 'rm') {
    if (command.via.includes('xargs')) return 'Auto asks before `xargs rm`: what it deletes comes from elsewhere.';
    if (command.via.includes('find')) return 'Auto asks before `find … -exec rm`: what it deletes is whatever find finds.';
    if (!rmRecursive(args)) return null;
    if (held !== null) return `Auto asks before a recursive rm here (${held}): it spares one of what is made again only on a plain line, run at the project's root.`;
    return spared.has(command) ? null : `Auto asks before a recursive rm not plainly of ${REMADE.map((d) => `${d}/`).join(', ')} or what git ignores -- a plain path, through no link, with nothing in the line that could change where it leads -- and never of .trash/, .cache/agent/ or a .local or .env file: nothing makes them again.`;
  }
  if (p === 'find' && args.includes('-delete')) return 'Auto asks before `find -delete`: what it deletes is whatever find finds.';
  if (p === 'rsync' && args.some((a) => /^--(delete|del$|remove-source-files)/.test(a))) return 'Auto asks before `rsync --delete`: it deletes what the source lacks.';
  if (p === 'truncate' || p === 'shred') return `Auto asks before \`${p}\`: it destroys a file's contents.`;
  if (p === 'rimraf' || packageRun(command.words) === 'rimraf') return 'Auto asks before rimraf: a recursive delete.';
  return null;
}

/**
 * Why Auto asks about a command line (§2, Permissions): a command nested too
 * deep to read, a git command that does more than read (`gitAsks`), or a
 * deletion it can read (`deletes`); null when it has nothing against it.
 */
export async function autoAsks(line: string, root: string, ignored: Ignored, at: At = {}): Promise<string | null> {
  return (await autoAsksWhy(line, root, ignored, at))?.reason ?? null;
}

/** Why Auto asks about a command line (`autoAsks`), and what it is in a few words: the card's "Auto still asks" line. */
export async function autoAsksWhy(line: string, root: string, ignored: Ignored, at: At = {}): Promise<{ reason: string; what: string } | null> {
  const commands = commandsOf(line);
  const moved = movesAway(commands, root);
  const held = withheld(line, root, at);
  const spared = held === null ? await sparedRms(commands, root, ignored) : new Set<Command>();
  // What a command runs among its words (`hiddenIn`), on a line that is not plain: a plain line runs none of them.
  const hidden = held === null ? [] : hiddenIn(commands);
  for (const command of [...commands, ...hidden]) {
    if (command.unread !== undefined) return { reason: command.unread, what: 'a command whose script it cannot read' };
    const route = devRouteOf(command, at.port);
    if (route !== null) return { reason: `It calls the dev server's own ${route} routes: the studio's tools (mcp__studio__…) do that work, with their checks and undo -- use them.`, what: `a call to the dev server's ${route} routes` };
    const git = gitAsksWhy(command, root, moved, held, remotesAt(at));
    if (git !== null) return git;
    const unnamed = writesUnnamed(command, root);
    if (unnamed !== null) return unnamed;
    const gone = deletes(command, spared, held);
    if (gone !== null) return { reason: gone, what: deleteWhat(command) };
  }
  return null;
}

/** tar's letters that take a value, in a bundle or after a `-`. */
const TAR_TAKES = new Set(['f', 'C', 'T', 'X', 'b', 'K', 'N', 'L', 'V', 'I']);
/** tar's long options that take a value as the next word when no `=` gives it. */
const TAR_LONG_TAKES = ['--file', '--directory', '--files-from', '--exclude-from', '--blocking-factor', '--starting-file', '--newer', '--tape-length', '--label', '--use-compress-program', '--exclude', '--transform', '--xform', '--owner', '--group', '--mode', '--format', '--strip-components'];

/**
 * What a command writes that its words do not name, run in the project: an archive unpacked whole (`tar x`, `unzip`
 * with no member listed) or a patch applied (`patch`, `git apply`) -- an archive's members and a patch's files may be
 * `.claude/settings.json` or `assets.local.json` (`guardedWrite` judges only what is named). A card under Auto and
 * Unsafe auto (the floor): every project has `.claude/`, so "when it holds a guarded file" is always. Members listed are
 * judged by name (`guarded`); a folder given outside the project (`tar -C /tmp`, `unzip -d /tmp`) is no write here.
 * Null for none.
 */
function writesUnnamed(command: Command, root: string): { reason: string; what: string } | null {
  const [program = '', ...args] = command.words;
  const outside = (dir: string | undefined): boolean => dir !== undefined && !/[$`~]/.test(dir) && !inside(root, resolve(root, dir));
  const card = (what: string, instead = 'Name the members, or unpack it outside the project and copy what is needed.'): { reason: string; what: string } => ({
    reason: `It ${what}, writing files its words do not name -- which may be under .claude/ or this machine's *.local settings, never written unasked. ${instead}`,
    what,
  });
  if (program === 'tar') {
    let extract = false;
    let dir: string | undefined;
    let fromList = false;
    const members: string[] = [];
    for (let i = 0; i < args.length; i++) {
      const a = args[i]!;
      const bundle = i === 0 && !a.startsWith('-') ? a : a.startsWith('-') && !a.startsWith('--') ? a.slice(1) : null;
      if (a.startsWith('--')) {
        const [name, value] = a.includes('=') ? [a.slice(0, a.indexOf('=')), a.slice(a.indexOf('=') + 1)] : [a, undefined];
        if (name === '--extract' || name === '--get') extract = true;
        const v = value ?? (TAR_LONG_TAKES.includes(name) ? args[++i] : undefined);
        if (name === '--directory') dir = v;
        if (name === '--files-from') fromList = true;
        continue;
      }
      if (bundle !== null) {
        for (let k = 0; k < bundle.length; k++) {
          const letter = bundle[k]!;
          if (letter === 'x') extract = true;
          if (!TAR_TAKES.has(letter)) continue;
          // A dashed bundle's value is the rest of it when there is a rest; an old-style bundle's are the next words.
          const v = a.startsWith('-') && k < bundle.length - 1 ? bundle.slice(k + 1) : args[++i];
          if (letter === 'C') dir = v;
          if (letter === 'T') fromList = true;
          if (a.startsWith('-')) break;
        }
        continue;
      }
      members.push(a);
    }
    if (!extract || outside(dir)) return null;
    if (members.length === 0 || fromList) return card('unpacks an archive whole');
    const named = members.find((m) => guarded(resolve(root, dir ?? '.', m), root) !== null);
    return named === undefined ? null : card(`unpacks ${named} from an archive`);
  }
  if (program === 'unzip') {
    let dir: string | undefined;
    const operands: string[] = [];
    let listing = false;
    for (let i = 0; i < args.length; i++) {
      const a = args[i]!;
      if (a === '-d') dir = args[++i];
      else if (a.startsWith('-d') && a.length > 2) dir = a.slice(2);
      else if (a === '-x') break;
      else if (/^-[A-Za-z]*[lZtv]/.test(a)) listing = true;
      else if (a === '-P') i++;
      else if (!a.startsWith('-')) operands.push(a);
    }
    if (listing || outside(dir)) return null;
    const members = operands.slice(1);
    if (members.length === 0) return card('unpacks an archive whole');
    const named = members.find((m) => /[*?[]/.test(m) || guarded(resolve(root, dir ?? '.', m), root) !== null);
    return named === undefined ? null : card(`unpacks ${named} from an archive`);
  }
  if (program === 'patch') {
    if (args.some((a) => a === '--dry-run' || a === '-C' || a === '--check')) return null;
    const d = args.findIndex((a) => a === '-d' || a === '--directory');
    if (d >= 0 && outside(args[d + 1])) return null;
    return card('applies a patch', 'Make its changes with Edit instead.');
  }
  if (program === 'git' && command.words[1] === 'apply') {
    const rest = command.words.slice(2);
    // Only reading the patch: what it would do, written nowhere.
    if (rest.some((a) => a === '--check' || a === '--stat' || a === '--numstat' || a === '--summary') && !rest.includes('--apply')) return null;
    return card('applies a patch', 'Make its changes with Edit instead.');
  }
  return null;
}

/**
 * Why Unsafe auto still asks about a command line (Docs/mcp.md §7 D3), and what it is in a few words: it takes
 * every one of Auto's still-asks of the shell -- git of any kind in this project, on any line (`push`, `pull`,
 * and what discards work here: `reset`, `clean`, `stash`, `rebase`, `restore`, `switch -f`, `checkout --`,
 * `commit --amend`), a script it cannot read (`curl … | sh`), a recursive `rm` of plain paths the project holds,
 * git-tracked or not -- and only its floor asks: anything outside the project -- git pointed at another
 * repository (`-C`, `--git-dir`), given a setting or a `GIT_*` that can point it elsewhere or run a program, a
 * git read of a file elsewhere (`--no-index`, `--output` …), anything after the line or the shell may have left
 * the root; a delete whose targets it cannot read as plain paths inside the project (`rm -rf $DIR`, `xargs rm`,
 * `find -delete`, `rsync --delete`, `truncate`, `shred`, rimraf -- they may be outside), or of what is `GUARDED`
 * or `KEPT`. A write under `.git/` or `.claude/` and the person's own ask rules are the gate's, before.
 */
export function unsafeAsksWhy(line: string, root: string, at: At = {}): { reason: string; what: string } | null {
  const commands = commandsOf(line);
  const moved = movesAway(commands, root) || at.away === true;
  for (const command of [...commands, ...hiddenIn(commands)]) {
    if (command.unread !== undefined) {
      // A script it cannot read goes by -- but not once the shell may be outside the project, the floor.
      if (!moved) continue;
      return { reason: `Unsafe auto still asks: ${command.unread} The shell may have left the project's root first.`, what: 'a command whose script it cannot read, away from the root' };
    }
    const unnamed = writesUnnamed(command, root);
    if (unnamed !== null) return { reason: `Unsafe auto still asks: ${unnamed.reason}`, what: unnamed.what };
    if (fetchedPaths(command).includes(IMPORT_ROUTE)) return { reason: `Unsafe auto still asks: it sends a file to the dev server's ${IMPORT_ROUTE} route -- asset_import, which asks before a file from outside the project, without its check. Use asset_import.`, what: `a call to the dev server's ${IMPORT_ROUTE} route` };
    if (command.words[0] === 'git') {
      // As on a plain line: git's reading commands, add, commit, a new branch -- what Auto lets by there.
      const why = gitAsksWhy(command, root, moved, null, remotesAt(at));
      if (why === null) continue;
      const sub = command.words[1] ?? '';
      // In this project, as it stands: any git goes by -- what discards work too. Held to the project: no setting,
      // no environment, not pointed elsewhere, not after a cd away, no read or write of a file elsewhere.
      const seated = !moved && command.config.every((key) => SAFE_GIT_CONFIG.test(key)) && command.lineEnv === undefined && !('elsewhere' in gitPlace(command, root, moved));
      const here = !READS_HELD.has(sub) || readsHere(sub, command.words.slice(2), root);
      if (seated && here) continue;
      return { reason: `Unsafe auto still asks: ${why.reason}`, what: why.what };
    }
    const gone = deletes(command, new Set(), null);
    if (gone === null) continue;
    const [p, ...args] = command.words;
    const targets = rmTargets(args);
    const spared = p === 'rm' && !moved && !unplain(command.program) && !command.via.includes('xargs') && !command.via.includes('find') && targets.length > 0 && targets.every((t) => plainRmTarget(t, root) !== null);
    if (!spared) return { reason: `Unsafe auto still asks: ${gone}`, what: deleteWhat(command) };
  }
  return null;
}

/**
 * On a line that is not plain, a `git`, an `rm`, a shell, `eval` or a wrapper
 * Auto knows among any command's words, read as a command of its own, run
 * under that command: what a wrapper Auto does not know runs (`noglob git rm
 * -r src`, `genv -C .. git add -A`, `chroot / rm -rf x`, `X+=1 git …`,
 * `nocorrect sh -c 'git …'`) is git or rm all the same. A match too many
 * (`echo git rm -r x`) is a card.
 */
function hiddenIn(commands: readonly Command[]): Command[] {
  const out: Command[] = [];
  for (const c of commands) {
    for (let k = 1; k < c.words.length; k++) {
      const p = programOf(c.words[k]!);
      if (p === 'git' || p === 'rm' || p === 'env' || p === 'eval' || SHELLS.has(p) || p in WRAPPERS) normalise(c.words.slice(k), 1, out, [...c.via, c.words[0]!]);
    }
  }
  return out;
}

/**
 * The host's rule that names a call, as Auto has it (`hostRule`): under Auto,
 * a recursive `rm` that Auto's own line lets by on a plain line (`withheld`,
 * `sparedRms`: what the build remakes, what git ignores, as plain paths) is spared `Bash(rm -rf:*)` --
 * the rule is for what can wipe work, and those cannot. Any other, a wrapper's
 * (`sudo rm -rf dist`) too, is the rule's card as before Auto spared any.
 */
export async function hostAsk(tool: string, input: Record<string, unknown>, root: string, auto: boolean, ignored: Ignored, at: At = {}, unsafe = false): Promise<string | undefined> {
  const line = input.command;
  if (!auto || (tool !== 'Bash' && tool !== 'PowerShell') || typeof line !== 'string') return hostRule(tool, input, root);
  // Unsafe auto: the host's rules give way to its own reading of the line (`unsafeAsksWhy`), which keeps the floor.
  if (unsafe) return undefined;
  const commands = commandsOf(line);
  const held = withheld(line, root, at);
  const spared = held === null ? await sparedRms(commands, root, ignored) : new Set<Command>();
  // Matched over these same commands, by identity: two alike in a line (`rm -rf dist/x; mv l dist; rm -rf dist/x`) are two.
  return HOST_ASK.find((r) => {
    const { tool: ruleTool, content } = parseRule(r);
    if (ruleTool !== tool) return false;
    if (content === null || content === '' || content === '*') return true;
    const names = bashRule(content);
    return commands.some((c) => !((c.words[0] === 'git' && gitAsksWhy(c, root, false, held, remotesAt(at)) === null) || spared.has(c)) && names(c));
  });
}

/** The host's rule in a few words, for the card's "Auto still asks" line: `git push`, a recursive delete of what it names. */
export function hostWhat(rule: string, input: Record<string, unknown>): string {
  const content = (parseRule(rule).content ?? rule).replace(/:\*$/, '').trim();
  if (!content.startsWith('rm')) return content;
  const rm = commandsOf(typeof input.command === 'string' ? input.command : '').find((c) => c.words[0] === 'rm' && rmRecursive(c.words.slice(1)));
  return rm === undefined ? 'a recursive delete' : `a recursive delete of ${clip(rmTargets(rm.words.slice(1)).join(' ') || 'nothing named', 80)}`;
}

// ---------------------------------------------------------------- reading through a link

/** The tools that only read the path they name. */
const READ_TOOLS = new Set(['Read', 'Grep', 'Glob', 'LS', 'NotebookRead']);

/**
 * Programs that only read, whatever their operands -- none that writes a file
 * with an option or runs a program (`tree -o`, `less`'s `-o` and its
 * `LESSOPEN`, `more`, `file -C`, `ag --pager` are not here); `rg` but with
 * `--pre` or `--hostname-bin`, `sed` and `find` are read below.
 */
const READERS = new Set(['cat', 'head', 'tail', 'grep', 'egrep', 'fgrep', 'rg', 'ls', 'wc', 'cut', 'tr', 'diff', 'cmp', 'stat', 'du', 'echo', 'printf', 'pwd', 'cd', 'test', '[', '[[', 'true', 'false', 'jq', 'realpath', 'readlink', 'basename', 'dirname', 'nl', 'od', 'strings', 'which', 'type', 'column', 'fold', 'rev', 'comm', 'md5', 'shasum', 'sha256sum', 'md5sum']);

/** `find`'s actions that write or run something. */
const FIND_WRITERS = new Set(['-delete', '-exec', '-execdir', '-ok', '-okdir', '-fprint', '-fprint0', '-fprintf', '-fls']);

/**
 * Is a sed script only addresses and printing: commands among `p`, `=`, `q`,
 * `d`, `n`, `N` and `{ }`, each after an address or two -- a line number
 * (`10`, `1~2`), `$`, a `/regex/` (`I`, `M` after it) or `+N`/`~N` as the
 * second -- separated by `;`, spaces or new lines. No `s`, `w`, `W`, `e`, `r`,
 * `R`, `y`, `a`, `i`, `c`, label, comment or other delimiter: what can write a
 * file or run a program is not a read. A bracket in a regex may not hold a
 * `/` (where a sed's regex ends is then plain).
 */
function sedScriptReads(script: string): boolean {
  let i = 0;
  const digits = (): boolean => {
    const from = i;
    while (i < script.length && script[i]! >= '0' && script[i]! <= '9') i++;
    return i > from;
  };
  /** An address, if one is here: false for one begun and not ended. */
  const address = (second: boolean): boolean => {
    const c = script[i];
    if (c === '$') i++;
    else if (c !== undefined && c >= '0' && c <= '9') {
      digits();
      if (script[i] === '~') {
        i++;
        if (!digits()) return false;
      }
    } else if (second && (c === '+' || c === '~')) {
      i++;
      if (!digits()) return false;
    } else if (c === '/') {
      for (i++; i < script.length && script[i] !== '/'; i++) {
        if (script[i] === '\\') i++;
        else if (script[i] === '[') {
          const close = script.indexOf(']', i + (script[i + 1] === '^' ? 3 : 2));
          if (close < 0 || script.slice(i, close).includes('/')) return false;
          i = close;
        }
      }
      if (i >= script.length) return false;
      i++;
      while (script[i] === 'I' || script[i] === 'M') i++;
    } else if (second) return false;
    return true;
  };
  const space = (): void => {
    while (i < script.length && ' \t'.includes(script[i]!)) i++;
  };
  for (;;) {
    while (i < script.length && ' \t\n;'.includes(script[i]!)) i++;
    if (i >= script.length) return true;
    if (script[i] === '}') {
      i++;
      continue;
    }
    if (!address(false)) return false;
    if (script[i] === ',') {
      i++;
      if (!address(true)) return false;
    }
    space();
    if (script[i] === '!') {
      i++;
      space();
    }
    const command = script[i++];
    if (command === undefined || !'p=qdnN{'.includes(command)) return false;
    if (command !== '{' && i < script.length && !' \t\n;}'.includes(script[i]!)) return false;
  }
}

/**
 * Does a `sed` only read: `-n` (`--quiet`, `--silent`) given, its scripts --
 * the first word that is no option, or each `-e`'s -- only addresses and
 * printing (`sedScriptReads`); no `-i`, `-f`, `-s`, `-u`, `-z` or any other
 * option but `-E`/`-r`.
 */
function sedReads(args: readonly string[]): boolean {
  let quiet = false;
  const scripts: string[] = [];
  let given = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i]!;
    if (a === '--') {
      if (!given && i + 1 < args.length) scripts.push(args[i + 1]!);
      break;
    }
    if (a === '--quiet' || a === '--silent') quiet = true;
    else if (a === '--regexp-extended') continue;
    else if (/^-[nEr]*e$/.test(a)) {
      quiet ||= a.includes('n');
      given = true;
      scripts.push(args[++i] ?? '');
    } else if (/^-[nEr]+$/.test(a)) quiet ||= a.includes('n');
    else if (a.startsWith('-') && a !== '-') return false;
    else if (!given && scripts.length === 0) scripts.push(a);
  }
  return quiet && scripts.length > 0 && scripts.every(sedScriptReads);
}

/** What `readsOnly` takes of git: its reading commands, as `gitReads` reads them. */
const readsGit = (command: Command): boolean => gitReads(command) && PURE_GIT_READS.has(command.words[1] ?? '');

/**
 * Does a call only read, as far as can be told -- by an allow-list, not a
 * search for writers: a reading tool, or a command line each of whose
 * commands is a reader (`READERS`; `rg` with no `--pre` or `--hostname-bin`),
 * a `sed` that only prints (`sedReads`), a `find` with none of its writers or
 * git reading (`PURE_GIT_READS`), run under no wrapper and given no variable
 * (`RIPGREP_CONFIG_PATH=…` would give rg options from a file), writing
 * nothing but `/dev/null`. What cannot be told does not.
 */
export function readsOnly(tool: string, input: Record<string, unknown>): boolean {
  if (READ_TOOLS.has(tool)) return true;
  if (tool !== 'Bash' || typeof input.command !== 'string') return false;
  const commands = commandsOf(input.command);
  return commands.length > 0 && commands.every((c) => {
    if (c.unread !== undefined || unplain(c.program) || c.via.length > 0 || (c.assigned ?? []).length > 0 || (c.outs ?? []).some((o) => o !== '/dev/null')) return false;
    const [p = '', ...args] = c.words;
    if (p === 'rg') return !args.some((a) => a.startsWith('--pre') || a.startsWith('--hostname-bin'));
    if (READERS.has(p)) return true;
    if (p === 'sed') return sedReads(args);
    if (p === 'find') return !args.some((a) => FIND_WRITERS.has(a));
    return readsGit(c);
  });
}

/**
 * The npm workspace a folder is in: the nearest folder above it with a
 * `package.json` that has `workspaces` -- never `/` or the home folder, nor
 * one above it. Null for none.
 */
function workspaceOf(dir: string, home: string): string | null {
  for (let at = dirname(dir); at !== dirname(at) && at !== home && !inside(at, home); at = dirname(at)) {
    try {
      const pkg = JSON.parse(readFileSync(join(at, 'package.json'), 'utf8')) as { workspaces?: unknown };
      if (pkg.workspaces !== undefined) return at;
    } catch {
      // No package.json here, or none that parses: on up.
    }
  }
  return null;
}

/**
 * Where the engine's links in the project lead: the real folder of each
 * symbolic link `node_modules/@vibe/<name>` -- in source mode the engine's
 * packages, `node_modules/@vibe/engine` being the engine's checkout beside
 * the project -- and the root's own real path, where it is named through one
 * (`/tmp` is `/private/tmp` on macOS). Claude Code names what is read
 * through such a link by its real path (`blockedPath`), outside the allowed
 * folders; under Auto, a read there goes by (`linkedRead`). Only those links,
 * and only one that leads into an npm workspace (`workspaceOf`: the engine's
 * checkout) -- never to `/`, the home folder, a folder above the root or
 * above home. The session reads them once, as it starts (`session.ts`): a
 * link made during it (`ln -s ~ node_modules/@vibe/h`) never widens it.
 */
export function linkedRoots(root: string, home: string = homedir()): string[] {
  const out = new Set<string>();
  const real = (path: string): string | null => {
    try {
      return realpathSync.native(path);
    } catch {
      return null;
    }
  };
  const top = real(root);
  if (top !== null && top !== root) out.add(top);
  const realRoot = top ?? root;
  const realHome = real(home) ?? home;
  const scope = join(root, 'node_modules', '@vibe');
  let names: string[];
  try {
    names = readdirSync(scope);
  } catch {
    return [...out];
  }
  for (const name of names) {
    const path = join(scope, name);
    try {
      if (!lstatSync(path).isSymbolicLink()) continue;
    } catch {
      continue;
    }
    const to = real(path);
    if (to === null || inside(root, to) || inside(realRoot, to)) continue;
    // `/`, home, or a folder holding the root or home: what a link there opens is everything.
    if (to === dirname(to) || inside(to, realRoot) || inside(to, realHome)) continue;
    if (workspaceOf(to, realHome) !== null) out.add(to);
  }
  return [...out];
}

/** A path with `/` between its names: a Windows one's `\` turned (a rule's glob, a key, are written with `/`). */
const slashed = (path: string): string => (sep === '\\' ? path.split(sep).join('/') : path);

/** Is a path the CLI named outside the project under one of `linked`'s folders. */
const underLinked = (path: string, linked: readonly string[]): boolean => linked.some((d) => inside(d, path));

/** Is `path` the project root or under it. */
const inside = (root: string, path: string): boolean => {
  const rel = relative(root, resolve(root, path));
  return rel === '' || !(rel === '..' || rel.startsWith(`..${sep}`) || isAbsolute(rel));
};

/** A path under the root, relative with `/`. */
const projectRel = (root: string, path: string): string => relative(root, resolve(root, path)).split(sep).join('/') || '.';

/**
 * Folders of the project nothing is written in unasked, Auto or not, whoever's
 * rules allow it: git's own store -- its config and hooks run programs, in the
 * host's own `git add` too, and no snapshot has it -- and Claude Code's
 * settings, agents and skills, which hold the person's own rules. In source
 * mode the engine's checkout is a repository too (`engine/.git`, the
 * submodule's): guarded as the project's own store is.
 */
export const GUARDED = ['.git', '.claude', 'engine/.git'];

/**
 * This machine's own settings, guarded as `GUARDED` is, wherever they are: a file named `*.local.json` or `*.local`
 * (`assets.local.json`, the tool paths the next export or `tools_check` runs) -- what `fs-deny.ts` keeps from reads
 * and `KEPT` from deletions. A path written there would run past `tools_set`'s ask. Its `Guarded.dir`.
 */
export const LOCAL_FILES = '*.local';

/** A name of this machine's own settings: `*.local.json` or `*.local`, any case. */
const isLocalName = (name: string): boolean => /\.local(\.json)?$/i.test(name);

/** Where Claude Code keeps worktrees: each a checkout of the project, its files the project's, its own `.git` and `.claude` guarded. */
const WORKTREES = '.claude/worktrees/';

/** A path under `GUARDED`: the folder it is under, as `GUARDED` names it (`LOCAL_FILES` for this machine's settings), and the path as the project names it. */
export interface Guarded {
  dir: string;
  rel: string;
  /** Written through the dev server's route (`FLOOR_ROUTES`): its path, `/__assets/tools`. */
  route?: string;
}

/**
 * The guarded folder a path is under, or null: matched ignoring case, as the
 * volume does (`.GIT/hooks` is `.git/hooks`); a worktree under
 * `.claude/worktrees/` is a checkout, guarded inside as the project is.
 */
export function guarded(path: string, root: string): Guarded | null {
  if (!inside(root, path)) return null;
  const rel = projectRel(root, path);
  let rest = rel;
  for (;;) {
    const lower = rest.toLowerCase();
    const slash = lower.startsWith(WORKTREES) ? rest.indexOf('/', WORKTREES.length) : -1;
    if (slash > 0) {
      rest = rest.slice(slash + 1);
      continue;
    }
    const dir = GUARDED.find((d) => lower === d || lower.startsWith(`${d}/`));
    if (dir !== undefined) return { dir, rel };
    return isLocalName(rel.slice(rel.lastIndexOf('/') + 1)) ? { dir: LOCAL_FILES, rel } : null;
  }
}

/** The tools that write the file their input names. */
const FILE_WRITERS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit']);

/** Programs whose operands are files they write -- or may: `cp`'s source too, a match too many being a card. `sed` and `perl` only with `-i`. */
const WRITES = new Set(['cp', 'mv', 'tee', 'touch', 'rm', 'rmdir', 'mkdir', 'ln', 'chmod', 'chown', 'chgrp', 'chflags', 'install', 'rsync', 'ditto', 'dd', 'sed', 'perl', 'truncate', 'shred', 'unlink', 'patch', 'curl', 'wget', 'tar', 'unzip']);

/** Programs that put their sources into a folder named among their operands: `cp x .` writes `./x`. */
const INTO_FOLDER = new Set(['cp', 'mv', 'install', 'rsync', 'ditto', 'ln']);

/** How many files of a folder copied in are looked at, at most: past it, only the first so many are judged. */
const WALK_MAX = 5000;

/** A path's real one where it exists -- the deepest part of it that does, its links followed, the rest as written. */
function realish(path: string): string {
  let at = path;
  const rest: string[] = [];
  for (;;) {
    try {
      return join(realpathSync.native(at), ...rest);
    } catch {
      const up = dirname(at);
      if (up === at) return path;
      rest.unshift(basename(at));
      at = up;
    }
  }
}

/** Is `path` a folder (its link followed)? */
function isFolder(path: string): boolean {
  try {
    return statSync(path).isDirectory();
  } catch {
    return false;
  }
}

/** The files under a folder, relative with `/`, folders too, at most `WALK_MAX`; its links not followed. */
function filesUnder(dir: string): string[] {
  const out: string[] = [];
  const walk = (at: string, rel: string): void => {
    let names: string[];
    try {
      names = readdirSync(at);
    } catch {
      return;
    }
    for (const name of names) {
      if (out.length >= WALK_MAX) return;
      const r = rel === '' ? name : `${rel}/${name}`;
      out.push(r);
      try {
        if (lstatSync(join(at, name)).isDirectory()) walk(join(at, name), r);
      } catch {
        // gone while read: nothing more of it
      }
    }
  };
  walk(dir, '');
  return out;
}

/**
 * The dev server's routes a call writes a guarded file through (Docs/mcp.md §7 D3): each writes what a studio tool
 * asks before at every level (`asksWhen`) or what `GUARDED` keeps, so a `curl` to one is that write -- a card at every
 * level, Unsafe auto's too, no Always. `PUT /__assets/tools` is `tools_set` (a program's path into
 * `assets.local.json`); `POST /__studio/download` is `tools_download` (a program from the internet, its path set there
 * too); `PUT /__studio/file` is the Code card's save, which writes `.claude/skills/`, `.claude/agents/` and a tracked
 * `.claude/settings.json`; `POST /__agent/skills` makes a skill under `.claude/skills/`. Matched on any host and any
 * method, the path read as the server reads it (dots resolved; case, doubled slashes and escapes ignored -- a match
 * too many is a card).
 */
const FLOOR_ROUTES: Readonly<Record<string, Guarded>> = {
  '/__assets/tools': { dir: LOCAL_FILES, rel: 'assets.local.json', route: '/__assets/tools' },
  '/__studio/download': { dir: LOCAL_FILES, rel: 'assets.local.json', route: '/__studio/download' },
  '/__studio/file': { dir: '.claude', rel: '.claude/', route: '/__studio/file' },
  '/__agent/skills': { dir: '.claude', rel: '.claude/skills/', route: '/__agent/skills' },
};

/** The paths a fetch names, as the dev server reads them: dots resolved, doubled slashes one, escapes decoded, lowercased, no trailing `/`. */
function fetchedPaths(command: Pick<Command, 'words'>): string[] {
  if (!FETCHERS.has(command.words[0] ?? '')) return [];
  const out: string[] = [];
  for (const raw of command.words.slice(1)) {
    const word = raw.replace(/^--url=/i, '');
    if (word.startsWith('-')) continue;
    const bare = word.replace(/^[a-z][a-z0-9+.-]*:\/\//i, '');
    const slash = bare.indexOf('/');
    if (slash < 0) continue;
    let path = bare.slice(slash).split(/[?#]/)[0]!;
    try {
      path = decodeURIComponent(path);
    } catch {
      // a stray %: read as written
    }
    try {
      out.push(new URL(`http://h${path.replace(/\/{2,}/g, '/')}`).pathname.replace(/\/{2,}/g, '/').replace(/\/$/, '').toLowerCase());
    } catch {
      // no path a server would read
    }
  }
  return out;
}

/** The guarded write a fetch to one of the dev server's routes is (`FLOOR_ROUTES`), or null. */
export function floorRouteOf(command: Pick<Command, 'words'>): Guarded | null {
  for (const path of fetchedPaths(command)) {
    const hit = FLOOR_ROUTES[path];
    if (hit) return hit;
  }
  return null;
}

/**
 * `PUT /__assets/import` sent a file by a fetch (`curl -T`, `--data-binary @…`): `asset_import` without its ask for
 * a file from outside the project (`asksWhen`), the file read by the fetch, which nothing here reads. Unsafe auto's
 * floor; Auto asks for every route.
 */
const IMPORT_ROUTE = '/__assets/import';

/**
 * The first file a command line writes under `GUARDED`, as far as it can be
 * read: a redirection's file (`> f`, `>> f`, `&> f`), or an operand of a
 * program that writes one (`cp`, `mv`, `tee`, `touch`, `rm`, `mkdir`, `ln`,
 * `chmod`, `dd of=`, `sed -i` …) -- relative to where a `cd` before it went.
 * An operand that is a folder (`.`, `src/`, one that is there) is where `cp`,
 * `mv`, `install`, `rsync`, `ditto` and `ln` put their sources: each source's
 * name there is judged -- every file under a source that is a folder too
 * (`WALK_MAX`) -- so `cp /tmp/assets.local.json .` asks. A path is judged as
 * written and as its real path where it exists (a link into `.claude/` is
 * `.claude/`). A fetch to a route that writes one (`floorRouteOf`) is that write.
 * An expansion is not read. Null for none.
 */
export function guardedWrite(line: string, root: string): Guarded | null {
  /** Where relative paths are, as the `cd`s so far have it; null once one went somewhere that cannot be read. */
  let cwd: string | null = root;
  const realRoot = realish(root);
  const readable = (path: string): boolean => !(/[$`]/.test(path) || path.startsWith('~') || (cwd === null && !isAbsolute(path)));
  const judge = (full: string): Guarded | null => {
    const hit = guarded(full, root);
    if (hit) return hit;
    const real = realish(full);
    return real === full ? null : guarded(real, realRoot);
  };
  const at = (path: string): Guarded | null => (readable(path) ? judge(resolve(cwd ?? root, path)) : null);
  for (const command of commandsOf(line)) {
    const [program = '', ...args] = command.words;
    if (program === 'cd' || program === 'pushd') {
      const to = args.find((a) => !a.startsWith('-'));
      cwd = to === undefined || /[$`~]/.test(to) || cwd === null ? null : resolve(cwd, to);
      continue;
    }
    const route = floorRouteOf(command);
    if (route) return route;
    const paths = [...(command.outs ?? [])];
    const editsInPlace = (program !== 'sed' && program !== 'perl') || args.some((a) => /^-[^-]*i/.test(a) || a.startsWith('--in-place'));
    const operands: string[] = [];
    if (WRITES.has(program) && editsInPlace) {
      for (const a of args) {
        if (a.includes('=')) operands.push(a.slice(a.indexOf('=') + 1));
        else if (!a.startsWith('-')) operands.push(a);
      }
    }
    paths.push(...operands);
    for (const path of paths) {
      const hit = at(path);
      if (hit) return hit;
    }
    if (!INTO_FOLDER.has(program)) continue;
    // A folder among the operands: each other operand lands in it by its name, a folder's files under that name --
    // or, for `rsync` and `ditto` given `src/` (and `ditto` always), its files straight in.
    for (const dir of operands) {
      if (!readable(dir)) continue;
      const full = resolve(cwd ?? root, dir);
      if (!(dir === '.' || dir === '..' || dir.endsWith('/') || isFolder(full))) continue;
      for (const source of operands) {
        if (source === dir || !readable(source)) continue;
        const from = resolve(cwd ?? root, source);
        const contents = program === 'ditto' || (program === 'rsync' && source.endsWith('/'));
        const name = basename(from);
        const landed = contents ? [] : [name];
        if (isFolder(from)) for (const f of filesUnder(from)) landed.push(contents ? f : `${name}/${f}`);
        for (const rel of landed) {
          const hit = judge(join(full, rel));
          if (hit) return hit;
        }
      }
    }
  }
  return null;
}

/** The guarded file a call writes (`GUARDED`): a `Write`, `Edit`, `MultiEdit` or `NotebookEdit`'s file, a command line's (`guardedWrite`); null for none. */
export function guardOf(tool: string, input: Record<string, unknown>, root: string): Guarded | null {
  if (FILE_WRITERS.has(tool)) {
    const file = typeof input.file_path === 'string' && input.file_path !== '' ? input.file_path : input.notebook_path;
    return typeof file === 'string' && file !== '' ? guarded(file, root) : null;
  }
  if ((tool === 'Bash' || tool === 'PowerShell') && typeof input.command === 'string') return guardedWrite(input.command, root);
  return null;
}

/** Why a guarded write asks: the card's reason, and the hook's -- `named`, a path the CLI named (`blockedPath`) rather than one read here. */
/** `a/, b/ or c/`: an English list of the guarded folders, so a new entry in GUARDED never touches the sentence. */
const listOf = (words: readonly string[]): string => (words.length < 2 ? words.join('') : `${words.slice(0, -1).join(', ')} or ${words.at(-1)}`);

export const guardReason = (g: Guarded, named = false): string =>
  g.dir === LOCAL_FILES
    ? `${named ? 'Claude Code asks about' : g.route !== undefined ? `It calls the dev server's ${g.route} route, which writes` : 'It writes'} ${g.rel}: this machine's own settings (a *.local.json or *.local file: tool paths, keys) are never written unasked -- a tool's path set there is a program the next export runs.`
    : `${named ? 'Claude Code asks about' : g.route !== undefined ? `It calls the dev server's ${g.route} route, which writes under` : 'It writes'} ${g.rel}: nothing under ${listOf(GUARDED.map((d) => `${d}/`))} is written unasked -- git's own store, which no snapshot has, and Claude Code's settings.`;

/** Where a guarded write goes, in a few words: `under .claude/`, `to this machine's settings`. */
export const guardPlace = (g: Guarded): string => (g.dir === LOCAL_FILES ? `to this machine's settings` : `under ${g.dir}/`);

/** What the agent is told when a guarded write is denied: not to route round it. */
export const guardDeclined = (g: Guarded): string =>
  `The user declined writing ${guardPlace(g)} (${g.rel}): do not write there another way -- no other tool, redirect, command or script. Say what you would have written there, and let them do it.`;

/**
 * Is a path the CLI names (`blockedPath`) one Auto's own rules decide? The
 * CLI names every folder an `rm -r` removes and every file a `>` or `>>`
 * writes, inside the project too (checked, CLI 2.1.289): there Auto's rules
 * have already decided -- `rm -r dist/x` and `echo x > notes.txt` go by, as an
 * Edit would, `rm -r src` is a card -- but under `GUARDED`, which is always a
 * card. A path outside the project stays the CLI's to ask about.
 */
export function autoDecides(blocked: string, root: string): boolean {
  return inside(root, blocked) && guarded(blocked, root) === null;
}

/** The host's rule that names this call, if one does: never for git that only reads. */
export const hostRule = (tool: string, input: Record<string, unknown>, root: string): string | undefined => HOST_ASK.find((r) => ruleMatches(r, tool, input, root, (c) => gitReads(c, root)));

/** Why the host's own rule asks. */
export const hostReason = (rule: string): string => `The editor asks before this (${rule}): it can wipe work that is not committed.`;

/** A glob as a regex: `**` any folders, `*` within one, `?` one character. */
function globRegex(glob: string): string {
  let out = '';
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i]!;
    if (c === '*' && glob[i + 1] === '*') {
      out += '.*';
      i++;
      if (glob[i + 1] === '/') i++;
    } else if (c === '*') out += '[^/]*';
    else if (c === '?') out += '[^/]';
    else out += c.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  }
  return out;
}

/** A Bash rule's content as a test of one command, as written or as run: `prefix:*`, a glob, or the command exactly. */
function bashRule(content: string): (command: Command) => boolean {
  const rule = content.trim().replace(/\s+/g, ' ');
  const glob = rule.includes('*') && !rule.endsWith(':*') ? new RegExp(`^${globRegex(rule).replace(/\[\^\/\]\*/g, '.*')}$`) : null;
  const test = (text: string): boolean => {
    const part = text.trim().replace(/\s+/g, ' ');
    if (rule.endsWith(':*')) {
      const prefix = rule.slice(0, -2).trim();
      return part === prefix || part.startsWith(`${prefix} `);
    }
    return glob ? glob.test(part) : part === rule;
  };
  return (command) => test(command.run) || test(command.written);
}

/** Does a path rule (gitignore's way) name this file? `//abs`, `~/home`, `/under the project`, else anywhere under it. */
function pathMatches(content: string, file: string, root: string): boolean {
  // The rule's patterns are written with `/`: the path and the root too, on Windows as anywhere.
  const base = slashed(root);
  const abs = slashed(isAbsolute(file) ? file : join(root, file));
  let pattern = content.trim();
  if (pattern.startsWith('//')) pattern = pattern.slice(1);
  else if (pattern.startsWith('~/')) pattern = posix.join(slashed(homedir()), pattern.slice(2));
  else if (pattern.startsWith('/')) pattern = posix.join(base, pattern);
  else pattern = posix.join(base, pattern.includes('/') ? pattern.replace(/^\.\//, '') : `**/${pattern}`);
  return new RegExp(`^${globRegex(pattern.replace(/\/$/, ''))}(?:/.*)?$`).test(abs);
}

/**
 * Does `rule` name this call? Over-matching only costs a card. A Bash rule
 * names a line when it names any command in it (`commandsOf`), but none that
 * `spare` lets by.
 */
export function ruleMatches(rule: string, tool: string, input: Record<string, unknown>, root: string, spare?: (command: Command) => boolean): boolean {
  const { tool: ruleTool, content } = parseRule(rule);
  const sameTool = ruleTool === tool || (ruleTool.startsWith('mcp__') && tool.startsWith(`${ruleTool.replace(/__\*$/, '')}__`));
  if (!sameTool) return false;
  if (content === null || content === '' || content === '*') return true;
  const str = (key: string): string => (typeof input[key] === 'string' ? (input[key] as string) : '');
  switch (tool) {
    case 'Bash':
    case 'PowerShell': {
      const names = bashRule(content);
      return commandsOf(str('command')).some((c) => !(spare?.(c) ?? false) && names(c));
    }
    case 'Edit':
    case 'MultiEdit':
    case 'Write':
    case 'Read':
    case 'NotebookEdit': {
      const file = str('file_path') || str('notebook_path');
      return file !== '' && pathMatches(content, file, root);
    }
    case 'WebFetch': {
      if (!content.startsWith('domain:')) return false;
      try {
        const host = new URL(str('url')).hostname;
        const domain = content.slice('domain:'.length);
        return host === domain || host.endsWith(`.${domain}`);
      } catch {
        return false;
      }
    }
    case 'Agent':
    case 'Task':
      return str('subagent_type') === content;
    case 'Skill':
      return str('skill') === content || str('command') === content;
    default:
      return false;
  }
}

// ---------------------------------------------------------------- cards

/** The card's line, when the SDK gives no `title`. */
export function titleFor(tool: string, input: Record<string, unknown>, displayName?: string): string {
  const file = (input.file_path ?? input.notebook_path) as unknown;
  const name = typeof file === 'string' && file !== '' ? basename(file) : undefined;
  switch (tool) {
    case 'Edit':
    case 'MultiEdit':
    case 'NotebookEdit':
      return `Claude wants to edit ${name ?? 'a file'}`;
    case 'Write':
      return `Claude wants to write ${name ?? 'a file'}`;
    case 'Read':
      return `Claude wants to read ${name ?? 'a file'}`;
    case 'Bash':
      return `Claude wants to run ${typeof input.command === 'string' ? clip(input.command, 80) : 'a command'}`;
    case 'WebFetch':
      try {
        return `Claude wants to fetch ${new URL(String(input.url)).hostname}`;
      } catch {
        return 'Claude wants to fetch a page';
      }
    default:
      // The editor's own tools (§8): the tool's name; its line, the input's summary, is the card's detail.
      if (tool.startsWith(STUDIO_TOOLS)) return `Claude wants to use the studio's ${tool.slice(STUDIO_TOOLS.length)}`;
      return `Claude wants to use ${displayName ?? tool}`;
  }
}

/** The suggestions an Always may keep: rules and folders, never a mode, never the CLI's own flag layer. */
export function keptSuggestions(suggestions: readonly PermissionUpdate[] | undefined): PermissionUpdate[] {
  return (suggestions ?? []).filter((s) => s.type !== 'setMode' && s.destination !== 'cliArg');
}

/** The suggestions kept at `destination`. */
export function retarget(suggestions: readonly PermissionUpdate[], destination: AlwaysDestination): PermissionUpdate[] {
  return suggestions.map((s) => ({ ...s, destination }));
}

/** Always's menu: one item per destination, the suggested rules its tooltip; none with nothing to keep. */
export function alwaysChoices(suggestions: readonly PermissionUpdate[] | undefined): AlwaysChoice[] {
  const kept = keptSuggestions(suggestions);
  if (kept.length === 0) return [];
  const rules = kept.flatMap((s) => {
    if (s.type === 'addRules' || s.type === 'replaceRules' || s.type === 'removeRules') return s.rules.map(ruleText);
    if (s.type === 'addDirectories' || s.type === 'removeDirectories') return s.directories.map((d) => `the folder ${d}`);
    return [];
  });
  return DESTINATIONS.map(({ destination, label, more }) => ({ destination, label, rules, more }));
}

/** An `AskUserQuestion` input's questions, as the card shows them. */
export function questionsOf(input: Record<string, unknown>): Question[] {
  const raw = Array.isArray(input.questions) ? input.questions : [];
  return raw.flatMap((q): Question[] => {
    if (typeof q !== 'object' || q === null) return [];
    const r = q as Record<string, unknown>;
    if (typeof r.question !== 'string') return [];
    const options = (Array.isArray(r.options) ? r.options : []).flatMap((o) => {
      const opt = typeof o === 'object' && o !== null ? (o as Record<string, unknown>) : {};
      return typeof opt.label === 'string' ? [{ label: opt.label, description: typeof opt.description === 'string' ? opt.description : '' }] : [];
    });
    return [{ question: r.question, header: typeof r.header === 'string' ? r.header : '', options, multiSelect: r.multiSelect === true }];
  });
}

/** A question card's answers as the tool takes them: question to label, several joined by ", ". */
export function answersFor(questions: readonly Question[], answers: Record<string, string | string[]>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const q of questions) {
    const a = answers[q.question];
    const text = Array.isArray(a) ? a.filter((s) => s.trim() !== '').join(', ') : (a ?? '').trim();
    if (text !== '') out[q.question] = text;
  }
  return out;
}

/** A path's real one, every link followed; null where nothing is (a studio tool's `asksWhen`). */
function realOrNull(path: string): string | null {
  try {
    return realpathSync.native(path);
  } catch {
    return null;
  }
}

const DECLINED = 'The user declined this tool call.';
const STOPPED = 'The user stopped the turn before answering.';
const SKIPPED = 'The user chose not to answer.';

/**
 * The words a tool refused for the turn is answered with (`TurnRequest.deny`): the Git card's draft is an answer
 * in words, so its `Edit` and `Write` are "not in this turn" -- whatever a rule or Auto would allow.
 */
export const notInTurn = (tool: string): string =>
  `${tool} is not in this turn: the person asked for an answer in words alone, with no file changed. Answer without it.`;

/** The session's `canUseTool`. */
export function createCanUseTool(context: PermissionContext): CanUseTool {
  return async (tool, input, options): Promise<PermissionResult> => {
    // A tool refused for this turn's length: before any card, rule or Auto.
    const refused = context.denied?.(tool) ?? null;
    if (refused !== null) return { behavior: 'deny', message: refused };
    const sub = options.agentID !== undefined;
    if (tool === 'AskUserQuestion') {
      const questions = questionsOf(input);
      const answer = await context.open({ kind: 'question', id: context.newId(), questions, sub }, options.signal);
      if (answer.outcome === 'answered') {
        const answers = answersFor(questions, answer.answers);
        if (Object.keys(answers).length > 0) return { behavior: 'allow', updatedInput: { ...input, answers }, decisionClassification: 'user_temporary' };
      }
      return { behavior: 'deny', message: answer.outcome === 'stopped' ? STOPPED : SKIPPED, decisionClassification: 'user_reject' };
    }
    const level = context.level();
    const auto = level !== 'ask';
    const unsafe = level === 'unsafe';
    /** The level's name on a card that still asks under it. */
    const levelName = unsafe ? 'Unsafe auto' : 'Auto';
    const matched = options.matchedAskRule;
    // A studio tool (Docs/mcp.md §2 rule 8): judged by its annotations -- a read never asks; a write follows the level;
    // a destructive one asks under Ask and Auto, and goes by under Unsafe auto. The person's own ask rules still ask.
    const studio = tool.startsWith(STUDIO_TOOLS) ? (context.metaOf ?? metaOf)(tool) : undefined;
    if (studio) {
      const place = { root: context.root, real: realOrNull, written: context.written?.() ?? [] };
      const kind = callKind(studio, input, place);
      let mine: string | undefined;
      let unread = false;
      if (matched && !/flag|cli/i.test(matched.source)) mine = ruleText({ toolName: matched.toolName, ruleContent: matched.ruleContent }) ?? undefined;
      try {
        mine ??= (await context.askRules()).find((r) => ruleMatches(r, tool, input, context.root));
      } catch {
        unread = true;
      }
      // Out of the project, by its input (`asksWhen`: asset_import reading a file elsewhere): asks at every level --
      // Unsafe auto's floor.
      const outside = kind === 'read' ? null : (studio.asksWhen?.(input, place) ?? null);
      const goes = outside === null && (kind === 'read' || (kind === 'write' && auto) || (kind === 'destructive' && unsafe));
      if (goes && mine === undefined && !unread) return { behavior: 'allow', updatedInput: input };
      const what = mine !== undefined ? `your ask rule ${mine}` : unread ? 'your settings could not be read' : outside !== null ? `${studio.name} outside the project (${outside})` : kind === 'destructive' ? `a destructive tool (${studio.name})` : null;
      const card: Card = {
        kind: 'permission',
        id: context.newId(),
        tool,
        title: titleFor(tool, input),
        description: options.description ?? null,
        reason: mine !== undefined ? `Your ask rule ${mine} names it.` : unread ? `Your settings could not be read, so ${levelName} asks.` : outside !== null ? `${studio.name}: ${outside} -- anything outside the project asks, at every level.` : kind === 'destructive' ? `${studio.name} is destructive: it asks unless the level is Unsafe auto.` : null,
        detail: summarise(tool, input, context.root),
        sub,
        use: options.toolUseID,
        always: mine !== undefined || kind === 'destructive' || outside !== null ? [] : alwaysChoices(options.suggestions),
        ...(auto && what !== null ? { auto: `${levelName} still asks: ${what}` } : {}),
      };
      const answer = await context.open(card, options.signal);
      if (answer.outcome === 'allowed') return { behavior: 'allow', updatedInput: input, decisionClassification: 'user_temporary' };
      if (answer.outcome === 'always') return { behavior: 'allow', updatedInput: input, updatedPermissions: retarget(keptSuggestions(options.suggestions), answer.destination), decisionClassification: 'user_permanent' };
      return { behavior: 'deny', message: answer.outcome === 'stopped' ? STOPPED : DECLINED, decisionClassification: 'user_reject' };
    }
    // A write under .git/ or .claude/ first: a card, Auto or not -- the hook asked it past any allow -- with no Always.
    const blocked = options.blockedPath;
    const read = guardOf(tool, input, context.root);
    const guard = read ?? (blocked !== undefined ? guarded(blocked, context.root) : null);
    const line = (tool === 'Bash' || tool === 'PowerShell') && typeof input.command === 'string' ? input.command : null;
    /** What Auto's allowances need beyond the line: the engine's folder, whether the shell may be away, the remotes. */
    const port = context.port?.();
    const at: At = { engine: context.engine ?? false, away: context.shell?.away() ?? false, remotes: context.remotes ?? [], engineRemotes: context.engineRemotes ?? [], ...(port !== undefined ? { port } : {}) };
    /** A line let run: where it leaves the shell (`ShellPlace`). */
    const ran = (): void => {
      if (line !== null) context.shell?.ran(line, context.root, input.run_in_background === true, options.toolUseID);
    };
    let reason: string | null = guard !== null ? guardReason(guard, read === null) : null;
    /** What made it a card, in a few words: the "Auto still asks" line. */
    let what: string | null = guard !== null ? `a write ${guardPlace(guard)} (${guard.rel})` : null;
    // Then a rule's: the SDK's match, the host's rules (under Auto, sparing the deletions Auto's own line lets by), the user's.
    // The host's own rule, which the CLI now names too (`matchedAskRule` from the flag layer, CLI 2.1.x): decided
    // here as `hostAsk` decides it, so Auto spares what its own line lets by (`rm -rf dist`) whoever names the rule.
    const named = matched ? ruleText({ toolName: matched.toolName, ruleContent: matched.ruleContent }) : null;
    const hostNamed = matched !== undefined && named !== null && /flag|cli/i.test(matched.source) && HOST_ASK.includes(named);
    if (reason === null && matched && named !== null && !hostNamed) {
      const host = /flag|cli/i.test(matched.source);
      reason = host ? hostReason(named) : `Your ask rule ${named} names it.`;
      what = host ? hostWhat(named, input) : `your ask rule ${named}`;
    } else if (reason === null) {
      const host = await hostAsk(tool, input, context.root, auto, context.ignored, at, unsafe);
      if (host !== undefined) {
        reason = hostReason(host);
        what = hostWhat(host, input);
      }
    }
    let unread = false;
    if (reason === null) {
      try {
        const mine = (await context.askRules()).find((r) => ruleMatches(r, tool, input, context.root));
        if (mine !== undefined) {
          reason = `Your ask rule ${mine} names it.`;
          what = `your ask rule ${mine}`;
        }
      } catch {
        // The rules unreadable: the card is the safe side.
        unread = true;
      }
    }
    const ruled = reason !== null;
    // Auto's own line: a git command that does more than read, a deletion it can read, a line too deep to read --
    // Unsafe auto's: its floor alone (`unsafeAsksWhy`).
    const why = auto && !ruled && line !== null ? (unsafe ? unsafeAsksWhy(line, context.root, at) : await autoAsksWhy(line, context.root, context.ignored, at)) : null;
    const asks = why?.reason ?? null;
    // A read through a link in the project -- the engine's checkout under node_modules/@vibe/ in source mode --
    // which the CLI names by its real path, outside: Auto lets it by as it would a read in the project; a line, only a plain one.
    const linkedRead = blocked !== undefined && !inside(context.root, blocked) && readsOnly(tool, input) && (line === null || withheld(line, context.root, at) === null) && underLinked(blocked, context.linked?.() ?? []);
    // The CLI names a path inside the project too -- an `rm -r`'s folder, a `> file`'s file: Auto's own rules have decided those.
    if (auto && !ruled && !unread && asks === null && (blocked === undefined || autoDecides(blocked, context.root) || linkedRead)) {
      ran();
      return { behavior: 'allow', updatedInput: input };
    }
    reason ??=
      asks ??
      (blocked !== undefined
        ? inside(context.root, blocked)
          ? `Claude Code asks about ${projectRel(context.root, blocked)}.`
          : `${blocked} is outside the folders allowed here.`
        : unread
          ? 'Your settings could not be read, so Auto asks.'
          : (options.decisionReason ?? null));
    what ??=
      why?.what ??
      (blocked !== undefined
        ? inside(context.root, blocked)
          ? `Claude Code's own check of ${projectRel(context.root, blocked)}`
          : `outside the project: ${blocked}`
        : unread
          ? 'your settings could not be read'
          : null);
    const card: Card = {
      kind: 'permission',
      id: context.newId(),
      tool,
      title: options.title ?? titleFor(tool, input, options.displayName),
      description: options.description ?? null,
      reason,
      detail: summarise(tool, input, context.root),
      sub,
      use: options.toolUseID,
      // An ask rule outranks an allow, and the hook asks Auto's own line before any allow: an Always for either would keep nothing.
      // A guarded write's Always would keep the folder itself allowed: the guard off for good, one click away.
      always: ruled || asks !== null ? [] : alwaysChoices(options.suggestions),
      // Auto on, and still a card: which rule made it, so the person knows it is not Auto being broken.
      ...(auto && what !== null ? { auto: `${levelName} still asks: ${what}` } : {}),
    };
    const answer = await context.open(card, options.signal);
    if (answer.outcome === 'allowed' || answer.outcome === 'always') ran();
    switch (answer.outcome) {
      case 'allowed':
        return { behavior: 'allow', updatedInput: input, decisionClassification: 'user_temporary' };
      case 'always':
        return { behavior: 'allow', updatedInput: input, updatedPermissions: retarget(keptSuggestions(options.suggestions), answer.destination), decisionClassification: 'user_permanent' };
      case 'stopped':
        return { behavior: 'deny', message: STOPPED, decisionClassification: 'user_reject' };
      default:
        // A guarded write denied: the agent told not to route round it (it did, with a Write after a redirect was denied).
        return { behavior: 'deny', message: guard !== null ? guardDeclined(guard) : DECLINED, decisionClassification: 'user_reject' };
    }
  };
}
