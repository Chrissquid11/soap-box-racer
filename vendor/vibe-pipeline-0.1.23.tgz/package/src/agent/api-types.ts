/**
 * The shapes the dev server's agent (`packages/pipeline/src/agent/`) and the editor's prompt
 * panel (`packages/editor/src/agent/`, phase 2) share (Docs/agent.md §2, §4, §5, §8):
 * the log's entries, the state, a turn's context, the cards, the editor
 * tools' calls relayed to a tab and its answers, and what each call under
 * `/__agent/` takes and answers. Types only.
 *
 * Pure: it imports nothing but the studio tools' catalogue's names, as a type
 * (`../mcp/catalog.ts`, which imports nothing), so the browser side imports it
 * too -- as types (the sandbox's `imports.test.ts` holds it to that).
 *
 * The server owns everything here: the settings, the models, the bar table,
 * the cards. The page draws what it is sent and words nothing about a turn --
 * `TurnContext` is facts, which `turn.ts` alone puts into words.
 */

import type { DENY_WRITERS, PageToolName, ToolName } from '../mcp/catalog.ts';

/** The push channel's event: `{ entry }`, `{ state }`, `{ delta }` or `{ mcp }`, to loopback tabs only. */
export type AgentEvent = 'vibebase:agent';

/**
 * The page's hello on the same socket (`import.meta.hot.send`), `{ tab }`: which
 * tab this socket is, so an editor tool's call reaches the tab whose turn it is
 * (Docs/agent.md §8). Said as the card is made and on every reconnect.
 */
export type HelloEvent = 'vibebase:agent:hello';

/** A page's keys and size for a conversation's terminal (Docs/terminal.md D3): `{ conversation, data }` or `{ conversation, cols, rows }`. */
export type TerminalEvent = 'vibebase:agent:terminal';

/** The hello's data: the tab's id, kept in its `sessionStorage` -- the same across a reload. */
export interface Hello {
  tab: string;
  /** The project's own MCP tools, as its `src/tools/` declares them (Docs/mcp.md M7): what the dev server registers. */
  tools?: ProjectToolDecl[];
  /**
   * The page knows conversations, plural: it is pushed every conversation's
   * messages and the list. A page from before them -- not saying so -- is
   * pushed the first conversation's alone, which it takes for its one.
   */
  multi?: boolean;
}

// ---------------------------------------------------------------- the conversations

/**
 * One open conversation, as the card's tab row shows it: its id (what every
 * route that acts on a conversation takes, `?conversation=`), its title, and
 * what its tab says of it.
 */
export interface ConversationInfo {
  id: string;
  /** From the first prompt ("New conversation" before), or as the person renamed it. */
  title: string;
  /** A turn of it in flight. */
  running: boolean;
  /** A permission or question card of it waiting for the person: "needs you". */
  waiting: boolean;
  /** The `seq` of its last `result` entry (0: none): a tab not shown since it moved has a turn finished unseen. */
  ended: number;
  /** Its last turn ended in an error: the column's last result's `how` -- in the terminal, once a turn ended there, that turn's (`TerminalState.failed`). Absent: not. */
  failed?: true;
  /** In the terminal: a turn there running or asking (`TerminalState.turn`), as the run's hooks tell it. */
  terminalTurn?: 'running' | 'waiting';
  /** In the terminal: when a turn there last ended (`TerminalState.ended`, ms); absent, none. */
  terminalEnded?: number;
}

// ---------------------------------------------------------------- settings

/** A quality bar's name (§3): `none` is no review. */
export type ReviewBar = 'none' | 'ok' | 'good' | 'very-good' | 'excellent' | 'perfect';

/** A row of the bar table: what the picker shows, the score a review must reach (`null` for none). */
export interface BarChoice {
  value: ReviewBar;
  label: string;
  score: number | null;
}

/**
 * The server's settings, kept with the conversation (`.cache/agent/<port>/<conversation>/session.json`),
 * changed only by `POST settings`: two tabs and a restart agree.
 */
export interface AgentSettings {
  /** A model's `value` from `models`; null is the CLI's own ("Default"). */
  model: string | null;
  /** One of the model's effort levels; null is the CLI's own. */
  effort: string | null;
  review: ReviewBar;
  /**
   * The permission level (§2, Permissions; Docs/mcp.md §7 D3): `ask`, every call a card; `auto`, every call no rule of
   * the user's asks about goes by, but Auto's still-asks and the studio's destructive tools; `unsafe`, Auto plus those,
   * above a floor that always asks. Auto by default. The person's alone: no tool sets it.
   */
  level: PermissionLevel;
  /**
   * Studio mode's recovery (Docs/studio.md §1, "Claude tries first"): a failed boot's error is sent to Claude in a
   * conversation titled Recovery, to fix -- three tries, then it is the person's. On by default. The project's, not
   * a conversation's: kept on the conversations' index, every conversation's state saying the one value, and
   * `POST settings { fixBoot }` sets it whichever conversation it names.
   */
  fixBoot: boolean;
  /**
   * What an outside client may do through the dev server's `/__mcp` endpoint (Docs/mcp.md M7): `off`, nothing; `read`,
   * the reads alone (the default); `write`, the writes too; `destructive`, the destructive tools too. The project's, as
   * `fixBoot` is: kept on the conversations' index, every conversation's state saying it.
   */
  outside: OutsideLevel;
}

/** A project's own MCP tool as the dev server is told it (Docs/mcp.md M7, Docs/packages.md §10): Claude calls it `project_<name>`. */
export type ProjectToolName = `project_${string}`;

/** What Claude calls a project's own tool before its name (`project_tiles_paint`): the server's and the page's one spelling. */
export const PROJECT_PREFIX = 'project_';

/**
 * A project's own MCP tool, declared in its `src/tools/` (`mcpTools`) and said in the studio tab's hello: what the
 * dev server registers beside the built-ins as `project_<name>`, relayed to the tab and run there by its `run`.
 */
export interface ProjectToolDecl {
  /** `<area>_<verb>`, lowercase: `tiles_paint`. Claude calls it `project_tiles_paint`. */
  name: string;
  /** What it does, for Claude: what a person does with it, its arguments, what it answers, that it is one step Z undoes. */
  description: string;
  /** Its input, as JSON Schema -- an object's (`{ type: 'object', properties, required }`): no zod, so a project needs no dependency. */
  input: Record<string, unknown>;
  /** MCP's hints, as the gate reads them: `readOnly` never asks; `destructive` asks under Auto. Neither: a write. */
  annotations?: { readOnly?: boolean; destructive?: boolean; idempotent?: boolean };
}

/** What a project tool's call came to in the tab: its words and JSON, and the world step its edits made (null: none). */
export interface ProjectToolResult {
  tool: 'project';
  name: string;
  words: string;
  json: unknown;
  step: string | null;
}

/** What outside clients of `/__mcp` may do (Config ▸ Claude ▸ Settings, "Outside clients"): the endpoint's one switch. */
export type OutsideLevel = 'off' | 'read' | 'write' | 'destructive';

/** The three permission levels, the prompt box's pick: Ask, Auto, Unsafe auto. */
export type PermissionLevel = 'ask' | 'auto' | 'unsafe';

/** A model as the picker shows it (D108): what the CLI reports, with its effort levels (none: no effort picker). */
export interface ModelChoice {
  value: string;
  label: string;
  efforts: string[];
}

// ---------------------------------------------------------------- the state

/** Who Claude Code is logged in as, from `initializationResult().account`. */
export interface AccountState {
  /** False: neither an email nor a plan from the first-party provider (an API key alone lands here, by design). */
  loggedIn: boolean;
  email: string | null;
  subscription: string | null;
  /** `firstParty`, or a third-party provider, which logs in its own way. */
  provider: string | null;
}

/** The turn in flight: the person's, or one Claude Code started itself. */
export interface RunningState {
  /**
   * `person`: sent from a page. `cli`: Claude Code went on by itself -- a
   * background task it started told it something after the turn ended -- held,
   * timed and stoppable like any other, ended by its own result.
   */
  origin: 'person' | 'cli';
  /** Its user message's uuid: what its `result` and `POST rewind` name. */
  turn: string;
  /** `Date.now()` when it was sent: the head's clock, which survives a reload. */
  startedAt: number;
  /** The bar it was sent with (D110): a later change to the picker does not reach it. */
  bar: number | null;
  /** Stop was pressed: Send and Clear wait for its result. */
  stopping: boolean;
  /**
   * D110 (Docs/modeler.md): the Gladius scripts the turn wrote are being built
   * now that it says it is done (`checking`), or one did not build and the turn
   * was sent back to fix it -- `attempt` of `of`. The clock runs on; Send waits.
   */
  fixing?: { attempt: number; of: number; checking: boolean };
  /** Reviews launched so far, and the last score read (§3): "Review 2/5 · last 6/10 · bar 7/10". */
  round: number;
  last: number | null;
}

/** Whether Review can run, the bar table and `MAX_REVIEWS` -- one table, the server's. */
export interface ReviewState {
  available: boolean;
  /** Why not: "the critic did not load: .claude/agents/code-critic.md". */
  why: string | null;
  bars: BarChoice[];
  max: number;
}

/**
 * The whole state, unsequenced: pushed whole whenever it changes, and with
 * every `GET state`.
 */
export interface AgentState {
  /** New per dev-server process: a page tells a restart from a gap in `seq`. */
  epoch: string;
  /** False: the SDK will not import, or this is not the machine running the dev server. */
  available: boolean;
  why: string | null;
  /** The conversation's CLI: none yet (the first attach starts it), starting, up, or failed to start. */
  session: 'off' | 'starting' | 'up' | 'failed';
  account: AccountState | null;
  /** Not logged in: what the card says, and what to do -- the server's words, said once. */
  login: { text: string; next: string } | null;
  /** Empty until the session is up: the pickers read "Default". */
  models: ModelChoice[];
  settings: AgentSettings;
  review: ReviewState;
  running: RunningState | null;
  /** The cards waiting for an answer, oldest first. */
  pending: Card[];
  /** Code changed during the turn, its reload held until the turn ends (§2, Code held for a turn). */
  held: string[];
  /** The API is being retried: "Retrying (2/10)…". */
  retrying: { attempt: number; of: number } | null;
  /** The context window used after the last turn, in percent. */
  context: number | null;
  /** Skills the CLI reported for this conversation, once it has started a turn. */
  skills: string[] | null;
  /**
   * What `/usage` shows (Docs/agent.md §2, "Usage"): the plan's limits as last heard, this conversation's cost and
   * tokens, the context window. Kept in `session.json`. Absent from a server before it.
   */
  usage?: UsageFacts;
  /**
   * The subagents and background tasks of the turn running, or of the last one, until the next begins -- and any
   * still running from before (Docs/agent.md §2, "Subagents"). Kept in `session.json`. Absent from a server before it.
   */
  agents?: AgentRow[];
  /** The CLI's slash commands -- its own, the project's and the skills -- once it is up (`initializationResult().commands`, `commands_changed`). Absent from a server before it. */
  commands?: CommandRow[];
  /**
   * The conversation continued in a terminal (Docs/terminal.md D1): the column's query closed, the `claude` CLI its owner
   * until Back to the column. Null or absent: the column's. Kept in `session.json`.
   */
  terminal?: TerminalState | null;
}

/** Asked of a conversation in the terminal (Docs/terminal.md D1): it is the CLI's until Back to the column. */
export const AWAY = 'This conversation is in the terminal: Back to the column first';

/** Where a conversation went on (`AgentState.terminal`, Docs/terminal.md D1, D5). */
export interface TerminalState {
  /** In the column's own terminal (xterm over a PTY of the dev server's), or the person's own: the command copied, or run in Terminal.app (the app's). */
  where: 'column' | 'own';
  /** When it was handed over, as `Date.now()`. */
  since: number;
  /** The session the CLI resumes: the column's own id, or one made for a conversation never sent. */
  sessionId: string;
  /** The session's messages when it was handed over: the terminal's turns are those after (D10). */
  before: number;
  /** The command line, to copy (`cd <project> && claude --resume …`). */
  command: string;
  /** The dev server's port the run was written under: its folder (`.cache/agent/<port>/…/terminal/`) and its URLs. */
  port: number;
  /**
   * The column's terminal: its CLI running now. False: it ended (the dev server restarted under it) -- the column started
   * again with this conversation shown opens it again by itself (Docs/terminal.md D12), Back takes it back.
   */
  live: boolean;
  /**
   * A turn there, as the run's hooks tell it (Docs/ai-panel.md §8): `running` from its prompt (`UserPromptSubmit`) to its
   * end, `waiting` while the CLI asks the person (a `Notification` of a permission prompt or a question) -- until a key is
   * typed into the column's terminal, or the turn ends. None: no turn known to run. Not kept across a restart.
   */
  turn?: 'running' | 'waiting';
  /** What `waiting` waits on: a permission prompt, or a question (an MCP elicitation) -- Esc declines the first and ends the turn, answers the second and the turn goes on. */
  asking?: 'permission' | 'question';
  /** When `turn` was last told, as `Date.now()`: one told nothing of for `TURN_STALE_MS` is no longer shown (a turn whose end no hook said). */
  turnAt?: number;
  /** Opened again by itself after a restart, tried by this dev server process already (D12): not tried again until it restarts. Not kept. */
  tried?: true;
  /** When a turn there last ended (`Stop` or `StopFailure`), as `Date.now()`; 0 or none, none yet. Kept. */
  ended?: number;
  /** That turn ended in an error (`StopFailure`: the API's, a limit, the network). */
  failed?: boolean;
}

/**
 * What a terminal run's hooks tell (`POST terminal/turn`, Docs/ai-panel.md §8): a prompt sent, its end, its failure, the
 * CLI asking (`asks` a permission prompt, `question` an MCP elicitation); `answered`, a key typed while it asked; `alive`,
 * the column's terminal writing while a turn runs (a long turn kept shown); `quiet`, a turn over with no end to mark -- Esc alone in the
 * column's terminal (an interrupt, a permission declined), or the CLI idle at its prompt (`Notification`'s `idle_prompt`).
 */
export type TerminalTurnEvent = 'prompt' | 'stop' | 'failed' | 'asks' | 'question' | 'answered' | 'quiet' | 'alive';

/**
 * A terminal turn told nothing of for this long is no longer shown running or waiting (Docs/ai-panel.md §8): an end no
 * hook says -- a turn interrupted, a permission declined, the CLI quit in the person's own terminal.
 */
export const TURN_STALE_MS = 30 * 60_000;

/** A turn made in the terminal, as Back reads it from the session (D10): the person's words, Claude's text, its tool calls counted. */
export interface TerminalTurn {
  prompt: string;
  text: string;
  tools: number;
}

/** A terminal's push (`ConversationMessage`): output to draw, or its CLI ended. */
export interface TerminalPush {
  /** Output, as the PTY wrote it (UTF-8). */
  data?: string;
  /** Where `data` begins in all the run's output, in characters: a page drawing the screen kept (`TerminalAnswer.end`) skips what it has. */
  at?: number;
  /** The CLI ended: its exit code (null: by a signal). */
  exited?: number | null;
}

/** `POST terminal/open`: where; the page's secret (the hello's) -- a program is started, the person's control alone. */
export interface TerminalOpenRequest {
  where: 'column' | 'own';
  secret?: string;
  /** The terminal's size, in cells. */
  cols?: number;
  rows?: number;
}

/** `POST terminal/close`: `force`, Back though the session was written in the last seconds (Terminal.app's, D5). */
export interface TerminalCloseRequest {
  force?: boolean;
  /** The page's secret (the hello's): ending the CLI is the person's, as starting it. */
  secret?: string;
}

/** `GET terminal`, and the answers of open and close: the state, the screen kept (column), the `.command` to open (app). */
export interface TerminalAnswer {
  state: AgentState;
  /** The last output kept, to draw again after a reload. */
  screen?: string;
  /** Where `screen` ends in all the run's output, in characters (`TerminalPush.at`). */
  end?: number;
  /** The run's `resume.command`, relative to the project (`where: 'own'`): what the app opens in Terminal.app. */
  file?: string;
}

/**
 * The tools that start a subagent: `Agent`, and `Task` as older CLIs name it. One list for the server's tracker
 * (`agents.ts`) and the page's transcript, which folds a subagent's steps under such a call -- a value the editor
 * imports, as `SKILL_NAME` is.
 */
export const AGENT_TOOLS: ReadonlySet<string> = new Set(['Agent', 'Task']);

/** A slash command the CLI takes as a prompt (`SlashCommand`): its name without the slash, what it does, its argument's hint. */
export interface CommandRow {
  name: string;
  description: string;
  /** "<file>", or '' for one that takes nothing. */
  hint: string;
  aliases?: string[];
}

/**
 * One limit of the plan, as last heard: a `rate_limit_event` (`from: 'event'`), or the CLI's own usage call
 * (`from: 'usage'`, what Claude Code's `/usage` reads). `kind` is the SDK's `rateLimitType` -- `five_hour`,
 * `seven_day`, `seven_day_opus`, `seven_day_sonnet`, `seven_day_overage_included`, `overage` -- or `model:<name>` for
 * a per-model weekly window.
 */
export interface UsageLimit {
  kind: string;
  /** "Session (5 hours)", "Week, all models", "Week, Opus" … */
  label: string;
  /** Percent of it used, 0-100; null: not said. */
  used: number | null;
  /** When it resets, as `Date.now()`; null: not said. */
  resets: number | null;
  /** The event's status; null: the usage call's, which says none. */
  status: 'allowed' | 'allowed_warning' | 'rejected' | null;
  /** When it was heard, as `Date.now()`. */
  at: number;
  from: 'event' | 'usage';
}

/** What `/usage` shows. Every part null until heard: said "not known yet", never guessed. */
export interface UsageFacts {
  limits: UsageLimit[];
  /** Plan limits apply (`rate_limits_available`): false for an API key, Bedrock, Vertex; null, not known. */
  plan: boolean | null;
  /** The plan's name ('max', 'pro' …), as the usage call or the account says. */
  subscription: string | null;
  /** The CLI's running total for this conversation at API prices (`total_cost_usd`), at its last result or usage call. */
  cost: number | null;
  /** This conversation's tokens so far, every model's together (`modelUsage`). */
  tokens: { input: number; output: number; cacheRead: number; cacheWrite: number } | null;
  /** The context window after the last turn (`getContextUsage()`). */
  context: { used: number; max: number; percent: number } | null;
  /** When any of it was last heard, as `Date.now()`. */
  at: number | null;
}

/**
 * A subagent (an `Agent` or `Task` call) or a background task (a shell, a monitor) a turn started, as the stream told
 * it (`agents.ts`): its call, its child messages (`parent_tool_use_id`), the `task_*` system messages.
 */
export interface AgentRow {
  /** The `Agent` call's `tool_use` id; a task with none, its task id. */
  id: string;
  kind: 'agent' | 'shell' | 'task';
  /** The `subagent_type` ("Explore", "vibe:code-critic"), or the task's type ("local_bash"). */
  type: string | null;
  description: string;
  state: 'running' | 'done' | 'failed' | 'stopped';
  /** Run in the background: its call answered at once, its end a `task_notification`. */
  background: boolean;
  startedAt: number;
  endedAt: number | null;
  /** Tool calls it made, as counted or as the CLI said. */
  tools: number;
  /** What it did last: "Read src/game/hop.ts", or the CLI's summary. */
  last: string | null;
  tokens: number | null;
  /** The turn it began in. */
  turn: string | null;
  /** The SDK's task id, once a `task_started` named it. */
  task?: string;
}

// ---------------------------------------------------------------- the log

/** One item of a todo list (`TodoWrite`, or the `TaskCreate`/`TaskUpdate` pair). */
export interface TodoItem {
  text: string;
  status: 'pending' | 'in_progress' | 'completed';
}

/** A file a turn changed: lines added and removed (null for a binary, or a file git does not see). */
export interface TurnFile {
  path: string;
  added: number | null;
  removed: number | null;
  /** New since the turn began. */
  created: boolean;
  /** Uncommitted before the turn too: the designer's own work is in it as well. */
  before: boolean;
  /** Gone since the turn began: a command deleted it (Undo this turn brings it back from the turn's snapshot). */
  deleted?: boolean;
}

/** What went wrong, for the page's card and its next step (§2, Failures). */
export type FailureCode =
  | 'login'
  | 'usage'
  | 'api'
  | 'not-found'
  | 'sdk'
  | 'ended'
  | 'critic';

/** An entry as the server makes it; `Entry` is this with its `seq` and time. */
export type EntryBody =
  /** A turn sent: its words, how many images ("2 images", never their bytes), and the context as worded. */
  | { kind: 'prompt'; turn: string; text: string; images: number; context: string | null }
  /** The agent's words, a block at a time; `delta` pushes stream them in before this replaces them. */
  | { kind: 'text'; text: string; sub: boolean; parent?: string }
  /** One tool call: its 160-character summary; `sub`, a subagent's (`↳`), `parent` its `Agent` call; `input`, `GET input` has the whole of it. */
  | { kind: 'tool'; id: string; tool: string; detail: string; sub: boolean; input: boolean; parent?: string }
  /** A checklist: the whole list, which the next one replaces. */
  | { kind: 'todo'; items: TodoItem[]; sub: boolean; parent?: string }
  /**
   * A review round (§3): first when the critic is launched (`score` null),
   * again when its report is back. `note` says what kept a score from being read.
   */
  | { kind: 'review'; id: string; round: number; of: number; bar: number | null; score: number | null; report: string | null; note: string | null }
  /**
   * A turn ended. `how`: done, stopped by Stop, or ended by an error. The
   * files are git's view of the turn (`changes.ts`); `before` the files
   * uncommitted when it began.
   */
  | {
      kind: 'result';
      turn: string;
      ok: boolean;
      how: 'done' | 'stopped' | 'error';
      why: string | null;
      ms: number;
      /**
       * What the turn cost at API prices -- the CLI's running total less the
       * last turn's -- notional on a subscription, and said so.
       */
      cost: number | null;
      /** `cost` is the conversation's so far, not the turn's: the first turn of a resumed query, whose base is not known. */
      costSoFar?: boolean;
      /** `cli`: a turn Claude Code started itself; no Undo (it has no user message to rewind to). */
      origin?: 'cli';
      files: TurnFile[];
      added: number;
      removed: number;
      before: string[];
    }
  /** A permission or question card opened; it is in `state.pending` until its `answer` entry. */
  | { kind: 'card'; card: Card }
  /** A card settled: how, and what was answered or kept. */
  | { kind: 'answer'; card: string; outcome: CardOutcome; detail: string | null }
  /**
   * An editor tool's call answered (§8): its `tool` row's words now that the
   * page has said what it did -- "set Transform.px = 3 on big crate" -- and
   * what it did in full, for the row's hover; or, `ok` false, why not. `id` is
   * the call's `tool_use` id, the row's own; `turn`, the turn it was made in;
   * `tab`, the tab that ran it (its hello's id) -- a row in another tab says
   * so. `set`, an `scene_set`'s values, as values: what a page carries across
   * a reload, whose undo stack does not survive it. Both absent in a log from
   * before they were kept.
   */
  | { kind: 'editor'; id: string; turn: string | null; tool: string; ok: boolean; words: string; detail: string | null; tab?: string | null; set?: EditorSetValues }
  /** A dim line; `more`, a list folded under it (the skills past the project's own). */
  | { kind: 'note'; text: string; more?: { summary: string; items: string[] } }
  /** Something failed: what, and what to do next. */
  | { kind: 'error'; text: string; next: string | null; code: FailureCode | null }
  /** A line across the transcript; `reset`, everything before it is gone (Clear). */
  | { kind: 'rule'; text: string; reset: boolean }
  /**
   * Back from the terminal (Docs/terminal.md D10): the turns made there, read from the session -- at most 50, `more`
   * counting the rest.
   */
  | { kind: 'terminal'; turns: TerminalTurn[]; more: number }
  /**
   * `/btw`, a side question (Docs/agent.md §2, "/btw"): asked of a fork of the conversation with no tools, its answer
   * never in the conversation's history nor in Undo. First as asked (`answer` and `error` null), again by the same `id`
   * when answered. `tokens`, the fork's own turn's (its result's `usage`): what it read -- the conversation's context,
   * most of it from the cache -- and wrote; null, not said. No dollars: its running total may carry the conversation's.
   */
  | { kind: 'btw'; id: string; question: string; answer: string | null; error: string | null; tokens: { read: number; written: number } | null; ms: number | null };

/**
 * An entry of the log: numbered from 1, in order, per conversation and across
 * restarts; `epoch`, the dev-server process that made it (the state's), so a
 * failure said before a restart is not said again after it. Absent in a log
 * written before entries carried one.
 */
export type Entry = EntryBody & { seq: number; at: number; epoch?: string };

// ---------------------------------------------------------------- cards

/** Where an Always is kept (the SDK's destinations a person can pick). */
export type AlwaysDestination = 'session' | 'localSettings' | 'projectSettings' | 'userSettings';

/** One item of a card's Always menu: where it is kept, the rules it adds (the tooltip), and whether it waits behind More…. */
export interface AlwaysChoice {
  destination: AlwaysDestination;
  label: string;
  rules: string[];
  /** The project's settings (committed) and the person's own everywhere: behind More…, not one click away. */
  more: boolean;
}

/** A tool call waiting for the person. */
export interface PermissionCard {
  kind: 'permission';
  id: string;
  tool: string;
  /** The SDK's `title` when it gives one ("Claude wants to …"), else made here. */
  title: string;
  description: string | null;
  /** Why it is asked: the SDK's `decisionReason`, the user's own `ask` rule, or a path outside the allowed folders. */
  reason: string | null;
  /** The input's 160-character summary. */
  detail: string;
  /** Auto on, and a card all the same: which rule made it, in a line -- "Auto still asks: git push". Absent with Auto off. */
  auto?: string;
  sub: boolean;
  always: AlwaysChoice[];
  /** The call's `tool_use` id: its row, which a denied card marks (an editor tool's, "-- denied"). Absent in a log from before. */
  use?: string;
}

/** An `AskUserQuestion` call: questions with their options, an "Other" line each. */
export interface QuestionCard {
  kind: 'question';
  id: string;
  questions: Question[];
  sub: boolean;
}

export interface Question {
  question: string;
  header: string;
  options: { label: string; description: string }[];
  multiSelect: boolean;
}

export type Card = PermissionCard | QuestionCard;

/** How a card settled. `stopped`: Stop, Clear, the server's exit or the SDK's abort denied it. */
export type CardOutcome = 'allowed' | 'always' | 'denied' | 'answered' | 'skipped' | 'stopped';

// ---------------------------------------------------------------- a turn's context (§5)

/**
 * What the editor shows, as facts -- gathered by the page (`context.ts`),
 * worded by the server (`turn.ts`) alone.
 */
export interface TurnContext {
  /** The game's name (the editor's `name()`: `BootOptions.title`). */
  game: string;
  /** A playtest running, the editor hidden under the game. */
  playtest: boolean;
  /** The playtest running or paused (the editor over its world): absent with none, and from a page before it (Docs/terminal.md D9). */
  play?: 'running' | 'paused';
  /** The scene open in the editor, kept in this browser: its name (null: none yet) and whether it is saved. */
  scene: { name: string | null; unsaved: boolean } | null;
  /** The tool up. */
  tool: string | null;
  /** Each tool's `context()`, the tool up's first. */
  tools: ToolContext[];
  /** The selection's first eight. */
  selection: SelectedEntity[];
  /** How many more are selected. */
  more: number;
  /**
   * The Model tab's model and canvases (Docs/modeler.md phase 3), while the tab
   * is up with a script open: what the turn is about and what was drawn over it.
   * Its canvases' composites go as the turn's images, named by `image`.
   */
  model?: ModelTurn | null;
  /**
   * What a quick prompt (`Mod+K`, Docs/ai-panel.md §4) is about: the thing it was opened at -- the entities selected in
   * the scene, a file of the Assets panel, the Model tab's parts, a line of the Code card. Absent for a prompt from
   * the column's box; null when the person dropped it (the chip's ×). "This", "it" and "here" in the prompt mean it.
   */
  target?: TurnTarget | null;
}

/** A quick prompt's target (`TurnContext.target`): facts, worded by the server (`turn.ts`' `wordTarget`). */
export type TurnTarget =
  /** The entities selected in the scene, the first eight, and how many more. */
  | { kind: 'entities'; entities: SelectedEntity[]; more: number }
  /** A file of the Assets panel, by its path from the project's root, and its key where it has one (`props/crate`). */
  | { kind: 'asset'; path: string; key: string | null }
  /** The Model tab's parts selected, by their `emit{name=…}` names, of the script open. */
  | { kind: 'parts'; script: string; parts: string[] }
  /** The Code card's file, by its path, and the caret's line (from 1), if it has one. */
  | { kind: 'file'; path: string; line: number | null }
  /**
   * A row of the Problems card (Docs/ai-panel.md §5, A3: Fix with Claude): the file, its line and column (0 for the
   * program's own), the code (`TS2322`), the whole message and the program that found it (`tsc`, `vite`).
   */
  | { kind: 'problem'; file: string; line: number; col: number; code: string; message: string; program: string }
  /** A line of the Console card (Explain): the stream it is in (`server`, `task:build`) and its text, ANSI stripped. */
  | { kind: 'log'; stream: string; text: string };

/** The model open in the Model tab, as a turn's facts (Docs/modeler.md M26, M27; Vibe3D D30, D33, D65). */
export interface ModelTurn {
  /** The Gladius script, `AssetsSource/models/…/<stem>.lua`. */
  script: string;
  /** Its shipped export, if built. */
  export: string | null;
  /** The build as the tab says it: "current · built", "did not build: line 12: …". */
  build: string;
  /** Every `params{}` entry in effect: its value, and whether the record (not the script's default) sets it. */
  params: { name: string; value: string; set: boolean }[];
  /** The parts selected and hidden, by their `emit{name=…}` names. */
  selected: string[];
  hidden: string[];
  /** The model's bounds in metres, Y up; null for none drawn. */
  bounds: { min: Vec3; max: Vec3 } | null;
  /** The views show a preview build, not the export: why. */
  preview: string | null;
  /**
   * The model posed by a clip, as gladius_query's `pose` spells it -- `fly@0.2` -- with what more is so ("(playing)", a
   * bone posed by hand on top); null at rest, the pose the script builds (Docs/modeler.md M31). Optional: an older page.
   */
  pose?: string | null;
  /**
   * The build trace's step the views show in the model's place (Docs/modeler.md M34): `step 12 of 30: extrude 'lid' --
   * …`; null or absent, the model itself.
   */
  step?: string | null;
  /** The canvases that go with the turn: each visible, not stale, oldest first. */
  canvases: CanvasTurn[];
  /** Canvases left out, and why: "2 stale (drawn over the model before a rebuild)", "1 hidden". */
  left: string[];
}

export type Vec3 = [number, number, number];

/** One canvas: a drawing over a view of the model, the camera that made it, what it was drawn over (D24, D29, D69, D75). */
export interface CanvasTurn {
  name: string;
  /** The turn's image that is its composite (the drawing over the render), by its index in `images`; null: it did not go. */
  image: number | null;
  /** The person's words about it, quoted first (D75, D80). */
  note: string;
  /** Its colours, each named, with how many marks. */
  colours: { name: string; hex: string; marks: number }[];
  camera: CanvasCamera;
  /** Each mark raycast onto the mesh (D33), biggest first. */
  marks: MarkAnchor[];
  /** What it was drawn over: the parts selected and hidden then, and the parameters set then if they differ from now. */
  selected: string[];
  hidden: string[];
  /** The pose it was drawn over, `fly@0.2`; null, the rest pose (Vibe3D D89). Optional: an older page. */
  pose?: string | null;
  /** The build trace's step it was drawn over, `step 12 of 30: extrude 'lid'` (Vibe3D D69); null, the model. Optional: an older page. */
  step?: string | null;
}

/** A canvas's camera, whole: enough to unproject any pixel of its image (D33). */
export interface CanvasCamera {
  projection: 'perspective' | 'orthographic';
  position: Vec3;
  target: Vec3;
  up: Vec3;
  /** Vertical field of view in degrees (perspective). */
  fov: number;
  /** The frustum's height at the target, metres. */
  frustumHeight: number;
  /** The image's size, pixels. */
  width: number;
  height: number;
}

/** A mark raycast onto the mesh: where it lands, or how it misses (D33). */
export interface MarkAnchor {
  /** Its colour's name (`red`) and hex. */
  colour: string;
  hex: string;
  /** Its area on the image, pixels, and its box there. */
  area: number;
  box: { x: number; y: number; w: number; h: number };
  /** The share of its rays that met the model, 0 to 1. */
  coverage: number;
  /** Where it lands: the mean point, the mean normal, its extent in metres, the parts under it. */
  hit: { point: Vec3; normal: Vec3 | null; extent: number; parts: string[] } | null;
  /** Missed: the ray through its middle, where that crosses the drawing's plane (a stand-in depth), and the ground (y = 0) if it meets it. */
  miss: { from: Vec3; along: Vec3; plane: Vec3; ground: Vec3 | null } | null;
}

/** A tool's own facts: its folder, its chosen files. */
export interface ToolContext {
  tool: string;
  facts: { name: string; value: string | string[] }[];
}

/** A selected entity: its id, `Name`, prefab and node, `Labels`, and the model keys its `View` carries. */
export interface SelectedEntity {
  id: number;
  name: string | null;
  /** The key of the prefab it is an instance of (`crates/big`); null for an entity no prefab made. */
  prefab: string | null;
  /** Which entity of that prefab, by its name there (`rider`); null for the instance's root, or no prefab. */
  node: string | null;
  labels: string[];
  models: string[];
}

/** An image for the turn: at most four, each at most 5 MB decoded. */
export interface TurnImage {
  name: string;
  media: 'image/png' | 'image/jpeg' | 'image/gif' | 'image/webp';
  /** Base64, no `data:` prefix. */
  data: string;
}

// ---------------------------------------------------------------- the studio's page tools (Docs/mcp.md)

/**
 * The studio MCP server's page tools (`packages/pipeline/src/mcp/`, Docs/mcp.md §3): those run in a studio tab --
 * relayed to it, answered by its dispatcher (`packages/editor/src/mcp/`) -- as the page knows them; the agent calls
 * them `mcp__studio__<name>`. Read off the catalogue's table (`../mcp/catalog.ts`, which imports nothing), never
 * written here twice.
 */
export type { PageToolName };

/**
 * Every studio MCP tool by name, page and server alike (the catalogue's `ToolName`): what an editor action names as the
 * tool that does the same (`@vibe/editor`'s `Mcp`, Docs/skills.md §2 rule 7).
 */
export type { ToolName };

/** A turn's `deny` naming every studio tool that writes, in one word (`TurnRequest.deny`; the catalogue's `DENY_WRITERS`). */
export type DenyWriters = typeof DENY_WRITERS;

/** `prefab_info`' input: one prefab whole, by key; left out, every prefab in a line. */
export interface EditorPrefabsArgs {
  key?: string;
}

/** `scene_save_prefab`'s input: the new prefab's key, and the entities -- left out, the selection -- it is made of. */
export interface EditorSavePrefabArgs {
  key: string;
  entities?: number[];
}

/** `scene_set`'s input: a numeric field, on `entities` or the selection; `value` one for all, or one per entity. */
export interface EditorSetArgs {
  entities?: number[];
  component: string;
  field: string;
  value: number | number[];
}

/** `scene_create`'s input: what to make (`prefab`, the one kind as yet: Docs/mcp.md M2 adds more), a prefab's key, where (relative to `parent` when given, else in the world), and what it hangs from. */
export interface EditorInstantiateArgs {
  kind?: 'prefab';
  prefab: string;
  at?: { x: number; y: number; z: number };
  parent?: number;
}

/**
 * `scene_override`'s input (Docs/prefabs.md §7): `verb` on an instance's
 * overrides -- `entity` (one of the instance's, or the selection's first),
 * `what` the overrides by their handles as `studio_state` lists them (left
 * out: every one of that entity, or of the whole instance on its root), `to`
 * the prefab Apply writes (left out: the instance's own); Unpack `completely`.
 */
export interface EditorOverrideArgs {
  verb: 'revert' | 'apply' | 'unpack';
  entity?: number;
  what?: string[];
  to?: string;
  completely?: boolean;
}

/** `scene_save`'s input: the scene's own name, or `name` for a new one. */
export interface EditorSaveArgs {
  name?: string;
}

/**
 * A call relayed to a studio tab -- the turn's, else the last to say hello -- pushed `{ mcp }` to its socket alone,
 * which runs it (`packages/editor/src/mcp/`) and answers `POST mcp/answer` with the same `id`.
 */
export interface McpCall {
  /** The relay's: what the answer names. */
  id: string;
  /** A studio tool's name, or a project's own (`project_<name>`, `ProjectToolName`: Docs/mcp.md M7). */
  tool: PageToolName | ProjectToolName;
  args: Record<string, unknown>;
  /** The turn it was made in: its result's Undo this turn walks its steps back. */
  turn: string | null;
  /** Its `tool_use` id: the transcript's row for it. Null where the CLI did not say. */
  use: string | null;
  /** The conversation's title, while more than one is open: its steps' labels say whose they are. */
  title?: string;
  /** An outside client's call (`/__mcp`, Docs/mcp.md M7): its steps are labelled `MCP: …`, and there is no turn. */
  outside?: true;
  /**
   * When the relay stops waiting for its answer (`Date.now()`'s, the tool's deadline from the call): a call that
   * changes the world and has not begun by then is refused, never begun -- its answer would come too late for the
   * agent, which was told `timeout`. Set by the relay.
   */
  expires?: number;
}

/**
 * `POST mcp/answer`: what the tab did -- a result (facts, the server words
 * them), an error naming what was wrong, or that the editor cannot just now
 * (`away`: a playtest running; `nopanel`, an asset tool in a tab with no
 * Assets panel made, refused before any step -- the dev server runs it
 * instead), which the server words.
 */
/** The relay's call as the session hands it over: the relay adds its `id` and `expires`. */
export type McpCallOut = Omit<McpCall, 'id' | 'expires'>;

export type McpAnswerRequest = { id: string; result: EditorResult } | { id: string; error: string } | { id: string; away: 'playtest' | 'nopanel' };

/** What a call came to, as the page says it: facts, worded on the server. */
export type EditorResult =
  | SelectionResult | StudioContextResult | DescribeResult | PrefabsResult | SetResult | SaveResult | InstantiateResult | OverrideResult | SavePrefabResult
  | QueryResult | EntityResult | DestroyResult | DuplicateResult | ReparentResult | RenameResult | ComponentResult | FlagsResult
  | RelateResult | UnrelateResult | ListResult<'scene_list_insert'> | ListResult<'scene_list_remove'> | ListResult<'scene_list_move'> | MainCameraResult | SelectResult | BatchResult | OpenPrefabResult | ClosePrefabResult
  | SceneOpenResult | SceneNewResult | SceneSaveAsResult | SceneStartResult
  | AssetNewResult | AssetMoveResult | AssetCopyResult | AssetDeleteResult | AssetRestoreResult | AssetOptionsResult
  | MaterialSetResult | PhysmatSetResult | PrefabEditResult | AssetExportResult
  | PlayResult<'play_start'> | PlayResult<'play_pause'> | PlayResult<'play_step'> | PlayStateResult | PlayStopResult
  | ViewShotResult | ViewGetResult<'view_get'> | ViewGetResult<'view_set'> | ViewGetResult<'view_focus'>
  | GameViewResult<'game_view_state'> | GameViewResult<'game_view_set'> | GameViewResult<'game_view_preset'>
  | PhysicsStateResult | PhysicsSettingsSetResult | PhysicsRaycastResult | PhysicsOverlapResult | PhysicsFitResult
  | HistoryListResult | HistoryMoveResult<'history_undo'> | HistoryMoveResult<'history_redo'>
  | ModelOpenResult | ModelInfoResult | ModelParamsSetResult | ModelPreviewResult | ModelExportResult | ModelMaterialsSetResult | ModelPoseResult
  | ModelAdoptResult | CopyResult | PasteResult | SceneImportResult;

/** One entity of a prefab, as `prefab_info` says it: what `Prefab.node(name)` finds, and what `init` may fill in. */
export interface PrefabNodeFacts {
  /** Its id path in the file (`''` the root; `rider/seat` inside a nested instance). */
  path: string;
  name: string | null;
  /** Its parent's path; null for the root. */
  parent: string | null;
  /** What it is made of: components and tags, the world's own left out. */
  components: string[];
  /** The model it draws (`view.model`), or null. */
  view: string | null;
  /** The nested prefab whose file makes it; null where this prefab's own file does. */
  from: string | null;
}

/** One prefab, as `prefab_info` says it: whole (`nodes`, `instances`) when asked for by key, else in a line. */
export interface PrefabFacts {
  key: string;
  /** Its file's uid (Docs/asset-ids.md §1), where it has one: what a reference to it holds beside the key. */
  uid?: string;
  /** Its file: `src/assets/prefabs/<key>.prefab`, JSON inside. */
  file: string;
  /** How many entities one instance is, and the names `node()` takes. */
  entities: number;
  names: string[];
  /** The prefab whose instance its root is -- a variant's base -- or null. */
  variantOf: string | null;
  /** The prefabs it nests an instance of (directly), and those nesting it. */
  nests: string[];
  nestedBy: string[];
  /** Its pool, from its file or `pool()` in code -- with what is parked and out now -- or null for none. */
  pool: { warm: number; max: number; parked: number; out: number } | null;
  /** Its instances' roots alive in the world now. */
  instances: number;
  /** The live compile's problem with its file, or null. */
  problem: string | null;
  /** Asked for by key: every entity of it, in tree order. */
  nodes?: PrefabNodeFacts[];
  /** Asked for by key: its instances' roots in the world (the first 32), id and name. */
  roots?: { id: number; name: string | null }[];
}

/** `prefab_info`: every prefab compiled, or the one asked for; and files under `prefabs/` that do not compile, by key, with why. */
export interface PrefabsResult {
  tool: 'prefab_info';
  prefabs: PrefabFacts[];
  broken: { key: string; problem: string }[];
}

/** `scene_save_prefab`: the prefab written, the instance that replaced the entities -- its root -- the step, and the editor's line. */
export interface SavePrefabResult {
  tool: 'scene_save_prefab';
  key: string;
  file: string;
  root: number;
  name: string | null;
  /** How many entities the instance is. */
  entities: number;
  step: string;
  said: string;
  /** A step the person had undone, dropped from the redo side by this one: Y no longer brings it back. */
  dropped?: string;
}

/**
 * `studio_state`, as the page answers it: what is open -- the editor's tab shown, the scene (saved or not), the
 * prefab open to edit, the playtest -- and the selection's first `entities.length` of `selected`. The server adds
 * its own (`StudioStateFacts`): the problems count and the jobs.
 */
/** `studio_context` (Docs/terminal.md D8): the editor's facts as a column turn gathers them (`gather(true)`), worded by the server. */
export interface StudioContextResult {
  tool: 'studio_context';
  context: TurnContext;
}

export interface SelectionResult {
  tool: 'studio_state';
  /** The editor's tab shown: Scene, Config, Model, Studio … (a tool's name); null where the page cannot say. */
  tab: string | null;
  /** The scene kept in this browser: its name (null: none yet) and whether it is saved. Null: the game's own world. */
  scene: { name: string | null; unsaved: boolean } | null;
  /** The prefab open to edit (its key), or null for the scene. */
  prefab: string | null;
  /** No playtest, one running (the editor hidden under the game), or one paused with the editor over its world. */
  playtest: 'none' | 'running' | 'paused';
  selected: number;
  entities: EntityFacts[];
}

/** One entity, whole: what it is, and each component's data. */
export interface EntityFacts {
  id: number;
  /** Its `EntityRef` and its path of names (M2): what the scene tools name it by. */
  ref: number;
  path: string;
  name: string | null;
  /** As `SelectedEntity`'s: the prefab's key, and which entity of it; null and null for an entity no prefab made. */
  prefab: string | null;
  node: string | null;
  /** The root of an instance of `prefab` (its node is the root): what the prefab places. */
  instance: boolean;
  /**
   * What it changes from its prefab (an entity of an instance; on its root,
   * the entities removed from it and added under it too): each by its handle
   * (`what`) and the entity of the prefab it is at (`at`, `''` the root), the
   * prefab's value and its own, and the prefabs Apply could write it to,
   * innermost first. Absent for an entity no prefab made.
   */
  overrides?: OverrideFacts[];
  labels: string[];
  /** What it hangs from: an id, or null at the root. */
  parent: number | null;
  layer: number;
  /** Its model keys (`View`'s `userData.assetKey`), resolved to their files on the server. */
  models: string[];
  /** Its tags. */
  tags: string[];
  /** The components switched off on it (`world.enable(e, C, false)`). */
  off: string[];
  /**
   * Each numeric component's fields and values; a `ref()` is `{ ref }`, the entity it points at, or null; a key field
   * (`Render.model`) its text, `''` for none -- or `{ key, uid }` where the asset has a uid, as a file names it
   * (Docs/asset-ids.md §3); an enum its name, flags their names (a list), a colour with alpha `#rrggbbaa`, a vector
   * its numbers under its one name (`dir: [0, 0, 1]`), as a file writes each.
   */
  components: Record<string, Record<string, number | string | string[] | number[] | { ref: number | null } | { key: string; uid: string; part?: string } | { key: string; part: string }>>;
  /** Each object component, summarised: a string, a number, or what it is. */
  objects: Record<string, string>;
  /** Each relation's links going out: to whom, and the link's data. */
  links: Record<string, { to: number; data: Record<string, number> }[]>;
}

/** One field's schema, as `scene_entity` answers it (the engine's `fieldSchema`, `ecs/fields.ts`). */
export interface FieldSchemaFacts {
  /**
   * What it holds: a number, a yes or no, a name of `names`, a list of `names`, a colour, a colour with alpha, a vector
   * of `size` numbers, an entity, an asset key of `keyKind` (any kind: `Model`, `Sfx`, `Prefab` …), a model and one
   * of its parts (`mesh`: `{ key, part }` or `"key#part"`).
   */
  kind: 'number' | 'bool' | 'enum' | 'flags' | 'color' | 'colorA' | 'vector' | 'ref' | 'key' | 'mesh' | 'string' | 'list' | 'dict' | 'record';
  type: string;
  label: string;
  help?: string;
  names?: string[];
  size?: number;
  keyKind?: string;
  /** A typed ref's components: what an entity must have to be held there. */
  needs?: string[];
  /** What scene_set holds a number to (clamped, said): its own bounds, else a whole number type's range. */
  min?: number;
  max?: number;
  step?: number;
  slider?: true;
  hidden?: true;
  /** scene_set refuses it: the game's code sets it. */
  readonly?: true;
  runtime?: true;
  group?: string;
  /** A data component's string: its most characters (held, said), and a text area. */
  maxLength?: number;
  multiline?: true;
  /** A data component's list: its element (`min`/`max` its count's). */
  of?: FieldSchemaFacts;
  /** A data component's dictionary: its key and value. */
  key?: FieldSchemaFacts;
  value?: FieldSchemaFacts;
  /** A data component's record: its fields. */
  fields?: Record<string, FieldSchemaFacts>;
}

/** One override, as `studio_state` says it and `scene_override` takes it. */
export interface OverrideFacts {
  at: string;
  what: string;
  prefab: string;
  here: string;
  to: string[];
}

/** `scene_override`: what was done -- the overrides by handle, the prefab written for Apply -- the step it made, and the editor's line. */
export interface OverrideResult {
  tool: 'scene_override';
  verb: 'revert' | 'apply' | 'unpack';
  /** The instance's root, and its prefab. */
  root: number;
  prefab: string;
  done: string[];
  /** Apply's prefab. */
  to: string | null;
  step: string;
  said: string;
  /** A step the person had undone, dropped from the redo side by this one. */
  dropped?: string;
}

/** `scene_describe`: `world.describe()`. */
export interface DescribeResult {
  tool: 'scene_describe';
  text: string;
}

/** `scene_set`: the values written, read back, and the step it made -- its label -- or null, nothing having changed. */
export interface SetResult {
  tool: 'scene_set';
  component: string;
  field: string;
  step: string | null;
  /**
   * Each entity's value before and after, read back: a key field's as its text, with the uid `now`'s asset has, where
   * it has one; a colour as `#rrggbb` (`#rrggbbaa` with alpha); an enum's name, flags' names (`fire, ice`); a vector
   * its numbers; a ref as the ref it holds (0: none); an object component's as JSON text -- `Name` as the name itself.
   * Its ref too (M2).
   */
  written: { id: number; ref?: number; name: string | null; was: number | string | number[]; now: number | string | number[]; uid?: string }[];
  /** Values held to a field's `min` or `max` on the way in, each said: `Brain.speed 12 clamped to 10, its max`. */
  clamped?: string[];
  /** An object component's write: no values kept by value across a reload (its step alone). */
  object?: boolean;
  /**
   * `was` given and not what the field holds now on these: nothing written (`written` empty, no step) -- each
   * entity's value now, to read and decide again.
   */
  changed?: { ref: number; id: number; name: string | null; now: number | string | number[] }[];
  /** A step the person had undone, dropped from the redo side by this one. */
  dropped?: string;
}

/**
 * An `scene_set` as the `editor` entry keeps it (§8): the field, the step it
 * made (null: nothing changed), and each entity's value before and after --
 * with the entry's `turn`, `id` (the call's `use`) and `tab`, what Undo this
 * turn puts back by value once a reload has taken the step away.
 */
export interface EditorSetValues {
  component: string;
  field: string;
  step: string | null;
  /** A key field's values as their text (`Render.model`), as `SetResult` answers them. */
  written: { id: number; was: number | string; now: number | string }[];
}

/** `scene_create`: the instance made -- its root's id and name, its entities, where -- and the step it made. */
export interface InstantiateResult {
  tool: 'scene_create';
  /** What was made: an instance of a prefab, an Empty, a camera. */
  kind: 'prefab' | 'empty' | 'camera';
  /** The prefab's key; null for an Empty or a camera. */
  prefab: string | null;
  id: number;
  /** Its `EntityRef`, and its path of names: what later calls name it by. */
  ref: number;
  path: string;
  /** A camera made: whether it is the main one (made main when the scene had none). */
  main?: boolean;
  name: string | null;
  /** How many entities the instance is. */
  entities: number;
  parent: number | null;
  at: { x: number; y: number; z: number };
  step: string;
  /** A step the person had undone, dropped from the redo side by this one. */
  dropped?: string;
}

/** `scene_save`: saved, under this name. */
export interface SaveResult {
  tool: 'scene_save';
  /** The file's name as written, capitals and spaces kept: `src/assets/scenes/<name>.scene`; with a prefab open, its key. */
  name: string;
  /** Its key: the name lowercased. */
  key: string;
  saved: true;
  /** With a prefab open to edit: that prefab saved to its file, and still open -- its file, whether a byte changed, what the save said. */
  prefab?: { file: string; wrote: boolean; said: string };
}

// ---------------------------------------------------------------- M2: the scene and its entities (Docs/mcp.md §4)

/**
 * An entity as the scene tools name it: its `EntityRef` (index and generation: a ref to one destroyed since names
 * nothing), its id this session, its path of names from its root (`big crate/rider`; an entity with no name is
 * `#<ref>` there), and its name.
 */
export interface EntityRow {
  ref: number;
  id: number;
  path: string;
  name: string | null;
}

/** `scene_query`'s row: an entity, what made it, and what it is made of. */
export interface QueryRow extends EntityRow {
  prefab: string | null;
  node: string | null;
  components: string[];
}

/** `scene_query`: the entities matching, a page of them in the tree's order, and where the next page starts (null: none). */
export interface QueryResult {
  tool: 'scene_query';
  total: number;
  entities: QueryRow[];
  next: string | null;
}

/** `scene_entity`: one entity whole -- `studio_state`'s row, and its ref, path, children, links both ways, object components by their save shape. */
export interface EntityResult {
  tool: 'scene_entity';
  entity: EntityFacts & {
    ref: number;
    path: string;
    children: EntityRow[];
    /** Object components that have a save shape, as `world.save()` writes them: what `scene_set` takes back. */
    saved: Record<string, unknown>;
    /**
     * Each numeric component's fields' schema, by the name `components` and `scene_set` use: what each holds and what
     * `scene_set` takes there -- its kind, an enum's or flags' names, a vector's size, a key's kind, bounds, step,
     * read only, hidden from the inspector, runtime -- and each data component's, all the way down (a list's `of`, a
     * dict's `key` and `value`, a record's `fields`, a string's `maxLength`).
     */
    schema: Record<string, Record<string, FieldSchemaFacts>>;
    /** Every link, out and in, by relation: the other end, and the link's data. */
    relations: Record<string, { out: { to: EntityRow; data: Record<string, number> }[]; into: { from: EntityRow; data: Record<string, number> }[] }>;
  };
}

/** `scene_destroy`: the entities named, gone with everything under them. */
export interface DestroyResult {
  tool: 'scene_destroy';
  destroyed: EntityRow[];
  /** How many went in all, children with them. */
  count: number;
  step: string;
  dropped?: string;
}

/** `scene_duplicate`: the copy, where the original is. */
export interface DuplicateResult {
  tool: 'scene_duplicate';
  of: EntityRow;
  copy: EntityRow;
  step: string;
  dropped?: string;
}

/** `scene_copy`: entities copied as the tree's Copy copies them -- each with everything under it -- as the clip's JSON. */
export interface CopyResult {
  tool: 'scene_copy';
  /** The roots copied, in the tree's order. */
  roots: EntityRow[];
  /** Every entity in the clip, the roots' children with them. */
  count: number;
  /** The clip kept page-side (the person's clipboard untouched): what `scene_paste` takes as `handle`, in this scene or another. */
  handle: string;
  /** The clip's text's length, in characters. */
  size: number;
  /** The clip, the text the tree's Copy puts on the clipboard -- only while it is short enough to answer whole (`CLIP_TEXT_MAX`). */
  clip?: string;
}

/** `scene_paste`: a clip made in the world, as the tree's Paste -- its roots, how many in all, what this build lacks. */
export interface PasteResult {
  tool: 'scene_paste';
  roots: EntityRow[];
  count: number;
  /** What the clip names that this build has not -- a prefab, a component -- each once, left out. */
  skipped: string[];
  step: string;
  dropped?: string;
}

/** `scene_reparent`: the entities moved, under `parent` (null: the roots), in front of `before` (null: last). */
export interface ReparentResult {
  tool: 'scene_reparent';
  moved: EntityRow[];
  parent: EntityRow | null;
  before: EntityRow | null;
  step: string;
  dropped?: string;
}

/** `scene_rename`: each entity's name before and after (null: none). */
export interface RenameResult {
  tool: 'scene_rename';
  renamed: (EntityRow & { was: string | null })[];
  step: string | null;
  dropped?: string;
}

/** `scene_component`: a component added, removed, switched on or off on the entities that took it. */
export interface ComponentResult {
  tool: 'scene_component';
  verb: 'add' | 'remove' | 'enable' | 'disable';
  component: string;
  /** Those it was done to; the rest had it so already. */
  done: EntityRow[];
  step: string | null;
  dropped?: string;
}

/** `scene_flags`: what changed, in words each ("Hide 2", "Layer → props", "Add label crate"). */
export interface FlagsResult {
  tool: 'scene_flags';
  entities: EntityRow[];
  changed: string[];
  step: string | null;
  dropped?: string;
}

/** `scene_relate`: a link made from `from` to `to`, with its data. */
export interface RelateResult {
  tool: 'scene_relate';
  relation: string;
  from: EntityRow;
  to: EntityRow;
  data: Record<string, number>;
  step: string;
  dropped?: string;
}

/** `scene_unrelate`: the link from `from` to `to` cut. */
export interface UnrelateResult {
  tool: 'scene_unrelate';
  relation: string;
  from: EntityRow;
  to: EntityRow;
  step: string;
  dropped?: string;
}

/**
 * `scene_list_insert`, `scene_list_remove`, `scene_list_move`: a data component's list (or dictionary) after the
 * edit, each entity's as JSON text (refs as entity refs), and the step -- null, nothing having changed.
 */
export interface ListResult<T extends 'scene_list_insert' | 'scene_list_remove' | 'scene_list_move' = 'scene_list_insert' | 'scene_list_remove' | 'scene_list_move'> {
  tool: T;
  component: string;
  path: string;
  step: string | null;
  written: { id: number; ref: number; was: string; now: string }[];
  /** A step the person had undone, dropped from the redo side by this one: set by the page's dispatcher (`mark`), as every edit's. */
  dropped?: string;
}

/** `scene_main_camera`: the camera the game draws through, and those that were main before. */
export interface MainCameraResult {
  tool: 'scene_main_camera';
  camera: EntityRow;
  /** Cameras that were main and are not now. */
  was: EntityRow[];
  step: string | null;
  dropped?: string;
}

/** `scene_select`: the person's selection now. */
export interface SelectResult {
  tool: 'scene_select';
  selected: EntityRow[];
}

/**
 * The tools a `batch` runs: the world's own edits, done at once -- nothing that waits on a file or a compile, loads
 * another world, or is no edit. The one list: the `batch` record's enum and words, and the page's `BATCHED`.
 */
export const BATCHED_TOOLS = [
  'scene_create', 'scene_destroy', 'scene_duplicate', 'scene_reparent', 'scene_rename', 'scene_component', 'scene_set', 'scene_flags',
  'scene_relate', 'scene_unrelate', 'scene_main_camera', 'scene_list_insert', 'scene_list_remove', 'scene_list_move',
] as const satisfies readonly PageToolName[];

/** `batch`: each call's result, in order, done as one step. */
export interface BatchResult {
  tool: 'batch';
  results: EditorResult[];
  step: string | null;
  dropped?: string;
}

/** `scene_open_prefab`: the prefab open to edit, its root, and why it cannot be saved (null: it can). */
export interface OpenPrefabResult {
  tool: 'scene_open_prefab';
  key: string;
  root: EntityRow | null;
  readOnly: string | null;
  said: string;
}

/** `scene_close_prefab`: back from `key` to `back` (a prefab, or "the scene"), saved first or its changes dropped. */
export interface ClosePrefabResult {
  tool: 'scene_close_prefab';
  key: string;
  back: string;
  saved: boolean;
  dropped: boolean;
  said: string;
}

/** `scene_open`: the scene opened in place of the world; what it held that no longer loads. */
export interface SceneOpenResult {
  tool: 'scene_open';
  key: string;
  discarded: boolean;
  skipped: string[];
}

/** `scene_import`: a world save written as a new scene file and opened, as the Scenes page's Import…. */
export interface SceneImportResult {
  tool: 'scene_import';
  key: string;
  /** The file written: `src/assets/scenes/<name>.scene`. */
  file: string;
  discarded: boolean;
  skipped: string[];
}

/** `scene_new`: the world emptied for a new scene, but for its one main camera (`Main Camera`). */
export interface SceneNewResult {
  tool: 'scene_new';
  discarded: boolean;
}

/** `scene_save_as`: written as a new scene file. */
export interface SceneSaveAsResult {
  tool: 'scene_save_as';
  /** The file's name as written, capitals and spaces kept: `src/assets/scenes/<name>.scene`. */
  name: string;
  /** Its key: the name lowercased. */
  key: string;
}

/** `scene_start`: the scene the game opens on start (null: its own world). */
export interface SceneStartResult {
  tool: 'scene_start';
  start: string | null;
}

// ---------------------------------------------------------------- M3: assets (Docs/mcp.md §4, D2)

/**
 * What every asset write answers, whichever way it ran (D2): through the Assets panel's own step in a studio tab
 * (`panel`: one step on its history, `Claude: …`, which Z there undoes) or by the dev server with no tab (`server`:
 * Undo this turn alone) -- and the files it wrote, moved or removed, which Undo this turn puts back.
 */
export interface AssetWrite {
  via: 'panel' | 'server';
  /** The panel's step, as its history names it; null for the server's, or nothing to do. */
  step: string | null;
  /** Project-relative paths it touched: Undo this turn's. */
  files: string[];
  /** Some of several done, the rest not: said. */
  partial?: string;
  /** Never the panel's: its history is not the world's (`droppedWords`). */
  dropped?: string;
}

/** A job of the pipeline's a write queued: its id (the push channel's `job`) and its source. */
export interface QueuedExport {
  id: string;
  source: string;
}

/** `asset_new`: a folder, a pack, a prefab, a variant, a material, a scene or a model script made. */
export interface AssetNewResult extends AssetWrite {
  tool: 'asset_new';
  kind: string;
  path: string;
  /** Its key, where it has one. */
  key: string | null;
  jobs: QueuedExport[];
}

/** `asset_move`: each family moved, from and to; the files the repair pass rewrote. */
export interface AssetMoveResult extends AssetWrite {
  tool: 'asset_move';
  moved: Array<[from: string, to: string]>;
  rewritten: string[];
}

/** `asset_copy`: the copies made, each a new asset. */
export interface AssetCopyResult extends AssetWrite {
  tool: 'asset_copy';
  copies: string[];
}

/** `asset_delete`: what went to the trash, and the slot it is in. */
export interface AssetDeleteResult extends AssetWrite {
  tool: 'asset_delete';
  removed: string[];
  slot: string | null;
}

/** `asset_restore`: what came back, where. */
export interface AssetRestoreResult extends AssetWrite {
  tool: 'asset_restore';
  restored: string[];
}

/** `asset_options`: a source's or a folder's export options, or a source in the build or out of it; the exports that follow. */
export interface AssetOptionsResult extends AssetWrite {
  tool: 'asset_options';
  path: string;
  jobs: QueuedExport[];
  /** With `as`: the name its export ships as now (null: its own stem), and the exports moved to it, `[from, to]`. */
  exportAs?: { as: string | null; moved: Array<[string, string]> };
}

/** `model_adopt`: a model file made a Gladius script's export, as Make a script for it -- the script, its copy, its build. */
export interface ModelAdoptResult extends AssetWrite {
  tool: 'model_adopt';
  /** The `.glb` adopted, under src/assets/models/. */
  path: string;
  /** The script written, under AssetsSource/models/: what model_open opens. */
  script: string;
  /** The copy of the file the script imports, beside it (`copied`: `copy` is a duplicate's made row, which a batch reads). */
  copied: string | null;
  /** The compression decoded on the way in. */
  decoded: string[];
  /** Its build, as it ended within the call (`done`, `failed`), or null: still running, or not known (the server's). */
  built: 'done' | 'failed' | null;
  jobs: QueuedExport[];
}

/** `material_set`: a material's fields written, as the Material block writes them. */
export interface MaterialSetResult extends AssetWrite {
  tool: 'material_set';
  key: string;
  path: string;
  /** The fields as given. */
  set: Record<string, unknown>;
}

/** `physmat_set`: a physics material's fields written, as the Assets inspector's Physics material block writes them. */
export interface PhysmatSetResult extends AssetWrite {
  tool: 'physmat_set';
  key: string;
  path: string;
  /** The material after: every field, filled in. */
  values: { friction: number; rollingFriction: number; restitution: number; frictionCombine: string; restitutionCombine: string };
}

/** `prefab_edit`: a prefab's pool or its root's components written, as the Prefab block writes them. */
export interface PrefabEditResult extends AssetWrite {
  tool: 'prefab_edit';
  key: string;
  path: string;
  /** What changed, in words: "pool warm 8, max 32", "Spin.speed". */
  changed: string[];
}

/** `asset_export`: the exports queued, and the studio job that follows them (`job_wait`); its result when it ended in time. */
export interface AssetExportResult extends AssetWrite {
  tool: 'asset_export';
  jobs: QueuedExport[];
  /** The studio's job following them (`job_status`, `job_wait`); null when nothing needed exporting. */
  job: string | null;
  /** How they ended, when they did within the call: each source's state and error. */
  ended?: Array<{ source: string; state: string; error?: string }>;
}

// ---------------------------------------------------------------- M4: play and view (Docs/mcp.md §4)

/** A playtest as the play tools say it: its state, the loop's tick, the ticks and seconds since it began. */
export interface PlayFacts {
  state: 'none' | 'running' | 'paused';
  /** The loop's tick now. */
  tick: number;
  /** Ticks since the playtest began (0 with none), and as seconds at 60 Hz. */
  ticks: number;
  seconds: number;
  /** What was changed while paused -- what Stop offers to keep -- each by its id (`play_stop`'s `keep`) and in words; none with no playtest. */
  changes: Array<{ id: string; words: string }>;
}

/** `play_start`, `play_pause`, `play_step`: what was done, and the playtest after it. */
export interface PlayResult<T extends 'play_start' | 'play_pause' | 'play_step' = 'play_start' | 'play_pause' | 'play_step'> extends PlayFacts {
  tool: T;
  /** What it did: started, resumed, paused, or stepped `stepped` ticks. */
  did: 'started' | 'resumed' | 'paused' | 'stepped';
  stepped?: number;
}

/** `play_state`: the playtest as it stands. */
export interface PlayStateResult extends PlayFacts {
  tool: 'play_state';
}

/** `play_stop`: the playtest over, the world put back, and what was changed while paused kept or dropped. */
export interface PlayStopResult extends PlayFacts {
  tool: 'play_stop';
  /** How it was decided: the call's `keep`, or the person's preference (`asked`: the dialog put to the person). */
  how: 'all' | 'none' | 'listed' | 'preference: keep' | 'preference: drop' | 'asked';
  /** Kept, in words; skipped with why; dropped, how many (not `dropped`: a step's answer says by that what it dropped from redo). */
  kept: string[];
  skipped: string[];
  discarded: number;
  /** The history step the kept ones are ("Kept from the playtest"), or null for none. */
  step: string | null;
  /** The step the person had undone, dropped from redo by the kept ones' step: they no longer have it. */
  dropped?: string;
}

/** What a `view_shot` looked through. */
export type ShotTarget = 'scene' | 'camera' | 'main' | 'model';

/** `view_shot`: an image of a view, beside its facts (the bytes ride as MCP image content, not in the JSON). */
export interface ViewShotResult {
  tool: 'view_shot';
  target: ShotTarget;
  /** The camera entity looked through (`camera`, `main`); null for the editor's view and the Model tab's. */
  camera: EntityRow | null;
  width: number;
  height: number;
  overlays: boolean;
  mimeType: string;
  /** Base64. */
  data: string;
  /** Said beside: smaller than asked, overlays not drawn there, the kept frame of a paused world. */
  notes: string[];
}

/** The editor's view as numbers: where its camera is, what it turns round, how it sees. */
export interface ViewPoseFacts {
  position: [number, number, number];
  target: [number, number, number];
  projection: 'perspective' | 'orthographic';
  /** Perspective's vertical field of view in degrees; orthographic's height seen at the target in metres. */
  fov: number | null;
  height: number | null;
  /** Where it looks from, named as the cube names it: front, right, top … or free. */
  preset: string;
}

/** `view_get`, and what `view_set` and `view_focus` leave: the pose, and the room past the editor's cards. */
export interface ViewGetResult<T extends 'view_get' | 'view_set' | 'view_focus' = 'view_get' | 'view_set' | 'view_focus'> {
  tool: T;
  view: ViewPoseFacts;
  /** The scene's room past the cards, in CSS pixels of the canvas; null: all of it. And the canvas's size. */
  room: { left: number; top: number; right: number; bottom: number } | null;
  canvas: { width: number; height: number };
  /** `view_focus`: the entities framed. */
  framed?: EntityRow[];
  /** The collider overlay (Docs/physics.md §7): none, the selection's, or every collider's. */
  colliders?: 'none' | 'selected' | 'all';
}

/**
 * `game_view_state`, and what `game_view_set` leaves (Docs/game-view.md D7): the game's frame -- the rect of the canvas
 * it is drawn in, CSS pixels from the canvas's top left -- the canvas's size, what the frame is now, and Maximize on Play.
 */
export interface GameViewResult<T extends 'game_view_state' | 'game_view_set' | 'game_view_preset' = 'game_view_state' | 'game_view_set' | 'game_view_preset'> {
  tool: T;
  /** The rect the game is drawn in: the preset's box while it applies (`applies`), else the room or the whole canvas. */
  frame: { x: number; y: number; width: number; height: number };
  canvas: { width: number; height: number };
  /** `room`: the scene's room between the editor's cards; `window`: the whole canvas (the cards away, or a maximized playtest). */
  fills: 'room' | 'window';
  /** A playtest plays over the whole window with every card hidden (true), or docked in the room (false): the person's preference. */
  maximizeOnPlay: boolean;
  /** The preset chosen, by its name: `Free Aspect` for none (Docs/game-view.md §4). */
  preset: string;
  /** Does it shape the frame now: the game's own cameras drawing -- a playtest running, or the Game look. */
  applies: boolean;
  /** The frame's size in the game's pixels -- a Pixel or Stretch preset's resolution, else the frame's own -- what its cameras and pointer measure. */
  pixels: { width: number; height: number };
  /** Device pixels per game pixel for a Pixel or Stretch preset -- Pixel's whole number, Stretch's factor -- else 1 (Fit and Free Aspect draw at the screen's sharpness). */
  scale: number;
  /** `game`: the stopped or paused scene seen through the game's cameras, shaped by the preset; `scene`: the editor's camera. */
  look: 'scene' | 'game';
  /** Every preset, in the dropdown's order: Free Aspect, the built-ins, the project's own (`own`). `size` `16:9` or `640x360`. */
  presets: { name: string; size: string | null; mode: 'fit' | 'pixel' | 'stretch'; filter: 'nearest' | 'linear'; own: boolean }[];
  /** `game_view_preset`'s: what it did. */
  did?: 'added' | 'changed' | 'removed' | 'moved';
}

/** The project's physics settings as the physics tools say them (`physics.json`, Docs/physics.md §3). */
export interface PhysicsSettingsFacts {
  enabled: boolean;
  gravity: [number, number, number];
  substeps: number;
  iterations: number;
  sleep: { linear: number; angular: number };
  defaultMaterial: { friction: number; restitution: number };
  layers: string[];
  ignore: [string, string][];
}

/** The physics running in the page: bodies by type and awake, triggers, contacts, the step's milliseconds. */
export interface PhysicsStatsFacts {
  dynamic: number;
  kinematic: number;
  static: number;
  awake: number;
  triggers: number;
  contacts: number;
  stepMs: number;
  maxStepMs: number;
}

/**
 * `physics_state` (Docs/physics.md §7): physics on or off in the project, whether it runs in this page (Ammo loaded),
 * the settings, the matrix as rows of the layers that collide, the stats (null where it does not run), and the collider
 * overlay's choice.
 */
export interface PhysicsStateResult {
  tool: 'physics_state';
  enabled: boolean;
  running: boolean;
  settings: PhysicsSettingsFacts;
  /** For each layer, the layers it collides with. */
  matrix: Record<string, string[]>;
  stats: PhysicsStatsFacts | null;
  colliders: 'none' | 'selected' | 'all';
}

/** `physics_settings_set`: the settings written, and whether the dev server restarts for it (`enabled` changed). */
export interface PhysicsSettingsSetResult {
  tool: 'physics_settings_set';
  settings: PhysicsSettingsFacts;
  restart: boolean;
}

/** One body a ray met: the entity, where, the surface's normal there, how far along. */
export interface PhysicsHitFacts {
  entity: EntityRow;
  point: [number, number, number];
  normal: [number, number, number];
  distance: number;
}

/** `physics_raycast`: what the ray met, nearest first (one with `all` false). */
export interface PhysicsRaycastResult {
  tool: 'physics_raycast';
  hits: PhysicsHitFacts[];
}

/** `physics_overlap`: what the shape there overlaps. */
export interface PhysicsOverlapResult {
  tool: 'physics_overlap';
  entities: EntityRow[];
}

/** `physics_fit`: a collider fitted to its entity's model -- the fields written, and the step. */
export interface PhysicsFitResult {
  tool: 'physics_fit';
  entity: EntityRow;
  collider: string;
  set: Record<string, number>;
  step: string | null;
  dropped?: string;
}


/** One step of the world's history, as `history_list` says it. */
export interface HistoryStepFacts {
  /** Its place, from 1 (the oldest kept). */
  n: number;
  label: string;
  /** Whose: the person's, Claude's in the panel (`Claude: …`), or an outside client's (`MCP: …`) -- the last two undone without `any`. */
  by: 'person' | 'Claude' | 'MCP';
  /** Done (under the person's place), or undone (redo brings it). */
  done: boolean;
}

/** `history_list`: the world's undo stack, and where the person is on it. */
export interface HistoryListResult {
  tool: 'history_list';
  steps: HistoryStepFacts[];
  /** Steps done: the person is after step `done`. */
  done: number;
  saved: boolean;
}

/** `history_undo`, `history_redo`: the steps taken back or done again. */
export interface HistoryMoveResult<T extends 'history_undo' | 'history_redo' = 'history_undo' | 'history_redo'> {
  tool: T;
  moved: string[];
  done: number;
}

// ---------------------------------------------------------------- M6: the Model tab (Docs/mcp.md §4)

/** A parameter as the model tools say it: its spec, and whether the record sets it (not the script's default). */
export interface ModelParamFacts {
  name: string;
  type: string;
  value: number | string | boolean;
  default: number | string | boolean;
  set: boolean;
  min?: number;
  max?: number;
  choices?: Array<number | string>;
  doc?: string;
}

/** A material as the model tools say it: as shown, whether the script declares it (`material{}`, editable), its parts. */
export interface ModelMaterialFacts {
  name: string;
  declared: boolean;
  line: number | null;
  parts: string[];
  baseColor: [number, number, number];
  metallic: number;
  roughness: number;
  emissive: [number, number, number];
  alphaMode: string;
}

/** An action the script declares (`action{}`): its name, rate and keys' times -- what `model_pose` keys into. */
export interface ModelActionFacts {
  name: string;
  fps: number;
  keys: number[];
  problem?: string;
}

/** The model open in the Model tab, as `model_info` says it. */
export interface ModelFacts {
  script: string;
  export: string | null;
  /** The build: ready, building, failed (with Gladius's first line), unmade, excluded, gone, offline, loading. */
  build: string;
  buildWords: string;
  error: string | null;
  parts: { count: number; names: string[]; selected: string[]; hidden: string[] };
  materials: ModelMaterialFacts[];
  /** The export's clips, and the script's actions. */
  clips: string[];
  actions: ModelActionFacts[];
  params: ModelParamFacts[] | null;
  /** The views show a preview, not the export (a parameter being tried, a save held for a turn). */
  previewing: boolean;
  /** The tab's history: steps and where it is. */
  history: { labels: string[]; done: number };
}

/** `model_open`: the script the Model tab opened, and its facts as they stand at once (its build may be on its way). */
export interface ModelOpenResult {
  tool: 'model_open';
  model: ModelFacts;
  /** A preview of a parameter not written, put away to open it (`discard`). */
  discarded: boolean;
}

/** `model_info`. */
export interface ModelInfoResult {
  tool: 'model_info';
  model: ModelFacts | null;
}

/** `model_params_set`: the step written -- the record's params, or baked into the script -- and the parameters after. */
export interface ModelParamsSetResult {
  tool: 'model_params_set';
  step: string;
  baked: string[];
  skipped: string[];
  params: ModelParamFacts[] | null;
  /** The file written: the record, or the script and its record (Undo this turn's). */
  files: string[];
  /** Never set: the Model tab's history is not the world's (`droppedWords`). */
  dropped?: string;
}

/** `model_preview`: a build at these parameters, its image (as `view_shot`'s model target draws it); nothing written. */
export interface ModelPreviewResult {
  tool: 'model_preview';
  params: Record<string, string>;
  width: number;
  height: number;
  mimeType: string;
  /** Base64. */
  data: string;
  notes: string[];
}

/** `model_export`: the export queued, as the tab's Export queues it; followed as one studio job. */
export interface ModelExportResult {
  tool: 'model_export';
  script: string;
  jobs: QueuedExport[];
  job: string | null;
  ended?: Array<{ source: string; state: string; error?: string }>;
}

/** `model_materials_set`: the step written into the script's `material{}`. */
export interface ModelMaterialsSetResult {
  tool: 'model_materials_set';
  step: string;
  material: string;
  files: string[];
  /** Never set: the Model tab's history is not the world's (`droppedWords`). */
  dropped?: string;
}

/** `model_pose`: the key written into the script's `action{}`, as K writes it. */
export interface ModelPoseResult {
  tool: 'model_pose';
  step: string;
  note: string;
  clip: string;
  time: number;
  files: string[];
  /** Never set: the Model tab's history is not the world's (`droppedWords`). */
  dropped?: string;
}

// ---------------------------------------------------------------- the calls, under /__agent/

/** `POST turn`. */
export interface TurnRequest {
  prompt: string;
  context?: TurnContext | null;
  images?: TurnImage[];
  /** The tab sending it (its hello's id): the editor tools' calls in this turn go to it. */
  tab?: string | null;
  /**
   * Tools refused for this turn's length, whatever the rules and Auto say -- the Git card's draft sends `DRAFT_DENY`
   * (`@vibe/editor`'s `studio/git/draft.ts`): the editing tools, Bash, the studio's writers -- an answer in words, no
   * file changed. `mcp__studio__writers` (`DenyWriters`) names every studio tool that is no read, as the catalogue
   * has them. A turn with any runs no review loop (there is nothing to review).
   */
  deny?: string[];
}

/** `POST turn`'s answer: the turn's uuid. */
export interface TurnAnswer {
  uuid: string;
}

/** `POST attach`: `retry`, the Retry button -- the only attach that starts a CLI again that failed or is not logged in. */
export interface AttachRequest {
  retry?: boolean;
}

/** `POST btw`: a side question about the conversation (`/btw`). Its answer comes as a `btw` entry with the same id. */
export interface BtwRequest {
  question: string;
}

/** `POST btw`'s answer. */
export interface BtwAnswer {
  id: string;
}

/**
 * `POST usage`: what `/usage` shows, asked afresh where the CLI is up -- its usage call (experimental in SDK 0.3.220)
 * and the context window -- else as last heard. `live`: the CLI's usage call answered just now.
 */
export interface UsageAnswer {
  usage: UsageFacts;
  live: boolean;
}

/** `POST answer`: a card's answer. `always` is the destination of an Always; `answers`, a question's, by question. */
export interface AnswerRequest {
  id: string;
  allow: boolean;
  always?: AlwaysDestination;
  answers?: Record<string, string | string[]>;
}

/** `POST settings`: any of them; the model through `setModel`, the effort through `applyFlagSettings`. */
export interface SettingsRequest {
  model?: string | null;
  effort?: string | null;
  review?: ReviewBar;
  level?: PermissionLevel;
  /** The project's, not the named conversation's: every conversation's state says it (`AgentSettings.fixBoot`). */
  fixBoot?: boolean;
  /** The project's too: what outside clients of `/__mcp` may do (`AgentSettings.outside`). */
  outside?: OutsideLevel;
  /**
   * The studio page's secret (`PageSecret`), which a change of `level` or `outside` must carry, with this
   * server's own `Origin`: those two are the person's, set in the studio -- never by a `curl`, Claude's own HTTP
   * tools or an outside client. No boundary against a local program that opens the HMR socket as a page would.
   */
  secret?: string;
}

/**
 * `POST rewind`. A real one (`dryRun: false`) passes what its preview listed:
 * a file is put back from the snapshot, or removed, only if it was shown.
 */
export interface RewindRequest {
  turn: string;
  dryRun: boolean;
  /** The preview's `changed`: put back from the turn's snapshot. Absent: whatever differs now. */
  changed?: string[];
  /** The preview's `made`: removed. Absent: none. */
  made?: string[];
}

/**
 * `POST rewind`'s answer, its paths relative to the project: the agent's
 * edits (`rewindFiles`, the `Edit`/`Write` checkpoints) and, from the turn's
 * snapshot, what a command changed or deleted -- this turn and those after it.
 */
export interface RewindAnswer {
  canRewind: boolean;
  error: string | null;
  /** The agent's edits put back: `rewindFiles`' files. */
  files: string[];
  /** Of `files`, those the turns made -- the first result naming each says `created`: putting them back removes them. */
  created: string[];
  added: number;
  removed: number;
  /** Files a command changed or deleted, put back from the turn's snapshot. */
  changed: string[];
  /** Files a command made, which the snapshot lacks: removed. */
  made: string[];
  /** Files the turns changed that nothing puts back: git ignores them, or the turn has no snapshot. */
  kept: string[];
  /** The turn's snapshot was found. */
  snapshot: boolean;
  /** A real rewind's files refused for a link where a file was. */
  skippedLinks: number | null;
  /**
   * Of the files above, those a later turn of another conversation named too
   * -- by that conversation's title: put back with the rest only as the
   * preview lists them, never silently. Absent from a server before conversations.
   */
  others?: { path: string; by: string }[];
  /**
   * Another conversation's turn is running, by its title: a real Undo is refused (409) until it ends -- its files
   * may be the ones put back, mid-edit, and its changes are in no result row yet. The preview says so.
   */
  busy?: string;
}

/**
 * `GET state?since=` and `POST attach`: the state, and the entries after
 * `since` -- of the conversation asked for (`?conversation=`; none, the
 * first) -- with its id and the list of every open one.
 */
export interface StateAnswer {
  state: AgentState;
  entries: Entry[];
  /** Absent from a server before conversations. */
  conversation?: string;
  conversations?: ConversationInfo[];
}

/** `GET conversations`, and each call that changes the list: the open conversations, in order. */
export interface ConversationsAnswer {
  conversations: ConversationInfo[];
  /** `POST conversations/new`'s: the one made. */
  conversation?: string;
}

// ---------------------------------------------------------------- skills

/** A new skill's name (`POST skills`): lowercase letters, digits and `-`, a letter or digit first, at most 41 -- the pipeline's `skills.ts` and the editor's name field hold it alike. */
export const SKILL_NAME = /^[a-z0-9][a-z0-9-]{0,40}$/;

/**
 * A skill Claude loads in this project (`GET skills`, Docs/agent.md §2 "Skills"): the project's own
 * (`.claude/skills/<name>/SKILL.md`, not a `vibe sync` copy), the plugin's (`vibe:vibe`, `vibe:gladius`: the
 * pipeline's `claude/skills/`), or the person's own, from outside the project.
 */
export interface SkillRow {
  /** As the SDK names it: a plugin's qualified, `vibe:gladius`. */
  name: string;
  /** `engine`: a skill `vibe sync` writes from the installed packages' pages (`engine`, `studio`), never edited. */
  source: 'project' | 'plugin' | 'engine' | 'user';
  /** Where it comes from, the package and version: the plugin's pipeline (`@vibe/pipeline 0.1.15`), a synced skill's pages' (`@vibe/editor 0.1.15, @vibe/engine 0.1.15, the project`). */
  from?: string;
  /** Its SKILL.md, relative to the project root -- what the Code card opens; '' outside the project (a user skill's always). */
  path: string;
  /** Its frontmatter's `description:`, else its body's first line; '' for a user skill. */
  description: string;
  /** The Code card may write it: the project's; the plugin's in source mode alone (the engine's own repository). */
  editable: boolean;
}

/** `GET skills`. */
export interface SkillsAnswer {
  /** The project's, the plugin's, then the person's own, each by name. */
  skills: SkillRow[];
  /** A conversation's `init` named the skills loaded: false, the person's own are not known yet (none listed). */
  heard: boolean;
}

/** `POST skills { name }`: the skill made, and when Claude has it. */
export interface NewSkillAnswer {
  row: SkillRow;
  /** "Claude loads it from its next conversation", or, a conversation's query told (`reloadSkills`), that it has it now. */
  note: string;
}

/** A read from another machine: the transcript holds the project's code. */
export interface Unavailable {
  available: false;
  why: string;
}

/** Streaming text, never kept: the `text` entry that follows replaces it. */
export interface Delta {
  text: string;
  sub: boolean;
}

/** A message of one conversation's: `conversation`, its id, where a server that has several says so. */
export type ConversationMessage = ({ entry: Entry } | { state: AgentState } | { delta: Delta } | { mcp: McpCall } | { terminal: TerminalPush }) & { conversation?: string };

/**
 * The push channel's `data`: a conversation's message, or the list of open
 * conversations whenever it changes (to pages that said `multi`). `{ mcp }`
 * goes to one tab only, the turn's.
 */
export type PushMessage = ConversationMessage | { conversations: ConversationInfo[] };

/** What a tab hears on the channel: a push, or -- to its socket alone -- the answer to its hello. */
export type TabMessage = PushMessage | { page: PageSecret };

/**
 * The answer to a studio tab's hello, to that socket alone and only to a page's (its upgrade carried this server's
 * `Origin`): a secret made once a server, which `POST settings` wants with a change of `level` or `outside`. Never in
 * an HTTP answer, so a `curl`, Claude's HTTP tools and an outside MCP client read none of it; a local program that
 * opens the HMR socket with that `Origin`, as a page would, is told it too (Docs/mcp.md §7 D1).
 */
export interface PageSecret {
  secret: string;
}
