/**
 * Claude's files, carried by the package (Docs/packages.md §9): the folder
 * `packages/pipeline/claude/`, a Claude Code plugin -- `.claude-plugin/plugin.json` (its `name`,
 * `vibe`), `skills/<name>/SKILL.md` (the engine's rules, `vibe`; modelling, `gladius`) and
 * `agents/code-critic.md` (the review loop's critic, Docs/agent.md §3).
 *
 * - **The editor's Claude loads it as a plugin**: `session.ts` passes `plugins: [{ type: 'local',
 *   path: CLAUDE_DIR }]`, in a project with no `.claude/` of its own as in the workspace. The SDK
 *   names what a plugin brings `<plugin>:<name>` -- `vibe:gladius`, `vibe:code-critic` (seen in
 *   `initializationResult()` and the `init` message, SDK 0.3.220) -- so `qualified` is how the
 *   session and the review loop know them.
 * - **A terminal session reads `.claude/`**, which `vibe sync` (`sync.ts`) writes from the same
 *   folder: the files `SYNCED` lists, each with a line saying it is written, not edited.
 *
 * Nothing at module level but constants.
 */
import { fileURLToPath } from 'node:url';

/** The plugin's folder: the pipeline's own `claude/`, beside its `src/` -- and beside `dist/` in the published form, where `vibe pack` copies it, so `../../claude` holds from `dist/agent/plugin.js` too (Docs/packages.md §6). */
export const CLAUDE_DIR = fileURLToPath(new URL('../../claude', import.meta.url));

/** The plugin's name, as its `.claude-plugin/plugin.json` has it: the prefix of every skill and agent it brings. */
export const PLUGIN = 'vibe';

/** A skill's or agent's name as the SDK lists it when the plugin brought it: `vibe:gladius`. */
export const qualified = (name: string): string => `${PLUGIN}:${name}`;

/** The files `vibe sync` writes into a project's `.claude/`, each at the same path under `CLAUDE_DIR`. */
export const SYNCED: readonly string[] = ['skills/vibe/SKILL.md', 'skills/gladius/SKILL.md', 'skills/gladius/api.md', 'agents/code-critic.md'];
