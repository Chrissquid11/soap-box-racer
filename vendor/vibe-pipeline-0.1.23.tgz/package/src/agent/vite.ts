/**
 * The agent's Vite plugin (Docs/agent.md §2): the dev server hosts Claude Code
 * for the editor's prompt panel -- one port, one process, the websocket the
 * page already holds.
 *
 * - **`apply: 'serve'`**: none of it is in a build. `configureServer` loads
 *   the conversations, their stores and the API -- `await import()`, so `vite build`,
 *   which loads this module with the config, loads none of them, nor the SDK
 *   that `session.ts` imports only when it starts one. It mounts the API on
 *   Vite's own middleware stack (after its CORS and host checks, before its
 *   transforms) and hears the page's websockets for the push, and each
 *   page's hello, which says which tab it is for the editor tools' relay.
 * - **The conversations live on `globalThis[Symbol.for('vibebase.agent')]`**
 *   (`conversations.ts`' holder: the sessions and the list, as data), made
 *   inside `configureServer`: editing `vite.config.ts` restarts the dev
 *   server in the same process (a change to the pipeline's own code restarts
 *   it as a new process when the turns end, `vibe dev` in `commands.ts`, and
 *   the conversations come back from disk), and the new plugin adopts every
 *   conversation, running
 *   this bundle's registry over them and re-pointing their push and the held
 *   reload; they go on. A holder from before conversations (`{ session }`)
 *   is adopted as the first. A session the old bundle made runs the old
 *   bundle's code until its Clear, when one of this bundle's takes over its
 *   log and settings. They are closed on the process's `exit` only, never on
 *   a server's `close`.
 * - **`hotUpdate` holds code for a turn** (`order: 'post'`, after the assets
 *   plugin's, so it is handed what that left): for the `client` environment,
 *   while any conversation's turn runs, a set Vite would answer with a reload,
 *   or a game module the boundary would rebuild, has its file join the held
 *   list, in the state, and the hook answers `[]`. An asset swapped live is
 *   `[]` already and passes untouched, and so does a set Vite applies in place
 *   (`appliedInPlace`, `hmr-walk.ts`: Vite's own walk up every importer path,
 *   shared with studio mode's hold): CSS, a module that accepts itself, one an
 *   importer accepts (`src/assets/hot.ts`' files) -- but never a module under
 *   `src/game/`, nor one whose path ends at the game's boundary
 *   (`src/game/live.ts`): the boundary accepting one means a
 *   world rebuild, not a patch, so it is held like the rest.
 *   When the last running turn ends -- its result, Stop, Clear, an error --
 *   each held file is replayed through Vite's watcher (a `change`), so Vite
 *   runs its own pipeline for it with no turn running and decides: a module
 *   the game's boundary accepts swaps into the running game (Docs/squidwright-
 *   implementation.md phase 0), the rest reloads every page (the LAN's too,
 *   whose updates were held as well); `POST reload` replays early. Every
 *   replay, a turn running or not, marks its file (`replaying`), and Vite's
 *   first call of the hook for it spends the mark and passes it, so a file
 *   replayed while a turn still runs is not held again. A session of an older
 *   bundle owed a reload gets one `full-reload`, after the replays of any files
 *   held beside it.
 *   An `index.html` edit is Vite's own reload, which no hook holds: the
 *   editor survives it (phase 2). It is the assets plugin's `holdBurst`, held
 *   for a turn.
 *
 * - **`/__mcp`, the studio's tools for outside clients** (Docs/mcp.md M7, `../mcp/http.ts`): mounted beside the API,
 *   behind a token made once a process (`../mcp/token.ts`, its 0600 file `.cache/agent/<port>/mcp.json` written once
 *   the server listens, gone at the process's exit) and the person's "Outside clients" setting (read-only by default).
 *
 * Nothing at module level: this imports only Node's `path`, Vite's types and the walk.
 */
import { relative, resolve, sep } from 'node:path';
import type { EnvironmentModuleNode, Plugin } from 'vite';
import type { HelloEvent, TerminalEvent } from './api-types.ts';
import type { Conversations, ConversationsHolder } from './conversations.ts';
import type { AgentServer } from './server.ts';
import type { SessionOptions } from './session.ts';
import type { McpKit } from '../mcp/registry.ts';
import { turnEnded, type TurnLink } from '../assets/turn-hold.ts';
import { appliedInPlace } from '../hmr-walk.ts';
import type { TokenKeeper } from '../mcp/token.ts';
import type { Runs } from '../mcp/runs.ts';
import type { TerminalPush } from './api-types.ts';
import type { Terminals, TerminalsOptions } from './terminal.ts';

/** Where the conversations are kept across Vite's in-process restarts. */
export const AGENT_KEY = Symbol.for('vibebase.agent');

/** What `globalThis[AGENT_KEY]` holds: the conversations, as data -- and, from before them, one session. */
export interface AgentHolder extends ConversationsHolder {
  /** Its process's exit closes every conversation: hooked once. */
  exitHooked?: boolean;
  /** The `/__mcp` endpoint's token (Docs/mcp.md M7): made once a process, kept across an in-process restart; its file goes with the process. */
  mcp?: TokenKeeper;
  /** Terminal runs' tokens (Docs/terminal.md D6): kept across an in-process restart, as their terminals are. */
  runs?: Runs;
  /** The conversations' terminals (Docs/terminal.md): their PTYs live with the process, across an in-process restart. */
  terminals?: Terminals;
  /** Where the terminals' output goes: this bundle's push, re-pointed on a restart. */
  terminalPush?: (conversation: string, push: TerminalPush) => void;
  /** This bundle's server's port as it listens; null before. */
  listening?: () => number | null;
}

export interface AgentPluginOptions {
  /** More for the session: a test's stand-in SDK, git, store. */
  session?: Partial<Omit<SessionOptions, 'root' | 'port' | 'carry'>>;
  /** No `.cache/agent/<port>/`: a test's. */
  noStore?: boolean;
  /** Told the API once it is made: a test's handle. */
  onServer?: (server: AgentServer) => void;
  /** Told the conversations once made: a test's handle. */
  onConversations?: (conversations: Conversations) => void;
  /** The `/__mcp` endpoint's SDK makings (`tool`, `createSdkMcpServer`): a test's stand-in. Default: the agent SDK's own. */
  mcpKit?: () => Promise<McpKit>;
  /** The `globalThis` key: a test's own. */
  key?: symbol;
  /** The terminals' stand-ins (Docs/terminal.md): a test's PTY, command, transcript. */
  terminal?: Partial<Pick<TerminalsOptions, 'pty' | 'command' | 'messages' | 'modified' | 'graceMs'>>;
  /**
   * The project's own tool folders (`vibe({ tools })`, `src/tools` when not said): their skill pages join the `studio`
   * skill this writes into `.claude/skills/` (`../skills/install.ts`).
   */
  tools?: readonly string[];
  /**
   * The link with the assets plugin for a Claude turn (`turn-hold.ts`,
   * Docs/modeler.md M21, D110): told whether a turn runs, told when the last
   * ends, and asked whether a turn's Gladius scripts build.
   */
  link?: TurnLink;
}

export function agent(options: AgentPluginOptions = {}): Plugin {
  let root = resolve('.');
  /**
   * Files being replayed, relative to the root as held: each is marked before its emit and passes `hotUpdate`
   * once, a turn running or not ("Reload now") -- the mark is spent on Vite's first call of the hook for it. One
   * Vite never calls for (an earlier plugin's `hotUpdate` threw, `hmr: false`, a path Vite short-circuits) stays,
   * and that file's next change during a turn passes the hold once: bounded, since a release with files to replay
   * clears the marks before making its own (the previous round's hooks have long run), so a stale mark never
   * outlives the next such release. An owed `full-reload` alone clears nothing: it may follow a round's marks
   * before Vite's watcher handlers have run.
   */
  const replaying = new Set<string>();
  /**
   * In place for the hold's purpose (`appliedInPlace`, Vite's own walk up the importers, `hmr-walk.ts`): no dead end
   * on any path, and no boundary the game's (`src/game/live.ts`) -- a world rebuild, not a patch, held like a reload,
   * as is any module under `src/game/` itself.
   */
  const inPlaceForHold = (modules: readonly EnvironmentModuleNode[]): boolean => !modules.some((m) => m.file !== null && rel(m.file).startsWith('src/game/')) && appliedInPlace(modules, rel, false);
  const key = options.key ?? AGENT_KEY;
  const g = globalThis as unknown as Record<symbol, AgentHolder | undefined>;
  /** A path from the watcher, relative to the root with `/`. */
  const rel = (file: string): string => {
    const r = relative(root, file);
    return r === '' || r.startsWith('..') ? file : r.split(sep).join('/');
  };

  /** This instance's registry, once its server is configured. */
  let registry: Conversations | undefined;
  return {
    name: 'agent',
    apply: 'serve',
    configResolved(config) {
      root = config.root;
    },
    async configureServer(server) {
      const { createSession, importSdk } = await import('./session.ts');
      const { createStore } = await import('./store.ts');
      const { createConversations } = await import('./conversations.ts');
      const { createAgentServer } = await import('./server.ts');
      const { createJobs } = await import('../mcp/jobs.ts');
      const { createEndpoint } = await import('../mcp/http.ts');
      const { createTokenKeeper, newToken } = await import('../mcp/token.ts');
      const { createRuns } = await import('../mcp/runs.ts');
      const { CONTEXT_MS, promptContext } = await import('./terminal-context.ts');
      const { createTerminals } = await import('./terminal.ts');
      const { agentEnv, cliVersion, findClaude } = await import('./env.ts');
      const { brief } = await import('./turn.ts');
      const { reposIn, ENGINE } = await import('./changes.ts');
      const { CLAUDE_DIR } = await import('./plugin.ts');
      const { resolveModels } = await import('./turn.ts');
      const { studioUrl } = await import('../mcp/words.ts');
      const { realpathSync } = await import('node:fs');
      const { allowedHosts } = await import('../assets/http.ts');
      const { syncSkills } = await import('../skills/install.ts');
      /** This server's own `server.allowedHosts`, as every route's `Host` check reads it. */
      const hosts = (): readonly string[] => allowedHosts(server.config.server?.allowedHosts);
      const port = (): number => server.config.server.port ?? 5190;
      const link = options.link;
      let holder = g[key];
      if (!holder) {
        holder = {};
        g[key] = holder;
      }
      const held = holder;
      // The studio tools' jobs: one registry for the process, kept across a restart as the conversations are -- but
      // the old bundle's running jobs failed: the work that ran them went with it, and could never end them now.
      held.jobs?.abandon('the dev server restarted while it ran: start it again');
      const jobs = (held.jobs ??= createJobs());
      // The `/__mcp` endpoint's token: one a process (Docs/mcp.md M7), its file written once the server listens.
      const keeper = (held.mcp ??= createTokenKeeper(root, newToken()));
      // Terminal runs' tokens (Docs/terminal.md D6): one a conversation in the terminal, the column's list on /__mcp.
      const runs = (held.runs ??= createRuns());
      // The conversations' terminals (Docs/terminal.md): made once a process, their output to this bundle's push.
      const standIn = process.env.VIBE_TERMINAL_COMMAND;
      const terminals = (held.terminals ??= createTerminals({
        root,
        // The port the server listens on (Vite may have moved off the one asked): what the run's CLI calls.
        port: () => {
          const address = g[key]?.listening?.();
          return address ?? port();
        },
        runs,
        env: () => (options.session?.env ?? (() => agentEnv()))(),
        findClaude: (env) => (options.session?.findClaude ?? findClaude)(env),
        // The CLI's version, for the hooks its settings may name (`STOP_FAILURE_SINCE`); a stand-in's is unknown.
        version: (file, env) => cliVersion(file, env),
        // A stand-in in claude's place (Docs/terminal.md §4: the checks'): a script run by this node, or a program.
        command: options.terminal?.command ?? (standIn ? (/\.(m?js|ts)$/.test(standIn) ? [process.execPath, standIn] : [standIn]) : null),
        messages: options.terminal?.messages ?? (async (id) => ((await importSdk()) as unknown as { getSessionMessages(id: string, o: { dir: string }): Promise<import('./terminal.ts').SessionLine[]> }).getSessionMessages(id, { dir: root })),
        modified: options.terminal?.modified ?? (async (id) => (await ((await importSdk()) as unknown as { getSessionInfo(id: string, o: { dir: string }): Promise<{ lastModified: number } | undefined> }).getSessionInfo(id, { dir: root }))?.lastModified ?? null),
        push: (conversation, push) => g[key]?.terminalPush?.(conversation, push),
        brief: () => brief(port(), reposIn(root).list.some((r) => r.prefix === `${ENGINE}/`)),
        plugin: CLAUDE_DIR,
        node: process.execPath,
        ...(options.terminal?.pty ? { pty: options.terminal.pty } : {}),
        ...(options.terminal?.graceMs !== undefined ? { graceMs: options.terminal.graceMs } : {}),
        log: (line) => server.config.logger?.info(line),
      }));
      if (!held.exitHooked) {
        held.exitHooked = true;
        process.once('exit', () => {
          for (const c of g[key]?.open ?? []) c.session.close();
          g[key]?.mcp?.remove();
          g[key]?.terminals?.closeAll();
        });
      }
      // The engine and studio skills (Docs/skills.md §3): the installed packages' pages and the project's tools', written
      // into .claude/skills/ as `vibe sync` writes them -- now, and again before each turn, so a page saved since reaches
      // it (the session has the query up read its skills again when anything changed). Only a changed file is written.
      const tools = options.tools ?? ['src/tools'];
      // Every conversation compares the skills' digest with the one its query last read: a change found by one turn, or
      // written by a terminal's `vibe sync` since, reaches each conversation's next turn.
      const skills = async (): Promise<{ changed: boolean; digest: string }> => {
        const done = await syncSkills(root, tools);
        if (done.changed) server.config.logger?.info(`[skills] .claude/skills/ engine and studio written again: ${done.wrote.length} files${done.removed.length > 0 ? `, ${done.removed.length} gone` : ''}`);
        return { changed: done.changed, digest: done.digest };
      };
      void skills().catch((err: unknown) => server.config.logger?.warn(`[skills] not written: ${err instanceof Error ? err.message : String(err)}`));
      // This bundle's registry over what the holder keeps: an in-process restart adopts every conversation.
      const conversations = createConversations(held, {
        root,
        port,
        current: createSession,
        disk: !options.noStore,
        store: (id, moved) => createStore(root, port(), { id, moved }),
        make: (made) => createSession({ root, port, skills, ...(link ? { check: (paths) => link.check(paths), held: () => link.held } : {}), ...options.session, ...made }),
      });
      // A conversation left in the person's own terminal by the process before (Docs/terminal.md D5): its run's token read
      // back, so its CLI keeps the studio's tools and the hook -- or, with none to read, marked not live and said.
      // Once the server listens: the port compared is the one the CLI there calls.
      const adoptAll = (): void =>
        void conversations.ready.then(async () => {
          for (const info of conversations.list()) {
            const c = conversations.get(info.id);
            await c.session.ready;
            if (c.session.state().terminal?.where === 'own') await terminals.adopt(c).catch(() => false);
          }
        });
      if (server.httpServer?.listening) adoptAll();
      else server.httpServer?.once('listening', adoptAll);
      const api = createAgentServer({
        conversations,
        port: () => server.config.server.port,
        hosts,
        skills: { root },
        terminals,
        // A terminal run's hook (Docs/terminal.md D7): the editor's facts as a column turn has them, worded for its prompt.
        terminal: {
          find: (token) => runs.find(token),
          context: async () => promptContext(await api.relay(null, { tool: 'studio_context', args: {}, turn: null, use: null }, CONTEXT_MS), (keys) => resolveModels(root, keys), studioUrl(port())),
          // A turn there begun, ended, failed or asking (Docs/ai-panel.md §8): the conversation's tab and the AI button say it.
          turn: (conversation, event) => {
            // A conversation closed meanwhile: `get` refuses, nothing to tell.
            try {
              conversations.get(conversation).session.terminalTurn(event);
            } catch {
              // Gone.
            }
          },
        },
      });
      conversations.host = {
        push: (message) => api.push(message),
        // The held code replayed, not answered with a `full-reload`: Vite's own pipeline runs for each file with no turn
        // running -- `hotUpdate` below passes it -- and decides, a swap for a module the game's boundary accepts, a reload
        // for the rest; `appliedInPlace` and the hold are unchanged. A file deleted during the turn is a `change` of a
        // missing file, which Vite reports and moves on from (an `unlink` replay is a later refinement). Nothing to
        // replay is a session of an older bundle that held code itself and asked for its reload (`owed`): no file list,
        // so the one reload. Each file is marked before its emit (`replaying`, above: what the mark is and when it is
        // spent or cleared).
        reload: (files) => {
          if (files.length === 0) {
            server.environments.client.hot.send({ type: 'full-reload', path: '*' });
            return;
          }
          replaying.clear();
          for (const file of files) {
            replaying.add(file);
            server.watcher.emit('change', resolve(root, file));
          }
        },
        editor: (tab, call, deadline, late) => api.relay(tab, call, deadline, late),
        jobs,
        // The Problems card's count, as the studio routes' plugin hands it to this holder (`ConversationsHolder.problems`):
        // no studio routes, not known.
        problems: () => held.problems?.() ?? null,
        // The assets server's work in-process, as the assets plugin hands it to this holder: the asset tools' server path.
        assets: () => held.assets?.() ?? null,
        // The studio routes' work in-process, as the studio plugin hands it to this holder: the studio tools'.
        studio: () => held.studio?.() ?? null,
        // The project's own MCP tools, as the last studio tab declared them in its hello.
        projectTools: () => api.projectTools(),
        // The last turn over (after a turn left broken was sent back, D110): the Gladius exports held for it made now,
        // resolving once they have ended and the watcher has seen their files -- the held code is replayed after that
        // (`turnsEnded`), so a page it reloads finds the new model. Then whoever waits for the turns' end is told
        // (`onTurnEnd`: `vibe dev`'s restart owed to a pipeline change, which waits its grace past the replay).
        turnsOver: async () => {
          // Told whatever the exports did: a rejected `over()` still owes `vibe dev` its restart.
          try {
            return (await link?.over()) ?? [];
          } finally {
            if (link) turnEnded(link);
          }
        },
        // What "Reload now" waits for: exports still being made (a turn's end's, or a list kept on disk at a start).
        exporting: () => link?.exporting ?? null,
      };
      // A Gladius script's export is held while any conversation's turn runs (M21).
      if (link) {
        link.turns = () => conversations.running();
        // A restart's exit (`vibe dev`, commands.ts) waits for the conversations' queued writes.
        link.flushed = () => conversations.flushed();
      }
      // Outside clients (Docs/mcp.md M7): the same registry on /__mcp, behind the token and the person's setting; the
      // page tools relayed to the last studio tab as an outside client's (`MCP: …` steps), no turn, no transcript row.
      const endpoint = createEndpoint({
        token: () => keeper.current(),
        hosts,
        level: async () => {
          await conversations.ready;
          return conversations.outside();
        },
        kit: options.mcpKit ?? (async () => (await importSdk()) as unknown as McpKit),
        context: {
          call: (tool, args, use, deadline) => api.relay(null, { tool, args, turn: null, use, outside: true }, deadline).then(({ tab: _tab, ...answer }) => answer),
          models: (keys) => resolveModels(root, keys),
          url: () => studioUrl(port()),
          jobs,
          problems: () => held.problems?.() ?? null,
          root: () => root,
          assets: () => held.assets?.() ?? null,
          studio: () => held.studio?.() ?? null,
          projectTools: () => api.projectTools(),
        },
        // A terminal run's token (Docs/terminal.md D6): the column's list, page tools relayed as the column's (`Claude: …`).
        run: (token) => runs.find(token),
        runContext: {
          call: (tool, args, use, deadline) => api.relay(null, { tool, args, turn: null, use }, deadline).then(({ tab: _tab, ...answer }) => answer),
          models: (keys) => resolveModels(root, keys),
          url: () => studioUrl(port()),
          jobs,
          problems: () => held.problems?.() ?? null,
          root: () => root,
          assets: () => held.assets?.() ?? null,
          studio: () => held.studio?.() ?? null,
          projectTools: () => api.projectTools(),
        },
        place: {
          root,
          real: (path) => {
            try {
              return realpathSync(path);
            } catch {
              return null;
            }
          },
        },
      });
      server.httpServer?.once('listening', () => {
        const address = server.httpServer?.address();
        keeper.publish(typeof address === 'object' && address !== null ? address.port : port());
      });
      server.httpServer?.once('close', () => void endpoint.close());
      // A run ended: its MCP sessions closed with its token.
      const offRevoke = runs.onRevoke((conversation) => void endpoint.closeRun(conversation));
      server.httpServer?.once('close', offRevoke);
      options.onServer?.(api);
      registry = conversations;
      options.onConversations?.(conversations);
      // Added here, not from a returned hook: after Vite's CORS and host checks, before its transforms. Vite 8 adds its
      // host check (`hostValidationMiddleware`) before any `configureServer` runs, but only while `server.allowedHosts`
      // is not `true` and the server is not HTTPS: every route checks `Host` itself as well (`assets/http.ts`' `guardHost`).
      // `/__mcp` first (`endpoint`), then the API under `/__agent/`.
      server.middlewares.use((req, res, next) => {
        endpoint
          .handle(req, res)
          .then((handled) => handled || api.handle(req, res))
          .then((handled) => {
            if (!handled) next();
          }, next);
      });
      server.ws.on('connection', (socket, req) => api.connection(socket, req));
      // Which tab a socket is (Docs/agent.md §8): the editor tools' calls go to the turn's alone.
      const hello: HelloEvent = 'vibebase:agent:hello';
      server.ws.on(hello, (data: unknown, client) => api.hello(client.socket, data));
      // A terminal's keys and size from a page (Docs/terminal.md D3), and its output to this bundle's push.
      held.terminalPush = (conversation, push) => api.push({ terminal: push, conversation });
      held.listening = () => {
        const address = server.httpServer?.address();
        return typeof address === 'object' && address !== null ? address.port : null;
      };
      const keys: TerminalEvent = 'vibebase:agent:terminal';
      server.ws.on(keys, (data: unknown, client) => api.terminal(client.socket, data));
    },
    hotUpdate: {
      order: 'post',
      handler({ file, modules }) {
        // Once, for the page: the `ssr` environment's set is Vite's.
        if (this.environment.name !== 'client') return;
        // A file the host is replaying passes once: "Reload now" replays with a turn still running, and holding it
        // again would refill the list and reach no page. Before the running check, so the mark is spent either way
        // (`replaying`, above).
        if (replaying.delete(rel(file))) return;
        // No turn of any conversation's, or nothing that would reload (an asset swapped live, CSS, a module accepted
        // where it is -- `inPlaceForHold`): untouched.
        if (!registry?.running() || modules.length === 0 || inPlaceForHold(modules)) return;
        registry.hold(rel(file));
        return [];
      },
    },
  };
}
