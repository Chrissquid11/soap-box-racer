/**
 * A turn's files (Docs/agent.md §3, "The files"): what git says the turn
 * changed, and the whole `Edit` and `Write` inputs its rows unfold to.
 *
 * - **A baseline as the turn starts**, touching no file: `git stash create`
 *   (a commit of the tree as it is, on no ref -- `HEAD` when it prints
 *   nothing, the tree being clean), the untracked files
 *   (`git ls-files -o --exclude-standard`) and what was uncommitted
 *   (`git status --porcelain`).
 * - **What differs, at the critic's launch and at the turn's end**:
 *   `git diff --numstat <base>` against the working tree, the untracked files
 *   new since (their lines counted here), and the paths the turn's `Edit`
 *   and `Write` rows named that git does not see (ignored, or outside it).
 *   What a `Bash` row changed is found by the baseline; what was uncommitted
 *   before is named as such -- the designer's own work, never the turn's. A
 *   Git LFS file (`git check-attr filter` is `lfs`) is binary, as git says of
 *   the rest: its numstat is its pointer's, `+1 −1` of a hash.
 *   A file gone since -- tracked, or untracked before the turn -- is listed
 *   too, `deleted`.
 * - **A snapshot for Undo this turn** (§2, A real undo): as a person's turn
 *   starts, the working tree as git sees it -- tracked and untracked, never
 *   ignored -- is written as a tree through an index of its own, touching
 *   neither the tree nor the real index, and kept on
 *   `refs/vibebase/turns/<port>/<turn>`, where gc keeps it: a folder of refs
 *   per dev server, so one port's turns never prune another's, and Clear (or
 *   a conversation closed) deletes its own turns' (`dropSnapshots`), never
 *   another conversation's. The last 20 turns' are kept, a port's, its
 *   conversations' together, the turn ids being time-ordered. The index is
 *   kept too, one per port (`<git dir>/vibebase-index-<port>`), seeded from
 *   the real one the first time: git trusts what it has stat'ed already, so a
 *   turn re-reads only the files changed since the last -- the untracked ones
 *   too, which the real index has none of. The port's conversations share it,
 *   so the work through it goes one at a time (`serially`): never two `git add
 *   -A` on one index at once. Undo then lists what differs from it among
 *   the files the turns named (`sinceSnapshot`) -- what a command changed or
 *   deleted, which no `Edit` checkpoint has -- and puts those back from it
 *   (`putBack`): each blob read with `git cat-file --filters` (a Git LFS file
 *   comes back whole) and written, a file it made since removed only when the
 *   preview listed it.
 * - **Whole inputs kept apart**, in memory: the last 20 turns' `Edit` and
 *   `Write` inputs, 4 MB at most, for `GET input?id=`; after a restart, "not
 *   kept".
 *
 * **Two repositories in source mode** (Docs/squidwright-implementation.md
 * 1.8): a project whose engine is the submodule `engine/` is two repositories,
 * the project's and the engine's, and git in the one says nothing of the
 * other's files (the outer sees `engine` as one gitlink). `gitRoots` lists
 * them; `Repos` -- made once a session -- runs each step above per repository
 * and merges the answers in one place, every path of the engine's prefixed
 * `engine/` as the project names it, and a path under `engine/` handed to the
 * engine's git without it (`split`). What the outer says of `engine` itself
 * (its gitlink, or `engine/` untracked) is left out: the inner says it file by
 * file. Each repository keeps its own snapshots, on its own refs.
 *
 * Git runs with `GIT_OPTIONAL_LOCKS=0`, so a status taken while the agent's
 * own git runs never contends for the index lock. Not a repository, or no
 * git: no baseline, no snapshot, and the turn's files are its rows' paths
 * alone.
 */
import { execFile, spawn } from 'node:child_process';
import { randomBytes, randomUUID } from 'node:crypto';
import { createWriteStream, existsSync } from 'node:fs';
import { chmod, copyFile, lstat, mkdir, open, rename, rm, symlink } from 'node:fs/promises';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import type { TurnFile } from './api-types.ts';

/** What a git call answered. */
export interface GitResult {
  code: number;
  stdout: string;
  stderr: string;
}

/** How a git call runs: more environment (`GIT_INDEX_FILE`), its output written to a file as bytes rather than answered. */
export interface GitOptions {
  env?: Record<string, string>;
  /** A file its stdout is written to, whole: a blob put back. Its answer's `stdout` is then empty. */
  out?: string;
  /** Its stdin, whole: a commit's message (`git commit -F -`, the Git card's). */
  input?: string;
}

/** Git in the project: a test's stand-in, or `gitIn(root)`. */
export type Git = (args: readonly string[], options?: GitOptions) => Promise<GitResult>;

/**
 * Work on a port's kept index, one at a time: the open conversations share it,
 * and two `git add -A` through one index at once would have the second fall
 * back to a fresh copy -- or, racing its lock, fail. `serially()` makes one.
 */
export type Serial = <T>(work: () => Promise<T>) => Promise<T>;

/** A queue: each piece of work starts once the one before it is done, failed or not. */
export function serially(): Serial {
  let queue: Promise<unknown> = Promise.resolve();
  return <T>(work: () => Promise<T>): Promise<T> => {
    const next = queue.then(work, work);
    queue = next.catch(() => {});
    return next;
  };
}

/** Work run at once: no other conversation shares the index. */
const atOnce: Serial = (work) => work();

/** The real git, in `root`. A git that cannot start answers code 127. */
export function gitIn(root: string): Git {
  return (args, options = {}) =>
    new Promise((done) => {
      const env = { ...process.env, GIT_OPTIONAL_LOCKS: '0', ...options.env };
      if (options.out !== undefined) {
        // Bytes to a file, never through a string: a blob may be binary, and big.
        const file = createWriteStream(options.out);
        const child = spawn('git', [...args], { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
        let stderr = '';
        child.stderr.on('data', (d: Buffer) => void (stderr += d.toString('utf8')));
        child.stdout.pipe(file);
        let code = 127;
        let ends = 0;
        const end = (): void => void (++ends === 2 && done({ code, stdout: '', stderr }));
        child.on('error', () => void file.end());
        child.on('close', (c) => {
          code = typeof c === 'number' ? c : 127;
          end();
        });
        file.on('close', end);
        return;
      }
      const child = execFile('git', [...args], { cwd: root, env, maxBuffer: 64 * 1024 * 1024, encoding: 'utf8' }, (err, stdout, stderr) => {
        const code = err === null ? 0 : typeof (err as { code?: unknown }).code === 'number' ? ((err as { code: number }).code) : 127;
        done({ code, stdout, stderr });
      });
      // A git that reads no stdin closes it early: the write's EPIPE is no failure of the call's.
      child.stdin?.on('error', () => {});
      child.stdin?.end(options.input ?? '');
    });
}

// ---------------------------------------------------------------- a turn's snapshot (Undo this turn)

/** Where the turns' snapshots are kept: a tree on a ref of its own, which gc keeps -- in a folder per port. */
export const SNAPSHOTS = 'refs/vibebase/turns/';

/** Where one dev server's snapshots are kept: its port's folder of refs, so one conversation's turns never prune another's. */
export const snapshotsOf = (port: number): string => `${SNAPSHOTS}${port}/`;

/** Snapshots kept: the last turns'. */
export const KEEP_SNAPSHOTS = 20;

/**
 * A turn's id: a UUID whose first 48 bits are the time (version 7), so the
 * snapshots' refs, named by it, sort as they were made. The SDK takes it as
 * the user message's `uuid`.
 */
export function turnId(now = Date.now()): string {
  const b = randomBytes(16);
  b.writeUIntBE(now, 0, 6);
  b[6] = (b[6]! & 0x0f) | 0x70;
  b[8] = (b[8]! & 0x3f) | 0x80;
  const hex = b.toString('hex');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

/** The working tree through `index`: every change added to it, then written as a tree. Null where git would not (the index locked, or broken). */
async function writeTree(git: Git, index: string): Promise<{ tree: string | null; locked: boolean }> {
  const env = { GIT_INDEX_FILE: index };
  const added = await git(['add', '-A'], { env });
  if (added.code !== 0) return { tree: null, locked: /\.lock\b/.test(added.stderr) };
  const tree = await git(['write-tree'], { env });
  return { tree: tree.code === 0 ? tree.stdout.trim() : null, locked: false };
}

/**
 * The working tree as git sees it -- tracked and untracked, never ignored --
 * as a tree object, through an index of its own (`GIT_INDEX_FILE`): neither
 * the tree nor the real index is touched. Given a port, the index is that dev
 * server's, kept between turns (`<git dir>/vibebase-index-<port>`, seeded from
 * the real one the first time), so git re-reads only what changed since it
 * last looked -- untracked files too; else, or should that one be locked by
 * another snapshot under way, a fresh copy of the real index, dropped after.
 * Null where git cannot.
 */
export async function treeOf(git: Git, root: string, port?: number, serial: Serial = atOnce): Promise<string | null> {
  const [dir, real] = await Promise.all([git(['rev-parse', '--absolute-git-dir']), git(['rev-parse', '--git-path', 'index'])]);
  if (dir.code !== 0 || real.code !== 0) return null;
  const realIndex = resolve(root, real.stdout.trim());
  if (port !== undefined) {
    const kept = join(dir.stdout.trim(), `vibebase-index-${port}`);
    // One at a time through the port's index: every conversation of the dev server snapshots through it.
    const tree = await serial(async () => {
      if (!(await exists(kept))) await copyFile(realIndex, kept).catch(() => {});
      const written = await writeTree(git, kept);
      // Broken -- not merely busy: made afresh next time.
      if (written.tree === null && !written.locked) await rm(kept, { force: true });
      return written.tree;
    });
    if (tree !== null) return tree;
  }
  const index = join(dir.stdout.trim(), `vibebase-index-${randomUUID()}`);
  try {
    try {
      await copyFile(realIndex, index);
    } catch {
      // No index yet: an empty one.
    }
    return (await writeTree(git, index)).tree;
  } finally {
    await rm(index, { force: true });
  }
}

/** The turn's snapshot taken and kept on its port's ref, the oldest of that port's past `KEEP_SNAPSHOTS` let go. Its tree, or null. */
export async function snapshot(git: Git, root: string, turn: string, port: number, keep = KEEP_SNAPSHOTS, serial: Serial = atOnce): Promise<string | null> {
  const tree = await treeOf(git, root, port, serial);
  const refs = snapshotsOf(port);
  if (tree === null || (await git(['update-ref', `${refs}${turn}`, tree])).code !== 0) return null;
  const all = await snapshotRefs(git, port);
  for (const old of all.slice(0, Math.max(0, all.length - keep))) await git(['update-ref', '-d', old]);
  return tree;
}

/** A port's snapshot refs, oldest first. */
async function snapshotRefs(git: Git, port: number): Promise<string[]> {
  const refs = await git(['for-each-ref', '--sort=refname', '--format=%(refname)', snapshotsOf(port)]);
  return refs.code === 0 ? refs.stdout.split('\n').filter((r) => r !== '') : [];
}

/**
 * A conversation's snapshots let go (Clear, a tab closed): its Undo goes with
 * it. `turns`, its turns' ids: those alone -- another conversation's on the
 * same port stay; left out, every one of the port's. How many.
 */
export async function dropSnapshots(git: Git, port: number, turns?: Iterable<string>): Promise<number> {
  const mine = turns === undefined ? null : new Set([...turns].map((t) => `${snapshotsOf(port)}${t}`));
  const all = (await snapshotRefs(git, port)).filter((ref) => mine === null || mine.has(ref));
  for (const ref of all) await git(['update-ref', '-d', ref]);
  return all.length;
}

/** What differs from a turn's snapshot, among the files the turns named: put back from it, or removed. */
export interface SinceSnapshot {
  /** The turn's snapshot is there (pruned, or never taken -- no git -- it is not). */
  found: boolean;
  /** Changed or deleted since: put back from the snapshot. */
  changed: string[];
  /** Made since, which the snapshot lacks: removed, if the preview listed them. */
  made: string[];
}

/**
 * The files among `named` -- what the turn and those after it changed, by
 * their result rows -- that differ from the turn's snapshot now, `spared`
 * (the `Edit` checkpoints' files, which `rewindFiles` puts back) left out.
 * Only files git sees: one it ignores is in no snapshot, and never touched.
 */
export async function sinceSnapshot(git: Git, root: string, turn: string, named: ReadonlySet<string>, spared: ReadonlySet<string>, port: number, serial: Serial = atOnce): Promise<SinceSnapshot> {
  const ref = await git(['rev-parse', '--verify', '--quiet', `${snapshotsOf(port)}${turn}^{tree}`]);
  if (ref.code !== 0) return { found: false, changed: [], made: [] };
  const now = await treeOf(git, root, port, serial);
  if (now === null) return { found: true, changed: [], made: [] };
  const diff = await git(['diff-tree', '-r', '-z', '--no-renames', '--name-status', '--relative', ref.stdout.trim(), now]);
  const changed: string[] = [];
  const made: string[] = [];
  const parts = fields(diff.stdout);
  for (let i = 0; i + 1 < parts.length; i += 2) {
    const [status, path] = [parts[i]!, parts[i + 1]!];
    if (!named.has(path) || spared.has(path)) continue;
    (status === 'A' ? made : changed).push(path);
  }
  return { found: true, changed: changed.sort(), made: made.sort() };
}

/**
 * Files put back from a turn's snapshot: each blob through `git cat-file
 * --filters` (smudged, so a Git LFS file is its content, not its pointer),
 * written beside the file and renamed over it, its mode as it was; a link a
 * link again. Then `made`, files the snapshot lacks, removed -- a file, never
 * a folder. What could not be done is answered, not thrown.
 */
export async function putBack(git: Git, root: string, turn: string, changed: readonly string[], made: readonly string[], port: number): Promise<{ done: string[]; failed: string[] }> {
  const done: string[] = [];
  const failed: string[] = [];
  const prefix = (await git(['rev-parse', '--show-prefix'])).stdout.trim();
  const tree = `${snapshotsOf(port)}${turn}`;
  for (let i = 0; i < changed.length; i += ATTR_BATCH) {
    const batch = changed.slice(i, i + ATTR_BATCH);
    const listed = await git(['--literal-pathspecs', 'ls-tree', '-z', '--full-tree', tree, '--', ...batch.map((p) => prefix + p)]);
    const found = new Set<string>();
    for (const row of fields(listed.stdout)) {
      const tab = row.indexOf('\t');
      const [mode, type, object] = row.slice(0, tab).split(' ');
      const full = row.slice(tab + 1);
      const path = full.slice(prefix.length);
      const file = join(root, path);
      found.add(path);
      try {
        await mkdir(dirname(file), { recursive: true });
        if (type !== 'blob') throw new Error(`${type} at ${path}`);
        if (mode === '120000') {
          const target = await git(['cat-file', 'blob', object!]);
          if (target.code !== 0) throw new Error(target.stderr);
          await rm(file, { force: true, recursive: false });
          await symlink(target.stdout, file);
        } else {
          const temp = `${file}.vibebase-undo-${randomUUID().slice(0, 8)}`;
          const blob = await git(['cat-file', '--filters', `${tree}:${full}`], { out: temp });
          if (blob.code !== 0) {
            await rm(temp, { force: true });
            throw new Error(blob.stderr);
          }
          await chmod(temp, mode === '100755' ? 0o755 : 0o644);
          await rename(temp, file);
        }
        done.push(path);
      } catch {
        failed.push(path);
      }
    }
    for (const path of batch) if (!found.has(path)) failed.push(path);
  }
  for (const path of made) {
    try {
      const file = join(root, path);
      const stat = await lstat(file);
      if (stat.isDirectory()) throw new Error('a folder');
      await rm(file, { force: true });
      done.push(path);
    } catch {
      failed.push(path);
    }
  }
  return { done, failed };
}

/** The tree as the turn found it. */
export interface Baseline {
  /** The commit to diff against; null where git has none (not a repository, no commit yet). */
  base: string | null;
  /** The project's folder under the repository's top, `''` at it: git's paths are the top's. */
  prefix: string;
  untracked: string[];
  /** Uncommitted when the turn began, tracked or not. */
  dirty: string[];
}

/** NUL-separated fields, the empty last one dropped. */
export const fields = (text: string): string[] => text.split('\0').filter((s) => s !== '');

/** `git status --porcelain -z`'s paths: `XY path`, a rename's or copy's old path a field of its own after it. */
function statusPaths(text: string): string[] {
  const out: string[] = [];
  const parts = text.split('\0');
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i]!;
    if (part.length < 4) continue;
    out.push(part.slice(3));
    if (part[0] === 'R' || part[0] === 'C') i++;
  }
  return out;
}

/**
 * The baseline, by asking git: three reads and one `stash create`, which
 * writes no ref and no file of the tree -- and, given the turn, its snapshot
 * on its dev server's refs (`snapshot`), for Undo this turn.
 */
export async function takeBaseline(git: Git, turn?: { root: string; id: string; port: number; serial?: Serial }): Promise<Baseline> {
  const top = await git(['rev-parse', '--show-prefix']);
  if (top.code !== 0) return { base: null, prefix: '', untracked: [], dirty: [] };
  if (turn) await snapshot(git, turn.root, turn.id, turn.port, KEEP_SNAPSHOTS, turn.serial).catch(() => null);
  const prefix = top.stdout.trim();
  const stash = await git(['stash', 'create']);
  let base = stash.code === 0 ? stash.stdout.trim() : '';
  if (base === '') {
    const head = await git(['rev-parse', '--verify', '--quiet', 'HEAD']);
    base = head.code === 0 ? head.stdout.trim() : '';
  }
  const [untracked, status] = await Promise.all([git(['ls-files', '-o', '--exclude-standard', '-z']), git(['status', '--porcelain', '-z', '--untracked-files=all', '--', '.'])]);
  const strip = (path: string): string => (prefix !== '' && path.startsWith(prefix) ? path.slice(prefix.length) : path);
  return {
    base: base === '' ? null : base,
    prefix,
    untracked: untracked.code === 0 ? fields(untracked.stdout) : [],
    dirty: status.code === 0 ? statusPaths(status.stdout).map(strip) : [],
  };
}

/** What a turn changed, by git's account and its rows'. */
export interface TurnChanges {
  files: TurnFile[];
  added: number;
  removed: number;
  /** Uncommitted when the turn began. */
  before: string[];
}

/** Is there a file (or a link) at `file`. */
async function exists(file: string): Promise<boolean> {
  try {
    await lstat(file);
    return true;
  } catch {
    return false;
  }
}

/** A file's lines, for an untracked file new since the baseline; null for a binary, or one too big to count. */
async function lineCount(file: string): Promise<number | null> {
  try {
    const handle = await open(file, 'r');
    try {
      const { size } = await handle.stat();
      if (size > 4 * 1024 * 1024) return null;
      const bytes = Buffer.alloc(size);
      await handle.read(bytes, 0, size, 0);
      if (bytes.subarray(0, 8000).includes(0)) return null;
      if (size === 0) return 0;
      let lines = 0;
      for (const b of bytes) if (b === 10) lines++;
      return bytes[size - 1] === 10 ? lines : lines + 1;
    } finally {
      await handle.close();
    }
  } catch {
    return null;
  }
}

/** Paths `check-attr` is asked about at once, at most: a command line's length. */
const ATTR_BATCH = 500;

/** The counted files that Git LFS keeps: their counts are the pointer's, so none (binary). */
async function uncountLfs(git: Git, files: Map<string, TurnFile>): Promise<void> {
  const counted = [...files.values()].filter((f) => f.added !== null).map((f) => f.path);
  for (let i = 0; i < counted.length; i += ATTR_BATCH) {
    const attrs = await git(['check-attr', '-z', 'filter', '--', ...counted.slice(i, i + ATTR_BATCH)]);
    if (attrs.code !== 0) return;
    // `<path> NUL filter NUL <value> NUL`, a path at a time.
    const parts = attrs.stdout.split('\0');
    for (let j = 0; j + 2 < parts.length; j += 3) {
      const file = parts[j + 2] === 'lfs' ? files.get(parts[j]!) : undefined;
      if (file) {
        file.added = null;
        file.removed = null;
      }
    }
  }
}

/** A path as the project names it: relative to `root` with `/`, or absolute where it is outside. */
export function projectPath(root: string, path: string): string {
  const abs = isAbsolute(path) ? path : join(root, path);
  const rel = relative(root, abs);
  return rel === '' || rel.startsWith('..') || isAbsolute(rel) ? abs : rel.split(sep).join('/');
}

/**
 * What differs from the baseline now: git's numstat against its commit, the
 * untracked files new since, and the rows' paths git did not name.
 */
export async function turnChanges(git: Git, root: string, baseline: Baseline | null, written: Iterable<string>): Promise<TurnChanges> {
  const files = new Map<string, TurnFile>();
  const dirty = new Set(baseline?.dirty ?? []);
  if (baseline?.base) {
    const diff = await git(['diff', '--numstat', '--no-renames', '--relative', '-z', baseline.base, '--', '.']);
    if (diff.code === 0) {
      for (const row of fields(diff.stdout)) {
        const [a, r, ...rest] = row.split('\t');
        const path = rest.join('\t');
        if (path === '') continue;
        files.set(path, { path, added: a === '-' ? null : Number(a), removed: r === '-' ? null : Number(r), created: false, before: dirty.has(path) });
      }
    }
    const now = await git(['ls-files', '-o', '--exclude-standard', '-z']);
    if (now.code === 0) {
      const was = new Set(baseline.untracked);
      const is = new Set(fields(now.stdout));
      for (const path of is) {
        if (was.has(path) || files.has(path)) continue;
        files.set(path, { path, added: await lineCount(join(root, path)), removed: 0, created: true, before: false });
      }
      // Untracked before and gone now: deleted -- no diff says so, the turn's snapshot has it.
      for (const path of was) {
        if (is.has(path) || files.has(path) || (await exists(join(root, path)))) continue;
        files.set(path, { path, added: null, removed: null, created: false, before: dirty.has(path), deleted: true });
      }
    }
    await uncountLfs(git, files);
    for (const file of files.values()) if (!file.deleted && file.added === 0 && !(await exists(join(root, file.path)))) file.deleted = true;
  }
  for (const raw of written) {
    const path = projectPath(root, raw);
    if (files.has(path)) continue;
    // Uncommitted before and still so, or ignored: git's diff has nothing to say. Named, uncounted.
    files.set(path, { path, added: null, removed: null, created: false, before: dirty.has(path) });
  }
  const list = [...files.values()].sort((x, y) => x.path.localeCompare(y.path));
  return {
    files: list,
    added: list.reduce((n, f) => n + (f.added ?? 0), 0),
    removed: list.reduce((n, f) => n + (f.removed ?? 0), 0),
    before: [...dirty].sort(),
  };
}

// ---------------------------------------------------------------- whole inputs

/** Turns whose inputs are kept. */
export const KEEP_TURNS = 20;
/** Bytes of JSON kept at most. */
export const KEEP_BYTES = 4 * 1024 * 1024;

/** The whole `Edit` and `Write` inputs of the last turns, for an Edit row to unfold to. */
export class Inputs {
  private readonly byId = new Map<string, { turn: string; input: unknown; size: number }>();
  private readonly turns: string[] = [];
  private bytes = 0;
  private readonly maxTurns: number;
  private readonly maxBytes: number;

  constructor(maxTurns = KEEP_TURNS, maxBytes = KEEP_BYTES) {
    this.maxTurns = maxTurns;
    this.maxBytes = maxBytes;
  }

  /** A call's input, kept under its turn; the oldest turns go past either cap. */
  keep(turn: string, id: string, input: unknown): void {
    const size = JSON.stringify(input ?? null).length;
    if (size > this.maxBytes) return;
    if (!this.turns.includes(turn)) this.turns.push(turn);
    const old = this.byId.get(id);
    if (old) this.bytes -= old.size;
    this.byId.set(id, { turn, input, size });
    this.bytes += size;
    while (this.turns.length > this.maxTurns || this.bytes > this.maxBytes) {
      const gone = this.turns.shift();
      if (gone === undefined) break;
      for (const [key, value] of this.byId) {
        if (value.turn !== gone) continue;
        this.byId.delete(key);
        this.bytes -= value.size;
      }
    }
  }

  /** A call's whole input, while kept. */
  get(id: string): unknown {
    return this.byId.get(id)?.input;
  }

  has(id: string): boolean {
    return this.byId.has(id);
  }

  clear(): void {
    this.byId.clear();
    this.turns.length = 0;
    this.bytes = 0;
  }
}

// ---------------------------------------------------------------- two repositories: the project's and the engine's

/** A repository of the project: its folder, the prefix its paths carry as the project names them (`''`, `engine/`). */
export interface GitRoot {
  root: string;
  prefix: string;
}

/** The submodule's folder in a project in source mode: the engine's checkout, its own repository. */
export const ENGINE = 'engine';

/**
 * The project's repositories: its own, and the engine's when `<root>/engine/.git`
 * is there -- a submodule's `.git` is a file, a checkout's a folder: either is one.
 */
export function gitRoots(root: string): GitRoot[] {
  const roots: GitRoot[] = [{ root, prefix: '' }];
  if (existsSync(join(root, ENGINE, '.git'))) roots.push({ root: join(root, ENGINE), prefix: `${ENGINE}/` });
  return roots;
}

/** A repository with its git: `gitIn(root)`, or a test's stand-in. */
export interface Repo extends GitRoot {
  git: Git;
}

/** The baselines of a turn: one a repository, in `Repos.list`'s order (null where git had none). */
export type Baselines = (Baseline | null)[];

/**
 * The steps above over every repository of the project, their answers merged:
 * the session's one handle on git. Paths in and out are the project's
 * (relative to the first repository's root, `engine/...` the engine's).
 */
export interface Repos {
  readonly list: readonly Repo[];
  /** Each repository's baseline, and its snapshot for Undo this turn given the turn (`takeBaseline`). */
  baseline(turn?: { id: string; port: number; serial?: Serial }): Promise<Baselines>;
  /** What the turn changed, every repository's files together (`turnChanges`); `written`, the rows' paths. */
  changes(baselines: Baselines | null, written: Iterable<string>): Promise<TurnChanges>;
  /** What differs from the turn's snapshots among `named` (`sinceSnapshot`): found where any repository's snapshot is (a turn that touched the engine alone has only its). */
  since(turn: string, named: ReadonlySet<string>, spared: ReadonlySet<string>, port: number, serial?: Serial): Promise<SinceSnapshot>;
  /** Files put back from the turn's snapshots, each from its repository's (`putBack`). */
  putBack(turn: string, changed: readonly string[], made: readonly string[], port: number): Promise<{ done: string[]; failed: string[] }>;
  /** The snapshots let go in every repository (`dropSnapshots`): how many. */
  drop(port: number, turns?: Iterable<string>): Promise<number>;
  /** Is a path (the project's, relative) one its repository's git ignores. */
  ignored(path: string): Promise<boolean>;
}

/** The repositories of `gitRoots(root)`, each with the real git. */
export const reposIn = (root: string): Repos => reposOf(gitRoots(root).map((r) => ({ ...r, git: gitIn(r.root) })));

/** Steps over `list`, merged: the first is the project's own, the rest nested in it under their prefixes. */
export function reposOf(list: readonly Repo[]): Repos {
  const [main, ...nested] = list;
  if (main === undefined) throw new Error('reposOf: no repository');
  /** The repository a project path is in, and the path as its git names it; an absolute path (outside) is the project's. */
  const split = (path: string): { at: number; path: string } => {
    for (let i = list.length - 1; i > 0; i--) {
      const prefix = list[i]!.prefix;
      if (path.startsWith(prefix)) return { at: i, path: path.slice(prefix.length) };
    }
    return { at: 0, path };
  };
  /** A path of the project's own repository that is a nested one's -- its gitlink, or its folder untracked: the nested one answers for it. */
  const nestedHere = (path: string): boolean => nested.some((r) => path === r.prefix.slice(0, -1) || path.startsWith(r.prefix));
  /** Paths split by repository. */
  const byRepo = (paths: Iterable<string>, root = main.root): string[][] => {
    const out = list.map((): string[] => []);
    for (const raw of paths) {
      const { at, path } = split(projectPath(root, raw));
      out[at]!.push(path);
    }
    return out;
  };
  const prefixed = (at: number, paths: readonly string[]): string[] => (at === 0 ? paths.filter((p) => !nestedHere(p)) : paths.map((p) => list[at]!.prefix + p));
  return {
    list,
    baseline: (turn) => Promise.all(list.map((r) => takeBaseline(r.git, turn && { root: r.root, ...turn }).catch(() => null))),
    async changes(baselines, written) {
      const rows = byRepo(written);
      const each = await Promise.all(list.map((r, i) => turnChanges(r.git, r.root, baselines?.[i] ?? null, rows[i]!)));
      const files: TurnFile[] = [];
      const before: string[] = [];
      each.forEach((c, i) => {
        for (const f of c.files) if (i > 0 || !nestedHere(f.path)) files.push(i === 0 ? f : { ...f, path: list[i]!.prefix + f.path });
        before.push(...prefixed(i, c.before));
      });
      files.sort((x, y) => x.path.localeCompare(y.path));
      return { files, added: files.reduce((n, f) => n + (f.added ?? 0), 0), removed: files.reduce((n, f) => n + (f.removed ?? 0), 0), before: before.sort() };
    },
    async since(turn, named, spared, port, serial) {
      const [n, sp] = [byRepo(named), byRepo(spared)];
      const each = await Promise.all(list.map((r, i) => sinceSnapshot(r.git, r.root, turn, new Set(n[i]), new Set(sp[i]), port, serial)));
      return {
        found: each.some((c) => c.found),
        changed: each.flatMap((c, i) => prefixed(i, c.changed)).sort(),
        made: each.flatMap((c, i) => prefixed(i, c.made)).sort(),
      };
    },
    async putBack(turn, changed, made, port) {
      const [c, m] = [byRepo(changed), byRepo(made)];
      const each = await Promise.all(list.map((r, i) => putBack(r.git, r.root, turn, c[i]!, m[i]!, port)));
      return { done: each.flatMap((b, i) => prefixed(i, b.done)), failed: each.flatMap((b, i) => prefixed(i, b.failed)) };
    },
    async drop(port, turns) {
      const ids = turns === undefined ? undefined : [...turns];
      const each = await Promise.all(list.map((r) => dropSnapshots(r.git, port, ids)));
      return each.reduce((a, b) => a + b, 0);
    },
    async ignored(path) {
      const { at, path: rel } = split(path);
      return (await list[at]!.git(['check-ignore', '-q', '--', rel])).code === 0;
    },
  };
}
