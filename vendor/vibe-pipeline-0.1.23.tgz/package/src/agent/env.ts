/**
 * The environment the Claude Code CLI gets (Docs/agent.md §2): the dev
 * server's own, with the CLI findable, and nothing that would change who pays
 * or make it take itself for something it is not.
 *
 * - **`PATH` holds `claude`** (Vibe3D's D32): the directories it installs to
 *   are added after what is there, so `pathToClaudeCodeExecutable` finds the
 *   person's own CLI -- and a `claude` typed into a Bash call is the same one.
 *   None found: the SDK's own, its per-platform optional dependency, runs.
 * - **No API key**: `ANTHROPIC_API_KEY` and `ANTHROPIC_AUTH_TOKEN` are taken
 *   out, so nothing silently switches the session to API billing; the CLI's
 *   own login is what it uses (rule 2).
 * - **No parent session**: a dev server started from a Claude Code session
 *   inherits what that session sets for what it runs -- `CLAUDECODE`,
 *   `CLAUDE_CODE_ENTRYPOINT`, its session's id, its IDE and messaging
 *   sockets, its effort. A CLI that sees them takes itself for a nested one,
 *   or talks to the parent's IDE; the SDK sets its own entrypoint. So every
 *   `CLAUDE_CODE_*` goes -- a name a newer parent sets included -- but the
 *   person's own settings (`PERSON`: `CLAUDE_CODE_USE_BEDROCK`,
 *   `_MAX_OUTPUT_TOKENS`, `_OAUTH_TOKEN` …), and the three a session sets
 *   under other names (`PARENT_SESSION`). `CLAUDE_CONFIG_DIR` and the rest
 *   pass.
 * - **No `NODE_ENV`** (`DEV_SERVER`): Vite sets `NODE_ENV=development` in the
 *   dev server's own process (and `VITE_USER_NODE_ENV` from a `.env`'s), so
 *   every command the CLI ran inherited it -- an `npm run build` from the card
 *   made a development build (`import.meta.env.DEV` true, MrDebug on without
 *   `?debug` in `build:debug`), unlike the same in a terminal. Both go: what
 *   the CLI runs picks its own, as from a fresh shell.
 *
 * `env` replaces the child's environment whole, so this is a full copy.
 */
import { execFile } from 'node:child_process';
import { constants } from 'node:fs';
import { access, stat } from 'node:fs/promises';
import { homedir } from 'node:os';
import { delimiter, join } from 'node:path';

/** Who pays: never inherited. */
export const BILLING = ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN'] as const;

/**
 * What a Claude Code session sets for the processes it starts under names of
 * its own -- a parent session's, never this one's. Every `CLAUDE_CODE_*` but
 * `PERSON` goes as well (`CLAUDE_CODE_SESSION_ID`, `_ENTRYPOINT`,
 * `_SSE_PORT`, `_MESSAGING_SOCKET` …, all found inherited).
 */
export const PARENT_SESSION = ['CLAUDECODE', 'CLAUDE_PID', 'CLAUDE_EFFORT'] as const;

/** The `CLAUDE_CODE_*` a person sets, for every session of theirs: these pass. */
export const PERSON: ReadonlySet<string> = new Set([
  'CLAUDE_CODE_USE_BEDROCK',
  'CLAUDE_CODE_USE_VERTEX',
  'CLAUDE_CODE_USE_FOUNDRY',
  'CLAUDE_CODE_SKIP_BEDROCK_AUTH',
  'CLAUDE_CODE_SKIP_VERTEX_AUTH',
  'CLAUDE_CODE_SKIP_FOUNDRY_AUTH',
  'CLAUDE_CODE_OAUTH_TOKEN',
  'CLAUDE_CODE_API_KEY_HELPER_TTL_MS',
  'CLAUDE_CODE_CLIENT_CERT',
  'CLAUDE_CODE_CLIENT_KEY',
  'CLAUDE_CODE_CLIENT_KEY_PASSPHRASE',
  'CLAUDE_CODE_MAX_OUTPUT_TOKENS',
  'CLAUDE_CODE_SUBAGENT_MODEL',
  'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC',
  'CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS',
  'CLAUDE_CODE_DISABLE_TERMINAL_TITLE',
  'CLAUDE_CODE_DISABLE_BACKGROUND_TASKS',
  'CLAUDE_CODE_IDE_SKIP_AUTO_INSTALL',
  'CLAUDE_CODE_SHELL',
  'CLAUDE_CODE_SHELL_PREFIX',
  'CLAUDE_CODE_GIT_BASH_PATH',
]);

/** What the dev server's own process has set that a command run from the card must not inherit. */
export const DEV_SERVER_VARS = ['NODE_ENV', 'VITE_USER_NODE_ENV'] as const;
const DEV_SERVER: ReadonlySet<string> = new Set(DEV_SERVER_VARS);

/**
 * What `npm run` sets for the script it runs (`npm_config_*`, `npm_lifecycle_event`, `npm_package_*`, `INIT_CWD`
 * …): a dev server started by `npm run dev` carries them, and a child npm that inherits them takes the parent's
 * lifecycle for its own -- `vibe new`'s install, a studio task's `npm run build`. Never passed on to one.
 */
export function fromNpmScript(key: string): boolean {
  return /^npm_/i.test(key) || key === 'INIT_CWD';
}

/**
 * A script's environment, for a task the studio runs (`studio/tasks.ts`): the dev server's own less what it set
 * for itself (`DEV_SERVER`: an `npm run build` from the Build card is a production build, as from a fresh shell)
 * and less what the `npm run dev` that started it set (`fromNpmScript`). Who pays and the parent session's
 * variables are the CLI's concern (`agentEnv`), not a script's: they pass.
 */
export function devServerEnv(base: Readonly<Record<string, string | undefined>> = process.env): Record<string, string> {
  const env: Record<string, string> = {};
  for (const [key, value] of Object.entries(base)) if (value !== undefined && !DEV_SERVER.has(key) && !fromNpmScript(key)) env[key] = value;
  return env;
}

/**
 * What a Windows process cannot start without, or finds nothing without: `SystemRoot` above all (node aborts at
 * start without it -- bcrypt, its random source, is not found), the shell, the temp and profile folders.
 */
export const WINDOWS_ESSENTIALS = ['SystemRoot', 'SystemDrive', 'windir', 'ComSpec', 'PATHEXT', 'TEMP', 'TMP', 'USERPROFILE', 'HOMEDRIVE', 'HOMEPATH', 'APPDATA', 'LOCALAPPDATA', 'ProgramData', 'ProgramFiles', 'ProgramFiles(x86)', 'ProgramW6432', 'CommonProgramFiles', 'NUMBER_OF_PROCESSORS', 'PROCESSOR_ARCHITECTURE', 'OS'] as const;

/**
 * `env` with, on Windows, each of `WINDOWS_ESSENTIALS` it lacks taken from `from` (this process's) -- keys matched
 * in any case, as Windows matches them, `env`'s own spelling and value kept. An environment made by hand (a test's, a
 * filtered one) then still starts a program there. As it is elsewhere. Pure but for the default `from`.
 */
export function withWindowsEssentials(env: Record<string, string>, platform: NodeJS.Platform = process.platform, from: Readonly<Record<string, string | undefined>> = process.env): Record<string, string> {
  if (platform !== 'win32') return env;
  const out = { ...env };
  const have = new Set(Object.keys(out).map((k) => k.toUpperCase()));
  const source = new Map(Object.entries(from).filter((e): e is [string, string] => e[1] !== undefined).map(([k, v]) => [k.toUpperCase(), [k, v] as const]));
  for (const name of WINDOWS_ESSENTIALS) {
    const found = source.get(name.toUpperCase());
    if (!have.has(name.toUpperCase()) && found) out[found[0]] = found[1];
  }
  return out;
}

/** Is `key` a parent session's, for the CLI not to inherit? */
export function fromParent(key: string): boolean {
  return (PARENT_SESSION as readonly string[]).includes(key) || (key.startsWith('CLAUDE_CODE_') && !PERSON.has(key));
}

/** Where `claude` installs itself, after what `PATH` has. */
export function installDirs(platform: NodeJS.Platform = process.platform, home = homedir()): string[] {
  if (platform === 'win32') return [join(home, '.local', 'bin'), join(process.env.APPDATA ?? join(home, 'AppData', 'Roaming'), 'npm')];
  return [join(home, '.local', 'bin'), join(home, '.claude', 'local'), '/opt/homebrew/bin', '/usr/local/bin'];
}

/** The CLI's environment: `base` less the billing, parent-session and dev-server variables, `PATH` with the install folders. */
export function agentEnv(base: Readonly<Record<string, string | undefined>> = process.env, platform: NodeJS.Platform = process.platform, home = homedir()): Record<string, string> {
  const billing = new Set<string>(BILLING);
  const env: Record<string, string> = {};
  for (const [key, value] of Object.entries(base)) if (value !== undefined && !billing.has(key) && !fromParent(key) && !DEV_SERVER.has(key)) env[key] = value;
  // Windows spells it `Path`; one key here, whatever it was.
  const pathKey = Object.keys(env).find((k) => k.toUpperCase() === 'PATH') ?? 'PATH';
  const dirs = (env[pathKey] ?? '').split(delimiter).filter((d) => d !== '');
  for (const dir of installDirs(platform, home)) if (!dirs.includes(dir)) dirs.push(dir);
  env[pathKey] = dirs.join(delimiter);
  return env;
}

/** `claude` on `env`'s `PATH`, its absolute path; undefined where there is none. */
export async function findClaude(env: Readonly<Record<string, string>>, platform: NodeJS.Platform = process.platform): Promise<string | undefined> {
  const pathKey = Object.keys(env).find((k) => k.toUpperCase() === 'PATH') ?? 'PATH';
  const name = platform === 'win32' ? 'claude.exe' : 'claude';
  for (const dir of (env[pathKey] ?? '').split(delimiter)) {
    if (dir === '') continue;
    const file = join(dir, name);
    try {
      if (!(await stat(file)).isFile()) continue;
      if (platform !== 'win32') await access(file, constants.X_OK);
      return file;
    } catch {
      // Not here.
    }
  }
  return undefined;
}

/**
 * The Claude Code CLI the turn logic was checked against (Docs/agent.md §7): the SDK is pinned, the
 * person's `claude` is not and updates itself, and the turns lean on what the CLI sends -- a
 * person's result naming its turn (`user_message_uuid`), `blockedPath` for an in-project `rm -r`,
 * no `matchedAskRule` for a `Bash(...)` rule. Another version is said once in the log, not refused.
 */
export const CHECKED_CLI = '2.1.289';

/** `claude --version`'s first `x.y.z`, or null: it could not be run, or said none. */
export function cliVersion(claude: string, env: Readonly<Record<string, string>>): Promise<string | null> {
  return new Promise((done) => {
    execFile(claude, ['--version'], { env, timeout: 5000 }, (err, stdout) => done(err ? null : (/\d+\.\d+\.\d+/.exec(String(stdout))?.[0] ?? null)));
  });
}

/** What the log says of the CLI's version: null for the one checked, else which it is and which was. */
export function versionNote(version: string | null): string | null {
  if (version === CHECKED_CLI) return null;
  if (version === null) return `[agent] the Claude Code CLI's version could not be read; the turns were checked against ${CHECKED_CLI}`;
  return `[agent] Claude Code CLI ${version}; the turns were checked against ${CHECKED_CLI} -- if turns end oddly or Auto asks differently, that is the first place to look`;
}
