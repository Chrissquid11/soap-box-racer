/**
 * The models, as the pickers show them (Docs/agent.md §2, Vibe3D's D108): what
 * the CLI reports through `initializationResult()`, never a list of ours, so
 * the choices cannot drift from the installed release.
 *
 * - **One mapping**, `toChoice`: a model's effort levels are carried only when
 *   it says it has them -- `supportsEffort` false and an empty list are the
 *   same answer, "no such setting here", and the Effort picker hides.
 * - **"Default" is the CLI's own**: its `default` row, or no model set at all
 *   (`null`), which is the same thing; the settings keep `null` for both.
 * - **An effort the model lacks is dropped first** (`effortFor`), on a switch
 *   or at start: naming a level the model does not support is an error.
 *
 * Pure: the shape it reads is the SDK's `ModelInfo`, described here.
 */
import type { ModelChoice } from './api-types.ts';

/** What `toChoice` reads of the SDK's `ModelInfo`. */
export interface ModelInfoLike {
  value: string;
  displayName?: string;
  supportsEffort?: boolean;
  supportedEffortLevels?: readonly string[];
}

/** The CLI's own row: what "Default" is. */
export const DEFAULT_MODEL = 'default';

/** A model as the picker shows it, with its effort levels (none: no Effort picker). */
export function toChoice(m: ModelInfoLike): ModelChoice {
  return {
    value: m.value,
    label: m.displayName || m.value,
    efforts: m.supportsEffort && m.supportedEffortLevels?.length ? [...m.supportedEffortLevels] : [],
  };
}

/** The settings' spelling of a model: the CLI's own row is no model set. */
export function modelSetting(model: string | null | undefined): string | null {
  return model === undefined || model === null || model === '' || model === DEFAULT_MODEL ? null : model;
}

/** The levels `model` has (`null`: the CLI's own row's); undefined while the models are not known. */
export function effortsOf(models: readonly ModelChoice[], model: string | null): string[] | undefined {
  if (models.length === 0) return undefined;
  const row = models.find((m) => m.value === (model ?? DEFAULT_MODEL));
  return row?.efforts ?? [];
}

/**
 * The effort to keep with `model`: `effort` if the model has it, else null --
 * dropped. While the models are not known yet (the session not up), kept: the
 * check runs again once they are.
 */
export function effortFor(models: readonly ModelChoice[], model: string | null, effort: string | null): string | null {
  if (effort === null) return null;
  const levels = effortsOf(models, model);
  if (levels === undefined) return effort;
  return levels.includes(effort) ? effort : null;
}
