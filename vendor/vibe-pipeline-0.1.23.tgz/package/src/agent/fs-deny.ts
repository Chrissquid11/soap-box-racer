/**
 * What the dev server never serves as a file (Docs/agent.md §2, "Reads are
 * loopback-only too"): Vite's `server.fs.deny`, set in `vite.config.ts`.
 *
 * The server listens on the LAN (`host: true`, to test on a phone), and Vite
 * serves any file under the root its deny list does not name -- to anyone who
 * can reach the port. The agent's routes answer only loopback callers, but its
 * transcripts are files: `.cache/agent/<port>/conversations.json` lists the
 * conversations, `<id>/log.jsonl` holds every prompt and reply. So these go,
 * for every caller, loopback too -- the page reads none of them as a file; it
 * asks `/__agent/` and `/__assets/`, which read them from disk:
 *
 * - `.cache/` -- the transcripts, the asset server's caches and `held.json`;
 * - `.claude/` -- the person's `settings.local.json` and the project's rules;
 * - `.trash/` -- what the Assets tool deleted, served back through `GET file`;
 * - `.git/`, `.env`, `.env.*`, keys and certificates, `.npmrc`, `.yarnrc.yml`
 *   -- Vite's own defaults, which a `deny` set in the config replaces rather
 *   than adds to, so they are listed again here;
 * - `*.local.json` and `*.local` -- this machine's own settings
 *   (`assets.local.json`).
 *
 * A pattern with no `/` matches the name anywhere (Vite prefixes it with
 * `**\/`); one with a `/` is matched against the whole absolute path, so each
 * starts with `**\/`. Checked against Vite itself in `fs-deny.test.ts`.
 *
 * Nothing at module level but the list.
 */
export const FS_DENY: readonly string[] = [
  // Vite's defaults (`server.fs.deny`), kept.
  '.env',
  '.env.*',
  '*.{crt,pem,key,p12,pfx,cer,der}',
  '.npmrc',
  '.yarnrc.yml',
  '**/.git/**',
  // Ours.
  '.envrc',
  '**/.cache/**',
  '**/.claude/**',
  '**/.trash/**',
  '*.local',
  '*.local.json',
];
