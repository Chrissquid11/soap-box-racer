/**
 * Claude's conversation in a terminal, and back (Docs/terminal.md): the `claude` CLI resuming a conversation of the
 * column -- in a PTY of the dev server's, drawn by xterm.js in the column, or in the person's own terminal (`own`: the
 * command copied, or run in Terminal.app by the Squidwright app) --
 * with what the column's session has: its settings, the brief, the package's Claude files, the studio's tools and the
 * editor's context with each prompt.
 *
 * - **One owner at a time** (D1): `open` hands the session over (`Session.handOver`: refused while a turn runs, the
 *   column's query closed), `close` and the CLI's own exit take it back (`Session.takeBack`), the turns made there read
 *   from the session's transcript with the SDK's `getSessionMessages` (D10) -- never a file of `~/.claude/` opened here.
 * - **The run's files** (`writeRun`, 0600 under `.cache/agent/<port>/<id>/terminal/`, gitignored with `.cache/`): the
 *   MCP config naming `studio` at `/__mcp` with the run's own token (`../mcp/runs.ts`, D6), the settings -- the host's
 *   `ask` rules and the destructive studio tools under Ask and Auto, and the `UserPromptSubmit` hook (D7) -- the brief,
 *   the hook's script, the run's record (its context route and token) and, for the person's own terminal, `resume.command` (Terminal.app runs it in the app) (0700).
 *   None of it is the person's: no `claude mcp add`, no settings file of theirs written. Gone when the run ends.
 * - **The command** (`terminalArgs`, D4): `--resume <id>` (or `--session-id` for a conversation never sent), `--model`,
 *   `--effort`, `--permission-mode` (Ask `manual`, Auto and Unsafe auto `auto`), `--plugin-dir`,
 *   `--append-system-prompt` (the brief's text; in a line for a shell `"$(cat brief.md)"`, for PowerShell on Windows `(Get-Content -Raw …)`), `--mcp-config`, `--settings` --
 *   every one an option `claude --help` lists (`fixtures/claude-help.txt`, checked by the tests). The environment is `env.ts`' `agentEnv()`, a terminal's.
 *   `command` puts a stand-in in `claude`'s place (a test's; `VIBE_TERMINAL_COMMAND` in the dev server's environment).
 * - **The PTY** (`node-pty`, the pipeline's optional dependency, imported as the first terminal opens; D2): its output
 *   pushed to the page in batches (`push`), the last `SCREEN_MAX` characters kept for a reload; keys and resizes from the
 *   page (`input`, `resize`). Ended gracefully (`end`): Esc, then Ctrl+C three times, `SIGHUP` after `graceMs`, `SIGKILL`
 *   after as long again (on Windows ConPTY's plain kill for both: it has no signals, `ptySignal`).
 * - **The person's own terminal** (`own`, D5): no PTY here; `close` asks the session's time first, and one written in the last
 *   `RECENT_MS` is refused (`409`) unless `force` -- its CLI may still be at it.
 *
 * Node only. Nothing at module level but constants and the hook's text.
 */
import { chmodSync, statSync } from 'node:fs';
import { chmod, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { spawn as spawnProcess } from 'node:child_process';
import { dirname, join } from 'node:path';
import { Refused } from '../assets/http.ts';
import { CATALOG, LONGEST_MS, STUDIO_TOOLS } from '../mcp/catalog.ts';
import type { Runs } from '../mcp/runs.ts';
import { MCP_PATH } from '../mcp/token.ts';
import type { AgentSettings, PermissionLevel, TerminalOpenRequest, TerminalPush, TerminalState, TerminalTurn } from './api-types.ts';
import { BILLING, DEV_SERVER_VARS, PARENT_SESSION, withWindowsEssentials } from './env.ts';
import { HOST_ASK } from './permissions.ts';
import { treeKill } from '../studio/child.ts';
import type { HandOver, Session } from './session.ts';
export { turnEvent } from './terminal-turn.ts';

/** The terminal's output kept for a reload, in characters, at most. */
export const SCREEN_MAX = 256 * 1024;
/** The own terminal's session written this recently: Back asks first (D5). */
export const RECENT_MS = 15_000;
/** Turns read back into the transcript, at most (D10): the latest; the rest counted. */
export const TURNS_MAX = 50;
/** A turn's words, and its text, read back at most, in characters. */
export const TURN_CHARS = 2000;
/** The last of the keys `end` sends, in milliseconds after the first. */
const KEYS_MS = 750;
/** Output batched this long before it is pushed, in milliseconds. */
const BATCH_MS = 12;

// ---------------------------------------------------------------- the command

/**
 * The CLI's permission mode for the column's level (D4): Ask is `manual` -- the CLI's mode that asks before each tool
 * (2.1.301's `--permission-mode` choices are acceptEdits, auto, bypassPermissions, manual, dontAsk, plan: no `default`);
 * Auto and Unsafe auto are the CLI's `auto` -- never a bypass.
 */
export const permissionMode = (level: PermissionLevel): 'manual' | 'auto' => (level === 'ask' ? 'manual' : 'auto');

/** The studio tools destructive at every input, as the CLI names them: the ones the column's cards ask under Auto. */
export const destructiveTools = (): string[] => CATALOG.filter((m) => m.annotations.destructiveHint && !('destroysWhen' in m)).map((m) => `${STUDIO_TOOLS}${m.name}`);

/** The run's `ask` rules (D6, D7): the host's, and under Ask and Auto the always-destructive studio tools; Unsafe auto lets those by. */
export const runAskRules = (level: PermissionLevel): string[] => [...HOST_ASK, ...(level === 'unsafe' ? [] : destructiveTools())];

/** The run's files, by name. */
export interface RunFiles {
  dir: string;
  mcp: string;
  settings: string;
  brief: string;
  hook: string;
  run: string;
  command: string;
}

/** Where a conversation's run keeps its files. */
export function runFiles(root: string, port: number, conversation: string): RunFiles {
  const dir = join(root, '.cache', 'agent', String(port), conversation, 'terminal');
  return { dir, mcp: join(dir, 'mcp.json'), settings: join(dir, 'settings.json'), brief: join(dir, 'brief.md'), hook: join(dir, 'hook.mjs'), run: join(dir, 'run.json'), command: join(dir, 'resume.command') };
}

/** The brief's place in arguments made for a shell line (`shellWords`): `"$(cat <brief.md>)"` there, its text in a PTY's. */
export const BRIEF_MARK = '\u0000brief';

/** The CLI's arguments (D4): resume or a new id, the column's settings, the run's files, the brief's text (`BRIEF_MARK` for a shell line). */
export function terminalArgs(o: { sessionId: string; resumed: boolean; settings: Pick<AgentSettings, 'model' | 'effort' | 'level'>; files: RunFiles; plugin: string; brief: string }): string[] {
  return [
    ...(o.resumed ? ['--resume', o.sessionId] : ['--session-id', o.sessionId]),
    ...(o.settings.model !== null ? ['--model', o.settings.model] : []),
    ...(o.settings.effort !== null ? ['--effort', o.settings.effort] : []),
    '--permission-mode', permissionMode(o.settings.level),
    '--plugin-dir', o.plugin,
    '--append-system-prompt', o.brief,
    '--mcp-config', o.files.mcp,
    '--settings', o.files.settings,
  ];
}

/** A word for a POSIX shell, in single quotes where it needs them. */
export const shellQuote = (word: string): string => (/^[\w@%+=:,./-]+$/.test(word) ? word : `'${word.replace(/'/g, `'\\''`)}'`);

/** Words for a shell: each quoted, the brief's place (`BRIEF_MARK`) read from its file as the shell runs it. */
export const shellWords = (words: readonly string[], briefFile: string): string => words.map((w) => (w === BRIEF_MARK ? `"$(cat ${shellQuote(briefFile)})"` : shellQuote(w))).join(' ');

/** A word for PowerShell: a flag as it is, anything else in single quotes (a quote in it doubled). */
export const psQuote = (word: string): string => (/^--?[\w-]+$/.test(word) ? word : `'${word.replace(/'/g, "''")}'`);

/** Words for PowerShell, the program first (`&`): the brief's place read from its file as it runs. */
export const psWords = (words: readonly string[], briefFile: string): string => words.map((w) => (w === BRIEF_MARK ? `(Get-Content -Raw -LiteralPath ${psQuote(briefFile)})` : psQuote(w))).join(' ');

/**
 * The line to paste into a terminal: into the project, then the CLI -- a POSIX shell's, or on Windows PowerShell's
 * (7.3 or later, which hands a native program its arguments as written; Windows PowerShell 5.1 may split a brief
 * with double quotes in it).
 */
export const commandLine = (root: string, claude: string, args: readonly string[], briefFile: string, platform: NodeJS.Platform = process.platform): string =>
  platform === 'win32' ? `Set-Location -LiteralPath ${psQuote(root)}; & ${psWords([claude, ...args], briefFile)}` : `cd ${shellQuote(root)} && ${shellWords([claude, ...args], briefFile)}`;

/** What a PTY's `kill` is given for `signal`: none on Windows, where node-pty's ConPTY takes no signal (it throws on one) and ends the process. */
export const ptySignal = (signal: string, platform: NodeJS.Platform): string | undefined => (platform === 'win32' ? undefined : signal);

/** What the environment loses in the own terminal's run, as `agentEnv` drops it for the column's (D4). */
const UNSET = [...BILLING, ...PARENT_SESSION, ...DEV_SERVER_VARS];

/** `resume.command`: Terminal.app runs it (D5). */
export function commandFile(root: string, claude: string, args: readonly string[], title: string, briefFile: string): string {
  return [
    '#!/bin/sh',
    `# Claude Code resuming the studio's conversation ${JSON.stringify(title)} (Docs/terminal.md D5): written by the dev server for this run.`,
    `cd ${shellQuote(root)} || exit 1`,
    `unset ${UNSET.join(' ')}`,
    'for v in $(env | sed -n "s/^\\(CLAUDE_CODE_[A-Z_]*\\)=.*/\\1/p"); do case "$v" in CLAUDE_CODE_USE_*|CLAUDE_CODE_SKIP_*|CLAUDE_CODE_OAUTH_TOKEN|CLAUDE_CODE_MAX_OUTPUT_TOKENS|CLAUDE_CODE_SHELL*) ;; *) unset "$v" ;; esac; done',
    `exec ${shellWords([claude, ...args], briefFile)}`,
    '',
  ].join('\n');
}

/**
 * The run's settings (D7): the `ask` rules, the hook that gives each prompt the editor's context -- and, the same script
 * with a word after, the hooks that tell the studio a turn's end, its failure and the CLI asking (Docs/ai-panel.md §8:
 * `Stop`, `StopFailure`, `Notification`), so the tab and the AI button can say so. None of these prints a thing: a
 * `Stop` hook's output could keep Claude going.
 */
export function runSettings(level: PermissionLevel, hookCommand: string, stopFailure = false): Record<string, unknown> {
  const hook = (word: string | null, timeout: number): Record<string, unknown>[] => [{ hooks: [{ type: 'command', command: word === null ? hookCommand : `${hookCommand} ${word}`, timeout }] }];
  return {
    permissions: { ask: runAskRules(level) },
    hooks: { UserPromptSubmit: hook(null, 10), Stop: hook('stop', 5), ...(stopFailure ? { StopFailure: hook('failed', 5) } : {}), Notification: hook('notify', 5) },
  };
}

/**
 * The CLI that has `StopFailure` (Claude Code 2.1.78, its changelog: "Added `StopFailure` hook event"). Before 2.1.122 a
 * malformed hooks entry invalidated the whole settings file ("Fixed a malformed hooks entry in `settings.json` no longer
 * invalidating the entire file") -- an older CLI could drop the run's `ask` rules with it. So the hook is written only for
 * a version known to have it; unknown (a stand-in, `--version` unread): left out, and a failed turn there reads as done.
 */
export const STOP_FAILURE_SINCE = '2.1.78';

/** `version` (`x.y.z`) at least `since`; null: no. */
export function versionAtLeast(version: string | null, since: string): boolean {
  if (version === null) return false;
  const a = version.split('.').map(Number);
  const b = since.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) > (b[i] ?? 0);
  }
  return true;
}

/** The run's MCP config (D6): the studio's server at `/__mcp`, the run's own token. */
export const mcpConfig = (port: number, token: string): Record<string, unknown> => ({
  mcpServers: { studio: { type: 'http', url: `http://localhost:${port}${MCP_PATH}`, headers: { Authorization: `Bearer ${token}` } } },
});

/**
 * The hook's script (D7), written into the run's folder: the run's record read, the dev server asked, its words printed
 * -- the CLI adds a `UserPromptSubmit` hook's output to the prompt as context. Anything wrong: nothing printed, exit 0,
 * the prompt goes as typed.
 */
export const HOOK_SCRIPT = `// The studio's hooks for a terminal run (Docs/terminal.md D7, Docs/ai-panel.md §8): written by the dev server, gone with the run.
// No word: UserPromptSubmit -- the editor's context printed for the prompt. stop, failed, notify: told to the studio, nothing printed.
import { readFileSync } from 'node:fs';
const word = process.argv[3] ?? null;
let run = null;
try {
  run = JSON.parse(readFileSync(process.argv[2], 'utf8'));
} catch {}
if (run && word === null) {
  try {
    const res = await fetch(run.url, { headers: { authorization: 'Bearer ' + run.token }, signal: AbortSignal.timeout(6000) });
    if (res.ok) process.stdout.write(await res.text());
  } catch {}
} else if (run && typeof run.turn === 'string') {
  let type = null;
  if (word === 'notify') {
    try {
      const input = JSON.parse(readFileSync(0, 'utf8'));
      if (typeof input.notification_type === 'string') type = input.notification_type;
    } catch {}
  }
  try {
    await fetch(run.turn, { method: 'POST', headers: { authorization: 'Bearer ' + run.token, 'content-type': 'application/json' }, body: JSON.stringify({ event: word, type }), signal: AbortSignal.timeout(3000) });
  } catch {}
}
process.exit(0);
`;


/** Everything a run needs on disk, written 0600 (the command 0700). */
export async function writeRun(files: RunFiles, o: { port: number; token: string; level: PermissionLevel; brief: string; node: string; command: string | null; stopFailure?: boolean }): Promise<void> {
  await mkdir(files.dir, { recursive: true, mode: 0o700 });
  const put = async (file: string, text: string, mode = 0o600): Promise<void> => {
    await writeFile(file, text, { mode });
    await chmod(file, mode);
  };
  const hook = [o.node, files.hook, files.run].map(shellQuote).join(' ');
  await put(files.mcp, `${JSON.stringify(mcpConfig(o.port, o.token), null, 2)}\n`);
  await put(files.settings, `${JSON.stringify(runSettings(o.level, hook, o.stopFailure === true), null, 2)}\n`);
  await put(files.brief, o.brief);
  await put(files.hook, HOOK_SCRIPT);
  await put(files.run, `${JSON.stringify({ url: `http://localhost:${o.port}/__agent/terminal/context`, turn: `http://localhost:${o.port}/__agent/terminal/turn`, token: o.token })}\n`);
  if (o.command !== null) await put(files.command, o.command, 0o700);
}

// ---------------------------------------------------------------- the turns read back

/** A message of the session's transcript, as the SDK's `getSessionMessages` answers it. */
export interface SessionLine {
  type: 'user' | 'assistant' | 'system';
  message: unknown;
  parent_tool_use_id: string | null;
}

const cut = (text: string): string => (text.length > TURN_CHARS ? `${text.slice(0, TURN_CHARS - 1)}…` : text);

/** A user message's words, or null for none of the person's (a tool's result, the CLI's own caveat or command output). */
function promptOf(message: unknown): string | null {
  const content = (message as { content?: unknown } | null)?.content;
  const text = typeof content === 'string'
    ? content
    : Array.isArray(content)
      ? content.filter((b): b is { type: 'text'; text: string } => (b as { type?: unknown }).type === 'text' && typeof (b as { text?: unknown }).text === 'string').map((b) => b.text).join('\n')
      : '';
  const words = text.trim();
  if (words === '' || words.startsWith('Caveat:') || words.startsWith('<local-command-')) return null;
  // A slash command as the CLI keeps it: its name and its arguments.
  const named = /<command-name>([^<]*)<\/command-name>/.exec(words);
  if (named) return `${named[1]!.trim()} ${(/<command-args>([^<]*)<\/command-args>/.exec(words)?.[1] ?? '').trim()}`.trim();
  return words;
}

/** The turns made after the first `before` messages (D10): the latest `TURNS_MAX`, and how many earlier. */
export function turnsOf(messages: readonly SessionLine[], before: number): { turns: TerminalTurn[]; more: number } {
  const turns: TerminalTurn[] = [];
  for (const m of messages.slice(before)) {
    if (m.parent_tool_use_id !== null) continue;
    if (m.type === 'user') {
      const prompt = promptOf(m.message);
      if (prompt !== null) turns.push({ prompt: cut(prompt), text: '', tools: 0 });
      continue;
    }
    if (m.type !== 'assistant' || turns.length === 0) continue;
    const turn = turns[turns.length - 1]!;
    const content = (m.message as { content?: unknown } | null)?.content;
    for (const b of Array.isArray(content) ? content : []) {
      const block = b as { type?: unknown; text?: unknown };
      if (block.type === 'tool_use') turn.tools++;
      else if (block.type === 'text' && typeof block.text === 'string' && block.text.trim() !== '') turn.text = cut(turn.text === '' ? block.text.trim() : `${turn.text}\n\n${block.text.trim()}`);
    }
  }
  const more = Math.max(0, turns.length - TURNS_MAX);
  return { turns: turns.slice(more), more };
}

// ---------------------------------------------------------------- the terminals

/** What is used of a `node-pty` terminal. */
export interface Pty {
  readonly pid: number;
  onData(fn: (data: string) => void): { dispose(): void };
  onExit(fn: (e: { exitCode: number; signal?: number }) => void): { dispose(): void };
  write(data: string): void;
  resize(cols: number, rows: number): void;
  kill(signal?: string): void;
}

/** `node-pty`'s `spawn`. */
export type PtySpawn = (file: string, args: string[], options: { name: string; cols: number; rows: number; cwd: string; env: Record<string, string> }) => Pty;

/**
 * `node-pty`'s spawn (D2), imported now. Its macOS `spawn-helper` comes out of some installs without its execute bit
 * (`posix_spawnp failed` at the first spawn): given it back here, the package's own file, as its post-install means to.
 */
export async function loadPty(): Promise<PtySpawn> {
  const dir = dirname(createRequire(import.meta.url).resolve('node-pty/package.json'));
  for (const helper of [join(dir, 'prebuilds', `${process.platform}-${process.arch}`, 'spawn-helper'), join(dir, 'build', 'Release', 'spawn-helper')]) {
    try {
      const mode = statSync(helper).mode;
      if ((mode & 0o111) === 0) chmodSync(helper, mode | 0o755);
    } catch {
      // Not this one, or not ours to change: the spawn says so.
    }
  }
  return (await import('node-pty')).spawn as unknown as PtySpawn;
}

/** A conversation as the terminals need it. */
export interface TerminalConversation {
  id: string;
  title: string;
  session: Session;
}

export interface TerminalsOptions {
  root: string;
  port(): number;
  runs: Runs;
  /** `node-pty`'s spawn, imported as the first terminal opens; a test's stand-in. Throws: not installed (D2). */
  pty?(): Promise<PtySpawn>;
  /** The program and its first arguments in `claude`'s place (a test's stand-in; `VIBE_TERMINAL_COMMAND`). None: `claude`. */
  command?: readonly string[] | null;
  /** The CLI's environment (`agentEnv()`), and how `claude` is found on it. */
  env(): Record<string, string>;
  findClaude(env: Record<string, string>): Promise<string | undefined>;
  /** The CLI's `--version` (`env.ts`' `cliVersion`), for the hooks it has (`STOP_FAILURE_SINCE`); none, or a stand-in: unknown. */
  version?(file: string, env: Record<string, string>): Promise<string | null>;
  /** The session's transcript (`getSessionMessages(id, { dir: root })`); its time (`getSessionInfo`). */
  messages(sessionId: string): Promise<readonly SessionLine[]>;
  modified(sessionId: string): Promise<number | null>;
  /** To the page: a conversation's terminal output, or its end. */
  push(conversation: string, push: TerminalPush): void;
  /** The brief the column's session appends (`turn.ts`' `brief`). */
  brief(): string;
  /** The package's Claude files (`plugin.ts`' `CLAUDE_DIR`). */
  plugin: string;
  /** The node that runs the hook: the dev server's own. */
  node: string;
  now?(): number;
  /** How long `end` waits after the keys, and after `SIGHUP`, in milliseconds (5000). */
  graceMs?: number;
  /** The platform the copied line is for and the PTY runs on (`process.platform`; a test's). */
  platform?: NodeJS.Platform;
  /**
   * Windows: a PTY's process tree ended (`taskkill /pid <pid> /T /F`, `child.ts`' `treeKill`) -- ConPTY's own kill
   * ends the program it started, not what that started. By default the real one for node-pty's PTYs, none for a
   * test's stand-in (`pty` given): its pid is made up.
   */
  killTree?(pid: number): void;
  log?(line: string): void;
}

export interface Terminals {
  /**
   * Continue in the terminal: the session handed over, the run's files written, the CLI started (column) -- or `file`, the
   * `.command` for the app to open. A conversation in the column's terminal whose CLI went with the process before
   * (`live` false) is opened again instead (D12): the same session resumed, no hand-over.
   */
  open(c: TerminalConversation, request: TerminalOpenRequest): Promise<{ file?: string }>;
  /** Back to the column: the CLI ended (column) or the session's time asked first (app, `force` past it), its turns read back. */
  close(c: TerminalConversation, force: boolean): Promise<void>;
  /** The output kept, to draw again, and where it ends in all the run's output (`TerminalPush.at`). */
  screen(conversation: string): string;
  end(conversation: string): number;
  /** Keys from the page. */
  input(conversation: string, data: string): void;
  resize(conversation: string, cols: number, rows: number): void;
  /** The PTY of a conversation running now. */
  live(conversation: string): boolean;
  /**
   * After a restart (D5): the person's own terminal's run keeps its token -- read back from its `run.json` and taken by
   * `/__mcp` and the hook again -- when this server listens on the port the run was written for; else, or with none to
   * read, it is marked not live: the studio's tools are gone from it. Called once the server listens.
   */
  adopt(c: TerminalConversation): Promise<boolean>;
  /** The process is going: every PTY ended at once. */
  closeAll(): void;
}

interface Live {
  pty: Pty;
  /** Its conversation: a key typed while the CLI asks answers it (`terminalTurn('answered')`). */
  c: TerminalConversation;
  screen: string[];
  size: number;
  pending: string;
  /** All the output so far, in characters: where the next push's data begins once `pending` is flushed. */
  total: number;
  timer: ReturnType<typeof setTimeout> | null;
  /** The end under way: what `close` waits for. */
  ended: Promise<void>;
  /** The exit seen. */
  done: boolean;
  /** Back asked for it: its end is no failure. */
  closing: boolean;
  /** The person typed into it: a quick exit 0 after that is theirs (`/exit`), no failure. */
  typed: boolean;
  /** When it started, as `now()`. */
  started: number;
  /** When its output last kept a turn running shown (`alive`), as `now()`: at most once a minute. */
  alive: number;
}

/** A turn running is kept shown by the terminal's output at most this often (`alive`), in milliseconds. */
export const ALIVE_MS = 60_000;

/** A CLI that ends by itself this soon after it started, or with an exit code but 0, has failed (D4): said with its last lines. */
export const EARLY_MS = 10_000;
/** Its last lines said, at most. */
const LAST_LINES = 8;

/** The output's last lines as a terminal shows them: escapes taken out, a line written over its last, empty lines left out. */
export function lastLines(screen: string, n = LAST_LINES): string {
  const text = screen
    .replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, '')
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, '')
    .replace(/\x1b[()][0-9A-Za-z]|\x1b[=>78]/g, '');
  // A carriage return alone goes back over the line: what is after the last one is what shows.
  const shown = text.split('\n').map((l) => l.replace(/\r+$/, '').split('\r').at(-1)!.trimEnd());
  return shown.filter((l) => l.trim() !== '').slice(-n).join('\n');
}

/** Cells, as the page measured them: sane, else the classic 80 × 24. */
const cells = (n: unknown, fallback: number): number => (typeof n === 'number' && Number.isInteger(n) && n >= 2 && n <= 1000 ? n : fallback);

/** `treeKill`'s command run for a PTY's pid on Windows, its failure (the tree gone already) no error. */
function runTreeKill(pid: number): void {
  const tree = treeKill(pid, 'win32');
  if (!tree) return;
  try {
    spawnProcess(tree.command, tree.args, { stdio: 'ignore', windowsHide: true }).on('error', () => {});
  } catch {
    // taskkill not there: ConPTY's kill alone.
  }
}

export function createTerminals(options: TerminalsOptions): Terminals {
  const lives = new Map<string, Live>();
  const now = options.now ?? Date.now;
  const grace = options.graceMs ?? 5000;
  const say = options.log ?? (() => {});
  const platform = options.platform ?? process.platform;
  const killTree = options.killTree ?? (options.pty ? () => {} : runTreeKill);
  /** The PTY ended by `signal` -- on Windows its tree by taskkill, then ConPTY's plain kill (`ptySignal`). */
  const hangUp = (pty: Pty, signal: string): void => {
    if (platform === 'win32') killTree(pty.pid);
    pty.kill(ptySignal(signal, platform));
  };

  /** The program, and the arguments before the CLI's, for a run. */
  async function program(env: Record<string, string>): Promise<{ file: string; pre: string[] }> {
    const stand = options.command;
    if (stand && stand.length > 0) return { file: stand[0]!, pre: stand.slice(1) };
    return { file: (await options.findClaude(env)) ?? 'claude', pre: [] };
  }

  /** Each CLI's answer, by its file, for the process's life: `--version` run once, not at every open. */
  const stopFailures = new Map<string, Promise<boolean>>();
  /** Does the CLI have the `StopFailure` hook (`STOP_FAILURE_SINCE`)? A stand-in or an unread version: no. */
  function hasStopFailure(file: string, env: Record<string, string>): Promise<boolean> {
    if ((options.command && options.command.length > 0) || !options.version) return Promise.resolve(false);
    const version = options.version;
    let known = stopFailures.get(file);
    if (!known) {
      known = version(file, env).then((v) => versionAtLeast(v, STOP_FAILURE_SINCE), () => false);
      stopFailures.set(file, known);
    }
    return known;
  }

  /** Conversations whose terminal is being opened now: a second open meanwhile (another window, a reload) is refused. */
  const opening = new Set<string>();

  /** The turns made there read back and the conversation the column's again; the run's token and files gone. */
  async function finish(c: TerminalConversation, why: string | null, failure: { text: string; next: string | null } | null = null): Promise<void> {
    const away = c.session.state().terminal;
    options.runs.revoke(c.id);
    if (!away) return;
    let read: { turns: TerminalTurn[]; more: number } | null = null;
    try {
      read = turnsOf(await options.messages(away.sessionId), away.before);
    } catch (err) {
      say(`[agent] the terminal's turns were not read: ${(err as Error).message}`);
    }
    c.session.takeBack(read?.turns ?? null, read?.more ?? 0, read === null ? (why ?? 'its turns could not be read back') : why, failure);
    // The run's folder is under the port it was written for, whatever this server's is now.
    await rm(runFiles(options.root, away.port || options.port(), c.id).dir, { recursive: true, force: true }).catch(() => {});
  }

  function flush(conversation: string, l: Live): void {
    l.timer = null;
    if (l.pending === '') return;
    const data = l.pending;
    l.pending = '';
    options.push(conversation, { data, at: l.total - data.length });
  }

  function start(c: TerminalConversation, spawn: PtySpawn, file: string, args: string[], env: Record<string, string>, cols: number, rows: number): void {
    const pty = spawn(file, args, { name: 'xterm-256color', cols, rows, cwd: options.root, env });
    let settle: () => void = () => {};
    const l: Live = { pty, c, screen: [], size: 0, pending: '', total: 0, timer: null, ended: new Promise<void>((r) => (settle = r)), done: false, closing: false, typed: false, started: now(), alive: now() };
    lives.set(c.id, l);
    const output = pty.onData((data) => {
      l.screen.push(data);
      l.size += data.length;
      while (l.size > SCREEN_MAX && l.screen.length > 1) l.size -= l.screen.shift()!.length;
      l.pending += data;
      l.total += data.length;
      l.timer ??= setTimeout(() => flush(c.id, l), BATCH_MS);
      // A turn running that writes is alive: a long one stays shown past `TURN_STALE_MS` (once a minute at most).
      const at = now();
      if (at - l.alive >= ALIVE_MS) {
        l.alive = at;
        if (c.session.state().terminal?.turn === 'running') c.session.terminalTurn('alive');
      }
    });
    const exit = pty.onExit(({ exitCode, signal }) => {
      l.done = true;
      output.dispose();
      exit.dispose();
      // Windows: ConPTY's agent and its pipes outlive the program until killed -- they would keep this process up.
      if (platform === 'win32') {
        try {
          pty.kill();
        } catch {
          // Closed already.
        }
      }
      if (l.timer) clearTimeout(l.timer);
      flush(c.id, l);
      if (lives.get(c.id) === l) lives.delete(c.id);
      options.push(c.id, { exited: signal ? null : exitCode });
      // Ended by itself with a failure, or at once (a mode or flag the CLI refused, a login it wants): said, its last lines with it.
      const ms = now() - l.started;
      const failed = !l.closing && (signal ? true : exitCode !== 0 || (ms < EARLY_MS && !l.typed));
      const failure = failed ? { text: `Claude Code in the terminal ended by itself ${signal ? 'on a signal' : `with exit code ${exitCode}`} after ${Math.max(1, Math.round(ms / 1000))} s; the conversation is back here.`, next: lastLines(l.screen.join('')) || null } : null;
      void finish(c, null, failure).finally(settle);
    });
  }

  /**
   * The column's terminal opened again after a restart (D12): the session is the CLI's still (`away`, kept in
   * `session.json`), so no hand-over -- the run's files written anew (a token of this process's), the CLI started with the
   * session resumed as the manual Back and Continue would, the turns made there before counted from the first hand-over's
   * `before` still. `--resume` once the CLI has written the session; a conversation handed over and never sent there, its
   * `--session-id` again. A CLI that will not start: the column's again, said (`finish`), as Continue's would be.
   */
  async function again(c: TerminalConversation, away: TerminalState, request: TerminalOpenRequest): Promise<{ file?: string }> {
    // Tried, this process: a page reloaded after a refusal does not try (and say it) again -- the state says so (`tried`).
    if (away.tried) throw new Refused(409, 'Opening the terminal again was tried already since the dev server started: Back to the column, then continue in the terminal');
    c.session.terminalTried();
    let spawn: PtySpawn;
    try {
      spawn = await (options.pty ?? loadPty)();
    } catch (err) {
      throw new Refused(503, `The terminal needs node-pty, which is not installed here (${(err as Error).message}): npm install, or Back to the column`);
    }
    const env = withWindowsEssentials(options.env(), platform);
    env.TERM = 'xterm-256color';
    env.COLORTERM = 'truecolor';
    const bound = Number(env.MCP_TOOL_TIMEOUT);
    if (env.MCP_TOOL_TIMEOUT !== undefined && Number.isFinite(bound) && bound < LONGEST_MS + 5_000) env.MCP_TOOL_TIMEOUT = String(LONGEST_MS + 5_000);
    const run = await program(env);
    const port = options.port();
    const files = runFiles(options.root, port, c.id);
    const brief = options.brief();
    const resumed = await resumable(away);
    const settings = c.session.state().settings;
    const made = { sessionId: away.sessionId, resumed, settings, files, plugin: options.plugin };
    const argv = terminalArgs({ ...made, brief });
    const shell = terminalArgs({ ...made, brief: BRIEF_MARK });
    // The folder of a run written under another port: gone, this one's in its place.
    if (away.port !== 0 && away.port !== port) await rm(runFiles(options.root, away.port, c.id).dir, { recursive: true, force: true }).catch(() => {});
    const token = options.runs.issue(c.id);
    try {
      await writeRun(files, { port, token, level: settings.level, brief, node: options.node, command: null, stopFailure: await hasStopFailure(run.file, env) });
    } catch (err) {
      options.runs.revoke(c.id);
      throw err;
    }
    const command = commandLine(options.root, run.file, [...run.pre, ...shell], files.brief, platform);
    try {
      start(c, spawn, run.file, [...run.pre, ...argv], env, cells(request.cols, 80), cells(request.rows, 24));
    } catch (err) {
      await finish(c, `the terminal could not start again (${(err as Error).message})`);
      throw new Refused(500, `The terminal could not start again: ${(err as Error).message}`);
    }
    c.session.terminalLive(true, { command, port });
    say(`[agent] ${c.id} back in the terminal after a restart: ${command}`);
    return {};
  }

  /** Has the CLI written the session (`--resume`), or is it a conversation never sent there (`--session-id` again)? Unknown: resumed, as the hand-over had it. */
  async function resumable(away: TerminalState): Promise<boolean> {
    if (away.before > 0) return true;
    try {
      return (await options.messages(away.sessionId)).length > 0;
    } catch {
      return true;
    }
  }

  /** `open`'s work, one at a time a conversation (`opening`). */
  async function openNow(c: TerminalConversation, request: TerminalOpenRequest): Promise<{ file?: string }> {
    // The column's terminal, its CLI gone with the process before: opened again, the session the CLI's still (D12).
    const was = c.session.state().terminal;
    if (was && was.where === 'column' && !was.live && request.where === 'column') return again(c, was, request);
    // node-pty first: a missing one refuses before anything is handed over (D2).
    let spawn: PtySpawn | null = null;
    if (request.where === 'column') {
      try {
        spawn = await (options.pty ?? loadPty)();
      } catch (err) {
        throw new Refused(503, `The terminal needs node-pty, which is not installed here (${(err as Error).message}): npm install, or Copy resume command and run it in a terminal of your own`);
      }
    }
    // On Windows what a process cannot start without, whatever the environment given lacks (`withWindowsEssentials`).
    const env = withWindowsEssentials(options.env(), platform);
    env.TERM = 'xterm-256color';
    env.COLORTERM = 'truecolor';
    const bound = Number(env.MCP_TOOL_TIMEOUT);
    if (env.MCP_TOOL_TIMEOUT !== undefined && Number.isFinite(bound) && bound < LONGEST_MS + 5_000) env.MCP_TOOL_TIMEOUT = String(LONGEST_MS + 5_000);
    const run = await program(env);
    const port = options.port();
    const files = runFiles(options.root, port, c.id);
    let argv: string[] = [];
    const brief = options.brief();
    const state = await c.session.handOver(request.where, async (at: HandOver) => {
      const made = { sessionId: at.sessionId, resumed: at.resumed, settings: at.settings, files, plugin: options.plugin };
      argv = terminalArgs({ ...made, brief });
      const shell = terminalArgs({ ...made, brief: BRIEF_MARK });
      const before = at.resumed ? (await options.messages(at.sessionId).catch(() => [])).length : 0;
      const token = options.runs.issue(c.id);
      try {
        await writeRun(files, { port, token, level: at.settings.level, brief, node: options.node, command: request.where === 'own' ? commandFile(options.root, run.file, [...run.pre, ...shell], c.title, files.brief) : null, stopFailure: await hasStopFailure(run.file, env) });
      } catch (err) {
        options.runs.revoke(c.id);
        throw err;
      }
      return { command: commandLine(options.root, run.file, [...run.pre, ...shell], files.brief, platform), before, port };
    });
    if (request.where === 'own') return { file: files.command.slice(options.root.length + 1).split('\\').join('/') };
    try {
      start(c, spawn!, run.file, [...run.pre, ...argv], env, cells(request.cols, 80), cells(request.rows, 24));
    } catch (err) {
      await finish(c, `the terminal could not start (${(err as Error).message})`);
      throw new Refused(500, `The terminal could not start: ${(err as Error).message}`);
    }
    say(`[agent] ${c.id} continued in the terminal: ${state.command}`);
    return {};
  }

  return {
    async open(c, request) {
      if (request.where !== 'column' && request.where !== 'own') throw new Refused(422, 'where is column or own');
      if (lives.has(c.id)) throw new Refused(409, 'This conversation is in the terminal already');
      // Taken before the first await: two opens at once (an app window and a browser tab, a reload mid-request) start one CLI.
      if (opening.has(c.id)) throw new Refused(409, 'This conversation\'s terminal is opening already');
      opening.add(c.id);
      try {
        return await openNow(c, request);
      } finally {
        opening.delete(c.id);
      }
    },
    async close(c, force) {
      const away = c.session.state().terminal;
      if (!away) return;
      const l = lives.get(c.id);
      if (l) {
        l.closing = true;
        if (!l.done) {
          // Gracefully: a turn running stopped (Esc), the box cleared and the CLI left (Ctrl+C, twice more for good).
          const send = (keys: string): void => {
            try {
              l.pty.write(keys);
            } catch {
              // Gone.
            }
          };
          send('\x1b');
          for (const wait of [KEYS_MS / 3, (KEYS_MS * 2) / 3, KEYS_MS]) setTimeout(() => !l.done && send('\x03'), wait);
          // After the keys' last, `grace` for the CLI to go; then a hang-up, and as long again before the kill.
          const hard = setTimeout(() => {
            if (!l.done) hangUp(l.pty, 'SIGHUP');
          }, KEYS_MS + grace);
          const kill = setTimeout(() => {
            if (!l.done) hangUp(l.pty, 'SIGKILL');
          }, KEYS_MS + grace * 2);
          await l.ended;
          clearTimeout(hard);
          clearTimeout(kill);
          return;
        }
        await l.ended;
        return;
      }
      // The person's own terminal (D5): its CLI is not ours to end -- a session written just now may still be in use there.
      if (away.where === 'own' && !force) {
        const at = await options.modified(away.sessionId).catch(() => null);
        const ago = at === null ? null : now() - at;
        if (ago !== null && ago < RECENT_MS) throw new Refused(409, `The session was written ${Math.max(1, Math.round(ago / 1000))} s ago: is it still running in a terminal? Quit Claude Code there first -- or Back anyway`);
      }
      await finish(c, away.where === 'column' && !away.live ? 'the terminal had ended (the dev server restarted under it)' : null);
    },

    screen: (conversation) => lives.get(conversation)?.screen.join('') ?? '',
    end: (conversation) => lives.get(conversation)?.total ?? 0,

    input(conversation, data) {
      const l = lives.get(conversation);
      if (!l || l.done || typeof data !== 'string' || data.length > 64 * 1024) return;
      l.typed = true;
      l.pty.write(data);
      // The CLI asked (a permission prompt, a question): a key typed there is the person answering it. Esc alone
      // declines a permission -- the turn ends, firing no Stop -- and interrupts a turn running: ended quietly here. Esc
      // on a question (an MCP elicitation) declines it and the turn goes on: answered.
      const away = l.c.session.state().terminal;
      const turn = away?.turn;
      if (turn !== undefined && data === '\x1b' && !(turn === 'waiting' && away?.asking === 'question')) l.c.session.terminalTurn('quiet');
      else if (turn === 'waiting') l.c.session.terminalTurn('answered');
    },

    resize(conversation, cols, rows) {
      const l = lives.get(conversation);
      if (!l || l.done) return;
      try {
        l.pty.resize(cells(cols, 80), cells(rows, 24));
      } catch {
        // Ended meanwhile.
      }
    },

    async adopt(c) {
      const away = c.session.state().terminal;
      if (!away || away.where !== 'own') return false;
      // Its CLI calls the port it was written for: a server on another port cannot serve it -- not live, said.
      if (away.port !== options.port()) {
        c.session.terminalLive(false);
        return false;
      }
      let token: unknown;
      try {
        token = (JSON.parse(await readFile(runFiles(options.root, away.port, c.id).run, 'utf8')) as { token?: unknown }).token;
      } catch {
        token = undefined;
      }
      const kept = typeof token === 'string' && options.runs.adopt(c.id, token);
      c.session.terminalLive(kept);
      return kept;
    },

    live: (conversation) => {
      const l = lives.get(conversation);
      return l !== undefined && !l.done;
    },

    closeAll() {
      for (const l of lives.values()) {
        try {
          hangUp(l.pty, 'SIGHUP');
        } catch {
          // Gone.
        }
      }
    },
  };
}
