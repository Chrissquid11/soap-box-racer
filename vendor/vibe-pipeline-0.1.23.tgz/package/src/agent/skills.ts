/**
 * The skills Claude loads in a project, for the editor's Config ▸ Claude ▸ Skills page (Docs/agent.md §2,
 * "Skills"): `GET skills` lists them, `POST skills { name }` makes a new one of the project's.
 *
 * - **Three sources**: the project's own -- each `.claude/skills/<name>/SKILL.md` that is not a `vibe sync`
 *   copy (`SYNC_HEADER`), editable; the plugin's, the pipeline's `claude/skills/` (`CLAUDE_DIR`), named as the SDK
 *   names them (`vibe:vibe`, `qualified`) -- `node_modules/@vibe/pipeline/claude/skills/` in a published project,
 *   read-only, `engine/packages/pipeline/claude/skills/` in source mode, editable (a change to the engine); and
 *   the person's own, the names the sessions' `init` reported beyond those two, no path.
 * - **A synced copy is the engine's**: `vibe`'s and `gladius`'s are the plugin's rows (never listed twice); `engine`'s
 *   and `studio`'s, which no plugin has, are rows of their own (`engine`), each with the packages and versions its pages
 *   came from (read off the copies' `<!-- from … -->` lines) -- never the person's, never made over (409). A folder of
 *   the name whose `SKILL.md` has no header is the project's own, listed as theirs.
 * - **A path is the project's** (relative, `/`), as the Code card opens it; '' for a file outside the project
 *   (the workspace's sandbox, whose plugin is `../../packages/...`) or a user skill.
 *
 * Nothing at module level but constants.
 */
import { mkdir, readdir, readFile, realpath, writeFile } from 'node:fs/promises';
import { join, relative, sep } from 'node:path';
import { Refused } from '../assets/http.ts';
import { SKILL_NAME, type SkillRow, type SkillsAnswer } from './api-types.ts';
import { CLAUDE_DIR, PLUGIN, qualified } from './plugin.ts';
import { SYNC_HEADER } from './sync.ts';

/** What a new skill's answer says of when Claude has it. */
export const NEXT_CONVERSATION = 'Claude loads it from its next conversation';
export const LOADED_NOW = 'Claude has it now, in the conversations running, and loads it in every one after';

/** A SKILL.md's description: its frontmatter's `description:` (quoted or not, folded or not), else the first line of its body. */
export function describeSkill(text: string): string {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  let body = 0;
  if (lines[0]?.trim() === '---') {
    const end = lines.indexOf('---', 1);
    const front = end > 0 ? lines.slice(1, end) : [];
    body = end > 0 ? end + 1 : 0;
    const at = front.findIndex((l) => /^description\s*:/.test(l));
    if (at >= 0) {
      let value = front[at]!.replace(/^description\s*:\s*/, '').trim();
      if (value === '' || /^[>|][-+]?$/.test(value)) {
        // A block: the indented lines after it.
        const more: string[] = [];
        for (let i = at + 1; i < front.length && /^\s+\S/.test(front[i]!); i++) more.push(front[i]!.trim());
        value = more.join(' ');
      }
      if (value.length >= 2 && (value[0] === '"' || value[0] === "'") && value.at(-1) === value[0]) value = value.slice(1, -1).replace(/\\"/g, '"');
      if (value !== '') return value;
    }
  }
  for (const line of lines.slice(body)) {
    const words = line.trim();
    if (words === '' || words === SYNC_HEADER || words.startsWith('<!--')) continue;
    return words.replace(/^#+\s*/, '');
  }
  return '';
}

/** A new skill's SKILL.md. */
export function skillTemplate(name: string): string {
  return [
    '---',
    `name: ${name}`,
    'description: "What this skill is for -- when Claude should load it"',
    '---',
    '',
    `# ${name}`,
    '',
    'Write here what Claude should know or do when this skill is loaded: the rules, the steps, the files to read first.',
    'Say in the description above, in one sentence, when it applies: Claude reads only that to decide whether to load the skill.',
    'Longer reference can go in files beside this one, each named from here; keep this file short.',
    '',
  ].join('\n');
}

/** The folders of `dir`, sorted; none readable, none. */
async function folders(dir: string): Promise<string[]> {
  try {
    return (await readdir(dir, { withFileTypes: true })).filter((d) => d.isDirectory()).map((d) => d.name).sort();
  } catch {
    return [];
  }
}

/**
 * The project's own skills' names: the folders of its `.claude/skills/` (a `vibe sync` copy among them), and the
 * plugin's (`plugin.ts`) as the SDK names them, `vibe:gladius` -- every name the skills note (`session.ts`) and
 * `listSkills` count as no person's own.
 */
export async function projectSkills(root: string, plugin: string = CLAUDE_DIR): Promise<Set<string>> {
  return new Set([...(await folders(join(root, '.claude', 'skills'))), ...(await folders(join(plugin, 'skills'))).map(qualified)]);
}

const text = (file: string): Promise<string | null> => readFile(file, 'utf8').catch(() => null);

/** A package's name and version, from the `package.json` in `dir`; undefined when there is none. */
async function packageOf(dir: string): Promise<string | undefined> {
  const body = await text(join(dir, 'package.json'));
  if (body === null) return undefined;
  try {
    const { name, version } = JSON.parse(body) as { name?: unknown; version?: unknown };
    return typeof name === 'string' ? `${name}${typeof version === 'string' && version !== '' ? ` ${version}` : ''}` : undefined;
  } catch {
    return undefined;
  }
}

/** Where a synced skill's pages came from: each copy's `<!-- from <package version>: <file> -->`, distinct and sorted. */
async function syncedFrom(dir: string): Promise<string> {
  const from = new Set<string>();
  let names: string[] = [];
  try {
    names = (await readdir(dir)).filter((n) => n.endsWith('.md'));
  } catch {
    // None.
  }
  for (const name of names) {
    const m = /^<!-- from (.+?): \S+ -->$/m.exec((await text(join(dir, name))) ?? '');
    if (m) from.add(m[1]!);
  }
  return [...from].sort().join(', ');
}

/** `file` as the project names it: relative with `/`, or '' outside it. Both real paths: a link, or `/var` against `/private/var`, says nothing. */
async function projectPath(root: string, file: string): Promise<string> {
  const real = await realpath(file).catch(() => file);
  const realRoot = await realpath(root).catch(() => root);
  const r = relative(realRoot, real);
  return r === '' || r.startsWith('..') || r.startsWith(sep) || /^[a-zA-Z]:/.test(r) ? '' : r.split(sep).join('/');
}

/**
 * `GET skills`: the project's, the plugin's, the engine's synced skills, then the person's own -- `loaded`, the names the sessions' `init`
 * reported (null: none has started, and the person's are not known yet).
 */
export async function listSkills(root: string, loaded: readonly string[] | null, plugin: string = CLAUDE_DIR): Promise<SkillsAnswer> {
  const project: SkillRow[] = [];
  const synced: SkillRow[] = [];
  const pluginNames = new Set(await folders(join(plugin, 'skills')));
  const pipeline = await packageOf(join(plugin, '..'));
  const local = join(root, '.claude', 'skills');
  for (const name of await folders(local)) {
    const body = await text(join(local, name, 'SKILL.md'));
    if (body === null) continue;
    if (body.includes(SYNC_HEADER)) {
      // vibe's and gladius's copies are the plugin's rows; engine's and studio's are the engine's own.
      if (!pluginNames.has(name)) {
        const from = await syncedFrom(join(local, name));
        synced.push({ name, source: 'engine', path: `.claude/skills/${name}/SKILL.md`, description: describeSkill(body), editable: false, ...(from !== '' ? { from } : {}) });
      }
      continue;
    }
    project.push({ name, source: 'project', path: `.claude/skills/${name}/SKILL.md`, description: describeSkill(body), editable: true });
  }
  const plugins: SkillRow[] = [];
  for (const name of await folders(join(plugin, 'skills'))) {
    const file = join(plugin, 'skills', name, 'SKILL.md');
    const body = await text(file);
    if (body === null) continue;
    const path = await projectPath(root, file);
    plugins.push({ name: qualified(name), source: 'plugin', path, description: describeSkill(body), editable: path !== '' && !path.split('/').includes('node_modules'), ...(pipeline !== undefined ? { from: pipeline } : {}) });
  }
  const known = await projectSkills(root, plugin);
  const user: SkillRow[] = [...new Set(loaded ?? [])]
    .filter((name) => !known.has(name))
    .sort()
    .map((name) => ({ name, source: 'user', path: '', description: '', editable: false }));
  return { skills: [...project, ...plugins, ...synced, ...user], heard: loaded !== null };
}

/** `POST skills { name }`: `.claude/skills/<name>/SKILL.md` from the template, as its row. 400 a bad name, 409 one there. */
export async function makeSkill(root: string, name: unknown, plugin: string = CLAUDE_DIR): Promise<SkillRow> {
  if (typeof name !== 'string' || !SKILL_NAME.test(name)) throw new Refused(400, 'a skill\'s name is lowercase letters, digits and -, a letter or digit first, at most 41');
  const theirs = await folders(join(plugin, 'skills'));
  if (theirs.includes(name)) throw new Refused(409, `${name}: ${theirs.join(' and ')} are the ${PLUGIN} plugin's -- pick another name`);
  const dir = join(root, '.claude', 'skills', name);
  await mkdir(join(root, '.claude', 'skills'), { recursive: true });
  try {
    await mkdir(dir);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'EEXIST') throw new Refused(409, `.claude/skills/${name} is there already`);
    throw err;
  }
  const body = skillTemplate(name);
  await writeFile(join(dir, 'SKILL.md'), body, { flag: 'wx' });
  return { name, source: 'project', path: `.claude/skills/${name}/SKILL.md`, description: describeSkill(body), editable: true };
}

