/**
 * The conversations on disk (Docs/agent.md §2, Surviving a restart):
 * `.cache/agent/<port>/`, gitignored and outside the watcher (`watch.ignored`).
 * One folder a port: two dev servers on one project (`npm run dev` and a
 * second on `--port 5191`) keep conversations of their own, never one log
 * interleaved, nor one's failed resume dropping the other's session. In it,
 * a folder per open conversation, `<port>/<id>/`, and the index of the open
 * ones in order with their titles, `<port>/conversations.json`
 * (`readIndex`, `writeIndex`).
 *
 * - **`session.json`**: `{ sessionId, settings, said }`, written at the
 *   CLI's `init` and whenever the settings change or a note is said once. A
 *   new `npm run dev` reads it and its first attach passes `resume:
 *   sessionId` -- sessions persist by default (`persistSession`), so the
 *   conversation goes on. `said`: the usage notes said, by when their limit
 *   resets, and the skills noted -- said once a conversation, not once a
 *   process.
 * - **`log.jsonl`**: each entry appended as it is made, one JSON line, cut to
 *   its last 500 when it reaches 1000 lines; read back whole at start.
 * - **Clear** deletes both: the session id and the transcript go with it; a
 *   conversation closed, its folder (`removeConversation`).
 * - **The one conversation of before** (`<port>/{session.json,log.jsonl}`) is
 *   moved into the first conversation's folder the first time
 *   (`moveIntoConversation`): it comes through whole, its session id with it,
 *   and resumes. A conversation adopted live from a dev server of before --
 *   an in-process restart onto this code -- goes on writing there (the old
 *   bundle's store, `legacy` in the index) and is moved at the next start.
 * - **The flat store of before** (`.cache/agent/{session.json,log.jsonl}`,
 *   one for every port) is moved into the default port's folder (5190, `npm
 *   run dev`'s) as it starts without a conversation of its own, and `read`
 *   says so (`moved`) -- only a conversation there is to go on with, one
 *   with a `sessionId`: a cleared one stays where it is. Another port takes
 *   it only once the default one has a conversation of its own, and so never
 *   will: a reviewer's `--port 5191` does not walk off with it.
 *
 * Writes go one at a time, in order; a line that does not parse (a write cut
 * short) is skipped when read. Nothing at module level.
 */
import { appendFile, lstat, mkdir, readFile, rename, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { writeAtomic } from '../assets/fs.ts';
import type { AgentRow, AgentSettings, CommandRow, Entry, OutsideLevel, TerminalState, UsageFacts } from './api-types.ts';
import { isOutside } from '../mcp/outside.ts';

/** Where the conversations are kept, under the project root: a folder per port. */
export const STORE_DIR = '.cache/agent';

/** `npm run dev`'s port: the flat store of before is its, first. */
export const DEFAULT_PORT = 5190;

/** The index of a port's open conversations, in its folder. */
export const INDEX_FILE = 'conversations.json';

/** One open conversation, as the index keeps it. */
export interface IndexEntry {
  id: string;
  title: string;
  /** Its title is the first prompt's, or the person's: no later prompt renames it. */
  titled: boolean;
  /** Its files are still where the one conversation of before kept them (`<port>/`): adopted live, moved at the next start. */
  legacy?: boolean;
}

/**
 * The port's index: its open conversations in order, and what is the project's rather than one conversation's --
 * `fixBoot` (studio mode's recovery sends a failed boot to Claude, Docs/studio.md §1), absent until first set.
 */
export interface Index {
  open: IndexEntry[];
  fixBoot?: boolean;
  /** What outside clients of `/__mcp` may do (Docs/mcp.md M7): absent until first set -- read-only. */
  outside?: OutsideLevel;
}

/** A conversation's id is its folder's name: this and nothing else. */
export const isConversationId = (id: unknown): id is string => typeof id === 'string' && /^[a-z0-9-]{1,40}$/.test(id);

const portDir = (root: string, port: number): string => join(root, STORE_DIR, String(port));
const exists = (file: string): Promise<boolean> => lstat(file).then(() => true, () => false);

/** The port's index: its open conversations in order, and the project's settings kept there. Null: none written yet. */
export async function readIndex(root: string, port: number): Promise<Index | null> {
  try {
    const data = JSON.parse(await readFile(join(portDir(root, port), INDEX_FILE), 'utf8')) as { open?: unknown; fixBoot?: unknown; outside?: unknown };
    if (!Array.isArray(data.open)) return null;
    const open = data.open.flatMap((e): IndexEntry[] => {
      const r = e as Record<string, unknown>;
      if (!isConversationId(r.id)) return [];
      return [{ id: r.id, title: typeof r.title === 'string' ? r.title : 'New conversation', titled: r.titled === true, ...(r.legacy === true ? { legacy: true } : {}) }];
    });
    return { open, ...(typeof data.fixBoot === 'boolean' ? { fixBoot: data.fixBoot } : {}), ...(isOutside(data.outside) ? { outside: data.outside } : {}) };
  } catch {
    return null;
  }
}

/** The port's index written, whole: the open conversations, and `fixBoot` beside them when it has been set. */
export async function writeIndex(root: string, port: number, index: Readonly<Index>): Promise<void> {
  await mkdir(portDir(root, port), { recursive: true });
  await writeAtomic(join(portDir(root, port), INDEX_FILE), `${JSON.stringify(index, null, 2)}\n`);
}

/**
 * The one conversation of before -- `<port>/session.json` and `log.jsonl`,
 * after the flat store's own move into the port's folder -- moved into
 * `<port>/<id>/`. `had`: there was one; `moved`: it came from the flat store
 * (`.cache/agent/`) just now, which the conversation says.
 */
export async function moveIntoConversation(root: string, port: number, id: string, defaultPort = DEFAULT_PORT): Promise<{ had: boolean; moved: boolean }> {
  const moved = await adoptFlat(root, port, defaultPort).catch(() => false);
  const dir = portDir(root, port);
  const theirs = [join(dir, 'session.json'), join(dir, 'log.jsonl')];
  const there = await Promise.all(theirs.map(exists));
  if (!there.some(Boolean)) return { had: false, moved };
  const into = join(dir, id);
  await mkdir(into, { recursive: true });
  const mine = [join(into, 'session.json'), join(into, 'log.jsonl')];
  for (let i = 0; i < theirs.length; i++) if (there[i]) await rename(theirs[i]!, mine[i]!);
  return { had: true, moved };
}

/** A closed conversation's folder, gone: its log is not needed. */
export async function removeConversation(root: string, port: number, id: string): Promise<void> {
  if (!isConversationId(id)) return;
  // Retried: a file closing under it as it goes (ENOTEMPTY, EBUSY) is a moment's, not a failure.
  await rm(join(portDir(root, port), id), { recursive: true, force: true, maxRetries: 3, retryDelay: 20 });
}

/**
 * The flat store of before, moved into `<port>/` if this port has no
 * conversation of its own, the flat one has one to go on with (a
 * `sessionId`), and this is the default port -- or that one has a
 * conversation of its own already, and so will never take it. True if it was.
 */
async function adoptFlat(root: string, port: number, defaultPort: number): Promise<boolean> {
  const flat = [join(root, STORE_DIR, 'session.json'), join(root, STORE_DIR, 'log.jsonl')] as const;
  const dir = portDir(root, port);
  const sessionFile = join(dir, 'session.json');
  const logFile = join(dir, 'log.jsonl');
  const theirs = await Promise.all(flat.map(exists));
  if (!theirs.some(Boolean)) return false;
  if ((await exists(sessionFile)) || (await exists(logFile)) || (await exists(join(dir, INDEX_FILE)))) return false;
  const kept = await readFile(flat[0], 'utf8').then((text) => JSON.parse(text) as Kept, () => null);
  if (typeof kept?.sessionId !== 'string' || kept.sessionId === '') return false;
  if (port !== defaultPort && !(await exists(portDir(root, defaultPort)))) return false;
  await mkdir(dir, { recursive: true });
  const mine = [sessionFile, logFile];
  for (let i = 0; i < flat.length; i++) if (theirs[i]) await rename(flat[i]!, mine[i]!);
  return true;
}

/** What `session.json` keeps. */
export interface Kept {
  sessionId?: string;
  settings?: Partial<AgentSettings>;
  /** Said once a conversation: each usage note's key (its limit and when it resets), and the skills noted. */
  said?: { usage?: string[]; skills?: string[] };
  /** What `/usage` shows, as last heard (`usage.ts`; read back by `readUsage`). */
  usage?: UsageFacts;
  /** The subagents and background tasks of the last turn (`agents.ts`; read back by `AgentTracker.restore`). */
  agents?: AgentRow[];
  /** The CLI's slash commands as last heard: the prompt box's list is whole straight after a restart, before the CLI is up. */
  commands?: CommandRow[];
  /** In the terminal (Docs/terminal.md D1): the CLI's until Back -- a restart still knows. */
  terminal?: TerminalState;
}

export interface Store {
  /** What a previous process left: the session and settings, and the log; `moved`, taken over from the flat store of before. */
  read(): Promise<{ kept: Kept; entries: Entry[]; moved: boolean }>;
  save(kept: Kept): Promise<void>;
  /** One entry, appended in order after whatever is being written. */
  append(entry: Entry): void;
  /** Both files gone (Clear). */
  clear(): Promise<void>;
  /** Resolves once every write asked for so far is done. */
  flushed(): Promise<void>;
}

/**
 * The store of a conversation of the dev server on `port`:
 * `.cache/agent/<port>/<id>/`. Without an `id`, `.cache/agent/<port>/` --
 * the one conversation of before, which takes the flat store over itself.
 * `moved`: the registry moved the flat store in for it, which `read` says.
 */
export function createStore(root: string, port: number, options: { keep?: number; cutAt?: number; warn?: (line: string) => void; defaultPort?: number; id?: string; moved?: boolean } = {}): Store {
  const dir = options.id === undefined ? portDir(root, port) : join(portDir(root, port), options.id);
  const sessionFile = join(dir, 'session.json');
  const logFile = join(dir, 'log.jsonl');
  const keep = options.keep ?? 500;
  const cutAt = options.cutAt ?? 1000;
  const warn = options.warn ?? ((line: string) => console.error(line));
  const defaultPort = options.defaultPort ?? DEFAULT_PORT;
  let lines = 0;
  let queue: Promise<void> = Promise.resolve();
  /** Writes, one at a time; a failure said and passed over. */
  const then = (work: () => Promise<void>): Promise<void> => {
    queue = queue.then(work).catch((err: unknown) => warn(`[agent] ${STORE_DIR}/${port}: ${(err as Error).message}`));
    return queue;
  };
  let said = options.moved === true;
  return {
    async read() {
      let moved = said;
      said = false;
      try {
        if (options.id === undefined) moved = await adoptFlat(root, port, defaultPort);
      } catch (err) {
        warn(`[agent] ${STORE_DIR}: the conversation kept before each port had a folder could not be moved: ${(err as Error).message}`);
      }
      let kept: Kept = {};
      try {
        const data = JSON.parse(await readFile(sessionFile, 'utf8')) as unknown;
        if (typeof data === 'object' && data !== null) kept = data as Kept;
      } catch {
        // None yet, or not readable: a fresh conversation.
      }
      const entries: Entry[] = [];
      try {
        for (const line of (await readFile(logFile, 'utf8')).split('\n')) {
          if (line.trim() === '') continue;
          try {
            const entry = JSON.parse(line) as Entry;
            if (typeof entry.seq === 'number' && typeof entry.kind === 'string') entries.push(entry);
          } catch {
            // A line cut short.
          }
        }
      } catch {
        // No log yet.
      }
      lines = entries.length;
      return { kept, entries, moved };
    },
    save(kept) {
      return then(async () => {
        await mkdir(dir, { recursive: true });
        await writeAtomic(sessionFile, `${JSON.stringify(kept, null, 2)}\n`);
      });
    },
    append(entry) {
      void then(async () => {
        await mkdir(dir, { recursive: true });
        await appendFile(logFile, `${JSON.stringify(entry)}\n`);
        if (++lines < cutAt) return;
        const all = (await readFile(logFile, 'utf8')).split('\n').filter((l) => l.trim() !== '');
        const last = all.slice(-keep);
        await writeAtomic(logFile, `${last.join('\n')}\n`);
        lines = last.length;
      });
    },
    clear() {
      return then(async () => {
        await rm(sessionFile, { force: true });
        await rm(logFile, { force: true });
        lines = 0;
      });
    },
    flushed: () => queue,
  };
}
