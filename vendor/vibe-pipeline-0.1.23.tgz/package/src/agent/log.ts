/**
 * The conversation's log (Docs/agent.md §2): entries numbered in order, what
 * a page asks for since the last one it has, and the caps. Pure -- no `node:`,
 * no package -- so it is tested alone, and the page's own model of it
 * (`packages/editor/src/agent/transcript.ts`, phase 2) reads the same shapes.
 *
 * - **Numbered from 1, never reused.** `seq` goes on across a Clear (the
 *   "New conversation" rule says the page drops what it has) and across a
 *   restart (the log read back from `.cache/agent/log.jsonl` sets where it
 *   goes on from); a new process has a new `epoch` in the state, so a page
 *   tells a restart from a gap.
 * - **Each entry names its process** (`epoch`, the state's): a page saying
 *   the last failure says one of this process's, never the one before a
 *   restart.
 * - **The caps**: the last 500 entries, and "Earlier turns are not kept"
 *   above them for a page further behind; a tool's detail at most 160
 *   characters; never an image's bytes, only how many.
 */
import { STUDIO_TOOLS } from '../mcp/catalog.ts';
import { summaryOf } from '../mcp/tools/index.ts';
import type { Entry, EntryBody } from './api-types.ts';

/** Entries kept: the transcript draws them whole. */
export const KEEP = 500;

/** A tool call's detail, at most. */
export const DETAIL = 160;

/** The rule a page further behind than the cap sees first. */
export const NOT_KEPT = 'Earlier turns are not kept';

/** `text` cut to `max` characters, an ellipsis last when cut. */
export function clip(text: string, max = DETAIL): string {
  const one = text.replace(/\s+/g, ' ').trim();
  return one.length > max ? `${one.slice(0, max - 1)}…` : one;
}

/** What the studio's tools are called by the agent: `mcp__studio__scene_set` (Docs/mcp.md; the catalogue's own). */
export { STUDIO_TOOLS };

/**
 * `path` relative to `root` with `/`, when it is under it; null else. Under a Windows root, either separator on
 * either side (a path the CLI names has `\`) and any case (Windows' names have none). Pure.
 */
export function underRoot(path: string, root: string): string | null {
  if (root === '') return null;
  // A Windows root (`C:\…`, `C:/…`): either separator, the case of no letter matters. A POSIX one as it is (a `\` is a name's there).
  if (/^[A-Za-z]:[\\/]/.test(root)) {
    const at = path.replace(/\\/g, '/');
    const base = `${root.replace(/\\/g, '/').replace(/\/$/, '')}/`;
    return at.toLowerCase().startsWith(base.toLowerCase()) ? at.slice(base.length) : null;
  }
  const base = root.endsWith('/') ? root : `${root}/`;
  return path.startsWith(base) ? path.slice(base.length) : null;
}

/**
 * A tool call in one line (Vibe3D's `summarise`): its path, command, pattern
 * or description -- the first it has -- cut to 160 characters, a path made
 * relative to `root` when it is under it. An editor tool's, its own words.
 */
export function summarise(tool: string, input: unknown, root = ''): string {
  const record = typeof input === 'object' && input !== null ? (input as Record<string, unknown>) : {};
  if (tool.startsWith(STUDIO_TOOLS)) return clip(summaryOf(tool.slice(STUDIO_TOOLS.length), record));
  for (const key of ['file_path', 'notebook_path', 'path', 'command', 'pattern', 'url', 'query', 'description', 'prompt', 'subject', 'skill']) {
    const value = record[key];
    if (typeof value !== 'string' || value === '') continue;
    const under = underRoot(value, root);
    return clip(under ?? value);
  }
  return tool;
}

/** The numbered log of one conversation, the last `KEEP` entries of it. */
export class Log {
  /** What is kept, oldest first. */
  readonly entries: Entry[] = [];
  /** The last `seq` given. */
  seq = 0;
  /** The `seq` of the newest entry cut by the cap, 0 if none was. */
  private cut = 0;
  private readonly keep: number;
  /** The dev-server process making entries now: each one is stamped with it. */
  private readonly epoch: string | undefined;

  constructor(keep = KEEP, epoch?: string) {
    this.keep = keep;
    this.epoch = epoch;
  }

  /** An entry, numbered, stamped with the process and kept; the oldest goes past the cap. */
  add(body: EntryBody, at: number): Entry {
    const entry = { ...body, seq: ++this.seq, at, ...(this.epoch !== undefined ? { epoch: this.epoch } : {}) } as Entry;
    this.entries.push(entry);
    while (this.entries.length > this.keep) this.cut = this.entries.shift()!.seq;
    return entry;
  }

  /**
   * The entries after `since` (0: all kept). A page behind the cap gets the
   * rule first, numbered as the last entry it lost, so it is new to the page
   * and before everything kept.
   */
  since(since: number): Entry[] {
    const after = this.entries.filter((e) => e.seq > since);
    if (this.cut === 0 || since >= this.cut) return after;
    const first = this.entries[0];
    return [{ kind: 'rule', text: NOT_KEPT, reset: false, seq: this.cut, at: first?.at ?? 0 }, ...after];
  }

  /** Everything gone but one rule, which says so (`reset`): a new conversation. Numbering goes on. */
  reset(text: string, at: number): Entry {
    this.entries.length = 0;
    this.cut = 0;
    return this.add({ kind: 'rule', text, reset: true }, at);
  }

  /** Entries read back from disk, in order: kept as they were, numbering going on from the last. */
  load(entries: readonly Entry[]): void {
    this.entries.length = 0;
    this.cut = 0;
    for (const entry of entries) {
      if (entry.seq <= this.seq && this.entries.length > 0) continue;
      this.entries.push(entry);
      this.seq = Math.max(this.seq, entry.seq);
    }
    while (this.entries.length > this.keep) this.cut = this.entries.shift()!.seq;
    // A log that was cut before it was written down starts after a gap: say so too.
    const first = this.entries[0];
    if (first !== undefined && first.seq > 1 && !(first.kind === 'rule' && first.reset)) this.cut = Math.max(this.cut, first.seq - 1);
  }
}
