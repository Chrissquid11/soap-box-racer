/**
 * Review: the quality bar (Docs/agent.md §3, Vibe3D's D109) -- the bar table,
 * `MAX_REVIEWS`, the loop's wording, and reading the critic: its file and its
 * score.
 *
 * - **The bar table and `MAX_REVIEWS` are here once**: the loop words them,
 *   the state carries them to the picker and the card's head.
 * - **The critic is the package's `claude/agents/code-critic.md`** (`plugin.ts`):
 *   its frontmatter (`tools`, `model`, `maxTurns`) and its brief are the
 *   file's; the SDK loads it from the plugin as `vibe:code-critic`, and from a
 *   project's `.claude/agents/` -- where `vibe sync` writes a copy for a
 *   terminal session -- as `code-critic`: `isCritic` knows both. This module
 *   only reads it: its tools, for the hook that holds the critic to them
 *   (`hooks.ts`), and that it is there at all -- once a query, as the CLI reads
 *   its own copy once: an edit to the file applies from the next Clear, or the
 *   next `npm run dev`.
 * - **The score is the critic's**: `criticScore` reads `SCORE: n/10` from its
 *   report -- the `tool_use_result` of the `Agent` call that launched it --
 *   never the author's retelling. A critic run in the background answers
 *   `async_launched`, which has no report: said, not scored.
 * - **The loop is an instruction**, appended to a turn sent with a bar: launch
 *   the critic, act below the bar, put a worse round back with `Edit` (never
 *   `git`: the host's `ask` rules stop that), stop at the bar or the fifth
 *   review. What the critic is told is the host's (`hooks.ts`), not the author's.
 *
 * Nothing at module level but constants.
 */
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { BarChoice, ReviewBar } from './api-types.ts';
import { CLAUDE_DIR, qualified } from './plugin.ts';

/** The critic's name: its file's name and its `subagent_type`. */
export const CRITIC = 'code-critic';

/** Where a project's own critic is, under its root: `vibe sync`'s copy, or one the project wrote to override the package's. */
export const CRITIC_FILE = '.claude/agents/code-critic.md';

/** The package's critic: the one read, the project's only where this is missing. */
export const PLUGIN_CRITIC = join(CLAUDE_DIR, 'agents', 'code-critic.md');

/** Is this the critic's name: bare (a project's `.claude/agents/`), or the plugin's (`vibe:code-critic`). */
export const isCritic = (name: unknown): boolean => name === CRITIC || name === qualified(CRITIC);

/** Reviews a turn may spend before it stops, bar met or not. */
export const MAX_REVIEWS = 5;

/** The bars, None first (the default). */
export const BARS: readonly BarChoice[] = [
  { value: 'none', label: 'None', score: null },
  { value: 'ok', label: 'ok', score: 5 },
  { value: 'good', label: 'good', score: 7 },
  { value: 'very-good', label: 'very good', score: 8 },
  { value: 'excellent', label: 'excellent', score: 9 },
  { value: 'perfect', label: 'perfect', score: 10 },
];

export function isBar(value: unknown): value is ReviewBar {
  return BARS.some((bar) => bar.value === value);
}

/** The score a bar asks for; null for none. */
export function barScore(bar: ReviewBar): number | null {
  return BARS.find((b) => b.value === bar)?.score ?? null;
}

/** The critic's score out of its report: `SCORE: n/10`, bold or not, anywhere in it (the brief puts it first). */
export function criticScore(report: string): number | undefined {
  const match = /SCORE\**\s*:\s*\**\s*(\d+(?:\.\d+)?)\s*\/\s*10/i.exec(report);
  if (!match) return undefined;
  const score = Number(match[1]);
  return score >= 0 && score <= 10 ? score : undefined;
}

/** Is this tool call the main thread launching the critic? (`Task` is the `Agent` tool's older name.) */
export function isCriticLaunch(tool: string, input: unknown): boolean {
  if (tool !== 'Agent' && tool !== 'Task') return false;
  return typeof input === 'object' && input !== null && isCritic((input as Record<string, unknown>).subagent_type);
}

/** What a critic's `tool_use_result` says: its report and score, or why there is none. */
export interface CriticReport {
  report: string | null;
  score: number | null;
  note: string | null;
}

/**
 * The critic's answer, from the `tool_use_result` of the call that launched it
 * (`AgentOutput`): `completed` holds the report; `async_launched` means it ran
 * in the background, and nothing can be read yet.
 */
export function criticReport(result: unknown): CriticReport {
  const r = typeof result === 'object' && result !== null ? (result as Record<string, unknown>) : {};
  if (r.status === 'async_launched' || r.status === 'remote_launched') {
    return { report: null, score: null, note: 'the critic ran in the background: no score read' };
  }
  let text = '';
  if (typeof result === 'string') text = result;
  else if (Array.isArray(r.content)) {
    text = r.content
      .map((part) => (typeof part === 'object' && part !== null && (part as { type?: unknown }).type === 'text' ? String((part as { text?: unknown }).text ?? '') : ''))
      .join('\n')
      .trim();
  }
  if (text === '') return { report: null, score: null, note: 'the critic gave no report' };
  const score = criticScore(text);
  return { report: text, score: score ?? null, note: score === undefined ? 'the report has no SCORE line' : null };
}

/**
 * The loop, appended to a turn sent with a bar (§3). It tells the author what
 * to do with the critic, never what the critic is told: the host writes that
 * (`hooks.ts`), so the critic hears no bar, no round and no opinion of the work.
 */
export function reviewLoop(bar: number, label: string, critic = CRITIC): string {
  return [
    `## Review: bar ${bar}/10 (${label})`,
    '',
    'The person set a quality bar for this turn. Doing what they asked is the first half of it;',
    'a review loop is the second, and the turn is not done until the loop ends.',
    '',
    '1. Do the request.',
    `2. Launch the \`${critic}\` subagent with the Agent tool (\`subagent_type: "${critic}"\`,`,
    '   `run_in_background: false`). The dev server writes what it is told -- the request and the',
    '   files this turn changed -- so your own prompt to it is replaced: one line will do.',
    '3. Its report begins `SCORE: n/10`; the dev server reads it from there.',
    `   At ${bar} or more, stop: the turn is done.`,
    `4. Below ${bar}, with fewer than ${MAX_REVIEWS} reviews spent: act on its list, highest impact`,
    '   first, then launch a fresh critic -- never one that has seen an earlier round.',
    "   - The person's request outranks the critic's advice: skip a suggestion that goes against",
    '     it, and say which and why.',
    '   - If a round scored lower than the one before, put that round\'s changes back first, with',
    '     Edit -- never with git, which would take the person\'s own uncommitted work with it --',
    '     then try something else.',
    `5. Stop after review ${MAX_REVIEWS} whether or not the bar is met. End with the last score and`,
    '   what you did not get to, so the person can decide what next.',
  ].join('\n');
}

// ---------------------------------------------------------------- the critic's file

/** The critic as its file has it. */
export interface Critic {
  /** Its `tools`, as named. */
  tools: string[];
  model: string | null;
  maxTurns: number | null;
  /** The body: its brief. */
  brief: string;
}

/** The critic's file read: its frontmatter (a `key: value` line each, `tools` comma-separated or a list) and its body. */
export function parseCritic(text: string): Critic | { why: string } {
  const match = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(text);
  if (!match) return { why: `${CRITIC_FILE} has no frontmatter` };
  const fields = new Map<string, string>();
  const lists = new Map<string, string[]>();
  let listKey: string | undefined;
  for (const line of match[1]!.split(/\r?\n/)) {
    const item = /^\s*-\s+(.+)$/.exec(line);
    if (item && listKey !== undefined) {
      lists.get(listKey)!.push(item[1]!.trim());
      continue;
    }
    const pair = /^([A-Za-z][\w-]*)\s*:\s*(.*)$/.exec(line);
    if (!pair) continue;
    listKey = undefined;
    if (pair[2]!.trim() === '') {
      listKey = pair[1]!;
      lists.set(listKey, []);
    } else fields.set(pair[1]!, pair[2]!.trim());
  }
  const tools = lists.get('tools') ?? (fields.get('tools') ?? '').split(',').map((s) => s.trim()).filter((s) => s !== '');
  const turns = Number(fields.get('maxTurns'));
  return {
    tools,
    model: fields.get('model') ?? null,
    maxTurns: Number.isInteger(turns) && turns > 0 ? turns : null,
    brief: match[2]!.trim(),
  };
}

/**
 * The critic's file, read: the package's (`plugin`: `PLUGIN_CRITIC`, or a
 * test's) first. The fallback is the project's under `root` (`CRITIC_FILE`),
 * read only where the package's is missing -- a package installed without its
 * `claude/`, or a project bringing a critic of its own in its place. Why not,
 * when neither is there or readable.
 */
export async function readCritic(root: string, plugin = PLUGIN_CRITIC): Promise<Critic | { why: string }> {
  for (const file of [plugin, join(root, CRITIC_FILE)]) {
    let text: string;
    try {
      text = await readFile(file, 'utf8');
    } catch {
      continue;
    }
    return parseCritic(text);
  }
  return { why: `the critic did not load: neither the vibe plugin's code-critic.md nor ${CRITIC_FILE}` };
}
