/**
 * A conversation (Docs/agent.md §2): the Agent SDK's `query` with a
 * streaming input that stays open between turns, started on the page's first
 * `POST attach` of it -- never at server start -- and kept until Clear,
 * across page reloads and dev-server restarts. The card's tabs are several of
 * these at once (`conversations.ts`): each turn names its conversation's
 * title (`title`), snapshots go through the port's kept index one at a time
 * (`serial`), and Undo this turn counts the other conversations' later turns
 * too (`later`), naming whose.
 *
 * - **The query's options are §2's table**: the project as `cwd`; every
 *   settings source and every skill, said; the package's Claude files as a
 *   plugin (`plugin.ts`: the skills and the critic, a project's `.claude/` or
 *   not); the host's `ask` rules
 *   (`permissions.ts`' `HOST_ASK`) as flag settings, this session's alone;
 *   Claude Code's own system prompt with the dev server's brief appended;
 *   `permissionMode: 'default'`, so `canUseTool` (`permissions.ts`) is asked;
 *   the `PreToolUse` hook (`hooks.ts`); the model and effort only when set;
 *   file checkpointing; partial messages; `resume` with the kept session id;
 *   `env.ts`'s environment and the `claude` on its `PATH`; stderr to the
 *   terminal, its last 40 lines kept for a failure's entry.
 * - **The SDK is imported here, inside `start`**: `vite build` loads the
 *   config, and `vite.ts` with it, and never this module's import of it. An
 *   SDK that will not import is `available: false`, said in the card.
 * - **Startup checks**, from `initializationResult()`: the account (none from
 *   the first-party provider is "not logged in"), the models (D108), and the
 *   critic among the agents -- or Review is disabled, saying why. The
 *   critic's file is read here, once a query: an edit to its tools applies
 *   from the next Clear or restart, as the CLI's own copy of it does. The
 *   first `system`/`init` of a query names the skills: one note, their count
 *   and the project's own (its `.claude/skills/` and the plugin's), the rest folded under it.
 * - **A failure is said once, and stands**: a CLI that would not start, or is
 *   not logged in, is started again only by Retry (`attach(true)`) or a Send
 *   -- never by a page load -- and the same error twice since the last prompt
 *   is one entry. Not logged in is the state's (`login`): the account, or an
 *   `authentication_failed` heard, never an entry from before a restart. A
 *   usage note, and the skills note, are said once a conversation
 *   (`session.json`'s `said`), not once a process.
 * - **What it hears** (`consume`) becomes the log's entries and the state, and
 *   only while its query is the current one (D114): one Clear replaced says
 *   nothing more. Text streams as `delta` pushes, never kept, until its block
 *   is a `text` entry. A tool call is a row; `TodoWrite`, or the
 *   `TaskCreate`/`TaskUpdate` pair, a checklist; `Edit` and `Write` record
 *   their path and keep their input; the `Agent` call to the critic and its
 *   `tool_use_result` are a review round and its score. The generator ending
 *   by itself is an error with the stderr tail, and the next Send resumes.
 * - **A turn may refuse tools** (`TurnRequest.deny`, the Git card's draft with Claude): `canUseTool` and the
 *   hook deny each for its length, "not in this turn", and it runs no review loop.
 * - **A turn** is a user message with a fresh `uuid`, the bar as it is now
 *   (D110), a git baseline and a snapshot of the tree taken first
 *   (`changes.ts`, on this port's refs) -- in each of the project's
 *   repositories (`Repos`: the engine's `engine/` too, in source mode). It ends on a `result` whose
 *   `user_message_uuid` is its own -- or on an error result that has none:
 *   only one turn is ever in flight, Send while one runs or stops being
 *   `409`. A success that names no turn is not its end: it is a sub-turn's
 *   the CLI ran meanwhile -- a background task's notification answered --
 *   and the person's turn goes on. Its end -- result, Stop, Clear, an error
 *   -- releases the code reload held during it. Its cost is the CLI's running total less the last
 *   result's; the first of a resumed query, whose base is not known, says it
 *   is the conversation's so far.
 * - **A turn that leaves a Gladius script broken is sent back** (Vibe3D
 *   D110, Docs/modeler.md M29): done by its own account, the scripts its
 *   `Edit` and `Write` calls wrote under `AssetsSource/` are built (`check`,
 *   the assets server's, through `turn-hold.ts`); one that does not build
 *   sends the turn back in the same conversation with Gladius's errors --
 *   a user message of the dev server's, saying so -- up to `MAX_FIXES`
 *   times, said in the transcript and the head (`running.fixing`). It runs
 *   on throughout: Send waits, the clock and the held export with it, and the
 *   fix's result ends it as the person's turn, its cost the results'
 *   together. A turn that failed or was stopped is not checked; Stop while
 *   the check runs ends it there.
 * - **Claude Code may go on by itself**: a background task it started (a
 *   `Bash` run in the background, `Monitor`) tells it something after the
 *   turn's result, and it talks and acts with no turn of the person's. Its
 *   first message opens a turn of its own (`origin: 'cli'`): held, timed and
 *   stoppable like any other, Send refused while it runs, ended by the next
 *   result that is not one of the person's turns' answered already. One that
 *   names a turn of the person's still waiting for its own -- ended early by
 *   an error result naming none, its work going on -- ends it as that
 *   person's turn: its files from that turn's baseline, its Undo.
 * - **Stop** is `interrupt()`, its cards denied; no result in 10 s and the
 *   query is closed, the turn ended, the next Send resuming in a new one.
 *   **Clear** is `interrupt()` then `close()` -- closing the input alone would
 *   let the CLI finish the turn, editing as it went -- and the session id and
 *   `.cache/agent/<port>/` go; the log keeps one rule, "New conversation". A
 *   turn's end still on its way (git asked for its files) is of the
 *   conversation before: the log's generation, moved on by Clear, drops it.
 * - **Settings are the server's**: the model through `setModel`, the effort
 *   through `applyFlagSettings` (`CLAUDE_EFFORT` follows it, checked) -- one
 *   top-level key, so the host's `permissions` in the flag layer stay -- an
 *   effort the new model lacks dropped and said; review from the next turn;
 *   the permission level at once.
 * - **Undo this turn** is `rewindFiles` for the agent's edits and the turn's
 *   snapshot for the rest: what a command changed or deleted among the files
 *   the turns named, put back from it; what it made, removed if the preview
 *   listed it.
 * - **The studio as tools** (Docs/mcp.md): the query has `mcpServers: { studio }`
 *   (`../mcp/registry.ts`, made with the SDK's `tool()` once it is imported). A
 *   page tool's call goes to the tab that sent the turn (`POST turn`'s `tab`; for a
 *   turn Claude Code started itself, the last one that sent one; with neither, the
 *   relay's own pick, the last studio tab to say hello) through the host
 *   (`server.ts`' relay, with the tool's deadline), and its answer becomes an `editor`
 *   entry: the call's row in the page's words, the tab that ran it, and a `scene_set`'s
 *   values -- what the page carries across a reload to undo by value. A server tool's
 *   row is its own words (`StudioContext.row`). `claude_settings` changes the model,
 *   effort and review as `POST settings` does, each change a note.
 *
 * - **`/usage`, `/btw` and the subagents** (§2): every `rate_limit_event`, result and context answer goes into
 *   `usage` (`usage.ts`), and `POST usage` asks the CLI afresh -- its usage call, where the SDK has it; every
 *   message goes to the subagents tracker (`agents.ts`); both are in the state and `session.json`. `/btw` is a
 *   fork of the conversation (`resume` + `forkSession`, written nowhere, no tools, one turn), its question and
 *   answer `btw` entries, the conversation's own query never told. The CLI's slash commands are the state's too.
 *
 * Its state is pushed whole to the host (`server.ts`) on every change, with
 * each entry as it is made. Nothing at module level.
 */
import type { AssetsCalls } from '../assets/server.ts';
import type { StudioCalls } from '../studio/calls.ts';
import type {
  AccountInfo,
  EffortLevel,
  McpSdkServerConfigWithInstance,
  Options,
  Query,
  SDKMessage,
  SDKUserMessage,
} from '@anthropic-ai/claude-agent-sdk';
import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { Refused } from '../assets/http.ts';
import { AWAY, TURN_STALE_MS } from './api-types.ts';
import type {
  AccountState,
  AgentSettings,
  AgentState,
  AnswerRequest,
  BtwAnswer,
  Card,
  CommandRow,
  PageToolName,
  ProjectToolDecl,
  ProjectToolName,
  ProjectToolResult,
  Entry,
  EntryBody,
  FailureCode,
  McpCallOut,
  ModelChoice,
  PushMessage,
  RewindAnswer,
  RewindRequest,
  SettingsRequest,
  TerminalState,
  TerminalTurn,
  TerminalTurnEvent,
  TodoItem,
  TurnAnswer,
  TurnRequest,
  UsageAnswer,
  UsageFacts,
} from './api-types.ts';
import { AgentTracker, DROP_GRACE_MS, type StreamMessage } from './agents.ts';
import { NO_USAGE, fromUsageCall, readUsage, withContext, withRate, withResult, type ModelTokens, type UsageCall } from './usage.ts';
import { ENGINE, Inputs, projectPath, reposIn, reposOf, turnId, type Baselines, type Git, type Repos, type Serial } from './changes.ts';
import { LONGEST_MS, STUDIO_TOOLS, deniedTools, metaOf } from '../mcp/catalog.ts';
import { PROJECT_PREFIX, projectMetaOf } from '../mcp/project.ts';
import { createJobs, type Jobs } from '../mcp/jobs.ts';
import { studioServer, type ClaudeSettingsChange, type ClaudeSettingsFacts, type McpKit } from '../mcp/registry.ts';
import { rowWords } from '../mcp/tools/index.ts';
import { awayOf, awayWords, beforeDelivery, studioUrl, type Away, type LateAnswer, type PageAnswer, type RowWords } from '../mcp/words.ts';
import { agentEnv, cliVersion, findClaude, versionNote } from './env.ts';
import { createHooks } from './hooks.ts';
import { KEEP, Log, summarise } from './log.ts';
import { effortFor, modelSetting, toChoice } from './models.ts';
import { HOST_ASK, ShellPlace, createCanUseTool, engineDir, engineRemotes, gitRemotes, linkedRoots, notInTurn, type CardAnswer, type Ignored } from './permissions.ts';
import { CLAUDE_DIR, qualified } from './plugin.ts';
import { projectSkills } from './skills.ts';
import { BARS, CRITIC, CRITIC_FILE, MAX_REVIEWS, barScore, criticReport, isCritic, isCriticLaunch, readCritic, reviewLoop } from './review.ts';
import type { Store } from './store.ts';
import { MAX_FIXES, brief, brokenWords, criticRequest, fixPrompt, fixesWords, modelKeys, resolveModels, turnContent, wordContext } from './turn.ts';
import type { ScriptCheck } from '../assets/turn-hold.ts';

// ---------------------------------------------------------------- what the session uses of the SDK

/** What the session uses of a `Query`: a test's stand-in has this shape. */
export type QueryLike = AsyncIterable<SDKMessage> &
  Pick<Query, 'interrupt' | 'close' | 'setModel' | 'applyFlagSettings' | 'initializationResult' | 'getContextUsage' | 'rewindFiles'> &
  Partial<Pick<Query, 'reloadSkills' | 'usage_EXPERIMENTAL_MAY_CHANGE_DO_NOT_RELY_ON_THIS_API_YET'>>;

/** The SDK's `query`. */
export type QueryFn = (params: { prompt: AsyncIterable<SDKUserMessage>; options: Options }) => QueryLike;

/** What the session uses of the SDK's module. */
export interface SdkLike {
  query: QueryFn;
  /** The MCP server's makings, for the studio's tools (`../mcp/registry.ts`); a stand-in without them has none. */
  tool?: McpKit['tool'];
  createSdkMcpServer?: McpKit['createSdkMcpServer'];
  /** The CLI's own settings merge: the user's `ask` rules, as it has them (alpha in 0.3.220). */
  resolveSettings?: (options: { cwd?: string; settingSources?: ('user' | 'project' | 'local')[] }) => Promise<{ effective: { permissions?: { ask?: string[] } } }>;
}

/** Where a session's pushes and its held reload go: the dev server it is hosted by now, re-pointed on a restart. */
export interface AgentHost {
  push(message: PushMessage): void;
  /** One full reload to every page. */
  reload(): void;
  /**
   * A page tool's call relayed to a studio tab -- `tab`, else the relay's pick: the last studio tab to say hello --
   * answered within `deadline` ms (`server.ts`' `relay`). Without it, every call is `gone`.
   */
  editor?(tab: string | null, call: McpCallOut, deadline: number, late?: LateAnswer): Promise<PageAnswer & { tab?: string }>;
  /** The dev server's jobs (`../mcp/jobs.ts`): `job_status` and `job_wait` read them. None: a registry of the session's own. */
  jobs?: Jobs;
  /** The Problems card's count now (the studio routes'); none, not known. */
  problems?(): number | null;
  /** The assets server's work in-process (Docs/mcp.md M3): the asset tools' server path. None, or null: none here. */
  assets?(): AssetsCalls | null;
  /** The studio routes' work in-process (Docs/mcp.md M5): the studio tools'. None, or null: none here. */
  studio?(): StudioCalls | null;
  /** The project's own MCP tools (Docs/mcp.md M7), as the last studio tab declared them (`server.ts`' `projectTools`). None: none. */
  projectTools?(): ProjectToolDecl[];
}

/** What a session made by a newer bundle takes over from the one it replaces (`vite.ts`, after a Clear). */
export interface Carry {
  epoch: string;
  entries: Entry[];
  settings: AgentSettings;
}

export interface SessionOptions {
  /** The project root, absolute: the CLI's `cwd`. */
  root: string;
  /** The dev server's port, for the brief. */
  port: () => number;
  /** The SDK's module; a test's stand-in. Default: `import('@anthropic-ai/claude-agent-sdk')`. */
  sdk?: () => Promise<SdkLike>;
  /** `.cache/agent/<port>/`; none, nothing is kept. */
  store?: Store;
  /** Git in the project, one repository (`changes.ts`); a test's stand-in. */
  git?: Git;
  /** The project's repositories (`changes.ts`' `Repos`); a test's stand-in. Default: `git` alone, or `reposIn(root)` -- the engine's too in source mode. */
  repos?: Repos;
  /** The CLI's environment (`env.ts`), and how `claude` is found on it. */
  env?: () => Record<string, string>;
  findClaude?: (env: Record<string, string>) => Promise<string | undefined>;
  /** Milliseconds Stop waits for the turn's result before it closes the query (10 000). */
  stopMs?: number;
  /** The terminal. */
  log?: (line: string) => void;
  /** The time, as `Date.now()`. */
  now?: () => number;
  /** A timer (`setTimeout`), answering its cancel: a terminal turn gone stale pushed (`TURN_STALE_MS`); a test's fake clock. */
  timer?: (run: () => void, ms: number) => () => void;
  /** A session made after a Clear by a newer bundle (`vite.ts`). */
  carry?: Carry;
  /** The settings a new conversation starts with -- the tab it was made from's -- where its store keeps none. */
  settings?: Partial<AgentSettings>;
  /** The conversation's title, now: each turn names it (`turn.ts`). None: a session alone. */
  title?: () => string;
  /** Work on the port's kept index, one at a time: the dev server's conversations share it (`changes.ts`' `serially`). */
  serial?: Serial;
  /**
   * The Gladius scripts among a turn's files built, the errors of each that
   * does not build (the assets server's, through `turn-hold.ts`): a turn that
   * leaves one broken is sent back to fix it, up to `MAX_FIXES` times (D110).
   * None: no turn is checked.
   */
  check?: (paths: readonly string[]) => Promise<ScriptCheck[]>;
  /**
   * The Gladius scripts saved while turns ran, their exports held (`turn-hold.ts`' `held`): checked
   * with the scripts the turn's `Edit` and `Write` calls wrote, so one a command changed (`sed`, a
   * heredoc) is checked too.
   */
  held?: () => readonly string[];
  /**
   * The files other conversations' running turns are writing (`Edit`, `Write`): a script held that one of them
   * writes is theirs to have checked, not this turn's (review round 2: A sent back for B's half-done edit).
   */
  others?: () => readonly string[];
  /**
   * The files other conversations' turns named in their results from `since`
   * (a time, as `Date.now()`) on, each by that conversation's title: Undo
   * this turn counts every conversation's later turns, and names whose.
   */
  later?: (since: number) => { path: string; by: string }[];
  /** Another conversation running a turn, by its title: a real Undo this turn waits for it to end. */
  busy?: () => string | null;
  /**
   * The engine and studio skills written into `.claude/skills/` again (`../skills/install.ts`, the dev server's):
   * `changed` when this call wrote a file, `digest` the skills' text as they now are, whoever wrote them. Run as each
   * turn begins, before its message goes: a query up reads its skills again (`reloadSkills`) when the digest is not the
   * one this conversation last saw -- a page saved since, written by this turn, another conversation's or a terminal's
   * `vibe sync` -- or, the first time, when this call changed a file. None: nothing written.
   */
  skills?: () => Promise<{ changed: boolean; digest: string }>;
  /** The project's own skills' names, for the skills note (`skills.ts`' `projectSkills`); a test's stand-in. */
  ownSkills?: (root: string) => Promise<Set<string>>;
}

export interface Session {
  /** The function that made it: a session kept across a restart is the old bundle's. */
  readonly made: unknown;
  /** The disk read: every call waits for it. */
  readonly ready: Promise<void>;
  /** Where pushes go; null between hosts. */
  host: AgentHost | null;
  state(): AgentState;
  since(seq: number): Entry[];
  /**
   * Start the query if it is not up: the first attach, or after the CLI ended.
   * `retry` (the Retry button): a CLI that failed to start, or is up but not
   * logged in, started again -- nothing else does that.
   */
  attach(retry?: boolean): Promise<void>;
  turn(request: TurnRequest): Promise<TurnAnswer>;
  stop(): Promise<void>;
  clear(): Promise<void>;
  answer(request: AnswerRequest): void;
  settings(request: SettingsRequest): Promise<void>;
  rewind(request: RewindRequest): Promise<RewindAnswer>;
  /** The held reload, now: true if there was one. */
  reload(): boolean;
  /**
   * `/usage` (§2, "Usage"): asked afresh where the CLI is up -- its usage call, where the SDK has it, and the context
   * window -- else what was last heard. Never a turn; costs nothing.
   */
  usage(): Promise<UsageAnswer>;
  /**
   * `/btw` (§2, "/btw"): a side question answered by a fork of the conversation -- resumed with `forkSession`, no
   * tools, one turn -- its question and then its answer `btw` entries, never in the conversation's history nor in
   * Undo; a turn running goes on. Refused (409) with no conversation yet to ask about.
   */
  btw(question: string): Promise<BtwAnswer>;
  /** A kept `Edit` or `Write` input, by its tool call's id. */
  input(id: string): unknown;
  /** Is a turn in flight: code changes are held while it is. */
  running(): boolean;
  /** A code change held for the turn's end. */
  hold(file: string): void;
  /** A note of the host's in the transcript: what became of the exports held for the turns (`turn-hold.ts`). */
  note(text: string): void;
  /** The files the running turn's `Edit` and `Write` calls have written or are writing: none with no turn running. */
  writes(): string[];
  carry(): Carry;
  /**
   * The skills read from disk again by the query up (`reloadSkills`, SDK 0.3.220): a skill made by `POST skills`
   * loaded mid-conversation. False with no query up, or the SDK without the call or refusing it: the next
   * conversation loads it.
   */
  reloadSkills(): Promise<boolean>;
  /**
   * Continue in the terminal (Docs/terminal.md D1): refused while a turn runs or the conversation is there already; the
   * query closed, a session id made for a conversation never sent; `prepare` (the run's files, the command) is handed the
   * id, whether it is resumed and the settings, and what it answers is kept as the conversation's `terminal`. From then
   * on Send, `/btw`, attach and Undo this turn are refused (`AWAY`) until `takeBack`.
   */
  handOver(where: TerminalState['where'], prepare: (at: HandOver) => Promise<{ command: string; before: number; port: number }>): Promise<TerminalState>;
  /**
   * The terminal's CLI running or not (`TerminalState.live`), said in the state; `run`, the command and port of a run
   * opened again after a restart (Docs/terminal.md D12).
   */
  terminalLive(live: boolean, run?: { command: string; port: number }): void;
  /** A turn in the terminal, as its run's hooks tell it (`terminalTurnNext`, Docs/ai-panel.md §8): said in the state and the tab row. */
  terminalTurn(event: TerminalTurnEvent): void;
  /** The terminal opened again after a restart, tried (D12): `tried` in the state for the rest of this process -- never kept. */
  terminalTried(): void;
  /** Back to the column (D10): the terminal's turns as one entry and a rule -- or `why` it ended with none read -- and the column's again. */
  takeBack(turns: readonly TerminalTurn[] | null, more: number, why?: string | null, failure?: { text: string; next: string | null } | null): void;
  /** The process is exiting: cards denied, the CLI closed. Synchronous. */
  close(): void;
}

/** What a hand-over gives the terminal's run (`Session.handOver`). */
export interface HandOver {
  sessionId: string;
  /** The CLI resumes it (`--resume`); false, a conversation never sent -- `--session-id`. */
  resumed: boolean;
  settings: AgentSettings;
}

/** An async iterable that stays open between turns, so one query spans them all (Vibe3D's). */
class TurnStream implements AsyncIterable<SDKUserMessage> {
  private readonly queue: SDKUserMessage[] = [];
  private wake: (() => void) | null = null;
  private closed = false;

  push(message: SDKUserMessage): void {
    this.queue.push(message);
    this.wake?.();
    this.wake = null;
  }

  close(): void {
    this.closed = true;
    this.wake?.();
    this.wake = null;
  }

  async *[Symbol.asyncIterator](): AsyncIterator<SDKUserMessage> {
    for (;;) {
      while (this.queue.length > 0) yield this.queue.shift()!;
      if (this.closed) return;
      await new Promise<void>((resolve) => (this.wake = resolve));
    }
  }
}

/**
 * The settings a new conversation starts with. `fixBoot` is the project's, not a conversation's: kept on the
 * conversations' index (`conversations.ts`, `setFixBoot`) and said in every state -- the session's own is never read.
 */
export const DEFAULT_SETTINGS: AgentSettings = { model: null, effort: null, review: 'none', level: 'auto', fixBoot: true, outside: 'read' };

/**
 * Settings as kept, read: a conversation's from before the three levels (`auto: true` or `false`) has its level
 * from it, once -- `auto` then dropped -- and a level that is none of the three is left out (the default's).
 */
export function readSettings(kept: unknown): Partial<AgentSettings> {
  if (typeof kept !== 'object' || kept === null) return {};
  const { auto, level, ...rest } = kept as Partial<AgentSettings> & { auto?: unknown };
  const out: Partial<AgentSettings> = { ...rest };
  if (level === 'ask' || level === 'auto' || level === 'unsafe') out.level = level;
  else if (typeof auto === 'boolean') out.level = auto ? 'auto' : 'ask';
  return out;
}

/** The tools whose path is a file the turn wrote, and whose input is kept. */
const WRITERS = new Set(['Edit', 'MultiEdit', 'Write', 'NotebookEdit']);

/** Lines of the CLI's stderr kept for a failure's entry. */
const TAIL = 40;

/** The person's turns a query remembers sending, the newest: what tells their results from Claude Code's own turns'. */
const SENT_KEPT = 64;

/** What each `SDKAssistantMessage.error` says, and what to do (§2, Failures). */
const FAILURES: Record<string, { text: string; next: string | null; code: FailureCode }> = {
  authentication_failed: { text: 'Claude Code is not logged in.', next: 'Run `claude` in a terminal, type /login, then Retry. An API key alone is not used here, by design.', code: 'login' },
  rate_limit: { text: 'Usage limit reached', next: 'Wait for it to reset, or pick another model.', code: 'usage' },
  overloaded: { text: "Anthropic's servers are busy", next: 'Try again shortly.', code: 'api' },
  server_error: { text: "Anthropic's servers had an error", next: 'Try again shortly.', code: 'api' },
  billing_error: { text: 'The account has a billing problem', next: 'Check it at claude.ai, then try again.', code: 'api' },
  oauth_org_not_allowed: { text: "This account's organisation does not allow Claude Code", next: 'Log in with another account: `claude`, then /login.', code: 'login' },
  model_not_found: { text: 'This model is not available to your account', next: 'Pick another.', code: 'api' },
  invalid_request: { text: 'The request was refused as invalid', next: 'Try again; if it keeps happening, Clear.', code: 'api' },
  max_output_tokens: { text: 'The reply hit its length limit', next: 'Ask it to go on.', code: 'api' },
  unknown: { text: 'Something went wrong talking to Anthropic', next: 'Try again.', code: 'api' },
};

const NOT_LOGGED_IN = FAILURES.authentication_failed!;
const SDK_MISSING = 'The agent SDK is not installed: npm i -D @anthropic-ai/claude-agent-sdk';
const NOT_FOUND = 'Claude Code was not found: install it, or run npm install';
const BUSY = 'a turn is running: Stop first';

/** `/btw`: how long its fork may take, and its words (§2, "/btw"). */
const BTW_MS = 120_000;
/** `/usage`: how long each of the CLI's answers may take. */
const USAGE_MS = 3000;
const BTW_EMPTY = 'Ask something: /btw <question>';
const BTW_NONE = 'Nothing to ask about yet: /btw asks about this conversation, and it has none -- send a prompt first';
const BTW_NO_TOOLS = 'A side question (/btw) uses no tools: answer from what you already know of the conversation.';
const BTW_BRIEF =
  'This is a side question (/btw) about the conversation so far, asked while it goes on: answer it briefly from what you already know of it -- no tools, nothing changed, nothing started. Your answer is shown beside the conversation, never added to it.';

/** A `/btw` fork's tokens: what it read (the input, the cache's reads and writes) and wrote. */
type BtwTokens = { read: number; written: number } | null;

/** A result's `usage` as a `/btw` block says it; null where it says none. */
export function btwTokens(usage: Record<string, unknown> | undefined): BtwTokens {
  if (!usage) return null;
  const n = (k: string): number => (typeof usage[k] === 'number' ? (usage[k] as number) : 0);
  const read = n('input_tokens') + n('cache_read_input_tokens') + n('cache_creation_input_tokens');
  const written = n('output_tokens');
  return read === 0 && written === 0 ? null : { read, written };
}

/** The CLI's slash commands, as the state lists them (`SlashCommand`): anything odd dropped. */
export function commandRows(list: unknown): CommandRow[] {
  if (!Array.isArray(list)) return [];
  return list.flatMap((c): CommandRow[] => {
    if (typeof c !== 'object' || c === null) return [];
    const r = c as Record<string, unknown>;
    if (typeof r.name !== 'string' || r.name === '') return [];
    const aliases = Array.isArray(r.aliases) ? r.aliases.filter((a): a is string => typeof a === 'string') : [];
    return [{ name: r.name.replace(/^\//, ''), description: typeof r.description === 'string' ? r.description : '', hint: typeof r.argumentHint === 'string' ? r.argumentHint : '', ...(aliases.length > 0 ? { aliases } : {}) }];
  });
}

/** Undo this turn refused while another conversation's turn runs. */
export const busyWords = (title: string): string => `A turn is running in "${title}": Undo waits until it ends`;

/** An account as the state has it; "not logged in" is no email and no plan from the first-party provider. */
function toAccount(info: AccountInfo | undefined): AccountState {
  const provider = info?.apiProvider ?? null;
  const firstParty = provider === null || provider === 'firstParty';
  return {
    loggedIn: !firstParty || Boolean(info?.email || info?.subscriptionType),
    email: info?.email ?? null,
    subscription: info?.subscriptionType ?? null,
    provider,
  };
}

/** `resetsAt` (seconds) as the person's clock reads it: "15:00", or "Tue 15:00" past today. */
function localTime(seconds: number, now: number): string {
  const at = new Date(seconds * 1000);
  const hhmm = `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;
  return at.toDateString() === new Date(now).toDateString() ? hhmm : `${at.toLocaleDateString('en-GB', { weekday: 'short' })} ${hhmm}`;
}

const describe = (err: unknown): string => (err instanceof Error ? err.message : String(err));

/** A promise that settles within `ms`, or rejects. */
function within<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`no answer in ${ms} ms`)), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err: unknown) => {
        clearTimeout(timer);
        reject(err as Error);
      },
    );
  });
}

/** The user's `ask` rules from the three settings files, where the SDK cannot resolve them. */
async function askRulesFromFiles(root: string): Promise<string[]> {
  const files = [join(process.env.CLAUDE_CONFIG_DIR ?? join(homedir(), '.claude'), 'settings.json'), join(root, '.claude', 'settings.json'), join(root, '.claude', 'settings.local.json')];
  const rules: string[] = [];
  for (const file of files) {
    try {
      const ask = (JSON.parse(await readFile(file, 'utf8')) as { permissions?: { ask?: unknown } }).permissions?.ask;
      if (Array.isArray(ask)) rules.push(...ask.filter((r): r is string => typeof r === 'string'));
    } catch {
      // Not there.
    }
  }
  return rules;
}

/**
 * The skills note: how many loaded, and the project's own by name -- the
 * question it answers is "did my skill load" -- the rest folded under it, a
 * person's own skills from everywhere else often being dozens.
 */
export function skillsNote(skills: readonly string[], own: ReadonlySet<string>): Extract<EntryBody, { kind: 'note' }> {
  if (skills.length === 0) return { kind: 'note', text: 'No skills loaded' };
  const mine = skills.filter((name) => own.has(name));
  const others = skills.filter((name) => !own.has(name));
  const text = `Skills: ${skills.length} loaded · ${mine.length > 0 ? `the project's: ${mine.join(', ')}` : "none of them the project's (.claude/skills/, the vibe plugin)"}`;
  return others.length === 0 ? { kind: 'note', text } : { kind: 'note', text, more: { summary: mine.length > 0 ? `The other ${others.length}` : `All ${others.length}`, items: others } };
}

/** The SDK, imported only now: never with the config. */
/** The SDK, loaded: the one place it is (the `/__mcp` endpoint's makings too, `vite.ts`). */
export const importSdk = async (): Promise<SdkLike> => (await import('@anthropic-ai/claude-agent-sdk')) as unknown as SdkLike;

// ---------------------------------------------------------------- the session

/** The query in hand. */
interface Live {
  query: QueryLike;
  stream: TurnStream;
  /** It was started with `resume`. */
  resumed: boolean;
  /** Closed by the session (Stop's deadline, Clear, a retry, the exit): its end is no error. */
  closing: boolean;
  /** Its first `init` named the skills. */
  noted: boolean;
  /** The CLI's `total_cost_usd` at its last result: a turn's cost is the next one less this. Null: not known (a resumed query, before its first result). */
  lastTotal: number | null;
  /** The person's turns sent on it, by uuid -- the last `SENT_KEPT`: a result naming none of them ends a turn Claude Code started itself. */
  sent: Set<string>;
  /**
   * Of those, the one no result has named yet: a turn ended early -- an error
   * result naming none -- whose own result may yet come. One at most: the CLI
   * answers in order, so the next turn sent lets the one before go.
   */
  open: Map<string, Turn>;
  /**
   * The skills' digest this query has read (`options.skills`): taken as it starts -- by a turn, by `POST attach` or a
   * rewind before any turn -- and moved on by each turn that finds them changed and has it read them again. Undefined:
   * not known (the skills could not be written as it started).
   */
  skills: string | undefined;
}

/** The turn in flight: the person's, or one Claude Code started itself (`origin: 'cli'`). */
interface Turn {
  id: string;
  origin: 'person' | 'cli';
  /** The tab that sent it: the editor tools' calls go there. */
  tab: string | null;
  live: Live;
  startedAt: number;
  bar: number | null;
  prompt: string;
  context: string | null;
  images: number;
  baseline: Promise<Baselines | null>;
  /** Its message is in the stream: Stop has something to interrupt. */
  sent: boolean;
  stopping: boolean;
  stopTimer: ReturnType<typeof setTimeout> | undefined;
  /** The files its `Edit` and `Write` calls wrote: named at the call, counted once its result is no error. */
  written: Set<string>;
  writing: Map<string, string>;
  /** The critic's launches, by tool call id, to their round. */
  reviews: Map<string, number>;
  last: number | null;
  /** The TaskCreate/TaskUpdate checklist: tasks by id, and creates waiting for theirs. */
  tasks: Map<string, TodoItem>;
  creating: Map<string, string>;
  /** The user message whose result ends it: its own, or the last fix it was sent back with (D110). */
  expect: string;
  /** Sent back to fix a script that does not build, so far (D110); `checking` while its scripts are built. */
  fixes: number;
  /** The scripts held already as it began: another turn's saves, not this one's to check. */
  heldBefore: Set<string>;
  checking: boolean;
  /** What its results cost so far, a fix's added to the turn's own: the result row says the whole. */
  spent: number | null;
  /** The tools refused for its length (`TurnRequest.deny`): `canUseTool` and the hook deny them, "not in this turn". */
  deny: ReadonlySet<string>;
}

/** `session.json`'s `terminal`, read back: a hand-over kept (Docs/terminal.md D1), or null for anything else. */
export function readAway(raw: unknown): TerminalState | null {
  const t = raw as Partial<TerminalState> | null | undefined;
  if (typeof t !== 'object' || t === null) return null;
  if ((t.where !== 'column' && t.where !== 'own') || typeof t.sessionId !== 'string' || t.sessionId === '') return null;
  return {
    where: t.where,
    since: typeof t.since === 'number' ? t.since : 0,
    sessionId: t.sessionId,
    before: typeof t.before === 'number' && t.before >= 0 ? t.before : 0,
    command: typeof t.command === 'string' ? t.command : '',
    port: typeof t.port === 'number' && Number.isInteger(t.port) ? t.port : 0,
    live: t.live === true,
    // A turn under way went with the process before, and so did a reopen's attempt; when one last ended stays (the tab's mark, Docs/ai-panel.md §8).
    ...(typeof t.ended === 'number' && t.ended > 0 ? { ended: t.ended, ...(t.failed === true ? { failed: true } : {}) } : {}),
  };
}

/**
 * A terminal's turn after what its run's hooks told (Docs/ai-panel.md §8): a prompt sent runs; the CLI asking waits, until a
 * key typed in the column's terminal answers it; its end (`stop`) or its failure marks when, and how. None changed: null.
 */
export function terminalTurnNext(away: TerminalState, event: TerminalTurnEvent, now: number): TerminalState | null {
  const { turn: _turn, turnAt: _at, asking: _asking, ...rest } = away;
  switch (event) {
    case 'prompt':
      return { ...rest, turn: 'running', turnAt: now };
    case 'asks':
      return { ...rest, turn: 'waiting', asking: 'permission', turnAt: now };
    case 'question':
      return { ...rest, turn: 'waiting', asking: 'question', turnAt: now };
    case 'answered':
      return away.turn === 'waiting' ? { ...rest, turn: 'running', turnAt: now } : null;
    case 'alive':
      // The terminal writing while a turn runs: a long turn is not hidden at `TURN_STALE_MS`.
      return away.turn === 'running' ? { ...rest, turn: 'running', turnAt: now } : null;
    case 'quiet':
      // Over with no end to mark: interrupted, declined, or idle at the prompt -- the person was there.
      return away.turn === undefined ? null : rest;
    case 'stop':
    case 'failed': {
      const { failed: _failed, ...ended } = rest;
      return { ...ended, ended: now, ...(event === 'failed' ? { failed: true } : {}) };
    }
  }
}

export function createSession(options: SessionOptions): Session {
  const { root } = options;
  const now = options.now ?? (() => Date.now());
  const say = options.log ?? ((line: string) => console.error(line));
  /** The CLI's version said, once a session. */
  let versionSaid = false;
  const repos = options.repos ?? (options.git ? reposOf([{ root, prefix: '', git: options.git }]) : reposIn(root));
  /** Where the engine's links lead (`linkedRoots`), read once as the session starts: a link made later never widens it. */
  const linked = linkedRoots(root);
  /** Is the engine's checkout a folder of its own under the root (`engineDir`), read once: `git -C engine` is plain then. */
  const engine = engineDir(root);
  /** Where the conversation's shells may be, across calls and the CLI's restarts (`ShellPlace`): the hook and canUseTool share it. */
  const shell = new ShellPlace();
  /** The project's remotes (`gitRemotes`), read once: the only ones `git fetch` goes to unasked under Auto. */
  const remotes = gitRemotes(root);
  /** The engine's checkout's remotes, read once, in source mode (`git -C engine remote`): the only ones `git -C engine fetch` goes to unasked. */
  const engines = engineRemotes(root);
  const store = options.store;
  const stopMs = options.stopMs ?? 10_000;
  const readOwnSkills = options.ownSkills ?? ((at: string) => projectSkills(at));
  const epoch = options.carry?.epoch ?? randomUUID();

  const log = new Log(KEEP, epoch);
  const inputs = new Inputs();
  let settings: AgentSettings = { ...DEFAULT_SETTINGS, ...readSettings(options.settings), ...readSettings(options.carry?.settings) };
  let sessionId: string | undefined;
  /** In the terminal (Docs/terminal.md D1): the CLI owns the session until Back. Kept in `session.json`. */
  let away: TerminalState | null = null;
  /** The terminal opened again after a restart, tried this process (D12): in the state, never in `session.json`. */
  let reopenTried = false;
  /** The push due when a terminal turn told nothing of goes stale (`TURN_STALE_MS`): the tab row stops showing it by itself. */
  let staleCancel: (() => void) | null = null;
  const timer = options.timer ?? ((run: () => void, ms: number) => {
    const t = setTimeout(run, ms);
    t.unref?.();
    return () => clearTimeout(t);
  });
  /** That push scheduled again from the turn now: cleared with no turn; one more state pushed once it is stale. */
  function staleLater(): void {
    staleCancel?.();
    staleCancel = null;
    if (!away?.turn) return;
    staleCancel = timer(() => {
      staleCancel = null;
      changed();
    }, Math.max(0, (away.turnAt ?? 0) + TURN_STALE_MS - now()) + 1);
  }
  let live: Live | undefined;
  let starting: Promise<void> | undefined;
  let status: AgentState['session'] = 'off';
  let available = true;
  let why: string | null = null;
  let account: AccountState | null = null;
  let models: ModelChoice[] = [];
  /** The critic: its tools, as its file names them, and the name it loaded under -- the plugin's, or a project's bare one first (`review.ts`). */
  let critic: { loaded: boolean; why: string | null; tools: string[]; name: string } = { loaded: false, why: null, tools: [], name: CRITIC };
  let running: Turn | undefined;
  let ending: Promise<void> = Promise.resolve();
  const cards = new Map<string, { card: Card; settle: (answer: CardAnswer, detail: string | null) => void }>();
  const settled = new Set<string>();
  /** The `tool_use` ids whose card was denied, stopped or skipped: their error results are the person's answer, not a refusal of the CLI's. */
  const refusedUses = new Set<string>();
  const held: string[] = [];
  let retrying: AgentState['retrying'] = null;
  let context: number | null = null;
  let skills: string[] | null = null;
  const tail: string[] = [];
  /** Usage notes said this conversation, by limit and when it resets: kept in `session.json`, so a restart says none again. */
  const rateSaid = new Set<string>();
  /** The skills the note named this conversation: a query resumed with the same says nothing. */
  let skillsSaid: string[] | null = null;
  /** Not logged in, as this process heard it from the API (`authentication_failed`): the state's `login` with the account's. */
  let loginFailure: { text: string; next: string } | null = null;
  let rateResets: number | undefined;
  /** `git check-ignore`, per path, for the turn under way: Auto lets a recursive `rm` of what git ignores by. */
  let ignoredCache = new Map<string, Promise<boolean>>();
  const ignored: Ignored = (path) => {
    let known = ignoredCache.get(path);
    if (known === undefined) {
      known = repos.ignored(path).catch(() => false);
      ignoredCache.set(path, known);
    }
    return known;
  };
  let askRules: () => Promise<readonly string[]> = () => askRulesFromFiles(root);
  /** Moved on by Clear: a turn's end still on its way belongs to the conversation before, and adds nothing. */
  let generation = 0;
  /** The project's own skills, `.claude/skills/<name>/` and the plugin's: named in the skills note, the rest folded. */
  let ownSkills: Promise<Set<string>> | undefined;
  /** The tab that sent the last turn: a turn Claude Code started itself has none of its own. */
  let lastTab: string | null = null;
  /** Editor tool calls seen as `tool_use` and not yet relayed: a call the CLI did not name is matched to the first of its tool. */
  const editorUses: { id: string; tool: string; detail: string }[] = [];
  /** The jobs where the host has none (a session alone, a test): the dev server's are shared by every conversation. */
  const ownJobs = createJobs();
  /** What `/usage` shows, as heard (§2, "Usage"): kept in `session.json`. */
  let usage: UsageFacts = NO_USAGE;
  /** The subagents and background tasks of this turn or the last (§2, "Subagents"): kept in `session.json`. */
  const agents = new AgentTracker();
  /** The CLI's slash commands, once it is up. */
  let commands: CommandRow[] = [];
  /** `/btw`'s forks running: closed by Clear and the exit. */
  const asides = new Set<QueryLike>();
  /** The timer that ends a dropped background task's row after its grace. */
  let sweeping: ReturnType<typeof setTimeout> | undefined;

  const session: Session = {
    made: createSession,
    ready: Promise.resolve(),
    host: null,
    state,
    since: (seq) => log.since(seq),
    attach: (retry) => attach(retry ?? false),
    turn,
    stop,
    clear,
    answer,
    settings: changeSettings,
    rewind,
    reload: release,
    usage: usageNow,
    btw,
    input: (id) => inputs.get(id),
    running: () => running !== undefined,
    hold(file) {
      if (running === undefined || held.includes(file)) return;
      held.push(file);
      changed();
    },
    carry: () => ({ epoch, entries: log.since(0), settings: { ...settings } }),
    note: (text) => void add({ kind: 'note', text }),
    writes: () => (running ? [...running.written, ...running.writing.values()] : []),
    async reloadSkills() {
      // The skills note's own: a skill made since is the project's from now on.
      ownSkills = undefined;
      const l = live;
      if (!l || l.closing || !l.query.reloadSkills) return false;
      try {
        await l.query.reloadSkills();
        return true;
      } catch {
        return false;
      }
    },
    handOver,
    terminalLive(on, run) {
      if (!away || (away.live === on && !run)) return;
      away.live = on;
      if (run) {
        away.command = run.command;
        away.port = run.port;
      }
      // A CLI gone: no turn of it runs.
      if (!on) delete away.turn;
      saveKept();
      changed();
    },
    terminalTried() {
      if (!away || reopenTried) return;
      reopenTried = true;
      changed();
    },
    terminalTurn(event) {
      if (!away) return;
      const next = terminalTurnNext(away, event, now());
      if (next === null) return;
      const ends = next.ended !== away.ended;
      away = next;
      // When a turn ended is kept (the tab's mark after a restart); a turn's start or a question is not.
      if (ends) saveKept();
      staleLater();
      changed();
    },
    takeBack(turns, more, why, failure) {
      if (!away) return;
      const where = away.where;
      away = null;
      reopenTried = false;
      staleLater();
      saveKept();
      if (turns && (turns.length > 0 || more > 0)) add({ kind: 'terminal', turns: [...turns], more });
      // The CLI ended by itself, failing (a mode it refused, a login): what it said last, so it is no silent dead terminal.
      if (failure) add({ kind: 'error', text: failure.text, next: failure.next, code: null });
      const n = (turns?.length ?? 0) + more;
      const said = turns === null ? `Back from the terminal${why ? `: ${why}` : ''}; the conversation goes on here.` : `Back from the ${where === 'own' ? 'terminal (your own)' : 'terminal'}: ${n === 0 ? 'no turns made there' : n === 1 ? '1 turn there' : `${n} turns there`}; the conversation goes on here.`;
      add({ kind: 'rule', text: said, reset: false });
      changed();
    },
    close() {
      staleCancel?.();
      denyCards();
      closeAsides();
      clearTimeout(sweeping);
      if (live) shut(live);
      live = undefined;
    },
  };

  // ---------------------------------------------------------------- the log and the state

  function state(): AgentState {
    return {
      epoch,
      available,
      why,
      session: status,
      account,
      login: account !== null && !account.loggedIn ? { text: NOT_LOGGED_IN.text, next: NOT_LOGGED_IN.next! } : loginFailure,
      models,
      settings: { ...settings },
      review: { available: available && critic.loaded, why: critic.why, bars: [...BARS], max: MAX_REVIEWS },
      running: running
        ? {
            origin: running.origin,
            turn: running.id,
            startedAt: running.startedAt,
            bar: running.bar,
            stopping: running.stopping,
            ...(running.checking || running.fixes > 0 ? { fixing: { attempt: running.fixes, of: MAX_FIXES, checking: running.checking } } : {}),
            round: running.reviews.size,
            last: running.last,
          }
        : null,
      pending: [...cards.values()].map((c) => c.card),
      held: [...held],
      retrying,
      context,
      skills,
      usage,
      agents: agents.snapshot(),
      commands: [...commands],
      terminal: away === null ? null : { ...away, ...(reopenTried ? { tried: true as const } : {}) },
    };
  }

  function add(body: EntryBody): Entry {
    const entry = log.add(body, now());
    store?.append(entry);
    session.host?.push({ entry });
    return entry;
  }

  function changed(): void {
    session.host?.push({ state: state() });
  }

  /** A failure said -- once: the same one again since the last prompt (a Retry that met it again) adds nothing. A restart's is another. */
  function error(text: string, next: string | null, code: FailureCode | null): void {
    for (let i = log.entries.length - 1; i >= 0; i--) {
      const e = log.entries[i]!;
      if (e.epoch !== epoch || e.kind === 'prompt' || (e.kind === 'rule' && e.reset)) break;
      if (e.kind !== 'error') continue;
      if (e.text === text && e.next === next && e.code === code) return;
      break;
    }
    add({ kind: 'error', text, next, code });
  }

  function saveKept(): void {
    const said = rateSaid.size > 0 || skillsSaid !== null ? { said: { usage: [...rateSaid], ...(skillsSaid ? { skills: skillsSaid } : {}) } } : {};
    const heard = usage.at !== null ? { usage } : {};
    const rows = agents.rows.length > 0 ? { agents: agents.snapshot() } : {};
    const known = commands.length > 0 ? { commands } : {};
    void store?.save({ ...(sessionId ? { sessionId } : {}), settings, ...said, ...heard, ...rows, ...known, ...(away ? { terminal: away } : {}) });
  }

  /** A usage note's key: its status, its limit and when it resets -- the next reset is another note. */
  const usageKey = (status: string, type: string | undefined, resetsAt: number | undefined): string => `${status}:${type ?? ''}:${resetsAt ?? ''}`;

  // ---------------------------------------------------------------- what a previous process left

  (session as { ready: Promise<void> }).ready = (async () => {
    if (options.carry) {
      log.load(options.carry.entries);
      return;
    }
    if (!store) return;
    const { kept, entries, moved } = await store.read();
    sessionId = typeof kept.sessionId === 'string' ? kept.sessionId : undefined;
    // In the terminal when the process before went: still the CLI's -- the column's own terminal ended with that process.
    away = readAway(kept.terminal);
    if (away?.where === 'column') away.live = false;
    settings = { ...DEFAULT_SETTINGS, ...readSettings(options.settings), ...readSettings(kept.settings) };
    // What was said this conversation, less the usage notes whose limit has reset since.
    const said = kept.said ?? {};
    for (const key of Array.isArray(said.usage) ? said.usage : []) {
      if (typeof key !== 'string') continue;
      const resets = Number(key.slice(key.lastIndexOf(':') + 1));
      if (!(resets > 0 && resets * 1000 < now())) rateSaid.add(key);
    }
    if (Array.isArray(said.skills)) skillsSaid = said.skills.filter((n) => typeof n === 'string');
    usage = readUsage(kept.usage);
    // The slash list whole before the CLI is up: the commands it last said, until it says them again.
    commands = commandRows(kept.commands);
    // Its CLI is gone with the process before: a row still running was stopped with it.
    agents.restore(kept.agents, now());
    log.load(entries);
    if (moved) add({ kind: 'rule', text: 'Moved here from .cache/agent/: the conversation kept before each dev server had a folder of its own', reset: false });
    // Nothing to go on with -- no entries, or only a conversation that never reached the CLI: no rule.
    if (entries.length === 0 || sessionId === undefined) return;
    // A turn whose prompt has no result after it was cut off by the restart.
    let open = false;
    for (const e of entries) {
      if (e.kind === 'prompt') open = true;
      else if (e.kind === 'result' || (e.kind === 'rule' && e.reset)) open = false;
    }
    add({ kind: 'rule', text: open ? 'The dev server restarted: the turn in progress was stopped; the conversation goes on.' : 'The dev server restarted; the conversation goes on.', reset: false });
  })();

  // ---------------------------------------------------------------- cards

  /** A tool the running turn refuses (`TurnRequest.deny`): its words for `canUseTool` and the hook; null for any other. */
  function denied(tool: string): string | null {
    return running?.deny.has(tool) ? notInTurn(tool) : null;
  }

  function openCard(card: Card, signal: AbortSignal): Promise<CardAnswer> {
    return new Promise((resolve) => {
      if (signal.aborted) {
        resolve({ outcome: 'stopped' });
        return;
      }
      const onAbort = (): void => settle({ outcome: 'stopped' }, null);
      const settle = (answer: CardAnswer, detail: string | null): void => {
        if (!cards.delete(card.id)) return;
        settled.add(card.id);
        // The call's error result is then the card's doing, not the CLI's: its row says "-- denied", not "refused".
        if (card.kind === 'permission' && card.use !== undefined && (answer.outcome === 'denied' || answer.outcome === 'stopped' || answer.outcome === 'skipped')) refusedUses.add(card.use);
        signal.removeEventListener('abort', onAbort);
        add({ kind: 'answer', card: card.id, outcome: answer.outcome, detail });
        changed();
        resolve(answer);
      };
      signal.addEventListener('abort', onAbort, { once: true });
      cards.set(card.id, { card, settle });
      add({ kind: 'card', card });
      changed();
    });
  }

  /** Every open card denied, "stopped": Stop, Clear, the exit. */
  function denyCards(): void {
    for (const open of [...cards.values()]) open.settle({ outcome: 'stopped' }, null);
  }

  function answer(request: AnswerRequest): void {
    const open = cards.get(request.id);
    if (!open) throw settled.has(request.id) ? new Refused(409, 'this card is already answered') : new Refused(404, 'no such card');
    const { card } = open;
    if (card.kind === 'question') {
      if (!request.allow) return open.settle({ outcome: 'skipped' }, null);
      const answers = request.answers ?? {};
      const words = Object.entries(answers).map(([q, a]) => `${q} ${Array.isArray(a) ? a.join(', ') : a}`);
      return open.settle({ outcome: 'answered', answers }, words.join('; ') || null);
    }
    if (!request.allow) return open.settle({ outcome: 'denied' }, null);
    if (request.always !== undefined) {
      const choice = card.always.find((a) => a.destination === request.always);
      if (!choice) throw new Refused(422, `this card has no Always for ${request.always}`);
      return open.settle({ outcome: 'always', destination: choice.destination }, `${choice.label}: ${choice.rules.join(', ')}`);
    }
    open.settle({ outcome: 'allowed' }, null);
  }

  // ---------------------------------------------------------------- the query

  /** A query ended by the session: its input closed, its CLI stopped, its end no error. */
  function shut(l: Live): void {
    l.closing = true;
    l.stream.close();
    try {
      l.query.close();
    } catch {
      // Gone already.
    }
  }

  function stderr(data: string): void {
    for (const line of data.split(/\r?\n/)) {
      if (line.trim() === '') continue;
      tail.push(line);
      if (tail.length > TAIL) tail.shift();
      say(`[agent] ${line}`);
    }
  }

  /** `digest`: the skills' as a turn just wrote them, which a query it starts reads; else `start` writes them itself. */
  /** Continue in the terminal (Docs/terminal.md D1): the column's query closed, the session the CLI's. */
  async function handOver(where: TerminalState['where'], prepare: (at: HandOver) => Promise<{ command: string; before: number; port: number }>): Promise<TerminalState> {
    await session.ready;
    if (away) throw new Refused(409, 'This conversation is in the terminal already');
    if (running) throw new Refused(409, 'A turn is running: Stop it, or wait for its end, then continue in the terminal');
    await ending;
    if (running) throw new Refused(409, 'A turn is running: Stop it, or wait for its end, then continue in the terminal');
    // A query starting is let finish, then closed with the rest: never two owners of one session.
    await starting?.catch(() => {});
    const resumed = sessionId !== undefined;
    const id = sessionId ?? randomUUID();
    const made = await prepare({ sessionId: id, resumed, settings: { ...settings } });
    if (live) {
      shut(live);
      live = undefined;
    }
    closeAsides();
    status = 'off';
    sessionId = id;
    away = { where, since: now(), sessionId: id, before: made.before, command: made.command, port: made.port, live: true };
    saveKept();
    add({ kind: 'rule', text: where === 'own' ? 'Continued in your own terminal: Back to the column takes it back' : 'Continued in the terminal', reset: false });
    changed();
    return { ...away };
  }

  async function attach(retry: boolean, digest?: string): Promise<void> {
    await session.ready;
    // The CLI in the terminal owns the session (D1): no query of the column's beside it.
    if (away) return;
    if (starting) return starting;
    // Up: started again only by Retry, and only not logged in -- reading its login afresh.
    if (live && status === 'up' && !(retry && account?.loggedIn === false)) return;
    // A failure stands until Retry: every page load starting a CLI again would only repeat it.
    if (status === 'failed' && !retry) return;
    if (live) {
      shut(live);
      live = undefined;
    }
    starting = start(digest).finally(() => (starting = undefined));
    return starting;
  }

  async function start(digest?: string): Promise<void> {
    status = 'starting';
    loginFailure = null;
    changed();
    let sdk: SdkLike;
    try {
      sdk = await (options.sdk ?? importSdk)();
    } catch {
      available = false;
      why = SDK_MISSING;
      status = 'failed';
      error(SDK_MISSING, null, 'sdk');
      changed();
      return;
    }
    available = true;
    why = null;
    const resolve = sdk.resolveSettings;
    askRules = resolve
      ? async () => (await resolve({ cwd: root, settingSources: ['user', 'project', 'local'] })).effective.permissions?.ask ?? []
      : () => askRulesFromFiles(root);
    const criticFile = await readCritic(root);
    critic = 'why' in criticFile ? { loaded: false, why: criticFile.why, tools: [], name: CRITIC } : { loaded: false, why: null, tools: criticFile.tools, name: CRITIC };
    const env = (options.env ?? (() => agentEnv()))();
    // The CLI bounds an MCP call by MCP_TOOL_TIMEOUT -- unbounded unless set, and the SDK passes it no per-server bound for an
    // in-process server: one set lower than the studio's longest deadline is raised above it, so a call ends by its own.
    const bound = Number(env.MCP_TOOL_TIMEOUT);
    if (env.MCP_TOOL_TIMEOUT !== undefined && Number.isFinite(bound) && bound < LONGEST_MS + 5_000) env.MCP_TOOL_TIMEOUT = String(LONGEST_MS + 5_000);
    const claude = await (options.findClaude ?? findClaude)(env);
    // Its version said once, beside the start: not the one the turns were checked against, a line in the log (never waited for).
    if (claude !== undefined && !versionSaid) {
      versionSaid = true;
      void cliVersion(claude, env).then((v) => {
        const note = versionNote(v);
        if (note !== null) say(note);
      });
    }
    // The studio as tools: made now, with the SDK's own makings; without them, or zod, the agent edits files alone.
    let studio: McpSdkServerConfigWithInstance | undefined;
    if (sdk.tool && sdk.createSdkMcpServer) {
      try {
        studio = await studioServer({ tool: sdk.tool, createSdkMcpServer: sdk.createSdkMcpServer }, {
          call: callPage,
          models: (keys) => resolveModels(root, keys),
          url: () => studioUrl(options.port()),
          get jobs() {
            return session.host?.jobs ?? ownJobs;
          },
          problems: () => session.host?.problems?.() ?? null,
          root: () => root,
          assets: () => session.host?.assets?.() ?? null,
          studio: () => session.host?.studio?.() ?? null,
          // The project's own tools (Docs/mcp.md M7): read as this server is made -- a tool declared later, the next session's.
          projectTools: () => session.host?.projectTools?.() ?? [],
          // An asset tool's files, the running turn's: Undo this turn puts them back as it does an Edit's.
          wrote: (paths) => {
            for (const path of paths) running?.written.add(path);
          },
          // `git_commit`'s `all`: the files the running turn wrote, never the person's.
          written: () => (running ? [...running.written] : []),
          settings: { read: claudeSettings, set: setClaudeSettings },
          row: serverRow,
        });
      } catch (err) {
        say(`[agent] the studio's tools are off: ${describe(err)}`);
      }
    }
    const stream = new TurnStream();
    // A new CLI: the calls of one gone never complete -- forgotten, the shell as it was marked (`ShellPlace.settle`).
    shell.settle();
    // The effort goes in now only where the models are known to have it; else once they are.
    const effortNow = models.length > 0 ? effortFor(models, settings.model, settings.effort) : null;
    const queryOptions: Options = {
      cwd: root,
      settingSources: ['user', 'project', 'local'],
      // The host's ask rules, this session's alone: the flag layer, no file written, no terminal session asked.
      settings: { permissions: { ask: [...HOST_ASK] } },
      skills: 'all',
      // The package's Claude files (`plugin.ts`): the vibe and gladius skills and the critic, a project's .claude/ or not.
      plugins: [{ type: 'local', path: CLAUDE_DIR }],
      systemPrompt: { type: 'preset', preset: 'claude_code', append: brief(options.port(), repos.list.some((r) => r.prefix === `${ENGINE}/`)) },
      permissionMode: 'default',
      canUseTool: createCanUseTool({ root, level: () => settings.level, metaOf: (tool) => metaOf(tool) ?? projectMetaOf(session.host?.projectTools?.() ?? [], tool), askRules: () => askRules(), ignored, open: openCard, newId: () => `card-${randomUUID().slice(0, 13)}`, denied, linked: () => linked, engine, shell, remotes, engineRemotes: engines, port: () => options.port(), written: () => (running ? [...running.written] : []) }),
      // Before the rules: the host's and Auto's matcher, which a person's broad allow would otherwise skip.
      hooks: createHooks({ criticRequest: requestForCritic, criticTools: () => critic.tools, root, auto: () => settings.level !== 'ask', askRules: () => askRules(), ignored, denied, engine, shell, remotes, engineRemotes: engines }),
      ...(studio ? { mcpServers: { studio } } : {}),
      ...(settings.model !== null ? { model: settings.model } : {}),
      ...(effortNow !== null ? { effort: effortNow as EffortLevel } : {}),
      enableFileCheckpointing: true,
      includePartialMessages: true,
      ...(sessionId !== undefined ? { resume: sessionId } : {}),
      env,
      ...(claude !== undefined ? { pathToClaudeCodeExecutable: claude } : {}),
      stderr,
    };
    // The skills as this query will read them: a turn's digest, else written now (a `POST attach` or a rewind before any
    // turn) -- so its first turn compares against what it started with, not against nothing.
    const skills =
      digest ??
      (
        await options.skills?.().catch((err: unknown) => {
          say(`[agent] the skills were not written: ${describe(err)}`);
          return undefined;
        })
      )?.digest;
    say(`[agent] starting Claude Code${claude ? ` (${claude})` : " (the SDK's own)"}${sessionId ? `, resuming ${sessionId}` : ''}`);
    let l: Live;
    try {
      const resumed = sessionId !== undefined;
      l = { query: sdk.query({ prompt: stream, options: queryOptions }), stream, resumed, closing: false, noted: false, lastTotal: resumed ? null : 0, sent: new Set(), open: new Map(), skills };
    } catch (err) {
      failed(err);
      return;
    }
    live = l;
    void consume(l);
    try {
      const init = await l.query.initializationResult();
      if (live !== l) return;
      account = toAccount(init.account);
      models = init.models.map(toChoice);
      commands = commandRows((init as { commands?: unknown }).commands);
      saveKept();
      if (usage.subscription === null && account.subscription !== null) usage = { ...usage, subscription: account.subscription };
      // The plugin's `vibe:code-critic` when it loaded -- the file readCritic read is the one that runs, so the
      // tools the hook holds it to are its own -- else the project's bare `code-critic` (vibe sync's copy).
      const named = init.agents.filter((a) => isCritic(a.name)).map((a) => a.name);
      critic.name = named.includes(qualified(CRITIC)) ? qualified(CRITIC) : (named[0] ?? CRITIC);
      critic.loaded = critic.why === null && named.length > 0;
      if (!critic.loaded) {
        critic.why ??= `the critic did not load: neither the vibe plugin's code-critic.md nor ${CRITIC_FILE}`;
        add({ kind: 'note', text: `Review is off: ${critic.why}` });
      }
      const fit = effortFor(models, settings.model, settings.effort);
      if (fit !== settings.effort) {
        add({ kind: 'note', text: `Effort ${settings.effort} is not one of this model's levels: dropped.` });
        settings.effort = fit;
        saveKept();
      } else if (fit !== null && effortNow === null) await l.query.applyFlagSettings({ effortLevel: fit as EffortLevel });
      if (!account.loggedIn) error(NOT_LOGGED_IN.text, NOT_LOGGED_IN.next, 'login');
      status = 'up';
    } catch (err) {
      if (live !== l) return;
      shut(l);
      live = undefined;
      if (l.resumed && !l.noted && /no conversation found/i.test(`${describe(err)}\n${tail.join('\n')}`)) {
        // The conversation kept from before is not the CLI's any more: nothing failed, the next Send starts afresh.
        status = 'off';
        forgetResume(l, 'The conversation from before could not be found: the next Send starts a new one.');
        changed();
        return;
      }
      failed(err);
      forgetResume(l);
      return;
    }
    changed();
  }

  /** A query started with `resume` that never came up: the kept conversation is gone, and the next starts afresh. */
  function forgetResume(l: Live, text = 'The conversation could not be resumed: the next Send starts a new one.'): void {
    if (!l.resumed || l.noted || sessionId === undefined) return;
    sessionId = undefined;
    saveKept();
    add({ kind: 'note', text });
  }

  /** The CLI would not start: the card says why, and what to do. */
  function failed(err: unknown): void {
    status = 'failed';
    const message = describe(err);
    const missing = /ENOENT|not found|no such file/i.test(message);
    const last = tail.slice(-8).join('\n');
    error(missing ? NOT_FOUND : `Claude Code would not start: ${message}${last ? `\n${last}` : ''}`, missing ? null : 'Retry, or run `claude` in a terminal to see why.', missing ? 'not-found' : 'ended');
    changed();
  }

  async function consume(l: Live): Promise<void> {
    let failure: unknown;
    try {
      for await (const message of l.query) {
        // D114: a query Clear (or a retry) replaced says nothing more.
        if (live !== l) break;
        try {
          await hear(l, message);
        } catch (err) {
          say(`[agent] ${describe(err)}`);
        }
      }
    } catch (err) {
      failure = err;
    }
    if (live !== l || l.closing) return;
    // Ended by itself, while current: the CLI is gone. The next Send resumes.
    live = undefined;
    status = 'off';
    retrying = null;
    const last = tail.slice(-TAIL).join('\n');
    const missing = failure !== undefined && /ENOENT|not found/i.test(describe(failure));
    error(missing ? NOT_FOUND : `Claude Code stopped${failure !== undefined ? `: ${describe(failure)}` : '.'}${last ? `\n${last}` : ''}`, 'Send goes on with the conversation.', missing ? 'not-found' : 'ended');
    denyCards();
    const turn = running;
    if (turn) await endTurn(turn, { how: 'error', why: 'Claude Code stopped', ms: now() - turn.startedAt, cost: null });
    changed();
  }

  async function hear(l: Live, m: SDKMessage): Promise<void> {
    let turn = running !== undefined && running.live === l ? running : undefined;
    // The subagents and background tasks (§2, "Subagents"): a row's start or end kept on disk; its progress pushed alone.
    const heard = agents.hear(m as unknown as StreamMessage, now(), turn?.id ?? null);
    if (heard === 'shape') saveKept();
    if (heard !== null) changed();
    // A background task the live set dropped: stopped after its grace even if nothing more is heard (`agents.ts`).
    armSweep();
    switch (m.type) {
      case 'system': {
        if (m.subtype === 'commands_changed') {
          commands = commandRows(m.commands);
          saveKept();
          changed();
        } else if (m.subtype === 'init') {
          if (sessionId !== m.session_id) {
            sessionId = m.session_id;
            saveKept();
          }
          if (!l.noted) {
            l.noted = true;
            skills = [...m.skills];
            // Once a conversation: a resumed query with the same skills says nothing new.
            const same = skillsSaid !== null && skillsSaid.length === skills.length && skillsSaid.every((n, i) => n === skills![i]);
            if (!same) {
              const named = [...skills];
              skillsSaid = named;
              saveKept();
              const own = await (ownSkills ??= readOwnSkills(root));
              // D114: a query cleared or replaced while the project's skills were read says nothing more -- its note
              // would land in the next conversation's log.
              if (live !== l) return;
              add(skillsNote(named, own));
            }
            changed();
          }
        } else if (m.subtype === 'api_retry') {
          retrying = { attempt: m.attempt, of: m.max_retries };
          changed();
        } else if (m.subtype === 'compact_boundary') {
          add({ kind: 'note', text: 'The conversation was compacted to fit' });
        }
        return;
      }
      case 'stream_event': {
        const event = m.event;
        if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') session.host?.push({ delta: { text: event.delta.text, sub: m.parent_tool_use_id !== null } });
        return;
      }
      case 'rate_limit_event': {
        const info = m.rate_limit_info;
        rateResets = info.resetsAt;
        // `/usage`'s limits: every event, said or not.
        usage = withRate(usage, info, now());
        saveKept();
        changed();
        const resets = info.resetsAt !== undefined ? `; resets ${localTime(info.resetsAt, now())}` : '';
        const key = usageKey(info.status, info.rateLimitType, info.resetsAt);
        if (rateSaid.has(key)) return;
        rateSaid.add(key);
        saveKept();
        if (info.status === 'rejected') error(`Usage limit reached${resets}`, FAILURES.rate_limit!.next, 'usage');
        else if (info.status === 'allowed_warning') {
          const used = info.utilization !== undefined ? ` ${Math.round(info.utilization * 100)} % of` : ' near';
          add({ kind: 'note', text: `Usage at${used} the ${(info.rateLimitType ?? 'usage').replace(/_/g, '-')} limit${resets}` });
        }
        return;
      }
      case 'assistant': {
        if (retrying) {
          retrying = null;
          changed();
        }
        if (m.error) {
          const failure = FAILURES[m.error] ?? FAILURES.unknown!;
          const resets = m.error === 'rate_limit' && rateResets !== undefined ? `; resets ${localTime(rateResets, now())}` : '';
          error(`${failure.text}${resets}`, failure.next, failure.code);
          // Not logged in is the state's to say, with Retry: this process heard it.
          if (failure.code === 'login') {
            loginFailure = { text: failure.text, next: failure.next! };
            changed();
          }
          return;
        }
        // Talking with no turn running: Claude Code went on by itself (a task it left running told it something).
        turn ??= running === undefined && live === l ? wake(l) : undefined;
        const sub = m.parent_tool_use_id !== null;
        const parent = m.parent_tool_use_id ?? undefined;
        for (const block of m.message.content) {
          if (block.type === 'text' && block.text.trim() !== '') add({ kind: 'text', text: block.text, sub, ...(parent ? { parent } : {}) });
          else if (block.type === 'tool_use') toolUse(turn, block.id, block.name, block.input, sub, parent);
        }
        return;
      }
      case 'user': {
        // A call completed, any agent's, in a turn or not: where the shells may be learns it (`ShellPlace.done`), as the PostToolUse hook does.
        if (typeof m.message.content !== 'string') for (const block of m.message.content) if (block.type === 'tool_result') shell.done(block.tool_use_id);
        if (!turn || typeof m.message.content === 'string') return;
        const results = m.message.content.filter((b) => b.type === 'tool_result');
        for (const block of results) {
          if (block.type !== 'tool_result') continue;
          // A write counts once it is done: a call refused or failed wrote nothing. A subagent's too.
          const path = turn.writing.get(block.tool_use_id);
          if (path !== undefined) {
            turn.writing.delete(block.tool_use_id);
            if (block.is_error !== true) turn.written.add(path);
          }
          // An editor tool's call the CLI refused before it reached the page -- its input did not fit the tool's schema (`"-2"` for
          // -2): no `editor` entry was made, and its row would read as done. Said, as the page's refusals are. One whose card was
          // denied is an error result too (the CLI marks a denial so): the card's answer says it, its row "-- denied".
          const refused = block.is_error === true ? editorUses.findIndex((u) => u.id === block.tool_use_id) : -1;
          if (refused >= 0 && refusedUses.delete(block.tool_use_id)) editorUses.splice(refused, 1);
          else if (refused >= 0) {
            const [use] = editorUses.splice(refused, 1);
            const said = (typeof block.content === 'string' ? block.content : (block.content ?? []).map((c) => ('text' in c ? c.text : '')).join(' ')).replace(/^Error:\s*/, '');
            const first = said.split('\n')[0]!.trim();
            add({ kind: 'editor', id: use!.id, turn: turn.id, tool: `${STUDIO_TOOLS}${use!.tool}`, ok: false, words: use!.detail, detail: `refused before it reached the editor: ${first.length > 140 ? `${first.slice(0, 139)}…` : first}`, tab: null });
          }
          if (m.parent_tool_use_id !== null) continue;
          const structured = results.length === 1 ? (m as { tool_use_result?: unknown }).tool_use_result : undefined;
          const round = turn.reviews.get(block.tool_use_id);
          if (round !== undefined) {
            const report = criticReport(structured ?? (typeof block.content === 'string' ? block.content : { status: 'completed', content: block.content }));
            if (report.score !== null) turn.last = report.score;
            add({ kind: 'review', id: block.tool_use_id, round, of: MAX_REVIEWS, bar: turn.bar, score: report.score, report: report.report, note: report.note });
            changed();
          }
          const subject = turn.creating.get(block.tool_use_id);
          if (subject !== undefined) {
            turn.creating.delete(block.tool_use_id);
            const id = (structured as { task?: { id?: unknown } } | undefined)?.task?.id;
            turn.tasks.set(typeof id === 'string' ? id : block.tool_use_id, { text: subject, status: 'pending' });
            add({ kind: 'todo', items: [...turn.tasks.values()].map((item) => ({ ...item })), sub: false });
          }
        }
        return;
      }
      case 'result': {
        // The CLI's running total, for the query's whole life: a turn's cost is what it grew by. Every result moves the base.
        const total = typeof m.total_cost_usd === 'number' ? m.total_cost_usd : null;
        const base = l.lastTotal;
        if (total !== null) l.lastTotal = total;
        // `/usage`'s cost and tokens: the session's whole, as the CLI keeps it.
        usage = withResult(usage, total, (m as { modelUsage?: Record<string, ModelTokens> }).modelUsage, now());
        if (!turn) return;
        const uuid = (m as { user_message_uuid?: string }).user_message_uuid;
        /** The person's turn this result is the end of, where Claude Code's own turn is running: theirs goes on under it. */
        let as: Turn | undefined;
        if (turn.origin === 'cli') {
          if (uuid !== undefined && l.sent.has(uuid)) {
            // A person's turn answered already: not this one's end. One still waiting for its own: this is it, and the work was theirs.
            as = l.open.get(uuid);
            if (as === undefined) return;
          }
        } else if (uuid !== undefined ? uuid !== turn.expect : m.subtype === 'success') {
          // Another turn's result; or a success naming none -- a sub-turn's, a background task's notification answered: the person's turn
          // goes on. An error result may carry none: it ends the turn in flight. Every person's result CLI 2.1.289 sent named its turn,
          // `/cost` too: should a later one not, the turn would run to Stop -- said here, so that is diagnosable.
          if (uuid === undefined) say(`[agent] a result naming no turn: not the end of the person's turn ${turn.id}`);
          return;
        }
        if (uuid !== undefined) l.open.delete(uuid);
        const ok = m.subtype === 'success' && !m.is_error;
        if (ok) loginFailure = null;
        const reason = m.subtype === 'success' ? (m.is_error ? m.result : null) : m.errors.filter((e) => !e.startsWith('[ede_diagnostic]')).join('; ') || m.subtype.replace(/_/g, ' ');
        retrying = null;
        const piece = total === null ? null : base === null ? total : Math.max(0, Math.round((total - base) * 1e6) / 1e6);
        // A turn sent back to fix its script (D110) costs what each of its results grew the total by.
        const cost = piece === null ? turn.spent : Math.round(((turn.spent ?? 0) + piece) * 1e6) / 1e6;
        // Done by its own account: its Gladius scripts built first, and sent back while one does not (D110).
        if (ok && !turn.stopping && !as && turn.origin === 'person' && options.check && (await sentBack(turn, l, cost))) return;
        if (running !== turn) return;
        const ms = turn.fixes > 0 ? now() - turn.startedAt : m.duration_ms;
        await endTurn(turn, { how: turn.stopping ? 'stopped' : ok ? 'done' : 'error', why: ok || turn.stopping ? null : reason, ms, cost, costSoFar: total !== null && base === null }, as);
        try {
          const answer = await l.query.getContextUsage();
          // A Clear meanwhile: the new conversation has used nothing yet.
          if (live === l) {
            context = Math.round(answer.percentage);
            usage = withContext(usage, answer, now());
          }
        } catch {
          // A usage the CLI would not give: the head keeps the last.
        }
        saveKept();
        changed();
        return;
      }
      default:
        return;
    }
  }

  /** One `tool_use` block: its row, or its checklist; a write's path and input; the critic's round. */
  function toolUse(turn: Turn | undefined, id: string, tool: string, input: unknown, sub: boolean, parent?: string): void {
    const of = parent ? { parent } : {};
    const record = typeof input === 'object' && input !== null ? (input as Record<string, unknown>) : {};
    if (tool === 'TodoWrite') {
      const todos = Array.isArray(record.todos) ? record.todos : [];
      const items = todos.flatMap((t): TodoItem[] => {
        const r = typeof t === 'object' && t !== null ? (t as Record<string, unknown>) : {};
        const status = r.status === 'completed' || r.status === 'in_progress' ? r.status : 'pending';
        return typeof r.content === 'string' ? [{ text: r.content, status }] : [];
      });
      add({ kind: 'todo', items, sub, ...of });
      return;
    }
    if (tool === 'TaskCreate' && turn) {
      turn.creating.set(id, typeof record.subject === 'string' ? record.subject : 'a task');
      return;
    }
    if (tool === 'TaskUpdate' && turn) {
      const task = typeof record.taskId === 'string' ? turn.tasks.get(record.taskId) : undefined;
      if (task) {
        if (typeof record.subject === 'string') task.text = record.subject;
        if (record.status === 'deleted') turn.tasks.delete(record.taskId as string);
        else if (record.status === 'pending' || record.status === 'in_progress' || record.status === 'completed') task.status = record.status;
        add({ kind: 'todo', items: [...turn.tasks.values()].map((item) => ({ ...item })), sub: false });
      }
      return;
    }
    // An editor tool's call: its row is matched to the page's answer by this id, should the CLI not say it.
    if (tool.startsWith(STUDIO_TOOLS)) {
      editorUses.push({ id, tool: tool.slice(STUDIO_TOOLS.length), detail: summarise(tool, input, root) });
      if (editorUses.length > 20) editorUses.shift();
    }
    let kept = false;
    if (WRITERS.has(tool) && turn) {
      const file = record.file_path ?? record.notebook_path;
      if (typeof file === 'string' && file !== '') turn.writing.set(id, projectPath(root, file));
      inputs.keep(turn.id, id, input);
      kept = inputs.has(id);
    }
    add({ kind: 'tool', id, tool, detail: summarise(tool, input, root), sub, input: kept, ...of });
    if (turn && !sub && isCriticLaunch(tool, input)) {
      const round = turn.reviews.size + 1;
      turn.reviews.set(id, round);
      add({ kind: 'review', id, round, of: MAX_REVIEWS, bar: turn.bar, score: null, report: null, note: null });
      changed();
    }
  }

  /** A studio tool's call, matched to its `tool_use` row: the CLI's id, else the first row of that tool still waiting. */
  function useFor(tool: string, use: string | null): string | null {
    const at = editorUses.findIndex((u) => (use === null ? u.tool === tool : u.id === use));
    const id = use ?? (at >= 0 ? editorUses[at]!.id : null);
    if (at >= 0) editorUses.splice(at, 1);
    return id;
  }

  /**
   * A page tool's call (Docs/mcp.md §3), relayed to the tab of the turn running -- or,
   * Claude Code going on by itself, the last that sent one; with neither, the relay's
   * pick -- within its deadline, and its answer as the row's words: an `editor` entry,
   * unless a Clear came meanwhile.
   */
  async function callPage(tool: PageToolName | ProjectToolName, args: Record<string, unknown>, use: string | null, deadline: number): Promise<PageAnswer> {
    const id = useFor(tool, use);
    const turn = running;
    const asked = turn?.tab ?? lastTab;
    const of = generation;
    const editor = session.host?.editor;
    /** The row's words for an answer: an `editor` entry, unless a Clear came meanwhile -- `late`, one that came after `timeout` was said. */
    const row = (answer: PageAnswer, tab: string | null, late: boolean): void => {
      if (id === null || of !== generation) return;
      // A scene_set's values, as values: the page carries them across a reload, its undo stack not surviving one.
      // A vector's (its numbers, a list) is kept by its step alone, as a colour's or an object's is.
      const result = 'result' in answer && answer.result.tool === 'scene_set' ? answer.result : null;
      const scalar = (v: number | string | number[]): v is number | string => !Array.isArray(v);
      const set = result && result.written.every((w) => scalar(w.was) && scalar(w.now))
        ? { component: result.component, field: result.field, step: result.step, written: result.written.map((w) => ({ id: w.id, was: w.was as number | string, now: w.now as number | string })) }
        : null;
      const why = (away: Away | 'lost'): string => awayWords(away, tool, deadline, studioUrl(options.port()));
      const words = tool.startsWith(PROJECT_PREFIX) ? projectRow(tool, answer, why) : rowWords(tool as PageToolName, args, answer, why);
      const said = late ? { ...words, detail: `Done after Claude was told it timed out (${Math.round(deadline / 1000)} s): ${words.detail ?? words.words}` } : words;
      add({ kind: 'editor', id, turn: turn?.id ?? null, tool: `${STUDIO_TOOLS}${tool}`, ...said, tab, ...(set ? { set } : {}) });
    };
    // An answer after the time ran out -- begun before it, and done: the transcript shows the write, as a row's answer.
    const late = (answer: PageAnswer, tab: string): void => row(answer, tab, true);
    const relayed: PageAnswer & { tab?: string } = editor ? await editor(asked, { tool, args, turn: turn?.id ?? null, use: id }, deadline, late) : { away: 'gone' };
    // The tab that ran it -- the relay's pick when none was asked for -- and the answer without it.
    const { tab: ran, ...answer } = relayed as PageAnswer & { tab?: string };
    // An asset write with no tab to run it is the dev server's (D2): its row is the server's, once done.
    if (!(beforeDelivery(answer as PageAnswer) && metaOf(tool)?.offline === true && session.host?.assets?.())) row(answer as PageAnswer, ran ?? asked, false);
    return answer as PageAnswer;
  }

  /** A project tool's row (Docs/mcp.md M7): its name, and what its handler said or why it did not run. */
  function projectRow(tool: string, answer: PageAnswer, why: (away: Away | 'lost') => string): RowWords {
    const name = tool.slice(PROJECT_PREFIX.length);
    if ('error' in answer) return { ok: false, words: `${name} (the project's tool)`, detail: answer.error };
    if ('away' in answer) return { ok: false, words: `${name} (the project's tool)`, detail: why(awayOf(answer)) };
    const r = answer.result as unknown as ProjectToolResult;
    return { ok: true, words: r.step ?? name, detail: r.words };
  }

  /** A server tool's call done (`job_wait`, `claude_settings`): its row's words, an `editor` entry with no tab. */
  function serverRow(tool: string, _args: Record<string, unknown>, use: string | null, row: RowWords): void {
    const id = useFor(tool, use);
    if (id !== null) add({ kind: 'editor', id, turn: running?.id ?? null, tool: `${STUDIO_TOOLS}${tool}`, ...row, tab: null });
  }

  /** Claude's own settings, as `claude_settings` reads them (D4). */
  function claudeSettings(): ClaudeSettingsFacts {
    return { model: settings.model, effort: settings.effort, review: settings.review, level: settings.level, models, bars: [...BARS] };
  }

  /** `claude_settings` setting model, effort or review -- as `POST settings` does -- each change a note in the transcript; never the level. */
  async function setClaudeSettings(change: ClaudeSettingsChange): Promise<ClaudeSettingsFacts> {
    const before = { ...settings };
    await changeSettings({ ...(change.model !== undefined ? { model: change.model } : {}), ...(change.effort !== undefined ? { effort: change.effort } : {}), ...(change.review !== undefined ? { review: change.review } : {}) });
    const label = (value: string | null): string => (value === null ? 'the default' : (models.find((m) => m.value === value)?.label ?? value));
    if (settings.model !== before.model) add({ kind: 'note', text: `Claude set the model to ${label(settings.model)}.` });
    if (settings.effort !== before.effort) add({ kind: 'note', text: `Claude set the effort to ${settings.effort ?? 'the default'}.` });
    if (settings.review !== before.review) {
      const bar = BARS.find((b) => b.value === settings.review);
      add({ kind: 'note', text: bar?.score == null ? 'Claude set the review to none.' : `Claude set the review to ${bar.label} (${bar.score}/10).` });
    }
    changed();
    return claudeSettings();
  }

  /** The critic's request for the turn running now: the host's words (`hooks.ts`); git failing, without the file list. */
  async function requestForCritic(): Promise<string | undefined> {
    const turn = running;
    if (!turn) return undefined;
    const changes = await repos.changes(await turn.baseline, turn.written).catch(() => null);
    return criticRequest({ prompt: turn.prompt, context: turn.context, images: turn.images, files: changes?.files ?? null, before: changes?.before ?? [] });
  }

  /** A turn Claude Code started itself, opened by its first message (`hear`): held, timed and stoppable like the person's. */
  function wake(l: Live): Turn {
    const t = newTurn('cli', null);
    t.live = l;
    t.sent = true;
    ignoredCache = new Map();
    // No snapshot: a turn of the CLI's own has no Undo (no user message to rewind to).
    t.baseline = repos.baseline().catch(() => null);
    running = t;
    add({ kind: 'rule', text: 'Claude Code went on by itself', reset: false });
    changed();
    return t;
  }

  /** A turn, not yet sent. */
  function newTurn(origin: Turn['origin'], bar: number | null, prompt = '', images = 0): Turn {
    const id = turnId(now());
    return {
      id,
      origin,
      tab: null,
      live: undefined as unknown as Live,
      startedAt: now(),
      bar,
      prompt,
      context: null,
      images,
      baseline: Promise.resolve(null),
      sent: false,
      stopping: false,
      stopTimer: undefined,
      written: new Set(),
      writing: new Map(),
      reviews: new Map(),
      last: null,
      tasks: new Map(),
      creating: new Map(),
      expect: id,
      fixes: 0,
      heldBefore: new Set(options.held?.() ?? []),
      checking: false,
      spent: null,
      deny: new Set(),
    };
  }

  // ---------------------------------------------------------------- a turn

  /**
   * D110 (Docs/modeler.md): a turn done by its own account whose Gladius
   * scripts do not build is sent back, in the same conversation, with
   * Gladius's errors -- up to `MAX_FIXES` times, said in the transcript and the
   * head, the turn running on throughout (Send waits, the export stays held).
   * True: sent back, its result is the fix's. False: it builds, or the fixes
   * are spent (said), or it was stopped meanwhile -- the turn ends.
   */
  async function sentBack(turn: Turn, l: Live, cost: number | null): Promise<boolean> {
    // The scripts this turn wrote, and those held since it began (a command's save) -- not ones held before it, nor ones
    // another running turn is writing: theirs to have checked at their own end.
    const others = new Set(options.others?.() ?? []);
    const heldSince = (options.held?.() ?? []).filter((p) => !turn.heldBefore.has(p) && !others.has(p));
    const scripts = [...new Set([...turn.written, ...heldSince])].filter((path) => /\.lua$/i.test(path) && path.startsWith('AssetsSource/'));
    if (scripts.length === 0) return false;
    turn.checking = true;
    turn.spent = cost;
    changed();
    let broken: ScriptCheck[] = [];
    try {
      broken = await options.check!(scripts);
    } catch (err) {
      say(`[agent] the turn's scripts could not be checked: ${describe(err)}`);
    }
    turn.checking = false;
    // Stopped, cleared or closed while Gladius built: nothing more is sent.
    if (running !== turn || turn.stopping || live !== l) {
      changed();
      return running !== turn;
    }
    if (broken.length === 0) {
      // What happens to the export is the hold's to say, as the last turn ends (`turn-hold.ts`): not said here.
      if (turn.fixes > 0) add({ kind: 'note', text: `It builds again, after ${fixesWords(turn.fixes)}` });
      changed();
      return false;
    }
    if (turn.fixes >= MAX_FIXES) {
      add({ kind: 'note', text: `${brokenWords(broken)} -- still, after ${fixesWords(MAX_FIXES)}: kept as it is` });
      changed();
      return false;
    }
    turn.fixes++;
    const uuid = randomUUID();
    turn.expect = uuid;
    l.sent.add(uuid);
    l.open.clear();
    l.open.set(uuid, turn);
    add({ kind: 'note', text: `${brokenWords(broken)}: sent back to fix it (${turn.fixes}/${MAX_FIXES})` });
    changed();
    l.stream.push({ type: 'user', message: { role: 'user', content: [{ type: 'text', text: fixPrompt(broken, turn.fixes, MAX_FIXES) }] }, parent_tool_use_id: null, session_id: sessionId ?? '', uuid: uuid as SDKUserMessage['uuid'] });
    return true;
  }

  /**
   * The turn over: its result entry with git's view of its files, the held
   * reload sent. Once. `as`: Claude Code's own turn ended by a person's turn's
   * result -- that turn's, then: its id (its Undo), its files from its baseline.
   */
  function endTurn(turn: Turn, outcome: { how: 'done' | 'stopped' | 'error'; why: string | null; ms: number; cost: number | null; costSoFar?: boolean }, as?: Turn): Promise<void> {
    if (running !== turn) return ending;
    running = undefined;
    if (turn.stopTimer !== undefined) clearTimeout(turn.stopTimer);
    denyCards();
    const of = generation;
    const whose = as ?? turn;
    ending = (async () => {
      const written = as ? new Set([...as.written, ...turn.written]) : turn.written;
      const changes = await repos.changes(await whose.baseline, written).catch(() => ({ files: [], added: 0, removed: 0, before: [] }));
      // Cleared while git answered: the result is the conversation before's, and the log has moved on.
      if (of !== generation) return;
      add({
        kind: 'result',
        turn: whose.id,
        ok: outcome.how === 'done',
        how: outcome.how,
        why: outcome.why,
        ms: outcome.ms,
        cost: outcome.cost,
        ...(outcome.costSoFar ? { costSoFar: true } : {}),
        ...(whose.origin === 'cli' ? { origin: 'cli' as const } : {}),
        files: changes.files,
        added: changes.added,
        removed: changes.removed,
        before: changes.before,
      });
      release();
      changed();
    })();
    return ending;
  }

  // ---------------------------------------------------------------- /usage and /btw

  /** `/usage`: the CLI asked afresh where it is up -- its usage call, then the context window -- each within 3 s. */
  async function usageNow(): Promise<UsageAnswer> {
    await session.ready;
    const l = live !== undefined && status === 'up' && !live.closing ? live : undefined;
    let fresh = false;
    if (l) {
      // Experimental in SDK 0.3.220 (its name says so): used where there, the events' facts where not.
      if (l.query.usage_EXPERIMENTAL_MAY_CHANGE_DO_NOT_RELY_ON_THIS_API_YET) {
        try {
          const call = await within(l.query.usage_EXPERIMENTAL_MAY_CHANGE_DO_NOT_RELY_ON_THIS_API_YET(), USAGE_MS);
          if (live === l) {
            usage = fromUsageCall(usage, call as unknown as UsageCall, now());
            fresh = true;
          }
        } catch (err) {
          say(`[agent] the CLI's usage call: ${describe(err)}`);
        }
      }
      try {
        const answer = await within(l.query.getContextUsage(), USAGE_MS);
        if (live === l) {
          usage = withContext(usage, answer, now());
          if (usage.context) context = usage.context.percent;
        }
      } catch {
        // The last context heard stands.
      }
      saveKept();
      changed();
    }
    return { usage, live: fresh };
  }

  /** While a background task's row waits out its grace (`agents.ts`' `dropping`), a timer to end it: again while one waits. */
  function armSweep(): void {
    if (!agents.dropping() || sweeping !== undefined) return;
    sweeping = setTimeout(() => {
      sweeping = undefined;
      if (agents.sweep(now())) {
        saveKept();
        changed();
      }
      armSweep();
    }, DROP_GRACE_MS + 50);
    // Never what keeps the dev server's process up.
    (sweeping as { unref?: () => void }).unref?.();
  }

  /** `/btw`: the question said at once, its answer by the same id when the fork has it. */
  async function btw(question: string): Promise<BtwAnswer> {
    await session.ready;
    const words = question.trim();
    if (away) throw new Refused(409, AWAY);
    if (words === '') throw new Refused(422, BTW_EMPTY);
    // Nothing to fork: refused, rather than answered with no context as if it knew the conversation.
    if (sessionId === undefined) throw new Refused(409, BTW_NONE);
    if (!available) throw new Refused(503, why ?? SDK_MISSING);
    const id = `btw-${randomUUID().slice(0, 8)}`;
    const from = sessionId;
    const of = generation;
    const started = now();
    add({ kind: 'btw', id, question: words, answer: null, error: null, tokens: null, ms: null });
    void aside(from, words).then((done) => {
      // Cleared meanwhile: the conversation it was about is gone, and so is the question.
      if (of !== generation) return;
      add({ kind: 'btw', id, question: words, answer: done.answer, error: done.error, tokens: done.tokens, ms: now() - started });
    });
    return { id };
  }

  /**
   * The fork that answers `/btw`: the conversation `from` resumed with `forkSession` and `persistSession: false` -- a
   * copy, written nowhere, the conversation itself untouched -- with no tools (`tools: []`, no MCP servers, every call
   * denied besides), one turn, no setting sources (no hooks of the project's run for it). It reports its own turn's
   * tokens (its result's `usage`), never a dollar figure: its running total may carry the conversation's.
   */
  async function aside(from: string, question: string): Promise<{ answer: string | null; error: string | null; tokens: BtwTokens }> {
    let sdk: SdkLike;
    try {
      sdk = await (options.sdk ?? importSdk)();
    } catch {
      return { answer: null, error: SDK_MISSING, tokens: null };
    }
    const env = (options.env ?? (() => agentEnv()))();
    const claude = await (options.findClaude ?? findClaude)(env);
    async function* once(): AsyncGenerator<SDKUserMessage> {
      yield { type: 'user', message: { role: 'user', content: question }, parent_tool_use_id: null, session_id: from };
    }
    const asked: Options = {
      cwd: root,
      resume: from,
      forkSession: true,
      persistSession: false,
      maxTurns: 1,
      tools: [],
      mcpServers: {},
      strictMcpConfig: true,
      settingSources: [],
      permissionMode: 'default',
      canUseTool: async () => ({ behavior: 'deny', message: BTW_NO_TOOLS }),
      systemPrompt: { type: 'preset', preset: 'claude_code', append: BTW_BRIEF },
      ...(settings.model !== null ? { model: settings.model } : {}),
      env,
      ...(claude !== undefined ? { pathToClaudeCodeExecutable: claude } : {}),
      stderr: (data: string) => {
        for (const line of data.split(/\r?\n/)) if (line.trim() !== '') say(`[agent btw] ${line}`);
      },
    };
    let q: QueryLike;
    try {
      q = sdk.query({ prompt: once(), options: asked });
    } catch (err) {
      return { answer: null, error: `The side question could not start: ${describe(err)}`, tokens: null };
    }
    asides.add(q);
    let late = false;
    const timer = setTimeout(() => {
      late = true;
      try {
        q.close();
      } catch {
        // Gone already.
      }
    }, BTW_MS);
    const text: string[] = [];
    let answer: string | null = null;
    let error: string | null = null;
    let tokens: BtwTokens = null;
    try {
      for await (const m of q) {
        if (m.type === 'assistant' && m.parent_tool_use_id === null) {
          if (m.error) error = (FAILURES[m.error] ?? FAILURES.unknown!).text;
          for (const block of m.message.content) if (block.type === 'text' && block.text.trim() !== '') text.push(block.text);
        } else if (m.type === 'result') {
          // Its own turn's tokens (`usage`, the turn's): never its running total, which a resumed fork may or may not
          // carry over from the conversation -- the SDK does not say.
          tokens = btwTokens((m as { usage?: Record<string, unknown> }).usage);
          if (m.subtype === 'success' && !m.is_error) answer = m.result.trim() !== '' ? m.result : text.join('\n\n');
          else {
            // The result's own words over the assistant's code: "tool_use ids were found without tool_result blocks …"
            // says more than "refused as invalid".
            const said = m.subtype === 'success' ? m.result : m.errors.filter((e) => !e.startsWith('[ede_diagnostic]')).join('; ');
            error = said.trim() !== '' ? said : (error ?? m.subtype.replace(/_/g, ' '));
          }
          break;
        }
      }
    } catch (err) {
      error ??= describe(err);
    } finally {
      clearTimeout(timer);
      asides.delete(q);
      try {
        q.close();
      } catch {
        // Gone already.
      }
    }
    if (answer === null && error === null) {
      if (text.length > 0) answer = text.join('\n\n');
      else error = late ? `No answer in ${Math.round(BTW_MS / 1000)} s: asked again, it may come` : 'No answer: the side question ended without one';
    }
    return { answer, error: answer !== null ? null : error, tokens };
  }

  /** Every `/btw` fork closed: Clear, the exit. */
  function closeAsides(): void {
    for (const q of asides) {
      try {
        q.close();
      } catch {
        // Gone already.
      }
    }
    asides.clear();
  }

  /** The held code reload, sent: one full reload to every page. */
  function release(): boolean {
    if (held.length === 0) return false;
    held.length = 0;
    session.host?.reload();
    changed();
    return true;
  }

  async function turn(request: TurnRequest): Promise<TurnAnswer> {
    await session.ready;
    if (away) throw new Refused(409, AWAY);
    if (running) throw new Refused(409, BUSY);
    await ending;
    if (running) throw new Refused(409, BUSY);
    // The bar as it is now (D110): a later change to the picker does not reach this turn.
    const review = settings.review;
    const label = BARS.find((b) => b.value === review)?.label ?? review;
    const prompt = request.prompt;
    const images = request.images ?? [];
    const t = newTurn('person', barScore(review), prompt, images.length);
    const id = t.id;
    t.tab = request.tab ?? null;
    if (t.tab !== null) lastTab = t.tab;
    // Tools refused for this turn (the Git card's draft): and no review loop, an answer in words having nothing to review.
    // `mcp__studio__writers` read as every studio tool that is no read, as the catalogue has them now.
    t.deny = new Set(deniedTools(request.deny ?? []));
    if (t.deny.size > 0) t.bar = null;
    // Claimed before anything is awaited: a second Send is 409 from here on.
    running = t;
    // The last turn's subagents go; any still running stay (§2, "Subagents").
    if (agents.begin()) saveKept();
    changed();
    try {
      ignoredCache = new Map();
      // The skill pages as they are now (Docs/skills.md §3): written before the CLI starts or the message goes.
      const pages = await options.skills?.().catch((err: unknown) => {
        say(`[agent] the skills were not written: ${describe(err)}`);
        return undefined;
      });
      // A query up compares with the digest it last read (taken as it started); none up starts below, reading them as written.
      const up = live;
      if (pages && up && !up.closing) {
        const stale = up.skills === undefined ? pages.changed : up.skills !== pages.digest;
        up.skills = pages.digest;
        if (stale) await session.reloadSkills();
      }
      // The baseline, and the tree as it is for Undo this turn: taken, and awaited, before the message goes.
      t.baseline = repos.baseline({ id, port: options.port(), ...(options.serial ? { serial: options.serial } : {}) }).catch(() => null);
      // A Send after a failure is a retry: the person asked for something.
      await attach(status === 'failed', pages?.digest);
      if (running !== t) return { uuid: id };
      if (!live || status !== 'up') throw new Refused(503, why ?? 'Claude Code is not running: see the transcript, then Retry');
      if (account?.loggedIn === false) throw new Refused(503, NOT_LOGGED_IN.text);
      t.live = live;
      // No critic, no review: the state said so before Send.
      if (!critic.loaded) t.bar = null;
      if (request.context) t.context = wordContext(request.context, await resolveModels(root, modelKeys(request.context)), images);
      await t.baseline;
      if (running !== t) return { uuid: id };
      add({ kind: 'prompt', turn: id, text: prompt, images: images.length, context: t.context });
      const content = turnContent({ context: t.context, prompt, images, loop: t.bar !== null ? reviewLoop(t.bar, label, critic.name) : null, conversation: options.title?.() ?? null });
      t.sent = true;
      live.sent.add(id);
      // Bounded: a result naming a turn this far back cannot come.
      for (const old of live.sent) {
        if (live.sent.size <= SENT_KEPT) break;
        live.sent.delete(old);
      }
      // The turn before's result, if it was ended early, comes before this one's: it is matched while this runs, or never.
      live.open.clear();
      live.open.set(id, t);
      live.stream.push({ type: 'user', message: { role: 'user', content }, parent_tool_use_id: null, session_id: sessionId ?? '', uuid: id as SDKUserMessage['uuid'] });
      changed();
    } catch (err) {
      if (running === t) {
        running = undefined;
        changed();
      }
      throw err;
    }
    return { uuid: id };
  }

  async function stop(): Promise<void> {
    const t = running;
    if (!t || t.stopping) return;
    t.stopping = true;
    denyCards();
    changed();
    // Not sent yet, or its scripts being built after its result (D110): nothing in flight to interrupt -- it ends here.
    if (!t.sent || t.checking) {
      await endTurn(t, { how: 'stopped', why: null, ms: now() - t.startedAt, cost: t.spent });
      return;
    }
    // No result in time: the CLI is closed, the turn ended, the next Send resumes in a new query.
    t.stopTimer = setTimeout(() => {
      if (running !== t) return;
      if (live === t.live) {
        shut(t.live);
        live = undefined;
        status = 'off';
      }
      void endTurn(t, { how: 'stopped', why: `no answer to Stop in ${Math.round(stopMs / 1000)} s: Claude Code was closed, and Send goes on with the conversation`, ms: now() - t.startedAt, cost: null });
    }, stopMs);
    try {
      await t.live.query.interrupt();
    } catch (err) {
      say(`[agent] interrupt: ${describe(err)}`);
    }
  }

  async function clear(): Promise<void> {
    await session.ready;
    generation++;
    const t = running;
    const l = live;
    denyCards();
    if (l) {
      if (t?.sent) {
        try {
          await within(l.query.interrupt(), 2000);
        } catch {
          // Closed below either way.
        }
      }
      shut(l);
    }
    live = undefined;
    status = 'off';
    if (t) {
      running = undefined;
      if (t.stopTimer !== undefined) clearTimeout(t.stopTimer);
    }
    release();
    sessionId = undefined;
    retrying = null;
    context = null;
    skills = null;
    inputs.clear();
    settled.clear();
    rateSaid.clear();
    skillsSaid = null;
    loginFailure = null;
    editorUses.length = 0;
    refusedUses.clear();
    closeAsides();
    agents.reset();
    // The plan's limits are the account's, not the conversation's: kept. Its cost, tokens and context go with it.
    usage = { ...NO_USAGE, limits: usage.limits, plan: usage.plan, subscription: usage.subscription, at: usage.at };
    // Undo this turn goes with the conversation: its snapshots too -- its own turns' alone, never another conversation's or port's.
    const turns = log.entries.flatMap((e) => (e.kind === 'prompt' ? [e.turn] : []));
    void repos.drop(options.port(), turns).catch(() => 0);
    await store?.clear();
    log.reset('New conversation', now());
    const rule = log.entries[0]!;
    store?.append(rule);
    saveKept();
    session.host?.push({ entry: rule });
    changed();
  }

  async function changeSettings(request: SettingsRequest): Promise<void> {
    await session.ready;
    const l = live !== undefined && status === 'up' ? live : undefined;
    // Both checked first, then applied: a refusal changes nothing.
    const model = request.model !== undefined ? modelSetting(request.model) : settings.model;
    let effort = settings.effort;
    let dropped = false;
    if (request.effort !== undefined) {
      effort = effortFor(models, model, request.effort);
      if (request.effort !== null && effort === null) throw new Refused(422, `${request.effort} is not an effort level of this model`);
    } else if (model !== settings.model && settings.effort !== null) {
      effort = effortFor(models, model, settings.effort);
      dropped = effort !== settings.effort;
    }
    if (model !== settings.model) {
      if (l) await l.query.setModel(model ?? undefined);
      settings.model = model;
    }
    if (effort !== settings.effort) {
      if (l) await l.query.applyFlagSettings({ effortLevel: effort as EffortLevel | null });
      if (dropped) {
        const name = models.find((m) => m.value === (model ?? 'default'))?.label ?? model ?? 'the default model';
        add({ kind: 'note', text: `${name} has no effort ${settings.effort}: dropped.` });
      }
      settings.effort = effort;
    }
    if (request.review !== undefined) settings.review = request.review;
    if (request.level !== undefined) settings.level = request.level;
    saveKept();
    changed();
  }

  /**
   * The files the result rows of `turn` and every turn after it named: what
   * its Undo may put back from the snapshot. And of those, the ones the first
   * row naming it says the turn made (`created`): there was none before, so
   * putting it back removes it.
   */
  function namedSince(turn: string): { named: Set<string>; made: Set<string>; others: Map<string, string> } {
    const named = new Set<string>();
    const made = new Set<string>();
    /** The files another conversation's later turn named, by its title: listed, and named so, in the preview. */
    const others = new Map<string, string>();
    const from = log.entries.findIndex((e) => (e.kind === 'prompt' || e.kind === 'result') && e.turn === turn);
    if (from < 0) return { named, made, others };
    for (const e of log.entries.slice(from)) {
      if (e.kind !== 'result') continue;
      for (const f of e.files) {
        if (!named.has(f.path) && f.created) made.add(f.path);
        named.add(f.path);
      }
    }
    // Every conversation's turns after it in time: what they changed since is put back from this turn's snapshot too, as they are named.
    for (const o of options.later?.(log.entries[from]!.at) ?? []) {
      named.add(o.path);
      if (!others.has(o.path)) others.set(o.path, o.by);
    }
    return { named, made, others };
  }

  async function rewind(request: RewindRequest): Promise<RewindAnswer> {
    await session.ready;
    if (away) throw new Refused(409, AWAY);
    if (running) throw new Refused(409, BUSY);
    // Another conversation's turn may be editing the very files put back, its changes in no result row yet: it ends first.
    const busy = options.busy?.() ?? null;
    if (busy !== null && !request.dryRun) throw new Refused(409, busyWords(busy));
    await attach(false);
    if (!live || status !== 'up') throw new Refused(503, why ?? 'Claude Code is not running');
    // A real rewind answers no file list (checked in 0.3.220): its dry run first says what it puts back.
    const preview = await live.query.rewindFiles(request.turn, { dryRun: true });
    const files = preview.canRewind ? (preview.filesChanged ?? []).map((f) => projectPath(root, f)) : [];
    // The rest, from the turn's snapshot: what a command changed, deleted or made among the files the turns named.
    const { named, made: created, others } = namedSince(request.turn);
    const since = await repos.since(request.turn, named, new Set(files), options.port(), options.serial).catch(() => ({ found: false, changed: [], made: [] }));
    const covered = new Set([...files, ...since.changed, ...since.made]);
    const kept = since.found ? await keptOf(named, covered) : [...named].filter((f) => !covered.has(f)).sort();
    const any = since.changed.length + since.made.length > 0;
    const answer = (r: typeof preview, changed: string[], made: string[]): RewindAnswer => ({
      canRewind: r.canRewind || any,
      error: r.canRewind || any ? null : (r.error ?? null),
      files: r.canRewind ? files : [],
      created: r.canRewind ? files.filter((f) => created.has(f)) : [],
      added: r.canRewind ? (preview.insertions ?? 0) : 0,
      removed: r.canRewind ? (preview.deletions ?? 0) : 0,
      changed,
      made,
      kept,
      snapshot: since.found,
      skippedLinks: request.dryRun ? null : (r.skippedLinks ?? null),
      ...(busy !== null ? { busy } : {}),
      ...(others.size > 0 ? { others: [...(r.canRewind ? files : []), ...changed, ...made].flatMap((path) => (others.has(path) ? [{ path, by: others.get(path)! }] : [])) } : {}),
    });
    if (request.dryRun) return answer(preview, since.changed, since.made);
    const r = preview.canRewind ? await live.query.rewindFiles(request.turn, { dryRun: false }) : preview;
    // Only what the preview showed: put back from the snapshot, and -- listed, never otherwise -- removed.
    const changed = request.changed === undefined ? since.changed : since.changed.filter((f) => request.changed!.includes(f));
    const made = since.made.filter((f) => request.made?.includes(f) ?? false);
    const back = await repos.putBack(request.turn, changed, made, options.port());
    const all = [...(r.canRewind ? files : []), ...back.done];
    if (all.length > 0 || r.canRewind) add({ kind: 'note', text: `Put back ${all.length === 0 ? 'the files' : `${all.length} file${all.length === 1 ? '' : 's'}: ${all.join(', ')}`}, as they were before that turn${back.failed.length > 0 ? `; not put back: ${back.failed.join(', ')}` : ''}` });
    return answer(r, changed.filter((f) => !back.failed.includes(f)), made.filter((f) => !back.failed.includes(f)));
  }

  /** The files the turns named that nothing puts back but git ignores (a snapshot has no ignored file): said, not undone. */
  async function keptOf(named: ReadonlySet<string>, covered: ReadonlySet<string>): Promise<string[]> {
    const out: string[] = [];
    for (const f of named) if (!covered.has(f) && (await ignored(f))) out.push(f);
    return out.sort();
  }

  return session;
}
