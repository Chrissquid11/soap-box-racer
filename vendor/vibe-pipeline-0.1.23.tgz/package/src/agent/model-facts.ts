/**
 * The model tools' facts made from the assets server's answers (Docs/mcp.md M6), node-free: the server's
 * `model_params_get` (`mcp/tools/model.ts`) and the page's `model_info` (the editor's `model/model-agent.ts`) say a
 * script's parameters the same way, through this one function. A pure subpath (`@vibe/pipeline/model-facts`): types
 * alone imported.
 */
import type { ParamsAnswer } from '../assets/api-types.ts';
import type { ModelParamFacts } from './api-types.ts';

/** A `GET params` answer as the model tools say its parameters; null: none read. */
export function paramFacts(answer: Pick<ParamsAnswer, 'params' | 'set'>): ModelParamFacts[] | null {
  if (!answer.params) return null;
  return answer.params.map((p) => ({
    name: p.name, type: p.type, value: p.value, default: p.default, set: answer.set[p.name] !== undefined,
    ...(p.min !== undefined ? { min: p.min } : {}), ...(p.max !== undefined ? { max: p.max } : {}), ...(p.choices ? { choices: p.choices } : {}), ...(p.doc ? { doc: p.doc } : {}),
  }));
}
