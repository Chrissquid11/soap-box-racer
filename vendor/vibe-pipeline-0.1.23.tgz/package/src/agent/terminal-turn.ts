/**
 * What a terminal run's hooks tell (Docs/ai-panel.md §8), read: a module of its own, with no imports, so the agent's
 * server reads `POST terminal/turn` without loading the terminals (`terminal.ts`, whose imports lead back to the
 * server through the studio's tools).
 */
import type { TerminalTurnEvent } from './api-types.ts';

/** What a run's hook said (`POST terminal/turn`'s body) as the turn's event: a notification asks for a permission prompt or a question, and the CLI idle at its prompt is a turn over with no end to mark (`quiet`: one interrupted, or declined); null, nothing to tell. */
export function turnEvent(word: unknown, type: unknown): TerminalTurnEvent | null {
  if (word === 'stop') return 'stop';
  if (word === 'failed') return 'failed';
  if (word === 'notify') return type === 'permission_prompt' ? 'asks' : type === 'elicitation_dialog' ? 'question' : type === 'idle_prompt' ? 'quiet' : null;
  return null;
}
