/**
 * The agent's API under `/__agent/`, and its push channel (Docs/agent.md §2,
 * "The routes"): what the editor's panel calls, from this machine only.
 *
 * - **The routes**: `POST attach` (start the conversation's session if it is
 *   not up; `{ retry: true }`, the Retry button, starts again one that
 *   failed), `GET state?since=`, `POST turn`, `stop`, `clear`, `answer`,
 *   `settings`, `rewind`, `usage` (`/usage`), `btw` (`/btw`), `GET input?id=` -- each a conversation's, named by
 *   `?conversation=<id>` (none: the first, so a page from before
 *   conversations keeps working until it reloads), checked here first;
 *   `POST reload`, the held reload every conversation shares; the list's own
 *   -- `GET conversations`, `POST conversations/new`, `close`, `rename` and
 *   `order` (`conversations.ts`); `GET skills` and `POST skills`, the
 *   Config ▸ Claude ▸ Skills page's (`skills.ts`); and `POST mcp/answer`, the relay's. A
 *   refusal is `{ refused }` with `403`, `404`, `409`, `413`, `415`, `422` or
 *   `503`.
 * - **The guards are the assets server's** (`packages/pipeline/src/assets/http.ts`, one set
 *   for both APIs): a write from loopback, an `Origin` equal to `Host`, JSON.
 *   **Reads too** are this machine's -- the transcript holds the project's
 *   code and whatever the agent read: a `GET` from elsewhere answers
 *   `{ available: false, why: 'on this machine only' }`. There is no read mode.
 * - **Bodies**: `POST turn` at most 28 MB -- four images of at most 5 MB
 *   decoded, as base64 -- `POST mcp/answer` 4 MB, other JSON 64 KB.
 * - **The push**, on `vibebase:agent`, goes per socket **to loopback tabs
 *   only**, as the assets server keeps its tabs -- never `server.ws.send`,
 *   which reaches every page on the LAN, a phone testing the game too. Each
 *   conversation's message carries its id; a page whose hello said `multi`
 *   is pushed every conversation's and the list, one from before
 *   conversations the first's alone, which it takes for its one.
 * - **The studio tools' relay** (Docs/mcp.md §3; Docs/agent.md §8): a loopback
 *   tab says which it is on its socket (`hello`, `{ tab }`, its id from
 *   `sessionStorage`, the same across a reload, a duplicated tab's made anew);
 *   `relay` pushes `{ mcp: { id, tool, args, turn, use } }` to one tab's socket
 *   alone -- the turn's tab if it is known, else the last studio tab to say
 *   hello with a socket open (every tab that says this hello is a studio
 *   page's: the agent card is the editor's) -- the last to say hello as it, of
 *   the ones still open: an id is kept with a set of sockets, so two pages that
 *   said the same id, one closing, leave the other the id's -- and `POST
 *   mcp/answer` settles it, `409` for an id not waiting. No tab at all is
 *   `gone` at once; a call whose socket closes goes again to another of its
 *   tab's, or waits for the tab between two sockets (a reload) and goes again
 *   to its new one; no answer within the call's deadline (the tool's: 15 s,
 *   a minute for one that waits for a compile) is `timeout` -- the tab is
 *   there, and the call may yet land. The session words both. An id with no
 *   socket open is kept for the reload it may be in -- the last `IDLE_TABS` of
 *   them: a tab closed for good is forgotten, and the map does not grow for
 *   ever.
 *
 * It is handed the conversations (`conversations.ts`) and Node's own `http` types, nothing of Vite's, so
 * `server.test.ts` runs it on a bare `http.createServer`. Nothing at module
 * level.
 */
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { Refused, drain, guardHost, guardWrite, mayWrite, mutating, readJson, sendJson } from '../assets/http.ts';
import { isOutside } from '../mcp/outside.ts';
import { checkDecls } from '../mcp/project.ts';
import type { TabSocket } from '../assets/server.ts';
import type {
  AgentEvent,
  AlwaysDestination,
  AnswerRequest,
  CanvasTurn,
  ConversationsAnswer,
  EditorResult,
  MarkAnchor,
  McpCallOut,
  ModelTurn,
  PushMessage,
  TabMessage,
  ReviewBar,
  SelectedEntity,
  OutsideLevel,
  ProjectToolDecl,
  SettingsRequest,
  TerminalAnswer,
  TerminalTurnEvent,
  StateAnswer,
  ToolContext,
  TurnContext,
  TurnImage,
  TurnRequest,
  TurnTarget,
  Unavailable,
  Vec3,
} from './api-types.ts';
import type { LateAnswer, PageAnswer } from '../mcp/words.ts';
import type { Conversation, Conversations } from './conversations.ts';
import type { Terminals } from './terminal.ts';
import { turnEvent } from './terminal-turn.ts';
import { isBar } from './review.ts';
import { LOADED_NOW, NEXT_CONVERSATION, listSkills, makeSkill } from './skills.ts';

/** Where the API is. */
const PREFIX = '/__agent/';
/** `/usage` and `/btw` asked of a session made before they were (an older bundle's, kept in-process). */
const OLD_SESSION = 'this conversation was started by an older dev server: Clear it, or restart the dev server, for /usage and /btw';

/** The push channel's event. */
const EVENT: AgentEvent = 'vibebase:agent';

/** `POST turn`'s body at most: four images of 5 MB decoded, as base64, and the words. */
export const TURN_LIMIT = 28 * 1024 * 1024;
/** An image, decoded, at most: the API's own limit. */
export const IMAGE_LIMIT = 5 * 1024 * 1024;
/** Images in a turn, at most. */
export const IMAGES = 4;
/** An editor tool's answer at most: the selection whole, `describe()`'s text. */
export const ANSWER_LIMIT = 4 * 1024 * 1024;
/** How long a relayed call waits for its tab, in milliseconds, when it names no deadline of its own (each studio tool has one: `../mcp/catalog.ts`). */
export const RELAY_MS = 15_000;
/** Tab ids with no socket open kept, at most -- a reloading tab's says hello again within seconds: past these, the oldest is forgotten. */
export const IDLE_TABS = 32;
/** Calls whose time ran out kept for a late answer, at most: the newest. */
export const LATE_KEPT = 64;

/** What a read from another machine is told. */
const ELSEWHERE: Unavailable = { available: false, why: 'on this machine only' };

const MEDIA = new Set<TurnImage['media']>(['image/png', 'image/jpeg', 'image/gif', 'image/webp']);
const DESTINATIONS = new Set<AlwaysDestination>(['session', 'localSettings', 'projectSettings', 'userSettings']);

export interface AgentServerOptions {
  /** The open conversations: each route acts on one, by `?conversation=`. */
  conversations: Conversations;
  /** The port the page is served on: a refusal names it. */
  port?: () => number | undefined;
  /** This server's `server.allowedHosts` (`assets/http.ts`' `allowedHosts`): `Host` names trusted beside this machine's. None: none. */
  hosts?: () => readonly string[];
  /** What failed. */
  warn?: (line: string) => void;
  /** How long a relayed call waits for its tab when it names no deadline (`RELAY_MS`): a test's shorter. */
  relayMs?: number;
  /** The project root, for `GET` and `POST skills` (`skills.ts`); `plugin`, the plugin's folder (`CLAUDE_DIR`), a test's stand-in. None: those are 404. */
  skills?: { root: string; plugin?: string };
  /**
   * A terminal run's prompt context (Docs/terminal.md D7, `GET terminal/context`): the conversation whose run holds a
   * token, and the words for its prompt (`terminal-context.ts`); `turn`, what its hooks tell of a turn there (`POST
   * terminal/turn`, and a prompt's context asked: its turn begun -- Docs/ai-panel.md §8). None: those routes are 404.
   */
  terminal?: { find(token: string): string | null; context(conversation: string): Promise<string>; turn?(conversation: string, event: TerminalTurnEvent): void };
  /** The conversations' terminals (`terminal.ts`, Docs/terminal.md): `terminal`, `terminal/open`, `terminal/close`, and the keys over the socket. None: 404. */
  terminals?: Terminals;
}

export interface AgentServer {
  /** A request under `/__agent/` answered; false for anything else (the next middleware's). */
  handle(req: IncomingMessage, res: ServerResponse): Promise<boolean>;
  /** A page's websocket: a tab on this machine, if it is loopback. */
  connection(socket: TabSocket, req: IncomingMessage): void;
  /** A message to every loopback tab: a conversation's other than the first, and the list, only to those that said `multi`. */
  push(message: PushMessage): void;
  /** A page's hello on its socket (`import.meta.hot.send('vibebase:agent:hello', { tab, multi })`): which tab it is. Loopback sockets only. */
  hello(socket: TabSocket, data: unknown): void;
  /**
   * A page tool's call, to one studio tab -- `tab` if it is known, else the last to say hello with a socket open --
   * and its answer within `deadline` ms (`relayMs` left out), with the tab that ran it: `gone` for no tab at all,
   * `timeout` for no answer in time.
   */
  relay(tab: string | null, call: McpCallOut, deadline?: number, late?: LateAnswer): Promise<PageAnswer & { tab?: string }>;
  /**
   * The project's own MCP tools (Docs/mcp.md M7), as the tab a call with no turn's would go to -- the last studio tab to
   * say hello with a socket open -- declared in its hello: none, no such tab or none declared.
   */
  projectTools(): ProjectToolDecl[];
  /**
   * Keys or a size for a conversation's terminal, from a page's socket (`vibebase:agent:terminal`, Docs/terminal.md
   * D3): `{ conversation, data }` or `{ conversation, cols, rows }`. Taken only from a loopback socket that opened as a
   * page of this server's own origin -- the keys reach a program.
   */
  terminal(socket: TabSocket, data: unknown): void;
}

// ---------------------------------------------------------------- checking a body

const bad = (what: string): never => {
  throw new Refused(422, what);
};

function str(value: unknown, what: string, max = 2000): string {
  if (typeof value !== 'string') bad(`${what} is not a string`);
  if ((value as string).length > max) bad(`${what} is over ${max} characters`);
  return value as string;
}

function strOrNull(value: unknown, what: string, max = 2000): string | null {
  return value === null || value === undefined ? null : str(value, what, max);
}

function list<T>(value: unknown, what: string, max: number, item: (v: unknown, i: number) => T): T[] {
  if (!Array.isArray(value)) bad(`${what} is not a list`);
  if ((value as unknown[]).length > max) bad(`${what} has more than ${max}`);
  return (value as unknown[]).map(item);
}

function record(value: unknown, what: string): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) bad(`${what} is not an object`);
  return value as Record<string, unknown>;
}

/** A `TurnContext` as the page sends it: facts, each checked and capped. */
export function checkContext(raw: unknown): TurnContext {
  const c = record(raw, 'context');
  const scene = c.scene === null || c.scene === undefined ? null : record(c.scene, 'context.scene');
  const tools = list(c.tools ?? [], 'context.tools', 32, (v, i): ToolContext => {
    const tool = record(v, `context.tools[${i}]`);
    return {
      tool: str(tool.tool, 'a tool', 100),
      facts: list(tool.facts ?? [], 'a tool\'s facts', 32, (f) => {
        const fact = record(f, 'a fact');
        return { name: str(fact.name, 'a fact\'s name', 100), value: Array.isArray(fact.value) ? list(fact.value, 'a fact\'s values', 64, (s) => str(s, 'a value', 500)) : str(fact.value, 'a fact\'s value', 1000) };
      }),
    };
  });
  const selection = list(c.selection ?? [], 'context.selection', 8, (v): SelectedEntity => {
    const e = record(v, 'a selected entity');
    if (typeof e.id !== 'number' || !Number.isInteger(e.id)) bad('a selected entity has no id');
    return {
      id: e.id as number,
      name: strOrNull(e.name, 'a name', 200),
      prefab: strOrNull(e.prefab, 'a prefab key', 300),
      node: strOrNull(e.node, 'a prefab node', 200),
      labels: list(e.labels ?? [], 'labels', 32, (s) => str(s, 'a label', 100)),
      models: list(e.models ?? [], 'models', 16, (s) => str(s, 'a model key', 300)),
    };
  });
  const more = c.more ?? 0;
  if (typeof more !== 'number' || !Number.isInteger(more) || more < 0) bad('context.more is not a count');
  return {
    game: str(c.game ?? '', 'context.game', 200),
    playtest: c.playtest === true,
    ...(c.play === 'running' || c.play === 'paused' ? { play: c.play } : {}),
    scene: scene === null ? null : { name: strOrNull(scene.name, 'the scene\'s name', 200), unsaved: scene.unsaved === true },
    tool: strOrNull(c.tool, 'context.tool', 100),
    tools,
    selection,
    more: more as number,
    ...(c.model === null || c.model === undefined ? {} : { model: checkModel(c.model) }),
    ...(c.target === undefined ? {} : { target: c.target === null ? null : checkTarget(c.target) }),
  };
}

/** A control character: a newline in a target's name would start a line of its own in the turn's context. */
const CONTROL = /[\u0000-\u001f\u007f]/;

/** A control character but a line's end and a tab: what a problem's message and a console line may not hold. */
const CONTROL_TEXT = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/;

/** `value`, refused if any of its strings holds a control character -- a target is worded line by line. */
function plain<T>(value: T, what: string): T {
  const strings = (v: unknown): string[] => (typeof v === 'string' ? [v] : Array.isArray(v) ? v.flatMap(strings) : typeof v === 'object' && v !== null ? Object.values(v).flatMap(strings) : []);
  if (strings(value).some((s) => CONTROL.test(s))) bad(`${what} holds a control character`);
  return value;
}

/** A problem's message or a console line: line ends and tabs allowed (the words fold them into one line), no other control character. */
function output(value: unknown, what: string): string {
  const text = str(value, what, 4000);
  if (CONTROL_TEXT.test(text)) bad(`${what} holds a control character`);
  return text;
}

/** A quick prompt's target as the page sends it (Docs/ai-panel.md §4): one of its kinds, each checked, capped and plain. */
export function checkTarget(raw: unknown): TurnTarget {
  const t = checkTargetShape(raw);
  // A problem's message and a console line's text are checked in their own cases (`output`); every other string here.
  plain(t.kind === 'problem' ? { ...t, message: '' } : t.kind === 'log' ? { ...t, text: '' } : t, 'context.target');
  return t;
}

function checkTargetShape(raw: unknown): TurnTarget {
  const t = record(raw, 'context.target');
  switch (t.kind) {
    case 'entities': {
      const more = t.more ?? 0;
      if (typeof more !== 'number' || !Number.isInteger(more) || more < 0) bad('context.target.more is not a count');
      return { kind: 'entities', entities: checkContext({ selection: t.entities ?? [] }).selection, more: more as number };
    }
    case 'asset':
      return { kind: 'asset', path: str(t.path, 'the target\'s path', 500), key: strOrNull(t.key, 'the target\'s key', 300) };
    case 'parts':
      return { kind: 'parts', script: str(t.script, 'the target\'s script', 500), parts: names(t.parts, 'the target\'s parts') };
    case 'file': {
      const line = t.line === null || t.line === undefined ? null : num(t.line, 'the target\'s line');
      if (line !== null && (!Number.isInteger(line) || line < 1)) bad('the target\'s line is not a line');
      return { kind: 'file', path: str(t.path, 'the target\'s path', 500), line };
    }
    case 'problem': {
      const at = (v: unknown, what: string): number => {
        const n = num(v ?? 0, what);
        if (!Number.isInteger(n) || n < 0) bad(`${what} is not a place`);
        return n;
      };
      return {
        kind: 'problem',
        file: str(t.file, 'the problem\'s file', 500),
        line: at(t.line, 'the problem\'s line'),
        col: at(t.col, 'the problem\'s column'),
        code: str(t.code ?? '', 'the problem\'s code', 40),
        message: output(t.message, 'the problem\'s message'),
        program: str(t.program ?? '', 'the problem\'s program', 40),
      };
    }
    case 'log':
      return { kind: 'log', stream: str(t.stream, 'the line\'s stream', 100), text: output(t.text, 'the line') };
    default:
      return bad('context.target is no kind of target');
  }
}

const num = (value: unknown, what: string): number => {
  if (typeof value !== 'number' || !Number.isFinite(value)) bad(`${what} is not a number`);
  return value as number;
};
const vec3 = (value: unknown, what: string): Vec3 => {
  const l = list(value, what, 3, (n, i) => num(n, `${what}[${i}]`));
  if (l.length !== 3) bad(`${what} is not three numbers`);
  return l as Vec3;
};
const names = (value: unknown, what: string): string[] => list(value ?? [], what, 64, (n) => str(n, `a name in ${what}`, 200));

/** One mark of a canvas (D33): where it lands, or how it misses. */
function checkMark(raw: unknown, i: number): MarkAnchor {
  const m = record(raw, `marks[${i}]`);
  const box = record(m.box, 'a mark\'s box');
  const hit = m.hit === null || m.hit === undefined ? null : record(m.hit, 'a mark\'s hit');
  const miss = m.miss === null || m.miss === undefined ? null : record(m.miss, 'a mark\'s miss');
  return {
    colour: str(m.colour, 'a mark\'s colour', 40),
    hex: str(m.hex, 'a mark\'s hex', 16),
    area: num(m.area, 'a mark\'s area'),
    box: { x: num(box.x, 'box.x'), y: num(box.y, 'box.y'), w: num(box.w, 'box.w'), h: num(box.h, 'box.h') },
    coverage: num(m.coverage, 'a mark\'s coverage'),
    hit: hit === null ? null : { point: vec3(hit.point, 'hit.point'), normal: hit.normal === null || hit.normal === undefined ? null : vec3(hit.normal, 'hit.normal'), extent: num(hit.extent, 'hit.extent'), parts: names(hit.parts, 'hit.parts') },
    miss: miss === null ? null : { from: vec3(miss.from, 'miss.from'), along: vec3(miss.along, 'miss.along'), plane: vec3(miss.plane, 'miss.plane'), ground: miss.ground === null || miss.ground === undefined ? null : vec3(miss.ground, 'miss.ground') },
  };
}

/** The Model tab's model and canvases as the page sends them (Docs/modeler.md M26): checked and capped as the rest of a context. */
export function checkModel(raw: unknown): ModelTurn {
  const m = record(raw, 'context.model');
  const bounds = m.bounds === null || m.bounds === undefined ? null : record(m.bounds, 'context.model.bounds');
  const canvases = list(m.canvases ?? [], 'context.model.canvases', 16, (v, i): CanvasTurn => {
    const c = record(v, `canvases[${i}]`);
    const cam = record(c.camera, 'a canvas\'s camera');
    const image = c.image === null || c.image === undefined ? null : num(c.image, 'a canvas\'s image');
    if (image !== null && (!Number.isInteger(image) || image < 0 || image >= IMAGES)) bad('a canvas\'s image is not one of the turn\'s');
    return {
      name: str(c.name, 'a canvas\'s name', 100),
      image,
      note: str(c.note ?? '', 'a canvas\'s note', 4000),
      colours: list(c.colours ?? [], 'a canvas\'s colours', 16, (k) => {
        const colour = record(k, 'a colour');
        return { name: str(colour.name, 'a colour\'s name', 40), hex: str(colour.hex, 'a colour\'s hex', 16), marks: num(colour.marks, 'a colour\'s marks') };
      }),
      camera: {
        projection: cam.projection === 'orthographic' ? 'orthographic' : 'perspective',
        position: vec3(cam.position, 'camera.position'),
        target: vec3(cam.target, 'camera.target'),
        up: vec3(cam.up, 'camera.up'),
        fov: num(cam.fov, 'camera.fov'),
        frustumHeight: num(cam.frustumHeight, 'camera.frustumHeight'),
        width: num(cam.width, 'camera.width'),
        height: num(cam.height, 'camera.height'),
      },
      marks: list(c.marks ?? [], 'a canvas\'s marks', 64, checkMark),
      selected: names(c.selected, 'a canvas\'s selection'),
      hidden: names(c.hidden, 'a canvas\'s hidden parts'),
      pose: strOrNull(c.pose ?? null, 'a canvas\'s pose', 200),
      step: strOrNull(c.step ?? null, 'a canvas\'s build step', 300),
    };
  });
  return {
    script: str(m.script, 'context.model.script', 500),
    export: strOrNull(m.export, 'context.model.export', 500),
    build: str(m.build ?? '', 'context.model.build', 1000),
    params: list(m.params ?? [], 'context.model.params', 128, (p) => {
      const param = record(p, 'a parameter');
      return { name: str(param.name, 'a parameter\'s name', 100), value: str(param.value, 'a parameter\'s value', 500), set: param.set === true };
    }),
    selected: names(m.selected, 'context.model.selected'),
    hidden: names(m.hidden, 'context.model.hidden'),
    bounds: bounds === null ? null : { min: vec3(bounds.min, 'bounds.min'), max: vec3(bounds.max, 'bounds.max') },
    preview: strOrNull(m.preview, 'context.model.preview', 500),
    pose: strOrNull(m.pose ?? null, 'context.model.pose', 300),
    step: strOrNull(m.step ?? null, 'context.model.step', 400),
    canvases,
    left: list(m.left ?? [], 'context.model.left', 16, (l) => str(l, 'a canvas left out', 300)),
  };
}

/** `POST turn`'s body: words, a context, at most four images of at most 5 MB each. */
export function checkTurn(body: Record<string, unknown>): TurnRequest {
  const prompt = str(body.prompt ?? '', 'prompt', 200_000);
  const images = list(body.images ?? [], 'images', IMAGES, (v, i): TurnImage => {
    const image = record(v, `images[${i}]`);
    const media = image.media as TurnImage['media'];
    if (!MEDIA.has(media)) bad(`images[${i}] is not a PNG, JPEG, GIF or WebP`);
    const data = str(image.data, `images[${i}].data`, Math.ceil((IMAGE_LIMIT * 4) / 3) + 4);
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(data)) bad(`images[${i}].data is not base64`);
    const decoded = Math.floor((data.length * 3) / 4) - (data.endsWith('==') ? 2 : data.endsWith('=') ? 1 : 0);
    if (decoded > IMAGE_LIMIT) throw new Refused(413, `images[${i}] is over 5 MB`);
    return { name: str(image.name ?? 'image', `images[${i}].name`, 200), media, data };
  });
  const context = body.context === null || body.context === undefined ? null : checkContext(body.context);
  // A canvas's note is words of the person's, beside the drawing they are about (Vibe3D D80): a turn of its own.
  const noted = context?.model?.canvases.some((c) => c.note.trim() !== '') ?? false;
  if (prompt.trim() === '' && images.length === 0 && !noted) bad('a turn needs words or an image');
  const tab = strOrNull(body.tab, 'tab', 100);
  // Tools refused for the turn: names, as the SDK has them (`Edit`, `mcp__studio__scene_set`).
  const deny = list(body.deny ?? [], 'deny', 32, (v) => {
    const name = str(v, 'a tool to deny', 100);
    if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(name)) bad(`deny names tools: ${name} is no tool's name`);
    return name;
  });
  return { prompt, context, images, tab, ...(deny.length > 0 ? { deny } : {}) };
}

/** `POST mcp/answer`'s body: the call's id, and one of a result, an error or why the editor cannot. */
function checkMcpAnswer(body: Record<string, unknown>): { id: string; answer: PageAnswer } {
  const id = str(body.id, 'id', 100);
  if ('result' in body) {
    const result = record(body.result, 'result');
    if (typeof result.tool !== 'string') bad('result names no tool');
    return { id, answer: { result: result as unknown as EditorResult } };
  }
  if ('error' in body) return { id, answer: { error: str(body.error, 'error', 4000) } };
  // `nopanel`: a tab with no Assets panel made, for an asset tool -- refused before any step, so the dev server runs it
  // instead (Docs/mcp.md M3). A `gone` from a page (one from before `nopanel`) is taken, as delivered: never run again.
  if (body.away === 'playtest' || body.away === 'nopanel') return { id, answer: { away: body.away } };
  if (body.away === 'gone') return { id, answer: { away: 'gone', delivered: true } };
  return bad('an answer is a result, an error, or away: playtest or nopanel');
}

function checkAnswer(body: Record<string, unknown>): AnswerRequest {
  const id = str(body.id, 'id', 200);
  if (typeof body.allow !== 'boolean') bad('allow is not true or false');
  const out: AnswerRequest = { id, allow: body.allow as boolean };
  if (body.always !== undefined && body.always !== null) {
    if (!DESTINATIONS.has(body.always as AlwaysDestination)) bad('always is not a destination: session, localSettings, projectSettings or userSettings');
    out.always = body.always as AlwaysDestination;
  }
  if (body.answers !== undefined && body.answers !== null) {
    const answers = record(body.answers, 'answers');
    out.answers = {};
    for (const [question, a] of Object.entries(answers)) {
      out.answers[question] = Array.isArray(a) ? list(a, 'an answer', 8, (s) => str(s, 'an answer', 2000)) : str(a, 'an answer', 2000);
    }
  }
  return out;
}

function checkSettings(body: Record<string, unknown>): SettingsRequest {
  const out: SettingsRequest = {};
  if ('model' in body) out.model = strOrNull(body.model, 'model', 200);
  if ('effort' in body) out.effort = strOrNull(body.effort, 'effort', 50);
  if ('review' in body) {
    if (!isBar(body.review)) bad('review is not a bar: none, ok, good, very-good, excellent or perfect');
    out.review = body.review as ReviewBar;
  }
  if ('level' in body) {
    if (body.level !== 'ask' && body.level !== 'auto' && body.level !== 'unsafe') bad('level is not ask, auto or unsafe');
    out.level = body.level as SettingsRequest['level'];
  }
  if ('fixBoot' in body) {
    if (typeof body.fixBoot !== 'boolean') bad('fixBoot is not true or false');
    out.fixBoot = body.fixBoot as boolean;
  }
  if ('outside' in body) {
    if (!isOutside(body.outside)) bad('outside is not off, read, write or destructive');
    out.outside = body.outside as OutsideLevel;
  }
  if ('secret' in body) out.secret = str(body.secret, 'secret', 200);
  return out;
}

/** Is `given` the page's secret? In constant time. */
function secretMatches(given: string | undefined, secret: string): boolean {
  if (given === undefined) return false;
  const a = Buffer.from(given);
  const b = Buffer.from(secret);
  return a.length === b.length && timingSafeEqual(a, b);
}

// ---------------------------------------------------------------- the server

export function createAgentServer(options: AgentServerOptions): AgentServer {
  const port = options.port ?? (() => undefined);
  const hosts = options.hosts ?? (() => []);
  const warn = options.warn ?? ((line: string) => console.error(line));
  /** Each tab's project tools (`Hello.tools`, Docs/mcp.md M7), by its id, with the problems last said of them. */
  const declared = new Map<string, { decls: ProjectToolDecl[]; bad: string }>();
  const relayMs = options.relayMs ?? RELAY_MS;
  const conversations = options.conversations;
  /** Tabs on this machine: loopback websockets. */
  const tabs = new Set<TabSocket>();
  /**
   * Of those, a page's: the upgrade carried this server's own `Origin`. Told the secret at its hello. A program that sends
   * none is told nothing -- but one that writes that `Origin` itself (outside a browser anyone may) is a page here, told it.
   */
  const pages = new WeakSet<TabSocket>();
  /**
   * The studio page's secret (`PageSecret`), made once a server: a change of the permission level or of what outside
   * clients may do carries it, with this server's own `Origin` -- the person's two. It stops a `curl`, Claude's own HTTP
   * tools and an outside MCP client, none of which hears a page's hello; it is no boundary against a local program that
   * opens the HMR socket as a page would (Docs/mcp.md §7 D1: a local program can do what the person can).
   */
  const pageSecret = randomBytes(32).toString('base64url');
  /** Of those, the pages that know conversations, plural (their hello said so). */
  const multi = new Set<TabSocket>();
  /**
   * Each tab by the id its hellos said, with the sockets still open that said
   * it, the latest last -- in the order they last said hello. One with no
   * socket open stays known, for the reload it may be in, but only the last
   * `IDLE_TABS` of those: a tab closed for good is forgotten.
   */
  const named = new Map<string, TabSocket[]>();
  /** The oldest ids with no socket open and no call waiting for them, let go past `IDLE_TABS`. */
  const trim = (): void => {
    let idle = 0;
    for (const sockets of named.values()) if (sockets.length === 0) idle++;
    for (const [id, sockets] of named) {
      if (idle <= IDLE_TABS) break;
      if (sockets.length > 0 || [...waiting.values()].some((call) => call.tab === id)) continue;
      named.delete(id);
      declared.delete(id);
      idle--;
    }
  };
  /** The socket a call to `tab` goes to: the last open one that said hello as it. */
  const socketOf = (tab: string): TabSocket | null => named.get(tab)?.at(-1) ?? null;
  /** A call sent again, on its tab's socket now: none open, it waits for one's hello. */
  const resend = (call: { tab: string; message: string; sentOn: TabSocket | null; delivered: boolean }): void => {
    const socket = socketOf(call.tab);
    call.sentOn = socket !== null && sendTo(socket, call.message) ? socket : null;
    if (call.sentOn !== null) call.delivered = true;
  };
  /**
   * Relayed calls waiting for their answer: to which tab, sent on which socket, whether it was ever sent (`delivered`:
   * a tab may have begun it), and how they settle.
   */
  const waiting = new Map<string, { tab: string; message: string; sentOn: TabSocket | null; delivered: boolean; settle(answer: PageAnswer): void }>();
  /** Calls whose time ran out, by id, for an answer that comes late: said to their `late`, the newest `LATE_KEPT`. */
  const lateCalls = new Map<string, { tab: string; late: LateAnswer }>();
  const keepLate = (id: string, call: { tab: string; late: LateAnswer }): void => {
    lateCalls.set(id, call);
    while (lateCalls.size > LATE_KEPT) lateCalls.delete(lateCalls.keys().next().value!);
  };

  /** A text to one socket; false if it would not take it. */
  const sendTo = (socket: TabSocket, text: string): boolean => {
    try {
      socket.send(text);
      return true;
    } catch {
      return false;
    }
  };
  const wrap = (message: TabMessage): string => JSON.stringify({ type: 'custom', event: EVENT, data: message });

  const stateAnswer = (c: Conversation, since: number): StateAnswer => ({ state: conversations.state(c), entries: c.session.since(since), conversation: c.id, conversations: conversations.list() });
  const sinceOf = (url: URL): number => {
    const n = Number(url.searchParams.get('since') ?? 0);
    return Number.isFinite(n) && n >= 0 ? n : 0;
  };
  const listAnswer = (made?: Conversation): ConversationsAnswer => ({ conversations: conversations.list(), ...(made ? { conversation: made.id } : {}) });

  /** A route of one conversation's: handed it, by `?conversation=` -- none, the first -- its session's disk read done. */
  type Route = (req: IncomingMessage, res: ServerResponse, url: URL, c: Conversation) => Promise<void>;
  /** The terminals, or 404: a server without them (a test's). */
  const terminalsHere = (): Terminals => {
    if (!options.terminals) throw new Refused(404, 'no terminals here');
    return options.terminals;
  };
  const routes: Record<string, Route> = {
    'GET state': async (_req, res, url, c) => sendJson(res, 200, stateAnswer(c, sinceOf(url))),
    // The conversation's terminal (Docs/terminal.md): its state and the screen kept, to draw again after a reload.
    'GET terminal': async (_req, res, _url, c) => {
      const terminals = terminalsHere();
      sendJson(res, 200, { state: conversations.state(c), screen: terminals.screen(c.id), end: terminals.end(c.id) } satisfies TerminalAnswer);
    },
    // Continue in the terminal: a program started -- a page's alone, with the secret its hello was told (D1, D4).
    'POST terminal/open': async (req, res, _url, c) => {
      const terminals = terminalsHere();
      const body = await readJson(req);
      if (req.headers.origin === undefined || !secretMatches(typeof body.secret === 'string' ? body.secret : undefined, pageSecret)) {
        throw new Refused(403, 'Continue in terminal is the person\'s: from the studio\'s own page (Claude\'s column), never a call from elsewhere');
      }
      if (body.where !== 'column' && body.where !== 'own') bad('where is column or own');
      const out = await terminals.open(c, { where: body.where as 'column' | 'own', cols: body.cols as number | undefined, rows: body.rows as number | undefined });
      sendJson(res, 200, { state: conversations.state(c), screen: terminals.screen(c.id), end: terminals.end(c.id), ...out } satisfies TerminalAnswer);
    },
    // Back to the column: the CLI ended, its turns read back (D10); `force` past Terminal.app's session written just now (D5).
    'POST terminal/close': async (req, res, _url, c) => {
      const terminals = terminalsHere();
      const body = await readJson(req);
      // Ending a program the person runs is theirs too: the page's secret and Origin, as open.
      if (req.headers.origin === undefined || !secretMatches(typeof body.secret === 'string' ? body.secret : undefined, pageSecret)) {
        throw new Refused(403, 'Back to the column is the person\'s: from the studio\'s own page (Claude\'s column), never a call from elsewhere');
      }
      if (body.force !== undefined && typeof body.force !== 'boolean') bad('force is not true or false');
      await terminals.close(c, body.force === true);
      sendJson(res, 200, { state: conversations.state(c) } satisfies TerminalAnswer);
    },
    'GET input': async (_req, res, url, c) => {
      const id = url.searchParams.get('id') ?? '';
      const input = c.session.input(id);
      if (input === undefined) throw new Refused(404, 'not kept');
      sendJson(res, 200, { id, input });
    },
    'POST attach': async (req, res, url, c) => {
      const body = await readJson(req);
      if (body.retry !== undefined && typeof body.retry !== 'boolean') bad('retry is not true or false');
      await c.session.attach(body.retry === true);
      sendJson(res, 200, stateAnswer(c, sinceOf(url)));
    },
    'POST turn': async (req, res, _url, c) => {
      const request = checkTurn(await readJson(req, TURN_LIMIT));
      // Its first prompt names it, before it goes: the turn says whose it is. Not while one runs -- that Send is refused.
      if (!c.session.running()) conversations.named(c, request.prompt);
      sendJson(res, 200, await c.session.turn(request));
    },
    'POST stop': async (req, res, _url, c) => {
      await readJson(req);
      await c.session.stop();
      sendJson(res, 200, { state: conversations.state(c) });
    },
    'POST clear': async (req, res, _url, c) => {
      await readJson(req);
      await conversations.clear(c.id);
      sendJson(res, 200, { state: conversations.state(conversations.get(c.id)) });
    },
    'POST answer': async (req, res, _url, c) => {
      c.session.answer(checkAnswer(await readJson(req)));
      sendJson(res, 200, { state: conversations.state(c) });
    },
    'POST settings': async (req, res, _url, c) => {
      // fixBoot is the project's (the conversations' index), whichever conversation the call names; the rest the conversation's.
      const { fixBoot, outside, secret, ...own } = checkSettings(await readJson(req));
      // The permission level and the outside clients' are the person's: this server's own Origin, which a `curl` lacks, and
      // the secret a page's hello was told, which no HTTP answer carries -- so no curl, HTTP tool of Claude's or outside
      // client sets them (a local program posing as a page on the HMR socket can: `pageSecret`). Nothing changed else.
      if ((outside !== undefined || own.level !== undefined) && (req.headers.origin === undefined || !secretMatches(secret, pageSecret))) {
        throw new Refused(403, 'the permission level and what outside clients may do are the person\'s: changed in the studio (Claude\'s card, Config ▸ Claude ▸ Settings), never by a call from elsewhere');
      }
      await c.session.settings(own);
      if (fixBoot !== undefined) conversations.setFixBoot(fixBoot);
      if (outside !== undefined) conversations.setOutside(outside);
      sendJson(res, 200, { state: conversations.state(c) });
    },
    // `/usage` (Docs/agent.md §2, "Usage"): the CLI asked afresh where it is up; never a turn.
    'POST usage': async (req, res, _url, c) => {
      await readJson(req);
      // A session an older bundle made, kept across a restart in-process, has none: its next Clear makes it anew.
      if (typeof c.session.usage !== 'function') throw new Refused(503, OLD_SESSION);
      sendJson(res, 200, await c.session.usage());
    },
    // `/btw` (§2, "/btw"): a side question, answered by a fork as a `btw` entry; a turn running goes on.
    'POST btw': async (req, res, _url, c) => {
      const body = await readJson(req);
      if (typeof c.session.btw !== 'function') throw new Refused(503, OLD_SESSION);
      sendJson(res, 200, await c.session.btw(str(body.question, 'question', 4000)));
    },
    'POST rewind': async (req, res, _url, c) => {
      const body = await readJson(req);
      const turn = str(body.turn, 'turn', 100);
      if (typeof body.dryRun !== 'boolean') bad('dryRun is not true or false');
      // What the preview listed from the turn's snapshot: the only files put back from it, or removed.
      const paths = (value: unknown, name: string): string[] | undefined => {
        if (value === undefined) return undefined;
        if (!Array.isArray(value) || value.length > 10_000 || !value.every((p) => typeof p === 'string' && p.length <= 4096)) bad(`${name} is not a list of paths`);
        return value as string[];
      };
      const changed = paths(body.changed, 'changed');
      const made = paths(body.made, 'made');
      sendJson(res, 200, await c.session.rewind({ turn, dryRun: body.dryRun as boolean, ...(changed ? { changed } : {}), ...(made ? { made } : {}) }));
    },
  };

  /** The routes of no one conversation: the held reload, the list, the relay's answer. */
  type Plain = (req: IncomingMessage, res: ServerResponse, url: URL) => Promise<void>;
  /** The skills' routes need the root: a server without one has none. */
  const skillsAt = (): { root: string; plugin?: string } => {
    if (!options.skills) throw new Refused(404, 'no skills here: the server was not told the project root');
    return options.skills;
  };
  /** The skills every open conversation's `init` named, together; null when none has said. */
  const loadedSkills = (): string[] | null => {
    let heard: string[] | null = null;
    for (const info of conversations.list()) {
      const named = conversations.state(conversations.get(info.id)).skills;
      if (named) heard = [...(heard ?? []), ...named];
    }
    return heard;
  };
  const plain: Record<string, Plain> = {
    // A terminal run's hook (Docs/terminal.md D7): its token, then the editor's facts in words, as text to print.
    'GET terminal/context': async (req, res) => {
      const terminal = options.terminal;
      if (!terminal) throw new Refused(404, 'no terminal runs here');
      const given = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization ?? '')?.[1];
      const conversation = given === undefined ? null : terminal.find(given);
      if (conversation === null) throw new Refused(401, 'not a terminal run\'s token: it ended, or the dev server restarted');
      // The hook runs as a prompt is sent: a turn there has begun (Docs/ai-panel.md §8).
      terminal.turn?.(conversation, 'prompt');
      const text = await terminal.context(conversation);
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(text);
    },
    // A terminal run's other hooks (Docs/ai-panel.md §8): a turn's end, its failure, the CLI asking -- the tab's and the AI button's marks.
    'POST terminal/turn': async (req, res) => {
      const terminal = options.terminal;
      if (!terminal?.turn) throw new Refused(404, 'no terminal runs here');
      const given = /^Bearer\s+(\S+)$/i.exec(req.headers.authorization ?? '')?.[1];
      const conversation = given === undefined ? null : terminal.find(given);
      if (conversation === null) throw new Refused(401, 'not a terminal run\'s token: it ended, or the dev server restarted');
      const body = await readJson(req);
      const event = turnEvent(body.event, body.type);
      if (event !== null) terminal.turn(conversation, event);
      sendJson(res, 200, { told: event });
    },
    'GET skills': async (_req, res) => {
      const { root, plugin } = skillsAt();
      sendJson(res, 200, await listSkills(root, loadedSkills(), plugin));
    },
    'POST skills': async (req, res) => {
      const { root, plugin } = skillsAt();
      const body = await readJson(req);
      const row = await makeSkill(root, body.name, plugin);
      // Each conversation's query up reads the skills again: the SDK's reloadSkills, where it has it.
      const told = await Promise.all(conversations.list().map((info) => conversations.get(info.id).session.reloadSkills()));
      sendJson(res, 200, { row, note: told.some(Boolean) ? LOADED_NOW : NEXT_CONVERSATION });
    },
    'POST reload': async (req, res) => {
      await readJson(req);
      sendJson(res, 200, { reloaded: await conversations.reload() });
    },
    'GET conversations': async (_req, res) => sendJson(res, 200, listAnswer()),
    'POST conversations/new': async (req, res) => {
      const body = await readJson(req);
      sendJson(res, 200, listAnswer(await conversations.create(strOrNull(body.from, 'from', 100))));
    },
    'POST conversations/close': async (req, res) => {
      const body = await readJson(req);
      await conversations.close(str(body.id, 'id', 100));
      sendJson(res, 200, listAnswer());
    },
    'POST conversations/rename': async (req, res) => {
      const body = await readJson(req);
      conversations.rename(str(body.id, 'id', 100), str(body.title, 'title', 500));
      sendJson(res, 200, listAnswer());
    },
    'POST conversations/order': async (req, res) => {
      const body = await readJson(req);
      conversations.order(list(body.ids, 'ids', 16, (v) => str(v, 'an id', 100)));
      sendJson(res, 200, listAnswer());
    },
    'POST mcp/answer': async (req, res) => {
      const { id, answer } = checkMcpAnswer(await readJson(req, ANSWER_LIMIT));
      const call = waiting.get(id);
      if (!call) {
        // Its time ran out, and it was done all the same (begun before `expires`): the transcript shows what it did.
        const gone = lateCalls.get(id);
        if (!gone) throw new Refused(409, 'this call is not waiting: it was answered, or its time ran out');
        lateCalls.delete(id);
        gone.late(answer, gone.tab);
        sendJson(res, 200, { ok: true, late: true });
        return;
      }
      call.settle(answer);
      sendJson(res, 200, { ok: true });
    },
  };

  return {
    async handle(req, res) {
      const url = new URL(req.url ?? '/', 'http://localhost');
      if (!url.pathname.startsWith(PREFIX)) return false;
      const route = url.pathname.slice(PREFIX.length);
      const method = req.method === 'HEAD' ? 'GET' : (req.method ?? 'GET');
      try {
        guardHost(req, hosts());
        if (mutating(req)) guardWrite(req, port(), hosts());
        else if (!mayWrite(req, hosts())) {
          // Another machine, or another page: the transcript is not theirs to read.
          sendJson(res, 200, ELSEWHERE);
          return true;
        }
        const key = `${method} ${route}`;
        const handler = routes[key];
        const other = plain[key];
        if (!handler && !other) throw new Refused(404, `no ${method} ${route} here`);
        await conversations.ready;
        if (other) await other(req, res, url);
        else {
          const c = conversations.get(url.searchParams.get('conversation'));
          await c.session.ready;
          await handler!(req, res, url, c);
        }
      } catch (err) {
        if (res.headersSent || res.destroyed) {
          if (!(err instanceof Refused)) warn(`[agent] ${(err as Error).message}`);
          res.destroy();
        } else if (err instanceof Refused) {
          await drain(req);
          sendJson(res, err.status, err.body);
        } else {
          warn(`[agent] ${(err as Error).stack ?? (err as Error).message}`);
          sendJson(res, 500, { refused: (err as Error).message });
        }
      }
      return true;
    },

    connection(socket, req) {
      if (!mayWrite(req, hosts())) return;
      tabs.add(socket);
      if (req.headers.origin !== undefined) pages.add(socket);
      socket.on('close', () => {
        tabs.delete(socket);
        multi.delete(socket);
        // Its tab is another of its sockets now -- a page that said the same id -- or between sockets, a reload, until it says hello again.
        for (const sockets of named.values()) {
          const at = sockets.indexOf(socket);
          if (at >= 0) sockets.splice(at, 1);
        }
        for (const call of waiting.values()) if (call.sentOn === socket) resend(call);
        trim();
      });
    },

    push(message) {
      if (tabs.size === 0) return;
      const text = wrap(message);
      // A page from before conversations knows one: the first's messages alone, never the list.
      const first = (): string | undefined => conversations.list()[0]?.id;
      const all = 'conversations' in message || (message.conversation !== undefined && message.conversation !== first());
      for (const socket of tabs) {
        if (all && !multi.has(socket)) continue;
        if (!sendTo(socket, text)) tabs.delete(socket);
      }
    },

    hello(socket, data) {
      if (!tabs.has(socket)) return;
      const tab = (data as { tab?: unknown } | null)?.tab;
      if (typeof tab !== 'string' || tab === '' || tab.length > 100) return;
      // The project's own tools, as this tab's src/tools/ declares them: kept by tab, the bad said once in the log.
      const { decls, bad } = checkDecls((data as { tools?: unknown }).tools);
      const said = JSON.stringify(bad);
      if (bad.length > 0 && declared.get(tab)?.bad !== said) warn(`[agent] the project's MCP tools (src/tools/): ${bad.join('; ')}`);
      declared.set(tab, { decls, bad: said });
      if ((data as { multi?: unknown }).multi === true) multi.add(socket);
      // The page's secret, to this socket alone, a page's: what a change of the level or the outside clients' carries.
      if (pages.has(socket)) sendTo(socket, wrap({ page: { secret: pageSecret } }));
      // A socket is one tab: a page that said another id before (a duplicate, made a new one) is that one's no more.
      for (const sockets of named.values()) {
        const at = sockets.indexOf(socket);
        if (at >= 0) sockets.splice(at, 1);
      }
      const had = named.get(tab) ?? [];
      // The latest to say hello last: the oldest ids are the first let go.
      named.delete(tab);
      named.set(tab, [...had, socket]);
      trim();
      // A call sent to no socket -- its tab between two, a reload -- sent now, on this one; one on a socket still open stays there.
      for (const call of waiting.values()) {
        if (call.tab !== tab || (call.sentOn !== null && tabs.has(call.sentOn))) continue;
        if (sendTo(socket, call.message)) {
          call.sentOn = socket;
          call.delivered = true;
        }
      }
    },

    terminal(socket, data) {
      const terminals = options.terminals;
      if (!terminals || !tabs.has(socket) || !pages.has(socket)) return;
      const m = data as { conversation?: unknown; data?: unknown; cols?: unknown; rows?: unknown } | null;
      if (typeof m !== 'object' || m === null || typeof m.conversation !== 'string') return;
      if (typeof m.data === 'string') terminals.input(m.conversation, m.data);
      else if (typeof m.cols === 'number' && typeof m.rows === 'number') terminals.resize(m.conversation, m.cols, m.rows);
    },

    projectTools() {
      const tab = [...named].reverse().find(([, sockets]) => sockets.length > 0)?.[0];
      return tab === undefined ? [] : [...(declared.get(tab)?.decls ?? [])];
    },

    relay(asked, call, deadline = relayMs, late) {
      // The turn's tab, if it is known; else the last studio tab to say hello that has a socket open.
      const tab = asked !== null && named.has(asked) ? asked : [...named].reverse().find(([, sockets]) => sockets.length > 0)?.[0];
      if (tab === undefined) return Promise.resolve({ away: 'gone' });
      const id = randomUUID();
      return new Promise<PageAnswer & { tab?: string }>((resolve) => {
        // No answer in time is `timeout`, not `gone`: the tab is there, and the call may yet land -- its answer then
        // said to `late` (the transcript's row), never dropped. The page begins no write past `expires`.
        const timer = setTimeout(() => {
          if (late && waiting.has(id)) keepLate(id, { tab, late });
          settle({ away: 'timeout' });
        }, deadline);
        // A `gone` once the call reached a tab is no proof it was not begun: marked `delivered`, never run again elsewhere.
        const settle = (answer: PageAnswer): void => {
          if (!waiting.delete(id)) return;
          clearTimeout(timer);
          resolve({ ...answer, ...('away' in answer && answer.away === 'gone' && waits.delivered ? { delivered: true } : {}), tab });
        };
        const waits = { tab, message: wrap({ mcp: { id, ...call, expires: Date.now() + deadline } }), sentOn: null as TabSocket | null, delivered: false, settle };
        waiting.set(id, waits);
        resend(waits);
      });
    },
  };
}
