/**
 * Physics in node: Ammo loaded (`@vibe/engine/physics-node`), the physics stage installed on the game's world, the
 * game made as it starts (`populate`), three seconds of ticks run -- the falling crate drops two metres, tumbles and
 * comes to rest on the floor, asleep. A game's own physics test goes the same way: `loadAmmo()`, then
 * `installPhysics(world, { ammo })`, then `world.loop.runTick()`.
 */
import { compilePrefabs, type Entity, installPhysics, Loop, RigidBody, World, WorldTransform } from '@vibe/engine';
import { prefabFilesFromDisk } from '@vibe/engine/node';
import { loadAmmo } from '@vibe/engine/physics-node';
import { suite } from '@vibe/engine/testing';
import { populate } from './populate.ts';
import { registerSystems } from './systems.ts';

const t = suite('game: the crate falls');

compilePrefabs(prefabFilesFromDisk(new URL('../assets/prefabs/', import.meta.url)));
const world = new World({ loop: new Loop({ seed: 1 }) });
registerSystems(world);
installPhysics(world, { ammo: await loadAmmo() });
populate(world);
world.flush();

/** The one entity with a body that moves: ids are the world's to give out. */
let crate = 0 as Entity;
for (let e = 1; e < world.extent; e++) if (world.alive(e as Entity) && world.has(e as Entity, RigidBody)) crate = e as Entity;
t.ok('populate made a crate with a body', crate !== 0);
const from = world.store(WorldTransform).py[crate]!;
for (let i = 0; i < 180; i++) world.loop.runTick();
const y = world.store(WorldTransform).py[crate]!;
t.ok(`it fell from ${from} m and rests on the floor (y ${y.toFixed(3)})`, from === 2 && Math.abs(y) < 0.05);
t.ok('...asleep', world.store(RigidBody).sleeping[crate] === 1);

t.done();
