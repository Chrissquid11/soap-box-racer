/**
 * The game, built in node: the prefab files compiled from disk, the systems registered, the first
 * entities made, a second of ticks run -- the crate turns, and the spin allocates nothing; its axis, an
 * enum, set to x turns it about x. A game's own tests go beside what they test, `*.test.ts`; `npm test`
 * finds them, then runs the engine's checks.
 */
import { compilePrefabs, type Entity, Loop, Transform, World } from '@vibe/engine';
import { prefabFilesFromDisk } from '@vibe/engine/node';
import { suite } from '@vibe/engine/testing';
import { Axis, Spin } from './components.ts';
import { populate } from './populate.ts';
import { registerSystems } from './systems.ts';

const t = suite('game: the crate spins');

compilePrefabs(prefabFilesFromDisk(new URL('../assets/prefabs/', import.meta.url)));
const world = new World({ loop: new Loop({ seed: 1 }) });
registerSystems(world);
populate(world);
world.flush();

/** The one entity with a Spin: ids are the world's to give out. */
let crate = 0 as Entity;
for (let e = 1; e < world.extent; e++) if (world.alive(e as Entity) && world.has(e as Entity, Spin)) crate = e as Entity;
t.ok('populate made a crate', crate !== 0);
t.ok('the crate is made with a speed', world.store(Spin).speed[crate]! > 0);
for (let i = 0; i < 60; i++) world.loop.runTick();
const at = world.store(Transform);
t.ok('a second on, it has turned about y', Math.abs(at.qy[crate]!) > 0.1);
t.ok('...and is still a unit quaternion', Math.abs(at.qy[crate]! ** 2 + at.qw[crate]! ** 2 - 1) < 1e-5);
t.noAlloc('the spin allocates nothing', () => world.loop.runTick());

// Its axis an enum: set to x (as the inspector's drop-down or a file's "x" would), it turns about x alone.
world.store(Spin).axis[crate] = Axis.x;
at.qx[crate] = 0;
at.qy[crate] = 0;
at.qz[crate] = 0;
at.qw[crate] = 1;
for (let i = 0; i < 60; i++) world.loop.runTick();
t.ok('about x: a turn about x, none about y or z', Math.abs(at.qx[crate]!) > 0.1 && at.qy[crate] === 0 && at.qz[crate] === 0);

t.done();
