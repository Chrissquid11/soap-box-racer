# @vibe/pipeline

Node's side of a Squidwright game: the `vibe` CLI, `vibe()` for a project's `vite.config.ts`, the
asset pipeline and its dev-server API, Claude Code's host for the editor, the checks `vibe test`
runs, `vibe pack`, `vibe new` and its template, and Claude's files (`claude/`: the `vibe` and
`gladius` skills, the critic). `vite` and `typescript` are peers: the project's own.

- `@vibe/pipeline` -- `vibe()` and what a project's own route is written with (`ToolRoute`, `checkPath`)
- `/kinds`, `/paths`, `/recipes`, `/parts`, `/look-words`, `/prefab-names`, `/assets-types`,
  `/agent-types`, `/studio-types` -- pure modules and contracts the editor imports in the browser
- `src/studio/` -- the studio's routes under `/__studio/` and its pushes: the log, the tasks, tsc's
  problems, the checks, the build's sizes and preview, the ffmpeg download (`Docs/studio.md`)
- `src/studio/tsserver.ts`, `files.ts`, `search.ts` -- the Code card's TypeScript bridge (the project's
  `tsc --lsp`, TypeScript 7), its file routes and its search
- `src/studio/git.ts` -- the Git card's routes under `/__studio/git/`: status, log, branches, diff, commit,
  checkout, push and pull, the last two always asking first
- the `vibe` bin -- `dev`, `build`, `preview`, `typecheck`, `test`, `assets`, `packs`, `export`, `sync`, `pack`, `new`

Imported by a project's `vite.config.ts` and run by its scripts. The docs are the squidwright
repository's `Docs/` (`packages.md`, `assets.md`, `agent.md`, `studio.md`).
