---
name: vibe
description: The engine's rules for writing or changing a Squidwright game -- its systems, components, prefabs, assets, UI, debug keys and audio. Load it before changing anything under src/game/, src/ui/ or src/assets/ of a project on @vibe/engine.
---

A Squidwright game is a project on three packages: **`@vibe/engine`** (the ECS, the loop, the view, the
asset runtime, `boot()`, the canvas UI), **`@vibe/editor`** (the editor -- studio mode, `?studio` -- debug builds only) and
**`@vibe/pipeline`** (the `vibe` CLI: `vibe dev`, `vibe test`, `vibe assets`, `vibe export`, the asset
pipeline, the editor's Claude). The project owns `src/main.ts` (its hooks into `boot()`), `src/game/`
(components, prefab tokens, systems), `src/ui/` (its HUD and menus), `src/assets/` (what ships) and
`AssetsSource/` (the originals). These are the rules that are easy to break; `vibe test` checks many of them and names the file, the line and the fix.

## Assets

- **No manifest, no string-built URLs.** A file in `src/assets/<kind>/` is its key:
  `models/props/crate.glb` is `Assets.instance('props/crate')`, `prefabs/crates/big.prefab` is
  `prefab('crates/big')`, `scenes/forest/camp.scene` is `scene('forest/camp')`, `materials/props/rust.material`
  (JSON inside: a type, colours, numbers, texture maps by key -- the engine skill's `render` page) is
  `'props/rust'` in a `Render.material`. `Assets` and `Audio` come from `@vibe/engine/assets`. Never build a URL from a path:
  every URL comes from a glob Vite rewrote.
- **A key in code; `{ "uid", "key" }` in files.** Every asset has a uid the pipeline stamps (a data
  file's `"uid"`, a source's record, a loose file's `.uid` beside it), and a prefab, scene, level or
  material file names an asset by both: `"model": { "uid": "uid://…", "key": "props/crate" }`. Write
  the key alone (`"props/crate"`) -- the pipeline adds the uid when it next passes; keep a uid a file
  has, never make one up. A file moved or renamed needs no edit of a file naming it; code naming its key
  changes first: its uid still finds it -- moved in the editor, the Finder or git -- and the pipeline
  rewrites the keys in files, while the editor refuses a move of an asset code names.
- **The generated files are `vibe assets`'s**, written on `vibe dev`, `vibe typecheck`, `vibe build` and
  install, and gitignored: `src/assets/keys.d.ts`, the globs beside it, `src/assets/bundle.ts` (the
  project's globs handed to the engine, `main.ts`'s first import) and `src/game/live.ts` (the swap
  boundary). Never edit one; never import a glob file anywhere else.
- **A key is the path lowercased; lookups take any case**: `models/props/Big Crate.glb` is
  `props/big crate`. Never two names that differ only by case (refused by the key generator and the
  editor); a case-only rename goes through the editor or `git mv`.
- **Load first, then build.** `Assets.preload()` finishes before the game is made (`boot()` does it);
  gameplay code is synchronous. Content for later goes in `packs/`, mounted between rounds.
- **Every original lives in `AssetsSource/`** (art, fonts, audio masters), never in `src/` or `public/`
  -- but a file that ships exactly as delivered (a `.woff2`, an icon `.svg`) may go straight into
  `src/assets/`. Every source ships through the pipeline -- the dev server exports a saved source by
  itself; `vibe export` otherwise -- with its options in `<stem>.export.json` and a folder's defaults
  in its `export.json`. Out of the build is `"include": false` in its record, or a loose file named
  with a leading `_`.
- **A model is a Gladius script** under `AssetsSource/models/`: the `gladius` skill.
- **Binary files go through Git LFS** (`.gitattributes`). A fresh clone needs `git lfs install`.

## The page: one canvas, its UI, its sound

- **One canvas.** The HUD and menus are Pixi widgets from `@vibe/engine/ui`, drawn into three's own
  WebGL2 context. Every piece of Pixi work -- draw, layout, a text change -- runs inside
  `CanvasUi.onPixiSide`. Never `pixi.destroy()`. Never shrink the canvas.
- **UI sizes are units**: `n * units.u` (HUD) or `n * units.m` (menus), never bare pixels. Colours and
  sizes come from the theme (`COLOUR`, `SIZE_U`, `SIZE_M`, `ALPHA` on `@vibe/engine/ui`), never a
  literal in a widget.
- **The game asks the UI first** about every pointer event (`Game.pointerClaim`).
- **Audio goes through `Audio`** (`@vibe/engine/assets`), never `new Audio()`. Whether the game makes
  sound is decided in one place, `updateMute()` in the engine's `boot()`.

## Debug keys and debug code

- **Every debug key and every debug button goes through MrDebug** (`@vibe/engine/debug`): register it once with
  `MrDebug.add({ name, key?, help, when?, run })` and it gets its key and its button in the debug panel together, under
  one switch (`MrDebug.enabled`). A key is a `KeyboardEvent.code` or a chord -- `'Mod+KeyZ'`, `'Shift+KeyD'`, `Mod` being
  Cmd on a Mac and Ctrl elsewhere -- or a list of them; a chord matches only its exact modifiers, and one nobody has
  stays the browser's. A key MrDebug takes goes nowhere else; with debug off it falls through to the game (`P` is the
  pause key there, and on any page but studio mode's, `?studio`, where it pauses a playtest). Never
  `addEventListener('keydown')` for a debug key, never a `DEBUG && e.code === ...` check, never a lil-gui button of your
  own. A field's own keys are actions with `field: '<name>'` on an element marked `data-keys-field="<name>"`, and one
  taken while typing too, for a key no field may have (F5), is marked `anywhere: true`; a key held is an action with
  `hold: true` (`run`, `release`, `MrDebug.held(code)`), never a `keyup` of your own. A game's debug key with no `when`
  never takes an editor key (`?` lists them): the editor's gives way, with a notice, and the `keys` check fails on it.
  The one exception is the Debugger page (`@vibe/editor/debugger`: the Debugger window in the app, `/__studio/debugger`
  in a browser): no game page, it loads no MrDebug, and its host page takes its keys and hands them to it (`page.key()`).
- **Debug code is gated by a literal, in its own module**: `const DEBUG = DEBUG_BUILD && MrDebug.on;`
  at the top of each module that has debug code, then `if (DEBUG) { ... }`. `DEBUG_BUILD` is a constant
  the build writes into every module; a `DEBUG` exported and imported would ship its branch in a
  release. Never import a `DEBUG` flag, and never use `DEBUG_BUILD` in code a node test imports. Build
  switches are `--mode` words (`vibe build --debug`), not env vars.
  A module of the project with a top-level side effect (storage written, a fetch, an `AudioContext`, a
  listener) checks `probing()` (`@vibe/engine/boot`) first: studio mode's probe page evaluates a changed
  module, and the graph under it, for real in a hidden same-origin frame before a reload goes, and only `boot()` checks for itself.
- **The editor is `@vibe/editor`, and the game never refers to it**: no import, not even
  `import type`, but the one `DEBUG`-gated `import('@vibe/editor')` (and its panel's) that
  `src/main.ts` hands `boot()`. A release build drops that import and the whole editor with it; the
  build fails, naming each file, if any of the editor reaches a release. The editor may import the
  game; never the reverse.

## Gameplay: the ECS

- **Gameplay is ECS systems**: components in `src/game/components.ts`, one system a file in
  `src/game/systems/`, registered in order in `src/game/systems.ts`. A system is one
  `world.system({ name, rate, read, write, with, without, after, update })`: a rate from the closed
  list, and stores handed over for exactly the components it declared. Slow systems decide; only
  60 Hz systems write `Transform`, and render systems draw it interpolated.
- **One loop shape**: `for (let n = 0; n < count; n++) { const e = members[n]; pos.x[e] += ...; }`.
  `members` is longer than what is due: never `for...of`, never `members.length`.
- **A system allocates nothing**: no `new`, no `{}` or `[]` literal, no closure, no `map`/`filter`/
  `forEach`/spread, no string building, inside `world.system(...)`. Scratch objects and helpers go at
  module level. `// alloc-ok: <reason>` on a line is the way out; `t.noAlloc(name, run)` in a test
  measures it for real.
- **Numbers in a `component` -- an enum, flags, a vector, a colour, a typed ref, an asset's key are numbers too -- a yes
  or no in a `tag`, lists, dicts, text, records in a `dataComponent` (never `parallel`), a handle in an `objectComponent`.**
  Which kind for what, its widget and its file form: the `engine` skill's `fields` page. Every component is defined at module level, before the world is made.
- **"Or" is `any: [A, B]`**: at least one of them. Their data through `optional(A)` and `has(e, A)`.
- **`parallel: true` only on a system that is pure arithmetic over its own members' rows**: numeric
  components, no `cmd`, `rng`, `input`, events, relations or `changed`. It may then run on worker
  threads; those things throw in it even with no workers.
- **Simulation code takes chance and time from the loop**: its seeded `rng` and its `time`/`dt`,
  never `Math.random`, `Date.now()` or `performance.now()`. Render and UI code may use either.
- **A change under `src/game/` swaps into the running game** in the dev server, no reload (through
  `src/game/live.ts`): tokens are redefined in place and the world is rebuilt from a save, so **never
  keep the world, a store, a column or a channel in a module variable** in `src/game/` -- take it from
  the world or the store each call.
- **Physics is a stage of every tick, on by default** (the engine skill's `physics` page): never move a dynamic body
  by its `Transform` every tick -- push it (`Forces`) or set its `velocity`; contacts are events, read the tick after.
- **Never keep a column across ticks** (`const xs = pos.x` at module level): the world may grow at a
  boundary and replace it. Take it from the store each call.

### What exists, and how it changes

- **What a thing is made of is a prefab**: a file `src/assets/prefabs/**/*.prefab` (JSON inside, named so it is told apart from every other JSON file: a `.json` there is no prefab) --
  its entities, their components and numbers, its tree, its links, its `Render` -- and a token for it in
  `src/game/prefabs.ts` (`const Big = prefab('crates/big')`, a node `Big.node('rider')`, both at module
  level, both checked by `keys.d.ts`). Never a `kind()` in game code. Write only what differs from the
  defaults. A file saved recompiles live in studio mode and every instance follows it; the plain
  page sees it after a reload. A field systems set is marked
  `component(..., { runtime: [...] })` and never written in a file (a compile error).
- **What exists changes through commands**: `cmd.instantiate(Prefab)` (the whole tree, its root's id
  at once), `cmd.part(root, Node)` for an entity of it, a bare `cmd.spawn()` for an entity code fills
  itself, `destroy`, `add`, `remove`, `setParent`, `relate`, `unrelate` in a system (`world.instantiate`
  and the rest outside one), applied at the tick boundary. `cmd.init(e, Component)` gives the writable
  store to fill in an entity just made -- on an instance, only a component its file makes it with.
- **More than one target, or data on the link, is a `relation`**: `cmd.relate(a, Likes, b)`, then
  `for (let p = likes.firstOut[e]; p !== 0; p = likes.nextOut[p])`. A link dies with either end.
- **Systems talk through events, not shared flags**: `const hits = world.events(Hit)` where the
  system is registered; `hits.emit()` to write, `for (let i = hits.begin(ctx); i < hits.end; i++)` to
  read. Read the tick after, by every reader, once. A reader below 60 Hz needs `stagger: false`.
- **Added is `onJoin`, removed is `onLeave`, changed is `changed: [C]` and `ctx.changed(e, C)`.**
  Never a dirty flag of your own: nobody marks anything.
- **Every entity can be switched off (`Disabled`), hidden (`Hidden`), on a layer (`setLayer`) and
  labelled (`Labels`); every component on an entity can be switched off (`cmd.enable(e, C, false)`).**
  Never a `visible` or `enabled` field of your own.
- **A pool is declared once, on the prefab**: `"pool": { "warm": 16, "max": 64 }` in its file, or
  `pool(P, { warm, max })` at module level when the numbers are the code's; never both. Then the same
  `cmd.instantiate` and `cmd.destroy`: the root's destroy gives it back (`world.pool(P)`'s numbers are read-only), and every ref to it goes
  `NONE`. Never a free list or a `dead` flag of your own; a parked instance is not `alive`.
- **An entity kept across ticks is an `EntityRef`**: `ref(e)` to keep, `deref(r)` each time it is used,
  and check for `NONE` -- the entity may have died. An `Entity` is only good during the call.
- **A saved game is `world.save()` and `game.load(save)`**: plain JSON, matched by component name. An
  object component needs `save` and `load` to be in it; scratch data is `{ transient: true }`.

### Transforms and views

- **`update` sees world transforms from the end of the last tick; `lateUpdate` sees this tick's.**
  Whatever follows something else reads `WorldTransform` in `lateUpdate`.
- **What an entity draws is its `Render`** (model, a part `key#part`, material, tint, shadows; keys as
  references in every file, the key alone as you write it: `"data": { "Render": { "model": "props/crate" } }`), and **the engine's `render`
  system attaches its view**; never `attach` an entity's look by hand -- that is for a tool's own
  object. Only render systems touch a three.js object (`@vibe/engine`). The three scene stays flat; the tree a game edits is the ECS's (`setParent`). A model's materials are
  the asset store's, shared by every instance: a per-entity look is a tint (`Render.tint`) or another
  material file -- never a clone of, or a write into, a shared material in game code.
- **The game draws through its main `Camera` entity** (`Camera { main: true }`; the template's
  `camera/main` prefab): a camera is an entity, moved by its `Transform` like anything else (a 60 Hz
  system), its projection, viewport, clear and layer mask its numbers. Never assign or move
  `Game.camera`: it is the fallback's, drawn through only while no `Camera` is.
- **How it moves is its `Animation`**: `clip` a clip's name among the clips of the model it is drawn
  with (`"data": { "Animation": { "clip": "fly" } }`; a key of kind `Clip`, `internKey('Clip', 'fly')`
  at module level to compare in a system), with `speed`, `fade`, `loop` and `time` (runtime, saved),
  played by the engine's `animate` system (the engine skill's `render` page); a clip played once says so with the
  `AnimationEnded` event. Never a mixer of a game's own.

## A project's own editor tools: the extension points

Anything the editor does through a list, a project adds to the list -- never a change to the editor
for one game. The engine skill's `tools` page has the table and a whole tool to copy; a tool's own page
(`<id>.skill.md` beside it, joining `studio`) says how to use it, in its own words -- never sending the
reader to the engine's docs, which a project does not have.

- **Tools, pages, inspector blocks**: `src/tools/index.ts` exports `tools` (`EditorTool`: a tab or a
  panel, its keys `ToolKey`s with a `when`, its turn facts its instance's `context()`), `pages`
  (`ConfigPage`) and `blocks` (`BlockItem { id, for, order, each?, make }`: a block under a component
  or a kind of entity, between the built-ins -- transform 10, render 20, the generic fields 30 -- or in
  one's place by its id), all from `@vibe/editor`. Debug code: `main.ts` reaches the file only through
  its `DEBUG`-gated `import()`, and the build fails if a release carries any of `src/tools/`
  (`vibe({ tools })` names other folders).
- **A tool's components** go in `src/tools/components.ts`, importing `@vibe/engine` alone, never the
  editor: `boot` awaits it before the world is made (`components`, behind `DEBUG_BUILD`), and the game's
  worker imports it too, so the page and the worker hold one list of components.
- **Data kinds**: `vibe({ kinds: { tilemaps: { dir, type, ext, data: true } } })` in `vite.config.ts`
  -- a folder under `src/assets/`, its key union in `keys.d.ts`, its generated
  `src/assets/<name>-globs.ts`, `Assets.data('tilemaps', key)` and `Assets.dataKeys('tilemaps')`, listed
  in the Assets panel.
- **Dev-server routes**: `vibe({ routes: [{ name, handler }] })` answers `/__tools/<name>/` through the
  pipeline's guards (`ToolRoute`; a path written checked with `checkPath`, written with `writeAtomic`,
  all from `@vibe/pipeline`); `ctx.push(message)` reaches the page, and the editor's
  `assetApi.tool(name).call(path, body)` calls it.
- **MCP tools of the project's own**: `src/tools/index.ts` exports `mcpTools` (`ProjectMcpTool` from
  `@vibe/editor`: `name` in lowercase words, `description`, `input` as JSON Schema -- no zod --
  `annotations` `{ readOnly?, destructive? }` and `run({ world, selection }, args)` answering
  `{ words, json?, step? }`, `step` the label of the one step its edits make; throw to refuse). The studio
  serves it as `project_<name>`; the tile tool's `tiles_paint` (`tile-tool/mcp.ts`) is the shape to copy.
- **Every action of a tool comes with its MCP tool** (`mcpTools`, each covered by the tool's `<name>.skill.md`):
  `button(mcp, …)`, `control(mcp, …)`, `MenuItem.mcp`, `ToolKey.mcp` name it (`'project_tiles_paint'`), or
  `'ui'` (the editor's view alone), or `projectNone('<why>')` while it is still to write; a raw `el('button')` or
  `MrDebug.add` in `src/tools/` needs `// mcp: …` (`npm test`'s `mcp` and `skills` checks).

## The studio's tools (Claude in a project)

The dev server hosts Claude Code for the editor's prompt and serves the studio as MCP tools
(`mcp__studio__*`; the `studio` skill, a page an editor). In a turn:

- **Read first**: `studio_state` (what is open, the scene, the selection, the playtest, the problems, the
  jobs) and `scene_query` / `scene_entity` -- the person edits and undoes between your calls.
- **Act with the tools, not around them**: entities with `scene_set`, `scene_create`, `scene_destroy` …
  (several in one `batch`: one step `Z` undoes); files under `src/assets/`, `AssetsSource/` and `packs/`
  with the asset tools (`asset_new`, `asset_move`, `asset_delete` …), never `mv`, `rm` or `cp`; models with
  the `model_*` tools; tests, builds, TypeScript and git with `tests_run`, `build_run`, `ts_*`, `git_*`.
- **Never `curl` the dev server's routes** (`/__assets`, `/__studio`, `/__agent`, `/__mcp`), and never edit
  a scene file the editor has open: change it with the scene tools, then `scene_save`.
- **Look** with `view_shot` after a change that shows; long work is a job (`job_wait`).
- Code and docs are still `Read`, `Grep`, `Edit` and `Write`. Most tools wait behind the tool search; the
  project's own are `project_<name>`.
- Outside the panel, a terminal Claude Code can use the same tools: `npx vibe mcp` prints the line to add
  them (read-only unless the person allows more in Config ▸ Claude ▸ Settings, "Outside clients").

## Checking a change

- In a studio turn `problems_list` (tsc, the checks) and `tests_run`, not the shell, then `view_shot`; else
  `npm run typecheck` after any edit: strict, `noUnusedLocals`/`noUnusedParameters` on -- a leftover fails it.
- `npm test` (`vibe test`): every `*.test.ts` under `src/`, run by node directly, then the checks over
  the project (the ECS rules, the debug keys' routes, the theme rule, the case of names), each finding
  with its fix. A test is `src/<thing>.test.ts` using `suite()` from `@vibe/engine/testing`.
- Imports carry `.ts` extensions so node can resolve them, and node only strips types: parameter
  properties and enums are compile errors -- write plain fields.
- Keep anything a test imports free of `import.meta.glob`, three's renderer and the DOM.

## How do I…

The how is two skills from the installed packages, a page per engine system and per editor: load one with
the Skill tool, then read the one page its index names for the task -- not `ls` or `grep` of `.claude/skills/`:

- **`engine`**, making the game: `game` (the project's shape, `main.ts`, the scripts, the checks -- first, in a
  project new to you), `ecs` (components, systems, events, relations, saves, the swap), `fields` (which kind for
  what: enums, flags, refs, keys, sliders; a data component's lists, dicts, records), `loop` (rates, input, `rng`, time), `prefabs`
  (files, nesting, overrides, pools), `render` (`Render`, materials, tint, `Animation`), `camera`, `physics` (bodies, colliders, forces, `physics.json`), `assets` (keys,
  uids, packs, exports and their options), `ui`, `audio`, `input`, `debug`, `testing`, `tools` (a project's own editor tools).
- **`studio`**, driving the editors through the MCP tools: `studio` (the loop: read, act, `Z`), `scene`,
  `assets`, `model`, `play`, `code`, `config`, and a page for each tool of the project's own.
- **Model with Gladius**: the `gladius` skill; the Model tab, the studio skill's `model` page.
- The packages' code is always there to read: `node_modules/@vibe/engine/src/`, `@vibe/editor/src/`, `@vibe/pipeline/src/`.
