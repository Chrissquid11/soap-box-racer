---
name: gladius
description: Model or change a 3D model of this project with Gladius -- a Lua script under AssetsSource/models/ is the model, its .glb under src/assets/models/ the dev server's build of it. Use whenever asked to create, change, fix or delete part of a model, or when a turn comes from the editor's Model tab with canvases drawn over it. Named `gladius`, not `model`, because `/model` is a built-in Claude Code command.
---

Model with Gladius by editing a **Lua script**, never the GLB. In this project the script is
`AssetsSource/models/<folder>/<name>.lua`; the dev server exports it to
`src/assets/models/<folder>/<name>.glb` by itself (the asset pipeline's `lua` recipe: the `engine` skill's
`assets` page), and the editor's Model tab (the `studio` skill's `model` page) shows it. Units are metres and degrees, Y up,
right-handed; Lua indices are 1-based.

## The loop

1. **Get the signatures.** Read **`api.md`** beside this file: a working reference pinned to
   Gladius 0.8.0, distilled from `gladius_api`. Do not guess signatures -- an unknown table field is
   an **error**, not ignored. Call `gladius_api` (the `gladius` MCP) when `api.md` does not cover
   what you need, when a signature in it is rejected, or when `gladius --version` is not 0.8.0.
2. **Find the script.** A change acts on the existing `.lua` that makes the model -- the turn names
   it (`Model tab: AssetsSource/models/props/crate.lua`). Read it as it is now: the person, or
   another conversation, may have changed it since you last did. Start a new script only when there
   is nothing to change.
3. **Query before you write, and before you finish.** `gladius_query` with `source` tries a draft
   and builds nothing to disk; with `path` it checks the script as saved. Add `measure` (e.g.
   `["y=1.2"]`) for "how wide is it there". Read its diagnostics and fix the cause.
4. **Edit the script in place** with Edit or Write. That is all the building there is: the dev
   server holds the shipped export while your turn runs, shows each save in the Model tab as a
   preview build, and exports once when the turn ends. **Never** `gladius_run` over a shipped
   `.glb`, never `npm run export`. To look at a build yourself, `gladius_run` to a path under
   `.cache/` and `gladius_render` it (`gladius_render` only does fixed orthographic presets).
5. **Report** what changed and any diagnostics left, warnings you chose to accept and why. If the
   script does not build when your turn ends, the turn comes back to you with Gladius's errors:
   fix only what they need, and keep the rest of the work.

## Parameters

Every number worth tuning goes in `params{}`, so the Model tab draws it as a control and a person
can play with the model without editing it:

```lua
local p = params{
  height = { default = 1.2, min = 0.5, max = 3, doc = "Body height, metres" },
  slats  = { default = 4, min = 2, max = 8, integer = true, doc = "Slats per side" },
  style  = { default = "plain", choices = { "plain", "banded" } },
  lid    = { default = true, doc = "A lid on top" },
}
```

- `min` **and** `max` on every number: the panel draws a slider only with both.
- `params` may be called **once**: to add one, extend the call that is there.
- The handful worth varying, not every constant. Bounds must be ones that build: an out-of-range
  value is refused (GLD-2001), not clamped.
- The project's own overrides live in the script's record (`<name>.export.json`'s `params`), set
  from the Model tab; leave them be unless asked.

## Parts and names

`emit(mesh, { name = "lid", material = "wood" })` names a part: the name is what the Model tab's
outliner lists, what a person selects, and what a turn names (`Selected: lid`). Keep names stable
across edits -- the tab keeps a selection and hidden parts by name -- and unique.

**Deleting a part** ("remove the code generating lid") means the statements that make it, not only
its `emit`: the mesh built for it, the locals, the parameters only it used, the material only it
used. A part made in a loop is removed from the loop.

## A turn from the Model tab: canvases

A turn may carry **canvases**: drawings over a view of the model, each with its image (the drawing
over the render), its camera, the person's note, and its marks.

- **The note is the request for that canvas** -- read it first. A colour named in the prompt ("the
  red marks") means the marks of that colour.
- **A stroke on the model** marks what to change. **A stroke in empty space** outlines something that
  does not exist yet, drawn where it should go: its shape and size are the specification.
- **Marks arrive raycast onto the mesh**: the world point a mark lands on, its normal, its extent in
  metres and the parts under it. Trust those over anything inferred from the image -- a point in a
  picture is a ray, and its depth cannot be recovered from the camera alone. A mark reported as
  missing genuinely missed; its plane point is a stand-in depth, its ground point (y = 0) exact.
- **Several canvases** from several angles pin down depth between them.
- **Parts hidden** in the views are missing from the images but still in the script: a display
  state, not a request.

Do not turn strokes into a mesh selection: a canvas is an instruction for this edit, not a region
that must survive the rebuild.

## On failure

`ok = false` carries structured diagnostics with codes and lines. Read them and fix the cause; do
not re-run the same script hoping for a different result, and do not delete a check to quiet a
warning.

## Habits

- Prefer component transforms with `feather` over hand-moving vertices; `knife`/`inset_faces` over
  booleans when the volume should not change.
- `weld` then `smooth_normals` before emitting; custom normals do not survive most operations.
- Flat palette colour: `uv_swatch` and a palette texture, no unwrap.
