# Gladius script API — working reference

**Pinned to Gladius 0.8.0** — checked against `gladius_api` of that version; `npm
test` compares this line with `gladius --version` and fails when they differ
(`scripts/agent/gladius-skill.test.ts`). Distilled from the stub (~98 KB) for the
signatures a script needs, carried over from Vibe3D's reference (0.4.0, brought up
to 0.7.2) and checked again: every function named below is in the 0.8.0 stub, and
the ones it added since -- the **SDF family**, the rig's, profile booleans,
`path_arc`, `sample_uvs` -- are in the last section, their stub annotations copied
whole. **New in 0.8.0**: `emit` places a node (`position`, `rotation`, `scale`;
ADR-093) and `cull_hidden` has a fourth method, `cut` (ADR-092), with its
`tolerance`; `check` and `query --checks` know `zfight` (`GLD-4045`). Nothing was
removed or renamed.

**Call `gladius_api` anyway when:** a signature here is rejected, you need an
option not listed, or `gladius --version` is no longer 0.8.0. The stub is
authoritative; this is a convenience. An unknown field in a table argument is an
**error**, not ignored, so a half-remembered option fails the build rather than
being silently dropped. `pivot` is required on rotate, scale and mirror: there is
no default.

Units are **metres, degrees, Y-up right-handed**. Lua indices are **1-based**.

---

## Vectors

```lua
v3(x, y, z) -> Vec3        v2(x, y) -> Vec2        origin() -> Vec3
axis_x() / axis_y() / axis_z() -> Vec3
dot(a, b) -> number        cross(a, b) -> Vec3     length(a) -> number
normalize(a) -> Vec3       lerp(a, b, t) -> Vec3   -- t is NOT clamped
deg(radians) / rad(degrees) -> number
```

## Primitives → Mesh

`anchor` is `"center" | "base" | "bottom" | "top" | "left" | "right" | "back" |
"front" | "min" | "max"`, or a `Vec3` in [-1, 1] over the bounding box.

```lua
box       { size = Vec3|number, anchor? }
sphere    { radius, segments?, rings?, anchor? }
cylinder  { radius, height, segments?, axis?, anchor? }
cone      { radius, height, radius_top?, segments?, axis?, anchor? }
torus     { major_radius, minor_radius, major_segments?, minor_segments?, axis?, anchor? }
capsule   { radius, height, segments?, rings?, axis?, anchor? }
polyhedron{ vertices = Vec3[], faces = integer[][], anchor? }
```

- `capsule.height` is the **cylindrical section only**; total extent is
  `height + 2 * radius`.
- `polyhedron` faces are **1-based** and are *kept* as polygons — a dodecahedron
  stays 12 faces, not 36 triangles.

## Profiles (closed 2D regions, XY plane) → Profile

```lua
rect { w, h, anchor? }          circle { radius, segments? }
ngon { radius, sides, anchor? } rounded_rect { w, h, radius, segments? }
poly { points = Vec2[], holes? = Vec2[][] }   -- outer CCW, holes CW
profile_union / profile_subtract / profile_intersect (a, ...)
offset(p, { distance, join? = "round"|"miter", segments? })
profile_area(p) -> number
```

## Generators → Mesh

```lua
path     { points = Vec3[], closed? }
path_arc { center, radius, start, sweep, normal?, segments? }
extrude(profile, { distance, twist?, scale_end?, segments?, anchor? })  -- along +Y, anchor defaults "base"
revolve(profile, { angle?, axis?, segments? })                          -- about +Y; X is radius
loft({ { p = Profile, at = Vec3, rotation? }, ... }, { closed?, caps? })
sweep(profile, path, { up?, twist?, scale?, caps? })
```

- `loft` sections must have **equal point counts** (GLD-3012).
- `revolve` on a profile crossing the axis is GLD-3011.

## Transforms → Mesh

**`pivot` is required on `rotate`, `scale` and `mirror`.** There is no default.

```lua
translate(m, offset)
rotate   (m, { angle, axis, pivot })
scale    (m, { factor = Vec3|number, pivot })   -- negative repairs winding + warns
mirror   (m, { normal, pivot })                 -- winding always repaired
place    (m, { anchor?, at })                   -- move so anchor lands on `at`
align    (m, { from, to, pivot })
```

## Component transforms — move part of a mesh

Topology is untouched; only positions change. `verts` accepts a VertSet, EdgeSet
or FaceSet. `pivot` also accepts an anchor name, resolved against the
**selection's** bounding box.

`feather` is proportional editing: `feather = 0.4` or
`{ radius, curve? = "smooth"|"linear"|"sharp"|"sphere", metric? = "surface"|"euclidean" }`.
`"surface"` (default) measures along the mesh, so a feather on one arm stays off
the torso; `"euclidean"` crosses gaps and is usually the bug.

```lua
translate_verts(m, { verts, offset, feather? })
rotate_verts   (m, { verts, angle, axis, pivot, feather? })   -- keep under ~30 deg when feathered
scale_verts    (m, { verts, factor, pivot, basis?, feather? })
orient_verts   (m, { verts, to, pivot? })   -- rotate a ring to face `to` — the mitre
relax_verts    (m, { verts, iterations?, strength? })
slide_verts    (m, { verts, direction, amount })   -- edge slide, amount in (0,1)
project_verts  (m, { verts, normal, point? })      -- flatten onto a plane
```

Custom normals do not survive these; re-run `smooth_normals`.

## Lattice — free-form deform

A lattice is a **value**: `move_control` returns a new one, like every mesh op.

```lua
lattice(m, { divisions = Vec3|integer, padding?, bounds?, interpolation? })
move_control (cage, { index = {i,j,k}, offset })     -- index is 1-based
move_controls(cage, { where? = fun(c)->bool, offset = Vec3|fun(c)->Vec3 })
apply_lattice(m, { lattice, verts? })
lattice_info (cage) -> table
```

Fit the cage to the whole mesh and leave the outermost control points alone, so
the deformation is already zero at the boundary. Vertices outside the cage are
clamped to it (GLD-3044 counts them).

## Booleans

```lua
union(a, ...)   subtract(a, ...)   intersect(a, ...)
join(a, ...)    -- concatenate shells WITHOUT CSG
```

`join` keeps each operand's triangulation and is far cheaper, but **you are
asserting the shells do not intersect**. Shared vertex positions are refused
(GLD-4031); genuinely crossing solids come out self-intersecting.

## Selection

```lua
convex_edges(m, { min_angle?, max_angle? })    concave_edges(m, {...})
sharp_edges (m, { angle? = 30, faces? })      -- convex + concave in one pass
edges_in_box(m, { min, max })                  faces_in_box(m, { min, max })
faces_facing(m, { direction, tolerance? })
edges_where(m, function(e) ... end)            -- e: midpoint, direction, length, dihedral
faces_where(m, function(f) ... end)            -- f: center, normal, area
verts_in_box(m, { min, max })
verts_where(m, function(v) ... end)            -- v: position, valence, normal

set_count(s)   set_union(a, ...)   set_subtract(a, ...)
verts_of(m, s)  edges_of(m, s)  faces_of(m, s)
reselect(m, s)  connected(m, s)
grow(m, { selection, steps? })   shrink(m, { selection, steps? })
boundary(m, { faces })           -- the rim of a region
edge_loop(m, { edges, max_turn?, min_angle? })
edge_ring(m, { edges })
selection_bounds(m, s) -> { min, max, center, size }
selection_frame (m, s) -> { center, normal, u, v, extent_u, extent_v }
```

- Predicates must return a **real boolean** (GLD-1007 otherwise).
- Every op returns a *new* mesh, so a set is refused by the next call (GLD-2101).
  `reselect` carries it across ops that did not rebuild topology.
- `selection_frame` is the right question for a ring that is not axis-aligned;
  `selection_bounds` reports world axes and none of them is its width.

## Modifiers

```lua
bevel         (m, { edges, width, segments? })     -- convex edges, 1-2 segments
extrude_faces (m, { faces, distance, direction?, along?, scale?, rotate?, axis? }) -> m, FaceSet
inset_faces   (m, { faces, distance? | distances?, along? }) -> m, FaceSet
knife_profile (m, { profile, direction, up?, faces? }) -> m, EdgeSet, FaceSet
knife         (m, { normal, point, faces?, polygons? }) -> m, EdgeSet
dissolve_edges(m, { edges })                       -- exact inverse of knife
subdivide     (m, { levels?, scheme?, creases? })  -- Catmull-Clark; creases IGNORED
decimate      (m, { target_triangles? | ratio?, preserve_boundary?, symmetry? })
weld          (m, { tolerance? })                  -- default 1e-6
clean         (m, { duplicates?, orphans?, degenerate? })   -- all default ON
smooth_normals(m, { angle? })
merge_faces   (m, { angle?, faces? })              -- recover quads/n-gons
retriangulate (m)
displace      (m, { amount, frequency?, octaves?, lacunarity?, gain?, seed?,
                    along? = "normal"|Axis, points?, feather? })
```

- `extrude_faces` / `inset_faces` return **the moved cap / innermost platform**,
  so a chain needs no re-selection — and positional selectors cannot tell a
  coplanar ring from its platform anyway.
- `inset_faces` `along = "region"` needs a planar region; `"surface"` is the only
  way to inset curved geometry, at the cost of exact volume.
- `weld` **refuses to return a mesh it broke** (GLD-3034). It drops custom
  normals — follow with `smooth_normals` — but since 0.2.2 it keeps the face
  partition, so `merge_faces` afterwards is recovery you no longer need.
- `knife` cuts **polygons**, not triangles (0.2.2, ADR-071): a cut quad comes back
  as two quads, so slicing a box twice gives 28 triangles rather than 52 and
  `retriangulate` afterwards is a check rather than a step. It is also
  mirror-equivariant — both halves of a mirrored figure split identically — which
  the old triangle cut was not. Three faces opt themselves out and need nothing
  from you: **non-planar** ones, ones fanned from a **Steiner point** (a cylinder
  cap), and any loop the plane meets other than exactly twice. `polygons = false`
  forces the old triangle-native cut everywhere; it is for reproducing earlier
  output and is **not** what protects a cylinder.
- `merge_faces` changes no geometry, only the recorded grouping; follow with
  `retriangulate` to actually bank the triangle saving. It only ever **coarsens**,
  starting from the partition the mesh came with, so it is safe to run
  speculatively and a no-op on the parts that never lost one.
- `clean` is the half of clean-up `weld` does **not** do: weld merges coincident
  *vertices*, and a duplicate triangle already shares its vertices, so no tolerance
  removes it. They compose one way round — `clean(weld(m))` — because an import
  arrives vertex-split and its doubled faces are invisible to a duplicate test
  until the weld has run.
- `displace` **adds no geometry**, so what it can express is bounded by the
  subdivision already there: displacing a 6-face box moves 8 corners and gives a
  wonky box. `subdivide` or `knife` FIRST. `amount` is a **peak in metres**, not a
  scale — the field is normalised whatever the octave count, so changing `octaves`
  does not change how far the surface travels. Too large an `amount` folds
  neighbours through each other and is refused (GLD-3034) rather than handed on.

**The n-gon partition, and what keeps it.** A Gladius mesh is triangles *with a
recorded grouping over them* — which triangles were one quad — and it is recorded,
never derived. As of 0.2.2 that survives almost everything: every primitive and
generator, every transform and vertex op, `knife`, `knife_profile`,
`dissolve_edges`, `bevel`, `extrude_faces`, `inset_faces`, Catmull-Clark
`subdivide`, `weld`, `clean`, every UV op, `paint_faces`, `smooth_normals`, `join`,
`merge` and a boolean result.

Only three things hand back a triangle soup, and all three destroy the grid by
construction rather than by omission: **`decimate`** and **`lod`**, which exist to
remove edges; **`subdivide` in `loop` mode**, which is triangle-native; and
**`import`**, which has no provenance to carry. There `face_count ==
triangle_count`, and `merge_faces` is how you get a grouping back. An op that edits
topology locally keeps the partition of the part it did not touch.

## UV

Meshes have **no** parameterisation until one of these is called.

```lua
unwrap_box(m, { scale? })   unwrap_cylindrical(m, { axis? })   unwrap_spherical(m, { axis? })
unwrap      (m, { seams = EdgeSet, method? = "conformal"|"min_stretch", iterations? })
pack_islands(m, { margin? = 0.01, rotate? = true, texel_density? = "uniform"|"preserve",
                  region? = { min = Vec2, max = Vec2 } })
islands(m) -> { faces, triangles, area_3d, area_uv, bounds, boundary_loops,
                euler, flipped, swatch }[]
uv_swatch (m, { faces?, at = Vec2 })   -- flat-colour palette mapping
has_uvs(m) -> boolean        unmapped_count(m) -> integer
```

- `unwrap` is the real one: seam-cut, then laid out. **Every island must be a
  topological disk**, checked before any solve — a part no seam touches is a closed
  surface (GLD-3053), and a tube wall seamed round both rims but not along it is an
  annulus (GLD-3054; the fix is one lengthwise cut, and the error says where).
  `"min_stretch"` when a conformal island visibly bows — tube walls, anything with
  thickness.
- `pack_islands` **moves nothing in 3D and renumbers nothing**, so normals,
  colours, the face partition and the unmapped flags all survive. It is the one UV
  op that is safe after `paint_faces` and `smooth_normals`.
- `islands` is the UV editor as data, ordered deterministically. `euler` is 1 for a
  disk; anything else did not come from `unwrap`.
- `sharp_edges` (under Selection) is the seam-selection gesture: a UV seam wants an
  inside corner as much as an outside one.

## Queries

```lua
section     (m, { normal, point? }) -> Profile
measure     (m, { normal, point? }) -> { min, max, center, size, area, span, loops } | nil
section_area(m, { normal, point? }) -> number
bbox(m) -> { min, max, center, size }      anchor_of(m, anchor) -> Vec3
triangle_count(m)  face_count(m)  ngon_count(m)  vertex_count(m)
volume(m)  surface_area(m)  is_manifold(m)  component_count(m)
```

`measure` returns **nil** when the plane misses, rather than erroring — sweeping
a plane until nothing comes back is how you find an extremity. `span` is the
longest chord, which is what `size` fails to give for a non-axis-aligned circle.

## Materials and scene

```lua
material({ name, base_color?, metallic?, roughness?, emissive?,
           texture?, normal_texture?, metallic_roughness_texture?,
           occlusion_texture?, emissive_texture?,
           texture_filter? = "nearest"|"linear", texture_wrap? = "clamp"|"repeat",
           compress? = "none"|"auto"|"etc1s"|"uastc",
           alpha_mode? = "opaque"|"mask"|"blend", alpha_cutoff? }) -> string
emit(m, { name, material?, lod?, lod_of?, open?,
          position? = Vec3, rotation? = Vec3, scale? = Vec3|number })   -- placement: 0.8.0
paint_faces(m, { faces = FaceSet, color })   -> Mesh
sample_colors(m, { source })                 -> Mesh
merge({ parts = { { mesh, material? }, ... }, mode? = "compatible"|"all" })
  -> { mesh, material, name }[]
cull_hidden({ meshes = Mesh[], method? = "camera"|"voxel"|"coplanar"|"cut",
              views? = 64, size? = 512, voxel?, tolerance? = 0.001 }) -> Mesh[]
```

**`emit` places a node** (0.8.0, ADR-093): with `position`, `rotation` or `scale`,
`m` is the node's **local** space, modelled about the pivot the node should have,
and the exported glTF node carries the transform -- so in the game the node's
origin is that pivot (a door modelled with its hinge at the origin, emitted
`position = v3(2, 0, 0), rotation = v3(0, 30, 0)`). `rotation` is degrees about
world X, then Y, then Z; `scale` a factor or a `Vec3`, non-zero per axis
(`GLD-3002`), negative allowed; applied scale, rotate, translate. Everything after
`emit` -- render, query, section, checks -- sees the placed, world-space mesh.
**A bound mesh cannot be placed** (glTF ignores a skinned node's transform) --
`GLD-2003`; move it with `translate`/`rotate`, which carry the bind. An LOD level
(`lod_of`) takes its base's placement and refuses its own (`GLD-2003`).

**`cull_hidden`** removes triangles the finished asset does not need, one mesh
back per mesh in, in order. **Four methods, four different questions** (v5; `cut` 0.8.0):
`camera` (default) asks what can be *seen* from outside — cameras on a sphere,
`views` directions at `size` pixels, and resolution changes how much comes off
rather than only how long it takes. `voxel` asks what outside air can *reach*, so
a room a door opens on survives and only sealed geometry goes; `voxel` is the
edge length in metres and is the narrowest gap air can flow through, not a
quality dial — too coarse seals a doorway and takes the room. `coplanar` asks
neither: it removes triangles sitting exactly on another, and takes no knob.
`cut` (0.8.0, ADR-092) asks whether a **later** mesh in the list covers this
ground in the same plane with no vertex shared -- a window drawn in the plane of
its wall, the commonest flicker in generated buildings -- and cuts the covered
ground out of the face beneath along the covering outline, keeping the covering
face whole: **list the wall before the window**. `tolerance` (default 0.001 m) is
how far apart two planes may be and still fight; a window 2 mm proud is left
alone. Faces sharing a plane back to back (butted boxes) are hidden, not
flickering, and are `voxel`'s. `query --checks zfight` (`GLD-4045`) lists the
pairs without cutting; `gladius run --cull-hidden --cull-method cut` does it over
the whole scene. `camera`, `voxel` and `coplanar` leave partial overlaps alone;
`cut` is the one that splits.
**A knob belonging to another method is an error, not an ignored field.** Every mesh occludes every other, so a crate
sealed inside a shell comes back **empty** and cannot be emitted (`GLD-5004`
names it). **Emit the result with `open = true`** — culling opens the surface on
purpose, and a node that does not say so is reported non-manifold. The bind does
not survive: cull first, bind second. `gladius run --cull-hidden` does the same
over the whole scene with no edit to the script; the script form exists because
only it reaches `query` and `render`, so the result can be *looked at* before it
is committed to. It answers "visible from **outside**", so an interior reachable
only through a door goes with everything genuinely sealed — right for props and
distant buildings, wrong for a space something walks into. `size` changes how
much comes off, not just how long it takes.

**`sample_colors`** colours a mesh from an imported file's own vertex colours:
`sample_colors(weld(m), { source = info.colors })`. Sample **before** moving or
reshaping the import (`GLD-3057` warns when it no longer matches), and emit with
a white material, for the multiplication reason below. `info.colors` is nil when
the file carries no COLOR_0.

**`paint_faces` — read this before using it.** glTF **multiplies** COLOR_0 by the
material's base colour and has no replace mode. An unpainted vertex is white, so it
multiplies to exactly the material colour; a painted one is multiplied too, so
green paint on a red material exports near-black. **Give a painted mesh a white
material.** Paint last: every op except `smooth_normals` drops colour, exactly as
it drops custom normals.

`merge` is the scripted form of `gladius run --merge`: collapse parts onto meshes
carrying their colours on the vertices. `"compatible"` loses nothing; `"all"` keeps
only the dominant material's finish and names every loss.

`base_color` is **linear, not sRGB**. Each `emit` produces one named glTF node —
that name is what the viewer's outliner shows and what a user selection refers to,
so name things the way a person would ask for them.

## Params, composition, import

```lua
params(spec) -> table    -- MAY BE CALLED ONCE. Out-of-range values are rejected, not clamped.
rng(seed) -> Rng         -- there is no global random; math.random is removed
noise3(x, y, z, { frequency?, octaves?, lacunarity?, gain?, seed? }) -> number  -- [-1,1]
include(relative_path) -> table    -- the file must `return` a table
import(path, { sha256?, prefix?, materials?, faces? }) -> Mesh, record
```

`params` entries: `{ default, min?, max?, integer?, choices?, doc? }`.

`noise3` is gradient noise, and the point of it against `rng` is that nearby points
give *related* values — which is what makes it usable for shape rather than static.
Same field and parameter meanings as `displace`, so tune a look with one and pass
the same numbers to the other. `seed` defaults to 0 because it is a pure function:
same position and seed, same answer, no stream.

**`import` traps**, all of which bite in practice:
- **`.glb` and `.fbx`**, chosen by the extension (v0.7.2). A `.gltf` is still
  refused — it names sibling files the build may not read, and a hash over it
  would pin the manifest rather than the geometry (GLD-1026). **FBX skin weights
  and animation are not read yet**: the geometry, parts and materials come
  across and the build says what it dropped. Centimetres and Z-up become metres
  and Y-up on the way in. Export stays GLB only.
- Resolved relative to the importing script and **confined to its subtree**;
  inline source cannot import at all (GLD-1022).
- Arrives **vertex-split**: no two triangles share an index, so nothing
  topological works until you `weld`. `merge_faces(weld(m))` turns a 12-triangle
  box back into 6 quads.
- **Normals are dropped** — call `smooth_normals`.
- Unpinned is a GLD-1023 warning; pass `sha256` to make the build reproducible.
- A multi-material import **collapses at emit** to the material covering the most
  triangles.

## Animation (v4)

```lua
action({ name, skeleton, keys = { { time?|frame?, pose?, rest? }, ... },
         fps?, loop?, duration?, interpolation? = "linear"|"step",
         lock?, airborne? }) -> Action
emit_action(a)
mirror_pose(pose, { both? }) -> table<string, JointPose>
```

A key is a time (or a frame) and a `pose` mapping joint name to `JointPose`;
`rest = true` keys the rest pose. `interpolation` defaults to `"linear"` and
interpolates the keyed numbers as Blender does — the exporter adds samples so
glTF's quaternion slerp follows the same path. `lock` pins a joint over a span
and needs a two-bone chain above it.

`emit_action` puts one in the file. Names must be unique (`GLD-2006`), and the
action's skeleton must be bound to an emitted mesh by the end of the script
(`GLD-6051`) — the order of the two does not matter.

Errors worth knowing: `GLD-6050` malformed (no keys, duplicate times, `rotate`
mixed with `forward`/`left`/`twist`, `forward` on a bone already pointing
forward, a lock without a chain above it), `GLD-6003` unknown or ambiguous joint.

## Diagnostics

```lua
info(msg)   warn(msg)   print(msg)   fail(msg)   check(m, check_name) -> boolean
```

`check` takes any name `query --checks` takes -- `manifold`, `tris`, `faces`,
`watertight`, `degenerate`, `duplicates`, `zfight` (0.8.0: two faces sharing a
plane and overlapping in it, `GLD-4045`), `normals`, `uv`, `stretch`, `flipped`,
`overlap`, `texel`, `coverage`, `bounds`, `materials` and the rigging set; an
unknown name is `GLD-1007`. `fail` aborts with GLD-2100 carrying the script line. Note `info` is a **global
function** — do not shadow it with a local called `info`, which is easy to do when
naming the record `import` returns.

## Rigging (v3)

`skeleton`, `joint`, `envelope`, `region`, `bind`, `mirror_joints`,
`fit_skeleton`, `move_joint`. `bind` takes envelopes and world-space regions,
**never per-vertex weights** — no signature accepts an index-keyed weight array.
Its `method` is `"heat"` (default), `"envelope"` or `"source"`; `source` is
implied by passing `source = info.skin` from an import, which resamples the
file's own weights. `smooth_normals` takes a `source` the same way.
Joint names are Mixamo names; mirroring matches `Left`/`Right` tokens, not
`.L`/`.R` suffixes.

## Added since 0.5 -- the 0.8.0 stub, verbatim

SDFs are fields (negative inside, metres) built of parts and turned into a mesh
by `sdf_mesh`; `sdf_graft` blends a field into a mesh body. The annotations are
the stub's own words, copied, not paraphrased.

```lua
---@param a Profile
---@param ... Profile
---@return Profile
function profile_union(a, ...) end

---@param a Profile
---@param ... Profile
---@return Profile
function profile_subtract(a, ...) end

---@param opts { center: Vec3, radius: number, start: number, sweep: number, normal: Vec3?, segments: integer? }
---@return Path
function path_arc(opts) end

---@param body Mesh
---@param field Sdf
---@param opts { region: { min: Vec3, max: Vec3 }, edge_length: number, symmetry: { normal: Vec3, pivot: Vec3 }? }
---@return Mesh # One closed surface: `body`'s faces outside `region` kept exactly — triangles, quads, UVs — and everything else replaced by `field`'s surface, joined by a band of fresh triangles, so the field's blend is a fillet where `union` would leave a crease. The field must CONTAIN the body: `sdf_union{ parts = { sdf_from_mesh(body), part }, blend = ... }`, with the part and its blend inside the region. Every body face the region passes through is dropped whole, so the seam runs along the first whole edge loop outside the region; put the region's floor across the neck, well below the blend. The band grades from the body's spacing down to edge_length and is about one body edge wide. New triangles are flagged unmapped (uv_swatch them); colours and binds are dropped. Reports the seam it made (GLD-4064). Refused: the region misses or holds the whole body (GLD-4061), seam loops that cannot be matched (GLD-4062), a field more than half an edge off the body at the seam or leaving it outside the region (GLD-4063), a band that folds (GLD-4065). edge_length has no default. `symmetry` makes the result mirror-exact about the plane — every vertex with its partner, the plane's vertices exactly on it — by building the graft, cutting it at the plane and reflecting the half the normal points into; without it about 1–3% of a mirrored figure's vertices lose their partner. It needs a mirror-exact body with no face across the plane (model one half and mirror it) and a symmetric field (fold the part with sdf_symmetry about the same plane), or GLD-4067.
function sdf_graft(body, field, opts) end

---@param opts { radius: number, center: Vec3?, name: string? }
---@return Sdf # `center` defaults to the origin. Primitives take `center`, not `anchor`: a field has no bounding-box anchor worth having.
function sdf_sphere(opts) end

---@param opts { size: Vec3|number, round: number?, center: Vec3?, name: string? }
---@return Sdf # `round` (default 0) rounds every edge exactly and keeps the size; more than half the smallest side is refused (GLD-3002), not clamped.
function sdf_box(opts) end

---@param opts { a: Vec3, b: Vec3, radius: number, name: string? }
---@return Sdf # ENDPOINTS, not height + axis: a limb, horn or finger runs from one point to another, often joint positions just read.
function sdf_capsule(opts) end

---@param opts { a: Vec3, b: Vec3, radius_a: number, radius_b: number, name: string? }
---@return Sdf # A capsule with a different radius at each end — the workhorse: a tapered limb, a horn, a nose, a finger. One radius may be 0, not both.
function sdf_round_cone(opts) end

---@param opts { a: Vec3, b: Vec3, radius: number, round: number?, name: string? }
---@return Sdf # Flat caps at `a` and `b`. `round` (default 0) is at most the radius or half the length.
function sdf_cylinder(opts) end

---@param opts { major_radius: number, minor_radius: number, center: Vec3?, axis: Axis?, name: string? }
---@return Sdf # `axis` (default "y") is the ring's normal, as on torus.
function sdf_torus(opts) end

---@param opts { radii: Vec3, center: Vec3?, name: string? }
---@return Sdf # The surface is exact; the distance off it is an approximation (the exact one needs a root solve), which matters only to an offset or sdf_distance above it.
function sdf_ellipsoid(opts) end

---@param m Mesh
---@param opts { name: string? }?
---@return Sdf # A closed mesh as a part: distances from the surface, signed by the angle-weighted pseudo-normal; overlapping join shells are signed group by group and unioned. Keeps positions only — UVs, partition, colours and any bind are gone. A source that crosses itself warns GLD-4058 (the sign is wrong near the crossing). Use it to blend a mesh part with field parts, or to fuse a join of overlapping parts without a boolean.
function sdf_from_mesh(m, opts) end

---@param opts { parts: Sdf[], blend: number?, name: string? }
---@return Sdf # `blend` (default 0 = hard edge) is a RADIUS in metres, roughly the fillet's width. Parts fold LEFT TO RIGHT in list order — a smooth blend is not associative, so order is contract. A blend reshapes only what lies within `blend` of the other parts, so it melts a thin part into a bump only when the part lies almost wholly within it — a nub, a short ear (GLD-4054); a long thin part just gets a filleted root (GLD-4070, info). A nil hole in the middle of `parts` is an error, not a shorter list, and quotes the element (`jwa`) when the line holds the whole constructor. `name` makes the combination a PART, as on sdf_intersect.
function sdf_union(opts) end

---@param opts { from: Sdf, cut: Sdf[], blend: number?, name: string? }
---@return Sdf # Removes every `cut` from `from`, left to right. `blend` rounds the rim of the hole. `name` makes the combination a part, cuts included, as on sdf_intersect.
function sdf_subtract(opts) end

---@param opts { parts: Sdf[], blend: number?, name: string? }
---@return Sdf # Keeps only what every part contains. The first part is the solid; the rest clip it. `name` makes the combination a PART: an ear built as a cone clipped by a box is named here, `sdf_intersect{ parts = { cone, slab }, name = "ear" }`, and then sdf_part_faces(m, head, "ear") selects every leaf inside it, through any transform above, and diagnostics call an unnamed leaf inside it `the sdf_box in 'ear' (head.lua:12)`. A leaf's own name still wins. Changes nothing the field evaluates to.
function sdf_intersect(opts) end

---@param s Sdf
---@param distance number
---@return Sdf # Grows the surface outward (positive) or shrinks it (negative), in metres. Offset a part BEFORE blending it: above a blend, distances are underestimates, and so is the offset.
function sdf_offset(s, distance) end

---@param s Sdf
---@param opts { normal: Vec3, pivot: Vec3 }
---@return Sdf # A mirror modifier with NO SEAM: keeps the half-space `normal` points into and reflects it across the plane, so the field is symmetric because space is folded. Build one ear on the kept side; the fold supplies the other. Not `mirror`, which reflects the whole field.
function sdf_symmetry(s, opts) end

---@param s Sdf
---@param thickness number
---@return Sdf # Hollows the solid: a wall `thickness` thick, centred on the old surface.
function sdf_shell(s, thickness) end

---@param s Sdf
---@param opts { amount: number, frequency: number?, octaves: integer?, lacunarity: number?, gain: number?, seed: integer? }
---@return Sdf # Adds noise3 to the distance — bark, rock, flesh. The same keys, defaults and field as displace, so a look tuned on one reads the same on the other. `amount` is a peak in metres. Displace LAST: everything above it reads approximate distances.
function sdf_displace(s, opts) end

---@param s Sdf
---@param opts { edge_length: number, bounds: { min: Vec3, max: Vec3 }?, method: ("smooth" | "sharp")?, symmetry: { normal: Vec3, pivot: Vec3 }? }
---@return Mesh # An ordinary CLOSED MANIFOLD Mesh: all triangles, NO recorded partition, NO UVs, every crease rounded to about one edge_length. `edge_length` (metres, roughly the longest triangle edge) is REQUIRED and has NO DEFAULT: it decides what survives — a part thinner than about two edge lengths may vanish — so leaving it out is GLD-1004 with a value computed from the field's size. GLD-4050 reports triangles and the MEASURED surface error. The whole grid is sampled, ~2·(extent/edge_length)³ evaluations; past the cap it is GLD-4056 with an edge_length that fits. `bounds` clips (capped flat, GLD-4055). `method` defaults to "smooth" (the level set); "sharp" is dual contouring: exact box corners and edges, crisp hole rims, about half the triangles, quads recorded as faces; it falls back to "smooth" with GLD-4059 where it cannot stay manifold. Then decimate to a budget, uv_swatch the WHOLE mesh first (it has no UVs), bind, emit. `symmetry` makes the mesh MIRROR-EXACT about the plane: a folded field's level-set mesh is not (some triangles lack a mirror twin, a vertex or two a partner, and decimate{ symmetry } refuses it, GLD-6010); with symmetry the field is meshed as usual, cut at the plane, and the kept half reflected, so every vertex has its partner and decimate{ symmetry = "x" } keeps it that way. Needs a symmetric field (GLD-4067 otherwise) and method "smooth" (sharp is refused, GLD-2003).
function sdf_mesh(s, opts) end

---@param s Sdf
---@param p Vec3
---@return number # Signed distance at `p`: negative inside. Selects a part's faces after meshing: faces_where(m, function(f) return sdf_distance(eye, f.center) < 0.002 end).
function sdf_distance(s, p) end

---@param m Mesh
---@param field Sdf
---@param part string
---@return FaceSet # The faces of `m` that the field part named `part` owns: those whose centre (the polygon's, as faces_where sees it) the field attributes to a leaf of that name — the part whose surface is nearest there. Colour a field part by name: `uv_swatch(m, { faces = sdf_part_faces(m, head, "eye_socket"), at = SOCKET })`. Read off the FIELD, not recorded on the mesh, so it works on the fresh sdf_mesh and equally after decimate, subdivide or a union; select on a mesh made from this field, since on any other it still answers with whichever part is nearest. A name on several leaves selects them all; a name on an sdf_union/sdf_subtract/sdf_intersect selects every leaf inside it; a part under sdf_symmetry owns both sides of the fold. An unknown name is GLD-4060, with `did you mean 'ear'?` for a near miss and the list of names the field has; a part that owns no face here is a GLD-4001 warning and an empty set.
function sdf_part_faces(m, field, part) end

---@param m Mesh
---@param opts { source: Mesh }
---@return Mesh # Copy UVs onto `m` from another mesh by surface position — for a mesh REBUILT from a painted one by an op that makes a new surface (`sample_uvs(sdf_mesh(sdf_from_mesh(painted), {...}), { source = painted })`). Each triangle takes the UV chart of the source triangle nearest its centroid, facing its way (so a thin part's back never reads its front), and each corner reads its own nearest point in that chart: a swatch boundary lands on an edge, a swatch arrives bit-exact, an unwrap stays an unwrap at another resolution. Vertices split at the source's seams; the partition, normals, colours and a bind come through. Sample from a source of the SAME shape — GLD-3061 counts corners more than 2% of the source's diagonal from it; GLD-3062 reports. A source with no UVs is GLD-3037. Not needed after decimate or subdivide: both carry UVs themselves.
function sample_uvs(m, opts) end

---@param opts { name: string, base_color: Vec3?, metallic: number?, roughness: number?, emissive: Vec3?, texture: string?, normal_texture: string?, metallic_roughness_texture: string?, occlusion_texture: string?, emissive_texture: string?, texture_filter: ("nearest"|"linear")?, texture_wrap: ("clamp"|"repeat")?, compress: ("none"|"auto"|"etc1s"|"uastc")?, alpha_mode: ("opaque"|"mask"|"blend")?, alpha_cutoff: number? }
---@return string # base_color is LINEAR, not sRGB. `texture_filter` ("nearest", the default, keeps a uv_swatch palette's swatches crisp; "linear" smooths a painted or photographic texture) and `texture_wrap` ("clamp", the default, or "repeat" to tile) set the base-colour texture's sampler (ADR-081); an import keeps the file's own. `compress` puts the material's textures through a GPU codec in the file (ADR-082): "none" (the default) ships them as authored, "auto" picks ETC1S for base colour and UASTC for the continuous maps, and "etc1s"/"uastc" force one. The GLB then carries BOTH the original and the KTX2, declaring KHR_texture_basisu without requiring it, so a viewer that cannot read KTX2 still draws the original. Refused on a palette atlas — a 4x4 block codec bleeds neighbouring swatches together, so compression on a texture left at texture_filter = "nearest" is GLD-2009. Dimensions must be multiples of 4 or export refuses rather than resizing. `metallic_roughness_texture` (glTF: blue = metal, green = roughness, multiplied by metallic/roughness), `occlusion_texture` (red) and `emissive_texture` (multiplied by emissive) follow the same path rule and are exported with the linear, repeating sampler (ADR-080); an import references a file's own the same way. `texture` is a path to a PNG or JPEG, relative to the script and restricted to its directory subtree; it is embedded in the GLB and bound as `baseColorTexture`. The sampler written for it is NEAREST and CLAMP_TO_EDGE, not the glTF default — `uv_swatch` collapses a region onto a single texel of a palette atlas, and linear filtering would blend that texel with the swatch beside it. `base_color` still multiplies the texture, so a dark base_color tints the atlas rather than being replaced by it. `normal_texture` is a tangent-space normal map (OpenGL convention, green up) under the same path rule; the GLB gets a MikkTSpace TANGENT and a LINEAR/REPEAT sampler for it, and it needs UVs. `alpha_mode` is "opaque" (default), "mask" (discard below `alpha_cutoff`, default 0.5; prefer it for cutouts) or "blend" (order-dependent in every renderer). `render` draws texture, normal map and alpha from the same files the export embeds.
function material(opts) end

---@param m Mesh
---@param opts { name: string, material: string?, lod: integer?, lod_of: string?, open: boolean?, position: Vec3?, rotation: Vec3?, scale: Vec3|number? }
---@return nil # `position`/`rotation`/`scale` PLACE THE NODE (ADR-093): `m` is the node's LOCAL space, modelled about the pivot you want, and the glTF node carries the transform, so in an engine the node origin is that pivot rather than the world origin. `rotation` is degrees about world X, then Y, then Z; `scale` is non-zero per axis (GLD-3002). Applied scale, rotate, translate. Render, query and checks see the placed world-space mesh. A bound mesh cannot be placed (glTF ignores a skinned node's transform — move it with translate/rotate, GLD-2003); an LOD level takes its base's placement and refuses its own (GLD-2003).
function emit(m, opts) end

---@param spec table<string, { default: any, min: number?, max: number?, integer: boolean?, choices: any[]?, doc: string? }>
---@return table # May be called ONCE. `default` is a number, string or boolean — its Lua type is the parameter's type, narrowed to whole numbers by `integer = true`; a table default is GLD-1007 because no override could carry it. Out-of-range values are rejected, never clamped (GLD-2001), and `choices` is enforced for every type, not only strings. An override naming a parameter that does not exist is GLD-2008 with a near-miss suggestion, not a silent no-op — a typo would otherwise build a clean, unchanged model and say nothing. Overrides arrive as text: a boolean takes `true`/`1` and `false`/`0` and nothing else. What was declared, and the value that actually built, come back in the `params` key of the JSON envelope and of the gladius_run / gladius_query results, in declaration order.
function params(spec) end

---@param opts { name: string, joints: Joint[], forward: Vec3?, up: Vec3? }
---@return Skeleton
function skeleton(opts) end

---@param opts { name: string, head: Vec3, tail: Vec3, roll: number?, scale: number?, parent: string?, limits: table? }
---@return Joint
function joint(opts) end

---@param opts { joint: string, radius: number, falloff: number?, cap: string? }
---@return Envelope
function envelope(opts) end

---@param opts { joint: string, min: Vec3, max: Vec3, weight: number? }
---@return Region # A world-space box forcing `weight` (default 1.0) for one joint, applied after the envelopes and in order. bind reports each one (GLD-6066): "region mixamorig:Head [...]: 1602 vertices, all at weight 1.00" is the proof a part is rigid; a warning names vertices a later region, an unshared partial weight or the influence cap moved, and a box holding none. Give a joint an action keys the loop nearest its own tail, or it bends nothing (GLD-6067).
function region(opts) end

---@param m Mesh
---@param s Skeleton
---@param opts { method: string?, envelopes: Envelope[]?, regions: Region[]?, max_influences: integer?, source: userdata? } # method "heat" (default), "envelope", or "source" — implied by `source = info.skin` from import, which samples the file's own weights by position (ADR-074)
---@return Mesh
function bind(m, s, opts) end

---@param s Skeleton
---@param opts { from: string?, to: string?, plane_normal: Vec3? }
---@return Skeleton
function mirror_joints(s, opts) end

---@param m Mesh
---@param opts { preset: string?, fingers: boolean?, twist: boolean?, symmetry_plane: Vec3? }?
---@return Skeleton
function fit_skeleton(m, opts) end

---@param s Skeleton
---@param name string
---@param opts { head: Vec3?, tail: Vec3?, roll: number? }
---@return Skeleton
function move_joint(s, name, opts) end

---@param opts { name: string, skeleton: Skeleton, keys: { time: number?, frame: number?, pose: table<string, JointPose>?, rest: boolean? }[], fps: number?, loop: boolean?, duration: number?, interpolation: '"linear"'|'"step"'?, lock: (string|{ joint: string, from: number?, to: number?, at: '"start"'|'"rest"'? })[]?, airborne: number[][]? }
---@return Action # `linear` (default) interpolates the keyed numbers like Blender; the exporter adds samples so glTF's quaternion slerp follows the same path. Errors: GLD-6050 malformed (no keys, duplicate times, rotate mixed with forward/left/twist, forward on a bone pointing forward, a lock without a two-bone chain above it), GLD-6003 unknown or ambiguous joint, GLD-1007 skeleton not a Skeleton.
function action(opts) end

---@param a Action
function emit_action(a) end
```
