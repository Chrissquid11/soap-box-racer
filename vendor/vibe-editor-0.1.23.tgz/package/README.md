# @vibe/editor

The editor of a Squidwright game -- studio mode (`?studio` on a dev server's page; the plain page is the
game, `P` its pause): the host, the Scene, Config, Model and Studio tabs, the Assets panel, Claude Code's
card, and the debug panel. Its peers are `@vibe/engine`,
`@vibe/pipeline` (its pure subpaths only) and `three`.

- `@vibe/editor` -- `createEditor` (what `boot()` loads), the `EditorContext` a tool gets, the parts a
  card is built of, `createAssetsTool`, the inspector's `BlockItem` list, `assetApi`
- `@vibe/editor/panel` -- the debug panel (stats and lil-gui), a lazy chunk of its own
- `src/studio/` -- the Studio tab of studio mode (`?studio`): the Console, Problems, Tests, Build, Code and
  Git cards (`Docs/studio.md`), and `app-shell.ts`, its side of the Squidwright app's `window.squidwright`
- `src/studio/git/` -- the Git card's pure parts (its rows, ticks, commit plan, log, ask bar) and Draft with Claude
- `src/studio/code/` -- the Code card's parts: Monaco (`monaco-editor`, this package's one dependency,
  loaded on the card's first open), the TypeScript bridge's client, the providers, tabs, tree, diff, search

Imported by a project's `main.ts` (one `DEBUG`-gated `import()` each, so a release drops it; the
build fails if one carries it) and by its own tools in `src/tools/`. The docs are the squidwright
repository's `Docs/` (`packages.md` §10, `assets-tool.md`, `modeler.md`, `agent.md`, `studio.md`).
