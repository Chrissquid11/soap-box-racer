/**
 * A prefab dragged from the Assets tool and dropped to place it (Docs/prefabs.md
 * §7): on the scene, where the ground under the pointer is; on an entity in the
 * tree, as that entity's child, at its origin; on the line between two rows,
 * as their sibling in that place (`drop-zone.ts`). One undo step, `Spawn
 * crates/big`, as the tree's Create menu's. **A model** dragged and dropped the
 * same way makes an entity of its own -- `Transform`, `Render { model }`, a
 * `Name` its file's stem -- one step `Spawn props/crate` (`spawnAt`'s model
 * case, `modelSpawn`; `placeAt` places either). **A
 * material** dropped on an entity -- the one drawn under the pointer, or its
 * tree row -- is worn by it: its `Render.material`, one step `Set
 * Render.material`, an override on an instance as any field edit is
 * (`wearMaterial`); one with no `Render` refuses, saying so.
 *
 * The rules:
 *   - **The drag says it carries prefabs** by a type of its own
 *     (`PREFAB_DRAG`, set beside the Assets tool's `DRAG_TYPE` when every file
 *     dragged is a prefab; `MODEL_DRAG` when every one is a model,
 *     `MATERIAL_DRAG` a material), since `dragover` can read a drag's types,
 *     never its data -- so the tree and the scene light only for a drag they can take.
 *   - **One a drop**: a drag of several places (or puts on) the first, and says so.
 *   - **One tab**: the Assets panel is along the bottom of the Scene tab, so a
 *     prefab's tile reaches the scene and the tree as it is; the Scene tool
 *     places it (`edits.ts`, `tree.ts`) -- the panel only says where it would
 *     land. (A drag held over another tool's button still brings that tab up.)
 *
 * Glob-free: the world and the entity are handed in.
 */
import { compiledPrefab, internKey, NONE, Render, type Entity, type World } from '@vibe/engine';
import { modelSpawn, spawnAt, type Spawnable } from './spawn.ts';

/** The type a drag of prefab files carries, beside `DRAG_TYPE`: their keys, as JSON. */
export const PREFAB_DRAG = 'application/x-vibebase-prefab';

/** The type a drag of model files carries, beside `DRAG_TYPE`: their keys, as JSON. */
export const MODEL_DRAG = 'application/x-vibebase-model';

/** The type a drag of material files carries, beside `DRAG_TYPE`: their keys, as JSON. */
export const MATERIAL_DRAG = 'application/x-vibebase-material';

/**
 * The type a drag of the tree's rows carries: the entities, as JSON indices --
 * the selection, if the row dragged is in it. Dropped on a folder of the
 * Assets tool, they are saved as a prefab there (`save-prefab.ts`).
 */
export const ENTITIES_DRAG = 'application/x-vibebase-entities';

/** Does this drag carry the tree's entities: readable during `dragover`. */
export const carriesEntities = (event: DragEvent): boolean => event.dataTransfer?.types.includes(ENTITIES_DRAG) ?? false;

/** What a drag is read by here: its types during `dragover`, its data on `drop` -- a `DragEvent`, or a test's stand-in. */
export interface Dragged {
  readonly dataTransfer: { readonly types: readonly string[]; getData(type: string): string } | null;
}

/** Does this drag carry prefabs: readable during `dragover`. */
export const carriesPrefab = (event: Dragged): boolean => event.dataTransfer?.types.includes(PREFAB_DRAG) ?? false;

/** Does this drag carry models: readable during `dragover`. */
export const carriesModel = (event: Dragged): boolean => event.dataTransfer?.types.includes(MODEL_DRAG) ?? false;

/** Does this drag carry materials: readable during `dragover`. */
export const carriesMaterial = (event: Dragged): boolean => event.dataTransfer?.types.includes(MATERIAL_DRAG) ?? false;

/** Does this drag make something where it lands -- a prefab's instance, or a model's entity: what the scene and the tree place. */
export const carriesPlaceable = (event: Dragged): boolean => carriesPrefab(event) || carriesModel(event);

/** The first key of `type` a drop carries, if `known` takes it; null otherwise. Only on `drop`. */
function droppedKey(event: Dragged, type: string, known: (key: string) => boolean): { key: string; more: number } | null {
  let keys: unknown;
  try {
    keys = JSON.parse(event.dataTransfer?.getData(type) || '[]');
  } catch {
    return null;
  }
  if (!Array.isArray(keys) || typeof keys[0] !== 'string' || !known(keys[0])) return null;
  return { key: keys[0], more: keys.length - 1 };
}

/** The first prefab key a drop carries, if it is one compiled now; null otherwise. Only on `drop`. */
export const droppedPrefab = (event: Dragged): { key: string; more: number } | null => droppedKey(event, PREFAB_DRAG, (key) => !!compiledPrefab(key));

/** The first model key a drop carries, if `known` (the asset store's) has it; null otherwise. Only on `drop`. */
export const droppedModel = (event: Dragged, known: (key: string) => boolean): { key: string; more: number } | null => droppedKey(event, MODEL_DRAG, known);

/** The first material key a drop carries, if `known` (the materials' store) has it; null otherwise. Only on `drop`. */
export const droppedMaterial = (event: Dragged, known: (key: string) => boolean): { key: string; more: number } | null => droppedKey(event, MATERIAL_DRAG, known);

/**
 * One of `what` -- a prefab's instance, or a model's entity (`spawnAt`) --
 * placed: at `at` in the world, or -- with a `parent` -- under it, in front of
 * its child `before` (NONE, last), at its origin, or at `at` taken as a point in
 * its space when `local`. NONE if the world is full. The caller flushes,
 * selects and commits the step.
 */
export function placeAt(world: World, what: Spawnable, at: { x: number; y: number; z: number }, parent: Entity = NONE, local = false, before: Entity = NONE): Entity {
  // Under a parent: at its origin (a drop on its tree row, or between two of its children's), or at `at` already in its space (`local`: a drop on the scene).
  const e = spawnAt(world, what, parent === NONE || local ? at : { x: 0, y: 0, z: 0 });
  if (e !== NONE && parent !== NONE) world.setParent(e, parent, before);
  return e;
}

/** One entity drawn as model `key`, where `placeAt` puts it: `Transform`, `Render { model }`, a `Name` its file's stem (`crate`, then `crate 2`). */
export const placeModel = (world: World, key: string, at: { x: number; y: number; z: number }, parent: Entity = NONE, local = false, before: Entity = NONE): Entity =>
  placeAt(world, modelSpawn(key), at, parent, local, before);

/** Can `e` wear a material dropped on it: alive, with a `Render`. What the tree's rows light for, and `wearMaterial` asks. */
/**
 * What a drop chooses (Docs/ecs.md §13, "A drag never changes it"): a prefab or a model placed, the entity made --
 * what you just made is what you look at; a material worn, nothing (`NONE`) -- the selection and the right panel stay
 * as they were, the Render block shown following if it is the wearer's.
 */
export const droppedChoice = (drop: 'placed' | 'worn', e: Entity): Entity => (drop === 'placed' ? e : NONE);

export const canWear = (world: World, e: Entity): boolean => e !== NONE && world.alive(e) && world.has(e, Render);

/**
 * Material `key` worn by `e`: its `Render.material`, written now. Returns why
 * not -- `e` has no `Render` (adding one is not this drop's to do) -- or null
 * when it is worn. The caller commits the step.
 */
export function wearMaterial(world: World, e: Entity, key: string, label: string): string | null {
  if (!canWear(world, e)) return `${label} has no Render to wear it -- add one (Add Component ▸ Rendering ▸ Render) and pick a model first`;
  world.store(Render).material[e] = internKey('Material', key);
  return null;
}
