/**
 * The keys card (`?`, and the top bar's Keys): every editor key that is
 * live as it opens, grouped by tool, read from MrDebug's own list -- the
 * actions named `editor…` whose `when` says yes -- so it says what the keys do
 * now, never what a list written by hand once said they did.
 *
 * - **A line an action**: its keys and chords as chips (`keyLabel`: `⌘Z` on a
 *   Mac, `Ctrl+Z` elsewhere), then its help. Two actions of one group with the
 *   same help -- Delete and Backspace -- are one line with both keys.
 * - **Grouped** as the editor registered them (`groupOf`): its own keys first,
 *   then each tool's under its name.
 * - **Closed by the editor's keys**, as every key is MrDebug's: `?` again, or
 *   Esc (the editor's `holdsEscape` while it is open). A press anywhere else, on
 *   the editor's cards or the scene, closes it too -- as a menu does.
 *
 * Its head names the keymap the keys are of (Industry Compatible or Blender,
 * Docs/navigation.md §8). Under the keys, what the mouse does -- the scene's, or the tool up's own
 * line (`ToolInstance.mouse`) -- and the choice the keys cannot show: whether
 * scrolling is a trackpad's or a mouse's (`wheel.ts`). The rest of the
 * navigation's preferences are on Config ▸ Preferences (Docs/navigation.md D1).
 *
 * Config ▸ Editor ▸ Keys (`config/keys.ts`) lists them with the same parts
 * (`keyGroups`, `mouseLine`) -- every key registered, live or not.
 */
import { keyLabel, keysOf, modName, MrDebug } from '@vibe/engine/debug';
import { KEYMAP_NAMES } from './editor-keys.ts';
import { loadPrefs, WHEEL_MODES, type NavPrefs, type WheelMode } from './prefs.ts';
import { control, el, letGo } from './shell.ts';

export interface KeysCard {
  readonly open: boolean;
  /** Read the live keys and show them; or, open already, close. */
  toggle(): void;
  close(): void;
  dispose(): void;
}

export interface KeysCardOptions {
  /** The group an action of the editor's belongs to, by its MrDebug name; the editor's own for any it does not know. */
  groupOf(name: string): string;
  /** The groups in the order they are shown: the editor's, then each tool's. */
  groups(): readonly string[];
  /** Told as it opens or closes: the editor's keys stand still while it is open. */
  changed?(): void;
  /** What the wheel is (`viewport.wheel`), and the way to choose another. */
  wheel(): WheelMode;
  setWheel(mode: WheelMode): void;
  /** The tool up's own line of what the mouse does, in place of the scene's (`ToolInstance.mouse`); null for the scene's. */
  mouse?(): string | null;
}

/** The class of a button that opens and closes the card: a press on it is not one outside. */
export const TOGGLE = 'ed-keys-toggle';

/** Each way the wheel can be read: its name on its button, and what scrolling then does. */
export const WHEELS: Record<WheelMode, { name: string; does: string }> = {
  auto: { name: 'Auto', does: 'A trackpad orbits with two fingers, zooms with a pinch, pans with Shift and two fingers; a mouse wheel zooms' },
  trackpad: { name: 'Trackpad', does: 'Two fingers orbit · a pinch or Ctrl zooms · Shift and two fingers pan' },
  mouse: { name: 'Mouse', does: 'The wheel zooms · Ctrl-wheel pans across · Shift-wheel pans up and down' },
};

/**
 * How the mouse moves a 3D view under the keymap: Industry Compatible's Alt with each button (Docs/navigation.md §8), or
 * Blender's middle button (§2) and Alt with the left under Emulate 3 Button Mouse.
 */
export const navLine = (nav: Pick<NavPrefs, 'keymap' | 'emulate3'> = loadPrefs().nav): string => nav.keymap === 'industry'
  ? 'Alt-drag orbits, Alt+middle-drag pans, Alt+right-drag zooms'
  : 'middle-drag orbits, Shift pans, Ctrl zooms, Alt snaps to an axis view'
    + (nav.emulate3 ? ' -- or Alt with the left button (Emulate 3 Button Mouse)' : '');

/** What the mouse does, which no key list says: the last line. */
export const mouseLine = (): string => {
  const mod = modName();
  return `Mouse: click selects · Shift-click adds · ${mod}-click adds or takes out · in the tree Shift-click selects the rows between · drag to box-select (Shift adds, ${mod} turns over) · ${navLine()}`
    + ' · wheel zooms · right-click for a menu · drag a row onto another to re-parent, onto its top or bottom edge to reorder'
    + ' · a row\'s eye hides it, its power sign switches it off · what is hidden or off is clicked through in the scene: select it in the tree';
};

/**
 * A choice -- Scrolling -- a button each way, the one in
 * use pressed, and what it does: changed in place, the keys left as they were
 * read. The keys card's, and Config ▸ Editor ▸ Preferences'.
 */
export function choice<M extends string>(name: string, modes: readonly M[], ways: Record<M, { name: string; does: string }>, now: () => M, set: (mode: M) => void): HTMLElement {
  const row = el('div', 'ed-keys-wheel');
  const does = el('span', 'ed-keys-help');
  const buttons = modes.map((mode) => {
    const b = letGo(control('ui', 'ed-button ed-small', ways[mode].name));
    b.title = ways[mode].does;
    b.addEventListener('click', () => {
      set(mode);
      mark();
    });
    return { mode, b };
  });
  const mark = (): void => {
    const chosen = now();
    for (const { mode, b } of buttons) b.setAttribute('aria-pressed', String(mode === chosen));
    does.textContent = ways[chosen].does;
  };
  mark();
  row.append(el('span', 'ed-keys-group-name', name), ...buttons.map(({ b }) => b), does);
  return row;
}

/**
 * The editor's keys as lines by group (`groupOf`, in `groups`' order, any other
 * after): `live`, those whose `when` says yes just now -- the card's -- else
 * every one registered (Config ▸ Keys). A line an action, its keys as chips;
 * two of a group with the same help one line.
 */
export function keyGroups({ groupOf, groups }: Pick<KeysCardOptions, 'groupOf' | 'groups'>, live: boolean): HTMLElement {
  const by = new Map<string, { keys: string[]; help: string }[]>();
  for (const action of MrDebug.list()) {
    const keys = keysOf(action);
    if (!action.name.startsWith('editor') || keys.length === 0 || (live && action.when && !action.when())) continue;
    const group = groupOf(action.name);
    const lines = by.get(group) ?? [];
    by.set(group, lines);
    const labels = keys.map((key) => keyLabel(key));
    const same = lines.find((line) => line.help === action.help);
    if (same) same.keys.push(...labels.filter((label) => !same.keys.includes(label)));
    else lines.push({ keys: labels, help: action.help });
  }
  const columns = el('div', 'ed-keys-groups');
  const order = [...groups(), ...[...by.keys()].filter((g) => !groups().includes(g))];
  for (const group of order) {
    const lines = by.get(group);
    if (!lines) continue;
    const column = el('div', 'ed-keys-group');
    column.append(el('div', 'ed-keys-group-name', group));
    for (const { keys, help } of lines) {
      const line = el('div', 'ed-keys-line');
      const chips = el('span', 'ed-keys-chips');
      for (const key of keys) chips.append(el('span', 'ed-key', key));
      line.append(chips, el('span', 'ed-keys-help', help));
      column.append(line);
    }
    columns.append(column);
  }
  return columns;
}

/** `root` is the editor's (the card goes in it), `canvas` the scene's: a press on either, outside the card, closes it. */
export function createKeysCard(root: HTMLElement, canvas: HTMLElement, { groupOf, groups, changed, wheel, setWheel, mouse: own }: KeysCardOptions): KeysCard {
  const card = el('div', 'ed-card ed-keys-card');
  card.hidden = true;
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-label', 'Keys');
  root.append(card);
  let open = false;

  /** A press outside: the card is done with -- but for one on a button that toggles it, which does so itself. Capturing, as a menu's. */
  const outside = (event: PointerEvent): void => {
    const target = event.target as Element | null;
    if (!card.contains(target) && !target?.closest?.(`.${TOGGLE}`)) close();
  };

  function show(): void {
    // Read before the card is open, while the keys it lists still are.
    const columns = keyGroups({ groupOf, groups }, true);
    const head = el('div', 'ed-keys-head');
    // The keymap whose keys these are (Docs/navigation.md §8): Config ▸ Preferences chooses it.
    head.append(el('div', 'ed-side-title', 'Keys'), el('span', 'ed-dim', `${KEYMAP_NAMES[loadPrefs().nav.keymap]} keymap · Live just now · ${keyLabel('Shift+Slash')} or Esc closes`));
    // Emulate Numpad on (Docs/navigation.md D5): said, since the digit row lists as the numpad only over a view.
    if (loadPrefs().nav.emulateNumpad) head.append(el('span', 'ed-dim', ' · Emulate Numpad is on: over a 3D view the digit row, - and = are the numpad'));
    // The tool up's own line where it has one -- the Assets tab's tiles, not the scene's rows -- else the scene's.
    const foot = el('div', 'ed-keys-foot', own?.() ?? mouseLine());
    card.replaceChildren(head, columns, foot, choice('Scrolling', WHEEL_MODES, WHEELS, wheel, setWheel));
    card.hidden = false;
    open = true;
    root.addEventListener('pointerdown', outside, true);
    canvas.addEventListener('pointerdown', outside, true);
    changed?.();
  }

  function close(): void {
    if (!open) return;
    open = false;
    card.hidden = true;
    card.replaceChildren();
    root.removeEventListener('pointerdown', outside, true);
    canvas.removeEventListener('pointerdown', outside, true);
    changed?.();
  }

  return {
    get open() {
      return open;
    },
    toggle: () => (open ? close() : show()),
    close,
    dispose() {
      close();
      card.remove();
    },
  };
}
