/**
 * One Copy and one Paste for the tree and for Claude (`edits.ts`' `copy` and `pasteClip`, `mcp/entities.ts`'
 * `scene_copy` and `scene_paste`): the decisions each would otherwise make on its own, made once.
 *
 * - **Refs out kept only in the world copied from** (`pasteHere`): a clip carries the id of the world it was copied
 *   from (`Clip.from`, `worldId`) -- the page's own random id and the world's generation: a page-wide count, the next
 *   taken by each `World` the first time it is seen and by each other world loaded into one (`anotherWorld`, the
 *   editor's `emit('loaded')` for another world: a scene opened, a prefab opened or gone Back from), so a new `World`
 *   -- a rebuild's -- never shares an id with the one before it. Pasted where that id is still the world's, a ref out of the clip still means what it did, and is kept;
 *   anywhere else -- another scene, another tab, after a reload -- the same number is somebody else.
 * - **Under the opened prefab's root**: with a prefab open, what is pasted goes under its root, each root's place
 *   put in its space where it is (`openedParent`, `moveRowsInPlace`) -- beside the root it would be in no prefab, and Save refuses that.
 * - **Claude's clips are its own** (`keepClip`, `clipOf`): `scene_copy` keeps its clip here, page-side, beside the
 *   tree's `copied` -- the person's clipboard never touched -- and answers a handle that `scene_paste` takes, so a clip
 *   larger than a tool's answer can carry is never cut. The last `CLIPS_KEPT` are kept; the page's reload forgets them.
 *
 * Pure ECS, no page: node tests it.
 */
import { type Entity, NONE, type World } from '@vibe/engine';
import { copyOut, pasteIn, type Clip, type Pasted } from './clip.ts';
import { openedParent } from './opened.ts';
import { moveRowsInPlace } from './reparent.ts';
import { spawnDressed } from './spawn.ts';

/** This page's own: a clip from another tab, or before a reload, is from another world whatever its count says. */
const PAGE = Math.random().toString(36).slice(2, 10);

/** The page's world generations so far: each world, and each other world loaded into one, takes the next. */
let generation = 0;

/** Each world's generation now: one never seen takes a fresh one, so two worlds never share an id. */
const generations = new WeakMap<World, number>();

/** The id of the world as it is now: what a clip copied from it carries. */
export function worldId(world: World): string {
  let now = generations.get(world);
  if (now === undefined) generations.set(world, (now = ++generation));
  return `${PAGE}:${now}`;
}

/** Another world loaded into `world` (a scene, a prefab opened or Back): clips copied before are no longer from it. */
export function anotherWorld(world: World): void {
  generations.set(world, ++generation);
}

/** `roots` copied, each with everything under it, stamped with the world they came from. */
export function copyHere(world: World, roots: readonly Entity[]): Clip {
  return { ...copyOut(world, roots), from: worldId(world) };
}

/** Was the clip copied from this world, as it is now: its refs out still mean what they did. */
export const fromHere = (world: World, clip: Clip): boolean => clip.from !== undefined && clip.from === worldId(world);

/**
 * `clip` made in `world`, its middle at `at` across the ground: its refs out kept only if it is from this world
 * (`fromHere`), and, with a prefab open (`openedRoot`, else NONE), its roots under the prefab's root in its space.
 * Flushed: the entities are there.
 */
export function pasteHere(world: World, clip: Clip, at: { x: number; z: number }, openedRoot: Entity): Pasted {
  const pasted = pasteIn(world, clip, at, { make: spawnDressed, keepRefs: fromHere(world, clip) });
  world.flush();
  const parent = openedRoot === NONE ? NONE : openedParent(world, openedRoot, []);
  if (parent !== NONE && pasted.roots.length > 0) {
    // Where it was pasted in the world, as a child of the root needs it -- turned and scaled too: it stays where it looked.
    moveRowsInPlace(world, pasted.roots, parent, NONE);
    world.flush();
  }
  return pasted;
}

// ---------------------------------------------------------------- Claude's clips

/** Claude's clips kept, at most: the oldest let go. */
export const CLIPS_KEPT = 8;

const clips = new Map<string, Clip>();
let made = 0;

/** A clip kept for `scene_paste`: its handle. */
export function keepClip(clip: Clip): string {
  const handle = `clip-${++made}`;
  clips.set(handle, clip);
  while (clips.size > CLIPS_KEPT) clips.delete(clips.keys().next().value!);
  return handle;
}

/** The clip a handle names, or undefined: never made, let go, or the page reloaded since. */
export const clipOf = (handle: string): Clip | undefined => clips.get(handle);

/** The handles kept now, oldest first: said when one named is not. */
export const clipHandles = (): string[] => [...clips.keys()];
