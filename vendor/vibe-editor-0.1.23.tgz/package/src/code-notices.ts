/**
 * Studio mode mid-session (Docs/studio.md §1, "Mid-session"): the project's code broken while the page is up, said
 * where it can be fixed -- the notices' part of it (`notices.ts`), each with Open, which brings the Code card up at
 * the line.
 *
 * - **A module Vite cannot serve** (`code`): the dev server's list (`studio:broken`, `GET broken`: the pipeline's
 *   `studio/broken.ts`) kept as one notice each -- `src/game/systems/spin.ts:19:52 -- Expected a semicolon` -- the game
 *   running on the last good code meanwhile; a page reload the server holds for it said on it. A module that serves
 *   again: its notice gone (`heard`). Not over recovery's stand-in: the boot notice says it there, and the game is not
 *   running on anything. A module that transforms but threw as the dev server's probe page evaluated it
 *   (`evaluated`, `studio/probe-frames.ts`): said so -- the page stays as it was -- its mapped stack on the hover, Open, and
 *   "Reload anyway" (`unhold`).
 * - **A runtime error** (`frame`, a system that threw; `swap`, a changed game module that threw as it was evaluated):
 *   said at once as boot words it, then placed -- its stack mapped by the dev server to the TypeScript (`POST stack`),
 *   the notice said again with `· at src/game/systems/spin.ts:7:7`, Open, and the mapped stack on its hover. A module the
 *   browser could not fetch is never said as a `swap`: the engine's `liveGame` leaves it out (`NOT_FETCHED`) -- that
 *   module is broken, its `code` notice names it.
 * - **Cleared** by kind (`clear`): boot's, on a good swap (`swap`, `frame`).
 *
 * No DOM: a node test drives it with stand-ins.
 */
import type { BrokenAnswer, CodeError, MappedStack } from '@vibe/pipeline/studio-types';
import { type NoticeAction, type NoticeKind, type Notices } from './notices.ts';

/** A file's place as the notices say it: `file:line:col`, the file alone when Vite named no line. */
export function codeWhere(e: Pick<CodeError, 'file' | 'line' | 'col'>): string {
  return e.line > 0 ? `${e.file}:${e.line}:${e.col}` : e.file;
}

/**
 * A broken module's notice: where, what, and what goes on meanwhile -- the game on its last good code, a held reload.
 * One that threw as the probe page evaluated it (`evaluated`): said so, the page as it was.
 */
export function codeText(e: CodeError, held: readonly string[]): string {
  const waits = held.length > 0 ? ` · the page reload ${held.join(', ')} asked for waits until it ${e.evaluated ? 'evaluates' : 'serves'}` : '';
  if (e.evaluated) return `${codeWhere(e)} threw as it was evaluated -- ${e.message} · the page stays as it was${waits}`;
  return `${codeWhere(e)} -- ${e.message} · the game runs on the last good code${waits}`;
}

export interface CodeNoticesOptions {
  notices: Notices;
  /** The dev server's `POST stack`; null with none (no stack is placed). */
  map: ((stack: string) => Promise<MappedStack>) | null;
  /** The Code card brought up at the place. */
  open(file: string, line: number, col: number): void;
  /** Are `code` notices said (not over recovery's stand-in)? */
  show: boolean;
  /** "Reload anyway" (`POST unhold`): a module held for a throw let go; none, not offered. */
  unhold?: () => void;
}

export interface CodeNotices {
  /** The server's list as it is now: a notice each, those no longer broken gone. */
  heard(answer: BrokenAnswer): void;
  /** How many modules are broken now: recovery's reload waits while any is. */
  readonly broken: number;
  /** Boot's notice: said, then placed when it is a runtime error with a stack. */
  say(kind: NoticeKind, text: string, error?: unknown): void;
  /** Every one of `kind` put away (boot's, on a good swap). */
  clear(kind: NoticeKind): void;
}

const openAction = (title: string, run: () => void): NoticeAction => ({ mcp: 'ui', label: 'Open', title, run });

export function createCodeNotices(options: CodeNoticesOptions): CodeNotices {
  const { notices } = options;
  let broken = 0;
  /**
   * Each broken file's notice, by file: its id, and what it says of the break (where and what) -- the held list
   * changing says it again in place; a new break in the file is a new notice; one the person dismissed stays so.
   */
  const shown = new Map<string, { id: number; break: string }>();
  /** Each kind's placing under way: a clear meanwhile makes it moot. */
  const cleared = new Map<NoticeKind, number>();
  const place = (kind: NoticeKind, text: string, error: Error & { stack: string }): void => {
    const said = notices.list.find((n) => n.kind === kind && n.text === text);
    if (!said || !options.map) return;
    const era = cleared.get(kind) ?? 0;
    options.map(error.stack).then(
      (mapped) => {
        // Put away meanwhile -- dismissed, or a good swap cleared it: nothing to place.
        if ((cleared.get(kind) ?? 0) !== era || !notices.list.some((n) => n.id === said.id)) return;
        const at = mapped.at;
        notices.dismiss(said.id);
        const actions = at ? [openAction(`Open ${codeWhere(at)} in the Code card`, () => options.open(at.file, at.line, at.col))] : undefined;
        notices.add(kind, at ? `${text} · at ${codeWhere(at)}` : text, error, actions, mapped.stack);
      },
      () => {
        // No map: the notice as boot said it, the stack as the browser has it.
      },
    );
  };
  return {
    heard(answer) {
      broken = answer.errors.length;
      if (!options.show) return;
      const files = new Set(answer.errors.map((e) => e.file));
      for (const [file, s] of shown) {
        if (files.has(file)) continue;
        notices.dismiss(s.id);
        shown.delete(file);
      }
      for (const e of answer.errors) {
        const text = codeText(e, answer.held);
        const actions = [openAction(`Open ${codeWhere(e)} in the Code card`, () => options.open(e.file, Math.max(1, e.line), Math.max(1, e.col)))];
        // A throw the probe page saw: the person may know better (a module that throws there alone).
        if (e.evaluated && options.unhold) actions.push({ mcp: 'ui', label: 'Reload anyway', title: 'Let the held page reload go, though this module threw as the probe page evaluated it', run: options.unhold });
        const what = `${codeWhere(e)} ${e.evaluated ? 'threw' : 'broken'} ${e.message}`;
        const was = shown.get(e.file);
        if (was && was.break === what) {
          // The same break: its words in place (the held list changed); dismissed, it stays so.
          if (notices.list.some((n) => n.id === was.id && n.text !== text)) notices.update(was.id, text, actions, e.stack);
          continue;
        }
        if (was) notices.dismiss(was.id);
        shown.set(e.file, { id: notices.add('code', text, undefined, actions, e.stack).id, break: what });
      }
    },
    get broken() {
      return broken;
    },
    say(kind, text, error) {
      notices.add(kind, text, error);
      if ((kind === 'frame' || kind === 'swap') && error instanceof Error && typeof error.stack === 'string') place(kind, text, error as Error & { stack: string });
    },
    clear(kind) {
      cleared.set(kind, (cleared.get(kind) ?? 0) + 1);
      notices.clear(kind);
    },
  };
}
