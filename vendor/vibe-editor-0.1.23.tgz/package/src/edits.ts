/**
 * The entity tool's edits of the world, each one world step called for what it
 * did: a prefab's instance or an Empty made -- the tree's Create menu, where the
 * camera looks; a prefab or a model dropped from the Assets panel, where it is
 * dropped; a material dropped on an entity, worn by it --
 * the selection duplicated, destroyed, copied and pasted, hidden or switched
 * off (`switches.ts`), and an entity moved in the tree. What starts them, the
 * menus, keys and buttons, is `entities.ts`'s.
 *
 * - **Made from the prefabs, as the game makes them** (`spawn.ts`, `clip.ts`):
 *   an instance, drawn and sized as its file says; a copy of an instance is an
 *   instance (Docs/prefabs.md §7).
 * - **Copy goes onto the clipboard** as well as into the tool's own buffer. With
 *   nothing copied in this page, Paste reads the clipboard: the button through
 *   `navigator.clipboard`, which the browser may ask the person to allow, and
 *   Mod+V as the browser's own paste, heard as a `paste` event, which asks
 *   nothing. Once the page has lost the focus since a Copy that reached the
 *   clipboard, Mod+V is the browser's paste again: something copied in another
 *   tab meanwhile is what is pasted, and the clip copied here only if the
 *   clipboard still holds it.
 */
import * as THREE from 'three';
import { keyLabel } from '@vibe/engine/debug';
import { Camera, type Entity, Hierarchy, isTyping, label, NONE, prefabFiles, untypedPrefab as prefab, type World } from '@vibe/engine';
import { Assets } from '@vibe/engine/assets';
import { inFront, MAIN_SAID, mainCameraCode, makeCamera, setMainCamera } from './camera-entity.ts';
import { copyRootsOf, readClip, type Clip } from './clip.ts';
import { copyHere, pasteHere } from './paste.ts';
import { flipAll } from './multi.ts';
import { moveRowsInPlace } from './reparent.ts';
import { snapping } from './prefs.ts';
import { skippedText } from './skipped.ts';
import { localAt, nestedKeys, openedParent } from './opened.ts';
import { carriesMaterial, carriesModel, carriesPlaceable, droppedChoice, droppedMaterial, droppedModel, droppedPrefab, placeAt, wearMaterial } from './prefab-drop.ts';
import { duplicate, modelSpawn, spawnAt, spawnLabel, type Spawnable } from './spawn.ts';
import { SWITCHES, switchStep, type Switch } from './switches.ts';
import type { Selection } from './selection.ts';
import type { EditorContext } from './tool.ts';
import type { Tree } from './tree.ts';
import { tabKey } from './editor-keys.ts';

/** The chord Paste is on: said where the button's read of the clipboard waits on the browser. */
export const PASTE = tabKey('paste');

export interface EditsHost {
  /** A structural edit queued: flushed, the tree and the inspector read again, one step called `label`. */
  changed(label: string): void;
  /** One world step called `label`, the other tools told. */
  commit(label: string): void;
  /** One thing at a time: a pick under way stops, quietly. */
  stopPick(): void;
  /** Is the tool up: a paste that comes late -- the editor put away meanwhile -- is dropped. */
  visible(): boolean;
}

export interface Edits {
  /** Was anything copied in this page: Mod+V is then MrDebug's, not the browser's. */
  readonly copied: boolean;
  /**
   * One of `what` where the camera looks, selected, one step `Spawn crates/big`:
   * the tree's Create menu. Right-clicked on `on`, a row, it is that row's child;
   * on the empty list (NONE), a root. In an opened prefab, under its root or
   * the row if it is the prefab's (`openedParent`): never beside the root.
   */
  create(what: Spawnable, on: Entity): void;
  /**
   * Create ▸ Camera: a camera entity in front of the editor's view, looking
   * along it -- `main` on when the scene has no main camera -- named `Camera`
   * (numbered), selected, one step `Create Camera`. Where it goes as `create`.
   */
  createCamera(on: Entity): void;
  /** A copy of the selected entity, where it is, selected. */
  duplicate(): void;
  /** Every selected entity destroyed, and everything under them. */
  destroy(): void;
  /**
   * `Hidden` or `Disabled` on every one of `es` -- or, when all have it, off
   * every one: one step, `Hide 3`, `Enable`. An ancestor's is not theirs to
   * take off: they stay under it.
   */
  toggle(which: Switch, es: readonly Entity[]): void;
  /** The selection, each with everything under it: into the buffer, and onto the clipboard if it will take it. */
  copy(): void;
  /** What was copied, round where the last one was placed or the middle of the view; with nothing copied here, the clipboard. */
  paste(): Promise<void>;
  /** `children` under `parent`, last, in the tree's order; NONE for none -- roots, last of the roots. One step. */
  reparent(children: readonly Entity[], parent: Entity): void;
  /**
   * `children` among `parent`'s children, in front of `before` -- NONE for
   * last -- together, in the tree's order. Under NONE, roots, among the roots
   * (Docs/ecs.md §8). One step.
   */
  reorder(children: readonly Entity[], parent: Entity, before: Entity): void;
  /**
   * A prefab dragged from the Assets tool and dropped (`prefab-drop.ts`): under
   * `parent` at its origin, in front of `before` (NONE, last) -- a drop on a
   * tree row's middle, or on the line between rows; beside a root, where the
   * camera looks -- or, with neither, on the ground under the pointer, or where
   * the camera looks if it is above the horizon. One step, `Spawn <key>`. Also
   * how a drop on the scene's canvas places one, while this tool is up.
   */
  placeDropped(event: DragEvent, parent: Entity, before?: Entity): void;
  /**
   * A material dragged from the Assets tool and dropped on `e` -- its tree row,
   * or the entity drawn under the pointer on the scene (NONE: none there) --
   * worn by it: its `Render.material`, one step `Set Render.material`, `e`
   * selected. One with no `Render` refuses, saying so.
   */
  wearDropped(event: DragEvent, e: Entity): void;
  /** Another world: what was copied no longer from this one. */
  reset(): void;
  dispose(): void;
}

/** What a step that makes or changes one entity needs: the world, the selection, and the world's history. */
export interface StepHost {
  world: World;
  selection: Selection;
  /** One world step called `label`, the other tools told. */
  commit(label: string): void;
}

/**
 * `e` made or changed: the world flushed, `e` selected, one world step called
 * `label`. The one way an edit here that makes something ends -- Create, a
 * drop, a paste, Create ▸ Camera, the notice's Add a main camera and Make
 * <name> main.
 */
export function madeStep(host: StepHost, e: Entity, label: string): void {
  host.world.flush();
  host.selection.choose(e);
  host.commit(label);
}

/** The orthographic size a camera made from the built-in one starts with -- which has none of its own: `Camera`'s default. */
export const BUILT_IN_SIZE = Camera.schema.size.initial;

/**
 * Add a main camera (the no-main-camera notice's, `camera-notice.ts`): a
 * camera entity where the built-in camera is now -- what the game draws
 * through while it has no main one -- `main` on, its field of view; selected,
 * one step. NONE, nothing made, if the world is full. The built-in camera has
 * no parent: its own position and rotation are the world's.
 */
export function addMainCamera(host: StepHost, built: THREE.PerspectiveCamera): Entity {
  const e = makeCamera(host.world, {
    position: [built.position.x, built.position.y, built.position.z],
    rotation: [built.quaternion.x, built.quaternion.y, built.quaternion.z, built.quaternion.w],
    main: true,
    lens: { projection: 0, fov: built.fov, size: BUILT_IN_SIZE },
  });
  if (e !== NONE) madeStep(host, e, 'Add a main camera');
  return e;
}

/** Make <name> main (the notice's): `e`'s `main` ticked and every other camera's off (`setMainCamera`), selected, one step. */
export function makeMainCamera(host: StepHost, e: Entity): void {
  if (!host.world.alive(e) || !host.world.has(e, Camera)) return;
  setMainCamera(host.world, e);
  madeStep(host, e, 'Set Camera.main');
}

const many = (n: number): string => `${n} ${n === 1 ? 'entity' : 'entities'}`;

export function createEdits(ctx: EditorContext, tree: Tree, host: EditsHost): Edits {
  const { game, world, selection, viewport } = ctx;
  const canvas = game.renderer.domElement;
  /** Where the last one was placed: where a paste goes, while it is in view. */
  let placedAt: THREE.Vector3 | null = null;
  /**
   * What Copy took -- stamped with the world it came from (`paste.ts`' `worldId`), so its refs out are kept only while
   * that is still the world; its text, as written onto the clipboard (`board`: it took it); and `away`: the page lost
   * the focus since, so the clipboard may hold something copied elsewhere -- Mod+V is then the browser's paste, and this
   * clip only if it is still that.
   */
  let copied: { clip: Clip; text: string; board: boolean; away: boolean } | null = null;
  /** The clipboard being read for Paste: the browser may be asking the person. */
  let reading = false;

  // ---------------------------------------------------------------- making

  /**
   * Where what is made now goes, given `wanted` -- the row it was asked on, or
   * NONE: in an opened prefab, under its root or that entity if it is the
   * prefab's (`openedParent`) -- beside the root it would be in no prefab, and
   * Save refuses that; in the scene, `wanted` itself, NONE a root.
   */
  const madeUnder = (wanted: Entity): Entity => (ctx.prefab === null ? wanted : openedParent(world, ctx.prefabRoot, wanted === NONE ? [] : [wanted]));

  /** One of `what` made where `at` is in the world: under `parent` in its space when there is one, else a root there. */
  function makeAt(what: Spawnable, at: { x: number; y: number; z: number }, parent: Entity): Entity {
    if (parent === NONE || !world.alive(parent)) return spawnAt(world, what, at);
    const e = spawnAt(world, what, localAt(world, parent, at));
    if (e === NONE) return NONE;
    world.setParent(e, parent);
    tree.unfold([parent]);
    return e;
  }

  /** The pointer over the ground, as the gizmo snaps: on the move step while snapping is on, Ctrl or Cmd turning it over. */
  const ground = new THREE.Vector3();
  function groundUnder(pointer: PointerEvent): THREE.Vector3 | null {
    const at = viewport.groundAt(pointer.clientX, pointer.clientY, ground);
    if (!at) return null;
    if (snapping(viewport.snap.on, pointer.ctrlKey || pointer.metaKey)) {
      const step = viewport.snap.move;
      at.x = Math.round(at.x / step) * step;
      at.z = Math.round(at.z / step) * step;
    }
    return at;
  }

  /**
   * An Apply's undo or redo landing (`holding`): its world would be loaded
   * over anything made now, so nothing is -- said on the tree's line. True if so.
   */
  function held(what = 'Not placed'): boolean {
    const line = ctx.overrides.holding();
    if (line !== null) tree.say(`${what}: ${line}`);
    return line !== null;
  }

  function create(what: Spawnable, on: Entity): void {
    if (held('Not made')) return;
    host.stopPick();
    const parent = madeUnder(world.alive(on) ? on : NONE);
    const e = makeAt(what, viewport.lookAt(), parent);
    if (e === NONE) return tree.say('Not made: the world is full', true);
    made(e, `Spawn ${spawnLabel(what)}`);
  }

  function createCamera(on: Entity): void {
    if (held('Not made')) return;
    host.stopPick();
    const view = viewport.view();
    // No main camera yet: this one is, so the game draws through it.
    const main = mainCameraCode(world) !== MAIN_SAID;
    const e = makeCamera(world, { position: inFront(view), rotation: view.quaternion, main, parent: madeUnder(world.alive(on) ? on : NONE) });
    if (e === NONE) return tree.say('Not made: the world is full', true);
    const parent = world.store(Hierarchy).parent[e]! as Entity;
    if (parent !== NONE) tree.unfold([parent]);
    made(e, 'Create Camera');
  }

  /** Is `key` a model the asset store holds now: what a model's drop places. */
  const isModel = (key: string): boolean => Assets.modelKeys().includes(key.toLowerCase());

  function placeDropped(event: DragEvent, parent: Entity, before?: Entity): void {
    if (held()) return;
    const dropped = droppedPrefab(event);
    // A model's file: an entity of its own drawn as it, placed where a prefab's instance would be.
    const model = dropped ? null : droppedModel(event, isModel);
    if (!dropped && !model) return tree.say(`Not placed: that is no ${carriesModel(event) ? 'model loaded' : 'prefab compiled'} now`, true);
    // In an opened prefab, never the prefab open, nor one nesting it: saved, it would be inside itself.
    const open = ctx.prefab;
    if (dropped && open !== null && nestedKeys(dropped.key, prefabFiles()).includes(open)) {
      return tree.say(`Not placed: ${dropped.key === open ? `${open} is the prefab open` : `${dropped.key} nests ${open}, the prefab open`} -- saved, it would be inside itself`, true);
    }
    // Dragged from the Assets panel: what was made is the world's step, so the keys and Z are the world's side's now.
    ctx.focus();
    // On the scene or the empty list, where the pointer is; on a row or between rows, where the camera looks.
    const free = parent === NONE && before === undefined;
    const at = free ? (groundUnder(event as unknown as PointerEvent) ?? viewport.lookAt()) : viewport.lookAt();
    // In an opened prefab: on the scene, under its root or the selected entity of it; beside its root, under the root.
    const under = free ? (ctx.prefab === null ? NONE : openedParent(world, ctx.prefabRoot, selection.list)) : parent === NONE ? madeUnder(NONE) : parent;
    // A prefab's instance or a model's entity, the same way: under a row, or beside one, at its parent's origin, in
    // its place among the children; else at `at`, in the space of the parent it is made under.
    const what = model ? modelSpawn(model.key) : prefab(dropped!.key);
    const e = free || under === NONE ? makeAt(what, at, under) : placeAt(world, what, at, under, false, before ?? NONE);
    if (e === NONE) return tree.say('Not placed: the world is full');
    // On the line between two roots: a root there, among them.
    if (!free && under === NONE && before !== undefined && before !== NONE) world.setParent(e, NONE, before);
    if (under === NONE) placedAt = at.clone();
    else tree.unfold([under]);
    const { key, more } = (dropped ?? model)!;
    made(e, `Spawn ${key}`);
    if (more > 0) tree.say(`Placed ${key}; a drop places one ${model ? 'model' : 'prefab'} -- the other ${more} not`);
  }

  function wearDropped(event: DragEvent, e: Entity): void {
    if (held('Not worn')) return;
    const dropped = droppedMaterial(event, (key) => Assets.materialIfPresent(key) !== null);
    if (!dropped) return tree.say('Not worn: that is no material compiled now', true);
    if (e === NONE || !world.alive(e)) return tree.say('Not worn: drop a material on an entity drawn in the scene, or on its row in the tree', true);
    const no = wearMaterial(world, e, dropped.key, label(world, e));
    if (no !== null) return tree.say(`Not worn: ${no}`, true);
    // Dragged from the Assets panel: the step is the world's, so the keys and Z are the world's side's now. Nothing is
    // chosen for it: the selection and the right panel stay as they were (the Render block shown follows, if it is this one).
    ctx.focus();
    const chooses = droppedChoice('worn', e);
    if (chooses !== NONE) selection.choose(chooses);
    host.changed('Set Render.material');
    if (dropped.more > 0) tree.say(`${label(world, e)} wears ${dropped.key}; a drop puts on one material -- the other ${dropped.more} not`);
  }

  // A prefab or a model dragged onto the scene while this tool is up: placed on the ground there. A material: worn by
  // the entity drawn under the pointer -- over none, the drop is refused.
  const overScene = (event: DragEvent): void => {
    if (!host.visible()) return;
    if (carriesMaterial(event)) {
      const on = viewport.entityAt(event.clientX, event.clientY) !== NONE;
      if (on) event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = on ? 'copy' : 'none';
      return;
    }
    if (!carriesPlaceable(event)) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
  };
  const dropOnScene = (event: DragEvent): void => {
    if (!host.visible()) return;
    if (carriesMaterial(event)) {
      event.preventDefault();
      return wearDropped(event, viewport.entityAt(event.clientX, event.clientY));
    }
    if (!carriesPlaceable(event)) return;
    event.preventDefault();
    placeDropped(event, NONE);
  };
  canvas.addEventListener('dragover', overScene);
  canvas.addEventListener('drop', dropOnScene);

  /**
   * `children` -- each alive, not under another of them, and not `parent` nor
   * above it, which would be a cycle the world refuses loudly -- under
   * `parent` in front of `before` (NONE, last), in the tree's order, so they
   * land together as they were. One step: `Reorder` where each was under
   * `parent` already (`beside`: dropped on the line), else `Reparent`, or
   * `Unparent` to the roots; with a count for several.
   */
  function reorder(children: readonly Entity[], parent: Entity, before: Entity, beside: boolean): void {
    // Each where it is in the world: its Transform landed in the new parent's space (`reparent.ts`).
    const moving = moveRowsInPlace(world, children, parent, before);
    if (moving.length === 0) return;
    // Read before the flush: where they were.
    const links = world.store(Hierarchy);
    const already = moving.every((c) => links.parent[c] === parent);
    tree.unfold([parent]);
    const what = already && (beside || parent === NONE) ? 'Reorder' : parent === NONE ? 'Unparent' : 'Reparent';
    host.changed(moving.length > 1 ? `${what} ${moving.length}` : what);
  }

  /** `e` made: in the world, to be selected, and one step. */
  const steps: StepHost = { world, selection, commit: (label) => host.commit(label) };
  const made = (e: Entity, label: string): void => madeStep(steps, e, label);

  // ---------------------------------------------------------------- copy and paste

  function copy(): void {
    // In the tree's order, so they paste in it: last of the roots, one after another.
    const roots = copyRootsOf(world, selection.list);
    if (roots.length === 0) return tree.say('Nothing selected to copy.');
    const clip = copyHere(world, roots);
    const text = JSON.stringify(clip);
    const mine = { clip, text, board: false, away: false };
    copied = mine;
    const n = many(clip.entities.length);
    tree.say(`Copied ${n}`);
    // Refused in a tab without the focus, or a page that is not allowed to: Paste here has them all the same.
    navigator.clipboard?.writeText(text).then(
      () => {
        mine.board = true;
        tree.say(`Copied ${n}, onto the clipboard too`);
      },
      () => tree.say(`Copied ${n} for Paste here; the clipboard would not take them`),
    );
  }

  /**
   * Paste, the button: with nothing copied in this page, the clipboard -- read
   * in the click that asked, which the browser may want the person to allow
   * first; one read at a time, or a second click waiting on the same question
   * would paste twice once it is answered.
   */
  async function paste(): Promise<void> {
    if (copied && !copied.away) return pasteClip(copied.clip);
    if (reading) return;
    reading = true;
    // The browser may ask the person first, and wait for the answer: said meanwhile, with the way that asks nothing.
    tree.say(`Reading the clipboard… the browser may ask to allow it first (${keyLabel(PASTE)} never asks)`);
    let text: string;
    try {
      text = await navigator.clipboard.readText();
    } catch (err) {
      // Copied here before the page lost the focus: that, as the clipboard cannot say otherwise.
      if (copied) return pasteClip(copied.clip);
      return tree.say(`Nothing copied here, and the clipboard could not be read: ${err instanceof Error ? err.message : String(err)}`, true);
    } finally {
      reading = false;
    }
    pasteText(text);
  }

  /** Text off the clipboard, pasted if it is entities copied in the editor; said if it is not. */
  function pasteText(text: string): void {
    // Still what was copied here: pasted as that; else something copied elsewhere since, which wins.
    if (copied?.away) {
      if (text === copied.text) {
        copied.away = false;
        return pasteClip(copied.clip);
      }
      copied = null;
    }
    const read = readClip(text);
    if (typeof read === 'string') return tree.say(`Nothing to paste: ${read}.`, true);
    pasteClip(read);
  }

  /**
   * The browser's own paste. Mod+V is MrDebug's only while something was copied
   * in this page (its `when`); with nothing, it is the browser's, which pastes
   * -- and what it pastes comes here, as `clipboardData`, which needs no
   * permission, where reading the clipboard does. Not into a field: that paste
   * is the field's.
   */
  const onPaste = (event: ClipboardEvent): void => {
    if (!host.visible() || ctx.playing || (copied && !copied.away) || isTyping(event.target)) return;
    const text = event.clipboardData?.getData('text/plain');
    if (text === undefined) return;
    event.preventDefault();
    pasteText(text);
  };
  document.addEventListener('paste', onPaste);
  /** The page lost the focus: another tab or app may copy meanwhile, so the next Mod+V asks the clipboard (`copied.away`). */
  const onBlur = (): void => {
    if (copied?.board) copied.away = true;
  };
  addEventListener('blur', onBlur);

  /**
   * `clip` made in the world, round where the last one was placed or the middle of the view -- through `pasteHere`, as
   * `scene_paste` makes it: its refs out kept if it came from this world, under the opened prefab's root with one open.
   */
  function pasteClip(clip: Clip): void {
    // The editor put away, or a playtest begun, while the clipboard was read: not now.
    if (!host.visible() || ctx.playing) return;
    // Every paste comes here -- the key, the button, the browser's own (`onPaste`): held at its front door, not by the guard.
    if (held('Not pasted')) return;
    host.stopPick();
    const at = placedAt && viewport.sees(placedAt) ? placedAt : viewport.lookAt();
    const done = pasteHere(world, clip, at, ctx.prefab === null ? NONE : ctx.prefabRoot);
    tree.unfold(done.all);
    selection.chooseAll(done.roots);
    const n = done.all.length;
    host.commit(n === 1 ? 'Paste' : `Paste ${n}`);
    tree.say(`Pasted ${many(n)}${skippedText(done.skipped)}`, n === 0);
  }

  return {
    get copied() {
      return copied !== null && !copied.away;
    },
    create,
    createCamera,
    duplicate() {
      const e = selection.primary;
      if (e === NONE) return;
      host.stopPick();
      made(duplicate(world, e), 'Duplicate');
    },
    destroy() {
      const all = selection.list;
      if (all.length === 0) return;
      host.stopPick();
      // One under another goes with it either way: destroying it twice is nothing.
      for (const e of all) world.destroy(e);
      host.changed(all.length > 1 ? `Destroy ${all.length}` : 'Destroy');
    },
    toggle(which, es) {
      const { tag } = SWITCHES[which];
      const live = es.filter((e) => world.alive(e));
      if (live.length === 0) return;
      host.stopPick();
      const on = flipAll(live.map((e) => world.has(e, tag)));
      const flipped = live.filter((e) => world.has(e, tag) !== on);
      for (const e of flipped) {
        if (on) world.add(e, tag);
        else world.remove(e, tag);
      }
      host.changed(switchStep(which, on, flipped.length));
    },
    copy,
    paste,
    reparent(children, parent) {
      reorder(children, parent, NONE, false);
    },
    reorder(children, parent, before) {
      reorder(children, parent, before, true);
    },
    placeDropped,
    wearDropped,
    reset() {
      // What was copied came from the world before: its stamp says so (`paste.ts`), its refs out not kept.
      placedAt = null;
    },
    dispose() {
      document.removeEventListener('paste', onPaste);
      removeEventListener('blur', onBlur);
      canvas.removeEventListener('dragover', overScene);
      canvas.removeEventListener('drop', dropOnScene);
    },
  };
}
