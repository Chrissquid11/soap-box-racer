/**
 * The game view's presets (Docs/game-view.md §4, D5-D6): what the play strip's dropdown, Config ▸ Editor ▸ Game view
 * and the `game_view_*` tools choose from, and the engine's resolution each one is (`Game.setResolution`).
 *
 * - **Free Aspect first**, the default: the room as it is. Then the built-ins -- the aspects (Fit only) and four
 *   resolutions -- then the project's own, made in the dropdown's "Add…" or by `game_view_preset`.
 * - **A preset is known by its name**, unique among them all: a built-in's is its words ("16:9", "320×180 Pixel").
 * - **An editor preview only** (D4): it shapes the frame while the game's own cameras draw -- a playtest, or the
 *   stopped scene's Game look -- never a release build.
 * - **Kept per project** (`prefs.ts`' `gameView`, among `PROJECT_PREFS`): the presets made and the one chosen.
 *
 * Pure: node tests it (`game-view.test.ts`).
 */
import type { GameResolution } from '@vibe/engine';

export type ScaleMode = 'fit' | 'pixel' | 'stretch';
export type ScaleFilter = 'nearest' | 'linear';
export const SCALE_MODES: readonly ScaleMode[] = ['fit', 'pixel', 'stretch'];
export const SCALE_FILTERS: readonly ScaleFilter[] = ['nearest', 'linear'];

/**
 * A preset: exactly `width` × `height` pixels (`exact`), or an aspect alone (`width`:`height`, Fit only); how it is
 * scaled, and for Stretch its filter (Pixel's is always nearest, Fit's unused).
 */
export interface GamePreset {
  name: string;
  width: number;
  height: number;
  exact: boolean;
  mode: ScaleMode;
  filter: ScaleFilter;
}

/** Free Aspect: the room as it is, no resolution. */
export const FREE = 'Free Aspect';

const aspect = (w: number, h: number): GamePreset => ({ name: `${w}:${h}`, width: w, height: h, exact: false, mode: 'fit', filter: 'linear' });
const exact = (w: number, h: number, mode: ScaleMode, filter: ScaleFilter = 'linear'): GamePreset => ({ name: presetWords(w, h, true, mode, filter), width: w, height: h, exact: true, mode, filter });

/** The built-ins, after Free Aspect: Unity's aspects, then four resolutions -- Fit at full sharpness, and the two scaled. */
export const BUILT_IN: readonly GamePreset[] = [
  aspect(16, 9), aspect(16, 10), aspect(4, 3), aspect(21, 9), aspect(9, 16),
  exact(1920, 1080, 'fit'), exact(1280, 720, 'fit'), exact(640, 360, 'stretch', 'linear'), exact(320, 180, 'pixel', 'nearest'),
];

/** The most presets a project keeps. */
export const PRESETS_MAX = 32;
/** The largest side an exact preset may have: a target that size is all a GPU should be asked for. */
export const SIDE_MAX = 8192;

/** A preset's size and scaling in words: `16:9`, `1920×1080`, `320×180 Pixel`, `640×360 Stretch`, `640×360 Stretch nearest`. */
export function presetWords(width: number, height: number, isExact: boolean, mode: ScaleMode, filter: ScaleFilter): string {
  if (!isExact) return `${width}:${height}`;
  const size = `${width}×${height}`;
  if (mode === 'fit') return size;
  if (mode === 'pixel') return `${size} Pixel`;
  return filter === 'linear' ? `${size} Stretch` : `${size} Stretch nearest`;
}

/** The engine's resolution for a preset, or null for Free Aspect (none). */
export function resolutionOf(p: GamePreset | null): GameResolution | null {
  if (p === null) return null;
  if (!p.exact) return { aspect: p.width / p.height, mode: 'fit' };
  return { width: p.width, height: p.height, mode: p.mode, filter: p.mode === 'pixel' ? 'nearest' : p.filter };
}

/** Every preset in the dropdown's order: the built-ins, then the project's own. Free Aspect is none of them. */
export const allPresets = (own: readonly GamePreset[]): GamePreset[] => [...BUILT_IN, ...own];

/** The preset of that name (any case), or null: Free Aspect, or a name no preset has. */
export function presetNamed(own: readonly GamePreset[], name: string): GamePreset | null {
  const low = name.trim().toLowerCase();
  return allPresets(own).find((p) => p.name.toLowerCase() === low) ?? null;
}

/**
 * A size as a person writes it, or why not: `16:9` an aspect, `1920x1080` (or `×`, `*`, spaces) exact pixels.
 * Whole numbers from 1; an exact side at most `SIDE_MAX`.
 */
export function parseSize(text: string): { width: number; height: number; exact: boolean } | string {
  const m = /^\s*(\d+)\s*([:x×*])\s*(\d+)\s*$/i.exec(text);
  if (!m) return 'a size is an aspect, 16:9, or pixels, 1920x1080';
  const width = Number(m[1]);
  const height = Number(m[3]);
  const isExact = m[2] !== ':';
  if (width < 1 || height < 1) return 'each side at least 1';
  if (isExact && (width > SIDE_MAX || height > SIDE_MAX)) return `each side at most ${SIDE_MAX} pixels`;
  if (!isExact && (width > 1000 || height > 1000)) return 'an aspect\'s numbers at most 1000';
  return { width, height, exact: isExact };
}

/** A preset as asked for -- by the "Add…" dialog, the Config page or `game_view_preset` -- checked: the preset, or why not. */
export interface PresetAsk {
  name?: string;
  size: string;
  mode?: ScaleMode;
  filter?: ScaleFilter;
}

/**
 * `ask` made a preset among `own` (the one called `replacing` taken out first, a change of it): the preset, or why
 * not. No name -- or, for a change, the old one unchanged where it was the old size and scaling in words -- its size
 * and scaling in words. An aspect is Fit only; a name taken -- Free Aspect's, a built-in's,
 * another of the project's -- is refused.
 */
export function presetFrom(ask: PresetAsk, own: readonly GamePreset[], replacing: string | null = null): GamePreset | string {
  const size = parseSize(ask.size);
  if (typeof size === 'string') return size;
  const mode = ask.mode ?? 'fit';
  if (!SCALE_MODES.includes(mode)) return 'mode is fit, pixel or stretch';
  // Pixel's is always nearest, whatever it is asked: a change to Pixel keeps no Stretch's filter.
  const filter = mode === 'pixel' ? 'nearest' : ask.filter ?? 'linear';
  if (!SCALE_FILTERS.includes(filter)) return 'filter is nearest or linear';
  if (!size.exact && mode !== 'fit') return 'an aspect alone is Fit only: give it pixels (640x360) to draw it Pixel or Stretch';
  // A name that was only the old preset's words is no name of the person's: it follows the new size and mode.
  const old = replacing === null ? undefined : own.find((p) => p.name === replacing);
  const given = (ask.name ?? '').trim();
  const auto = old !== undefined && old.name === presetWords(old.width, old.height, old.exact, old.mode, old.filter) && given === old.name;
  const name = (auto ? '' : given) || presetWords(size.width, size.height, size.exact, mode, filter);
  if (name.length > 40) return 'a name of at most 40 characters';
  const low = name.toLowerCase();
  const others = own.filter((p) => p.name !== replacing);
  if (low === FREE.toLowerCase() || BUILT_IN.some((p) => p.name.toLowerCase() === low) || others.some((p) => p.name.toLowerCase() === low)) return `a preset is called ${name} already`;
  return { name, width: size.width, height: size.height, exact: size.exact, mode, filter };
}

/** The project's presets as kept, read: each checked, anything odd dropped, a name twice kept once. */
export function readPresets(data: unknown): GamePreset[] {
  if (!Array.isArray(data)) return [];
  const kept: GamePreset[] = [];
  for (const one of data.slice(0, PRESETS_MAX)) {
    const p = one as Partial<GamePreset> | null;
    if (typeof p !== 'object' || p === null || typeof p.name !== 'string') continue;
    if (typeof p.width !== 'number' || typeof p.height !== 'number') continue;
    const made = presetFrom({ name: p.name, size: `${p.width}${p.exact === true ? 'x' : ':'}${p.height}`, mode: p.mode, filter: p.filter }, kept);
    if (typeof made !== 'string') kept.push(made);
  }
  return kept;
}

/** A size as a person writes it, and as `parseSize` reads it: `16:9` or `640x360`. */
export const sizeText = (p: GamePreset): string => `${p.width}${p.exact ? 'x' : ':'}${p.height}`;

/** A preset as `game_view_state` lists it: its name, its size in words (none for Free Aspect), mode, filter, the project's or not. */
export interface PresetRow {
  name: string;
  size: string | null;
  mode: ScaleMode;
  filter: ScaleFilter;
  own: boolean;
}

/** Every preset as `game_view_state` lists it, in the dropdown's order: Free Aspect, the built-ins, the project's `own`. */
export function presetRows(own: readonly GamePreset[]): PresetRow[] {
  return [
    { name: FREE, size: null, mode: 'fit', filter: 'linear', own: false },
    ...BUILT_IN.map((p) => ({ name: p.name, size: sizeText(p), mode: p.mode, filter: p.filter, own: false })),
    ...own.map((p) => ({ name: p.name, size: sizeText(p), mode: p.mode, filter: p.filter, own: true })),
  ];
}

/** The size of a box in words for the dropdown's foot: `640×360` in CSS pixels, and Pixel's scale, `×3` -- device pixels per game pixel (`Game.scale`). */
export function boxWords(box: { width: number; height: number }, pixels: { width: number; height: number }, scale: number, p: GamePreset | null): string {
  // A Pixel box at a fractional pixel ratio is a fraction of a CSS pixel (`fitBox`): its CSS size said whole.
  const size = `${Math.round(box.width)}×${Math.round(box.height)}`;
  if (!p || !p.exact || p.mode === 'fit') return size;
  const by = Number.isInteger(scale) ? `×${scale}` : `×${scale.toFixed(2)}`;
  return `${size} · ${pixels.width}×${pixels.height} ${by}`;
}
