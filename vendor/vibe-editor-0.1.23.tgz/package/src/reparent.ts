/**
 * Reparenting in place (Docs/ecs.md §13): an entity moved under another parent
 * in the tree -- dragged onto a row, between rows, to the roots, Unparent,
 * `scene_reparent` -- keeps where it is in the world, as Unity's default does.
 * Its new local `Transform` is the new parent's world pose undone over its own:
 * `toLocal(newParent, toWorld(oldParent, local))` (`gesture.ts`). Node-safe:
 * the world and the maths, no DOM.
 *
 * - **Never through the 32-bit world**: each parent's world pose is composed
 *   here from the `Transform`s up its chain in doubles, not read from
 *   `WorldTransform`, whose 32 bits would put a bit or two of noise into what
 *   did not move. What comes out is then settled, channel by channel, against
 *   the local value it had -- and, on an instance's entity, its prefab's -- by
 *   gesture.ts' rule (`settled`, `sameRotation`): a value only float noise away
 *   from one of them is that one, to the bit. So a move between two parents at
 *   the same pose writes nothing new, a move there and back ends as it began,
 *   and an instance gains no override from noise.
 * - **The nearest, under a non-uniform scale**: a parent scaled unevenly with
 *   its child turned against it would skew the child, which a `Transform` (no
 *   skew) cannot hold; the scale goes along the child's own axes, as gesture.ts
 *   scales. A parent scaled to 0 on an axis, the old or the new, keeps its
 *   child's local numbers: into it there is no inverse, and out of it the 0
 *   would be baked into the child's own scale and its position flattened.
 * - **Each once**: rows moved together each keep their own world pose; one under
 *   another of them goes with it, untouched (`moveRows`, as `movers`). One whose
 *   parent did not change (a reorder) is not written.
 */
import { type Entity, Hierarchy, NONE, Transform, type World } from '@vibe/engine';
import { moveRows } from './drop-zone.ts';
import { normalize, type Pose, POSE_FIELDS, type Quat, sameRotation, settled, settledRotation, toLocal, toWorld, type Vec3 } from './gesture.ts';
import { nodeValue } from './overrides-edit.ts';

type Columns = Record<(typeof POSE_FIELDS)[number], { [i: number]: number }>;

const IDENTITY: Pose = { p: [0, 0, 0], q: [0, 0, 0, 1], s: [1, 1, 1] };

/** `e`'s local `Transform` as a pose; the identity for none. */
export function localPose(world: World, e: Entity): Pose {
  if (!world.has(e, Transform)) return IDENTITY;
  const t = world.rawStore(Transform) as unknown as Columns;
  return { p: [t.px[e]!, t.py[e]!, t.pz[e]!], q: [t.qx[e]!, t.qy[e]!, t.qz[e]!, t.qw[e]!], s: [t.sx[e]!, t.sy[e]!, t.sz[e]!] };
}

/** `e`'s world pose, composed in doubles from the `Transform`s of it and every ancestor (one without, the identity); NONE, the identity. */
export function worldPose(world: World, e: Entity): Pose {
  const chain: Entity[] = [];
  const links = world.store(Hierarchy);
  for (let a = e; a !== NONE && chain.length < 4096; a = links.parent[a]! as Entity) chain.push(a);
  let pose = IDENTITY;
  for (let i = chain.length - 1; i >= 0; i--) pose = toWorld(pose, localPose(world, chain[i]!));
  return pose;
}

/** The first of `wanted` that `value` is only float noise from (next to `around`), or `value`. */
function settleTo(value: number, wanted: readonly (number | undefined)[], around: number): number {
  for (const w of wanted) {
    if (w === undefined) continue;
    const s = settled(value, w, around);
    if (s === w) return w;
  }
  return value;
}

const most = (...vs: readonly number[][]): number => {
  let m = 0;
  for (const v of vs) for (const x of v) m = Math.max(m, Math.abs(x));
  return m;
};

/**
 * The local pose that keeps a child where it is in the world, moved from under `from` to under `to` (each a world
 * pose; null, the roots): settled against `local`, the pose it had, then `prefab`, its prefab's, if it has one. Null
 * where either parent is scaled to 0 on an axis -- `to` has no inverse, and out of `from` the 0 would be baked into the
 * child's own scale and its position flattened for good: the child keeps its numbers.
 */
export function landedLocal(from: Pose | null, to: Pose | null, local: Pose, prefab: Pose | null = null): Pose | null {
  if ((from && from.s.includes(0)) || (to && to.s.includes(0))) return null;
  const inWorld = from ? toWorld(from, local) : local;
  const raw = to ? toLocal(to, inWorld) : inWorld;
  if (!raw || ![...raw.p, ...raw.q, ...raw.s].every(Number.isFinite)) return null;
  // Noise is relative to the largest number it came through: the parents' and the world's.
  const far = most(inWorld.p, from?.p ?? [], to?.p ?? [], local.p, raw.p);
  const big = most(inWorld.s, from?.s ?? [], to?.s ?? [], local.s, raw.s);
  const p = raw.p.map((v, i) => settleTo(v, [local.p[i], prefab?.p[i]], far)) as Vec3;
  const s = raw.s.map((v, i) => settleTo(v, [local.s[i], prefab?.s[i]], big)) as Vec3;
  // gesture.ts' rule, one place: the rotation it had, or its prefab's, to the bit; else each of the four settled against
  // the one it had, then against its prefab's (an axis the prefab leaves at 0 stays an exact 0).
  let q: Quat;
  if (prefab && !sameRotation(raw.q, local.q) && sameRotation(raw.q, prefab.q)) q = [...prefab.q];
  else {
    q = settledRotation(normalize(raw.q), local.q);
    if (prefab) {
      const side = q[0] * prefab.q[0] + q[1] * prefab.q[1] + q[2] * prefab.q[2] + q[3] * prefab.q[3] < 0 ? -1 : 1;
      q = q.map((v, i) => settleTo(v, [side * prefab.q[i]!], 1)) as Quat;
    }
  }
  return { p, q, s };
}

/** The pose `e`'s prefab gives it, if it is an instance's entity made by its prefab with a `Transform`; else null. */
function prefabPose(world: World, e: Entity): Pose | null {
  const root = world.instanceRoot(e);
  if (root === NONE) return null;
  const node = world.nodeOf(e);
  const compiled = world.prefabOf(root);
  if (!compiled || node < 0 || !compiled.kinds[node]?.components.includes(Transform)) return null;
  const v = POSE_FIELDS.map((f) => nodeValue(compiled, Transform, Transform.fields.findIndex((x) => x.name === f), node));
  return { p: [v[0]!, v[1]!, v[2]!], q: [v[3]!, v[4]!, v[5]!, v[6]!], s: [v[7]!, v[8]!, v[9]!] };
}

/** `pose` into `e`'s `Transform`, only the numbers that differ; true if any did. */
function writePose(world: World, e: Entity, pose: Pose): boolean {
  const t = world.rawStore(Transform) as unknown as Columns;
  const v = [...pose.p, ...pose.q, ...pose.s];
  let changed = false;
  for (let i = 0; i < POSE_FIELDS.length; i++) {
    const column = t[POSE_FIELDS[i]!];
    // The column's own rounding compared, not the double: a value the same once stored is not a change.
    if (Math.fround(v[i]!) === column[e]) continue;
    column[e] = v[i]!;
    changed = true;
  }
  if (changed) world.moved(e);
  return changed;
}

/**
 * `rows` under `parent` in front of `before`, as `moveRows` moves them -- each that changed parent keeping its world
 * pose (`keepWorld`, the default), its local `Transform` landed in the new parent's space. Those moved, in order.
 */
export function moveRowsInPlace(world: World, rows: readonly Entity[], parent: Entity, before: Entity, keepWorld = true): Entity[] {
  if (!keepWorld) return moveRows(world, rows, parent, before);
  const links = world.store(Hierarchy);
  // Where each was, before any moves: its old parent and that parent's world pose.
  const was = new Map<Entity, { parent: Entity; from: Pose | null }>();
  for (const e of rows) {
    if (!world.alive(e)) continue;
    const up = links.parent[e]! as Entity;
    was.set(e, { parent: up, from: up === NONE ? null : worldPose(world, up) });
  }
  const moving = moveRows(world, rows, parent, before);
  // The new parent is none of them nor under one: its pose is the same before and after.
  const to = parent === NONE ? null : worldPose(world, parent);
  for (const e of moving) {
    const old = was.get(e);
    if (!old || old.parent === parent || !world.has(e, Transform)) continue;
    const landed = landedLocal(old.from, to, localPose(world, e), prefabPose(world, e));
    if (landed) writePose(world, e, landed);
  }
  return moving;
}
