/**
 * The entity tree's columns (`tree.ts`, Docs/ecs.md §13): what each is called,
 * how wide it is, and the one grid the header and every row share, so the
 * columns line up down the list whichever are on. Pure, so node tests it.
 *
 * - **The name takes what is left** and cuts itself short; the id is as wide
 *   as the highest index needs; the prefab, the layer and the tags are as wide as
 *   their words, and give way -- the name never under `NAME_MIN` -- where the
 *   panel is too narrow for them all; labels and components share what is left
 *   with the name, which has twice their share.
 * - **Which are on is a preference** (`prefs.ts`, `columns`), ticked on the
 *   list under the tree's columns button: the id, the layer and the tags
 *   until then. The filter reads them all, shown or not.
 */
import { COLUMNS, type Column } from './prefs.ts';

/** What a column is called, in the header and on the chooser, and what it is, on hover there. */
export const COLUMN: Record<Column, { name: string; title: string }> = {
  id: { name: 'ID', title: 'Its index, #12: what the world numbers it by' },
  prefab: { name: 'Prefab', title: 'The prefab it is an instance of, and which entity of it: what the Create menu lists. None: entity' },
  labels: { name: 'Labels', title: 'Its labels, #spawn: free text for the filter and a game\'s own tools' },
  components: { name: 'Components', title: 'The components on it, as the game defines them' },
  layer: { name: 'Layer', title: 'Its layer: what systems and queries filter by. Chosen, the selection goes onto it, if the row is in it' },
  tags: { name: 'Tags', title: 'Its tags: what systems query by. Ticked, the selection has it, if the row is in it' },
};

/** The least the name is given, in pixels, however many columns are on: a caret and a few words. */
export const NAME_MIN = 100;
/** The name's share of what the others leave: twice a free column's. */
const NAME = `minmax(${NAME_MIN}px, 2fr)`;

/**
 * Every column's width but the id's, which follows the world (`idWidth`): as
 * wide as its words, given up first where there is no room -- the grid fills
 * those up to their widths before the name and the free ones share the rest --
 * or a share of what is left.
 */
const WIDTH: Record<Exclude<Column, 'id'>, string> = {
  prefab: 'minmax(0, 96px)',
  labels: 'minmax(0, 1fr)',
  components: 'minmax(0, 1fr)',
  layer: 'minmax(0, 66px)',
  tags: 'minmax(0, 74px)',
};

/**
 * The switches at the end of every row -- Claude's mark's slot (Docs/ai-panel.md D8, 14 px, empty unless its last turn
 * changed the entity), then the eye, the pointer and the power sign: drawn, picked, on -- in pixels.
 */
export const SWITCHES = 66;

/** The id's column, in pixels: as wide as the highest index the world has had needs, its `#` too. */
export const idWidth = (extent: number): number => 8 + 7 * String(Math.max(1, extent - 1)).length;

/** Those of `on` there are, in the order a row shows them, each once. */
export const inOrder = (on: readonly Column[]): Column[] => COLUMNS.filter((c) => on.includes(c));

/** `on` with `column` put in, or taken out if it is in: in order either way. */
export const flip = (on: readonly Column[], column: Column): Column[] =>
  inOrder(on.includes(column) ? on.filter((c) => c !== column) : [...on, column]);

/** The grid the header and every row share: the name, each column on in order, then the switches. */
export function grid(on: readonly Column[], extent: number): string {
  const widths = inOrder(on).map((c) => (c === 'id' ? `${idWidth(extent)}px` : WIDTH[c]));
  return [NAME, ...widths, `${SWITCHES}px`].join(' ');
}
