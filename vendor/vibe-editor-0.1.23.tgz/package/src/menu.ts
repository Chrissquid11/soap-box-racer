/**
 * A small menu card: the entity tool's right-click menu with its Create
 * submenus, the Assets tool's menus.
 *
 * - **Where it is asked for**: at a point on the page -- a right-click's -- or
 *   under a button, and kept on screen either way (`menu-place.ts`).
 * - **Its items are buttons**: a click runs one, and so do Enter and Space on
 *   one that has the focus, the browser's own. `run` is told which it was, so
 *   a menu can do something else for the keyboard.
 * - **An item may be a submenu** (`items`): marked ▸, it opens beside its item
 *   -- right of the card, or left at the window's edge -- as the pointer rests
 *   on it, on a click, or on → (`enter`) with the focus on it, its first item
 *   then focused; ← (`back`) closes the innermost and puts the focus back on
 *   its item. The pointer on another item of the card closes it. A pause
 *   before either, so a pointer on its way to a submenu across the items
 *   below its own does not close it.
 * - **Closed by whoever opened it**: Esc is that tool's (`holdsEscape`,
 *   `cancel`), never a key listener of the menu's own -- and the arrow keys
 *   that walk it (`step`, `enter`, `back`) are the tool's MrDebug actions. A
 *   press anywhere outside it, on the editor's cards or the scene, closes it
 *   too: a `pointerdown` on the editor's root and the canvas while it is open.
 */
import { MARGIN, placeAt, placeBeside, stepIndex } from './menu-place.ts';
import { control, el } from './shell.ts';
import type { Mcp } from './mcp/declare.ts';

export interface MenuItem {
  label: string;
  /**
   * The MCP tool that does what this entry does, `'ui'`, or why none does (`Mcp`, `mcp/declare.ts`). A submenu's
   * head, which runs nothing of its own, is `'ui'`.
   */
  mcp: Mcp;
  /** Hover text. */
  title?: string;
  /** A key that does the same, shown on the right. */
  key?: string;
  /** Red on hover: it destroys something. */
  danger?: boolean;
  /** A line above it: another group begins. */
  rule?: boolean;
  /** A submenu: these, beside it. An item with them runs nothing of its own. */
  items?: readonly MenuItem[];
  /** `byKey`: chosen with Enter or Space rather than clicked. The menu is closed first. */
  run?(byKey: boolean): void;
}

export interface MenuOptions {
  /** A line at the top, quieter than the items: what the menu is for. */
  title?: string;
  /** A line at the foot, as quiet: what the items leave as it is now (the game view's box and scale). */
  foot?: string;
  /** The first item focused: opened from the keyboard, so it goes on from there. */
  focus?: boolean;
  /**
   * How far down the page it may reach, in CSS pixels from the top: the card ends above it (and above the window's
   * foot, always), and scrolls past that -- the game view's menu kept out from under the cards below the scene's room.
   */
  bottom?: number;
}

export interface Menu {
  readonly open: boolean;
  /** Up at a point on the page, or under `at` (a button, which then toggles it rather than closing and opening it again). */
  show(at: { x: number; y: number } | HTMLElement, items: readonly MenuItem[], options?: MenuOptions): void;
  close(): void;
  /** The focus to the item `by` below the one that has it, in its own card, round from the end; the first if none has. */
  step(by: 1 | -1): void;
  /** →: the submenu of the item with the focus opened, its first item focused. */
  enter(): void;
  /** ←: the innermost submenu closed, the focus back on its item. */
  back(): void;
  dispose(): void;
}

/** The least a menu card is cut to before it scrolls, however little room: CSS pixels. */
const MIN_HEIGHT = 120;

/** How long the pointer rests on an item before its submenu opens, or another's closes: milliseconds. */
const REST_MS = 150;

/** One card of the menu: the first, or a submenu hanging from `from`, an item of the card before it. */
interface Level {
  card: HTMLElement;
  buttons: HTMLButtonElement[];
  items: readonly MenuItem[];
  from: HTMLButtonElement | null;
}

/** `root` is the editor's (the card goes in it), `canvas` the scene's: a press on either, outside the card, closes it. */
export function createMenu(root: HTMLElement, canvas: HTMLElement, closed?: () => void): Menu {
  let open = false;
  /** The button it hangs from, if it does: a press there is that button's to toggle with. */
  let anchor: HTMLElement | null = null;
  /** The first card, then each submenu open, innermost last. */
  let levels: Level[] = [];
  let rest: ReturnType<typeof setTimeout> | undefined;

  /** A press outside: the menu is done with. Capturing, so it is heard before whatever the press is for. */
  const outside = (event: PointerEvent): void => {
    const target = event.target as Node | null;
    if (target && (levels.some((l) => l.card.contains(target)) || anchor?.contains(target))) return;
    close();
  };

  /** The card `depth` and every one inside it taken away; its item no longer marked open. */
  function closeFrom(depth: number): void {
    while (levels.length > depth) {
      const level = levels.pop()!;
      if (level.card.contains(document.activeElement)) (document.activeElement as HTMLElement).blur();
      level.card.remove();
      level.from?.setAttribute('aria-expanded', 'false');
    }
  }

  function close(): void {
    if (!open) return;
    open = false;
    clearTimeout(rest);
    root.removeEventListener('pointerdown', outside, true);
    canvas.removeEventListener('pointerdown', outside, true);
    // An item that had the focus goes with the card: the focus back on the page, where the editor's keys are heard.
    closeFrom(0);
    anchor?.removeAttribute('data-menu-open');
    anchor = null;
    closed?.();
  }

  /** A card of `items`, the menu's `depth`-th, built and put in the editor's root -- placed by the caller once it has a size. */
  function build(items: readonly MenuItem[], depth: number, from: HTMLButtonElement | null, title?: string, foot?: string): Level {
    const card = el('div', depth === 0 ? 'ed-card ed-menu' : 'ed-card ed-menu ed-submenu');
    card.setAttribute('role', 'menu');
    const level: Level = { card, buttons: [], items, from };
    if (title) card.append(el('div', 'ed-menu-title', title));
    for (const item of items) {
      if (item.rule) card.append(el('div', 'ed-menu-rule'));
      const b = control(item.mcp, item.danger ? 'ed-menu-item ed-danger' : 'ed-menu-item');
      b.setAttribute('role', 'menuitem');
      if (item.title) b.title = item.title;
      b.append(el('span', undefined, item.label));
      if (item.items) {
        b.setAttribute('aria-haspopup', 'menu');
        b.setAttribute('aria-expanded', 'false');
        b.append(el('span', 'ed-menu-more', '▸'));
      } else if (item.key) b.append(el('span', 'ed-key', item.key));
      // A click the keyboard made -- Enter or Space on the button -- counts no presses.
      b.addEventListener('click', (event) => {
        if (item.items) return void sub(depth, b, item.items, event.detail === 0);
        close();
        item.run?.(event.detail === 0);
      });
      // Resting on an item: its submenu opens, another of this card's closes.
      b.addEventListener('pointerenter', () => {
        clearTimeout(rest);
        rest = setTimeout(() => {
          if (!open || levels[depth] !== level) return;
          if (item.items) sub(depth, b, item.items, false);
          else closeFrom(depth + 1);
        }, REST_MS);
      });
      card.append(b);
      level.buttons.push(b);
    }
    if (foot) card.append(el('div', 'ed-menu-title ed-menu-foot', foot));
    // Into a submenu: what its item's pause was about to do is not done.
    card.addEventListener('pointerenter', () => {
      if (depth > 0) clearTimeout(rest);
    });
    root.append(card);
    return level;
  }

  /** The submenu of `from`, an item of card `depth`, opened beside it -- its first item focused if asked by key. */
  function sub(depth: number, from: HTMLButtonElement, items: readonly MenuItem[], focus: boolean): void {
    clearTimeout(rest);
    const already = levels[depth + 1];
    if (already?.from !== from) {
      closeFrom(depth + 1);
      const level = build(items, depth + 1, from);
      const { width, height } = level.card.getBoundingClientRect();
      const { left, top } = placeBeside(from.getBoundingClientRect(), levels[depth]!.card.getBoundingClientRect(), { width, height }, { width: innerWidth, height: innerHeight });
      level.card.style.left = `${left}px`;
      level.card.style.top = `${top}px`;
      from.setAttribute('aria-expanded', 'true');
      levels.push(level);
    } else closeFrom(depth + 2);
    if (focus) levels[depth + 1]!.buttons[0]?.focus();
  }

  function show(at: { x: number; y: number } | HTMLElement, items: readonly MenuItem[], { title, foot, focus = false, bottom }: MenuOptions = {}): void {
    close();
    open = true;
    anchor = at instanceof HTMLElement ? at : null;
    // Its button marked open: the button's tooltip (`data-tip`) is not drawn over the menu meanwhile (shell.css).
    anchor?.setAttribute('data-menu-open', '');
    const level = build(items, 0, null, title, foot);
    levels = [level];
    // Given a `bottom`, ending above it and the window's foot -- no taller, the rest of it scrolled to; else shell.css's cap.
    const limit = Math.min(bottom ?? innerHeight, innerHeight) - MARGIN;
    const fitTo = (top: number): void => {
      if (bottom === undefined) return;
      // The whole card, its padding and edge too, within the limit.
      level.card.style.boxSizing = 'border-box';
      level.card.style.maxHeight = `${Math.max(MIN_HEIGHT, limit - top)}px`;
    };
    if (anchor) fitTo(anchor.getBoundingClientRect().bottom);
    // Placed once it has a size: below the button or at the point, and kept on screen.
    const { width, height } = level.card.getBoundingClientRect();
    const { left, top } = placeAt(anchor ? { x: 0, y: 0 } : (at as { x: number; y: number }), { width, height }, { width: innerWidth, height: innerHeight }, anchor?.getBoundingClientRect());
    level.card.style.left = `${Math.max(MARGIN, left)}px`;
    level.card.style.top = `${top}px`;
    fitTo(top);
    root.addEventListener('pointerdown', outside, true);
    canvas.addEventListener('pointerdown', outside, true);
    if (focus) level.buttons[0]?.focus();
  }

  /** The card the arrows walk: the one with the focus, else the innermost open. */
  function focusedLevel(): number {
    const at = levels.findIndex((l) => l.card.contains(document.activeElement));
    return at >= 0 ? at : levels.length - 1;
  }

  return {
    get open() {
      return open;
    },
    show,
    close,
    step(by) {
      const depth = focusedLevel();
      const level = levels[depth];
      if (!level) return;
      // Walking a card: what hangs from another item of it is shut.
      closeFrom(depth + 1);
      const next = stepIndex(level.buttons.indexOf(document.activeElement as HTMLButtonElement), by, level.buttons.length);
      if (next >= 0) level.buttons[next]!.focus();
    },
    enter() {
      const depth = focusedLevel();
      const level = levels[depth];
      const at = level ? level.buttons.indexOf(document.activeElement as HTMLButtonElement) : -1;
      const items = at >= 0 ? level!.items[at]!.items : undefined;
      if (items) sub(depth, level!.buttons[at]!, items, true);
    },
    back() {
      const depth = focusedLevel();
      if (depth === 0) return;
      const from = levels[depth]!.from;
      closeFrom(depth);
      from?.focus();
    },
    dispose: close,
  };
}
