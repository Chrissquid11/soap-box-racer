/**
 * The tool contract: what a tool of the editor is (`EditorTool`, made once into
 * a `ToolInstance`) and what the editor hands it (`EditorContext`). Scene (the
 * entities), Config and Assets are three; a game's level editor, spline tool or
 * tile layer is one more, sharing the one undo stack, the one selection and the
 * scene. A page of the Config tab is a `ConfigPage` (made once into a
 * `PageInstance`), given in `createEditor`'s `pages` or added by a tool
 * (`ctx.pages.add`). `index.ts` has a worked example of each and the parts to
 * build them with.
 *
 * - **An edit is a step**: a world edit is `ctx.worldSteps.commit(label)` and
 *   then `ctx.emit('changed')`, so Undo, the History card and every other tool
 *   keep up; a step of the tool's own is `ctx.history.push`.
 * - **Its keys are `ctx.keys.add`**, MrDebug actions live only while it is up,
 *   never a key listener; Esc is its `holdsEscape` and `cancel`.
 * - **A stack of its own**, if its steps are not the world's: `history` on the
 *   instance, and `busy()` while they are on their way; the host's Undo, Redo
 *   and History card follow the tool up (`active-history.ts`).
 * - **A tab of its own, or a place in another's** (`within`): the Assets panel
 *   is shown along the bottom of the Scene tab, beside the entities. There one
 *   side has the keys and the bars' history -- the one last pressed in
 *   (`cards`, `ctx.focused`, `sides.ts`) -- and the right panel is the card of
 *   whichever chose last (`ctx.inspect`, `setInspector`), unless it is locked
 *   (`ctx.lock`). A choice on one side lets go of the other's (`ctx.chose`,
 *   `letGo`): one selection across the tab.
 * - **What it shows, as facts**, for the agent's turn (`context`, Docs/agent.md
 *   §4, §5): its folder, its chosen files -- names and values, never
 *   sentences; the dev server words them.
 * - **Settings and tables are a Config page**, not a tab: a `ConfigPage` in a
 *   group of the Config tab's tree (Game, Assets, Editor, or one of a game's
 *   own), its card the rest of the screen while it is chosen. A tool whose
 *   state a page shows -- the Assets tool's Tools -- adds it as it is made
 *   (`ctx.pages.add`) and brings it up with `ctx.pages.show(id)`.
 */
import type { Mcp } from './mcp/declare.ts';
import type { PageModel } from './mcp/host.ts';
import type { TurnAttachments, TurnTarget } from './agent/context.ts';
import type { QuickAt } from './agent/quick.ts';
import type { BlockItem } from './blocks.ts';
import type { Entity, World } from '@vibe/engine';
import type { ProjectToolDecl } from '@vibe/pipeline/agent-types';
import type { Game } from '@vibe/engine/boot';
import type { History } from './history.ts';
import type { IconName } from './icons.ts';
import type { OverrideSteps } from './overrides-steps.ts';
import type { PlayButton, PlaytestState } from './playtest-state.ts';
import type { TabId } from './tab-pages.ts';
import type { PanelHead } from './shell.ts';
import type { Selection } from './selection.ts';
import type { Viewport } from './viewport.ts';
import type { WorldSteps } from './world-steps.ts';

/**
 * What the editor says, and a tool may:
 *
 * - `changed`  the world was edited -- emitted by the tool that edited it,
 *              after its world step. Every other tool's `refresh` runs.
 * - `loaded`   another world is in -- a scene loaded, the world emptied -- after
 *              `history.reset()` and `worldSteps.sync()`. The selection is
 *              emptied, and every tool's `refresh` runs, the emitter's too.
 * - `selection` the selection changed (the editor's: `Selection` emits it).
 * - `tool`     another tool is up (`ctx.tool`).
 * - `playtest` a playtest began or ended (`ctx.playing`).
 */
export type EditorEvent = 'changed' | 'selection' | 'loaded' | 'tool' | 'playtest';

/** A key of a tool's: a MrDebug action, live only while the tool is up and the editor is editing. */
export interface ToolKey {
  /** Unique among the editor's keys: listed in the debug panel as `editor: <name>`. */
  name: string;
  /**
   * A `KeyboardEvent.code` (`'KeyG'`) pressed alone, or a chord -- `'Mod+KeyG'`,
   * `'Shift+KeyG'`, `Mod` being Cmd on a Mac and Ctrl elsewhere -- or several
   * that each do it (`['KeyD', 'Mod+KeyD']`): any MrDebug key. Left out: a
   * button in the debug panel only. Listed on the editor's keys card (`?`)
   * under the tool's name while it is live.
   */
  key?: string | readonly string[];
  /** One line: what it does. */
  help: string;
  /** The MCP tool that does what this key does, `'ui'`, or why none does (`Mcp`, `mcp/declare.ts`). */
  mcp: Mcp;
  /** Narrower still than "this tool is up and the editor is editing". */
  when?(): boolean;
  /**
   * It only looks -- the camera, the gizmo's mode, the selection, a menu or a
   * list walked -- changing neither the world nor its history: live while an
   * Apply lands, when every other key is refused and said (`hold.ts`).
   */
  view?: true;
  /**
   * Live whichever side of its tab has the keys (`sides.ts`): a key of the
   * tool's card as a whole -- the Assets panel's fold -- not of its choice.
   */
  anySide?: true;
  /**
   * Live whichever tab is up, the tool's own or not, its `when` the whole rule: a key that brings the tool up
   * from elsewhere -- a tile tool's from the Scene tab, with a tile layer selected. The editor's own keys still win.
   */
  anyTab?: true;
  /**
   * A field's own key (MrDebug's `field`): taken only while typing into an element marked
   * `data-keys-field="<field>"`, or inside one -- the Studio tab's console filter's Enter and Esc -- and
   * never anywhere else. Without one, a key typed into a field is never the tool's.
   */
  field?: string;
  /** A key held, not pressed (MrDebug's `hold`): `run` as it goes down, `release` as it comes up -- the Model tab's flying. */
  hold?: true;
  release?(): void;
  run(): void;
}

/**
 * How a model is opened: `room`, it was just made to be looked at -- an import or Make a script landing in the Model tab
 * (Docs/modeler.md M39) -- so the tab makes room for its views at a small window even where the Assets panel was unfolded.
 */
export interface OpenHow {
  room?: boolean;
}

export interface EditorContext {
  readonly game: Game;
  readonly world: World;
  /** The shell's root: a tool's cards go in here (`el('div', 'ed-card ed-side ed-left')`). */
  readonly root: HTMLElement;
  /**
   * The scene's header (`shell.ts`' `PanelHead`): `Scene` and the scene's name,
   * or `Prefab`, the prefab open, its Save and Back, and Back's question under
   * it. The tool whose left card shows the scene's entities -- the tree --
   * puts `root` at that card's top, its own controls (its fold) in `end`.
   */
  readonly head: PanelHead;
  /** The one undo stack: push a step of your own, or group several. */
  readonly history: History;
  /** World edits as steps: edit the world, then `commit('Label')`. */
  readonly worldSteps: WorldSteps;
  /** What is selected, as refs, the first shown: `choose` one, `chooseAll(list, latest?)` several at once. */
  readonly selection: Selection;
  /**
   * The scene: the editor's camera, the gizmo, picking (`onPick`), what is
   * drawn (`add`, `on('update')`); `setBoxAway` while the tool's clicks are its
   * own, so a drag on nothing draws no box; `drag`, what a plain drag is.
   */
  readonly viewport: Viewport;
  /** The id of the tab up: a tool on the bar -- this one's, or the one it is shown `within`. */
  readonly tool: string;
  /**
   * Does this tool have the keys and the bars' history: up, and -- in a tab it
   * shares -- the side last pressed in (`sides.ts`). Its keys are live only
   * then (but those marked `anySide`).
   */
  readonly focused: boolean;
  /** The keys to this tool, in the tab it shares: what a press in its cards does (the host hears those itself, `cards`). */
  focus(): void;
  /** Is the right panel this tool's card just now? Always, alone in its tab. */
  readonly inspecting: boolean;
  /**
   * The right panel this tool's, in the tab it shares: something was chosen in
   * it -- a file, an entity -- and the inspector shows what was chosen last.
   * Its `setInspector` is told. Nothing while the panel is locked.
   */
  inspect(): void;
  /**
   * Something was chosen in this tool -- an entity, a file, not nothing: every
   * other tool up in its tab lets go of its own choice (`letGo`), so the tab
   * has one selection across its sides. The lock does not stop it, and
   * remembers it -- the panel this tool's as it opens. With `browsing` --
   * only folders chosen, a way through the files, no subject (the Assets
   * panel's folder tiles) -- nothing: the other side keeps its choice, and
   * the lock remembers nothing.
   */
  chose(browsing?: boolean): void;
  /** Can the right panel be locked in the tab up (its tool's `lock`): the lock button shown. */
  readonly lockable: boolean;
  /** Is the right panel locked: its side kept, and each inspector on what it showed as it was locked. */
  readonly locked: boolean;
  /** Lock the right panel to what it shows, or unlock it: every tool up told (`setLocked`). Nothing where the tab has no lock. */
  lock(on: boolean): void;
  /** Is a playtest running? Every tool is hidden while one does. */
  readonly playing: boolean;
  /** The playtest's state: none, running (every tool hidden), or paused, the world the playtest's (`playtest-state.ts`). */
  playtest(): PlaytestState;
  /** One of the play strip's buttons, as its key sends it: Play (`F5`), Pause (`F6`), Stop, Step (`playtest-state.ts`) -- the app's Game menu's. */
  play(button: PlayButton): void;
  /** What the world is called, under the editor's title. */
  readonly title: string;
  /**
   * Call the world this -- a scene's name -- or, with null, what the game calls
   * it. `note`, if given, is the name's hover text, read as the pointer comes
   * onto it: when it was saved, which goes out of date as it sits there.
   */
  setTitle(title: string | null, note?: () => string): void;
  /** Bring a tool up, as its button does. */
  showTool(id: string): void;
  /**
   * The prefab opened to edit (Docs/prefabs.md §7), the innermost of a stack;
   * null while the scene is. Its world is in the scene meanwhile, with a
   * history of its own.
   */
  readonly prefab: string | null;
  /** That prefab's instance in the scene, its root -- what Spawn and a drop put things under there (`openedParent`) -- NONE while the scene is. */
  readonly prefabRoot: Entity;
  /** Every prefab open with edits not saved, outermost first: a Rename or Delete of one asks first, as those edits could then only be dropped. */
  readonly prefabsUnsaved: readonly string[];
  /** Every prefab open, outermost first: the Assets tool's Root block is read-only on each ("open: edit it there"). */
  readonly prefabsOpen: readonly string[];
  /**
   * `key` opened to edit, over whatever is in the scene -- the scene, or the
   * prefab open, for a nested one -- the Entities tool brought up; its words
   * on the top bar's status line if it cannot be.
   */
  openPrefab(key: string): void;
  /**
   * A Gladius script -- `AssetsSource/…/*.lua`, or its export, which opens its
   * script -- opened in the tool that opens models (the Model tab,
   * Docs/modeler.md), that tool brought up. False if no tool opens models, or
   * it is not one it opens (`ToolInstance.openModel` says why on the line).
   */
  openModel(path: string, how?: OpenHow): boolean;
  /** What a tool sends with the agent's next turn changed (`ToolInstance.attachments`): the card's line read again. */
  turnChanged(): void;
  /**
   * Words put in the Claude card's box for the person to send -- or not: the
   * card unfolded, the box focused, nothing sent (the Model tab's Delete of a
   * part, Docs/modeler.md M30). False where there is no card (no dev server).
   */
  askClaude(text: string): boolean;
  /**
   * Ask Claude about something (Docs/ai-panel.md §5, A3: Ask Claude…, Fix with Claude, Explain): the quick prompt
   * opened at `at` -- the item's row, a point; none, where Mod+K would open for the target -- naming `target`, which
   * goes with the turn as a fact; `text` in the box for the person to send or change. Never sent by itself. False
   * where there is no Claude (no dev server).
   */
  ask(request: { target: TurnTarget; text?: string; at?: HTMLElement | { x: number; y: number } }): boolean;
  /** Is there a Claude to ask (`ask`): a dev server hosts one. An item that asks is not offered without. */
  readonly canAsk: boolean;
  /** Did Claude's last turn change `e` (Docs/ai-panel.md D8): the tree's mark, until the next turn or until it is selected. */
  touched(e: Entity): boolean;
  /**
   * The card along the bottom of this tool's tab -- the Assets panel, within
   * it -- folded or not (null: none here), and the way to fold it: the Model
   * tab folds it when the views would be too short (Docs/modeler.md §4).
   */
  readonly bottom: { folded(): boolean | null; fold(folded: boolean): void };
  /**
   * A project file shown chosen where it is listed -- the Assets tool brought up,
   * in the folder that lists it, the file chosen and in view -- as Unity's
   * ping on an instance's prefab does. False if no tool shows files.
   */
  revealAsset(path: string): boolean;
  /**
   * A model key's thumbnail -- or, with `type` `'Texture'`, a texture's -- for a key picker's row and field (`key-field.ts`,
   * `key-looks.ts`): the tool that lists files makes it through its one queue -- made if it never was, the new one after
   * a re-export -- and resolves its URL, or null for none to be had.
   */
  modelThumb(key: string, type?: 'Model' | 'Texture'): Promise<string | null>;
  /**
   * The Model tab's files, made by the tool that lists files (Docs/modeler.md M38, M39) -- each one step of its stack:
   * **New model** in `dir` (else the models folder it has open, or `AssetsSource/models`), its name asked in a dialog;
   * **Import model…**, its file picker for `dir`, a `.glb` or `.fbx` imported as a script that imports it -- called
   * synchronously from a press, as a browser opens a picker only then; **Make a script** for a `.glb` delivered as it
   * is. Each brings up what it opens in the Model tab. False if no tool lists files.
   */
  readonly modelFiles: {
    newModel(dir?: string): boolean;
    importModels(dir?: string): boolean;
    adoptModel(path: string): boolean;
    /** The script's whole Options block, in the files tool's inspector, scrolled to and lit; the bottom panel left as it is. */
    options(path: string): boolean;
  };
  /**
   * Prefab `from` renamed `to` (the Assets tool's Rename, and its undo): the
   * world's own instances of it named anew once `to` is compiled -- as a load,
   * no step of its own: the rename's step is the files'.
   */
  renamedPrefab(from: string, to: string): void;
  /**
   * An instance's overrides settled (Docs/prefabs.md §7): Revert and Unpack as
   * world steps, Apply as one step with the prefab's file in it
   * (`overrides-steps.ts`). The inspector's and the agent's alike.
   */
  readonly overrides: OverrideSteps;
  /** The world as changed, on screen: flushed, presented, the viewport on it, the stopped frame drawn again. */
  draw(): void;
  /** Hear an event (`EditorEvent`). Returns the undo. */
  on(event: EditorEvent, fn: () => void): () => void;
  /** Tell the others: `changed` after an edit, `loaded` after another world (a lock on entities let go, `inspector-lock.ts`' `letsGo`). */
  emit(event: EditorEvent): void;
  /**
   * A key for this tool (MrDebug, as every editor key): live while this tool is
   * up and the editor is editing -- not while the keys card is open -- gone
   * when the editor is disposed. The editor's own keys -- the tools', Mod+S, T, Z,
   * Y, H, ?, P, Esc and their chords -- were there first and win. Returns the
   * undo.
   */
  readonly keys: { add(key: ToolKey): () => void };
  /**
   * While an Apply, or its undo or redo, lands: `what` refused and said on the
   * editor's line -- "Load: not now -- Undoing the Apply: a moment" -- true;
   * else false. What a tool asks first at each whole-world entry point of its
   * own (a scene loaded, a prefab saved from a question asked before): its keys
   * and its cards are held already (`hold.ts`).
   */
  refuses(what: string): boolean;
  /**
   * The Config tab's pages (`config/pages.ts`): `add` one -- a tool's own, made
   * at once with the Config tab's context -- and `show` one, the Config tab
   * brought up on it (false if there is no such page, or no Config tab).
   */
  readonly pages: ConfigPages;
  /** The inspector's blocks, sorted (`blocks.ts`): the editor's own and a project's (`createEditor({ blocks })`). What the Scene tab's inspector draws with. */
  readonly blocks: readonly BlockItem[];
  /**
   * `el` in the top bar's middle (`Shell.middle`), right after Save and the play strip in the bar's centre, before AI,
   * Undo and Redo at its end -- on every tab, the tool up or not -- placed by `order` among the others (the lower
   * first; ties in the order added): the Studio tab's problems count (10) and spinner (20). Returns the way to take it
   * out again.
   */
  control(el: HTMLElement, order: number): () => void;
}

/** The Config tab's pages, as a tool reaches them (`EditorContext.pages`). */
export interface ConfigPages {
  /** Every page, in the order added. */
  readonly list: readonly ConfigPage[];
  /** A page in the Config tab's tree, under its group; an id taken already throws. Returns the undo: the page made away with. */
  add(page: ConfigPage): () => void;
  /** The Config tab up on page `id`, as a click on its row. False if there is no such page, or no Config tab to show it. */
  show(id: string): boolean;
  /** The Config tab itself (`config/config.ts`) takes the pages here: told of each, made or taken away, and asked to show one. */
  attach(tab: PagesTab): void;
}

/** What the Config tab answers to: the pages are its to make and to show (`ConfigPages.attach`). */
export interface PagesTab {
  added(page: ConfigPage): void;
  removed(page: ConfigPage): void;
  show(id: string): void;
}

/**
 * A page of the Config tab: one row in its tree, under `group`, and the rest of
 * the screen while it is chosen. Made once, as the Config tab is (or as it is
 * added, after), with the Config tab's context: its keys are listed under
 * Config, live while that tab is up -- a page's own keys narrow themselves to
 * its being shown with their `when`.
 */
export interface ConfigPage {
  /** Unique among the pages: `ctx.pages.show(id)`, and what the Config tab keeps as chosen. */
  id: string;
  /** Its row in the tree and its header: `Systems`. */
  title: string;
  /** The tree's group it is under: `Game`, `Assets`, `Editor`, `Claude` -- in that order -- or a game's own, after them. */
  group: string;
  /** Its row's hover: what the page is for. */
  help?: string;
  create(ctx: EditorContext): PageInstance;
}

/** A page made: its card's content, and what the Config tab tells it -- as a tool's instance is told. */
export interface PageInstance {
  /** What it shows, under the page's header: the Config tab puts it in its page card. */
  readonly root: HTMLElement;
  /** Chosen and the Config tab up, or not: a page reads afresh as it is shown, and stops any timer as it goes. */
  setVisible(visible: boolean): void;
  /** Read the world again: on `changed` and `loaded`, after an undo or a redo. A page not shown may do nothing. */
  refresh?(): void;
  /** Esc is this page's just now -- a question asked in it -- `cancel` its no. */
  holdsEscape?(): boolean;
  cancel?(): void;
  /** Save (`S`, the bar's button), as a tool's: the Scenes page's, which saves the scene from any tab. */
  save?(): void;
  dispose(): void;
}

/** One fact a tool says of what it shows (`ToolInstance.context`): a name, and one value or several. */
export interface ToolFact {
  name: string;
  value: string | readonly string[];
}

/**
 * What a project adds to the editor (`boot`'s `tools` module, `ProjectTools`): its tools after the editor's
 * (each answering a turn's facts as any tool does, `context()`), its Config pages and its inspector blocks.
 */
export interface EditorExtensions {
  tools?: readonly EditorTool[];
  pages?: readonly ConfigPage[];
  blocks?: readonly BlockItem[];
  /** Its own MCP tools (Docs/mcp.md M7): `project_<name>` to Claude and to an outside client, run here. */
  mcpTools?: readonly ProjectMcpTool[];
}

/** What a project's MCP tool is handed as it runs, in the studio tab: the editor's world and what is selected. */
export interface ProjectToolContext {
  /** The world the editor edits: what the tool changes is changed here, then made one step. */
  readonly world: World;
  /** The selection, the first shown first (read it; a tool's call never moves it). */
  readonly selection: readonly Entity[];
}

/** What a project's MCP tool's run came to: its words for Claude, its JSON, and the step its edits make. */
export interface ProjectToolAnswer {
  /** A line or two: what was done, or found. */
  words: string;
  /** Facts beside the words, as JSON. */
  json?: unknown;
  /**
   * The label of the one world step its edits make -- `Z` undoes it, labelled `Claude: <step>` (an outside client's `MCP: …`).
   * None: a step under the tool's name if it changed the world all the same. A `readOnly` tool's is ignored: what it changed is put back.
   */
  step?: string;
}

/**
 * A project's own MCP tool (Docs/mcp.md M7, Docs/packages.md §10), exported from its `src/tools/index.ts` as
 * `mcpTools`: declared to the dev server by the studio tab, registered beside the built-ins as `project_<name>`, its
 * calls relayed here and run by `run` -- its edits of the world one step, gated by its annotations. It throws to
 * refuse (its message is the tool's error; the world is put back as it was).
 */
export interface ProjectMcpTool extends ProjectToolDecl {
  run(ctx: ProjectToolContext, args: Record<string, unknown>): ProjectToolAnswer | Promise<ProjectToolAnswer>;
}

export interface EditorTool {
  /** Unique: what `showTool` and `ctx.tool` call it. */
  id: string;
  /** On its button. */
  name: string;
  icon: IconName;
  /** The key that brings it up, a `KeyboardEvent.code` (`'Digit4'`); on the button, and a MrDebug action. */
  key?: string;
  /** That key's line in the debug panel. */
  help?: string;
  /**
   * Shown inside another tool's tab, not one of its own: that tool's id (the
   * Assets panel's `entities`), or the ids of several -- the same instance in
   * each, the first its home (`['entities', 'model']`). No button on the bar;
   * its key brings up its tab -- the one up, if it is one of them, else the
   * first -- gives this tool the keys and calls `summon`.
   */
  within?: string | readonly string[];
  /**
   * Where its tab sits on the tool strip: by default at the top, in the tools' order; `'bottom'` pins it to the
   * strip's foot -- the Config tab's, as a settings tab is in an IDE. A project's tool may declare `place: 'bottom'`
   * too: the foot's tabs in the tools' order, under the Config tab's.
   */
  place?: 'bottom';
  /**
   * Its tab's right panel has a lock (`ctx.lock`, `sides.ts`): a button in its inspectors' headers that keeps the
   * panel on what it shows, whatever is chosen -- the Scene tab's.
   */
  lock?: true;
  /**
   * What its inspector's lock pins is paths, of no world (the Assets panel's files): another world loaded does not
   * let the lock go, as it does one on entities (`sides.ts`' `release`).
   */
  pins?: 'paths';
  /** Made once, as the editor is: its cards into `ctx.root`, its keys through `ctx.keys`. */
  create(ctx: EditorContext): ToolInstance;
}

/** One of the editor's own tools: its id one of `tab-pages.ts`' (`tabId`), which names the `studio` page about it. */
export type EditorTab = EditorTool & { readonly id: TabId };

export interface ToolInstance {
  /** Up or not: another tool has the screen, the editor closed, a playtest running. */
  setVisible(visible: boolean): void;
  /**
   * Its cards, in a tab it shares: a press or a focus in one gives it the keys
   * (the scene's are the tab's own tool's), and the focused side's are lit with
   * the editor's focus ring (`ed-focus-side`).
   */
  cards?(): readonly HTMLElement[];
  /** It has the keys now, in the tab it shares, or the other side has: its own lit title rows follow. */
  setFocused?(focused: boolean): void;
  /** The right panel its card, or the other side's (`EditorContext.inspect`): shown or hidden accordingly while it is up. */
  setInspector?(shown: boolean): void;
  /**
   * The right panel locked or unlocked (`EditorContext.lock`): locked, its inspector pins what it shows now and
   * draws that, whatever is chosen, until it is unlocked; its lock button drawn as it is.
   */
  setLocked?(locked: boolean): void;
  /** Another tool of its tab chose something (`EditorContext.chose`): its own choice cleared -- the right panel not asked for. */
  letGo?(): void;
  /** Its key pressed while it is shown `within` another's tab: what it does as it is asked for -- unfolded, its card's keys. */
  summon?(): void;
  /** A card along the bottom (the Assets panel): is it folded to its tab, and the way to fold or unfold it (`EditorContext.bottom`). */
  folded?(): boolean;
  setFolded?(folded: boolean): void;
  /** The scene's header (`EditorContext.head`) in view -- its card unfolded: Back's question is asked under it. */
  showHead?(): void;
  /** Read the world again: on `changed` and `loaded` from elsewhere, and after an undo or a redo. */
  refresh?(): void;
  /** Esc is this tool's just now -- a pick, a question: the editor's Esc action calls `cancel`, and the editor stays open. */
  holdsEscape?(): boolean;
  cancel?(): void;
  /** The top bar's status line while this tool is up, in place of the editor's own; null for that. */
  hint?(): string | null;
  /** The keys card's line of what the mouse does while this tool is up, in place of the scene's; null for that. */
  mouse?(): string | null;
  /**
   * What this tool shows now, as facts for the agent's next turn: the Assets
   * tool's folder and chosen files, a game's tool its own. Asked of every tool
   * as a turn is sent, the tool up's first; null, or none, for nothing to say.
   * Facts, not words (`turn.ts` on the dev server words them): `{ name:
   * 'folder', value: 'AssetsSource/models/props' }`. `whole`: asked for a sender with no attachments -- a
   * terminal's prompt, `studio_context` (Docs/terminal.md D9) -- so what a tool up leaves to its `attachments`
   * (the Model tab's model) is said here too.
   */
  context?(whole?: boolean): ToolFact[] | null;
  /**
   * What goes with the agent's next turn beyond the facts, while this tool is
   * up (the Model tab's model and canvases, Docs/modeler.md M26): shown over
   * the card's box, gathered as the turn goes. Null for nothing.
   */
  attachments?(): TurnAttachments | null;
  /**
   * What a quick prompt (`Mod+K`, Docs/ai-panel.md §4) opened now is about in this tool, and where on the page it
   * opens: the Assets panel's file chosen, the Model tab's parts, the Code card's file and caret. Null for nothing
   * chosen (the host then tries the scene's selection, then the focused card's top).
   */
  quickTarget?(): QuickAt | null;
  /**
   * The tool's own view drawn now, its canvas to copy in the same task: what `view_shot`'s `model` target is (the
   * Model tab's, Docs/mcp.md M4). Null while it is not shown. None: the tool has no view of its own.
   */
  shot?(): HTMLCanvasElement | null;
  /** The Model tab's model as the studio's model tools work it (Docs/mcp.md M6). None: the tool opens no model. */
  readonly model?: PageModel;
  /** Save (`S`, the bar's button): the first tool that has one does it. */
  save?(): void;
  /** A project file shown chosen where it is listed (`EditorContext.revealAsset`): the tool that lists files has it, and is brought up first. */
  revealAsset?(path: string): void;
  /** A model's or a texture's thumbnail (`EditorContext.modelThumb`): the tool that lists files has it. */
  modelThumb?(key: string, type?: 'Model' | 'Texture'): Promise<string | null>;
  /** A text file opened in the Studio tab's Code card, at `line` and `col` when given (the host's `reveal` in studio mode): the tab brought up. */
  openFile?(path: string, line?: number, col?: number): Promise<void>;
  /** A text file's diff from `at` (a turn, `HEAD`) to now in the Code card: the tab brought up. */
  openDiff?(path: string, at: string): Promise<void>;
  /** A model opened (`EditorContext.openModel`): the tool that opens them has it, brought up first. False: not one it opens. */
  openModel?(path: string, how?: OpenHow): boolean;
  /** New model in `dir` (else the tool's models folder): its name asked, the script made, opened (`EditorContext.newModel`). The tool that lists files has it. */
  newModel?(dir?: string): void;
  /** The file picker, its `.glb` and `.fbx` imported as scripts into `dir` (`EditorContext.importModels`); synchronous from the press. */
  importModels?(dir?: string): void;
  /** Make a script for the `.glb` delivered as it is at `path` (`EditorContext.adoptModel`). */
  adoptModel?(path: string): void;
  /** A script's Options block shown and lit in this tool's inspector (`EditorContext.modelFiles.options`). */
  modelOptions?(path: string): void;
  /**
   * What this tool keeps across a reload the editor survives, as plain values
   * (the resume record's `tools`, `resume.ts`): the Model tab's cameras. Given
   * back once, to `takeBack`, as the editor is made again after the reload.
   */
  carry?(): unknown;
  takeBack?(kept: unknown): void;
  /** Home, and the top bar's Frame all, with this tool's tab up: the camera onto everything it shows, in place of the scene's. */
  frameAll?(): void;
  /**
   * Its tab draws a scene of its own (the Model tab's views): with the cards
   * put away (the key left of `1`) that scene is what is left, and this tool's
   * keys stay live, as the Scene tab's do over the world.
   */
  readonly ownScene?: boolean;
  /**
   * Its tab is a page: a card over the scene's room, the game behind it unseen (the Config tab, the Studio tab).
   * Play pressed with it up goes to the Scene tab first, and Stop comes back (`play-scene.ts`). A tool whose cards
   * sit beside the scene (Tiles) leaves it out.
   */
  readonly page?: boolean;
  /**
   * This tool's own stack, for steps that are not the world's and must outlive
   * it -- the Assets tool's: a file renamed is not rewound with a scene
   * (Docs/assets.md §6). While the tool has the keys (`focused`), Undo, Redo,
   * the bars and the History card are this one's; `EditorContext.history`
   * stays the world's.
   */
  history?: History;
  /** Its steps are still on their way (a call to the dev server): Undo, Redo and the History card do nothing meanwhile. */
  busy?(): boolean;
  dispose(): void;
}
