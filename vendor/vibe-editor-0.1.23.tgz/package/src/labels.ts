/**
 * An entity's labels as the labels drop-down writes them (`Labels`, an object component; Docs/ecs.md §13): the
 * one path every label takes -- the drop-down's ticks and field, and the studio tools' `scene_flags` (Docs/mcp.md
 * §2 rule 2). Pure ECS, no page: node tests it, and the tools run it.
 *
 * - **What a label is**: what the field makes of what is typed (`typedLabels`) -- trimmed, not empty, no comma.
 *   `labelRefusal` says why another is none, so a tool refuses what the field would never make.
 * - **`Labels` comes and goes with them**: put on with an entity's first label, taken off with its last.
 */
import { type Entity, Labels, type World } from '@vibe/engine';

const store = (world: World): { value: string[][] } => world.rawStore(Labels) as { value: string[][] };

/** `e`'s labels: none without the component. */
export const labelsOf = (world: World, e: Entity): readonly string[] => (world.has(e, Labels) ? (store(world).value[e] ?? []) : []);

/** Why `label` is no label the field would make -- spaces around it, empty, a comma in it -- or null for one it would. */
export function labelRefusal(label: string): string | null {
  if (label.trim() === '') return 'a label is not empty';
  if (label !== label.trim()) return `${JSON.stringify(label)} has spaces around it: a label is trimmed`;
  if (label.includes(',')) return `${JSON.stringify(label)} has a comma in it: a comma ends a label, so it is two`;
  return null;
}

/** `labels` onto every one of `es` that has not got each, `Labels` put on where it is not: those that gained any. */
export function addLabels(world: World, es: readonly Entity[], labels: readonly string[]): Entity[] {
  const did: Entity[] = [];
  for (const e of es) {
    const fresh = labels.filter((l) => !labelsOf(world, e).includes(l));
    if (fresh.length === 0) continue;
    const list = world.has(e, Labels) ? store(world).value[e]! : world.add(e, Labels).value[e]!;
    list.push(...fresh);
    did.push(e);
  }
  return did;
}

/** `label` off every one of `es` that has it; an entity's last gone, `Labels` with it: those that lost it. */
export function removeLabel(world: World, es: readonly Entity[], label: string): Entity[] {
  const did: Entity[] = [];
  for (const e of es) {
    if (!world.has(e, Labels)) continue;
    const list = store(world).value[e]!;
    const i = list.indexOf(label);
    if (i < 0) continue;
    list.splice(i, 1);
    if (list.length === 0) world.remove(e, Labels);
    did.push(e);
  }
  return did;
}
