---
skill: studio
title: The scene
when: Before making, changing or saving anything in the scene or a prefab open to edit through the scene_* tools
covers:
  tools:
    - scene_query
    - scene_entity
    - scene_describe
    - scene_create
    - scene_set
    - batch
    - scene_destroy
    - scene_duplicate
    - scene_reparent
    - scene_rename
    - scene_component
    - scene_flags
    - scene_relate
    - scene_unrelate
    - scene_list_insert
    - scene_list_remove
    - scene_list_move
    - scene_main_camera
    - scene_select
    - scene_copy
    - scene_paste
    - scene_override
    - scene_save_prefab
    - scene_open_prefab
    - scene_close_prefab
    - scene_save
    - scene_save_as
    - scene_open
    - scene_new
    - scene_import
    - scene_start
    - scene_list
order: 20
---
# The scene

The Scene tab is the studio's editor of the world: the entity tree on the left, the scene in the middle, one
inspector on the right. Every `scene_*` tool acts on the world that tab shows -- the scene open, or the prefab
open to edit -- exactly as the person's own tree, menus and inspector do, in the studio tab in their browser.
So the person sees each edit as it lands, and undoes it with `Z`.

Never edit a `.scene` or `.prefab` file the editor has open with a file tool, and never `curl` the dev server:
the editor would not know, and the next save writes over it. Go through the tools.

## Read first

Nothing in the world is known until it is read. Before an edit:

- **`studio_state`**: what is open (the tab, the scene and whether it is saved, a prefab open to edit, a
  playtest), and every selected entity whole -- with its overrides, if it is an instance. "The selected crate"
  means what this says is selected.
- **`scene_query`**: entities by `name` (a part, any case; `exact` for the whole), `path`, `component`,
  `prefab`, `label`, `tag`, `layer` or `parent` (null: the roots). Every filter given must hold. A page at a time:
  `limit`, then `cursor` from the answer's `next`.
- **`scene_entity`**: one entity whole -- its components and their values, its children, its links in and out,
  an object component's `saved` shape (what `scene_set` takes back), and each numeric component's `schema`: for
  every field its `kind` (`number`, `bool`, `enum`, `flags`, `color`, `colorA`, `vector`, `ref`, `key`, `mesh`), an enum's
  or flags' `names`, a vector's `size`, a key's `keyKind` (any asset kind: `Model`, `Sfx`, `Prefab`, `Font` …; a `mesh`'s `Model`), a typed ref's `needs` (the components an entity must
  have to be held there), `min` / `max` / `step`, and `readonly` -- and each data component's all the way down: a
  `string` (its `maxLength`), a `list` (its element `of`, its count's `min` / `max`), a `dict` (its `key` and
  `value`), a `record` (its `fields`). Read it before setting a field you have not set before: it says what
  `scene_set` takes there.
- **`scene_describe`**: the game's own words for its world -- every prefab, component (with its fields, and
  ` · Physics/Colliders` where its `menu` puts it in Add Component) and system. Read it before naming a component or a relation you have not seen.
- **`prefab_info`** lists the prefabs there are to place; **`scene_list`** the scene files.

**An entity is named by its ref or its path.** A ref is the number the answers give (`ref 12`); it holds the
entity's generation, so a ref to one destroyed since names nothing rather than its successor. A path is names
from a root joined by `/` (`big crate/rider`; `#12` for one with no name). A path follows names: after a rename
or a move, use the new path or the ref. Left out where a tool allows it, the entities are the person's
selection.

## The jobs

**Make something** -- `scene_create`:

- `kind: 'prefab'` (the default) with `prefab: 'crates/big'`: one instance, the whole tree, as the Spawn list
  places it. The key is the file's path under `src/assets/prefabs/` without `.prefab`.
- `kind: 'empty'`: a Transform and a name, for code to fill in. `kind: 'camera'`: in front of the editor's view,
  the main camera when the scene has none.
- `at: { x, y, z }` in metres (relative to `parent` when given), `parent` and `before` for its place in the tree,
  `name`. It answers the new ref and path. It does not move the selection.

**Name it** -- `scene_rename`: several at once are numbered (wall, wall 2, wall 3); `""` takes the name off.

**Move it in the tree** -- `scene_reparent`: under `parent` (null: the roots), in front of `before`. Each stays
where it is in the world, as a drag in the tree does: its Transform is worked out again in the new parent's space
(under a parent scaled unevenly with it turned, the nearest a Transform holds). `keepWorld: false` keeps its
Transform numbers instead, now relative to the new parent, so it moves with it.

**Set a field** -- `scene_set`: `entities`, `component`, `field`, and `value` -- one for all (a list there is the one
value: a vector's numbers, a list's elements) -- or `values`, one an entity in the order of `entities`. Read the
field's `schema` first (`scene_entity`); each kind takes:

| `kind` in the schema | `value` | e.g. |
|---|---|---|
| `number` | a number, held to `min` / `max` (clamped, and the answer says so) | `Hop.power: 5` |
| `bool` | `true` / `false` | `Render.castShadow: false` |
| `enum` | a name among its `names` (an index of one is read too) | `Mood.feeling: "grumpy"` |
| `flags` | a list of names, `[]` for none | `Mood.riledBy: ["hops", "loot"]` |
| `color`, `colorA` | `"#rrggbb"`, `"#rrggbbaa"` | `Mood.grumpy: "#ff7a5c"` |
| `vector` | its numbers under its one name; one axis alone by its column | `dir: [0, 1, 0]`, `dirY: 1` |
| `ref` | an entity by ref or path, `null` for nobody; a typed one (`needs`) only an entity with each | `Follow.who: "big crate/rider"` |
| `key` | a key of its `keyKind` as text, or the `{ uid, key }` an answer showed (never a uid made up), `""` for none | `Hop.sound: "hop"` |
| `mesh` | `{ key, part }` or `"key#part"` (no part: the whole model) | `{ "key": "props/parrot", "part": "tail" }` |
| `list`, `dict`, `string`, `record` | a data component's: by a path, below | `Patrol.waypoints[2]` |
| an object component | the whole of it, `field` left out, in the `saved` shape `scene_entity` shows | |

Refused with why, nothing written: a name an enum or flags has not (the names there are said), a key the project has
none of that kind (the keys there are; one of another kind said so: `hop is a Sfx, not a Model`), a part its model
has not, an entity a typed ref cannot hold (`rock has no Health: needs an entity with Health`), a `readonly` field.

**A data component** (lists, dictionaries, text, records) is set by a path in `field`: a field whole (`waypoints`),
an element (`waypoints[2]`), a dictionary's entry by its key (`table.rare` -- an enum's name, text; a number or an
entity's `[3]`), a record's field (`stats.speed`), any depth (`legs[0].to`). The value in the shape `scene_entity`
shows: an enum by name, a key as text or `{ uid, key }`, a ref by an entity's ref or path, a dictionary
`{ "rare": … }` (number or entity keys `[[k, v], …]`). With no `field`, `value` names the fields to set and every
other stays as it is. Every element is checked, what does not fit refused with its path (`Loot.table.rarre: no
name "rarre" -- its names are …`, `Patrol.waypoints[3]: rock has no Transform: needs an entity with Transform`); a
number is held to its `min` / `max` and text to its `maxLength`, said.

**A list's +, × and grip** -- `scene_list_insert` (`path`, `index` -- the end when left out -- and `value`, the
element's default when left out), `scene_list_remove` (`index`) and `scene_list_move` (`from`, `to`), each ONE
step. On a dictionary the same three take its entry by `key`: insert adds one (no `key`: the first free -- an
enum's next name, `"key 2"`; a key it has refused), remove takes it out, move puts it elsewhere in its order (kept
in the file) -- or, with `rename`, gives it another key in its place (a key it has refused). A list's `max` refuses
one more, its `min` one fewer.

What the person does by dragging is one of these: a tree row dropped on a ref field is `scene_set` of that entity, on
a list `scene_list_insert` (on a row, before it), an asset from the Assets panel on a key field `scene_set` of its key.
To do what a drop does, call the tool; `scene_entity`'s schema says what a field takes.

A `readonly` field is refused (the game's code sets it), as is a name an enum or flags has not -- the answer
says the names there are.

`was` (one, or one per entity): written only where the field still holds it. If the person changed it meanwhile,
nothing is written and the answer says each value now -- read it and decide again. Use it whenever the person
may be editing the same thing.

**Add or remove a component** -- `scene_component` with `verb`: `add` (at its defaults: `scene_set` then fills
it in), `remove`, `enable` or `disable` (switched off: data kept, out of the systems that need it). It is the
inspector's **Add Component** button: a card with a search at its top and the components under their categories --
each component's `menu` (`Physics/Colliders`, `Rendering`; a game's own with none under `Game`), the same words
`scene_describe` prints after a component (`BoxCollider { … } · Physics/Colliders`). Typed, it lists every match,
best first; Enter adds the one lit, to every one selected that has it not, one step. Name the component to
`scene_component` directly -- the categories are only how a person finds it.

**Tags, labels, layers, switches** -- `scene_flags`: `hidden` (not drawn, still running), `disabled` (in no
system, not drawn), `unpickable` (not picked in the scene) -- each for the entity and everything under it --
`layer` (0 to 31, or a layer's name), `tags: { add, remove }` (the game's tags, by name), `labels: { add,
remove }` (free text). All of it one step.

**Link two entities** -- `scene_relate` (`entity` to `target` by `relation`, the link's numbers in `data`) and
`scene_unrelate`. A link dies with either end.

**Which camera the game draws through** -- `scene_main_camera`: that camera's `Camera.main` on, every other's
off.

**Copy or remove** -- `scene_duplicate` (an instance's root copies the whole instance; any other entity its own
components, not its children) and `scene_destroy` (everything under it too).

**Copy entities into another scene** -- as the tree's Copy and Paste: `scene_copy` with `entities` keeps the
clip in the studio tab and answers its `handle` (`clip-3`: each with everything under it; nothing changed, the
person's clipboard left alone; the last 8 kept until the page reloads), with the clip's JSON too only while it is
short; `scene_open` the other scene (or `scene_open_prefab`); `scene_paste` with that `handle` -- new entities with
free names, instances whole again, links and refs among them kept (a ref out of the clip only in the world it was
copied from), `at` `{ x, z }` for where their middle goes (left out, where they were); with a prefab open, under
its root. One step. Entities the person copied and pasted to you as text go in `clip` instead of `handle`.

**Select** -- `scene_select`, only when the person asked to see something selected: no other tool moves their
selection, and a selection is no edit.

## Prefabs in the scene

An entity made by a prefab is an **instance**: it follows its prefab's file, and whatever it changes from it is
an **override**. `studio_state` lists an instance's overrides, each by its handle (`Transform.px`; on a root,
`rider: Transform.px` for an entity inside it).

- **Settle overrides** -- `scene_override` with `verb`: `revert` (back to the prefab, in the world only),
  `apply` (written into the prefab's file -- or `to`, an inner prefab -- so every instance takes it; answered once
  the file compiles), `unpack` (on a root: plain entities, no longer the prefab's). `what` names the handles; left
  out, it is every override `studio_state` lists for that entity -- on a root, the whole instance's -- so read
  that list first and name only what should go. A ref pointed outside its instance (`→ rider (outside)`) is the
  scene's alone: `apply` refuses it, saying so; one pointed at nobody applies like any field.
- **Edit the prefab itself** -- `scene_open_prefab` with the prefab's `key` (`'crates/big'`, or `{ uid, key }` -- a
  real uid, never one made up; a key, not an instance's ref) puts the scene aside and opens that prefab
  alone; the answer says when it is read-only, and why. Every scene tool then edits the prefab (a `scene_create`
  with no parent goes under its root).
  `scene_save` (no name) writes the prefab's file and stays in it, as S and the header's Save do;
  `scene_close_prefab` with `save: true` writes the file and goes back; `save: false` drops the changes
  (destructive: the person's edits of the prefab go -- ask first).
- **Make a prefab from the scene** -- `scene_save_prefab` with a new `key` (`crates/pile`): the entities and what
  is under them written as `src/assets/prefabs/<key>.prefab`, then replaced by one instance of it. One step: `Z`
  puts them back and the file in the trash.

## batch: several edits, one step

`batch` runs `calls` in order, each `{ tool, args }` of `scene_create`, `scene_destroy`, `scene_duplicate`,
`scene_reparent`, `scene_rename`, `scene_component`, `scene_set`, `scene_flags`, `scene_relate`,
`scene_unrelate`, `scene_main_camera`, `scene_list_insert`, `scene_list_remove` or `scene_list_move`, as ONE step the person undoes with one `Z`. A later call names what an
earlier one made as `"$<n>"` -- `"$0"`, the entity call 0 created or duplicated -- wherever its args name an
entity (`parent`, `entities`, `entity`, `before`, `target`). One call that fails undoes the ones before it:
nothing changed, and the answer says which failed and why.

Use `batch` for edits that belong together -- a thing made, named, placed and set up -- so one `Z` takes the
whole job back. It runs no save, Apply, prefab open or anything that waits on a file.

## Steps, `Z` and saving

- **Each edit tool is one step** on the editor's undo stack, labelled `Claude: …`; the person undoes it with `Z`
  as their own. `history_undo` (and `history_redo`) does the same from a tool, `n` steps back from the latest --
  only an agent's steps (`Claude: …`, this conversation's or another's, or an outside client's `MCP: …`); one of
  the person's among them refuses the whole call, unless `any: true`, which is for when the person asked.
  `history_list` shows the steps and whose each is.
- **No edit saves the scene.** Edits live in the editor's world until `scene_save` writes the scene file. Save
  when the job is done and the person wants it kept, not after every edit.
- **`scene_save`** writes the scene open (or `name`: a new one) -- with a prefab open to edit, that prefab's file,
  staying in it (a name is refused then); **`scene_save_as`** a new scene file under
  `src/assets/scenes/`, never over another; **`scene_open`** and **`scene_new`** replace the world (`scene_new`'s
  is empty but for one main camera, `Main Camera`, at (0, 5, 10) looking at the origin) -- refused while
  it has changes nobody saved, unless `discard: true` (destructive: ask the person first); **`scene_import`**, as
  Import…, writes a world save exported as `.json` before scenes were files (`save` its text, `name` the new scene's)
  as a new scene file -- never over another -- and opens it, on the same terms; **`scene_start`** picks
  the scene the game opens on start. **`scene_list`** lists the scene files.
- The game loads a scene with `game.load(scene('forest/camp'))`; the systems that run over it are the
  [ECS page](../engine/ecs.md)'s.

## Refusals, and what they mean

A tool that will not do something says why and changes nothing (a batch: nothing at all).

| The answer says | What to do |
|---|---|
| The studio is not open: ask the person to open … | ask them to open the URL it gives; nothing was done |
| A playtest is running in the studio: play_pause pauses it …, play_stop stops it | `play_stop` stops it, the world put back (`keep` says which changes made while paused stay) -- as the person's `Shift+F5` or Esc, where `T` (or `F5`) started it; ask first if they started it. Or `play_pause`: paused, the scene's reads and edits work on its world (its saves and opens wait for Stop). While it runs, the scene's tools -- `scene_query` and `scene_entity` too -- `prefab_info` and `history_undo` / `history_redo` are refused; `studio_state`, `history_list`, the play and view tools, the asset writes and every server tool work ([play](play.md) has the list) |
| There is no component called … : those … are | use a name it lists (`scene_describe` lists them all) |
| … is a tag / a relation / the world's own | `scene_flags` for a tag, `scene_relate` for a relation; `WorldTransform` is worked out: set `Transform` |
| … has no Health: scene_component adds it | add it first, then set it |
| … is set by the game's systems as it runs | a runtime field: a prefab keeps none of it; leave it to the game |
| the field no longer holds `was` (`changed`) | the person changed it: read the values it gives, decide again |
| Nothing is selected | name the entities by ref or path |
| the world has changes nobody saved | `scene_save` first, or ask before `discard: true` |
| … is open -- scene_close_prefab first | finish the prefab: close it, saving or not |
| did not answer within … s | it may still be working: read `studio_state` before trying again |

## A job, end to end

"Put three little crates in a row in front of the big one, under a group called row, and save."

1. `studio_state` -- the scene is open and saved, no playtest. `scene_query` with `name: 'big crate'` -- ref 7,
   at the origin. `prefab_info` -- `crates/little` is there.
2. One `batch`:

   ```json
   { "calls": [
     { "tool": "scene_create", "args": { "kind": "empty", "name": "row", "at": { "x": 0, "y": 0, "z": 2 } } },
     { "tool": "scene_create", "args": { "prefab": "crates/little", "parent": "$0", "at": { "x": -1, "y": 0, "z": 0 } } },
     { "tool": "scene_create", "args": { "prefab": "crates/little", "parent": "$0", "at": { "x": 0, "y": 0, "z": 0 } } },
     { "tool": "scene_create", "args": { "prefab": "crates/little", "parent": "$0", "at": { "x": 1, "y": 0, "z": 0 } } },
     { "tool": "scene_rename", "args": { "entities": ["$1", "$2", "$3"], "name": "crate" } }
   ] }
   ```

   One step, "Claude: 5 edits": the crates named crate, crate 2, crate 3.
3. `view_shot` to look at it, if the person cares how it looks.
4. `scene_save` -- the scene file written. Say what was made, and that one `Z` takes it all back.
