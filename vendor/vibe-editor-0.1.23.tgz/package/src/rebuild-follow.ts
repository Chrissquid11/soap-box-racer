/**
 * The editor following a swap of the game's code (Docs/squidwright-implementation.md
 * 0.5): `Game.rebuild` saves the world, resets it in place -- the same `World`
 * -- registers the new systems and loads the save back, calling
 * `onBeforeRebuild` before and `onRebuilt` after. The editor hangs these two
 * on those hooks (`editor.ts`, beside `livePrefabs.around`).
 *
 * - **Pure**: what to do, decided over a host of the editor's locals
 *   (`FollowHost`), so a node test runs every case without a page.
 * - **Before**: what is under way finished before the save is taken -- a
 *   playtest ended as closing the editor ends it, the world put back first, so
 *   the save is the edited world; an edit under way a step of its own, as
 *   `prepareReload` does. Closed, nothing: the game runs, the swap is its own.
 * - **Refused**: a prefab open with changes not saved, a playtest over it
 *   ended first -- the rare case kept simple: `swap: false` (the hook's
 *   `false`), `rebuild` answers `'reload'`, and the reload's resume path asks
 *   about them as it does today. A prefab open and saved swaps: the
 *   scene put aside under it is a save, and loads into the new build on Back.
 * - **After**: the swap is no step (as a recompile is none) -- the world as
 *   loaded back the known state; every tool reads it again; the selection
 *   chosen again by ref (refs survive a save and a load, as `resume.ts`
 *   relies on); one line says it all: a playtest the swap ended (what
 *   `beforeRebuild` returns), the prefab open it went on under, what the load
 *   brought up to date and skipped.
 *   Kept: the undo stack, the unsaved mark, the opened-prefab stack.
 */
import type { Entity, EntityRef } from '@vibe/engine';
import { skippedText, updatedText } from './skipped.ts';
import { PENDING, type WorldSteps } from './world-steps.ts';

/** What the editor hands the two decisions: its locals, read and called. */
export interface FollowHost {
  isOpen(): boolean;
  /** A playtest under way. */
  playing(): boolean;
  /** The playtest ended, the world put back, the editor as it was before it. */
  stopPlaying(): void;
  /** A prefab open with changes not saved. */
  openedUnsaved(): boolean;
  /** A prefab open at all (its stack is a world put aside; the swap goes on under it, the world put aside is a save too). */
  openedKey(): string | null;
  worldSteps: Pick<WorldSteps, 'commit' | 'sync'>;
  selection: { refs(): readonly EntityRef[]; alive(refs: readonly EntityRef[]): Entity[]; chooseAll(es: Entity[]): void };
  /** The editor's `emit('loaded', null, 'again')`: the selection dropped, then every tool reads the world again -- the same world, so the inspector's lock holds. */
  loaded(): void;
  say(line: string): void;
  draw(): void;
}

/**
 * What `beforeRebuild` found: refused (`swap: false`, the hook's `false`), or let through -- with whether it
 * ended a playtest, for `afterRebuild`'s one line to say (a line said before would be replaced by it at once).
 */
export type BeforeRebuild = { swap: false } | { swap: true; playtestEnded: boolean };

/** Before the save is taken: `swap: false` refuses the swap (Vite reloads instead, and the resume path asks as today). */
export function beforeRebuild(host: FollowHost): BeforeRebuild {
  if (!host.isOpen()) return { swap: true, playtestEnded: false };
  // A playtest can run inside the opened-prefab mode: ended first, then the prefab's unsaved changes still refuse.
  const playtestEnded = host.playing();
  if (playtestEnded) host.stopPlaying();
  if (host.openedUnsaved()) return { swap: false };
  // An edit under way is a step of its own first: the swap is none.
  host.worldSteps.commit(PENDING);
  return { swap: true, playtestEnded };
}

/**
 * After the world is loaded back: the tools read it again, the selection chosen again by ref, one line said --
 * a playtest `before` ended, the prefab open the swap went on under, what the load brought up to date and skipped.
 */
export function afterRebuild(host: FollowHost, change: { skipped: readonly string[]; updated?: readonly string[] }, before: BeforeRebuild): void {
  if (!host.isOpen()) return;
  // Taken before `loaded` drops them.
  const refs = host.selection.refs();
  // The world as loaded back is the known state: no step. The undo stack is not reset -- the world is the same
  // object, and every step's save loads into it; one naming a component this build dropped loads with it skipped,
  // as a scene would.
  host.worldSteps.sync();
  host.loaded();
  const alive = host.selection.alive(refs);
  if (alive.length > 0) host.selection.chooseAll(alive);
  const ended = before.swap && before.playtestEnded;
  const under = host.openedKey();
  const swapped = `${ended ? 'Playtest ended, game code swapped' : 'Game code swapped'}${under ? ` under ${under}` : ''}`;
  host.say(`${swapped}${updatedText(change.updated)}${skippedText(change.skipped)}`);
  host.draw();
}
