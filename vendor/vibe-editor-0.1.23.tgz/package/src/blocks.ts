/**
 * The inspector's blocks as a list (Docs/squidwright-plan.md §3, "Lists, not hooks"): each block is an
 * item -- an id, what it is for, an order, and how it is made -- and the inspector draws, for the
 * entities selected, every item that applies, sorted. The editor's own are items on the same list
 * (`builtInBlocks`: Transform, Render, and a numeric or an object component's fields, ten apart); a
 * project adds its own through `createEditor({ blocks })` -- `boot`'s `tools` module's `blocks` -- a
 * tile layer's palette under its component, a road's curve editor. An item with a built-in's id
 * replaces it.
 *
 * - **`for` a component**: drawn when every one selected has it, handed it.
 * - **`for` a predicate** `(world, e)`: drawn when it holds for every one selected, handed none.
 * - **`each`** (the generic blocks'): made once for each component every one selected has that the
 *   inspector shows as fields and `each` takes -- in the world's order of components, each handed its
 *   component; not for Transform, Render, Name or `WorldTransform` (theirs are their own), nor `View` --
 *   the engine's slot for what `Render` draws, never shown (Docs/render.md §1) -- nor tags, the
 *   switches, labels, relations or what the world keeps for itself.
 * - **The order**: by `order`; at one order, a block of a component's ranks by that component in the
 *   world's order, its generic block first and an item `for` it right after -- so an item for
 *   `TileLayer` at the generic blocks' order (`BLOCK_ORDER.components`) sits right under TileLayer's
 *   fields, one at 15 between Transform and Render, one at 35 after every component. Then the list's own
 *   order: the built-ins before a project's.
 *
 * Pure -- the engine's types and nothing of the DOM -- so `blocks.test.ts` sorts and picks with
 * stand-in makers; `inspector-blocks.ts` hands the real ones to `builtInBlocks`.
 */
import { type AnyComponent, Camera, Disabled, type Entity, Hidden, Labels, Name, Render, Transform, View, type World, WorldTransform } from '@vibe/engine';
import * as THREE from 'three';
import type { Blocks } from './inspector-blocks.ts';
import { agreed, spread } from './multi.ts';

/** One block of the inspector's: what it is for, where it goes, and how it is made. */
export interface BlockItem {
  /** Unique on the list: a project's item with a built-in's id takes its place. */
  id: string;
  /** A component every one selected has, or a predicate that holds for every one. */
  for: AnyComponent | ((world: World, e: Entity) => boolean);
  /** Where it goes: the built-ins are `BLOCK_ORDER`'s, ten apart. */
  order: number;
  /**
   * Made once for each component the inspector shows as fields that this takes -- the generic blocks'
   * (`dataBlock`, `objectBlock`) -- handed it. `for` must then be a predicate.
   */
  each?: (component: AnyComponent) => boolean;
  /** Its block for `es`: handed the component it is for (`for` a component, or `each`'s), none for a predicate. */
  make(blocks: Blocks, es: readonly Entity[], component?: AnyComponent): HTMLElement;
}

/** The built-ins' orders, ten apart: a project's item between two takes a number between. */
export const BLOCK_ORDER = { transform: 10, render: 20, components: 30 } as const;

/** Kept by the world for itself -- `ViewState`, `WorldTransform` -- and not the editor's to show as fields or offer to add. */
export const internal = (component: AnyComponent): boolean => component.kind === 'data' && component.transient;

/** Shown first, each its own way -- or, `View`, not at all: never a generic block. */
const OWN: readonly AnyComponent[] = [Transform, WorldTransform, Name, Render, Camera, View];
/** Every entity's, shown on lines of their own (`inspector-state.ts`): never a block, nor an "Only on" line. */
export const STATE: readonly AnyComponent[] = [Hidden, Disabled, Labels];

/** Does the inspector show `component` as fields: a numeric or an object component, the game's, not a tag, switch, label or relation? */
export function fielded(component: AnyComponent): boolean {
  if (component.bit < 0 || component.kind === 'relation' || component.kind === 'tag' || internal(component)) return false;
  return !STATE.includes(component) && !OWN.includes(component);
}

/** The makers of the built-ins, handed in: the DOM's (`inspector-blocks.ts`), or a test's stand-ins. */
export interface BuiltInMakers {
  transform: BlockItem['make'];
  render: BlockItem['make'];
  camera: BlockItem['make'];
  data: BlockItem['make'];
  object: BlockItem['make'];
}

/** The editor's own blocks as items: Transform, Render, Camera's own, then each component's fields -- numeric or object -- in the world's order. No View: the engine's own. */
export function builtInBlocks(make: BuiltInMakers): BlockItem[] {
  const any = (): boolean => true;
  return [
    { id: 'transform', for: Transform, order: BLOCK_ORDER.transform, make: make.transform },
    { id: 'render', for: Render, order: BLOCK_ORDER.render, make: make.render },
    // Camera's own block (`inspector-camera.ts`), among the components in the world's order, as its generic one would be.
    { id: 'camera', for: Camera, order: BLOCK_ORDER.components, make: make.camera },
    { id: 'data', for: any, each: (c) => c.kind === 'data', order: BLOCK_ORDER.components, make: make.data },
    { id: 'object', for: any, each: (c) => c.kind === 'object', order: BLOCK_ORDER.components, make: make.object },
  ];
}

/** The list a project's items join: each in place of a built-in of its id, else after them. Two of one id among `extra` throws. */
export function blockList(builtIns: readonly BlockItem[], extra: readonly BlockItem[] = []): BlockItem[] {
  const ids = extra.map((item) => item.id);
  const twice = ids.find((id, i) => ids.indexOf(id) !== i);
  if (twice !== undefined) throw new Error(`[editor] two inspector blocks share the id '${twice}'`);
  const replaced = new Map(extra.map((item) => [item.id, item]));
  return [...builtIns.map((item) => replaced.get(item.id) ?? item), ...extra.filter((item) => !builtIns.some((b) => b.id === item.id))];
}

/** One block to make: its item, and the component it is made for (none for a predicate's). */
export interface BlockUse {
  item: BlockItem;
  component?: AnyComponent;
}

/** Every block `items` makes for `es` -- all selected, the first first -- in the order they are drawn (the module's header). None for none selected. */
export function blocksFor(world: World, es: readonly Entity[], items: readonly BlockItem[]): BlockUse[] {
  if (es.length === 0) return [];
  const all = (component: AnyComponent): boolean => es.every((e) => world.has(e, component));
  const rank = (component: AnyComponent): number => world.allComponents.indexOf(component);
  const uses: Array<BlockUse & { key: [number, number, number, number] }> = [];
  items.forEach((item, at) => {
    if (item.each) {
      for (const component of world.allComponents) {
        if (fielded(component) && item.each(component) && all(component)) uses.push({ item, component, key: [item.order, rank(component), 0, at] });
      }
      return;
    }
    const target = item.for;
    if (typeof target === 'function') {
      if (es.every((e) => target(world, e))) uses.push({ item, key: [item.order, -1, 0, at] });
    } else if (all(target)) uses.push({ item, component: target, key: [item.order, rank(target), 1, at] });
  });
  uses.sort((a, b) => a.key[0] - b.key[0] || a.key[1] - b.key[1] || a.key[2] - b.key[2] || a.key[3] - b.key[3]);
  return uses.map(({ item, component }) => (component === undefined ? { item } : { item, component }));
}

/**
 * Of several selected, what only some have, by how many have it, the most first:
 * the inspector's "Only on 2 of 3" blocks. Not the world's own, a relation, a tag
 * (the state line's), the switches, nor `View` -- the engine's, from `Render`,
 * which is what says how each is drawn.
 */
export function onlySome(world: World, es: readonly Entity[]): [number, AnyComponent[]][] {
  const some = new Map<number, AnyComponent[]>();
  for (const component of world.allComponents) {
    if (component.bit < 0 || component.kind === 'relation' || component.kind === 'tag' || internal(component) || STATE.includes(component) || component === View) continue;
    const count = es.filter((x) => world.has(x, component)).length;
    if (count === 0 || count === es.length) continue;
    some.set(count, [...(some.get(count) ?? []), component]);
  }
  return [...some.entries()].sort((a, b) => b[0] - a[0]);
}

/** A view in a few words: its three.js type and how many children it has; `none` for none. */
export function describeView(value: unknown): string {
  if (!(value instanceof THREE.Object3D)) return 'none';
  const n = value.children.length;
  return `${value.type}, ${n} ${n === 1 ? 'child' : 'children'}`;
}

/**
 * The Render block's title words for the views of every one selected (`null`
 * for one with none): what they are drawn as, or `not all alike` with each on
 * hover -- and for one, its object's name.
 */
export function drawnAs(views: readonly unknown[]): { text: string; title: string } {
  const said = views.map(describeView);
  const same = agreed(said);
  if (same === null) return { text: 'not all alike', title: `What each is drawn as: ${spread(said)}` };
  const object = views[0];
  const named = views.length === 1 && object instanceof THREE.Object3D && object.name ? `, "${object.name}"` : '';
  return { text: same, title: `What ${views.length > 1 ? 'each is' : 'it is'} drawn as${named}: the engine's render system makes it from these fields` };
}

const plain = (v: unknown): boolean => v === null || ['string', 'number', 'boolean'].includes(typeof v);

/**
 * Has its block a box to switch it off, for `es`? Not what the world keeps for
 * itself, nor a relation, nor what makes no sense off -- where the entity is,
 * its name -- nor what the inspector shows another way: the labels, and the
 * switches of the whole entity, `Hidden` and `Disabled`. And only what a save
 * keeps, as a save keeps what is off with it: an undo is a save put back, so a
 * switch on anything else -- `View`, which the game attaches again after a
 * load -- would be no step and would not last.
 */
export function switchable(world: World, component: AnyComponent, es: readonly Entity[]): boolean {
  if (component.bit < 0 || component.kind === 'relation' || internal(component)) return false;
  if (([Transform, WorldTransform, Name, Labels, Hidden, Disabled] as readonly AnyComponent[]).includes(component)) return false;
  if (component.kind !== 'object' || (component.save && component.load)) return true;
  const slots = (world.rawStore(component) as { value: unknown[] }).value;
  return !component.create && es.every((e) => !world.has(e, component) || plain(slots[e]));
}
