/**
 * The gizmo on the selection: three's TransformControls, moving, turning or
 * scaling it (G R S, Blender's) along the world's axes or the selection's own (X), and
 * snapping to the steps on the top bar (V).
 *
 * - **It drags a stand-in** at the first entity's world transform, never the
 *   view -- the view's matrix is `present`'s to write. Each step lands in the
 *   local `Transform` in the parent's space (`gestureLocal`), and the rest of
 *   the selection follow it (`gesture.ts`). A drag is one step of history,
 *   told once as it is let go (`edited`).
 * - **It writes no float noise, near the origin or far out, World or Local**:
 *   only its mode's channels -- a move the position, never the rotation or the
 *   scale -- each from where it was as the drag began plus the drag, worked
 *   out in the frame it is made in (`GestureFrame`) and seen from the parent,
 *   never a round trip through the 32-bit world. What holds: in World, a
 *   world axis the drag does not move is not moved -- a Y drag under a turned
 *   parent 1000 m out changes `py` alone, an X drag `px` and `pz`, the two it
 *   reaches; in Local, an own axis the drag does not move is not moved -- a
 *   Local X drag of a child not turned changes `px` alone, under any parent,
 *   snapped or not, and a Local Y turn `qy` and `qw` alone. An instance shows
 *   one override for it, not three. A turn back to where it began -- a full
 *   turn -- writes the rotation it began with.
 * - **Ctrl or Cmd held turns snapping over** for as long as it is held, read
 *   off the pointer events -- a key listener is MrDebug's alone.
 */
import * as THREE from 'three';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { frameBottom, Hierarchy, isWhole, NONE, Transform, WorldTransform, type Entity, type World } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import { gestureLocal, movers, POSE_FIELDS, type GestureFrame, type GizmoMode, type GizmoSpace, type Pose, type Quat, type Vec3 } from './gesture.ts';
import type { IconName } from './icons.ts';
import { keepPref, loadPrefs, snapping, type Snap } from './prefs.ts';
import type { Selection } from './selection.ts';
import { altThrough } from './view/alt-through.ts';
import { tabKey } from './editor-keys.ts';

export type { GizmoMode, GizmoSpace } from './gesture.ts';

/** The gizmo's modes as a person meets them: the step a drag makes, the top bar's icons, the keys. */
export const GIZMO_MODES: readonly { mode: GizmoMode; name: string; icon: IconName; readonly key: string; help: string }[] = [
  // Industry Compatible's W E R, or Blender's G R S (Docs/navigation.md §7, §8): the live keymap's, read as each is shown
  // or registered. Plain S no longer saves (Mod+S does).
  { mode: 'translate', name: 'Move', icon: 'move', get key() { return tabKey('move'); }, help: 'The gizmo moves the selection' },
  { mode: 'rotate', name: 'Rotate', icon: 'rotate', get key() { return tabKey('rotate'); }, help: 'The gizmo turns the selection' },
  { mode: 'scale', name: 'Scale', icon: 'scale', get key() { return tabKey('scale'); }, help: 'The gizmo scales the selection' },
];

/** A `Transform`'s ten numbers, in the order they are kept and put back. */
const FIELDS = POSE_FIELDS;

/** `e`'s pose in the world, as the world worked it out at its last boundary. */
function worldPoseOf(world: World, e: Entity): Pose {
  const w = world.store(WorldTransform);
  return { p: [w.px[e]!, w.py[e]!, w.pz[e]!], q: [w.qx[e]!, w.qy[e]!, w.qz[e]!, w.qw[e]!], s: [w.sx[e]!, w.sy[e]!, w.sz[e]!] };
}

/**
 * The world pose `e`'s `Transform` is relative to: its parent's, or null for
 * none -- a root, or a parent without a `Transform`, which passes nothing on,
 * so the child is placed as if it had no parent: what a change in the world
 * is seen from to land in a `Transform` (`gestureLocal`, `vectorToLocal`).
 */
export function parentPoseOf(world: World, e: Entity): Pose | null {
  const parent = world.store(Hierarchy).parent[e]! as Entity;
  return parent !== NONE && world.has(parent, Transform) ? worldPoseOf(world, parent) : null;
}

const samePose = (a: Pose, b: Pose): boolean => a.p.every((v, i) => v === b.p[i]) && a.q.every((v, i) => v === b.q[i]) && a.s.every((v, i) => v === b.s[i]);

export interface GizmoOptions {
  game: Game;
  /** The camera the scene is seen through now: the editor's own, perspective or orthographic -- read as the handles are drawn and pressed. */
  camera(): THREE.Camera;
  /** The gizmo is on the first; a drag moves them all. */
  selection: Selection;
  /** The camera holds still while a handle is dragged, and is free again after. */
  hold(held: boolean): void;
  /** A drag is over: one step of history, called this -- `Move`, `Rotate 3`. */
  edited(label: string): void;
  /** A step of a drag wrote the selection's `Transform`s and flushed the world. */
  moved(): void;
  /** Something of the gizmo's changed on screen: the frame to be drawn soon. */
  changed(): void;
}

export interface Gizmo {
  /** What goes in the scene while the editor is open: the stand-in, and the handles. */
  readonly objects: readonly THREE.Object3D[];
  readonly mode: GizmoMode;
  setMode(mode: GizmoMode): void;
  readonly space: GizmoSpace;
  toggleSpace(): void;
  readonly snap: Readonly<Snap>;
  setSnap(snap: Partial<Snap>): void;
  /** A handle is held: the press is the gizmo's. */
  readonly dragging: boolean;
  /** The handle under the pointer, if any: nothing else is hovered while one is. */
  readonly axis: string | null;
  /** On `e`, where the world says it is -- or off, for NONE or an entity with no `Transform`. Mid-drag it stays where the drag has it. */
  show(e: Entity): void;
  /** Its listeners on the canvas, and off: snapping's first, capturing, then the handles'. */
  connect(): void;
  disconnect(): void;
  dispose(): void;
}

export function createGizmo({ game, camera, selection, hold, edited, moved, changed }: GizmoOptions): Gizmo {
  const world = game.world;
  const canvas = game.renderer.domElement;
  /** What the gizmo drags: an empty object at the selection's world transform, a direct child of the scene. */
  const stand = new THREE.Object3D();
  stand.name = 'editor: gizmo stand-in';
  const gizmo = new TransformControls(camera());
  /** The undo of `altThrough` while connected. */
  let undoAlt: (() => void) | null = null;
  /** The game's frame as three's controls take a viewport: CSS pixels from the canvas's bottom left. */
  const port = new THREE.Vector4();
  /**
   * The handles sized and picked through the camera drawn through now: a projection swapped since, the other one --
   * and the pointer measured across the game's frame (`Game.frame`, Docs/game-view.md §3), where the view is drawn.
   */
  const current = (): void => {
    const now = camera();
    if (gizmo.camera !== now) gizmo.camera = now;
    const f = game.frame;
    const high = canvas.clientHeight;
    if (isWhole(f, canvas.clientWidth, high)) gizmo.viewport = null;
    else gizmo.viewport = port.set(f.x, frameBottom(f, high), f.width, f.height);
  };
  gizmo.setSpace('world');
  const helper = gizmo.getHelper();
  /** `show` is moving it: what that changes is on its way to the screen already. */
  let showing = false;

  // ---------------------------------------------------------------- a gesture on the selection

  /**
   * A drag under way: the stand-in as it began and as it was last written, the
   * entities it moves -- each once, one under another selected going with it --
   * with its local `Transform` and its world pose as it began and its
   * parent's world pose (still: no mover's parent moves), and whether it is
   * the one the stand-in is on, and how many have a `Transform`, for the
   * step's name. Null between drags.
   */
  let gesture: {
    from: Pose;
    last: Pose;
    count: number;
    locals: { e: Entity; at: number[]; start: Pose; parent: Pose | null; first: boolean }[];
  } | null = null;

  const standPose = (): Pose => ({ p: stand.position.toArray() as Vec3, q: stand.quaternion.toArray() as Quat, s: stand.scale.toArray() as Vec3 });

  /** A drag begins: what it moves, and from where -- each entity once, one under another selected going with it. */
  function begin(): void {
    const e = selection.primary;
    const placed = selection.list.filter((x) => world.has(x, Transform));
    const links = world.store(Hierarchy);
    const moving = movers(placed, (x) => links.parent[x]! as Entity);
    const t = world.store(Transform);
    const from = standPose();
    gesture = {
      from,
      last: from,
      count: placed.length,
      locals: moving.map((x) => ({ e: x, at: FIELDS.map((f) => t[f][x]!), start: worldPoseOf(world, x), parent: parentPoseOf(world, x), first: x === e })),
    };
  }

  /**
   * A drag let go where it began -- not past a snap step, or brought back to
   * it: each `Transform` it wrote put back to the bit, so it makes no step.
   */
  function putBack(): void {
    if (!gesture || !samePose(standPose(), gesture.from)) return;
    const t = world.store(Transform);
    for (const { e, at } of gesture.locals) {
      if (!world.alive(e) || !world.has(e, Transform)) continue;
      FIELDS.forEach((f, i) => (t[f][e] = at[i]!));
      world.moved(e);
    }
    world.flush();
  }

  /**
   * The frame the drag is made in, as TransformControls makes it: a scale
   * along the entity's own axes always, a free turn (E, XYZE) or a free move
   * (XYZ) the world's, else the space on the bar; snapped or not just now.
   */
  const frame = (): GestureFrame => {
    const free = gizmo.axis === 'E' || gizmo.axis === 'XYZE' || gizmo.axis === 'XYZ';
    const space: GizmoSpace = gizmo.mode === 'scale' ? 'local' : free ? 'world' : gizmo.space;
    return { space, snapped: gizmo.mode === 'translate' && !!gizmo.translationSnap, ...(gizmo.axis ? { axis: gizmo.axis } : {}) };
  };

  /** A step of the drag: each entity it moves from where it began, the first by the stand-in, the others after it. */
  function step(): void {
    if (!gesture) return;
    const to = standPose();
    const t = world.store(Transform);
    for (const { e, at, start, parent, first } of gesture.locals) {
      if (!world.alive(e) || !world.has(e, Transform)) continue;
      const next = gestureLocal(gizmo.mode, gesture.from, to, start, at, parent, first, frame());
      // Under a parent scaled to nothing on an axis no local pose gives it: nothing written.
      if (!next) continue;
      FIELDS.forEach((f, i) => (t[f][e] = next[i]!));
      world.moved(e);
    }
  }

  // The camera holds still while a handle is dragged. The gizmo hears each
  // press first (it is connected first), so the camera never starts that drag.
  gizmo.addEventListener('dragging-changed', (event) => {
    hold(!!event.value);
    if (event.value) return begin();
    const many = gesture && gesture.count > 1 ? ` ${gesture.count}` : '';
    putBack();
    gesture = null;
    edited(GIZMO_MODES.find((m) => m.mode === gizmo.mode)!.name + many);
  });
  gizmo.addEventListener('change', () => {
    if (!showing) changed();
  });
  gizmo.addEventListener('objectChange', () => {
    const e = selection.primary;
    if (e === NONE || !world.alive(e) || !world.has(e, Transform)) return;
    // A move that did not get past a snap step moved nothing: nothing written.
    if (!gesture) return;
    const to = standPose();
    if (samePose(to, gesture.last)) return;
    gesture.last = to;
    step();
    // World transforms worked out before the tools hear of it: what they draw from them is drawn with this frame.
    world.flush();
    moved();
  });

  // ---------------------------------------------------------------- snapping

  /** The editor's preferences: snapping's toggle and steps among them. */
  const prefs = loadPrefs();
  /** Ctrl or Cmd, as the last pointer event had it: turns snapping over. */
  let held = false;
  /** The gizmo told what snapping is now: the toggle, turned over while the key is held. */
  const applySnap = (): void => {
    const on = snapping(prefs.snap.on, held);
    gizmo.setTranslationSnap(on ? prefs.snap.move : null);
    gizmo.setRotationSnap(on ? THREE.MathUtils.degToRad(prefs.snap.turn) : null);
    gizmo.setScaleSnap(on ? prefs.snap.scale : null);
  };
  applySnap();
  /** Read off every pointer event, before the gizmo hears it -- and the camera it picks its handles through kept current. */
  const snap = (event: PointerEvent): void => {
    current();
    const pressed = event.ctrlKey || event.metaKey;
    if (pressed === held) return;
    held = pressed;
    applySnap();
  };

  return {
    objects: [stand, helper],
    get mode() {
      return gizmo.mode;
    },
    setMode(mode) {
      gizmo.setMode(mode);
    },
    get space() {
      return gizmo.space;
    },
    toggleSpace() {
      gizmo.setSpace(gizmo.space === 'world' ? 'local' : 'world');
    },
    get snap() {
      return prefs.snap;
    },
    setSnap(next) {
      Object.assign(prefs.snap, next);
      keepPref('snap', { ...prefs.snap });
      applySnap();
    },
    get dragging() {
      return gizmo.dragging;
    },
    get axis() {
      return gizmo.axis;
    },
    show(e) {
      showing = true;
      // Before each frame (the viewport's update): the handles sized through the camera drawn through.
      current();
      if (e !== NONE && world.has(e, Transform)) {
        // Mid-drag the gizmo has the stand-in; otherwise it goes where the world says.
        if (!gizmo.dragging) {
          const { p, q, s } = worldPoseOf(world, e);
          stand.position.fromArray(p);
          stand.quaternion.fromArray(q);
          stand.scale.fromArray(s);
          stand.updateMatrixWorld();
        }
        if (gizmo.object !== stand) gizmo.attach(stand);
      } else if (gizmo.object) {
        gizmo.detach();
      }
      showing = false;
    },
    connect() {
      canvas.addEventListener('pointerdown', snap, true);
      canvas.addEventListener('pointermove', snap, true);
      // Alt+left under Emulate 3 Button Mouse orbits, over a handle too (Docs/navigation.md §2): the gizmo stands aside.
      undoAlt = altThrough(canvas, gizmo);
      gizmo.connect(canvas);
    },
    disconnect() {
      canvas.removeEventListener('pointerdown', snap, true);
      canvas.removeEventListener('pointermove', snap, true);
      undoAlt?.();
      undoAlt = null;
      gizmo.disconnect();
    },
    dispose() {
      helper.dispose();
    },
  };
}
