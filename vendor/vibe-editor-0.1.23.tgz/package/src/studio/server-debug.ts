/**
 * The dev server's debugger in this page (Docs/studio.md §11, "The dev server's debugger"): a `ShellDebug` over the
 * dev server's routes and pushes, for a browser tab -- in the app the shell's preload answers (`app-shell.ts`). The
 * server attaches to this tab when it runs in a Chrome with a debugging port (VS Code's F5, "Studio (dev)"), and
 * sets the Code card's breakpoints in the game through Chrome's debugging protocol, as the app does.
 *
 * - `breakpoints()`, `toggle()`, `open()`: `GET` and `POST /__studio/debug/breakpoints`, `POST /__studio/debug/open`
 *   (the mutations through the server's write guards).
 * - `onBreakpoints`, `onHit`: the `studio:debug-breakpoints` and `studio:debug-hit` pushes.
 * - **Attached or not** (`available`, `onAvailable`): `GET /__studio/debug/state` once, then the `studio:debug-state`
 *   push -- attached to this tab (`state.page` is its `location.href`, `pageKey`): with two studio tabs the server
 *   has the newest, and the other's card says "Breakpoints are attached to another tab of this project". Not attached -- a plain `npm run dev` in an everyday browser -- the card says what would attach it
 *   (`unavailable`: the launch configuration's port, the one the server looks on) and its gutter rests, as in a
 *   browser before.
 *
 * Pure but for what it is handed: a node test drives it with stand-in calls and pushes (`server-debug.test.ts`).
 */
import type { DebugState, StudioMessage } from '@vibe/pipeline/studio-types';
import type { DebugCalls } from '../assets/api.ts';
import type { ShellDebug } from './app-shell.ts';

/** The pushes it hears: the studio's, by kind. */
export interface DebugPushes {
  on<K extends 'studio:debug-state' | 'studio:debug-breakpoints' | 'studio:debug-hit'>(kind: K, fn: (message: Extract<StudioMessage, { kind: K }>) => void): () => void;
}

/** A hub's pushes as the debugger hears them (`StudioHub.hear`). */
export function hubPushes(hub: { hear<K extends StudioMessage['kind']>(kind: K, fn: (message: Extract<StudioMessage, { kind: K }>) => void): () => void }): DebugPushes {
  return { on: (kind, fn) => hub.hear(kind, fn) };
}

/** What a breakpoint asked for with nothing attached says: what would attach one, on `port` (null: not known yet). */
export function notAttachedWords(port: number | null): string {
  return `Breakpoints need the app, or VS Code's F5 (Studio (dev))${port === null ? '' : `: its launch configuration's "port": ${port} (.vscode/launch.json)`}`;
}

/** The dev server's debugger, as the Code card uses it: a `ShellDebug` whose `available` changes. */
export interface ServerDebug extends ShellDebug {
  available(): boolean;
  unavailable(): string;
  /** Attached or let go, or the port it looks on changed; the unsubscribe. */
  onAvailable(fn: (attached: boolean) => void): () => void;
  /** Its pushes let go. */
  dispose(): void;
}

/** The words while the server is attached to another studio tab of this project (the newest it found). */
export const OTHER_TAB = 'Breakpoints are attached to another tab of this project';

/** A page's url as the tab and the server's target list both name it: origin, path and query, no hash. */
export function pageKey(url: string): string {
  try {
    const parsed = new URL(url);
    return `${parsed.origin}${parsed.pathname}${parsed.search}`;
  } catch {
    return url;
  }
}

/**
 * The dev server's debugger for the tab at `here()` (`location.href`): available only while the server is attached
 * to this tab -- with two studio tabs it attaches the newest, and the older one's breakpoints would stop only that.
 */
export function serverDebug(calls: DebugCalls, pushes: DebugPushes, here: () => string = () => (typeof location === 'undefined' ? '' : location.href)): ServerDebug {
  /** Attached to this tab. */
  let attached = false;
  /** Attached to another tab of this project. */
  let elsewhere = false;
  /** The port the server looks on, once its state is heard. */
  let port: number | null = null;
  const watchers = new Set<(attached: boolean) => void>();
  const set = (state: DebugState): void => {
    const mine = state.attached && state.page !== null && pageKey(state.page) === pageKey(here());
    const other = state.attached && !mine;
    // Told when any changes: the card's words name the port, or the other tab.
    if (mine === attached && other === elsewhere && state.port === port) return;
    port = state.port;
    attached = mine;
    elsewhere = other;
    for (const fn of watchers) fn(attached);
  };
  const offs = [pushes.on('studio:debug-state', (m) => set(m.state))];
  void calls.state().then(set, () => undefined);
  return {
    breakpoints: () => calls.breakpoints(),
    toggle: (file, line) => calls.toggle(file, line),
    open: () => calls.open(),
    onBreakpoints(fn) {
      const off = pushes.on('studio:debug-breakpoints', (m) => fn(m.list));
      offs.push(off);
      return off;
    },
    onHit(fn) {
      const off = pushes.on('studio:debug-hit', (m) => fn({ file: m.file, line: m.line }));
      offs.push(off);
      return off;
    },
    available: () => attached,
    unavailable: () => (elsewhere ? OTHER_TAB : notAttachedWords(port)),
    onAvailable(fn) {
      watchers.add(fn);
      return () => void watchers.delete(fn);
    },
    dispose() {
      for (const off of offs) off();
      watchers.clear();
    },
  };
}
