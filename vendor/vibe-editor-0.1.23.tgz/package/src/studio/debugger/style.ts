/**
 * The Debugger page's look (`page.ts` puts it in the page's head): the launcher's tokens and the few base rules the
 * page uses (`packages/studio/src/launcher/launcher.css`' -- the editor's look, dark glass cards, amber for what is
 * chosen), then its own layout -- the toolbar, the state line, the stack and the breakpoints on the left, the source
 * and the locals on the right. A string, not a `.css` file: the page is built by two hosts -- the launcher's Vite (the
 * app's Debugger window) and the project's dev server (the Debugger tab) -- and a string is the same in both.
 * Its tokens are `launcher.css`' copied by hand (the launcher's page may not import the editor): keep both the same.
 */
export const DEBUGGER_CSS = `:root {
  --ink: rgba(255, 255, 255, 0.92);
  --dim: rgba(255, 255, 255, 0.52);
  --faint: rgba(255, 255, 255, 0.3);
  --panel: rgba(16, 20, 28, 0.92);
  --raised: rgba(255, 255, 255, 0.07);
  --edge: rgba(255, 255, 255, 0.1);
  --accent: #f0a63c;
  --accent-ink: #1a1206;
  --danger: #ff6b5a;
  --radius: 14px;
  --shadow: 0 18px 40px rgba(0, 0, 0, 0.45);
  --back: #0b0e14;
  color-scheme: dark;
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  min-height: 100vh;
  background: radial-gradient(1200px 600px at 20% -10%, #1b2333, var(--back));
  color: var(--ink);
  font: 13px/1.4 ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif;
}

.top {
  display: flex;
  align-items: baseline;
  gap: 10px;
  padding: 22px 28px 8px;
}

h1 {
  margin: 0;
  font-size: 20px;
  font-weight: 650;
  letter-spacing: 0.01em;
}

h2 {
  margin: 0 0 10px;
  font-size: 13px;
  font-weight: 600;
  color: var(--dim);
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.version,
.dim {
  color: var(--dim);
}

.small {
  font-size: 12px;
}

.card {
  background: var(--panel);
  border: 1px solid var(--edge);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  padding: 16px 18px;
  min-width: 0;
}

.rows {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.mono {
  font-family: ui-monospace, Menlo, monospace;
  font-size: 12px;
  color: var(--dim);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

input {
  font: inherit;
  color: var(--ink);
  background: var(--raised);
  border: 1px solid var(--edge);
  border-radius: 8px;
  padding: 7px 9px;
}

button {
  font: inherit;
  font-weight: 600;
  color: var(--accent-ink);
  background: var(--accent);
  border: 0;
  border-radius: 8px;
  padding: 6px 12px;
  cursor: pointer;
}

button.quiet {
  color: var(--ink);
  background: var(--raised);
  border: 1px solid var(--edge);
}

button:disabled {
  cursor: default;
  opacity: 0.45;
}

.dbg-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  padding: 4px 28px 8px;
}

.dbg-tick {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 6px;
  margin-left: auto;
  color: var(--dim);
  font-size: 12px;
}

.dbg-tick input {
  width: auto;
  margin: 0;
}

.dbg-state {
  margin: 0;
  padding: 6px 28px 10px;
  font-weight: 600;
}

.dbg-state.paused {
  color: var(--accent);
}

.dbg-state.bad {
  color: var(--danger);
}

.dbg-panes {
  display: grid;
  grid-template-columns: minmax(220px, 1fr) minmax(320px, 2fr);
  gap: 16px;
  padding: 0 28px 28px;
}

@media (max-width: 700px) {
  .dbg-panes {
    grid-template-columns: 1fr;
    padding: 0 16px 16px;
  }
  .dbg-bar,
  .dbg-state {
    padding-left: 16px;
    padding-right: 16px;
  }
}

.dbg-gap {
  margin-top: 18px;
}

.dbg-frame {
  width: 100%;
  text-align: left;
  font-weight: 400;
  color: var(--ink);
  background: var(--raised);
  border: 1px solid transparent;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.dbg-frame.chosen {
  border-color: var(--accent);
}

.dbg-frame .mono {
  white-space: nowrap;
}

.dbg-frame.theirs {
  opacity: 0.6;
}

.dbg-source {
  margin: 0;
  max-height: 46vh;
  overflow: auto;
  padding: 8px 0;
  border-radius: 8px;
  background: rgba(0, 0, 0, 0.35);
  border: 1px solid var(--edge);
  font: 12px/1.5 ui-monospace, Menlo, monospace;
  color: var(--ink);
}

.dbg-line {
  display: flex;
  white-space: pre;
  padding-right: 10px;
}

.dbg-line .no {
  flex: none;
  width: 4.5em;
  padding-right: 1em;
  text-align: right;
  color: var(--faint);
  user-select: none;
}

.dbg-line.dot .no {
  color: var(--danger);
}

.dbg-line.dot .no::before {
  content: '● ';
}

.dbg-line.here {
  background: rgba(240, 166, 60, 0.18);
  box-shadow: inset 3px 0 0 var(--accent);
}

.dbg-locals {
  display: grid;
  grid-template-columns: max-content 1fr;
  gap: 2px 14px;
  font: 12px/1.5 ui-monospace, Menlo, monospace;
}

.dbg-locals .name {
  color: var(--accent);
}

.dbg-locals .value {
  color: var(--ink);
  overflow-wrap: anywhere;
}

.dbg-bp {
  width: 100%;
  text-align: left;
  font-weight: 400;
  color: var(--ink);
  background: var(--raised);
  border: 1px solid transparent;
  font-family: ui-monospace, Menlo, monospace;
  font-size: 12px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.dbg-bp::before {
  content: '● ';
  color: var(--danger);
}

/* One the game does not have set: no code on its line within reach, or its module not loaded yet. */
.dbg-bp.unbound::before {
  content: '○ ';
}

.dbg-bp:hover {
  border-color: var(--danger);
}
`;
