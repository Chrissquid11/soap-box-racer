/**
 * The Debugger's page (Docs/studio.md §13, and §11's dev server's debugger): one page, two hosts -- the app's Debugger
 * window (the launcher's `debug.html`, its transport the window's preload, `window.squidwright.debugger`) and the
 * Debugger tab of a Chrome started with a debugging port (VS Code's F5; the dev server's `GET /__studio/debugger`,
 * its transport this server's routes and pushes, `serverTransport`). `@vibe/editor/debugger`: it imports nothing but
 * its own look (`style.ts`) and the view's types, so the launcher's page builds it in as it is.
 *
 * Everything it shows comes through the transport: the whole view at each change -- the state line, the call stack
 * (a row per frame, mapped to the TypeScript), the chosen frame's source around its line and its locals, the
 * project's breakpoints -- and every button is a command sent back.
 *
 * - **The toolbar**: Continue (F5), Pause (F6), Step over (F10), Step into (F11), Step out (Shift+F11), each on when
 *   it applies, and a tick "Pause on uncaught exceptions". **The keys** are the host's own `keydown`, handed to the
 *   mounted page's `key`: this is no game's page, and MrDebug is the game's.
 * - **Another debugger's pause** (VS Code's, sharing the dev server's tab): shown, read-only -- "Paused by another
 *   debugger (VS Code)", no Continue or steps.
 * - **A frame clicked**: its locals and its source (`frame`). **A breakpoint clicked**: removed (`remove`). One the
 *   game does not have set (no code on its line within reach, its module not loaded yet) says "not set".
 * - No transport (the launcher's page opened in a browser): the host's words, and nothing to press.
 */
import type { DebugView } from '@vibe/pipeline/studio-types';
import { DEBUGGER_CSS } from './style.ts';

/** How the page reaches the debugger: the app's preload, or the dev server's routes and pushes. */
export interface DebuggerTransport {
  /** The whole view at each change; the unsubscribe. */
  on(fn: (view: DebugView) => void): () => void;
  /** continue, stepOver, stepInto, stepOut, pause, pauseOnExceptions ('uncaught' | 'none'), frame (its index), remove ({ file, line }). */
  send(command: string, arg?: unknown): Promise<void>;
  /** The view now, once the page is up. */
  hello(): Promise<DebugView>;
}

/** The mounted page: what its host hands it. */
export interface MountedDebugger {
  /** A key typed in the page (the host's `keydown`): F5, F6, F10, F11, Shift+F11 taken. */
  key(e: KeyboardEvent): void;
}

/** What `import.meta.hot` is to the server transport: a push heard, and the page's hello said. */
interface HotLike {
  on(event: string, fn: (data: unknown) => void): void;
  send?(event: string): void;
}

/** A studio page's hello to the dev server: the pipeline's `STUDIO_HELLO` (`studio-types`), its words here, as this module imports no value. */
export const DEBUGGER_HELLO = 'studio:hello';

/** The debugger's keys. */
export const DEBUGGER_KEYS: Readonly<Record<string, string>> = { F5: 'continue', F6: 'pause', F10: 'stepOver', F11: 'stepInto', 'Shift+F11': 'stepOut' };

/** A refusal's words: Electron's wrapping of a main-process error taken off. */
const words = (err: unknown): string => (err instanceof Error ? err.message : String(err)).replace(/^Error invoking remote method '[^']*': (?:Error: )?/, '');

/**
 * The dev server's transport, for the Debugger tab: `GET /__studio/debug/view`, `POST /__studio/debug/command`, and the
 * `studio:debug-view` push under `event` (the assets channel's), heard through this module's `import.meta.hot` -- the
 * project's Vite serves it, and its client connects the tab's socket, which says `DEBUGGER_HELLO` at once: the server's
 * studio pushes go to studio pages alone.
 */
export function serverTransport(event: string, fetcher: typeof fetch = (input, init) => fetch(input, init), hot: HotLike | undefined = (import.meta as { hot?: HotLike }).hot): DebuggerTransport {
  const listeners = new Set<(view: DebugView) => void>();
  hot?.on(event, (data) => {
    const message = data as { type?: unknown; kind?: unknown; view?: DebugView };
    if (message.type === 'studio' && message.kind === 'studio:debug-view' && message.view) for (const fn of listeners) fn(message.view);
  });
  hot?.send?.(DEBUGGER_HELLO);
  const answer = async (res: Response): Promise<unknown> => {
    const body = (await res.json().catch(() => ({}))) as { refused?: unknown };
    if (!res.ok) throw new Error(typeof body.refused === 'string' ? body.refused : `the dev server answered ${res.status}`);
    return body;
  };
  return {
    on(fn) {
      listeners.add(fn);
      return () => void listeners.delete(fn);
    },
    async send(command, arg) {
      await answer(await fetcher('/__studio/debug/command', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(arg === undefined ? { command } : { command, arg }) }));
    },
    hello: async () => (await answer(await fetcher('/__studio/debug/view'))) as DebugView,
  };
}

/** The page built into `doc`'s body over `transport`; with none, `absent` said on the state line. */
export function mountDebugger(transport: DebuggerTransport | null, absent: string, doc: Document = document): MountedDebugger {
  const make = <K extends keyof HTMLElementTagNameMap>(tag: K, className?: string, text?: string): HTMLElementTagNameMap[K] => {
    // mcp: typed: make's tag -- each make('button') is declared at its call
    const node = doc.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const button = (id: string, label: string, title: string, quiet: boolean): HTMLButtonElement => {
    const b = make('button', quiet ? 'quiet' : undefined, label); // mcp: none: NOT_FOR_CLAUDE.debugger -- every control of the Debugger page
    b.type = 'button';
    b.id = id;
    b.title = title;
    return b;
  };

  const style = make('style');
  style.textContent = DEBUGGER_CSS;
  doc.head.append(style);

  // ---------------------------------------------------------------- the markup
  const projectName = make('span', 'version');
  const top = make('header', 'top');
  top.append(make('h1', undefined, 'Debugger'), projectName);
  const buttons = {
    continue: button('continue', '▶ Continue', 'Continue (F5)', false),
    pause: button('pause', '⏸ Pause', 'Pause (F6)', true),
    stepOver: button('stepOver', 'Step over', 'Step over (F10)', true),
    stepInto: button('stepInto', 'Step into', 'Step into (F11)', true),
    stepOut: button('stepOut', 'Step out', 'Step out (Shift+F11)', true),
  };
  const uncaught = make('input');
  uncaught.type = 'checkbox';
  uncaught.id = 'uncaught';
  const tick = make('label', 'dbg-tick');
  tick.append(uncaught, ' Pause on uncaught exceptions');
  const bar = make('div', 'dbg-bar');
  bar.append(...Object.values(buttons), tick);
  const state = make('p', 'dbg-state', 'Asking…');
  const stack = make('div', 'rows');
  const bps = make('div', 'rows');
  const side = make('section', 'card dbg-side');
  side.append(make('h2', undefined, 'Call stack'), stack, make('h2', 'dbg-gap', 'Breakpoints'), bps, make('p', 'dim small', "Set in the Code card's gutter; a click here removes one."));
  const sourceFile = make('span', 'mono');
  const sourceTitle = make('h2', undefined, 'Source ');
  sourceTitle.append(sourceFile);
  const source = make('pre', 'dbg-source');
  const locals = make('div', 'dbg-locals');
  const main = make('section', 'card dbg-main');
  main.append(sourceTitle, source, make('h2', 'dbg-gap', 'Locals'), locals);
  const panes = make('main', 'dbg-panes');
  panes.append(side, main);
  doc.body.classList.add('debugger');
  doc.body.replaceChildren(top, bar, state, panes);
  stack.append(make('p', 'dim small', 'Running: nothing to show until it stops.'));

  let view: DebugView | null = null;

  /** A command to the debugger; its refusal on the state line. */
  function command(name: string, arg?: unknown): void {
    if (!transport) return;
    transport.send(name, arg).catch((err: unknown) => {
      state.textContent = words(err);
      state.className = 'dbg-state bad';
    });
  }

  function draw(next: DebugView): void {
    view = next;
    const paused = next.paused;
    doc.title = `Debugger · ${next.project}`;
    projectName.textContent = next.project;
    state.textContent = next.words;
    state.className = `dbg-state${next.attachError ? ' bad' : paused ? ' paused' : ''}`;
    const live = next.attachError === null;
    // Another debugger's pause (VS Code's) is shown read-only: its to step and resume.
    const ours = paused !== null && !paused.other;
    buttons.continue.disabled = !live || !ours;
    buttons.stepOver.disabled = !live || !ours;
    buttons.stepInto.disabled = !live || !ours;
    buttons.stepOut.disabled = !live || !ours;
    buttons.pause.disabled = !live || paused !== null;
    uncaught.checked = next.pauseOnExceptions === 'uncaught';
    uncaught.disabled = !live;

    if (!paused) stack.replaceChildren(make('p', 'dim small', live ? 'Running: nothing to show until it stops.' : 'Not attached.'));
    else {
      stack.replaceChildren(
        ...paused.frames.map((frame, i) => {
          // mcp: ui -- a frame of the stack shown
          const row = make('button', `dbg-frame${i === paused.selected ? ' chosen' : ''}${frame.ours ? '' : ' theirs'}`);
          row.type = 'button';
          row.title = `${frame.file}:${frame.line}:${frame.col}`;
          // The file's name and line, which tell the frames apart; its whole path on the hover.
          row.append(make('span', 'name', frame.function), make('span', 'mono', `${frame.file.slice(frame.file.lastIndexOf('/') + 1)}:${frame.line}`));
          row.addEventListener('click', () => command('frame', i));
          return row;
        }),
      );
    }

    if (next.breakpoints.length === 0) bps.replaceChildren(make('p', 'dim small', 'None.'));
    else {
      bps.replaceChildren(
        ...next.breakpoints.map((b) => {
          // mcp: ui -- a breakpoint's place shown
          const row = make('button', `dbg-bp${b.set ? '' : ' unbound'}`, `${b.file}:${b.line}`);
          row.type = 'button';
          row.title = `${b.file}:${b.line}${b.set ? '' : ' (not set: no code on this line yet)'}: a click removes it`;
          if (!b.set) row.append(make('span', 'dim', ' · not set'));
          row.addEventListener('click', () => command('remove', { file: b.file, line: b.line }));
          return row;
        }),
      );
    }

    if (!paused) {
      sourceFile.textContent = '';
      source.replaceChildren();
      locals.replaceChildren(make('span', 'dim', '—'));
      return;
    }
    const at = paused.source;
    sourceFile.textContent = `${at.file}:${at.line}`;
    if ('none' in at) source.replaceChildren(make('span', 'dim', `  No source: ${at.none}`));
    else {
      const dots = new Set(next.breakpoints.filter((b) => b.file === at.file).map((b) => b.line));
      let here: HTMLElement | null = null;
      source.replaceChildren(
        ...at.lines.map((text, i) => {
          const n = at.first + i;
          const line = make('div', `dbg-line${n === at.line ? ' here' : ''}${dots.has(n) ? ' dot' : ''}`);
          line.append(make('span', 'no', String(n)), make('span', 'text', text));
          if (n === at.line) here = line;
          return line;
        }),
      );
      (here as HTMLElement | null)?.scrollIntoView({ block: 'center' });
    }
    if (paused.locals.length === 0) locals.replaceChildren(make('span', 'dim', 'none'));
    else {
      locals.replaceChildren(...paused.locals.flatMap((l) => [make('span', 'name', l.name), make('span', 'value', l.value)]));
      if (paused.more > 0) locals.append(make('span', 'dim', '…'), make('span', 'dim', `${paused.more} more`));
    }
  }

  for (const [name, b] of Object.entries(buttons)) b.addEventListener('click', () => command(name));
  uncaught.addEventListener('change', () => command('pauseOnExceptions', uncaught.checked ? 'uncaught' : 'none'));

  if (!transport) {
    state.textContent = absent;
    state.className = 'dbg-state bad';
    for (const b of Object.values(buttons)) b.disabled = true;
    uncaught.disabled = true;
  } else {
    transport.on(draw);
    transport.hello().then(draw, (err: unknown) => {
      state.textContent = words(err);
      state.className = 'dbg-state bad';
    });
  }

  return {
    key(e) {
      const name = DEBUGGER_KEYS[`${e.shiftKey ? 'Shift+' : ''}${e.key}`];
      if (!name) return;
      e.preventDefault();
      if (e.repeat && name !== 'stepOver' && name !== 'stepInto' && name !== 'stepOut') return;
      if (!view) return;
      if (name === 'pause' ? view.paused !== null : view.paused === null || view.paused.other) return;
      command(name);
    },
  };
}
