/**
 * A stream's lines on screen (`createLogView`): the Console card's list, and the Build card's under its buttons
 * (the same view, its task's stream). A virtual list (`virtual.ts`' `mount`): rows one line high (`LINE`), the
 * list element scrolling, the rows drawn for what is in view and a little more.
 *
 * - **Follow-tail**, on at the start: new lines keep the list at its end. Scrolled up by the person, it stops,
 *   and **⤓ follow** shows to turn it back on (and to the end).
 * - **Clear** is the view's alone: lines up to the last held are not shown again here; the ring stays, and
 *   another view of the stream -- or this one, once disposed -- has them all.
 * - **The filter** (`filterLines`) and **ANSI stripped** (`stripAnsi`) for display only; a line's level
 *   (`levelOf`) is a class, `ed-log-<level>`.
 * - **Drawn once a frame** at most, whatever came meanwhile.
 */
import type { LogLine } from '@vibe/pipeline/studio-types';
import { button, control, el } from '../shell.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import { mount, type Mounted } from '../virtual.ts';
import { explainable, filterLines, levelOf, stripAnsi } from './console-lines.ts';
import type { LogStore } from './log-store.ts';

/** A row's height in pixels: shell.css' `.ed-log-line`. */
export const LINE = 18;

export interface LogView {
  /** The list, its follow button and its empty line. */
  readonly el: HTMLElement;
  /** The stream shown. */
  readonly stream: string;
  /** Another stream shown: its backlog fetched the first time, followed to its end. */
  show(stream: string): void;
  /** Only lines with `query` in them; '' for all. */
  filter(query: string): void;
  /** What is held now hidden from this view. */
  clear(): void;
  /** Laid out again: the card it is in shown. */
  refresh(): void;
  dispose(): void;
}

/** A line's Explain (the Console card's, Docs/ai-panel.md §5, A3): asked about with its stream and text, at its button. On an error or a warning line alone. */
export type ExplainLine = (stream: string, text: string, row: HTMLElement) => void;

export function createLogView(logs: LogStore, stream: string, empty = 'No lines yet.', explain: ExplainLine | null = null): LogView {
  const root = el('div', 'ed-log');
  const list = el('div', 'ed-rows ed-log-rows');
  const none = el('div', 'ed-dim ed-log-none', empty);
  const follow = button('ui', '⤓ follow', 'Follow the newest lines again', () => {
    following = true;
    follow.hidden = true;
    draw();
  }, 'ed-small ed-log-follow');
  follow.hidden = true;
  root.append(list, none, follow);

  let current = stream;
  let query = '';
  /** Each stream's last seq cleared from this view. */
  const cleared = new Map<string, number>();
  let shown: LogLine[] = [];
  let following = true;
  let frame = 0;

  const compute = (): void => {
    const after = cleared.get(current) ?? 0;
    const lines = logs.lines(current);
    shown = filterLines(after > 0 ? lines.filter((l) => l.seq > after) : lines, query);
    none.hidden = shown.length > 0;
  };
  compute();

  const rows: Mounted = mount({
    list,
    rowHeight: () => LINE,
    perRow: () => 1,
    count: () => shown.length,
    key: (i) => String(shown[i]!.seq),
    make: () => {
      const row = el('div', 'ed-log-line');
      if (!explain) return row;
      // Explain on the row's end, on hover: the line asked about, the row it is in read as it is clicked.
      const ask = control(NOT_FOR_CLAUDE.askClaude, 'ed-log-ask', 'Explain');
      ask.title = 'Ask Claude what this line means: a box here, the line goes with the prompt -- you send it';
      ask.addEventListener('click', (event) => {
        event.stopPropagation();
        explain(current, row.dataset.text ?? '', ask);
      });
      row.append(el('span', 'ed-log-text'), ask);
      return row;
    },
    update(row, i) {
      const text = stripAnsi(shown[i]!.text);
      if (explain) {
        row.dataset.text = text;
        (row.firstChild as HTMLElement).textContent = text;
        // Explain on an error or a warning alone (D7): a plain line has nothing to explain.
        (row.lastChild as HTMLElement).hidden = !explainable(text);
      } else row.textContent = text;
      row.title = text.length > 80 ? text : '';
      const level = levelOf(text);
      row.className = level ? `ed-log-line ed-log-${level}` : 'ed-log-line';
    },
  });

  /** The next frame: the lines worked out again, drawn, and at the end while following. */
  function draw(): void {
    if (frame !== 0) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      compute();
      rows.flush();
      if (following && list.clientHeight > 0) list.scrollTop = list.scrollHeight;
    });
  }

  // Scrolled up by the person: following stops.
  list.addEventListener(
    'scroll',
    () => {
      // The list hidden measures nothing, and with a frame still to draw the rows are not yet the lines: no decision then.
      if (list.clientHeight === 0 || frame !== 0) return;
      const atEnd = list.scrollTop + list.clientHeight >= list.scrollHeight - LINE;
      if (atEnd === following) return;
      following = atEnd;
      follow.hidden = atEnd;
    },
    { passive: true },
  );

  const off = logs.on((changed) => {
    if (changed === current) draw();
  });
  void logs.load(current);

  return {
    el: root,
    get stream() {
      return current;
    },
    show(next) {
      if (next === current) return;
      current = next;
      // No scroll here: the old stream's rows are still drawn, and a scroll event now would read "scrolled up"
      // and turn following off. The draw goes to the new stream's end itself.
      following = true;
      follow.hidden = true;
      void logs.load(next);
      draw();
    },
    filter(next) {
      if (next === query) return;
      query = next;
      draw();
    },
    clear() {
      const lines = logs.lines(current);
      cleared.set(current, lines.length > 0 ? lines[lines.length - 1]!.seq : 0);
      following = true;
      follow.hidden = true;
      draw();
    },
    refresh: draw,
    dispose() {
      cancelAnimationFrame(frame);
      off();
      rows.dispose();
      root.remove();
    },
  };
}
