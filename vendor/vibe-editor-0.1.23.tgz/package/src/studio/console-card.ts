/**
 * The Studio tab's Console card: the dev server's log and each task's, as the terminal showed them.
 *
 * - **A stream picker**: `server`, and `task:<name>` for every script the project lets a card run (`GET
 *   /__studio/tasks`' `allowed`) and every stream heard since (`log-store.ts`' `streams`).
 * - **The lines** (`log-view.ts`): a virtual list, follow-tail on until scrolled up (**⤓ follow** brings it back),
 *   ANSI stripped, a line's prefix (`[vibe]`, `[assets]`, `[agent]`, Vite's `[vite]`) its colour.
 * - **Explain** on an error or a warning line's end, on hover (where a dev server hosts Claude): the quick prompt by it, the line
 *   its target (Docs/ai-panel.md §5, A3), "Explain this" in it -- never sent.
 * - **Clear**: this card's view only -- the server's ring keeps every line.
 * - **The filter**: a text field marked `data-keys-field="console"` (`CONSOLE_FIELD`), whose Enter applies it
 *   and Esc clears it: MrDebug field actions the tool registers (`studio-tool.ts`, `ToolKey.field`), calling
 *   `applyFilter` and `clearFilter` -- the field listens for no key itself (CLAUDE.md), and every Esc clears,
 *   the field keeping the focus.
 *
 * Fed by the hub's log: `studio:log` pushes from the start, the backlog fetched the first time a stream is shown.
 */
import { textInput } from '../fields.ts';
import { button, el } from '../shell.ts';
import { streamName } from './console-lines.ts';
import type { StudioAsk, StudioCard, StudioHub } from './hub.ts';
import { createLogView } from './log-view.ts';

/** The filter field's key scope (MrDebug's `data-keys-field`). */
export const CONSOLE_FIELD = 'console';

/** The Console card: its filter's keys are the tool's, which call these. */
export interface ConsoleCard extends StudioCard {
  /** The filter as typed, applied (the field's Enter). */
  applyFilter(): void;
  /** The filter emptied and applied (the field's Esc). */
  clearFilter(): void;
}

export function createConsoleCard(hub: StudioHub, ask: StudioAsk | null = null): ConsoleCard {
  const root = el('section', 'ed-studio-card ed-studio-console');
  const top = el('div', 'ed-buttons');
  const picker = el('select', 'ed-input ed-studio-stream');
  picker.title = 'Which log: the dev server\'s, or a task\'s';

  const form = el('div', 'ed-line ed-studio-filter');
  const input = textInput('', 'Filter: Enter applies, Esc clears');
  input.dataset.keysField = CONSOLE_FIELD;
  input.title = 'Only the lines with this in them: Enter applies it, Esc clears it';
  form.append(input);
  const clear = button('ui', 'Clear', 'Clear this card\'s view: the server keeps every line, and another card shows them', () => view.clear(), 'ed-small');
  top.append(picker, form, clear);

  // Explain on a line's end (Docs/ai-panel.md §5, A3): the quick prompt by it, the line its target -- never sent.
  const view = createLogView(hub.logs, 'server', 'No lines yet: the dev server has said nothing since it started.', ask ? (stream, text, row) => ask({ kind: 'log', stream, text }, 'Explain this', row) : null);
  root.append(top, view.el);


  /** The streams offered: `server`, the tasks the project may run, every one heard. */
  let offered = '';
  function fillPicker(): void {
    const streams = ['server', ...hub.allowed.map((name) => `task:${name}`), ...hub.logs.streams()];
    const unique = [...new Set(streams)];
    const now = unique.join('\n');
    if (now === offered) return;
    offered = now;
    picker.replaceChildren(
      ...unique.map((stream) => {
        const option = el('option', undefined, streamName(stream));
        option.value = stream;
        return option;
      }),
    );
    picker.value = view.stream;
  }
  picker.addEventListener('change', () => view.show(picker.value));
  fillPicker();
  const offs = [hub.on('task', fillPicker), hub.logs.on(fillPicker)];

  return {
    el: root,
    applyFilter: () => view.filter(input.value),
    clearFilter() {
      input.value = '';
      view.filter('');
    },
    show() {
      fillPicker();
      view.refresh();
    },
    hide() {},
    dispose() {
      for (const off of offs) off();
      view.dispose();
      root.remove();
    },
  };
}
