/**
 * The Studio tab's facts for a turn (Docs/terminal.md D9): what Claude's column and the terminal's prompts are told of
 * it -- the card shown (the tab up), the Code card's file with the caret's line and column, the text selected there and
 * whether it is saved, and the Problems: how many, the first `PROBLEMS_SAID`. Pure (node tests it); the tab's
 * `context()` calls it with its cards' state.
 */
import type { Problem } from '@vibe/pipeline/studio-types';
import type { ToolFact } from '../tool.ts';
import type { CodeCaret } from './code-card.ts';

/** Characters of the selected text said, at most: the rest is counted. */
export const SELECTION_SAID = 500;
/** Problems listed, at most: the rest counted. */
export const PROBLEMS_SAID = 5;
/** A problem's line, at most, in characters. */
const PROBLEM_CHARS = 200;
/** A fact's value is capped at 1000 by the server (`checkContext`): the quoted selection stays under it. */
const QUOTED_MAX = 990;

/** Whitespace and control characters each run one space: a fact is one line. */
const oneLine = (text: string): string => text.replace(/[\s\u0000-\u001f\u007f]+/g, ' ').trim();

/** The selected text as a fact's value: one line, quoted, cut at `SELECTION_SAID` and the cut said. */
export function selectionWords(text: string): string {
  const flat = oneLine(text);
  let n = Math.min(flat.length, SELECTION_SAID);
  let quoted = JSON.stringify(flat.slice(0, n));
  // Escapes lengthen it: cut further until it fits the server's cap.
  while (quoted.length > QUOTED_MAX && n > 0) {
    n = Math.floor(n * 0.8);
    quoted = JSON.stringify(flat.slice(0, n));
  }
  return n < flat.length ? `${quoted} … (${flat.length} characters in all)` : quoted;
}

/** One problem in a line: `src/game/x.ts:12:5 TS2322 Type 'string' is not…`. */
export function problemLine(p: Problem): string {
  const where = p.line > 0 ? `${p.file}:${p.line}:${p.col}` : p.file;
  const line = oneLine(`${where} ${p.code} ${p.message.split('\n')[0] ?? ''}`);
  return line.length > PROBLEM_CHARS ? `${line.slice(0, PROBLEM_CHARS - 1)}…` : line;
}

/** What the Studio tab knows now. `card`: the card shown while the tab is up, else null. */
export interface StudioNow {
  card: string | null;
  caret: CodeCaret | null;
  problems: readonly Problem[];
}

/** The tab's facts; null when it has nothing to say. */
export function studioFacts(now: StudioNow): ToolFact[] | null {
  const facts: ToolFact[] = [];
  if (now.card !== null) facts.push({ name: 'card shown', value: now.card });
  const c = now.caret;
  if (c) {
    facts.push({ name: 'Code card file', value: `${c.path}, line ${c.line}, column ${c.col}${c.unsaved ? ' (changes not saved)' : ''}` });
    if (c.selection !== null) facts.push({ name: 'selected there', value: selectionWords(c.selection) });
  }
  const n = now.problems.length;
  if (n > 0) {
    const listed = now.problems.slice(0, PROBLEMS_SAID).map(problemLine);
    facts.push({ name: `problems (${n})`, value: n > PROBLEMS_SAID ? [...listed, `and ${n - PROBLEMS_SAID} more (problems_list)`] : listed });
  }
  return facts.length > 0 ? facts : null;
}
