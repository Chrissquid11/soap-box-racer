/**
 * The studio's log as this page holds it (`studio-tool.ts` makes one; the Console card shows a stream of it, the
 * Tests and Build cards their task's): each stream's lines, the newest `KEEP`, merged by seq (`console-lines.ts`'
 * `merge`) from three sources --
 *
 * - **the pushes** (`studio:log`, which `take` is handed): appended; one whose first line is past the last held
 *   leaves a gap, filled by one `GET /__studio/log?stream=&since=` (one at a time a stream, once more if another
 *   came meanwhile);
 * - **the backlog** (`load`): one `GET log?stream=&since=0` the first time a stream is shown, merged with whatever
 *   pushes came while it was on its way;
 * - nothing else: Clear is a view's (`log-view.ts`), never the store's -- the ring stays.
 *
 * No DOM: node tests it with a stand-in `GET` (`console.test.ts`).
 */
import type { LogAnswer, LogLine } from '@vibe/pipeline/studio-types';
import { KEEP, gapAfter, merge } from './console-lines.ts';

export interface LogStore {
  /** The stream's lines held, in order by seq. */
  lines(stream: string): readonly LogLine[];
  /** Every stream heard or loaded, in the order first met. */
  streams(): readonly string[];
  /** The stream's backlog asked for once (later calls answer the same). */
  load(stream: string): Promise<void>;
  /** A `studio:log` push's lines. */
  take(stream: string, lines: readonly LogLine[]): void;
  /** Told after a stream's lines change. Returns the undo. */
  on(fn: (stream: string) => void): () => void;
  dispose(): void;
}

interface Held {
  lines: LogLine[];
  /** The backlog asked for: its promise. */
  loading: Promise<void> | null;
  /** Its backlog in, so a gap means lines missed (before it, a push's first lines are what the backlog brings). */
  loaded: boolean;
  /** A gap's `GET` under way, and the `since` the next one asks from (null: none wanted). */
  filling: Promise<void> | null;
  wanted: number | null;
}

/** The seq after which `lines` skip one or more, from `from` on: the first hole's start, or null for none. */
function holeAfter(lines: readonly LogLine[], from: number): number | null {
  for (let i = 1; i < lines.length; i++) {
    const before = lines[i - 1]!.seq;
    if (before >= from && lines[i]!.seq > before + 1) return before;
  }
  return null;
}

/** `get(stream, since)` is `GET /__studio/log`; `warn` says a fetch that failed (the console, by default). */
export function createLogStore(get: (stream: string, since: number) => Promise<LogAnswer>, warn: (text: string) => void = (text) => console.warn(text), keep = KEEP): LogStore {
  const held = new Map<string, Held>();
  const listeners = new Set<(stream: string) => void>();
  let disposed = false;

  const of = (stream: string): Held => {
    let h = held.get(stream);
    if (!h) {
      h = { lines: [], loading: null, loaded: false, filling: null, wanted: null };
      held.set(stream, h);
    }
    return h;
  };
  const tell = (stream: string): void => {
    if (disposed) return;
    for (const fn of listeners) fn(stream);
  };
  const last = (h: Held): number => (h.lines.length > 0 ? h.lines[h.lines.length - 1]!.seq : 0);

  /** What the server has after `since`, merged in: one `GET` at a time a stream, the earliest `since` asked meanwhile next. */
  function fill(stream: string, since: number): Promise<void> {
    const h = of(stream);
    h.wanted = h.wanted === null ? since : Math.min(h.wanted, since);
    if (h.filling) return h.filling;
    h.filling = (async () => {
      try {
        while (h.wanted !== null && !disposed) {
          const from = h.wanted;
          h.wanted = null;
          const answer = await get(stream, from);
          h.lines = merge(h.lines, answer.lines, keep);
          tell(stream);
        }
      } catch (err) {
        h.wanted = null;
        warn(`[studio] the ${stream} log's missing lines were not fetched: ${(err as Error).message}`);
      } finally {
        h.filling = null;
      }
    })();
    return h.filling;
  }

  return {
    lines: (stream) => held.get(stream)?.lines ?? [],
    streams: () => [...held.keys()],
    load(stream) {
      const h = of(stream);
      return (h.loading ??= (async () => {
        try {
          const answer = await get(stream, 0);
          h.lines = merge(h.lines, answer.lines, keep);
          h.loaded = true;
          tell(stream);
          // A push past the backlog's end while it was on its way, with lines missing between: those.
          const hole = holeAfter(h.lines, answer.seq);
          if (hole !== null) await fill(stream, hole);
        } catch (err) {
          h.loading = null;
          warn(`[studio] the ${stream} log was not fetched: ${(err as Error).message}`);
        }
      })());
    },
    take(stream, lines) {
      if (lines.length === 0) return;
      const h = of(stream);
      const gap = gapAfter(h.loaded ? last(h) : null, lines);
      h.lines = merge(h.lines, lines, keep);
      tell(stream);
      if (gap !== null) void fill(stream, gap);
    },
    on(fn) {
      listeners.add(fn);
      return () => void listeners.delete(fn);
    },
    dispose() {
      disposed = true;
      listeners.clear();
    },
  };
}
