/**
 * The Console card's pure parts (`console-card.ts`, `log-store.ts`, `log-view.ts`): a line's ANSI taken off for
 * display (`stripAnsi`), its level by its prefix (`levelOf`, a CSS class only), a stream's lines merged with what
 * came by seq (`merge`), the gap a push leaves (`gapAfter`), and the filter (`filterLines`). No DOM: node tests them
 * (`console.test.ts`).
 */
import type { LogLine } from '@vibe/pipeline/studio-types';

/** A stream's lines kept here: as many as the server's ring holds. */
export const KEEP = 2000;

/**
 * ANSI's escapes: CSI (`ESC [ … final`: colours, the cursor, erasing), OSC (`ESC ] … BEL` or `ESC ] … ESC \`:
 * a title, a hyperlink's ends) and the two-byte ones (`ESC` and one of `@`-`_`).
 */
const ANSI = /\u001b\[[0-?]*[ -/]*[@-~]|\u001b\][^\u0007\u001b]*(?:\u0007|\u001b\\)|\u001b[@-Z\\-_]|\u009b[0-?]*[ -/]*[@-~]/g;

/** `text` with every ANSI escape taken off: what the card shows (the ring keeps them). */
export const stripAnsi = (text: string): string => text.replace(ANSI, '');

/** Who said a line, by its prefix after an optional clock (`10:42:01 AM [vite] page reload`): a CSS class's word. */
export type Level = 'vibe' | 'assets' | 'agent' | 'studio' | 'checks' | 'vite' | 'run' | 'error' | null;

const PREFIX = /^(?:\d{1,2}:\d{2}:\d{2}(?:\s?[AP]M)?\s+)?\[(vibe|assets|agent|studio|checks|vite)\]/i;

/** A line's level, read off its stripped text: `[vibe]`, `[assets]`, `[agent]`, `[studio]`, `[checks]`, Vite's `[vite]`; `$ npm run …` a task's start; `error:`/`Error:` an error; else none. */
export function levelOf(text: string): Level {
  const prefix = PREFIX.exec(text);
  if (prefix) return prefix[1]!.toLowerCase() as Level;
  if (text.startsWith('$ ')) return 'run';
  if (/^\s*(?:\w*Error\b|error\b|npm (?:ERR!|error))/.test(text)) return 'error';
  return null;
}

/** A warning, said in words: the line's level is no prefix's, but it is one to explain (D7). */
const WARNING = /\bwarn(?:ing)?\b/i;

/** Is a line one Explain is offered on (Docs/ai-panel.md D7): an error, or a warning. */
export function explainable(text: string): boolean {
  return levelOf(text) === 'error' || WARNING.test(text);
}

/**
 * `have` and `incoming` as one list, in order by seq, each seq once (`have`'s kept), the newest `keep`. The usual
 * case -- every one new and after the last -- appends without sorting.
 */
export function merge(have: readonly LogLine[], incoming: readonly LogLine[], keep = KEEP): LogLine[] {
  if (incoming.length === 0) return have.length > keep ? have.slice(have.length - keep) : [...have];
  const last = have.length > 0 ? have[have.length - 1]!.seq : 0;
  let ordered = true;
  for (let i = 0; i < incoming.length; i++) {
    if (incoming[i]!.seq <= (i === 0 ? last : incoming[i - 1]!.seq)) {
      ordered = false;
      break;
    }
  }
  let out: LogLine[];
  if (ordered) out = [...have, ...incoming];
  else {
    const bySeq = new Map<number, LogLine>();
    for (const line of incoming) bySeq.set(line.seq, line);
    for (const line of have) bySeq.set(line.seq, line);
    out = [...bySeq.values()].sort((a, b) => a.seq - b.seq);
  }
  return out.length > keep ? out.slice(out.length - keep) : out;
}

/**
 * Lines a push left out: `since` to ask the server for (`GET log?since=`), or null for none. `last` is the seq
 * of the last line held; a push whose first line is past `last + 1` leaves a gap -- unless nothing is held yet and
 * the backlog is still to come (`last` null), which the backlog's own `GET` covers.
 */
export function gapAfter(last: number | null, incoming: readonly LogLine[]): number | null {
  if (last === null || incoming.length === 0) return null;
  return incoming[0]!.seq > last + 1 ? last : null;
}

/** The lines whose stripped text has `query` in it, any case; all for an empty query. */
export function filterLines(lines: readonly LogLine[], query: string): LogLine[] {
  const q = query.trim().toLowerCase();
  if (q === '') return [...lines];
  return lines.filter((line) => stripAnsi(line.text).toLowerCase().includes(q));
}

/** A stream's name for the picker: `server`, `task: build`. */
export const streamName = (stream: string): string => (stream.startsWith('task:') ? `task: ${stream.slice(5)}` : stream);
