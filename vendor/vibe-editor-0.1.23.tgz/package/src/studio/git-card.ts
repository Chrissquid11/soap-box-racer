/**
 * The Studio tab's Git card (`Mod+Alt+6`): what `git status`, `add`, `commit`, `switch`, `push`, `pull` and `log`
 * were in a terminal, over the dev server's `/__studio/git/` routes (`hub.calls.git`).
 *
 * - **The head**, a row a repository (the engine's too, in source mode, named): the branch picker -- a `select` of
 *   the branches, "+ new branch…" last, which shows a name field and Create -- how far ahead and behind its
 *   upstream is as last fetched, and Pull and Push.
 * - **The changes**: a row each (`git/model.ts`' `rowsFrom`) -- a tick (ticked goes in the commit; every row ticked
 *   as it first comes, an untracked file too, and kept by path across a refresh), the kind as a letter, the path.
 *   A path's click opens its diff in the Code card (`hub.openDiff(path, 'HEAD')`: as last committed against the
 *   disk); an untracked one, which `HEAD` has not, the file (`openFile`). An all box over them.
 * - **The message**: a `textarea` marked `data-keys-field="git"` (`GIT_FIELD`), whose `Mod+Enter` commits -- a
 *   MrDebug field action the tool registers, the field listening for no key itself. **Commit** makes one commit a
 *   repository of the ticked rows (`commitPlan`: a rename's old path with it). **Draft with Claude** writes the
 *   message (`git/draft.ts`): a turn in the card's own conversation, titled Git, that may change no file -- the
 *   button saying "Drafting…" meanwhile, the Claude card left as it is.
 * - **The log**: the last twenty commits, a row each (the short hash, the subject, the author, the date); a row
 *   unfolds its files with their `+`/`-`; a file's click opens its diff from before that commit (`openDiff(path,
 *   '<hash>^')`) to now.
 * - **What asks first** -- a checkout with local changes, every push and pull -- shows the server's words in a bar
 *   (`askStep`): "Push 2 commits on main to origin/main?  Push · Cancel". Their lines go to the Console's `git`
 *   stream as they come; the last one is the status line's.
 * - **The status line**: what git last said, or why not.
 * - **Wide** (the card 1100 px or more, on the page the Studio tab covers): the changes, the message and its buttons
 *   in a column on the left, the log in one on the right; narrower, one above the other.
 *
 * Refreshed: the status as the card shows and after every action, and on `studio:file-changed` (500 ms after the
 * last, while shown); the log and the branches as it shows and after a commit, a checkout or
 * a pull.
 */
import type { GitBranches, GitRepoStatus } from '@vibe/pipeline/studio-types';
import { createAgentApi } from '../agent/api.ts';
import { textInput } from '../fields.ts';
import { button, control, el } from '../shell.ts';
import { draftMessage, draftPrompt } from './git/draft.ts';
import { IDLE, KIND_LETTER, allState, askSentence, askStep, commitPlan, confirmWord, draftPaths, isAsk, keepNaming, logRows, rowsFrom, runningWord, setTick, tickAll, type AskAction, type AskBar, type AskEvent, type GitRow, type LogRow, type Naming } from './git/model.ts';
import type { StudioCard, StudioHub } from './hub.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';

/** The message box's key scope (MrDebug's `data-keys-field`): its `Mod+Enter` commits. */
export const GIT_FIELD = 'git';

/** A file change heard is read this long after the last one. */
const DEBOUNCE_MS = 500;

/** The branch picker's last option: a new branch. */
const NEW_BRANCH = '\0new';

export interface GitCard extends StudioCard {
  /** The ticked rows committed with the message (`Mod+Enter` in the box). */
  commit(): Promise<void>;
  /** Everything read again. */
  refresh(): Promise<void>;
}

export function createGitCard(hub: StudioHub): GitCard {
  const calls = hub.calls.git;
  const agent = createAgentApi();
  const root = el('section', 'ed-studio-card ed-studio-git');

  const heads = el('div', 'ed-studio-git-heads');
  const ask = el('div', 'ed-studio-git-ask');
  ask.hidden = true;
  const askWords = el('span', 'ed-studio-git-ask-words');
  const askYes = button('ui', 'Confirm', 'Do it', () => void confirmAsk(), 'ed-small ed-accent');
  // Cancelled: the picker back on the branch it is on (a checkout's ask left it on the one not switched to).
  const askNo = button('ui', 'Cancel', 'Leave it', () => {
    step({ type: 'cancel' });
    drawHeads();
  }, 'ed-small');
  ask.append(askWords, askYes, askNo);

  const changesHead = el('div', 'ed-studio-git-changes-head');
  const all = el('input');
  all.type = 'checkbox';
  all.title = 'Tick every change, or none';
  all.addEventListener('change', () => {
    rows = tickAll(rows, all.checked);
    drawRows();
  });
  const changesTitle = el('span', 'ed-dim', 'Changes');
  changesHead.append(all, changesTitle);
  const changes = el('div', 'ed-studio-list ed-studio-git-changes');

  const message = el('textarea', 'ed-input ed-studio-git-message');
  message.dataset.keysField = GIT_FIELD;
  message.spellcheck = true;
  message.rows = 4;
  message.placeholder = 'The commit message: a subject line, a blank line, a body (Mod+Enter commits)';
  const actions = el('div', 'ed-buttons');
  const draft = button(NOT_FOR_CLAUDE.askClaude, 'Draft with Claude', 'Claude writes the message from the ticked changes\' diff, changing no file', () => void draftNow());
  const commitButton = button('git_commit', 'Commit', 'Commit the ticked changes with this message (Mod+Enter in the box)', () => void commitNow(), 'ed-accent');
  actions.append(draft, commitButton);

  const logTitle = el('div', 'ed-dim', 'Log');
  const log = el('div', 'ed-studio-list ed-studio-git-log');
  const line = el('div', 'ed-status ed-studio-git-status');
  // Two columns, the changes and the message beside the log, while the card is wide enough (shell.css); else one.
  const work = el('div', 'ed-studio-git-col');
  work.append(changesHead, changes, message, actions);
  const history = el('div', 'ed-studio-git-col');
  history.append(logTitle, log);
  const cols = el('div', 'ed-studio-git-cols');
  cols.append(work, history);
  root.append(heads, ask, cols, line);

  let rows: GitRow[] = [];
  let repos: GitRepoStatus[] = [];
  let branches: GitBranches[] = [];
  let logs: LogRow[] = [];
  const open = new Set<string>();
  let bar: AskBar = IDLE;
  /**
   * The "+ new branch…" field open, and its text: kept across every redraw of the head row (`keepNaming`). One at a
   * time: opening it in one repository drops the other repository's.
   */
  let naming: Naming | null = null;
  let busy = false;
  let drafting = false;
  let conversation: string | null = null;
  let visible = false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  let disposed = false;

  const say = (text: string, bad = false): void => {
    line.textContent = text;
    line.classList.toggle('ed-bad', bad);
  };
  const failed = (what: string) => (err: Error) => say(`${what}: ${err.message}`, true);

  // ---------------------------------------------------------------- reading

  async function readStatus(): Promise<void> {
    try {
      const status = await calls.status();
      if (disposed) return;
      repos = status.repos;
      naming = keepNaming(naming, repos);
      rows = rowsFrom(status, rows);
      drawHeads();
      drawRows();
    } catch (err) {
      failed('git status')(err as Error);
    }
  }

  async function readLogAndBranches(): Promise<void> {
    try {
      const [l, b] = await Promise.all([calls.log(), calls.branches()]);
      if (disposed) return;
      logs = logRows(l);
      branches = b;
      drawHeads();
      drawLog();
    } catch (err) {
      failed('git log')(err as Error);
    }
  }

  async function refresh(): Promise<void> {
    await Promise.all([readStatus(), readLogAndBranches()]);
  }

  // A file changed on disk: the status read again 500 ms after the last -- while shown; showing reads it anyway.
  const offFile = hub.onFile(() => {
    if (!visible) return;
    clearTimeout(timer);
    timer = setTimeout(() => void readStatus(), DEBOUNCE_MS);
  });

  // ---------------------------------------------------------------- drawing

  function drawHeads(): void {
    const many = repos.length > 1;
    // The name field rebuilt as it was: its text from `naming`, its focus and caret if it had them.
    const typing = document.activeElement instanceof HTMLInputElement && heads.contains(document.activeElement) ? document.activeElement : null;
    const caret = typing ? [typing.selectionStart, typing.selectionEnd] as const : null;
    let refocus = null as HTMLInputElement | null;
    heads.replaceChildren(
      ...repos.map((r) => {
        const row = el('div', 'ed-buttons ed-studio-git-head');
        if (many) row.append(el('span', 'ed-studio-git-repo', r.repo));
        const picker = el('select', 'ed-input ed-studio-git-branch');
        picker.title = 'The branch: another switches to it, "+ new branch…" starts one here';
        const list = branches.find((b) => b.repo === r.repo)?.branches ?? [];
        const names = list.map((b) => b.name);
        if (r.branch !== null && !names.includes(r.branch)) names.unshift(r.branch);
        if (r.branch === null) {
          const detached = el('option', undefined, '(detached HEAD)');
          detached.value = '';
          picker.append(detached);
        }
        for (const name of names) {
          const option = el('option', undefined, name);
          option.value = name;
          picker.append(option);
        }
        const fresh = el('option', undefined, '+ new branch…');
        fresh.value = NEW_BRANCH;
        picker.append(fresh);
        const mine = naming !== null && naming.repo === r.repo ? naming : null;
        picker.value = mine !== null ? NEW_BRANCH : (r.branch ?? '');
        const field = el('span', 'ed-studio-git-new');
        field.hidden = mine === null;
        const name = textInput(mine?.text ?? '', 'new branch name');
        name.addEventListener('input', () => {
          naming = { repo: r.repo, from: naming?.repo === r.repo ? naming.from : r.branch, text: name.value };
        });
        if (mine !== null && typing !== null) refocus = name;
        const create = button('git_branch', 'Create', 'Start this branch here, from HEAD', () => void checkout({ what: 'checkout', repo: r.repo, branch: name.value.trim(), create: true }), 'ed-small');
        const cancel = button('ui', 'Cancel', 'No new branch', () => {
          naming = null;
          field.hidden = true;
          picker.value = r.branch ?? '';
        }, 'ed-small');
        field.append(name, create, cancel);
        picker.addEventListener('change', () => {
          if (picker.value === NEW_BRANCH) {
            naming = { repo: r.repo, from: r.branch, text: '' };
            field.hidden = false;
            name.value = '';
            name.focus();
            return;
          }
          if (naming?.repo === r.repo) naming = null;
          field.hidden = true;
          if (picker.value !== '' && picker.value !== r.branch) void checkout({ what: 'checkout', repo: r.repo, branch: picker.value });
        });
        const upstream = el('span', 'ed-dim ed-studio-git-ab', r.upstream === null ? 'no upstream' : `↑${r.ahead} ↓${r.behind}`);
        upstream.title = r.upstream === null ? 'No upstream yet: Push sets one' : `Ahead of ${r.upstream} by ${r.ahead}, behind by ${r.behind}, as last fetched`;
        const pull = button('git_pull', 'Pull', r.upstream === null ? 'No upstream to pull from' : `Pull ${r.upstream}, fast-forward only`, () => void first({ what: 'pull', repo: r.repo }), 'ed-small');
        pull.disabled = busy || r.upstream === null || r.branch === null;
        const push = button('git_push', 'Push', r.upstream === null ? 'Push, setting the upstream' : `Push to ${r.upstream}`, () => void first({ what: 'push', repo: r.repo }), 'ed-small');
        push.disabled = busy || r.branch === null;
        picker.disabled = busy;
        create.disabled = busy;
        cancel.disabled = busy;
        row.append(picker, field, upstream, pull, push);
        return row;
      }),
    );
    if (refocus !== null) {
      refocus.focus();
      if (caret !== null) refocus.setSelectionRange(caret[0], caret[1]);
    }
    if (repos.length === 0) heads.replaceChildren(el('div', 'ed-dim', 'No git repository here: git init makes one.'));
  }

  function drawRows(): void {
    const state = allState(rows);
    all.checked = state === 'all';
    all.indeterminate = state === 'some';
    all.disabled = rows.length === 0;
    changesTitle.textContent = rows.length === 0 ? 'No changes' : `Changes (${rows.filter((r) => r.ticked).length} of ${rows.length} ticked)`;
    changes.replaceChildren(
      ...rows.map((r) => {
        const row = el('div', 'ed-studio-git-row');
        const tick = el('input');
        tick.type = 'checkbox';
        tick.checked = r.ticked;
        tick.title = 'Ticked: goes in the commit';
        tick.addEventListener('change', () => {
          rows = setTick(rows, r.repo, r.path, tick.checked);
          drawRows();
        });
        const letter = el('span', `ed-studio-git-kind ed-studio-git-${r.kind}`, KIND_LETTER[r.kind]);
        letter.title = `${r.kind}${r.staged ? ', staged' : ''}`;
        const path = control('ui', 'ed-studio-row ed-studio-git-path', r.from !== undefined ? `${r.from} → ${r.path}` : r.path);
        path.title = r.kind === 'untracked' ? 'Open the file in the Code card' : r.kind === 'deleted' ? 'Its diff: as last committed, against nothing' : 'Its diff: as last committed, against the disk';
        path.addEventListener('click', () => {
          const go = r.kind === 'untracked' ? hub.openFile(r.path) : hub.openDiff(r.path, 'HEAD');
          void go.catch(failed(r.path));
        });
        row.append(tick, letter, path);
        return row;
      }),
    );
    commitButton.disabled = busy || commitPlan(rows).length === 0;
    draft.disabled = busy || drafting || commitPlan(rows).length === 0;
  }

  function drawLog(): void {
    log.replaceChildren(
      ...(logs.length === 0
        ? [el('div', 'ed-dim', 'No commits yet.')]
        : logs.map((c) => {
            const item = el('div', 'ed-studio-git-commit');
            const head = control('ui', 'ed-studio-row ed-studio-git-entry');
            head.title = `${c.hash}${repos.length > 1 ? ` (${c.repo})` : ''}: its files`;
            head.append(el('span', 'ed-studio-git-hash', c.short), el('span', 'ed-studio-git-subject', c.subject), el('span', 'ed-dim', ` ${c.author}, ${c.when}`));
            const files = el('div', 'ed-studio-git-files');
            files.hidden = !open.has(c.hash);
            for (const f of c.files) {
              const file = control('ui', 'ed-studio-row ed-studio-git-file');
              file.title = `Its diff from before ${c.short} to now`;
              file.append(el('span', 'ed-studio-git-plus', f.plus), el('span', 'ed-studio-git-minus', f.minus), el('span', undefined, f.path));
              file.addEventListener('click', () => void hub.openDiff(f.path, `${c.hash}^`).catch(failed(f.path)));
              files.append(file);
            }
            if (c.files.length === 0) files.append(el('div', 'ed-dim', 'No files of the project in it.'));
            head.addEventListener('click', () => {
              if (open.has(c.hash)) open.delete(c.hash);
              else open.add(c.hash);
              files.hidden = !open.has(c.hash);
            });
            item.append(head, files);
            return item;
          })),
    );
  }

  function drawAsk(): void {
    ask.hidden = bar.state === 'idle';
    if (bar.state === 'idle') return;
    askWords.textContent = bar.state === 'asking' ? askSentence(bar.words) : runningWord(bar.action);
    askYes.textContent = confirmWord(bar.action);
    askYes.hidden = bar.state !== 'asking';
    askNo.hidden = bar.state !== 'asking';
  }

  const step = (event: AskEvent): void => {
    bar = askStep(bar, event);
    drawAsk();
  };

  const setBusy = (now: boolean): void => {
    busy = now;
    drawHeads();
    drawRows();
  };

  // ---------------------------------------------------------------- acting

  /** A checkout, push or pull asked the first time: its ask in the bar, or (a clean checkout) done. */
  async function first(action: AskAction): Promise<void> {
    try {
      const answer =
        action.what === 'checkout'
          ? await calls.checkout(action.repo, action.branch ?? '', { create: action.create === true })
          : action.what === 'push'
            ? await calls.push(action.repo)
            : await calls.pull(action.repo);
      step({ type: 'answered', action, answer });
      if (!isAsk(answer)) {
        say(answer.lines.at(-1) ?? `${confirmWord(action)}: done`);
        await afterRun(action);
      }
    } catch (err) {
      failed(action.what)(err as Error);
      await readStatus();
    }
  }

  async function checkout(action: AskAction): Promise<void> {
    if (!action.branch) {
      say('A new branch needs a name', true);
      return;
    }
    await first(action);
  }

  async function confirmAsk(): Promise<void> {
    if (bar.state !== 'asking') return;
    const action = bar.action;
    step({ type: 'confirm' });
    setBusy(true);
    say(`${runningWord(action)} (its lines in the Console, stream git)`);
    try {
      const answer =
        action.what === 'checkout'
          ? await calls.checkout(action.repo, action.branch ?? '', { create: action.create === true, confirm: true })
          : action.what === 'push'
            ? await calls.push(action.repo, true)
            : await calls.pull(action.repo, true);
      say(isAsk(answer) ? answer.ask : (answer.lines.at(-1) ?? `${confirmWord(action)}: done`));
    } catch (err) {
      failed(action.what)(err as Error);
    } finally {
      step({ type: 'ended' });
      setBusy(false);
      await afterRun(action);
    }
  }

  async function afterRun(action: AskAction): Promise<void> {
    if (action.what === 'push') await readStatus();
    else await refresh();
  }

  async function commitNow(): Promise<void> {
    const plan = commitPlan(rows);
    const text = message.value.trim();
    if (plan.length === 0) return say('Nothing ticked to commit', true);
    if (text === '') return say('The commit needs a message: write one, or Draft with Claude', true);
    if (drafting) return say('Claude is still drafting the message: wait, or commit after', true);
    if (busy) return;
    setBusy(true);
    const made: string[] = [];
    try {
      for (const group of plan) {
        const done = await calls.commit(group.repo, message.value, group.paths);
        made.push(plan.length > 1 ? `${done.short} (${group.repo})` : done.short);
      }
      message.value = '';
      say(`Committed ${made.join(', ')}`);
    } catch (err) {
      failed(made.length > 0 ? `Committed ${made.join(', ')}, then` : 'Commit')(err as Error);
    } finally {
      setBusy(false);
      await refresh();
    }
  }

  async function draftNow(): Promise<void> {
    const paths = draftPaths(rows);
    if (paths.length === 0 || drafting) return;
    drafting = true;
    draft.textContent = 'Drafting…';
    drawRows();
    say('Claude is writing the message (the Git conversation in the Claude card)…');
    try {
      const diff = await calls.diff(paths);
      const files = rows.filter((r) => r.ticked);
      const answer = await draftMessage(agent, draftPrompt(files, diff), { conversation, stopped: () => disposed });
      conversation = answer.conversation;
      if (disposed) return;
      message.value = answer.text;
      say('Drafted: read it, change it, then Commit');
    } catch (err) {
      if (!disposed) failed('Draft')(err as Error);
    } finally {
      drafting = false;
      draft.textContent = 'Draft with Claude';
      drawRows();
    }
  }

  drawHeads();
  drawRows();
  drawLog();
  drawAsk();

  return {
    el: root,
    commit: commitNow,
    refresh,
    show() {
      visible = true;
      void refresh();
    },
    hide() {
      visible = false;
      clearTimeout(timer);
    },
    dispose() {
      disposed = true;
      clearTimeout(timer);
      offFile();
      root.remove();
    },
  };
}
