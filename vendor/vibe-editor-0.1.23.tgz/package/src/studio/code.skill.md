---
skill: studio
title: Code, tests, builds and git
when: Before checking the game's code (problems, the console, TypeScript), running its tests or a build, searching it, or committing, branching, pushing or pulling through the studio
covers:
  tools:
    - problems_list
    - console_read
    - tests_run
    - build_run
    - preview_start
    - preview_stop
    - job_cancel
    - ts_diagnostics
    - ts_definition
    - ts_references
    - ts_hover
    - code_search
    - code_move
    - code_delete
    - git_status
    - git_diff
    - git_log
    - git_commit
    - git_branch
    - git_push
    - git_pull
order: 60
---
# Code, tests, builds and git

The Studio tab (`5`) is the project's workbench: the **Console** (the dev server's log and each task's), **Problems**
(what is wrong now), **Tests**, **Build**, **Code** (the person's editor over the project's TypeScript) and **Git**.
These tools are its cards' doings, run by the dev server -- they need no studio tab open, only the dev server.

**You write code with your own Edit and Write**, as always; these tools check it, run it and commit it. The Code
card's Save is the person's, for the person's own typing. A file saved under `src/game/` swaps into the running
game with no reload; one that does not compile or cannot be served does not, and Problems says why.

## Is it right? Reads

- **`problems_list`** -- everything wrong now, as the Problems card lists it: TypeScript's errors (from its watch),
  the modules Vite cannot serve (a syntax error, an import of no file -- these stop new code swapping in), and the
  checks' findings from the last test run the studio made. Each with file, line, column and words; `file` narrows
  to one file, `limit` caps the list (200). Read it after every change to code, before saying it is done.
- **`ts_diagnostics`** -- TypeScript's errors and warnings for one `file`, fresh, through the studio's language
  server (the project's own TypeScript); no `file`, the whole project as the watch last checked it.
- **`ts_definition`**, **`ts_references`** (`declaration: false` leaves the declaration out), **`ts_hover`** (a
  name's type and doc comment) -- at `file`, `line`, `col`, each from 1 as an editor shows them. Use them to find
  what a name is and who uses it before changing it.
- **`code_search`** -- `q` a literal text (any case), `glob` to narrow the paths (`**/*.lua`; `*.ts` matches a
  file's name anywhere): over `src/`, `AssetsSource/`, `packs/`, `public/`, `engine/`, the project's `.claude`
  skills and agents and `CLAUDE.md` -- never `node_modules`, `.git` or `dist`. The first 500 hits. To read a file
  whole, Read it.
- **`console_read`** -- the Console's log: `stream` `server` (the default: the dev server's `[assets]`, `[agent]`,
  `[studio]` lines and Vite's), `task:<script>` (a test run's, a build's), or `git`; `since` an earlier answer's
  `seq` for only what is new; `filter` (any case) to keep lines that have it; `limit` the last so many (200). The
  last 2000 lines of a stream are kept.

## Moving and deleting files

- **`code_move`** -- `from` and `to`, project-relative: a file or a folder moved or renamed, as the Code card tree's
  Rename and drag. A script (or a folder of them): TypeScript rewrites every import of it, and its own relative
  imports -- the answer names the files it changed (`edited`), and says why when it could not (`imports`). A file the
  person has open in a Code card tab is not written: its new imports go into that tab (`held`), saved there if it had no unsaved changes, else waiting -- tell them
  to save it.
  Under `src/assets/`, `AssetsSource/` or `packs/` it is the Assets panel's move: the uid kept, the keys in files
  rewritten, refused while game code names the asset (change the code first). A file at `to` is refused unless
  `replace: true`; a generated file (`keys.d.ts`, the globs, `live.ts`), a folder holding one and a folder into itself
  are refused always.
- **`code_delete`** -- `paths`: gone for good (Undo this turn puts back what this turn deleted); an asset to the
  project's `.trash/`, refused while a data file names it. Ask before deleting what you did not make.

Never `mv` or `rm` a file of the project: these keep the imports and the assets whole. A new file, a copy and Save As
are your own Write.

While a Code card tab has a file open, the TypeScript tools answer for that tab's text, the person's unsaved
typing and all -- say so if what they report is not on disk.

## Tests and builds

- **`tests_run`** -- as the Tests card's Run all: `vibe test`, every test file and then the checks (the ECS rules,
  the routes, the UI, the skills …). Or `paths`, test files under `src/` (`src/game/spin.test.ts`), each run alone.
  Answered when it ends within 20 s -- files passed and failed, each failure's name and message, the checks'
  findings -- else with a job: `job_wait` it ([working in the studio](studio.md)).
- **`build_run`** -- as the Build card: `kind` `release` (the default: the typechecks, the packs, the production
  build into `dist/`), `debug` (sourcemaps and the debug tools kept) or `packs` (the content packs alone). A job
  the same way, answered with its exit and last lines. A running preview stops as a build starts.
- **`preview_start`** -- serve the last build's `dist/`: answers its url for the person to open (no tab is opened);
  `port` for a port of its own. **`preview_stop`** stops it.
- **One task at a time**: a test run or a build is refused while another runs -- wait for that one's job first.
- **`job_cancel`** -- the cards' Stop: the task running ended, and the job following it (`tests_run`'s,
  `build_run`'s) failed as stopped; a `tests_run` of several files stopped in one runs no more of them. `id` stops
  only if that job follows the task running now -- a test run's job and a test task, a build's and a build -- and is
  refused otherwise, nothing stopped (between your test run's files the person's own build may run). An export's job
  is no task's. The person may have started the task: stop only yours, or one they asked you to.

A test is a `<thing>.test.ts` beside what it tests, made with `suite()` from `@vibe/engine/testing`; the
[ECS page](../engine/ecs.md) has a system's test to copy.

## Git

The project's repository -- and in a source project the engine's submodule (`repo: 'engine'`; `project` is the
default).

- **`git_status`** -- each repository's branch, upstream, ahead and behind (as last fetched: nothing is fetched),
  and each changed file (modified, added, deleted, renamed, untracked, conflict; staged or not).
- **`git_diff`** with `paths` -- their diff against the last commit, staged or not, an untracked file as new; cut
  at 100 KB. **`git_log`** -- the last commits (`count`, 20 by default, at most 100), each with its files' lines.
- **`git_commit`** with `message` and either `paths` (exactly those, project-relative; a rename's old path beside
  its new one) or `all: true` -- **the files this turn wrote** (its Edits and Writes, its tools' files) that git
  sees changed, never a file the person changed or made. What the person staged by hand and you did not name
  stays out. One repository a commit. The commit stays: Undo this turn puts files back, never the commit away. It
  never pushes.
- **`git_branch`** -- `action` `list` (the default: a read), `create` with `name` (from HEAD, switched to), or
  `switch` with `name`. A switch with local changes is refused unless `confirm: true`, which the person is asked
  about first.
- **`git_push`** -- the current branch to its upstream, never forced (one with no upstream is pushed with
  `--set-upstream`). **`git_pull`** -- fast-forward only: one that would merge is git's refusal, said, never a
  merge.

**What asks the person**: under Ask, every write. Under Auto: `git_commit` naming any file this turn did not write
(the person's work), `git_branch` with `confirm`, `git_push` and `git_pull` (they reach another machine). Under
Unsafe auto they go by. Commit only when the person asks, and push only when they ask for that too.

## Refusals, and what they mean

| The answer says | What to do |
|---|---|
| The studio routes are not running here | the dev server is not up: ask the person to start it (`npm run dev`) |
| … is no test file: a test file's name ends .test.ts | name a `*.test.ts` |
| … is running: one task at a time | `job_status`, `job_wait` that job, then run again |
| No stream … yet: the streams are … | use one it lists |
| … is no script: TypeScript's server reads .ts and .js files | the TypeScript tools take code files |
| TypeScript's server: … | the language server's own words; `problems_list` still has the watch's errors |
| The preview did not start: … -- build first | `build_run`, then `preview_start` |
| Name the paths to commit, or all: true -- one of them | give exactly one |
| Nothing this turn wrote is changed … | name the `paths` (the person is asked about any you did not write) |
| Not switched: … -- call again with confirm: true once the person agrees | ask them, then confirm |
| git's own words (a push rejected, a pull that would merge) | say them; never force, never merge behind their back |

## A job, end to end

"Add a test that the spinner turns, and commit it."

1. `code_search` with `q: 'Spin'`, `glob: 'src/game/**'` -- hits with their `path`, `line` and `col`: the
   component in `src/game/components.ts` (line 13, col 14), the system `src/game/systems/spin.ts`. `ts_references`
   with that hit's place -- `file: 'src/game/components.ts'`, `line: 13`, `col: 14` -- to see what reads it.
2. Write `src/game/systems/spin.test.ts` with Write (the [ECS page](../engine/ecs.md) shows a system's test).
3. `problems_list` with `file: 'src/game/systems/spin.test.ts'` -- clean. `tests_run` with `paths:
   ['src/game/systems/spin.test.ts']` -- passed.
4. `tests_run` with nothing -- the whole run and the checks, so nothing else broke (`job_wait` if it answers a job).
5. `git_status`, then `git_commit` with `all: true` and a message saying what and why -- only your file goes in.
   Say the hash; push only if asked.

## Rules that bite

- Read `problems_list` after every code change: a change that does not compile never reaches the running game.
- Run the tests before saying a change works, and the whole run before a commit.
- `git_commit` with `all: true` commits only what this turn wrote; naming the person's files asks them.
- Never push, pull, switch a branch with changes, or commit unless the person asked.
- The Debugger and its breakpoints (F9, the Code card's Debugger button) are the person's: a breakpoint stops the
  game in a window of its own, where no tool answers. Read the code, run the tests and read `console_read` instead.
