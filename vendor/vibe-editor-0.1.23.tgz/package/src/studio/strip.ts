/**
 * A tab strip (`createStrip`): a row of tabs over one card's body, the body the
 * current tab's section -- any card's (`ed-tabstrip` and its parts in
 * shell.css; not `ed-strip`, the editor's tool strip down the left edge), first
 * the Studio tab's Console, Problems, Tests, Build, Code and Git (`studio-tool.ts`). Each tab's section is made the first time it is shown
 * (`make`) and kept after, hidden while another is current. Built with
 * `dom.ts`' parts, so node imports it (`strip.test.ts`, over a stand-in page).
 *
 * - **The current tab lit**: its button has `ed-active` and `aria-selected`;
 *   the others neither.
 * - **Keys**, given `keys`: the n-th tab is `Mod+Alt+<n>` (`STRIP_KEYS`), a
 *   MrDebug action through the tool's `ctx.keys` like any other, live while
 *   `keys.when()` says (the Studio tab up). Not plain `Alt+<n>`: the agent's
 *   card has those for its conversations (`TAB_KEYS.jump`), live on every tab.
 */
import { control, el } from '../dom.ts';
import type { ToolKey } from '../tool.ts';
import { tabKey } from '../editor-keys.ts';

/** The keys of the strip's first six tabs, in order: Mod+Alt+1 to 6. */
export const STRIP_KEYS: readonly string[] = (['studio console', 'studio problems', 'studio tests', 'studio build', 'studio code', 'studio git'] as const).map(tabKey);

export interface StripTab {
  /** Unique in the strip: what `show` takes. */
  id: string;
  /** On its tab. */
  name: string;
  /** Its section, made the first time it is shown. */
  make(): HTMLElement;
}

export interface StripOptions {
  tabs: readonly StripTab[];
  /** The tabs' keys, through a tool's `ctx.keys`; `when` narrows them (the tool up). Left out: no keys. */
  keys?: { add(key: ToolKey): () => void; when(): boolean };
  /** The keys' names start with it -- `studio console` -- unique among the editor's. Default `strip`. */
  name?: string;
  /** A key as a person reads it, for the tabs' tooltips (`keyLabel`, `@vibe/engine/debug`: the page's, not node's). */
  label?(key: string): string;
  /** Told after another tab is current. */
  changed?(id: string): void;
}

export interface Strip {
  /** The tabs' row and the body under it. */
  readonly el: HTMLElement;
  readonly tabs: readonly StripTab[];
  /** The id of the tab shown. */
  readonly current: string;
  /** Tab `id` shown, its section made if it was not; false for an id the strip has not. */
  show(id: string): boolean;
  /** Its keys taken away. */
  dispose(): void;
}

export function createStrip({ tabs, keys, changed, name = 'strip', label = (key) => key }: StripOptions): Strip {
  if (new Set(tabs.map((tab) => tab.id)).size !== tabs.length) throw new Error(`[strip] two tabs share an id: ${tabs.map((tab) => tab.id).join(', ')}`);
  const root = el('div', 'ed-tabstrip');
  const row = el('div', 'ed-tabstrip-tabs');
  row.setAttribute('role', 'tablist');
  const body = el('div', 'ed-tabstrip-body');
  root.append(row, body);

  const made = new Map<string, HTMLElement>();
  let current = '';
  const buttons = tabs.map((tab, n) => {
    const b = control('ui', 'ed-tabstrip-tab', tab.name);
    b.setAttribute('role', 'tab');
    const key = STRIP_KEYS[n];
    b.title = key && keys ? `${tab.name} (${label(key)})` : tab.name;
    b.addEventListener('click', () => void show(tab.id));
    row.append(b);
    return b;
  });

  function show(id: string): boolean {
    const at = tabs.findIndex((tab) => tab.id === id);
    if (at < 0) return false;
    let section = made.get(id);
    if (!section) {
      section = tabs[at]!.make();
      made.set(id, section);
      body.append(section);
    }
    for (const [other, part] of made) part.hidden = other !== id;
    buttons.forEach((b, n) => {
      b.classList.toggle('ed-active', n === at);
      b.setAttribute('aria-selected', String(n === at));
    });
    const was = current;
    current = id;
    if (was !== id) changed?.(id);
    return true;
  }

  const offKeys = keys
    ? tabs.slice(0, STRIP_KEYS.length).map((tab, n) => keys.add({ name: `${name} ${tab.id}`, mcp: 'ui', key: STRIP_KEYS[n]!, view: true, when: keys.when, help: `The ${tab.name} card`, run: () => void show(tab.id) }))
    : [];

  if (tabs[0]) show(tabs[0].id);

  return {
    el: root,
    tabs,
    get current() {
      return current;
    },
    show,
    dispose() {
      for (const off of offKeys) off();
    },
  };
}
