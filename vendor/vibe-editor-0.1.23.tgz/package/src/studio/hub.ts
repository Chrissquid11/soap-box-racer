/**
 * What the Studio tab knows of the server, in one place (`studio-tool.ts` makes it; the cards read it): the
 * pushes heard through the editor's `Live` (`studio:log`, `studio:task`, `studio:problems`, `studio:dist`,
 * `studio:preview`), and one `GET` each as it is made -- the problems, the tasks, the preview -- so the top bar's
 * pill and spinner (`StudioState`, which this sets) are right before any card is opened.
 *
 * - **The log** is a `LogStore` (`log-store.ts`): every stream's pushes taken from the start, each stream's backlog
 *   fetched the first time a card shows it.
 * - **A run** (`run`) goes through `POST /__studio/run`; its refusal's words are answered, for the card's line.
 *   What runs is told by the pushes, not the answer: two tabs agree.
 * - **A file opened** (`openFile`, `openDiff`): what the Problems card's row and the agent card's result row call;
 *   the Code card does it (`code`, the tool's: the card made if it is not, the strip switched to it). A file that
 *   changed on disk (`studio:file-changed`) is heard through `onFile`, an export job's news through `onJob`
 *   (studio mode's recovery: `editor.ts`, `recovery.ts`).
 * - **Said to the server as it is made** (`hello`, `STUDIO_HELLO` on Vite's websocket): this page is a studio page --
 *   the server's studio pushes, its probe of a reload and its debugger's look for a tab are for these alone, never the
 *   plain page's socket nor the probe frame's.
 *
 * No DOM: the cards draw, this holds.
 */
import type { TurnTarget } from '../agent/context.ts';
import type { DistAnswer, Problem, StudioMessage, TaskEnd } from '@vibe/pipeline/studio-types';
import type { StudioCalls } from '../assets/api.ts';
import type { Live, LiveEvents, StudioEvents, StudioKind } from '../assets/live.ts';
import { createLogStore, type LogStore } from './log-store.ts';
import type { StudioState } from './state.ts';

/** Ask Claude about a target from a card (Fix with Claude, Explain): the quick prompt at `at`, `text` in it, never sent. */
export type StudioAsk = (target: TurnTarget, text: string, at: HTMLElement) => void;

/** A card of the Studio tab's strip: made the first time it is shown (`studio-tool.ts`), told as it comes and goes. */
export interface StudioCard {
  readonly el: HTMLElement;
  show(): void;
  hide(): void;
  dispose(): void;
}

/** What opens a file: the Code card, brought up. */
export interface CodeOpener {
  /** `path` in a tab, the caret at `line` and `col` (from 1) when given. */
  openFile(path: string, line?: number, col?: number): Promise<void>;
  /** `path` as it was at `at` (a turn, `HEAD`) against now, side by side. */
  openDiff(path: string, at: string): Promise<void>;
}

/** A file changed or gone on disk. */
export type FileChanged = Extract<StudioMessage, { kind: 'studio:file-changed' }>;

/** What changed: the cards hear the parts they draw. */
export type HubEvent = 'problems' | 'task' | 'dist' | 'preview';

export interface StudioHub {
  readonly calls: StudioCalls;
  readonly logs: LogStore;
  /** tsc's problems, as last pushed or fetched. */
  readonly problems: readonly Problem[];
  /** The task running, or null. */
  readonly running: string | null;
  /** The task that ran last, as it ended. */
  readonly last: TaskEnd | null;
  /** The scripts a run may name in this project. */
  readonly allowed: readonly string[];
  /** `dist/` as last measured; null for none built, undefined not asked yet. */
  readonly dist: DistAnswer | null | undefined;
  /** The preview's url while one runs. */
  readonly preview: string | null;
  /** `script` run (`args`, `test`'s one file): null once it started, else the refusal's words. */
  run(script: string, args?: readonly string[]): Promise<string | null>;
  /** `dist/` measured again (`GET dist`), told. */
  measure(): Promise<void>;
  /** `path` opened in the Code card (brought up), at `line` and `col` when given. */
  openFile(path: string, line?: number, col?: number): Promise<void>;
  /** `path`'s diff from `at` (a turn, `HEAD`) to now, in the Code card. */
  openDiff(path: string, at: string): Promise<void>;
  /** Hear a file change on disk. Returns the undo. */
  onFile(fn: (message: FileChanged) => void): () => void;
  /** Hear an export job's news (the assets push's `job`): studio mode's recovery reloads when one is done. Returns the undo. */
  onJob(fn: LiveEvents['job']): () => void;
  /** Hear a studio push by its kind (the dev server's debugger's, `server-debug.ts`). Returns the undo. */
  hear<K extends StudioKind>(kind: K, fn: StudioEvents[K]): () => void;
  /** Hear a change. Returns the undo. */
  on(event: HubEvent, fn: () => void): () => void;
  dispose(): void;
}

export interface HubOptions {
  calls: StudioCalls;
  live: Pick<Live, 'on'>;
  state: StudioState;
  /** A fetch that failed: the console, by default. */
  warn?: (text: string) => void;
  /** The Code card, made and brought up: what `openFile` and `openDiff` go to. Left out: they are refused. */
  code?: () => CodeOpener;
  /** `STUDIO_HELLO` sent on the page's socket (`import.meta.hot.send`): called once, as the hub is made. */
  hello?: () => void;
}

export function createStudioHub({ calls, live, state, code, hello, warn = (text) => console.warn(text) }: HubOptions): StudioHub {
  const logs = createLogStore((stream, since) => calls.log(stream, since), warn);
  let problems: readonly Problem[] = [];
  let running: string | null = null;
  let last: TaskEnd | null = null;
  let allowed: readonly string[] = [];
  let dist: DistAnswer | null | undefined;
  let preview: string | null = null;
  let disposed = false;
  const listeners = new Map<HubEvent, Set<() => void>>();
  const tell = (event: HubEvent): void => {
    if (disposed) return;
    for (const fn of listeners.get(event) ?? []) fn();
  };
  const setProblems = (list: readonly Problem[]): void => {
    problems = list;
    state.setProblems(list.length);
    tell('problems');
  };
  const setRunning = (name: string | null): void => {
    running = name;
    state.setRunning(name);
    tell('task');
  };

  const offs = [
    live.on('studio:log', (m) => logs.take(m.stream, m.lines)),
    live.on('studio:task', (m) => {
      if (m.state === 'started') setRunning(m.name);
      else {
        last = { name: m.name, code: m.code, signal: m.signal, at: m.at };
        setRunning(running === m.name ? null : running);
      }
    }),
    live.on('studio:problems', (m) => setProblems(m.problems)),
    live.on('studio:dist', (m) => {
      dist = m.dist;
      tell('dist');
    }),
    live.on('studio:preview', (m) => {
      preview = m.url;
      tell('preview');
    }),
  ];

  // A studio page: the server's studio pushes and its probe are for this socket from now on.
  hello?.();
  const said = (what: string) => (err: Error) => warn(`[studio] ${what} not fetched: ${err.message}`);
  // The pill and the spinner from the start: one GET each.
  void calls.problems().then((list) => !disposed && setProblems(list), said('the problems'));
  void calls.tasks().then((answer) => {
    if (disposed) return;
    allowed = answer.allowed;
    last = answer.last;
    setRunning(answer.running);
  }, said('the tasks'));
  void calls.preview().then((url) => {
    if (disposed) return;
    preview = url;
    tell('preview');
  }, said('the preview'));

  return {
    calls,
    logs,
    get problems() {
      return problems;
    },
    get running() {
      return running;
    },
    get last() {
      return last;
    },
    get allowed() {
      return allowed;
    },
    get dist() {
      return dist;
    },
    get preview() {
      return preview;
    },
    async run(script, args) {
      try {
        await calls.run(script, args);
        return null;
      } catch (err) {
        return (err as Error).message;
      }
    },
    async measure() {
      try {
        dist = await calls.dist();
        tell('dist');
      } catch (err) {
        said('dist/')(err as Error);
      }
    },
    openFile: (path, line, col) => (code ? code().openFile(path, line, col) : Promise.reject(new Error('no Code card here'))),
    openDiff: (path, at) => (code ? code().openDiff(path, at) : Promise.reject(new Error('no Code card here'))),
    onFile: (fn) => live.on('studio:file-changed', fn),
    onJob: (fn) => live.on('job', fn),
    hear: (kind, fn) => live.on(kind, fn as LiveEvents[typeof kind]),
    on(event, fn) {
      let set = listeners.get(event);
      if (!set) listeners.set(event, (set = new Set()));
      set.add(fn);
      return () => void set.delete(fn);
    },
    dispose() {
      disposed = true;
      for (const off of offs) off();
      listeners.clear();
      logs.dispose();
    },
  };
}
