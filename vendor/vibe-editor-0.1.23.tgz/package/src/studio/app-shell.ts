/**
 * The Squidwright app's window around the studio (Docs/squidwright-implementation.md 5.1): what its preload
 * (`packages/studio/electron/preload.ts`) puts on `window.squidwright`, and the editor's side of it -- pure but
 * for reading the global, so a node test drives it (`app-shell.test.ts`).
 *
 * - **The global** (`SquidwrightShell`), declared here rather than in a `.d.ts`: a project's program reaches
 *   the editor's sources through its exports and includes no `.d.ts` of the editor's, but it does include this
 *   module, which the Build card imports. In a browser there is none (`appShell()` is null).
 * - **Reveal dist/** (`revealIn`): the shell's `reveal` when the global is there -- its rejection's words, less
 *   Electron's `Error invoking remote method ...` prefix, shown as they are -- else the dev server's
 *   `POST /__studio/reveal`, which answers 501 in a browser (`noShell`: the button rests).
 * - **The Game menu's commands** (`shellAction`): `play`, `pause`, `stop`, `step` the playtest's events -- what
 *   F5, F6, Shift+F5 and F10 send (`playtest-state.ts`; in the app the menu's accelerator takes the key before
 *   the page, in a browser MrDebug does: both reach the same event); `build`, `build:debug` run the Build card's tasks,
 *   `preview` what its Preview button does, `reveal-dist` the same as Reveal; any other word (the launcher's
 *   window's `new`, `open`...) is none of the studio's. The Studio tool subscribes as it is made and lets go as
 *   it is disposed (`studio-tool.ts`).
 * - **Breakpoints** (`debug`, `ShellDebug`): the shell keeps them and sets them in the game through Chrome's debugging
 *   protocol (`packages/studio/electron/debugger.ts`); the Code card's gutter toggles them and draws their dots, and
 *   marks the line the game last stopped at once it runs on (`onHit`). In a browser the dev server's debugger
 *   answers instead (`server-debug.ts`, handed to `shellDebug`): attached when the tab runs in a Chrome with a
 *   debugging port (VS Code's F5), and saying so when not (`available`).
 */
import { ApiRefused } from '../assets/api.ts';
import type { PlayButton } from '../playtest-state.ts';
import type { Breakpoint } from './code/breakpoints.ts';

/** `window.squidwright`: the app's preload, in its windows alone. */
export interface SquidwrightShell {
  shell: true;
  /** Shows `path` -- relative to the window's project, inside it -- in the Finder or the Explorer; rejects with the shell's words otherwise. */
  reveal(path: string): Promise<void>;
  /** Puts `path` -- relative to the window's project, inside it -- in the system's Trash (the Code card's Delete); absent in an app from before it. */
  trash?(path: string): Promise<void>;
  /**
   * Runs `path` -- a terminal run's `resume.command` under the window's project's `.cache/agent/` (Docs/terminal.md D5) --
   * in Terminal.app; rejects with the shell's words for any other path. Absent in an app from before it.
   */
  terminal?(path: string): Promise<void>;
  /** The menu's commands for this window; the unsubscribe. */
  onCommand(fn: (command: string, arg?: string) => void): () => void;
  /** The project's breakpoints (the shell's debugger); absent in an app from before them. */
  debug?: ShellDebug;
}

/** `window.squidwright.debug`: the project's breakpoints, kept by the shell, and its Debugger window. */
export interface ShellDebug {
  /** The project's list: `{ file, line, set }`, the project's path, a 1-based line and whether the game has it set. */
  breakpoints(): Promise<Breakpoint[]>;
  /** A breakpoint added, or taken away when it is there; the list after, answered once the game has it set (or cannot). */
  toggle(file: string, line: number): Promise<Breakpoint[]>;
  /** Where the game last stopped, told once it runs on; the unsubscribe. */
  onHit(fn: (at: Breakpoint) => void): () => void;
  /** The list changed, or a breakpoint's `set` (the Debugger window removed one, a module loaded); the unsubscribe. */
  onBreakpoints(fn: (list: Breakpoint[]) => void): () => void;
  /** The project's Debugger window, made or brought forward. */
  open(): Promise<void>;
  /** Can it set breakpoints now? The app's always can (absent); the dev server's while it is attached to this tab. */
  available?(): boolean;
  /** `available` changed; the unsubscribe. */
  onAvailable?(fn: (available: boolean) => void): () => void;
  /** While not `available`: what would make it, the words the card says (the dev server's port among them). */
  unavailable?(): string;
}

/** `ShellDebug`'s names: what the shell's preload exposes (`app-shell.test.ts` reads it for each). */
export const SHELL_DEBUG: readonly (keyof ShellDebug)[] = ['breakpoints', 'toggle', 'onHit', 'onBreakpoints', 'open'];

/**
 * The debugger in this page: the app's when there is one, else `server()`'s -- the dev server's (`server-debug.ts`) --
 * else null (an app from before it, or nothing asked).
 */
export function shellDebug(server?: () => ShellDebug): ShellDebug | null {
  const shell = appShell();
  if (shell) return shell.debug ?? null;
  return server ? server() : null;
}

declare global {
  interface Window {
    squidwright?: SquidwrightShell;
  }
}

/** The app's shell around this page, or null in a browser (or in node). */
export function appShell(): SquidwrightShell | null {
  const found = typeof window === 'undefined' ? undefined : window.squidwright;
  return found?.shell === true ? found : null;
}

/** What a Reveal came to: shown, no shell to show it (the browser's 501), or refused with words to show. */
export type RevealAnswer = { kind: 'shown' } | { kind: 'noShell' } | { kind: 'refused'; why: string };

/** A shell's rejection's words: Electron's wrapping of a main-process error taken off. */
export function shellWords(err: unknown): string {
  const text = err instanceof Error ? err.message : String(err);
  return text.replace(/^Error invoking remote method '[^']*': (?:Error: )?/, '');
}

/** `path` revealed by the shell when there is one, else by the dev server's route (`server`). */
export async function revealIn(shell: SquidwrightShell | null, server: (path: string) => Promise<void>, path: string): Promise<RevealAnswer> {
  try {
    if (shell) await shell.reveal(path);
    else await server(path);
    return { kind: 'shown' };
  } catch (err) {
    if (!shell && err instanceof ApiRefused && err.status === 501) return { kind: 'noShell' };
    return { kind: 'refused', why: shellWords(err) };
  }
}

/** A Game-menu command, as the Studio tool acts on it. */
export type ShellAction = { kind: 'play'; event: PlayButton } | { kind: 'run'; script: 'build' | 'build:debug' } | { kind: 'preview' } | { kind: 'reveal' };

/** The action a command names, or null for one that is not the studio's. */
export function shellAction(command: string): ShellAction | null {
  switch (command) {
    case 'play':
      return { kind: 'play', event: 'F5' };
    case 'pause':
      return { kind: 'play', event: 'F6' };
    case 'stop':
    case 'step':
      return { kind: 'play', event: command };
    case 'build':
    case 'build:debug':
      return { kind: 'run', script: command };
    case 'preview':
      return { kind: 'preview' };
    case 'reveal-dist':
      return { kind: 'reveal' };
    default:
      return null;
  }
}
