/**
 * The Studio tab (`studioTool`, key `5`), always among the editor's tabs (the
 * editor is studio mode's, `?studio`). Its
 * card covers the page as the Config tab's page does (`ed-config-page`'s
 * shape, `.ed-card.ed-studio`): from the tool strip's edge to the window's
 * right (Claude's column's, docked: `--ed-ai-room`), under the top bar to the
 * foot -- no side panel, no fold, no width of its own.
 * It holds a tab strip (`strip.ts`) of six cards: Console
 * (`console-card.ts`), Problems (`problems-card.ts`), Tests (`tests-card.ts`),
 * Build (`build-card.ts`), Code (`code-card.ts`: Monaco over the TypeScript
 * bridge) and Git (`git-card.ts`: status, commit, branches, log, push and
 * pull), each made the first time it is shown and told as it comes and goes
 * (`StudioCard`). The scene stays behind it, as it is: no gizmo or picking on
 * this tab. The card's header names the card shown (`Studio ·
 * Console`): not `ctx.setTitle`, which is the world's name under the editor's
 * title.
 *
 * - **What the server says, in one place** (`hub.ts`): the tool hears the
 *   studio's pushes through a `Live` of its own (`createLive` over the
 *   session's `assetApi()`) and asks once for the problems, the tasks and the
 *   preview as it is made; the cards read the hub.
 * - **The top bar's middle** (`ctx.control`): the problems count and the
 *   running task's spinner (`state.ts`), on every tab; the pill clicked brings
 *   this tab up on Problems. The hub drives them through the tool's
 *   `StudioState`, from the pushes -- not the cards, which may never be made.
 *   Then **Build**: the release build run, this tab brought up on the Build
 *   card to watch it; resting while any task runs.
 * - **Keys**: `5` the tab (the host's, as every tool's); `Mod+Alt+1`…`6` its
 *   cards while it is up (`strip.ts`' `STRIP_KEYS`, listed under Studio by `?`);
 *   Enter and Esc in the Console's filter, and the Code card's `Mod+S` and `F9`
 *   (a breakpoint on the caret's line; typed into its editor, `CODE_FIELD`) and Enter (in its search fields,
 *   `SEARCH_FIELD`), and the Git card's `Mod+Enter` (in its message box,
 *   `GIT_FIELD`), field actions (`ToolKey.field`); the Code card tree's `F2`
 *   (Rename) and `Delete`/`Backspace` while the focus is on a row of it, and
 *   its menu's arrows -- Esc that menu's (`holdsEscape`).
 * - **The app's Game menu** (`app-shell.ts`, in the Squidwright app alone): its commands heard as the tab
 *   is made and let go as it is disposed -- `play`, `pause`, `stop`, `step` the playtest's events through the
 *   host (`ctx.play`, as F5, F6, Shift+F5 and F10), the tab left as it is; `build` and `build:debug` run the Build card's tasks, `preview`
 *   does what its Preview button does, `reveal-dist` what its Reveal does -- each bringing the tab up on the
 *   Build card, as the top bar's Build does.
 * - **A file opened from a card** (`hub.openFile`, `openDiff`: the Problems
 *   card's row, the agent's result row through the host's `reveal`):
 *   the Code card made if it is not, the strip switched to it.
 */
import { STUDIO_HELLO } from '@vibe/pipeline/studio-types';
import { keyLabel } from '@vibe/engine/debug';
import { assetApi } from '../assets/boot.ts';
import { createLive } from '../assets/live.ts';
import { button, el } from '../shell.ts';
import type { EditorContext, EditorTab, ToolInstance } from '../tool.ts';
import { tabId } from '../tab-pages.ts';
import { appShell, shellAction } from './app-shell.ts';
import { createBuildCard, type BuildCard } from './build-card.ts';
import { CODE_FIELD, createCodeCard, type CodeCard } from './code-card.ts';
import { SEARCH_FIELD } from './code/search-pane.ts';
import { CONSOLE_FIELD, createConsoleCard, type ConsoleCard } from './console-card.ts';
import { GIT_FIELD, createGitCard, type GitCard } from './git-card.ts';
import { createStudioHub, type StudioAsk, type StudioCard, type StudioHub } from './hub.ts';
import { createProblemsCard } from './problems-card.ts';
import { createStudioBar, type StudioState } from './state.ts';
import { createStrip, type Strip } from './strip.ts';
import { createTestsCard } from './tests-card.ts';
import { studioFacts } from './studio-facts.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import { keyed, tabKey } from '../editor-keys.ts';

export type { StudioState } from './state.ts';

/** The Studio tab's id. */
export const STUDIO_ID = tabId('studio');

/** The strip's cards, in order: their ids are what `show` takes. */
export const STUDIO_CARDS = [
  { id: 'console', name: 'Console' },
  { id: 'problems', name: 'Problems' },
  { id: 'tests', name: 'Tests' },
  { id: 'build', name: 'Build' },
  { id: 'code', name: 'Code' },
  { id: 'git', name: 'Git' },
] as const;

/** The bar's middle, in order: the count, the spinner, Build. */
const PILL_ORDER = 10;
const SPINNER_ORDER = 20;
const BUILD_ORDER = 30;

/** A Studio tab made: the tool's instance, its state for the bar, its strip, what it knows of the server. */
export interface StudioInstance extends ToolInstance {
  readonly state: StudioState;
  readonly strip: Strip;
  readonly hub: StudioHub;
}

type CardId = (typeof STUDIO_CARDS)[number]['id'];

export const studioTool: EditorTab = {
  id: STUDIO_ID,
  name: 'Studio',
  icon: 'terminal',
  key: tabKey('studio'),
  help: 'The Studio tab (studio mode): the console, the problems, the tests, the build, the code and git',
  create: (ctx) => createStudio(ctx),
};


function createStudio(ctx: EditorContext): StudioInstance {
  const { root } = ctx;
  let visible = false;

  // The page, as the Config tab's: no side panel, so no fold and no width kept.
  const card = el('div', 'ed-card ed-page ed-studio');
  card.hidden = true;
  const head = el('div', 'ed-panel-head ed-panel-bar');
  const title = el('div', 'ed-side-title', 'Studio');
  head.append(title);

  const bar = createStudioBar(() => bringUp('problems'));
  const api = assetApi();
  const live = createLive(api);
  // A file opened from a card (a problem, a turn's result row): the Code card made if it is not, and brought up.
  const hub = createStudioHub({
    calls: api.studio,
    live,
    state: bar.state,
    hello: () => import.meta.hot?.send(STUDIO_HELLO),
    code: () => {
      bringUp('code');
      return cards.get('code') as CodeCard;
    },
  });

  /** Ask Claude about a problem or a console line (Docs/ai-panel.md §5, A3): the quick prompt, through the host; none without a Claude. */
  const asker: StudioAsk | null = ctx.canAsk ? (target, text, at) => void ctx.ask({ target, text, at }) : null;
  /** Each card, made the first time it is shown. */
  const makers: Record<CardId, () => StudioCard> = {
    console: () => createConsoleCard(hub, asker),
    problems: () => createProblemsCard(hub, asker),
    tests: () => createTestsCard(hub),
    build: () => createBuildCard(hub),
    code: () => createCodeCard({ hub, overlay: root, revealAsset: (path) => ctx.revealAsset(path) }),
    git: () => createGitCard(hub),
  };
  const cards = new Map<string, StudioCard>();
  let shown: StudioCard | null = null;

  const strip = createStrip({
    name: 'studio',
    tabs: STUDIO_CARDS.map(({ id, name }) => ({
      id,
      name,
      make: () => {
        const card = makers[id]();
        cards.set(id, card);
        return card.el;
      },
    })),
    keys: { add: (key) => ctx.keys.add(key), when: () => visible },
    label: keyLabel,
    // The header names the card shown; the card left told, the card come told.
    changed: (id) => {
      title.textContent = `Studio · ${STUDIO_CARDS.find((c) => c.id === id)?.name ?? ''}`;
      shown?.hide();
      shown = cards.get(id) ?? null;
      if (visible) shown?.show();
    },
  });
  card.append(head, strip.el);
  root.append(card);

  /** The tab up on `id`. */
  const bringUp = (id: CardId): void => {
    ctx.showTool(STUDIO_ID);
    strip.show(id);
  };
  const build = button('build_run', 'Build', 'The release build: run, and watched on the Studio tab\'s Build card', () => {
    bringUp('build');
    void (cards.get('build') as BuildCard | undefined)?.run('build');
  }, 'ed-small ed-studio-build-button');
  const drawBuild = (): void => {
    build.disabled = hub.running !== null;
    build.title = hub.running ? `${hub.running} is running: one task at a time` : 'The release build: run, and watched on the Studio tab\'s Build card';
  };
  drawBuild();
  const offBuild = hub.on('task', drawBuild);
  // The console filter's own keys: MrDebug field actions, taken only while typing into it.
  const consoleCard = (): ConsoleCard | undefined => cards.get('console') as ConsoleCard | undefined;
  const offFilterKeys = [
    ctx.keys.add({ name: 'studio filter apply', mcp: 'ui', key: 'Enter', field: CONSOLE_FIELD, view: true, when: () => visible, help: 'Apply the Console\'s filter, from its field', run: () => consoleCard()?.applyFilter() }),
    ctx.keys.add({ name: 'studio filter clear', mcp: 'ui', key: 'Escape', field: CONSOLE_FIELD, view: true, when: () => visible, help: 'Clear the Console\'s filter, from its field', run: () => consoleCard()?.clearFilter() }),
  ];
  // The Code card's Save and F9: typed into its editor (the card's root is marked `data-keys-field="code"`).
  const codeCard = (): CodeCard | undefined => cards.get('code') as CodeCard | undefined;
  const offCodeKeys = [
    ctx.keys.add({ name: 'code save', mcp: NOT_FOR_CLAUDE.codeEdit, key: 'Mod+KeyS', field: CODE_FIELD, when: () => visible && strip.current === 'code', help: 'Save the Code card\'s file, from its editor', run: () => void codeCard()?.save() }),
    ctx.keys.add({ name: 'code breakpoint', mcp: NOT_FOR_CLAUDE.debugger, key: 'F9', field: CODE_FIELD, when: () => visible && strip.current === 'code', help: 'Toggle a breakpoint on the caret\'s line (the Squidwright app sets it in the game)', run: () => codeCard()?.toggleAtCaret() }),
    ctx.keys.add({ name: 'code search', mcp: 'code_search', key: 'Enter', field: SEARCH_FIELD, view: true, when: () => visible && strip.current === 'code', help: 'Search the files, from the Code card\'s search fields', run: () => void codeCard()?.search() }),
    // The tree's: live while the focus is on a row of it (a click there keeps it), never in the editor or a field.
    ctx.keys.add({ ...keyed('code tree rename'), mcp: 'code_move', when: () => visible && strip.current === 'code' && (codeCard()?.treeFocused() ?? false), help: 'Rename the Code card tree\'s selected file or folder, where it is', run: () => codeCard()?.renameSelected() }),
    ctx.keys.add({ ...keyed('code tree delete'), mcp: 'code_delete', when: () => visible && strip.current === 'code' && (codeCard()?.treeFocused() ?? false), help: 'Delete the Code card tree\'s selected file or folder (asked first)', run: () => codeCard()?.deleteSelected() }),
    // Its right-click menu walked by the arrows, as every menu card of the editor's is.
    ctx.keys.add({ ...keyed('code menu item above'), mcp: 'ui', view: true, when: () => visible && (codeCard()?.menu.open ?? false), help: 'The item above in the Code card tree\'s menu', run: () => codeCard()?.menu.step(-1) }),
    ctx.keys.add({ ...keyed('code menu item below'), mcp: 'ui', view: true, when: () => visible && (codeCard()?.menu.open ?? false), help: 'The item below in the Code card tree\'s menu', run: () => codeCard()?.menu.step(1) }),
  ];
  // The Git card's commit: Mod+Enter typed into its message box (marked `data-keys-field="git"`).
  const offGitKeys = [
    ctx.keys.add({ name: 'git commit', mcp: 'git_commit', key: 'Mod+Enter', field: GIT_FIELD, when: () => visible && strip.current === 'git', help: 'Commit the Git card\'s ticked changes, from its message box', run: () => void (cards.get('git') as GitCard | undefined)?.commit() }),
  ];
  // The app's Game menu: the play commands the host's playtest's; each other on the Build card, the tab brought up on it.
  const offShell =
    appShell()?.onCommand((command) => {
      const action = shellAction(command);
      if (action === null) return;
      if (action.kind === 'play') {
        ctx.play(action.event);
        return;
      }
      bringUp('build');
      const buildCard = cards.get('build') as BuildCard | undefined;
      if (!buildCard) return;
      if (action.kind === 'run') void buildCard.run(action.script);
      else if (action.kind === 'preview') void buildCard.preview();
      else void buildCard.reveal();
    }) ?? (() => undefined);
  const offControls = [...offFilterKeys, ...offCodeKeys, ...offGitKeys, ctx.control(bar.pill, PILL_ORDER), ctx.control(bar.spinner, SPINNER_ORDER), ctx.control(build, BUILD_ORDER), offBuild, offShell];

  return {
    // The whole page over the scene's room, every card of it (the Code card too): Play goes to the scene first.
    page: true,
    state: bar.state,
    strip,
    hub,
    // A quick prompt (Mod+K) about the Code card's file at the caret, while that card is shown.
    quickTarget: () => (visible && strip.current === 'code' ? codeCard()?.quickTarget() ?? null : null),
    // A turn's facts (Docs/terminal.md D9): the card shown, the Code card's file, caret and selection, the Problems.
    context: () =>
      studioFacts({
        card: visible ? (STUDIO_CARDS.find((c) => c.id === strip.current)?.name ?? null) : null,
        caret: codeCard()?.caret() ?? null,
        problems: hub.problems,
      }),
    openFile: (path, line, col) => hub.openFile(path, line, col),
    // Across a reload the editor survives (a file moved under src/game/ reloads the page): the card shown, the Code card's tabs.
    carry: () => ({ card: strip.current, code: codeCard()?.carry() ?? null }),
    takeBack(kept) {
      const k = kept as { card?: unknown; code?: unknown } | null;
      const card = STUDIO_CARDS.find((c) => c.id === k?.card)?.id;
      // The Code card made (its tabs come back to it), then the card that was shown.
      if (k?.code) strip.show('code');
      if (card) strip.show(card);
      if (k?.code) void codeCard()?.takeBack(k.code);
    },
    // The Code card tree's menu is Esc's while it is open.
    holdsEscape: () => visible && (codeCard()?.holdsEscape() ?? false),
    cancel: () => codeCard()?.cancel(),
    openDiff: (path, at) => hub.openDiff(path, at),
    setVisible(show) {
      if (show === visible) return;
      visible = show;
      card.hidden = !show;
      // No side panels on this tab: the dock centres in the room from the strip to the window's edge (or Claude's column's).
      root.classList.toggle('ed-studio-up', show);
      if (show) shown?.show();
      else shown?.hide();
    },
    dispose() {
      for (const off of offControls) off();
      for (const c of cards.values()) c.dispose();
      cards.clear();
      hub.dispose();
      live.dispose();
      strip.dispose();
      card.remove();
      root.classList.remove('ed-studio-up');
    },
  };
}
