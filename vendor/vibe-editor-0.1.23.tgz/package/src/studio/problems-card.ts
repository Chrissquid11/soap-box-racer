/**
 * The Studio tab's Problems card: TypeScript's errors over the project, as the server's tsc watch finds them, and the
 * modules its Vite cannot serve now -- a syntax error, an import of no file (the program `vite`, Docs/studio.md §1
 * "Mid-session") -- (`studio:problems`, merged there; one `GET /__studio/problems` as the tab is made, `hub.ts`). Its
 * line says what they do to the game (`problemsSummary`).
 *
 * - **Grouped by file** (`groupByFile`): a file's header row with its count, its problems under it, folded and
 *   unfolded by a click on the header; files in name order, a file's problems by line.
 * - **A row** is `file:line  message` (`rowText`), the whole message, its code and its program on hover. A click
 *   opens the file at its line and column in the Code card (`hub.openFile`: the card brought up); a problem of no
 *   file's (`line: 0`, the program's own) opens the program's file at its top.
 * - **Fix with Claude** on a row's end (on hover; where a dev server hosts Claude): the quick prompt by the row, the
 *   problem its target (Docs/ai-panel.md §5, A3), "Fix this" in it -- never sent.
 * - **The count** is the top bar's pill (`StudioState.problems`, which the hub sets): red while there are any.
 *
 * Drawn whole as the problems change: they are few, and a person reads them all.
 */
import type { Problem } from '@vibe/pipeline/studio-types';
import { control, el } from '../shell.ts';
import type { StudioAsk, StudioCard, StudioHub } from './hub.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import { groupByFile, locationOf, problemsSummary, rowText, rowTitle } from './problems-list.ts';

export function createProblemsCard(hub: StudioHub, ask: StudioAsk | null = null): StudioCard {
  const root = el('section', 'ed-studio-card ed-studio-problems');
  const sum = el('div', 'ed-dim');
  const list = el('div', 'ed-studio-list');
  const said = el('div', 'ed-status');
  root.append(sum, list, said);
  /** Files folded by a click on their header: kept while their problems come and go. */
  const folded = new Set<string>();

  const say = (text: string, bad = false): void => {
    said.textContent = text;
    said.classList.toggle('ed-bad', bad);
  };

  function open(p: Problem): void {
    hub.openFile(p.file, Math.max(1, p.line), Math.max(1, p.col)).catch((err: Error) => say(`${locationOf(p)}: not opened (${err.message})`, true));
  }

  function draw(): void {
    const problems = hub.problems;
    const groups = groupByFile(problems);
    sum.textContent = problemsSummary(problems, groups.length);
    list.replaceChildren(
      ...groups.map((group) => {
        const box = el('div', 'ed-studio-group');
        const head = control('ui', 'ed-studio-group-head');
        const isFolded = folded.has(group.file);
        head.append(el('span', 'ed-studio-fold', isFolded ? '▸' : '▾'), el('span', 'ed-studio-file', group.file), el('span', 'ed-studio-count', String(group.problems.length)));
        head.title = isFolded ? 'Unfold its problems' : 'Fold its problems';
        head.addEventListener('click', () => {
          if (folded.has(group.file)) folded.delete(group.file);
          else folded.add(group.file);
          draw();
        });
        box.append(head);
        if (!isFolded) {
          for (const p of group.problems) {
            const row = control('ui', 'ed-studio-row ed-studio-problem', rowText(p));
            row.title = `${rowTitle(p)}\n\nClick: open ${locationOf(p)} in the Code card`;
            row.addEventListener('click', () => open(p));
            if (!ask) {
              box.append(row);
              continue;
            }
            // Fix with Claude (Docs/ai-panel.md §5, A3): the quick prompt by the row, the problem its target -- never sent.
            const line = el('div', 'ed-studio-asks');
            const fix = control(NOT_FOR_CLAUDE.askClaude, 'ed-studio-ask', 'Fix with Claude');
            fix.title = `Ask Claude to fix ${locationOf(p)}: a box here, the problem goes with the prompt -- you send it`;
            fix.addEventListener('click', () => ask({ kind: 'problem', file: p.file, line: p.line, col: p.col, code: p.code, message: p.message, program: p.program }, 'Fix this', fix));
            line.append(row, fix);
            box.append(line);
          }
        }
        return box;
      }),
    );
  }

  const off = hub.on('problems', () => {
    if (!root.hidden) draw();
  });
  draw();

  return {
    el: root,
    show: draw,
    hide() {},
    dispose() {
      off();
      root.remove();
    },
  };
}
