/**
 * The Code card's tab list, its rules pure (`tabs.test.ts`): a `TabList` in, a new one out -- the card draws
 * whatever comes back.
 *
 * - **Open**: a path already open is made active, nothing moved; a new one goes after the active tab (`after`) or
 *   at the end, and is active.
 * - **Close**: the next active is the tab to its right, else to its left, else none; closing another than the
 *   active leaves the active as it is. `closeOthers` keeps the one named and every pinned tab.
 * - **Pinned** tabs are never closed by `closeOthers` and sit first, in the order they were pinned among
 *   themselves; unpinning puts a tab back after the pinned ones.
 * - **Renamed** (`renameTab`): its file moved, the tab keeps its place, its marks and its being active.
 * - A tab's model is `{ path, dirty, pinned, readOnly, owner, removed }`: `owner` null for a file the TypeScript
 *   bridge is not told of (not `.ts`/`.js`), false when another tab holds it (`heldBy` says which).
 */

export interface Tab {
  path: string;
  dirty: boolean;
  pinned: boolean;
  /** Not editable: a package's file, a file another tab holds, a turn's snapshot. */
  readOnly: boolean;
  /** This tab holds the file on the TypeScript server; false when another does; null for a file the bridge is not told of. */
  owner: boolean | null;
  /** When another tab holds it: that tab, for the status line. */
  heldBy?: string;
  /** Gone from disk since it was opened: marked, until saved anew. */
  removed: boolean;
}

export interface TabList {
  readonly tabs: readonly Tab[];
  readonly active: string | null;
}

export const emptyTabs: TabList = { tabs: [], active: null };

/** A tab's model with the defaults: clean, not pinned, writable, not the bridge's, on disk. */
export const newTab = (path: string, over: Partial<Omit<Tab, 'path'>> = {}): Tab => ({ path, dirty: false, pinned: false, readOnly: false, owner: null, removed: false, ...over });

/** Pinned first, each part in its own order. */
const sorted = (tabs: readonly Tab[]): Tab[] => [...tabs.filter((t) => t.pinned), ...tabs.filter((t) => !t.pinned)];

export const find = (list: TabList, path: string): Tab | undefined => list.tabs.find((t) => t.path === path);

/** `tab` opened and active: where it is if it is open already, else after the active one (`after`) or at the end. */
export function openTab(list: TabList, tab: Tab, place: 'after' | 'end' = 'after'): TabList {
  if (find(list, tab.path)) return { ...list, active: tab.path };
  const tabs = [...list.tabs];
  const at = place === 'after' && list.active !== null ? tabs.findIndex((t) => t.path === list.active) : -1;
  // Never among the pinned unless it is pinned: after the last of them at least.
  const pinned = tabs.filter((t) => t.pinned).length;
  const index = at < 0 ? tabs.length : Math.max(at + 1, tab.pinned ? 0 : pinned);
  tabs.splice(index, 0, tab);
  return { tabs: sorted(tabs), active: tab.path };
}

export function activate(list: TabList, path: string): TabList {
  return find(list, path) ? { ...list, active: path } : list;
}

/** `path` closed: the active one after it is the tab to its right, else its left, else none -- if it was the active. */
export function closeTab(list: TabList, path: string): TabList {
  const at = list.tabs.findIndex((t) => t.path === path);
  if (at < 0) return list;
  const tabs = list.tabs.filter((t) => t.path !== path);
  if (list.active !== path) return { tabs, active: list.active };
  const next = tabs[at] ?? tabs[at - 1] ?? null;
  return { tabs, active: next?.path ?? null };
}

/** Every tab but `path` and the pinned closed; `path` active. */
export function closeOthers(list: TabList, path: string): TabList {
  if (!find(list, path)) return list;
  return { tabs: list.tabs.filter((t) => t.path === path || t.pinned), active: path };
}

/** The tabs `closeOthers(path)` would close: those that are not `path` and not pinned. */
export const othersOf = (list: TabList, path: string): Tab[] => list.tabs.filter((t) => t.path !== path && !t.pinned);

/** One tab's model changed (`dirty`, `readOnly`, `owner`, `removed`); pinning goes through `pin`. */
export function update(list: TabList, path: string, change: Partial<Omit<Tab, 'path' | 'pinned'>>): TabList {
  if (!find(list, path)) return list;
  return { ...list, tabs: list.tabs.map((t) => (t.path === path ? { ...t, ...change } : t)) };
}

/** Pinned or not: a pinned tab moves to the end of the pinned ones, an unpinned one to the start of the rest. */
export function pin(list: TabList, path: string, pinned: boolean): TabList {
  const tab = find(list, path);
  if (!tab || tab.pinned === pinned) return list;
  const rest = list.tabs.filter((t) => t.path !== path);
  const head = rest.filter((t) => t.pinned);
  const tail = rest.filter((t) => !t.pinned);
  // Pinned: the last of the pinned; unpinned: the first of the rest -- the same place between the two parts.
  return { ...list, tabs: [...head, { ...tab, pinned }, ...tail] };
}

/** `from`'s tab now `to`'s, where it was and as it was (the file moved or renamed); the active one follows it. */
export function renameTab(list: TabList, from: string, to: string): TabList {
  if (!find(list, from) || from === to) return list;
  const tabs = list.tabs.filter((t) => t.path !== to).map((t) => (t.path === from ? { ...t, path: to } : t));
  return { tabs, active: list.active === from ? to : list.active === to ? to : list.active };
}

/** The dirty tabs: what closing the card's tabs would lose. */
export const dirtyTabs = (list: TabList): Tab[] => list.tabs.filter((t) => t.dirty);

/** A file's Monaco language, by its extension: ts, js, json (and a prefab's, a scene's), css, html, markdown, lua, else plain text. */
export function languageOf(path: string): string {
  const ext = path.slice(path.lastIndexOf('.') + 1).toLowerCase();
  switch (ext) {
    case 'ts':
    case 'mts':
    case 'cts':
    case 'tsx':
      return 'typescript';
    case 'js':
    case 'mjs':
    case 'cjs':
    case 'jsx':
      return 'javascript';
    case 'json':
    case 'prefab':
    case 'scene':
      return 'json';
    case 'css':
      return 'css';
    case 'html':
      return 'html';
    case 'md':
      return 'markdown';
    case 'lua':
      return 'lua';
    default:
      return 'plaintext';
  }
}

/** Does the TypeScript bridge answer for this file: a `typescript` or `javascript` one. */
export const isScript = (path: string): boolean => {
  const language = languageOf(path);
  return language === 'typescript' || language === 'javascript';
};
