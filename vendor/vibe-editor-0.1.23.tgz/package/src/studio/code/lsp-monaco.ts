/**
 * The Code card's converters between the Language Server Protocol (`lsp.ts`, what the TypeScript bridge carries)
 * and Monaco's shapes, each way the providers (`providers.ts`) need -- pure, so node tests every one
 * (`lsp-monaco.test.ts`) with no Monaco loaded: Monaco's enums are `monaco-enums.ts`' mirrored numbers, and a
 * converter that must make a Monaco `Uri` takes the maker (`toUri`, `monaco.Uri.parse` in the card).
 *
 * - **Positions**: LSP's 0-based line and UTF-16 character, Monaco's 1-based line and column (Monaco's columns
 *   count UTF-16 units too): `+1` one way, `-1` the other.
 * - **Markup**: `MarkupContent` (markdown as is, plain text escaped) and the old `MarkedString` (code in a
 *   language: a fenced block) to `IMarkdownString`.
 * - **Diagnostics** to markers: severity (1 error → `Error` … 4 hint → `Hint`), the code as a string, the source,
 *   the tags (unnecessary, deprecated) and the related information.
 * - **Edits**: `TextEdit[]` to Monaco's, a `WorkspaceEdit` to the per-uri edits it holds (`changes` and
 *   `documentChanges`' text edits; a file made, renamed or deleted is counted, not applied), and `applyTextEdits`
 *   for a file no tab has open -- what rename writes through the file routes.
 */
import type * as M from 'monaco-editor/editor/editor.api.js';
import type {
  LspCodeAction,
  LspCommand,
  LspCompletionItem,
  LspCompletionList,
  LspContentChange,
  LspDiagnostic,
  LspHover,
  LspLocation,
  LspLocationLink,
  LspMarkedString,
  LspMarkupContent,
  LspPosition,
  LspRange,
  LspSignatureHelp,
  LspTextEdit,
  LspWorkspaceEdit,
} from './lsp.ts';
import { CompletionItemInsertTextRule, CompletionItemKind, CompletionItemTag, MarkerSeverity, MarkerTag } from './monaco-enums.ts';

/** A Monaco `Uri` made from a uri's text: `monaco.Uri.parse` in the page, a stand-in in a test. */
export type ToUri = (uri: string) => M.Uri;

// ---------------------------------------------------------------- positions and ranges

export const toMonacoPosition = (p: LspPosition): M.IPosition => ({ lineNumber: p.line + 1, column: p.character + 1 });

export const toLspPosition = (p: M.IPosition): LspPosition => ({ line: p.lineNumber - 1, character: p.column - 1 });

export const toMonacoRange = (r: LspRange): M.IRange => ({
  startLineNumber: r.start.line + 1,
  startColumn: r.start.character + 1,
  endLineNumber: r.end.line + 1,
  endColumn: r.end.character + 1,
});

export const toLspRange = (r: M.IRange): LspRange => ({
  start: { line: r.startLineNumber - 1, character: r.startColumn - 1 },
  end: { line: r.endLineNumber - 1, character: r.endColumn - 1 },
});

/** Does `a` touch `b` (ends included): a diagnostic sent with a code action's request when it does. */
export function rangesTouch(a: LspRange, b: LspRange): boolean {
  const before = (x: LspPosition, y: LspPosition): boolean => x.line < y.line || (x.line === y.line && x.character < y.character);
  return !before(a.end, b.start) && !before(b.end, a.start);
}

// ---------------------------------------------------------------- markup

/** Markdown's specials escaped: plain text shown as it is. */
export const escapeMarkdown = (text: string): string => text.replace(/[\\`*_{}[\]()#+\-.!|<>]/g, '\\$&');

/** One piece of LSP markup as Monaco's markdown; empty text gives none. */
export function toMarkdown(content: LspMarkupContent | LspMarkedString | undefined): M.IMarkdownString | null {
  if (content === undefined) return null;
  let value: string;
  if (typeof content === 'string') value = escapeMarkdown(content);
  else if ('kind' in content) value = content.kind === 'markdown' ? content.value : escapeMarkdown(content.value);
  else value = `\`\`\`${content.language}\n${content.value}\n\`\`\``;
  return value.trim() === '' ? null : { value };
}

/** A documentation field (`string | MarkupContent`) as Monaco's: a string stays a string. */
export function toDocumentation(doc: string | LspMarkupContent | undefined): string | M.IMarkdownString | undefined {
  if (doc === undefined || typeof doc === 'string') return doc;
  return doc.kind === 'plaintext' ? doc.value : { value: doc.value };
}

export function toHover(hover: LspHover | null): M.languages.Hover | null {
  if (!hover) return null;
  const parts = Array.isArray(hover.contents) ? hover.contents : [hover.contents];
  const contents = parts.map((part) => toMarkdown(part)).filter((m): m is M.IMarkdownString => m !== null);
  if (contents.length === 0) return null;
  return hover.range ? { contents, range: toMonacoRange(hover.range) } : { contents };
}

// ---------------------------------------------------------------- completion

/** LSP's `CompletionItemKind` (1 Text … 25 TypeParameter) to Monaco's; one it does not know is Text. */
export function toCompletionKind(kind: number | undefined): M.languages.CompletionItemKind {
  const K = CompletionItemKind;
  const map: Record<number, M.languages.CompletionItemKind> = {
    1: K.Text, 2: K.Method, 3: K.Function, 4: K.Constructor, 5: K.Field, 6: K.Variable, 7: K.Class, 8: K.Interface,
    9: K.Module, 10: K.Property, 11: K.Unit, 12: K.Value, 13: K.Enum, 14: K.Keyword, 15: K.Snippet, 16: K.Color,
    17: K.File, 18: K.Reference, 19: K.Folder, 20: K.EnumMember, 21: K.Constant, 22: K.Struct, 23: K.Event,
    24: K.Operator, 25: K.TypeParameter,
  };
  return (kind !== undefined ? map[kind] : undefined) ?? K.Text;
}

/** A Monaco completion item that remembers the server's, for `completionItem/resolve`. */
export interface LspSuggestion extends M.languages.CompletionItem {
  lsp: LspCompletionItem;
}

/**
 * A server's completion item as Monaco's: its text edit's range (insert and replace both, when it has the two),
 * else the list's default edit range, else `wordRange` -- the word before the caret, which the provider works out;
 * a snippet's `$1`s kept as such; deprecated struck through.
 */
export function toCompletionItem(item: LspCompletionItem, wordRange: M.IRange, defaults?: LspCompletionList['itemDefaults']): LspSuggestion {
  const edit = item.textEdit;
  const fallback = defaults?.editRange;
  let range: M.IRange | M.languages.CompletionItemRanges = wordRange;
  let insertText = item.insertText ?? item.label;
  if (edit && 'range' in edit) range = toMonacoRange(edit.range);
  else if (edit) range = { insert: toMonacoRange(edit.insert), replace: toMonacoRange(edit.replace) };
  else if (fallback && 'start' in fallback) range = toMonacoRange(fallback);
  else if (fallback) range = { insert: toMonacoRange(fallback.insert), replace: toMonacoRange(fallback.replace) };
  if (edit) insertText = edit.newText;
  else if (fallback && item.textEditText !== undefined) insertText = item.textEditText;
  const format = item.insertTextFormat ?? defaults?.insertTextFormat;
  const out: LspSuggestion = {
    label: item.labelDetails ? { label: item.label, detail: item.labelDetails.detail, description: item.labelDetails.description } : item.label,
    kind: toCompletionKind(item.kind),
    insertText,
    range,
    lsp: item,
  };
  if (format === 2) out.insertTextRules = CompletionItemInsertTextRule.InsertAsSnippet;
  if (item.detail !== undefined) out.detail = item.detail;
  const doc = toDocumentation(item.documentation);
  if (doc !== undefined) out.documentation = doc;
  if (item.sortText !== undefined) out.sortText = item.sortText;
  if (item.filterText !== undefined) out.filterText = item.filterText;
  if (item.preselect) out.preselect = true;
  if (item.deprecated || item.tags?.includes(1)) out.tags = [CompletionItemTag.Deprecated];
  const commit = item.commitCharacters ?? defaults?.commitCharacters;
  if (commit) out.commitCharacters = commit;
  if (item.additionalTextEdits) out.additionalTextEdits = item.additionalTextEdits.map(toTextEdit);
  return out;
}

/** A completion answer -- a list, the bare items, or none -- as Monaco's list. */
export function toCompletionList(answer: LspCompletionList | LspCompletionItem[] | null, wordRange: M.IRange): M.languages.CompletionList {
  if (!answer) return { suggestions: [] };
  const list: LspCompletionList = Array.isArray(answer) ? { isIncomplete: false, items: answer } : answer;
  // An item's `data` left out falls back to the list's default (LSP 3.17): resolve needs it.
  const items = list.itemDefaults?.data !== undefined ? list.items.map((item) => (item.data === undefined ? { ...item, data: list.itemDefaults!.data } : item)) : list.items;
  return { suggestions: items.map((item) => toCompletionItem(item, wordRange, list.itemDefaults)), incomplete: list.isIncomplete };
}

/** A resolved item's new parts laid onto the suggestion Monaco holds: its detail, documentation, extra edits. */
export function resolvedInto(suggestion: LspSuggestion, resolved: LspCompletionItem): LspSuggestion {
  const out: LspSuggestion = { ...suggestion, lsp: resolved };
  if (resolved.detail !== undefined) out.detail = resolved.detail;
  const doc = toDocumentation(resolved.documentation);
  if (doc !== undefined) out.documentation = doc;
  if (resolved.additionalTextEdits) out.additionalTextEdits = resolved.additionalTextEdits.map(toTextEdit);
  return out;
}

// ---------------------------------------------------------------- diagnostics

/** LSP's severity (1 error … 4 hint; none is an error, as LSP says the client decides) as Monaco's. */
export function toSeverity(severity: number | undefined): M.MarkerSeverity {
  switch (severity) {
    case 2:
      return MarkerSeverity.Warning;
    case 3:
      return MarkerSeverity.Info;
    case 4:
      return MarkerSeverity.Hint;
    default:
      return MarkerSeverity.Error;
  }
}

/** A diagnostic as a marker: its range, severity, message, code (`2322`), source, tags and related places. */
export function toMarker(d: LspDiagnostic, toUri: ToUri): M.editor.IMarkerData {
  const marker: M.editor.IMarkerData = { severity: toSeverity(d.severity), message: d.message, ...toMonacoRange(d.range) };
  if (d.code !== undefined) marker.code = String(d.code);
  if (d.source !== undefined) marker.source = d.source;
  const tags = (d.tags ?? []).flatMap((tag) => (tag === 1 ? [MarkerTag.Unnecessary] : tag === 2 ? [MarkerTag.Deprecated] : []));
  if (tags.length > 0) marker.tags = tags;
  if (d.relatedInformation && d.relatedInformation.length > 0) {
    marker.relatedInformation = d.relatedInformation.map((r) => ({ resource: toUri(r.location.uri), message: r.message, ...toMonacoRange(r.location.range) }));
  }
  return marker;
}

// ---------------------------------------------------------------- places

/** A definition's or a reference's place -- a `Location` or a `LocationLink` -- as Monaco's. */
export function toLocation(loc: LspLocation | LspLocationLink, toUri: ToUri): M.languages.Location | M.languages.LocationLink {
  if ('targetUri' in loc) {
    const link: M.languages.LocationLink = { uri: toUri(loc.targetUri), range: toMonacoRange(loc.targetRange), targetSelectionRange: toMonacoRange(loc.targetSelectionRange) };
    if (loc.originSelectionRange) link.originSelectionRange = toMonacoRange(loc.originSelectionRange);
    return link;
  }
  return { uri: toUri(loc.uri), range: toMonacoRange(loc.range) };
}

/** The uri a place is in. */
export const uriOfLocation = (loc: LspLocation | LspLocationLink): string => ('targetUri' in loc ? loc.targetUri : loc.uri);

/** A definition's answer -- one place, a list, or none -- as a list. */
export function locations(answer: LspLocation | LspLocation[] | LspLocationLink[] | null): (LspLocation | LspLocationLink)[] {
  if (!answer) return [];
  return Array.isArray(answer) ? answer : [answer];
}

// ---------------------------------------------------------------- signature help

export function toSignatureHelp(help: LspSignatureHelp | null): M.languages.SignatureHelp | null {
  if (!help || help.signatures.length === 0) return null;
  const signatures = help.signatures.map((s): M.languages.SignatureInformation => {
    const info: M.languages.SignatureInformation = {
      label: s.label,
      parameters: (s.parameters ?? []).map((p) => {
        const doc = toDocumentation(p.documentation);
        return doc === undefined ? { label: p.label } : { label: p.label, documentation: doc };
      }),
    };
    const doc = toDocumentation(s.documentation);
    if (doc !== undefined) info.documentation = doc;
    if (s.activeParameter !== undefined) info.activeParameter = s.activeParameter;
    return info;
  });
  return { signatures, activeSignature: help.activeSignature ?? 0, activeParameter: help.activeParameter ?? 0 };
}

// ---------------------------------------------------------------- edits

export const toTextEdit = (e: LspTextEdit): M.languages.TextEdit => ({ range: toMonacoRange(e.range), text: e.newText });

/** What a workspace edit does, by uri: its text edits (from `changes` and `documentChanges`), and how many files it would make, rename or delete -- which the card does not do. */
export interface EditsByUri {
  edits: Map<string, LspTextEdit[]>;
  fileOps: number;
}

export function editsByUri(edit: LspWorkspaceEdit | null): EditsByUri {
  const edits = new Map<string, LspTextEdit[]>();
  let fileOps = 0;
  const add = (uri: string, list: readonly LspTextEdit[]): void => {
    const had = edits.get(uri);
    if (had) had.push(...list);
    else edits.set(uri, [...list]);
  };
  if (edit?.documentChanges) {
    for (const change of edit.documentChanges) {
      if ('textDocument' in change) add(change.textDocument.uri, change.edits);
      else fileOps++;
    }
  } else if (edit?.changes) {
    for (const [uri, list] of Object.entries(edit.changes)) add(uri, list);
  }
  return { edits, fileOps };
}

/** Text edits by uri as Monaco's workspace edit (`versionId` left out: the edit is for the text as it is). */
export function toWorkspaceEdit(byUri: ReadonlyMap<string, readonly LspTextEdit[]>, toUri: ToUri): M.languages.WorkspaceEdit {
  const edits: M.languages.IWorkspaceTextEdit[] = [];
  for (const [uri, list] of byUri) {
    const resource = toUri(uri);
    for (const e of list) edits.push({ resource, textEdit: toTextEdit(e), versionId: undefined });
  }
  return { edits };
}

/** Where each line of `text` starts, LSP's way: a line ends at `\n`, `\r\n` or `\r`. */
function lineStarts(text: string): number[] {
  const starts = [0];
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    if (c === 13 /* \r */) {
      if (text.charCodeAt(i + 1) === 10) i++;
      starts.push(i + 1);
    } else if (c === 10 /* \n */) starts.push(i + 1);
  }
  return starts;
}

/** A position's offset into `text` (UTF-16, as LSP's characters are), held to its line's end and the text's. */
function offsetOf(text: string, starts: readonly number[], p: LspPosition): number {
  if (p.line >= starts.length) return text.length;
  const start = starts[p.line]!;
  const next = p.line + 1 < starts.length ? starts[p.line + 1]! : text.length;
  // The line's own end, before its line break.
  let end = next;
  if (end > start && text.charCodeAt(end - 1) === 10) end--;
  if (end > start && text.charCodeAt(end - 1) === 13) end--;
  return Math.min(start + Math.max(0, p.character), end);
}

/** `edits` applied to `text` (each against the text as it was, as LSP has it): what rename writes into a file no tab has open. */
export function applyTextEdits(text: string, edits: readonly LspTextEdit[]): string {
  const starts = lineStarts(text);
  const spans = edits.map((e, n) => ({ from: offsetOf(text, starts, e.range.start), to: offsetOf(text, starts, e.range.end), text: e.newText, n }));
  // Last first, so an edit leaves the offsets before it as they were; two at one place in the order given.
  spans.sort((a, b) => b.from - a.from || b.n - a.n);
  let out = text;
  for (const s of spans) out = out.slice(0, s.from) + s.text + out.slice(s.to);
  return out;
}

// ---------------------------------------------------------------- code actions

/** A Monaco code action that remembers the server's, for `codeAction/resolve` (an action answered without its edit). */
export interface LspAction extends M.languages.CodeAction {
  lsp?: LspCodeAction;
}

/**
 * A code action -- or a bare command -- as Monaco's: its edit only when every file it touches is open (`openUris`),
 * else a command that applies it (`applyCommand`, its arguments the edit and the server's command when there is one,
 * run after the edit); one with neither edit nor command keeps the server's, to be resolved when chosen.
 */
export function toCodeAction(action: LspCodeAction | LspCommand, toUri: ToUri, openUris: ReadonlySet<string>, applyCommand: string, executeCommand: string): LspAction {
  if (typeof (action as LspCommand).command === 'string') {
    const cmd = action as LspCommand;
    return { title: cmd.title, command: { id: executeCommand, title: cmd.title, arguments: [cmd] } };
  }
  const a = action as LspCodeAction;
  const out: LspAction = { title: a.title };
  if (!a.edit && !a.command) out.lsp = a;
  if (a.kind !== undefined) out.kind = a.kind;
  if (a.isPreferred) out.isPreferred = true;
  if (a.disabled) out.disabled = a.disabled.reason;
  if (a.diagnostics) out.diagnostics = a.diagnostics.map((d) => toMarker(d, toUri));
  if (a.edit) {
    const { edits, fileOps } = editsByUri(a.edit);
    const allOpen = fileOps === 0 && [...edits.keys()].every((uri) => openUris.has(uri));
    if (allOpen) out.edit = toWorkspaceEdit(edits, toUri);
    else out.command = { id: applyCommand, title: a.title, arguments: a.command ? [a.edit, a.command] : [a.edit] };
  }
  // An edit Monaco applies and a command: the command after it, Monaco's way; a command alone, the same. (An edit
  // the apply command writes carries the command itself, above.)
  if (a.command && !out.command) out.command = { id: executeCommand, title: a.command.title, arguments: [a.command] };
  return out;
}

// ---------------------------------------------------------------- document sync

/** Monaco's content changes as `didChange`'s incremental `contentChanges`, in the order Monaco gives them (each applies to the text the one before left). */
export function toContentChanges(changes: readonly Pick<M.editor.IModelContentChange, 'range' | 'rangeLength' | 'text'>[]): LspContentChange[] {
  return changes.map((c) => ({ range: toLspRange(c.range), rangeLength: c.rangeLength, text: c.text }));
}
