/**
 * Monaco's language features for `typescript` and `javascript`, each a provider that asks the dev server's
 * TypeScript language server through the bridge (`bridge.ts`) and converts its answer (`lsp-monaco.ts`). Monaco's
 * own TypeScript (`language/typescript`, its worker and its copy of the compiler) is never loaded: the bridge's
 * server is the one TypeScript, the project's own.
 *
 * | Monaco provider        | LSP request                                                    |
 * | ---------------------- | -------------------------------------------------------------- |
 * | completion             | `textDocument/completion`, `completionItem/resolve`            |
 * | hover                  | `textDocument/hover`                                           |
 * | definition             | `textDocument/definition` (the target opened by the card's editor opener) |
 * | references             | `textDocument/references` (Monaco's peek)                      |
 * | rename                 | `textDocument/prepareRename`, then `textDocument/rename`       |
 * | signature help         | `textDocument/signatureHelp`                                   |
 * | code actions           | `textDocument/codeAction` (quick fixes, `source.organizeImports`), `codeAction/resolve` for one answered without its edit, `workspace/executeCommand` for a command |
 * | document formatting    | `textDocument/formatting`                                      |
 *
 * - **A place in a file no tab has** (a definition's, a reference's): Monaco's peek needs a model for it, so
 *   `ensureModels` makes one (read-only, no tab) from `GET file`; a uri outside the project (TypeScript's own
 *   `lib.*.d.ts`) is left out, and the status line says where it is.
 * - **Rename** applies its edit to the open tabs through Monaco (one undo step each), and writes the files no tab
 *   has through `GET file`, the edits, `PUT file` with the mtime read (`writeEdits`). A code action's edit that
 *   reaches a file no tab has goes the same way, as a command (`APPLY_EDIT`) -- and its server command, when it
 *   has one, is run once the edit is done.
 * - **Diagnostics** are not a provider: `publishDiagnostics` and `textDocument/diagnostic` become markers in the
 *   card (`code-card.ts`).
 */
import type * as M from 'monaco-editor/editor/editor.api.js';
import type { Bridge } from './bridge.ts';
import type {
  LspCodeAction,
  LspCommand,
  LspCompletionItem,
  LspCompletionList,
  LspDiagnostic,
  LspHover,
  LspLocation,
  LspLocationLink,
  LspPrepareRename,
  LspSignatureHelp,
  LspTextEdit,
  LspWorkspaceEdit,
} from './lsp.ts';
import {
  editsByUri,
  locations,
  rangesTouch,
  resolvedInto,
  toCodeAction,
  toCompletionList,
  toHover,
  toLocation,
  toLspPosition,
  toLspRange,
  toMonacoRange,
  toSignatureHelp,
  toTextEdit,
  toWorkspaceEdit,
  uriOfLocation,
  type LspAction,
  type LspSuggestion,
} from './lsp-monaco.ts';

/** The languages the bridge answers for. */
export const TS_LANGUAGES = ['typescript', 'javascript'] as const;

/** A code action's edit that reaches a file no tab has: applied by the card. */
export const APPLY_EDIT = 'vibe.code.applyEdit';
/** A code action that is a server command: `workspace/executeCommand`. */
export const EXECUTE = 'vibe.code.execute';

export interface ProviderHost {
  readonly bridge: Bridge;
  /** The project path of a model the card made (a tab's or a peek's), or null. */
  pathOf(model: M.editor.ITextModel): string | null;
  /** Is a tab open on this uri (the bridge's text, `bridge.uri(path)`)? */
  isOpen(uri: string): boolean;
  /** Models made, read-only and with no tab, for the places a peek shows: those in the project. Answers the uris it could not (outside). */
  ensureModels(uris: readonly string[]): Promise<string[]>;
  /** Edits to files no tab has: each read, edited, saved with its mtime. Answers what was done, for the status line. */
  writeEdits(byUri: ReadonlyMap<string, readonly LspTextEdit[]>): Promise<string>;
  /** The server's diagnostics on a uri, as last heard: what a code action's request names. */
  diagnosticsOf(uri: string): readonly LspDiagnostic[];
  /** A word on the status line. */
  say(text: string, bad?: boolean): void;
}

export function registerProviders(monaco: typeof M, host: ProviderHost): M.IDisposable[] {
  const { bridge } = host;
  const toUri = (uri: string): M.Uri => monaco.Uri.parse(uri);
  /** The document a request names, or null for a model the card does not know. */
  const doc = (model: M.editor.ITextModel): { uri: string } | null => {
    const path = host.pathOf(model);
    return path === null || bridge.root === null ? null : { uri: bridge.uri(path) };
  };
  /** A request's failure said, never thrown at Monaco (which would log it): no answer. */
  const quiet = async <T>(what: string, run: () => Promise<T>): Promise<T | null> => {
    try {
      return await run();
    } catch (err) {
      host.say(`${what}: ${(err as Error).message}`, true);
      return null;
    }
  };
  /** The places a peek shows, with models for those in the project; those outside said. */
  const placed = async (list: (LspLocation | LspLocationLink)[]): Promise<(LspLocation | LspLocationLink)[]> => {
    const outside = new Set(await host.ensureModels([...new Set(list.map(uriOfLocation))]));
    if (outside.size > 0) {
      const first = [...outside][0]!;
      const where = bridge.place(first);
      host.say(`${'outside' in where ? where.outside : first} is outside the project: not opened here`);
    }
    return list.filter((loc) => !outside.has(uriOfLocation(loc)));
  };

  /** The uris an action's edit touches that a tab has open. */
  const openOf = (a: LspCodeAction | LspCommand): Set<string> => new Set('edit' in a && a.edit ? [...editsByUri(a.edit).edits.keys()].filter((uri) => host.isOpen(uri)) : []);

  /** A server command: `workspace/executeCommand`. */
  const run = (command: LspCommand): Promise<unknown> => quiet(command.title, () => bridge.request('workspace/executeCommand', { command: command.command, arguments: command.arguments }));

  const out: M.IDisposable[] = [];
  for (const language of TS_LANGUAGES) {
    out.push(
      monaco.languages.registerCompletionItemProvider(language, {
        triggerCharacters: ['.', '"', "'", '`', '/', '@', '<', '#', ' '],
        async provideCompletionItems(model, position, context) {
          const d = doc(model);
          if (!d) return { suggestions: [] };
          const word = model.getWordUntilPosition(position);
          const wordRange = { startLineNumber: position.lineNumber, startColumn: word.startColumn, endLineNumber: position.lineNumber, endColumn: position.column };
          const answer = await quiet('completions', () =>
            bridge.request<LspCompletionList | LspCompletionItem[] | null>('textDocument/completion', {
              textDocument: d,
              position: toLspPosition(position),
              // Monaco's trigger kinds count from 0, LSP's from 1.
              context: { triggerKind: context.triggerKind + 1, triggerCharacter: context.triggerCharacter },
            }),
          );
          return toCompletionList(answer, wordRange);
        },
        async resolveCompletionItem(item) {
          const suggestion = item as LspSuggestion;
          if (!suggestion.lsp) return item;
          const resolved = await quiet('completion details', () => bridge.request<LspCompletionItem>('completionItem/resolve', suggestion.lsp));
          return resolved ? resolvedInto(suggestion, resolved) : item;
        },
      }),
      monaco.languages.registerHoverProvider(language, {
        async provideHover(model, position) {
          const d = doc(model);
          if (!d) return null;
          return toHover(await quiet('hover', () => bridge.request<LspHover | null>('textDocument/hover', { textDocument: d, position: toLspPosition(position) })));
        },
      }),
      monaco.languages.registerDefinitionProvider(language, {
        async provideDefinition(model, position) {
          const d = doc(model);
          if (!d) return null;
          const answer = await quiet('definition', () => bridge.request<LspLocation | LspLocation[] | LspLocationLink[] | null>('textDocument/definition', { textDocument: d, position: toLspPosition(position) }));
          return (await placed(locations(answer))).map((loc) => toLocation(loc, toUri));
        },
      }),
      monaco.languages.registerReferenceProvider(language, {
        async provideReferences(model, position, context) {
          const d = doc(model);
          if (!d) return null;
          const answer = await quiet('references', () =>
            bridge.request<LspLocation[] | null>('textDocument/references', { textDocument: d, position: toLspPosition(position), context: { includeDeclaration: context.includeDeclaration } }),
          );
          return (await placed(answer ?? [])).map((loc) => toLocation(loc, toUri) as M.languages.Location);
        },
      }),
      monaco.languages.registerRenameProvider(language, {
        async resolveRenameLocation(model, position) {
          const d = doc(model);
          if (!d) return { range: new monaco.Range(position.lineNumber, position.column, position.lineNumber, position.column), text: '', rejectReason: 'not a file of the project' };
          let answer: LspPrepareRename;
          try {
            answer = await bridge.request<LspPrepareRename>('textDocument/prepareRename', { textDocument: d, position: toLspPosition(position) });
          } catch (err) {
            return { range: new monaco.Range(position.lineNumber, position.column, position.lineNumber, position.column), text: '', rejectReason: (err as Error).message };
          }
          const word = model.getWordAtPosition(position);
          const wordRange = word ? new monaco.Range(position.lineNumber, word.startColumn, position.lineNumber, word.endColumn) : null;
          if (answer === null) return { range: wordRange ?? new monaco.Range(position.lineNumber, position.column, position.lineNumber, position.column), text: '', rejectReason: 'This can not be renamed.' };
          if ('defaultBehavior' in answer) return wordRange ? { range: wordRange, text: model.getValueInRange(wordRange) } : { range: new monaco.Range(position.lineNumber, position.column, position.lineNumber, position.column), text: '', rejectReason: 'This can not be renamed.' };
          const range = toMonacoRange('range' in answer ? answer.range : answer);
          return { range, text: 'placeholder' in answer ? answer.placeholder : model.getValueInRange(range) };
        },
        async provideRenameEdits(model, position, newName) {
          const d = doc(model);
          if (!d) return { edits: [], rejectReason: 'not a file of the project' };
          let edit: LspWorkspaceEdit | null;
          try {
            edit = await bridge.request<LspWorkspaceEdit | null>('textDocument/rename', { textDocument: d, position: toLspPosition(position), newName });
          } catch (err) {
            return { edits: [], rejectReason: (err as Error).message };
          }
          const { edits, fileOps } = editsByUri(edit);
          const open = new Map<string, LspTextEdit[]>();
          const closed = new Map<string, LspTextEdit[]>();
          for (const [uri, list] of edits) (host.isOpen(uri) ? open : closed).set(uri, list);
          if (closed.size > 0) host.say(await host.writeEdits(closed));
          if (fileOps > 0) host.say(`the rename would also make, move or delete ${fileOps} file${fileOps === 1 ? '' : 's'}: not done here`, true);
          return toWorkspaceEdit(open, toUri);
        },
      }),
      monaco.languages.registerSignatureHelpProvider(language, {
        signatureHelpTriggerCharacters: ['(', ',', '<'],
        signatureHelpRetriggerCharacters: [')'],
        async provideSignatureHelp(model, position, _token, context) {
          const d = doc(model);
          if (!d) return null;
          const help = toSignatureHelp(
            await quiet('signature help', () =>
              bridge.request<LspSignatureHelp | null>('textDocument/signatureHelp', {
                textDocument: d,
                position: toLspPosition(position),
                context: { triggerKind: context.triggerKind, triggerCharacter: context.triggerCharacter, isRetrigger: context.isRetrigger },
              }),
            ),
          );
          return help ? { value: help, dispose() {} } : null;
        },
      }),
      monaco.languages.registerCodeActionProvider(
        language,
        {
          async provideCodeActions(model, range, context) {
            const d = doc(model);
            if (!d) return { actions: [], dispose() {} };
            const lspRange = toLspRange(range);
            const diagnostics = host.diagnosticsOf(d.uri).filter((x) => rangesTouch(x.range, lspRange));
            const answer = await quiet('code actions', () =>
              bridge.request<(LspCodeAction | LspCommand)[] | null>('textDocument/codeAction', {
                textDocument: d,
                range: lspRange,
                context: { diagnostics, only: context.only ? [context.only] : undefined, triggerKind: context.trigger },
              }),
            );
            return { actions: (answer ?? []).map((a) => toCodeAction(a, toUri, openOf(a), APPLY_EDIT, EXECUTE)), dispose() {} };
          },
          // An action the server answered without its edit (it resolves them: `resolveSupport`): asked for it now.
          async resolveCodeAction(action) {
            const lsp = (action as LspAction).lsp;
            if (!lsp) return action;
            const resolved = await quiet('the code action', () => bridge.request<LspCodeAction>('codeAction/resolve', lsp));
            return resolved ? toCodeAction(resolved, toUri, openOf(resolved), APPLY_EDIT, EXECUTE) : action;
          },
        },
        { providedCodeActionKinds: ['quickfix', 'refactor', 'source', 'source.organizeImports'] },
      ),
      monaco.languages.registerDocumentFormattingEditProvider(language, {
        async provideDocumentFormattingEdits(model, options) {
          const d = doc(model);
          if (!d) return [];
          const edits = await quiet('formatting', () => bridge.request<LspTextEdit[] | null>('textDocument/formatting', { textDocument: d, options: { tabSize: options.tabSize, insertSpaces: options.insertSpaces } }));
          return (edits ?? []).map(toTextEdit);
        },
      }),
    );
  }

  out.push(
    // A code action's edit reaching a file no tab has: the open ones through their models, the rest written; then its command.
    monaco.editor.registerCommand(APPLY_EDIT, (_accessor, edit: LspWorkspaceEdit, then?: LspCommand) => {
      const { edits } = editsByUri(edit);
      const closed = new Map<string, LspTextEdit[]>();
      for (const [uri, list] of edits) {
        const model = host.isOpen(uri) ? monaco.editor.getModel(toUri(uri)) : null;
        if (!model) {
          closed.set(uri, list);
          continue;
        }
        model.pushEditOperations([], list.map((e) => ({ range: toMonacoRange(e.range), text: e.newText })), () => null);
      }
      const execute = (): void => {
        if (then) void run(then);
      };
      if (closed.size > 0) {
        void host.writeEdits(closed).then((said) => {
          host.say(said);
          execute();
        });
      } else execute();
    }),
    monaco.editor.registerCommand(EXECUTE, (_accessor, command: LspCommand) => void run(command)),
  );
  return out;
}
