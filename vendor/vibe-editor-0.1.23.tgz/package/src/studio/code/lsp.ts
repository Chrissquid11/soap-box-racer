/**
 * The few Language Server Protocol shapes the Code card speaks (LSP 3.17), as the TypeScript bridge carries them
 * (`@vibe/pipeline/studio-types`' `TS_REQ`/`TS_RES`/`TS_EVENT`): positions are 0-based lines and UTF-16
 * characters, uris `file://` ones. Types alone -- written here rather than taken from a `vscode-*` package: the
 * card needs a page of them, and `lsp-monaco.ts` converts each to Monaco's and back.
 */

export interface LspPosition {
  line: number;
  character: number;
}

export interface LspRange {
  start: LspPosition;
  end: LspPosition;
}

export interface LspLocation {
  uri: string;
  range: LspRange;
}

export interface LspLocationLink {
  originSelectionRange?: LspRange;
  targetUri: string;
  targetRange: LspRange;
  targetSelectionRange: LspRange;
}

export interface LspTextEdit {
  range: LspRange;
  newText: string;
}

export interface LspInsertReplaceEdit {
  newText: string;
  insert: LspRange;
  replace: LspRange;
}

export interface LspMarkupContent {
  kind: 'plaintext' | 'markdown';
  value: string;
}

/** The deprecated form a hover may still answer: plain text, or code in a language. */
export type LspMarkedString = string | { language: string; value: string };

/** `DiagnosticSeverity`: 1 error, 2 warning, 3 information, 4 hint. */
export type LspSeverity = 1 | 2 | 3 | 4;

export interface LspDiagnostic {
  range: LspRange;
  severity?: LspSeverity;
  code?: number | string;
  source?: string;
  message: string;
  /** `DiagnosticTag`: 1 unnecessary, 2 deprecated. */
  tags?: number[];
  relatedInformation?: { location: LspLocation; message: string }[];
  data?: unknown;
}

export interface LspCommand {
  title: string;
  command: string;
  arguments?: unknown[];
}

export interface LspCompletionItem {
  label: string;
  labelDetails?: { detail?: string; description?: string };
  /** `CompletionItemKind`, from 1 (Text) to 25 (TypeParameter). */
  kind?: number;
  /** `CompletionItemTag`: 1 deprecated. */
  tags?: number[];
  detail?: string;
  documentation?: string | LspMarkupContent;
  deprecated?: boolean;
  preselect?: boolean;
  sortText?: string;
  filterText?: string;
  insertText?: string;
  /** 1 plain text, 2 a snippet. */
  insertTextFormat?: 1 | 2;
  textEdit?: LspTextEdit | LspInsertReplaceEdit;
  textEditText?: string;
  additionalTextEdits?: LspTextEdit[];
  commitCharacters?: string[];
  command?: LspCommand;
  data?: unknown;
}

export interface LspCompletionList {
  isIncomplete: boolean;
  itemDefaults?: {
    commitCharacters?: string[];
    editRange?: LspRange | { insert: LspRange; replace: LspRange };
    insertTextFormat?: 1 | 2;
    data?: unknown;
  };
  items: LspCompletionItem[];
}

export interface LspHover {
  contents: LspMarkupContent | LspMarkedString | LspMarkedString[];
  range?: LspRange;
}

export interface LspParameterInformation {
  label: string | [number, number];
  documentation?: string | LspMarkupContent;
}

export interface LspSignatureInformation {
  label: string;
  documentation?: string | LspMarkupContent;
  parameters?: LspParameterInformation[];
  activeParameter?: number;
}

export interface LspSignatureHelp {
  signatures: LspSignatureInformation[];
  activeSignature?: number;
  activeParameter?: number;
}

export interface LspTextDocumentEdit {
  textDocument: { uri: string; version: number | null };
  edits: LspTextEdit[];
}

/** A file made, renamed or deleted by an edit: the card does not apply these (said on the status line). */
export interface LspFileOperation {
  kind: 'create' | 'rename' | 'delete';
  uri?: string;
  oldUri?: string;
  newUri?: string;
}

export interface LspWorkspaceEdit {
  changes?: Record<string, LspTextEdit[]>;
  documentChanges?: (LspTextDocumentEdit | LspFileOperation)[];
}

export interface LspCodeAction {
  title: string;
  kind?: string;
  diagnostics?: LspDiagnostic[];
  isPreferred?: boolean;
  disabled?: { reason: string };
  edit?: LspWorkspaceEdit;
  command?: LspCommand;
  data?: unknown;
}

/** `textDocument/prepareRename`'s answer: the range, the range and its placeholder, the default, or none. */
export type LspPrepareRename = LspRange | { range: LspRange; placeholder: string } | { defaultBehavior: boolean } | null;

export interface LspPublishDiagnostics {
  uri: string;
  version?: number;
  diagnostics: LspDiagnostic[];
}

/** `textDocument/diagnostic`'s answer (the pull model). */
export type LspDocumentDiagnosticReport = { kind: 'full'; resultId?: string; items: LspDiagnostic[] } | { kind: 'unchanged'; resultId: string };

/** One `contentChanges` entry of `textDocument/didChange`: a range replaced, or (no range) the whole text. */
export type LspContentChange = { range: LspRange; rangeLength?: number; text: string } | { text: string };

/** A JSON-RPC message, as the bridge carries it. */
export interface RpcMessage {
  jsonrpc?: '2.0';
  id?: number | string | null;
  method?: string;
  params?: unknown;
  result?: unknown;
  error?: { code: number; message: string; data?: unknown };
}
