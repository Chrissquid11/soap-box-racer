/**
 * The Code card tree's file operations, their rules pure (`file-names.test.ts`): the names a new, duplicated or kept
 * file gets, where a path goes when what holds it moves, what a drop may do, and the right-click menu's entries for a
 * row -- the card (`code-card.ts`) draws and runs them, the dev server's `files/*` routes (`file-ops.ts`) decide.
 *
 * - **A name** (`nameRefusal`): not empty, no `/` or `\`, not `.` or `..`, no NUL -- the server checks the rest.
 * - **A copy's name** (`copyName`), VS Code's: `spin.ts` → `spin copy.ts`, then `spin copy 2.ts`…; the extension is the
 *   last dot's (`spin.test.ts` → `spin.test copy.ts`), a folder's whole name its stem; a name taken in the folder skipped.
 * - **A path after a move** (`movedPath`): the path moved itself, or one under a folder moved; else null.
 * - **A drop** (`dropRefusal`): a move onto its own folder is nothing; into itself or under itself, generated or
 *   read-only, refused with words; else null, and `dropTarget` is the path it lands at.
 * - **A clash's question** (`clashWords`): what is there, and -- open in a tab, changes not saved -- that a Replace closes
 *   the tab and loses them.
 * - **A move's edits in a tab** (`afterEdits`, `editsWords`): a clean tab saves them, a dirty one holds them.
 * - **The menu** (`menuEntries`): VS Code's order and groups -- New File…, New Folder…; Open; Rename…, Duplicate, Save
 *   As…; Copy Path, Copy Relative Path; Reveal in Finder (the app alone), Reveal in the Assets panel (an asset's);
 *   Delete -- each entry there or not by what the row is. The tree's empty space has the first group alone.
 */

import { WRITE_DIRS } from '@vibe/pipeline/paths';

/** A row the menu is for: a file, a folder, or the tree's empty space (the root). */
export interface MenuTarget {
  kind: 'file' | 'folder' | 'root';
  path: string;
  /** Read-only: a package's, an ignored file's. */
  readOnly?: boolean;
  /** Written by `vibe assets`. */
  generated?: boolean;
  /** A tab has it open with its text in a buffer: Save As writes that text. */
  buffered?: boolean;
}

/** What the menu can do here: the app's Finder, an Assets panel to reveal in. */
export interface MenuPlace {
  finder: boolean;
  assetsPanel: boolean;
}

export type MenuAction = 'newFile' | 'newFolder' | 'open' | 'rename' | 'duplicate' | 'saveAs' | 'copyPath' | 'copyRelative' | 'revealFinder' | 'revealAssets' | 'delete';

export interface MenuEntry {
  action: MenuAction;
  label: string;
  /** The key that does the same, shown on its right. */
  key?: string;
  /** A line above it: another group. */
  rule?: boolean;
  danger?: boolean;
}

/** The assets' folders -- `src/assets/`, `AssetsSource/`, `packs/` -- the pipeline's own list, which the Assets panel lists. */
export const ASSET_DIRS: readonly string[] = WRITE_DIRS;

/** Is the path one of the assets' (or one of their folders). */
export const isAssetPath = (path: string): boolean => ASSET_DIRS.some((d) => path === d || path.startsWith(`${d}/`));

export const parentOf = (path: string): string => (path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '');
export const baseOf = (path: string): string => path.slice(path.lastIndexOf('/') + 1);
export const joinPath = (dir: string, name: string): string => (dir === '' ? name : `${dir}/${name}`);

/** Why a name typed is no name, or null. */
export function nameRefusal(name: string): string | null {
  const n = name.trim();
  if (n === '') return 'a name, please';
  if (n === '.' || n === '..') return `${n} is no name`;
  if (/[/\\\0]/.test(n)) return 'a name has no / or \\ in it';
  if (n !== name) return 'no spaces at its ends';
  return null;
}

/** The name with its extension split off at the last dot (none for a folder, a dot-file, or no dot). */
export function splitName(name: string, folder = false): { stem: string; ext: string } {
  const dot = name.lastIndexOf('.');
  if (folder || dot <= 0) return { stem: name, ext: '' };
  return { stem: name.slice(0, dot), ext: name.slice(dot) };
}

/** A copy's path beside `path`, VS Code's way: `x copy.ts`, `x copy 2.ts`… -- the first `taken` does not have. */
export function copyName(path: string, folder: boolean, taken: (path: string) => boolean): string {
  const { stem, ext } = splitName(baseOf(path), folder);
  const dir = parentOf(path);
  for (let n = 1; ; n++) {
    const next = joinPath(dir, `${stem} copy${n === 1 ? '' : ` ${n}`}${ext}`);
    if (!taken(next)) return next;
  }
}

/** Where `path` is once `from` moved to `to`: itself moved, or under a folder moved; null when untouched. */
export function movedPath(path: string, from: string, to: string): string | null {
  if (path === from) return to;
  if (path.startsWith(`${from}/`)) return to + path.slice(from.length);
  return null;
}

/** Where a drop of `from` onto the folder `folder` (`''`: the root) puts it. */
export const dropTarget = (from: string, folder: string): string => joinPath(folder, baseOf(from));

/** What a drop of `from` (a folder or not, read-only or generated) onto `folder` comes to: `'none'` (its own folder), a refusal in words, or null -- go. */
export function dropRefusal(from: { path: string; folder: boolean; readOnly?: boolean; generated?: boolean }, folder: string, copy: boolean): string | null | 'none' {
  if (from.generated) return `${from.path} is generated by vibe assets: never moved by hand`;
  if (!copy && from.readOnly) return `${from.path} is read-only here: not moved`;
  if (from.folder && (folder === from.path || folder.startsWith(`${from.path}/`))) return `${from.path} cannot go into itself`;
  if (!copy && parentOf(from.path) === folder) return 'none';
  return null;
}

/**
 * The question a clash asks: `at` there already; Replace (a file's alone) or Keep both, the copy's name said. A tab
 * open on `at` is named -- a Replace closes it, its unsaved changes lost when it has any.
 */
export function clashWords(at: string, isFolder: boolean, verb: 'move' | 'copy', keepName: string, tab: 'open' | 'dirty' | null): string {
  const lost = tab === 'dirty' ? ` It is open in a tab with changes not saved: a Replace closes the tab and they are lost.` : tab === 'open' ? ' It is open in a tab: a Replace closes the tab.' : '';
  return `${at} is there already${isFolder ? ' (a folder: it is never replaced)' : ''}.${isFolder ? '' : lost} ${isFolder ? 'Keep both' : `Replace it with the one you ${verb === 'move' ? 'moved' : 'copied'}, or keep both`} -- the new one named ${keepName}?`;
}

/**
 * What a tab does with a move's import edits (`vibe/applyEdits`), as VS Code's `files.refactoring.autoSave`: one that
 * was clean saves them at once (`save`) -- or, still at the path it opened (the moved file itself, its buffer not yet
 * followed), once it has followed the move (`saveAfterMove`); one with unsaved changes keeps them with the edits, unsaved
 * (`hold`), for the person to save.
 */
export function afterEdits(wasDirty: boolean, followed: boolean): 'save' | 'saveAfterMove' | 'hold' {
  return wasDirty ? 'hold' : followed ? 'save' : 'saveAfterMove';
}

/**
 * The status line's part for the tabs a move gave edits: those saved, those still waiting with unsaved changes, and
 * those whose save failed (the file changed on disk: its tab's bar says how), and those sent to a tab this page has
 * not heard from (`unheard`: another page's tab, or one closed meanwhile) -- never counted saved.
 */
export function editsWords(saved: readonly string[], waiting: readonly string[], failed: readonly string[] = [], unheard: readonly string[] = []): string {
  const parts: string[] = [];
  if (saved.length > 0) parts.push(`saved in their tabs: ${saved.join(', ')}`);
  if (waiting.length > 0) parts.push(`given their new imports in their tabs, unsaved (save them): ${waiting.join(', ')}`);
  if (failed.length > 0) parts.push(`given their new imports but not saved (see the tab): ${failed.join(', ')}`);
  // Sent to a tab this one has not heard from: another page's, or one closed meanwhile.
  if (unheard.length > 0) parts.push(`sent to a tab not heard from here (another page's, or closed): ${unheard.join(', ')}`);
  return parts.length === 0 ? '' : ` -- ${parts.join('; ')}`;
}

/** The menu's entries for a row, in VS Code's order and groups. */
export function menuEntries(target: MenuTarget, place: MenuPlace): MenuEntry[] {
  const out: MenuEntry[] = [
    { action: 'newFile', label: 'New File…' },
    { action: 'newFolder', label: 'New Folder…' },
  ];
  if (target.kind === 'root') return out;
  const fixed = target.readOnly === true || target.generated === true;
  const group = (entries: MenuEntry[]): void => {
    if (entries.length === 0) return;
    out.push({ ...entries[0]!, rule: true }, ...entries.slice(1));
  };
  if (target.kind === 'file') group([{ action: 'open', label: 'Open' }]);
  const edits: MenuEntry[] = [];
  if (!fixed) edits.push({ action: 'rename', label: 'Rename…', key: 'F2' }, { action: 'duplicate', label: 'Duplicate' });
  if (target.kind === 'file' && target.buffered && !isAssetPath(target.path)) edits.push({ action: 'saveAs', label: 'Save As…' });
  group(edits);
  group([
    { action: 'copyPath', label: 'Copy Path' },
    { action: 'copyRelative', label: 'Copy Relative Path' },
  ]);
  const reveals: MenuEntry[] = [];
  if (place.finder) reveals.push({ action: 'revealFinder', label: 'Reveal in Finder' });
  if (place.assetsPanel && isAssetPath(target.path) && !target.generated) reveals.push({ action: 'revealAssets', label: 'Reveal in the Assets panel' });
  group(reveals);
  if (!fixed) group([{ action: 'delete', label: 'Delete', key: 'Delete', danger: true }]);
  return out;
}
