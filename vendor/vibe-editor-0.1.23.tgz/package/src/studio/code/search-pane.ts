/**
 * The Code card's search pane, in the tree's place while "Search" is on: a query field and a glob field (`**\/*.lua`),
 * both marked `data-keys-field="code-search"` (`SEARCH_FIELD`) -- their Enter a MrDebug field action the tool
 * registers, which calls `run()`: the fields listen for no key themselves -- then `GET /__studio/search?q=&glob=`,
 * its hits in a virtual list (`virtual.ts`' `mount`) grouped by file (a file's row with its count, its hits under
 * it: `line:col  text`), a hit's click opening the file at that line and column. `truncated` is said: the first
 * `SEARCH_LIMIT` only.
 */
import { SEARCH_LIMIT, type SearchHit } from '@vibe/pipeline/studio-types';
import type { StudioCalls } from '../../assets/api.ts';
import { textInput } from '../../fields.ts';
import { control, el } from '../../dom.ts';
import { mount, type Mounted } from '../../virtual.ts';
import { ROW } from './tree-model.ts';

/** The fields' key scope (MrDebug's `data-keys-field`). */
export const SEARCH_FIELD = 'code-search';

/** A row of the list: a file's head, or one of its hits. */
type Row = { kind: 'file'; path: string; count: number } | { kind: 'hit'; hit: SearchHit };

export interface SearchPane {
  readonly el: HTMLElement;
  /** The query run (the fields' Enter). */
  run(): Promise<void>;
  /** The query field focused, its text chosen. */
  focus(): void;
  dispose(): void;
}

/** Hits grouped by file, in the order they came: a file's row, then its hits. Pure. */
export function rowsOf(hits: readonly SearchHit[]): Row[] {
  const byFile = new Map<string, SearchHit[]>();
  for (const hit of hits) {
    const list = byFile.get(hit.path);
    if (list) list.push(hit);
    else byFile.set(hit.path, [hit]);
  }
  return [...byFile].flatMap(([path, list]): Row[] => [{ kind: 'file', path, count: list.length }, ...list.map((hit): Row => ({ kind: 'hit', hit }))]);
}

export function createSearchPane(calls: Pick<StudioCalls, 'search'>, open: (path: string, line: number, col: number) => void): SearchPane {
  const root = el('div', 'ed-code-search');
  const query = textInput('', 'Search: Enter runs it');
  query.dataset.keysField = SEARCH_FIELD;
  query.title = 'A word or a phrase, any case: Enter searches every file the tree has';
  const glob = textInput('', 'Files: **/*.lua');
  glob.dataset.keysField = SEARCH_FIELD;
  glob.title = 'Only the files whose path matches this (**/*.ts, src/game/**): Enter searches';
  const said = el('div', 'ed-dim ed-code-said', 'Type a word, then Enter.');
  const list = el('div', 'ed-code-list');
  root.append(query, glob, said, list);

  let rows: Row[] = [];
  const view: Mounted = mount({
    list,
    rowHeight: () => ROW,
    perRow: () => 1,
    count: () => rows.length,
    key: (i) => {
      const r = rows[i]!;
      return r.kind === 'file' ? `f:${r.path}` : `h:${r.hit.path}:${r.hit.line}:${r.hit.col}`;
    },
    make: () => {
      const b = control('ui', 'ed-code-row');
      b.addEventListener('click', () => {
        const r = rows[Number(b.dataset.at)];
        if (r?.kind === 'hit') open(r.hit.path, r.hit.line, r.hit.col);
        else if (r) open(r.path, 1, 1);
      });
      return b;
    },
    update: (b, i) => {
      const r = rows[i]!;
      b.dataset.at = String(i);
      b.classList.toggle('ed-code-row-file', r.kind === 'file');
      if (r.kind === 'file') {
        b.replaceChildren(el('span', 'ed-code-name', r.path), el('span', 'ed-code-count', String(r.count)));
        b.title = `${r.path}: ${r.count} ${r.count === 1 ? 'hit' : 'hits'}`;
      } else {
        b.replaceChildren(el('span', 'ed-code-at', `${r.hit.line}:${r.hit.col}`), el('span', 'ed-code-text', r.hit.text.trim()));
        b.title = `${r.hit.path}:${r.hit.line}:${r.hit.col}\n${r.hit.text}`;
      }
    },
  });

  let asked = 0;
  return {
    el: root,
    async run() {
      const q = query.value;
      if (q.trim() === '') {
        said.textContent = 'Type a word, then Enter.';
        return;
      }
      const mine = ++asked;
      said.textContent = 'Searching…';
      try {
        const answer = await calls.search(q, glob.value.trim());
        if (mine !== asked) return;
        rows = rowsOf(answer.hits);
        const files = rows.length - answer.hits.length;
        said.textContent =
          answer.hits.length === 0
            ? `Nothing found for "${q}".`
            : `${answer.hits.length} ${answer.hits.length === 1 ? 'hit' : 'hits'} in ${files} ${files === 1 ? 'file' : 'files'}${answer.truncated ? ` -- the first ${SEARCH_LIMIT} only: narrow it` : ''}`;
        view.flush();
        list.scrollTop = 0;
      } catch (err) {
        if (mine === asked) said.textContent = `Not searched: ${(err as Error).message}`;
      }
    },
    focus() {
      query.focus();
      query.select();
    },
    dispose() {
      view.dispose();
      root.remove();
    },
  };
}
