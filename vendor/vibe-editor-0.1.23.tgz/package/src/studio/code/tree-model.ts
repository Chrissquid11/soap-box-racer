/**
 * The Code card's file tree, pure (`tree-model.test.ts`): the folders made from `GET /__studio/tree`'s paths
 * (`buildTree`), which are unfolded at first (`defaultUnfolded`: the first level, and every folder an open file
 * is in), and the rows to draw (`visibleRows`) -- what `virtual.ts`' `mount` lays out, a row per item.
 *
 * - **Empty folders**: the tree is made from files, so a folder with none is not in it -- but one made by New Folder,
 *   which the card keeps and hands in (`buildTree`'s `empty`).
 * - **Order**: a folder's folders first, then its files, each by name (case-insensitive, then as written).
 * - **Folded**: a folder's children are rows only while it is in the unfolded set; the card keeps that set, a
 *   click toggling a folder in it.
 * - **The filter**: a substring of the path, any case; while there is one, every file that matches is a row of
 *   its own, flat, its whole path its name -- and no folder.
 */
import type { FileEntry } from '@vibe/pipeline/studio-types';

/** A row's height in pixels, the tree's and the search pane's: `shell.css`' `.ed-code-row` is this tall. */
export const ROW = 20;

export interface TreeFolder {
  name: string;
  /** From the root, posix; `''` for the root. */
  path: string;
  folders: TreeFolder[];
  files: FileEntry[];
}

export interface TreeRow {
  /** A file's path, or a folder's. */
  path: string;
  /** What the row says: the last segment, or (filtered) the whole path. */
  name: string;
  depth: number;
  folder: boolean;
  /** A folder's: unfolded now. */
  open: boolean;
  /** A file's entry. */
  file?: FileEntry;
}

const byName = (a: string, b: string): number => {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  return x < y ? -1 : x > y ? 1 : a < b ? -1 : a > b ? 1 : 0;
};
const baseName = (path: string): string => path.slice(path.lastIndexOf('/') + 1);

/** The tree of `files`, and of `folders` with no file in them yet (one New Folder made: kept by the card). */
export function buildTree(files: readonly FileEntry[], empty: Iterable<string> = []): TreeFolder {
  const root: TreeFolder = { name: '', path: '', folders: [], files: [] };
  const folders = new Map<string, TreeFolder>([['', root]]);
  const folderOf = (path: string): TreeFolder => {
    const had = folders.get(path);
    if (had) return had;
    const cut = path.lastIndexOf('/');
    const parent = folderOf(cut < 0 ? '' : path.slice(0, cut));
    const made: TreeFolder = { name: path.slice(cut + 1), path, folders: [], files: [] };
    parent.folders.push(made);
    folders.set(path, made);
    return made;
  };
  for (const file of files) {
    const cut = file.path.lastIndexOf('/');
    folderOf(cut < 0 ? '' : file.path.slice(0, cut)).files.push(file);
  }
  for (const path of empty) if (path !== '') folderOf(path);
  for (const f of folders.values()) {
    f.folders.sort((a, b) => byName(a.name, b.name));
    f.files.sort((a, b) => byName(baseName(a.path), baseName(b.path)));
  }
  return root;
}

/** Every folder a path is in: `src/game/x.ts` → `src`, `src/game`. */
export function foldersOf(path: string): string[] {
  const parts = path.split('/').slice(0, -1);
  return parts.map((_, n) => parts.slice(0, n + 1).join('/'));
}

/** The folders unfolded at first: the first level's, and those the open files are in. */
export function defaultUnfolded(tree: TreeFolder, openPaths: Iterable<string>): Set<string> {
  const out = new Set(tree.folders.map((f) => f.path));
  for (const path of openPaths) for (const folder of foldersOf(path)) out.add(folder);
  return out;
}

/** The rows to draw: the tree as `unfolded` has it, or -- with a `filter` -- every file whose path has it, flat. */
export function visibleRows(tree: TreeFolder, unfolded: ReadonlySet<string>, filter = ''): TreeRow[] {
  const rows: TreeRow[] = [];
  const needle = filter.trim().toLowerCase();
  if (needle !== '') {
    const walk = (f: TreeFolder): void => {
      for (const sub of f.folders) walk(sub);
      for (const file of f.files) if (file.path.toLowerCase().includes(needle)) rows.push({ path: file.path, name: file.path, depth: 0, folder: false, open: false, file });
    };
    walk(tree);
    rows.sort((a, b) => byName(a.path, b.path));
    return rows;
  }
  const walk = (f: TreeFolder, depth: number): void => {
    for (const sub of f.folders) {
      const open = unfolded.has(sub.path);
      rows.push({ path: sub.path, name: sub.name, depth, folder: true, open });
      if (open) walk(sub, depth + 1);
    }
    for (const file of f.files) rows.push({ path: file.path, name: baseName(file.path), depth, folder: false, open: false, file });
  };
  walk(tree, 0);
  return rows;
}
