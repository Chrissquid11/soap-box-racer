/**
 * The Code card's breakpoints, the pure part (`code-card.ts` draws them; the shell keeps them -- `window.squidwright.debug`,
 * `app-shell.ts`): `{ file, line }`, the project's path and a 1-based line, as the shell's `breakpoints.json` holds
 * them (the pipeline's `studio/debugger/model.ts` has the same rules on the debugger's side), and whether the game has each set:
 * one with no code on its line within reach, or in a module not loaded yet, is `set: false`, drawn hollow.
 *
 * - `toggle`: a breakpoint added, or taken away when it is there -- what a click in the gutter asks the shell, done
 *   here too so the dot answers at once (the shell's list, when it comes, replaces it).
 * - `merge`: two lists as one, each breakpoint once, sorted by file then line.
 * - `dotsIn`: a file's dots, ascending: each line and whether it is set (no `set` -- a toggle not yet answered, an
 *   app from before it -- is drawn set).
 * Imports nothing.
 */

export interface Breakpoint {
  file: string;
  line: number;
  /** Set in the game now (the shell's word; absent before it answers). */
  set?: boolean;
}

/** A dot of an open file. */
export interface Dot {
  line: number;
  set: boolean;
}

const order = (a: Breakpoint, b: Breakpoint): number => (a.file < b.file ? -1 : a.file > b.file ? 1 : a.line - b.line);

/** `a` and `b` as one list: each breakpoint once, sorted by file then line. */
export function merge(a: readonly Breakpoint[], b: readonly Breakpoint[] = []): Breakpoint[] {
  const seen = new Set<string>();
  const out: Breakpoint[] = [];
  for (const bp of [...a, ...b]) {
    const key = `${bp.file}\n${bp.line}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(bp.set === undefined ? { file: bp.file, line: bp.line } : { file: bp.file, line: bp.line, set: bp.set });
  }
  return out.sort(order);
}

/** `list` with `file:line` added, or without it when it is there. */
export function toggle(list: readonly Breakpoint[], file: string, line: number): Breakpoint[] {
  const there = list.some((bp) => bp.file === file && bp.line === line);
  return there ? list.filter((bp) => bp.file !== file || bp.line !== line) : merge(list, [{ file, line }]);
}

/** `file`'s dots in `list`, ascending: each line, and whether the game has it set. */
export function dotsIn(list: readonly Breakpoint[], file: string): Dot[] {
  return list
    .filter((bp) => bp.file === file)
    .map((bp) => ({ line: bp.line, set: bp.set !== false }))
    .sort((a, b) => a.line - b.line);
}
