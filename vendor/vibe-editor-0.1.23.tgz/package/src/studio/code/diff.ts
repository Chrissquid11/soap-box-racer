/**
 * The Code card's diff view, its pairing pure (`diff.test.ts`): `(path, at)` → the two texts to show side by
 * side, fetched through what is handed in.
 *
 * - **Before** is `GET file?path=&at=<turn>` -- the file as the turn's snapshot has it -- or `at=HEAD`, as git last
 *   committed it, or `at=<hash>^`, as it was before a commit of the Git card's log; a 404 there is a file made
 *   since: an empty before.
 * - **After** is the open buffer when a tab has the file (what the person sees, edits and all), else the disk
 *   (`GET file`); a 404 there is a file the turn removed: an empty after.
 * - Anything else that fails is the pairing's failure: the card says why.
 *
 * The view itself (`code-card.ts`): `monaco.editor.createDiffEditor` in the editor's place, read-only, a Close
 * back to the editor.
 */
import type { FileAnswer } from '@vibe/pipeline/studio-types';

export interface DiffSources {
  /** `GET file?path=&at=`: the before; null for a 404. */
  before(path: string, at: string): Promise<FileAnswer | null>;
  /** `GET file?path=`: the disk; null for a 404. */
  disk(path: string): Promise<FileAnswer | null>;
  /** The open buffer's text, when a tab has the file. */
  buffer(path: string): string | null;
}

export interface DiffPair {
  path: string;
  at: string;
  before: string;
  after: string;
  /** What each side is, for the view's head. */
  beforeLabel: string;
  afterLabel: string;
}

/** `at`'s words: `HEAD` is git's last commit; a hash with `^` the commit before it (the Git card's log), a bare hash that commit; anything else a turn. */
export function atLabel(at: string): string {
  if (at === 'HEAD') return 'as last committed';
  const commit = /^([0-9a-f]{7,40})(\^)?$/i.exec(at);
  if (commit) return commit[2] ? `before ${commit[1]!.slice(0, 7)}` : `at ${commit[1]!.slice(0, 7)}`;
  return 'before the turn';
}

export async function pairFor(path: string, at: string, sources: DiffSources): Promise<DiffPair> {
  const open = sources.buffer(path);
  const [before, disk] = await Promise.all([sources.before(path, at), open === null ? sources.disk(path) : Promise.resolve(null)]);
  const after = open ?? disk?.text ?? '';
  return {
    path,
    at,
    before: before?.text ?? '',
    after,
    beforeLabel: before === null ? `${atLabel(at)}: not there (${at === 'HEAD' || /^[0-9a-f]{7,40}\^?$/i.test(at) ? 'new since' : 'the turn made it'})` : atLabel(at),
    afterLabel: open !== null ? 'now, in its tab' : disk === null ? 'now: removed' : 'now, on disk',
  };
}
