/**
 * Monaco's enums the Code card's converters (`lsp-monaco.ts`) need, as plain values: mirrored from
 * **monaco-editor 0.57.0**'s `esm/vs/editor/editor.api.d.ts` (the version `packages/editor/package.json` pins), so
 * a node test imports the converters without loading Monaco -- which needs a page. A Monaco upgrade checks each
 * number here against the new `editor.api.d.ts` (the comment on each says where it is); the types are Monaco's own,
 * imported as types alone, so a member renamed there fails the typecheck here.
 */
import type * as M from 'monaco-editor/editor/editor.api.js';

/** `MarkerSeverity` (a top-level `declare enum`): what a diagnostic's gutter mark is. */
export const MarkerSeverity = {
  Hint: 1 as M.MarkerSeverity.Hint,
  Info: 2 as M.MarkerSeverity.Info,
  Warning: 4 as M.MarkerSeverity.Warning,
  Error: 8 as M.MarkerSeverity.Error,
} as const;

/** `MarkerTag` (top level): unused code faded, a deprecated name struck through. */
export const MarkerTag = {
  Unnecessary: 1 as M.MarkerTag.Unnecessary,
  Deprecated: 2 as M.MarkerTag.Deprecated,
} as const;

/** `languages.CompletionItemKind`: the icon in the suggest list. */
export const CompletionItemKind = {
  Method: 0 as M.languages.CompletionItemKind.Method,
  Function: 1 as M.languages.CompletionItemKind.Function,
  Constructor: 2 as M.languages.CompletionItemKind.Constructor,
  Field: 3 as M.languages.CompletionItemKind.Field,
  Variable: 4 as M.languages.CompletionItemKind.Variable,
  Class: 5 as M.languages.CompletionItemKind.Class,
  Struct: 6 as M.languages.CompletionItemKind.Struct,
  Interface: 7 as M.languages.CompletionItemKind.Interface,
  Module: 8 as M.languages.CompletionItemKind.Module,
  Property: 9 as M.languages.CompletionItemKind.Property,
  Event: 10 as M.languages.CompletionItemKind.Event,
  Operator: 11 as M.languages.CompletionItemKind.Operator,
  Unit: 12 as M.languages.CompletionItemKind.Unit,
  Value: 13 as M.languages.CompletionItemKind.Value,
  Constant: 14 as M.languages.CompletionItemKind.Constant,
  Enum: 15 as M.languages.CompletionItemKind.Enum,
  EnumMember: 16 as M.languages.CompletionItemKind.EnumMember,
  Keyword: 17 as M.languages.CompletionItemKind.Keyword,
  Text: 18 as M.languages.CompletionItemKind.Text,
  Color: 19 as M.languages.CompletionItemKind.Color,
  File: 20 as M.languages.CompletionItemKind.File,
  Reference: 21 as M.languages.CompletionItemKind.Reference,
  Folder: 23 as M.languages.CompletionItemKind.Folder,
  TypeParameter: 24 as M.languages.CompletionItemKind.TypeParameter,
  Snippet: 28 as M.languages.CompletionItemKind.Snippet,
} as const;

/** `languages.CompletionItemTag`. */
export const CompletionItemTag = {
  Deprecated: 1 as M.languages.CompletionItemTag.Deprecated,
} as const;

/** `languages.CompletionItemInsertTextRule`: a snippet's `$1` placeholders taken as such. */
export const CompletionItemInsertTextRule = {
  None: 0 as M.languages.CompletionItemInsertTextRule.None,
  InsertAsSnippet: 4 as M.languages.CompletionItemInsertTextRule.InsertAsSnippet,
} as const;

/** `languages.CompletionTriggerKind` (Monaco's from 0, LSP's from 1). */
export const CompletionTriggerKind = {
  Invoke: 0 as M.languages.CompletionTriggerKind.Invoke,
  TriggerCharacter: 1 as M.languages.CompletionTriggerKind.TriggerCharacter,
  TriggerForIncompleteCompletions: 2 as M.languages.CompletionTriggerKind.TriggerForIncompleteCompletions,
} as const;

/** `languages.SignatureHelpTriggerKind` (the same numbers as LSP's). */
export const SignatureHelpTriggerKind = {
  Invoke: 1 as M.languages.SignatureHelpTriggerKind.Invoke,
  TriggerCharacter: 2 as M.languages.SignatureHelpTriggerKind.TriggerCharacter,
  ContentChange: 3 as M.languages.SignatureHelpTriggerKind.ContentChange,
} as const;

/** `languages.CodeActionTriggerType`: asked for (the light bulb clicked, Mod+.) or on its own. */
export const CodeActionTriggerType = {
  Invoke: 1 as M.languages.CodeActionTriggerType.Invoke,
  Auto: 2 as M.languages.CodeActionTriggerType.Auto,
} as const;
