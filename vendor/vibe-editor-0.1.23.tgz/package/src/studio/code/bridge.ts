/**
 * The Code card's client of the dev server's TypeScript bridge (`@vibe/pipeline/studio-types`, the bridge's
 * header): LSP messages over Vite's websocket -- `TS_REQ` up, `TS_RES` and `TS_EVENT` down -- through the page's
 * `import.meta.hot` (a `TsChannel`; handed in, so a node test drives a stand-in, `bridge.test.ts`).
 *
 * - **`request(method, params)`**: its own ids, the answer matched by id; a JSON-RPC error is a `BridgeError`
 *   carrying the code -- the bridge's own `TS_REFUSED`, `TS_TIMED_OUT`, `TS_DOWN` named in its words (`codeName`).
 *   A request the bridge never answers (the socket gone) fails on `vite:ws:disconnect`, or after `TS_TIMEOUT`
 *   and a little more -- the bridge's own timeout is the one that should fire.
 * - **`hold(gate)`**: a request (but `vibe/status` and `vibe/open`, the bridge's own) waits for the promise the gate
 *   gives, if any, before it is sent -- `followStatus`' hold while the server has forgotten this tab's files.
 * - **`notify(method, params)`**; **`on(method, fn)`** for the server's notifications (`TS_EVENT`):
 *   `textDocument/publishDiagnostics`, `window/showMessage`.
 * - **The tab never sends `initialize`**: the bridge owns the handshake. `status()` (`vibe/status`) tells the
 *   state, and the project's absolute root -- answered even while the server is `off`, which it does not start --
 *   which every uri is made from.
 * - **Documents**: `open(path, text, languageId)` is `vibe/open` (version 1) → `TsOpenAnswer`, `owner` or
 *   read-only (held by another tab); `change(path, …)` bumps the version and sends `didChange` -- the full text,
 *   or Monaco's ranges (`lsp-monaco.ts`' `toContentChanges`) when the card asks for incremental sync -- for an
 *   owned document only; `close(path)` sends `didClose` for one owned. A read-only one is never changed on the
 *   server: queries on it answer for the holder's text.
 * - **Uris** (`uriOf`, `pathOfUri`): `file://` + the root + `/` + the path, each segment percent-encoded; back,
 *   a uri under the root is its path (posix), under its `node_modules/` read-only, and one outside has no path:
 *   the card says where it is.
 */
import { TS_DOWN, TS_EVENT, TS_REFUSED, TS_REQ, TS_RES, TS_TIMED_OUT, TS_TIMEOUT, type TsEnvelope, type TsOpenAnswer, type TsStatus } from '@vibe/pipeline/studio-types';
import type { LspContentChange, RpcMessage } from './lsp.ts';

/** What `import.meta.hot` is to the bridge: send an event, hear one, stop hearing it. */
export interface TsChannel {
  send(event: string, data?: unknown): void;
  on(event: string, listener: (data: unknown) => void): void;
  off?(event: string, listener: (data: unknown) => void): void;
}

/** A request the server or the bridge refused: the JSON-RPC code (`TS_DOWN` …) and its message. */
export class BridgeError extends Error {
  readonly code: number;
  readonly data: unknown;
  constructor(code: number, message: string, data?: unknown) {
    super(message);
    this.name = 'BridgeError';
    this.code = code;
    this.data = data;
  }
}

/** The bridge's own codes in words, for the status line; another code is the server's. */
export function codeName(code: number): string {
  switch (code) {
    case TS_REFUSED:
      return 'refused: not this machine\'s tab';
    case TS_TIMED_OUT:
      return 'timed out';
    case TS_DOWN:
      return 'TypeScript is down';
    default:
      return `error ${code}`;
  }
}

/** A JSON-RPC error answer as a `BridgeError`: the bridge's codes say what they are before the message. */
export function errorOf(error: { code: number; message: string; data?: unknown }): BridgeError {
  const own = error.code === TS_REFUSED || error.code === TS_TIMED_OUT || error.code === TS_DOWN;
  return new BridgeError(error.code, own ? `${codeName(error.code)}${error.message ? `: ${error.message}` : ''}` : error.message, error.data);
}

// ---------------------------------------------------------------- uris

/** `root` (absolute, either slash) as a `file://` uri's path: forward slashes, a leading one (a Windows drive gets one too), each segment encoded. */
function rootPath(root: string): string {
  let p = root.replace(/\\/g, '/').replace(/\/+$/, '');
  if (!p.startsWith('/')) p = `/${p}`;
  return p
    .split('/')
    .map((seg, n) => (n === 1 && /^[A-Za-z]:$/.test(seg) ? seg : encodeURIComponent(seg)))
    .join('/');
}

/** The uri of `path` (posix, from the root) in the project at `root`. */
export function uriOf(root: string, path: string): string {
  return `file://${rootPath(root)}/${path.split('/').map(encodeURIComponent).join('/')}`;
}

/** Where a uri is: a path under the root (read-only under its `node_modules/`), or outside it -- the absolute path, for the card's words. */
export type UriPlace = { path: string; readOnly: boolean } | { outside: string };

export function pathOfUri(root: string, uri: string): UriPlace {
  let abs: string;
  try {
    abs = uri.startsWith('file://') ? decodeURIComponent(uri.slice('file://'.length)) : uri;
  } catch {
    abs = uri;
  }
  // `file:///c%3A/x` and `file:///C:/x` are one place: the drive letter's case is not the path's.
  const norm = (p: string): string => p.replace(/\\/g, '/').replace(/^\/([A-Za-z]):/, (_m, d: string) => `/${d.toLowerCase()}:`);
  const base = norm(`/${root.replace(/\\/g, '/').replace(/^\/+/, '').replace(/\/+$/, '')}`);
  const at = norm(abs.startsWith('/') ? abs : `/${abs}`);
  if (!at.startsWith(`${base}/`)) return { outside: abs.replace(/^\/([A-Za-z]:)/, '$1') };
  const path = at.slice(base.length + 1);
  return { path, readOnly: path.startsWith('node_modules/') || path.includes('/node_modules/') };
}

// ---------------------------------------------------------------- the client

/** A document this tab has told the server of. */
interface Doc {
  uri: string;
  version: number;
  owner: boolean;
  /** Its `vibe/open` still on its way: an edit made meanwhile is not sent (not owned yet) but kept here, its text. */
  opening: boolean;
  latest: string | null;
}

export interface Bridge {
  /** The project's root as `vibe/status` last said, or null before the first. */
  readonly root: string | null;
  /** `vibe/status`: the server's state, the root, TypeScript's version. */
  status(): Promise<TsStatus>;
  request<T = unknown>(method: string, params?: unknown): Promise<T>;
  /** Each request but `vibe/status` and `vibe/open` waits for what `gate` gives (none: sent at once); null lets go. */
  hold(gate: (() => Promise<void> | null) | null): void;
  notify(method: string, params?: unknown): void;
  /** Hear a notification the server sends (`TS_EVENT`). Returns the undo. */
  on(method: string, fn: (params: unknown) => void): () => void;
  /** The uri of a path, once the root is known. */
  uri(path: string): string;
  /** A uri's place (`pathOfUri`). */
  place(uri: string): UriPlace;
  /** `vibe/open`: the file opened on the server by this tab (`owner`), or read-only, held by another. */
  open(path: string, text: string, languageId: string): Promise<TsOpenAnswer>;
  /** Is `path` open here, and owned. */
  owns(path: string): boolean;
  /** An owned document's new text (`didChange`): the whole, or the changes given. Nothing for one not owned. */
  change(path: string, text: string, changes?: readonly LspContentChange[]): void;
  /** `didClose` for an owned document; forgotten either way. */
  close(path: string): void;
  /** Every document closed, every request failed, the channel let go. */
  dispose(): void;
}

export interface BridgeOptions {
  /** How long a request waits on the bridge before failing here: the bridge's `TS_TIMEOUT` and a margin, by default. */
  timeoutMs?: number;
}

export function createBridge(channel: TsChannel, { timeoutMs = TS_TIMEOUT + 5_000 }: BridgeOptions = {}): Bridge {
  let nextId = 1;
  let root: string | null = null;
  let disposed = false;
  const pending = new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void; timer: ReturnType<typeof setTimeout> }>();
  const listeners = new Map<string, Set<(params: unknown) => void>>();
  const docs = new Map<string, Doc>();
  let gate: (() => Promise<void> | null) | null = null;

  const failAll = (error: BridgeError): void => {
    for (const [id, p] of pending) {
      clearTimeout(p.timer);
      pending.delete(id);
      p.reject(error);
    }
  };

  const onRes = (data: unknown): void => {
    const message = (data as TsEnvelope | undefined)?.message as RpcMessage | undefined;
    if (!message || typeof message.id !== 'number') return;
    const p = pending.get(message.id);
    if (!p) return;
    pending.delete(message.id);
    clearTimeout(p.timer);
    if (message.error) p.reject(errorOf(message.error));
    else p.resolve(message.result ?? null);
  };
  const onEvent = (data: unknown): void => {
    const message = (data as TsEnvelope | undefined)?.message as RpcMessage | undefined;
    if (!message || typeof message.method !== 'string') return;
    for (const fn of listeners.get(message.method) ?? []) fn(message.params);
  };
  const onGone = (): void => failAll(new BridgeError(TS_DOWN, 'the dev server went away'));
  channel.on(TS_RES, onRes);
  channel.on(TS_EVENT, onEvent);
  channel.on('vite:ws:disconnect', onGone);

  const send = (message: RpcMessage): void => channel.send(TS_REQ, { message } satisfies TsEnvelope);

  /** Sent now, whatever the gate: the bridge's own messages, and a request once its wait is over. */
  function ask<T>(method: string, params?: unknown): Promise<T> {
    if (disposed) return Promise.reject(new BridgeError(TS_DOWN, 'the Code card was closed'));
    const id = nextId++;
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new BridgeError(TS_TIMED_OUT, `${codeName(TS_TIMED_OUT)}: ${method} had no answer`));
      }, timeoutMs);
      pending.set(id, { resolve: resolve as (v: unknown) => void, reject, timer });
      send({ jsonrpc: '2.0', id, method, params });
    });
  }

  function request<T>(method: string, params?: unknown): Promise<T> {
    const wait = disposed ? null : gate?.();
    // The wait's own failure is no reason to fail the request: it is sent either way, and answers for itself.
    return wait ? wait.then(() => ask<T>(method, params), () => ask<T>(method, params)) : ask<T>(method, params);
  }

  const uri = (path: string): string => {
    if (root === null) throw new Error('[code] no root yet: vibe/status first');
    return uriOf(root, path);
  };

  const bridge: Bridge = {
    get root() {
      return root;
    },
    async status() {
      const s = await ask<TsStatus>('vibe/status');
      root = s.root;
      return s;
    },
    request,
    hold(g) {
      gate = g;
    },
    notify(method, params) {
      if (!disposed) send({ jsonrpc: '2.0', method, params });
    },
    on(method, fn) {
      let set = listeners.get(method);
      if (!set) listeners.set(method, (set = new Set()));
      set.add(fn);
      return () => void set.delete(fn);
    },
    uri,
    place: (u) => (root === null ? { outside: u } : pathOfUri(root, u)),
    async open(path, text, languageId) {
      const u = uri(path);
      // Opened again (a reload of the text): the old one closed first, so the server starts at version 1 again.
      if (docs.has(path)) bridge.close(path);
      const doc: Doc = { uri: u, version: 1, owner: false, opening: true, latest: null };
      docs.set(path, doc);
      let answer: TsOpenAnswer;
      try {
        answer = await ask<TsOpenAnswer>('vibe/open', { uri: u, text, version: 1, languageId });
      } finally {
        doc.opening = false;
      }
      if (docs.get(path) === doc) {
        doc.owner = answer.owner;
        // Typed into while the open was on its way (a reopen after a crash, as the caret is in it): the server has
        // the text as it was sent, so the whole of it now -- the incremental changes after this build on it.
        if (doc.owner && doc.latest !== null && doc.latest !== text) {
          doc.version++;
          bridge.notify('textDocument/didChange', { textDocument: { uri: doc.uri, version: doc.version }, contentChanges: [{ text: doc.latest }] });
        }
        doc.latest = null;
      }
      return answer;
    },
    owns: (path) => docs.get(path)?.owner === true,
    change(path, text, changes) {
      const doc = docs.get(path);
      if (doc?.opening) doc.latest = text;
      if (!doc || !doc.owner) return;
      doc.version++;
      bridge.notify('textDocument/didChange', { textDocument: { uri: doc.uri, version: doc.version }, contentChanges: changes ?? [{ text }] });
    },
    close(path) {
      const doc = docs.get(path);
      if (!doc) return;
      docs.delete(path);
      if (doc.owner) bridge.notify('textDocument/didClose', { textDocument: { uri: doc.uri } });
    },
    dispose() {
      for (const path of [...docs.keys()]) bridge.close(path);
      disposed = true;
      failAll(new BridgeError(TS_DOWN, 'the Code card was closed'));
      channel.off?.(TS_RES, onRes);
      channel.off?.(TS_EVENT, onEvent);
      channel.off?.('vite:ws:disconnect', onGone);
      listeners.clear();
    },
  };
  return bridge;
}

// ---------------------------------------------------------------- the server's state, followed

/** A document to tell the server of again: an open script buffer's path, its text now, its language. */
export interface OpenDocument {
  path: string;
  text: string;
  languageId: string;
}

export interface StatusFollower {
  /** A status heard -- the bridge's `vibe/status` notification (heard here) or the answer of a `status()` the card asked. */
  heard(s: TsStatus): void;
  /** The bridge unreachable (a `status()` that failed): what it held of this tab may be gone, so reopen at the next `up`. */
  lost(): void;
  /** Stop hearing the notification, and hold no request. */
  off(): void;
}

export interface FollowOptions {
  /** Every status, to draw. */
  status(s: TsStatus): void;
  /** The documents to open again: the card's script buffers. */
  documents(): Iterable<OpenDocument>;
  /** One reopened: its answer, or the failure. */
  reopened(path: string, answer: TsOpenAnswer | Error): void;
}

/**
 * The server's state followed, and the open documents told to it again once it is back: a crash (`failed`) or a
 * stop (`off`) forgets every file, and the bridge says `starting` before `up`, so what decides is a `lost` flag --
 * set at `failed` or `off` (or `lost()`), cleared as every document is opened again: at the next `up`. An `off`
 * before the server was ever heard starting is the server not started yet, nothing lost (the first `vibe/open`
 * starts it).
 *
 * **Requests are held** (`bridge.hold`) while the files are lost and while their reopens are on their way: a
 * request sent meanwhile -- the keystroke's that restarts the server -- would otherwise reach it before the reopens
 * and ask about a file it does not know. Since a request is what restarts a crashed server, one made while `lost`
 * starts the reopens itself, its `vibe/open`s going first (the bridge sends a tab's messages in order once `up`),
 * and is sent when they have settled; the `up` heard after finds nothing lost. A reopen refused `TS_DOWN` (the
 * server not back: its respawn is once a minute) leaves the files lost, for the next `up` or request.
 */
export function followStatus(bridge: Bridge, options: FollowOptions): StatusFollower {
  let lost = false;
  let seen = false;
  /** The reopens on their way, settled (never failing) once every answer is in. */
  let ready: Promise<void> | null = null;
  const reopen = (): Promise<void> => {
    lost = false;
    const each = [...options.documents()].map((d) =>
      bridge.open(d.path, d.text, d.languageId).then(
        (answer) => {
          options.reopened(d.path, answer);
          return true;
        },
        (err: Error) => {
          options.reopened(d.path, err);
          return !(err instanceof BridgeError && err.code === TS_DOWN);
        },
      ),
    );
    const p: Promise<void> = Promise.all(each).then((done) => {
      if (done.includes(false)) lost = true;
      if (ready === p) ready = null;
    });
    ready = p;
    return p;
  };
  const heard = (s: TsStatus): void => {
    if (s.state === 'starting' || s.state === 'up') seen = true;
    else if (s.state === 'failed' || (s.state === 'off' && seen)) lost = true;
    options.status(s);
    if (s.state === 'up' && lost) void reopen();
  };
  bridge.hold(() => (lost ? reopen() : ready));
  const unhear = bridge.on('vibe/status', (params) => heard(params as TsStatus));
  return {
    heard,
    lost() {
      lost = true;
    },
    off() {
      unhear();
      bridge.hold(null);
    },
  };
}
