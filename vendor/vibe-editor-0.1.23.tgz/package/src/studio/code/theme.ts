/**
 * Monaco's theme for the Code card, made from the shell's own tokens (`shell.css`' `.ed` custom properties: the
 * code background, the ink, the dim and faint inks, the edge, the accent, danger and warning, and the syntax
 * colours `--code-*`) as they are when the card first opens -- read off the card's element (`readTokens`), so a
 * colour changed in shell.css changes the editor too. `themeFrom(tokens)` is pure (`theme.test.ts`): Monaco wants
 * `#rrggbb` or `#rrggbbaa`, so `rgb()`/`rgba()` and short hex become that (`hexOf`). A dark base (`vs-dark`),
 * defined once (`defineTheme`) and set.
 */
import type * as M from 'monaco-editor/editor/editor.api.js';

/** The theme's name, as `defineTheme` and `setTheme` take it. */
export const THEME = 'vibe-studio';

/** The custom properties read, by the name `themeFrom` takes them under. */
export const TOKENS = {
  background: '--code-bg',
  ink: '--ink',
  dim: '--dim',
  faint: '--faint',
  raised: '--raised',
  edge: '--edge',
  accent: '--accent',
  danger: '--danger',
  warn: '--warn',
  good: '--good',
  keyword: '--code-keyword',
  string: '--code-string',
  number: '--code-number',
  type: '--code-type',
} as const;

export type ThemeTokens = Record<keyof typeof TOKENS, string>;

/** A CSS colour as Monaco's hex -- `#rgb`, `#rrggbb`, `#rrggbbaa`, `rgb()`, `rgba()` -- or null for one it is not. */
export function hexOf(css: string): string | null {
  const c = css.trim().toLowerCase();
  const two = (n: number): string => Math.round(Math.max(0, Math.min(255, n))).toString(16).padStart(2, '0');
  let m = /^#([0-9a-f]{3,4})$/.exec(c);
  if (m) return `#${[...m[1]!].map((d) => d + d).join('')}`;
  m = /^#([0-9a-f]{6}|[0-9a-f]{8})$/.exec(c);
  if (m) return c;
  m = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/.exec(c);
  if (!m) return null;
  const alpha = m[4] === undefined ? 1 : m[4].endsWith('%') ? Number.parseFloat(m[4]) / 100 : Number.parseFloat(m[4]);
  const hex = `#${two(+m[1]!)}${two(+m[2]!)}${two(+m[3]!)}`;
  return alpha >= 1 ? hex : `${hex}${two(alpha * 255)}`;
}

/** Monaco's theme from the tokens: the editor's ground, words, selection, gutter and widgets, and the syntax. A token that is no colour is left out (Monaco's own then). */
export function themeFrom(tokens: ThemeTokens): M.editor.IStandaloneThemeData {
  const hex = (name: keyof ThemeTokens): string | null => hexOf(tokens[name]);
  /** A rule's colour: Monaco's rules take hex without the `#`, and no alpha. */
  const fg = (name: keyof ThemeTokens): string | undefined => hex(name)?.slice(1, 7);
  /** A token's colour, its alpha replaced: a ground under words (a selection, a diff's lines). */
  const tint = (name: keyof ThemeTokens, alpha: string): string | null => (hex(name) === null ? null : `${hex(name)!.slice(0, 7)}${alpha}`);
  const colours: Record<string, string | null> = {
    'editor.background': hex('background'),
    'editor.foreground': hex('ink'),
    'editorLineNumber.foreground': hex('faint'),
    'editorLineNumber.activeForeground': hex('dim'),
    'editor.lineHighlightBackground': hex('raised'),
    'editor.selectionBackground': tint('accent', '40'),
    'editorCursor.foreground': hex('accent'),
    'editorIndentGuide.background1': hex('edge'),
    'editorWidget.background': hex('background'),
    'editorWidget.border': hex('edge'),
    'editorSuggestWidget.background': hex('background'),
    'editorSuggestWidget.border': hex('edge'),
    'editorSuggestWidget.selectedBackground': hex('raised'),
    'editorHoverWidget.background': hex('background'),
    'editorHoverWidget.border': hex('edge'),
    'editorError.foreground': hex('danger'),
    'editorWarning.foreground': hex('warn'),
    'editorGutter.background': hex('background'),
    'diffEditor.insertedTextBackground': tint('good', '26'),
    'diffEditor.removedTextBackground': tint('danger', '26'),
    focusBorder: hex('accent'),
  };
  const rules: M.editor.ITokenThemeRule[] = [
    { token: 'comment', foreground: fg('dim'), fontStyle: 'italic' },
    { token: 'keyword', foreground: fg('keyword') },
    { token: 'string', foreground: fg('string') },
    { token: 'number', foreground: fg('number') },
    { token: 'type', foreground: fg('type') },
    { token: 'type.identifier', foreground: fg('type') },
    { token: 'delimiter', foreground: fg('dim') },
    { token: 'invalid', foreground: fg('danger') },
  ].filter((r) => r.foreground !== undefined);
  return {
    base: 'vs-dark',
    inherit: true,
    rules,
    colors: Object.fromEntries(Object.entries(colours).filter((e): e is [string, string] => e[1] !== null)),
  };
}

/** The tokens as they are on `el` (inside the shell's `.ed`): the page's, not node's. */
export function readTokens(el: Element): ThemeTokens {
  const style = getComputedStyle(el);
  return Object.fromEntries(Object.entries(TOKENS).map(([name, prop]) => [name, style.getPropertyValue(prop).trim()])) as ThemeTokens;
}
