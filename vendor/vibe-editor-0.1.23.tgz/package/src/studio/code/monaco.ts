/**
 * Monaco, for the Code card: **the one module that imports `monaco-editor`**, and itself only ever imported by
 * `import()` -- `code-card.ts`' `start()` on the card's first open, never as the editor loads -- so a debug build
 * has Monaco as a lazy chunk of its own and a release build none of it (the editor is not there at all).
 *
 * - **What is loaded**: the editor's API (`editor/editor.api.js`) and its features (`features/register.all.js`,
 *   with the few `editor.main.js` adds beside it: the core commands, find, suggest, go to symbol), and the
 *   basic-languages tokenizers alone for typescript, javascript, css, html, markdown and lua -- each a Monarch
 *   grammar loaded on its language's first model -- and JSON's own small grammar here (`.json`, `.prefab`,
 *   `.scene`). **Never `language/typescript`** (nor the `languages/features/*` editor.main.js brings): its worker and
 *   its own TypeScript. The project's TypeScript is the dev server's (the bridge), and `providers.ts` asks it.
 * - **One worker**: `MonacoEnvironment.getWorker` gives the editor's own (diffs, links, word suggestions), through
 *   Vite's `?worker`; there is no other.
 * - **Its CSS** comes with the imports (`codicon.css` and every widget's own), which Vite injects into the page.
 *
 * `monaco-editor` is a `dependency` of `@vibe/editor`, not a devDependency: a project depends on the editor (in
 * its devDependencies), and npm installs a package's dependencies with it -- a devDependency of the editor would
 * never reach a project.
 */
import * as monaco from 'monaco-editor/editor/editor.api.js';
import 'monaco-editor/features/register.all.js';
import 'monaco-editor/editor/browser/coreCommands.js';
import 'monaco-editor/editor/contrib/find/browser/findController.js';
import 'monaco-editor/editor/contrib/suggest/browser/suggestController.js';
import 'monaco-editor/editor/contrib/gotoSymbol/browser/goToCommands.js';
import 'monaco-editor/languages/definitions/typescript/register.js';
import 'monaco-editor/languages/definitions/javascript/register.js';
import 'monaco-editor/languages/definitions/css/register.js';
import 'monaco-editor/languages/definitions/html/register.js';
import 'monaco-editor/languages/definitions/markdown/register.js';
import 'monaco-editor/languages/definitions/lua/register.js';
import EditorWorker from 'monaco-editor/editor/editor.worker.js?worker';

export type Monaco = typeof monaco;

self.MonacoEnvironment = {
  getWorker: () => new EditorWorker(),
};

/** JSON's colours: a key, a string, a number, a word -- Monaco's own JSON support is a worker's, not loaded here. */
monaco.languages.register({ id: 'json', extensions: ['.json', '.prefab', '.scene'], aliases: ['JSON', 'json'] });
monaco.languages.setMonarchTokensProvider('json', {
  tokenizer: {
    root: [
      [/"(?:[^"\\]|\\.)*"(?=\s*:)/, 'type'],
      [/"(?:[^"\\]|\\.)*"/, 'string'],
      [/-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/, 'number'],
      [/\b(?:true|false|null)\b/, 'keyword'],
      [/[{}[\],:]/, 'delimiter'],
    ],
  },
});
monaco.languages.setLanguageConfiguration('json', {
  brackets: [
    ['{', '}'],
    ['[', ']'],
  ],
  autoClosingPairs: [
    { open: '{', close: '}' },
    { open: '[', close: ']' },
    { open: '"', close: '"' },
  ],
});

export { monaco };
