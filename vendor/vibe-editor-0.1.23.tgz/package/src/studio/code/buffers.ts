/**
 * What the Code card does with an open buffer when the file under it moves, pure (`buffers.test.ts`):
 * `decide(buffer, event) → action`, the card doing the action.
 *
 * - **`studio:file-changed`, `changed`**: the card's own save heard back (the mtime it holds) → nothing; while
 *   its save is on its way → `wait` (the card decides again once the answer brings the mtime); a clean buffer →
 *   `reload` (`GET file`, the text set with `pushEditOperations` so undo keeps, the caret and the scroll put
 *   back); a dirty one → the `bar`: "Changed on disk: Reload · Keep mine".
 * - **`removed`**: the tab marked `removed` (said on its tab and the status line); it stays editable, and a save
 *   writes the file anew.
 * - **A save's 412** (`FileConflict`): the same bar, the server's text as the "on disk" side and its mtime -- a
 *   click on the bar's diff shows mine against it. Keep mine then saves over it with that mtime.
 * - **A save's 423** (`FileLocked`): the status line says "Claude is writing this file (<title>); try again when
 *   the turn ends"; the buffer keeps its edits, dirty.
 */

export interface BufferState {
  path: string;
  dirty: boolean;
  /** The mtime the buffer's text was read or saved at; null for a file not on disk (removed, or a turn's snapshot). */
  mtime: number | null;
  /** Its save on its way. */
  saving: boolean;
  removed: boolean;
}

export type FileEvent =
  | { kind: 'changed'; mtime: number | null }
  | { kind: 'removed' }
  | { kind: 'conflict'; text: string; mtime: number }
  | { kind: 'locked'; title: string };

export type BufferAction =
  | { do: 'nothing' }
  | { do: 'wait' }
  | { do: 'reload' }
  /** The bar: Reload · Keep mine. `onDisk` the server's text when it came with the event (a 412), else fetched on a diff; `mtime` what Keep mine saves over. */
  | { do: 'bar'; onDisk: string | null; mtime: number | null }
  | { do: 'removed' }
  | { do: 'say'; text: string };

/** The words of a 423. */
export const lockedText = (title: string): string => `Claude is writing this file (${title}); try again when the turn ends`;

export function decide(buffer: BufferState, event: FileEvent): BufferAction {
  switch (event.kind) {
    case 'changed':
      if (buffer.saving) return { do: 'wait' };
      // Our own save heard back, or a touch that changed nothing we hold.
      if (event.mtime !== null && event.mtime === buffer.mtime && !buffer.removed) return { do: 'nothing' };
      return buffer.dirty ? { do: 'bar', onDisk: null, mtime: event.mtime } : { do: 'reload' };
    case 'removed':
      return buffer.removed ? { do: 'nothing' } : { do: 'removed' };
    case 'conflict':
      return { do: 'bar', onDisk: event.text, mtime: event.mtime };
    case 'locked':
      return { do: 'say', text: lockedText(event.title) };
  }
}
