/**
 * The Studio tab's Code card: a real editor -- Monaco (`code/monaco.ts`, loaded on the card's first open) over the
 * dev server's file routes (`GET tree`, `GET file`, `PUT file`) and its TypeScript bridge (`code/bridge.ts`: the
 * project's own TypeScript language server, spoken to in LSP; `code/providers.ts` the features).
 *
 * - **Layout**: a left pane -- the file tree (`code/tree-model.ts`, a virtual list), its toolbar a filter field,
 *   Search (the search pane, `code/search-pane.ts`, in the tree's place) and a refresh -- then the tab bar, the
 *   editor filling the rest, and a status line: the bridge's state and TypeScript's version, the file's read-only
 *   or holder words, the caret's `Ln, Col`, the last save's result.
 *   The Studio tab covers the page: the tree keeps its width (`--code-side-w`), the editor and the diff the rest.
 * - **A file opened**: `GET file`, a Monaco model per path (its language by extension, `tabs.ts`' `languageOf`);
 *   a `.ts`/`.js` one told to the bridge (`vibe/open`) -- this tab its owner, or read-only while another tab holds
 *   it (`held by <tab>`); a package's file (`readOnly` from the route) is read-only too.
 * - **Save** is `Mod+S`, a MrDebug field action (`field: 'code'`) the tool registers: the card's root is marked
 *   `data-keys-field="code"`, and Monaco's own keys stay inside it -- its input is a `textarea` (`editContext:
 *   false`: Monaco's EditContext input is a plain `div`, which MrDebug would not take for typing), so the editor's
 *   single-letter keys rest while the caret is in it. `PUT file { path, text, ifMtime }`, the new mtime kept.
 *   A dirty tab's close asks in a bar in the card: Save · Don't save · Cancel.
 * - **The disk moving** (`studio:file-changed`, through the hub; a save's 412 and 423): `code/buffers.ts`' `decide`
 *   -- a clean buffer read again with the caret and the scroll kept (one edit: undo keeps), a dirty one the bar
 *   "changed on disk: Reload · Keep mine · Diff", a file removed marked on its tab, a 423 "Claude is writing this
 *   file (<title>); try again when the turn ends".
 * - **The diff view** (`openDiff(path, at)`, `code/diff.ts` its pairing): Monaco's diff editor in the editor's
 *   place, read-only, the turn's (or HEAD's) text against the open buffer or the disk; Close goes back. What the
 *   Problems card's row and the agent card's result row open, through the hub.
 * - **Diagnostics**: the bridge's markers in the gutter (owner `ts`: `publishDiagnostics`, and
 *   `textDocument/diagnostic` once as a file opens and after each save of one this tab does not own). The top
 *   bar's problems count stays tsc's, project-wide (the Problems card's): the bridge's are only the open files'.
 * - **Breakpoints** (the app's: `window.squidwright.debug`, `app-shell.ts`; in a browser the dev server's, `server-debug.ts`,
 *   attached when the tab runs under VS Code's F5 -- a Chrome with a debugging port): a plain left click in the glyph margin
 *   of a script toggles one there, and so does `F9` on the caret's line (`toggleAtCaret`, a field action of the
 *   card's, `CODE_FIELD`, the tool registers) -- the shell keeps the list (`breakpoints.json`) and sets it in the game through
 *   Chrome's debugging protocol -- drawn as a red dot (`ed-code-breakpoint`) on every open file, hollow (`unbound`)
 *   while the game does not have it set (no code on its line within reach, its module not loaded yet), read as the
 *   card starts and again whenever the shell says the list changed (the Debugger window removed one, a module
 *   loaded). Once the game runs on after a pause, the line it stopped at is marked for 3 s (`ed-code-hit`, one mark
 *   at a time across the files) when its file is open, else said on the status
 *   line: while paused the page is frozen, so nothing here moves until then. The status line's Debugger button opens
 *   the project's Debugger (the app's window, the dev server's tab). With neither able to set one (a browser the dev
 *   server's debugger is not attached to) a click there or F9 says breakpoints need the app or VS Code's F5, and the
 *   Debugger button is disabled with the same words for its title (`code/breakpoints.ts` is the list's rules).
 * - **The tree's files** (`code/file-names.ts` the rules, the dev server's `files/*` routes the work, `file-ops.ts`):
 *   a click selects a row (a folder's toggles, a file's opens); a right-click -- on a file, a folder or the empty space
 *   -- opens the editor's menu card (`menu.ts`) in VS Code's order: New File…, New Folder… (the name typed in the tree,
 *   where it will be, Enter to make, Esc to leave it; a new file opened); Open; Rename… (`F2` too), Duplicate (`x
 *   copy.ts`), Save As… (a tab's text to a new path, opened there, the file left as on disk); Copy Path, Copy Relative
 *   Path; Reveal in Finder (the app's alone, `window.squidwright.reveal`), Reveal in the Assets panel (an asset's);
 *   Delete (`Delete`, `Backspace` too), asked in the editor's dialog, saying where it goes -- the app's Trash
 *   (`window.squidwright.trash`, the server checking first), the project's `.trash/` for an asset, for good in a
 *   browser -- and what of it was not saved. A row dragged onto a folder (a file: onto its folder; the empty space:
 *   the root) moves there, Alt (Option) copies; the folder under the pointer lit, opened after a moment's rest; a
 *   generated or read-only row not dragged, said why. Into itself is refused; a name there already asks Replace, Keep
 *   both or Cancel. A move keeps the project whole: the tabs and their unsaved text follow their files (a new model at
 *   the new path; a dirty one keeps its old mtime, so a save over imports TypeScript rewrote meanwhile is a conflict,
 *   not a loss), the breakpoints too; the server rewrites the imports (TypeScript's) or the asset's keys (the Assets
 *   panel's move), and the status line says how many files changed. The keys are the Studio tool's MrDebug actions,
 *   live while the focus is in the tree (`treeFocused`); the menu's arrows too, Esc its `holdsEscape`.
 * - **Theme and sizes** from `shell.css`' tokens (`code/theme.ts`); the card's CSS under `.ed-code-`.
 *
 * `hide()` keeps every buffer; `dispose()` disposes the models and closes the bridge's open files.
 */
import type * as M from 'monaco-editor/editor/editor.api.js';
import { keyLabel } from '@vibe/engine/debug';
import type { ApplyEdits, FileClash, FileEntry, FilesMoved, TsOpenAnswer, TsStatus } from '@vibe/pipeline/studio-types';
import { ApiRefused } from '../assets/api.ts';
import { textEdit, textInput } from '../fields.ts';
import { showDialog, dialogNote } from '../dialog.ts';
import { createMenu, type Menu, type MenuItem } from '../menu.ts';
import type { Mcp } from '../mcp/declare.ts';
import { appShell, shellDebug, shellWords } from './app-shell.ts';
import { afterEdits, baseOf, clashWords, copyName, editsWords, dropRefusal, dropTarget, isAssetPath, joinPath, menuEntries, movedPath, nameRefusal, parentOf, splitName, type MenuAction, type MenuTarget } from './code/file-names.ts';
import { hubPushes, notAttachedWords, serverDebug, type ServerDebug } from './server-debug.ts';
import { dotsIn, toggle as toggleBreakpoint, type Breakpoint } from './code/breakpoints.ts';
import { button, control, el, iconButton } from '../shell.ts';
import { mount, type Mounted } from '../virtual.ts';
import { createBridge, followStatus, type Bridge, type BridgeError, type OpenDocument, type StatusFollower, type TsChannel } from './code/bridge.ts';
import type { LspDiagnostic, LspDocumentDiagnosticReport, LspPublishDiagnostics, LspTextEdit } from './code/lsp.ts';
import { applyTextEdits, toContentChanges, toMarker, toMonacoRange } from './code/lsp-monaco.ts';
import { decide, type FileEvent } from './code/buffers.ts';
import { pairFor, type DiffPair } from './code/diff.ts';
import { createSearchPane } from './code/search-pane.ts';
import type { Monaco } from './code/monaco.ts';
import type { QuickAt } from '../agent/quick.ts';
import { registerProviders } from './code/providers.ts';
import { activate, closeTab, dirtyTabs, emptyTabs, find, isScript, languageOf, newTab, openTab, pin, renameTab, update, closeOthers, type Tab, type TabList } from './code/tabs.ts';
import { readTokens, themeFrom, THEME } from './code/theme.ts';
import { buildTree, defaultUnfolded, foldersOf, ROW, visibleRows, type TreeFolder, type TreeRow } from './code/tree-model.ts';
import type { FileChanged, StudioCard, StudioHub } from './hub.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';


/** The card's key scope (MrDebug's `data-keys-field`): Mod+S, F9. */
export const CODE_FIELD = 'code';

export interface CodeCard extends StudioCard {
  /** `path` opened in a tab (or brought forward), the caret at `line` and `col` (from 1) when given. */
  openFile(path: string, line?: number, col?: number): Promise<void>;
  /** `path` as it was at `at` (a turn, `HEAD`) against now, side by side in the editor's place. */
  openDiff(path: string, at: string): Promise<void>;
  /** The active tab saved (Mod+S). */
  save(): Promise<void>;
  /** The search pane's query run (its fields' Enter). */
  search(): Promise<void>;
  /** A breakpoint toggled on the caret's line of the active file (F9), as a click in its gutter does. */
  toggleAtCaret(): void;
  /** A quick prompt (Mod+K, Docs/ai-panel.md §4) about the active file at the caret: over the caret's line, in the editor's box. Null with no file open. */
  quickTarget(): QuickAt | null;
  /**
   * Where the person is in the active file, for a turn's facts (Docs/terminal.md D9): its path, the caret's line and column
   * (from 1), the text selected (null for none) and whether it has changes not saved. Null with no file open in the editor.
   */
  caret(): CodeCaret | null;
  /** The tree's selected row renamed where it is (F2). */
  renameSelected(): void;
  /** The tree's selected row deleted, asked first (Delete, Backspace). */
  deleteSelected(): void;
  /** Is the focus in the tree (a row of it): its keys are live. */
  treeFocused(): boolean;
  /** The tree's right-click menu: its arrows are the tool's keys. */
  readonly menu: Menu;
  /** Esc is the card's just now: its menu is open. */
  holdsEscape(): boolean;
  cancel(): void;
  /** What the card keeps across a reload the editor survives (a move under `src/game/` reloads the page): its tabs, their unsaved text, the tree's folds. */
  carry(): CodeCarry;
  /** Given back after that reload: the tabs opened again, their unsaved text over them. */
  takeBack(kept: unknown): Promise<void>;
}

/** The active file and the caret in it (`CodeCard.caret`). */
export interface CodeCaret {
  path: string;
  line: number;
  col: number;
  selection: string | null;
  unsaved: boolean;
}

/** The Code card across a reload (`carry`): plain values, the paths as they are after any move under way. */
export interface CodeCarry {
  /** Each tab: its path, pinned, and -- with changes not saved -- its text and the mtime it was read at. */
  tabs: Array<{ path: string; pinned: boolean; text: string | null; mtime: number | null; save?: boolean }>;
  active: string | null;
  unfolded: string[];
  selected: string | null;
  made: string[];
  /** The status line's last words: a move's report outlives the reload it caused. */
  said?: string;
}

/** A carried record, checked: anything odd is none. */
function carried(kept: unknown): CodeCarry | null {
  const k = kept as Partial<CodeCarry> | null;
  if (!k || !Array.isArray(k.tabs) || !Array.isArray(k.unfolded) || !Array.isArray(k.made)) return null;
  const tabs = k.tabs.filter((t) => t && typeof t.path === 'string' && (t.text === null || typeof t.text === 'string'));
  return { tabs, active: typeof k.active === 'string' ? k.active : null, unfolded: k.unfolded.filter((x) => typeof x === 'string'), selected: typeof k.selected === 'string' ? k.selected : null, made: k.made.filter((x) => typeof x === 'string'), ...(typeof k.said === 'string' ? { said: k.said } : {}) };
}

export interface CodeCardOptions {
  hub: StudioHub;
  /** Where Monaco's widgets that overflow the card (suggest, hover) are put: the shell's root, over everything. */
  overlay: HTMLElement;
  /** The bridge's channel: the page's `import.meta.hot` by default. */
  channel?: TsChannel;
  /** A file under the assets shown chosen in the Assets panel (`EditorContext.revealAsset`): false where no tool lists files. */
  revealAsset?: (path: string) => boolean;
}

/** An open file's buffer: its model, the mtime it was read or saved at, the version it was saved at. */
interface Buffer {
  path: string;
  model: M.editor.ITextModel;
  mtime: number | null;
  /** The route said so: a package's file, never saved. */
  fixed: boolean;
  /** The model's alternative version id as last read or saved: dirty while it differs. */
  savedAt: number;
  saving: boolean;
  view: M.editor.ICodeEditorViewState | null;
  sub: M.IDisposable;
  /** A `publishDiagnostics` heard for it: the server pushes, no pull needed after an edit. */
  pushed: boolean;
  /** A change on disk heard while its save was on its way: decided again once the answer is in. */
  pending: FileEvent | null;
  /** Its breakpoints' dots, its last hit's mark: Monaco's decoration ids on its model. */
  dots: string[];
  hit: string[];
}

/** The status line's parts. */
interface Status {
  ts: HTMLElement;
  file: HTMLElement;
  caret: HTMLElement;
  said: HTMLElement;
}

/** The key of the row a new file's or folder's name is typed in: no path has a NUL. */
const NEW_ROW = '\u0000new';

/** The menu's entries' MCP declarations: Rename and Delete are the tools'; what makes a file is Write's; the rest the view. */
const MENU_MCP: Record<MenuAction, Mcp> = {
  newFile: NOT_FOR_CLAUDE.codeFiles,
  newFolder: NOT_FOR_CLAUDE.codeFiles,
  open: 'ui',
  rename: 'code_move',
  duplicate: NOT_FOR_CLAUDE.codeFiles,
  saveAs: NOT_FOR_CLAUDE.codeFiles,
  copyPath: 'ui',
  copyRelative: 'ui',
  revealFinder: 'ui',
  revealAssets: 'ui',
  delete: 'code_delete',
};

/** A 409's `FileClash`: the path in the way, or null for any other failure. */
function clashOf(err: unknown): string | null {
  return err instanceof ApiRefused && err.status === 409 && typeof (err.body as Partial<FileClash>).clash === 'string' ? (err.body as unknown as FileClash).clash : null;
}

export function createCodeCard({ hub, overlay, channel = import.meta.hot as TsChannel | undefined, revealAsset }: CodeCardOptions): CodeCard {
  const calls = hub.calls;
  const root = el('section', 'ed-studio-card ed-code');
  root.dataset.keysField = CODE_FIELD;

  // ---------------------------------------------------------------- the left pane: the tree
  const side = el('div', 'ed-code-side');
  const tools = el('div', 'ed-code-tools');
  const filter = textInput('', 'Filter files');
  filter.title = 'Only the files whose path has this in it, flat';
  const refresh = iconButton('ui', 'history', 'List the files again', () => void loadTree());
  const searchToggle = iconButton('ui', 'search', 'Search the files (the tree again on a second click)', () => setSearching(!searching));
  tools.append(filter, searchToggle, refresh);
  const treeList = el('div', 'ed-code-list ed-code-tree');
  const searchPane = createSearchPane(calls, (path, line, col) => void openFile(path, line, col));
  searchPane.el.hidden = true;
  side.append(tools, treeList, searchPane.el);
  let searching = false;
  function setSearching(on: boolean): void {
    searching = on;
    treeList.hidden = on;
    filter.hidden = on;
    searchPane.el.hidden = !on;
    searchToggle.classList.toggle('ed-active', on);
    if (on) searchPane.focus();
    else treeView.invalidate();
  }

  // ---------------------------------------------------------------- the main pane
  const main = el('div', 'ed-code-main');
  const tabBar = el('div', 'ed-code-tabs');
  tabBar.setAttribute('role', 'tablist');
  const ask = el('div', 'ed-code-bar');
  ask.hidden = true;
  const host = el('div', 'ed-code-editor');
  const empty = el('div', 'ed-code-empty ed-dim', 'Open a file from the tree.');
  host.append(empty);
  // The diff view: in the editor's place while it is up, a head with what each side is and Close.
  const diffHead = el('div', 'ed-code-diffhead');
  diffHead.hidden = true;
  const diffHost = el('div', 'ed-code-editor ed-code-diff');
  diffHost.hidden = true;
  const statusLine = el('div', 'ed-code-status');
  const status: Status = { ts: el('span', 'ed-code-ts'), file: el('span', 'ed-code-file'), caret: el('span', 'ed-code-caret'), said: el('span', 'ed-code-said') };
  statusLine.append(status.ts, status.file, status.caret, status.said);
  // The debugger: the app's, else the dev server's (attached when this tab runs under VS Code's F5) -- the Debugger
  // button shown disabled, saying what would make one, while neither can set a breakpoint.
  let fromServer: ServerDebug | null = null;
  const debug = shellDebug(() => (fromServer = serverDebug(calls.debug, hubPushes(hub))));
  /** Can breakpoints be set now: the app's always, the dev server's while it is attached. */
  const usable = (): boolean => debug !== null && (debug.available?.() ?? true);
  /**
   * What a breakpoint asked for with nothing to set it says (a browser the dev server's debugger is not attached to):
   * the status line's words, the Debugger button's title -- and what the project's launch configuration needs for F5,
   * the port the dev server looks on.
   */
  const needsApp = (): string => debug?.unavailable?.() ?? notAttachedWords(null);
  const DEBUGGER_TITLE = "The project's Debugger: the call stack, the locals and the steps when the game stops at a breakpoint";
  const debuggerButton = button(NOT_FOR_CLAUDE.debugger, 'Debugger', DEBUGGER_TITLE, () => {
    debug?.open().catch((err: unknown) => say(`No Debugger: ${shellWords(err)}`, true));
  }, 'ed-small ed-quiet ed-code-debugger');
  const drawUsable = (): void => {
    debuggerButton.disabled = !usable();
    debuggerButton.title = usable() ? DEBUGGER_TITLE : needsApp();
  };
  drawUsable();
  // The dev server's: attached (or let go) as a Chrome with a debugging port comes and goes -- the list read again.
  const offAvailable = debug?.onAvailable?.(() => {
    drawUsable();
    void debug.breakpoints().then((list) => setPoints(list), () => undefined);
  });
  statusLine.append(debuggerButton);
  main.append(tabBar, ask, diffHead, host, diffHost, statusLine);
  root.append(side, main);

  // Monaco's widgets that would be cut off by the card: in a layer over the editor of their own.
  const widgets = el('div', 'monaco-editor ed-code-widgets');

  const say = (text: string, bad = false): void => {
    status.said.textContent = text;
    status.said.title = text;
    status.said.classList.toggle('ed-bad', bad);
  };

  // ---------------------------------------------------------------- state
  let monaco: Monaco | null = null;
  let editor: M.editor.IStandaloneCodeEditor | null = null;
  let bridge: Bridge | null = channel ? createBridge(channel) : null;
  let tsState: TsStatus | null = null;
  /**
   * The server's state followed (`bridge.ts`' `followStatus`): every script buffer opened again when it is back up
   * after a crash or a stop.
   */
  let follower: StatusFollower | null = null;
  let started: Promise<void> | null = null;
  let disposed = false;
  let shown = false;
  let tabs: TabList = emptyTabs;
  const buffers = new Map<string, Buffer>();
  /**
   * Models made for a peek or a definition in a file no tab has: read-only, by path; dropped at the next peek's
   * (`ensureModels`) unless a tab took one over or an editor still shows one.
   */
  const shadows = new Map<string, M.editor.ITextModel>();
  /** Every model the card made, its path, by its uri's text as Monaco has it. */
  const pathByUri = new Map<string, string>();
  /** The server's diagnostics, by uri (Monaco's text of it). */
  const diagnostics = new Map<string, LspDiagnostic[]>();
  const disposables: M.IDisposable[] = [];
  const offs: (() => void)[] = [];

  /** A uri's text as Monaco has it: the one key every map here uses. */
  const key = (uri: string): string => (monaco ? monaco.Uri.parse(uri).toString() : uri);

  // ---------------------------------------------------------------- the TypeScript status
  function drawTs(): void {
    if (!bridge) {
      status.ts.textContent = 'TypeScript: no dev server';
      return;
    }
    const s = tsState;
    status.ts.textContent = !s ? 'TypeScript: …' : s.state === 'up' ? `TypeScript ${s.version ?? ''}`.trim() : s.state === 'failed' ? 'TypeScript failed' : `TypeScript ${s.state}`;
    status.ts.title = s?.why ?? (s ? `The project's TypeScript language server: ${s.state}${s.version ? ` (${s.version})` : ''}` : '');
    status.ts.classList.toggle('ed-bad', s?.state === 'failed');
  }
  async function askStatus(): Promise<void> {
    if (!bridge) return drawTs();
    let s: TsStatus;
    try {
      s = await bridge.status();
    } catch (err) {
      // The bridge not reached: whatever it held of this tab may be gone, so every file is opened again at the next
      // `up`.
      follower?.lost();
      tsState = { state: 'failed', root: tsState?.root ?? '', why: (err as BridgeError).message };
      return drawTs();
    }
    if (follower) follower.heard(s);
    else {
      tsState = s;
      drawTs();
    }
  }

  // ---------------------------------------------------------------- the tree
  let files: FileEntry[] = [];
  /** The project's folder, absolute (the tree's answer): Copy Path's. */
  let treeRoot = '';
  /** Folders New Folder made that hold no file yet: the tree is made from files, so these are handed in. */
  const madeFolders = new Set<string>();
  let tree: TreeFolder = buildTree([]);
  let unfolded = new Set<string>();
  let rows: TreeRow[] = [];
  /** The row chosen (a file's or a folder's path): F2 and Delete act on it, the menu was opened on it. */
  let selected: string | null = null;
  /** A name typed in the tree: a new file's or folder's (in `folder`), or a row's rename. */
  let editing: { kind: 'new'; folder: string; isFolder: boolean; field: HTMLFormElement } | { kind: 'rename'; path: string; isFolder: boolean; field: HTMLFormElement } | null = null;
  /** The folder a drag is over and may drop in (`''`: the root), lit; null: none. */
  let dropOn: string | null = null;
  /** The tabs a move's import edits went to (`vibe/applyEdits`): saved, or waiting with unsaved changes -- the move's report says which. */
  const editsGiven = new Map<string, 'saving' | 'saved' | 'failed' | 'waiting'>();
  /** Those tabs' saves under way: the move's report waits for them all to settle. */
  let editSaves: Promise<void>[] = [];
  /** A tab's save of a move's edits, its outcome kept for the report (a failure's 412 bar is the save's own). */
  const saveEdits = (path: string): Promise<void> => {
    editsGiven.set(path, 'saving');
    const done = save(path).then((ok) => void editsGiven.set(path, ok ? 'saved' : 'failed'), () => void editsGiven.set(path, 'failed'));
    editSaves.push(done);
    return done;
  };
  /** Clean tabs of moved files given edits before they followed the move: saved once they have (`moveBuffer`). */
  const saveAfterMove = new Set<string>();
  /** Moves asked of the server and not yet followed: a reload meanwhile (Vite's, for a module gone) carries the paths as they will be. */
  let pending: Array<[string, string]> = [];
  /** The folds a reload carried: the tree's first listing takes them in place of its defaults. */
  let foldsBack: Set<string> | null = null;
  const drawTree = (): void => {
    rows = visibleRows(tree, unfolded, editing?.kind === 'new' ? '' : filter.value);
    // A new name's row: first in its folder, under the folder's own row (the root's: at the top).
    const made = editing?.kind === 'new' ? editing : null;
    if (made) {
      const at = made.folder === '' ? -1 : rows.findIndex((r) => r.folder && r.path === made.folder);
      const depth = at < 0 ? 0 : rows[at]!.depth + 1;
      rows.splice(at + 1, 0, { path: NEW_ROW, name: '', depth, folder: made.isFolder, open: false });
    }
    placeField();
    treeList.classList.toggle('ed-code-drop-root', dropOn === '');
    treeView.invalidate();
  };
  /** The name field over its row: placed by the row's index, as the virtual list places rows. */
  function placeField(): void {
    if (!editing) return;
    const key = editing.kind === 'new' ? NEW_ROW : editing.path;
    const at = rows.findIndex((r) => r.path === key);
    if (at < 0) return;
    const field = editing.field;
    field.style.top = `${at * ROW}px`;
    field.style.paddingLeft = `calc(${rows[at]!.depth} * var(--code-indent) + var(--code-pad) + 14px)`;
    if (!field.isConnected) treeList.append(field);
  }
  const treeView: Mounted = mount({
    list: treeList,
    rowHeight: () => ROW,
    perRow: () => 1,
    count: () => rows.length,
    key: (i) => rows[i]!.path,
    make: () => {
      // Its click opens a file or folds a folder; dragged, it moves (or with Alt copies) what it names.
      const b = control('code_move', 'ed-code-row');
      b.draggable = true;
      b.addEventListener('click', () => {
        const row = rows[Number(b.dataset.at)];
        if (!row || row.path === NEW_ROW) return;
        select(row.path);
        if (row.folder) {
          if (unfolded.has(row.path)) unfolded.delete(row.path);
          else unfolded.add(row.path);
          drawTree();
        } else void openFile(row.path, undefined, undefined, false);
      });
      return b;
    },
    update: (b, i) => {
      const row = rows[i]!;
      b.dataset.at = String(i);
      b.style.paddingLeft = `calc(${row.depth} * var(--code-indent) + var(--code-pad))`;
      b.classList.toggle('ed-active', !row.folder && tabs.active === row.path);
      b.classList.toggle('ed-selected', row.path === selected);
      b.classList.toggle('ed-code-drop', dropOn !== null && dropOn !== '' && row.folder && row.path === dropOn);
      b.classList.toggle('ed-code-generated', row.file?.generated === true);
      b.classList.toggle('ed-code-folder', row.folder);
      b.classList.toggle('ed-code-untracked', row.file?.tracked === false && row.file.generated !== true);
      b.replaceChildren(el('span', 'ed-code-fold', row.folder ? (row.open ? '▾' : '▸') : ''), el('span', 'ed-code-name', row.name));
      b.title = row.path === NEW_ROW ? '' : row.folder ? row.path : `${row.path}${row.file?.generated ? ' (generated by vibe assets: read-only)' : row.file?.readOnly ? ' (read-only)' : ''}${row.file?.tracked === false && !row.file.generated ? ' (not tracked by git)' : ''}`;
      // The row under a name being typed is the field's: empty, so the field alone shows.
      if (row.path === NEW_ROW || (editing?.kind === 'rename' && editing.path === row.path)) b.replaceChildren(el('span', 'ed-code-fold', row.folder ? '▸' : ''));
    },
  });
  filter.addEventListener('input', drawTree);

  async function loadTree(): Promise<void> {
    try {
      const answer = await calls.tree();
      files = answer.files;
      treeRoot = answer.root ?? treeRoot;
      // A folder made empty and since given a file, or gone: the files say so now.
      for (const f of [...madeFolders]) if (files.some((x) => x.path.startsWith(`${f}/`))) madeFolders.delete(f);
      const first = tree.folders.length === 0;
      tree = buildTree(files, madeFolders);
      if (first) unfolded = foldsBack ?? defaultUnfolded(tree, tabs.tabs.map((t) => t.path));
      foldsBack = null;
      drawTree();
    } catch (err) {
      say(`The files were not listed: ${(err as Error).message}`, true);
    }
  }

  // ---------------------------------------------------------------- the tree's files: the menu, names, drags
  const menu = createMenu(overlay, overlay);
  const shell = appShell();

  /** The row chosen, drawn so. */
  function select(path: string | null): void {
    selected = path;
    treeView.invalidate();
  }

  /** A row by an element inside it (an event's target). */
  const rowAt = (target: EventTarget | null): TreeRow | undefined => {
    // A drag's target may be the text in a row: its element is the parent.
    const node = target as Node | null;
    const element = node?.nodeType === Node.TEXT_NODE ? node.parentElement : (node as Element | null);
    const b = element?.closest?.('.ed-code-row') as HTMLElement | null;
    return b && treeList.contains(b) ? rows[Number(b.dataset.at)] : undefined;
  };

  /** Is anything at the path, or under it: a name taken. */
  const taken = (path: string): boolean => madeFolders.has(path) || files.some((f) => f.path === path || f.path.startsWith(`${path}/`));

  /** A folder that holds a generated or read-only file: never renamed, moved or deleted whole. */
  const folderFixed = (path: string): boolean => files.some((f) => (f.generated === true || f.readOnly) && f.path.startsWith(`${path}/`));

  /** What the menu is for: the row's facts. */
  function targetOf(row: TreeRow | undefined): MenuTarget {
    if (!row || row.path === NEW_ROW) return { kind: 'root', path: '' };
    if (row.folder) return { kind: 'folder', path: row.path, readOnly: folderFixed(row.path) };
    const tab = find(tabs, row.path);
    return { kind: 'file', path: row.path, readOnly: row.file?.readOnly === true, generated: row.file?.generated === true, buffered: buffers.has(row.path) && tab !== undefined && !tab.readOnly };
  }

  /** The right-click menu for a row (or the empty space), at the pointer. */
  function openMenu(at: { x: number; y: number }, row: TreeRow | undefined): void {
    const target = targetOf(row);
    if (row && row.path !== NEW_ROW) select(row.path);
    const entries = menuEntries(target, { finder: shell !== null, assetsPanel: revealAsset !== undefined });
    const items: MenuItem[] = entries.map((e) => ({
      label: e.label,
      mcp: MENU_MCP[e.action],
      ...(e.key ? { key: keyLabel(e.key) } : {}),
      ...(e.rule ? { rule: true } : {}),
      ...(e.danger ? { danger: true } : {}),
      run: () => runAction(e.action, target),
    }));
    menu.show(at, items, { title: target.kind === 'root' ? 'The project' : target.path });
  }

  /** A menu entry done for its row. */
  function runAction(action: MenuAction, target: MenuTarget): void {
    const folder = target.kind === 'folder';
    const home = target.kind === 'folder' ? target.path : target.kind === 'file' ? parentOf(target.path) : '';
    switch (action) {
      case 'newFile':
        return startNew(home, false);
      case 'newFolder':
        return startNew(home, true);
      case 'open':
        return void openFile(target.path);
      case 'rename':
        return startRename(target.path, folder);
      case 'duplicate':
        return void duplicate(target.path, folder);
      case 'saveAs':
        return saveAs(target.path);
      case 'copyPath':
        return copyText(treeRoot ? `${treeRoot}/${target.path}` : target.path);
      case 'copyRelative':
        return copyText(target.path);
      case 'revealFinder':
        shell?.reveal(target.path).catch((err: unknown) => say(`Not revealed: ${shellWords(err)}`, true));
        return;
      case 'revealAssets':
        if (!revealAsset?.(target.path)) say('No tool here shows files.', true);
        return;
      case 'delete':
        return askDelete(target.path, folder);
    }
  }

  function copyText(text: string): void {
    void navigator.clipboard?.writeText(text).then(() => say(`Copied ${text}`), () => say('The clipboard was not written: the browser said no', true));
  }

  // -------------------------------------------------- a name typed in the tree

  /** The name field put away, the tree drawn without it. */
  function endEdit(): void {
    const was = editing;
    editing = null;
    was?.field.remove();
    drawTree();
  }

  /** A name field: `value` in it, its stem selected; Enter (or leaving it) commits, Esc leaves it. */
  function nameField(value: string, isFolder: boolean, commit: (name: string) => void): HTMLFormElement {
    const field = textEdit({ value, placeholder: isFolder ? 'Folder name' : 'File name', commit, cancel: endEdit });
    field.classList.add('ed-code-namefield');
    const input = field.querySelector('input')!;
    // After textEdit's own select-all: the name without its extension, as VS Code does.
    queueMicrotask(() => input.setSelectionRange(0, splitName(value, isFolder).stem.length));
    return field;
  }

  /** New File… or New Folder… in `folder`: a row there with the name to type. */
  function startNew(folder: string, isFolder: boolean, value = ''): void {
    menu.close();
    if (editing) endEdit();
    if (searching) setSearching(false);
    if (folder !== '') for (const f of [...foldersOf(`${folder}/x`)]) unfolded.add(f);
    const field = nameField(value, isFolder, (name) => void commitNew(folder, isFolder, name));
    editing = { kind: 'new', folder, isFolder, field };
    drawTree();
  }

  async function commitNew(folder: string, isFolder: boolean, name: string): Promise<void> {
    endEdit();
    if (name.trim() === '') return;
    const why = nameRefusal(name);
    if (why) {
      say(`Not made: ${why}`, true);
      return startNew(folder, isFolder, name);
    }
    const path = joinPath(folder, name);
    try {
      await calls.files.make(path, isFolder);
    } catch (err) {
      say(`${path} not made: ${(err as Error).message}`, true);
      return startNew(folder, isFolder, name);
    }
    if (isFolder) {
      madeFolders.add(path);
      unfolded.add(path);
    }
    await loadTree();
    select(path);
    say(`Made ${path}`);
    if (!isFolder) await openFile(path);
  }

  /** Rename… (F2): the row's name a field where it is. */
  function startRename(path: string, isFolder: boolean): void {
    menu.close();
    if (editing) endEdit();
    if (searching) setSearching(false);
    const field = nameField(baseOf(path), isFolder, (name) => {
      endEdit();
      if (name === baseOf(path) || name.trim() === '') return;
      const why = nameRefusal(name);
      if (why) return say(`Not renamed: ${why}`, true);
      void moveTo(path, joinPath(parentOf(path), name), isFolder);
    });
    editing = { kind: 'rename', path, isFolder, field };
    drawTree();
  }

  // -------------------------------------------------- moving, copying, deleting

  /** A tab open on `path`: with changes not saved, or not; null for none. */
  const tabAt = (path: string): 'open' | 'dirty' | null => {
    const b = buffers.get(path);
    return b ? (isDirty(b) ? 'dirty' : 'open') : null;
  };

  /** A name there already: Replace (a file's alone), Keep both (the moved one renamed `x copy`), or Cancel. */
  function askClash(at: string, isFolder: boolean, verb: 'move' | 'copy'): Promise<'replace' | 'keep' | 'cancel'> {
    return new Promise((answer) => {
      showDialog({
        title: `${baseOf(at)} is there already`,
        text: clashWords(at, isFolder, verb, baseOf(copyName(at, isFolder, taken)), tabAt(at)),
        buttons: [
          ...(isFolder ? [] : [{ label: 'Replace', kind: 'danger' as const, title: `${at} is lost, the other in its place`, run: () => answer('replace') }]),
          { label: 'Keep both', kind: 'accent', title: 'The new one named apart', run: () => answer('keep') },
        ],
        cancel: () => answer('cancel'),
      });
    });
  }

  /** `from` moved to `to` -- the server's move (imports, an asset's keys) -- a clash asked about; the tabs follow. */
  async function moveTo(from: string, to: string, isFolder: boolean): Promise<void> {
    let done: FilesMoved;
    let replacing = false;
    editsGiven.clear();
    saveAfterMove.clear();
    editSaves = [];
    const asking = (dest: string): Promise<FilesMoved> => {
      pending = [[from, dest]];
      say(`Moving ${from} → ${dest}…`);
      return calls.files.move(from, dest, dest === to && replacing);
    };
    /** The move in words: what moved, and what the server rewrote for it. */
    const report = (d: FilesMoved): void => {
      const changed = [...d.edited, ...d.rewritten];
      const moved = d.moved.map(([a, b]) => `${a} → ${b}`).join(', ');
      // The tabs given edits: saved where they were clean, waiting where they had unsaved changes (or the save failed).
      const of = (state: string): string[] => d.held.filter((p) => (editsGiven.get(p) ?? 'unheard') === state);
      // Saved once settled; until then (the first report, before the saves) a clean tab's is counted as saving. A path
      // no `vibe/applyEdits` reached here is its own: another page's tab, or one closed meanwhile.
      const held = editsWords([...of('saved'), ...of('saving')], of('waiting'), of('failed'), of('unheard'));
      say(`Moved ${moved}${changed.length > 0 ? ` -- ${d.via === 'assets' ? 'its key rewritten' : 'imports updated'} in ${changed.length} file${changed.length === 1 ? '' : 's'}: ${changed.join(', ')}` : ''}${held}${d.imports ? ` -- imports ${d.imports}` : ''}`, d.imports !== undefined);
    };
    try {
      try {
        done = await asking(to);
      } catch (err) {
        pending = [];
        const at = clashOf(err);
        if (at === null) return say(`${from} not moved: ${(err as Error).message}`, true);
        say(`${at} is there already`);
        const choice = await askClash(at, isFolder, 'move');
        if (choice === 'cancel') return say('');
        replacing = choice === 'replace';
        try {
          done = await asking(replacing ? to : copyName(to, isFolder, taken));
        } catch (again) {
          return say(`${from} not moved: ${(again as Error).message}`, true);
        }
      }
      // Said at once: a page reload the move brings (a module gone under src/game/) carries the words.
      report(done);
      // A file replaced: its tab closed first (the question said so) -- else the moved one's buffer would land on it.
      if (replacing && buffers.has(to)) closeNow(to);
      await followMoves(done.moved);
    } finally {
      pending = [];
    }
    await loadTree();
    if (done.moved[0]) select(done.moved[0][1]);
    // A notification that comes after the HTTP answer given a moment (a few frames' worth) to arrive, then the tabs'
    // saves of the move's edits settled: the line says which saved, which did not, and which were never heard of.
    // Only a tab open here is waited for (after the follow, at its new path): 300 ms at most.
    for (let n = 0; n < 10 && done.held.some((p) => !editsGiven.has(p) && buffers.has(p)); n++) await new Promise((r) => setTimeout(r, 30));
    await Promise.allSettled(editSaves);
    report(done);
    for (const p of done.held) {
      editsGiven.delete(p);
      saveAfterMove.delete(p);
    }
  }

  /** `from` copied to `to` (Alt-drag, Duplicate): a clash asked about. */
  async function copyTo(from: string, to: string, isFolder: boolean): Promise<void> {
    let copies: string[];
    try {
      copies = (await calls.files.copy(from, to)).copies;
    } catch (err) {
      const at = clashOf(err);
      if (at === null) return say(`${from} not copied: ${(err as Error).message}`, true);
      const choice = await askClash(at, isFolder, 'copy');
      if (choice === 'cancel') return;
      try {
        copies = (await calls.files.copy(from, choice === 'replace' ? to : copyName(to, isFolder, taken), choice === 'replace')).copies;
      } catch (again) {
        return say(`${from} not copied: ${(again as Error).message}`, true);
      }
      // The file replaced: its tab closed (the question said so), its buffer no longer the file's.
      if (choice === 'replace' && buffers.has(to)) closeNow(to);
    }
    await loadTree();
    if (copies[0]) select(copies[0]);
    say(`Copied ${from} to ${copies.join(', ')}`);
  }

  /** Duplicate: beside itself, `x copy.ts` (an asset's copy named by the Assets panel's way). */
  function duplicate(path: string, isFolder: boolean): Promise<void> {
    return copyTo(path, copyName(path, isFolder, taken), isFolder);
  }

  /** Save As…: the tab's text to a path typed, opened there in its place; the file it was left as on disk. */
  function saveAs(path: string): void {
    const b = buffers.get(path);
    if (!b) return;
    showDialog({
      title: `Save ${baseOf(path)} as`,
      text: `A new file with this tab's text, opened in its place. ${path} is left as it is on disk${isDirty(b) ? ': its unsaved changes go to the new file' : ''}.`,
      field: { value: copyName(path, false, taken), label: 'Path in the project' },
      buttons: [{ label: 'Save', kind: 'accent', takesName: true, run: (name) => saveAsTo(b, name.trim()) }],
    });
  }

  async function saveAsTo(b: Buffer, to: string): Promise<boolean> {
    const why = to.split('/').map(nameRefusal).find((w) => w !== null);
    if (why) {
      dialogNote(why);
      return false;
    }
    if (isAssetPath(to)) {
      dialogNote('Not among the assets: an asset\'s copy is the Assets panel\'s Duplicate (a uid of its own)');
      return false;
    }
    try {
      await calls.save(to, b.model.getValue(), null);
    } catch (err) {
      dialogNote(err instanceof ApiRefused && err.status === 412 ? `${to} is there already` : (err as Error).message);
      return false;
    }
    const from = b.path;
    closeNow(from);
    await loadTree();
    await openFile(to);
    say(`Saved as ${to}; ${from} left as it was on disk`);
    return true;
  }

  /** Delete…: asked in the editor's dialog, saying where it goes and what of it was not saved. */
  function askDelete(path: string, isFolder: boolean): void {
    menu.close();
    const entry = files.find((f) => f.path === path);
    if (entry?.generated) return say(`${path} is generated by vibe assets: it is not deleted`, true);
    if (entry?.readOnly || (isFolder && folderFixed(path))) return say(`${path} ${isFolder ? 'holds files that are read-only or generated' : 'is read-only here'}: not deleted`, true);
    const unsaved = [...buffers.values()].filter((x) => movedPath(x.path, path, path) !== null && isDirty(x)).map((x) => x.path);
    const asset = isAssetPath(path);
    const trash = !asset && shell?.trash !== undefined;
    const where = asset ? 'It goes to the project\'s .trash/, as the Assets panel deletes (refused while a data file names it).' : trash ? 'It goes to the Trash.' : 'It is deleted for good: a browser has no Trash to put it in.';
    showDialog({
      title: `Delete ${baseOf(path)}?`,
      text: `${path}${isFolder ? ' and everything in it' : ''}. ${where}${unsaved.length > 0 ? ` ${unsaved.join(', ')} ${unsaved.length === 1 ? 'has' : 'have'} changes not saved: they go with it.` : ''}`,
      buttons: [{ label: trash ? 'Move to Trash' : 'Delete', kind: 'danger', run: () => void deleteNow(path, trash) }],
    });
  }

  async function deleteNow(path: string, trash: boolean): Promise<void> {
    try {
      if (trash) {
        // The server's checks first (a generated file, a running turn's), then the app's Trash.
        await calls.files.remove([path], true);
        await shell!.trash!(path);
      } else await calls.files.remove([path]);
    } catch (err) {
      return say(`${path} not deleted: ${shellWords(err)}`, true);
    }
    for (const open of [...buffers.keys()]) if (movedPath(open, path, path) !== null) closeNow(open);
    for (const f of [...madeFolders]) if (movedPath(f, path, path) !== null) madeFolders.delete(f);
    if (selected !== null && movedPath(selected, path, path) !== null) selected = null;
    await loadTree();
    say(`Deleted ${path}${trash ? ' (to the Trash)' : isAssetPath(path) ? ' (to the project\'s .trash/)' : ''}`);
  }

  /** What moved, followed: the folders open and made, the selection, every tab and its buffer, the breakpoints. */
  async function followMoves(pairs: ReadonlyArray<readonly [string, string]>): Promise<void> {
    for (const [from, to] of pairs) {
      const follow = (set: Set<string>): void => {
        for (const p of [...set]) {
          const now = movedPath(p, from, to);
          if (now === null) continue;
          set.delete(p);
          set.add(now);
        }
      };
      follow(unfolded);
      follow(madeFolders);
      for (const folder of foldersOf(to)) unfolded.add(folder);
      if (selected !== null) selected = movedPath(selected, from, to) ?? selected;
      for (const path of [...buffers.keys()]) {
        const now = movedPath(path, from, to);
        if (now !== null) await moveBuffer(path, now);
      }
      if (debug && usable()) {
        for (const point of points.filter((p) => movedPath(p.file, from, to) !== null)) {
          const now = movedPath(point.file, from, to)!;
          // Off at the old path, on at the new: the shell keeps them by path.
          void debug.toggle(point.file, point.line).then(() => debug.toggle(now, point.line)).then(setPoints, () => undefined);
        }
      }
    }
  }

  /**
   * A tab's file moved: its buffer made again at the new path (a model's uri is fixed), read from the disk -- the
   * imports TypeScript rewrote in it -- and, when it had changes not saved, those put back over it with the mtime it
   * had: a save then meets whatever the move wrote as a conflict, never over it unseen.
   */
  async function moveBuffer(from: string, to: string): Promise<void> {
    const b = buffers.get(from);
    if (!b || !monaco) return;
    // Never two buffers on one path: one there already is let go (a Replace closes it first).
    if (buffers.has(to)) closeNow(to);
    const text = b.model.getValue();
    const shown = editor?.getModel() === b.model;
    const view = shown ? editor!.saveViewState() : b.view;
    tabs = renameTab(tabs, from, to);
    dropBuffer(from);
    let answer: Awaited<ReturnType<typeof calls.file>> | null = null;
    try {
      answer = await calls.file(to);
    } catch {
      // Not readable at its new place (gone again): its text as it was, written anew by a save.
    }
    // Its text as the tab has it -- unsaved changes, and import edits TypeScript sent it (`vibe/applyEdits`) -- over the
    // disk's, at the mtime it was read at: a save then meets a change since as a conflict.
    const differs = answer !== null && answer.text !== text;
    const nb = makeBuffer(to, answer?.text ?? text, differs || !answer ? b.mtime : answer.mtime, answer?.readOnly ?? b.fixed);
    if (nb.model.getValue() !== text) nb.model.setValue(text);
    nb.view = view;
    buffers.set(to, nb);
    drawDots(nb);
    tabs = update(tabs, to, { dirty: isDirty(nb), removed: false });
    await tellBridge(to, nb.model.getValue(), nb.fixed);
    // Clean before the move's edits came to it at its old path: saved now, at its new one.
    if (saveAfterMove.delete(to)) await saveEdits(to);
    if (shown) {
      editor!.setModel(nb.model);
      if (view) editor!.restoreViewState(view);
      showTab(to);
    } else drawTabs();
  }

  // -------------------------------------------------- the tree's own events: the menu, the drags

  treeList.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    if (editing) return;
    openMenu({ x: event.clientX, y: event.clientY }, rowAt(event.target));
  });

  /** The row dragged, while a drag of the tree's is on. */
  let dragging: { path: string; folder: boolean } | null = null;
  /** A closed folder rested on in a drag: opened after `OPEN_MS`. */
  let restOn: string | null = null;
  let restTimer: ReturnType<typeof setTimeout> | undefined;
  const OPEN_MS = 600;
  const setDropOn = (folder: string | null): void => {
    if (dropOn === folder) return;
    dropOn = folder;
    treeList.classList.toggle('ed-code-drop-root', folder === '');
    treeView.invalidate();
  };
  const endDrag = (): void => {
    dragging = null;
    clearTimeout(restTimer);
    restOn = null;
    setDropOn(null);
  };
  treeList.addEventListener('dragstart', (event) => {
    const row = rowAt(event.target);
    if (!row || row.path === NEW_ROW || editing || !event.dataTransfer) return void event.preventDefault();
    const fixed = row.folder ? (folderFixed(row.path) ? `${row.path} holds files that are generated or read-only: it is not moved` : null) : row.file?.generated ? `${row.path} is generated by vibe assets: it is not moved` : row.file?.readOnly ? `${row.path} is read-only here: it is not moved` : null;
    if (fixed) {
      event.preventDefault();
      return say(fixed, true);
    }
    dragging = { path: row.path, folder: row.folder };
    select(row.path);
    event.dataTransfer.setData('text/plain', row.path);
    event.dataTransfer.effectAllowed = 'copyMove';
  });
  /** A drag come over the tree, or moving in it: the folder under it lit, if it may drop there. */
  const over = (event: DragEvent): void => {
    if (!dragging || !event.dataTransfer) return;
    const row = rowAt(event.target);
    // On a file: its folder; on the empty space: the root.
    const folder = !row || row.path === NEW_ROW ? '' : row.folder ? row.path : parentOf(row.path);
    const copy = event.altKey;
    const refused = dropRefusal({ path: dragging.path, folder: dragging.folder }, folder, copy);
    if (refused !== null) {
      event.dataTransfer.dropEffect = 'none';
      setDropOn(null);
      return;
    }
    event.preventDefault();
    event.dataTransfer.dropEffect = copy ? 'copy' : 'move';
    setDropOn(folder);
    // A closed folder rested on opens, so a drag can go deeper.
    const closed = row?.folder && !row.open ? row.path : null;
    if (closed !== restOn) {
      clearTimeout(restTimer);
      restOn = closed;
      if (closed !== null) {
        restTimer = setTimeout(() => {
          if (restOn !== closed || !dragging) return;
          unfolded.add(closed);
          drawTree();
        }, OPEN_MS);
      }
    }
  };
  treeList.addEventListener('dragenter', over);
  treeList.addEventListener('dragover', over);
  // Out of the tree: by where the pointer is, not by `relatedTarget` (null for a row put away under it as it scrolls).
  treeList.addEventListener('dragleave', (event) => {
    const box = treeList.getBoundingClientRect();
    if (event.clientX <= box.left || event.clientX >= box.right || event.clientY <= box.top || event.clientY >= box.bottom) setDropOn(null);
  });
  treeList.addEventListener('drop', (event) => {
    if (!dragging) return;
    event.preventDefault();
    const what = dragging;
    const into = dropOn;
    const copy = event.altKey;
    endDrag();
    if (into === null) return;
    const to = dropTarget(what.path, into);
    void (copy ? copyTo(what.path, to, what.folder) : moveTo(what.path, to, what.folder));
  });
  treeList.addEventListener('dragend', endDrag);

  // ---------------------------------------------------------------- tabs
  const isDirty = (b: Buffer): boolean => b.model.getAlternativeVersionId() !== b.savedAt;

  function drawTabs(): void {
    tabBar.replaceChildren(
      ...tabs.tabs.map((tab) => {
        const t = el('div', 'ed-code-tab');
        t.setAttribute('role', 'tab');
        t.classList.toggle('ed-active', tab.path === tabs.active);
        t.classList.toggle('ed-code-pinned', tab.pinned);
        t.classList.toggle('ed-code-removed', tab.removed);
        const name = control('ui', 'ed-code-tab-name', tab.path.slice(tab.path.lastIndexOf('/') + 1));
        name.title = `${tab.path}${tab.readOnly ? ' (read-only)' : ''}${tab.removed ? ' (removed on disk: a save writes it anew)' : ''}\nDouble-click: ${tab.pinned ? 'unpin' : 'pin'} it`;
        name.addEventListener('click', () => showTab(tab.path));
        name.addEventListener('dblclick', () => {
          tabs = pin(tabs, tab.path, !tab.pinned);
          drawTabs();
        });
        const mark = el('span', 'ed-code-tab-mark', tab.dirty ? '●' : tab.pinned ? '⊙' : '');
        const close = iconButton('ui', 'close', tab.dirty ? 'Close: it has changes not saved' : 'Close', () => void closeAsked(tab.path), 'ed-icon-button ed-code-tab-close');
        t.append(name, mark, close);
        return t;
      }),
    );
    if (tabs.tabs.length > 1) {
      const others = button('ui', 'Close others', 'Close every tab but this one and the pinned', () => void closeOthersAsked(), 'ed-small ed-quiet ed-code-others');
      tabBar.append(others);
    }
    treeView.invalidate();
  }

  function setTab(path: string, change: Partial<Omit<Tab, 'path' | 'pinned'>>): void {
    tabs = update(tabs, path, change);
    drawTabs();
    drawFile();
  }

  /** The status line's file words: the path, read-only or who holds it. */
  function drawFile(): void {
    const tab = tabs.active ? find(tabs, tabs.active) : undefined;
    if (!tab) {
      status.file.textContent = '';
      status.caret.textContent = '';
      return;
    }
    const words = [tab.path];
    if (tab.owner === false) words.push(`held by ${tab.heldBy ?? 'another tab'}: read-only here`);
    else if (tab.readOnly) words.push('read-only');
    if (tab.removed) words.push('removed on disk');
    status.file.textContent = words.join(' · ');
  }

  function drawCaret(): void {
    const at = editor?.getPosition();
    status.caret.textContent = at && tabs.active ? `Ln ${at.lineNumber}, Col ${at.column}` : '';
  }

  /** `path`'s tab active, its model in the editor, its view state back. */
  function showTab(path: string): void {
    const b = buffers.get(path);
    if (!b || !editor) return;
    if (!diffHost.hidden) closeDiff();
    const was = tabs.active ? buffers.get(tabs.active) : undefined;
    if (was && was !== b) was.view = editor.saveViewState();
    tabs = activate(tabs, path);
    empty.hidden = true;
    if (editor.getModel() !== b.model) {
      editor.setModel(b.model);
      if (b.view) editor.restoreViewState(b.view);
    }
    const tab = find(tabs, path)!;
    editor.updateOptions({ readOnly: tab.readOnly, readOnlyMessage: { value: readOnlyWords(tab) } });
    drawTabs();
    drawFile();
    drawCaret();
  }

  const readOnlyWords = (tab: Tab): string =>
    tab.owner === false ? `Another tab (${tab.heldBy ?? 'not this one'}) holds this file: edit it there.` : 'A package\'s file: read here, never saved.';

  // ---------------------------------------------------------------- the ask bar (a dirty tab's close)
  function bar(text: string, choices: { label: string; title: string; run: () => void; extra?: string }[]): void {
    ask.replaceChildren(el('span', 'ed-code-bar-text', text), ...choices.map((c) => button('ui', c.label, c.title, () => {
      ask.hidden = true;
      c.run();
    }, `ed-small ${c.extra ?? ''}`)));
    ask.hidden = false;
  }

  async function closeAsked(path: string): Promise<void> {
    const b = buffers.get(path);
    if (b && isDirty(b)) {
      bar(`${path} has changes not saved.`, [
        { label: 'Save', title: 'Save it, then close it', run: () => void save(path).then((ok) => ok && closeNow(path)), extra: 'ed-accent' },
        { label: 'Don\'t save', title: 'Close it, its changes lost', run: () => closeNow(path), extra: 'ed-danger' },
        { label: 'Cancel', title: 'Keep it open', run: () => {} },
      ]);
      return;
    }
    closeNow(path);
  }

  async function closeOthersAsked(): Promise<void> {
    const keep = tabs.active;
    if (!keep) return;
    const lost = dirtyTabs(tabs).filter((t) => t.path !== keep && !t.pinned);
    const go = (): void => {
      const before = tabs.tabs.map((t) => t.path);
      tabs = closeOthers(tabs, keep);
      for (const path of before) if (!find(tabs, path)) dropBuffer(path);
      showTab(keep);
    };
    if (lost.length === 0) return go();
    bar(`${lost.length} of the others ${lost.length === 1 ? 'has' : 'have'} changes not saved.`, [
      { label: 'Don\'t save', title: 'Close them, their changes lost', run: go, extra: 'ed-danger' },
      { label: 'Cancel', title: 'Keep them open', run: () => {} },
    ]);
  }

  function dropBuffer(path: string): void {
    // A pull scheduled by its last edit would ask for a file the bridge no longer has open.
    clearTimeout(pulls.get(path));
    pulls.delete(path);
    const b = buffers.get(path);
    if (!b) return;
    buffers.delete(path);
    b.sub.dispose();
    bridge?.close(path);
    pathByUri.delete(b.model.uri.toString());
    diagnostics.delete(b.model.uri.toString());
    b.model.dispose();
  }

  function closeNow(path: string): void {
    tabs = closeTab(tabs, path);
    dropBuffer(path);
    if (tabs.active) showTab(tabs.active);
    else {
      editor?.setModel(null);
      empty.hidden = false;
      drawTabs();
      drawFile();
      drawCaret();
    }
  }

  // ---------------------------------------------------------------- opening a file
  /** The uri a path's model is made with: the bridge's when the root is known, so the server's uris find it. */
  const modelUri = (path: string): M.Uri => {
    const m = monaco!;
    return bridge?.root ? m.Uri.parse(bridge.uri(path)) : m.Uri.from({ scheme: 'file', path: `/${path}` });
  };

  /** The server's markers on a model, from its diagnostics. */
  function mark(uri: string, list: LspDiagnostic[]): void {
    if (!monaco) return;
    const k = key(uri);
    diagnostics.set(k, list);
    const model = monaco.editor.getModel(monaco.Uri.parse(uri));
    if (model) monaco.editor.setModelMarkers(model, 'ts', list.map((d) => toMarker(d, (u) => monaco!.Uri.parse(u))));
  }

  /** `textDocument/diagnostic`: the pull, for a file this tab reads but does not own (and once as any opens). */
  async function pull(path: string): Promise<void> {
    if (!bridge?.root || !isScript(path)) return;
    const uri = bridge.uri(path);
    try {
      const report = await bridge.request<LspDocumentDiagnosticReport | null>('textDocument/diagnostic', { textDocument: { uri } });
      if (report?.kind === 'full') mark(uri, report.items);
    } catch {
      // The server pushes instead, or is down: the status line says the latter.
    }
  }

  /** A buffer made for `path` from its answer, its edits sent to the bridge as they come. */
  function makeBuffer(path: string, text: string, mtime: number | null, fixed: boolean): Buffer {
    const m = monaco!;
    const uri = modelUri(path);
    let model = shadows.get(path) ?? m.editor.getModel(uri);
    shadows.delete(path);
    if (model) {
      if (model.getValue() !== text) model.setValue(text);
    } else model = m.editor.createModel(text, languageOf(path), uri);
    pathByUri.set(model.uri.toString(), path);
    const b: Buffer = { path, model, mtime, fixed, savedAt: model.getAlternativeVersionId(), saving: false, view: null, sub: { dispose() {} }, pushed: false, pending: null, dots: [], hit: [] };
    b.sub = model.onDidChangeContent((e) => {
      // Incremental: the bridge's handshake negotiates `textDocumentSync.change: 2` (Incremental) with the server,
      // so a keystroke sends its range, not the file. The text rides along for an edit made while a reopen waits.
      bridge?.change(path, model.getValue(), toContentChanges(e.changes));
      // The tab's mark follows the model: a reload or a save sets it too, so it is read, not remembered here.
      const dirty = isDirty(b);
      if (find(tabs, path)?.dirty !== dirty) setTab(path, { dirty });
      if (!b.pushed && bridge?.owns(path)) schedulePull(path);
    });
    return b;
  }

  /** An owned file the server has not pushed diagnostics for: pulled a moment after the edits stop. */
  const pulls = new Map<string, ReturnType<typeof setTimeout>>();
  function schedulePull(path: string): void {
    clearTimeout(pulls.get(path));
    pulls.set(path, setTimeout(() => {
      pulls.delete(path);
      void pull(path);
    }, 600));
  }

  async function openFile(path: string, line?: number, col?: number, focus = true): Promise<void> {
    await start();
    if (disposed || !editor || !monaco) return;
    if (!buffers.has(path)) {
      let answer;
      try {
        answer = await calls.file(path);
      } catch (err) {
        say(`${path} not opened: ${(err as Error).message}`, true);
        return;
      }
      if (buffers.has(path)) return openFile(path, line, col, focus);
      const b = makeBuffer(path, answer.text, answer.mtime, answer.readOnly);
      buffers.set(path, b);
      drawDots(b);
      tabs = openTab(tabs, newTab(path, { readOnly: answer.readOnly }));
      for (const folder of foldersOf(path)) unfolded.add(folder);
      await tellBridge(path, answer.text, answer.readOnly);
    }
    showTab(path);
    if (line !== undefined) {
      const at = { lineNumber: line, column: col ?? 1 };
      editor.setPosition(at);
      editor.revealPositionInCenterIfOutsideViewport(at);
    }
    // Opened from the tree: the focus stays there, so its keys (F2, Delete) go on working.
    if (focus) editor.focus();
  }

  /** A script's buffer told to the bridge: this tab its owner, or read-only while another holds it. */
  async function tellBridge(path: string, text: string, fixed: boolean): Promise<void> {
    if (!isScript(path) || !bridge) return;
    try {
      if (!bridge.root) await askStatus();
      const held = await bridge.open(path, text, languageOf(path));
      tabs = update(tabs, path, { owner: held.owner, heldBy: held.heldBy, readOnly: fixed || !held.owner });
      // No status asked again here: the bridge's `vibe/status` notification (the follower's) draws each change.
      void pull(path);
    } catch (err) {
      say(`TypeScript does not know ${path}: ${(err as Error).message}`, true);
    }
  }

  /** The script buffers, for the follower to open again when a restarted server knows none of them. */
  function* scriptDocuments(): Iterable<OpenDocument> {
    for (const b of buffers.values()) if (isScript(b.path)) yield { path: b.path, text: b.model.getValue(), languageId: languageOf(b.path) };
  }

  /** A buffer opened again on a restarted server: its tab's owner and read-only words as the answer says. */
  function reopened(path: string, answer: TsOpenAnswer | Error): void {
    const b = buffers.get(path);
    if (!b) return;
    if (answer instanceof Error) return say(`TypeScript does not know ${path}: ${answer.message}`, true);
    tabs = update(tabs, path, { owner: answer.owner, heldBy: answer.heldBy, readOnly: b.fixed || !answer.owner });
    // Only what the answer changes: not `showTab`, which would close a diff view that is up.
    const tab = find(tabs, path)!;
    if (editor?.getModel() === b.model) editor.updateOptions({ readOnly: tab.readOnly, readOnlyMessage: { value: readOnlyWords(tab) } });
    drawTabs();
    drawFile();
    void pull(path);
  }

  /** The models made for an earlier peek that no tab took over, this one does not show and no editor shows: gone. */
  function dropShadows(keep: ReadonlySet<string>): void {
    for (const [path, model] of shadows) {
      const k = model.uri.toString();
      // A definition asked from inside a references peek's embedded editor comes here again while that peek still
      // shows its model: `getEditors()` lists the embedded editors too, so one shown anywhere is kept.
      if (keep.has(k) || monaco!.editor.getEditors().some((e) => e.getModel() === model)) continue;
      shadows.delete(path);
      pathByUri.delete(k);
      diagnostics.delete(k);
      model.dispose();
    }
  }

  /** Models for places a peek shows in files no tab has: read from the routes. The uris it could not, answered. */
  async function ensureModels(uris: readonly string[]): Promise<string[]> {
    const m = monaco!;
    const out: string[] = [];
    dropShadows(new Set(uris.map(key)));
    await Promise.all(
      uris.map(async (uri) => {
        if (m.editor.getModel(m.Uri.parse(uri))) return;
        const where = bridge!.place(uri);
        if ('outside' in where) return void out.push(uri);
        try {
          const answer = await calls.file(where.path);
          if (m.editor.getModel(m.Uri.parse(uri))) return;
          const model = m.editor.createModel(answer.text, languageOf(where.path), m.Uri.parse(uri));
          shadows.set(where.path, model);
          pathByUri.set(model.uri.toString(), where.path);
        } catch {
          out.push(uri);
        }
      }),
    );
    return out;
  }

  /** Text edits to files no tab has open: each read, edited and saved with the mtime it was read at. */
  async function writeEdits(byUri: ReadonlyMap<string, readonly LspTextEdit[]>): Promise<string> {
    const done: string[] = [];
    const failed: string[] = [];
    for (const [uri, edits] of byUri) {
      const where = bridge!.place(uri);
      if ('outside' in where || where.readOnly) {
        failed.push(`${'outside' in where ? where.outside : where.path} (not the project's to write)`);
        continue;
      }
      try {
        const answer = await calls.file(where.path);
        const text = applyTextEdits(answer.text, edits);
        await calls.save(where.path, text, answer.mtime);
        shadows.get(where.path)?.setValue(text);
        done.push(where.path);
      } catch (err) {
        failed.push(`${where.path} (${(err as Error).message})`);
      }
    }
    return [done.length > 0 ? `written: ${done.join(', ')}` : '', failed.length > 0 ? `not written: ${failed.join(', ')}` : ''].filter(Boolean).join('; ');
  }

  // ---------------------------------------------------------------- saving
  /** `path` (the active tab's by default) saved: true once it is on disk. */
  async function save(path = tabs.active ?? ''): Promise<boolean> {
    const b = buffers.get(path);
    const tab = find(tabs, path);
    if (!b || !tab) return false;
    if (tab.readOnly) {
      say(`${path} is read-only here: not saved`, true);
      return false;
    }
    if (b.saving) return false;
    b.saving = true;
    const text = b.model.getValue();
    const at = b.model.getAlternativeVersionId();
    try {
      const { mtime } = await calls.save(path, text, tab.removed ? null : b.mtime);
      b.mtime = mtime;
      b.savedAt = at;
      setTab(path, { dirty: isDirty(b), removed: false });
      say(`Saved ${path}`);
      if (bridge && !bridge.owns(path)) void pull(path);
      return true;
    } catch (err) {
      saveFailed(b, err as Error);
      return false;
    } finally {
      b.saving = false;
      // A change on disk heard meanwhile: decided now that the mtime is known.
      const pending = b.pending;
      b.pending = null;
      if (pending) act(b, pending);
    }
  }

  function saveFailed(b: Buffer, err: Error): void {
    if (err instanceof ApiRefused && err.status === 423) {
      const title = (err.body.conversation as { title?: string } | undefined)?.title ?? 'a conversation';
      return act(b, { kind: 'locked', title });
    }
    if (err instanceof ApiRefused && err.status === 412 && typeof err.body.text === 'string' && typeof err.body.mtime === 'number') {
      return act(b, { kind: 'conflict', text: err.body.text, mtime: err.body.mtime });
    }
    say(`${b.path} not saved: ${err.message}`, true);
  }

  // ---------------------------------------------------------------- the disk moving under a buffer
  /** What `decide` says, done. */
  function act(b: Buffer, event: FileEvent): void {
    const tab = find(tabs, b.path);
    const action = decide({ path: b.path, dirty: isDirty(b), mtime: b.mtime, saving: b.saving, removed: tab?.removed ?? false }, event);
    switch (action.do) {
      case 'nothing':
        return;
      case 'wait':
        b.pending = event;
        return;
      case 'reload':
        return void reload(b);
      case 'bar':
        return changedBar(b, action.onDisk, action.mtime);
      case 'removed':
        b.mtime = null;
        setTab(b.path, { removed: true });
        say(`${b.path} was removed on disk: a save writes it anew`, true);
        return;
      case 'say':
        say(action.text, true);
        return;
    }
  }

  /** A clean buffer read again: the text replaced as one edit (undo keeps it), the caret and the scroll put back. */
  async function reload(b: Buffer): Promise<void> {
    let answer;
    try {
      answer = await calls.file(b.path);
    } catch (err) {
      say(`${b.path} not read again: ${(err as Error).message}`, true);
      return;
    }
    if (buffers.get(b.path) !== b) return;
    const active = editor !== null && editor.getModel() === b.model;
    const view = active ? editor!.saveViewState() : null;
    if (b.model.getValue() !== answer.text) b.model.pushEditOperations([], [{ range: b.model.getFullModelRange(), text: answer.text }], () => null);
    if (view) editor!.restoreViewState(view);
    b.mtime = answer.mtime;
    b.savedAt = b.model.getAlternativeVersionId();
    setTab(b.path, { dirty: false, removed: false });
    say(`${b.path} changed on disk: read again`);
  }

  /** The bar over a dirty buffer whose file changed: Reload (mine lost), Keep mine (saved over it), Diff. */
  function changedBar(b: Buffer, onDisk: string | null, mtime: number | null): void {
    if (tabs.active !== b.path) showTab(b.path);
    bar(`${b.path} changed on disk.`, [
      {
        label: 'Reload',
        title: 'Read it again: the changes here are lost (undo brings them back)',
        run: () => {
          closeDiff();
          void reload(b);
        },
        extra: 'ed-danger',
      },
      {
        label: 'Keep mine',
        title: 'Save what is here over the file on disk',
        run: () => {
          closeDiff();
          b.mtime = mtime;
          void save(b.path);
        },
        extra: 'ed-accent',
      },
      {
        label: 'Diff',
        title: 'The file on disk against what is here, side by side',
        run: () => {
          void (async () => {
            const disk = onDisk ?? (await calls.file(b.path).then((a) => a.text, () => ''));
            showDiff({ path: b.path, at: 'disk', before: disk, after: b.model.getValue(), beforeLabel: 'on disk', afterLabel: 'mine, in its tab' });
            changedBar(b, disk, mtime);
          })();
        },
      },
    ]);
  }

  // ---------------------------------------------------------------- the diff view
  let diffEditor: M.editor.IStandaloneDiffEditor | null = null;
  let diffModels: M.editor.ITextModel[] = [];

  function showDiff(pair: DiffPair): void {
    const m = monaco;
    if (!m) return;
    // Side by side: Monaco's own breakpoint (900 px) would make it inline on a narrow window, so it is set low --
    // inline only where the two halves could not be read at all.
    diffEditor ??= m.editor.createDiffEditor(diffHost, {
      readOnly: true,
      originalEditable: false,
      automaticLayout: false,
      renderSideBySide: true,
      useInlineViewWhenSpaceIsLimited: true,
      renderSideBySideInlineBreakpoint: 400,
      minimap: { enabled: false },
      theme: THEME,
    });
    const before = m.editor.createModel(pair.before, languageOf(pair.path));
    const after = m.editor.createModel(pair.after, languageOf(pair.path));
    diffEditor.setModel({ original: before, modified: after });
    for (const old of diffModels) old.dispose();
    diffModels = [before, after];
    diffHead.replaceChildren(el('span', undefined, `${pair.path}: ${pair.beforeLabel} ⟷ ${pair.afterLabel}`), button('ui', 'Close', 'Back to the editor', closeDiff, 'ed-small'));
    diffHead.title = `${pair.path}\nLeft: ${pair.beforeLabel}\nRight: ${pair.afterLabel}`;
    diffHead.hidden = false;
    diffHost.hidden = false;
    host.hidden = true;
    layoutDiff();
  }

  /** The diff editor sized to its place: told the size, as it was made while hidden (it measures nothing then). */
  function layoutDiff(): void {
    if (diffEditor && !diffHost.hidden) diffEditor.layout({ width: diffHost.clientWidth, height: diffHost.clientHeight });
  }

  function closeDiff(): void {
    diffHead.hidden = true;
    diffHost.hidden = true;
    host.hidden = false;
    diffEditor?.setModel(null);
    for (const old of diffModels) old.dispose();
    diffModels = [];
    editor?.layout();
  }

  /** A 404 as none: a file a turn made has no before, one it removed no after. */
  const orNone = <T>(p: Promise<T>): Promise<T | null> => p.catch((err: Error) => (err instanceof ApiRefused && err.status === 404 ? null : Promise.reject(err)));

  async function openDiff(path: string, at: string): Promise<void> {
    await start();
    if (disposed || !monaco) return;
    try {
      const pair = await pairFor(path, at, {
        before: (p, a) => orNone(calls.file(p, a)),
        disk: (p) => orNone(calls.file(p)),
        buffer: (p) => buffers.get(p)?.model.getValue() ?? null,
      });
      showDiff(pair);
      say(`${path}: ${pair.beforeLabel} ⟷ ${pair.afterLabel}`);
    } catch (err) {
      say(`${path}: no diff (${(err as Error).message})`, true);
    }
  }

  // ---------------------------------------------------------------- breakpoints (the app's, or the dev server's)
  let points: Breakpoint[] = [];
  /** The last hit's mark's timer, and the buffer it is in (one mark at a time, whichever file). */
  let hitTimer: ReturnType<typeof setTimeout> | undefined;
  let hitBuffer: Buffer | null = null;

  /** The last hit's mark taken away, from whichever buffer has it. */
  function clearHit(): void {
    clearTimeout(hitTimer);
    const b = hitBuffer;
    hitBuffer = null;
    if (b && buffers.get(b.path) === b && !b.model.isDisposed()) b.hit = b.model.deltaDecorations(b.hit, []);
  }

  /** A buffer's dots drawn from the list: hollow where the game does not have it set. */
  function drawDots(b: Buffer): void {
    if (!monaco) return;
    const dots = dotsIn(points, b.path).filter((dot) => dot.line <= b.model.getLineCount());
    b.dots = b.model.deltaDecorations(
      b.dots,
      dots.map((dot) => ({
        range: new monaco!.Range(dot.line, 1, dot.line, 1),
        options: dot.set
          ? { glyphMarginClassName: 'ed-code-breakpoint', glyphMarginHoverMessage: { value: 'Breakpoint: a click takes it away' }, stickiness: 1 }
          : { glyphMarginClassName: 'ed-code-breakpoint unbound', glyphMarginHoverMessage: { value: 'Breakpoint not set: no code on this line yet. A click takes it away' }, stickiness: 1 },
      })),
    );
  }

  function setPoints(list: Breakpoint[]): void {
    points = list;
    for (const b of buffers.values()) drawDots(b);
  }

  /** A click in the gutter of `path` at `line`: the shell's toggle, the dot drawn at once and again from its answer. */
  function toggleAt(path: string, line: number): void {
    if (!debug || !usable()) return say(needsApp(), true);
    if (!isScript(path)) return say(`${path}: breakpoints go in a script`, true);
    setPoints(toggleBreakpoint(points, path, line));
    debug.toggle(path, line).then(setPoints, (err: unknown) => {
      say(`Breakpoint not set: ${shellWords(err)}`, true);
      void debug.breakpoints().then(setPoints, () => undefined);
    });
  }

  /** Where the game stopped, told once it runs on: the line marked for 3 s in its open file, else said. */
  function hitAt(at: Breakpoint): void {
    const b = buffers.get(at.file);
    say(`Stopped at ${at.file}:${at.line}`);
    if (!b || !monaco) return;
    clearHit();
    hitBuffer = b;
    b.hit = b.model.deltaDecorations(b.hit, [{ range: new monaco.Range(at.line, 1, at.line, 1), options: { isWholeLine: true, className: 'ed-code-hit', linesDecorationsClassName: 'ed-code-hit-edge' } }]);
    if (editor?.getModel() === b.model) editor.revealLineInCenterIfOutsideViewport(at.line);
    hitTimer = setTimeout(clearHit, 3000);
  }

  // ---------------------------------------------------------------- Monaco, once
  function start(): Promise<void> {
    return (started ??= (async () => {
      say('Loading the editor…');
      const loaded = await import('./code/monaco.ts');
      if (disposed) return;
      const m = (monaco = loaded.monaco);
      m.editor.defineTheme(THEME, themeFrom(readTokens(root)));
      m.editor.setTheme(THEME);
      const style = getComputedStyle(root);
      overlay.append(widgets);
      editor = m.editor.create(host, {
        model: null,
        theme: THEME,
        // A textarea for its input, not EditContext's div: MrDebug takes a textarea for typing (see the header).
        editContext: false,
        automaticLayout: false,
        fixedOverflowWidgets: true,
        overflowWidgetsDomNode: widgets,
        minimap: { enabled: false },
        fontFamily: style.getPropertyValue('--code-font').trim() || undefined,
        fontSize: Number.parseFloat(style.getPropertyValue('--code-size')) || undefined,
        lineHeight: Number.parseFloat(style.getPropertyValue('--code-line')) || undefined,
        tabSize: 2,
        scrollBeyondLastLine: false,
        renderLineHighlight: 'line',
        // The breakpoints' column (a click there toggles one).
        glyphMargin: true,
      });
      disposables.push(
        editor,
        editor.onDidChangeCursorPosition(drawCaret),
        editor.onMouseDown((e) => {
          if (e.target.type !== m.editor.MouseTargetType.GUTTER_GLYPH_MARGIN || !e.target.position) return;
          // A plain left click alone: a right click is the context menu's, a Ctrl/Cmd click Monaco's own.
          if (!e.event.leftButton || e.event.ctrlKey || e.event.metaKey) return;
          const path = pathByUri.get(editor!.getModel()?.uri.toString() ?? '');
          if (path !== undefined && buffers.has(path)) toggleAt(path, e.target.position.lineNumber);
        }),
        ...registerProviders(m, {
          bridge: bridge!,
          pathOf: (model) => pathByUri.get(model.uri.toString()) ?? null,
          isOpen: (uri) => {
            const path = pathByUri.get(key(uri));
            return path !== undefined && buffers.has(path);
          },
          ensureModels,
          writeEdits,
          diagnosticsOf: (uri) => diagnostics.get(key(uri)) ?? [],
          say,
        }),
        // A definition in another file: opened in a tab (read-only under node_modules); outside the project, said.
        m.editor.registerEditorOpener({
          openCodeEditor: (_source, resource, at) => {
            const uri = resource.toString();
            const known = pathByUri.get(uri);
            const where = known !== undefined ? { path: known, readOnly: false } : bridge?.place(uri);
            if (!where || 'outside' in where) {
              say(`${where && 'outside' in where ? where.outside : uri} is outside the project: not opened here`);
              return true;
            }
            const line = at && 'startLineNumber' in at ? at.startLineNumber : at?.lineNumber;
            const col = at && 'startColumn' in at ? at.startColumn : at?.column;
            void openFile(where.path, line, col);
            return true;
          },
        }),
      );
      const resized = new ResizeObserver(() => {
        editor?.layout();
        layoutDiff();
      });
      resized.observe(host);
      resized.observe(diffHost);
      offs.push(() => resized.disconnect());
      // A file of a tab changed or gone on disk: reloaded, barred or marked (`buffers.ts`' `decide`).
      offs.push(
        hub.onFile((m: FileChanged) => {
          const b = buffers.get(m.path);
          if (b) act(b, m.change === 'removed' ? { kind: 'removed' } : { kind: 'changed', mtime: m.mtime });
        }),
      );
      if (bridge) {
        // The bridge's own word at each change of state, and every script buffer opened again when it is back up
        // after a crash or a stop: the server has forgotten the files (it says `starting` between, so a flag decides).
        const f = (follower = followStatus(bridge, {
          status: (s) => {
            tsState = s;
            drawTs();
          },
          documents: scriptDocuments,
          reopened,
        }));
        offs.push(() => f.off());
        offs.push(
          bridge.on('textDocument/publishDiagnostics', (params) => {
            const p = params as LspPublishDiagnostics;
            const path = pathByUri.get(key(p.uri));
            const b = path !== undefined ? buffers.get(path) : undefined;
            if (b) b.pushed = true;
            mark(p.uri, p.diagnostics);
          }),
          bridge.on('window/showMessage', (params) => say(`TypeScript: ${(params as { message?: string }).message ?? ''}`)),
          // A move's import edits for a file this tab has open: never written under it by the server, but taken by its
          // model as one edit (undo takes it back), left unsaved -- the tab opened it at `was`, or follows it at `path`.
          // A tab that was clean saves them at once, as VS Code's files.refactoring.autoSave (`afterEdits`).
          bridge.on('vibe/applyEdits', (params) => {
            const p = params as ApplyEdits;
            const b = buffers.get(p.was) ?? buffers.get(p.path);
            if (!b || b.model.isDisposed()) return;
            const what = afterEdits(isDirty(b), b.path === p.path);
            b.model.pushEditOperations([], p.edits.map((e) => ({ range: toMonacoRange(e.range), text: e.newText })), () => null);
            if (what === 'hold') return void editsGiven.set(p.path, 'waiting');
            editsGiven.set(p.path, 'saving');
            if (what === 'saveAfterMove') saveAfterMove.add(p.path);
            else void saveEdits(p.path);
          }),
        );
      }
      if (debug) {
        offs.push(debug.onBreakpoints(setPoints), debug.onHit(hitAt));
        void debug.breakpoints().then(setPoints, (err: unknown) => say(`Breakpoints not read: ${shellWords(err)}`, true));
      }
      say('');
      await Promise.all([askStatus(), loadTree()]);
    })());
  }

  drawTs();

  return {
    el: root,
    openFile: async (path, line, col) => {
      closeDiff();
      await openFile(path, line, col);
    },
    openDiff,
    async save() {
      await save();
    },
    search: () => searchPane.run(),
    quickTarget() {
      const path = tabs.active;
      if (!shown || !editor || path === null || !buffers.has(path) || !diffHost.hidden) return null;
      const box = editor.getDomNode()?.getBoundingClientRect();
      if (!box || box.width === 0) return null;
      const at = editor.getPosition();
      const seen = at ? editor.getScrolledVisiblePosition(at) : null;
      // The caret line's top: the box opens over it, the line in sight.
      const anchor = seen ? { x: box.left + seen.left, y: box.top + seen.top } : { x: box.left + box.width / 2, y: box.top };
      return { target: { kind: 'file', path, line: at?.lineNumber ?? null }, anchor, room: { left: box.left, top: box.top, right: box.right, bottom: box.bottom } };
    },
    caret() {
      const path = tabs.active;
      const b = path === null ? undefined : buffers.get(path);
      if (!editor || path === null || !b || editor.getModel() !== b.model) return null;
      const at = editor.getPosition();
      const sel = editor.getSelection();
      const text = sel && !sel.isEmpty() ? b.model.getValueInRange(sel) : '';
      return { path, line: at?.lineNumber ?? 1, col: at?.column ?? 1, selection: text === '' ? null : text, unsaved: isDirty(b) };
    },
    carry() {
      const through = (path: string): string => pending.reduce((p, [from, to]) => movedPath(p, from, to) ?? p, path);
      return {
        tabs: tabs.tabs.map((t) => {
          const b = buffers.get(t.path);
          const dirty = b !== undefined && isDirty(b);
          const now = through(t.path);
          // A clean tab given a move's edits before it followed the move: saved once it is back (`takeBack`).
          return { path: now, pinned: t.pinned, text: dirty ? b.model.getValue() : null, mtime: dirty ? b.mtime : null, ...(saveAfterMove.has(now) ? { save: true } : {}) };
        }),
        active: tabs.active === null ? null : through(tabs.active),
        unfolded: [...unfolded].map(through),
        selected: selected === null ? null : through(selected),
        made: [...madeFolders].map(through),
        said: status.said.textContent ?? '',
      };
    },
    async takeBack(kept) {
      const back = carried(kept);
      if (!back) return;
      foldsBack = new Set(back.unfolded);
      for (const f of back.made) madeFolders.add(f);
      selected = back.selected;
      for (const t of back.tabs) {
        await openFile(t.path, undefined, undefined, false);
        const b = buffers.get(t.path);
        if (!b) continue;
        // Its unsaved text over what is on disk, at the mtime it was read at: a save meets a change since as a conflict.
        if (t.text !== null && t.text !== b.model.getValue()) {
          b.model.setValue(t.text);
          b.mtime = t.mtime;
        }
        if (t.pinned) tabs = pin(tabs, t.path, true);
        if (t.save === true) void save(t.path);
      }
      if (back.active !== null && buffers.has(back.active)) showTab(back.active);
      else drawTabs();
      if (foldsBack) {
        unfolded = foldsBack;
        foldsBack = null;
        drawTree();
      }
      if (back.said) say(back.said);
    },
    renameSelected() {
      if (selected === null) return;
      const entry = files.find((f) => f.path === selected);
      const isFolder = entry === undefined;
      if (entry?.generated || entry?.readOnly || (isFolder && folderFixed(selected))) return say(`${selected} is ${entry?.generated ? 'generated by vibe assets' : 'read-only here'}: not renamed`, true);
      startRename(selected, isFolder);
    },
    deleteSelected() {
      if (selected !== null) askDelete(selected, !files.some((f) => f.path === selected));
    },
    treeFocused: () => shown && !searching && editing === null && treeList.contains(document.activeElement),
    menu,
    holdsEscape: () => menu.open,
    cancel: () => menu.close(),
    toggleAtCaret() {
      const at = editor?.getPosition();
      const path = tabs.active;
      if (!diffHost.hidden) return say('Close the diff: a breakpoint goes on a file\'s line', true);
      if (!at || path === null || !buffers.has(path)) return say('No line to set a breakpoint on: a file open, the caret on a line', true);
      toggleAt(path, at.lineNumber);
    },
    show() {
      shown = true;
      void start().then(() => {
        if (shown) editor?.layout();
      }, (err: Error) => say(`The editor did not load: ${err.message}`, true));
    },
    hide() {
      shown = false;
      menu.close();
    },
    dispose() {
      disposed = true;
      menu.dispose();
      editing?.field.remove();
      clearTimeout(restTimer);
      clearHit();
      for (const t of pulls.values()) clearTimeout(t);
      for (const off of offs) off();
      offAvailable?.();
      fromServer?.dispose();
      for (const path of [...buffers.keys()]) dropBuffer(path);
      for (const model of shadows.values()) model.dispose();
      shadows.clear();
      closeDiff();
      diffEditor?.dispose();
      for (const d of disposables) d.dispose();
      searchPane.dispose();
      bridge?.dispose();
      bridge = null;
      treeView.dispose();
      widgets.remove();
      root.remove();
    },
  };
}

