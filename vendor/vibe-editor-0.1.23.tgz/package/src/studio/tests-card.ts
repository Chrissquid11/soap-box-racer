/**
 * The Studio tab's Tests card: `vibe test` run from a button, its output read into a row per test file as it
 * streams in (`test-output.ts`' `parseTestOutput`).
 *
 * - **Run all**: `POST /__studio/run { script: 'test' }`. **Stop** while it runs (`POST cancel`).
 * - **The rows**: a file's suite title and its count, green or red; a failing file's lines (its `FAIL`s and what
 *   it got) open under it, a click on the row folding them. The checks after the files are the last row. A
 *   failing file's row has **Run one** -- `POST run { script: 'test', args: [<path>] }` -- as the runner names a
 *   file's path only when it fails (`FAILED <path>`).
 * - **The line under the buttons**: a spinner while the task runs (the top bar's too, `StudioState.running`,
 *   which the hub sets), then the files' count and the exit code.
 *
 * What it reads: `task:test`'s lines in the hub's log -- the stream's backlog fetched as the card is made, then
 * the pushes -- from its last `$ npm run test` line on, so a run started elsewhere (another tab) shows too.
 */
import type { LogLine } from '@vibe/pipeline/studio-types';
import { button, control, el } from '../shell.ts';
import { stripAnsi } from './console-lines.ts';
import type { StudioCard, StudioHub } from './hub.ts';
import { fileWords, parseTestOutput, type TestRun } from './test-output.ts';

/** The task's stream. */
const STREAM = 'task:test';

/** The lines of the last run in the stream: from its last `$ npm run test` line on. */
function lastRun(lines: readonly LogLine[]): string[] {
  let from = -1;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i]!.text.startsWith('$ npm run test')) {
      from = i;
      break;
    }
  }
  return from < 0 ? [] : lines.slice(from).map((l) => stripAnsi(l.text));
}

export function createTestsCard(hub: StudioHub): StudioCard {
  const root = el('section', 'ed-studio-card ed-studio-tests');
  const top = el('div', 'ed-buttons');
  const runAll = button('tests_run', 'Run all', 'Run every test file and the checks (vibe test)', () => void run(), 'ed-accent');
  const stop = button('job_cancel', 'Stop', 'Stop the tests running', () => void hub.calls.cancel().catch((err: Error) => say(err.message, true)), 'ed-small');
  top.append(runAll, stop);
  const line = el('div', 'ed-status');
  const spin = el('span', 'ed-studio-spin', '⟳');
  const words = el('span');
  line.append(spin, words);
  const list = el('div', 'ed-studio-list');
  root.append(top, line, list);

  /** Files a click on their row turned from how they start -- a failing one's lines open, a passing one's shut -- by title. */
  const toggled = new Set<string>();
  /** A refusal's words, until the next run. */
  let refusal: string | null = null;
  let frame = 0;

  const say = (text: string, bad = false): void => {
    refusal = bad ? text : null;
    draw();
  };

  async function run(args?: readonly string[]): Promise<void> {
    refusal = null;
    const refused = await hub.run('test', args);
    if (refused) say(refused, true);
  }

  const testing = (): boolean => hub.running === 'test';

  function status(parsed: TestRun): string {
    if (refusal) return refusal;
    if (testing()) return parsed.files.length > 0 ? `Running… ${parsed.files.filter((f) => f.done).length} files so far` : 'Running…';
    const end = hub.last?.name === 'test' ? hub.last : null;
    const exit = end ? (end.signal ? `stopped by ${end.signal}` : `exited ${end.code}`) : parsed.exit !== null ? (/^\d+$/.test(parsed.exit) ? `exited ${parsed.exit}` : `stopped by ${parsed.exit}`) : null;
    if (parsed.total) return `${parsed.total.passed} of ${parsed.total.files} test files passed${exit ? ` -- ${exit}` : ''}`;
    if (exit) return exit;
    return 'Not run yet here: Run all.';
  }

  function draw(): void {
    const parsed = parseTestOutput(lastRun(hub.logs.lines(STREAM)));
    const busy = testing();
    runAll.disabled = hub.running !== null;
    runAll.title = hub.running && !busy ? `${hub.running} is running: one task at a time` : 'Run every test file and the checks (vibe test)';
    stop.hidden = !busy;
    spin.hidden = !busy;
    words.textContent = status(parsed);
    line.classList.toggle('ed-bad', refusal !== null || (!busy && parsed.total !== null && parsed.total.passed < parsed.total.files));

    const rows: HTMLElement[] = [];
    for (const file of parsed.files) {
      const bad = file.failed > 0 || (!file.done && !busy);
      const row = el('div', `ed-studio-test${bad ? ' ed-bad' : file.done ? ' ed-good' : ''}`);
      const name = control('ui', 'ed-studio-row', `${file.title}  ·  ${fileWords(file, busy)}`);
      name.title = file.path ?? file.title;
      const open = file.lines.length > 0 && bad !== toggled.has(file.title);
      name.addEventListener('click', () => {
        if (file.lines.length === 0) return;
        if (toggled.has(file.title)) toggled.delete(file.title);
        else toggled.add(file.title);
        draw();
      });
      row.append(name);
      if (file.path && bad) {
        const path = file.path;
        const one = button('tests_run', 'Run one', `Run ${path} alone`, () => void run([path]), 'ed-small');
        one.disabled = hub.running !== null;
        row.append(one);
      }
      rows.push(row);
      if (open) rows.push(el('div', 'ed-studio-out', file.lines.join('\n')));
    }
    if (parsed.checks) {
      const c = parsed.checks;
      const row = el('div', `ed-studio-test ${c.clean ? 'ed-good' : c.findings > 0 ? 'ed-bad' : ''}`);
      row.append(el('div', 'ed-studio-row', c.clean ? 'checks  ·  clean' : `checks  ·  ${c.findings} ${c.findings === 1 ? 'finding' : 'findings'}`));
      rows.push(row);
      if (c.lines.length > 0) rows.push(el('div', 'ed-studio-out', c.lines.join('\n')));
    }
    list.replaceChildren(...rows);
  }

  /** Drawn once a frame at most, as lines stream in. */
  const later = (): void => {
    if (frame !== 0) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      if (!root.hidden) draw();
    });
  };
  const offs = [hub.logs.on((stream) => stream === STREAM && later()), hub.on('task', later)];
  void hub.logs.load(STREAM);
  draw();

  return {
    el: root,
    show: draw,
    hide() {},
    dispose() {
      cancelAnimationFrame(frame);
      for (const off of offs) off();
      root.remove();
    },
  };
}
