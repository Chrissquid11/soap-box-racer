/**
 * The Tests card's parser, `vibe test`'s output as rows: the pipeline's (`@vibe/pipeline/test-output`), which the
 * studio's `tests_run` tool reads a run with too (Docs/mcp.md M5) -- one parser, the card's and the tool's.
 */
export { fileWords, parseTestOutput, type TestFile, type TestRun } from '@vibe/pipeline/test-output';
