/**
 * What the Studio tab shows in the top bar's middle (`EditorContext.control`):
 * the problems count and the running task's spinner, driven by one small
 * `StudioState` the tool owns -- its setters what the cards call (the
 * Problems card the count, the Tests and Build cards the task). Built with
 * `dom.ts`' parts, so node imports it (`state.test.ts`, over a stand-in page).
 *
 * - **The pill**: `N problems` (`1 problem`), red (`ed-bad`) while there are
 *   any, hidden at none; a click is the tool's (`onProblems`: the Problems card shown).
 * - **The spinner**: `⟳ build…` while a task runs, its glyph turning; hidden while none does.
 */
import { control, el, tip } from '../dom.ts';

export interface StudioState {
  /** Problems found just now: TypeScript's errors over the project. */
  readonly problems: number;
  /** The task running -- `build`, `test` -- or null for none. */
  readonly running: string | null;
  setProblems(count: number): void;
  setRunning(task: string | null): void;
}

export interface StudioBar {
  readonly state: StudioState;
  /** The problems count, for the bar's middle. */
  readonly pill: HTMLButtonElement;
  /** The running task, for the bar's middle. */
  readonly spinner: HTMLElement;
}

/** The pill's words: `1 problem`, `3 problems`. */
export const problemsText = (count: number): string => `${count} ${count === 1 ? 'problem' : 'problems'}`;

export function createStudioBar(onProblems: () => void): StudioBar {
  let problems = 0;
  let running: string | null = null;

  const pill = control('ui', 'ed-studio-pill');
  pill.addEventListener('click', () => onProblems());
  const spinner = el('span', 'ed-studio-running');
  const glyph = el('span', 'ed-studio-spin', '⟳');
  const task = el('span', 'ed-studio-task');
  spinner.append(glyph, task);

  const draw = (): void => {
    pill.hidden = problems === 0;
    pill.textContent = problemsText(problems);
    pill.classList.toggle('ed-bad', problems > 0);
    tip(pill, `${problemsText(problems)}: the Studio tab's Problems card`);
    spinner.hidden = running === null;
    task.textContent = running === null ? '' : `${running}…`;
    spinner.title = running === null ? '' : `Running: ${running}`;
  };
  draw();

  return {
    pill,
    spinner,
    state: {
      get problems() {
        return problems;
      },
      get running() {
        return running;
      },
      setProblems(count) {
        problems = Math.max(0, Math.floor(count));
        draw();
      },
      setRunning(next) {
        running = next;
        draw();
      },
    },
  };
}
