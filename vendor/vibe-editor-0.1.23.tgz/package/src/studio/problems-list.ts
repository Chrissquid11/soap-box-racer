/**
 * The Problems card's pure parts (`problems-card.ts`): tsc's problems -- and the modules the dev server cannot serve,
 * the program `vite` (Docs/studio.md §1, "Mid-session") -- grouped by file, sorted by file then line then column
 * (`groupByFile`), a row's words (`rowText`), what a click copies (`locationOf`), and the card's line over them
 * (`problemsSummary`): what each kind does to the game. No DOM: node tests them (`problems.test.ts`).
 */
import { VITE_PROGRAM, type Problem } from '@vibe/pipeline/studio-types';
import { problemsText } from './state.ts';

/**
 * The card's line: none; or the count and files, then what they do -- a module the dev server cannot serve stops its
 * swap (the game runs on the last good code until it is fixed), and type errors alone stop nothing (the game runs).
 */
export function problemsSummary(problems: readonly Problem[], files: number): string {
  if (problems.length === 0) return 'No problems: TypeScript finds nothing wrong, and the dev server serves every module.';
  const served = problems.filter((p) => p.program === VITE_PROGRAM).length;
  const head = `${problemsText(problems.length)} in ${files} ${files === 1 ? 'file' : 'files'}`;
  if (served === 0) return `${head} · type errors only: the game still runs, and each save still swaps in`;
  return `${head} · ${served} the dev server cannot serve: the game runs on the last good code until ${served === 1 ? 'it is' : 'they are'} fixed`;
}

/** One file's problems, in order by line and column. */
export interface ProblemGroup {
  file: string;
  problems: Problem[];
}

/** `problems` by file, the files in name order, each file's by line then column (then code, for a stable order). */
export function groupByFile(problems: readonly Problem[]): ProblemGroup[] {
  const byFile = new Map<string, Problem[]>();
  for (const p of problems) {
    const list = byFile.get(p.file);
    if (list) list.push(p);
    else byFile.set(p.file, [p]);
  }
  return [...byFile.keys()]
    .sort((a, b) => (a < b ? -1 : a > b ? 1 : 0))
    .map((file) => ({
      file,
      problems: byFile.get(file)!.sort((a, b) => a.line - b.line || a.col - b.col || (a.code < b.code ? -1 : a.code > b.code ? 1 : 0)),
    }));
}

/** Where a problem is, as a click copies it: `src/game/x.ts:12`. */
export const locationOf = (p: Problem): string => `${p.file}:${p.line}`;

/** A problem's row: `src/game/x.ts:12  Type 'string' is not assignable…` -- the message's first line (tsc's own goes on indented). */
export const rowText = (p: Problem): string => `${locationOf(p)}  ${p.message.split('\n')[0]}`;

/** A row's hover text: the whole message, its code, its column and its program. */
export const rowTitle = (p: Problem): string => `${p.file}(${p.line},${p.col}) ${p.code} [${p.program}]\n${p.message}`;
