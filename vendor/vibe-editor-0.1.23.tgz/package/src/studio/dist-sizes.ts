/**
 * The Build card's sizes table, pure (`build-card.ts`): `GET /__studio/dist` as rows -- the folders and the ten
 * largest files, each sorted by bytes, the largest first, with a size a person reads (`humanBytes`: `1.2 MB`).
 * No DOM: node tests it (`build.test.ts`).
 */
import type { DistAnswer } from '@vibe/pipeline/studio-types';

/** A row of the table. `files` for a folder's, absent for a file's. */
export interface SizeRow {
  path: string;
  bytes: number;
  size: string;
  files?: number;
}

export interface SizeRows {
  folders: SizeRow[];
  largest: SizeRow[];
}

const UNITS = ['B', 'kB', 'MB', 'GB'] as const;

/** `n` bytes as a person reads them, by thousands as Vite's report does: `812 B`, `14.6 kB`, `1.2 MB`. */
export function humanBytes(n: number): string {
  let v = Math.max(0, n);
  let u = 0;
  while (v >= 1000 && u < UNITS.length - 1) {
    v /= 1000;
    u++;
  }
  return u === 0 ? `${Math.round(v)} B` : `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${UNITS[u]}`;
}

/** Bytes, the most first; a tie by path. */
const bySize = (a: { path: string; bytes: number }, b: { path: string; bytes: number }): number => b.bytes - a.bytes || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0);

/** The table's rows from what the server measured. */
export function sizeRows(dist: DistAnswer): SizeRows {
  return {
    folders: [...dist.folders].sort(bySize).map((f) => ({ path: f.path, bytes: f.bytes, size: humanBytes(f.bytes), files: f.files })),
    largest: [...dist.largest].sort(bySize).map((f) => ({ path: f.path, bytes: f.bytes, size: humanBytes(f.bytes) })),
  };
}
