/**
 * "Draft with Claude" (`git-card.ts`'s button): a commit message written by a turn in a conversation of the card's
 * own, which may change no file.
 *
 * - **The conversation** is titled "Git": the card's id for it while it is open, else the open one of that title
 *   (a page reloaded finds it again), else one made (`POST conversations/new`) and renamed "Git" before its first
 *   turn -- a renamed conversation keeps its title, which a first prompt would otherwise give it. It is listed in
 *   the Claude card as any other.
 * - **The turn** is `DRAFT_PROMPT`, the files and their diff (`GET git/diff` of the ticked paths, cut at 100 KB),
 *   sent with `deny: DRAFT_DENY` -- Edit, Write, MultiEdit, NotebookEdit, Bash and every studio tool that is no read
 *   (`mcp__studio__writers`, which the session reads as the catalogue's writers: `scene_set`, `scene_create` …,
 *   Claude's own settings, `claude_settings`) refused for the turn's length, by the host before any rule
 *   (`TurnRequest.deny`), and no review loop. The prompt asks for no trailer and no sign-off -- the person commits
 *   it -- and `cleanDraft` drops a trailing `Co-Authored-By:` or `🤖 Generated with` line anyway.
 * - **The answer** is the turn's last words: its entries read (`GET state?since=`) until its own `result` comes,
 *   then the last `text` entry that is not a subagent's, a fence round it taken off. A result that failed, or none
 *   in `DRAFT_MS`, is an error with the server's words; the card gone (`DraftOptions.stopped`) ends the reading.
 *
 * No DOM: the agent API is handed in (`createAgentApi`'s, a test's stand-in).
 */
import type { ConversationsAnswer, DenyWriters, Entry, StateAnswer, TurnAnswer, TurnRequest, Unavailable } from '@vibe/pipeline/agent-types';
import type { GitChange, GitDiff } from '@vibe/pipeline/studio-types';
import { KIND_LETTER } from './model.ts';

/** The conversation's title. */
export const GIT_TITLE = 'Git';

/** The tools the draft's turn may not use: it answers in words. */
export const DRAFT_DENY: readonly string[] = [
  'Edit',
  'Write',
  'MultiEdit',
  'NotebookEdit',
  'Bash',
  // The studio's writers, in one word the session reads as every tool of the catalogue that is no read (`@vibe/pipeline`'s
  // `mcp/catalog.ts`, `DENY_WRITERS`); its readers -- studio_state, scene_describe, prefab_info, the jobs -- stay.
  'mcp__studio__writers' satisfies DenyWriters,
];

/** How long a draft may take. */
export const DRAFT_MS = 180_000;

/** How often its entries are read while it runs. */
export const DRAFT_POLL_MS = 1000;

export const DRAFT_PROMPT =
  'Write the commit message for these changes (the staged list follows). Answer with the message alone: a subject line under 72 characters, a blank line, then a short body when it helps. No trailer, no sign-off, no Co-Authored-By line: the person commits it.';

/** The prompt: the ask, each file with its kind's letter, then the diff (said when cut). */
export function draftPrompt(files: readonly Pick<GitChange, 'path' | 'kind' | 'from'>[], diff: GitDiff): string {
  const list = files.map((f) => `- ${KIND_LETTER[f.kind]} ${f.path}${f.from !== undefined ? ` (from ${f.from})` : ''}`).join('\n');
  const cut = diff.truncated ? '\n\n(The diff is cut at 100 KB: the files above are all of the change.)' : '';
  return `${DRAFT_PROMPT}\n\n${list}\n\n\`\`\`diff\n${diff.diff.trimEnd()}\n\`\`\`${cut}`;
}

/** A trailer Claude Code's own prompt adds to a commit message: not the person's to sign. */
const TRAILER = /^\s*(co-authored-by:|🤖 generated with)/i;

/** The answer as a message: trimmed, a fence round the whole taken off, a trailing `Co-Authored-By:` or `🤖 Generated with` line dropped. */
export function cleanDraft(text: string): string {
  const t = text.trim();
  const fenced = /^```[\w-]*\n([\s\S]*?)\n```$/.exec(t);
  const lines = (fenced ? fenced[1]! : t).trim().split('\n');
  while (lines.length > 0 && (TRAILER.test(lines.at(-1)!) || lines.at(-1)!.trim() === '')) lines.pop();
  return lines.join('\n').trim();
}

/** The agent API's calls the draft makes (`AgentApi`'s, or a test's). */
export interface DraftApi {
  conversations(): Promise<ConversationsAnswer | Unavailable>;
  create(from: string | null): Promise<ConversationsAnswer>;
  rename(id: string, title: string): Promise<ConversationsAnswer>;
  of(id: string | null): { state(since?: number): Promise<StateAnswer | Unavailable>; turn(request: TurnRequest): Promise<TurnAnswer> };
}

export interface DraftOptions {
  /** The conversation the card used last; null for none yet. */
  conversation: string | null;
  /** A pause between reads: a test's at once. */
  wait?: (ms: number) => Promise<void>;
  /** The clock, for `DRAFT_MS`. */
  now?: () => number;
  timeoutMs?: number;
  /** True once nobody waits for the answer (the card disposed): the reading ends, an error said. */
  stopped?: () => boolean;
}

const unavailable = (answer: object): answer is Unavailable => 'available' in answer && (answer as Unavailable).available === false;

/**
 * A conversation of a card's own: its id still open, else the one titled `title`, else a new one so titled (renamed
 * before its first turn, so a first prompt does not name it). The Git card's, and studio mode's Recovery
 * (`recovery-fix.ts`).
 */
export async function titledConversation(api: Pick<DraftApi, 'conversations' | 'create' | 'rename'>, kept: string | null, title: string): Promise<string> {
  const list = await api.conversations();
  if (unavailable(list)) throw new Error(list.why);
  if (kept !== null && list.conversations.some((c) => c.id === kept)) return kept;
  const titled = list.conversations.find((c) => c.title === title);
  if (titled) return titled.id;
  const made = await api.create(null);
  const id = made.conversation;
  if (id === undefined) throw new Error('the dev server made no conversation');
  await api.rename(id, title);
  return id;
}

/** The card's conversation: its id still open, else the one titled "Git", else a new one so titled. */
export const gitConversation = (api: DraftApi, kept: string | null): Promise<string> => titledConversation(api, kept, GIT_TITLE);

/** The message drafted, and the conversation it was drafted in. */
export async function draftMessage(api: DraftApi, prompt: string, options: DraftOptions): Promise<{ text: string; conversation: string }> {
  const wait = options.wait ?? ((ms: number) => new Promise<void>((done) => setTimeout(done, ms)));
  const now = options.now ?? (() => Date.now());
  const conversation = await gitConversation(api, options.conversation);
  const c = api.of(conversation);
  const first = await c.state(0);
  if (unavailable(first)) throw new Error(first.why);
  let since = first.entries.reduce((n, e) => Math.max(n, e.seq), 0);
  const { uuid } = await c.turn({ prompt, deny: [...DRAFT_DENY] });
  const heard: Entry[] = [];
  const until = now() + (options.timeoutMs ?? DRAFT_MS);
  const stopped = options.stopped ?? (() => false);
  for (;;) {
    await wait(DRAFT_POLL_MS);
    if (stopped()) throw new Error('stopped: the Git card is gone');
    const answer = await c.state(since);
    if (unavailable(answer)) throw new Error(answer.why);
    for (const e of answer.entries) {
      heard.push(e);
      since = Math.max(since, e.seq);
    }
    const end = heard.find((e) => e.kind === 'result' && e.turn === uuid);
    if (end && end.kind === 'result') {
      if (!end.ok) throw new Error(end.why ?? `the turn ${end.how === 'stopped' ? 'was stopped' : 'failed'}`);
      const words = heard.filter((e): e is Extract<Entry, { kind: 'text' }> => e.kind === 'text' && !e.sub && e.seq < end.seq).at(-1);
      if (!words) throw new Error('the turn ended with no words');
      return { text: cleanDraft(words.text), conversation };
    }
    const failed = heard.find((e) => e.kind === 'error');
    if (failed && failed.kind === 'error' && answer.state.running === null) throw new Error(failed.text);
    if (now() > until) throw new Error(`no answer in ${Math.round((options.timeoutMs ?? DRAFT_MS) / 1000)} s: see the Git conversation in the Claude card`);
  }
}
