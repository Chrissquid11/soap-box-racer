/**
 * The Git card's pure parts (`git-card.ts` draws them; `model.test.ts` holds them):
 *
 * - **The rows** (`rowsFrom`): a row per change of `GET git/status`, each with its tick -- ticked goes in the
 *   commit, every row ticked as it first comes, an untracked file too -- kept across a refresh by its repository
 *   and path, a row gone from the status dropped with its tick.
 * - **The commit's paths** (`commitPlan`): the ticked rows, one commit a repository (the project's first), a
 *   rename's old path with its new one -- `git commit -- <new>` alone would leave the old name's removal behind.
 * - **The log's rows** (`logRows`): both repositories' commits merged newest first, a date as a person reads it,
 *   each file's lines as `+3` and `-1` (`bin` for a binary).
 * - **A new branch being named** (`keepNaming`): the "+ new branch…" field and its text, kept across every redraw of
 *   the head row -- a refresh, a Commit -- until its Cancel, its repository off the branch it began on (its branch
 *   made, or a checkout from anywhere), or its repository gone.
 * - **The ask bar** (`askStep`): a checkout, push or pull answered `{ ask }` shows its words with a confirm and a
 *   Cancel; confirmed, it runs (the bar resting) until it is done or fails; one answered with what it did never
 *   asks.
 *
 * No DOM, no fetch.
 */
import type { GitAsk, GitChange, GitLog, GitRan, GitRepo, GitRepoStatus, GitStatus } from '@vibe/pipeline/studio-types';

/** A change as the card lists it: the status's row and its tick. */
export interface GitRow extends GitChange {
  ticked: boolean;
}

/** A kind as one letter, the row's first column. */
export const KIND_LETTER: Record<GitChange['kind'], string> = {
  modified: 'M',
  added: 'A',
  deleted: 'D',
  renamed: 'R',
  untracked: 'U',
  conflict: '!',
};

/** A row's identity across refreshes. */
const keyOf = (row: { repo: GitRepo; path: string }): string => `${row.repo}\0${row.path}`;

/** The status's changes as rows, the ticks of `before` kept by path, a new row ticked, a vanished one dropped. */
export function rowsFrom(status: GitStatus, before: readonly GitRow[] = []): GitRow[] {
  const ticks = new Map(before.map((row) => [keyOf(row), row.ticked]));
  return status.changes.map((change) => ({ ...change, ticked: ticks.get(keyOf(change)) ?? true }));
}

/** One row's tick set. */
export function setTick(rows: readonly GitRow[], repo: GitRepo, path: string, ticked: boolean): GitRow[] {
  return rows.map((row) => (row.repo === repo && row.path === path ? { ...row, ticked } : row));
}

/** Every row ticked, or none. */
export const tickAll = (rows: readonly GitRow[], ticked: boolean): GitRow[] => rows.map((row) => ({ ...row, ticked }));

/** What the "all" box shows: every row ticked, none, or some. */
export function allState(rows: readonly GitRow[]): 'all' | 'none' | 'some' {
  const n = rows.filter((row) => row.ticked).length;
  return n === 0 ? 'none' : n === rows.length ? 'all' : 'some';
}

/** A commit to make: a repository and the paths it takes. */
export interface CommitGroup {
  repo: GitRepo;
  paths: string[];
}

/** The ticked rows' paths, a commit a repository (the project's first), a rename's old path beside its new one. */
export function commitPlan(rows: readonly GitRow[]): CommitGroup[] {
  const groups: CommitGroup[] = [];
  for (const repo of ['project', 'engine'] as const) {
    const paths: string[] = [];
    for (const row of rows) {
      if (!row.ticked || row.repo !== repo) continue;
      paths.push(row.path);
      if (row.from !== undefined) paths.push(row.from);
    }
    if (paths.length > 0) groups.push({ repo, paths: [...new Set(paths)] });
  }
  return groups;
}

/** The paths whose diff the draft is written from: every ticked row's, a rename's old one too. */
export const draftPaths = (rows: readonly GitRow[]): string[] => commitPlan(rows).flatMap((group) => group.paths);

/** A commit as the log lists it. */
export interface LogRow {
  repo: GitRepo;
  hash: string;
  short: string;
  subject: string;
  author: string;
  /** `2026-10-11 10:05`, as the commit's own clock had it. */
  when: string;
  files: { path: string; plus: string; minus: string }[];
}

/** An ISO date as a person reads it: the day and the minute, in the commit's own offset. */
export const whenOf = (iso: string): string => (/^\d{4}-\d\d-\d\dT\d\d:\d\d/.test(iso) ? `${iso.slice(0, 10)} ${iso.slice(11, 16)}` : iso);

/** Both repositories' commits, newest first (by their ISO dates, as instants), at most `max`. */
export function logRows(logs: readonly GitLog[], max = 20): LogRow[] {
  const rows = logs.flatMap((log) =>
    log.entries.map((e) => ({
      at: Date.parse(e.date),
      row: {
        repo: log.repo,
        hash: e.hash,
        short: e.short,
        subject: e.subject,
        author: e.author,
        when: whenOf(e.date),
        files: e.files.map((f) => ({ path: f.path, plus: f.added === null ? 'bin' : `+${f.added}`, minus: f.deleted === null ? '' : `-${f.deleted}` })),
      },
    })),
  );
  // Stable: one repository's own order kept where two dates are equal or unreadable.
  return rows
    .map((r, i) => ({ ...r, i }))
    .sort((a, b) => (Number.isNaN(a.at) || Number.isNaN(b.at) || a.at === b.at ? a.i - b.i : b.at - a.at))
    .slice(0, max)
    .map((r) => r.row);
}

/** What the ask bar is about: a checkout (a branch, made or not), a push or a pull, in a repository. */
export interface AskAction {
  what: 'checkout' | 'push' | 'pull';
  repo: GitRepo;
  branch?: string;
  create?: boolean;
}

/** The ask bar: nothing asked; an ask waiting for its confirm; a confirmed one running. */
export type AskBar = { state: 'idle' } | { state: 'asking'; action: AskAction; words: string } | { state: 'running'; action: AskAction };

export type AskEvent =
  /** A first call answered: its ask, or what it did (no ask). */
  | { type: 'answered'; action: AskAction; answer: GitAsk | GitRan }
  | { type: 'confirm' }
  | { type: 'cancel' }
  /** The confirmed call ended, done or refused. */
  | { type: 'ended' };

export const IDLE: AskBar = { state: 'idle' };

/** Is an answer an ask, waiting for `confirm: true`. */
export const isAsk = (answer: GitAsk | GitRan): answer is GitAsk => 'ask' in answer;

/** The bar's next state. A running call is never cancelled from the bar: git is under way. */
export function askStep(bar: AskBar, event: AskEvent): AskBar {
  switch (event.type) {
    case 'answered':
      if (bar.state === 'running') return bar;
      return isAsk(event.answer) ? { state: 'asking', action: event.action, words: event.answer.ask } : IDLE;
    case 'confirm':
      return bar.state === 'asking' ? { state: 'running', action: bar.action } : bar;
    case 'cancel':
      return bar.state === 'asking' ? IDLE : bar;
    case 'ended':
      return bar.state === 'running' ? IDLE : bar;
  }
}

/** The confirm button's word for an action. */
export const confirmWord = (action: AskAction): string => (action.what === 'push' ? 'Push' : action.what === 'pull' ? 'Pull' : action.create ? 'Create' : 'Switch');

/** The ask bar's words while the confirmed call runs: "Pushing…", "Creating…". */
export const runningWord = (action: AskAction): string => (action.what === 'push' ? 'Pushing…' : action.what === 'pull' ? 'Pulling…' : action.create ? 'Creating…' : 'Switching…');

/** The ask's words as the bar shows them: a sentence, its first letter up. */
export const askSentence = (words: string): string => words.charAt(0).toUpperCase() + words.slice(1);

/** A new branch being named in a repository's head row: the repository, the branch it began on, the text typed so far. */
export interface Naming {
  repo: GitRepo;
  /** The repository's branch as the naming began (`null` on a detached HEAD). */
  from: string | null;
  text: string;
}

/**
 * The naming kept after a status read: none once its repository is gone or on another branch than it began on (the
 * branch made by Create, or a checkout from anywhere) -- never by the text, so a name typed through the current
 * branch's own is kept.
 */
export function keepNaming(naming: Naming | null, repos: readonly Pick<GitRepoStatus, 'repo' | 'branch'>[]): Naming | null {
  if (naming === null) return null;
  const repo = repos.find((r) => r.repo === naming.repo);
  if (repo === undefined) return null;
  return repo.branch === naming.from ? naming : null;
}
