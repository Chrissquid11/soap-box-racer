/**
 * Studio mode mid-session (Docs/studio.md §1, "Mid-session"): the dev server's **evaluation probe** made in this tab --
 * before it lets a page reload go, the server asks whether the changed modules evaluate (the pipeline's
 * `studio/probe.ts`), so a `throw` at the top of `src/main.ts` holds the reload instead of reloading studio mode into a
 * page that cannot boot.
 *
 * - **Asked** (`studio:probe { id, url }`): acked at once (`POST probe { id, ack: true }`) -- the server, hearing no
 *   ack, takes it that no studio tab is there and lets the reload go -- and the probe page made as a hidden frame of
 *   its own (`probeFrame`): a realm of its own, so the modules it imports fresh are evaluated as a first load would,
 *   never a second time in this page (a debug action registered twice, a second game booted). The probe page posts
 *   its results to the server itself.
 * - **Done** (`vibebase:probe-done` from the frame, `postMessage`): the frame goes; else after `PROBE_FRAME_MS`.
 *
 * No DOM but `probeFrame`'s, called only in the browser: a node test drives the rest with a stand-in frame.
 */
import { PROBE_DONE } from '@vibe/pipeline/studio-types';

/** A probe frame left longer than this goes whatever it did (the server stops waiting well before). */
export const PROBE_FRAME_MS = 20_000;

export interface ProbeFramesOptions {
  /** `POST probe { id, ack: true }`. */
  ack(id: string): Promise<unknown>;
  /** A hidden frame of the probe page at `url`; what removes it. */
  frame(url: string): () => void;
  later(run: () => void, ms: number): unknown;
  cancel(timer: unknown): void;
}

export interface ProbeFrames {
  /** `studio:probe` heard: acked, its frame made. */
  asked(message: { id: string; url: string }): void;
  /** The probe page said it is done (`PROBE_DONE`): its frame goes. */
  done(id: string): void;
  /** How many frames are up. */
  readonly open: number;
  /** Every frame gone (the editor closing). */
  dispose(): void;
}

export function createProbeFrames(options: ProbeFramesOptions): ProbeFrames {
  const frames = new Map<string, { remove(): void; timer: unknown }>();
  const done = (id: string): void => {
    const f = frames.get(id);
    if (!f) return;
    frames.delete(id);
    options.cancel(f.timer);
    f.remove();
  };
  return {
    asked({ id, url }) {
      if (frames.has(id)) return;
      options.ack(id).catch((err: Error) => console.warn(`[editor] the probe ${id} not acked: ${err.message}`));
      frames.set(id, { remove: options.frame(url), timer: options.later(() => done(id), PROBE_FRAME_MS) });
    },
    done,
    get open() {
      return frames.size;
    },
    dispose() {
      for (const id of [...frames.keys()]) done(id);
    },
  };
}

/** The probe page as a hidden frame of this page's document; what removes it. Browser only. */
export function probeFrame(url: string): () => void {
  const frame = document.createElement('iframe');
  frame.hidden = true;
  frame.setAttribute('aria-hidden', 'true');
  frame.tabIndex = -1;
  frame.src = url;
  document.body.append(frame);
  return () => frame.remove();
}

/** Is this `message` event the probe page's done, from this page's origin? Its id, or null. */
export function probeDoneId(event: { origin: string; data: unknown }, origin: string): string | null {
  if (event.origin !== origin || typeof event.data !== 'object' || event.data === null) return null;
  const { type, id } = event.data as { type?: unknown; id?: unknown };
  return type === PROBE_DONE && typeof id === 'string' ? id : null;
}
