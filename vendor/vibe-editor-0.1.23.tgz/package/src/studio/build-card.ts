/**
 * The Studio tab's Build card: the project built, measured, previewed -- what `npm run build` and `vite preview`
 * were in a terminal.
 *
 * - **Build** (`script: 'build'`, the release), **Build debug** (`build:debug`), **Export** (`export`: every
 *   stale or missing source exported -- not `export -- --check`: the run route takes `args` for `test` alone),
 *   **Stop** while one of them runs (`POST cancel`). One task at a time, the server's rule: the buttons rest
 *   while any runs.
 * - **The task's lines** under the buttons while it runs, and after: the Console's list (`log-view.ts`) on the
 *   task's stream.
 * - **The sizes** (`GET /__studio/dist` as the card is made, and `studio:dist` as a build ends 0): `dist/`'s
 *   folders with their bytes and files, and the ten largest files, each sorted by bytes (`sizeRows`).
 * - **Preview** (`POST /__studio/preview`): the url as a link the person clicks to open it in a new tab -- never
 *   opened from code. Stopped by the server as the next build starts (`studio:preview` null).
 * - **Reveal dist/**: in the Squidwright app, its shell's `window.squidwright.reveal('dist')` (`app-shell.ts`),
 *   its refusal's words shown; in a browser `POST /__studio/reveal`, which answers 501, and the button says
 *   "the app does this" and rests.
 *
 * The top bar's Build button is the tool's (`studio-tool.ts`): it runs the release build and shows this card;
 * so do the app's Game menu's commands, through `run`, `preview` and `reveal`.
 */
import { button, el } from '../shell.ts';
import { appShell, revealIn } from './app-shell.ts';
import { sizeRows } from './dist-sizes.ts';
import type { StudioCard, StudioHub } from './hub.ts';
import { createLogView } from './log-view.ts';

/** The scripts this card runs, in its buttons' order. */
export const BUILD_TASKS = ['build', 'build:debug', 'export'] as const;

export interface BuildCard extends StudioCard {
  /** `script` run (one of `BUILD_TASKS`), its lines shown here. */
  run(script: (typeof BUILD_TASKS)[number]): Promise<void>;
  /** What the Preview button does. */
  preview(): Promise<void>;
  /** What Reveal dist/ does. */
  reveal(): Promise<void>;
}

export function createBuildCard(hub: StudioHub): BuildCard {
  const root = el('section', 'ed-studio-card ed-studio-build');
  const top = el('div', 'ed-buttons');
  const runs = {
    build: button('build_run', 'Build', 'The release build (npm run build): typecheck, packs, dist/', () => void run('build'), 'ed-accent'),
    'build:debug': button('build_run', 'Build debug', 'The debug build (npm run build:debug): sourcemaps and the debug tools kept', () => void run('build:debug')),
    export: button('asset_export', 'Export', 'Every stale or missing source in AssetsSource/ exported (npm run export)', () => void run('export')),
  };
  const stop = button('job_cancel', 'Stop', 'Stop the task running', () => void hub.calls.cancel().catch((err: Error) => say(err.message, true)), 'ed-small');
  top.append(runs.build, runs['build:debug'], runs.export, stop);

  const line = el('div', 'ed-status');
  const spin = el('span', 'ed-studio-spin', '⟳');
  const words = el('span');
  line.append(spin, words);

  const ends = el('div', 'ed-buttons');
  const preview = button('preview_start', 'Preview', 'Serve dist/ (vite preview) and give its link', () => void startPreview());
  const link = el('a', 'ed-button ed-small');
  link.target = '_blank';
  link.rel = 'noopener';
  link.hidden = true;
  const reveal = button('ui', 'Reveal dist/', 'Show dist/ in the Finder or the Explorer', () => void revealDist());
  ends.append(preview, link, reveal);

  /** The stream shown: the last of this card's tasks to run, `build` before any. */
  const lastOwn = (): string => {
    const name = hub.running ?? hub.last?.name ?? null;
    return name !== null && (BUILD_TASKS as readonly string[]).includes(name) ? name : 'build';
  };
  const view = createLogView(hub.logs, `task:${lastOwn()}`, 'No build here yet: Build.');
  const sizes = el('div', 'ed-studio-list');
  root.append(top, line, view.el, ends, sizes);

  let refusal: string | null = null;
  const say = (text: string, bad = false): void => {
    refusal = bad ? text : null;
    words.textContent = text;
    line.classList.toggle('ed-bad', bad);
  };

  async function run(script: (typeof BUILD_TASKS)[number]): Promise<void> {
    view.show(`task:${script}`);
    refusal = null;
    const refused = await hub.run(script);
    if (refused) say(refused, true);
  }

  async function startPreview(): Promise<void> {
    preview.disabled = true;
    say('Starting the preview…');
    try {
      // The push says the url to every tab; the answer, here, at once.
      drawPreview(await hub.calls.startPreview());
      say('');
    } catch (err) {
      say(`The preview did not start: ${(err as Error).message}`, true);
    } finally {
      preview.disabled = false;
    }
  }

  async function revealDist(): Promise<void> {
    const answer = await revealIn(appShell(), (path) => hub.calls.reveal(path), 'dist');
    if (answer.kind === 'noShell') {
      reveal.textContent = 'Reveal: the app does this';
      reveal.title = 'A browser cannot show a folder: the Squidwright app\'s window does';
      reveal.disabled = true;
    } else if (answer.kind === 'refused') say(answer.why, true);
    else if (refusal !== null) {
      // Shown: an earlier refusal's words go, the task's line comes back.
      refusal = null;
      drawTask();
    }
  }

  function drawPreview(url: string | null): void {
    link.hidden = url === null;
    if (url !== null && link.href !== url) {
      link.href = url;
      link.textContent = `Open ${url} ↗`;
      link.title = 'The preview of dist/, in a new tab';
    }
  }

  function drawTask(): void {
    const running = hub.running;
    const ours = running !== null && (BUILD_TASKS as readonly string[]).includes(running);
    for (const b of Object.values(runs)) b.disabled = running !== null;
    stop.hidden = !ours;
    spin.hidden = !ours;
    if (ours) {
      if (view.stream !== `task:${running}`) view.show(`task:${running}`);
      say(`Running ${running}…`);
      return;
    }
    if (refusal) return;
    const end = hub.last;
    if (end && (BUILD_TASKS as readonly string[]).includes(end.name)) {
      const bad = end.code !== 0;
      say(`${end.name} ${end.signal ? `stopped by ${end.signal}` : `exited ${end.code}`}`, bad);
    } else say(running ? `${running} is running: one task at a time` : '');
  }

  function drawSizes(): void {
    const dist = hub.dist;
    if (dist === undefined) {
      sizes.replaceChildren(el('div', 'ed-dim', 'Measuring dist/…'));
      return;
    }
    if (dist === null) {
      sizes.replaceChildren(el('div', 'ed-dim', 'No dist/ yet: Build makes it, and its sizes show here.'));
      return;
    }
    const rows = sizeRows(dist);
    const table = el('table', 'ed-studio-sizes');
    const section = (title: string, list: typeof rows.folders, files: boolean): void => {
      const head = el('tr');
      const th = el('th', undefined, title);
      th.colSpan = files ? 3 : 2;
      head.append(th);
      table.append(head);
      for (const r of list) {
        const tr = el('tr');
        tr.append(el('td', undefined, r.path), el('td', 'ed-studio-num', r.size));
        if (files) tr.append(el('td', 'ed-studio-num', `${r.files} ${r.files === 1 ? 'file' : 'files'}`));
        tr.title = `${r.bytes.toLocaleString()} bytes`;
        table.append(tr);
      }
    };
    section('Folders', rows.folders, true);
    section('The largest files', rows.largest, false);
    sizes.replaceChildren(el('div', 'ed-dim', `dist/ as measured ${new Date(dist.at).toLocaleTimeString()}`), table);
  }

  const offs = [hub.on('task', drawTask), hub.on('dist', drawSizes), hub.on('preview', () => drawPreview(hub.preview))];
  if (hub.dist === undefined) void hub.measure();
  drawTask();
  drawSizes();
  drawPreview(hub.preview);

  return {
    el: root,
    run,
    preview: startPreview,
    reveal: revealDist,
    show() {
      drawTask();
      view.refresh();
    },
    hide() {},
    dispose() {
      for (const off of offs) off();
      view.dispose();
      root.remove();
    },
  };
}
