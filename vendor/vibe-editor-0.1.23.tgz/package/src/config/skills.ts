/**
 * Config ▸ Claude ▸ Skills (`skillsPage`, Docs/agent.md §2 "Skills"): the skills Claude loads in this project --
 * the project's own, the engine's (the vibe plugin's, and the `engine` and `studio` skills vibe sync writes, each
 * with the packages and versions it came from, said in its row), the person's -- from `GET /__agent/skills`, grouped with a heading each
 * (`skills-rows.ts`' words), each with its description and, where its file is in the project, Edit (View when
 * read-only) opening it in the Studio tab's Code card. New skill… makes `.claude/skills/<name>/SKILL.md` from a
 * template (`POST skills`), reads the list again and opens the file.
 *
 * - **In the Code card**: the host's `reveal` opens a text file there (`open`).
 * - **Read on show**, and again after a skill is made. Added by the host only where Claude's card is.
 */
import { createAgentApi, isUnavailable } from '../agent/api.ts';
import { button, control, el } from '../dom.ts';
import type { ConfigPage, PageInstance } from '../tool.ts';
import { NAME_RULE, groupSkills, nameProblem } from './skills-rows.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';

/** How a page opens a project file: in the Code card (the host's `reveal`), its answer the words to show. */
export interface FileOpener {
  open(path: string): Promise<string>;
}

export function skillsPage(opener: FileOpener): ConfigPage {
  return {
    id: 'claude-skills',
    title: 'Skills',
    group: 'Claude',
    help: "Skills: a SKILL.md each, its frontmatter a name and a description. Claude loads one when its description fits the task -- the project's, the vibe plugin's and your own",
    create: () => createSkills(opener),
  };
}

function createSkills(opener: FileOpener): PageInstance {
  const api = createAgentApi();
  const root = el('div', 'ed-prefs ed-config-skills');
  const help = el('div', 'ed-dim');
  help.textContent = "A skill is a folder with a SKILL.md: a frontmatter name and description, then what Claude should know. Claude reads every description and loads a skill when its description fits the task -- so the description says when.";

  // New skill…: a name, Make.
  const form = el('form', 'ed-buttons');
  const name = el('input', 'ed-input');
  name.type = 'text';
  name.placeholder = 'new skill name, e.g. level-design';
  name.spellcheck = false;
  const make = control(NOT_FOR_CLAUDE.codeEdit, 'ed-button ed-accent', 'Make');
  make.type = 'submit';
  make.title = 'Make .claude/skills/<name>/SKILL.md from a template, and open it';
  form.append(name, make);
  const rule = el('div', 'ed-pref-help', NAME_RULE);
  const status = el('div', 'ed-status');
  const list = el('div', 'ed-config-skills-list');
  root.append(help, el('div', 'ed-component-head', 'New skill…'), form, rule, status, list);

  const say = (text: string, bad = false): void => {
    status.textContent = text;
    status.classList.toggle('ed-bad', bad);
  };
  /** Open a file in the Code card, or say where it is; `after`, words said after either. */
  const open = async (path: string, editable: boolean, after = ''): Promise<void> => {
    say(`${await opener.open(path)}${editable ? '' : ' (read-only)'}${after}`);
  };

  let seen = false;
  let reading = 0;
  async function read(): Promise<void> {
    const mine = ++reading;
    let answer;
    try {
      answer = await api.skills();
    } catch (err) {
      if (mine === reading) list.replaceChildren(el('div', 'ed-bad', `Not read: ${(err as Error).message}`));
      return;
    }
    if (mine !== reading) return;
    if (isUnavailable(answer)) {
      list.replaceChildren(el('div', 'ed-dim', `Not here: ${answer.why}`));
      return;
    }
    list.replaceChildren();
    for (const group of groupSkills(answer)) {
      list.append(el('div', 'ed-component-head', `${group.heading} (${group.rows.length})`));
      if (group.rows.length === 0) list.append(el('div', 'ed-dim', group.empty));
      for (const row of group.rows) {
        const line = el('div', 'ed-pref');
        line.title = row.title;
        const controls = el('div', 'ed-pref-controls');
        controls.append(el('span', 'ed-dim', row.line));
        // Where it came from, in the row's text: which packages, which versions -- not only in the hover.
        if (row.from !== null) controls.append(el('span', 'ed-dim', `· ${row.from}`));
        if (row.button) {
          const editable = row.button === 'Edit';
          controls.append(button('ui', row.button, `Open ${row.path} in the Code card${editable ? '' : ', read-only'}`, () => void open(row.path, editable), 'ed-small'));
        }
        line.append(el('div', 'ed-pref-name', row.name), controls);
        list.append(line);
      }
    }
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    void makeSkill();
  });
  async function makeSkill(): Promise<void> {
    const wanted = name.value.trim();
    const problem = nameProblem(wanted);
    if (problem) return say(problem, true);
    make.disabled = true;
    try {
      const made = await api.newSkill(wanted);
      name.value = '';
      say(`Made ${made.row.path}. ${made.note}.`);
      await read();
      await open(made.row.path, true, `. ${made.note}.`);
    } catch (err) {
      say(`Not made: ${(err as Error).message}`, true);
    } finally {
      make.disabled = false;
    }
  }

  return {
    root,
    setVisible(visible) {
      if (visible && !seen) void read();
      seen = visible;
    },
    dispose() {
      reading++;
      root.remove();
    },
  };
}
