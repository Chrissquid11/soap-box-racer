/**
 * Config ▸ Claude ▸ CLAUDE.md (`claudeMdPage`): the project's `CLAUDE.md` -- its first lines shown dimmed (`GET
 * /__studio/file`, `skills-rows.ts`' `previewOf`, once `GET tree` lists it: a project with none asks no file, so no
 * 404 in the console), Edit opening it in the Studio tab's Code card (the host's
 * `reveal`, `FileOpener`), and Create for a project with none (`PUT
 * file` of `claudeMdStub`, named from `package.json`). Read on show. Added by the host only where Claude's card is.
 */
import { ApiRefused } from '../assets/api.ts';
import { assetApi } from '../assets/boot.ts';
import { button, el } from '../dom.ts';
import type { ConfigPage, PageInstance } from '../tool.ts';
import { claudeMdStub, previewOf } from './skills-rows.ts';
import type { FileOpener } from './skills.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';

const FILE = 'CLAUDE.md';

export function claudeMdPage(opener: FileOpener): ConfigPage {
  return {
    id: 'claude-md',
    title: 'CLAUDE.md',
    group: 'Claude',
    help: "The project's CLAUDE.md: the rules Claude reads first in this project, before any turn",
    create: () => createClaudeMd(opener),
  };
}

function createClaudeMd(opener: FileOpener): PageInstance {
  const api = assetApi().studio;
  const root = el('div', 'ed-prefs ed-config-claude-md');
  const help = el('div', 'ed-dim');
  help.textContent =
    "CLAUDE.md holds the rules Claude reads first in this project, at the start of every conversation: what the game is, how it is laid out, what not to do. The engine's own rules are not here: they are the vibe skill, which comes with the vibe plugin.";
  const status = el('div', 'ed-status');
  const edit = button('ui', 'Edit', 'Open CLAUDE.md in the Code card', () => void open(), 'ed-small');
  const create = button(NOT_FOR_CLAUDE.codeEdit, 'Create', 'Make CLAUDE.md: three lines naming the project and the vibe skill, then open it', () => void make(), 'ed-small');
  const buttons = el('div', 'ed-buttons');
  buttons.append(edit, create);
  const preview = el('pre', 'ed-dim ed-config-claude-md-preview');
  const more = el('div', 'ed-dim');
  root.append(help, buttons, status, preview, more);

  const say = (text: string, bad = false): void => {
    status.textContent = text;
    status.classList.toggle('ed-bad', bad);
  };
  async function open(): Promise<void> {
    say(await opener.open(FILE));
  }

  const none = (): void => {
    preview.textContent = '';
    more.textContent = '';
    edit.hidden = true;
    create.hidden = false;
    say('This project has no CLAUDE.md yet: Create makes one.');
  };

  /** Does the tree list CLAUDE.md: false only when the tree says it is not there (no GET file, so no 404 in the console); a tree not read says nothing. */
  async function listed(): Promise<boolean> {
    try {
      return (await api.tree()).files.some((f) => f.path === FILE);
    } catch {
      return true;
    }
  }

  let reading = 0;
  async function read(): Promise<void> {
    const mine = ++reading;
    try {
      if (!(await listed())) {
        if (mine === reading) none();
        return;
      }
      if (mine !== reading) return;
      const file = await api.file(FILE);
      if (mine !== reading) return;
      const cut = previewOf(file.text);
      preview.textContent = cut.text;
      more.textContent = cut.more > 0 ? `… and ${cut.more} more ${cut.more === 1 ? 'line' : 'lines'}` : '';
      edit.hidden = false;
      create.hidden = true;
      edit.textContent = file.readOnly ? 'View' : 'Edit';
    } catch (err) {
      if (mine !== reading) return;
      // Gone since the tree was read, or the tree not read: the 404 is the same answer.
      if (err instanceof ApiRefused && err.status === 404) return none();
      preview.textContent = '';
      more.textContent = '';
      edit.hidden = false;
      create.hidden = true;
      say(`Not read: ${(err as Error).message}`, true);
    }
  }

  /** The project's name, from its package.json; a stand-in without one. */
  async function projectName(): Promise<string> {
    try {
      const name = (JSON.parse((await api.file('package.json')).text) as { name?: unknown }).name;
      if (typeof name === 'string' && name !== '') return name;
    } catch {
      // No package.json, or no JSON: the stand-in.
    }
    return 'This game';
  }

  async function make(): Promise<void> {
    create.disabled = true;
    try {
      await api.save(FILE, claudeMdStub(await projectName()), null);
      say('Made CLAUDE.md.');
      await read();
      await open();
    } catch (err) {
      say(`Not made: ${(err as Error).message}`, true);
    } finally {
      create.disabled = false;
    }
  }

  let seen = false;
  return {
    root,
    setVisible(visible) {
      if (visible && !seen) {
        say('');
        void read();
      }
      seen = visible;
    },
    dispose() {
      reading++;
      root.remove();
    },
  };
}
