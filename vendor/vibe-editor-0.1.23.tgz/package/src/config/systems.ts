/**
 * Config ▸ Game ▸ Systems (`systemsPage`): every system in the order it runs,
 * with its rate, its dependency level, the components it reads and writes, and
 * its members slot by slot -- `world.describe()` with a face (Docs/ecs.md §13),
 * filling the page.
 *
 * - **The bars are the thing to look at**: a staggered system's members should
 *   be spread evenly over its slots, which is what choosing ids per kind is for.
 * - **Read again every second while it is shown**, and built again only when
 *   something did move, so a bar being looked at keeps its tooltip.
 */
import { el } from '../shell.ts';
import type { ConfigPage, EditorContext, PageInstance } from '../tool.ts';

/** How often the shown table is read again, in milliseconds. */
const EVERY = 1000;

export const systemsPage: ConfigPage = {
  id: 'systems',
  title: 'Systems',
  group: 'Game',
  help: 'Every system in the order it runs: its rate, level, data and members slot by slot',
  create: (ctx) => createSystems(ctx),
};

function createSystems({ game, world }: EditorContext): PageInstance {
  const panel = el('div', 'ed-config-systems');
  let seen = false;
  let timer: ReturnType<typeof setInterval> | undefined;
  /** What the table was built from, last time: the same again is not built again. */
  let shown = '';

  function refresh(): void {
    const now = JSON.stringify([world.stats, world.bytes, game.loop.tick, world.systemInfo().map((info) => [info.members, info.slots])]);
    if (now === shown && panel.childElementCount > 0) return;
    shown = now;
    panel.replaceChildren();
    const s = world.stats;
    panel.append(
      el(
        'div',
        'ed-facts',
        `${s.entities} entities of ${s.capacity}  ·  ${(world.bytes / 1024 / 1024).toFixed(1)} MB  ·  grew ${s.growths}×  ·  pool misses ${s.poolMisses}`
          + `  ·  buffer growths ${s.commandGrowths}  ·  refused ${s.refused}  ·  tick ${game.loop.tick}`,
      ),
    );
    const table = el('table', 'ed-table');
    const head = el('tr');
    for (const name of ['system', 'runs', 'level', 'members', 'by slot', 'reads', 'writes']) head.append(el('th', undefined, name));
    table.append(head);
    for (const info of world.systemInfo()) {
      const row = el('tr');
      const runs = info.phase !== 'simulation' ? info.phase
        : `${info.rate} Hz${info.stagger ? '' : ', all at once'}${info.stages === 'update' ? '' : ` · ${info.stages}`}`;
      const bars = el('div', 'ed-bars');
      const peak = Math.max(1, ...info.slots);
      for (const count of info.slots) {
        const bar = el('i');
        bar.style.height = `${Math.round((count / peak) * 100)}%`;
        bar.title = String(count);
        bars.append(bar);
      }
      const slots = el('td');
      slots.append(bars);
      row.append(
        el('td', 'ed-name', info.name),
        el('td', 'ed-dim', runs),
        el('td', 'ed-dim', String(info.level)),
        el('td', undefined, info.ecs ? String(info.members) : '–'),
        slots,
        el('td', 'ed-dim', info.reads.join(', ')),
        el('td', undefined, info.writes.join(', ')),
      );
      table.append(row);
    }
    panel.append(table);
    const conflicts = world.conflicts();
    if (conflicts.length > 0) {
      panel.append(el('div', 'ed-component-head', 'Share written data in one level: run in registration order'));
      for (const [a, b, component] of conflicts) panel.append(el('div', 'ed-dim', `${a}, then ${b}: ${component}`));
    }
  }

  return {
    root: panel,
    setVisible(visible) {
      seen = visible;
      clearInterval(timer);
      timer = undefined;
      if (!visible) return;
      refresh();
      timer = setInterval(refresh, EVERY);
    },
    // Read again only while it is shown: up again, it reads afresh anyway.
    refresh: () => {
      if (seen) refresh();
    },
    dispose() {
      clearInterval(timer);
      panel.remove();
    },
  };
}
