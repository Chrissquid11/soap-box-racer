/**
 * The editor's Config tab (`configTool`, key `2`; Docs/ecs.md §13): its left
 * panel, docked where the Scene tab's tree is -- the same width and fold
 * (`panels.left`), the same header -- holds **a tree of pages** in foldable
 * groups (`pages.ts`), headed CONFIG; the rest of the screen, under the top
 * bar to the window's right edge, is the page chosen. No inspector, no Assets
 * panel; the dock floats over the page as over the scene, and Claude's
 * column, docked, is the page's right edge (`--ed-ai-room`).
 *
 * - **Pages are plugins**: `EditorContext.pages` -- the host's list, a game's
 *   own (`createEditor`'s `pages`) and a tool's (the Assets tool's Tools)
 *   among them. Each is made once, with this tab's context, as it comes
 *   (`ConfigPages.attach`), so a page that does its work unseen -- Scenes'
 *   Save on `S`, its name on the Scene tab's header -- is live from the start.
 * - **The page chosen, and the groups folded, are kept** (`config` in
 *   `prefs.ts`); a kept page no longer there is the first.
 * - **Keys while the tree has the focus** (MrDebug, `ctx.keys`, on the keys
 *   card under Config): ↑ ↓ walk the rows seen -- a page walked to is shown --
 *   ← to a page's group and folds it, → unfolds it and goes in; Enter folds or
 *   unfolds a group. A click on a row gives the tree the focus.
 * - **Undo** here is the world's: the tab keeps no stack of its own (a page's
 *   steps -- a scene loaded -- are the world's too).
 */
import { el, sidePanel } from '../shell.ts';
import { keepPref, loadPrefs } from '../prefs.ts';
import type { ConfigPage, EditorContext, EditorTab, PageInstance, ToolInstance } from '../tool.ts';
import { tabId } from '../tab-pages.ts';
import { chosenOf, foldRow, groupId, rowsOf, stepRow, type PageRow } from './pages.ts';
import { keyed, tabKey } from '../editor-keys.ts';

/** The Config tab's id: what `ctx.pages.show` brings up. */
export const CONFIG_ID = tabId('config');

export const configTool: EditorTab = {
  id: CONFIG_ID,
  name: 'Config',
  icon: 'config',
  key: tabKey('config'),
  // At the strip's foot, as an IDE's settings are: the tools people work in at the top.
  place: 'bottom',
  help: 'The editor\'s Config tab: its pages -- the systems, the scenes, the export tools, preferences, keys',
  create: (ctx) => createConfig(ctx),
};

/** A page made: the page, what it made, and its card's wrapper. */
interface Made {
  page: ConfigPage;
  instance: PageInstance;
}

function createConfig(ctx: EditorContext): ToolInstance {
  const { root, pages } = ctx;
  const kept = loadPrefs().config;
  let folded: string[] = [...kept.folded];
  /** The page shown, by id; resolved against the pages there are as each comes (`chosenOf`). */
  let wanted = kept.page;
  let chosen = '';
  /** The row the arrows are on: the page shown, or a group's head. */
  let cursor = '';
  let visible = false;
  const made = new Map<string, Made>();

  // ---------------------------------------------------------------- the left panel: the tree of pages

  const tree = el('div', 'ed-card ed-side ed-left ed-config-tree');
  tree.hidden = true;
  const bar = el('div', 'ed-panel-head ed-panel-bar');
  const ends = el('span', 'ed-head-end');
  bar.append(el('div', 'ed-side-title', 'Config'), ends);
  const list = el('div', 'ed-config-list');
  // Focusable, so a click on a row gives it the keys (the arrows' `when`); its rows are not.
  list.tabIndex = 0;
  list.setAttribute('role', 'tree');
  list.setAttribute('aria-label', 'Config pages');
  tree.append(bar, list);
  root.append(tree);
  const side = sidePanel(root, tree, 'left', { name: 'Config' });
  ends.append(side.fold);

  // ---------------------------------------------------------------- the page: the rest of the screen

  const card = el('div', 'ed-card ed-page ed-config-page');
  card.hidden = true;
  const pageBar = el('div', 'ed-panel-head ed-panel-bar');
  const pageGroup = el('span', 'ed-config-crumb');
  const pageTitle = el('div', 'ed-side-title');
  pageBar.append(pageTitle, pageGroup);
  const body = el('div', 'ed-config-body');
  card.append(pageBar, body);
  // After the tree and its grip and tab: a folded tree's tab sits over the page's left edge, which makes room for it.
  root.append(card);

  const rows = (): PageRow[] => rowsOf(pages.list, folded);
  const keep = (): void => keepPref('config', { page: chosen, folded: [...folded] });

  function drawTree(): void {
    const items: HTMLElement[] = [];
    for (const row of rows()) {
      const item = el('div', `ed-config-row ed-config-row-${row.kind}`);
      item.dataset.id = row.id;
      item.setAttribute('role', 'treeitem');
      if (row.kind === 'group') {
        item.append(el('span', 'ed-caret', row.folded ? '▸' : '▾'), el('span', undefined, row.title));
        item.setAttribute('aria-expanded', String(!row.folded));
        item.title = row.folded ? `${row.title}: click to unfold` : `${row.title}: click to fold`;
        // mcp: ui -- a group folded
        item.addEventListener('click', () => {
          cursor = row.id;
          setFolded(row.group, !row.folded);
        });
      } else {
        item.append(el('span', undefined, row.title));
        item.setAttribute('aria-selected', String(row.id === chosen));
        item.title = row.help ?? row.title;
        // mcp: ui -- a page shown
        item.addEventListener('click', () => choose(row.id));
      }
      if (row.id === cursor) item.classList.add('ed-config-cursor');
      items.push(item);
    }
    list.replaceChildren(...items);
  }

  function setFolded(group: string, shut: boolean): void {
    folded = shut ? [...folded.filter((g) => g !== group), group] : folded.filter((g) => g !== group);
    keep();
    drawTree();
  }

  /** The page `id` shown, and kept: the others told they are not. */
  function choose(id: string): void {
    wanted = id;
    chosen = chosenOf(pages.list, id);
    cursor = chosen;
    // Its group open, so the row lit is seen.
    const group = pages.list.find((p) => p.id === chosen)?.group;
    if (group !== undefined && folded.includes(group)) folded = folded.filter((g) => g !== group);
    keep();
    showPage();
    drawTree();
  }

  /** The chosen page's card in the page, shown while the tab is; every other page told it is not. */
  function showPage(): void {
    const now = made.get(chosen);
    pageTitle.textContent = now?.page.title ?? 'No pages';
    pageGroup.textContent = now ? now.page.group : '';
    pageGroup.title = now?.page.help ?? '';
    for (const m of made.values()) if (m !== now) m.instance.setVisible(false);
    if (now) {
      if (now.instance.root.parentElement !== body) body.replaceChildren(now.instance.root);
      now.instance.setVisible(visible);
    } else body.replaceChildren(el('div', 'ed-dim', 'No pages: a tool or the game adds them (EditorContext.pages).'));
  }

  // ---------------------------------------------------------------- the pages, made as they come

  pages.attach({
    added(page) {
      const instance = page.create(ctx);
      made.set(page.id, { page, instance });
      // The page kept as chosen may come late -- a tool's, added as that tool is made.
      const next = chosenOf(pages.list, wanted);
      if (next !== chosen) {
        chosen = next;
        cursor = chosen;
        if (visible) showPage();
      }
      if (visible) drawTree();
    },
    removed(page) {
      const m = made.get(page.id);
      if (!m) return;
      made.delete(page.id);
      m.instance.setVisible(false);
      m.instance.dispose();
      chosen = chosenOf(pages.list, wanted);
      cursor = chosen;
      if (visible) {
        showPage();
        drawTree();
      }
    },
    show(id) {
      ctx.showTool(CONFIG_ID);
      choose(id);
      // Its width as kept: a reset of the panels (Preferences) reads again here.
      side.refresh();
    },
  });

  // ---------------------------------------------------------------- keys

  /** The tree has the focus: its arrows are live. */
  const inTree = (): boolean => visible && list.contains(document.activeElement);
  /** The cursor on `id`: a page walked to is shown. */
  const goTo = (id: string): void => {
    if (id === cursor) return;
    if (id.startsWith('group:')) {
      cursor = id;
      drawTree();
    } else choose(id);
  };
  const fold = (open: boolean): void => {
    const next = foldRow(pages.list, folded, cursor, open);
    const changed = next.folded.join('\n') !== folded.join('\n');
    folded = next.folded;
    if (changed) keep();
    if (next.at !== cursor) goTo(next.at);
    else drawTree();
  };
  const offKeys = [
    ctx.keys.add({ ...keyed('config up'), mcp: 'ui', view: true, when: inTree, help: 'The row above in the Config tree: a page is shown as it is reached', run: () => goTo(stepRow(rows(), cursor, -1)) }),
    ctx.keys.add({ ...keyed('config down'), mcp: 'ui', view: true, when: inTree, help: 'The row below in the Config tree', run: () => goTo(stepRow(rows(), cursor, 1)) }),
    ctx.keys.add({ ...keyed('config fold'), mcp: 'ui', view: true, when: inTree, help: 'From a page to its group; a group folded shut', run: () => fold(false) }),
    ctx.keys.add({ ...keyed('config unfold'), mcp: 'ui', view: true, when: inTree, help: 'A group unfolded; then into its first page', run: () => fold(true) }),
    ctx.keys.add({
      ...keyed('config toggle'), mcp: 'ui', view: true, when: () => inTree() && cursor.startsWith('group:'), help: 'The group under the cursor folded or unfolded',
      run: () => {
        const group = cursor.slice(groupId('').length);
        setFolded(group, !folded.includes(group));
      },
    }),
  ];

  /** The page shown, if any. */
  const up = (): PageInstance | undefined => made.get(chosen)?.instance;
  /** The first page that saves -- Scenes -- whether shown or not: Mod+S saves the scene from every tab. */
  const saver = (): PageInstance | undefined => [...made.values()].find((m) => m.instance.save)?.instance;

  return {
    // A page over the scene's room: Play goes to the scene first.
    page: true,
    setVisible(show) {
      visible = show;
      tree.hidden = !show;
      card.hidden = !show;
      // No right panel on this tab: the dock centres in the room to the window's edge (or Claude's column's).
      root.classList.toggle('ed-config-up', show);
      if (show) {
        side.refresh();
        chosen = chosenOf(pages.list, wanted);
        if (cursor === '' || (!cursor.startsWith('group:') && cursor !== chosen)) cursor = chosen;
        drawTree();
      }
      showPage();
    },
    // Every page reads the world again: one not shown does nothing, or as little.
    refresh() {
      for (const m of made.values()) m.instance.refresh?.();
    },
    get save() {
      const page = saver();
      return page ? () => page.save!() : undefined;
    },
    holdsEscape: () => [...made.values()].some((m) => m.instance.holdsEscape?.() === true),
    cancel() {
      for (const m of made.values()) if (m.instance.holdsEscape?.()) m.instance.cancel?.();
    },
    context: () => (visible && up() ? [{ name: 'Config page', value: `${made.get(chosen)!.page.group} ▸ ${made.get(chosen)!.page.title}` }] : null),
    dispose() {
      for (const off of offKeys) off();
      for (const m of made.values()) m.instance.dispose();
      made.clear();
      root.classList.remove('ed-config-up');
      side.dispose();
      tree.remove();
      card.remove();
    },
  };
}
