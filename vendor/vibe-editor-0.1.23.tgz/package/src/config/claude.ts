/**
 * Config ▸ Claude ▸ Settings (`claudePage`): the agent's settings that are the
 * dev server's -- Model, Effort, Review, the permission level, Fix a failed boot, Outside clients (Docs/agent.md §4, Docs/mcp.md M7) -- of the
 * conversation the card shows, and said so ("For ‹title›"; Fix a failed boot is every conversation's, the
 * project's), as the settings chip's popover under the card's box has them
 * (all but those two), over the same state and the same `POST
 * settings` (`agent/settings-picks.ts`): a change here is the card's at once,
 * and the other way. Added by the host only where the card is, a dev server
 * hosting Claude Code.
 */
import type { AgentSettings } from '../agent/agent-card.ts';
import { createSettingsPicks } from '../agent/settings-picks.ts';
import { el } from '../shell.ts';
import type { ConfigPage, PageInstance } from '../tool.ts';

export function claudePage(settings: AgentSettings): ConfigPage {
  return {
    id: 'claude',
    title: 'Settings',
    group: 'Claude',
    help: 'Claude Code\'s model, effort, review and permission level for the conversation shown, and Fix a failed boot and Outside clients for every conversation: the dev server\'s, as the settings chip under Claude\'s prompt box sets them',
    create: () => createClaude(settings),
  };
}

function createClaude(settings: AgentSettings): PageInstance {
  const root = el('div', 'ed-prefs ed-config-claude');
  const picks = createSettingsPicks((request) => settings.set(request));
  const row = (name: string, help: string, control: HTMLElement): HTMLElement => {
    const line = el('div', 'ed-pref');
    const box = el('div', 'ed-pref-controls');
    box.append(control);
    line.append(el('div', 'ed-pref-name', name), box, el('div', 'ed-pref-help', help));
    return line;
  };
  const down = el('div', 'ed-dim');
  root.append(
    row('Model', 'What Claude Code runs on, from its own list -- Default is its own choice. Changed at once, mid-conversation too.', picks.model),
    row('Effort', 'How hard the model may think: only the levels the model reports -- none, and there is no choice.', picks.effort),
    row('Review', 'A separate critic scores each result out of 10, and the agent works on until the bar is met: from the next turn.', picks.review),
    row('Permissions', 'Ask: each call that changes anything waits on the card for you. Auto: every call no rule of yours asks about goes ahead, but what can lose work. Unsafe auto: that too -- git push, git that discards work (reset, clean, stash …), a script it cannot read, a delete of what git tracks, the studio\'s destructive tools -- above a floor that always asks (.git/, .claude/, outside the project, your own ask rules). Yours alone: Claude never sets it.', picks.level),
    row('Outside clients', 'What an MCP client outside this page -- a terminal Claude Code, another tool -- may do through the dev server\'s /__mcp endpoint (vibe mcp prints its address, its token and the line to add it). Read-only by default; writes are steps Z undoes, labelled MCP: …; destructive tools only when picked. For every conversation: the project\'s.', picks.outside),
    row('Fix a failed boot', 'When the game cannot load, Claude is sent the error and asked to fix it (three tries, then it is yours). For every conversation: the project\'s, not the one shown.', picks.fixBoot.line),
    down,
  );
  let seen = false;
  const draw = (): void => {
    if (!seen) return;
    const up = settings.up();
    picks.draw(settings.state(), up);
    down.textContent = up ? `For "${settings.title()}", the conversation shown in Claude's column: each conversation has its own, but Fix a failed boot, which is every conversation's. The dev server keeps them -- every browser tab, and a restart, agree.` : 'Claude Code is not up just now: the column\'s head line says why.';
  };
  const off = settings.on(draw);
  return {
    root,
    setVisible(visible) {
      seen = visible;
      draw();
    },
    dispose() {
      off();
      root.remove();
    },
  };
}
