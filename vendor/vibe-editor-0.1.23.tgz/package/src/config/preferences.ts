/**
 * Config ▸ Editor ▸ Preferences (`preferencesPage`): the editor's own
 * settings that a person sets, each with its value now, changed here and kept
 * where it always was (`prefs.ts`) -- never a setting of its own:
 *
 * - **Snapping**: on or off, and its steps for moving, turning and scaling --
 *   through the viewport, as the top bar's magnet and steps (`V`) set them, so
 *   the bar shows the change at once.
 * - **Navigation** (Docs/navigation.md D1, §8): the keymap -- Industry
 *   Compatible (the default) or Blender's own, the keys re-bound at once --
 *   then Blender's preferences for moving
 *   round a 3D view, each with Blender's default -- Emulate 3 Button Mouse,
 *   Emulate Numpad, Zoom to Mouse Position, Orbit Around Selection, Auto
 *   Perspective -- and what the wheel is (the keys card's Scrolling).
 * - **The inspector's Position**: in its parent's space or the world's, as the
 *   Transform block's Local and World set it -- read again as the block is built.
 * - **The tree's columns**: those ticked on its columns button -- read again as
 *   the Scene tab comes up.
 * - **After a playtest**: what Stop does with what was changed while it was
 *   paused -- asks (`playtest-edits.ts`, the dialog), keeps it all, or drops it
 *   all (Docs/studio.md §1).
 * - **The side panels**: every one back to its usual width, unfolded.
 *
 * Read again each time the page is shown: the same settings change elsewhere.
 */
import { modName } from '@vibe/engine/debug';
import { COLUMN } from '../columns.ts';
import { choice, WHEELS } from '../keys-card.ts';
import { KEYMAP_NAMES, KEYMAPS, type Keymap } from '../editor-keys.ts';
import { AFTER_PLAYTEST, COLUMNS, keepPref, loadPrefs, PANEL, STEPS, stepText, WHEEL_MODES, type NavSwitch, type SnapStep } from '../prefs.ts';
import { button, control, el, letGo } from '../shell.ts';
import type { ConfigPage, EditorContext, PageInstance } from '../tool.ts';

export const PREFERENCES_PAGE = 'preferences';

/** What the page needs of the editor beyond its context: Maximize on Play set through the editor, so its toggle and a playtest follow. */
export interface PreferencesPageOptions {
  setMaximize(on: boolean): void;
  /** The keymap chosen (Docs/navigation.md §8): kept, and the editor's keys re-bound at once. */
  setKeymap(keymap: Keymap): void;
}

export function preferencesPage(options: PreferencesPageOptions): ConfigPage {
  return {
    id: PREFERENCES_PAGE,
    title: 'Preferences',
    group: 'Editor',
    help: 'The editor\'s own settings: snapping and its steps, the 3D views\' navigation and scrolling, the inspector\'s Position, the tree\'s columns, after a playtest, the side panels',
    create: (ctx) => createPreferences(ctx, options),
  };
}

/** The navigation's preferences, Blender's (Docs/navigation.md D1): each one's name on its row, and what it does. */
const NAV_ROWS: readonly { key: NavSwitch; name: string; help: string }[] = [
  { key: 'emulate3', name: 'Emulate 3 Button Mouse', help: 'Alt with the left button is the middle one: Alt-drag orbits, Shift+Alt-drag pans, Ctrl+Alt-drag zooms -- for a mouse with no middle button, or a trackpad' },
  { key: 'emulateNumpad', name: 'Emulate Numpad', help: 'With the pointer over a 3D view, the digit row, - and = are the numpad\'s keys (1 front, 5 the projection, 7 top...); elsewhere 1-6 are still the tabs' },
  { key: 'zoomToMouse', name: 'Zoom to Mouse Position', help: 'The wheel zooms toward the point under the pointer, not the middle of the view' },
  { key: 'orbitSelection', name: 'Orbit Around Selection', help: 'The orbit turns round the middle of what is selected, not the view\'s own pivot' },
  { key: 'autoPerspective', name: 'Auto Perspective', help: 'A view from an axis (a numpad key, a cone of the cube) goes orthographic, and orbiting away from it back to perspective' },
];

/** What each keymap is, on its row (Docs/navigation.md §8). */
const KEYMAP_HELP = 'The 3D views\' keys and mouse: Blender\'s Industry Compatible keymap -- Alt+left-drag orbits, Alt+middle pans, Alt+right zooms, W E R the gizmo, F1-F4 the views, A frames all -- or Blender\'s own -- middle-drag orbits, G R S the gizmo, the numpad the views, Home frames all. The editor\'s own keys (the tabs, play, save, undo) are the same under both; the keys card (?) lists the live ones';
/** Why Emulate 3 Button Mouse is off under Industry Compatible (D12). */
const EMULATE3_OFF = 'Not under Industry Compatible: Alt with the left button already orbits there, Alt with the middle pans, Alt with the right zooms';

/** What each snap step is for, on its row. */
const STEP_NAMES: Record<SnapStep, string> = { move: 'Move step', turn: 'Turn step', scale: 'Scale step' };

function createPreferences({ viewport, pages }: EditorContext, { setMaximize, setKeymap }: PreferencesPageOptions): PageInstance {
  const root = el('div', 'ed-prefs');

  /** A setting's row: its name, its controls, and a line of what it does. */
  const row = (name: string, help: string, ...controls: HTMLElement[]): HTMLElement => {
    const line = el('div', 'ed-pref');
    const box = el('div', 'ed-pref-controls');
    box.append(...controls);
    line.append(el('div', 'ed-pref-name', name), box, el('div', 'ed-pref-help', help));
    return line;
  };
  /** Buttons a value each, the one in force pressed: a click sets it, then the page is read again. */
  const segments = <V>(values: readonly V[], now: V, label: (v: V) => string, set: (v: V) => void): HTMLElement[] =>
    values.map((v) => {
      const b = letGo(control('ui', 'ed-button ed-small', label(v)));
      b.setAttribute('aria-pressed', String(v === now));
      b.addEventListener('click', () => {
        set(v);
        draw();
      });
      return b;
    });
  const head = (text: string): HTMLElement => el('div', 'ed-component-head', text);
  const said = el('div', 'ed-dim');

  function draw(): void {
    const snap = viewport.snap;
    const prefs = loadPrefs();
    const on = el('input', 'ed-check');
    on.type = 'checkbox';
    on.checked = snap.on;
    on.addEventListener('change', () => {
      on.blur();
      viewport.setSnap({ on: on.checked });
      draw();
    });
    const onLine = el('label', 'ed-check-line');
    onLine.append(on, el('span', undefined, snap.on ? 'On' : 'Off'));
    const steps = (Object.keys(STEPS) as SnapStep[]).map((which) =>
      row(STEP_NAMES[which], `What a ${which === 'move' ? 'move' : which === 'turn' ? 'turn' : 'scale'} with the gizmo snaps to -- the top bar's step, a click there the next`,
        ...segments(STEPS[which], snap[which], (v) => stepText(which, v), (v) => viewport.setSnap({ [which]: v }))));

    const columns = COLUMNS.map((column) => {
      const tick = el('label', 'ed-check-line');
      tick.title = COLUMN[column].title;
      const box = el('input', 'ed-check');
      box.type = 'checkbox';
      box.checked = prefs.columns.includes(column);
      box.addEventListener('change', () => {
        box.blur();
        const next = loadPrefs().columns.filter((c) => c !== column);
        keepPref('columns', COLUMNS.filter((c) => c === column ? box.checked : next.includes(c)));
      });
      tick.append(box, el('span', undefined, COLUMN[column].name));
      return tick;
    });

    root.replaceChildren(
      head('The gizmo'),
      row('Snap', `Whether a gizmo drag snaps to its steps -- V, and the top bar's magnet; ${modName()} held while dragging turns it over`, onLine),
      ...steps,
      head('Navigation'),
      row('Keymap', KEYMAP_HELP, ...segments(KEYMAPS, prefs.nav.keymap, (k) => KEYMAP_NAMES[k], (k) => setKeymap(k))),
      ...NAV_ROWS.map(({ key, name, help }) => {
        const buttons = segments([false, true], prefs.nav[key], (on) => (on ? 'On' : 'Off'), (on) => keepPref('nav', { ...loadPrefs().nav, [key]: on }));
        // Emulate 3 Button Mouse means nothing under Industry Compatible (D12): shown, disabled, saying why.
        const meaningless = key === 'emulate3' && prefs.nav.keymap === 'industry';
        if (meaningless) for (const b of buttons) (b as HTMLButtonElement).disabled = true;
        const line = row(name, meaningless ? EMULATE3_OFF : help, ...buttons);
        if (meaningless) line.classList.add('ed-pref-off');
        return line;
      }),
      choice('Scrolling', WHEEL_MODES, WHEELS, () => viewport.wheel, (mode) => viewport.setWheel(mode)),
      head('The inspector'),
      row('Position', 'The Transform block\'s Position and Rotation: relative to the parent, or in the world -- its Local and World',
        ...segments([false, true], prefs.worldPosition, (w) => (w ? 'World' : 'Local'), (w) => keepPref('worldPosition', w))),
      head('The tree'),
      row('Columns', 'What a row shows after its name -- the tree header\'s columns button; the filter reads them all, shown or not', ...columns),
      head('The playtest'),
      row('After a playtest', 'What Stop does with what you changed while the playtest was paused: asks which to keep, keeps it all, or drops it all -- the scene as the playtest found it',
        ...segments(AFTER_PLAYTEST, prefs.afterPlaytest, (a) => (a === 'ask' ? 'Ask' : a === 'keep' ? 'Keep' : 'Drop'), (a) => keepPref('afterPlaytest', a))),
      row('Maximize on Play', 'Where a playtest plays: in the scene\'s room with the cards where they are (Off), or over the whole window with every card hidden (On) -- the play strip\'s toggle too',
        ...segments([false, true], prefs.maximizeOnPlay, (on) => (on ? 'On' : 'Off'), (on) => setMaximize(on))),
      head('The side panels'),
      row('Widths', `Every side panel -- the tree and this one, the inspectors, the Assets panel's folders -- back to its usual width (${PANEL} px), unfolded`,
        button('ui', 'Reset', 'Every side panel back to its usual width, unfolded', () => {
          keepPref('panels', { left: { width: PANEL, folded: false }, right: { width: PANEL, folded: false } });
          said.textContent = 'Every side panel back to its usual width: each takes it as its tab comes up';
          // This tab's own panel at once: the Config tab reads its width again as a page is shown.
          pages.show(PREFERENCES_PAGE);
        }, 'ed-small')),
      said,
    );
  }

  return {
    root,
    setVisible(visible) {
      if (!visible) return void root.replaceChildren();
      said.textContent = '';
      draw();
    },
    // Snapping set by V or the bar meanwhile: the page as it is now.
    refresh() {
      if (root.childElementCount > 0) draw();
    },
    dispose: () => root.remove(),
  };
}
