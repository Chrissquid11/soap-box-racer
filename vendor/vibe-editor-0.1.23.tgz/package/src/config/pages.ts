/**
 * The Config tab's pages, and its tree of them (Docs/ecs.md §13): the
 * registry a tool adds a page to (`createPages`, the host's, handed to every
 * tool as `EditorContext.pages`) and the rules of the tree -- the groups in
 * order, the rows a fold leaves, the page chosen, the arrows' step. Pure, so a
 * node test holds them; the Config tab (`config.ts`) draws them.
 *
 * - **Groups in a fixed order**: Game, Assets, Editor, Claude (`GROUPS`), then
 *   a game's own, in the order their first page came. A group with no page is
 *   no row.
 * - **The page chosen is kept** (`config.page`, `prefs.ts`), and a kept id no
 *   page has any more -- a game's page taken out -- is the first page.
 * - **The arrows walk the rows seen**: a group folded hides its pages, and ←
 *   on a page goes to its group, ← on an open group folds it, → unfolds it and
 *   then goes in (`stepRow`, `foldRow`).
 */
import type { ConfigPage, ConfigPages, PagesTab } from '../tool.ts';

/** The tree's groups in their order; any other -- a game's own -- after them. */
export const GROUPS: readonly string[] = ['Game', 'Assets', 'Editor', 'Claude'];

/** A row of the tree: a group's head, or a page under it. A group's id is `group:` and its name, which no page's is. */
export interface PageRow {
  kind: 'group' | 'page';
  id: string;
  group: string;
  title: string;
  /** A group's: folded shut, its pages not rows. */
  folded?: boolean;
  help?: string;
}

/** What these rules read of a page. */
type Placed = Pick<ConfigPage, 'id' | 'title' | 'group' | 'help'>;

export const groupId = (group: string): string => `group:${group}`;

/** The groups the pages are in: `GROUPS`' order, then a game's own in the order their first page came. */
export function groupsOf(pages: readonly Placed[]): string[] {
  const named = new Set(pages.map((p) => p.group));
  const own = [...named].filter((g) => !GROUPS.includes(g));
  return [...GROUPS.filter((g) => named.has(g)), ...own];
}

/** The tree's rows: each group's head, and under an open one its pages in the order added. */
export function rowsOf(pages: readonly Placed[], folded: readonly string[]): PageRow[] {
  const rows: PageRow[] = [];
  for (const group of groupsOf(pages)) {
    const shut = folded.includes(group);
    rows.push({ kind: 'group', id: groupId(group), group, title: group, folded: shut });
    if (shut) continue;
    for (const p of pages) if (p.group === group) rows.push({ kind: 'page', id: p.id, group, title: p.title, help: p.help });
  }
  return rows;
}

/** The page shown: `kept` if a page has that id, else the first in the tree's order; '' with none. */
export function chosenOf(pages: readonly Placed[], kept: string): string {
  if (pages.some((p) => p.id === kept)) return kept;
  for (const group of groupsOf(pages)) {
    const first = pages.find((p) => p.group === group);
    if (first) return first.id;
  }
  return '';
}

/** The row `by` from `at` among `rows`, held at the ends; one not there (folded away) goes to its group's row, else the first. */
export function stepRow(rows: readonly PageRow[], at: string, by: number): string {
  if (rows.length === 0) return '';
  let i = rows.findIndex((r) => r.id === at);
  if (i < 0) return rows[0]!.id;
  i = Math.max(0, Math.min(rows.length - 1, i + by));
  return rows[i]!.id;
}

/**
 * ← and → on row `at`: what is folded after, and where the cursor goes. ← on a
 * page goes to its group; on an open group folds it. → on a folded group
 * unfolds it; on an open one goes to its first page.
 */
export function foldRow(pages: readonly Placed[], folded: readonly string[], at: string, open: boolean): { folded: string[]; at: string } {
  const rows = rowsOf(pages, folded);
  const row = rows.find((r) => r.id === at);
  if (!row) return { folded: [...folded], at };
  if (row.kind === 'page') return { folded: [...folded], at: open ? at : groupId(row.group) };
  const shut = folded.includes(row.group);
  if (!open) return { folded: shut ? [...folded] : [...folded, row.group], at };
  if (shut) return { folded: folded.filter((g) => g !== row.group), at };
  const first = pages.find((p) => p.group === row.group);
  return { folded: [...folded], at: first?.id ?? at };
}

/**
 * The registry (`EditorContext.pages`): pages in the order added, an id once.
 * The Config tab attaches as it is made and makes each page -- those added
 * before it, then each as it comes -- and shows one when asked.
 */
export function createPages(initial: readonly ConfigPage[] = []): ConfigPages {
  const list: ConfigPage[] = [];
  let tab: PagesTab | null = null;
  const add = (page: ConfigPage): (() => void) => {
    if (page.id.startsWith('group:') || list.some((p) => p.id === page.id)) throw new Error(`[editor] two Config pages share an id, or one is a group's: ${page.id}`);
    list.push(page);
    tab?.added(page);
    let gone = false;
    return () => {
      if (gone) return;
      gone = true;
      const at = list.indexOf(page);
      if (at >= 0) list.splice(at, 1);
      tab?.removed(page);
    };
  };
  for (const page of initial) add(page);
  return {
    get list() {
      return list;
    },
    add,
    show(id) {
      if (!tab || !list.some((p) => p.id === id)) return false;
      tab.show(id);
      return true;
    },
    attach(next) {
      if (tab) throw new Error('[editor] the Config pages have a tab already');
      tab = next;
      for (const page of list) next.added(page);
    },
  };
}
