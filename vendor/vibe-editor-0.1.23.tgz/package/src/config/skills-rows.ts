/**
 * The words of Config ▸ Claude ▸ Skills and ▸ CLAUDE.md (`skills.ts`, `claude-md.ts`), pure, so a node test holds
 * them: the rows grouped by source with a heading each, a row's line, hover and button; the name rule a new skill
 * is held to; the CLAUDE.md preview's cut and the stub a project with none is made.
 */
import { SKILL_NAME, type SkillRow, type SkillsAnswer } from '@vibe/pipeline/agent-types';

/** Said under the name field. */
export const NAME_RULE = 'Lowercase letters, digits and -, a letter or digit first: it is the folder, .claude/skills/<name>/';

/** Why `name` will not do, or null when it will. */
export function nameProblem(name: string): string | null {
  if (name === '') return 'Type a name first';
  if (name.length > 41) return 'At most 41 characters';
  if (!SKILL_NAME.test(name)) return /[A-Z]/.test(name) ? 'Lowercase only' : NAME_RULE;
  return null;
}

/** One row as the page draws it. */
export interface SkillLine {
  name: string;
  /** The description's first line (or what stands in for one). */
  line: string;
  /** The whole description, and where the file is: the row's hover. */
  title: string;
  /** The packages and versions it came from (`@vibe/engine 0.1.15`, `the project`), said in the row; null for none. */
  from: string | null;
  /** Its button's word: Edit, View, or none (no file in the project). */
  button: 'Edit' | 'View' | null;
  path: string;
}

/** A heading and its rows; `empty`, said when it has none. */
export interface SkillGroup {
  /** The project's own, the engine's (the vibe plugin and the skills vibe sync writes), the person's. */
  group: 'project' | 'engine' | 'user';
  heading: string;
  rows: SkillLine[];
  empty: string;
}

export const HEADINGS: Readonly<Record<SkillGroup['group'], string>> = {
  project: "This project's",
  engine: "The engine's (the vibe plugin, and the skills vibe sync writes)",
  user: 'Yours, outside the project',
};

/** Where a row's file is, where it came from and what an edit of it is. */
function whereOf(row: SkillRow): string {
  const from = row.from !== undefined ? ` (${row.from})` : '';
  if (row.source === 'user') return 'A skill of your own, outside the project (your ~/.claude/, or a plugin of yours)';
  if (row.source === 'project') return `${row.path}: this project's own, committed with it`;
  if (row.source === 'engine') return `${row.path}: the engine's, written by vibe sync from the installed packages' pages${row.from !== undefined ? `: ${row.from}` : ''} -- never edited, never committed: a page changes in its package (or the project's tool folder) and comes at the next sync`;
  if (row.path === '') return `The engine's${from}, outside this project (the pipeline package's claude/skills/): open it in your own editor`;
  if (row.editable) return `${row.path}: the engine's own repository${from} -- an edit here is a change to the engine, for every game on it`;
  return `${row.path}: the package's${from}, read-only -- vibe sync's copies in .claude/skills/ are the same, written on install and never edited`;
}

/** A row's line, hover and button. */
export function lineOf(row: SkillRow): SkillLine {
  const description = row.description.trim();
  const line = description.split('\n')[0] ?? '';
  return {
    name: row.name,
    line: line !== '' ? line : row.source === 'user' ? 'A skill of your own, outside the project' : 'No description',
    title: description !== '' ? `${description}\n\n${whereOf(row)}` : whereOf(row),
    from: row.from !== undefined && row.from !== '' ? row.from : null,
    button: row.path === '' ? null : row.editable ? 'Edit' : 'View',
    path: row.path,
  };
}

/** The rows in the page's order: the project's, the engine's (the plugin's, then vibe sync's), the person's. */
export function groupSkills(answer: SkillsAnswer): SkillGroup[] {
  const of = (...sources: SkillRow['source'][]): SkillLine[] => sources.flatMap((source) => answer.skills.filter((r) => r.source === source).map(lineOf));
  return [
    { group: 'project', heading: HEADINGS.project, rows: of('project'), empty: 'None yet: New skill… makes one in .claude/skills/.' },
    { group: 'engine', heading: HEADINGS.engine, rows: of('plugin', 'engine'), empty: 'None found: the pipeline package has no claude/skills/, and vibe sync has written none.' },
    {
      group: 'user',
      heading: HEADINGS.user,
      rows: of('user'),
      empty: answer.heard ? 'None: Claude loaded no skill of yours.' : 'Not known yet: Claude names them at the first turn of a conversation -- send one in the Claude card, then come back.',
    },
  ];
}

/** How many lines of CLAUDE.md the page shows. */
export const PREVIEW_LINES = 12;

/** CLAUDE.md's first lines, and how many more there are. */
export function previewOf(text: string, lines = PREVIEW_LINES): { text: string; more: number } {
  const all = text.replace(/\r\n/g, '\n').replace(/\n$/, '').split('\n');
  return { text: all.slice(0, lines).join('\n'), more: Math.max(0, all.length - lines) };
}

/** A project's first CLAUDE.md: three lines, naming the project and the vibe skill. */
export function claudeMdStub(project: string): string {
  return `# ${project}\n\nThe rules Claude reads first in this project go here; the engine's own rules are the vibe skill (the vibe plugin's) -- load it before changing src/game/, src/ui/ or src/assets/.\n`;
}
