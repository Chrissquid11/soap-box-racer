/**
 * Config ▸ Editor ▸ Game view (`gameViewPage`, Docs/game-view.md §4): the presets the play strip's dropdown shapes
 * the game with -- Free Aspect, the built-ins, then the project's own -- each of the project's a row to edit in
 * place: its name, its size (`16:9`, `640x360`), its mode, and for Stretch its filter; Use, ↑ ↓ to reorder, and
 * Remove. A row at the foot adds one. What changes here is kept at once (`game-view-store.ts`) and the frame follows.
 *
 * Read again each time the page is shown, and on `refresh`: the dropdown and the tools change the same presets.
 */
import { BUILT_IN, FREE, presetWords, SCALE_FILTERS, SCALE_MODES, sizeText, type GamePreset, type ScaleFilter, type ScaleMode } from '../game-view.ts';
import type { GameViews } from '../game-view-store.ts';
import { button, el } from '../shell.ts';
import { textInput } from '../fields.ts';
import type { ConfigPage, PageInstance } from '../tool.ts';

export const GAME_VIEW_PAGE = 'game-view';

/** What the page needs: the presets kept, which the editor shapes the frame by. */
export interface GameViewPageOptions {
  views: GameViews;
}

export function gameViewPage(options: GameViewPageOptions): ConfigPage {
  return {
    id: GAME_VIEW_PAGE,
    title: 'Game view',
    group: 'Editor',
    help: 'The game view\'s presets -- Free Aspect, the built-in aspects and resolutions, the project\'s own -- that the play strip\'s dropdown shapes a playtest with: Fit, Pixel or Stretch',
    create: () => createGameViewPage(options),
  };
}

const MODE_WORDS: Record<ScaleMode, string> = { fit: 'Fit', pixel: 'Pixel', stretch: 'Stretch' };
const FILTER_WORDS: Record<ScaleFilter, string> = { nearest: 'Nearest', linear: 'Linear' };

const SIZE_TIP = 'Size: an aspect, 16:9 (Fit only), or pixels, 640x360';

function select<V extends string>(values: readonly V[], words: Record<V, string>, now: V, label: string): HTMLSelectElement {
  const pick = el('select', 'ed-input ed-small');
  pick.setAttribute('aria-label', label);
  for (const v of values) pick.append(Object.assign(el('option', undefined, words[v]), { value: v }));
  pick.value = now;
  return pick;
}

function createGameViewPage({ views }: GameViewPageOptions): PageInstance {
  const root = el('div', 'ed-prefs ed-game-presets');
  const said = el('div', 'ed-dim');
  const head = (text: string): HTMLElement => el('div', 'ed-component-head', text);

  /** A line of what went wrong, or nothing: the page read again either way. */
  const after = (why: string | null): void => {
    draw();
    said.textContent = why ?? '';
  };

  /** A chosen mark and Use, for a preset of any kind. */
  const use = (name: string): HTMLElement => {
    if (views.chosen === name) return el('span', 'ed-dim', 'In use');
    return button('game_view_set', 'Use', `Shape the game view with ${name}: the play strip's dropdown`, () => after(views.choose(name)), 'ed-small');
  };

  /** One of the built-ins, or Free Aspect: its words and Use. */
  const fixedRow = (name: string, words: string): HTMLElement => {
    const line = el('div', 'ed-pref');
    const box = el('div', 'ed-pref-controls');
    box.append(use(name));
    line.append(el('div', 'ed-pref-name', name), box, el('div', 'ed-pref-help', words));
    return line;
  };

  /** One of the project's: every part of it a field, changed as it is left. */
  const ownRow = (p: GamePreset, at: number, count: number): HTMLElement => {
    const line = el('div', 'ed-pref ed-game-preset');
    const box = el('div', 'ed-pref-controls');
    const name = textInput(p.name, 'Name');
    name.title = 'Its name: the dropdown\'s words for it, unique among the presets';
    const size = textInput(sizeText(p), '640x360');
    size.title = SIZE_TIP;
    size.classList.add('ed-game-size');
    const mode = select(SCALE_MODES, MODE_WORDS, p.mode, 'Mode');
    const filter = select(SCALE_FILTERS, FILTER_WORDS, p.filter, 'Filter (Stretch)');
    filter.disabled = p.mode !== 'stretch';
    const change = (): void => after(((r) => (typeof r === 'string' ? r : null))(views.put({ name: name.value, size: size.value, mode: mode.value as ScaleMode, filter: filter.value as ScaleFilter }, p.name)));
    for (const field of [name, size]) field.addEventListener('change', change);
    for (const field of [mode, filter]) field.addEventListener('change', change);
    const up = button('game_view_preset', '↑', 'Up the list: the dropdown\'s order', () => {
      views.move(p.name, -1);
      after(null);
    }, 'ed-small');
    up.disabled = at === 0;
    const down = button('game_view_preset', '↓', 'Down the list', () => {
      views.move(p.name, 1);
      after(null);
    }, 'ed-small');
    down.disabled = at === count - 1;
    const remove = button('game_view_preset', 'Remove', `Take ${p.name} out of the project's presets`, () => after(views.remove(p.name)), 'ed-small ed-danger');
    box.append(size, mode, filter, use(p.name), up, down, remove);
    line.append(name, box, el('div', 'ed-pref-help', presetWords(p.width, p.height, p.exact, p.mode, p.filter)));
    return line;
  };

  /** The row at the foot: a new preset, its size, mode and filter, and Add. */
  const addRow = (): HTMLElement => {
    const line = el('div', 'ed-pref ed-game-preset');
    const box = el('div', 'ed-pref-controls');
    const name = textInput('', 'Name');
    name.title = 'Its name; none, its size and mode in words';
    const size = textInput('', '640x360');
    size.title = SIZE_TIP;
    size.classList.add('ed-game-size');
    const mode = select(SCALE_MODES, MODE_WORDS, 'fit', 'Mode');
    const filter = select(SCALE_FILTERS, FILTER_WORDS, 'linear', 'Filter (Stretch)');
    mode.addEventListener('change', () => void (filter.disabled = mode.value !== 'stretch'));
    filter.disabled = true;
    const add = button('game_view_preset', 'Add', 'A preset of the project\'s own, at the end of the list', () => {
      const made = views.put({ name: name.value, size: size.value, mode: mode.value as ScaleMode, filter: filter.value as ScaleFilter });
      after(typeof made === 'string' ? made : null);
    }, 'ed-small ed-accent');
    box.append(size, mode, filter, add);
    line.append(name, box, el('div', 'ed-pref-help', 'A size is an aspect (16:9, Fit only) or pixels (640x360): Fit draws at the screen\'s sharpness, Pixel at exactly that size scaled by a whole number, Stretch at that size scaled by any, Nearest or Linear'));
    return line;
  };

  function draw(): void {
    const own = views.own;
    root.replaceChildren(
      head('Built in'),
      fixedRow(FREE, 'The room as it is: the game fills the space between the cards'),
      ...BUILT_IN.map((p) => fixedRow(p.name, p.exact ? `${p.width}×${p.height}, ${MODE_WORDS[p.mode]}${p.mode === 'stretch' ? `, ${FILTER_WORDS[p.filter]}` : ''}` : `The aspect ${p.width}:${p.height}, Fit`)),
      head('The project\'s'),
      ...own.map((p, i) => ownRow(p, i, own.length)),
      addRow(),
      said,
    );
  }

  return {
    root,
    setVisible(visible) {
      if (!visible) return void root.replaceChildren();
      said.textContent = '';
      draw();
    },
    refresh() {
      if (root.childElementCount > 0 && !root.contains(document.activeElement)) draw();
    },
    dispose: () => root.remove(),
  };
}
