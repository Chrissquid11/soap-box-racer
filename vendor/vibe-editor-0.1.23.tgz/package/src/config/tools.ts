/**
 * Config ▸ Assets ▸ Tools (`toolsPage`): the tools the export steps need --
 * Gladius, ffmpeg, Git LFS and the rest `GET tools` lists -- their state,
 * their paths and Check again (Docs/assets-tool.md §7). The block itself is
 * the Assets tool's (`assets/ui/tools-block.ts`), which holds what the server
 * said; that tool adds this page as it is made (`ctx.pages.add`) and opens it
 * where the Assets panel says a tool is wanting -- a folder's `⚠`, the
 * inspector's **Set its path in Tools** (`ctx.pages.show`).
 *
 * **The Download row** (`downloadRow`, step 2.3), under ffmpeg's entry: shown
 * when `GET /__studio/checks` says ffmpeg is missing -- asked each time the page
 * comes -- on this machine's page alone (a write). **Download** is `POST
 * /__studio/download { tool: 'ffmpeg' }`, answered at once; the rest comes as
 * `studio:download` pushes, heard through a `Live` of the page's own: a bar
 * with the bytes, then the path it went to -- the tools looked for again
 * (`checkAgain`), so the entry's Set its path field shows it -- or a failure's
 * words.
 */
import type { DownloadState } from '@vibe/pipeline/studio-types';
import { assetApi } from '../assets/boot.ts';
import { createLive, type Live } from '../assets/live.ts';
import type { ToolsBlock } from '../assets/ui/tools-block.ts';
import { button, el } from '../shell.ts';
import { humanBytes } from '../studio/dist-sizes.ts';
import type { ConfigPage, PageInstance } from '../tool.ts';

/** The page's id: what the Assets tool shows. */
export const TOOLS_PAGE = 'tools';

/** The tool the studio downloads. */
const FFMPEG = 'ffmpeg';

/** A download's progress in words: `12.3 MB of 40.1 MB`, `12.3 MB` with no length said. */
export const progressWords = (s: Pick<DownloadState, 'received' | 'total'>): string => (s.total ? `${humanBytes(s.received)} of ${humanBytes(s.total)}` : humanBytes(s.received));

/** The Download row: under ffmpeg's entry in `block`, checked again by `check()`. */
function downloadRow(block: ToolsBlock): { check(): void; dispose(): void } {
  const api = assetApi();
  const row = el('div', 'ed-download');
  row.hidden = true;
  const said = el('div', 'ed-dim');
  const go = button('tools_download', 'Download ffmpeg', 'Fetch a static ffmpeg build for this machine, check its checksum and set its path', () => void start(), 'ed-small');
  const bar = el('div', 'ed-download-bar');
  const fill = el('div', 'ed-download-fill');
  bar.append(fill);
  bar.hidden = true;
  const words = el('div', 'ed-status');
  row.append(said, go, bar, words);
  block.under(FFMPEG, row);

  let live: Live | null = null;
  let missing = false;

  function draw(s: DownloadState): void {
    const busy = s.state === 'downloading' || s.state === 'unpacking';
    row.hidden = !missing && s.state === 'idle';
    go.hidden = busy || s.state === 'done';
    bar.hidden = !busy;
    fill.style.width = s.total ? `${Math.min(100, (100 * s.received) / s.total).toFixed(1)}%` : busy ? '100%' : '0';
    words.classList.toggle('ed-bad', s.state === 'failed');
    words.textContent =
      s.state === 'downloading' ? `Downloading: ${progressWords(s)}`
      : s.state === 'unpacking' ? 'Unpacking…'
      : s.state === 'done' ? `Downloaded: ${s.path ?? ''}`
      : s.state === 'failed' ? `Not downloaded: ${s.why ?? 'it failed'}`
      : '';
  }

  /** The pushes, heard from the first check on. */
  function listen(): void {
    if (live) return;
    live = createLive(api);
    live.on('studio:download', (m) => {
      if (m.tool !== FFMPEG) return;
      draw(m);
      if (m.state === 'done') {
        missing = false;
        void block.checkAgain();
      }
    });
  }

  async function start(): Promise<void> {
    listen();
    words.classList.remove('ed-bad');
    words.textContent = 'Starting…';
    try {
      draw(await api.studio.download(FFMPEG));
    } catch (err) {
      words.classList.add('ed-bad');
      words.textContent = `Not downloaded: ${(err as Error).message}`;
    }
  }

  return {
    check() {
      void (async () => {
        if ((await api.online()) !== 'write') return;
        try {
          const [rows, state] = await Promise.all([api.studio.checks(), api.studio.downloadState(FFMPEG)]);
          missing = rows.some((r) => r.name === FFMPEG && !r.ok);
          said.textContent = missing ? 'Not on this machine: the studio can fetch a static build of it.' : '';
          listen();
          draw(state);
        } catch {
          // No studio routes on this server: no row.
        }
      })();
    },
    dispose() {
      live?.dispose();
      row.remove();
    },
  };
}

/** The page over the Assets tool's block; `shown` tells it as the page comes and goes (the tool asks the server again as it comes). */
export function toolsPage(block: ToolsBlock, shown?: (visible: boolean) => void): ConfigPage {
  return {
    id: TOOLS_PAGE,
    title: 'Tools',
    group: 'Assets',
    help: 'The tools the export steps need: found, missing or lacking, their paths, Check again, ffmpeg\'s Download',
    create: (): PageInstance => {
      const download = downloadRow(block);
      return {
        root: block.root,
        setVisible(visible) {
          if (visible) {
            block.refresh();
            download.check();
          }
          shown?.(visible);
        },
        refresh: () => block.refresh(),
        dispose: () => {
          download.dispose();
          block.root.remove();
        },
      };
    },
  };
}
