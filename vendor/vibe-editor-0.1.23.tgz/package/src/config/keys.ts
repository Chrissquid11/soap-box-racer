/**
 * Config ▸ Editor ▸ Keys (`keysPage`): every key the editor has registered, by
 * group -- the editor's own, the prompt box's, then each tool's -- live just
 * now or not, as the keys card (`?`, which lists only the live ones) draws
 * them (`keyGroups`), and what the mouse does in the scene under them. Read
 * afresh each time the page is shown: a tool's keys come and go with it.
 */
import { keyLabel } from '@vibe/engine/debug';
import { keyGroups, mouseLine } from '../keys-card.ts';
import { el } from '../shell.ts';
import type { ConfigPage, PageInstance } from '../tool.ts';

/** What the page asks of the host: the groups as the keys card has them. */
export interface KeysPageOptions {
  groupOf(name: string): string;
  groups(): readonly string[];
}

export function keysPage(options: KeysPageOptions): ConfigPage {
  return {
    id: 'keys',
    title: 'Keys',
    group: 'Editor',
    help: 'Every key of the editor, by group, live just now or not',
    create: () => createKeys(options),
  };
}

function createKeys({ groupOf, groups }: KeysPageOptions): PageInstance {
  const root = el('div', 'ed-config-keys');
  return {
    root,
    setVisible(visible) {
      if (!visible) return void root.replaceChildren();
      const note = el('div', 'ed-dim', `Every key, live just now or not: ${keyLabel('Shift+Slash')} lists only those live where you are. A key works only where its group is up -- a tool's while that tool has the keys.`);
      root.replaceChildren(note, keyGroups({ groupOf, groups }, false), el('div', 'ed-keys-foot', mouseLine()));
    },
    dispose: () => root.remove(),
  };
}
