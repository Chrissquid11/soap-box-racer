/**
 * Config ▸ Game ▸ Scenes (`scenesPage`): the scene files -- every
 * `src/assets/scenes/**\/*.scene`, a `world.save()` inside (the engine's `scenes.ts`,
 * Docs/ecs.md §19) -- opened, saved, renamed, duplicated, deleted, shown in the
 * Assets panel; the world emptied to start a new one; and the start scene
 * picked. A page of the Config tab, made as the editor is: its Save is `S` on
 * every tab, and the scene's name and dot in the Scene tab's header are its
 * (`ctx.setTitle`).
 *
 * - **A scene is a file, written by the dev server** (`PUT prefab`, as a
 *   prefab file is written): Save writes the open scene's file again, Save
 *   as… a new one, its name asked on a line -- the file's, as typed: "My
 *   Camp" is `My Camp.scene`, its key `my camp` (the name lowercased); a name
 *   no file may have is refused with why, never made another
 *   (`scene-files.ts`' `sceneNameFrom`). Rename is the server's move, Duplicate a new file
 *   named `-2`, Delete the server's delete -- to the project's trash
 *   (`.trash/`), where the Assets panel's Trash restores it, not the OS's.
 *   Without a dev server that writes (a `?debug` build on a static host, a
 *   page from the LAN) every write is refused with a line saying so; the
 *   scenes the build bundled still open.
 * - **The open scene follows its file** (`follow`): renamed or moved -- on
 *   this page, in the Assets panel, by an undo there; every move and delete
 *   the dev server answers is told once (`onFilesWent`) -- its key is the
 *   file's new one: the header, `S`, the resume record, the start mark (in
 *   the file) all with it. Deleted, the world stays, with no file and not
 *   saved: the next `S` asks a name. A rename on disk outside the editor is
 *   followed too, found by the text (a file gone, one new with the same).
 * - **The start scene is the file that says `"start": true`** (the picker
 *   writes it, and takes it off the one before): committed with it, so a
 *   release opens it as a debug build does (the engine's `boot`). None: the game's own
 *   world.
 * - **Another world loaded is another history**: through `Game.load`, so the
 *   models come back, then `history.reset()`, `worldSteps.sync()` and the
 *   editor's `loaded` -- the steps were of the world before. Opened from the
 *   Assets panel too (`openScene`: a double-click on a `.scene`, its
 *   inspector's Open).
 * - **"Lose what changed?" is the editor's dialog** (`dialog.ts`'s
 *   `askUnsaved`) -- opening, importing or emptying over changes nobody
 *   saved: Save (then on; a world with no file named in the dialog, Save
 *   as…), Don't save, Cancel. **Every other question is a line in the panel**
 *   (`ask.ts`) -- a name, "replace it?", a delete. Never `prompt` or
 *   `confirm`: those stop the page, and the game and any automation driving
 *   it with it. Cancel, or Esc, says no.
 * - **Leaving with changes nobody saved asks first** (`beforeunload`) -- the
 *   world's, a scene file's or not, its mark read under a prefab open too, or
 *   a prefab's open in the editor (`guardUnsaved`, `leave-guard.ts`) -- but
 *   for a reload the editor survives (`editor.ts`' `prepareReload`), which
 *   lets that one pass (`letReloadPass`): the world goes with the resume
 *   record, and comes back under its key and unsaved mark (`sceneMark`,
 *   `resumeScene`), as the start scene opened at boot does. In recovery every
 *   reload passes, with no record: the stand-in is nothing to keep
 *   (`resume.ts`' `passWrite`). Unpassed, the app asks in its own dialog
 *   (Docs/studio.md §13): Electron shows no "Leave site?".
 * - **The agent saves through Save** (`saveScene`, its `scene_save`,
 *   Docs/agent.md §8): the scene's own file, or a new one for a new scene --
 *   never over another scene, which is the person's to say here.
 * - **Once, the browser's scenes move into files** (`migrate`): the scenes
 *   this page kept in `localStorage` (`vibebase.scenes`) before scenes were
 *   files, each written as a `.scene` named from its name (a key taken gets
 *   `-2`), its start scene the start scene if none is yet, and the entry
 *   renamed `vibebase.scenes.migrated` -- kept, never deleted. The page's line
 *   says how many moved.
 */
import { caseKey, onSceneFiles, type SceneFile, sceneIfPresent, sceneKeys, sceneName, sceneSave, startScene, type WorldSave } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import { ApiRefused } from '../assets/api.ts';
import { assetApi, onFilesWent } from '../assets/boot.ts';
import {
  freeKey,
  LEGACY_KEY,
  LEGACY_MOVED,
  legacyScenes,
  madeSceneName,
  migrationPlan,
  sceneFileOf,
  sceneKeyAfter,
  sceneNameFrom,
  scenePathOf,
  sceneText,
  SCENES_DIR,
  sceneKeyOf,
  whyNotSave,
} from '../assets/scene-files.ts';
import { createAsk } from '../ask.ts';
import { newSceneWorld } from '../camera-entity.ts';
import { askUnsaved, dialogNote } from '../dialog.ts';
import { textEdit } from '../fields.ts';
import { button, el } from '../shell.ts';
import { skippedText, updatedText } from '../skipped.ts';
import type { ConfigPage, EditorContext, PageInstance } from '../tool.ts';
import { ago, dateOf } from '../when.ts';
import { holdsPrefab } from '../level-keys.ts';
import { PENDING } from '../world-steps.ts';
import { asksOnLeave, editedAfter } from '../leave-guard.ts';
import { notSavedPlaying, STOP_FIRST } from '../playtest-state.ts';
import { leave, saveAsRefusal } from '../mcp/scenes.ts';

/**
 * `save` in place of the world, through `Game.load`; or, if it will not load,
 * the world left as it was and why. A load that fails halfway has already
 * emptied the world, so the world before is kept to put back.
 */
function loadInto(game: Game, save: WorldSave): { skipped: string[]; updated?: string[] } | { error: string } {
  const why = whyNotSave(save);
  if (why) return { error: why };
  const before = game.world.save();
  try {
    return game.load(save);
  } catch (err) {
    game.load(before);
    return { error: err instanceof Error ? err.message : String(err) };
  }
}

/** The scene files that hold an instance of prefab `key` -- by the key its reference names now: what its Prefab block lists under Used by. */
export function scenesHolding(key: string): string[] {
  return sceneKeys().filter((k) => holdsPrefab(sceneIfPresent(k), key));
}

/** The start scene opened at boot, for the editor to call current when it first opens; and the world as it was opened. */
let startKey: string | null = null;
let openedAs: string | null = null;

/**
 * At boot, in a debug build: `boot` opened the start scene `key` (the engine's `scenes.ts`' `startScene`)
 * in place of the game's own world. The editor, made later, calls it the open scene -- saved, if the
 * game has not run since.
 */
export function openedOnStart(game: Game, key: string): void {
  startKey = key;
  // Read again rather than taken from the file: links can list in another order after a load.
  openedAs = JSON.stringify(game.world.save());
}

/** What the Scenes page knows of the world for a reload the editor survives: the scene's key, what it came from, edited since it was saved. */
export interface SceneMark {
  current: string | null;
  source: string | null;
  edited: boolean;
}

/** The mark a reload brought back, for the tool to take as it is made; and the live tool's, for the record. */
let resumed: SceneMark | null = null;
let marked: (() => SceneMark) | null = null;
/** A reload the editor survives is under way: the guard lets it pass. */
let passing = false;

/** The Scenes page's mark now, for the resume record; null without one. */
export const sceneMark = (): SceneMark | null => marked?.() ?? null;

/** A Save done: the file's name as written (capitals and spaces kept, `src/assets/scenes/<name>.scene`) and its key apart; or why not. */
export type SceneSaved = { name: string; key: string } | { error: string };

/** The live page's Save, under a name: what `saveScene` and the agent's Save as call. */
let saving: ((name: string | null) => Promise<SceneSaved>) | null = null;

/**
 * The world saved as Save does -- the scene's own file, or a new one named
 * `name` -- for the agent's `scene_save` (Docs/agent.md §8). Never over
 * another scene: replacing one is asked in the panel, and the person's to say.
 */
export function saveScene(name: string | null): Promise<SceneSaved> {
  return saving?.(name) ?? Promise.resolve({ error: 'The Scenes page is not made yet: the editor has not been opened' });
}

/**
 * The live page's Open, New scene, Save as… and start pick as the agent's scene tools call them (Docs/mcp.md M2):
 * the same code as the buttons, with no question to ask -- so what nobody saved is refused unless the call says
 * `discard`, and a name another scene has is refused, never written over.
 */
export interface AgentScenes {
  open(key: string, discard: boolean): { skipped: string[]; discarded: boolean } | { error: string };
  fresh(discard: boolean): { discarded: boolean } | { error: string };
  saveAs(name: string): Promise<SceneSaved>;
  start(key: string | null): Promise<{ start: string | null } | { error: string }>;
  /** Import…: a world save's text written as a new scene named from `name`, then opened -- refused over what nobody saved, unless `discard`. */
  importSave(text: string, name: string, discard: boolean): Promise<{ key: string; file: string; skipped: string[]; discarded: boolean } | { error: string }>;
}
let agentScenes: AgentScenes | null = null;

/** The Scenes page's tools for the agent; refused whole while the page is not made yet (the editor never opened). */
export function scenesForAgent(): AgentScenes {
  const none = 'The Scenes page is not made yet: the editor has not been opened';
  return agentScenes ?? {
    open: () => ({ error: none }),
    fresh: () => ({ error: none }),
    saveAs: async () => ({ error: none }),
    start: async () => ({ error: none }),
    importSave: async () => ({ error: none }),
  };
}

/** The live page's Open: what `openScene` calls -- null if it went on, else why not. */
let opening: ((key: string) => string | null) | null = null;

/**
 * The scene `key` opened in place of the world, as its row's Open does -- from
 * the Assets panel (a double-click, the inspector's Open) -- "lose what
 * changed?" asked first in the editor's dialog when there is something to lose.
 * Null if it went on; else why not, for the caller's line: the page not made
 * yet (the editor never opened), or a playtest on (Stop first).
 */
export function openScene(key: string): string | null {
  if (!opening) return 'The Scenes page is not made yet';
  return opening(key);
}

/** After a reload, before the editor is made: the scene it had, by key and mark. */
export function resumeScene(mark: SceneMark): void {
  resumed = mark;
}

/** What the guard reads of the opened mode: edits not saved beside the scene's, and the scene's own mark under it. */
export interface GuardBeside {
  /** A prefab open with edits not saved, at any level: `editor.ts`' `opened.unsavedAny`. */
  beside(): boolean;
  /** The scene's steps at their save: `history.saved`, or with a prefab open the mark put aside under it (`opened.outerSaved`). */
  sceneSaved(): boolean;
}
let unsavedBeside: GuardBeside | null = null;

/**
 * The guard asks too while `beside` says so -- a prefab open in the editor
 * with edits not saved, at any level -- and reads the scene's saved mark from
 * `sceneSaved`, which with a prefab open is the one put aside under it, not
 * the prefab's stack; through the same pass a reload the editor survives lets
 * through. Handed in from `editor.ts`, so this tool knows nothing of the
 * opened mode; null takes it away.
 */
export function guardUnsaved(given: GuardBeside | null): void {
  unsavedBeside = given;
}

/** The next unload is a reload the editor survives (`prepareReload`): the guard does not ask. Off again, and it asks. */
export function letReloadPass(on: boolean): void {
  passing = on;
}

/**
 * The scene `key` as its file has it, in place of the world -- for a resume
 * whose world was too big to keep across the reload. Null if there is no such scene.
 */
export function loadKept(game: Game, key: string): { skipped: string[] } | { error: string } | null {
  const file = sceneIfPresent(key);
  return file ? loadInto(game, file) : null;
}

const sizeOf = (chars: number): string =>
  chars < 1024 ? `${chars} B` : chars < 1024 * 1024 ? `${(chars / 1024).toFixed(1)} KB` : `${(chars / 1024 / 1024).toFixed(1)} MB`;

/** How often the panel's "modified 5 min ago" is read again while it is shown, in milliseconds. */
const EVERY = 30_000;

/** What a refusal says, as a line: the server's words, or the error's. */
const why = (err: unknown): string => (err instanceof Error ? err.message : String(err));

export const scenesPage: ConfigPage = {
  id: 'scenes',
  title: 'Scenes',
  group: 'Game',
  help: 'The scene files under src/assets/scenes: open, save, rename, duplicate, delete, a new one, the one the game opens on start',
  create: (ctx) => createScenes(ctx),
};

function createScenes(ctx: EditorContext): PageInstance {
  const { game, history, worldSteps } = ctx;
  const api = assetApi();
  /** The scene being edited, by key: the one last saved or opened -- or brought back by a reload. Null for a world with no file. */
  let current: string | null = resumed ? (resumed.current === null ? null : caseKey(resumed.current)) : startKey;
  /** What a world with no file came from: New scene. Null for the game's own. */
  let source: string | null = resumed?.source ?? null;
  /**
   * Edits since the last save: a step pushed, or undone or redone away from it.
   * Not the game having run since -- that empties history unsaved, but nothing
   * was edited -- and not another world loaded.
   */
  let edited = resumed?.edited ?? false;
  resumed = null;
  marked = () => ({ current, source, edited });
  /** Steps pushed, undone and redone, counted: a save that waited on the server marks the world saved only if none came meanwhile. */
  let moves = 0;
  /**
   * The open scene's file as last seen, and the keys there were then: a file
   * renamed on disk, outside the editor -- gone, and a new one with the same
   * text -- is followed by it (`onSceneFiles`, below).
   */
  let held = current === null ? undefined : sceneIfPresent(current);
  let known = new Set<string>(sceneKeys());
  /** Each scene file's size and when it was last written, from the dev server's index; none without one. */
  let stats = new Map<string, { size: number; mtime: number }>();

  /** When the current scene was saved, in words and in full: under the editor's title on hover. */
  const note = (): string => {
    if (current === null) return 'No file: Save as… writes one';
    if (!sceneIfPresent(current)) return 'Its file is not there: Save writes it again';
    const at = stats.get(current)?.mtime;
    return `${at ? `Saved ${ago(at, Date.now())} · ${dateOf(at)}` : scenePathOf(current)}${history.saved ? '' : ' · changed since'}`;
  };
  /** Under the editor's title too. */
  const named = (): void => ctx.setTitle(current !== null ? (sceneName(current) ?? current) : source, note);

  // ---------------------------------------------------------------- the panel

  const panel = el('div', 'ed-scenes');
  /** Chosen and the Config tab up: the list and its times are read only then. */
  let seen = false;

  const nowName = el('b');
  const nowState = el('div', 'ed-dim');
  const now = el('div', 'ed-scene-now');
  now.append(nowName, nowState);

  const saveButton = button('scene_save', 'Save', '', () => save());
  const saveAsButton = button('scene_save_as', 'Save as…', 'Write the world as a new scene file', () => saveAs());
  const newButton = button('scene_new', 'New scene', 'Empty the world but for a main camera, to build one from nothing', () => newScene(), 'ed-danger');
  const actions = el('div', 'ed-buttons');
  actions.append(saveButton, saveAsButton, newButton);

  // What the last thing done came to, under the question, when there is one.
  const status = el('div', 'ed-status');
  status.hidden = true;

  const listTitle = el('div', 'ed-component-head');
  const list = el('div', 'ed-scene-list');

  const startLine = el('label', 'ed-line');
  const startPick = el('select', 'ed-input');
  startLine.title = 'The scene the game opens in place of its own world when the page loads -- in every build: the file says "start": true';
  startLine.append(el('span', undefined, 'Open on start'), startPick);

  // The file picker, never seen: Import clicks it.
  const picker = el('input', 'ed-import');
  picker.type = 'file';
  picker.accept = '.json,.scene,application/json';
  picker.hidden = true;
  const files = el('div', 'ed-buttons');
  files.append(
    button('scene_import', 'Import…', 'A world save exported as a .json before scenes were files: written as a new .scene, and opened', () => importFile()),
    button('ui', 'Copy', 'The world as JSON, on the clipboard: paste it into a file, or into world.load(...) at the console', () => void copy()),
    picker,
  );

  // Its header is the page's (`config.ts`): the scene now, then what to do with it.
  panel.append(now, actions);
  // The question, when there is one, under the buttons that asked it.
  const ask = createAsk(panel);
  const { askFirst, askName } = ask;
  const closeAsk = (): void => ask.close();
  panel.append(status, listTitle, list, el('div', 'ed-component-head', 'Start'), startLine, el('div', 'ed-component-head', 'File'), files);

  // ---------------------------------------------------------------- reading out

  function say(text: string, bad = false): void {
    status.hidden = false;
    status.textContent = text;
    status.classList.toggle('ed-bad', bad);
  }

  /** The current scene's line, Save's title. */
  function refresh(): void {
    // What the world is called: the current scene's key, or what it came from, or the game's own.
    nowName.textContent = ctx.title;
    const at = current === null ? undefined : stats.get(current)?.mtime;
    nowState.textContent =
      current === null ? 'No file: Save as… writes one'
      : !sceneIfPresent(current) ? 'Its file is not there: Save writes it again'
      : history.saved ? (at ? `Saved ${ago(at, Date.now())}` : 'Saved')
      : at ? `Changed since it was saved ${ago(at, Date.now())}` : 'Changed since it was saved';
    nowState.title = current === null ? '' : `${scenePathOf(current)}${at ? ` · saved ${dateOf(at)}` : ''}`;
    saveButton.title = current === null ? 'Name the world and write it as a scene file (Mod+S)' : `Write ${current}.scene again (Mod+S)`;
  }

  /** Each row's "modified 5 min ago", read again on a timer without building the list again: a rename under way stays. */
  let times: (() => void)[] = [];

  function drawList(): void {
    list.replaceChildren();
    times = [];
    const keys = sceneKeys();
    const start = startScene();
    listTitle.textContent = `In src/assets/scenes  ${keys.length}`;
    if (keys.length === 0) list.append(el('div', 'ed-dim', 'None yet: Save as… writes the world as one.'));
    for (const key of keys) {
      const file = sceneIfPresent(key)!;
      const row = el('div', 'ed-scene');
      if (key === current) row.setAttribute('aria-current', 'true');
      const label = el('div', 'ed-scene-name');
      label.append(el('span', undefined, sceneName(key) ?? key));
      if (start === key) label.append(el('span', 'ed-badge', 'on start'));
      const text = el('div', 'ed-scene-text');
      const meta = el('div', 'ed-scene-meta');
      const time = (): void => {
        const at = stats.get(key);
        const size = at?.size ?? JSON.stringify(file).length;
        const count = Array.isArray(file.entities) ? file.entities.length : 0;
        meta.textContent = `${count} ${count === 1 ? 'entity' : 'entities'} · ${sizeOf(size)}${at?.mtime ? ` · modified ${ago(at.mtime, Date.now())}` : ''}`;
        meta.title = `${scenePathOf(key)}${at?.mtime ? ` · modified ${dateOf(at.mtime)}` : ''}`;
      };
      time();
      times.push(time);
      text.append(label, meta);
      const buttons = el('div', 'ed-scene-actions');
      buttons.append(
        button('scene_open', 'Open', `Open ${key} in place of the world`, () => load(key), 'ed-small'),
        button('asset_move', 'Rename', `Rename ${key}.scene`, () => rename(key, label), 'ed-small ed-quiet'),
        button('asset_copy', 'Duplicate', `A copy of ${key}.scene beside it, named -2`, () => void duplicate(key), 'ed-small ed-quiet'),
        button('ui', 'Show', `Show ${key}.scene in the Assets panel`, () => reveal(key), 'ed-small ed-quiet'),
        button('asset_delete', 'Delete', `${key}.scene to the project's trash`, () => remove(key), 'ed-small ed-quiet ed-danger'),
      );
      row.append(text, buttons);
      list.append(row);
    }
    drawStart(keys, start);
  }

  /** The start picker: the game's own world, or each scene. */
  function drawStart(keys: readonly string[], start: string | null): void {
    const own = el('option', undefined, "None: the game's own world");
    own.value = '';
    startPick.replaceChildren(own, ...keys.map((key) => {
      const option = el('option', undefined, key);
      option.value = key;
      return option;
    }));
    startPick.value = start ?? '';
  }

  /** After anything that changed the files or what the world is: the list, the line, the subtitle. */
  function changed(): void {
    named();
    drawList();
    refresh();
  }

  /** Each scene file's size and time, from the dev server's index -- as the page is shown, and after the files change. */
  let reading = false;
  async function readStats(): Promise<void> {
    if (reading) return;
    reading = true;
    try {
      const answer = await api.tree();
      if (!('tree' in answer)) return;
      const next = new Map<string, { size: number; mtime: number }>();
      for (const entry of answer.tree) {
        const key = sceneKeyOf(entry.path);
        if (key !== undefined) next.set(key, { size: entry.size, mtime: entry.mtime });
      }
      stats = next;
      for (const time of times) time();
      refresh();
    } catch {
      // No index to read: the rows say what the files themselves do.
    } finally {
      reading = false;
    }
  }

  // ---------------------------------------------------------------- questions

  /**
   * `run` now, or -- if it would lose changes nobody has saved -- after the
   * editor's dialog: Save (the scene's file, or a new one named there), then
   * `run`; Don't save, `run`; Cancel, nothing. `doing` is what `run` does, asked.
   */
  function unsavedThen(doing: string, run: () => void): void {
    // An edit under way is a step first, so `saved` knows of it.
    worldSteps.commit(PENDING);
    if (history.saved) return run();
    closeAsk();
    const what = current !== null ? `'${current}'` : source !== null ? `'${source}'` : 'The world';
    // A prefab open: S is the prefab's, so the scene cannot be saved from here.
    const cannot = ctx.prefab !== null ? `${ctx.prefab} is open -- Back to the scene to save it` : undefined;
    askUnsaved({
      what,
      doing,
      go: run,
      ...(cannot !== undefined ? { save: null, why: cannot } : current !== null ? {
        save: () => write(current!).then((failed) => {
          if (failed !== null) dialogNote(`Not saved: ${failed}.`);
          return failed === null;
        }),
      } : {
        named: freeKey(madeSceneName(source ?? '') ?? 'scene', (k) => sceneIfPresent(k) !== undefined),
        save: async (typed?: string) => {
          const made = sceneNameFrom(typed ?? '');
          if ('refused' in made) {
            dialogNote(`No name for a scene: ${made.refused}.`);
            return false;
          }
          if (sceneIfPresent(made.name)) {
            dialogNote(`There is a scene ${sceneName(made.name) ?? made.name} already: another name, or Cancel and Save as… to write over it.`);
            return false;
          }
          const failed = await write(made.name);
          if (failed !== null) dialogNote(`Not saved: ${failed}.`);
          return failed === null;
        },
      }),
    });
  }

  // ---------------------------------------------------------------- writing

  /** Why this page cannot write files now, or null if it can. */
  async function cannotWrite(): Promise<string | null> {
    const online = await api.online();
    if (online === 'write') return null;
    return online === 'read' ? 'this page reads the dev server from another machine, and only the machine running it writes files' : 'there is no dev server to write the file (npm run dev)';
  }

  /** `text` written as scene `key`'s file -- made, or written again, whichever it is on disk. Null if it was, else why not. */
  async function put(key: string, text: string, create: boolean): Promise<string | null> {
    const path = scenePathOf(key);
    try {
      await api.putPrefab(path, text, create);
      return null;
    } catch (err) {
      // The map is a moment behind the disk (a file just written, or just gone): the other way once.
      if (err instanceof ApiRefused && (err.status === 409 || err.status === 404)) {
        try {
          await api.putPrefab(path, text, err.status === 404);
          return null;
        } catch (again) {
          return why(again);
        }
      }
      return why(err);
    }
  }

  /** The world written as scene `name` -- a key, or a new file's name as typed -- which is then the current scene. Null if it was, else why not. */
  async function write(name: string): Promise<string | null> {
    const key = caseKey(name);
    // An Apply landing loads its world: what is saved now is not what is there after it, nor the save point.
    if (ctx.refuses('Save')) return 'an Apply is landing';
    // A playtest's world is the game's, not the scene's: Stop puts the scene's back, and then it is saved.
    const playtest = ctx.playtest();
    if (playtest !== 'none') {
      const no = notSavedPlaying(playtest);
      say(`Not saved: ${no}.`, true);
      return no;
    }
    // The prefab open is in the scene: its own Save writes it, and the scene is put aside under it.
    if (ctx.prefab !== null) {
      const no = `${ctx.prefab} is open: Mod+S saves the prefab -- Back to the scene to save it`;
      say(`Not saved: ${no}.`, true);
      return no;
    }
    const cannot = await cannotWrite();
    if (cannot) {
      say(`Not saved: ${cannot}.`, true);
      return cannot;
    }
    // What is written is the world as history has it now: an edit under way a step of its own first.
    worldSteps.commit(PENDING);
    const at = moves;
    // With each instance's overrides: a load brings every instance up to its prefab as compiled then (Docs/prefabs.md §6).
    const text = sceneText(sceneSave(game.world), startScene() === key);
    const failed = await put(name, text, !sceneIfPresent(key));
    if (failed) {
      say(`Not saved: ${failed}.`, true);
      return failed;
    }
    current = key;
    source = null;
    // Edited while the server wrote it: what is on disk is the world before those edits, so not saved.
    if (moves === at) history.markSaved();
    say(`Saved ${scenePathOf(name)} · ${sizeOf(text.length)}${moves === at ? '' : ' -- edited since, so not marked saved'}`);
    changed();
    void readStats();
    return null;
  }

  function save(): void {
    if (current !== null) {
      void write(current);
      return;
    }
    // Nothing to save over: the name is asked for here, on this page -- from whichever tab.
    ctx.pages.show(scenesPage.id);
    saveAs();
  }

  function saveAs(): void {
    const suggested = current !== null ? (sceneName(current) ?? current) : freeKey('scene', (k) => sceneIfPresent(k) !== undefined);
    askName('Save the world as', suggested, (typed) => {
      const made = sceneNameFrom(typed);
      if ('refused' in made) return say(`Not saved: ${made.refused}.`, true);
      const then = (): void => void write(made.name);
      if (caseKey(made.name) === current || !sceneIfPresent(made.name)) return then();
      askFirst(`There is a scene ${sceneName(made.name) ?? made.name} already. Write over it?`, 'Replace', then, true);
    });
  }

  // The agent's Save and Save as: no question to answer, so a name that is another scene's is refused, not replaced (`saveAsRefusal`, one rule).
  saving = async (name) => {
    if (name === null && current === null) return { error: 'The world has no scene file yet: give one (name), and it is saved as a new scene' };
    const made = name === null ? { name: sceneName(current!) ?? current! } : sceneNameFrom(name);
    if ('refused' in made) return { error: `‘${name}’ is no name for a scene file: ${made.refused}` };
    const key = caseKey(made.name);
    const taken = saveAsRefusal(key, current, (k) => sceneIfPresent(k) !== undefined);
    if (taken) return { error: taken };
    // A question the panel had up is no longer the question.
    closeAsk();
    const failed = await write(made.name);
    return failed === null ? { name: made.name, key } : { error: `Not saved: ${failed}` };
  };

  // ---------------------------------------------------------------- opening

  /** Another world in place of this one: history starts again, and everything is read again. */
  function become(key: string | null, from: string | null, skipped: string[], text: string): void {
    current = key;
    source = from;
    held = key === null ? undefined : sceneIfPresent(key);
    history.reset();
    worldSteps.sync();
    // Another world: what was edited in the last is no longer here to lose.
    edited = false;
    // The other tools: nothing of the last world selected, all of it read again.
    ctx.emit('loaded');
    say(text + skippedText(skipped));
    changed();
  }

  /** During a playtest, `what` refused and said, and why returned: Stop would load the world it found over another opened now. */
  function playtestRefuses(what: string): string | null {
    if (ctx.playtest() === 'none') return null;
    const no = `${what}: not now -- ${STOP_FIRST}`;
    say(`${no}.`, true);
    return no;
  }

  function load(key: string): string | null {
    const no = playtestRefuses('Open');
    if (no) return no;
    if (ctx.refuses('Open')) return null;
    const shown = sceneName(key) ?? key;
    unsavedThen(`Open ${shown} in place of it?`, () => {
      // Asked first: the question may have been answered under an Apply's landing, whose world would load over this.
      if (ctx.refuses('Open')) return;
      const file = sceneIfPresent(key);
      if (!file) {
        say(`${key} is not there any more.`, true);
        return drawList();
      }
      const done = loadInto(game, file);
      if ('error' in done) return say(`${key} did not open: ${done.error}.`, true);
      become(key, null, done.skipped, `Opened ${shown}${updatedText(done.updated)}`);
    });
    return null;
  }
  opening = (key) => load(key);

  function newScene(): void {
    if (playtestRefuses('New scene') !== null || ctx.refuses('New scene')) return;
    worldSteps.commit(PENDING);
    const empty = (): void => {
      if (ctx.refuses('New scene')) return;
      // Destroyed the usual way, roots taking their children with them; then the one main camera the game draws through.
      newSceneWorld(game.world);
      become(null, 'New scene', [], 'An empty world but for its Main Camera: Create, on the tree\'s menu, adds to it; Save as… writes it as a scene.');
    };
    // Changes nobody saved: the dialog. Saved, it is in its file -- still asked, on the panel's line: every entity goes.
    if (!history.saved) return unsavedThen('Empty the world for a new scene? Every entity goes.', empty);
    askFirst('Empty the world? Every entity goes.', 'Empty it', empty, true);
  }

  // ---------------------------------------------------------------- the files

  function rename(key: string, label: HTMLElement): void {
    closeAsk();
    const was = sceneName(key) ?? key;
    const form = textEdit({
      value: was,
      commit: (typed) => {
        const made = sceneNameFrom(typed);
        if ('refused' in made) {
          say(`Not renamed: ${made.refused}.`, true);
          return drawList();
        }
        const to = made.name;
        if (to === was) return drawList();
        // Another scene's key: refused. Its own (a case-only rename): the file renamed, the key the same.
        if (caseKey(to) !== key && sceneIfPresent(to)) {
          say(`There is a scene ${sceneName(to) ?? to} already.`, true);
          return drawList();
        }
        void (async () => {
          const cannot = await cannotWrite();
          if (cannot) return say(`Not renamed: ${cannot}.`, true);
          try {
            await api.move(scenePathOf(key), sceneFileOf(to));
          } catch (err) {
            return say(`Not renamed: ${why(err)}.`, true);
          }
          // The open scene, if it was this one, has followed its file already (`onFilesWent`, below).
          say(`Renamed ${was} to ${to}`);
          changed();
        })();
      },
      cancel: drawList,
    });
    label.replaceWith(form);
  }

  async function duplicate(key: string): Promise<void> {
    const file = sceneIfPresent(key);
    if (!file) return;
    const cannot = await cannotWrite();
    if (cannot) return say(`Not duplicated: ${cannot}.`, true);
    const to = freeKey(sceneName(key) ?? key, (k) => sceneIfPresent(k) !== undefined);
    // A copy is never the start scene: one file says so.
    const failed = await put(to, sceneText(file, false), true);
    if (failed) return say(`Not duplicated: ${failed}.`, true);
    say(`Duplicated ${key} as ${to}`);
  }

  function remove(key: string): void {
    askFirst(`Delete ${key}.scene? It goes to the project's trash (.trash/), where the Assets panel's Trash restores it.`, 'Delete', () => {
      void (async () => {
        const cannot = await cannotWrite();
        if (cannot) return say(`Not deleted: ${cannot}.`, true);
        try {
          await api.remove([scenePathOf(key)]);
        } catch (err) {
          return say(`Not deleted: ${why(err)}.`, true);
        }
        // The open scene, if it was this one, has no file now (`onFilesWent`, below).
        say(`Deleted ${key}.scene: in the trash`);
        changed();
      })();
    }, true);
  }

  function reveal(key: string): void {
    if (!ctx.revealAsset(scenePathOf(key))) say('No tool here shows files.', true);
  }

  /** `key` the start scene, or none: its file says `"start": true`, and the one before's no longer does. Null if done, else why not. */
  async function setStart(key: string | null): Promise<string | null> {
    const was = startScene();
    if (was === key) return null;
    const cannot = await cannotWrite();
    if (cannot) {
      drawList();
      say(`Not changed: ${cannot}.`, true);
      return cannot;
    }
    const marks: [string, boolean][] = [...(was !== null ? [[was, false] as [string, boolean]] : []), ...(key !== null ? [[key, true] as [string, boolean]] : [])];
    for (const [k, on] of marks) {
      const file = sceneIfPresent(k);
      if (!file) continue;
      const failed = await put(k, sceneText(file, on), false);
      if (failed) {
        drawList();
        say(`Not changed: ${k}.scene was not written: ${failed}.`, true);
        return `${k}.scene was not written: ${failed}`;
      }
    }
    say(key !== null ? `${key} opens when the page loads, in every build -- its file says "start": true` : 'The game builds its own world when the page loads');
    return null;
  }

  // The agent's scene tools (Docs/mcp.md M2): the buttons' own code, no question -- what nobody saved refused unless discarded.
  /** Whether the world can be put aside for another now (`leave`): an edit under way a step first, then whether anything is dropped. */
  const leaving = (what: string, discard: boolean): { error: string } | { discarded: boolean } =>
    leave(what, discard, () => worldSteps.commit(PENDING), () => ({ playtest: ctx.playtest() !== 'none', prefab: ctx.prefab, holding: ctx.overrides.holding() !== null, saved: history.saved, current }));
  agentScenes = {
    open(key, discard) {
      const left = leaving('Not opened', discard);
      if ('error' in left) return left;
      const file = sceneIfPresent(key);
      if (!file) return { error: `There is no scene ${key}: the scenes are ${sceneKeys().join(', ') || 'none'}` };
      closeAsk();
      const done = loadInto(game, file);
      if ('error' in done) return { error: `${key} did not open: ${done.error}` };
      become(key, null, done.skipped, `Opened ${sceneName(key) ?? key}${updatedText(done.updated)} (Claude)`);
      return { skipped: done.skipped, discarded: left.discarded };
    },
    fresh(discard) {
      const left = leaving('Not emptied', discard);
      if ('error' in left) return left;
      closeAsk();
      newSceneWorld(game.world);
      become(null, 'New scene', [], 'An empty world but for its Main Camera (Claude): Save as… writes it as a scene.');
      return { discarded: left.discarded };
    },
    // Save's own path, a name given (`saving`).
    saveAs: (name) => saveScene(name),
    async importSave(text, name, discard) {
      const left = leaving('Not imported', discard);
      if ('error' in left) return left;
      closeAsk();
      const done = await importText(text, name, ' (Claude)');
      return 'error' in done ? done : { ...done, discarded: left.discarded };
    },
    async start(key) {
      if (key !== null && !sceneIfPresent(key)) return { error: `There is no scene ${key}: the scenes are ${sceneKeys().join(', ') || 'none'}` };
      const failed = await setStart(key);
      if (failed !== null) return { error: `Not changed: ${failed}` };
      drawList();
      return { start: key };
    },
  };

  startPick.addEventListener('change', () => {
    // Let go of, or the next key would pick another rather than reach the editor.
    startPick.blur();
    void setStart(startPick.value === '' ? null : startPick.value);
  });

  // ---------------------------------------------------------------- the browser's scenes, moved into files once

  async function migrate(): Promise<void> {
    let raw: string | null;
    try {
      raw = localStorage.getItem(LEGACY_KEY);
    } catch {
      return;
    }
    const legacy = legacyScenes(raw);
    if (raw === null || (await api.online()) !== 'write') return;
    const plan = migrationPlan(legacy?.scenes.map((s) => s.name) ?? [], (k) => sceneIfPresent(k) !== undefined);
    // The start scene carried over only if none is chosen yet: a file's own word is the newer.
    const startName = startScene() === null ? (legacy?.start ?? null) : null;
    const moved: string[] = [];
    const failed: string[] = [];
    for (const [i, { name, key }] of plan.entries()) {
      const was = await put(key, sceneText(legacy!.scenes[i]!.save, name === startName), true);
      if (was === null) moved.push(name === key ? key : `‘${name}’ as ${key}`);
      else failed.push(`‘${name}’ (${was})`);
    }
    try {
      localStorage.setItem(LEGACY_MOVED, raw);
      localStorage.removeItem(LEGACY_KEY);
    } catch {
      // Storage blocked since: moved again next time, each as -2.
    }
    // The scene open was one of them, by name: now by its key.
    const mine = current === null ? undefined : plan.find((p) => p.name === current);
    if (mine) {
      current = caseKey(mine.key);
      named();
    }
    const text =
      `Moved ${moved.length} scene${moved.length === 1 ? '' : 's'} from this browser into ${SCENES_DIR}/` +
      (moved.length > 0 ? `: ${moved.join(', ')}` : '') +
      (failed.length > 0 ? ` · not moved: ${failed.join(', ')}` : '') +
      ` · the browser's copy kept as ${LEGACY_MOVED}`;
    console.info(`[editor] ${text}`);
    say(text, failed.length > 0);
  }
  void migrate();

  // ---------------------------------------------------------------- import, copy

  function importFile(): void {
    if (playtestRefuses('Import') !== null) return;
    // The picker opens from a click: the question's button is one too.
    unsavedThen('Import a file in place of it?', () => picker.click());
  }

  picker.addEventListener('change', () => {
    const file = picker.files?.[0];
    // Emptied, so the same file picked again is a change again.
    picker.value = '';
    if (file) void read(file);
  });

  /** A save exported before scenes were files: written as a new scene file, named from the file's, and opened. */
  async function read(file: File): Promise<void> {
    const done = await importText(await file.text(), file.name, '');
    if ('error' in done) say(`${done.error}.`, true);
  }

  /**
   * A world save's text written as a new scene file -- named from `from` (a file's name, or the name given), never over
   * another -- then opened: Import…'s and `scene_import`'s one path. `by` follows the line said: '' the person's
   * Import…, whose refusal names no tool; ' (Claude)' `scene_import`'s, whose names the tool to call.
   */
  async function importText(text: string, from: string, by: string): Promise<{ key: string; file: string; skipped: string[] } | { error: string }> {
    let data: unknown;
    try {
      data = JSON.parse(text);
    } catch {
      return { error: `${from} could not be read as JSON: nothing written` };
    }
    const no = whyNotSave(data);
    if (no) return { error: `${from} was not imported: ${no}` };
    const cannot = await cannotWrite();
    if (cannot) return { error: `${from} was not imported: ${cannot}` };
    const name = freeKey(madeSceneName(from.replace(/\.(json|scene)$/i, '')) ?? 'scene', (k) => sceneIfPresent(k) !== undefined);
    const key = caseKey(name);
    const failed = await put(name, sceneText(data as WorldSave, false), true);
    if (failed) return { error: `${from} was not imported: ${failed}` };
    // Read while an Apply landed: its world would load over this one.
    // Said to whoever imported: Claude opens it with its tool, the person from the list -- no tool's name on their line.
    const later = by === '' ? `open it from the list in a moment` : `scene_open it in a moment`;
    if (ctx.refuses('Import')) return { error: `${from} was written as ${sceneFileOf(name)}, but not opened: an Apply is landing -- ${later}` };
    const done = loadInto(game, data as SceneFile);
    if ('error' in done) return { error: `${from} was written as ${sceneFileOf(name)}, but did not open: ${done.error}` };
    become(key, null, done.skipped, `Imported ${from} as ${sceneFileOf(name)}${updatedText(done.updated)}${by}`);
    return { key, file: sceneFileOf(name), skipped: done.skipped };
  }

  async function copy(): Promise<void> {
    worldSteps.commit(PENDING);
    const json = JSON.stringify(sceneSave(game.world));
    try {
      await navigator.clipboard.writeText(json);
      say(`Copied the world as JSON · ${sizeOf(json.length)}`);
    } catch (err) {
      say(`The clipboard refused it: ${why(err)}`, true);
    }
  }

  // The line says saved or not as history moves; and whether there are edits since the save, for leaving the page.
  const unlisten = history.on((event) => {
    if (event === 'push' || event === 'undo' || event === 'redo') moves++;
    // A prefab open over the scene: its moves are the prefab's, not the scene's (`leave-guard.ts`).
    edited = editedAfter(edited, event, history);
    if (seen) refresh();
  });

  /**
   * The open scene's file renamed or moved (`to`): the scene is that file now -- its name in the header, `S`
   * writing it, the resume record holding it; the start mark is in the file, so it goes with it. Gone (null):
   * the world stays as it is, with no file and not saved -- the next `S` asks a name.
   */
  function follow(from: string, to: string | null, how: string): void {
    current = to;
    held = to === null ? undefined : sceneIfPresent(to);
    if (to === null) {
      source = null;
      edited = true;
      history.forgetSaved();
      say(`${from}.scene ${how}: the world is as it was, with no file -- Save as… names it.`);
    } else say(`${from}.scene ${how} ${to}.scene: the open scene is that file now.`);
    changed();
  }

  // A file moved or deleted through the dev server -- on this page, in the Assets panel, by an undo or a redo
  // there: the open scene follows its file. The one place every rename and delete is told.
  const unwent = onFilesWent((went) => {
    if (current === null) return;
    const to = sceneKeyAfter(current, went);
    if (to !== current) follow(current, to, to === null ? 'went' : 'is now');
  });

  // A scene file written, renamed or gone -- here, in the Assets panel, by hand: the list and the times read again.
  const unheard = onSceneFiles(() => {
    // Renamed on disk, outside the editor: its file gone, and a new one with the same text -- now, or in a later
    // burst (a watcher can tell the unlink and the add apart). A file deleted by hand is left as it was: Save writes it again.
    if (current !== null) {
      const file = sceneIfPresent(current);
      if (file) held = file;
      else if (held) {
        const text = JSON.stringify(held);
        const to = sceneKeys().find((k) => !known.has(k) && JSON.stringify(sceneIfPresent(k)) === text);
        if (to !== undefined) follow(current, to, 'was renamed on disk to');
      }
    }
    known = new Set(sceneKeys());
    named();
    if (!seen) return;
    drawList();
    refresh();
    void readStats();
  });

  /**
   * Leaving the page with the world edited since it was saved -- a scene file's or not -- or a prefab open with
   * edits not saved: the browser asks first. The scene's mark is the one put aside under a prefab open (`leave-guard.ts`).
   */
  const guard = (event: BeforeUnloadEvent): void => {
    const state = { passing, edited, sceneSaved: unsavedBeside?.sceneSaved() ?? history.saved, besideUnsaved: unsavedBeside?.beside() === true };
    if (!asksOnLeave(state)) return;
    event.preventDefault();
    // What older browsers need to ask; the text itself is the browser's own.
    event.returnValue = '';
  };
  addEventListener('beforeunload', guard);

  /** "Modified 5 min ago" read again while the panel is shown. */
  let timer: ReturnType<typeof setInterval> | undefined;
  const tick = (): void => {
    for (const time of times) time();
    refresh();
  };

  // Made as the editor first opens: the start scene opened at boot that the game has not run since is as saved.
  named();
  if (openedAs !== null && current === startKey && JSON.stringify(game.world.save()) === openedAs) history.markSaved();
  openedAs = null;
  void readStats();

  return {
    root: panel,
    setVisible(visible) {
      if (!visible) closeAsk();
      seen = visible;
      clearInterval(timer);
      timer = undefined;
      if (!visible) return;
      drawList();
      refresh();
      void readStats();
      timer = setInterval(tick, EVERY);
    },
    // The current scene's line read again: after an edit, an undo, another world.
    refresh() {
      if (seen) refresh();
    },
    // Save, `S`: the current scene written again; with none yet, Save as…
    save,
    // A question is up in the panel: Esc is its "no", not the editor's close.
    holdsEscape: () => ask.open,
    cancel: closeAsk,
    dispose() {
      closeAsk();
      unlisten();
      unwent();
      unheard();
      clearInterval(timer);
      removeEventListener('beforeunload', guard);
      marked = null;
      saving = null;
      opening = null;
      panel.remove();
    },
  };
}
