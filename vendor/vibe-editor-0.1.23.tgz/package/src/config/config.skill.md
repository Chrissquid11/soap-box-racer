---
skill: studio
title: The Config tab, and Claude's settings
when: Before changing your own model, effort or review bar, setting up the export tools (Gladius, ffmpeg …), or when the person points at a page of the Config tab (systems, scenes, physics, preferences, keys, Claude, skills, CLAUDE.md)
covers:
  tools:
    - claude_settings
    - scene_describe
    - scene_list
    - scene_start
    - tools_check
    - tools_set
    - tools_download
order: 70
---
# The Config tab, and Claude's settings

The Config tab (`2`, at the foot of the tool strip) is the project's settings and tables: a tree of pages on the
left, in groups -- **Game**, **Assets**, **Editor**, **Claude**, then the project's own -- and the page chosen
filling the rest. Most of it is the person's own; this page says which parts a tool reaches, and what to do about
the rest.

## The pages, and the tools for each

| Page | What it is | Through the tools |
|---|---|---|
| Game ▸ Systems | every system in the order it runs: its rate, what it reads and writes, its members slot by slot | `scene_describe` reads the same: every prefab, component and system |
| Game ▸ Scenes | the scene files: open, save, rename, duplicate, delete, a new one (empty but for its `Main Camera`), the start scene, Import… of an old world save | `scene_list`, `scene_start`, and the scene page's `scene_open`, `scene_new`, `scene_save_as`, `scene_import` ([the scene](scene.md)); a rename or delete is `asset_move` / `asset_delete` ([the assets](assets.md)) |
| Game ▸ Physics | the project's `physics.json`: physics on or off, gravity, substeps, iterations, sleep, the default material, the layer names and the matrix of which collide, the stats while it runs | `physics_state` reads it, `physics_settings_set` writes it ([physics](physics.md)) |
| Assets ▸ Tools | the tools exports need (Gladius, ffmpeg, Git LFS …), their paths, Check again, Download ffmpeg | `tools_check`, `tools_set`, `tools_download` (below) |
| Editor ▸ Preferences | snapping, the 3D views' keymap -- Industry Compatible (the default: Alt+left-drag orbits, Alt+middle pans, Alt+right zooms, W E R the gizmo, F1-F4 the views, A frames all) or Blender's (middle-drag orbits, G R S, the numpad, Home) -- and navigation (Blender's preferences) and scrolling, "After a playtest" … | the person's; read for what it decides -- `play_stop` with no `keep` follows "After a playtest" ([play](play.md)) |
| Editor ▸ Game view | the game view's presets -- Free Aspect, the built-ins, the project's own, each its size, mode (Fit, Pixel, Stretch) and filter -- that the play strip's dropdown previews a playtest at | `game_view_state` reads them, `game_view_preset` adds, changes, moves and removes the project's, `game_view_set` chooses one ([play](play.md)) |
| Editor ▸ Keys | every key the editor has, live or not (`?` shows the live ones) | read-only for everyone |
| Claude ▸ Settings | your model, effort, review bar; the permission level; Fix a failed boot; Outside clients | `claude_settings`: model, effort and review; the rest is the person's |
| Claude ▸ Skills | the skills you load here: the project's, the engine's (the vibe plugin's, and `engine` and `studio` as vibe sync wrote them, from which packages), the person's | a project skill is a file: write `.claude/skills/<name>/SKILL.md` with Write when asked |
| Claude ▸ CLAUDE.md | the project's `CLAUDE.md` | a file: Edit it when asked |

A project's own Config pages (its `src/tools/`) are its own; a project tool's page in this skill says what reaches
them.

## The game's own words: `scene_describe`

`scene_describe` answers what the Systems page shows and more: every prefab, every component with its fields, every
system with its rate and data. Read it before naming a component or a system, and to see what runs and how often.

## Scenes

- **`scene_list`** -- the scene files under `src/assets/scenes/`: each its key (what `scene_open` takes), file,
  whether the game starts on it, and which is open in the studio with changes nobody saved.
- **`scene_start`** -- the scene the game opens on start, in every build (the Scenes page's pick): `key`, a scene's
  key (`scene_list` gives them), or `null` for the game's own world. That file says `"start": true`, the one before
  no longer does. It changes the game for everyone
  who runs it -- set it when asked.
- To open, save, save as or start a new scene, the [scene page](scene.md) has the tools and their refusals (a world
  with unsaved changes is never replaced without `discard: true`, which asks).

## The export tools: `tools_check`, `tools_set`, `tools_download`

An export runs programs on this machine -- Gladius for a `.lua` model, ffmpeg for sound and video, Blender for a
`.blend`, Git LFS -- and a source waits, `missing` its tool, until there is one (`asset_info` says which).

- **`tools_check`** -- Check again: every tool looked for again, each its state (found, missing, lacking), version,
  path and what to do; what can now be made is queued. Read it first, and after a tool was installed.
- **`tools_set`** -- a tool's path (`tool`, `path`), kept in the project's local file, never committed; `''` forgets
  it. It asks the person, at every level: the dev server will run that program. Set one the person named, or one
  `tools_check`'s hint points at -- never a guess.
- **`tools_download`** -- `tool: 'ffmpeg'`: a static build for this machine, its checksum checked, its path set. A
  job (`job_wait`). It asks the person, at every level: a program from the internet.

## Claude's settings: `claude_settings`

Your own settings in this conversation, as the settings chip under the person's prompt box (in Claude's column) and
Config ▸ Claude ▸ Settings show them.

- **Read**: call it with nothing -- the model, the effort, the review bar and the permission level, with the
  choices: each model's value and label with its effort levels, and the review bars.
- **Set** any of: `model` (a model's `value` from that list; `"default"` or null for the CLI's own), `effort` (one
  of that model's levels; null for the default), `review` -- `none`, or the score a separate critic's review of
  each turn must reach: `ok`, `good`, `very-good`, `excellent`, `perfect`. Each change is a line in the person's
  transcript ("Claude set the model to …"), and the answer gives the settings after.
- A model with no such effort drops the effort, said. An effort that is no level of the model is refused, nothing
  changed.
- **Never the permission level** (Ask, Auto, Unsafe auto): it is read, never set, by any tool -- the person's alone.
  So are Fix a failed boot and Outside clients (what an outside MCP client may do).

Change your settings when the person asks, or when the job plainly wants it and you say so -- a bigger model for a
hard bug, a review bar for a change that must be right. Never to get past something the person set.

## Refusals, and what they mean

| The answer says | What to do |
|---|---|
| Not changed: … is not an effort level of this model | pick one from the model's levels in the read |
| Claude's settings are not reachable from here | they are the studio panel's Claude's alone: an outside client is never offered the tool |
| There is no component called … (from another tool) | `scene_describe` lists what there is |

## A job, end to end

"This bug is nasty -- think harder, and have it reviewed before you finish."

1. `claude_settings` with nothing -- the model and its effort levels, the bars, the level (Auto).
2. `claude_settings` with `effort: 'high'` (one the model lists) and `review: 'very-good'` -- two lines in the
   transcript; the answer has the settings after.
3. Say what you set, and that the permission level stays theirs.

## Rules that bite

- The permission level, Outside clients and Fix a failed boot are the person's: no tool sets them, and no
  workaround should.
- Preferences and keys are the person's: read them for what they decide, never write their files.
- Skills and `CLAUDE.md` are files you write with Write and Edit -- only when asked: they steer every later turn.
