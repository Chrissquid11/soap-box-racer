/**
 * World edits held while an Apply, or its undo or redo, lands
 * (`OverrideSteps.holding`; Docs/prefabs.md §7): its world is loaded once its
 * files compile, so anything that changed the world or its history meanwhile
 * would be loaded over -- or, a step, drop the Apply from redo. Held at the
 * three ways in, each in one place, so a key or a card added later is held
 * too unless it says it only looks. **This is the one list** of what is held;
 * `overrides-steps.ts` and Docs/prefabs.md §7 point here.
 *
 * - **Every key** (`key`): each MrDebug action the editor registers -- the
 *   host's and every tool's (`editor.ts`' `addKey`, `ctx.keys.add`) -- is
 *   wrapped: while held, its run is refused and said ("Playtest: not now --
 *   Undoing the Apply: a moment"), the key still taken: T (playtest), Mod+S, Z,
 *   Y, Alt+↑ and Esc (Back), the tools' -- Delete, Duplicate, Paste, the
 *   switches, Save as prefab, the Assets tool's file keys. Free only what
 *   changes neither: the tool strip, the cards, H, ?, Home, Esc that closes a
 *   card, menu or question, the camera, the gizmo's mode, the selection, the
 *   agent's prompt box (`free`, `ToolKey.view`).
 * - **Every press on the editor's cards** (`pointer`, capturing on the
 *   root): a press, a click -- the keyboard's too, Enter or Space on a button
 *   -- a double-click, a right-click, a drag begun or a file dropped: the top
 *   bar's Save, Playtest, Undo, Redo and Close, an opened prefab's Save, Back
 *   and Back's question, the tree and its menu, the inspector (its marks'
 *   menus, the Overrides list's Revert, Apply, Unpack), the Create menu, the
 *   Scenes tool's Load, New, Import, Save, the Assets tool's files, sheet and
 *   menus, the Systems tool's table, the History card's rows -- stopped there
 *   and said; free only `FREE`: the tool strip (`.ed-tools`), the agent's card
 *   and the top bar's AI button that shows or hides it (`.ed-ai`),
 *   the top bar's middle -- the gizmo, History, Keys, the status line
 *   (`.ed-hint`) -- the keys card, a panel's tab and grip, and the modal dialog
 *   (`.ed-dialog-backdrop`: its keys are never held either, and what its answers
 *   do asks `refuses` itself). The cards stay where they
 *   are, dimmed (`.ed-held`, a progress cursor), and nothing reaches the
 *   scene behind them.
 * - **Every whole-world entry point** (`refuses`, `ctx.refuses`), asked first
 *   by each, whichever way it is reached: a playtest begun, Save (the
 *   scene's, a prefab's, the agent's), Back from a prefab and opening one,
 *   closing the editor (boot's `P` too), a travel in the History card, the
 *   agent's row Undo and Undo this turn -- refused whole, its files too, the
 *   preview left up with the line (`transcript.ts`) -- a scene loaded,
 *   emptied, imported or saved, Save as prefab's question answered (one asked
 *   before the hold began); every paste -- the key, the button, the browser's
 *   own paste event (`edits.ts`' `pasteClip`), "Not pasted"; Spawn and a
 *   prefab dropped, "Not placed"; Revert, Unpack and another Apply throw
 *   (`overrides-steps.ts`' `revert`, `unpack`, `apply`).
 *
 * **What waits instead**, then runs: the agent's editor tools that change the
 * world or save it (`mcp/page.ts`' `WAITS`; one that waited for an undo
 * runs after it, a new step, so it says that the Apply is no longer to redo);
 * a prefab renamed in the Assets tool, whose world is renamed once nothing
 * lands (`renamePrefabInWorld`); every stack's Undo, the Assets tool's too
 * (`active-history.ts`' `worldBusy`). The gizmo is off the selection
 * (`viewport`'s `held`); a typed field keeps its focus and refuses what is
 * typed (`editor.ts`' `beforeinput`). A reload meanwhile keeps the world the
 * landing puts back once its files are written (`landingTo`), and an Apply
 * whose undo or redo could not land is told to it (`notes`). Another prefab's
 * live update is held with the landing's and brought up to as the world is
 * put back. The "not now" line goes with the hold (`holdEdits(null)`).
 * Anything that gets through all of these is put back as it is committed
 * (`world-steps.ts`' guard): never a step. Pure: node tests it with
 * stand-ins (`hold.test.ts`).
 */

/** The cards a press is never held on: they change neither the world nor its history. */
export const FREE = '.ed-tools, .ed-ag, .ed-ai, .ed-hint, .ed-keys-card, .ed-tab, .ed-grip, .ed-dialog-backdrop';

/** The presses held on the other cards, capturing on the editor's root. */
export const PRESSES = ['pointerdown', 'mousedown', 'click', 'dblclick', 'auxclick', 'contextmenu', 'dragstart', 'drop'] as const;

/** The presses that are said: one line a click, not three. */
const SAID = new Set(['click', 'contextmenu', 'drop']);

/** What `pointer` needs of an event: a DOM event, or a node test's stand-in. */
export interface HeldEvent {
  readonly type: string;
  readonly target: unknown;
  preventDefault(): void;
  stopImmediatePropagation(): void;
}

export interface HoldOptions {
  /** What a world edit is refused with just now (`OverrideSteps.holding`), or null. */
  line(): string | null;
  /** The editor's line. */
  say(line: string): void;
  /** The editor's root: a press outside it is never its business. */
  inside?(target: unknown): boolean;
}

export interface Hold {
  /** Held just now? `what` refused and said -- "Playtest: not now -- Undoing the Apply: a moment" -- true; else false. */
  refuses(what: string): boolean;
  /** `action` with its run held: refused and said while held, unless it only looks (`free`). The key is still taken. */
  key<A extends { name: string; run(): void }>(action: A, free: boolean): A;
  /** A press on the editor: stopped, and said, if held and not on a free card. True if it was. */
  pointer(event: HeldEvent): boolean;
}

/** The action's name as a person reads it: `editor: save as prefab` is "Save as prefab". */
const named = (name: string): string => {
  const bare = name.replace(/^editor: /, '');
  return bare.charAt(0).toUpperCase() + bare.slice(1);
};

/** Does `target` sit in an element matching `selector`? An element's `closest`, else no. */
const within = (target: unknown, selector: string): boolean => {
  const t = target as { closest?: (s: string) => unknown } | null;
  return typeof t?.closest === 'function' && t.closest(selector) != null;
};

export function createHold({ line, say, inside }: HoldOptions): Hold {
  const refuses = (what: string): boolean => {
    const held = line();
    if (held === null) return false;
    say(`${what}: not now -- ${held}`);
    return true;
  };
  return {
    refuses,
    key(action, free) {
      if (free) return action;
      const run = action.run;
      return { ...action, run: () => void (refuses(named(action.name)) || run()) };
    },
    pointer(event) {
      if (line() === null) return false;
      if (inside && !inside(event.target)) return false;
      if (within(event.target, FREE)) return false;
      event.preventDefault();
      event.stopImmediatePropagation();
      if (SAID.has(event.type)) say(`Not now -- ${line()}`);
      return true;
    },
  };
}
