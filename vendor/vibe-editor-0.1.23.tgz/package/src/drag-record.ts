/**
 * What is being dragged in the page, known during the drag (Docs/properties.md D7): one record, set at a
 * drag's start, cleared at its end or its drop -- so every field can say, while the drag is under way, whether
 * it would take it and, if not, why. A browser lets a page read a drag's data only on the drop; this is the
 * editor's own drags' answer. The MIME types stay for anything outside the page (the Assets panel's, the tree's).
 *
 * - **What a drag carries** (`DragRecord`): entities -- tree rows, one or several; a component -- a block's
 *   header in the inspector, that entity as the component; assets -- the Assets panel's files, each its key and
 *   its kind (`null` for a file that is no key).
 * - **Where it may land** (`DropField`): a ref field (`ref()`, `ref(Health, …)`: the components it needs); a
 *   key field of a kind; a relation's "Link to…".
 * - **`fits(field, record, facts)`**: what a drop would set -- the entity, the key, the entities to link -- or
 *   why it would not, in the words the field shows dimmed and the notice says. `facts` is what of the world it
 *   asks (is it alive, what has it, its name), so node tests it (`drag-record.test.ts`).
 *
 * The record itself (`startDrag`, `endDrag`, `dragging`) is the module's: one drag at a time in a page. The
 * lighting is `drop-target.ts`'s, over the page.
 */
import { label, refMisfit, refTakes, type Entity, type World } from '@vibe/engine';

/** What a drag in the page carries. */
export type DragRecord =
  | { readonly what: 'entities'; readonly entities: readonly Entity[] }
  | { readonly what: 'component'; readonly entity: Entity; readonly component: string }
  | { readonly what: 'assets'; readonly files: readonly ({ readonly kind: string; readonly key: string } | null)[] };

/** What a drop lands on. */
export type DropField =
  /** A `ref()` field: `needs` the components (by name) an entity must have. */
  | { readonly kind: 'ref'; readonly needs?: readonly string[] }
  /** A `key(kind)` field: `keyKind` the key type (`Model`, `Texture` …). */
  | { readonly kind: 'key'; readonly keyKind: string }
  /** A relation's "Link to…": each entity dropped a link's target. */
  | { readonly kind: 'link'; readonly relation: string };

/** What `fits` asks of the world. */
export interface DragFacts {
  alive(e: Entity): boolean;
  /** Does `e` have the component of this name? */
  has(e: Entity, component: string): boolean;
  /** How `e` is called: its label. */
  name(e: Entity): string;
}

/** `world`'s facts, as `fits` asks them: a component by its name, an entity by its label. */
export function factsOf(world: World): DragFacts {
  return {
    alive: (e) => e !== 0 && world.alive(e),
    has: (e, name) => {
      const c = world.allComponents.find((x) => x.name === name);
      return c !== undefined && world.has(e, c);
    },
    name: (e) => label(world, e),
  };
}

/** What a drop would do, or why it would not. */
export type Fit =
  | { readonly ok: true; readonly entity: Entity }
  | { readonly ok: true; readonly key: string }
  | { readonly ok: true; readonly entities: readonly Entity[] }
  | { readonly ok: false; readonly why: string };

const no = (why: string): Fit => ({ ok: false, why });

/** A key type as a person says it: `Model` "a model", `UiSfx` "a ui sfx". */
const aKind = (kind: string): string => {
  const words = kind.replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase();
  return `${/^[aeio]/.test(words) ? 'an' : 'a'} ${words}`;
};

/** Does a drag of `record` fit `field`: what it would set, or why not. */
export function fits(field: DropField, record: DragRecord, facts: DragFacts): Fit {
  if (field.kind === 'key') {
    if (record.what !== 'assets') return no(`${aKind(field.keyKind)}, not ${record.what === 'component' ? 'a component' : 'an entity'}`);
    const files = record.files;
    if (files.length === 0) return no('nothing dragged');
    const other = files.find((f) => f === null || f.kind !== field.keyKind);
    if (other === null) return no(`${aKind(field.keyKind)}: that file is no asset a field holds`);
    if (other !== undefined) return no(`${aKind(field.keyKind)}, not ${aKind(other.kind)}`);
    if (files.length > 1) return no(`one ${aKind(field.keyKind).replace(/^an? /, '')} at a time`);
    return { ok: true, key: files[0]!.key };
  }
  if (record.what === 'assets') return no(`${field.kind === 'ref' ? refTakes(field) : 'an entity to link to'}, not an asset`);
  if (field.kind === 'link') {
    const entities = record.what === 'entities' ? record.entities : [record.entity];
    const living = entities.filter((e) => facts.alive(e));
    if (living.length === 0) return no('it is gone');
    return { ok: true, entities: living };
  }
  // A ref: one entity, alive, with what it needs. A component's header is its entity, as that entity's row would be:
  // what the entity has decides, not which header was dragged (Docs/properties.md D4).
  let e: Entity;
  if (record.what === 'component') e = record.entity;
  else {
    if (record.entities.length !== 1) return no(`one entity at a time: ${record.entities.length} dragged`);
    e = record.entities[0]!;
  }
  if (!facts.alive(e)) return no('it is gone');
  const why = refMisfit(field, (c) => facts.has(e, c), facts.name(e));
  return why === null ? { ok: true, entity: e } : no(why);
}

/** What a drop on a list would add: each element, an entity or a key -- or why not. */
export type ManyFit = { readonly ok: true; readonly items: readonly (Entity | string)[] } | { readonly ok: false; readonly why: string };

/**
 * Does a drag of `record` fit a list whose element is `element` (a ref, a key), `room` more at most: every one dragged
 * an element -- several rows, several assets -- or why not (the first that does not fit, or too many). A component's
 * header is its entity, one.
 */
export function fitsMany(element: DropField, record: DragRecord, facts: DragFacts, room = Infinity): ManyFit {
  const each: DragRecord[] = record.what === 'entities' ? record.entities.map((e) => ({ what: 'entities', entities: [e] }))
    : record.what === 'assets' ? record.files.map((f) => ({ what: 'assets', files: [f] }))
      : [record];
  if (each.length === 0) return { ok: false, why: 'nothing dragged' };
  if (each.length > room) return { ok: false, why: room <= 0 ? 'the list is full: at its most' : `room for ${room} more, and ${each.length} dragged` };
  const items: (Entity | string)[] = [];
  for (const one of each) {
    const fit = fits(element, one, facts);
    if (!fit.ok) return { ok: false, why: each.length > 1 ? `not all fit -- ${fit.why}` : fit.why };
    if ('entity' in fit) items.push(fit.entity);
    else if ('key' in fit) items.push(fit.key);
  }
  return { ok: true, items };
}

/** The whole of `fits`' answer as a line: null for a fit, the reason otherwise. */
export const misfit = (fit: Fit): string | null => (fit.ok ? null : fit.why);

// ---------------------------------------------------------------- the record

let current: DragRecord | null = null;
const listeners = new Set<(record: DragRecord | null) => void>();

/** A drag in the page began: what it carries, said to whoever listens (the lighting). */
export function startDrag(record: DragRecord): void {
  current = record;
  for (const l of listeners) l(current);
}

/** The drag ended -- dropped, or let go anywhere. */
export function endDrag(): void {
  if (current === null) return;
  current = null;
  for (const l of listeners) l(null);
}

/** What is being dragged in the page now, or null. */
export const dragging = (): DragRecord | null => current;

/** Told of every drag's start (its record) and end (null). Returns the way to stop. */
export function onDrag(listener: (record: DragRecord | null) => void): () => void {
  listeners.add(listener);
  return () => void listeners.delete(listener);
}
