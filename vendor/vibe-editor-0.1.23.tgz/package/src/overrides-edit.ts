/**
 * What a designer sees and does with an instance's overrides (Docs/prefabs.md
 * §7, §9): each difference as one item -- a field, a
 * component added or removed, a switch, the layer, a name, an object's data,
 * a ref, a parent, a link's data, an entity removed or added -- and what
 * Revert, Apply and Unpack do with them. Pure but for the world handed in:
 * node tests it (`overrides-edit.test.ts`); the editor wraps each in a step
 * (`overrides-steps.ts`).
 *
 * - **Items come from `overridesOf`** (`src/ecs/overrides.ts`), worked out
 *   each time they are asked for, never kept: so they are never stale after
 *   an undo, a live update or a recompile. Where the root stands -- its
 *   position, its rotation -- and its name are no items: every instance placed
 *   differs there, as in Unity, and Apply would move the prefab.
 * - **Revert is the world alone**: the instance fitted to its prefab with the
 *   item left out of its overrides (`fitInstance`), an added entity
 *   destroyed. No file.
 * - **Apply writes the target prefab's file through the writer**
 *   (`clipToPrefab`, in the file's own layout): a fresh instance of the
 *   target in a scratch world, the item put on it from the live entity, copied
 *   out and written back as the opened mode's Save writes -- so a field
 *   applied is a line changed in git, and every kind of difference is written
 *   as the writer writes it. An inner prefab's entity is that file's own data;
 *   an outer prefab holds it as an override of the instance it nests. What
 *   the writer says it cannot keep (`notes`) refuses the Apply, naming it.
 * - **Applied to an inner prefab, it is taken out of each prefab between**:
 *   an override of the same thing there would win over the inner file, and
 *   the Apply would change nothing anyone sees -- as Unity does.
 * - **Unpack**: the instance's `Instance` rows cleared, nothing else changed;
 *   one level leaves each instance it nests an instance of its own prefab
 *   (`completely`: every entity plain).
 */
import { type AnyComponent, compiledPrefab, pathList, dataDefault, dataPlain, type DataComponentOf, fromPlain, isData, mapRefs, NO_REF, type CompiledPrefab, type Component, fieldPlain, fieldValue, fileFieldOf, type Entity, type EntityRef, fitInstance, Hierarchy, Instance, isOutsideRef, keyKindOf, keyText, Loop, Name, NONE, type Override, overrideList, overridesOf, pathInOwner, type PrefabFile, type PrefabOwner, resolveRef, Transform, untypedPrefab as prefab, World } from '@vibe/engine';
import { prefabText } from './assets/ui/prefab-steps.ts';
import { copyOut, pasteIn } from './clip.ts';
import { eulerDegrees, eulerNear, type Quat } from './gesture.ts';
import { clipToPrefab, ownersOf, tidy } from './prefab-write.ts';

/**
 * One thing an instance changed, as a person settles it. A rotation is one
 * thing, not its quaternion's four numbers: `Transform.rotation`, its `fields`
 * the four, settled together, and the `axes` of its angles in degrees that
 * differ -- what the inspector marks and the list shows.
 */
export type Part =
  | { kind: 'set'; component: string; field: string; fields?: readonly string[]; axes?: readonly Turned[] }
  | { kind: 'refs'; component: string; field: string }
  | { kind: 'add' | 'remove' | 'off' | 'on' | 'objects'; component: string }
  /** A data component's top-level field, overridden whole (D9): a list replaced, not merged. */
  | { kind: 'objects'; component: string; field: string }
  | { kind: 'layer' | 'name' | 'parent' | 'removed' | 'added' }
  | { kind: 'links'; relation: string; to: string };

export interface Item {
  /** The entity of the prefab it is at, by its node's path (`''` the root); for `added`, the one it was put under. */
  path: string;
  /** The entity changed, or added; NONE for one removed. */
  entity: Entity;
  part: Part;
  /** The prefabs whose file could hold it, innermost first. */
  owners: readonly string[];
  /** Why none can, where `owners` is empty: a ref to an entity outside the instance, which only the scene holds. */
  why?: string;
  /** Its handle, as the agent names it: `Transform.px`, `+Spin`, `-Glow`, `off Spin`, `layer`, `removed`, `added #12`. */
  what: string;
  /** What the prefab gives, and what the instance has, in words. */
  was: string;
  now: string;
}

export interface InstanceItems {
  root: Entity;
  prefab: CompiledPrefab;
  items: Item[];
  /** What no override can say (a new link, a ref out of the instance): said, never an item. */
  notes: string[];
}

/** An axis of a rotation in degrees (Euler, XYZ, as the inspector shows it): the prefab's angle and the instance's. */
export interface Turned {
  axis: 'x' | 'y' | 'z';
  was: number;
  now: number;
}

/** The root's own placing -- where it stands, which way it faces -- and its name: every instance's, never an item. */
const PLACING = new Set(['px', 'py', 'pz', 'qx', 'qy', 'qz', 'qw']);
/** A `Transform`'s rotation, the four numbers one item. */
const QUAT = ['qx', 'qy', 'qz', 'qw'] as const;
/** What a `set` part writes: its fields, or its one. */
export const setFields = (part: { field: string; fields?: readonly string[] }): readonly string[] => part.fields ?? [part.field];
/** An angle as the list shows it: to a hundredth of a degree, no float tail. */
export const shownAngle = (v: number): string => String(Math.round(v * 100) / 100 || 0);

const componentNamed = (world: World, name: string): AnyComponent | undefined => world.allComponents.find((c) => c.name === name);

/** A node's value of a field as the compile makes it: its own, or the field's default. */
export function nodeValue(p: CompiledPrefab, c: Component, field: number, node: number): number {
  for (const run of p.full) {
    if (run.component !== c.id || run.field !== field) continue;
    for (let j = 0; j < run.node.length; j++) if (run.node[j] === node) return run.value[j]!;
  }
  return c.fields[field]!.initial;
}

const shownNumber = (v: number, type: string): string => String(tidy(v, type));
const short = (v: unknown): string => {
  const s = JSON.stringify(v) ?? 'nothing';
  return s.length > 60 ? `${s.slice(0, 59)}…` : s;
};

/** `e`'s path in its instance (`''` the root), or null for one not of it. */
function pathIn(world: World, p: CompiledPrefab, root: Entity, e: Entity): string | null {
  if (e === NONE || !world.alive(e) || world.instanceRoot(e) !== root) return null;
  return p.paths[world.nodeOf(e)] ?? null;
}

const named = (world: World, e: Entity): string => {
  const names = (world.rawStore(Name) as { value: (string | null)[] }).value;
  return world.has(e, Name) && names[e] ? names[e]! : `#${e}`;
};

/**
 * Every difference of instance `root` from its prefab as compiled now, an item
 * each, in node order then the entities added -- the root's placing and name
 * left out. Null for no instance's root.
 */
export function itemsOf(world: World, root: Entity): InstanceItems | null {
  const found = overridesOf(world, root);
  if (!found) return null;
  const p = found.prefab;
  const items: Item[] = [];
  const at = (path: string): number => p.paths.indexOf(path);
  for (const d of found.differences) {
    const o = d.override;
    const n = at(d.path);
    const e = d.entity;
    const push = (part: Part, what: string, was: string, now: string): void => void items.push({ path: d.path, entity: e, part, owners: d.owners, ...(d.why !== undefined ? { why: d.why } : {}), what, was, now });
    for (const cn of o.add ?? []) push({ kind: 'add', component: cn }, `+${cn}`, 'without it', 'added');
    for (const cn of o.remove ?? []) push({ kind: 'remove', component: cn }, `-${cn}`, 'with it', 'removed');
    for (const [cn, fields] of Object.entries(o.set ?? {})) {
      const c = componentNamed(world, cn);
      // A rotation: one item, where its first number is, its angles in degrees -- the axes that differ, as the inspector shows them.
      const rotation = (): void => {
        const fi = QUAT.map((f) => Transform.fields.findIndex((x) => x.name === f));
        const has = p.kinds[n]!.components.includes(Transform);
        const was = eulerDegrees(fi.map((i) => (has ? nodeValue(p, Transform, i, n) : Transform.fields[i]!.initial)) as Quat);
        const t = world.rawStore(Transform) as Columns;
        const now = eulerNear(QUAT.map((f) => t[f]![e]!) as Quat, was);
        const all = (['x', 'y', 'z'] as const).map((axis, i): Turned => ({ axis, was: was[i]!, now: now[i]! }));
        const differ = all.filter((a) => shownAngle(a.was) !== shownAngle(a.now));
        const axes = differ.length > 0 ? differ : all;
        push({ kind: 'set', component: cn, field: 'rotation', fields: QUAT, axes }, `${cn}.rotation`,
          axes.map((a) => `${a.axis} ${shownAngle(a.was)}°`).join(', '), axes.map((a) => `${a.axis} ${shownAngle(a.now)}°`).join(', '));
      };
      let turned = false;
      for (const [f, v] of Object.entries(fields)) {
        if (c === Transform && d.path === '' && PLACING.has(f)) continue;
        if (c === Transform && (QUAT as readonly string[]).includes(f)) {
          if (!turned) rotation();
          turned = true;
          continue;
        }
        // A vector (`dir: [x, y, z]`): one item over its columns, both sides its numbers. An enum, flags, a colour with
        // alpha: both sides as a person reads them (`fieldPlain`), the override holding the name.
        const ff = c?.kind === 'data' ? fileFieldOf(c, f) : undefined;
        if (ff && ff.name === f && (ff.field.vec !== undefined || ff.field.enum || ff.field.flags || ff.field.alpha)) {
          const data = c as Component;
          const has = p.kinds[n]!.components.includes(data);
          const then = (column: string): number => (has ? nodeValue(p, data, data.fields.findIndex((x) => x.name === column), n) : data.fields.find((x) => x.name === column)!.initial);
          if (ff.field.vec !== undefined) {
            const columns = ff.columns.map((x) => x.name);
            push({ kind: 'set', component: cn, field: f, fields: columns }, `${cn}.${f}`, columns.map((x) => shownNumber(then(x), ff.field.type)).join(', '), Array.isArray(v) ? (v as number[]).map((x) => shownNumber(x, ff.field.type)).join(', ') : String(v));
          } else {
            const now = fieldValue(data, f, v);
            push({ kind: 'set', component: cn, field: f }, `${cn}.${f}`, String(fieldPlain(data, f, then(f))) || 'none', now === null ? String(v) : String(fieldPlain(data, f, now)) || 'none');
          }
          continue;
        }
        const fi = c?.kind === 'data' ? c.fields.findIndex((x) => x.name === f) : -1;
        const type = fi >= 0 ? (c as Component).fields[fi]!.type : 'f64';
        const has = fi >= 0 && p.kinds[n]!.components.includes(c!);
        // A key field (`Render.model`): the key's text both sides -- the override holds a reference (`{ uid, key }`, or the
        // key), shown as the key it resolves to now, by its uid first as `fieldValue` reads it (a moved asset's key now,
        // not the one the file still says); the compile the id.
        const kind = fi >= 0 ? keyKindOf(c as Component, f) : null;
        if (kind !== null) {
          const was = has ? keyText(kind, nodeValue(p, c as Component, fi, n)) || 'none' : 'none';
          const now = typeof v === 'number' ? keyText(kind, v) || 'none' : resolveRef(kind, v) || 'none';
          push({ kind: 'set', component: cn, field: f }, `${cn}.${f}`, was, now);
          continue;
        }
        push({ kind: 'set', component: cn, field: f }, `${cn}.${f}`, has ? shownNumber(nodeValue(p, c as Component, fi, n), type) : 'none', shownNumber(Number(v), type));
      }
    }
    for (const cn of o.off ?? []) push({ kind: 'off', component: cn }, `off ${cn}`, 'on', 'off');
    for (const cn of o.on ?? []) push({ kind: 'on', component: cn }, `on ${cn}`, 'off', 'on');
    if (o.layer !== undefined) push({ kind: 'layer' }, 'layer', String(p.layers[n] ?? 0), String(o.layer));
    if (o.name !== undefined && d.path !== '') push({ kind: 'name' }, 'name', p.names[n] ?? 'none', o.name);
    for (const [cn, data] of Object.entries(o.objects ?? {})) {
      const c = componentNamed(world, cn);
      // A data component: an item a top-level field (D9), both sides as a file writes them.
      if (isData(c) && typeof data === 'object' && data !== null) {
        const then = p.objects.find((x) => x.component === c && x.node === n)?.data as Record<string, unknown> | undefined;
        for (const [f, v] of Object.entries(data)) {
          const el = c.data[f];
          if (!el) continue;
          // Both sides as an override writes a ref: a path inside the instance, a list (`[]` its root).
          const was = then && f in then ? mapRefs(el, then[f], (r) => (typeof r === 'number' ? pathList(p.paths[r]!) : r)) : dataPlain(el, dataDefault(el), () => null);
          push({ kind: 'objects', component: cn, field: f }, `${cn}.${f}`, short(was), short(v));
        }
        continue;
      }
      push({ kind: 'objects', component: cn }, cn, 'as the prefab', short(data));
    }
    for (const [cn, fields] of Object.entries(o.refs ?? {})) {
      // Inside the instance by its path; nobody; or an entity of the scene outside it, by its name (Docs/prefabs.md §2).
      for (const [f, path] of Object.entries(fields)) {
        const now = path === null ? 'nobody' : isOutsideRef(path) ? `${world.alive(path.entity as Entity) ? named(world, path.entity as Entity) : 'gone'} (outside)` : (path.join('/') || 'its root');
        push({ kind: 'refs', component: cn, field: f }, `${cn}.${f}`, 'as the prefab', `→ ${now}`);
      }
    }
    if (o.parent !== undefined) push({ kind: 'parent' }, 'parent', `under ${p.paths[p.parents[n]!] || 'its root'}`, `under ${o.parent.join('/') || 'its root'}`);
    for (const l of o.links ?? []) {
      const to = l.to.join('/');
      push({ kind: 'links', relation: l.relation, to }, `${l.relation} → ${to || 'its root'}`, 'as the prefab', short(l.set));
    }
  }
  for (const path of found.removed) {
    const n = at(path);
    // Not the prefab whose own root it is: no prefab removes its own root.
    items.push({ path, entity: NONE, part: { kind: 'removed' }, owners: (p.owners[n] ?? []).filter((x) => x.at !== path).map((x) => x.key), what: 'removed', was: p.names[n] ?? path, now: 'gone' });
  }
  const tree = world.rawStore(Hierarchy) as { parent: { [i: number]: number } };
  for (const e of found.added) {
    const under = tree.parent[e]! as Entity;
    const path = pathIn(world, p, root, under) ?? '';
    items.push({ path, entity: e, part: { kind: 'added' }, owners: (p.owners[at(path)] ?? []).map((x) => x.key), what: `added #${e}`, was: 'none', now: named(world, e) });
  }
  return { root, prefab: p, items, notes: found.notes };
}

/** Is `item` the same one as `other`: at the same entity of the prefab, about the same thing? */
export const sameItem = (a: Item, b: Item): boolean => a.path === b.path && a.what === b.what && (a.part.kind !== 'added' || a.entity === b.entity);

/** The items of `e` itself in `all` -- an entity's own marks; for an instance's root, its removed and added too. */
export function itemsAt(world: World, all: InstanceItems, e: Entity): Item[] {
  const path = pathIn(world, all.prefab, all.root, e);
  if (path === null) return all.items.filter((i) => i.part.kind === 'added' && i.entity === e);
  return all.items.filter((i) => (i.part.kind === 'added' ? i.path === path : i.path === path && i.part.kind !== 'removed') || (e === all.root && i.part.kind === 'removed'));
}

// ---------------------------------------------------------------- revert

/** `list` without what `item` says: the override at its path less that part. */
function without(list: Override[], item: Item): Override[] {
  const part = item.part;
  return list.flatMap((o0): Override[] => {
    if (o0.at.join('/') !== item.path) return [o0];
    const o: Override = structuredClone(o0);
    const cut = <T>(xs: T[] | undefined, x: T): T[] | undefined => {
      const left = xs?.filter((y) => y !== x);
      return left && left.length > 0 ? left : undefined;
    };
    switch (part.kind) {
      case 'set':
        if (o.set?.[part.component]) {
          // A vector's columns, and its entry in the file (`dir: [x, y, z]`).
          for (const f of [...setFields(part), part.field]) delete o.set[part.component]![f];
          if (Object.keys(o.set[part.component]!).length === 0) delete o.set[part.component];
        }
        break;
      case 'refs':
        if (o.refs?.[part.component]) {
          delete o.refs[part.component]![part.field];
          if (Object.keys(o.refs[part.component]!).length === 0) delete o.refs[part.component];
        }
        break;
      case 'add':
        o.add = cut(o.add, part.component);
        if (o.set) delete o.set[part.component];
        if (o.objects) delete o.objects[part.component];
        break;
      case 'remove':
        o.remove = cut(o.remove, part.component);
        break;
      case 'off':
        o.off = cut(o.off, part.component);
        break;
      case 'on':
        o.on = cut(o.on, part.component);
        break;
      case 'objects':
        if (o.objects && 'field' in part) {
          const fields = o.objects[part.component] as Record<string, unknown> | undefined;
          if (fields) delete fields[part.field];
          if (fields && Object.keys(fields).length === 0) delete o.objects[part.component];
        } else if (o.objects) delete o.objects[part.component];
        break;
      case 'layer':
        delete o.layer;
        break;
      case 'name':
        delete o.name;
        break;
      case 'parent':
        delete o.parent;
        break;
      case 'removed':
        delete o.removed;
        break;
      case 'links':
        o.links = o.links?.filter((l) => !(l.relation === part.relation && l.to.join('/') === part.to));
        if (o.links?.length === 0) delete o.links;
        break;
      case 'added':
        break;
    }
    for (const k of ['set', 'refs', 'objects'] as const) if (o[k] && Object.keys(o[k]!).length === 0) delete o[k];
    return [o];
  });
}

/**
 * `items` of instance `root` reverted: back to what its prefab gives, every
 * other override kept as it is; an entity added destroyed. Outside a tick;
 * flushed. How many were reverted.
 */
export function revertItems(world: World, root: Entity, items: readonly Item[]): number {
  const found = overridesOf(world, root);
  if (!found) return 0;
  let list = overrideList(found);
  let done = 0;
  for (const item of items) {
    if (item.part.kind === 'added') {
      if (world.alive(item.entity)) world.destroy(item.entity);
    } else list = without(list, item);
    done++;
  }
  world.flush();
  fitInstance(world, root, found.prefab, list);
  world.flush();
  return done;
}

// ---------------------------------------------------------------- unpack

/**
 * Instance `root` made plain entities: its `Instance` rows cleared, nothing
 * else changed. One level (`completely` false): each instance it nests is an
 * instance of its own prefab after, its root that nested instance's root, and
 * its entities that prefab's node kinds (`World.rekind`) -- so it stays one
 * through any load: an undo, a playtest's end, a scene saved and loaded, a
 * reload's resume.
 * Throws, in words, for a pooled prefab's instance -- its pool counts it out.
 * How many entities were made plain.
 */
export function unpack(world: World, root: Entity, completely: boolean): number {
  const p = world.prefabOf(root);
  if (!p || world.instanceRoot(root) !== root) throw new Error('not an instance\'s root');
  if (p.pool) throw new Error(`${p.key} is pooled: its pool counts this instance out, and takes it back on destroy -- destroy it and place a plain copy instead`);
  const inst = world.rawStore(Instance) as Record<'prefab' | 'node' | 'root' | 'next', { [i: number]: number }>;
  const members: Entity[] = [];
  for (let e = root as number; e !== 0; e = inst.next[e]!) {
    if (inst.root[e] !== root || inst.prefab[e] !== p.id) break;
    if (world.alive(e as Entity)) members.push(e as Entity);
  }
  /** Each nested instance one level in: its owner and its members by its own node. */
  const groups = new Map<string, { owner: PrefabOwner; inner: CompiledPrefab; at: Map<number, Entity> }>();
  if (!completely) {
    for (const e of members) {
      const owners = p.owners[inst.node[e]!] ?? [];
      // The prefab nested one level in that makes it: the owner just inside this one.
      const owner = owners.length >= 2 ? owners[owners.length - 2]! : null;
      const inner = owner ? compiledPrefab(owner.key) : undefined;
      if (!owner || !inner) continue;
      const path = p.paths[inst.node[e]!]!;
      const rel = pathInOwner(owner, path);
      const node = rel === null ? -1 : inner.paths.indexOf(rel);
      if (node < 0) continue;
      const key = `${owner.key}@${owner.at}`;
      const g = groups.get(key) ?? { owner, inner, at: new Map<number, Entity>() };
      g.at.set(node, e);
      groups.set(key, g);
    }
  }
  for (const e of members) inst.prefab[e] = inst.node[e] = inst.root[e] = inst.next[e] = 0;
  for (const { inner, at } of groups.values()) {
    const top = at.get(0);
    if (top === undefined) continue;
    const nodes = [...at.keys()].sort((a, b) => a - b);
    nodes.forEach((n, i) => {
      const e = at.get(n)!;
      // Its own prefab's node kind, not the outer one's (`crates/rider/seat`, not `crates/big/rider/seat`): a load
      // finds each member's node by its kind's name, and would make it plain else -- an undo, a playtest, a scene.
      world.rekind(e, inner.kinds[n]!);
      inst.prefab[e] = inner.id;
      inst.node[e] = n;
      inst.root[e] = top;
      inst.next[e] = i + 1 < nodes.length ? at.get(nodes[i + 1]!)! : 0;
    });
  }
  return members.length;
}

// ---------------------------------------------------------------- apply

/** One file an Apply writes: its key, its text, and the text it replaces. */
export interface ApplyWrite {
  key: string;
  text: string;
  before: string;
}

export interface ApplyPlan {
  target: string;
  writes: ApplyWrite[];
  /** The items applied, and those the target cannot hold (left as overrides). */
  applied: Item[];
  left: Item[];
}

/** The owner `target` of node `path` in `p`, or null if that prefab cannot hold it. */
function ownerOf(p: CompiledPrefab, path: string, target: string): PrefabOwner | null {
  const n = p.paths.indexOf(path);
  return (p.owners[n] ?? []).find((o) => o.key === target) ?? null;
}

type Columns = Record<string, { [i: number]: number }>;

/** A scratch world for a fresh instance to write a file from: small, never shared. */
const scratchWorld = (): World => new World({ loop: new Loop(), entities: 1024, shared: false });

/**
 * `items` of instance `root` applied to the prefab `target`: the files to
 * write, in the files' own layout -- the target's, and each prefab between it
 * and the instance whose own override of the same thing would win over it.
 * Items the target cannot hold are left. Throws, in words, what refuses the
 * whole Apply: nothing the target can hold, what the writer cannot keep, a
 * file that would not compile (`check`).
 */
export function planApply(
  world: World,
  root: Entity,
  items: readonly Item[],
  target: string,
  files: Readonly<Record<string, PrefabFile>>,
  check?: (key: string, files: Record<string, PrefabFile>) => string | null,
): ApplyPlan {
  const p = world.prefabOf(root);
  if (!p || world.instanceRoot(root) !== root) throw new Error('not an instance\'s root');
  const file = files[target];
  const compiled = compiledPrefab(target);
  if (!file || !compiled) throw new Error(`there is no prefab ${target} to apply to`);
  const applied = items.filter((i) => i.owners.includes(target) && ownerOf(p, i.path, target) !== null);
  const left = items.filter((i) => !applied.includes(i));
  if (applied.length === 0) {
    const why = items.find((i) => i.why !== undefined)?.why;
    throw new Error(`${target} cannot hold ${items.length === 1 ? 'it' : 'any of them'}: ${items.map((i) => i.what).join(', ')}${why ? ` -- ${why}` : ''}`);
  }

  // A fresh instance of the target, its entities by their path in it.
  const scratch = scratchWorld();
  const top = scratch.instantiate(prefab(target));
  scratch.flush();
  const at = new Map<string, Entity>();
  const sinst = scratch.rawStore(Instance) as Record<'node' | 'next', { [i: number]: number }>;
  for (let e = top as number; e !== 0; e = sinst.next[e]!) at.set(compiled.paths[sinst.node[e]!]!, e as Entity);
  const tree = world.rawStore(Hierarchy) as { parent: { [i: number]: number } };
  /** The scratch entity at a path of the outer prefab, through `owner`; refused for one it has not. */
  const scratchAt = (owner: PrefabOwner, path: string, why: string): Entity => {
    const rel = pathInOwner(owner, path);
    const e = rel === null ? undefined : at.get(rel);
    if (e === undefined) throw new Error(`${why}: ${path || 'its root'} is not in ${target}`);
    return e;
  };
  const pathOfLive = (e: Entity): string | null => pathIn(world, p, root, e);
  /**
   * A data component's fields (`only`, else every one) from the live entity into the scratch one: its refs each the
   * scratch instance's entity at the same path, nobody for one outside -- `strict`, refused, for a field applied.
   */
  const copyData = (c: DataComponentOf, e: Entity, s: Entity, owner: PrefabOwner, only: string | null, what: string): void => {
    const live = (world.rawStore(c) as { value: Record<string, unknown>[] }).value[e]!;
    const slot = (scratch.rawStore(c) as { value: Record<string, unknown>[] }).value[s]!;
    for (const [f, el] of Object.entries(c.data)) {
      if (only !== null && f !== only) continue;
      slot[f] = fromPlain(el, dataPlain(el, live[f], (r) => r), f, {
        ref: (r) => {
          const to = typeof r === 'number' ? world.deref(r as EntityRef) : NONE;
          if (to === NONE) return NO_REF;
          const path = pathOfLive(to);
          if (path === null) {
            if (only !== null) throw new Error(`${what} points outside the instance, at ${named(world, to)}: only the scene can hold that, never a prefab`);
            return NO_REF;
          }
          return scratch.ref(scratchAt(owner, path, what));
        },
      });
    }
  };
  const copyComponent = (c: AnyComponent, e: Entity, s: Entity, owner?: PrefabOwner): void => {
    if (!scratch.has(s, c)) scratch.add(s, c);
    if (isData(c) && owner) {
      scratch.flush();
      copyData(c, e, s, owner, null, c.name);
    } else if (c.kind === 'object') {
      const live = (world.rawStore(c) as { value: unknown[] }).value[e];
      const slot = (scratch.rawStore(c) as { value: unknown[] }).value;
      if (c.save && c.load) slot[s] = c.load(c.save(live), slot[s]) ?? slot[s];
      else slot[s] = live;
    } else if (c.kind === 'data') {
      const from = world.rawStore(c) as Columns;
      const to = scratch.rawStore(c) as Columns;
      for (const f of c.fields) if (!(c.schema as Record<string, { ref?: true }>)[f.name]?.ref) to[f.name]![s] = from[f.name]![e]!;
    }
  };

  for (const item of applied) {
    const owner = ownerOf(p, item.path, target)!;
    const s = scratchAt(owner, item.path, item.what);
    const e = item.entity;
    const part = item.part;
    switch (part.kind) {
      case 'set': {
        const c = componentNamed(world, part.component) as Component;
        if (!scratch.has(s, c)) copyComponent(c, e, s);
        for (const f of setFields(part)) (scratch.rawStore(c) as Columns)[f]![s] = (world.rawStore(c) as Columns)[f]![e]!;
        if (c === Transform) scratch.moved(s);
        break;
      }
      case 'add': {
        const c = componentNamed(world, part.component)!;
        copyComponent(c, e, s, owner);
        if (!world.enabled(e, c)) scratch.enable(s, c, false);
        break;
      }
      case 'remove': {
        const c = componentNamed(world, part.component)!;
        if (scratch.has(s, c)) scratch.remove(s, c);
        break;
      }
      case 'off':
      case 'on': {
        const c = componentNamed(world, part.component)!;
        if (scratch.has(s, c)) scratch.enable(s, c, part.kind === 'on');
        break;
      }
      case 'objects': {
        const c = componentNamed(world, part.component)!;
        if (isData(c) && 'field' in part) {
          if (!scratch.has(s, c)) {
            scratch.add(s, c);
            scratch.flush();
          }
          copyData(c, e, s, owner, part.field, item.what);
        } else copyComponent(c, e, s, owner);
        break;
      }
      case 'layer':
        scratch.setLayer(s, world.layerOfEntity(e));
        break;
      case 'name': {
        const names = (world.rawStore(Name) as { value: unknown[] }).value;
        if (!scratch.has(s, Name)) scratch.add(s, Name);
        (scratch.rawStore(Name) as { value: unknown[] }).value[s] = names[e];
        break;
      }
      case 'refs': {
        const c = componentNamed(world, part.component) as Component;
        const to = world.deref((world.rawStore(c) as Columns)[part.field]![e]! as EntityRef);
        // Nobody: the prefab's ref cleared -- its own dropped, or a nested one's overridden with null.
        if (to === NONE) {
          (scratch.rawStore(c) as Columns)[part.field]![s] = 0;
          break;
        }
        const path = pathOfLive(to);
        if (path === null) throw new Error(`${item.what} points outside the instance, at ${named(world, to)}: only the scene can hold that, never a prefab`);
        (scratch.rawStore(c) as Columns)[part.field]![s] = scratch.ref(scratchAt(owner, path, item.what));
        break;
      }
      case 'parent': {
        const path = pathOfLive(tree.parent[e]! as Entity);
        if (path === null) throw new Error(`${item.what}: its parent is outside the instance`);
        scratch.setParent(s, scratchAt(owner, path, item.what));
        break;
      }
      case 'links': {
        const r = componentNamed(world, part.relation);
        if (r?.kind !== 'relation') throw new Error(`there is no relation ${part.relation}`);
        const toLive = (() => {
          const rows = world.rawStore(r) as Columns;
          for (let row = rows.firstOut![e]!; row !== 0; row = rows.nextOut![row]!) if (pathOfLive(rows.target![row]! as Entity) === part.to) return row;
          return 0;
        })();
        const toScratch = scratchAt(owner, part.to, item.what);
        const srows = scratch.rawStore(r) as Columns;
        let row = 0;
        for (let x = srows.firstOut![s]!; x !== 0 && row === 0; x = srows.nextOut![x]!) if (srows.target![x] === toScratch) row = x;
        if (row === 0) row = scratch.relate(s, r, toScratch);
        if (toLive !== 0 && row !== 0) for (const f of r.fields) srows[f.name]![row] = (world.rawStore(r) as Columns)[f.name]![toLive]!;
        break;
      }
      case 'removed':
        scratch.destroy(s);
        break;
      case 'added': {
        const clip = copyOut(world, [e]);
        const pasted = pasteIn(scratch, clip, { x: 0, z: 0 }, { make: (w, kind) => w.spawn(kind), keepRefs: false });
        const made = pasted.roots[0];
        if (made === undefined) throw new Error(`${item.what} could not be copied`);
        scratch.flush();
        scratch.setParent(made, s);
        // Where it is under its parent, not in the world.
        if (world.has(e, Transform)) {
          const from = world.rawStore(Transform) as Columns;
          const to = scratch.rawStore(Transform) as Columns;
          for (const f of ['px', 'py', 'pz', 'qx', 'qy', 'qz', 'qw', 'sx', 'sy', 'sz']) to[f]![made] = from[f]![e]!;
        }
        // Its name as it is: the scratch world names nothing twice, and has none of the scene's.
        if (world.has(e, Name)) (scratch.rawStore(Name) as { value: unknown[] }).value[made] = (world.rawStore(Name) as { value: unknown[] }).value[e];
        break;
      }
    }
    scratch.flush();
  }
  scratch.flush();

  const written = clipToPrefab(copyOut(scratch, [top]), { compiled: (key) => compiledPrefab(key), unpack: { key: target, file } });
  if (written.notes.length > 0) throw new Error(`${target} cannot keep it: ${written.notes.join('; ')}`);
  const writes: ApplyWrite[] = [];
  const next: Record<string, PrefabFile> = { ...files };
  if (!written.unchanged) {
    writes.push({ key: target, text: prefabText(written.file), before: prefabText(file) });
    next[target] = written.file;
  }

  // Each prefab between the target and the instance: its own override of the same thing would win, so it goes.
  for (const item of applied) {
    const n = p.paths.indexOf(item.path);
    const chain = p.owners[n] ?? [];
    const from = chain.findIndex((o) => o.key === target);
    for (const outer of chain.slice(from + 1)) {
      const rel = pathInOwner(outer, item.path);
      const outerFile = next[outer.key];
      if (rel === null || !outerFile) continue;
      const copy = structuredClone(outerFile);
      if (!dropOverride(copy, rel, item.part)) continue;
      next[outer.key] = copy;
      const had = writes.find((w) => w.key === outer.key);
      if (had) had.text = prefabText(copy);
      else writes.push({ key: outer.key, text: prefabText(copy), before: prefabText(files[outer.key]!) });
    }
  }
  if (writes.length === 0) throw new Error(`${target} says ${applied.length === 1 ? 'that' : 'those'} already`);
  for (const w of writes) {
    const problem = check?.(w.key, next);
    if (problem) throw new Error(`${w.key} would not compile, so nothing was written: ${problem}`);
  }
  return { target, writes, applied, left };
}

/**
 * `part` taken out of the override `file` holds at `path` -- a path of its own
 * prefab, inside an instance it nests. True if the file changed.
 */
export function dropOverride(file: PrefabFile, path: string, part: Part): boolean {
  const owner = ownersOf(file)(path);
  if (!owner || 'plain' in owner) return false;
  const entity = file.entities.find((x) => x.id === owner.nested);
  if (!entity?.overrides) return false;
  const before = JSON.stringify(entity.overrides);
  const item: Item = { path: owner.inner, entity: NONE, part, owners: [], what: '', was: '', now: '' };
  // An inner prefab given a component: the outer's own adding of it goes too (`without`), or the compile would add it twice.
  const list = without(entity.overrides, item).filter((o) => Object.keys(o).some((k) => k !== 'at' && (o as unknown as Record<string, unknown>)[k] !== undefined));
  if (JSON.stringify(list) === before) return false;
  if (list.length > 0) entity.overrides = list;
  else delete entity.overrides;
  return true;
}
