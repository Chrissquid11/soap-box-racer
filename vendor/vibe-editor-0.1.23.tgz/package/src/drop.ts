/**
 * A list floated in the editor's root under its button (`dropUnder`): its right edge on the button's, above it where
 * there is no room below, kept there as anything scrolls or the window is resized, and taken away by a press anywhere
 * but on the two. `minWidth` and `fit` size a card (at least so wide; its height capped to the room on the side it
 * opens, above where there is more room); `rebind` follows a button built again in its place. A side card cuts off
 * whatever is inside it, so every drop-down of the editor floats this way:
 *
 * - the tags' list (`tags-drop.ts`) -- the inspector's and each tree row's -- and the labels' (`labels-drop.ts`);
 * - the tree's column chooser (`tree.ts`);
 * - the Assets panel's files chooser (`assets/ui/files.ts`) and its folder picker (`assets/ui/assets-tool.ts`);
 * - the inspector's Add Component card (`add-component.ts`), with `minWidth`, `fit` and `rebind`.
 */

/** How `dropUnder` sizes what it floats; left out, the list's own size, below its button unless there is no room. */
export interface DropOptions {
  /** At least this wide, and at least as wide as its button (capped to the window): the Add Component card. */
  minWidth?: number;
  /** Its height capped to the room on the side it opens on -- below, or above where there is more room there. */
  fit?: true;
}

/** What `dropUnder` returns: called, it takes the list away; `rebind` moves it under a button built again in place of the first. */
export interface Dropped {
  (): void;
  rebind(button: HTMLElement): void;
  /** Placed again: its rows changed. */
  place(): void;
}

/** The gap a dropped list keeps from the window's edges. */
const EDGE = 8;
/** Below this, `fit` opens above where there is more room. */
const FIT_BELOW = 260;

/**
 * `list` floated in `root` under `button`, its right edge on the button's --
 * above it where there is no room below -- and kept there as anything scrolls
 * or the window is resized. A press anywhere but on the two is `shut`'s.
 * Returns what takes it away (`Dropped`), which can also follow a button built
 * again (`rebind`) and place it again (`place`).
 */
export function dropUnder(root: HTMLElement, first: HTMLElement, list: HTMLElement, shut: () => void, options: DropOptions = {}): Dropped {
  let button = first;
  const place = (): void => {
    if (!button.isConnected) return;
    const r = button.getBoundingClientRect();
    if (options.minWidth !== undefined) list.style.width = `${Math.min(Math.max(r.width, options.minWidth), innerWidth - 2 * EDGE)}px`;
    if (options.fit) {
      const below = innerHeight - r.bottom - 2 * EDGE;
      const above = r.top - 2 * EDGE;
      const down = below >= FIT_BELOW || below >= above;
      const room = Math.max(120, down ? below : above);
      list.style.maxHeight = `${room}px`;
      const width = list.getBoundingClientRect().width;
      list.style.left = `${Math.max(EDGE, Math.min(r.right - width, innerWidth - width - EDGE))}px`;
      list.style.top = `${down ? r.bottom + 4 : Math.max(EDGE, r.top - 4 - Math.min(list.scrollHeight, room))}px`;
      return;
    }
    const { width, height } = list.getBoundingClientRect();
    list.style.left = `${Math.max(EDGE, Math.min(r.right - width, innerWidth - width - EDGE))}px`;
    list.style.top = `${r.bottom + 4 + height > innerHeight - EDGE ? Math.max(EDGE, r.top - height - 4) : r.bottom + 4}px`;
  };
  // Capturing, so it is heard before whatever the press is for: a row's click, the scene's.
  const outside = (event: PointerEvent): void => {
    const target = event.target as Node | null;
    if (target && (list.contains(target) || button.contains(target))) return;
    shut();
  };
  // A scroll does not bubble: heard capturing, whatever scrolled -- but the list's own.
  const scrolled = (event: Event): void => {
    if (event.target instanceof Node && list.contains(event.target)) return;
    place();
  };
  root.append(list);
  place();
  document.addEventListener('pointerdown', outside, true);
  document.addEventListener('scroll', scrolled, true);
  addEventListener('resize', place);
  button.setAttribute('aria-expanded', 'true');
  const away = (): void => {
    list.remove();
    document.removeEventListener('pointerdown', outside, true);
    document.removeEventListener('scroll', scrolled, true);
    removeEventListener('resize', place);
    button.setAttribute('aria-expanded', 'false');
  };
  return Object.assign(away, {
    rebind(next: HTMLElement) {
      button = next;
      button.setAttribute('aria-expanded', 'true');
      place();
    },
    place,
  });
}
