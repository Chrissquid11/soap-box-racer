/**
 * The editor's view as the studio's view tools work it (`PageHost.views`, Docs/mcp.md M4): the same camera `F`, the
 * cube and the numpad move (`viewport.ts`), and images of views (`view_shot`, `view-shot.ts`) -- the editor's, a
 * camera entity's, the game's main camera, the Model tab's -- drawn as the screen draws them, the person's view unmoved.
 *
 * Made by `editor.ts` from what it has: the game, the viewport, the scene's room past the cards, the Model tab's
 * canvas; the game puts its frame back after a shot (`Game.drawOnce`).
 */
import type * as THREE from 'three';
import { type Entity, View } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import type { PageView, Shot } from './mcp/host.ts';
import type { Room, Viewport } from './viewport.ts';
import { checkContext, drawShot, encode, fromCanvas, shotSize } from './view-shot.ts';
import { poseLookingAt, SCENE_FOV } from './camera.ts';

export interface ViewHostOptions {
  game: Game;
  viewport: Viewport;
  /** The scene's room past the editor's cards, in client pixels; null for all of the canvas. */
  room(): Room | null;
  /** The Model tab's views drawn now, their canvas (`ToolInstance.shot`); null while it is not shown. */
  modelShot(): HTMLCanvasElement | null;
}

export function createViewHost({ game, viewport, room, modelShot }: ViewHostOptions): PageView {
  const canvas = game.renderer.domElement;
  /** The camera a `camera` target looks through: the entity's view, if it is a camera. */
  const cameraOf = (e: Entity): THREE.Camera | null => {
    const object = game.world.alive(e) && game.world.has(e, View) ? (game.world.store(View).value[e] as THREE.Object3D | null) : null;
    return object && (object as THREE.Camera).isCamera ? (object as THREE.Camera) : null;
  };
  /** A camera's own shape: a perspective camera's aspect, else the game's frame's. */
  const shapeOf = (camera: THREE.Camera): { width: number; height: number } => {
    const p = camera as THREE.PerspectiveCamera;
    return p.isPerspectiveCamera && p.aspect > 0 ? { width: p.aspect * 1000, height: 1000 } : { width: game.frame.width, height: game.frame.height };
  };

  return {
    get() {
      const pose = viewport.pose;
      if (!pose) throw new Error('The editor\'s view has not opened yet');
      const projection = pose.projection ?? 'perspective';
      const at = room();
      const c = canvas.getBoundingClientRect();
      return {
        pose: { position: pose.position, target: pose.target, projection, fov: projection === 'perspective' ? (pose.fov ?? SCENE_FOV) : null, height: projection === 'orthographic' ? (pose.height ?? null) : null },
        room: at ? { left: Math.round(at.left - c.left), top: Math.round(at.top - c.top), right: Math.round(at.right - c.left), bottom: Math.round(at.bottom - c.top) } : null,
        canvas: { width: canvas.clientWidth, height: canvas.clientHeight },
      };
    },
    setPose(position, target) {
      // A pose given by where and round what is upright (`view_set`): the up of the view before would lie anywhere against the new look.
      viewport.setPose(poseLookingAt(viewport.pose, position, target));
    },
    look: (preset) => viewport.look(preset),
    setProjection: (projection) => viewport.setProjection(projection),
    frame: (list) => viewport.frameOn(list),
    async shot(ask): Promise<Shot> {
      const notes: string[] = [];
      let image: HTMLCanvasElement;
      let entity: Entity | null = null;
      if (ask.target === 'model') {
        const source = modelShot();
        if (!source) throw new Error('The Model tab is not shown: open it, then look again');
        const size = shotSize({ width: source.width, height: source.height }, { width: source.width, height: source.height }, ask.width, ask.height);
        if (size.note) notes.push(size.note);
        // In the task it was drawn in: the canvas is not kept between frames.
        image = fromCanvas(source, size);
        notes.push('The Model tab as it is drawn, its views and labels and all.');
      } else {
        checkContext(game.renderer.getContext());
        const running = game.isRunning;
        // A world that is not running drawn as it stands now: commands applied, the views placed.
        if (!running) {
          game.world.flush();
          game.loop.present();
          viewport.update();
        }
        // The overlays are in the scene while the editor is up: not while a playtest runs (the viewport closed).
        const overlaysIn = !running;
        // The game's frame (Docs/game-view.md §2): what the image is of, in CSS pixels and in the buffer's.
        const whole = { width: game.frame.width, height: game.frame.height };
        const scale = canvas.width / Math.max(1, canvas.clientWidth || canvas.width);
        const buffer = { width: Math.floor(whole.width * scale), height: Math.floor(whole.height * scale) };
        // The camera looked through (null: the game's own, its cameras' plan) and the view's shape.
        let camera: THREE.Camera | null;
        let shape = whole;
        const width = ask.width;
        let height = ask.height;
        if (ask.target === 'scene') camera = viewport.camera;
        else if (ask.target === 'main') {
          camera = null;
          const main = game.gameView.entity;
          entity = main === 0 ? null : main;
          // The game's cameras are laid out over the frame: the image has its shape.
          if (width !== null && height !== null && Math.abs(width / height - whole.width / Math.max(1, whole.height)) > 0.01) {
            notes.push('Drawn at the game view\'s shape, from the width asked: the game\'s cameras are laid out over the whole of it.');
            height = null;
          }
          notes.push(running
            ? 'The game as the player sees it: its cameras and its HUD.'
            : `The 3D world through the game's own cameras${entity === null ? ' (no camera entity is main: the built-in one)' : ''}: no HUD -- the game's HUD is drawn only while a playtest runs.`);
        } else {
          const e = ask.camera!;
          const seen = cameraOf(e);
          if (!seen) throw new Error(`entity ${e} is no camera: target camera looks through a Camera entity's view`);
          camera = seen;
          shape = shapeOf(seen);
          entity = e;
        }
        if (ask.overlays && running) notes.push('A playtest runs: the editor\'s overlays are not in the scene.');
        const size = shotSize(shape, buffer, width, height);
        if (size.note) notes.push(size.note);
        const overlays = ask.overlays && overlaysIn;
        // The overlays out for the moment it is drawn, unless asked for; the view cube and a camera's preview drawn over with them.
        // Asked for through a camera: that camera's own shape out still -- through the game's cameras, every one's.
        const through = ask.target === 'camera' ? ask.camera! : ask.target === 'main' ? null : undefined;
        const hide = !overlaysIn
          ? null
          : !ask.overlays
            ? (hidden: boolean) => viewport.hideOverlays(hidden)
            : through === undefined ? null : (hidden: boolean) => viewport.hideCamera(through, hidden);
        image = drawShot(game, camera, size, { over: overlays, ui: ask.target === 'main' }, hide);
      }
      const { data, mimeType } = await encode(image, ask.format);
      return { data, mimeType, width: image.width, height: image.height, notes, camera: entity };
    },
  };
}
