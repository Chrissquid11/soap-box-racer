/**
 * A reload the editor survives (Docs/agent.md §4, "The host's changes"): the
 * record `editor.ts`' `prepareReload` keeps in this tab's `sessionStorage`
 * just before Vite reloads the page -- the agent's code arriving at a turn's
 * end, an `index.html` edit, a dev-server restart -- and read back by
 * `editor.ts`' `resume`, which boot calls first (`@vibe/engine/boot`'s
 * `EditorModule.resume`), bringing the editor back on its tool, with the
 * unsaved world, the selection and the camera.
 *
 * - **The record**: `{ at, page, open, tool, title, unsaved, world,
 *   selection, camera, scene, agent, agentMinimized, notes }` -- `world.save()` (in a playtest, the
 *   world it put aside), the selection's refs (a save keeps them: entities
 *   keep their indices and generations), the camera's pose (its projection and
 *   orthographic height with it), the Scenes tool's
 *   mark, and the agent's editor edits in this tab as values
 *   (`mcp/page.ts`' carry, read there). A world too big for
 *   `sessionStorage` is left out, the scene's name kept: the scene comes back
 *   as last saved, and the editor says so -- with no selection: refs name
 *   entities of the world they were taken in, and other ones in another.
 * - **The page's own** (as built after review D): every page that shares the
 *   tab's `sessionStorage` -- a same-origin frame of the editor, a copy of
 *   the tab made while a record waits -- would write one key, and whichever
 *   booted first would take the last writer's tool and selection. So a page
 *   has an id, kept in its session history entry (`pageId`: the same across
 *   its reloads, another in each frame), the record is kept under it
 *   (`resumeKey`) and says whose it is, and a page takes its own alone.
 * - **The project's own**: kept at its project's id too (`resumeKey`), so a page of another project on the same
 *   port -- the same origin, in the same tab -- never takes it.
 * - **Read once, and only fresh**: `takeResume` deletes it as it reads it, and
 *   one older than `RESUME_MS` is no reload's -- a tab opened again later
 *   starts as ever; another page's record past it is let go of too. The world
 *   is loaded through `Game.load`: a component this build lacks is skipped,
 *   and said.
 * - **Kept through a recovery** (studio mode, Docs/studio.md §1): a recovery boot takes no record, and
 *   its page stamps the one there fresh as it reloads or goes (`touchResume`), and drops none on a dev
 *   server restart -- the real boot after the fix, minutes later maybe, takes it.
 * - **Undo history does not survive**: a fresh one; the unsaved mark as it
 *   was. The agent's edits do, as values: Undo this turn puts them back by
 *   value (Docs/agent.md §8). So does what the stack held that the files
 *   still do: an Apply whose undo could not land -- the dev server gone, then
 *   restarted -- is in `notes`, with how to take it back, said on the line.
 * - **The pass** (`createReloadPass`): a reload said to be coming writes the
 *   record and lets that one unload past the Scenes tool's guard for
 *   `PASS_MS`. The dev server away (the socket closed), the pass holds for
 *   `AWAY_MS`, then lapses -- a tab closed while the server is stopped for
 *   good is asked about -- but the record is kept, and the page asks the
 *   server every `PING_MS` whether it is back (`HEAD /`). When it answers, the
 *   pass is armed again and the record written again, its `at` now, so
 *   `readResume` takes it: Vite's client awaits the disconnect's listeners
 *   before its own ping and reload (8.3.2's `client.mjs`), so that reload
 *   always finds the pass, however long the server was away.
 *
 * This file is the record and the pass, their effects handed in:
 * `readResume` is pure -- anything odd is no record -- and the pass runs on a
 * stand-in clock, so node tests both.
 */
import type { WorldSave } from '@vibe/engine';
import { projectId, projectKey } from '@vibe/engine/project-key';
import type { CameraPose } from './camera.ts';
import type { SceneMark } from './config/scenes.ts';

/** Where the records are kept: this tab's `sessionStorage`, one a page (`resumeKey`). Rename per game, as the scenes' key. */
export const RESUME_KEY = 'vibebase.editor.resume';

/**
 * One page's record's key: each page sharing the tab's `sessionStorage` keeps its own, at its project's id
 * (`projectKey`: two projects on one port share an origin) -- `vibebase.editor.resume@<id>:<page>`.
 */
export const resumeKey = (page: string, id: string = projectId()): string => `${projectKey(RESUME_KEY, id)}:${page}`;

/** A key of a record, of any project's, or the one key a build before kept every page's record under. */
const isResumeKey = (key: string): boolean => key === RESUME_KEY || key.startsWith(`${RESUME_KEY}:`) || key.startsWith(`${RESUME_KEY}@`);

/** What a page's id is kept in: its session history entry's state, under this name. */
const PAGE_STATE = 'vibebasePage';

/** Where a page's id is kept, handed in: the page's `history.state` and `replaceState`, or a test's. */
export interface PageHost {
  state(): unknown;
  replace(state: unknown): void;
  /** A new id. */
  make(): string;
}

/**
 * This page's id: kept in its session history entry's state, so a reload --
 * Vite's `location.reload()` keeps the entry -- has it again, and each frame
 * of a tab, whose entries are its own, has another. Made, and kept, the first
 * time it is asked for.
 */
export function pageId(host: PageHost): string {
  const state = host.state();
  const held = typeof state === 'object' && state !== null ? (state as Record<string, unknown>) : null;
  const kept = held?.[PAGE_STATE];
  if (typeof kept === 'string' && kept !== '') return kept;
  const id = host.make();
  host.replace({ ...(held ?? {}), [PAGE_STATE]: id });
  return id;
}

/** What the records need of `sessionStorage`: a test's stand-in has this shape. */
export type ResumeStorage = Pick<Storage, 'getItem' | 'setItem' | 'removeItem' | 'key' | 'length'>;

/** This tab's `sessionStorage`, or none where it is blocked. */
const tabStorage = (): ResumeStorage | null => {
  try {
    return globalThis.sessionStorage ?? null;
  } catch {
    return null;
  }
};

/** A record older than this, in milliseconds, is no reload's. */
export const RESUME_MS = 30_000;

/** A reload said to be coming lets the Scenes tool's guard pass this long, in milliseconds... */
export const PASS_MS = 10_000;
/** ...and, the dev server away, this long: it restarts in seconds; one stopped for good is not coming back. */
export const AWAY_MS = 120_000;
/** How often the page asks a dev server that went away whether it is back, in milliseconds: as Vite's client does. */
export const PING_MS = 1000;

export interface ResumeRecord {
  /** When it was written, as `Date.now()`. */
  at: number;
  /** The page that wrote it (`pageId`): it is that page's alone. */
  page: string;
  /** The editor was open: the only time one is written. */
  open: boolean;
  /** The tool up. */
  tool: string;
  /** The side that had the keys -- the Assets panel within the Scene tab -- if not `tool`: given the keys again. */
  focused?: string;
  /** What the world was called under the editor's title: said when the world could not be kept. */
  title: string | null;
  /** Changed since it was last saved: the dot after the name. */
  unsaved: boolean;
  /** The world, or null where it was too big to keep. */
  world: WorldSave | null;
  /** The selection, as refs, the first shown. */
  selection: number[];
  camera: CameraPose | null;
  /** The Scenes tool's mark: the scene's name, what it came from, edited since saved. */
  scene: SceneMark | null;
  /** The agent's editor edits in this tab, as values: `mcp/page.ts`' to read (`readCarry`). Null for none. */
  agent: unknown;
  /**
   * The agent's card minimized (Docs/agent.md §4), this page's own. The preferences are the browser's, shared by every
   * page of it: with two studio pages open, minimizing the card in one writes them for both, so the other's reload
   * would come back as the first left it. The record is this page's alone (`pageId`), so each page's card comes back
   * as it was on that page; a new page, with no record, takes the preferences.
   */
  agentMinimized?: boolean;
  /** Each tool's own, by its id, as values (`ToolInstance.carry`): the Model tab's cameras. Read back by that tool alone. */
  tools: Record<string, unknown>;
  /**
   * What the page that comes back says, once (the line): what the reload
   * took with the history -- an Apply whose undo or redo could not land, which
   * the prefab files still hold, and how to take it back (`OverrideSteps.notes`).
   */
  notes: string[];
}

const triple = (v: unknown): v is [number, number, number] => Array.isArray(v) && v.length === 3 && v.every((n) => typeof n === 'number' && Number.isFinite(n));

/**
 * The record as kept, read: null for none, one too old, another page's (with
 * `page`, the page asking), or anything odd. Its selection only with its
 * world: refs name entities of the world they were taken in.
 */
export function readResume(text: string | null, now: number, page?: string): ResumeRecord | null {
  let data: unknown;
  try {
    data = JSON.parse(text ?? 'null');
  } catch {
    return null;
  }
  if (typeof data !== 'object' || data === null) return null;
  const r = data as Record<string, unknown>;
  if (typeof r.at !== 'number' || now - r.at > RESUME_MS || now - r.at < -RESUME_MS || r.open !== true || typeof r.tool !== 'string') return null;
  // Another page's -- a frame's, a copy's: its tool and selection are not this one's.
  if (page !== undefined && r.page !== page) return null;
  const camera = r.camera as { position?: unknown; target?: unknown; projection?: unknown; height?: unknown; up?: unknown; fov?: unknown } | null | undefined;
  const scene = r.scene as Record<string, unknown> | null | undefined;
  const world = typeof r.world === 'object' && r.world !== null ? (r.world as WorldSave) : null;
  return {
    at: r.at,
    page: typeof r.page === 'string' ? r.page : '',
    open: true,
    tool: r.tool,
    ...(typeof r.focused === 'string' ? { focused: r.focused } : {}),
    title: typeof r.title === 'string' ? r.title : null,
    unsaved: r.unsaved === true,
    world,
    selection: world !== null && Array.isArray(r.selection) ? r.selection.filter((n): n is number => typeof n === 'number' && Number.isInteger(n) && n > 0) : [],
    camera: camera && triple(camera.position) && triple(camera.target)
      ? {
        position: camera.position,
        target: camera.target,
        // Its projection and orthographic height, where kept and sound: a pose from before them is perspective.
        ...(camera.projection === 'perspective' || camera.projection === 'orthographic' ? { projection: camera.projection } : {}),
        ...(typeof camera.height === 'number' && Number.isFinite(camera.height) && camera.height > 0 ? { height: camera.height } : {}),
        // Upside down as it was left (Docs/navigation.md §6), and its field of view (Align view with camera's): where kept and sound.
        ...(triple(camera.up) && Math.hypot(...camera.up) > 1e-6 ? { up: camera.up } : {}),
        ...(typeof camera.fov === 'number' && Number.isFinite(camera.fov) && camera.fov > 0 && camera.fov < 180 ? { fov: camera.fov } : {}),
      }
      : null,
    scene: scene && typeof scene === 'object'
      ? { current: typeof scene.current === 'string' ? scene.current : null, source: typeof scene.source === 'string' ? scene.source : null, edited: scene.edited === true }
      : null,
    agent: r.agent ?? null,
    ...(typeof r.agentMinimized === 'boolean' ? { agentMinimized: r.agentMinimized } : {}),
    tools: typeof r.tools === 'object' && r.tools !== null && !Array.isArray(r.tools) ? (r.tools as Record<string, unknown>) : {},
    notes: Array.isArray(r.notes) ? r.notes.filter((n): n is string => typeof n === 'string') : [],
  };
}

/**
 * The record written, under its page's key -- with its world, or, where that
 * is too big for `sessionStorage`, without it. False if nothing could be
 * written at all.
 */
export function writeResume(record: ResumeRecord, storage: ResumeStorage | null = tabStorage()): boolean {
  if (!storage) return false;
  const key = resumeKey(record.page);
  try {
    storage.setItem(key, JSON.stringify(record));
    return true;
  } catch {
    // Full: the scene's name and the rest, without the world.
  }
  try {
    storage.setItem(key, JSON.stringify({ ...record, world: null }));
    return true;
  } catch {
    return false;
  }
}

/** A page's record dropped: a reload that was said to be coming did not come. */
export function dropResume(page: string, storage: ResumeStorage | null = tabStorage()): void {
  try {
    storage?.removeItem(resumeKey(page));
  } catch {
    // Blocked: nothing was kept either.
  }
}

/**
 * This page's record kept fresh: its `at` stamped `now`, the rest as it was -- false for none (or one not this
 * page's, or odd). Studio mode's recovery (Docs/studio.md §1) keeps the record of the reload before it for the real
 * boot that follows the fix, which may come minutes later: stamped as recovery's page reloads, so `takeResume` still
 * takes it then -- never past `RESUME_MS` from that reload.
 */
export function touchResume(page: string, now: number, storage: ResumeStorage | null = tabStorage()): boolean {
  if (!storage) return false;
  try {
    const text = storage.getItem(resumeKey(page));
    const at = (JSON.parse(text ?? 'null') as { at?: unknown } | null)?.at;
    // Read as it would be at its own time: only its age is set aside.
    if (typeof at !== 'number' || readResume(text, at, page) === null) return false;
    storage.setItem(resumeKey(page), JSON.stringify({ ...(JSON.parse(text!) as object), at: now }));
    return true;
  } catch {
    return false;
  }
}

/**
 * This page's record, taken: read, and deleted as it is read -- null for none,
 * or one too old. Another page's past `RESUME_MS` -- a frame gone for good --
 * is let go of too, and so is the one key a build before kept every page's
 * record under.
 */
export function takeResume(page: string, now: number, storage: ResumeStorage | null = tabStorage()): ResumeRecord | null {
  if (!storage) return null;
  try {
    const record = readResume(storage.getItem(resumeKey(page)), now, page);
    const stale: string[] = [];
    for (let i = 0; i < storage.length; i++) {
      const key = storage.key(i);
      if (key === null || !isResumeKey(key)) continue;
      if (key === resumeKey(page) || key === RESUME_KEY || readResume(storage.getItem(key), now) === null) stale.push(key);
    }
    for (const key of stale) storage.removeItem(key);
    return record;
  } catch {
    return null;
  }
}

/**
 * The pass's `write` for a page: a page in recovery passes with no record written -- its world is the stand-in,
 * which nothing brings back (the record kept is the real boot's), and a reload is its way out, so the guard never
 * holds one (Docs/studio.md §1); any other page passes once its record is written (`write`'s true).
 */
export const passWrite = (recovering: boolean, write: () => boolean): (() => boolean) => () => recovering || write();

/** What the pass does and asks, handed in: `editor.ts`' effects, or a test's stand-ins. */
export interface ReloadPassHost {
  /** The record written as the editor is now (`prepareReload`); true if the unload may pass (`passWrite`: recovery's with none). */
  write(): boolean;
  /** This page's record dropped. */
  drop(): void;
  /** The Scenes tool's guard: the next unload let by, or asked about. */
  pass(on: boolean): void;
  /** Does the dev server answer. */
  ping(): Promise<boolean>;
  now(): number;
  later(run: () => void, ms: number): unknown;
  cancel(timer: unknown): void;
}

export interface ReloadPass {
  /** A reload is coming (`vite:beforeFullReload`): the record written, the unload let by for `PASS_MS`. */
  arm(): void;
  /**
   * The dev server went away (`vite:ws:disconnect`): armed, the pass held for
   * `AWAY_MS` and then lapsed, the record kept; the server asked every
   * `PING_MS`, and when it answers, armed again, the record written again --
   * and then the promise settles. Vite's client awaits it before it pings and
   * reloads itself. Undefined when nothing was written (`write`'s false):
   * nothing kept, nothing held up.
   */
  away(): Promise<void> | undefined;
  /** A socket again (`vite:ws:connect`). */
  back(): void;
  /** The page going (`pagehide`): armed, the record once more -- an edit made meanwhile kept; else the page's own going, and its socket closing then no restart. */
  leaving(): void;
  /** The page shown again from the back/forward cache (`pageshow`, persisted): no longer going, so a restart is kept again. */
  shown(): void;
  readonly armed: boolean;
  dispose(): void;
}

/** The pass a reload the editor survives gets past the Scenes tool's guard: armed, lapsed, and armed again when a server that went away is back. */
export function createReloadPass(host: ReloadPassHost, times: { pass: number; away: number; ping: number } = { pass: PASS_MS, away: AWAY_MS, ping: PING_MS }): ReloadPass {
  let armed = false;
  let lapse: unknown;
  let gone = false;
  let goneAt = 0;
  let unloading = false;
  let pinging: unknown;
  let release: (() => void) | null = null;
  let waiting: Promise<void> | undefined;
  let disposed = false;

  function arm(): boolean {
    if (!host.write()) return false;
    armed = true;
    host.pass(true);
    host.cancel(lapse);
    lapse = host.later(disarm, times.pass);
    return true;
  }

  function disarm(): void {
    if (gone) {
      const left = times.away - (host.now() - goneAt);
      if (left > 0) {
        lapse = host.later(disarm, left);
        return;
      }
      // Away too long: a tab closed now is asked about. The record stays, and the pings go on.
      armed = false;
      host.pass(false);
      return;
    }
    armed = false;
    host.pass(false);
    // A record nobody reloaded for would bring an older world back on the next reload of any kind.
    host.drop();
  }

  /** Back, or asked again in `PING_MS`. */
  function ping(): void {
    pinging = host.later(() => {
      void host.ping().then(
        (up) => up,
        () => false,
      ).then((up) => {
        if (disposed) return;
        if (!up) return ping();
        gone = false;
        // The record as the editor is now, at this time, and the pass for the reload Vite makes next; closed meanwhile, none.
        if (!arm()) host.drop();
        settle();
      });
    }, times.ping);
  }

  function settle(): void {
    const done = release;
    release = null;
    waiting = undefined;
    done?.();
  }

  return {
    arm: () => void arm(),
    away() {
      if (unloading || disposed) return undefined;
      if (waiting) return waiting;
      if (!gone) {
        gone = true;
        goneAt = host.now();
      }
      if (!arm()) return undefined;
      waiting = new Promise<void>((resolve) => (release = resolve));
      ping();
      return waiting;
    },
    back() {
      gone = false;
    },
    leaving() {
      if (armed) host.write();
      else unloading = true;
    },
    shown() {
      unloading = false;
    },
    get armed() {
      return armed;
    },
    dispose() {
      disposed = true;
      host.cancel(lapse);
      host.cancel(pinging);
      settle();
    },
  };
}

/** What a resume's world came to (`resumeWorld`): loaded; or it would not, and the scene as last saved is up instead; or nothing could be. */
export type ResumedWorld = { how: 'loaded'; skipped: string[] } | { how: 'kept' | 'lost'; why: string };

/**
 * The record's `world` loaded in place of the game's (`editor.ts`' `resume`).
 * A load that throws part way has already emptied the world: the world from
 * before is put back, and then the scene as last saved tried (`kept`, true if
 * it loaded) -- never a half-loaded world left for the editor to open on.
 * `lost`: neither; boot goes on as with no record, the start scene opened.
 */
export function resumeWorld(
  game: { readonly world: { save(): WorldSave }; load(save: WorldSave): { skipped: string[] } },
  world: WorldSave,
  kept: () => boolean,
): ResumedWorld {
  const before = game.world.save();
  try {
    return { how: 'loaded', skipped: game.load(world).skipped };
  } catch (err) {
    const why = err instanceof Error ? err.message : String(err);
    try {
      game.load(before);
    } catch {
      // The world before would not load back either: what the scene, or boot's start scene, loads over.
    }
    return { how: kept() ? 'kept' : 'lost', why };
  }
}
