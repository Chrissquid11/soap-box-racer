/**
 * Each script's canvases, kept for the page's life (Docs/modeler.md M28): a
 * book a script -- its canvases in order, the one open, the count that names
 * the next, and the version of the export they were drawn over. Opening
 * another model puts the book away, the quads taken out of the scene; opening
 * the script again brings it back -- marked stale if the export it was drawn
 * over changed meanwhile (D74), as a rebuild under it would have. A script
 * the index says is gone has its book put away dropped (`drop`), its canvases
 * freed -- not the one out, which the tab still shows as not there.
 *
 * Pure and generic over what a canvas is: node tests it
 * (`canvas-books.test.ts`); `canvases.ts` keeps its `Canvas`es in it.
 */

export interface Book<T> {
  items: T[];
  open: T | null;
  /** The last number a canvas of this script was named with. */
  counter: number;
  /** The export's version the canvases were drawn over (its size and time), null until a model is shown. */
  version: string | null;
}

export interface Books<T> {
  /** The script whose book is out, or null. */
  readonly path: string | null;
  /** Its book: an empty one with no script. */
  readonly book: Book<T>;
  /** Another script's book out -- made empty the first time -- the one before put away. Answers the one put away (null: none, or the same). */
  open(path: string | null): Book<T> | null;
  /**
   * A model of the script shown at `version`: true if the book's canvases were
   * drawn over another -- a rebuild while it was put away -- and are stale now.
   * The version kept either way.
   */
  shown(version: string): boolean;
  /** Every book, for a whole clear (dispose). */
  all(): Book<T>[];
  /** Every book by its script: what a reload carries. */
  entries(): [string, Book<T>][];
  /** A script's book, if kept (a reload's canvases put into it before the script opens). */
  of(path: string): Book<T>;
  /** The script gone (deleted, renamed away): its book put away dropped, answered to be freed -- null for none, or the one out. */
  drop(path: string): Book<T> | null;
}

const empty = <T>(): Book<T> => ({ items: [], open: null, counter: 0, version: null });

export function createBooks<T>(): Books<T> {
  const books = new Map<string, Book<T>>();
  let path: string | null = null;
  let book: Book<T> = empty();
  const of = (p: string): Book<T> => {
    let b = books.get(p);
    if (!b) books.set(p, (b = empty()));
    return b;
  };
  return {
    get path() {
      return path;
    },
    get book() {
      return book;
    },
    open(next) {
      if (next === path) return null;
      const away = path === null ? null : book;
      path = next;
      book = next === null ? empty() : of(next);
      return away;
    },
    shown(version) {
      const stale = book.version !== null && book.version !== version && book.items.length > 0;
      book.version = version;
      return stale;
    },
    all: () => [...books.values()],
    entries: () => [...books.entries()],
    of,
    drop(gone) {
      const b = books.get(gone);
      if (!b || gone === path) return null;
      books.delete(gone);
      return b;
    },
  };
}

/** A canvas carried across a reload, drawn over export `then`, shown over `now`: stale if both are known and differ (D74). */
export const drifted = (then: string | null, now: string | null): boolean => then !== null && now !== null && then !== now;
