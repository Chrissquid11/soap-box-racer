/**
 * The editor's Model tab (`modelTool`, key `3`; Docs/modeler.md is its whole
 * specification): a Gladius script under `AssetsSource/models/` opened, what
 * the pipeline builds of it shown in one, two or four views, its parts listed,
 * its build followed live.
 *
 * - **Its panels are the editor's**: the outliner docked on the left
 *   (`outliner.ts`), the model or the part on the right (`inspector.ts`), the
 *   stage between them (`stage.ts`) under its toolbar and banner, the Assets
 *   panel along the bottom -- the Scene tab's own, `within` this tab too (M6).
 *   The right panel is whichever chose last (`sides.ts`): a part picked here,
 *   a file there.
 * - **Opening a model** (M19): `openModel` -- a `.lua`, or its export, which
 *   opens its script -- from the Assets panel's double-click, its inspector's
 *   and its menu's Open in Model tab, the empty state's list; the last one is
 *   kept (`prefs.ts`' `model`) and opened again as the tab first shows.
 * - **The selection and the hidden parts are the tab's**, as ids (paths of
 *   names, `parts.ts`): carried across a rebuild, dropped for another model
 *   (M13, M15). Hiding sets the parts' objects' `visible` -- the export was
 *   decoded for the tab alone.
 * - **Its keys are MrDebug actions** (`ctx.keys.add`), made in `model-keys.ts`
 *   from a state of getters and the tab's doings -- which wins where two share
 *   a key, and Esc's order, a table its test reads -- listed under Model on
 *   the keys card and Config ▸ Keys, live while the tab is up and its side has
 *   them; the toolbar's tips and the panels' titles name them.
 * - **What it shows, as facts** for Claude's turn (M20): the script, the
 *   export, the build, the parts selected and the parts hidden, the views.
 * - **Canvases and Claude** (phase 3, M26-M30): the left panel's Canvases
 *   pane is the paint mode (`canvases.ts`, `canvas-panel.ts`) -- the left
 *   button draws over a view, each drawing a canvas with its camera; while
 *   the tab is up a turn of the Claude card carries the model and every
 *   canvas going (`attachments`), shown over the card's box. A script whose
 *   export is held for a Claude turn shows each save as a preview build, the
 *   chip saying "Claude is editing" (M21). A part's Delete asks Claude, in
 *   words put in the card's box (M30).
 */
import * as THREE from 'three';
import type { ModelAnswer, ModelDiagnostic, ModelNode } from '@vibe/pipeline/assets-types';
import { keyLabel, modName, MrDebug } from '@vibe/engine/debug';
import { createApi } from '../assets/api.ts';
import { shippedFiles } from '../assets/boot.ts';
import { createLive } from '../assets/live.ts';
import { decodeScratch } from '../assets/preview/scratch.ts';
import { TOOLS_PAGE } from '../config/tools.ts';
import type { IconName } from '../icons.ts';
import { createMenu, type MenuItem } from '../menu.ts';
import { showDialog } from '../dialog.ts';
import { extOf } from '@vibe/pipeline/paths';
import { projectKey } from '@vibe/engine/project-key';
import { keepPref, loadPrefs, storedPrefs, MODEL_FOLDS_MAX, SHADINGS, type ModelPrefs, type Shading } from '../prefs.ts';
import { navLine } from '../keys-card.ts';
import { scrollLine } from '../view/navigation.ts';
import type { ClickHow, Combine } from '../selection.ts';
import { addSheet, button, control, el, icon, iconButton, letGo, tip } from '../shell.ts';
import type { Mcp } from '../mcp/declare.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import type { EditorContext, EditorTab, ToolFact, ToolInstance } from '../tool.ts';
import { tabId } from '../tab-pages.ts';
import type { ModelTurn } from '@vibe/pipeline/agent-types';
import type { TurnAttachments } from '../agent/context.ts';
import { createAnimating } from './animating.ts';
import { createCanvasPanel } from './canvas-panel.ts';
import { createCanvases, MARQUEES, readCarried, type Canvas, type CarriedCanvas, type PaintTool } from './canvases.ts';
import { createEditing } from './editing.ts';
import { createModelAgent } from './model-agent.ts';
import { switchingHistory } from './history-switch.ts';
import { createInspector, stateWords } from './inspector.ts';
import { createExportRow, readExportOptions, type ExportOptions } from './export-row.ts';
import css from './model.css?inline';
import { createOutliner, type Pane } from './outliner.ts';
import { boxParts, clickPart, count, eyeClick, hiddenOf, withChildren, type Part, type PartTree } from './parts.ts';
import { forgotten, shown, type PerModel } from './per-model.ts';
import { createSource, modelName, scriptProblem, touches, type BuildState } from './source.ts';
import { createStage } from './stage.ts';
import { readPoses, type ViewPose } from '../view/view-camera.ts';
import { kernelByName, statsOf, statsRows } from './stats.ts';
import { createTracing } from './tracing.ts';
import { LAYOUTS, nextLayout, type Layout } from './views.ts';
import { createRoom } from './model-room.ts';
import { escapeTarget, modelKeys, type ModelKeyState } from './model-keys.ts';
import { keymapNow, tabKey } from '../editor-keys.ts';

/** Where the canvases wait across a reload (M28) -- at the project's id: its scripts' drawings -- and for how long they are fresh. */
const CANVASES_KEY = projectKey('vibebase.model.canvases');
const CANVASES_MS = 120_000;

/** The Model tab's id: what `showTool` and `openModel` bring up. */
export const MODEL_ID = tabId('model');

export const modelTool: EditorTab = {
  id: MODEL_ID,
  name: 'Model',
  icon: 'model',
  key: tabKey('model'),
  help: 'The editor\'s Model tab: a Gladius script\'s model in one, two or four views, its parts, its live rebuild',
  create: (ctx) => createModel(ctx),
};

/** How long a line the tab says itself stays on the status line, in milliseconds. */
const SAID_MS = 8000;

const SHADING_LOOKS: Readonly<Record<Shading, { icon: IconName; words: string }>> = {
  shaded: { icon: 'shaded', words: 'Shaded' },
  'shaded-wireframe': { icon: 'shadedWire', words: 'Shaded with its wires: the polygons heavy, the triangles faint' },
  wireframe: { icon: 'wireframe', words: 'Wireframe: the polygons heavy, the triangles under them' },
};

const LAYOUT_LOOKS: Readonly<Record<Layout, { icon: IconName; words: string }>> = {
  1: { icon: 'layout1', words: 'One view' },
  2: { icon: 'layout2', words: 'Two views: Free and Front' },
  4: { icon: 'layout4', words: 'Four views: Top, Free, Front, Right' },
};

function createModel(ctx: EditorContext): ToolInstance {
  const dropSheet = addSheet(css);
  let prefs: ModelPrefs = loadPrefs().model;
  const keep = (change: Partial<ModelPrefs>): void => {
    // What is kept now -- a model pref changed in Config ▸ Editor ▸ Preferences or another tab since -- under this change, never
    // this tab's older copy over it; nothing kept, or the storage refusing, this tab's own.
    prefs = { ...(storedPrefs()?.model ?? prefs), ...change };
    keepPref('model', prefs);
  };

  // ---------------------------------------------------------------- the room: toolbar, banner, views

  // Before the side panels: their grips and folded tabs lie over its edges.
  const room = el('div', 'ed-mo-room');
  room.hidden = true;
  const bar = el('div', 'ed-mo-bar');
  const banner = el('div', 'ed-mo-banner');
  banner.hidden = true;
  const viewsEl = el('div', 'ed-mo-views');
  const empty = el('div', 'ed-mo-empty');
  empty.hidden = true;
  viewsEl.append(empty);
  room.append(bar, banner, viewsEl);
  ctx.root.append(room);

  // ---------------------------------------------------------------- what is open

  /** Its own client of the dev server's API and index (M5): never the Assets panel's answer sink. */
  const api = createApi({ bundle: shippedFiles });
  const live = createLive(api);
  let tree: PartTree | null = null;
  let scene: THREE.Object3D | null = null;
  let selection: string[] = [];
  let hidden = new Set<string>();
  let kernel = new Map<string, ModelNode>();
  let answer: ModelAnswer | null = null;
  let told: readonly ModelDiagnostic[] = [];
  let visible = false;
  let inspecting = true;
  let writes = false;
  /** A line of the tab's own on the status line, and until when. */
  let notice: { text: string; until: number } | null = null;
  void api.online().then((online) => {
    writes = online === 'write';
  });

  /** What the open script's last export did worth reading: hidden surfaces removed, samples dropped (M41, M42). */
  let buildNotes: readonly string[] = [];
  const source = createSource({
    api,
    live,
    decode: (path) => decodeScratch(path, { api, entryAt: (p) => live.index.entries.get(p) }),
    model: (scratch, first) => {
      // The export in: a preview shown for a drag put away for it.
      editing.exportShown();
      showModel(scratch.scene, first, scratch.animations);
      // The canvases drawn over another export of it -- rebuilt while another model was open -- are stale (D74, M28).
      const exported = source.exportPath ? live.index.entries.get(source.exportPath) : undefined;
      if (exported) canvases.shown(`${exported.mtime}:${exported.size}`);
      if (first) adoptCarried();
    },
    state: () => {
      if (source.state.kind === 'ready' || source.state.kind === 'none') void readOptions();
      // A key just written that does not build: said where it was keyed, not only in the banner.
      const st = source.state;
      if (st.kind === 'failed') {
        const first = st.lines.find((d) => d.severity === 'error') ?? st.lines[0];
        animating.built(first ? `${first.line !== undefined ? `line ${first.line}: ` : ''}${first.message.replace(/^[^:\n]*\.lua:\d+:\s*/, '')}` : st.error);
      }
      drawBanner();
      drawPanels();
    },
    notes: (notes) => {
      buildNotes = notes;
      if (source.path !== null) drawPanels();
    },
    kernel: (got) => {
      // What Gladius said of the build -- its info() lines, its warnings (Vibe3D D35's log) -- for the right panel.
      told = got ? got.diagnostics : [];
      kernel = got ? kernelByName(got.nodes) : new Map();
      // Each kernel node's lines follow the part made of it -- by the name three.js gave it -- hidden with it; and only
      // a node whose triangles are that part's (M4's rule, the counts' too): the query runs the script as it is now, which
      // may be a save past the export shown, or one whose export failed after Gladius. Those are triangles only.
      const partOf = new Map<ModelNode, Part>();
      for (const [name, node] of kernel) {
        const part = tree?.all.find((p) => p.object.name === name);
        if (part && part.triangles === node.triangles) partOf.set(node, part);
      }
      const matched = got ? got.nodes.filter((node) => partOf.has(node)) : [];
      answer = got && matched.length > 0 ? got : null;
      stage.setPolygons(answer ? matched : null, answer ? (node) => partOf.get(node)?.object ?? null : null);
      drawBar();
      drawStats();
      drawPanels();
    },
    held: () => isHeld(),
    // The live list, asked before a stale script is exported here (M21): the push may be on its way; heard, it is ours too.
    heldNow: () => api.held().then((answer) => {
      setHeld(answer.held);
      return { held: answer.held, turns: answer.turns ?? false };
    }),
  });

  const stage = createStage({
    host: viewsEl,
    room,
    watch: ctx.root,
    click: (object, how) => clickOn(object, how),
    box: (objects, how) => boxed(objects, how),
    menu: (object, x, y) => partMenu(object ? (tree?.byObject.get(object)?.id ?? null) : null, x, y),
    pickable: () => pickable(),
    partOf: (object) => partObject(object),
    changed: () => drawBar(),
    said: (line) => say(line),
    scrolled: (trackpad) => say(scrollLine(trackpad)),
    held: (code) => MrDebug.held(code),
    // The Canvases pane up: the left button draws (M28). Made below; asked only once the tab shows.
    paint: {
      active: () => canvases.painting && tree !== null,
      down: (view, x, y) => canvases.down(view, x, y),
      move: (x, y) => canvases.move(x, y),
      up: () => canvases.up(),
      cancel: () => canvases.cancel(),
      hover: (view, x, y) => canvases.hover(view, x, y),
      prepare: (view) => canvases.prepare(view),
      drawn: () => canvases.drawn(),
      rested: (view) => canvases.rested(view),
    },
    // Phase 5: the build trace's cut lines, their width in each view's pixels (M36). Made below; asked only once the tab shows.
    trace: { prepare: (width, height) => tracing.prepare(width, height) },
    // Phase 4: the bones and the pose gizmo (M31-M33). Made below; asked only once the tab shows.
    pose: {
      // A build step in the model's place: no bone under the pointer, no gizmo to grab -- they are the model's.
      grabbing: () => !tracing.showing && animating.stage.grabbing(),
      hover: (view, height, x, y) => animating.stage.hover(tracing.showing ? null : view, height, x, y),
      drawing: (view, height) => animating.stage.drawing(view, height),
      pick: (view, x, y) => (tracing.showing ? null : animating.stage.pick(view, x, y)),
      place: () => animating.stage.place(),
    },
  });
  const outliner = createOutliner(ctx.root, {
    choose: (id, how) => select(clickPart(selection, outliner.shown(), id, how)),
    eye: (id) => {
      const r = eyeClick(hidden, selection, id);
      setHidden(r.hidden);
      say(`${r.hide ? 'Hidden' : 'Shown'}: ${r.ids.length > 1 ? `${r.ids.length} parts` : (tree?.byId.get(id)?.name ?? id)}`);
    },
    frame: (id) => {
      if (!selection.includes(id)) select([id]);
      frameSelection();
    },
    menu: (id, x, y) => partMenu(id, x, y),
    files: (at) => filesMenu(at),
    close: () => close(),
    pane: (next) => setPane(next),
  });
  const inspector = createInspector(ctx.root, {
    reveal: (path) => {
      if (!ctx.revealAsset(path)) say(`${path}: the Assets panel is not here to show it`);
    },
    build: () => void build(),
    edit: () => edit(),
    frame: () => frameSelection(),
    hide: () => hideSelection(),
    writes: () => writes,
    unbuildable: () => unbuildable(),
    exportRow: () => exportRow.root,
    close: () => close(),
  });
  /** The card's export row (M41, M42): cull, clean, merge, each one step; All options… the Assets inspector's block. */
  const exportRow = createExportRow({
    blocked: () => (!writes ? 'Read only: models are changed on the machine running the dev server' : source.state.kind === 'excluded' ? 'Out of the build: never exported' : isHeld() ? 'Held for Claude\'s turn: set it once the turn ends' : null),
    set: (name, value) => {
      const file = source.path?.split('/').pop() ?? 'the script';
      void editing.editRecord(`${file}'s ${name} → ${String(value)}`, (o) => ({ ...o, [name]: value })).then(() => void readOptions());
    },
    all: () => {
      if (source.path && !ctx.modelFiles.options(source.path)) say('The Assets panel is not here: its inspector has every export option');
    },
  });
  let exportOptions: ExportOptions | null = null;
  /** The export's options read again -- as the model opens, after each build and each change from the row. */
  let optionsAsk = 0;
  async function readOptions(): Promise<void> {
    const path = source.path;
    const mine = ++optionsAsk;
    if (!path) {
      exportOptions = null;
      return exportRow.draw(null);
    }
    const read = async (p: string): Promise<string | null> => {
      // Only what the index has: a folder with no export.json is asked nothing (no 404 in the console).
      if (!live.index.entries.has(p)) return null;
      try {
        const r = await api.file(p);
        return r.ok ? await r.text() : null;
      } catch {
        return null;
      }
    };
    const got = await readExportOptions(path, read).catch(() => null);
    if (mine !== optionsAsk || path !== source.path) return;
    exportOptions = got;
    exportRow.draw(got);
  }
  const menu = createMenu(ctx.root, room);

  // Phase 2: parameters, materials, and the undo over them (Docs/modeler.md M22–M25), in the right panel under the facts.
  const editing = createEditing({
    api,
    live,
    heldForClaude: () => isHeld(),
    path: () => source.path,
    writes: () => writes,
    readOnly: () => (source.state.kind === 'excluded' && source.state.underscore ? 'Read only: out of the build by its _ name -- rename it without the _ to build and change it here.' : null),
    say: (text) => say(text),
    showPreview: (preview, animations) => showModel(preview, false, animations),
    reshow: () => {
      if (!source.reshow()) drawAll();
    },
    select: (ids) => select(ids),
    draw: () => stage.draw(),
    changed: () => drawBar(),
    folds: () => prefs.folds,
    keepFold: (key, folded) => keepFold(key, folded),
    outside: (label) => animating.outside(label),
  });
  /** A block's fold kept, the newest choices at most `MODEL_FOLDS_MAX`. */
  function keepFold(key: string, folded: boolean): void {
    const folds = { ...prefs.folds };
    delete folds[key];
    folds[key] = folded;
    const keys = Object.keys(folds);
    for (const k of keys.slice(0, Math.max(0, keys.length - MODEL_FOLDS_MAX))) delete folds[k];
    keep({ folds });
  }

  /** A build step shown (phase 5) -- asked by the animation while it is being made, before the trace exists: none then. */
  let traceShown = (): boolean => false;
  // Phase 4: the clips, the bones, the weight maps, the pose keyed into the script (Docs/modeler.md M31-M33).
  const animating = createAnimating({
    scene: stage.overlayRoot,
    element: viewsEl,
    draw: () => stage.draw(),
    say: (text) => say(text),
    setPosed: (posed) => stage.setPosed(posed),
    changed: () => {
      drawStats();
      canvasesChanged();
    },
    scriptPath: () => source.path,
    scriptText: () => editing.scriptText(),
    askClaude: (text) => ctx.askClaude(text),
    keepEveryKey: () => editing.editRecord(`${source.path?.split('/').pop() ?? 'the script'}'s anim → 0: every key kept`, (o) => ({ ...o, anim: 0 })),
    editScript: (label, change) => editing.editScript(label, change),
    writing: () => editing.writing,
    readOnly: () => (writes ? (source.state.kind === 'excluded' && source.state.underscore ? 'Read only: out of the build by its _ name -- rename it without the _ to key a pose here.' : null) : 'Read only: models are changed on the machine running the dev server.'),
    held: () => isHeld(),
    folds: () => prefs.folds,
    keepFold: (key, folded) => keepFold(key, folded),
    prefs: () => ({ bones: prefs.bones, autoKey: prefs.autoKey, speed: prefs.speed }),
    keepPrefs: (change) => keep(change),
    traced: () => traceShown(),
    leaveTrace: () => {
      tracing.leave();
      say(`Back to the model to play the clip: the build trace kept where it stands -- ${keyLabel('Shift+KeyT')} returns to it`);
    },
  });
  // Phase 5: the build trace (Docs/modeler.md M34-M37) -- its block after Materials, its strip in the clips' strip's place.
  const tracing = createTracing({
    api,
    live,
    stage,
    path: () => source.path,
    overrides: () => editing.overrides(),
    blocked: () => (writes ? null : 'Traced on the machine running the dev server: this page may not run Gladius'),
    say: (text) => say(text),
    changed: () => traceChanged(),
    stepped: () => drawStats(),
    folds: () => prefs.folds,
    keepFold: (key, folded) => keepFold(key, folded),
    prefs: () => ({ traceSpeed: prefs.traceSpeed, traceView: prefs.traceView }),
    keepPrefs: (change) => keep(change),
  });
  tracing.setShading(stage.shading);
  traceShown = () => tracing.showing;
  // The right panel: Parameters, then the clips and the pose, then Materials -- what is worked with first -- then the trace.
  inspector.mount(editing.blocks[0]!, animating.block, ...editing.blocks.slice(1), tracing.block);
  room.append(animating.strip, tracing.strip);

  /** The trace shown or not, played or not: the clips' strip gives way, the stats are the step's, the canvases follow it. */
  function traceChanged(): void {
    room.classList.toggle('ed-mo-tracing', tracing.showing);
    // The steps are static meshes: no clip plays over them, no bone is under the pointer.
    if (tracing.showing) {
      animating.pause();
      animating.stage.hover(null, 0, 0, 0);
    }
    // The Pose block says it waits for the model (or offers itself again).
    animating.redraw();
    drawStats();
    canvasesChanged();
    stage.draw();
  }

  // ---------------------------------------------------------------- a Claude turn editing the script (M21)

  /** The Gladius scripts whose shipped export waits for a Claude turn's end: each save shown here as a preview instead. */
  let held: string[] = [];
  const isHeld = (): boolean => source.path !== null && held.includes(source.path);
  /** The script's version last previewed while held: a save heard once. */
  let heldVersion = '';
  const scriptVersion = (): string => {
    const e = source.path ? live.index.entries.get(source.path) : undefined;
    return e ? `${e.mtime}:${e.size}` : '';
  };
  /** A save of the script while its export is held: built as a preview, shown as a rebuild (D44). */
  function previewSave(): void {
    if (!isHeld() || !writes) return;
    const version = scriptVersion();
    if (version === heldVersion) return;
    heldVersion = version;
    editing.savedPreview();
  }
  /** The held list heard -- pushed, or read again -- and what it changes here. */
  function setHeld(list: readonly string[]): void {
    const was = isHeld();
    held = [...list];
    if (isHeld() && !was) {
      heldVersion = '';
      // The save that made it held reached the page first, as an edit from outside: it is the turn's.
      editing.claimedByTurn();
      say(`${source.path?.split('/').pop()}'s export is held while a Claude turn runs: each save shows here as a preview -- the shipped model is exported once no turn runs`);
    }
    previewSave();
    // The turn over: its export is made now -- or, the script as it was before (a turn put back what it changed), not at all;
    // then nothing arrives to put the preview away, and the export is shown again once the source has settled.
    if (was && !isHeld()) {
      // The line said "held while a Claude turn runs": said again now that it does not.
      say(`Claude's turn is over: ${source.path?.split('/').pop()}'s export is made from the script as it is now -- ${keyLabel('KeyZ')} takes back each of its edits`);
      clearTimeout(heldBack);
      heldBack = setTimeout(() => {
        if (editing.previewing && !editing.building && source.state.kind !== 'building' && !isHeld() && !source.reshow()) drawAll();
      }, 1500);
    }
    // Held or not: the right panel's state line says so too, as the chip does (the Key's refusal with it).
    if (was !== isHeld()) {
      drawPanels();
      animating.redraw();
    } else drawBar();
  }
  const offHeld = live.on('held', (list) => setHeld(list));
  let heldBack: ReturnType<typeof setTimeout> | undefined;
  // The page heals a `held` it missed (review round 2): the script moving asks the list again -- now, and once the
  // server has settled the save -- and while it is held the list is read again every few seconds until it is not.
  let heldAgain: ReturnType<typeof setTimeout> | undefined;
  const offSaved = live.on('changed', (diff) => {
    // A script deleted or renamed away: its canvases put away are no one's now (a reload would carry them for ever).
    if ('from' in diff && diff.removed.length > 0) canvases.forget(diff.removed);
    previewSave();
    if (!source.path || !touches(diff, source.path, source.exportPath)) return;
    askHeld();
    clearTimeout(heldAgain);
    heldAgain = setTimeout(askHeld, 1500);
  });
  const heldPoll = setInterval(() => {
    if (visible && isHeld()) askHeld();
  }, 3000);
  /** The list as it is now: asked as a model opens -- a page loaded mid-turn -- and again to heal a push missed. */
  function askHeld(): void {
    void live.start().then(() => api.held()).then((answer) => setHeld(answer.held), () => {});
  }

  // ---------------------------------------------------------------- canvases (phase 3, M26-M28)

  /** The left panel's pane: the parts, or the canvases -- paint mode (D63). */
  let pane: Pane = 'parts';
  const canvases = createCanvases({
    scene: stage.scene,
    renderer: () => stage.renderer(),
    background: () => stage.background,
    views: () => stage.paintViews(),
    overlays: () => [stage.outlineGroup, ...animating.overlays],
    // The pose a canvas is drawn over, and put back as it is reopened (Vibe3D D89, D69).
    pose: () => animating.pose,
    goToPose: (pose) => animating.goTo(pose),
    // ...and the build step (D69): reopened, it is shown again -- or, drawn over the model, the model (D86).
    step: () => tracing.stepRef(),
    goToStep: (ref) => tracing.goTo(ref),
    radius: () => stage.radius,
    selected: () => selectedParts().map((p) => p.name),
    hidden: () => (tree ? tree.all.filter((p) => hidden.has(p.id)).map((p) => p.name) : []),
    restore: (names, off) => {
      if (!tree) return;
      setHidden(new Set(tree.all.filter((p) => off.includes(p.name)).map((p) => p.id)));
      select(tree.all.filter((p) => names.includes(p.name)).map((p) => p.id));
    },
    // Over a build step its meshes are what the marks land on; over the model, its parts.
    targets: (step) => (step ? (tracing.meshesAt(step) ?? pickable()) : pickable()),
    partName: (object) => {
      const traced = tracing.nameOf(object);
      if (traced) return traced;
      const part = partObject(object);
      return part ? (tree?.byObject.get(part)?.name ?? null) : null;
    },
    overlay: viewsEl,
    changed: () => canvasesChanged(),
    draw: () => stage.draw(),
    say: (text) => say(text),
  });
  const canvasPanel = createCanvasPanel(outliner.canvasPane, canvases, {
    undo: () => {
      if (canvases.open?.history.undo()) canvasesChanged();
    },
    remove: (id) => removeCanvas(id),
    keys: {
      tool: { brush: keyLabel('KeyX'), eraser: keyLabel('KeyX'), rect: keyLabel('KeyM'), ellipse: keyLabel('KeyM'), lasso: keyLabel('KeyM') },
      erase: keyLabel('KeyX'),
      marquee: keyLabel('KeyM'),
      smaller: keyLabel('BracketLeft'),
      bigger: keyLabel('BracketRight'),
      copy: keyLabel('Mod+KeyC'),
      cut: keyLabel('Mod+KeyX'),
      paste: keyLabel('Mod+KeyV'),
      delete: keyLabel('Delete'),
      undo: keyLabel('KeyZ'),
      pane: keyLabel('KeyC'),
    },
  });
  /**
   * The editor's Z, Y and History card: the tab's stack (M23) -- or, in paint mode with a canvas open, that canvas's own,
   * so Z takes back its last stroke and nothing of the model (M28, Vibe3D's per-layer undo).
   */
  // The first Z past an open canvas's last step is held and said: the next one reaches the model's own -- a script step.
  const tabHistory = switchingHistory(editing.history, (label) => say(`The canvas's own steps are all undone: the next ${keyLabel('KeyZ')} undoes ${label} on the model`));
  outliner.setPane('parts', 0);
  // A canvas's Z and Y said on the line with what they took back, as the model's steps are -- a step of the canvas's own
  // alone (its stack moved), not the model's under it, which editing.ts says.
  let canvasAt: { stack: unknown; done: number } = { stack: null, done: 0 };
  tabHistory.on((event) => {
    const stack = tabHistory.current;
    const moved = canvasAt.stack === stack && canvasAt.done !== stack.done;
    canvasAt = { stack, done: stack.done };
    if (stack === editing.history || !moved) return;
    if (event === 'undo' && stack.redoLabel) say(`Undid ${stack.redoLabel}`);
    else if (event === 'redo' && stack.undoLabel) say(`Redid ${stack.undoLabel}`);
    if (event === 'undo' || event === 'redo') canvasPanel.draw();
  });

  /** Something of the canvases changed: the pane, the tab's count, the stack in use, the card's line. */
  function canvasesChanged(): void {
    const open = canvases.open;
    // A canvas open in paint mode: its stack first, and the model's under it for Z and Y when it has nothing to give.
    tabHistory.use(canvases.painting && open ? open.history : editing.history, canvases.painting && open ? editing.history : null);
    canvasPanel.draw();
    outliner.setPane(pane, canvases.list.length);
    drawBar();
    ctx.turnChanged();
  }

  /** Parts, or Canvases: the paint mode is the Canvases pane being up (D63). */
  function setPane(next: Pane): void {
    if (next === 'canvases' && !tree) return say('No model shown to draw over yet');
    // A canvas is a drawing over one frame (D89): playback held.
    if (next === 'canvases') animating.pause();
    pane = next;
    canvases.setPainting(next === 'canvases');
    room.classList.toggle('ed-mo-painting', next === 'canvases');
    if (next === 'canvases' && canvases.list.length === 0) say(`Draw on a view: the first stroke captures it as a canvas for Claude -- Alt-drag orbits, a right drag pans, ${keyLabel('KeyC')} goes back to the parts`);
    canvasesChanged();
    stage.draw();
  }

  /** A canvas deleted: a step of the tab's own stack, which brings it back. */
  function removeCanvas(id: string): void {
    const at = canvases.list.findIndex((c) => c.id === id);
    const gone: Canvas | null = canvases.remove(id);
    if (!gone) return;
    editing.history.push({
      label: `Delete canvas ${gone.name}`,
      undo: () => canvases.restoreCanvas(gone, at),
      redo: () => void canvases.remove(gone.id),
      // Let go of for good -- fallen off the stack, the stack reset: freed, unless its undo had put it back.
      drop: () => {
        if (!canvases.owns(gone)) gone.dispose();
      },
    });
    canvasesChanged();
    say(`${gone.name} deleted -- ${keyLabel('KeyZ')} brings it back`);
  }

  // ---------------------------------------------------------------- the model shown

  /** Cameras kept across a reload, for the script they were of: put back as it first loads, in place of a framing (M18). */
  let posesFor: { source: string; poses: (ViewPose | null)[] } | null = null;

  /** A model decoded (`first`: opened, else a rebuild), its clips: parts read, the selection and the hidden carried by name. */
  function showModel(next: THREE.Object3D | null, first: boolean, animations: readonly THREE.AnimationClip[]): void {
    // The rules of what a model shown keeps of the one before -- a rebuild, a preview -- and what it does not: `per-model.ts`.
    put(shown(now(), next, first));
    // A rebuild under the canvases: each a picture of a model that is not there any more -- kept, marked, not sent (D74, D80).
    if (!first) canvases.markStale();
    applyHidden();
    stage.setPolygons(null, null);
    stage.setModel(next, first);
    if (first && posesFor && posesFor.source === source.path) stage.setPoses(posesFor.poses);
    if (first) posesFor = null;
    stage.setOutline(selectedObjects());
    // The clips on the model shown: the clip, its time and a pose carried by name (D89).
    animating.setModel(next, animations, first);
    animating.selection(selectedObjects());
    editing.model(tree, next);
    editing.selection(selection);
    drawAll();
  }

  /** What the tab holds of the model open, as one value (`per-model.ts`), and put back from one. */
  const now = (): PerModel => ({ scene, tree, selection, hidden, kernel, answer, told });
  function put(next: PerModel): void {
    ({ scene, tree, selection, hidden, kernel, answer, told } = next);
  }

  /**
   * The one way the model open is let go -- another script opened, the tab closed: every per-model thing at once (the
   * views, the polygons, the outline, the selection, the hidden parts, what Gladius said, the counts, the materials, a
   * menu on a part), whether or not the next script ever shows a model. The banner, the chip, the outliner and the
   * panels are drawn from it by the `drawAll` that follows; the parameters and the undo are `editing.open`'s.
   */
  function forget(): void {
    menu.close();
    put(forgotten());
    // The canvases are kept by script (M28): the open one's put away with its model, as `open` brings the next's out.
    if (pane === 'canvases') {
      pane = 'parts';
      canvases.setPainting(false);
      room.classList.remove('ed-mo-painting');
    }
    stage.setPolygons(null, null);
    stage.setOutline([]);
    stage.setModel(null, true);
    stage.setStats(null);
    animating.setModel(null, [], true);
    editing.model(null, null);
    editing.selection([]);
  }

  /** The objects drawn and not: each part's own eye (an ancestor's hides it with it, as three draws). */
  function applyHidden(): void {
    for (const part of tree?.all ?? []) part.object.visible = !hidden.has(part.id);
  }

  const selectedParts = (): Part[] => (tree ? selection.map((id) => tree!.byId.get(id)).filter((p): p is Part => p !== undefined) : []);
  const selectedObjects = (): THREE.Object3D[] => selectedParts().map((p) => p.object);

  /** What a click or a box may take: every part's meshes drawn just now. */
  function pickable(): THREE.Object3D[] {
    const out: THREE.Object3D[] = [];
    // A build step in the model's place: no part of the model under a click.
    if (tracing.showing) return out;
    for (const part of tree?.all ?? []) if ((part.kind === 'mesh' || part.kind === 'skinned') && !hiddenOf(part, hidden)) out.push(part.object);
    return out;
  }

  /** A hit object's part's object: itself if it is a part, else its nearest part above it. */
  function partObject(object: THREE.Object3D): THREE.Object3D | null {
    for (let o: THREE.Object3D | null = object; o; o = o.parent) if (tree?.byObject.has(o)) return o;
    return null;
  }

  function select(ids: readonly string[]): void {
    selection = [...ids];
    editing.selection(selection);
    // The bones among them: their weight map, the first posed (M32, M33).
    animating.selection(selectedObjects());
    // The open canvas, in paint mode, takes the selection made after drawing too (D29).
    canvases.selectionChanged(selectedParts().map((p) => p.name));
    stage.setOutline(selectedObjects());
    drawStats();
    drawPanels();
    // Choosing a part makes the right panel this tab's again.
    if (selection.length > 0) ctx.inspect();
    if (selection[0]) outliner.reveal(selection[0]);
  }

  function clickOn(object: THREE.Object3D | null, how: ClickHow): void {
    // A build step shown: its meshes are not parts -- the selection kept for the model's return.
    if (tracing.showing) return void say(`A build step is shown in the model's place: ${keyLabel('Escape')} or Back to the model to pick its parts`);
    const id = object ? (tree?.byObject.get(object)?.id ?? null) : null;
    if (id === null) {
      // A bone posed at a held frame is kept by a click on nothing -- a press that missed the gizmo's ring by a hair
      // must not drop it (M33); Esc, or another part or bone, lets it go.
      if (how === 'one' && animating.posing) return say(`The bone stays chosen while it is posed: ${keyLabel('Escape')} lets it go, or click another part or bone`);
      // A click on nothing, alone, lets the selection go; with a modifier it keeps it.
      if (how === 'one' && selection.length > 0) select([]);
      return;
    }
    select(clickPart(selection, [], id, how === 'range' || how === 'add-range' ? 'add' : how));
  }

  function boxed(objects: readonly THREE.Object3D[], how: Combine): void {
    if (tracing.showing) return void say(`A build step is shown in the model's place: ${keyLabel('Escape')} or Back to the model to pick its parts`);
    const ids = objects.map((o) => tree?.byObject.get(o)?.id).filter((id): id is string => id !== undefined);
    // An empty box is a press that missed too: the bone posed stays (M33).
    if (ids.length === 0 && animating.posing) return say(`The bone stays chosen while it is posed: ${keyLabel('Escape')} lets it go`);
    select(boxParts(selection, ids, how));
    say(ids.length === 0 ? 'The box held no part\'s middle' : `${ids.length} ${ids.length === 1 ? 'part' : 'parts'} in the box`);
  }

  function setHidden(next: Set<string>): void {
    hidden = next;
    applyHidden();
    stage.setOutline(selectedObjects());
    stage.draw();
    drawStats();
    drawPanels();
  }

  /** Shift+H: the selection hidden -- or, all of it hidden already, shown (the Scene tab's rule). */
  function hideSelection(): void {
    if (selection.length === 0) return say('Nothing selected to hide: click a part, in the views or on the left');
    const all = selection.every((id) => hidden.has(id));
    const next = new Set(hidden);
    for (const id of selection) {
      if (all) next.delete(id);
      else next.add(id);
    }
    setHidden(next);
    say(`${all ? 'Shown' : 'Hidden'}: ${selection.length > 1 ? `${selection.length} parts` : selectedParts()[0]?.name} · ${keyLabel('Shift+KeyH')} again ${all ? 'hides' : 'shows'} them`);
  }

  function showOnly(id: string): void {
    if (!tree) return;
    const keepIds = new Set([id, ...withChildren(tree, [id]).map((p) => p.id)]);
    for (let p = tree.byId.get(id)?.parent ?? null; p; p = p.parent) keepIds.add(p.id);
    setHidden(new Set(tree.all.filter((p) => !keepIds.has(p.id)).map((p) => p.id)));
  }

  function frameSelection(): void {
    stage.frame(selectedParts().length > 0 ? selectedObjects() : null);
  }

  // ---------------------------------------------------------------- opening

  /** `path` opened: a script, or an export's script; false, said, for anything else. */
  function open(path: string, room = false): boolean {
    const problem = scriptProblem(path);
    if (problem) {
      // An export: its source, once the index has it.
      if (/\.(glb|gltf)$/i.test(path)) {
        void live.start().then(() => {
          const entry = live.index.entries.get(path);
          const from = entry?.source;
          if (from && scriptProblem(from) === null) open(from);
          // A .glb delivered as it is (Vibe3D D49): offered a script that imports it, the one way it can be changed here.
          else if (entry?.role === 'loose' && entry.kind === 'models' && extOf(path) === 'glb') offerScript(path);
          else say(`${path} is not built from a Gladius script: the Model tab opens a .lua`);
        }, () => say('No dev server: the Model tab cannot read the index'));
        return true;
      }
      say(problem);
      return false;
    }
    if (source.path === path && source.state.kind !== 'none' && source.state.kind !== 'gone') {
      // Asked again -- the Assets inspector's Back to the model: its card in the right panel.
      ctx.inspect();
      say(`${modelName(path)} is open`);
      return true;
    }
    forget();
    exportOptions = null;
    // The model before's notes ("hidden surfaces removed …") are not this one's: its own come with its build.
    buildNotes = [];
    canvases.openFor(path);
    keep({ source: path });
    editing.open(path);
    tracing.open(path);
    void source.open(path);
    heldVersion = '';
    askHeld();
    // A model opened is chosen here: the right panel its card -- its build, Export options, its blocks -- not the file
    // the Assets panel chose last (a New model, an import, Make a script land in the Model tab to be worked on).
    ctx.inspect();
    drawAll();
    // The tab's room rule as a model opens, not only as the tab comes up: an import or Make a script landing here at a
    // small window gets views to look at (a panel the person unfolded here stays so).
    requestAnimationFrame(() => viewRoom.fit({ made: room }));
    return true;
  }

  /**
   * A `.glb` with no script (M39; Vibe3D D49), asked to open: the Model tab works on a script -- a parameter, a canvas,
   * Claude all change the script -- so it offers to make one, the file copied in and imported; never made unasked.
   */
  function offerScript(glb: string): void {
    const file = glb.split('/').pop() ?? glb;
    showDialog({
      title: `${file} has no script`,
      text: `The Model tab shows and changes a Gladius script's model. Make a script for it: ${file} copied into AssetsSource/ beside a script that imports it, pinned by its hash -- its parts, colours, skin and clips kept -- built as its export, the key unchanged, and opened here. What ships is then Gladius's rebuild of the file -- welded, its quads recovered, normals sampled, its materials named ${file.replace(/\.glb$/i, '')}:<material> -- not its bytes. Z in the Assets panel undoes it.`,
      buttons: [{ label: 'Make a script for it', kind: 'accent', title: 'One step of the Assets panel\'s: the script, its copy, its export', run: () => void ctx.modelFiles.adoptModel(glb) }],
    });
  }

  function close(): void {
    forget();
    buildNotes = [];
    canvases.openFor(null);
    source.close();
    editing.open(null);
    tracing.open(null);
    keep({ source: '' });
    drawAll();
  }

  /** Why the script open cannot be built here, or null: out of the build -- by its `_` name, or its record. */
  function unbuildable(): string | null {
    if (source.state.kind === 'gone') return 'Not there: the script was renamed, moved or deleted -- close it';
    if (source.state.kind !== 'excluded') return null;
    return source.state.underscore
      ? 'Not built: out of the build by its _ name -- rename it without the _ to build it'
      : `Not built: out of the build -- tick it in the Assets panel (${keyLabel('Shift+KeyB')} on it) to build it`;
  }

  async function build(): Promise<void> {
    if (!source.path) return say('No model open to build');
    const why = unbuildable();
    if (why) return say(why);
    if (!(await source.build())) say(writes ? 'Not built: see the banner' : 'This page may not export: build it on the machine running the dev server');
    else say(`${modelName(source.path)} sent to be built: the bar and the banner say how it goes`);
  }

  function edit(): void {
    const path = source.path;
    if (!path) return;
    api.reveal(path, true).then(
      () => say(`Opened ${path} in the application this machine edits it with: saved, it rebuilds here`),
      (err: Error) => say(`${path} did not open: ${err.message}`),
    );
  }

  // ---------------------------------------------------------------- the toolbar

  const barButton = (mcp: Mcp, glyph: IconName, run: () => void): HTMLButtonElement => letGo(iconButton(mcp, glyph, '', run, 'ed-bar-button'));
  const sep = (): HTMLElement => el('i', 'ed-mo-sep');
  const layoutButtons = LAYOUTS.map((layout) => ({ layout, b: barButton('ui', LAYOUT_LOOKS[layout].icon, () => setLayout(layout)) }));
  const shadingButtons = SHADINGS.map((mode) => ({ mode, b: barButton('ui', SHADING_LOOKS[mode].icon, () => setShading(mode)) }));
  const gridButton = barButton('ui', 'ground', () => setGrid(!stage.grid));
  const statsButton = barButton('ui', 'stats', () => setStats(!prefs.stats));
  const frameButton = barButton('ui', 'frame', () => frameSelection());
  const buildButton = barButton('model_export', 'build', () => void build());
  const traceButton = barButton('model_trace', 'trace', () => tracing.toggle());
  const chip = el('span', 'ed-mo-chip');
  bar.append(...layoutButtons.map((x) => x.b), sep(), ...shadingButtons.map((x) => x.b), sep(), gridButton, statsButton, sep(), frameButton, buildButton, traceButton, chip);

  function drawBar(): void {
    for (const { layout, b } of layoutButtons) {
      b.setAttribute('aria-pressed', String(stage.layout === layout));
      tip(b, LAYOUT_LOOKS[layout].words, 'L');
    }
    for (const { mode, b } of shadingButtons) {
      b.setAttribute('aria-pressed', String(stage.shading === mode));
      const polys = mode !== 'shaded' && answer === null && source.path !== null ? ' (triangles only: no polygons from Gladius yet)' : '';
      tip(b, `${SHADING_LOOKS[mode].words}${polys}`, keyLabel('Shift+KeyZ'));
    }
    gridButton.setAttribute('aria-pressed', String(stage.grid));
    tip(gridButton, `The ground in metres${stage.gridLine ? `: ${stage.gridLine}` : ''}`, 'G');
    statsButton.setAttribute('aria-pressed', String(prefs.stats));
    tip(statsButton, 'Statistics: objects, vertices, edges, faces, triangles -- the selection\'s over the model\'s', 'I');
    tip(frameButton, 'Frame the selection, or the whole model, in the view under the pointer', 'F');
    const why = unbuildable();
    buildButton.disabled = !source.path || !writes || why !== null;
    tip(buildButton, why ?? (writes ? 'Build now: the script exported again, current or not' : 'Build now: this page may not export'), 'B');
    traceButton.disabled = !source.path;
    traceButton.setAttribute('aria-pressed', String(tracing.showing));
    tip(traceButton, tracing.showing ? 'Back to the model: the build trace kept where it stands' : 'Step through the build: the script replayed op by op in the views, from its end', keyLabel('Shift+KeyT'));
    const { words, tone } = stateWords(source.state);
    const name = source.path ? modelName(source.path) : '';
    const short: Partial<Record<BuildState['kind'], string>> = { failed: 'did not build', unmade: 'not made: a tool is missing', excluded: 'out of the build', gone: 'not there', offline: 'no dev server', loading: 'reading…' };
    const said = source.state.kind === 'building' ? `Building ${name}… ${source.state.step ?? ''}`.trim() : source.state.kind === 'ready' ? `${name} · built` : source.state.kind === 'none' ? '' : `${name} · ${short[source.state.kind] ?? words}`;
    // A preview on screen is said over the build's state: what is shown is not the export yet.
    const preview = editing.previewing || editing.building;
    if (isHeld()) {
      // Claude's turn is editing the script (M21): its saves shown as previews, the shipped export once at the turn's end.
      const failing = editing.savedError ? ' -- the last save does not build yet' : '';
      chip.textContent = `${name} · held for Claude's turn -- preview${editing.building ? ', building…' : failing}`;
      chip.title = `${source.path?.split('/').pop()} was saved while a turn of the Claude card runs: its export is held, and each save is built as a preview and shown here; the shipped .glb is exported once no turn runs${editing.savedError ? `. The last save: ${editing.savedError}` : ''}`;
    } else {
      chip.textContent = preview ? `${name} · preview${editing.building ? ' -- building…' : ''}` : said;
      chip.title = preview ? 'A preview build of the value being dragged: not the export -- let go, and it is written and exported once' : words;
    }
    chip.classList.toggle('ed-mo-busy', tone === 'busy' || editing.building);
    chip.classList.toggle('ed-mo-preview', preview || isHeld());
  }

  function setLayout(layout: Layout): void {
    stage.setLayout(layout);
    keep({ layout });
    drawBar();
  }

  function setShading(mode: Shading): void {
    stage.setShading(mode);
    tracing.setShading(mode);
    keep({ shading: mode });
    // Wanting polygons and having none: the kernel asked again.
    if (mode !== 'shaded' && answer === null && tree) source.query();
    drawBar();
  }

  function setGrid(on: boolean): void {
    stage.setGrid(on);
    keep({ grid: on });
    drawBar();
  }

  function setStats(on: boolean): void {
    keep({ stats: on });
    drawStats();
    drawBar();
  }

  // ---------------------------------------------------------------- the banner and the empty state

  /** The banner's buttons, by what the state needs. */
  const bannerButton = (mcp: Mcp, text: string, title: string, run: () => void, extra = 'ed-small'): HTMLButtonElement => letGo(button(mcp, text, title, run, extra));

  function drawBanner(): void {
    const state: BuildState = source.state;
    const name = source.path ? modelName(source.path) : '';
    const file = source.path?.split('/').pop() ?? '';
    banner.classList.remove('ed-mo-bad');
    const head = el('div', 'ed-mo-banner-head');
    const title = el('span', 'ed-mo-banner-title');
    head.append(title);
    const body: HTMLElement[] = [];
    switch (state.kind) {
      case 'failed': {
        banner.classList.add('ed-mo-bad');
        title.textContent = `${file} did not build${scene ? ' -- the last good build is shown' : ''}`;
        const lines = state.lines.length > 0 ? state.lines : [{ severity: 'error' as const, message: state.error }];
        for (const d of lines.slice(0, 12)) {
          const row = el('div', `ed-mo-diag${d.severity === 'error' ? ' ed-mo-error' : ''}`);
          // `crate.lua:18: unexpected …` -- the line said once, in its column.
          const words = d.line !== undefined ? d.message.replace(/^[^:\n]*\.lua:\d+:\s*/, '') : d.message;
          row.append(el('span', 'ed-mo-diag-at', d.line !== undefined ? `line ${d.line}` : d.severity), el('span', undefined, words));
          body.push(row);
        }
        if (lines.length > 12) body.push(el('div', 'ed-dim', `and ${lines.length - 12} more`));
        body.push(el('div', 'ed-dim', 'Fix the script and save it: it builds again by itself.'));
        if (writes) head.append(bannerButton('ui', 'Open script', 'In the application this machine edits it with', () => edit()), bannerButton('model_export', 'Build again', 'Export the script again now (B)', () => void build()));
        break;
      }
      case 'unmade':
        banner.classList.add('ed-mo-bad');
        title.textContent = state.tool === 'gladius' ? 'Gladius is not found on this machine: nothing can be built' : `${file} cannot be made here: ${state.reason}`;
        if (state.passed) body.push(el('div', undefined, `${state.passed[0]!.toUpperCase()}${state.passed.slice(1)}.`));
        if (state.hint) body.push(el('div', undefined, state.hint));
        body.push(el('div', 'ed-dim', scene ? 'The last export is shown, as it was built elsewhere.' : 'Install it, or tell the editor where it is, then build again.'));
        head.append(bannerButton('ui', 'Set its path in Tools', 'Config ▸ Assets ▸ Tools: where Gladius is, checked again', () => void ctx.pages.show(TOOLS_PAGE), 'ed-small ed-accent'));
        break;
      case 'excluded':
        if (state.underscore) {
          title.textContent = `${file} is out of the build: a name or folder starting with _ is never exported, so there is nothing to show`;
          body.push(el('div', 'ed-dim', 'Rename it -- or its folder -- without the _ in the Assets panel to build it: it exports, and shows here.'));
          head.append(bannerButton('ui', 'Show it in the Assets panel', 'The script, chosen there', () => void ctx.revealAsset(source.path!)));
          break;
        }
        title.textContent = `${file} is out of the build: it is never exported, so there is nothing to show`;
        body.push(el('div', 'ed-dim', 'Tick it in the Assets panel (Shift+B on it) to put it in the build: it exports, and shows here.'));
        head.append(bannerButton('ui', 'Show it in the Assets panel', 'The script, chosen there', () => void ctx.revealAsset(source.path!)));
        break;
      case 'gone':
        banner.classList.add('ed-mo-bad');
        title.textContent = `${name} is not there any more: renamed, moved or deleted`;
        head.append(bannerButton('ui', 'Close it', 'Back to the list of scripts', () => close()));
        break;
      case 'offline':
        banner.classList.add('ed-mo-bad');
        title.textContent = 'No dev server: the Model tab builds and reads models through it (npm run dev)';
        break;
      default:
        if (!banner.hidden) stage.refit();
        banner.hidden = true;
        banner.replaceChildren();
        return;
    }
    banner.replaceChildren(head, ...body);
    banner.hidden = false;
    stage.refit();
  }

  /** No model open: how to open one, and the project's scripts to click. */
  let listing = 0;
  function drawEmpty(): void {
    const none = source.path === null;
    empty.hidden = !none && scene !== null;
    if (!none) {
      // Opened, not shown yet: what it is waiting for.
      const words = source.state.kind === 'loading' || source.state.kind === 'building' ? `Opening ${modelName(source.path!)}…` : '';
      empty.replaceChildren(...(words ? [el('div', 'ed-mo-empty-card', words)] : []));
      empty.hidden = scene !== null || words === '';
      return;
    }
    const card = el('div', 'ed-mo-empty-card');
    card.append(
      el('h2', undefined, 'No model open'),
      el('div', undefined, 'Double-click a .lua in the Assets panel\'s Source tab -- or its .glb in the Assets tab -- choose a script here, or start one.'),
    );
    if (writes) {
      const make = el('div', 'ed-buttons');
      make.append(
        letGo(button('asset_new', 'New model…', 'A Gladius script, empty and documented: named, built once and opened here -- Z in the Assets panel undoes it', () => void ctx.modelFiles.newModel(), 'ed-small ed-accent')),
        letGo(button('asset_import', 'Import model…', 'A .glb or .fbx: copied into the models folder the Assets panel shows (the sheet\'s Into list changes it) beside a script that imports it -- parts, colours, skin and clips kept -- and opened here', () => importModels(), 'ed-small')),
      );
      card.append(make);
    }
    const list = el('div', 'ed-mo-scripts');
    list.append(el('div', 'ed-dim', 'Looking for scripts…'));
    const loose = el('div', 'ed-mo-scripts');
    card.append(list, loose);
    empty.replaceChildren(card);
    const mine = ++listing;
    void source.scripts().then(
      (paths) => {
        if (mine !== listing) return;
        // The models with no script (D49): each offered one, the one way it can be changed here.
        const glbs = writes ? source.unscripted() : [];
        loose.replaceChildren(...(glbs.length > 0 ? [el('div', 'ed-dim', 'Models with no script -- delivered as they are:')] : []), ...glbs.map((path) => {
          const b = control('model_adopt', 'ed-mo-script');
          const stem = (path.split('/').pop() ?? path).replace(/\.glb$/i, '');
          // The inspector's button's words: what ships becomes Gladius's rebuild of the file -- said before the press, as there.
          b.title = `Make a script for ${path}: the file copied in beside a script that imports it, built as its export (the key unchanged) and opened here. What ships is then Gladius's rebuild of the file -- welded, its quads recovered, normals sampled, its materials named ${stem}:<material> -- not its bytes. Z in the Assets panel undoes it`;
          b.append(icon('file'), el('span', undefined, path.split('/').pop() ?? path), el('span', 'ed-dim', 'Make a script'));
          b.addEventListener('click', () => void ctx.modelFiles.adoptModel(path));
          return b;
        }));
        if (paths.length === 0) return void list.replaceChildren(el('div', 'ed-dim', 'No .lua scripts under AssetsSource/models/ yet: New model or Import model starts one.'));
        list.replaceChildren(...paths.map((path) => {
          const b = control('model_open', 'ed-mo-script');
          b.title = `Open ${path}`;
          b.append(icon('model'), el('span', undefined, modelName(path)), el('span', 'ed-dim', path.split('/').pop() ?? ''));
          b.addEventListener('click', () => open(path));
          return b;
        }));
      },
      () => {
        if (mine === listing) list.replaceChildren(el('div', 'ed-dim', 'No dev server: no scripts to list (npm run dev).'));
      },
    );
  }

  // ---------------------------------------------------------------- the panels

  function drawStats(): void {
    // A build step shown: its own numbers -- the model's would describe what is not on screen.
    if (prefs.stats && tracing.showing) return stage.setStats(tracing.stats());
    if (!prefs.stats || !tree || tree.all.length === 0) return stage.setStats(null);
    const whole = statsOf(tree.all, kernel);
    const picked = selection.length > 0 ? statsOf(withChildren(tree, selection), kernel) : null;
    // The selected bones' weight map: how many vertices they move (D91) -- its colour key is the Animation block's.
    const w = animating.weights;
    const weighed: (readonly [string, string])[] = w ? [['Weights', `${count(w.influenced)} / ${count(w.vertices)}`]] : [];
    stage.setStats([...statsRows(whole, picked), ...weighed]);
  }

  function drawPanels(): void {
    const model = source.path ? { name: modelName(source.path), path: source.path } : null;
    outliner.draw(model && source.state.kind === 'gone' ? { ...model, gone: true } : model, tree, selection, hidden, kernel);
    editing.redraw();
    exportRow.draw(source.path ? exportOptions : null);
    inspector.draw(source.path ? { path: source.path, name: modelName(source.path), exportPath: source.exportPath, state: source.state, told, held: isHeld(), notes: buildNotes } : null, tree, selection, hidden, kernel);
    // No blocks for a script that is not there (renamed, deleted): the inspector's wrapper hides them all, both ways
    // (`blocksShown`) -- never a block's own `hidden` set here, which nothing would set back.
    // The script or its parameters moved since the trace: traced again (M37).
    tracing.check();
    drawBar();
    drawEmpty();
    // What a turn would carry follows the model: the card's line over its box.
    ctx.turnChanged();
  }

  function drawAll(): void {
    drawBanner();
    drawStats();
    drawPanels();
  }

  // ---------------------------------------------------------------- the menu

  /**
   * Import model…: the Assets panel's sheet and picker. The panel unfolded for the sheet is the sheet's, not the
   * person's: never remembered as theirs (`model-room.ts`).
   */
  function importModels(dir?: string): void {
    viewRoom.importing();
    ctx.modelFiles.importModels(dir);
  }

  /** The left panel's model button: a script made or imported (M38, M39), each one step of the Assets panel's. */
  function filesMenu(at: HTMLElement): void {
    if (!writes) return say('This page may not write: New model and Import are the dev server\'s, on this machine');
    const dir = source.path ? source.path.slice(0, source.path.lastIndexOf('/')) : undefined;
    menu.show(at, [
      { mcp: 'asset_new', label: 'New model…', title: `A Gladius script, empty and documented, in the models folder the Assets panel shows, else ${dir ?? 'AssetsSource/models'} -- the dialog's In list changes it: named, built once and opened here -- Z in the Assets panel undoes it`, run: () => void ctx.modelFiles.newModel(dir) },
      { mcp: 'asset_import', label: 'Import model…', title: `A .glb or .fbx into the models folder the Assets panel shows, else ${dir ?? 'AssetsSource/models'} -- the sheet's Into list changes it: copied in beside a script that imports it -- parts, colours, skin and clips kept -- and opened here`, run: () => importModels(dir) },
    ], { title: 'Model' });
  }

  function partMenu(id: string | null, x: number, y: number): void {
    if (!tree) return;
    if (id === null) {
      const items: MenuItem[] = [
        { mcp: 'ui', label: 'Frame the model', key: 'Home', run: () => stage.frame(null, true) },
        { mcp: 'ui', label: 'Show every part', key: keyLabel('Alt+KeyH'), run: () => setHidden(new Set()) },
      ];
      return menu.show({ x, y }, items, { title: source.path ? modelName(source.path) : 'Model' });
    }
    if (!selection.includes(id)) select([id]);
    const part = tree.byId.get(id);
    if (!part) return;
    const many = selection.length > 1;
    const all = selection.every((s) => hidden.has(s));
    const items: MenuItem[] = [
      { mcp: 'ui', label: 'Frame', key: 'F', title: 'The view under the pointer onto it', run: () => frameSelection() },
      { mcp: 'ui', label: all ? 'Show' : 'Hide', key: keyLabel('Shift+KeyH'), title: many ? `All ${selection.length} selected` : part.name, run: () => hideSelection() },
      { mcp: 'ui', label: 'Show only this', title: 'Every other part hidden: Alt+H shows them again', run: () => showOnly(id) },
      { mcp: 'ui', label: 'Show every part', key: keyLabel('Alt+KeyH'), run: () => setHidden(new Set()) },
      { mcp: 'ui', label: 'Copy name', rule: true, title: 'Its name as the script has it -- emit{name=…}: the string to find in the script', run: () => void navigator.clipboard?.writeText(part.name).then(() => say(`Copied: ${part.name}`), () => say('Not copied: the page did not have the focus')) },
      { mcp: NOT_FOR_CLAUDE.askClaude, label: many ? `Delete ${selection.length} parts…` : 'Delete…', key: keyLabel('Delete'), rule: true, title: 'Asks Claude: the words go in the Claude card\'s box for you to send -- the code that makes it is removed, not only its emit', run: () => deleteParts() },
    ];
    menu.show({ x, y }, items, { title: many ? `${selection.length} parts` : part.name });
  }

  // ---------------------------------------------------------------- what a turn of the Claude card carries (M26)

  /** The model open, as a turn's facts: the script, its export and build, the parameters, the parts, the bounds, the preview. */
  function modelTurn(): ModelTurn {
    const bounds = scene ? new THREE.Box3().setFromObject(scene) : null;
    const v = (p: THREE.Vector3): [number, number, number] => [Math.round(p.x * 1e4) / 1e4, Math.round(p.y * 1e4) / 1e4, Math.round(p.z * 1e4) / 1e4];
    const set = editing.overrides();
    return {
      script: source.path!,
      export: source.exportPath,
      build: stateWords(source.state).words,
      params: editing.params().map((p) => ({ name: p.name, value: p.value, set: p.name in set })),
      selected: selectedParts().map((p) => p.name),
      hidden: tree ? tree.all.filter((p) => hidden.has(p.id)).map((p) => p.name) : [],
      bounds: bounds && !bounds.isEmpty() ? { min: v(bounds.min), max: v(bounds.max) } : null,
      preview: isHeld() ? 'a preview of the script as last saved (its export held for this turn), not the export' : editing.previewing ? 'a preview of a parameter being dragged, not the export' : null,
      pose: animating.turnPose(),
      step: tracing.turnStep(),
      canvases: [],
      left: [],
    };
  }

  /** What goes with a turn while the tab is up: the model, and every canvas going -- the card shows it over its box. */
  function attachments(): TurnAttachments {
    const going = canvases.sendable();
    return {
      subject: source.path!.split('/').pop()!,
      canvases: going.map((c) => ({ id: c.id, name: c.name, note: c.note.trim() !== '' })),
      left: canvases.leftOut(),
      skip: (id, skipped) => canvases.setSkipped(id, skipped),
      async gather(first, room) {
        const model = modelTurn();
        const got = await canvases.turn(first, room);
        return { model: { ...model, canvases: got.canvases, left: got.left }, images: got.images };
      },
      sent() {
        for (const c of canvases.list) if (c.skipped) canvases.setSkipped(c.id, false);
      },
    };
  }

  // ---------------------------------------------------------------- the canvases across a reload (M28)

  /**
   * Every script's canvases as values -- strokes as PNG, camera, note -- in this tab's `sessionStorage` under a
   * key of their own, not the resume record: a record too big drops the world first, and drawings must not cost
   * the scene. Too big themselves, the oldest go until they fit, said after the reload.
   */
  function keepCanvases(): void {
    const items = canvases.carry();
    try {
      sessionStorage.removeItem(CANVASES_KEY);
      if (items.length === 0) return;
      for (let n = items.length; n > 0; n--) {
        try {
          sessionStorage.setItem(CANVASES_KEY, JSON.stringify({ at: Date.now(), items: items.slice(items.length - n), dropped: items.length - n }));
          return;
        } catch {
          // Over the storage's room: one fewer, the oldest first.
        }
      }
    } catch {
      // Storage blocked: nothing kept, the canvases go with the page.
    }
  }

  /** The canvases kept for this reload, taken (read and deleted); only fresh -- a tab opened later starts without. */
  function takeCanvases(): void {
    let raw: string | null = null;
    try {
      raw = sessionStorage.getItem(CANVASES_KEY);
      sessionStorage.removeItem(CANVASES_KEY);
    } catch {
      return;
    }
    if (!raw) return;
    try {
      const kept = JSON.parse(raw) as { at?: unknown; items?: unknown; dropped?: unknown };
      if (typeof kept.at !== 'number' || Date.now() - kept.at > CANVASES_MS || !Array.isArray(kept.items)) return;
      canvases.takeBack(kept.items.map(readCarried).filter((c): c is CarriedCanvas => c !== null));
      carriedDropped = typeof kept.dropped === 'number' ? kept.dropped : 0;
    } catch {
      // Not ours, or from another build: started without.
    }
  }
  let carriedDropped = 0;

  /** A model shown and drawn: canvases a reload carried for it made again, their backdrops rendered anew. */
  function adoptCarried(): void {
    if (!visible) return;
    const exported = source.exportPath ? live.index.entries.get(source.exportPath) : undefined;
    void canvases.adopt(exported ? `${exported.mtime}:${exported.size}` : null).then((n) => {
      if (n === 0) return;
      const lost = carriedDropped > 0 ? ` (${carriedDropped} too big to keep across it are gone)` : '';
      carriedDropped = 0;
      say(`${n} ${n === 1 ? 'canvas' : 'canvases'} back from before the reload${lost} -- their undo starts afresh`);
      canvasesChanged();
    });
  }

  // ---------------------------------------------------------------- Delete asks Claude (M30, D65)

  /**
   * The selected parts' Delete: nothing maps a part back to the statements that made it -- Gladius reports names, not
   * provenance -- so the agent trusted with every other edit is asked, in words put in the card's box for the person to
   * read and send (not sent by itself: a click must not rewrite a script unseen). Z, and Undo this turn, take it back.
   */
  function deleteParts(): void {
    const names = selectedParts().map((p) => p.name);
    if (!source.path || names.length === 0) return say('Nothing selected to delete: click a part, in the views or on the left');
    const list = names.length === 1 ? `"${names[0]}"` : `${names.slice(0, -1).map((n) => `"${n}"`).join(', ')} and "${names.at(-1)}"`;
    const text = `In ${source.path}, remove the code generating the part${names.length === 1 ? '' : 's'} ${list} -- the meshes, locals, parameters and materials only ${names.length === 1 ? 'it uses' : 'they use'}, not just the emit.`;
    if (!ctx.askClaude(text)) return say('No Claude card here (it needs the dev server): delete it in the script');
    say(`Written in the Claude card's box: send it to have ${names.length === 1 ? names[0] : `${names.length} parts`} removed from the script`);
  }

  // ---------------------------------------------------------------- what is said

  /** The one timer that clears what was said: a new line moves it on, dispose calls it off. */
  let sayTimer: ReturnType<typeof setTimeout> | undefined;
  function say(text: string): void {
    notice = { text, until: Date.now() + SAID_MS };
    ctx.draw();
    clearTimeout(sayTimer);
    sayTimer = setTimeout(() => {
      if (notice && notice.until <= Date.now()) {
        notice = null;
        if (visible) ctx.draw();
      }
    }, SAID_MS + 50);
  }

  // ---------------------------------------------------------------- keys

  /** The fly keys as the mouse line says them (M8): held over a view. */
  // Held alone over a view under Blender's keymap; under Industry Compatible with the right button held (Docs/navigation.md D10).
  const flyWords = (): string => `${['KeyW', 'KeyA', 'KeyS', 'KeyD'].map((c) => keyLabel(c)).join(' ')} fly (${keyLabel('KeyQ')} ${keyLabel('KeyE')} down, up; Shift faster), held over a view${keymapNow() === 'industry' ? ' with the right button' : ''}`;
  const nextMarquee = (tool: PaintTool): PaintTool => (MARQUEES.includes(tool) ? MARQUEES[(MARQUEES.indexOf(tool) + 1) % MARQUEES.length]! : 'rect');
  /** The next row's part, up or down from the first selected. */
  const walk = (by: 1 | -1): void => {
    const rows = outliner.shown();
    if (rows.length === 0) return;
    const at = selection[0] === undefined ? -1 : rows.indexOf(selection[0]);
    const next = rows[Math.max(0, Math.min(rows.length - 1, at < 0 ? 0 : at + by))]!;
    select([next]);
  };
  /** What the keys' `when`s read (`model-keys.ts`), live as each key comes. */
  const keyState: ModelKeyState = {
    get visible() { return visible; },
    get model() { return tree !== null; },
    get source() { return source.path !== null; },
    get hovering() { return stage.hovering; },
    get menuOpen() { return menu.open; },
    get inRows() { return outliner.rows.contains(document.activeElement); },
    get selected() { return selection.length; },
    get painting() { return canvases.painting && !canvasPanel.typing; },
    get marquee() { return canvases.hasMarquee; },
    get canPaste() { return canvases.canPaste; },
    get canvasOpen() { return canvases.open !== null; },
    get clips() { return animating.hasClips; },
    get rigged() { return animating.rigged; },
    get posing() { return animating.posing; },
    get animTyping() { return animating.typing; },
    get tracing() { return tracing.showing; },
    get emulating() { return stage.hovering && loadPrefs().nav.emulateNumpad; },
    get traceTyping() { return tracing.typing; },
  };
  const offKeys = modelKeys(keyState, {
    frame: () => frameSelection(),
    layout: () => setLayout(nextLayout(stage.layout)),
    shading: () => setShading(SHADINGS[(SHADINGS.indexOf(stage.shading) + 1) % SHADINGS.length]!),
    grid: () => setGrid(!stage.grid),
    stats: () => setStats(!prefs.stats),
    look: (preset) => stage.look(preset),
    flip: () => stage.flip(),
    projection: () => stage.toggleProjection(),
    orbit: (dx, dy) => stage.orbitBy(dx, dy),
    pan: (dx, dy) => stage.panBy(dx, dy),
    zoom: (scale) => stage.zoomBy(scale),
    hide: () => hideSelection(),
    showAll: () => setHidden(new Set()),
    selectAll: () => select(tree ? tree.all.map((p) => p.id) : []),
    walk,
    build: () => void build(),
    fly: () => stage.fly((c) => MrDebug.held(c)),
    walkView: () => stage.walk((c) => MrDebug.held(c)),
    arrowFly: () => stage.arrowFly((c) => MrDebug.held(c)),
    pane: () => setPane(pane === 'canvases' ? 'parts' : 'canvases'),
    brushOrEraser: () => canvases.setTool(canvases.tool === 'brush' ? 'eraser' : 'brush'),
    marquee: () => canvases.setTool(nextMarquee(canvases.tool)),
    brush: (by) => canvases.setSize(canvases.size + by * Math.max(1, Math.round(canvases.size / 5))),
    copyMarks: () => void canvases.copy(),
    cutMarks: () => void canvases.cutSelection(),
    pasteMarks: () => void canvases.paste(),
    deleteMarks: () => void canvases.deleteSelection(),
    deleteParts: () => deleteParts(),
    play: () => animating.toggle(),
    frameStep: (by) => animating.step(by),
    clipStart: () => animating.toStart(),
    clipEnd: () => animating.toEnd(),
    key: () => animating.key(),
    poseMode: (mode) => animating.setMode(mode),
    bones: () => animating.toggleBones(),
    trace: () => tracing.toggle(),
    tracePlay: () => tracing.togglePlay(),
    traceStep: (by) => tracing.step(by),
    traceStart: () => tracing.toStart(),
    traceEnd: () => tracing.toEnd(),
    menuStep: (by) => menu.step(by),
  }).map((key) => ctx.keys.add(key));

  // ---------------------------------------------------------------- the tool

  // ---------------------------------------------------------------- room for the views at a small window

  const viewRoom = createRoom({
    visible: () => visible,
    viewsHeight: () => viewsEl.clientHeight,
    bottom: ctx.bottom,
    prefs: () => prefs,
    keep: (change) => keep(change),
    folded: () => say(`The Assets panel folded to give the views room -- ${keyLabel('Shift+Space')} or its tab unfolds it, and it stays so here`),
    frame: () => stage.frame(null, true),
    later: (run) => void requestAnimationFrame(run),
  });
  // The window made smaller with the tab up -- or the Claude card's box grown under the views -- asks the same, once it settles.
  let roomFrame = 0;
  const onResize = (): void => {
    cancelAnimationFrame(roomFrame);
    roomFrame = requestAnimationFrame(() => viewRoom.fit({ resized: true }));
  };
  window.addEventListener('resize', onResize);

  // The studio's model tools (Docs/mcp.md M6): the tab's own doings, each write one step of its history.
  const modelAgent = createModelAgent({
    source,
    editing,
    history: editing.history,
    clips: () => animating.clipNames(),
    parts: () => ({ tree, selected: selectedParts().map((p) => p.name), hidden: tree ? tree.all.filter((p) => hidden.has(p.id)).map((p) => p.name) : [] }),
    openModel: (path) => ctx.openModel(path),
    openBlocked: () => (ctx.playing ? 'a playtest runs -- the Model tab opens once it stops' : null),
    buildWords: (state) => stateWords(state).words,
  });

  function showPanels(): void {
    room.hidden = !visible;
    outliner.setVisible(visible);
    inspector.setVisible(visible && inspecting);
  }

  return {
    setVisible(show) {
      if (show === visible) return;
      visible = show;
      ctx.root.classList.toggle('ed-model-up', show);
      if (!show) {
        menu.close();
        viewRoom.leaving();
      }
      showPanels();
      stage.setVisible(show);
      tracing.setVisible(show);
      if (show) {
        viewRoom.shown();
        if (tree) adoptCarried();
        // The model kept from last time, as the tab first shows.
        if (source.path === null && prefs.source !== '' && scriptProblem(prefs.source) === null) open(prefs.source);
        drawAll();
      }
    },
    cards: () => [outliner.root, inspector.root, room],
    setInspector(shown) {
      inspecting = shown;
      if (visible) showPanels();
    },
    // Esc lets go of a menu, then of a marquee, then of a bone being posed, before it puts the editor away.
    holdsEscape: () => escapeTarget(keyState) !== null,
    cancel: () => {
      const target = escapeTarget(keyState);
      if (target === 'menu') menu.close();
      else if (target === 'marquee') canvases.clearMarquee();
      else if (target === 'trace') {
        tracing.leave();
        say(`Back to the model: the build trace kept where it stands -- ${keyLabel('Shift+KeyT')} returns to it`);
      } else if (target === 'pose') {
        select([]);
        say('The bone let go');
      }
    },
    hint: () => (notice && notice.until > Date.now() ? notice.text : null),
    mouse: () => `Model: a click picks a part (${modName()} toggles, Shift adds) -- with Bones on (${keyLabel('KeyJ')}), a bone's line · a drag boxes · ${navLine()} · a drag on the cube orbits · the wheel zooms · right-click for a menu · ${flyWords()}`,
    attachments: () => (visible && source.path && source.state.kind !== 'gone' && source.state.kind !== 'none' ? attachments() : null),
    shot: () => (visible ? stage.snapshot() : null),
    // A quick prompt (Mod+K, Docs/ai-panel.md §4) about the parts selected: over the views, a third down.
    quickTarget: () => {
      const picked = selectedParts();
      if (!visible || !source.path || picked.length === 0) return null;
      const at = viewsEl.getBoundingClientRect();
      return { target: { kind: 'parts', script: source.path, parts: picked.slice(0, 32).map((p) => p.name) }, anchor: { x: at.left + at.width / 2, y: at.top + at.height / 3 }, room: { left: at.left, top: at.top, right: at.right, bottom: at.bottom } };
    },
    model: modelAgent,
    context: (whole) => {
      // Up, the model goes whole with the column's turn (`attachments`): these facts are for a turn sent from another tab,
      // or asked whole -- a terminal's prompt, `studio_context`, which carry no attachments (Docs/terminal.md D9).
      if (!source.path || (visible && whole !== true)) return null;
      const facts: ToolFact[] = [
        { name: 'model open', value: source.path },
        { name: 'build', value: stateWords(source.state).words },
      ];
      if (source.exportPath) facts.push({ name: 'its export', value: source.exportPath });
      const picked = selectedParts();
      const set = editing.overrides();
      if (Object.keys(set).length > 0) facts.push({ name: 'parameters set by its record (not the script\'s defaults)', value: Object.entries(set).map(([k, v]) => `${k}=${v}`) });
      if (editing.previewing) facts.push({ name: 'views', value: 'a preview of a parameter being dragged, not the export' });
      const posed = animating.turnPose();
      if (posed) facts.push({ name: 'posed by a clip (not the rest pose the script builds)', value: posed });
      const stepped = tracing.turnStep();
      if (stepped) facts.push({ name: 'the views show the build trace (not the finished model)', value: stepped });
      if (picked.length > 0) facts.push({ name: 'parts selected', value: picked.slice(0, 32).map((p) => p.name) });
      const off = tree ? tree.all.filter((p) => hidden.has(p.id)).map((p) => p.name) : [];
      if (off.length > 0) facts.push({ name: 'parts hidden (still in the script)', value: off.slice(0, 32) });
      return facts;
    },
    openModel: (path, how) => open(path, how?.room === true),
    // The views' cameras across a reload the editor survives (the resume record, M18), with the script they are of.
    carry: () => {
      keepCanvases();
      return source.path ? { source: source.path, layout: stage.layout, views: stage.poses() } : null;
    },
    takeBack(kept) {
      takeCanvases();
      const k = (typeof kept === 'object' && kept !== null ? kept : {}) as { source?: unknown; layout?: unknown; views?: unknown };
      if (typeof k.source !== 'string' || scriptProblem(k.source) !== null) return;
      if (LAYOUTS.includes(k.layout as Layout) && k.layout !== stage.layout) setLayout(k.layout as Layout);
      posesFor = { source: k.source, poses: readPoses(k.views) };
    },
    history: tabHistory,
    busy: () => editing.busy(),
    frameAll: () => stage.frame(null, true),
    ownScene: true,
    dispose() {
      clearTimeout(sayTimer);
      visible = false;
      ctx.root.classList.remove('ed-model-up');
      window.removeEventListener('resize', onResize);
      cancelAnimationFrame(roomFrame);
      for (const off of offKeys) off();
      offHeld();
      offSaved();
      clearTimeout(heldBack);
      clearTimeout(heldAgain);
      clearInterval(heldPoll);
      canvases.dispose();
      tracing.dispose();
      animating.dispose();
      menu.dispose();
      editing.dispose();
      stage.dispose();
      source.dispose();
      outliner.dispose();
      inspector.dispose();
      room.remove();
      dropSheet();
    },
  };
}
