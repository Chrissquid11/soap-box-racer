/**
 * Room for the Model tab's views at a small window (Docs/modeler.md §4): the
 * Assets panel along the bottom folded when the views would be shorter than
 * `LEAST_VIEWS`, and given back as the tab goes.
 *
 * - **As the tab comes up**: folded for room -- unless a person unfolded it
 *   here before (`panel`, remembered). One the tab folded and a reload left
 *   folded (`roomFold`) is unfolded first, and measured again.
 * - **A model made to be looked at** (an import, Make a script, New model --
 *   `made`): room made even where the panel was unfolded here, the model
 *   framed again in the views it has now.
 * - **The window made smaller** (`resized`): the views keep their least height
 *   whatever was remembered.
 * - **Import model…'s sheet** unfolds the panel for itself (`importing`): left
 *   up while the sheet is, folded back by the sheet, and never remembered as
 *   the person's choice.
 * - **Leaving**: a panel folded for room unfolded again for the other tab -- or,
 *   unfolded by the person meanwhile, remembered (`panel`).
 *
 * DOM-free: the measure, the panel, the prefs and the next frame are handed in
 * (`model-room.test.ts`).
 */

/** The views' least height before the Assets panel is folded away for them, in CSS pixels. */
export const LEAST_VIEWS = 300;

export interface RoomHost {
  /** The tab is up. */
  visible(): boolean;
  /** The views' height now, in CSS pixels. */
  viewsHeight(): number;
  /** The Assets panel along the bottom: folded or not (null: none here), and the way to fold it. */
  readonly bottom: { folded(): boolean | null; fold(folded: boolean): void };
  /** The tab's prefs as kept: `panel`, a person unfolded it here; `roomFold`, the tab folded it. */
  prefs(): { panel: boolean; roomFold: boolean };
  keep(change: { panel?: boolean; roomFold?: boolean }): void;
  /** The panel folded for room: said on the editor's line. */
  folded(): void;
  /** The model framed in every view. */
  frame(): void;
  /** On the next animation frame. */
  later(run: () => void): void;
}

export interface Room {
  /** The tab came up. */
  shown(): void;
  /** The views' height may have changed: `made`, a model just made to be looked at; `resized`, the window. */
  fit(how?: { made?: boolean; resized?: boolean }): void;
  /** Import model… asked: a panel unfolded now is the sheet's. */
  importing(): void;
  /** The tab goes. */
  leaving(): void;
}

export function createRoom(host: RoomHost): Room {
  const { bottom } = host;
  /** The Assets panel unfolded by Import model…'s sheet, not by the person: let go once it is seen folded again. */
  let sheetUnfolded = false;

  function fit({ made = false, resized = false } = {}): void {
    if (bottom.folded() === true) sheetUnfolded = false;
    if (!host.visible() || (host.prefs().panel && !made && !resized) || bottom.folded() !== false) return;
    // Up for Import model…'s sheet: left so until the import lands (`made`) or the sheet folds it again.
    if (sheetUnfolded && !made) return;
    if (host.viewsHeight() >= LEAST_VIEWS) return;
    bottom.fold(true);
    host.keep({ roomFold: true });
    // A model framed in the views before they grew: framed again in the room they have now.
    if (made) host.later(() => host.later(() => host.frame()));
    host.folded();
  }

  return {
    shown() {
      if (host.prefs().roomFold && bottom.folded() === true) bottom.fold(false);
      host.keep({ roomFold: false });
      host.later(() => fit());
    },
    fit,
    importing() {
      if (bottom.folded() === true) sheetUnfolded = true;
    },
    leaving() {
      const was = sheetUnfolded;
      sheetUnfolded = false;
      if (!host.prefs().roomFold) return;
      host.keep({ roomFold: false });
      if (bottom.folded() === true) bottom.fold(false);
      // Unfolded meanwhile by the person -- not by Import model…'s sheet, which folds it again itself.
      else if (!was) host.keep({ panel: true });
    },
  };
}
