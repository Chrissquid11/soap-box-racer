/**
 * The Model tab's writes into a Gladius script (Docs/modeler.md M24, M25):
 * a `material{}` call's fields set, added or taken out (Vibe3D D94), and
 * `params{}`'s defaults baked to the values the model is built at (D45) --
 * each the whole script's text in, the whole text out, through `lua-table.ts`'
 * scanner: comments, strings with braces in them, nested tables and the
 * author's layout all kept, every other byte as it was.
 *
 * - **A material is found by the name it registers** -- `material{ name =
 *   "Crate", … }`, the name the model's material carries -- with or without
 *   parentheses; a material the script does not declare that way (an import's,
 *   a name worked out at run time) has no call to edit: said, never guessed.
 * - **A value set replaces the whole value**: `base_color = tint` becomes the
 *   literal -- what setting a value means; the link to `tint` is gone for that
 *   field (a cost D94 accepted). Colours are written linear, `v3(r, g, b)`, as
 *   Gladius takes them.
 * - **A default baked is a literal replaced by a literal**: `default = 1.0` →
 *   `default = 2`. A default that is an expression (`base * 2`) is not
 *   rewritten: named as skipped, and its override kept.
 *
 * Pure (`script-edits.test.ts`).
 */
import type { ParamSpec } from '@vibe/pipeline/assets-types';
import {
  additions,
  applyEdits,
  booleanLiteral,
  fieldTable,
  fieldText,
  findCalls,
  luaNumber,
  numberLiteral,
  quoted,
  removal,
  replaceValue,
  skippedRanges,
  stringLiteral,
  v3Literal,
  type Edit,
  type LuaTable,
} from './lua-table.ts';

// ---------------------------------------------------------------- materials

/** The `material{}` fields the Materials block writes (Gladius 0.8.0's `material` options, as 0.7.3's). */
export const MATERIAL_FIELDS = [
  'base_color',
  'metallic',
  'roughness',
  'emissive',
  'alpha_mode',
  'alpha_cutoff',
  'texture',
  'normal_texture',
  'metallic_roughness_texture',
  'occlusion_texture',
  'emissive_texture',
  'texture_filter',
  'texture_wrap',
  'compress',
] as const;
export type MaterialField = (typeof MATERIAL_FIELDS)[number];

/** A value as the block sets it: a number, a word or a path, a linear colour; null takes the field out. */
export type MaterialValue = number | string | readonly [number, number, number] | null;

/** A value as the script writes it: `0.35`, `"crate.png"`, `v3(1, 0.9, 0.8)`. */
export function luaValue(value: Exclude<MaterialValue, null>): string {
  if (typeof value === 'number') return luaNumber(value);
  if (typeof value === 'string') return quoted(value);
  return `v3(${value.map(luaNumber).join(', ')})`;
}

interface MaterialCall extends LuaTable {
  name: string;
}

/** Every `material{}` call whose `name` is a string literal, in the order written. */
function materialCalls(text: string): MaterialCall[] {
  const out: MaterialCall[] = [];
  for (const call of findCalls(text, 'material')) {
    const nameField = call.fields.find((f) => f.key === 'name');
    const name = nameField ? stringLiteral(text.slice(nameField.valueStart, nameField.valueEnd)) : undefined;
    if (name !== undefined) out.push({ ...call, name });
  }
  return out;
}

/** A field's value as the script writes it, read: a number, a string, a colour, a boolean -- or the source text, for anything computed. */
export type ScriptValue = { kind: 'number'; value: number } | { kind: 'string'; value: string } | { kind: 'colour'; value: [number, number, number] } | { kind: 'boolean'; value: boolean } | { kind: 'expression'; source: string };

export function scriptValue(source: string): ScriptValue {
  const n = numberLiteral(source);
  if (n !== undefined) return { kind: 'number', value: n };
  const s = stringLiteral(source);
  if (s !== undefined) return { kind: 'string', value: s };
  const c = v3Literal(source);
  if (c !== undefined) return { kind: 'colour', value: c };
  const b = booleanLiteral(source);
  if (b !== undefined) return { kind: 'boolean', value: b };
  return { kind: 'expression', source: source.trim() };
}

/** A material as its script declares it: its name, the line of its call, each field's value as written. */
export interface DeclaredMaterial {
  name: string;
  /** 1-based. */
  line: number;
  fields: Record<string, ScriptValue>;
}

/** Every material the script declares with a literal name: what the block reads beside the model's own (`compress` is only here). */
export function declaredMaterials(text: string): DeclaredMaterial[] {
  return materialCalls(text).map((call) => {
    const fields: Record<string, ScriptValue> = {};
    for (const f of call.fields) if (f.key !== 'name') fields[f.key] = scriptValue(text.slice(f.valueStart, f.valueEnd));
    return { name: call.name, line: text.slice(0, call.open).split('\n').length, fields };
  });
}

/**
 * The script with `name`'s `material{}` carrying `set`: a field there has its
 * value replaced; one not there is added after the last; `null` takes one
 * out. `problem` when the script declares no such material.
 */
export function editMaterial(text: string, name: string, set: Readonly<Partial<Record<MaterialField, MaterialValue>>>): { text: string } | { problem: string } {
  const call = materialCalls(text).find((c) => c.name === name);
  if (!call) return { problem: `the script has no material{ name = "${name}" } to edit: its material is made some other way (an import, a name worked out as it runs)` };
  const edits: Edit[] = [];
  const added: string[] = [];
  const removed = new Set<string>();
  for (const [key, value] of Object.entries(set) as Array<[MaterialField, MaterialValue | undefined]>) {
    if (value === undefined) continue;
    const field = call.fields.find((f) => f.key === key);
    if (value === null) {
      if (field) {
        edits.push(removal(text, call, field));
        removed.add(key);
      }
      continue;
    }
    if (field) edits.push(replaceValue(field, luaValue(value)));
    else added.push(key);
  }
  const kept = call.fields.filter((f) => !removed.has(f.key));
  edits.push(...additions(text, call, kept, added.map((key) => fieldText(text, kept, key, luaValue(set[key as MaterialField] as Exclude<MaterialValue, null>)))));
  return { text: applyEdits(text, edits) };
}

// ---------------------------------------------------------------- parameters

/** How a value is spelled as a default: a boolean as a word, an integer whole, a number shortest, a string quoted. */
export function defaultLiteral(spec: Pick<ParamSpec, 'type'>, value: number | string | boolean): string {
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'number') return spec.type === 'integer' ? String(Math.round(value)) : String(Number(value.toPrecision(12)));
  return quoted(value);
}

/**
 * `params{}`'s defaults made the values given (D45's Bake into script): each
 * one's `default = <literal>` replaced, in place. `baked` were written;
 * `skipped`, with why, were not -- a default that is an expression, a
 * parameter not declared as a literal table in the one `params{}` call.
 */
export function bakeDefaults(text: string, values: ReadonlyArray<{ name: string; type: ParamSpec['type']; value: number | string | boolean }>): { text: string; baked: string[]; skipped: Array<{ name: string; why: string }> } {
  const skip = skippedRanges(text);
  const call = findCalls(text, 'params', skip)[0];
  const baked: string[] = [];
  const skipped: Array<{ name: string; why: string }> = [];
  if (!call) return { text, baked, skipped: values.map((v) => ({ name: v.name, why: 'no params{ … } call to write into' })) };
  const edits: Edit[] = [];
  for (const v of values) {
    const field = call.fields.find((f) => f.key === v.name);
    const table = field ? fieldTable(text, field, skip) : undefined;
    const def = table?.fields.find((f) => f.key === 'default');
    if (!def) {
      skipped.push({ name: v.name, why: field ? 'its declaration is not a { default = … } table' : 'not declared by name in params{ … }' });
      continue;
    }
    const was = scriptValue(text.slice(def.valueStart, def.valueEnd));
    if (was.kind === 'expression' || was.kind === 'colour') {
      skipped.push({ name: v.name, why: `its default is worked out (${text.slice(def.valueStart, def.valueEnd).trim()}), not a value to replace` });
      continue;
    }
    edits.push(replaceValue(def, defaultLiteral(v, v.value)));
    baked.push(v.name);
  }
  return { text: edits.length > 0 ? applyEdits(text, edits) : text, baked, skipped };
}
