/**
 * The canvases' arithmetic (Docs/modeler.md M26-M28; Vibe3D D24-D27, D33,
 * D50-D51): pure, no DOM and no three.js, so node tests it.
 *
 * - **A canvas is a drawing plus the camera that made it** (`CapturedCamera`):
 *   its picture plane is a quad standing in front of the model (D27's depth,
 *   `planeDistanceFor`), facing the camera and sized to the frustum there
 *   (`planeSize`), so a texel of the drawing and a point of the plane are one
 *   map (`texelToLocal`, `localToTexel`) -- the stroke unprojection.
 * - **The same view** (`sameView`, D27): projection, target, direction and
 *   frustum height, within tolerances of the model's size -- tight on purpose:
 *   reopening the wrong canvas is worse than capturing another.
 * - **Square-on, and the fade off it** (`facing`, D50, D51): 1 within about
 *   1.15° of the canvas's own direction (it can be drawn into), falling to 0 at
 *   about 4° -- where it is gone, and the reach of the camera's magnet.
 * - **Marquees** (`Mask`): a rectangle, an ellipse or a lasso, in texels; their
 *   bounds, moved, a point inside them, and an ellipse as a polygon.
 * - **The clipboard** (D27): a region kept as a share of its canvas, so a paste
 *   into a canvas of another size lands in the same place at the same scale.
 * - **Marks** (D33): the drawing's alpha down-sampled by its *maximum* (a one-
 *   texel stroke survives), its 8-connected components, each coloured by its
 *   commonest colour, named among the brush's.
 */

export type Vec3 = [number, number, number];
export type Quat = [number, number, number, number];
export type Projection = 'perspective' | 'orthographic';

/** The camera a canvas was captured from, whole: what it was drawn over, and how to reopen and unproject it. */
export interface CapturedCamera {
  projection: Projection;
  position: Vec3;
  target: Vec3;
  /** The camera's orientation: the quad copies it, so its local X and Y are the image's right and up. */
  quaternion: Quat;
  /** Vertical field of view, degrees (perspective). */
  fov: number;
  /** The frustum's height at the target, metres. */
  frustumHeight: number;
  /** The view's width over its height. */
  aspect: number;
  /** From the camera to the picture plane, metres (D27: just in front of the model). */
  planeDistance: number;
  /** The drawing's size, texels. */
  width: number;
  height: number;
}

/** The brush's colours, each with its name: the prompt names marks by colour ("the red marks"), so they are told apart in words. */
export const BRUSH_COLOURS: readonly { name: string; hex: string }[] = [
  { name: 'red', hex: '#ff3b30' },
  { name: 'orange', hex: '#ff9500' },
  { name: 'yellow', hex: '#ffd60a' },
  { name: 'green', hex: '#34c759' },
  { name: 'cyan', hex: '#32ade6' },
  { name: 'blue', hex: '#0a84ff' },
  { name: 'purple', hex: '#bf5af2' },
  { name: 'white', hex: '#ffffff' },
];

/** A drawing's longest edge at most, texels: past it detail costs memory and buys nothing. */
export const MAX_TEXTURE = 2048;
/** Square-on: about 1.15°. A canvas can be drawn into only from here (D26, D50). */
export const SQUARE_ON = 0.9998;
/** Gone: about 4.05°. Between the two it fades, and the camera at rest is pulled onto it (D51). */
export const FACING_GONE = 0.9975;

// ---------------------------------------------------------------- the picture plane

/** How far in front of the camera the plane stands: just in front of the model's sphere, never a postage stamp at the eye (D27). */
export function planeDistanceFor(distance: number, radius: number): number {
  return Math.max(distance - radius * 1.15, distance * 0.2, 1e-4);
}

/** The quad's size in metres: the frustum at the plane's depth -- in orthographic, the frustum itself. */
export function planeSize(cam: Pick<CapturedCamera, 'projection' | 'frustumHeight' | 'planeDistance' | 'fov' | 'aspect'>): { width: number; height: number } {
  const height = cam.projection === 'orthographic' ? cam.frustumHeight : 2 * cam.planeDistance * Math.tan((cam.fov * Math.PI) / 360);
  return { width: height * cam.aspect, height };
}

/** A texel of the drawing as a point on the quad, in its own plane (origin its middle, Y up): the stroke unprojected. */
export function texelToLocal(cam: CapturedCamera, tx: number, ty: number): [number, number] {
  const { width, height } = planeSize(cam);
  return [(tx / cam.width - 0.5) * width, (0.5 - ty / cam.height) * height];
}

/** A point on the quad, back to the drawing's texels. */
export function localToTexel(cam: CapturedCamera, lx: number, ly: number): [number, number] {
  const { width, height } = planeSize(cam);
  return [(lx / width + 0.5) * cam.width, (0.5 - ly / height) * cam.height];
}

/** The drawing's size for a view of `w` by `h` CSS pixels at a pixel ratio: the screen's density, within `MAX_TEXTURE`. */
export function textureSize(w: number, h: number, ratio: number): { width: number; height: number } {
  const longest = Math.max(w, h) * ratio;
  const scale = longest > MAX_TEXTURE ? MAX_TEXTURE / longest : ratio;
  return { width: Math.max(1, Math.round(w * scale)), height: Math.max(1, Math.round(h * scale)) };
}

/** A brush `size` CSS pixels wide, in texels of a canvas `texels` tall seen `viewHeight` CSS pixels tall. */
export function brushTexels(size: number, texels: number, viewHeight: number): number {
  return Math.max(1, (size * texels) / Math.max(1, viewHeight));
}

const sub = (a: Vec3, b: Vec3): Vec3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const len = (a: Vec3): number => Math.hypot(a[0], a[1], a[2]);
const unit = (a: Vec3): Vec3 => {
  const l = len(a) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
};
const dot = (a: Vec3, b: Vec3): number => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

/** A view as `sameView` and `facing` read it: where it is and what it looks at. */
export interface ViewNow {
  projection: Projection;
  position: Vec3;
  target: Vec3;
  frustumHeight: number;
}

/** From the target toward the camera, unit length. */
export const towardCamera = (v: { position: Vec3; target: Vec3 }): Vec3 => unit(sub(v.position, v.target));

/**
 * Is `view` the view `cam` was captured from (D27)? The projection; the target
 * within 2 % of the model's radius; the direction within about 0.6°; the
 * frustum's height within 1 %. A drawing reopened there lies where it was drawn.
 */
export function sameView(cam: CapturedCamera, view: ViewNow, radius: number): boolean {
  if (cam.projection !== view.projection) return false;
  if (len(sub(cam.target, view.target)) > radius * 0.02) return false;
  if (dot(towardCamera(cam), towardCamera(view)) < 0.99995) return false;
  return Math.abs(cam.frustumHeight - view.frustumHeight) <= view.frustumHeight * 0.01;
}

/** How square-on a view is to a canvas, from the cosine between their directions: 1 to draw in, fading to 0 by about 4° (D50). */
export function facing(alignment: number): number {
  if (alignment >= SQUARE_ON) return 1;
  if (alignment <= FACING_GONE) return 0;
  return (alignment - FACING_GONE) / (SQUARE_ON - FACING_GONE);
}

/** The cosine between a view's direction and a canvas's: what `facing` takes. */
export const alignment = (cam: { position: Vec3; target: Vec3 }, view: { position: Vec3; target: Vec3 }): number => dot(towardCamera(cam), towardCamera(view));

/**
 * The frustum's height to reopen a canvas at, in a view of `aspect` now (D25):
 * as captured, widened where the view is narrower than it was, so the whole
 * drawing is in sight -- registration holds at any zoom.
 */
export function reopenHeight(cam: Pick<CapturedCamera, 'frustumHeight' | 'aspect'>, aspect: number): number {
  return cam.frustumHeight * Math.max(1, cam.aspect / Math.max(aspect, 1e-6));
}

// ---------------------------------------------------------------- marquees

/** A region of a drawing, in texels. Replayable, unlike a pixel mask (D27). */
export type Mask =
  | { shape: 'rect'; x: number; y: number; w: number; h: number }
  | { shape: 'ellipse'; x: number; y: number; w: number; h: number }
  | { shape: 'lasso'; points: number[] };

export function maskBounds(mask: Mask): { x: number; y: number; w: number; h: number } {
  if (mask.shape !== 'lasso') return { x: mask.x, y: mask.y, w: mask.w, h: mask.h };
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (let i = 0; i + 1 < mask.points.length; i += 2) {
    x0 = Math.min(x0, mask.points[i]!);
    x1 = Math.max(x1, mask.points[i]!);
    y0 = Math.min(y0, mask.points[i + 1]!);
    y1 = Math.max(y1, mask.points[i + 1]!);
  }
  return x0 === Infinity ? { x: 0, y: 0, w: 0, h: 0 } : { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

/** The mask moved by (`dx`, `dy`): the marquee travels with the pixels it moved. */
export function translateMask(mask: Mask, dx: number, dy: number): Mask {
  if (mask.shape === 'lasso') return { shape: 'lasso', points: mask.points.map((v, i) => (i % 2 === 0 ? v + dx : v + dy)) };
  return { ...mask, x: mask.x + dx, y: mask.y + dy };
}

/** The mask's outline as a polygon, flat x, y pairs: an ellipse in `steps` sides. */
export function maskPolygon(mask: Mask, steps = 64): number[] {
  if (mask.shape === 'lasso') return [...mask.points];
  if (mask.shape === 'rect') return [mask.x, mask.y, mask.x + mask.w, mask.y, mask.x + mask.w, mask.y + mask.h, mask.x, mask.y + mask.h];
  const cx = mask.x + mask.w / 2;
  const cy = mask.y + mask.h / 2;
  const out: number[] = [];
  for (let i = 0; i < steps; i++) {
    const a = (i / steps) * Math.PI * 2;
    out.push(cx + (Math.abs(mask.w) / 2) * Math.cos(a), cy + (Math.abs(mask.h) / 2) * Math.sin(a));
  }
  return out;
}

/** Is (`x`, `y`) inside the mask: where a press moves the marquee's pixels rather than starting another. */
export function insideMask(mask: Mask, x: number, y: number): boolean {
  if (mask.shape === 'rect') return x >= mask.x && x <= mask.x + mask.w && y >= mask.y && y <= mask.y + mask.h;
  if (mask.shape === 'ellipse') {
    const rx = Math.abs(mask.w) / 2;
    const ry = Math.abs(mask.h) / 2;
    if (rx === 0 || ry === 0) return false;
    const nx = (x - (mask.x + mask.w / 2)) / rx;
    const ny = (y - (mask.y + mask.h / 2)) / ry;
    return nx * nx + ny * ny <= 1;
  }
  // Even-odd, as a canvas fills it.
  const p = mask.points;
  let inside = false;
  for (let i = 0, j = p.length - 2; i + 1 < p.length; j = i, i += 2) {
    const xi = p[i]!;
    const yi = p[i + 1]!;
    const xj = p[j]!;
    const yj = p[j + 1]!;
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

/** A marquee dragged from (`x0`, `y0`) to (`x1`, `y1`), or along `points` for a lasso. */
export function marqueeOf(tool: 'rect' | 'ellipse' | 'lasso', x0: number, y0: number, x1: number, y1: number, points: readonly number[]): Mask {
  if (tool === 'lasso') return { shape: 'lasso', points: [...points] };
  return { shape: tool, x: Math.min(x0, x1), y: Math.min(y0, y1), w: Math.abs(x1 - x0), h: Math.abs(y1 - y0) };
}

/** A marquee too small to mean anything -- a click: no selection, not a zero-sized one. */
export function emptyMask(mask: Mask): boolean {
  const b = maskBounds(mask);
  return b.w < 2 || b.h < 2 || (mask.shape === 'lasso' && mask.points.length < 6);
}

// ---------------------------------------------------------------- the clipboard

/** A region copied, as a share of its canvas: pasted into another, it lands in the same place at the same apparent scale (D27). */
export interface ClipPlace {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** A region of `w` by `h` texels at (`x`, `y`) of a canvas `width` by `height`, as shares. */
export const clipOf = (x: number, y: number, w: number, h: number, width: number, height: number): ClipPlace => ({ x: x / width, y: y / height, w: w / width, h: h / height });

/** Where a clip lands in a canvas `width` by `height`, in whole texels. */
export function placeClip(clip: ClipPlace, width: number, height: number): { x: number; y: number; w: number; h: number } {
  return { x: Math.round(clip.x * width), y: Math.round(clip.y * height), w: Math.max(1, Math.round(clip.w * width)), h: Math.max(1, Math.round(clip.h * height)) };
}

// ---------------------------------------------------------------- marks (D33)

/** The mask's longest edge, cells: the components are found on this; detail past it buys nothing. */
export const MASK_EDGE = 384;
/** A component smaller than this many cells is a speck, not a mark. */
export const MIN_CELLS = 6;

/** A drawing's alpha, down-sampled by its maximum to at most `edge` cells along its longest side: a thin stroke survives. */
export function downsampleMax(rgba: ArrayLike<number>, width: number, height: number, edge = MASK_EDGE): { mask: Uint8Array; mw: number; mh: number; sx: number; sy: number } {
  const scale = Math.min(1, edge / Math.max(width, height));
  const mw = Math.max(1, Math.round(width * scale));
  const mh = Math.max(1, Math.round(height * scale));
  const sx = width / mw;
  const sy = height / mh;
  const mask = new Uint8Array(mw * mh);
  for (let y = 0; y < mh; y++) {
    for (let x = 0; x < mw; x++) {
      let peak = 0;
      const x0 = Math.floor(x * sx);
      const x1 = Math.min(width, Math.ceil((x + 1) * sx));
      const y0 = Math.floor(y * sy);
      const y1 = Math.min(height, Math.ceil((y + 1) * sy));
      for (let py = y0; py < y1 && peak <= 96; py++) for (let px = x0; px < x1; px++) peak = Math.max(peak, rgba[(py * width + px) * 4 + 3]!);
      mask[y * mw + x] = peak > 96 ? 1 : 0;
    }
  }
  return { mask, mw, mh, sx, sy };
}

/** One mark: its cells (indices into the mask) and their box. */
export interface Component {
  cells: number[];
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
}

/** The mask's 8-connected regions of at least `min` cells: two strokes that touch are one mark. */
export function components(mask: Uint8Array, mw: number, mh: number, min = MIN_CELLS): Component[] {
  const seen = new Uint8Array(mask.length);
  const out: Component[] = [];
  const stack: number[] = [];
  for (let start = 0; start < mask.length; start++) {
    if (mask[start] === 0 || seen[start] === 1) continue;
    stack.length = 0;
    stack.push(start);
    seen[start] = 1;
    const c: Component = { cells: [], minX: mw, maxX: 0, minY: mh, maxY: 0 };
    while (stack.length > 0) {
      const index = stack.pop()!;
      c.cells.push(index);
      const x = index % mw;
      const y = (index / mw) | 0;
      c.minX = Math.min(c.minX, x);
      c.maxX = Math.max(c.maxX, x);
      c.minY = Math.min(c.minY, y);
      c.maxY = Math.max(c.maxY, y);
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx;
          const ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= mw || ny >= mh) continue;
          const n = ny * mw + nx;
          if (mask[n] === 1 && seen[n] === 0) {
            seen[n] = 1;
            stack.push(n);
          }
        }
      }
    }
    if (c.cells.length >= min) out.push(c);
  }
  return out;
}

const hexOf = (r: number, g: number, b: number): string => `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('')}`;
const rgbOf = (hex: string): [number, number, number] => [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)];

/** The brush colour nearest an RGB, by name and hex: an antialiased edge is still its stroke's colour. */
export function nearestColour(r: number, g: number, b: number): { name: string; hex: string } {
  let best = BRUSH_COLOURS[0]!;
  let bestD = Infinity;
  for (const c of BRUSH_COLOURS) {
    const [cr, cg, cb] = rgbOf(c.hex);
    const d = (cr - r) ** 2 + (cg - g) ** 2 + (cb - b) ** 2;
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  // Far from every brush colour (a paste from elsewhere): its own hex, named by it.
  return bestD > 90 ** 2 ? { name: hexOf(r, g, b), hex: hexOf(r, g, b) } : best;
}

/** A colour named in words: `red`, or a hex for one off the brush. */
export const colourName = (hex: string): string => BRUSH_COLOURS.find((c) => c.hex === hex.toLowerCase())?.name ?? hex.toLowerCase();

/**
 * A drawing made thumbnail-sized so its marks still read (review: a 6-texel
 * stroke scaled to 96 px vanished): each thumbnail pixel the strongest texel
 * of the block it covers -- its colour, whole -- then grown by one pixel, so a
 * stroke is at least about three pixels wide in the list.
 */
export function thumbInk(rgba: ArrayLike<number>, width: number, height: number, tw: number, th: number): Uint8ClampedArray {
  const picked = new Uint8ClampedArray(tw * th * 4);
  const sx = width / tw;
  const sy = height / th;
  for (let y = 0; y < th; y++) {
    for (let x = 0; x < tw; x++) {
      let best = -1;
      let peak = 0;
      const x1 = Math.min(width, Math.ceil((x + 1) * sx));
      const y1 = Math.min(height, Math.ceil((y + 1) * sy));
      for (let py = Math.floor(y * sy); py < y1; py++) {
        for (let px = Math.floor(x * sx); px < x1; px++) {
          const a = rgba[(py * width + px) * 4 + 3]!;
          if (a > peak) {
            peak = a;
            best = (py * width + px) * 4;
          }
        }
      }
      if (best >= 0) for (let c = 0; c < 4; c++) picked[(y * tw + x) * 4 + c] = c === 3 ? 255 : rgba[best + c]!;
    }
  }
  const out = new Uint8ClampedArray(picked);
  for (let y = 0; y < th; y++) {
    for (let x = 0; x < tw; x++) {
      const at = (y * tw + x) * 4;
      if (picked[at + 3] !== 0) continue;
      for (let dy = -1; dy <= 1 && out[at + 3] === 0; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx;
          const ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= tw || ny >= th) continue;
          const n = (ny * tw + nx) * 4;
          if (picked[n + 3] === 0) continue;
          for (let c = 0; c < 4; c++) out[at + c] = picked[n + c]!;
          break;
        }
      }
    }
  }
  return out;
}
