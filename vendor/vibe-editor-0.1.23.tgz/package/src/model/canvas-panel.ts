/**
 * The Canvases pane of the Model tab's left panel (Docs/modeler.md M28;
 * Vibe3D's `layerPanel.ts`, D27, D52, D63, D75): the painter's bar over the
 * list of canvases and the open one's note. Dumb: it draws what the
 * controller (`canvases.ts`) holds and calls back; nothing is kept here.
 *
 * - **The painter's bar**: brush, eraser and the three marquees; the brush's
 *   colours, each named on its hover (a prompt names marks by colour); its
 *   size, with a true-size ring shown in the view as it moves; copy, cut,
 *   paste and delete of a marquee's marks -- between canvases too; Undo, the
 *   open canvas's own (Z). Every button's tip names its key.
 * - **The list**, oldest first (a turn sends them so): a thumbnail of the
 *   drawing over the render, its name and what it is ("3 edits", "stale --
 *   drawn before a rebuild: not sent", "empty"), its eye, its ×. A click goes
 *   back to it: its camera, what was selected and hidden then.
 * - **The note**, the open canvas's: "the person says of it" in the turn,
 *   quoted first; a note alone is a turn (D80). Never redrawn under the caret.
 * - **"Show all canvases"**: every visible canvas from everywhere (D25).
 * - **Empty**: how a canvas comes to be, in a sentence.
 */
import { control, el, icon } from '../dom.ts';
import type { IconName } from '../icons.ts';
import { BRUSH_COLOURS } from './canvas-math.ts';
import { poseText } from './clips.ts';
import { stepText } from './trace-steps.ts';
import type { Canvases, PaintTool } from './canvases.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import type { Mcp } from '../mcp/declare.ts';

export interface CanvasPanelHost {
  /** Undo on the open canvas (the editor's, on its stack). */
  undo(): void;
  /** A canvas removed: the tab makes it a step and says so. */
  remove(id: string): void;
  /** Keys as the tips name them. */
  keys: { tool: Record<PaintTool, string>; erase: string; marquee: string; smaller: string; bigger: string; copy: string; cut: string; paste: string; delete: string; undo: string; pane: string };
}

const TOOLS: readonly { tool: PaintTool; glyph: IconName; words: string }[] = [
  { tool: 'brush', glyph: 'brush', words: 'Brush: draw on the view -- the first stroke in a view captures it as a canvas' },
  { tool: 'eraser', glyph: 'eraser', words: 'Eraser: rub marks off the open canvas' },
  { tool: 'rect', glyph: 'marqueeRect', words: 'Rectangle select: drag inside it to move the marks' },
  { tool: 'ellipse', glyph: 'marqueeEllipse', words: 'Ellipse select: drag inside it to move the marks' },
  { tool: 'lasso', glyph: 'lasso', words: 'Lasso select: drag inside it to move the marks' },
];

export interface CanvasPanel {
  draw(): void;
  /** The note box has the focus: its keys are typing. */
  readonly typing: boolean;
}

export function createCanvasPanel(into: HTMLElement, canvases: Canvases, host: CanvasPanelHost): CanvasPanel {
  const keyed = (words: string, key: string): string => (key ? `${words} (${key})` : words);
  const button = (mcp: Mcp, glyph: IconName, run: () => void): HTMLButtonElement => {
    const b = control(mcp, 'ed-mo-paint-b') as HTMLButtonElement;
    b.append(icon(glyph));
    b.addEventListener('click', () => {
      b.blur();
      run();
    });
    return b;
  };

  // ---------------------------------------------------------------- the painter's bar

  const bar = el('div', 'ed-mo-paintbar');
  const toolButtons = TOOLS.map((t) => {
    const b = button('ui', t.glyph, () => canvases.setTool(t.tool));
    b.title = keyed(t.words, host.keys.tool[t.tool]);
    return { tool: t.tool, b };
  });
  const tools = el('div', 'ed-mo-paint-row');
  tools.append(...toolButtons.map((x) => x.b));
  const swatches = el('div', 'ed-mo-paint-row ed-mo-swatches');
  const swatchButtons = BRUSH_COLOURS.map((c) => {
    const b = control('ui', 'ed-mo-swatch') as HTMLButtonElement;
    b.style.setProperty('--swatch', c.hex);
    b.title = `${c.name[0]!.toUpperCase()}${c.name.slice(1)}: a prompt can name these marks -- "the ${c.name} ones"`;
    b.addEventListener('click', () => {
      b.blur();
      canvases.setColour(c.hex);
    });
    swatches.append(b);
    return { hex: c.hex, b };
  });
  const sizeRow = el('label', 'ed-mo-paint-row ed-mo-size');
  const slider = el('input', 'ed-mo-size-slider') as HTMLInputElement;
  slider.type = 'range';
  slider.min = '1';
  slider.max = '60';
  slider.title = keyed('The brush\'s size, in screen pixels: its ring shows it, true size, in the view', `${host.keys.smaller} ${host.keys.bigger}`);
  const sizeWords = el('span', 'ed-mo-size-words');
  sizeRow.append(el('span', 'ed-dim', 'Size'), slider, sizeWords);
  slider.addEventListener('input', () => canvases.setSize(Number(slider.value)));
  slider.addEventListener('change', () => slider.blur());
  const copyB = button('ui', 'copy', () => canvases.copy());
  copyB.title = keyed('Copy the marks in the marquee', host.keys.copy);
  const cutB = button(NOT_FOR_CLAUDE.paintCanvas, 'cut', () => canvases.cutSelection());
  cutB.title = keyed('Cut the marks in the marquee', host.keys.cut);
  const pasteB = button(NOT_FOR_CLAUDE.paintCanvas, 'paste', () => canvases.paste());
  pasteB.title = keyed('Paste into the open canvas -- another canvas too: the same place, the same scale', host.keys.paste);
  const deleteB = button(NOT_FOR_CLAUDE.paintCanvas, 'trash', () => canvases.deleteSelection());
  deleteB.title = keyed('Delete the marks in the marquee', host.keys.delete);
  const undoB = button(NOT_FOR_CLAUDE.paintCanvas, 'undo', () => host.undo());
  const edits = el('div', 'ed-mo-paint-row');
  edits.append(copyB, cutB, pasteB, deleteB, el('i', 'ed-mo-sep'), undoB);
  const ghostRow = el('label', 'ed-mo-paint-row ed-mo-ghosts');
  const ghost = el('input') as HTMLInputElement;
  ghost.type = 'checkbox';
  ghostRow.title = 'Every visible canvas standing in the scene, from every angle -- off, only the open one, and only from about where it was drawn';
  ghostRow.append(ghost, el('span', undefined, 'Show all canvases'));
  ghost.addEventListener('change', () => {
    ghost.blur();
    canvases.setGhosts(ghost.checked);
  });
  bar.append(tools, swatches, sizeRow, edits, ghostRow);

  // ---------------------------------------------------------------- the list and the note

  const list = el('div', 'ed-mo-canvases');
  const noteHead = el('div', 'ed-mo-note-head');
  const note = el('textarea', 'ed-mo-note') as HTMLTextAreaElement;
  note.rows = 3;
  note.addEventListener('input', () => canvases.setNote(note.value));
  into.append(bar, list, noteHead, note);

  function row(index: number): HTMLElement {
    const canvas = canvases.list[index]!;
    const item = el('div', 'ed-mo-crow');
    item.classList.toggle('ed-mo-crow-open', canvas === canvases.open);
    item.classList.toggle('ed-mo-crow-stale', canvas.stale);
    item.classList.toggle('ed-mo-crow-off', !canvas.visible);
    const thumb = el('span', 'ed-mo-thumb');
    thumb.append(canvas.thumb);
    const words = el('span', 'ed-mo-cwords');
    const edits = canvas.ops.length;
    const drawn = canvas.base && edits === 0 ? 'from before the reload' : `${canvas.base ? 'from before the reload, ' : ''}${edits} ${edits === 1 ? 'edit' : 'edits'}`;
    // The pose it is over, as gladius_query names it (D89): `fly@0.2`.
    // ...and the build step it is over (D69): `step 12`, its op on the hover.
    const over = `${canvas.pose ? ` · ${poseText(canvas.pose)}` : ''}${canvas.step ? ` · step ${canvas.step.index}` : ''}`;
    const what = canvas.stale ? `stale: drawn before a rebuild -- not sent${over}` : canvas.empty ? `empty${over}` : `${drawn}${over}${canvas.note.trim() ? ' · a note' : ''}${canvas.skipped ? ' · left out of this turn' : ''}`;
    words.append(el('span', 'ed-mo-cname', canvas.name), el('span', 'ed-mo-cwhat', what));
    const eye = control('ui', 'ed-mo-eye') as HTMLButtonElement;
    eye.append(icon(canvas.visible ? 'eye' : 'eyeOff'));
    eye.setAttribute('aria-pressed', String(!canvas.visible));
    eye.title = canvas.visible ? 'Hide it: not shown, not sent' : 'Show it: sent with the next turn';
    eye.addEventListener('click', (event) => {
      event.stopPropagation();
      eye.blur();
      canvases.setVisible(canvas.id, !canvas.visible);
    });
    const drop = control(NOT_FOR_CLAUDE.paintCanvas, 'ed-mo-eye') as HTMLButtonElement;
    drop.append(icon('close'));
    drop.title = 'Delete this canvas (Z on the model brings it back)';
    drop.addEventListener('click', (event) => {
      event.stopPropagation();
      host.remove(canvas.id);
    });
    item.append(thumb, words, eye, drop);
    item.title = `${canvas.name}: click to go back to it -- its camera, and the parts selected and hidden when it was drawn${canvas.step ? `; drawn over the build trace's ${stepText(canvas.step)}, shown again` : ''}`;
    // mcp: ui -- the view as a canvas was drawn: its camera, parts selected and hidden
    item.addEventListener('click', () => canvases.select(canvas.id, true));
    return item;
  }

  function draw(): void {
    for (const { tool, b } of toolButtons) b.setAttribute('aria-pressed', String(canvases.tool === tool));
    for (const { hex, b } of swatchButtons) b.setAttribute('aria-pressed', String(canvases.colour === hex && canvases.tool === 'brush'));
    if (document.activeElement !== slider) slider.value = String(canvases.size);
    sizeWords.textContent = `${canvases.size} px`;
    const marquee = canvases.hasMarquee;
    copyB.disabled = !marquee;
    cutB.disabled = !marquee;
    deleteB.disabled = !marquee;
    pasteB.disabled = !canvases.canPaste || canvases.open === null;
    const open = canvases.open;
    undoB.disabled = !open || !open.history.canUndo;
    undoB.title = open?.history.undoLabel ? `Undo ${open.history.undoLabel} (${host.keys.undo})` : `Undo the open canvas's last edit (${host.keys.undo})`;
    ghost.checked = canvases.ghosts;
    const rows = canvases.list.map((_, i) => row(i));
    if (rows.length === 0) {
      list.replaceChildren(el('div', 'ed-mo-nothing', `Draw on a view: the first stroke captures it as a canvas -- its picture, its camera, the parts selected -- and the next turn of the Claude card takes it with the words. Alt-drag still orbits, a right drag pans. ${host.keys.pane} goes back to the parts.`));
    } else list.replaceChildren(...rows);
    noteHead.textContent = open ? `Note on ${open.name}` : 'Note';
    note.disabled = open === null;
    note.placeholder = open ? `What should change here? It goes with the next turn, quoted first -- a note alone is a turn.` : 'Open a canvas -- draw, or click one above -- to write what it is about.';
    // Never under the caret: the box is written only while nobody types in it.
    if (document.activeElement !== note) note.value = open?.note ?? '';
  }

  draw();
  return {
    draw,
    get typing() {
      return document.activeElement === note;
    },
  };
}
