/**
 * The Materials block in the Model tab's right panel (Docs/modeler.md §4,
 * M24; Vibe3D D88, D94, D96): one entry per material the model is drawn with,
 * in `material{}`'s words -- its colour (linear, as the script writes it; the
 * swatch in display colour), metallic, roughness, emissive, alpha, vertex
 * colours, each texture slot with its picture, size, filtering and wrapping.
 *
 * - **A click on an entry's name selects the parts drawn with it** (D88): a
 *   way into the parts, not a second selection; the entry is marked while the
 *   selection uses it. Its caret folds it (kept by name, D94): the caret apart
 *   from the name, so folding never changes the selection.
 * - **A material the script declares is edited in place** (D94): colour and
 *   emissive pickers, metallic and roughness sliders with their numbers, alpha
 *   mode and cutoff, the base texture's filtering and wrapping, every texture
 *   slot set to an image in the script's folder (the normal map's row always
 *   there to add one) or taken out. A control previews on the model as it
 *   moves (`live`) and is written into the script's `material{}` call as it is
 *   let go (`commit`): one step of the tab's undo, the export once.
 * - **One it does not** -- an import's, a name worked out as the script runs --
 *   is read-only, and says why: there is no call to write into.
 * - **Compression** (`compress`, D96) is read from the script and shown, not
 *   offered: the pipeline makes a model's textures WebP after Gladius (its
 *   `textureMax` and `textureQuality` options), so a KTX2 Gladius made would
 *   not reach the game.
 */
import { button, control, el } from '../dom.ts';
import { numberField } from '../fields.ts';
import { luaNumber } from './lua-table.ts';
import type { DeclaredMaterial, MaterialField, MaterialValue } from './script-edits.ts';
import { linearToHex, hexToLinear, NO_MATERIAL, TEXTURE_SLOTS, undeclaredWords, type LiveChange, type MaterialInfo, type TextureInfo, type TextureSlot } from './materials.ts';

export interface MaterialPanelHost {
  /** The parts drawn with it selected. */
  select(info: MaterialInfo): void;
  /** A control moving: the model changed live, nothing written. */
  live(info: MaterialInfo, change: LiveChange): void;
  /** A control let go: written into its material{} call; `from` is what it was, for the step's label. */
  commit(info: MaterialInfo, field: MaterialField, value: MaterialValue, from: string): void;
  /** Its texture slot to pick for: the images in the script's folder, as the script names them. */
  images(): string[];
  /** A material folded or unfolded, by name: kept. */
  folded(name: string, folded: boolean): void;
  /** The whole block folded or unfolded: kept. */
  foldedAll(folded: boolean): void;
}

export interface MaterialView {
  list: readonly MaterialInfo[];
  /** What the script declares, by name. */
  declared: ReadonlyMap<string, DeclaredMaterial>;
  /** The names of the materials the selection is drawn with. */
  selected: ReadonlySet<string>;
  /** Folded, by name. */
  folded: ReadonlySet<string>;
  writes: boolean;
  /** Why not, when it may not. */
  readOnly?: string | null;
  /** A model is shown: its materials are read off it (none shown: nothing to read, said as such). */
  modelShown: boolean;
  /** The script's text is not read yet: nothing can be said to be declared. */
  reading: boolean;
}

export interface MaterialPanel {
  readonly root: HTMLElement;
  draw(view: MaterialView): void;
  setFolded(folded: boolean): void;
}

const SLOT_WORDS: Readonly<Record<TextureSlot, string>> = {
  texture: 'Base colour',
  normal_texture: 'Normal map',
  metallic_roughness_texture: 'Metal / rough',
  occlusion_texture: 'Occlusion',
  emissive_texture: 'Emissive',
};

/** A colour as the script is given it: `luaValue`'s numbers, four places at most -- what is shown is what is written. */
const v3Text = (c: readonly number[]): string => `v3(${c.map(luaNumber).join(', ')})`;

/** A texture's picture, small: drawn pixelated when it is filtered nearest, so a palette atlas looks as it is sampled. */
function thumbOf(info: TextureInfo): HTMLElement {
  const canvas = el('canvas', 'ed-mo-thumb');
  const size = 40;
  canvas.width = size;
  canvas.height = size;
  if (info.filter === 'nearest') canvas.classList.add('ed-mo-thumb-px');
  const image = info.texture.image as CanvasImageSource | null;
  const ctx = canvas.getContext('2d');
  if (ctx && image && info.width > 0 && info.height > 0) {
    ctx.imageSmoothingEnabled = info.filter !== 'nearest';
    const scale = Math.min(size / info.width, size / info.height);
    const w = info.width * scale;
    const h = info.height * scale;
    try {
      ctx.drawImage(image, (size - w) / 2, (size - h) / 2, w, h);
    } catch {
      // A compressed texture has no picture to draw: the box stays empty, its size said beside it.
    }
  }
  return canvas;
}

export function createMaterialPanel(host: MaterialPanelHost): MaterialPanel {
  const root = el('section', 'ed-mo-sec');
  const head = el('div', 'ed-mo-sec-head');
  const caret = control('ui', 'ed-mo-sec-caret');
  const title = el('span', 'ed-mo-sec-title', 'Materials');
  const count = el('span', 'ed-mo-sec-count');
  head.append(caret, title, count);
  const status = el('div', 'ed-mo-sec-status');
  const list = el('div', 'ed-mo-mats');
  const body = el('div', 'ed-mo-sec-body');
  body.append(status, list);
  root.append(head, body);

  let shut = false;
  const fold = (next: boolean): void => {
    shut = next;
    root.classList.toggle('ed-mo-shut', shut);
    caret.textContent = shut ? '▸' : '▾';
    caret.title = shut ? 'Show the materials' : 'Fold the materials away';
  };
  fold(false);
  const toggle = (): void => {
    fold(!shut);
    host.foldedAll(shut);
  };
  caret.addEventListener('click', toggle);
  // mcp: ui -- the section folded
  title.addEventListener('click', toggle);

  /** What was drawn last: a draw that would draw the same touches nothing -- a control in hand is never made again under it. */
  let last = '';
  /** A control is being moved or typed in: the entries are not made again until it is let go. */
  let holding = false;
  let pendingView: MaterialView | null = null;

  /** One entry's editable body: each control previews as it moves and commits as it is let go. */
  function controls(info: MaterialInfo, declared: DeclaredMaterial | undefined, writes: boolean, readOnly: string | null, reading: boolean): HTMLElement[] {
    const out: HTMLElement[] = [];
    const editable = declared !== undefined && writes;
    const grid = el('div', 'ed-mo-mat-grid');
    const hold = (on: boolean): void => {
      holding = on;
      if (!on && pendingView) {
        const v = pendingView;
        pendingView = null;
        draw(v);
      }
    };

    // Colours: a swatch in display colour, the script's linear v3 beside it.
    const colour = (label: string, field: 'base_color' | 'emissive', value: [number, number, number], extra?: string): void => {
      const swatch = el('input', 'ed-mo-swatch');
      swatch.type = 'color';
      swatch.value = linearToHex(value);
      swatch.disabled = !editable;
      const said = el('span', 'ed-mo-mat-value', `${v3Text(value)}${extra ?? ''}`);
      said.title = `${field} = ${v3Text(value)} -- linear, as the script writes it; ${swatch.value} on screen`;
      swatch.title = editable ? `${field}: pick -- the model shows it as you move; closed, it is written into the script` : said.title;
      const from = v3Text(value);
      swatch.addEventListener('input', () => {
        hold(true);
        const lin = hexToLinear(swatch.value);
        said.textContent = `${v3Text(lin)}${extra ?? ''}`;
        host.live(info, { [field]: lin });
      });
      swatch.addEventListener('change', () => {
        host.commit(info, field, hexToLinear(swatch.value), from);
        hold(false);
      });
      const cell = el('span', 'ed-mo-mat-colour');
      cell.append(swatch, said);
      grid.append(el('span', 'ed-dim', label), cell);
    };
    colour('base_color', 'base_color', info.baseColor, info.vertexColours ? ' × vertex colours' : '');
    if (info.vertexColours) grid.lastElementChild!.setAttribute('title', 'Drawn with the mesh\'s vertex colours times this: on a white material they are the whole colour');

    // Numbers 0..1: a slider and its number.
    const unit = (label: 'metallic' | 'roughness', value: number): void => {
      const from = String(Number(value.toFixed(3)));
      let now = value;
      const slider = el('input', 'ed-mo-slider');
      slider.type = 'range';
      slider.min = '0';
      slider.max = '1';
      slider.step = '0.01';
      slider.value = String(value);
      slider.disabled = !editable;
      const field = numberField({
        label: '',
        value,
        step: 0.01,
        min: 0,
        max: 1,
        digits: 3,
        fixed: !editable,
        title: `${label}: 0 to 1`,
        set(v) {
          hold(true);
          now = v;
          slider.value = String(v);
          host.live(info, { [label === 'metallic' ? 'metallic' : 'roughness']: v });
        },
        commit() {
          host.commit(info, label, now, from);
          hold(false);
        },
      });
      (field.label.firstElementChild as HTMLElement).remove();
      slider.addEventListener('input', () => {
        hold(true);
        now = Number(slider.value);
        field.show(now);
        host.live(info, { [label]: now });
      });
      slider.addEventListener('change', () => {
        host.commit(info, label, Number(slider.value), from);
        hold(false);
      });
      const cell = el('span', 'ed-mo-mat-unit');
      cell.append(slider, field.label);
      grid.append(el('span', 'ed-dim', label), cell);
    };
    unit('metallic', info.metallic);
    unit('roughness', info.roughness);
    colour('emissive', 'emissive', info.emissive);

    // Alpha: its mode, and its cutoff for a mask.
    const choice = (label: string, field: MaterialField, value: string, options: readonly string[], tip: string): HTMLSelectElement => {
      const select = el('select', 'ed-input ed-small ed-mo-mat-choice');
      for (const o of options) {
        const opt = el('option', undefined, o);
        opt.value = o;
        select.append(opt);
      }
      select.value = value;
      select.disabled = !editable;
      select.title = tip;
      select.addEventListener('change', () => {
        host.live(info, { [field]: select.value } as LiveChange);
        host.commit(info, field, select.value, value);
      });
      grid.append(el('span', 'ed-dim', label), select);
      return select;
    };
    choice('alpha_mode', 'alpha_mode', info.alphaMode, ['opaque', 'mask', 'blend'], 'opaque; mask: cut below alpha_cutoff (best for leaves, fences); blend: see-through, drawn in order');
    if (info.alphaMode === 'mask') {
      let cutoff = info.alphaCutoff;
      const field = numberField({
        label: '',
        value: info.alphaCutoff,
        step: 0.01,
        min: 0,
        max: 1,
        digits: 3,
        fixed: !editable,
        title: 'alpha_cutoff: below this alpha, nothing is drawn',
        set(v) {
          hold(true);
          cutoff = v;
          host.live(info, { alpha_cutoff: v });
        },
        commit() {
          host.commit(info, 'alpha_cutoff', cutoff, String(info.alphaCutoff));
          hold(false);
        },
      });
      (field.label.firstElementChild as HTMLElement).remove();
      grid.append(el('span', 'ed-dim', 'alpha_cutoff'), field.label);
    }
    out.push(grid);

    // The texture slots: each with its picture, or Add for the normal map.
    const slots = el('div', 'ed-mo-mat-slots');
    for (const slot of TEXTURE_SLOTS) {
      const tex = info.textures.find((x) => x.slot === slot);
      const written = declared?.fields[slot];
      const path = written?.kind === 'string' ? written.value : null;
      if (!tex && slot !== 'normal_texture' && !path) continue;
      const row = el('div', 'ed-mo-mat-slot');
      const text = el('div', 'ed-mo-mat-slot-text');
      text.append(el('span', 'ed-mo-mat-slot-name', SLOT_WORDS[slot]));
      if (tex) text.append(el('span', 'ed-dim', `${tex.width}×${tex.height} · ${tex.filter} · ${tex.wrap}`));
      if (path) text.append(el('span', 'ed-mo-mat-path', path));
      else if (!tex) text.append(el('span', 'ed-dim', 'none'));
      if (tex) row.append(thumbOf(tex));
      else row.append(el('span', 'ed-mo-thumb ed-mo-thumb-none'));
      row.append(text);
      if (editable) {
        const actions = el('div', 'ed-buttons');
        const pick = el('select', 'ed-input ed-small ed-mo-mat-pick');
        const images = host.images();
        const first = el('option', undefined, tex || path ? 'Change…' : 'Add…');
        first.value = '';
        pick.append(first);
        for (const image of images) {
          const o = el('option', undefined, image);
          o.value = image;
          pick.append(o);
        }
        if (images.length === 0) {
          const none = el('option', undefined, 'No PNG or JPEG in the script\'s folder: drop one into it in the Assets panel');
          none.disabled = true;
          pick.append(none);
        }
        pick.title = `${SLOT_WORDS[slot]}: an image in the script's folder or under it (Gladius reads textures there alone)`;
        pick.addEventListener('change', () => {
          if (pick.value) host.commit(info, slot, pick.value, path ?? 'none');
        });
        actions.append(pick);
        if (path) actions.append(button('model_materials_set', 'Remove', `${slot} taken out of the material{} call`, () => host.commit(info, slot, null, path), 'ed-small ed-quiet'));
        row.append(actions);
      }
      slots.append(row);
    }
    // The base texture's sampler: Gladius sets it for `texture` alone (its ADR-081); the other slots are linear and repeat.
    const base = info.textures.find((x) => x.slot === 'texture');
    if (base) {
      const sampler = el('div', 'ed-mo-mat-grid');
      const f = el('select', 'ed-input ed-small');
      const w = el('select', 'ed-input ed-small');
      for (const o of ['nearest', 'linear']) f.append(Object.assign(el('option', undefined, o), { value: o }));
      for (const o of ['clamp', 'repeat']) w.append(Object.assign(el('option', undefined, o), { value: o }));
      f.value = base.filter;
      w.value = base.wrap === 'repeat' ? 'repeat' : 'clamp';
      f.disabled = w.disabled = !editable;
      f.title = 'texture_filter: nearest keeps a palette atlas\'s swatches crisp; linear smooths a painted texture';
      w.title = 'texture_wrap: clamp, or repeat to tile';
      f.addEventListener('change', () => {
        host.live(info, { texture_filter: f.value as 'nearest' | 'linear' });
        host.commit(info, 'texture_filter', f.value, base.filter);
      });
      w.addEventListener('change', () => {
        host.live(info, { texture_wrap: w.value as 'clamp' | 'repeat' });
        host.commit(info, 'texture_wrap', w.value, base.wrap);
      });
      sampler.append(el('span', 'ed-dim', 'texture_filter'), f, el('span', 'ed-dim', 'texture_wrap'), w);
      slots.append(sampler);
    }
    if (slots.childElementCount > 0) out.push(slots);
    const compress = declared?.fields.compress;
    if (compress) {
      const c = el('div', 'ed-dim ed-mo-mat-note', `compress = ${compress.kind === 'string' ? compress.value : 'worked out'} -- not used here: the pipeline makes the textures WebP (textureMax, textureQuality in the Options block)`);
      out.push(c);
    }
    if (!declared && reading) {
      out.push(el('div', 'ed-dim ed-mo-mat-note', 'Reading the script…: whether it declares this material is known once it is read.'));
    } else if (!declared) {
      out.push(el('div', 'ed-dim ed-mo-mat-note', undeclaredWords(info.name)));
    } else if (!writes) out.push(el('div', 'ed-dim ed-mo-mat-note', readOnly ?? 'Read only: materials are edited on the machine running the dev server.'));
    return out;
  }

  function draw(view: MaterialView): void {
    if (holding) {
      pendingView = view;
      return;
    }
    // What it is drawn from, but the three.js objects: a rebuild that changes nothing is not drawn again.
    const key = JSON.stringify([
      view.list.map((m) => [m.name, m.baseColor, m.metallic, m.roughness, m.emissive, m.alphaMode, m.alphaCutoff, m.vertexColours, m.parts.map((p) => p.id), m.textures.map((x) => [x.slot, x.width, x.height, x.filter, x.wrap, x.texture.uuid])]),
      [...view.declared.values()],
      [...view.selected],
      [...view.folded],
      view.writes,
      view.readOnly,
      view.modelShown,
      view.reading,
    ]);
    if (key === last) return;
    last = key;
    count.textContent = view.list.length > 0 ? String(view.list.length) : '';
    status.hidden = view.list.length > 0;
    status.textContent = view.list.length > 0 ? '' : view.modelShown ? 'No materials: the model draws nothing.' : 'No model shown: its materials are read off the model once it builds.';
    const entries: HTMLElement[] = [];
    for (const info of view.list) {
      const declared = view.declared.get(info.name);
      const entry = el('div', 'ed-mo-mat');
      entry.classList.toggle('ed-mo-mat-used', view.selected.has(info.name));
      const top = el('div', 'ed-mo-mat-head');
      const fold = control('ui', 'ed-mo-sec-caret');
      const shutNow = view.folded.has(info.name);
      fold.textContent = shutNow ? '▸' : '▾';
      fold.title = shutNow ? 'Show its settings' : 'Fold its settings away';
      fold.addEventListener('click', () => host.folded(info.name, !shutNow));
      const chip = el('span', 'ed-mo-mat-chip');
      chip.style.background = linearToHex(info.baseColor);
      const name = control('ui', 'ed-mo-mat-name');
      name.textContent = info.name;
      name.title = `Select the ${info.parts.length === 1 ? 'part' : `${info.parts.length} parts`} drawn with ${info.name}: ${info.parts.map((p) => p.name).join(', ') || 'none'}`;
      name.addEventListener('click', () => host.select(info));
      const none = info.name === NO_MATERIAL;
      const tag = el('span', 'ed-mo-mat-tag', declared ? `line ${declared.line}` : view.reading ? 'reading…' : none ? 'none given' : 'not in the script');
      tag.title = declared ? `material{ name = "${info.name}" } is on line ${declared.line} of the script: edits are written there` : none ? 'Their emit names no material: the file\'s default, white' : 'Read only: no material{} call names it';
      top.append(fold, chip, name, tag);
      entry.append(top);
      if (!shutNow) {
        const inner = el('div', 'ed-mo-mat-body');
        inner.append(...controls(info, declared, view.writes, view.readOnly ?? null, view.reading));
        entry.append(inner);
      }
      entries.push(entry);
    }
    list.replaceChildren(...entries);
  }

  return { root, draw, setFolded: fold };
}
