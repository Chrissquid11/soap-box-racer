/**
 * A canvas's marks raycast onto the mesh (Docs/modeler.md M27; Vibe3D D33):
 * a point in an image is a ray, and only the mesh knows where it ends -- the
 * tab has the mesh, so each mark is told where it actually lands.
 *
 * - **The marks**: the drawing's alpha down-sampled by its maximum, its
 *   connected regions (`canvas-math.ts`), each coloured by its commonest
 *   colour, named among the brush's.
 * - **Up to 40 rays a mark**, through its texels from the camera that drew it
 *   -- rebuilt from the canvas's own camera, never the view's now -- along
 *   the view in orthographic. What they hit: the mean point and normal, the
 *   extent in metres, the parts (`emit{name=…}`) under it, the share of rays
 *   that hit.
 * - **A miss is a miss** (D33): never snapped to whatever is behind. Said
 *   with the ray through its middle, where that crosses the drawing's plane (a
 *   stand-in depth), and where it meets the ground, y = 0, if it does -- the
 *   one surface a mark can miss the model and still mean ("put one here").
 *
 * three.js and plain arrays only, no DOM: node tests it against a box.
 */
import * as THREE from 'three';
import type { MarkAnchor, Vec3 as Vec3T } from '@vibe/pipeline/agent-types';
import { components, downsampleMax, nearestColour, planeDistanceFor, texelToLocal, textureSize, type CapturedCamera } from './canvas-math.ts';
import type { ViewCamera } from '../view/view-camera.ts';

/** Rays a mark at most: enough to even out a wobbly stroke, few enough to be instant. */
const MAX_SAMPLES = 40;

const round = (v: THREE.Vector3): Vec3T => [Math.round(v.x * 1e4) / 1e4, Math.round(v.y * 1e4) / 1e4, Math.round(v.z * 1e4) / 1e4];

/**
 * A view captured as a canvas's camera (D24, D27): where it is, what it looks
 * at, its orientation, its lens and frustum, the plane's depth just in front
 * of the model (`radius` round `centre`), and the drawing's texels for a view
 * `w` by `h` CSS pixels at the screen's `ratio`.
 */
export function captureCamera(view: ViewCamera, w: number, h: number, radius: number, ratio: number): CapturedCamera {
  view.update();
  const camera = view.camera;
  const distance = view.distance || 1;
  const size = textureSize(w, h, ratio);
  return {
    projection: view.projection,
    position: camera.position.toArray() as [number, number, number],
    target: view.target.toArray() as [number, number, number],
    quaternion: camera.quaternion.toArray() as [number, number, number, number],
    fov: view.perspective.fov,
    frustumHeight: view.frustumHeight(distance),
    aspect: w / Math.max(h, 1),
    planeDistance: planeDistanceFor(distance, radius),
    width: size.width,
    height: size.height,
  };
}

/** The camera's up, from its orientation: the turn's camera block says it whole (D33). */
export function upOf(cam: CapturedCamera): Vec3T {
  return round(new THREE.Vector3(0, 1, 0).applyQuaternion(new THREE.Quaternion(...cam.quaternion)));
}

/** The world point on a canvas's plane under a texel: the stroke unprojected. */
export function texelToWorld(cam: CapturedCamera, tx: number, ty: number, out = new THREE.Vector3()): THREE.Vector3 {
  const q = new THREE.Quaternion(...cam.quaternion);
  const [lx, ly] = texelToLocal(cam, tx, ty);
  const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(q);
  return out
    .fromArray(cam.position)
    .addScaledVector(forward, cam.planeDistance)
    .add(new THREE.Vector3(lx, ly, 0).applyQuaternion(q));
}

/** A ray from the canvas's camera through a texel: from the eye in perspective, along the view in orthographic. */
export function aimThroughTexel(ray: THREE.Ray, cam: CapturedCamera, tx: number, ty: number): void {
  const onPlane = texelToWorld(cam, tx, ty);
  if (cam.projection === 'orthographic') {
    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(new THREE.Quaternion(...cam.quaternion));
    ray.origin.copy(onPlane).addScaledVector(forward, -1000);
    ray.direction.copy(forward);
    return;
  }
  ray.origin.fromArray(cam.position);
  ray.direction.copy(onPlane).sub(ray.origin).normalize();
}

/** Where a ray meets y = 0, if ahead and within reach: past 10 km a ray is a direction, not a place. */
export function groundHit(ray: THREE.Ray): THREE.Vector3 | null {
  if (Math.abs(ray.direction.y) < 1e-6) return null;
  const t = -ray.origin.y / ray.direction.y;
  return t <= 0 || t > 1e4 ? null : ray.at(t, new THREE.Vector3());
}

/**
 * Each mark of a drawing (`rgba`, `cam.width` by `cam.height` texels) where it
 * lands on `targets` -- the parts drawn now, a hidden one left out, so a mark
 * goes through to what is seen behind it -- `partOf` naming the part a hit
 * object belongs to; biggest first. No targets: every mark misses.
 */
export function anchorsOf(rgba: ArrayLike<number>, cam: CapturedCamera, targets: readonly THREE.Object3D[], partOf: (object: THREE.Object3D) => string | null): MarkAnchor[] {
  const { width } = cam;
  const { mask, mw, mh, sx, sy } = downsampleMax(rgba, cam.width, cam.height);
  const caster = new THREE.Raycaster();
  for (const t of targets) t.updateWorldMatrix(true, true);
  const model = targets.length > 0;
  const anchors: MarkAnchor[] = [];
  for (const c of components(mask, mw, mh)) {
    const step = Math.max(1, Math.floor(c.cells.length / MAX_SAMPLES));
    const counts = new Map<string, { name: string; hex: string; n: number }>();
    const hits: THREE.Intersection[] = [];
    let sampled = 0;
    for (let i = 0; i < c.cells.length; i += step) {
      const cell = c.cells[i]!;
      const cx = ((cell % mw) + 0.5) * sx;
      const cy = (((cell / mw) | 0) + 0.5) * sy;
      // The colour of the strongest texel of the cell: an antialiased edge is its stroke's colour.
      const at = (Math.min(cam.height - 1, Math.floor(cy)) * width + Math.min(width - 1, Math.floor(cx))) * 4;
      const colour = nearestColour(rgba[at]!, rgba[at + 1]!, rgba[at + 2]!);
      const had = counts.get(colour.hex);
      if (had) had.n++;
      else counts.set(colour.hex, { ...colour, n: 1 });
      if (!model) continue;
      sampled++;
      aimThroughTexel(caster.ray, cam, cx, cy);
      const hit = caster.intersectObjects(targets as THREE.Object3D[], true)[0];
      if (hit) hits.push(hit);
    }
    const colour = [...counts.values()].sort((a, b) => b.n - a.n)[0] ?? { name: 'white', hex: '#ffffff', n: 0 };
    const anchor: MarkAnchor = {
      colour: colour.name,
      hex: colour.hex,
      area: Math.round(c.cells.length * sx * sy),
      box: { x: Math.round(c.minX * sx), y: Math.round(c.minY * sy), w: Math.round((c.maxX - c.minX + 1) * sx), h: Math.round((c.maxY - c.minY + 1) * sy) },
      coverage: sampled > 0 ? Math.round((hits.length / sampled) * 100) / 100 : 0,
      hit: null,
      miss: null,
    };
    if (hits.length > 0) {
      const centroid = new THREE.Vector3();
      const normal = new THREE.Vector3();
      const box = new THREE.Box3();
      const parts = new Set<string>();
      for (const hit of hits) {
        centroid.add(hit.point);
        box.expandByPoint(hit.point);
        if (hit.face) normal.add(hit.face.normal.clone().transformDirection(hit.object.matrixWorld));
        const name = partOf(hit.object);
        if (name) parts.add(name);
      }
      centroid.divideScalar(hits.length);
      anchor.hit = {
        point: round(centroid),
        normal: normal.lengthSq() > 1e-9 ? round(normal.normalize()) : null,
        extent: Math.round(box.getSize(new THREE.Vector3()).length() * 1e4) / 1e4,
        parts: [...parts].sort(),
      };
    } else {
      const mx = ((c.minX + c.maxX) / 2 + 0.5) * sx;
      const my = ((c.minY + c.maxY) / 2 + 0.5) * sy;
      aimThroughTexel(caster.ray, cam, mx, my);
      const ground = groundHit(caster.ray);
      anchor.miss = { from: round(caster.ray.origin), along: round(caster.ray.direction), plane: round(texelToWorld(cam, mx, my)), ground: ground ? round(ground) : null };
    }
    anchors.push(anchor);
  }
  // Biggest first: a prompt naming one mark usually means the obvious one.
  return anchors.sort((a, b) => b.area - a.area);
}

/** Each colour a drawing's marks are, with how many marks: the turn names them. */
export function coloursOf(anchors: readonly MarkAnchor[]): { name: string; hex: string; marks: number }[] {
  const out = new Map<string, { name: string; hex: string; marks: number }>();
  for (const a of anchors) {
    const had = out.get(a.hex);
    if (had) had.marks++;
    else out.set(a.hex, { name: a.colour, hex: a.hex, marks: 1 });
  }
  return [...out.values()];
}
