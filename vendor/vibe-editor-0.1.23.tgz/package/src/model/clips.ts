/**
 * The clock of the Model tab's clips (Docs/modeler.md M31; Vibe3D D89):
 * what a clip is in Gladius's words -- its name (the `action{}`'s), its length,
 * its rate and whether it loops, read from the `extras` Gladius writes on each
 * glTF animation -- and the arithmetic of a transport over it: frames at the
 * clip's own rate (the one its keys and locks were baked at), a step that
 * wraps on a loop and stops at the ends of a one-shot, playback that wraps or
 * stops on the last frame, the pose a frame is named by (`fly@0.2`, the
 * spelling `gladius_query`'s `pose` takes).
 *
 * The read itself -- `clipInfo` over the extras -- is the engine's
 * (`@vibe/engine`'s `assets/clip-info.ts`), which its `animate` system reads
 * too; this is the tab's arithmetic over it.
 *
 * Pure: no three, no DOM (`clips.test.ts`).
 */
import type { ClipInfo } from '@vibe/engine';

/** The speeds offered: four fixed steps (D89) -- the preferences' own, which keep the one chosen. */
export { MODEL_SPEEDS as SPEEDS } from '../prefs.ts';

/** A clip as read from its `extras` (Docs/modeler.md M31): the engine's, re-said for the tab's modules. */
export type { ClipInfo } from '@vibe/engine';

/** A pose named by its clip and time: the rest pose is null. */
export interface PoseRef {
  action: string;
  time: number;
}

/** Does it loop: the person's choice for its name, else the file's, else yes. */
export function loops(clip: ClipInfo, chosen: ReadonlyMap<string, boolean>): boolean {
  return chosen.get(clip.name) ?? clip.loop ?? true;
}

/** Its frames: the last frame's number, its length at its rate. */
export const framesOf = (clip: Pick<ClipInfo, 'duration' | 'fps'>): number => Math.max(0, Math.round(clip.duration * clip.fps));

/** The frame a time is on, the nearest. */
export const frameAt = (clip: Pick<ClipInfo, 'fps'>, time: number): number => Math.round(time * clip.fps + 1e-9);

/** A frame's time, within the clip. */
export function timeOfFrame(clip: Pick<ClipInfo, 'duration' | 'fps'>, frame: number): number {
  const last = framesOf(clip);
  const f = Math.min(last, Math.max(0, frame));
  // The last frame is the clip's end, whatever its length's rounding.
  return f === last ? clip.duration : f / clip.fps;
}

/** A time held: on the frame nearest it. */
export const snapToFrame = (clip: Pick<ClipInfo, 'duration' | 'fps'>, time: number): number => timeOfFrame(clip, frameAt(clip, time));

/** One frame on or back at the clip's rate (D89): wrapping on a loop, as playback does; held at the ends of a one-shot. */
export function stepFrame(clip: Pick<ClipInfo, 'duration' | 'fps'>, time: number, by: number, loop: boolean): number {
  const frames = framesOf(clip);
  const frame = frameAt(clip, time) + by;
  const wrapped = loop && frames > 0 ? ((frame % frames) + frames) % frames : frame;
  return timeOfFrame(clip, wrapped);
}

/**
 * Playback moved on by `seconds` of the page's time at `speed`: a loop wraps;
 * a one-shot stops on its last frame, not back at the first -- the end of a
 * fall is a pose worth looking at.
 */
export function advance(clip: Pick<ClipInfo, 'duration'>, time: number, seconds: number, speed: number, loop: boolean): { time: number; playing: boolean } {
  const next = time + Math.max(0, seconds) * speed;
  if (next < clip.duration) return { time: next, playing: true };
  if (loop && clip.duration > 0) return { time: next % clip.duration, playing: true };
  return { time: clip.duration, playing: false };
}

/** A time to three places: what a pose is named by. */
export const round3 = (time: number): number => Number(time.toFixed(3));

/** `fly@0.2`: a pose as `gladius_query`'s `pose` spells it; `rest pose` for none. */
export const poseText = (pose: PoseRef | null): string => (pose ? `${pose.action}@${round3(pose.time)}` : 'rest pose');

/** The same pose: the same clip within a millisecond, or both the rest pose. */
export function samePose(a: PoseRef | null, b: PoseRef | null): boolean {
  if (a === null || b === null) return a === b;
  return a.action === b.action && Math.abs(a.time - b.time) < 1e-3;
}

/** A pose kept as a value (a canvas across a reload), read back: null for the rest pose or anything else. */
export function readPose(value: unknown): PoseRef | null {
  const v = value as Partial<PoseRef> | null;
  if (!v || typeof v.action !== 'string' || v.action === '' || typeof v.time !== 'number' || !Number.isFinite(v.time) || v.time < 0) return null;
  return { action: v.action, time: v.time };
}

/** The frames a timeline marks: every one, or every `n`th where they would crowd under `most`. */
export function ticksOf(clip: Pick<ClipInfo, 'duration' | 'fps'>, most: number): { every: number; frames: number[] } {
  const frames = framesOf(clip);
  const steps = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600];
  const every = steps.find((n) => frames / n <= most) ?? Math.ceil(frames / Math.max(1, most));
  const out: number[] = [];
  for (let f = 0; f <= frames; f += every) out.push(f);
  return { every, frames: out };
}

/** The transport's words: `frame 6 / 15 · 0.200 s` -- three places, so the line keeps its width as it counts. */
export function clockWords(clip: ClipInfo, time: number): string {
  return `frame ${frameAt(clip, time)} / ${framesOf(clip)} · ${time.toFixed(3)} s`;
}

/** A clip's line in the list: `0.50 s · 15 frames at 30 fps · loops` -- what the person chose over what the file says. */
export function clipWords(clip: ClipInfo, loop: boolean): string {
  return `${clip.duration.toFixed(2)} s · ${framesOf(clip)} frames at ${clip.fps} fps · ${loop ? 'loops' : 'once'}`;
}
