/**
 * Lua table constructors found and edited in a script's text (Docs/modeler.md
 * M24; Vibe3D's `luaTable.ts`, D94, D120): what the Materials block writes into
 * a `material{}` call and what Bake writes into `params{}`'s defaults.
 *
 * - **A scanner, not a parser.** It knows what it must to find a table and its
 *   top-level entries without being fooled: strings (both quotes, escapes),
 *   long brackets (`[[ ]]`, `[==[ ]==]`), comments (`--`, `--[[ ]]`) and
 *   nesting (`{}`, `()`, `[]`). Anything computed is left alone, never guessed
 *   at: a value replaced is replaced whole, as the source text it was.
 * - **Fields and entries at depth 1**: `key = value`, `["odd:key"] = value`,
 *   and positional entries -- a nested table is one value, never a source of
 *   stray keys.
 * - **Edits as offsets** (`Edit`: `[from, to)` and the text there), applied
 *   last first (`applyEdits`), so one pass makes several. An edit keeps the
 *   author's layout: a field added to a table of a field a line goes on a line
 *   of its own, indented as the last; one added to a one-line table goes on
 *   that line; `key=value` or `key = value` as the last field is written. A
 *   field taken out alone on its line takes the line; one sharing it takes its
 *   comma, or the comma before it when it is last.
 *
 * Pure (`lua-table.test.ts`): no DOM, no three.
 */

/** One `key = value` at depth 1: offsets into the text, `valueEnd` exclusive and trimmed. */
export interface Field {
  key: string;
  keyStart: number;
  valueStart: number;
  valueEnd: number;
  /** Just past the `,` or `;` that ends it, or `valueEnd` when there is none. */
  sepEnd: number;
}

/** One positional entry at depth 1 -- a list's element. */
export interface Entry {
  start: number;
  end: number;
  sepEnd: number;
}

export interface LuaTable {
  /** The offset of its `{`. */
  open: number;
  /** The offset of its `}`. */
  close: number;
  fields: Field[];
  entries: Entry[];
}

/** Text from `from` to `to` (exclusive) made `text`. */
export interface Edit {
  from: number;
  to: number;
  text: string;
}

/** Strings and comments, as `[start, end)`, so a scan steps over them. */
export function skippedRanges(text: string): Array<[number, number]> {
  const ranges: Array<[number, number]> = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]!;
    if (ch === '-' && text[i + 1] === '-') {
      const long = /^\[(=*)\[/.exec(text.slice(i + 2, i + 64));
      const end = long ? text.indexOf(`]${long[1]}]`, i + 2 + long[0].length) : text.indexOf('\n', i);
      const stop = end < 0 ? text.length : long ? end + long[1]!.length + 2 : end;
      ranges.push([i, stop]);
      i = stop - 1;
    } else if (ch === '"' || ch === "'") {
      let j = i + 1;
      while (j < text.length && text[j] !== ch && text[j] !== '\n') j += text[j] === '\\' ? 2 : 1;
      ranges.push([i, Math.min(j + 1, text.length)]);
      i = j;
    } else if (ch === '[') {
      const long = /^\[(=*)\[/.exec(text.slice(i, i + 64));
      if (long) {
        const end = text.indexOf(`]${long[1]}]`, i + long[0].length);
        const stop = end < 0 ? text.length : end + long[1]!.length + 2;
        ranges.push([i, stop]);
        i = stop - 1;
      }
    }
  }
  return ranges;
}

/** The skipped range `offset` is in, if any: the ranges are in order, so a binary search. */
export function rangeAt(ranges: ReadonlyArray<readonly [number, number]>, offset: number): readonly [number, number] | undefined {
  let lo = 0;
  let hi = ranges.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const r = ranges[mid]!;
    if (offset < r[0]) hi = mid - 1;
    else if (offset >= r[1]) lo = mid + 1;
    else return r;
  }
  return undefined;
}

const SPACE = /\s/;

export function skipSpace(text: string, i: number): number {
  while (i < text.length && SPACE.test(text[i]!)) i++;
  return i;
}

/** The string a value is, when it is a plain string literal. */
export function stringLiteral(source: string): string | undefined {
  const m = /^(["'])((?:\\.|(?!\1).)*)\1$/.exec(source.trim());
  return m ? m[2]!.replace(/\\(.)/g, '$1') : undefined;
}

/** The number a value is, when it is a plain number literal, not an expression. */
export function numberLiteral(source: string): number | undefined {
  const text = source.trim();
  if (!/^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/.test(text)) return undefined;
  const value = Number(text);
  return Number.isFinite(value) ? value : undefined;
}

/** The boolean a value is, when it is `true` or `false`. */
export function booleanLiteral(source: string): boolean | undefined {
  const text = source.trim();
  return text === 'true' ? true : text === 'false' ? false : undefined;
}

/** `v3(a, b, c)` of three number literals, as numbers. */
export function v3Literal(source: string): [number, number, number] | undefined {
  const m = /^v3\s*\(\s*([^,()]+),\s*([^,()]+),\s*([^,()]+)\)$/.exec(source.trim());
  if (!m) return undefined;
  const xyz = [m[1]!, m[2]!, m[3]!].map(numberLiteral);
  return xyz.every((n) => n !== undefined) ? (xyz as [number, number, number]) : undefined;
}

/** True when `[start, stop)` holds nothing but space and comments -- a trailing `-- note` before `}`. */
function onlySkipped(text: string, start: number, stop: number, skip: ReadonlyArray<readonly [number, number]>): boolean {
  for (let i = start; i < stop; i++) {
    if (SPACE.test(text[i]!)) continue;
    const range = rangeAt(skip, i);
    if (!range || text[range[0]] !== '-') return false;
    i = range[1] - 1;
  }
  return true;
}

/** The table opening at `open` (its `{`), read to its matching close; undefined if it never closes. */
export function readTable(text: string, open: number, skip: ReadonlyArray<readonly [number, number]>): LuaTable | undefined {
  const fields: Field[] = [];
  const entries: Entry[] = [];
  let depth = 0;
  let entryStart = open + 1;
  let pending: { key: string; keyStart: number; valueStart: number } | undefined;

  /** One entry ends at `end`: with a separator of its own, or (`separator` false) at the closing brace. */
  const closeEntry = (end: number, separator: boolean): void => {
    if (pending) {
      let valueEnd = end;
      while (valueEnd > pending.valueStart && SPACE.test(text[valueEnd - 1]!)) valueEnd--;
      // A trailing comment before the brace is no part of the value.
      while (valueEnd > pending.valueStart) {
        let cut = false;
        for (let j = pending.valueStart; j < valueEnd; j++) {
          const r = rangeAt(skip, j);
          if (r && text[r[0]] === '-' && r[1] >= valueEnd) {
            valueEnd = j;
            cut = true;
            break;
          }
          if (r) j = r[1] - 1;
        }
        if (!cut) break;
        while (valueEnd > pending.valueStart && SPACE.test(text[valueEnd - 1]!)) valueEnd--;
      }
      fields.push({ ...pending, valueEnd, sepEnd: separator ? end + 1 : valueEnd });
      pending = undefined;
      return;
    }
    const start = skipSpace(text, entryStart);
    let stop = end;
    while (stop > start && SPACE.test(text[stop - 1]!)) stop--;
    if (stop > start && !onlySkipped(text, start, stop, skip)) entries.push({ start, end: stop, sepEnd: separator ? end + 1 : stop });
  };

  for (let i = open; i < text.length; i++) {
    const range = rangeAt(skip, i);
    if (range) {
      i = range[1] - 1;
      continue;
    }
    const ch = text[i]!;
    if (ch === '{' || ch === '(' || ch === '[') {
      depth++;
      if (depth === 1) entryStart = i + 1;
      continue;
    }
    if (ch === '}' || ch === ')' || ch === ']') {
      depth--;
      if (depth === 0) {
        closeEntry(i, false);
        return { open, close: i, fields, entries };
      }
      continue;
    }
    if (depth !== 1) continue;
    if (ch === ',' || ch === ';') {
      closeEntry(i, true);
      entryStart = i + 1;
      continue;
    }
    if (!pending && ch === '=' && text[i + 1] !== '=' && !'=~<>'.includes(text[i - 1] ?? '')) {
      // The key is what sits just before `=`, with nothing but space and comments since the last separator.
      const before = text.slice(entryStart, i);
      const ident = /([A-Za-z_]\w*)\s*$/.exec(before);
      const bracket = ident ? null : /\[\s*(["'])((?:\\.|(?!\1).)*)\1\s*\]\s*$/.exec(before);
      const match = ident ?? bracket;
      if (match) {
        const key = ident ? ident[1]! : bracket![2]!.replace(/\\(.)/g, '$1');
        const keyStart = i - match[0].length;
        if (onlySkipped(text, entryStart, keyStart, skip)) pending = { key, keyStart, valueStart: skipSpace(text, i + 1) };
      }
    }
  }
  return undefined;
}

/**
 * Every call of `name` whose table can be read -- `name{ … }` or `name({ … })`
 * -- in the order written. A field access (`m.material`, `lib:material`) is
 * not the call, and neither is the word in a string or a comment.
 */
export function findCalls(text: string, name: string, skip: ReadonlyArray<readonly [number, number]> = skippedRanges(text)): LuaTable[] {
  const found: LuaTable[] = [];
  const word = new RegExp(`\\b${name}\\b`, 'g');
  let match: RegExpExecArray | null;
  while ((match = word.exec(text))) {
    const start = match.index;
    if (rangeAt(skip, start)) continue;
    let back = start - 1;
    while (back >= 0 && SPACE.test(text[back]!)) back--;
    if (text[back] === '.' || text[back] === ':') continue;
    let i = skipSpace(text, start + match[0].length);
    if (text[i] === '(') i = skipSpace(text, i + 1);
    if (text[i] !== '{') continue;
    const table = readTable(text, i, skip);
    if (table) found.push(table);
  }
  return found;
}

/** The table a field's value is, when that value is a literal `{ … }`. */
export function fieldTable(text: string, field: Field, skip: ReadonlyArray<readonly [number, number]>): LuaTable | undefined {
  return text[field.valueStart] === '{' ? readTable(text, field.valueStart, skip) : undefined;
}

/** `text` with `edits` made, last first, so each offset is the original text's. Overlapping edits are refused. */
export function applyEdits(text: string, edits: readonly Edit[]): string {
  const sorted = [...edits].sort((a, b) => b.from - a.from || b.to - a.to);
  let out = text;
  let floor = Infinity;
  for (const e of sorted) {
    if (e.to > floor) throw new Error('lua-table: two edits overlap');
    out = out.slice(0, e.from) + e.text + out.slice(e.to);
    floor = e.from;
  }
  return out;
}

const lineStartOf = (text: string, at: number): number => text.lastIndexOf('\n', at - 1) + 1;
const lineEndOf = (text: string, at: number): number => {
  const n = text.indexOf('\n', at);
  return n < 0 ? text.length : n;
};

/** A field's value replaced whole -- `base_color = tint` becomes the literal given. */
export function replaceValue(field: Field, literal: string): Edit {
  return { from: field.valueStart, to: field.valueEnd, text: literal };
}

/**
 * A field taken out: alone on its line, the whole line (a comment after it
 * too); sharing it, its separator with it, or the one before it when it has
 * none (the last).
 */
export function removal(text: string, table: LuaTable, field: Field): Edit {
  const lineStart = lineStartOf(text, field.keyStart);
  const lineEnd = lineEndOf(text, field.sepEnd);
  const rest = text.slice(field.sepEnd, lineEnd);
  const alone = /^\s*$/.test(text.slice(lineStart, field.keyStart)) && /^\s*(--.*)?$/.test(rest);
  if (alone && lineEnd < text.length) return { from: lineStart, to: lineEnd + 1, text: '' };
  if (field.sepEnd > field.valueEnd) {
    let start = field.keyStart;
    let stop = field.sepEnd;
    while (text[stop] === ' ') stop++;
    if (stop >= text.length || text[stop] === '\n' || text[stop] === '\r') while (start > lineStart && text[start - 1] === ' ') start--;
    return { from: start, to: stop, text: '' };
  }
  const index = table.fields.indexOf(field);
  const previous = index > 0 ? table.fields[index - 1] : undefined;
  return { from: previous ? previous.valueEnd : field.keyStart, to: field.sepEnd, text: '' };
}

/** Is `key = value` written with spaces round its `=` in this table? Its last field says; else yes. */
function spacedIn(text: string, kept: readonly Field[]): boolean {
  const last = kept[kept.length - 1];
  if (!last) return true;
  return /\s=|=\s/.test(text.slice(last.keyStart, last.valueStart));
}

/** `key = value`, spaced as the table's fields are. */
export function fieldText(text: string, kept: readonly Field[], key: string, literal: string): string {
  return spacedIn(text, kept) ? `${key} = ${literal}` : `${key}=${literal}`;
}

/**
 * Fields added to a table that may have some (`kept`: those still there after
 * any removal), laid out as it is: a field a line, a new line indented as the
 * last; one line, on it; none, inside its braces.
 */
export function additions(text: string, table: LuaTable, kept: readonly Field[], added: readonly string[]): Edit[] {
  if (added.length === 0) return [];
  const last = kept[kept.length - 1];
  if (!last) {
    const inside = text.slice(table.open + 1, table.close);
    return [{ from: table.open + 1, to: table.close, text: /\n/.test(inside) ? `\n  ${added.join(',\n  ')},\n` : ` ${added.join(', ')} ` }];
  }
  const multiLine = text.slice(table.open, table.close).includes('\n') && lineStartOf(text, last.keyStart) !== lineStartOf(text, table.open);
  if (multiLine) {
    const lead = last.sepEnd === last.valueEnd ? ',' : '';
    const indent = /^[ \t]*/.exec(text.slice(lineStartOf(text, last.keyStart)))![0];
    const lines = added.map((a) => `\n${indent}${a},`).join('');
    const end = lineEndOf(text, last.sepEnd);
    // The close on the last field's line (`  a = 1 }`): the new ones before it, the brace on a line of its own.
    if (table.close < end) return [{ from: last.sepEnd, to: last.sepEnd, text: `${lead}${lines}\n${/^[ \t]*/.exec(text.slice(lineStartOf(text, table.open)))![0]}` }];
    if (!lead || last.valueEnd === end) return [{ from: end, to: end, text: `${lead}${lines}` }];
    // A comment after the last field: its comma after its value, the new lines after the comment.
    return [{ from: last.valueEnd, to: last.valueEnd, text: lead }, { from: end, to: end, text: lines }];
  }
  if (last.sepEnd > last.valueEnd) return [{ from: last.sepEnd, to: last.sepEnd, text: ` ${added.join(', ')},` }];
  return [{ from: last.valueEnd, to: last.valueEnd, text: `, ${added.join(', ')}` }];
}

/** A Lua string literal: double-quoted, its backslashes, quotes and line breaks escaped. */
export function quoted(value: string): string {
  return `"${value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n')}"`;
}

/** A number as a script writes it: four places at most, no trailing zeros -- `0.35`, `1`, `-0.0125`. */
export function luaNumber(value: number): string {
  const n = Number(value.toFixed(4));
  return String(Object.is(n, -0) ? 0 : n);
}
