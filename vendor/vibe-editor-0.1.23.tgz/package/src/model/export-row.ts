/**
 * The model card's export row (Docs/modeler.md M41, M42, review round 1): the
 * export choices a modeller reaches for while looking at the model -- hidden
 * surfaces (`cull`), `clean`, `merge` -- on the card itself, each change one
 * step of the tab's undo written into the record as the Options block writes it
 * (`editing.editRecord`, `PUT sidecar`); **All options…** for the rest, the
 * Assets inspector's Options block scrolled to and lit.
 *
 * The values shown are the export's -- the recipe's defaults, the folders'
 * `export.json`s, the record's own (`resolveOptions`) -- read through `GET file`
 * (`readExportOptions`), as the model opens and after each build.
 */
import type { OptionValue, Options } from '@vibe/pipeline/assets-types';
import { folderChain, folderRecordPath, recordPath } from '@vibe/pipeline/paths';
import { isFound, recipeFor, resolveOptions, type Schemas } from '@vibe/pipeline/recipes';
import { button, el } from '../dom.ts';

/** The options on the row, in its order. */
export const ROW_OPTIONS = ['cull', 'clean', 'merge'] as const;

/** A script's export options as they apply: the resolved values, the schemas, and what its record sets itself. */
export interface ExportOptions {
  values: Options;
  own: Options;
  schemas: Schemas;
}

/** The options of `script`, read: `read(path)` is a file's text, or null where there is none. */
export async function readExportOptions(script: string, read: (path: string) => Promise<string | null>): Promise<ExportOptions | null> {
  const found = recipeFor(script);
  if (!isFound(found) || found.ext !== 'lua') return null;
  const parse = (text: string | null): Record<string, unknown> | undefined => {
    if (text === null) return undefined;
    try {
      const json = JSON.parse(text) as { options?: Record<string, unknown> };
      return json.options;
    } catch {
      return undefined;
    }
  };
  const layers = await Promise.all(folderChain(script).map((dir) => read(folderRecordPath(dir)).then(parse)));
  const own = parse(await read(recordPath(script))) ?? {};
  return { values: resolveOptions(found.row, [...layers, own]).options, own: own as Options, schemas: found.row.options ?? {} };
}

export interface ExportRowHost {
  /** May this page write, and the script be changed now: why not, or null. */
  blocked(): string | null;
  /** One option set, one step of the tab's undo. */
  set(name: string, value: OptionValue): void;
  /** The Options block, whole, in the Assets inspector. */
  all(): void;
}

export interface ExportRow {
  readonly root: HTMLElement;
  draw(options: ExportOptions | null): void;
}

export function createExportRow(host: ExportRowHost): ExportRow {
  const root = el('div', 'ed-mo-export');
  const label = el('span', 'ed-mo-export-label', 'Export');
  const cull = el('select', 'ed-input ed-mo-export-cull');
  const cleanBox = el('input');
  cleanBox.type = 'checkbox';
  const clean = el('label', 'ed-tick ed-mo-export-clean');
  clean.append(cleanBox, el('span', undefined, 'clean'));
  const merge = el('select', 'ed-input ed-mo-export-merge');
  const all = button('ui', 'All options…', 'Every export option -- Draco, textures, animation reduction, the cull knobs -- in the Assets panel\'s inspector, its Options block lit', () => host.all(), 'ed-small ed-quiet');
  root.append(label, cull, clean, merge, all);
  cull.addEventListener('change', () => host.set('cull', cull.value));
  merge.addEventListener('change', () => host.set('merge', merge.value));
  cleanBox.addEventListener('change', () => host.set('clean', cleanBox.checked));

  const fill = (select: HTMLSelectElement, values: readonly string[], words: (v: string) => string): void => {
    if (select.options.length === values.length) return;
    select.replaceChildren(...values.map((v) => {
      const o = el('option', undefined, words(v));
      o.value = v;
      return o;
    }));
  };

  return {
    root,
    draw(options) {
      root.hidden = options === null;
      if (!options) return;
      const { values, schemas } = options;
      fill(cull, schemas.cull?.values ?? [], (v) => (v === 'none' ? 'no cull' : `cull ${v}`));
      fill(merge, schemas.merge?.values ?? [], (v) => (v === 'none' ? 'no merge' : `merge ${v}`));
      cull.value = String(values.cull ?? 'none');
      merge.value = String(values.merge ?? 'none');
      cleanBox.checked = values.clean === true;
      const why = host.blocked();
      for (const c of [cull, merge, cleanBox]) c.disabled = why !== null;
      cull.title = `${why ? `${why}\n` : ''}${schemas.cull?.help ?? ''}`;
      merge.title = `${why ? `${why}\n` : ''}${schemas.merge?.help ?? ''}`;
      clean.title = `${why ? `${why}\n` : ''}${schemas.clean?.help ?? ''}`;
    },
  };
}
