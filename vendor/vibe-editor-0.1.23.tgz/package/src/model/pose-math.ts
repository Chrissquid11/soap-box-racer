/**
 * A bone's pose in Gladius's words (Docs/modeler.md M33; Vibe3D D121): what a
 * bone turned in the views comes to as a key's fields, and the fields typed
 * back into a turn of the bone -- the one part of posing that is a claim about
 * another program's conventions, so kept apart and tested against numbers
 * Gladius wrote.
 *
 * **Measured against Gladius 0.7.3, and again on 0.8.0** (the parrot and test actions built with
 * `gladius run`, the GLB's channels read back -- M33): a key is relative to
 * the joint's **rest**, and its swing and twist are about axes of the **model**
 * at rest, not of the glTF node's frame -- Vibe3D's local-frame reading (D121)
 * held only for bones whose frames were the model's:
 *
 *     d  = the bone's direction at rest (its +Y in the model)
 *     δ  = W · (rest⁻¹ · local) · W⁻¹       the turn in model axes (W: its rest rotation in the model)
 *     δ  = R(d × Z, forward) · R(d × X, left) · R(d, twist)
 *
 * -- `forward` swings the tail toward +Z, `left` toward +X, `twist` about its
 * length, in that order (the one that fits, to a hundredth of a degree, of
 * the six). `orient` is the turn in the **node's own** frame as an axis times
 * degrees; `rotate` is δ as degrees about model X, then Y, then Z; `translate`
 * is model metres, through the parent's rest rotation.
 *
 * Three's math alone, no renderer, no DOM (`pose-math.test.ts`).
 */
import * as THREE from 'three';

const DEG = 180 / Math.PI;
const X = new THREE.Vector3(1, 0, 0);
const Z = new THREE.Vector3(0, 0, 1);

/** How near a swing's world axis a bone may point before Gladius refuses that swing (GLD-6050). */
const DEGENERATE = Math.cos((12 * Math.PI) / 180);

/** A bone as the script builds it, before any clip: what every field of a key is measured from. */
export interface Rest {
  /** Its local transform at rest. */
  quaternion: THREE.Quaternion;
  position: THREE.Vector3;
  /** Its rotation in the model at rest (W), and its parent's: the axes keys are in. */
  world: THREE.Quaternion;
  parentWorld: THREE.Quaternion;
}

/** A pose's numbers, every spelling: what the fields show and what the writer chooses from. */
export interface PoseNumbers {
  forward: number;
  left: number;
  twist: number;
  orient: [number, number, number];
  rotate: [number, number, number];
  translate: [number, number, number];
  /** Swing axes this bone points along: `forward` or `left` there is refused, so it is written as `orient`. */
  degenerate: ('forward' | 'left')[];
}

const round = (value: number, places = 3): number => {
  const n = Number(value.toFixed(places));
  return Object.is(n, -0) ? 0 : n;
};

/** The bone's direction at rest, in the model. */
const directionOf = (rest: Pick<Rest, 'world'>): THREE.Vector3 => new THREE.Vector3(0, 1, 0).applyQuaternion(rest.world).normalize();

/**
 * The swing and twist axes: `forward` about d × Z, `left` about d × X, twist
 * about d. Where a swing has no axis (the bone points along it) a stand-in
 * perpendicular to d, so the numbers still say a turn -- the writer uses
 * `orient` there.
 */
function axesOf(rest: Pick<Rest, 'world'>): { d: THREE.Vector3; forward: THREE.Vector3; left: THREE.Vector3 } {
  const d = directionOf(rest);
  const forward = d.clone().cross(Z);
  const left = d.clone().cross(X);
  if (forward.lengthSq() < 1e-8) forward.copy(left.lengthSq() > 1e-8 ? left.clone().cross(d) : new THREE.Vector3(1, 0, 0));
  if (left.lengthSq() < 1e-8) left.copy(d.clone().cross(forward));
  return { d, forward: forward.normalize(), left: left.normalize() };
}

const turn = (axis: THREE.Vector3, deg: number): THREE.Quaternion => new THREE.Quaternion().setFromAxisAngle(axis, deg / DEG);

/** The turn `forward`, `left`, `twist` make, in model axes. */
export function swingTwist(rest: Pick<Rest, 'world'>, forward: number, left: number, twist: number): THREE.Quaternion {
  const a = axesOf(rest);
  return turn(a.forward, forward).multiply(turn(a.left, left)).multiply(turn(a.d, twist));
}

/** A turn in model axes as `forward`, `left`, `twist`: Euler XYZ in the frame of the three axes. */
function readSwingTwist(rest: Pick<Rest, 'world'>, delta: THREE.Quaternion): [number, number, number] {
  const a = axesOf(rest);
  const c1 = a.forward;
  const c2 = a.left.clone().addScaledVector(c1, -a.left.dot(c1)).normalize();
  const c3 = c1.clone().cross(c2);
  // The frame is left-handed where the bone points down: the twist is about −c3 there.
  const sign = c3.dot(a.d) < 0 ? -1 : 1;
  const basis = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(c1, c2, c3));
  const inFrame = basis.clone().invert().multiply(delta).multiply(basis);
  const e = new THREE.Euler().setFromQuaternion(inFrame, 'XYZ');
  // Every turn has two such triples; the middle one is kept within ±90° by three. A wing raised past level (left 125)
  // reads as the other, (180, 55, 180): the smaller in all is the one a person writes.
  const wrap = (deg: number): number => ((((deg + 180) % 360) + 360) % 360) - 180;
  const one: [number, number, number] = [e.x * DEG, e.y * DEG, sign * e.z * DEG];
  const two: [number, number, number] = [wrap(one[0] + 180), wrap(180 - one[1]), wrap(one[2] + 180)];
  const size = (v: readonly number[]): number => Math.abs(v[0]!) + Math.abs(v[1]!) + Math.abs(v[2]!);
  return refine(rest, delta, size(two) + 1e-6 < size(one) ? two : one);
}

/**
 * The triple made exact where the two swing axes are not quite square (a bone
 * leaning in both X and Z): a few Gauss-Newton steps on the turn itself, from
 * the frame's answer.
 */
function refine(rest: Pick<Rest, 'world'>, target: THREE.Quaternion, start: [number, number, number]): [number, number, number] {
  const x = [...start] as [number, number, number];
  const goal = target.clone();
  const residual = (v: readonly number[]): number[] => {
    const q = swingTwist(rest, v[0]!, v[1]!, v[2]!);
    if (q.dot(goal) < 0) q.set(-q.x, -q.y, -q.z, -q.w);
    return [q.x - goal.x, q.y - goal.y, q.z - goal.z, q.w - goal.w];
  };
  for (let step = 0; step < 6; step++) {
    const r = residual(x);
    if (Math.hypot(...r) < 1e-10) break;
    const h = 1e-3;
    const J = [0, 1, 2].map((i) => {
      const moved = [...x];
      moved[i]! += h;
      return residual(moved).map((v, k) => (v - r[k]!) / h);
    });
    // (Jᵀ J) dx = −Jᵀ r, three by three.
    const A = [0, 1, 2].map((i) => [0, 1, 2].map((j) => J[i]!.reduce((sum, v, k) => sum + v * J[j]![k]!, 0)));
    const b = [0, 1, 2].map((i) => -J[i]!.reduce((sum, v, k) => sum + v * r[k]!, 0));
    const dx = solve3(A, b);
    if (!dx) break;
    for (let i = 0; i < 3; i++) x[i]! += dx[i]!;
  }
  return x;
}

/** A 3×3 system by Cramer's rule; null where it is singular. */
function solve3(a: number[][], b: number[]): number[] | null {
  const det = (m: number[][]): number => m[0]![0]! * (m[1]![1]! * m[2]![2]! - m[1]![2]! * m[2]![1]!) - m[0]![1]! * (m[1]![0]! * m[2]![2]! - m[1]![2]! * m[2]![0]!) + m[0]![2]! * (m[1]![0]! * m[2]![1]! - m[1]![1]! * m[2]![0]!);
  const d = det(a);
  if (Math.abs(d) < 1e-14) return null;
  return [0, 1, 2].map((c) => det(a.map((row, i) => row.map((v, j) => (j === c ? b[i]! : v)))) / d);
}

/** A bone at `quaternion` and `position` (its local transform) as a key's fields, relative to its rest. */
export function describe(rest: Rest, quaternion: THREE.Quaternion, position: THREE.Vector3): PoseNumbers {
  const local = rest.quaternion.clone().invert().multiply(quaternion);
  const model = rest.world.clone().multiply(local).multiply(rest.world.clone().invert());
  const [forward, left, twist] = readSwingTwist(rest, model);
  // `orient`: the turn in the node's own frame, an axis times its degrees.
  const w = Math.min(1, Math.abs(local.w));
  const angle = 2 * Math.acos(w);
  const sin = Math.sqrt(Math.max(1e-12, 1 - local.w * local.w));
  const scale = angle < 1e-9 ? 0 : (angle * DEG * (local.w < 0 ? -1 : 1)) / sin;
  // `rotate`: degrees about model X, then Y, then Z -- three's ZYX is Rz·Ry·Rx.
  const e = new THREE.Euler().setFromQuaternion(model, 'ZYX');
  // `translate`: model metres, through the parent's rest rotation.
  const offset = position.clone().sub(rest.position).applyQuaternion(rest.parentWorld);
  return {
    forward: round(forward),
    left: round(left),
    twist: round(twist),
    orient: [round(local.x * scale), round(local.y * scale), round(local.z * scale)],
    rotate: [round(e.x * DEG), round(e.y * DEG), round(e.z * DEG)],
    translate: [round(offset.x, 5), round(offset.y, 5), round(offset.z, 5)],
    degenerate: degenerateAxes(rest),
  };
}

/** Typed fields back into the bone's local transform: degrees and metres in, the turn and the move out. */
export function fromNumbers(rest: Rest, values: { forward: number; left: number; twist: number; translate: readonly [number, number, number] }): { quaternion: THREE.Quaternion; position: THREE.Vector3 } {
  const model = swingTwist(rest, values.forward, values.left, values.twist);
  const local = rest.world.clone().invert().multiply(model).multiply(rest.world);
  const offset = new THREE.Vector3(...values.translate).applyQuaternion(rest.parentWorld.clone().invert());
  return { quaternion: rest.quaternion.clone().multiply(local), position: rest.position.clone().add(offset) };
}

/** The swings this bone has no room for: it points along their world axis (forward Z, left X). */
export function degenerateAxes(rest: Pick<Rest, 'world'>): ('forward' | 'left')[] {
  const d = directionOf(rest);
  const out: ('forward' | 'left')[] = [];
  if (Math.abs(d.z) > DEGENERATE) out.push('forward');
  if (Math.abs(d.x) > DEGENERATE) out.push('left');
  return out;
}

/**
 * What the script should call a joint (D121, D122): the file's own name (three
 * makes `mixamorig:RightArm` into `mixamorigRightArm`; the loader keeps the
 * original), then its short form after a rig's prefix where no other joint in
 * the file ends the same -- Gladius resolves by suffix and refuses an ambiguous
 * one (GLD-6003) -- and a script that writes `LeftArm` should not come back
 * from a drag with `["mixamorig:LeftArm"]` beside it.
 */
export function jointName(full: string, every: readonly string[]): string {
  const tail = full.slice(full.lastIndexOf(':') + 1);
  if (tail === full || !/^[A-Za-z_]\w*$/.test(tail)) return full;
  const seen = every.filter((name) => name.slice(name.lastIndexOf(':') + 1) === tail).length;
  return seen === 1 ? tail : full;
}
