/**
 * The Parameters block in the Model tab's right panel (Docs/modeler.md §4,
 * M22; Vibe3D D45, D47, D58, D67): a row per `params{}` entry -- a slider and
 * a number for a bounded number, a list for choices, a tick for a boolean, a
 * swatch and its text for a colour, a line for any other string -- its name
 * amber while an override changes it, its default and range on hover, ↺ to
 * take the record's override away; Reset all and **Bake into script** at the
 * block's head.
 *
 * - **Dragging previews, letting go commits** (D47): a slider's `input`, a
 *   scrub, a typed number ask for a preview build (`preview`); its `change`,
 *   the end of a scrub, Enter or leaving the field commit once (`commit`) --
 *   the record's `params`, one step of the tab's undo, the export once. A
 *   list, a tick and a colour picked preview and commit at once (D67).
 * - **Rows are reconciled, never made again under a gesture** (D58): a row
 *   whose shape (`shapeOf`) is the same has its value written in place, and
 *   not even that while it is being dragged or typed in; only a parameter
 *   added, taken away or given new bounds makes rows anew.
 * - **Every state says itself**: reading; Gladius missing; this Gladius too
 *   old; the script not getting as far as `params{}`; none declared (with the
 *   line that declares one); an override refused (its words, the rows kept,
 *   ↺ there to take it back); a preview building, or failed (its line, the
 *   last good preview kept).
 */
import type { ParamsAnswer, ParamSpec } from '@vibe/pipeline/assets-types';
import { button, control, el, iconButton } from '../dom.ts';
import { numberField, textInput, type NumberField } from '../fields.ts';
import { digitsOf, isLog, LOG_STEPS, logPosition, logValue, normaliseHex, overrideText, rowsOf, sayValue, shapeOf, stepOf, type ParamRow } from './params.ts';

export interface ParamPanelHost {
  /** A value being moved: built as a preview, nothing written. */
  preview(name: string, text: string): void;
  /** A value let go of: written to the record (or, undefined, the record's own override taken away). */
  commit(spec: ParamSpec, text: string | undefined): void;
  /** Every override of the record's own taken away. */
  resetAll(): void;
  /** The values as they are written into params{}'s defaults; the overrides cleared. */
  bake(): void;
  /** The block folded or unfolded: kept. */
  folded(folded: boolean): void;
}

/** What the block shows. */
export interface ParamView {
  answer: ParamsAnswer | null;
  /** Reading it just now. */
  reading: boolean;
  /** May this page write: the controls are read-only where not. */
  writes: boolean;
  /** Why not, when it may not, said on the block's line. */
  readOnly?: string | null;
  /** A preview is being built. */
  building: boolean;
  /** The last preview's failure, its line; null once one builds. */
  previewError: string | null;
  /** The tab's undo is busy writing: Bake and Reset wait. */
  busy: boolean;
}

interface Row {
  shape: string;
  root: HTMLElement;
  name: HTMLElement;
  note: HTMLElement;
  reset: HTMLButtonElement;
  /** Writes the value in place -- unless the person has it in hand. */
  show(row: ParamRow): void;
  /** Is it being dragged or typed in? */
  held(): boolean;
}

export interface ParamPanel {
  readonly root: HTMLElement;
  draw(view: ParamView): void;
  setFolded(folded: boolean): void;
}

/** A spec's tooltip: its doc, its default, its range or choices, its line. */
function tipOf(spec: ParamSpec): string {
  const parts = [spec.doc ?? spec.name, `Default ${sayValue(spec.default)}`];
  if (spec.min !== undefined || spec.max !== undefined) parts.push(`Range ${spec.min ?? '−∞'} to ${spec.max ?? '∞'}`);
  if (spec.choices) parts.push(`One of ${spec.choices.join(', ')}`);
  if (spec.line !== undefined) parts.push(`params{} line ${spec.line}`);
  return parts.join('\n');
}

export function createParamPanel(host: ParamPanelHost): ParamPanel {
  const root = el('section', 'ed-mo-sec');
  const head = el('div', 'ed-mo-sec-head');
  const caret = control('ui', 'ed-mo-sec-caret');
  const title = el('span', 'ed-mo-sec-title', 'Parameters');
  const count = el('span', 'ed-mo-sec-count');
  const ends = el('span', 'ed-mo-sec-ends');
  const resetAll = button('model_params_set', 'Reset', 'Every override the record sets taken away: the script\'s defaults again (one step: Z takes it back)', () => host.resetAll(), 'ed-small ed-quiet');
  const bake = button('model_params_set', 'Bake', 'The values shown written into params{} as its defaults, the overrides cleared: the script alone builds this (one step: Z takes it back)', () => host.bake(), 'ed-small ed-accent');
  ends.append(resetAll, bake);
  head.append(caret, title, count, ends);
  const status = el('div', 'ed-mo-sec-status');
  const rowsEl = el('div', 'ed-mo-params');
  const body = el('div', 'ed-mo-sec-body');
  // The line under the rows: what it says may grow and shrink without moving a row under the pointer.
  body.append(rowsEl, status);
  root.append(head, body);

  let folded = false;
  const fold = (next: boolean): void => {
    folded = next;
    root.classList.toggle('ed-mo-shut', folded);
    caret.textContent = folded ? '▸' : '▾';
    caret.title = folded ? 'Show the parameters' : 'Fold the parameters away';
  };
  fold(false);
  const toggle = (): void => {
    fold(!folded);
    host.folded(folded);
  };
  caret.addEventListener('click', toggle);
  // mcp: ui -- the section folded
  title.addEventListener('click', toggle);

  const rows = new Map<string, Row>();
  let writes = true;

  /** One row, made for its shape: its widget, wired to preview and commit. */
  function makeRow(first: ParamRow): Row {
    const spec = (): ParamSpec => current.get(first.spec.name)?.spec ?? first.spec;
    // One line: its name | its control | ↺ -- as Vibe3D's panel and the Materials grid (the note is the name's hover).
    const rowEl = el('div', 'ed-mo-param');
    let name = el('span', 'ed-mo-param-name', first.spec.name);
    const note = el('span', 'ed-mo-param-note');
    const ctl = el('span', 'ed-mo-param-ctl');
    const reset = iconButton('model_params_set', 'undo', 'Take the record\'s override away: the script\'s default again', () => commit(undefined));
    reset.classList.add('ed-mo-param-reset');
    rowEl.append(name, ctl, reset);
    let held = false;
    let show: (row: ParamRow) => void = () => {};
    /**
     * The answer a value was let go against: until a newer answer comes -- the
     * one read after the commit -- the row keeps what the person set, not the
     * value from before it (D58: nothing written under a gesture's result).
     */
    let pinned: ParamSpec | null = null;
    const commit = (text: string | undefined): void => {
      pinned = spec();
      host.commit(spec(), text);
    };

    switch (first.widget) {
      case 'slider':
      case 'number': {
        const s = first.spec;
        const step = stepOf(s);
        const digits = digitsOf(s);
        let last = Number(s.value);
        const field: NumberField = numberField({
          // The row's name is the number's scrub label: drag it to scrub, click it to type, as every number in the editor.
          label: s.name,
          labelClass: 'ed-mo-param-name',
          value: typeof s.value === 'number' ? s.value : undefined,
          step,
          integer: s.type === 'integer',
          ...(s.min !== undefined ? { min: s.min } : {}),
          ...(s.max !== undefined ? { max: s.max } : {}),
          digits,
          title: tipOf(s),
          set(value) {
            last = value;
            if (slider) slider.value = toSlider(value);
            host.preview(s.name, overrideText(spec(), value));
          },
          commit() {
            commit(overrideText(spec(), last));
          },
        });
        const pair = field.label;
        const scrub = pair.firstElementChild as HTMLElement;
        const form = pair.lastElementChild as HTMLElement;
        name.replaceWith(scrub);
        name = scrub;
        let slider: HTMLInputElement | null = null;
        // A wide range (min above 0, max a thousand times it): a log slider, each decade the same length (`isLog`).
        const log = isLog(s);
        const toSlider = (value: number): string => (log ? String(logPosition(s, value)) : String(value));
        const fromSlider = (text: string): number => (log ? logValue(s, Number(text)) : Number(text));
        if (first.widget === 'slider') {
          slider = el('input', 'ed-mo-slider');
          slider.type = 'range';
          slider.min = log ? '0' : String(s.min);
          slider.max = log ? String(LOG_STEPS) : String(s.max);
          slider.step = log ? '1' : String(step);
          slider.value = typeof s.value === 'number' ? toSlider(s.value) : String(s.value);
          slider.title = `${tipOf(s)}${log ? `\nA log slider: ${s.min} to ${s.max}, each tenfold the same length` : ''}\nDrag: the model rebuilds as it moves; let go: written to the record`;
          const sl = slider;
          sl.addEventListener('pointerdown', () => void (held = true));
          sl.addEventListener('input', () => {
            held = true;
            last = fromSlider(sl.value);
            field.show(last);
            host.preview(s.name, overrideText(spec(), last));
          });
          sl.addEventListener('change', () => {
            held = false;
            last = fromSlider(sl.value);
            commit(overrideText(spec(), last));
          });
          sl.addEventListener('pointerup', () => void (held = false));
          ctl.append(slider);
        }
        ctl.append(form);
        show = (row) => {
          const v = row.spec.value;
          if (typeof v !== 'number') {
            note.textContent = `${note.textContent} · now "${String(v)}"`;
            return;
          }
          last = v;
          field.show(v);
          if (slider && document.activeElement !== slider && !held) slider.value = toSlider(v);
        };
        const input = field.input;
        const was = (): boolean => held || document.activeElement === input;
        return finish(was);
      }
      case 'choice': {
        const select = el('select', 'ed-input ed-mo-param-choice');
        for (const c of first.spec.choices ?? []) {
          const o = el('option', undefined, String(c));
          o.value = String(c);
          select.append(o);
        }
        select.title = tipOf(first.spec);
        select.addEventListener('change', () => {
          // Read once: the preview's redraw comes between.
          const value = select.value;
          pinned = spec();
          host.preview(first.spec.name, value);
          commit(value);
        });
        ctl.append(select);
        show = (row) => {
          if (document.activeElement !== select) select.value = String(row.spec.value);
        };
        return finish(() => false);
      }
      case 'tick': {
        const label = el('label', 'ed-line ed-check-line ed-mo-param-tick');
        const box = el('input', 'ed-check');
        box.type = 'checkbox';
        box.title = tipOf(first.spec);
        box.addEventListener('change', () => {
          const text = box.checked ? 'true' : 'false';
          pinned = spec();
          host.preview(first.spec.name, text);
          commit(text);
        });
        label.append(box, el('span', 'ed-dim', 'on'));
        ctl.append(label);
        show = (row) => {
          box.checked = row.spec.value === true;
          (label.lastChild as HTMLElement).textContent = box.checked ? 'on' : 'off';
        };
        return finish(() => false);
      }
      case 'colour': {
        const swatch = el('input', 'ed-mo-swatch');
        swatch.type = 'color';
        swatch.title = `${tipOf(first.spec)}\nPick: the model rebuilds as it moves; closed: written to the record`;
        const text = textInput(String(first.spec.value));
        text.title = 'The value as the script sees it: a hex code, or a name the script takes';
        let picking = false;
        swatch.addEventListener('input', () => {
          picking = true;
          text.value = swatch.value;
          host.preview(first.spec.name, swatch.value);
        });
        swatch.addEventListener('change', () => {
          picking = false;
          commit(swatch.value);
        });
        const form = el('form', 'ed-field');
        form.noValidate = true;
        form.append(text);
        form.addEventListener('submit', (e) => {
          e.preventDefault();
          text.blur();
        });
        text.addEventListener('change', () => commit(text.value.trim()));
        ctl.append(swatch, form);
        show = (row) => {
          const v = String(row.spec.value);
          if (document.activeElement !== text) text.value = v;
          const hex = normaliseHex(v);
          if (hex && !picking) swatch.value = hex;
          swatch.classList.toggle('ed-mo-swatch-unknown', !hex);
        };
        return finish(() => picking || document.activeElement === text);
      }
      default: {
        const form = el('form', 'ed-field');
        form.noValidate = true;
        const text = textInput(String(first.spec.value));
        text.title = tipOf(first.spec);
        form.append(text);
        form.addEventListener('submit', (e) => {
          e.preventDefault();
          text.blur();
        });
        text.addEventListener('change', () => {
          const value = text.value;
          pinned = spec();
          host.preview(first.spec.name, value);
          commit(value);
        });
        ctl.append(form);
        show = (row) => {
          if (document.activeElement !== text) text.value = String(row.spec.value);
        };
        return finish(() => document.activeElement === text);
      }
    }

    function finish(isHeld: () => boolean): Row {
      return {
        shape: shapeOf(first.spec),
        root: rowEl,
        name,
        note,
        reset,
        show(row) {
          if (isHeld()) return;
          if (pinned !== null && pinned === row.spec) return;
          pinned = null;
          show(row);
        },
        held: isHeld,
      };
    }
  }

  /** The rows as last drawn, by name: what a row's handlers read their spec from. */
  const current = new Map<string, ParamRow>();

  function drawRows(list: readonly ParamRow[]): void {
    current.clear();
    for (const r of list) current.set(r.spec.name, r);
    const order: HTMLElement[] = [];
    let changedShape = list.length !== rows.size;
    for (const r of list) {
      const shape = shapeOf(r.spec);
      let row = rows.get(r.spec.name);
      if (row && row.shape !== shape) {
        row.root.remove();
        rows.delete(r.spec.name);
        row = undefined;
        changedShape = true;
      }
      if (!row) {
        row = makeRow(r);
        rows.set(r.spec.name, row);
        changedShape = true;
      }
      order.push(row.root);
      // Its marks always; its value unless it is in hand.
      row.root.classList.toggle('ed-mo-changed', r.changed);
      const why = r.inherited ? 'Set by a folder\'s export.json above it, not by this source\'s record' : r.own ? 'Set in this source\'s record (its .export.json): ↺ takes it away' : '';
      row.name.title = `${r.changed ? `Changed from its default, ${sayValue(r.spec.default)}${why ? ` -- ${why}` : ''}\n` : ''}${tipOf(r.spec)}`;
      // Its default, faint after its name while it is changed (CSS `::after`, so the name keeps its own text and scrub).
      row.name.dataset.default = r.changed ? sayValue(r.spec.default) : '';
      row.reset.title = `Back to its default, ${sayValue(r.spec.default)}: the record's override taken away`;
      // Its place kept when there is nothing to take away: the row's controls never move as it comes and goes.
      row.reset.style.visibility = r.own && writes ? '' : 'hidden';
      row.root.classList.toggle('ed-mo-readonly', !writes);
      for (const input of row.root.querySelectorAll<HTMLInputElement | HTMLSelectElement>('input, select')) input.disabled = !writes;
      row.show(r);
    }
    for (const [name, row] of rows) {
      if (!current.has(name)) {
        row.root.remove();
        rows.delete(name);
      }
    }
    if (changedShape || [...rowsEl.children].some((c, i) => c !== order[i])) rowsEl.replaceChildren(...order);
  }

  /**
   * The block's line, under its rows: always there, so a row never moves as it comes and goes -- and a quiet word
   * (the hint, Amber's, building) one line, the whole on hover, so a commit that turns a row amber moves nothing under
   * it; only a fault wraps, to be read whole.
   */
  const say = (text: string, tone: '' | 'bad' | 'busy' = '', whole = tone === 'bad'): void => {
    status.textContent = text || ' ';
    status.title = text;
    status.className = `ed-mo-sec-status${tone ? ` ed-mo-${tone}` : ''}${whole ? '' : ' ed-mo-one-line'}`;
  };

  return {
    root,
    setFolded: fold,
    draw(view) {
      writes = view.writes;
      const answer = view.answer;
      const list = answer ? rowsOf(answer) : [];
      count.textContent = list.length > 0 ? String(list.length) : '';
      const own = list.some((r) => r.own);
      const changed = list.some((r) => r.changed);
      // Their places kept, shown or not: nothing above a slider moves as a drag ends and they come.
      resetAll.style.visibility = own && view.writes ? '' : 'hidden';
      resetAll.disabled = view.busy;
      bake.style.visibility = changed && view.writes ? '' : 'hidden';
      bake.disabled = view.busy || (answer !== null && !answer.ok);
      bake.title = answer && !answer.ok
        ? 'Not while a value is refused: fix it or take it back (↺) first -- a refused value written as a default would break the script itself'
        : 'Bake into script: the values shown written into params{} as its defaults, the overrides cleared -- the script alone builds this (one step: Z takes it back)';
      drawRows(list);
      // What there is to say, the most pressing first.
      if (!answer) return say(view.reading ? 'Reading the script\'s parameters…' : '', view.reading ? 'busy' : '');
      if (answer.missing) return say('Gladius is not found on this machine: it is what reads the parameters (see the banner).', 'bad');
      if (answer.params === null) {
        if (answer.error || answer.problem) return say(`params{} could not be read: ${answer.error ?? answer.problem}`, 'bad');
        return say('This Gladius does not report a script\'s parameters: 0.6 or newer does.', 'bad');
      }
      if (list.length === 0) return say('The script declares no params{}. Add one -- local P = params{ size = { default = 1, min = 0.1, max = 4 } } -- and each number is a slider here.', '', true);
      if (!answer.ok && answer.error) return say(`${answer.error.replace(/^GLD-\d+:\s*/, '')} -- set it back (↺) or to a value it takes`, 'bad');
      if (view.previewError) return say(`Preview: ${view.previewError} -- the last good one is shown`, 'bad');
      if (view.building) return say('Building a preview…', 'busy');
      if (!view.writes) return say(view.readOnly ?? 'Read only: parameters are set on the machine running the dev server.', '', true);
      say(changed ? 'Amber: set by the record, not the script -- Bake writes them in' : 'Drag to try a value; let go to keep it');
    },
  };
}
