/**
 * The model open in the Model tab, and its life (Docs/modeler.md M3, M4, M5,
 * M15–M17): a Gladius script under `AssetsSource/`, its export read and
 * decoded, its builds followed, the kernel asked after each.
 *
 * - **Its own client index** (M5): an `Api` and a `Live` of the tab's own --
 *   `Api.connect` takes one answer sink, and the Assets panel's index must keep
 *   its own calls' diffs -- started the first time a model is opened.
 * - **What is shown is the export** (M3): `src/assets/models/…/<stem>.glb`
 *   through `GET file` and the game's loaders (`decodeScratch`): the model the
 *   game will draw. A script not `current` is exported (`POST export`, which
 *   the server dedupes against its auto-export); one that never built shows
 *   nothing but why.
 * - **A build followed, not polled**: the script's `job` messages say it is
 *   building, failed (its first line) or could not be made (a tool missing);
 *   the index's diff says its export was written (its size and time moved),
 *   and the new one is decoded -- a rebuild (`first: false`): the tab keeps its
 *   cameras, its selection and its hidden parts.
 * - **A failed build keeps the last good model** (M16) and asks the kernel
 *   (`GET model`) for its diagnostics with their lines; each good one asks it
 *   for the polygons and counts (M4) -- one query running, one waiting.
 * - **One open at a time**: a model opened while another is still on its way
 *   wins; a decode overtaken is freed the moment it lands, never shown.
 *
 * `stateOf` -- what a script's index entry says of its build -- is pure
 * (`source.test.ts`); the rest is handed its api, live and decoder.
 */
import type { Diff, Entry, JobMessage, ModelAnswer, ModelDiagnostic, QueuedJobInfo, ToolLook, TreeAnswer } from '@vibe/pipeline/assets-types';
import { ROOTS } from '@vibe/pipeline/kinds';
import { baseName, extOf, locate, underscored } from '@vibe/pipeline/paths';
import type { Api } from '../assets/api.ts';
import type { Live } from '../assets/live.ts';
import type { Scratch } from '../assets/preview/scratch.ts';
import { sayPassedOver } from '@vibe/pipeline/look-words';

/**
 * What the tab says of the script's build, beside whatever it shows:
 *
 * - `none`      no model open
 * - `loading`   the index, or the export, on its way
 * - `building`  an export queued or running -- the last model still shown
 * - `ready`     the export shown is the script's as it is
 * - `failed`    the last build failed: why, Gladius's lines if asked for (M16)
 * - `unmade`    a tool it needs is not here: which, and its hint (M17)
 * - `excluded`  out of the build: never exported, nothing to show
 * - `gone`      no such script
 * - `offline`   no dev server to build or read it
 */
export type BuildState =
  | { kind: 'none' }
  | { kind: 'loading' }
  | { kind: 'building'; step?: string }
  | { kind: 'ready' }
  | { kind: 'failed'; error: string; lines: readonly ModelDiagnostic[] }
  | { kind: 'unmade'; reason: string; tool?: string; hint?: string; passed?: string }
  | { kind: 'excluded'; underscore?: boolean }
  | { kind: 'gone' }
  | { kind: 'offline' };

/**
 * The right panel's blocks -- Parameters, Animation, Materials, the trace -- shown: a model open whose script is there.
 * Worked out afresh from the state at every draw, both ways: a script gone for a moment (a New model not yet in the
 * index, a rename) hides them, and it back shows them again.
 */
export function blocksShown(path: string | null, state: BuildState): boolean {
  return path !== null && state.kind !== 'gone';
}

/** Is `path` a script the tab opens: a `.lua` under `AssetsSource/models/`? Its words if not. */
export function scriptProblem(path: string): string | null {
  if (extOf(path) !== 'lua') return `${baseName(path)} is no Gladius script: the Model tab opens a .lua`;
  const where = locate(path);
  if (!where || where.root !== 'source' || where.kind !== 'models') return `${path} is not under ${ROOTS.source.dir}/models/: the Model tab opens a script there`;
  return null;
}

/** Is a path out of the build by its name: a file or a folder under its kind's starting with `_`? */
export function underscoredPath(path: string): boolean {
  const under = locate(path)?.under;
  return under !== undefined && underscored(under);
}

/** A model's key as the game names it: `props/crate` for `AssetsSource/models/props/crate.lua`. */
export function modelName(path: string): string {
  const under = locate(path)?.under;
  return (under ?? baseName(path)).replace(/\.lua$/, '');
}

/** What a script's entry says of its build, before any job is heard: the state, and whether an export is there to show. */
export function stateOf(entry: Entry | undefined, exported: Entry | undefined): BuildState {
  if (!entry) return { kind: 'gone' };
  // Out of the build by its name: a `_` file or folder is no source at all -- never exported, nothing to wait for.
  if (entry.role !== 'source') return { kind: 'excluded', underscore: underscoredPath(entry.path) };
  switch (entry.status) {
    case 'current':
      return exported ? { kind: 'ready' } : { kind: 'building' };
    case 'stale':
    case 'missing':
    case 'checking':
    case 'conflict':
      return { kind: 'building' };
    case 'failed':
      return { kind: 'failed', error: (entry.reason ?? 'the last export failed').replace(/^the last export failed: /, ''), lines: [] };
    case 'unmade': {
      const tool = /\b(gladius)\b/.exec(entry.reason ?? '')?.[1];
      return { kind: 'unmade', reason: entry.reason ?? 'a tool it needs is not here', ...(tool ? { tool } : {}) };
    }
    case 'excluded':
      return { kind: 'excluded' };
    default:
      return { kind: 'building' };
  }
}

/**
 * Does an index move touch the script open or its export: a diff naming
 * either, or a whole tree (a gap filled)? Pure (`source.test.ts`).
 */
export function touches(diff: Diff | TreeAnswer, script: string, exported: string | null): boolean {
  if (!('from' in diff)) return true;
  const ours = (p: string): boolean => p === script || p === exported;
  return diff.added.some((e) => ours(e.path)) || diff.updated.some((e) => ours(e.path)) || diff.removed.some(ours);
}

/** An export's version as the index has it: its size and time, which move as it is written again. */
export const versionOf = (entry: Entry | undefined): string | null => (entry ? `${entry.mtime}:${entry.size}` : null);

/** The first line of a job's error, Gladius's own words after its code: `GLD-1007  error: crate.lua:3: …` → `crate.lua:3: …`. */
export function errorLine(error: string): string {
  const first = error.split('\n').find((l) => l.trim() !== '') ?? error;
  return first.replace(/^.*?exited \d+:\s*/, '').replace(/^GLD-\d+\s+error:\s*/, '').trim();
}

/** The status line's words while a stale script waits for the turn's end. */
export const HELD_STEP = "waiting for Claude's turn to end";

/**
 * Does the tab export a stale script itself now, or wait? It waits while the link holds the script, or while any
 * turn runs -- its auto-export is then held (or about to be, the watcher's quiet not yet come), and the turn's end
 * exports it (M21).
 */
export function heldDecision(path: string, now: { held: readonly string[]; turns: boolean }): 'build' | 'wait' {
  return now.held.includes(path) || now.turns ? 'wait' : 'build';
}

export interface SourceHost {
  api: Api;
  live: Live;
  /** The export decoded for the tab alone (`decodeScratch`). */
  decode(path: string): Promise<Scratch>;
  /** A new model in -- the first of this script (`first`), or a rebuild -- to show; the one before is freed after. */
  model(scratch: Scratch, first: boolean): void;
  /** What the tab says of the build changed. */
  state(state: BuildState): void;
  /** The kernel's answer for the model shown (`GET model`, M4) -- or null, none to be had. */
  kernel(answer: ModelAnswer | null): void;
  /** Is the script's export held for a Claude turn (M21): opened stale, it is not exported now -- the turn's end does that. */
  held?(): boolean;
  /**
   * The live held list and whether a turn runs (`GET held`), asked before the tab exports a stale script itself: the
   * `held` push may not have reached the page yet, and a script Claude is still writing is never built half-written
   * (M21). None: not asked, built at once.
   */
  heldNow?(): Promise<{ held: readonly string[]; turns: boolean }>;
  /**
   * What the last export of the script open did worth reading (`JobMessage.notes`, `Run.notes`; Docs/modeler.md M41,
   * M42): hidden surfaces removed and the parts gone whole, samples dropped, a merge not made -- read as it opens, and
   * with every build after.
   */
  notes?(notes: readonly string[]): void;
}

export interface Source {
  /** The script open, or null. */
  readonly path: string | null;
  readonly state: BuildState;
  /** The export shown, or null. */
  readonly exportPath: string | null;
  /** The script's index entry, as the tab's index has it. */
  entry(): Entry | undefined;
  /** Open `path` (a `.lua`, checked by the caller): its export shown when it is in, built first if it must be. */
  open(path: string): Promise<void>;
  /** The script exported again now, current or not: what `B` and Build now do. False where this page may not write. */
  build(): Promise<boolean>;
  /** The same, for the studio's `model_export` (Docs/mcp.md M6): the jobs it queued, or null where it was not. */
  exportNow(): Promise<QueuedJobInfo[] | null>;
  /** The kernel asked again for the model shown (the shading wants polygons it has none of). */
  query(): void;
  /** The export shown handed to the tab again (`model`, not first), the kernel asked again: a preview put away for it. False if none is shown. */
  reshow(): boolean;
  /** Every `.lua` under `AssetsSource/models/`, for the empty state, once the index is in. */
  scripts(): Promise<string[]>;
  /**
   * The `.glb` models delivered as they are -- no script makes them -- the index has (after `scripts`): what Make a
   * script is offered for (Docs/modeler.md M39). `_` names are out of the build and not offered.
   */
  unscripted(): string[];
  close(): void;
  dispose(): void;
}

export function createSource(host: SourceHost): Source {
  const { api, live } = host;
  let path: string | null = null;
  let state: BuildState = { kind: 'none' };
  let shown: Scratch | null = null;
  let shownVersion: string | null = null;
  let exportPath: string | null = null;
  /** Bumped by every open and close: a decode or a query of one before is let go. */
  let ticket = 0;
  /**
   * The ticket of the script waiting for the turns' end (`buildUnlessHeld`), or null: ended by the `held` push saying the
   * list emptied (asked again then) or by the index moving the script to current (the turn's end exported it).
   */
  let waiting: number | null = null;
  /** `held` pushes of an empty list heard: one heard while the list was being asked asks again. */
  let emptied = 0;
  let started = false;
  let looks: readonly ToolLook[] | null = null;

  const set = (next: BuildState): void => {
    state = next;
    host.state(next);
  };
  const entryOf = (p: string | null): Entry | undefined => (p === null ? undefined : live.index.entries.get(p));
  const exportOf = (entry: Entry | undefined): string | null => entry?.exports?.[0] ?? null;

  /** The tools as looked for, for an `unmade`'s hint and a path set in Tools that was passed over: asked again each time (a path may have been set since). */
  async function lookOf(tool: string | undefined): Promise<{ hint?: string; passed?: string }> {
    if (!tool) return {};
    try {
      looks = (await api.tools()).tools ?? looks;
    } catch {
      // The last look, if any.
    }
    const look = looks?.find((l) => l.tool === tool);
    if (!look) return {};
    const passed = sayPassedOver(look);
    return { ...(look.hint ? { hint: look.hint } : {}), ...(passed ? { passed } : {}) };
  }

  /**
   * The export at `exported`, decoded and shown if it is not the one shown
   * already. Called by `settle` alone, which runs one at a time: no two
   * decodes are ever under way, so an older one can never land after a newer.
   */
  async function show(exported: string, first: boolean): Promise<void> {
    const mine = ticket;
    const version = versionOf(entryOf(exported));
    if (!first && version !== null && version === shownVersion) return;
    let scratch: Scratch;
    try {
      scratch = await host.decode(exported);
    } catch (err) {
      if (mine !== ticket) return;
      set({ kind: 'failed', error: `${baseName(exported)} could not be read: ${(err as Error).message}`, lines: [] });
      return;
    }
    // Overtaken -- another script opened, or this one closed -- while it decoded: freed, never shown.
    if (mine !== ticket) {
      scratch.dispose();
      return;
    }
    const before = shown;
    shown = scratch;
    shownVersion = version;
    exportPath = exported;
    host.model(scratch, first);
    if (before && before !== scratch) before.dispose();
    query();
  }

  /** `GET model`: one running, one waiting, its answer only for the script still open. */
  let querying = false;
  let again = false;
  function query(): void {
    if (path === null) return;
    if (querying) {
      again = true;
      return;
    }
    querying = true;
    const asked = path;
    const mine = ticket;
    void api.model(asked).then(
      (answer) => {
        if (mine !== ticket) return;
        if (answer.ok) return host.kernel(answer);
        host.kernel(null);
        const missing = answer.missing;
        if (missing) {
          // Gladius not here: nothing can be built, whatever is shown -- said with the way to Tools (M17).
          void lookOf(missing).then((looked) => {
            if (mine !== ticket) return;
            const hint = answer.hint ?? looked.hint;
            set({ kind: 'unmade', reason: `${missing} is not found on this machine`, tool: missing, ...(hint ? { hint } : {}), ...(looked.passed ? { passed: looked.passed } : {}) });
          });
          return;
        }
        // A build that failed: Gladius's own lines, with where, in place of the job's one line. The last good model is kept.
        const error = answer.diagnostics.find((d) => d.severity === 'error');
        if ((state.kind === 'failed' || !shown) && (error || answer.problem)) {
          set({ kind: 'failed', error: error?.message ?? answer.problem ?? 'the build failed', lines: answer.diagnostics.filter((d) => d.severity !== 'info') });
        }
      },
      () => {
        if (mine === ticket) host.kernel(null);
      },
    ).finally(() => {
      querying = false;
      if (again) {
        again = false;
        query();
      }
    });
  }

  /** One settle at a time: another asked meanwhile runs once after it (`first` if any asked so), reading the index as it is then. */
  let settling = false;
  let settleAgain = false;
  let settleFirst = false;

  /** The script's entry read again: what to show, what to say. */
  async function settle(first: boolean): Promise<void> {
    if (settling) {
      settleAgain = true;
      settleFirst ||= first;
      return;
    }
    settling = true;
    try {
      await settleOnce(first);
    } finally {
      settling = false;
    }
    if (settleAgain) {
      const wasFirst = settleFirst;
      settleAgain = false;
      settleFirst = false;
      await settle(wasFirst);
    }
  }

  async function settleOnce(first: boolean): Promise<void> {
    if (path === null) return;
    const mine = ticket;
    const entry = entryOf(path);
    const exported = exportOf(entry);
    const exportEntry = entryOf(exported);
    // A script being hashed again with its export shown is no build: nothing to say until the index has settled it (review).
    const next = entry?.status === 'checking' && shown && state.kind === 'ready' ? state : stateOf(entry, exportEntry);
    if (next.kind === 'unmade') Object.assign(next, await lookOf(next.tool));
    // The last good build shown while one is on its way, or failed, or not to be made.
    if (exported && exportEntry && (first || !shown || versionOf(exportEntry) !== shownVersion)) await show(exported, first || !shown);
    if (mine !== ticket) return;
    const pending = entry !== undefined && (entry.status === 'stale' || entry.status === 'missing');
    // The script current (or gone) now: the turn's end exported it, or someone did -- the wait is over.
    if (!pending) waiting = null;
    if (next.kind === 'failed') {
      // Gladius's own lines, once the kernel has said them, are kept over the index's one-line reason.
      if (state.kind !== 'failed' || state.lines.length === 0) set(next);
      query();
    } else if (next.kind === 'building' && entry && (entry.status === 'stale' || entry.status === 'missing') && first && !host.held?.()) {
      set(next);
      void buildUnlessHeld(mine);
    } else if (next.kind === 'building' && pending && waiting === mine) set({ kind: 'building', step: HELD_STEP });
    else set(next);
  }

  /**
   * A stale script opened: exported now (the server dedupes it against its own auto-export) -- or, where this page may
   * not, said -- unless the live held list holds it or a turn runs (`heldDecision`): then it waits, saying so, until
   * the `held` push says the list emptied (the turns over: asked once more) or the index moves it to current (the
   * turn's end exported it). No asking while the turn runs.
   */
  async function buildUnlessHeld(mine: number): Promise<void> {
    waiting = null;
    for (;;) {
      if (mine !== ticket || path === null) return;
      const entry = entryOf(path);
      if (!entry || (entry.status !== 'stale' && entry.status !== 'missing')) return;
      if (!host.heldNow) break;
      const heard = emptied;
      let now: { held: readonly string[]; turns: boolean };
      try {
        now = await host.heldNow();
      } catch {
        break;
      }
      if (mine !== ticket) return;
      if (heldDecision(path, now) === 'build') break;
      // The list emptied while it was asked: the answer may be from before -- asked again.
      if (emptied !== heard) continue;
      waiting = mine;
      if (state.kind !== 'building' || state.step !== HELD_STEP) set({ kind: 'building', step: HELD_STEP });
      return;
    }
    const asked = await build(false);
    if (!asked && state.kind === 'building' && mine === ticket) set({ kind: 'failed', error: 'not current, and this page may not export it: export it on the machine running the dev server', lines: [] });
  }

  /** Index moves and job messages, for the script open -- a diff of other files' alone moves nothing here (review: another source saved flashed "Building…"). */
  const offChanged = live.on('changed', (diff) => {
    if (path === null || !live.index.loaded) return;
    if (!touches(diff, path, exportPath ?? exportOf(entryOf(path)))) return;
    void settle(false);
  });
  const offJob = live.on('job', (job: JobMessage) => {
    if (job.source !== path) return;
    if (job.state === 'queued' || job.state === 'running' || job.state === 'parked') set({ kind: 'building', ...(job.state === 'running' ? { step: `step ${job.step} of ${job.of}` } : {}) });
    else if (job.state === 'failed') {
      set({ kind: 'failed', error: errorLine(job.error ?? 'the build failed'), lines: [] });
      query();
    } else if (job.state === 'unmade') {
      const tool = /\b(gladius)\b/.exec(job.error ?? '')?.[1];
      void lookOf(tool).then((looked) => set({ kind: 'unmade', reason: job.error ?? 'a tool it needs is not here', ...(tool ? { tool } : {}), ...looked }));
    } else if (job.state === 'done' || job.state === 'skipped') {
      if (job.state === 'done') host.notes?.(job.notes ?? []);
      // The index's diff brings the new export; a build that changed nothing (the same bytes) is ready as it is.
      void live.refresh().then(() => settle(false));
    }
  });
  // The turns over (the list pushed empty -- `turnsOver` pushes it at every turns' end): a script waiting asks once more.
  const offHeld = live.on('held', (list) => {
    if (list.length > 0) return;
    emptied++;
    if (waiting === null || waiting !== ticket) return;
    const mine = waiting;
    void buildUnlessHeld(mine);
  });
  const offOffline = live.on('offline', () => {
    if (path !== null) set({ kind: 'offline' });
  });

  async function build(force: boolean): Promise<boolean> {
    return (await exporting(force)) !== null;
  }

  /** `POST export` of the script open: the jobs it queued, or null -- nothing open, a page that may not write, refused (said). */
  async function exporting(force: boolean): Promise<QueuedJobInfo[] | null> {
    if (path === null) return null;
    if ((await api.online()) !== 'write') return null;
    try {
      return (await api.exportSources({ paths: [path] }, force)).jobs;
    } catch (err) {
      set({ kind: 'failed', error: `not exported: ${(err as Error).message}`, lines: [] });
      return null;
    }
  }

  return {
    get path() {
      return path;
    },
    get state() {
      return state;
    },
    get exportPath() {
      return exportPath;
    },
    entry: () => entryOf(path),
    async open(next) {
      ticket++;
      path = next;
      shownVersion = null;
      exportPath = null;
      // The model before is another script's: the tab took it off the stage before asking for this one.
      shown?.dispose();
      shown = null;
      set({ kind: 'loading' });
      const mine = ticket;
      if ((await api.online()) === false) {
        if (mine === ticket) set({ kind: 'offline' });
        return;
      }
      if (!started) {
        started = true;
        try {
          await live.start();
        } catch {
          started = false;
          if (mine === ticket) set({ kind: 'offline' });
          return;
        }
      }
      if (mine !== ticket) return;
      // The last export's notes, from the runs cache: a reload, or another session's build, says them too.
      host.notes?.([]);
      void api.run(next).then((run) => {
        if (mine === ticket && run?.current === true) host.notes?.(run.notes ?? []);
      }, () => {});
      await settle(true);
    },
    build: () => build(true),
    exportNow: () => exporting(true),
    query,
    reshow() {
      if (!shown || path === null) return false;
      host.model(shown, false);
      query();
      return true;
    },
    async scripts() {
      if ((await api.online()) === false) return [];
      if (!started) {
        started = true;
        try {
          await live.start();
        } catch (err) {
          // Asked again next time, as `open` does.
          started = false;
          throw err;
        }
      }
      return [...live.index.entries.values()]
        .filter((e) => e.role === 'source' && scriptProblem(e.path) === null)
        .map((e) => e.path)
        .sort();
    },
    unscripted() {
      return [...live.index.entries.values()]
        .filter((e) => e.role === 'loose' && e.kind === 'models' && extOf(e.path) === 'glb' && !baseName(e.path).startsWith('_'))
        .map((e) => e.path)
        .sort();
    },
    close() {
      ticket++;
      path = null;
      exportPath = null;
      shownVersion = null;
      shown?.dispose();
      shown = null;
      set({ kind: 'none' });
    },
    dispose() {
      ticket++;
      offChanged();
      offJob();
      offHeld();
      offOffline();
      shown?.dispose();
      shown = null;
      live.dispose();
    },
  };
}
