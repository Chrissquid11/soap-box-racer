/**
 * What the Model tab holds of the one model open (Docs/modeler.md M15, M16,
 * M22): its scene and parts, the selection and the hidden parts, the kernel's
 * counts and polygons, what Gladius said. One place says what each becomes:
 *
 * - **Another script opened, or none** (`forgotten`): all of it gone at once --
 *   before the new script has shown anything, and whether it ever will (a `_`
 *   script, a first build that fails, Gladius missing, a script gone): nothing
 *   of the model before is ever shown as the new one's.
 * - **A model shown** (`shown`): its first load starts afresh; a rebuild -- or a
 *   preview of a value dragged -- keeps the selection and the hidden parts by
 *   name (M13) and what Gladius said and its counts until its next answer (a
 *   count is used only where its triangles still match, M4), so the panel's
 *   facts never drop out under a gesture.
 *
 * Pure (`per-model.test.ts`): three objects read, no DOM.
 */
import type * as THREE from 'three';
import type { ModelAnswer, ModelDiagnostic, ModelNode } from '@vibe/pipeline/assets-types';
import { kept, partsOf, type PartTree } from './parts.ts';

export interface PerModel {
  scene: THREE.Object3D | null;
  tree: PartTree | null;
  selection: string[];
  hidden: Set<string>;
  /** The kernel's counts by node name (M4, M12). */
  kernel: Map<string, ModelNode>;
  /** The kernel's answer, while its polygons match the model shown. */
  answer: ModelAnswer | null;
  /** What Gladius said of the build: its info() lines and warnings. */
  told: readonly ModelDiagnostic[];
}

/** Nothing of any model: another script opened, or the tab closed. */
export function forgotten(): PerModel {
  return { scene: null, tree: null, selection: [], hidden: new Set(), kernel: new Map(), answer: null, told: [] };
}

/** `next` shown -- the first of its script (`first`), or a rebuild or a preview of it -- after `before`. */
export function shown(before: PerModel, next: THREE.Object3D | null, first: boolean): PerModel {
  const tree = next ? partsOf(next) : null;
  const carry = !first && tree !== null;
  return {
    scene: next,
    tree,
    selection: carry ? kept(before.selection, tree) : [],
    hidden: carry ? new Set(kept(before.hidden, tree)) : new Set(),
    // The polygons are of the model before: asked again for this one.
    answer: null,
    kernel: first ? new Map() : before.kernel,
    told: first ? [] : before.told,
  };
}
