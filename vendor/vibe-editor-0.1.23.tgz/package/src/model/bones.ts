/**
 * The bones overlay (Docs/modeler.md M32; Vibe3D D91, D121, changed after
 * review): every bone drawn as a stick of its own -- from its head along its
 * +Y, as long as the way to the child it points at -- so each bone, a leaf too
 * (Head, Tail, a wing tip, a foot), has a line of its own to see and to click;
 * faint links from a parent's head to each child's where they do not run along
 * a stick (Spine to a wing's shoulder). Picked on screen against the sticks
 * alone, the nearest within 14 px -- a ray would hit the body every time; the
 * selected sticks amber, the one under the pointer lit.
 *
 * `stickLengths` is pure (`bones.test.ts`); the drawing is three's, no DOM.
 */
import * as THREE from 'three';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';

/** A child points along its parent's stick when its offset is within this of the parent's +Y. */
const ALONG = 0.95;
/** A leaf's stick, as a share of its parent's: a stub along its own rest direction. */
const LEAF = 0.6;
/** How near a stick a press counts, CSS pixels. */
export const PICK_PX = 14;
/** A stick's width, and its dark rim's, CSS pixels: read over a light mesh as over a dark one (review round 2). */
const STICK_PX = 3;
const RIM_PX = 5.5;

/** A bone's place in the tree for its stick: its parent (by index), its children's offsets in its frame. */
export interface StickBone {
  parent: number;
  children: readonly (readonly [number, number, number])[];
}

/**
 * Each bone's stick length, in its own frame: the farthest child lying along
 * its +Y; with none along it, most of the way to its children; a leaf, a share
 * of its parent's (a root alone, `fallback`). Parents come before children.
 */
export function stickLengths(bones: readonly StickBone[], fallback: number): number[] {
  const out: number[] = [];
  bones.forEach((bone, i) => {
    let along = 0;
    let any = 0;
    for (const [x, y, z] of bone.children) {
      const length = Math.hypot(x, y, z);
      if (length < 1e-9) continue;
      any = Math.max(any, length);
      if (y / length > ALONG) along = Math.max(along, length);
    }
    if (along > 0) out[i] = along;
    else if (any > 0) out[i] = any * LEAF;
    else out[i] = bone.parent >= 0 && bone.parent < i ? (out[bone.parent] ?? fallback) * LEAF : fallback;
  });
  return out;
}

const INK = new THREE.Color(0x6fa8ff);
const CHOSEN = new THREE.Color(0xf0a63c);
const LIT = new THREE.Color(0xffffff);

export class BoneSticks {
  readonly group = new THREE.Group();
  private bones: THREE.Bone[] = [];
  private lengths: number[] = [];
  /** For each bone with a parent bone not reached along the parent's stick: a faint link. */
  private links: [number, number][] = [];
  private readonly sticks: LineSegments2;
  private readonly rim: LineSegments2;
  private readonly stickMaterial = new LineMaterial({ vertexColors: true, linewidth: STICK_PX, depthTest: false, transparent: true });
  private readonly rimMaterial = new LineMaterial({ color: 0x05070a, linewidth: RIM_PX, depthTest: false, transparent: true, opacity: 0.85 });
  private readonly linked: THREE.LineSegments;
  /** The sticks' ends and colours, as the fat lines read them: written in place each frame. */
  private ends6 = new Float32Array(0);
  private colours6 = new Float32Array(0);
  private chosen = new Set<THREE.Bone>();
  private lit: THREE.Bone | null = null;

  constructor() {
    this.group.name = 'model: bones';
    this.sticks = new LineSegments2(new LineSegmentsGeometry(), this.stickMaterial);
    // The rim: the same sticks wider and dark, under them -- in front of the mesh, never lost in a light surface.
    this.rim = new LineSegments2(this.sticks.geometry, this.rimMaterial);
    this.linked = new THREE.LineSegments(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: INK, depthTest: false, transparent: true, opacity: 0.45 }));
    this.rim.renderOrder = 20;
    this.sticks.renderOrder = 21;
    this.linked.renderOrder = 19;
    for (const lines of [this.rim, this.sticks, this.linked]) {
      lines.frustumCulled = false;
      lines.raycast = () => {};
      lines.matrixAutoUpdate = false;
      this.group.add(lines);
    }
  }

  /** A model's bones, at rest: their sticks measured. */
  set(bones: readonly THREE.Bone[], fallback: number): void {
    this.bones = [...bones];
    const index = new Map(this.bones.map((b, i) => [b, i] as const));
    const tree: StickBone[] = this.bones.map((b) => ({
      parent: index.get(b.parent as THREE.Bone) ?? -1,
      children: b.children.filter((c) => (c as THREE.Bone).isBone).map((c) => [c.position.x, c.position.y, c.position.z] as const),
    }));
    this.lengths = stickLengths(tree, fallback);
    this.links = [];
    this.bones.forEach((b, i) => {
      const p = tree[i]!.parent;
      if (p < 0) return;
      const off = b.position;
      const length = off.length();
      // A child at the end of its parent's stick is joined already.
      if (length > 1e-9 && off.y / length > ALONG && Math.abs(length - this.lengths[p]!) < 1e-6) return;
      this.links.push([p, i]);
    });
    this.sticks.geometry.dispose();
    const geometry = new LineSegmentsGeometry();
    this.ends6 = new Float32Array(Math.max(1, this.bones.length) * 6);
    this.colours6 = new Float32Array(Math.max(1, this.bones.length) * 6);
    geometry.setPositions(this.ends6);
    geometry.setColors(this.colours6);
    this.sticks.geometry = geometry;
    this.rim.geometry = geometry;
    this.sticks.visible = this.rim.visible = this.bones.length > 0;
    this.linked.geometry.dispose();
    this.linked.geometry = new THREE.BufferGeometry();
    this.linked.geometry.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(this.links.length * 6), 3));
    this.paint();
  }

  /** The selected bones amber, the one under the pointer lit. */
  mark(chosen: readonly THREE.Bone[], lit: THREE.Bone | null): boolean {
    const same = lit === this.lit && chosen.length === this.chosen.size && chosen.every((b) => this.chosen.has(b));
    this.chosen = new Set(chosen);
    this.lit = lit;
    if (!same) this.paint();
    return !same;
  }

  private paint(): void {
    this.bones.forEach((b, i) => {
      const c = b === this.lit ? LIT : this.chosen.has(b) ? CHOSEN : INK;
      this.colours6.set([c.r, c.g, c.b, c.r, c.g, c.b], i * 6);
    });
    const start = this.sticks.geometry.getAttribute('instanceColorStart') as THREE.InterleavedBufferAttribute | undefined;
    if (start) {
      (start.data.array as Float32Array).set(this.colours6);
      start.data.needsUpdate = true;
    }
  }

  /** Before a view is drawn: the fat lines' widths are in its pixels. */
  resolution(width: number, height: number): void {
    this.stickMaterial.resolution.set(Math.max(width, 1), Math.max(height, 1));
    this.rimMaterial.resolution.set(Math.max(width, 1), Math.max(height, 1));
  }

  private readonly head = new THREE.Vector3();
  private readonly tail = new THREE.Vector3();

  /** A bone's stick in the world, now: its head and its tail. */
  ends(i: number, head: THREE.Vector3, tail: THREE.Vector3): void {
    const bone = this.bones[i]!;
    bone.getWorldPosition(head);
    bone.localToWorld(tail.set(0, this.lengths[i]!, 0));
  }

  /** Before a frame: each stick and link where the bones are now. */
  place(): void {
    if (!this.group.visible || this.bones.length === 0) return;
    for (let i = 0; i < this.bones.length; i++) {
      this.ends(i, this.head, this.tail);
      this.ends6.set([this.head.x, this.head.y, this.head.z, this.tail.x, this.tail.y, this.tail.z], i * 6);
    }
    const start = this.sticks.geometry.getAttribute('instanceStart') as THREE.InterleavedBufferAttribute | undefined;
    if (start) {
      (start.data.array as Float32Array).set(this.ends6);
      start.data.needsUpdate = true;
    }
    const links = this.linked.geometry.getAttribute('position') as THREE.BufferAttribute;
    this.links.forEach(([p, c], k) => {
      this.bones[p]!.getWorldPosition(this.head);
      this.bones[c]!.getWorldPosition(this.tail);
      links.setXYZ(k * 2, this.head.x, this.head.y, this.head.z);
      links.setXYZ(k * 2 + 1, this.tail.x, this.tail.y, this.tail.z);
    });
    links.needsUpdate = true;
  }

  /** The bone whose stick is nearest a point of a view, within `PICK_PX`; null for none. */
  pick(camera: THREE.Camera, x: number, y: number, width: number, height: number): THREE.Bone | null {
    let best: THREE.Bone | null = null;
    let nearest = PICK_PX;
    for (let i = 0; i < this.bones.length; i++) {
      this.ends(i, this.head, this.tail);
      this.head.project(camera);
      this.tail.project(camera);
      if (this.head.z > 1 || this.tail.z > 1) continue;
      const d = toSegment(x, y, (this.head.x * 0.5 + 0.5) * width, (-this.head.y * 0.5 + 0.5) * height, (this.tail.x * 0.5 + 0.5) * width, (-this.tail.y * 0.5 + 0.5) * height);
      if (d < nearest) {
        nearest = d;
        best = this.bones[i]!;
      }
    }
    return best;
  }

  dispose(): void {
    this.sticks.geometry.dispose();
    this.linked.geometry.dispose();
    for (const m of [this.stickMaterial, this.rimMaterial, this.linked.material as THREE.Material]) m.dispose();
  }
}

/** Pixels from a point to a segment: the skeleton is drawn, so this is how it is hit. */
export function toSegment(px: number, py: number, ax: number, ay: number, bx: number, by: number): number {
  const dx = bx - ax;
  const dy = by - ay;
  const length = dx * dx + dy * dy;
  const t = length === 0 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / length));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}
