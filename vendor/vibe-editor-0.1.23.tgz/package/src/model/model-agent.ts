/**
 * The Model tab as the studio's model tools work it (`PageModel`, Docs/mcp.md M6): each tool through the tab's own
 * doings, never a second path -- Open in Model tab (`EditorContext.openModel`, the tab brought up), the Parameters
 * block's drag and let go and its Bake (`editing.ts`' agent), the Materials block's let go, K (`pose-keys.ts`' `poseEdit`
 * through the tab's `editScript`, as `animating.ts`' key), Build (`source.ts`' export). Each write is one step of the
 * tab's own history -- its Z -- and names the files it wrote, which the turn's Undo this turn puts back.
 *
 * - **A preview nobody wrote** -- a parameter tried, not let go -- is the tab's one unsaved state: opening another
 *   script over it is refused unless `discard`, which puts it away.
 * - **A pose in the readable trio**: a joint the key spells with `rotate` or `orient` would need the bone's own frame
 *   to say the same turn -- the tab's gizmo has it, the tool does not -- so it is refused, saying so.
 *
 * Made by `model-tool.ts` from its parts; pure over them.
 */
import type { ModelFacts, ModelParamFacts } from '@vibe/pipeline/agent-types';
import { paramFacts } from '@vibe/pipeline/model-facts';
import { recordPath } from '@vibe/pipeline/paths';
import type { PageModel } from '../mcp/host.ts';
import type { History } from '../history.ts';
import type { Editing } from './editing.ts';
import type { PartTree } from './parts.ts';
import { declaredActions, poseEdit, type JointEdit } from './pose-keys.ts';
import { MATERIAL_FIELDS, type MaterialField, type MaterialValue } from './script-edits.ts';
import { scriptProblem, type Source } from './source.ts';

export interface ModelAgentParts {
  source: Source;
  editing: Editing;
  /** The tab's own history (`editing.history`). */
  history: History;
  /** The clips of the model shown. */
  clips(): string[];
  /** The parts, and which are selected and hidden. */
  parts(): { tree: PartTree | null; selected: string[]; hidden: string[] };
  /** Open in Model tab, as the Assets panel asks it: the tab brought up; false where it is not opened. */
  openModel(path: string): boolean;
  /** Why an open would be refused now, asked before anything is put away: a playtest runs. Null: it may. */
  openBlocked?(): string | null;
  /** The build in the inspector's words (`inspector.ts`' `stateWords`). */
  buildWords(state: Source['state']): string;
  /** Wait a frame or so: a build state settling after an open. */
  later?(ms: number): Promise<void>;
}

/** What `GET params` answered, as the tools say each parameter (`paramFacts`, the server's too). */
const paramsOf = (answer: Awaited<ReturnType<Editing['agent']['params']>>): ModelParamFacts[] | null => (answer && answer.ok ? paramFacts(answer) : null);

const wait = (ms: number): Promise<void> => new Promise((resolve) => setTimeout(resolve, ms));

export function createModelAgent(parts: ModelAgentParts): PageModel {
  const { source, editing, history } = parts;
  const later = parts.later ?? wait;

  const agent: PageModel = {
    path: () => source.path,
    async open(path, discard) {
      const problem = scriptProblem(path);
      if (problem) return { problem };
      // Everything that could refuse the open is asked first: a preview is put away only by an open that happens.
      if (editing.writing) return { problem: 'The Model tab is writing a change: try again in a moment' };
      const blocked = parts.openBlocked?.() ?? null;
      if (blocked) return { problem: `${path} was not opened: ${blocked}` };
      const previewed = editing.previewing && source.path !== null ? source.path : null;
      if (previewed !== null && !discard) return { problem: `The Model tab shows a preview of ${previewed.split('/').pop()} at values nobody wrote: open another with discard: true to put it away, or set them (model_params_set)` };
      if (!parts.openModel(path)) return { problem: `${path} was not opened: the editor is busy -- the status line says why${previewed !== null ? '; the preview is still shown, nothing put away' : ''}` };
      // Opened: another model's open put the preview away with it; the same model asked again keeps it, so it goes here.
      if (previewed !== null && editing.previewing) editing.agent.unpreview();
      const discarded = previewed !== null;
      // Its build state as it comes: the index read, the export decoded -- at most a few seconds.
      for (let i = 0; i < 50 && source.state.kind === 'loading'; i++) await later(100);
      return { discarded };
    },
    async facts(): Promise<ModelFacts | null> {
      const script = source.path;
      if (script === null) return null;
      const answer = await editing.agent.params();
      const text = editing.scriptText();
      const { tree, selected, hidden } = parts.parts();
      const state = source.state;
      return {
        script,
        export: source.exportPath,
        build: state.kind,
        buildWords: parts.buildWords(state),
        error: state.kind === 'failed' ? state.error : state.kind === 'unmade' ? state.reason : null,
        parts: { count: tree?.all.length ?? 0, names: (tree?.all ?? []).slice(0, 200).map((p) => p.name), selected, hidden },
        materials: editing.agent.materials(),
        clips: parts.clips(),
        actions: text === null ? [] : declaredActions(text).map((a) => ({ name: a.name, fps: a.fps, keys: a.keys.map((k) => Number(k.time.toFixed(3))), ...(a.problem ? { problem: a.problem } : {}) })),
        params: paramsOf(answer),
        previewing: editing.previewing,
        history: { labels: [...history.labels], done: history.done },
      };
    },
    async setParams(values, bake) {
      const script = source.path;
      if (!script) return { problem: 'No model is open in the Model tab: model_open opens one' };
      const r = await editing.agent.setParams(values, bake);
      if ('problem' in r) return r;
      return { ...r, files: bake ? [script, recordPath(script)] : [recordPath(script)] };
    },
    preview: (values) => editing.agent.preview(values),
    unpreview: () => editing.agent.unpreview(),
    async export() {
      if (!source.path) return { problem: 'No model is open in the Model tab: model_open opens one' };
      if (source.state.kind === 'excluded') return { problem: 'Out of the build: never exported -- tick it in the Assets panel to build it' };
      if (source.state.kind === 'gone') return { problem: 'Not there: the script was renamed, moved or deleted' };
      const jobs = await source.exportNow();
      if (jobs === null) return { problem: 'Not exported: this page may not export, or the export was refused -- the banner says why' };
      return { jobs };
    },
    async setMaterial(name, set) {
      const script = source.path;
      if (!script) return { problem: 'No model is open in the Model tab: model_open opens one' };
      const fields: Partial<Record<MaterialField, MaterialValue>> = {};
      for (const [field, value] of Object.entries(set)) {
        if (!(MATERIAL_FIELDS as readonly string[]).includes(field)) return { problem: `${field} is no material field: ${MATERIAL_FIELDS.join(', ')}` };
        fields[field as MaterialField] = value;
      }
      if (!editing.agent.materials().some((m) => m.name === name && m.declared)) {
        return { problem: `${name} is no material{} of ${script.split('/').pop()}: the declared ones are ${editing.agent.materials().filter((m) => m.declared).map((m) => m.name).join(', ') || 'none'}` };
      }
      const r = await editing.agent.setMaterial(name, fields);
      return 'problem' in r ? r : { label: r.label, files: [script] };
    },
    async pose(clip, at, joints) {
      const script = source.path;
      if (!script) return { problem: 'No model is open in the Model tab: model_open opens one' };
      const blocked = editing.agent.blocked();
      if (blocked) return { problem: blocked };
      const text = editing.scriptText();
      if (text === null) return { problem: 'The script is not read yet: try again in a moment' };
      const action = declaredActions(text).find((a) => a.name === clip);
      if (!action) return { problem: `${script.split('/').pop()} declares no action{name="${clip}"}: its actions are ${declaredActions(text).map((a) => a.name).join(', ') || 'none'}` };
      if ((at.time === undefined) === (at.frame === undefined)) return { problem: 'Say when: time (seconds) or frame -- one of them' };
      const time = at.time ?? at.frame! / action.fps;
      const names = Object.keys(joints);
      if (names.length === 0) return { problem: 'No joint given' };
      const edits: Record<string, JointEdit> = {};
      for (const [joint, j] of Object.entries(joints)) {
        const turned = j.forward !== undefined || j.left !== undefined || j.twist !== undefined;
        if (!turned && !j.translate) return { problem: `${joint}: give forward, left, twist (degrees) or translate` };
        // The readable trio alone (`trioOnly`): a key spelling the joint with rotate or orient is refused by poseEdit
        // before it edits, so these orient and rotate are never read.
        edits[joint] = {
          ...(turned ? { rotation: { forward: j.forward ?? 0, left: j.left ?? 0, twist: j.twist ?? 0, orient: [Number.NaN, Number.NaN, Number.NaN], rotate: [Number.NaN, Number.NaN, Number.NaN] } } : {}),
          ...(j.translate ? { translate: j.translate } : {}),
        };
      }
      const frame = Math.round(time * action.fps);
      const label = `Key: ${names.join(', ')} ${names.some((n) => joints[n]!.translate) ? (names.some((n) => joints[n]!.forward !== undefined || joints[n]!.left !== undefined || joints[n]!.twist !== undefined) ? 'rot+move' : 'move') : 'rot'} at ${clip} ${frame}`;
      let note = '';
      let problem: string | null = null;
      const pushed = await editing.editScript(label, (now) => {
        const r = poseEdit(now, { clip, time, joints: edits, trioOnly: true });
        if ('problem' in r) {
          problem = r.problem;
          return r;
        }
        note = r.note;
        return r.text;
      });
      if (!pushed) return { problem: problem ?? 'Not written: the status line says why' };
      return { label, note, time: Number(time.toFixed(3)), files: [script] };
    },
  };
  return agent;
}
