/**
 * The stats overlay's numbers (Docs/modeler.md M12; Vibe3D D111): Objects,
 * Vertices, Edges, Faces and Triangles -- `selected / total` while parts are
 * selected -- pure, so a node test holds the rules (`stats.test.ts`).
 *
 * - **Vertices, edges and faces are the kernel's** (`GET model`, M4) for a
 *   part whose kernel node has the same triangles: the mesh the script
 *   builds, as Blender would count it. The GLB cannot give faces, nor edges a
 *   diagonal is not among, and it splits a flat-shaded vertex per face.
 * - **Matched by name**, the kernel's put through GLTFLoader's own rule --
 *   sanitised, a repeat suffixed `_1`, `_2` -- and **checked by triangles**: a
 *   count from another build, or a name matched wrongly, is never borrowed.
 * - **Without the kernel's answer** (an older Gladius, a failed query, a
 *   merged export whose nodes are not the script's): the GLB's -- vertices as
 *   stored, the triangles' own edges, triangles as faces.
 * - **Bones are no objects**: a rigged figure is one object, not thirty.
 */
import * as THREE from 'three';
import type { ModelNode } from '@vibe/pipeline/assets-types';
import type { Part, PartTotals } from './parts.ts';
import { count } from './parts.ts';

export interface Totals {
  objects: number;
  vertices: number;
  edges: number;
  faces: number;
  triangles: number;
}

/** The kernel's nodes by the name three.js gives the node made of each (GLTFLoader's `createUniqueName`). */
export function kernelByName(nodes: readonly ModelNode[]): Map<string, ModelNode> {
  const out = new Map<string, ModelNode>();
  const used = new Map<string, number>();
  for (const node of nodes) {
    const base = THREE.PropertyBinding.sanitizeNodeName(node.name);
    const seen = used.get(base);
    used.set(base, seen === undefined ? 0 : seen + 1);
    out.set(seen === undefined ? base : `${base}_${seen + 1}`, node);
  }
  return out;
}

/** The distinct edges of a geometry's triangles, by index: the fallback's edge count. Kept per geometry. */
const triangleEdges = new WeakMap<THREE.BufferGeometry, number>();

export function edgesOf(geometry: THREE.BufferGeometry): number {
  const cached = triangleEdges.get(geometry);
  if (cached !== undefined) return cached;
  const index = geometry.getIndex();
  const stride = geometry.getAttribute('position')?.count ?? 0;
  const n = index ? index.count : stride;
  const at = (i: number): number => (index ? index.getX(i) : i);
  const edges = new Set<number>();
  for (let i = 0; i + 2 < n; i += 3) {
    const a = at(i);
    const b = at(i + 1);
    const c = at(i + 2);
    // One number a pair, exact while stride² stays under 2^53.
    edges.add(a < b ? a * stride + b : b * stride + a);
    edges.add(b < c ? b * stride + c : c * stride + b);
    edges.add(c < a ? c * stride + a : a * stride + c);
  }
  triangleEdges.set(geometry, edges.size);
  return edges.size;
}

/** One part's vertices, edges and faces: the kernel's where it holds this mesh, else the GLB's. */
export function countsOf(part: Part, kernel: ReadonlyMap<string, ModelNode>): { vertices: number; edges: number; faces: number; kernel: boolean } {
  const node = kernel.get(part.object.name);
  if (node && node.triangles === part.triangles) return { vertices: node.vertices, edges: node.edges, faces: node.faces, kernel: true };
  const geometry = (part.object as THREE.Mesh).geometry;
  return { vertices: part.vertices, edges: geometry ? edgesOf(geometry) : 0, faces: part.triangles, kernel: false };
}

/** The totals over these parts -- each once, as given. */
export function statsOf(parts: readonly Part[], kernel: ReadonlyMap<string, ModelNode>): Totals {
  const totals: Totals = { objects: 0, vertices: 0, edges: 0, faces: 0, triangles: 0 };
  for (const part of parts) {
    if (part.kind === 'bone') continue;
    totals.objects++;
    if (part.kind !== 'mesh' && part.kind !== 'skinned') continue;
    const c = countsOf(part, kernel);
    totals.vertices += c.vertices;
    totals.edges += c.edges;
    totals.faces += c.faces;
    totals.triangles += part.triangles;
  }
  return totals;
}

/** The overlay's rows: a name and its value, `selected / total` while something is selected. */
export function statsRows(whole: Totals, picked: Totals | null): [string, string][] {
  const rows: [string, keyof Totals][] = [['Objects', 'objects'], ['Vertices', 'vertices'], ['Edges', 'edges'], ['Faces', 'faces'], ['Triangles', 'triangles']];
  return rows.map(([label, key]) => [label, picked ? `${count(picked[key])} / ${count(whole[key])}` : count(whole[key])]);
}

/**
 * A totals line's numbers over these parts (Docs/modeler.md M12): the
 * kernel's vertices where it holds every mesh among them -- one figure with the
 * stats overlay's and the part panel's -- else the GLB's, `stored`.
 */
export function partTotals(parts: readonly Part[], kernel: ReadonlyMap<string, ModelNode>): PartTotals {
  const totals: PartTotals = { objects: 0, triangles: 0, vertices: 0, stored: false };
  let stored = 0;
  for (const part of parts) {
    if (part.kind === 'bone') continue;
    totals.objects++;
    if (part.kind !== 'mesh' && part.kind !== 'skinned') continue;
    const c = countsOf(part, kernel);
    totals.triangles += part.triangles;
    totals.vertices += c.vertices;
    stored += part.vertices;
    if (!c.kernel) totals.stored = true;
  }
  if (totals.stored) totals.vertices = stored;
  return totals;
}
