/**
 * The Parameters block's reading of `GET params` (Docs/modeler.md M22): for
 * the script open, and that one alone.
 *
 * - **The path is the one opened**, given to `open` -- never asked of the tab
 *   afterwards, which may still name the script before (it is opened after).
 * - **One read in flight per opening, one waiting**: a read asked while one is
 *   out runs once after it, reading the script as it is then. Another script
 *   opened starts afresh: a read still out for the one before is let go, and
 *   its answer, when it comes, dropped -- never shown over the new script's,
 *   never one the new script's waits behind.
 * - **What may be written is the open script's**: `spec` answers a parameter
 *   only from an answer for the script open now, so a row left from another
 *   script -- or a name the script no longer declares -- is never committed
 *   into this one's record.
 *
 * Handed its fetch (`param-reader.test.ts`); no DOM.
 */
import type { ParamSpec, ParamsAnswer } from '@vibe/pipeline/assets-types';

export interface ParamReader {
  /** The script open, as given to `open`. */
  readonly path: string | null;
  /** Its answer, once read; null before, and for none open. */
  readonly answer: ParamsAnswer | null;
  /** A first read is out: nothing to show yet. */
  readonly reading: boolean;
  /** Another script, or none: what was read is let go. */
  open(path: string | null): void;
  /** Read again -- after it if one is out. Resolves once this opening's reads are done. */
  read(): Promise<void>;
  /** `name` as the open script declares it, by the latest answer for it -- undefined if it does not. */
  spec(name: string): ParamSpec | undefined;
}

export function createParamReader(fetch: (path: string) => Promise<ParamsAnswer>, changed: () => void): ParamReader {
  let path: string | null = null;
  let answer: ParamsAnswer | null = null;
  /** Bumped by every `open`: a read for an opening before is let go. */
  let ticket = 0;
  /** The opening whose read is out, if one is. */
  let out: number | null = null;
  let again = false;
  let reading = false;

  async function read(): Promise<void> {
    const at = path;
    if (at === null) return;
    const mine = ticket;
    if (out === mine) {
      again = true;
      return;
    }
    out = mine;
    reading = answer === null;
    changed();
    let got: ParamsAnswer;
    try {
      got = await fetch(at);
    } catch (err) {
      got = { ok: false, ms: 0, params: null, set: {}, own: {}, diagnostics: [], problem: (err as Error).message };
    }
    // Another script opened meanwhile: this answer is not its, and its own reads went on without waiting for this.
    if (mine !== ticket) return;
    out = null;
    reading = false;
    answer = got;
    changed();
    if (again) {
      again = false;
      await read();
    }
  }

  return {
    get path() {
      return path;
    },
    get answer() {
      return answer;
    },
    get reading() {
      return reading;
    },
    open(next) {
      ticket++;
      path = next;
      answer = null;
      out = null;
      again = false;
      reading = false;
      changed();
    },
    read,
    spec(name) {
      return answer?.params?.find((p) => p.name === name);
    },
  };
}
