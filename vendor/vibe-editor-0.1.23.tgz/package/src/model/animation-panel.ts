/**
 * The Model tab's animation controls (Docs/modeler.md §4, M31-M33; Vibe3D
 * D89, D91, D121, D122), in two places: the **transport strip** along the
 * views' foot -- where the time is looked at -- and the **Animation block** in
 * the right panel -- what the clips are, the bones, the pose.
 *
 * - **The strip** (shown while the model has clips): a timeline the views'
 *   width, a tick a frame (every nth where they would crowd), the script's
 *   keys of the clip as diamonds (a click goes to one), the playhead; under it
 *   to the start, a frame back, play or pause, a frame on, to the end, the clip
 *   (a list: the rest pose and each clip), the clock (`frame 6 / 15 · 0.200
 *   s`), the speed and Loop. A drag on the timeline scrubs, frame by frame.
 * - **The block** (shown while the model has clips or bones): each clip -- its
 *   length, frames, rate and whether it loops -- a click plays it from its
 *   start; Bones; and **Pose**: the bone chosen and the frame held, its turn
 *   in Gladius's words as three fields (forward, left, twist, degrees) and its
 *   move as three (metres, world axes), Rotate or Move for the gizmo (and
 *   Scale, which says why there is none), Reset, **Key**, Auto key; under them
 *   the line that says what is so -- and, when a key cannot be written, why.
 * - **Drawn from a view of the state** (`draw`), the clock alone each frame
 *   while playing (`tick`): nothing is made again under the pointer.
 */
import { keyLabel } from '@vibe/engine/debug';
import { button, control, el, icon, iconButton, tip } from '../dom.ts';
import { numberField, type NumberField } from '../fields.ts';
import { letGo } from '../shell.ts';
import { clipWords, clockWords, frameAt, framesOf, SPEEDS, ticksOf, type ClipInfo } from './clips.ts';
import type { PoseMode, Readout } from './posing.ts';
import { RAMP_CSS, weightWords, type WeightFacts } from './weights.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import type { Mcp } from '../mcp/declare.ts';
import { tabKey } from '../editor-keys.ts';

/** Why the Scale button and R do nothing but say so. */
export const SCALE_WHY = 'Gladius bones have no scale: a key turns and moves a joint; its length is the rest skeleton\'s (move_joint), the same in every clip';

export interface AnimationPanelHost {
  /** A clip chosen -- `play`: from the list, played from its start; from the strip's list, held at its first frame. */
  choose(name: string | null, play: boolean): void;
  toggle(): void;
  step(by: number): void;
  toStart(): void;
  toEnd(): void;
  /** The timeline pressed or dragged to a time. */
  seek(time: number): void;
  setSpeed(speed: number): void;
  setLoop(on: boolean): void;
  setBones(on: boolean): void;
  setMode(mode: PoseMode | 'scale'): void;
  /** A computed key's way forward: words in the Claude card's box, not sent. */
  ask(): void;
  /** A key smoothed away by the export: the record's anim to 0, the export made again. */
  keepEveryKey(): void;
  /** Typed numbers: the bone turned and moved to them, live; `done` as a field is let go. */
  setNumbers(values: { forward: number; left: number; twist: number; translate: [number, number, number] }, done: boolean): void;
  reset(): void;
  key(): void;
  setAuto(on: boolean): void;
  folded(folded: boolean): void;
  say(text: string): void;
}

/** What the controls show. */
export interface AnimationView {
  clips: readonly ClipInfo[];
  current: ClipInfo | null;
  time: number;
  playing: boolean;
  speed: number;
  loop: boolean;
  /** Has the model bones: the Bones switch and the pose are offered. */
  rigged: boolean;
  bones: boolean;
  /** The script's keys of the clip shown, in seconds; null where it has none to show (an imported clip). */
  keys: readonly number[] | null;
  pose: {
    /** The bones selected, by name, and the one posed (the first). */
    bones: readonly string[];
    readout: Readout | null;
    mode: PoseMode;
    auto: boolean;
    /** Typing is offered: a frame held, a bone chosen. */
    editable: boolean;
    /** Why Key cannot write now, or null. */
    blocked: string | null;
    /** The last word about a key: written, or refused. */
    message: { text: string; ok: boolean } | null;
    /** The selected bones' weight map, or null. */
    weights: WeightFacts | null;
    /** The frame held is a computed key: Ask Claude offered. */
    ask: boolean;
    /** The last key was smoothed away by the export: Keep every key offered. */
    keepKeys: boolean;
  };
}

export interface AnimationPanel {
  /** The right panel's block. */
  readonly block: HTMLElement;
  /** The transport strip, along the views' foot. */
  readonly strip: HTMLElement;
  draw(view: AnimationView): void;
  /** The clock and the playhead alone: each frame while playing. */
  tick(view: Pick<AnimationView, 'current' | 'time' | 'playing'>): void;
  setFolded(folded: boolean): void;
  /** A pose field being typed in: the arrows and Space are the field's. */
  readonly typing: boolean;
}

const SPEED_WORDS: Readonly<Record<number, string>> = { 0.25: '¼×', 0.5: '½×', 1: '1×', 2: '2×' };

export function createAnimationPanel(host: AnimationPanelHost): AnimationPanel {
  // ---------------------------------------------------------------- the strip

  const strip = el('div', 'ed-mo-strip');
  strip.hidden = true;
  const line = el('div', 'ed-mo-timeline');
  line.setAttribute('role', 'slider');
  line.setAttribute('aria-label', 'The clip\'s time: drag to scrub, frame by frame');
  const ticks = el('div', 'ed-mo-ticks');
  const keysEl = el('div', 'ed-mo-keys');
  const head = el('div', 'ed-mo-playhead');
  line.append(ticks, keysEl, head);
  const controls = el('div', 'ed-mo-transport');
  const tbtn = (mcp: Mcp, glyph: Parameters<typeof icon>[0], run: () => void): HTMLButtonElement => {
    const b = letGo(control(mcp, 'ed-bar-button'));
    b.append(icon(glyph));
    b.addEventListener('click', run);
    return b;
  };
  const startB = tbtn('ui', 'toStart', () => host.toStart());
  const backB = tbtn('ui', 'stepBack', () => host.step(-1));
  const playB = tbtn('ui', 'play', () => host.toggle());
  const onB = tbtn('ui', 'stepOn', () => host.step(1));
  const endB = tbtn('ui', 'toEnd', () => host.toEnd());
  tip(startB, 'To the clip\'s start', keyLabel('Shift+ArrowLeft'));
  tip(backB, 'A frame back, at the clip\'s rate', keyLabel('ArrowLeft'));
  tip(onB, 'A frame on, at the clip\'s rate', keyLabel('ArrowRight'));
  tip(endB, 'To the clip\'s end', keyLabel('Shift+ArrowRight'));
  const clipSel = el('select', 'ed-mo-clip-select');
  clipSel.title = 'The clip shown -- or the rest pose, the model as the script builds it';
  clipSel.addEventListener('change', () => {
    host.choose(clipSel.value === '' ? null : clipSel.value, false);
    clipSel.blur();
  });
  const clock = el('span', 'ed-mo-clock');
  const speedSel = el('select', 'ed-mo-speed');
  speedSel.title = 'Playback speed';
  for (const s of SPEEDS) speedSel.append(new Option(SPEED_WORDS[s] ?? `${s}×`, String(s)));
  speedSel.addEventListener('change', () => {
    host.setSpeed(Number(speedSel.value));
    speedSel.blur();
  });
  const loopLabel = el('label', 'ed-mo-check');
  const loopBox = el('input');
  loopBox.type = 'checkbox';
  loopLabel.append(loopBox, el('span', undefined, 'Loop'));
  loopLabel.title = 'Wrap round at the end -- as the action\'s own loop says, until changed here (for this clip, this session)';
  loopBox.addEventListener('change', () => {
    host.setLoop(loopBox.checked);
    loopBox.blur();
  });
  // Key and Auto key here too: where the eye is while posing, never below the right panel's fold (1024×700).
  const stripKey = tbtn('model_pose', 'keyframe', () => host.key());
  stripKey.classList.add('ed-mo-strip-key');
  stripKey.append(el('span', undefined, 'Key'));
  const stripAuto = el('label', 'ed-mo-check');
  const stripAutoBox = el('input');
  stripAutoBox.type = 'checkbox';
  stripAuto.append(stripAutoBox, el('span', undefined, 'Auto'));
  stripAuto.title = 'Auto key: write the key as a bone is let go';
  stripAutoBox.addEventListener('change', () => {
    host.setAuto(stripAutoBox.checked);
    stripAutoBox.blur();
  });
  controls.append(startB, backB, playB, onB, endB, clipSel, clock, speedSel, loopLabel, stripKey, stripAuto);
  strip.append(line, controls);

  // The timeline: a press or a drag scrubs, frame by frame; a key's diamond goes to that key.
  let shownClip: ClipInfo | null = null;
  const timeAt = (clientX: number): number => {
    const r = line.getBoundingClientRect();
    const share = Math.min(1, Math.max(0, (clientX - r.left) / Math.max(1, r.width)));
    return share * (shownClip?.duration ?? 0);
  };
  let scrubbing: number | null = null;
  line.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || !shownClip) return;
    event.preventDefault();
    scrubbing = event.pointerId;
    line.setPointerCapture(event.pointerId);
    const key = (event.target as HTMLElement).closest<HTMLElement>('.ed-mo-key');
    host.seek(key ? Number(key.dataset.time) : timeAt(event.clientX));
  });
  line.addEventListener('pointermove', (event) => {
    if (scrubbing === event.pointerId) host.seek(timeAt(event.clientX));
  });
  const endScrub = (event: PointerEvent): void => {
    if (scrubbing !== event.pointerId) return;
    scrubbing = null;
    if (line.hasPointerCapture(event.pointerId)) line.releasePointerCapture(event.pointerId);
  };
  line.addEventListener('pointerup', endScrub);
  line.addEventListener('pointercancel', endScrub);

  // ---------------------------------------------------------------- the block

  const block = el('section', 'ed-mo-sec ed-mo-anim');
  block.hidden = true;
  const bhead = el('div', 'ed-mo-sec-head');
  const caret = control('ui', 'ed-mo-sec-caret');
  const title = el('span', 'ed-mo-sec-title', 'Animation');
  const count = el('span', 'ed-mo-sec-count');
  const ends = el('span', 'ed-mo-sec-ends');
  const bonesB = button('ui', 'Bones', '', () => host.setBones(bonesB.getAttribute('aria-pressed') !== 'true'), 'ed-small ed-quiet');
  ends.append(bonesB);
  bhead.append(caret, title, count, ends);
  const list = el('div', 'ed-mo-clips');
  const poseEl = el('div', 'ed-mo-pose');
  const status = el('div', 'ed-mo-sec-status');
  const body = el('div', 'ed-mo-sec-body');
  body.append(list, poseEl, status);
  block.append(bhead, body);
  let folded = false;
  const fold = (next: boolean): void => {
    folded = next;
    block.classList.toggle('ed-mo-shut', folded);
    caret.textContent = folded ? '▸' : '▾';
    caret.title = folded ? 'Show the clips and the pose' : 'Fold the clips and the pose away';
  };
  fold(false);
  const toggleFold = (): void => {
    fold(!folded);
    host.folded(folded);
  };
  caret.addEventListener('click', toggleFold);
  // mcp: ui -- the section folded
  title.addEventListener('click', toggleFold);

  // The pose: what is posed, its numbers, its buttons.
  const target = el('div', 'ed-mo-pose-target');
  const modes = el('div', 'ed-mo-seg');
  /** A mode's button, its tip naming its key as the keymap has it when the pointer comes onto it (Docs/navigation.md §8: W E R or G R S). */
  const modeB = (mode: PoseMode | 'scale', words: string, glyph: Parameters<typeof icon>[0], why: () => string): HTMLButtonElement => {
    const b = iconButton('ui', glyph, why(), () => host.setMode(mode), 'ed-mo-seg-b');
    b.addEventListener('pointerenter', () => (b.title = why()));
    b.append(el('span', undefined, words));
    return b;
  };
  // In the keys' order, as the Scene tab's gizmo buttons are.
  const moveB = modeB('translate', 'Move', 'move', () => `The gizmo moves the bone off its rest place: its arrows (${keyLabel(tabKey('model pose move'))})`);
  const rotateB = modeB('rotate', 'Rotate', 'rotate', () => `The gizmo turns the bone: its rings (${keyLabel(tabKey('model pose rotate'))})`);
  const scaleB = modeB('scale', 'Scale', 'scale', () => `${SCALE_WHY} (${keyLabel(tabKey('model pose scale'))})`);
  scaleB.classList.add('ed-mo-seg-off');
  modes.append(moveB, rotateB, scaleB);
  const values = { forward: 0, left: 0, twist: 0, x: 0, y: 0, z: 0 };
  let typingIn = false;
  const send = (done: boolean): void => host.setNumbers({ forward: values.forward, left: values.left, twist: values.twist, translate: [values.x, values.y, values.z] }, done);
  const field = (key: keyof typeof values, label: string, unit: 'deg' | 'm', title: string): NumberField => {
    const f = numberField({
      label,
      value: 0,
      step: unit === 'deg' ? 1 : 0.001,
      digits: unit === 'deg' ? 2 : 4,
      title,
      set(v) {
        values[key] = v;
        send(false);
      },
      commit() {
        send(true);
      },
    });
    f.input.addEventListener('focus', () => void (typingIn = true));
    f.input.addEventListener('blur', () => void (typingIn = false));
    return f;
  };
  const fields = {
    forward: field('forward', 'forward °', 'deg', 'forward: the bone\'s tail swung toward +Z, the model\'s front -- degrees from its rest, as the key\'s forward ='),
    left: field('left', 'left °', 'deg', 'left: the bone\'s tail swung toward +X, the model\'s left -- degrees from its rest, as the key\'s left ='),
    twist: field('twist', 'twist °', 'deg', 'twist: the bone turned about its own length -- degrees from its rest, as the key\'s twist ='),
    x: field('x', 'move x', 'm', 'Moved along the model\'s X from its rest place, metres (the key\'s translate)'),
    y: field('y', 'y', 'm', 'Moved along the model\'s Y from its rest place, metres (the key\'s translate)'),
    z: field('z', 'z', 'm', 'Moved along the model\'s Z from its rest place, metres (the key\'s translate)'),
  };
  const cells = (...fs: NumberField[]): HTMLElement => {
    const row = el('div', 'ed-mo-pose-fields');
    for (const f of fs) {
      const cell = el('div', 'ed-mo-pose-cell');
      cell.append(f.label);
      row.append(cell);
    }
    return row;
  };
  const turnRow = cells(fields.forward, fields.left, fields.twist);
  const moveRow = cells(fields.x, fields.y, fields.z);
  const actions = el('div', 'ed-buttons ed-mo-pose-actions');
  const resetB = button('ui', 'Reset', 'The clip\'s own pose again: the edit dropped', () => host.reset(), 'ed-small ed-quiet');
  const keyB = button('model_pose', 'Key', '', () => host.key(), 'ed-small ed-accent');
  const autoLabel = el('label', 'ed-mo-check');
  const autoBox = el('input');
  autoBox.type = 'checkbox';
  autoLabel.append(autoBox, el('span', undefined, 'Auto key'));
  autoLabel.title = 'Write the key as a bone is let go -- the gizmo released, a field typed in and left -- instead of pressing Key: each one an edit of the script and a build';
  autoBox.addEventListener('change', () => {
    host.setAuto(autoBox.checked);
    autoBox.blur();
  });
  actions.append(resetB, keyB, autoLabel);
  const weightEl = el('div', 'ed-mo-weights');
  const ramp = el('span', 'ed-mo-ramp');
  ramp.style.background = RAMP_CSS;
  ramp.title = 'Weight 0 (blue) to 1 (red): how much the selected bones move each vertex';
  const weightWordsEl = el('span');
  weightEl.append(ramp, weightWordsEl);
  const why = el('div', 'ed-mo-pose-why');
  const whyWords = el('span');
  const askB = button(NOT_FOR_CLAUDE.askClaude, 'Ask Claude to change this key', 'Words naming the clip, the time, the bone and the call put in the Claude card\'s box -- for you to finish and send, not sent', () => host.ask(), 'ed-small');
  const keepB = button('asset_options', 'Keep every key (anim 0) and rebuild', 'The record\'s anim set to 0 -- every sample kept -- the model exported again: one step, Z takes it back', () => host.keepEveryKey(), 'ed-small ed-accent');
  why.append(whyWords, askB, keepB);
  poseEl.append(el('div', 'ed-mo-sub', 'Pose'), target, modes, turnRow, moveRow, actions, why, weightEl);

  // ---------------------------------------------------------------- drawing

  let listShape = '';
  let rows: HTMLButtonElement[] = [];
  let tickShape = '';

  function drawList(view: AnimationView): void {
    const shape = view.clips.map((c) => `${c.name}|${c.duration}|${c.fps}|${c.loop}`).join(';');
    if (shape !== listShape) {
      listShape = shape;
      const rest = letGo(control('ui', 'ed-mo-clip'));
      rest.append(el('span', 'ed-mo-clip-name', 'rest pose'), el('span', 'ed-mo-clip-meta', 'as the script builds it'));
      rest.title = 'The model with no clip on it: what the script builds, and what the polygons are drawn on';
      rest.addEventListener('click', () => host.choose(null, false));
      rows = [rest];
      for (const c of view.clips) {
        const row = letGo(control('ui', 'ed-mo-clip'));
        row.dataset.name = c.name;
        row.append(el('span', 'ed-mo-clip-name', c.name), el('span', 'ed-mo-clip-meta', ''));
        row.title = `${c.name}: ${c.duration.toFixed(3)} s at ${c.fps} fps, ${c.loop === undefined ? 'looping unsaid (an imported clip)' : c.loop ? 'looping' : 'once'} -- it moves ${c.joints.length} ${c.joints.length === 1 ? 'joint' : 'joints'}: ${c.joints.slice(0, 24).join(', ')}${c.joints.length > 24 ? '…' : ''}. A click plays it from its start`;
        row.addEventListener('click', () => host.choose(c.name, true));
        rows.push(row);
      }
      list.replaceChildren(...rows);
      // The strip's list of clips, the same.
      clipSel.replaceChildren(new Option('rest pose', ''), ...view.clips.map((c) => new Option(c.name, c.name)));
    }
    rows.forEach((row, i) => {
      const clip = i === 0 ? null : view.clips[i - 1]!;
      row.setAttribute('aria-pressed', String(clip ? view.current?.name === clip.name : view.current === null));
      if (clip) {
        const meta = row.lastElementChild as HTMLElement;
        const words = clipWords(clip, view.current?.name === clip.name ? view.loop : (clip.loop ?? true));
        if (meta.textContent !== words) meta.textContent = words;
      }
    });
    const value = view.current?.name ?? '';
    if (clipSel.value !== value) clipSel.value = value;
  }

  function drawTimeline(view: AnimationView): void {
    const clip = view.current;
    shownClip = clip;
    line.classList.toggle('ed-mo-off', !clip);
    const shape = clip ? `${clip.name}|${clip.duration}|${clip.fps}|${(view.keys ?? []).join(',')}|${line.clientWidth}` : '';
    if (shape !== tickShape) {
      tickShape = shape;
      ticks.replaceChildren();
      keysEl.replaceChildren();
      if (clip && clip.duration > 0) {
        const most = Math.max(4, Math.floor(line.clientWidth / 6));
        const { every, frames } = ticksOf(clip, most);
        for (const f of frames) {
          const mark = el('i', f % (every * 5) === 0 ? 'ed-mo-tick ed-mo-tick-major' : 'ed-mo-tick');
          mark.style.left = `${(Math.min(clip.duration, f / clip.fps) / clip.duration) * 100}%`;
          ticks.append(mark);
        }
        for (const time of view.keys ?? []) {
          if (time < 0 || time > clip.duration + 1e-6) continue;
          const k = el('i', 'ed-mo-key');
          k.style.left = `${(time / clip.duration) * 100}%`;
          k.dataset.time = String(time);
          k.title = `A key of ${clip.name}'s action{} at ${Number(time.toFixed(3))} s (frame ${frameAt(clip, time)}): click to go to it`;
          keysEl.append(k);
        }
      }
    }
  }

  function drawClock(view: Pick<AnimationView, 'current' | 'time' | 'playing'>): void {
    const clip = view.current;
    head.hidden = !clip;
    if (clip) head.style.left = `${clip.duration > 0 ? (view.time / clip.duration) * 100 : 0}%`;
    const words = clip ? clockWords(clip, view.time) : 'rest pose';
    if (clock.textContent !== words) clock.textContent = clock.title = words;
    line.setAttribute('aria-valuenow', clip ? String(frameAt(clip, view.time)) : '0');
    line.setAttribute('aria-valuemax', clip ? String(framesOf(clip)) : '0');
    const playing = view.playing;
    if (playB.dataset.playing !== String(playing)) {
      playB.dataset.playing = String(playing);
      playB.replaceChildren(icon(playing ? 'pause' : 'play'));
      tip(playB, playing ? 'Pause: held on the frame shown' : 'Play the clip -- the first, from the rest pose', keyLabel('Space'));
    }
  }

  function drawPose(view: AnimationView): void {
    const p = view.pose;
    poseEl.hidden = !view.rigged;
    const r = p.readout;
    const clip = view.current;
    const at = clip ? `${clip.name} · frame ${frameAt(clip, view.time)} (${Number(view.time.toFixed(3))} s)` : 'the rest pose';
    target.textContent = p.bones.length === 0
      ? 'Select a bone -- in the outliner, or with Bones on, in a view -- to see its weights and pose it'
      : `${r?.joint ?? p.bones[0]}${p.bones.length > 1 ? ` (+${p.bones.length - 1})` : ''} · ${at}`;
    target.classList.toggle('ed-dim', p.bones.length === 0);
    rotateB.setAttribute('aria-pressed', String(p.mode === 'rotate'));
    moveB.setAttribute('aria-pressed', String(p.mode === 'translate'));
    const show = (f: NumberField, value: number | undefined): void => f.show(value === undefined ? undefined : value);
    if (!typingIn) {
      values.forward = r?.forward ?? 0;
      values.left = r?.left ?? 0;
      values.twist = r?.twist ?? 0;
      [values.x, values.y, values.z] = r?.translate ?? [0, 0, 0];
    }
    show(fields.forward, r?.forward);
    show(fields.left, r?.left);
    show(fields.twist, r?.twist);
    show(fields.x, r?.translate[0]);
    show(fields.y, r?.translate[1]);
    show(fields.z, r?.translate[2]);
    for (const f of Object.values(fields)) f.input.disabled = !p.editable;
    for (const b of [rotateB, moveB]) b.disabled = !p.editable;
    turnRow.classList.toggle('ed-mo-held', r?.held === true);
    moveRow.classList.toggle('ed-mo-held', r?.held === true);
    resetB.disabled = r?.held !== true;
    keyB.disabled = p.blocked !== null || r?.held !== true;
    keyB.title = p.blocked ?? (r?.held ? `Write this pose into ${clip?.name}'s key at ${Number(view.time.toFixed(3))} s in the script, as it spells it -- one step, Z takes it back (${keyLabel('KeyK')})` : 'Turn the bone first -- the gizmo, or the fields');
    autoBox.checked = p.auto;
    stripAutoBox.checked = p.auto;
    stripKey.hidden = !view.rigged;
    stripAuto.hidden = !view.rigged;
    stripKey.disabled = keyB.disabled;
    tip(stripKey, keyB.title, keyLabel('KeyK'));
    const degenerate = r && r.degenerate.length > 0 ? `${r.joint} points along the ${r.degenerate.join(' and ')} axis: Gladius refuses that swing, so a new joint is keyed as orient. ` : '';
    const said = p.message ?? (p.blocked ? { text: p.blocked, ok: false } : null);
    whyWords.textContent = `${degenerate}${said?.text ?? ''}`.trim();
    askB.hidden = !p.ask;
    keepB.hidden = !p.keepKeys;
    // Red for a fault alone -- a key written whose build failed -- never for why Key waits (a bone to choose, a step
    // shown in the model's place, a frame to hold): those are states, in the line's own dim tone.
    why.classList.toggle('ed-mo-bad', p.message !== null && !p.message.ok);
    why.hidden = whyWords.textContent === '' && !p.ask && !p.keepKeys;
    weightEl.hidden = p.weights === null;
    if (p.weights) {
      weightWordsEl.textContent = `${p.weights.bones.length > 1 ? `${p.weights.bones.length} bones` : p.weights.bones[0]} ${weightWords(p.weights)}`;
      weightEl.title = `The weight map of ${p.weights.bones.join(', ')} on the meshes they deform: dark blue 0 to red 1 -- ${weightWords(p.weights)}`;
    }
  }

  return {
    block,
    strip,
    draw(view) {
      const any = view.clips.length > 0;
      block.hidden = !any && !view.rigged;
      strip.hidden = !any;
      count.textContent = any ? `${view.clips.length} ${view.clips.length === 1 ? 'clip' : 'clips'}` : 'no clips';
      bonesB.hidden = !view.rigged;
      bonesB.setAttribute('aria-pressed', String(view.bones));
      bonesB.title = `The skeleton drawn over the model, posed with it -- a click on a bone's line picks it (${keyLabel('KeyJ')})`;
      list.hidden = !any;
      drawList(view);
      drawTimeline(view);
      drawClock(view);
      if (speedSel.value !== String(view.speed)) speedSel.value = String(view.speed);
      loopBox.checked = view.loop;
      for (const b of [startB, backB, onB, endB]) b.disabled = !view.current;
      playB.disabled = !any;
      loopBox.disabled = !view.current;
      drawPose(view);
      status.textContent = any ? '' : 'No clips: Gladius writes one for each emit_action in the script. The bones and their weights are here all the same.';
      status.hidden = status.textContent === '';
    },
    tick(view) {
      drawClock(view);
    },
    setFolded: fold,
    get typing() {
      return typingIn;
    },
  };
}
