/**
 * The Model tab's keys (Docs/modeler.md §4, M8, M28-M36): every one a MrDebug
 * action (`ctx.keys.add`), listed under Model on the editor's keys card, made
 * here from a small state and the tab's doings -- so the six phases' keys, and
 * which wins where two share one, are one table a node test reads
 * (`model-keys.test.ts`).
 *
 * - **Two on one key say when**: MrDebug takes the first live action in the
 *   order added (`mr-debug.ts`), and refuses two on one key unless both have a
 *   `when`. The pairs here are kept apart by their `when`s, never by order --
 *   at most one is live in any state:
 *   - **Space and ← →**: the clip's transport, or -- a trace step shown -- the
 *     trace's; Shift+← → the same.
 *   - **G and S**: the grid and fly's back, held over a view -- or, a bone being
 *     posed, the pose gizmo's move and scale (the Scene tab's G R S, Blender's);
 *     the grid and fly yield. Under Industry Compatible's keymap the pose gizmo
 *     is W E R and the held flight has no keys (Docs/navigation.md D10, D11).
 *   - **Delete**: the marks in the marquee while painting, else the parts
 *     selected (asking Claude).
 *   - **↑ ↓**: the menu open, else the outliner's rows when they have the focus.
 * - **Esc's order** (`escapeTarget`): a menu, then a marquee, then a trace step
 *   shown, then a bone being posed -- else the editor puts itself away.
 *
 * DOM-free: the state is read through its getters as a key comes, the doings
 * handed in.
 */
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import type { ToolKey } from '../tool.ts';
import { emulatedKeys, viewKeys } from '../view/nav-keys.ts';
import type { Preset } from '../view/views.ts';
import { keyed, keymapNow } from '../editor-keys.ts';

/** What the keys' `when`s read, as a key comes: getters on the tab's state. */
export interface ModelKeyState {
  /** The tab is up. */
  readonly visible: boolean;
  /** A model is shown (its parts' tree). */
  readonly model: boolean;
  /** A script is open, built or not. */
  readonly source: boolean;
  /** The pointer is over a view. */
  readonly hovering: boolean;
  readonly menuOpen: boolean;
  /** The outliner's rows have the focus. */
  readonly inRows: boolean;
  /** Parts selected. */
  readonly selected: number;
  /** Paint mode (the Canvases pane), and the canvas's note not being typed in. */
  readonly painting: boolean;
  readonly marquee: boolean;
  readonly canPaste: boolean;
  /** A canvas open to paste into. */
  readonly canvasOpen: boolean;
  /** The model has clips. */
  readonly clips: boolean;
  /** The model has bones. */
  readonly rigged: boolean;
  /** A bone is being posed (chosen at a held frame). */
  readonly posing: boolean;
  /** A field of the clips' or the pose's is typed in. */
  readonly animTyping: boolean;
  /** A trace step is shown in the views. */
  readonly tracing: boolean;
  /** Emulate Numpad on and the pointer over a 3D view: the digit row, - and = are the numpad (Docs/navigation.md D5). */
  readonly emulating: boolean;
  /** The trace's speed box is typed in. */
  readonly traceTyping: boolean;
}

/** What the keys do: the tab's own doings. */
export interface ModelKeyDoings {
  frame(): void;
  layout(): void;
  shading(): void;
  grid(): void;
  stats(): void;
  /** A numpad view: the side it looks from (`nav-keys.ts`' `NUMPAD_VIEWS`). */
  look(preset: Exclude<Preset, 'free'>): void;
  flip(): void;
  projection(): void;
  /** The numpad's steps (Docs/navigation.md §3): an orbit in turns, a pan in shares of the height seen, a zoom. */
  orbit(dx: number, dy: number): void;
  pan(dx: number, dy: number): void;
  zoom(scale: number): void;
  hide(): void;
  showAll(): void;
  selectAll(): void;
  /** The next row's part in the outliner, up or down. */
  walk(by: 1 | -1): void;
  build(): void;
  /** A fly key went down: the view under the pointer flies while any is held. */
  fly(): void;
  /** Blender's walk in the view under the pointer. */
  walkView(): void;
  /** An arrow key went down over a view: it flies while any arrow is held. */
  arrowFly(): void;
  pane(): void;
  brushOrEraser(): void;
  marquee(): void;
  /** The brush a fifth smaller or bigger. */
  brush(by: 1 | -1): void;
  copyMarks(): void;
  cutMarks(): void;
  pasteMarks(): void;
  deleteMarks(): void;
  deleteParts(): void;
  play(): void;
  frameStep(by: 1 | -1): void;
  clipStart(): void;
  clipEnd(): void;
  key(): void;
  poseMode(mode: 'translate' | 'rotate' | 'scale'): void;
  bones(): void;
  trace(): void;
  tracePlay(): void;
  traceStep(by: 1 | -1): void;
  traceStart(): void;
  traceEnd(): void;
  menuStep(by: 1 | -1): void;
}


/** What Esc lets go of first, in this state -- or nothing, and the editor puts itself away. */
export type EscapeTarget = 'menu' | 'marquee' | 'trace' | 'pose' | null;

export function escapeTarget(s: ModelKeyState): EscapeTarget {
  if (s.menuOpen) return 'menu';
  if (s.painting && s.marquee) return 'marquee';
  if (s.visible && s.tracing && !s.traceTyping) return 'trace';
  if (s.visible && s.posing && !s.animTyping) return 'pose';
  return null;
}

/** The keys' `when`s, named: what the table reads. */
export function keyRules(s: ModelKeyState) {
  const up = (): boolean => s.visible;
  const hasModel = (): boolean => s.visible && s.model;
  const painting = (): boolean => hasModel() && s.painting;
  return {
    up,
    hasModel,
    painting,
    /** The arrows fly: a model in, the pointer over a view, no menu open (Docs/navigation.md §7). */
    arrows: (): boolean => hasModel() && s.hovering && !s.menuOpen,
    /** A fly key flies: a model in, the pointer over a view, no menu open, no bone being posed. */
    flies: (): boolean => hasModel() && s.hovering && !s.menuOpen && !s.posing,
    // The pointer over a view, the arrows fly there; the rows have them otherwise.
    rows: (): boolean => s.visible && s.inRows && !s.menuOpen && !(hasModel() && s.hovering),
    /** The clip's transport: clips, no menu, nothing typed in, no trace step shown. */
    clip: (): boolean => hasModel() && s.clips && !s.menuOpen && !s.animTyping && !s.tracing,
    play: (): boolean => hasModel() && s.clips && !s.animTyping && !s.tracing,
    /** A trace step shown: its transport. */
    trace: (): boolean => s.visible && s.tracing && !s.menuOpen && !s.traceTyping,
    posing: (): boolean => hasModel() && s.posing,
    rigged: (): boolean => hasModel() && s.rigged,
    source: (): boolean => s.visible && s.source,
  };
}

/** Every key of the tab's, in the order added -- MrDebug's order, though no two share a key and a state. */
export function modelKeys(s: ModelKeyState, act: ModelKeyDoings): ToolKey[] {
  const r = keyRules(s);
  // Blender's numpad, the Scene tab's too (`view/nav-keys.ts`, Docs/navigation.md §3): on the view under the pointer.
  const views = viewKeys({ prefix: 'model', mcp: 'ui', who: 'The view under the pointer', when: r.up }, act);
  const keys: ToolKey[] = [
    { ...keyed('model frame'), mcp: 'ui', view: true, when: r.hasModel, help: 'Frame the selection -- or the whole model -- in the view under the pointer', run: () => act.frame() },
    { ...keyed('model layout'), mcp: 'ui', view: true, when: r.up, help: 'The next layout of views: one, two, four', run: () => act.layout() },
    { ...keyed('model shading'), mcp: 'ui', view: true, when: r.up, help: 'The next shading: shaded, shaded with its wires, wireframe', run: () => act.shading() },
    // G is the pose gizmo's Move while a bone is posed under Blender's keymap (G R S): the grid's otherwise -- always
    // under Industry Compatible's, whose Move is W (Docs/navigation.md D11).
    {
      ...keyed('model grid'), mcp: 'ui', view: true, when: () => r.up() && !(s.posing && keymapNow() === 'blender'),
      help: 'The ground in metres, on or off (a bone posed, under Blender\'s keymap: the gizmo\'s Move)', run: () => act.grid(),
    },
    { ...keyed('model stats'), mcp: 'ui', view: true, when: r.up, help: 'The statistics in the first view, on or off', run: () => act.stats() },
    ...views,
    { ...keyed('model hide'), mcp: 'ui', view: true, when: r.hasModel, help: 'The selected parts hidden -- or, all hidden, shown', run: () => act.hide() },
    { ...keyed('model show all'), mcp: 'ui', view: true, when: r.hasModel, help: 'Every part shown', run: () => act.showAll() },
    { ...keyed('model select all'), mcp: 'ui', view: true, when: r.hasModel, help: 'Every part selected', run: () => act.selectAll() },
    // The arrows fly the view under the pointer (Docs/navigation.md §7), before the rows' and the menu's: ↑ ↓ along the look,
    // ← → across -- but while the clip's or the trace's transport has ← →, those stay theirs.
    {
      // Whichever side has the keys (the Assets panel's too): the pointer over a view is what says the arrows fly.
      ...keyed('model fly ahead'), mcp: 'ui', view: true, anySide: true, hold: true, when: r.arrows,
      help: 'Fly the view under the pointer while held: ↑ ahead, ↓ back, Shift faster', run: () => act.arrowFly(),
    },
    {
      ...keyed('model fly across'), mcp: 'ui', view: true, anySide: true, hold: true,
      when: () => r.arrows() && !r.clip() && !r.trace(),
      help: 'Fly the view under the pointer across while held: ← left, → right, Shift faster (the clip\'s and the trace\'s ← → while theirs)', run: () => act.arrowFly(),
    },
    { ...keyed('model part above'), mcp: 'ui', view: true, when: r.rows, help: 'The part above in the outliner', run: () => act.walk(-1) },
    { ...keyed('model part below'), mcp: 'ui', view: true, when: r.rows, help: 'The part below in the outliner', run: () => act.walk(1) },
    { ...keyed('model build'), mcp: 'model_export', when: r.source, help: 'Build the script now: exported again, current or not', run: () => act.build() },
    // Flying (D102, M8): held keys, MrDebug's `hold` -- the view under the pointer flies while any is down, Shift four times as fast.
    // Under Industry Compatible's keymap none has a key (Docs/navigation.md D10): the right button held flies.
    ...(['forward', 'back', 'left', 'right', 'down', 'up'] as const).map((way): ToolKey => ({
      ...keyed(`model fly ${way}`), mcp: 'ui', view: true, hold: true, when: r.flies,
      help: `Fly ${way}, held -- the view under the pointer, its pivot with it; Shift four times as fast${way === 'forward' || way === 'back' ? ' (orthographic: zoom)' : ''}`,
      run: () => act.fly(),
    })),
    // Blender's walk (Docs/navigation.md §4) in the view under the pointer; the held W A S D Q E above still fly (D6).
    {
      ...keyed('model walk'), mcp: 'ui', view: true, when: r.flies,
      help: 'Walk in the view under the pointer: the mouse looks, W A S D move, E Q rise and fall, Shift faster, Alt slower, the wheel the speed -- a click, Enter or Space keeps it, a right click or Esc puts the view back',
      run: () => act.walkView(),
    },
    // The canvases (M28) -- C the pane, the painter's keys while it is up -- and a part's Delete asking Claude (M30).
    { ...keyed('model canvases'), mcp: 'ui', view: true, when: r.hasModel, help: 'The Canvases pane, and paint mode -- or back to the parts', run: () => act.pane() },
    { ...keyed('model brush or eraser'), mcp: 'ui', view: true, when: r.painting, help: 'The brush, or the eraser', run: () => act.brushOrEraser() },
    { ...keyed('model marquee'), mcp: 'ui', view: true, when: r.painting, help: 'The next marquee: rectangle, ellipse, lasso', run: () => act.marquee() },
    { ...keyed('model brush smaller'), mcp: 'ui', view: true, when: r.painting, help: 'The brush smaller', run: () => act.brush(-1) },
    { ...keyed('model brush bigger'), mcp: 'ui', view: true, when: r.painting, help: 'The brush bigger', run: () => act.brush(1) },
    { ...keyed('model copy marks'), mcp: 'ui', when: () => r.painting() && s.marquee, help: 'Copy the marks in the marquee', run: () => act.copyMarks() },
    { ...keyed('model cut marks'), mcp: NOT_FOR_CLAUDE.paintCanvas, when: () => r.painting() && s.marquee, help: 'Cut the marks in the marquee', run: () => act.cutMarks() },
    { ...keyed('model paste marks'), mcp: NOT_FOR_CLAUDE.paintCanvas, when: () => r.painting() && s.canPaste && s.canvasOpen, help: 'Paste into the open canvas: the same place, the same scale', run: () => act.pasteMarks() },
    { ...keyed('model delete marks'), mcp: NOT_FOR_CLAUDE.paintCanvas, when: () => r.painting() && s.marquee, help: 'Delete the marks in the marquee', run: () => act.deleteMarks() },
    { ...keyed('model delete part'), mcp: NOT_FOR_CLAUDE.askClaude, when: () => r.hasModel() && !r.painting() && s.selected > 0 && !s.menuOpen, help: 'Delete the selected parts: asks Claude, in words put in its box for you to send', run: () => act.deleteParts() },
    // The clips' transport, the bones, the pose keyed (M31-M33).
    { ...keyed('model play'), mcp: 'ui', view: true, when: r.play, help: 'Play the clip, or hold the frame shown -- from the rest pose, the first clip plays', run: () => act.play() },
    { ...keyed('model frame back'), mcp: 'ui', view: true, when: r.clip, help: 'A frame back, at the clip\'s own rate (a loop wraps)', run: () => act.frameStep(-1) },
    { ...keyed('model frame on'), mcp: 'ui', view: true, when: r.clip, help: 'A frame on, at the clip\'s own rate (a loop wraps)', run: () => act.frameStep(1) },
    { ...keyed('model clip start'), mcp: 'ui', view: true, when: r.clip, help: 'To the clip\'s start', run: () => act.clipStart() },
    { ...keyed('model clip end'), mcp: 'ui', view: true, when: r.clip, help: 'To the clip\'s end', run: () => act.clipEnd() },
    { ...keyed('model key pose'), mcp: 'model_pose', view: true, when: r.rigged, help: 'Key the pose: the bone turned at the frame held written into the clip\'s action{} in the script', run: () => act.key() },
    // The pose gizmo's modes, the Scene tab's keys: G R S under Blender's keymap -- the grid's G and fly's S yield while a
    // bone is posed -- W E R under Industry Compatible's (its held flight off, D10).
    { ...keyed('model pose move'), mcp: 'ui', view: true, when: r.posing, help: 'The pose gizmo moves the bone', run: () => act.poseMode('translate') },
    { ...keyed('model pose rotate'), mcp: 'ui', view: true, when: r.posing, help: 'The pose gizmo turns the bone', run: () => act.poseMode('rotate') },
    { ...keyed('model pose scale'), mcp: 'ui', view: true, when: r.posing, help: 'Scale: Gladius bones have none -- says why', run: () => act.poseMode('scale') },
    { ...keyed('model bones'), mcp: 'ui', view: true, when: r.rigged, help: 'The bones overlay on or off: a click on a bone\'s line picks it', run: () => act.bones() },
    // The build trace (M34-M36) -- Shift+T steps through or back to the model; while a step is shown its own transport.
    { ...keyed('model trace'), mcp: 'model_trace', view: true, when: r.source, help: 'Step through the build: the script replayed op by op in the views -- or back to the model', run: () => act.trace() },
    { ...keyed('model trace play'), mcp: 'ui', view: true, when: r.trace, help: 'Play the build step by step, or hold the step shown', run: () => act.tracePlay() },
    { ...keyed('model trace back'), mcp: 'ui', view: true, when: r.trace, help: 'A step back in the build trace: its move run backwards', run: () => act.traceStep(-1) },
    { ...keyed('model trace on'), mcp: 'ui', view: true, when: r.trace, help: 'A step on in the build trace: the next operation, animated', run: () => act.traceStep(1) },
    { ...keyed('model trace start'), mcp: 'ui', view: true, when: r.trace, help: 'To the build trace\'s start: nothing built yet', run: () => act.traceStart() },
    { ...keyed('model trace end'), mcp: 'ui', view: true, when: r.trace, help: 'To the build trace\'s end: the model as the script finishes it', run: () => act.traceEnd() },
    { ...keyed('model menu up'), mcp: 'ui', view: true, when: () => s.menuOpen, help: 'The item above in the menu that is open', run: () => act.menuStep(-1) },
    { ...keyed('model menu down'), mcp: 'ui', view: true, when: () => s.menuOpen, help: 'The item below in the menu that is open', run: () => act.menuStep(1) },
  ];
  // Emulate Numpad (D5): the digit row, - and = as the numpad, only with the pointer over a view.
  return [...keys, ...emulatedKeys(keys, () => s.emulating)];
}
