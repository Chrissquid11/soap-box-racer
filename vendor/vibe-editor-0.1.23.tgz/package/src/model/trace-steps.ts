/**
 * The build trace's rules, pure (Docs/modeler.md M34-M37; Vibe3D D66, D69,
 * D70): no DOM, no three.js, so node tests import it.
 *
 * - **The steps** as the page holds them: a synthetic **start** before the
 *   first (index 0, nothing built), so the first operation has something to
 *   come out of (D66); `liveAt` -- what is on screen at a step, Total (every
 *   mesh made by then that nothing has replaced) or Last (that step's alone).
 * - **A step carried across a re-trace** (`carryStep`, M37): the same index if
 *   the op there is the same, else the same occurrence of that op and name,
 *   else the nearest place; the end stays the end.
 * - **The transport's timing** (D66): a log speed slider 0.1x-32x, read to two
 *   figures; 260 ms a step at 1x; a tween `min(200 / speed, interval * 0.9)`
 *   ms, so it lands before the next step at any speed; `due` -- the steps a
 *   frame's time owes at a speed.
 * - **A knife's cut** (`cutSegments`, D70): the edges whose both ends are new,
 *   matched by where they are (quantised to 1e-5), never by index; else the
 *   edges whose both ends went (a dissolve). Never both, never every edge that
 *   differs.
 * - **The words**: a step (`12 of 30 · extrude lid`), the cost, a canvas's step.
 */
import type { TraceAnswer, TraceStep } from '@vibe/pipeline/assets-types';

/** Total: everything alive at a step -- the model as it stands. Last: what that step made, alone. */
export type TraceView = 'total' | 'last';

/** The start: before the script built anything. Carries no node: nothing is drawn for it. */
export const START: TraceStep = { index: 0, op: 'start', triangles: 0 };

/** The steps as the page steps through them: the start first, when there are any. */
export function withStart(steps: readonly TraceStep[]): TraceStep[] {
  return steps.length > 0 ? [START, ...steps] : [];
}

/**
 * The steps on screen at step `index` (its own number, not its place): the
 * step itself always; in Total every step at or before it whose mesh nothing
 * has consumed yet -- alive over `index <= K < consumedAt`, gone exactly where
 * its replacement is born. Sorted.
 */
export function liveAt(steps: readonly TraceStep[], index: number, view: TraceView): number[] {
  if (index <= 0) return [];
  const live = new Set<number>([index]);
  if (view === 'total') for (const s of steps) if (s.index > 0 && s.index <= index && (s.consumedAt === undefined || s.consumedAt > index)) live.add(s.index);
  return [...live].sort((a, b) => a - b);
}

/** The one step whose mesh step `index` was made from (consumed there), or null where it was none or several (a union). */
export function sourceOf(steps: readonly TraceStep[], index: number): number | null {
  let found: number | null = null;
  for (const s of steps) {
    if (s.consumedAt !== index) continue;
    if (found !== null) return null;
    found = s.index;
  }
  return found;
}

/** `op label`, or the op. */
const nameOf = (s: TraceStep): string => (s.label ? `${s.op} ${s.label}` : s.op);

/**
 * Where to stand in `next` (a re-trace) having stood at place `at` of `old`
 * (both with their start): the end stays the end; the start the start; else
 * the same occurrence of that op and name -- the second `knife` is the second
 * knife again, wherever an edit above it moved it, never the first that came
 * to stand at its old index; else the same place, as near as `next` has.
 */
export function carryStep(old: readonly TraceStep[], at: number, next: readonly TraceStep[]): number {
  if (next.length === 0) return 0;
  const last = next.length - 1;
  if (old.length === 0 || at >= old.length - 1) return last;
  const was = old[at];
  if (!was || was.index === 0) return 0;
  const name = nameOf(was);
  let k = 0;
  for (let i = 1; i < at; i++) if (nameOf(old[i]!) === name) k++;
  for (let i = 1, seen = 0; i < next.length; i++) {
    if (nameOf(next[i]!) !== name) continue;
    if (seen === k) return i;
    seen++;
  }
  return Math.min(at, last);
}

// ---------------------------------------------------------------- the transport's timing

/** The speeds, and why the slider is a logarithm (D66): every doubling the same width, 1x not at 3 % of the travel. */
export const MIN_SPEED = 0.1;
export const MAX_SPEED = 32;
export const SLIDER_STEPS = 1000;
/** A step at 1x: slow enough to read the op's name as it goes. */
export const STEP_MS = 260;
/** A step's transition at 1x: well inside the interval. */
export const TWEEN_MS = 200;

/** Two significant figures, clamped: a slider lands on 2.0713x and nobody means that; one figure would flatten the slow end. */
export function roundSpeed(speed: number): number {
  const clamped = Math.min(MAX_SPEED, Math.max(MIN_SPEED, speed));
  return Number(clamped.toPrecision(2));
}

export function speedToSlider(speed: number): number {
  return Math.round((Math.log(speed / MIN_SPEED) / Math.log(MAX_SPEED / MIN_SPEED)) * SLIDER_STEPS);
}

export function sliderToSpeed(position: number): number {
  return roundSpeed(MIN_SPEED * Math.pow(MAX_SPEED / MIN_SPEED, position / SLIDER_STEPS));
}

/** A typed speed read: a number in range rounded, or null for what is no speed (empty, nought, words) -- the box shows the speed in force again. */
export function typedSpeed(text: string): number | null {
  const n = Number(text.trim().replace(/[x×]$/i, ''));
  return text.trim() !== '' && Number.isFinite(n) && n > 0 ? roundSpeed(n) : null;
}

/** Milliseconds between steps while playing. */
export const intervalMs = (speed: number): number => STEP_MS / speed;

/** A transition's length: scaled with the speed, and always done before the next step lands (D66). */
export const tweenMs = (speed: number): number => Math.min(TWEEN_MS / speed, intervalMs(speed) * 0.9);

/**
 * The steps a frame's `dt` owes while playing, and what is carried to the next
 * frame: at 32x a 16 ms frame owes two steps -- they are taken, never dropped,
 * so a fast replay keeps its pace; a long stall (the tab hidden) owes at most
 * `most` -- the replay does not leap to its end as it comes back.
 */
export function due(carried: number, dt: number, speed: number, most = 4): { steps: number; carried: number } {
  const every = intervalMs(speed);
  const total = carried + Math.max(0, dt);
  const steps = Math.floor(total / every);
  if (steps > most) return { steps: most, carried: 0 };
  return { steps, carried: total - steps * every };
}

// ---------------------------------------------------------------- a knife's cut (D70)

/** A mesh's triangles: its positions (x, y, z each) and its index (or none: three vertices a triangle). */
export interface Tris {
  positions: ArrayLike<number>;
  index: ArrayLike<number> | null;
}

/** Positions compared at 1e-5: a vertex nothing moved comes back through a build with its last bit different. */
const GRID = 1e5;

const spot = (p: ArrayLike<number>, v: number): string => `${Math.round(p[v * 3]! * GRID)},${Math.round(p[v * 3 + 1]! * GRID)},${Math.round(p[v * 3 + 2]! * GRID)}`;

function places(t: Tris): Set<string> {
  const out = new Set<string>();
  for (let v = 0; v < t.positions.length / 3; v++) out.add(spot(t.positions, v));
  return out;
}

/** Every triangle edge, by where its ends are -- a knife renumbers what it touches -- with its two ends and its segment. */
function edges(t: Tris): Map<string, { ends: [string, string]; segment: number[] }> {
  const out = new Map<string, { ends: [string, string]; segment: number[] }>();
  const count = t.index ? t.index.length : t.positions.length / 3;
  const at = (i: number): number => (t.index ? t.index[i]! : i);
  const p = t.positions;
  for (let i = 0; i + 2 < count; i += 3) {
    for (let e = 0; e < 3; e++) {
      const a = at(i + e);
      const b = at(i + ((e + 1) % 3));
      const ka = spot(p, a);
      const kb = spot(p, b);
      if (ka === kb) continue;
      const id = ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
      if (!out.has(id)) out.set(id, { ends: [ka, kb], segment: [p[a * 3]!, p[a * 3 + 1]!, p[a * 3 + 2]!, p[b * 3]!, p[b * 3 + 1]!, p[b * 3 + 2]!] });
    }
  }
  return out;
}

/** The edges of `mine` that `theirs` lacks and whose both ends are new to it. */
function own(mine: Map<string, { ends: [string, string]; segment: number[] }>, theirs: Map<string, unknown>, theirPlaces: Set<string>): number[] {
  const out: number[] = [];
  for (const [id, edge] of mine) {
    if (theirs.has(id) || theirPlaces.has(edge.ends[0]) || theirPlaces.has(edge.ends[1])) continue;
    // One by one: a spread is an argument per number, and a dense mesh overflows the stack.
    for (const n of edge.segment) out.push(n);
  }
  return out;
}

/**
 * What an edge-only op did, as segments: the edges it **added** whose both ends
 * are new (a cut makes its own vertices where it crosses edges; a
 * re-triangulation's diagonal lands on corners already there) -- else the edges
 * it **took away** whose both ends are gone (a dissolve). `removed` says which.
 * Nothing found, nothing: no fallback to every edge that differs (D70).
 */
export function cutSegments(before: Tris, after: Tris): { segments: number[]; removed: boolean } {
  const was = edges(before);
  const now = edges(after);
  const added = own(now, was, places(before));
  if (added.length > 0) return { segments: added, removed: false };
  return { segments: own(was, now, places(after)), removed: true };
}

// ---------------------------------------------------------------- words

/** `12 of 30 · extrude lid`; the start, `start · nothing built yet · 30 steps`. */
export function stepWords(step: TraceStep, of: number): string {
  if (step.index === 0) return `start · nothing built yet · ${of} ${of === 1 ? 'step' : 'steps'}`;
  return `${step.index} of ${of} · ${nameOf(step)}`;
}

const megabytes = (bytes: number): string => (bytes >= 1e6 ? `${(bytes / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1e3))} kB`);

/** What a trace came to (D66: the cost said, not prevented): `30 steps · 7,230 triangles traced · 1.2 MB · 340 ms` (every step's summed), and what the budget left out. */
export function costWords(answer: Pick<TraceAnswer, 'steps' | 'triangles' | 'total' | 'bytes' | 'ms' | 'capped'>): string {
  const n = answer.steps.length;
  // "traced": every step's triangles summed -- never the model's own count, which the stats say.
  const head = `${n} ${n === 1 ? 'step' : 'steps'} · ${answer.triangles.toLocaleString('en-US')} triangles ${answer.capped ? 'kept' : 'traced'} · ${megabytes(answer.bytes)} · ${answer.ms.toLocaleString('en-US')} ms`;
  if (!answer.capped) return head;
  return `${head} -- ${answer.capped.dropped} early ${answer.capped.dropped === 1 ? 'step' : 'steps'} not kept: the steps come to ${answer.total.toLocaleString('en-US')} triangles traced, over the ${answer.capped.cap.toLocaleString('en-US')} a trace keeps`;
}

/** The step a canvas was drawn over (D69): its number, of how many, its op and name. Survives as values, not a trace. */
export interface StepRef {
  index: number;
  of: number;
  op: string;
  label?: string;
  /** Which occurrence of its op and name it was (0 the first): found again by it in a trace made since (`placeOf`). */
  nth?: number;
}

/** A step as values; with the trace's steps, which occurrence of its op and name it is. */
export function stepRef(step: TraceStep, of: number, steps?: readonly TraceStep[]): StepRef {
  const nth = steps ? steps.filter((s) => s.index > 0 && s.index < step.index && nameOf(s) === nameOf(step)).length : undefined;
  return { index: step.index, of, op: step.op, ...(step.label ? { label: step.label } : {}), ...(nth !== undefined ? { nth } : {}) };
}

/**
 * Where a step ref stands in `steps` (with the start): the same occurrence of its op and name -- as a re-trace
 * carries the step shown (`carryStep`) -- else, a ref without one, the same index and op; -1 where it is not.
 */
export function placeOf(steps: readonly TraceStep[], ref: StepRef): number {
  const name = ref.label ? `${ref.op} ${ref.label}` : ref.op;
  if (ref.nth !== undefined) {
    for (let i = 1, seen = 0; i < steps.length; i++) {
      if (nameOf(steps[i]!) !== name) continue;
      if (seen === ref.nth) return i;
      seen++;
    }
    return -1;
  }
  return steps.findIndex((s) => s.index === ref.index && s.op === ref.op);
}

/** `step 12 of 30: extrude 'lid'` -- the turn's words and the canvas's row's. */
export function stepText(ref: StepRef): string {
  return `step ${ref.index} of ${ref.of}: ${ref.op}${ref.label ? ` '${ref.label}'` : ''}`;
}

/** A step ref read back (a reload's carried canvas): checked field by field, or null. */
export function readStepRef(value: unknown): StepRef | null {
  if (typeof value !== 'object' || value === null) return null;
  const v = value as Record<string, unknown>;
  if (typeof v.index !== 'number' || typeof v.of !== 'number' || typeof v.op !== 'string' || v.index < 1 || v.index > v.of) return null;
  return { index: v.index, of: v.of, op: v.op, ...(typeof v.label === 'string' && v.label ? { label: v.label } : {}), ...(typeof v.nth === 'number' && Number.isInteger(v.nth) && v.nth >= 0 ? { nth: v.nth } : {}) };
}

/** The same step: by number and op (a canvas's, against the one shown). */
export const sameStep = (a: StepRef | null, b: StepRef | null): boolean => (a === null ? b === null : b !== null && a.index === b.index && a.op === b.op && a.of === b.of);
