/**
 * The Model tab's build trace (Docs/modeler.md M34-M37; Vibe3D D66, D69, D70,
 * D76, D77, D86): the open script replayed op by op in the views, its steps
 * listed in the right panel's Build trace block, stepped through on a strip
 * along the views' foot.
 *
 * - **Traced when asked, not at every load** (M34, D76 changed): the block
 *   unfolded, Step through, `Shift+T`, a canvas drawn over a step reopened -- a trace
 *   is a whole Gladius build and some, and the tab already asks one of every
 *   save (`GET model`). Once traced, a change of the script or its parameters
 *   traces it again by itself, the old steps kept on screen marked stale
 *   meanwhile; a script that no longer builds keeps the old trace, stale, its
 *   line said (M37).
 * - **Loaded is not shown** (D76): a trace arriving does not take the views;
 *   **shown** is a step in the model's place (`Stage.setTrace`), until Back to
 *   the model (Esc, `Shift+T`). The trace outlives its panel (D69): the block folded,
 *   another pane, a canvas -- the step stays.
 * - **It opens on its last step** (D69): shown first, the views change by
 *   nothing but the grey of what the export finishes; step back from there.
 * - **The step shown survives a re-trace** (M37: `carryStep`) -- where D69
 *   ended the trace: here the re-trace is automatic, and a person mid-replay
 *   editing the script wants to see the same step's new shape.
 * - **Its own frame loop**, only while it plays or a step moves: each frame the
 *   steps due at the speed (`due`), the transition advanced -- inside a catch,
 *   so a fault in one step's geometry costs that move, never the loop (D77).
 * - **A late answer is dropped** (D66): one for another script, or one older
 *   than the trace asked for since.
 */
import type * as THREE from 'three';
import type { GLTF } from 'three/addons/loaders/GLTFLoader.js';
import type { ModelNode, TraceAnswer, TraceStep } from '@vibe/pipeline/assets-types';
import { recordPath } from '@vibe/pipeline/paths';
import { decodeModel, disposeModel } from '@vibe/engine';
import { keyLabel } from '@vibe/engine/debug';
import type { Api } from '../assets/api.ts';
import type { Live } from '../assets/live.ts';
import type { Shading } from '../prefs.ts';
import type { Stage } from './stage.ts';
import { createTracePanel, type TracePanel } from './trace-panel.ts';
import { carryStep, costWords, due, liveAt, placeOf, roundSpeed, stepRef, stepText, stepWords, tweenMs, withStart, type StepRef, type TraceView } from './trace-steps.ts';
import { TraceDrawing } from './trace-view.ts';

export interface TracingHost {
  api: Api;
  live: Live;
  stage: Stage;
  /** The script open, or null. */
  path(): string | null;
  /** Its parameters set by its record: a change traces again. */
  overrides(): Readonly<Record<string, string>>;
  /** Why a trace cannot be asked for here, or null (a page that may not run Gladius). */
  blocked(): string | null;
  say(text: string): void;
  /** Shown or not, playing or not: the toolbar, the clips' strip, the keys, the canvases follow. */
  changed(): void;
  /** Another step shown: the stats follow it. */
  stepped(): void;
  folds(): Readonly<Record<string, boolean>>;
  keepFold(key: string, folded: boolean): void;
  prefs(): { traceSpeed: number; traceView: TraceView };
  keepPrefs(change: Partial<{ traceSpeed: number; traceView: TraceView }>): void;
}

export interface Tracing {
  readonly block: HTMLElement;
  readonly strip: HTMLElement;
  /** A step stands in the model's place. */
  readonly showing: boolean;
  readonly playing: boolean;
  /** The speed box typed in: the arrows and Space are its own. */
  readonly typing: boolean;
  /** Another script open (or none): everything of the last let go. */
  open(path: string | null): void;
  /** The script, its parameters or the panels moved: traced again if what was traced is not what is there now. */
  check(): void;
  /** The shading changed: the steps' polygons asked for a wire mode. */
  setShading(mode: Shading): void;
  /** Step through (`Shift+T`): shown at its end -- traced first if need be -- or, shown, the model back. */
  toggle(): void;
  leave(): void;
  step(by: number): void;
  toStart(): void;
  toEnd(): void;
  togglePlay(): void;
  /** The step shown, as values -- for a canvas drawn over it (D69); null while the model is shown. */
  stepRef(): StepRef | null;
  /** A canvas reopened: its step shown again -- or, drawn over the model, the model shown (D86). */
  goTo(ref: StepRef | null): void;
  /** The meshes on screen while a step is shown: what a canvas's marks raycast onto. */
  shownMeshes(): THREE.Mesh[];
  /** The meshes a canvas drawn over step `ref` raycasts onto (Total, as drawn); null where this trace has it no more. */
  meshesAt(ref: StepRef): THREE.Mesh[] | null;
  /** The stats overlay's rows while a step is shown: the step, its objects and triangles. */
  stats(): (readonly [string, string])[] | null;
  /** A mesh shown, named for a mark: `step 7 (extrude)`. */
  nameOf(object: THREE.Object3D): string | null;
  /** The tab shown or not: the loop sleeps hidden. */
  setVisible(visible: boolean): void;
  /** Before a view is drawn: the cut's width in that view's pixels (the stage's `trace` hook). */
  prepare(width: number, height: number): void;
  /** The facts for a turn: the step shown, or null. */
  turnStep(): string | null;
  dispose(): void;
}

/** The trace in hand: its steps with the start, its answer, its version, and what it was traced from. */
interface Held {
  steps: TraceStep[];
  answer: TraceAnswer;
  key: string;
}

export function createTracing(host: TracingHost): Tracing {
  const drawing = new TraceDrawing();
  let path: string | null = null;
  let held: Held | null = null;
  /** What the script and its parameters are now -- a trace of anything else is stale. */
  let tracedKey = '';
  /** A trace is under way (its key), or null; one more wanted after it. */
  let asking: string | null = null;
  let again = false;
  /** The last trace failed: its words. */
  let failure: string | null = null;
  /** Wanted: the block unfolded, or the trace used -- a change traces again by itself. */
  let wanted = false;
  /** Shown once it arrives (Step through pressed before there was a trace) -- at its end, or at a canvas's step. */
  let showOnArrival = false;
  let arrival: StepRef | null = null;
  let at = 0;
  let showing = false;
  let playing = false;
  let carried = 0;
  let visible = false;
  let view: TraceView = host.prefs().traceView;
  let speed = roundSpeed(host.prefs().traceSpeed);
  let shading: Shading = 'shaded';
  let faces: Promise<void> | null = null;
  let polygons: ModelNode[] | null = null;
  /** Bumped whenever the script open changes: an answer for an older one is dropped. */
  let epoch = 0;
  /** A change heard: traced again once things settle (a save and its export come close together). */
  let checkSoon: ReturnType<typeof setTimeout> | undefined;

  const keyNow = (): string => {
    if (!path) return '';
    const e = host.live.index.entries.get(path);
    const r = host.live.index.entries.get(recordPath(path));
    const o = host.overrides();
    return `${e ? `${e.mtime}:${e.size}` : '?'}|${r?.hash ?? (r ? `${r.mtime}:${r.size}` : '-')}|${Object.keys(o).sort().map((k) => `${k}=${o[k]}`).join(',')}`;
  };
  const stale = (): boolean => held !== null && held.key !== keyNow();

  // ---------------------------------------------------------------- the panel

  const panel: TracePanel = createTracePanel({
    go: (place) => {
      stopPlay();
      show(place, false);
    },
    step: (by) => step(by),
    toStart: () => toStart(),
    toEnd: () => toEnd(),
    toggle: () => togglePlay(),
    enter: () => toggle(),
    leave: () => leave(),
    setView: (next) => {
      view = next;
      host.keepPrefs({ traceView: next });
      if (showing) show(at, false);
      draw();
    },
    setSpeed: (next) => {
      speed = roundSpeed(next);
      host.keepPrefs({ traceSpeed: speed });
      draw();
    },
    folded: (folded) => {
      host.keepFold('trace', folded);
      if (!folded) {
        wanted = true;
        ask();
      }
    },
    retrace: () => {
      wanted = true;
      ask(true);
    },
  });
  panel.setFolded(host.folds().trace ?? true);
  if (!panel.isFolded) wanted = true;

  function line(): { text: string; tone: 'idle' | 'busy' | 'bad' } {
    if (!path) return { text: '', tone: 'idle' };
    const blocked = host.blocked();
    if (blocked && !held) return { text: blocked, tone: 'idle' };
    if (asking !== null) return { text: held ? 'The script changed: tracing it again… -- the steps below are the last trace\'s' : 'Tracing the build: the script run with every operation\'s mesh kept…', tone: 'busy' };
    if (failure) return { text: held ? `${failure} -- the steps below are the last good trace's` : failure, tone: 'bad' };
    if (held && stale()) return { text: 'The script changed since this trace: it is traced again when it builds', tone: 'busy' };
    if (held) return { text: costWords(held.answer), tone: 'idle' };
    return { text: `Unfold to trace: the script run once with every operation's mesh kept, then stepped through in the views (${keyLabel('Shift+KeyT')})`, tone: 'idle' };
  }

  function draw(): void {
    panel.draw({
      steps: held?.steps ?? [],
      at,
      showing,
      playing,
      view,
      speed,
      line: line(),
      blocked: path ? host.blocked() : 'No model open',
      stale: held !== null && (stale() || asking !== null),
    });
  }

  // ---------------------------------------------------------------- tracing

  /** Trace the script open, if it wants it: not again for what is in hand, one at a time, the newest after. */
  function ask(force = false): void {
    if (!path) return;
    // A script the index has not (renamed away, deleted) -- or the index not in yet: asked of no one, no red line in the
    // console for it; the index's arrival moves `keyNow`, and `check` asks then.
    if (!host.live.index.loaded || !host.live.index.entries.has(path)) return draw();
    const why = host.blocked();
    if (why) {
      draw();
      return;
    }
    const key = keyNow();
    if (!force && held && held.key === key && failure === null) return draw();
    if (!force && failure !== null && tracedKey === key) return draw();
    if (asking !== null) {
      again = asking !== key || force;
      return draw();
    }
    void trace(key);
  }

  async function trace(key: string): Promise<void> {
    const mine = epoch;
    const script = path!;
    asking = key;
    again = false;
    draw();
    let answer: TraceAnswer;
    let gltf: GLTF | null = null;
    try {
      answer = await host.api.trace(script);
      if (mine !== epoch) return;
      if (answer.ok && answer.version) {
        const bytes = await host.api.traceBytes(script, answer.version);
        if (mine !== epoch) return;
        gltf = await decodeModel({ bytes, name: 'trace.glb' });
      }
    } catch (err) {
      answer = { ok: false, ms: 0, steps: [], triangles: 0, total: 0, bytes: 0, diagnostics: [], error: (err as Error).message };
    } finally {
      if (mine === epoch) asking = null;
    }
    // The script closed or another opened meanwhile: the late answer dropped (D66).
    if (mine !== epoch) {
      if (gltf) disposeModel(gltf);
      return;
    }
    tracedKey = key;
    if (answer.superseded) {
      // A newer ask of this page's (or another's) took its place: whatever is wanted now is asked again.
      again = true;
    } else if (!answer.ok || !gltf) {
      failure = answer.missing ? `Gladius is not found on this machine: nothing can be traced${answer.hint ? ` -- ${answer.hint}` : ''}` : `The trace did not build: ${answer.error ?? 'the instrumented build failed'}`;
      showOnArrival = false;
      arrival = null;
    } else {
      failure = null;
      take(answer, gltf, key);
    }
    draw();
    host.changed();
    if (again) {
      again = false;
      ask(true);
    }
  }

  /** A trace in: the drawing given it, the step stood at carried over (M37) -- the end for a first. */
  function take(answer: TraceAnswer, gltf: GLTF, key: string): void {
    const steps = withStart(answer.steps);
    const before = held;
    at = before ? carryStep(before.steps, at, steps) : steps.length - 1;
    held = { steps, answer, key };
    drawing.load(gltf, answer.steps);
    faces = null;
    polygons = null;
    if (showing) {
      // The new scene in the stage's place: its wires built again, the step at its carried place.
      host.stage.setTrace(null);
      host.stage.setTrace(drawing.group);
      show(at, false);
      const was = before?.steps.length ?? 0;
      if (was > 0) host.say(`Traced again: ${steps.length - 1} steps (were ${was - 1}) -- still at ${stepWords(steps[at]!, steps.length - 1)}`);
    } else if (showOnArrival) {
      showOnArrival = false;
      const place = arrival ? placeOf(steps, arrival) : -1;
      if (arrival && place < 0) host.say(`This canvas was drawn over ${stepText(arrival)}, which the script no longer makes -- shown at its end`);
      arrival = null;
      enter(place >= 0 ? place : steps.length - 1);
    }
    wantFaces();
  }

  /** A wire mode on and a trace shown: its steps' polygons, asked once a trace (a second Gladius pass). */
  function wantFaces(): void {
    if (!held || !showing || shading === 'shaded' || faces) {
      if (polygons && showing) applyPolygons();
      return;
    }
    const mine = held;
    const version = held.answer.version!;
    const script = path!;
    faces = host.api.traceFaces(script, version).then(
      (got) => {
        if (held !== mine) return;
        polygons = Object.entries(got.steps).map(([index, segments]) => ({ name: String(index), vertices: 0, edges: 0, faces: 0, triangles: 0, segments }));
        if (showing) applyPolygons();
      },
      () => {},
    );
  }

  function applyPolygons(): void {
    host.stage.setTracePolygons(polygons, (node) => drawing.nodeOf(Number(node.name)));
  }

  // ---------------------------------------------------------------- shown

  /** The model's place given to the trace, at place `place`. */
  function enter(place: number): void {
    if (!held) return;
    if (!showing) {
      showing = true;
      host.stage.setTrace(drawing.group);
      wantFaces();
      host.changed();
    }
    show(place, false);
  }

  /** Back to the model: the trace kept where it stands. */
  function leave(): void {
    if (!showing) return;
    stopPlay();
    showing = false;
    host.stage.setTraceAway([]);
    host.stage.setTrace(null);
    host.changed();
    draw();
  }

  /** The step at `place` shown; `animate` a one-step move (its transition the speed's length). */
  function show(place: number, animate: boolean): void {
    if (!held) return;
    if (!showing) return enter(place);
    const steps = held.steps;
    const next = Math.max(0, Math.min(steps.length - 1, place));
    const previous = steps[at]?.index ?? null;
    at = next;
    const step = steps[next]!;
    drawing.show(step.index, view, animate ? tweenMs(speed) : 0, previous);
    host.stage.setTraceAway(drawing.moving !== null ? [drawing.nodeOf(drawing.moving)].filter((n): n is THREE.Object3D => n !== null) : []);
    if (drawing.animating) loop();
    host.stage.draw();
    host.stepped();
    draw();
  }

  function step(by: number): void {
    if (!held) return;
    stopPlay();
    if (!showing) return enter(Math.max(0, Math.min(held.steps.length - 1, at + by)));
    show(at + by, Math.abs(by) === 1);
  }

  function toStart(): void {
    stopPlay();
    if (held) show(0, false);
  }

  function toEnd(): void {
    stopPlay();
    if (held) show(held.steps.length - 1, false);
  }

  function togglePlay(): void {
    if (playing) return stopPlay();
    if (!held) return toggle();
    if (!showing) enter(at);
    // Played from the end, the build replays from its start.
    if (at >= held.steps.length - 1) show(0, false);
    playing = true;
    carried = 0;
    loop();
    draw();
    host.changed();
  }

  function stopPlay(): void {
    if (!playing) return;
    playing = false;
    draw();
    host.changed();
  }

  function toggle(): void {
    if (showing) return leave();
    if (held && !stale()) return enter(at);
    if (held) {
      enter(at);
      wanted = true;
      return ask();
    }
    if (host.blocked()) return host.say(host.blocked()!);
    wanted = true;
    showOnArrival = true;
    if (panel.isFolded) {
      panel.setFolded(false);
      host.keepFold('trace', false);
    }
    host.say('Tracing the build: it shows here at its last step as it arrives -- ← → step, Space plays');
    ask();
  }

  // ---------------------------------------------------------------- the frame loop (D77)

  let frame = 0;
  let last = 0;
  function loop(): void {
    if (frame !== 0 || !visible) return;
    last = performance.now();
    frame = requestAnimationFrame(tick);
  }
  function tick(now: number): void {
    frame = 0;
    const dt = Math.min(250, Math.max(0, now - last));
    last = now;
    try {
      if (playing && held && showing) {
        const d = due(carried, dt, speed);
        carried = d.carried;
        if (d.steps > 0) {
          const end = held.steps.length - 1;
          const to = Math.min(end, at + d.steps);
          show(to, to === at + 1);
          // Off the end it stops there: a loop would leave it unclear whether the start or the end is shown.
          if (to >= end) stopPlay();
        }
      }
      drawing.advance(dt);
      host.stage.setTraceAway(drawing.moving !== null ? [drawing.nodeOf(drawing.moving)].filter((n): n is THREE.Object3D => n !== null) : []);
      host.stage.draw();
    } catch (err) {
      // The loop outlives any fault in a frame (D77): said, playback held, the next frame drawn.
      console.warn('[model] the build trace\'s frame failed -- playback held', err);
      playing = false;
      draw();
    }
    if ((playing && showing) || drawing.animating) loop();
  }

  // ---------------------------------------------------------------- the tab

  return {
    block: panel.block,
    strip: panel.strip,
    get showing() {
      return showing;
    },
    get playing() {
      return playing;
    },
    get typing() {
      return panel.typing;
    },
    open(next) {
      epoch++;
      leave();
      stopPlay();
      drawing.clear();
      held = null;
      path = next;
      tracedKey = '';
      asking = null;
      again = false;
      failure = null;
      faces = null;
      polygons = null;
      showOnArrival = false;
      arrival = null;
      at = 0;
      wanted = !panel.isFolded;
      if (wanted) ask();
      draw();
    },
    check() {
      if (!path) return draw();
      // Wanted -- the block open, or a trace in hand -- and the script or its parameters moved: traced again (M37).
      if ((wanted || held !== null) && keyNow() !== (held?.key ?? tracedKey)) {
        clearTimeout(checkSoon);
        checkSoon = setTimeout(() => ask(), 400);
      }
      draw();
    },
    setShading(mode) {
      shading = mode;
      wantFaces();
    },
    toggle,
    leave,
    step,
    toStart,
    toEnd,
    togglePlay,
    stepRef() {
      if (!showing || !held) return null;
      const s = held.steps[at];
      return s && s.index > 0 ? stepRef(s, held.steps.length - 1, held.steps) : null;
    },
    goTo(ref) {
      if (ref === null) {
        // Drawn over the model: the model shown -- not the trace's last step, which would put the trace's grey in its place (D86).
        if (showing) leave();
        return;
      }
      if (!held) {
        // Not traced (another session, or a reload): traced now, and shown at the canvas's step as it arrives (M34).
        const why = host.blocked();
        if (why) return host.say(`This canvas was drawn over ${stepText(ref)}: ${why}`);
        wanted = true;
        showOnArrival = true;
        arrival = ref;
        host.say(`This canvas was drawn over ${stepText(ref)}: tracing the build to show it…`);
        return ask();
      }
      const place = placeOf(held.steps, ref);
      if (place < 0) return host.say(`This canvas was drawn over ${stepText(ref)}, which this trace no longer has`);
      stopPlay();
      enter(place);
    },
    shownMeshes: () => (showing ? drawing.shownMeshes() : []),
    meshesAt(ref) {
      const place = held ? placeOf(held.steps, ref) : -1;
      return place > 0 ? drawing.meshesAt(held!.steps[place]!.index, 'total') : null;
    },
    stats() {
      if (!showing || !held) return null;
      const s = held.steps[at]!;
      const live = liveAt(held.answer.steps, s.index, view);
      const tris = live.reduce((n, i) => n + (held!.answer.steps[i - 1]?.triangles ?? 0), 0);
      return [['Step', `${s.index} / ${held.steps.length - 1}`], ['Objects', String(live.length)], ['Triangles', tris.toLocaleString('en-US')]];
    },
    nameOf(object) {
      const index = drawing.stepOf(object);
      if (index === null || !held) return null;
      const s = held.steps.find((x) => x.index === index);
      return s ? `step ${index} (${s.label ? `${s.op} ${s.label}` : s.op})` : null;
    },
    prepare: (width, height) => drawing.prepare(width, height),
    setVisible(next) {
      visible = next;
      if (!next) stopPlay();
    },
    turnStep() {
      const ref = showing && held ? held.steps[at] : undefined;
      if (!ref || !held) return null;
      if (ref.index === 0) return `the start of the build trace: nothing built yet (of ${held.steps.length - 1} steps)`;
      return `${stepText(stepRef(ref, held.steps.length - 1))} -- the model as it stood part way through the script, ${view === 'total' ? 'everything alive then' : 'that operation\'s result alone'}`;
    },
    dispose() {
      epoch++;
      cancelAnimationFrame(frame);
      clearTimeout(checkSoon);
      host.stage.setTrace(null);
      drawing.dispose();
    },
  };
}
