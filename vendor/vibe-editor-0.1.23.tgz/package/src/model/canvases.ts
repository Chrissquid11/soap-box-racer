/**
 * The Model tab's canvases (Docs/modeler.md M26-M28; Vibe3D's `annotate.ts`,
 * D24-D29, D50, D51, D63, D74, D75, D80): drawings over a view of the model,
 * each with the camera that made it, sent with a turn of the Claude card.
 *
 * - **A canvas is a drawing plus its camera** (D24). Its drawing is a texture
 *   on a quad standing in the scene just in front of the model, facing the
 *   camera that drew it and sized to the frustum there (D25, D27): the model
 *   and the drawing are one world seen through one camera, so a resize, a
 *   layout or a zoom cannot put them out of register. A thin frame keeps it
 *   findable edge-on.
 * - **Drawing captures** (D26): the left button in paint mode draws; in a view
 *   with no canvas open for it, the first stroke captures that view -- the
 *   render as it is, the camera, the parts selected and hidden (D29) -- or
 *   reopens the canvas already drawn from there (D27). Pan and zoom keep the
 *   canvas open; turning away starts another. One a rebuild has made stale
 *   takes no stroke: the next starts a new one (D80).
 * - **Square-on, fading, magnetic** (D50, D51): the open canvas is shown only
 *   from about its own direction, fading out over 4°; a view at rest within
 *   that reach swings onto it (direction only, the zoom kept); a canvas no
 *   view shows any more is closed (D75). "Show all canvases" shows every
 *   visible one from everywhere (D25's ghosts).
 * - **Ops, not pixels** (D27): a stroke is a vector, a move or a paste carries
 *   only the pixels it touches; each is a step of the canvas's own history,
 *   which the editor's Z and Y work on while the canvas is open in paint mode
 *   (per-canvas undo). The marquee is drawn as SVG over the view, never into
 *   the drawing.
 * - **Stale** (D74, D80): a model rebuilt under a canvas marks it; it stays,
 *   visible and editable, but is not sent.
 * - **What a turn carries** (`turn`): each visible canvas not stale, oldest
 *   first -- its composite (the drawing over the render), its camera, its
 *   note, its colours and its marks raycast onto the parts drawn now
 *   (`anchors.ts`).
 */
import * as THREE from 'three';
import type { CanvasTurn, TurnImage } from '@vibe/pipeline/agent-types';
import { imageFor } from '../agent/shot.ts';
import { createHistory, type History } from '../history.ts';
import { anchorsOf, captureCamera, coloursOf, upOf } from './anchors.ts';
import { createBooks, drifted } from './canvas-books.ts';
import { poseText, readPose, samePose, type PoseRef } from './clips.ts';
import { readStepRef, sameStep, stepText, type StepRef } from './trace-steps.ts';
import {
  alignment,
  BRUSH_COLOURS,
  brushTexels,
  clipOf,
  emptyMask,
  facing,
  insideMask,
  marqueeOf,
  maskBounds,
  maskPolygon,
  placeClip,
  planeSize,
  reopenHeight,
  thumbInk,
  sameView,
  translateMask,
  type CapturedCamera,
  type ClipPlace,
  type Mask,
} from './canvas-math.ts';
import { FOV, type ViewCamera } from '../view/view-camera.ts';
import { viewLabel, type Rect } from '../view/views.ts';

/** What the left button does in paint mode, chosen on the painter's bar. */
export type PaintTool = 'brush' | 'eraser' | 'rect' | 'ellipse' | 'lasso';
export const MARQUEES: readonly PaintTool[] = ['rect', 'ellipse', 'lasso'];

/** One edit of a drawing. */
export type Op =
  | { kind: 'stroke'; colour: string; width: number; erase: boolean; points: number[] }
  | { kind: 'erase-region'; mask: Mask }
  | { kind: 'paste'; source: HTMLCanvasElement; x: number; y: number; cut?: Mask };

const THUMB_WIDTH = 96;

/** The frame round a canvas: its colour. */
const FRAME = 0xffffff;

/** One canvas: its drawing, its camera, what it was drawn over, its note, its history. */
export class Canvas {
  readonly id: string;
  name: string;
  readonly cam: CapturedCamera;
  /** The render as it was when it was drawn over: the honest record. */
  readonly background: HTMLCanvasElement;
  /** The parts selected and hidden when it was drawn (D29), by name; selected kept in step while it is open. */
  selected: string[];
  hidden: string[];
  visible = true;
  stale = false;
  note = '';
  /** The clip and time it was drawn over (Vibe3D D89, D69): null, the rest pose. Survives `stale` -- it names an action, not a build. */
  pose: PoseRef | null = null;
  /** The build trace's step it was drawn over (D69): null, the model as exported. Survives `stale` as the pose does: said, not sent. */
  step: StepRef | null = null;
  /** Left out of the next turn by the card's ×: back in after it. */
  skipped = false;
  /**
   * The drawing as it came back from a reload (M28): its strokes as pixels, under every op since. Its own
   * undo starts after it -- a reload keeps the drawing, not its steps.
   */
  base: CanvasImageSource | null = null;
  readonly ops: Op[] = [];
  readonly history: History = createHistory({ steps: 200 });
  readonly paint: HTMLCanvasElement;
  readonly ctx: CanvasRenderingContext2D;
  readonly texture: THREE.CanvasTexture;
  readonly mesh: THREE.Mesh;
  readonly border: THREE.LineLoop;
  readonly thumb: HTMLCanvasElement;

  constructor(id: string, name: string, cam: CapturedCamera, background: HTMLCanvasElement, selected: string[], hidden: string[]) {
    this.id = id;
    this.name = name;
    this.cam = cam;
    this.background = background;
    this.selected = selected;
    this.hidden = hidden;
    this.paint = document.createElement('canvas');
    this.paint.width = cam.width;
    this.paint.height = cam.height;
    this.ctx = this.paint.getContext('2d', { willReadFrequently: true })!;
    this.texture = new THREE.CanvasTexture(this.paint);
    this.texture.colorSpace = THREE.SRGBColorSpace;
    const { width, height } = planeSize(cam);
    const material = new THREE.MeshBasicMaterial({ map: this.texture, transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
    this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, height), material);
    this.mesh.name = `canvas:${id}`;
    // A plane faces +Z and a camera looks down -Z: its orientation copied, the quad faces it, its X and Y the image's.
    this.mesh.quaternion.fromArray(cam.quaternion);
    const forward = new THREE.Vector3(0, 0, -1).applyQuaternion(this.mesh.quaternion);
    this.mesh.position.fromArray(cam.position).addScaledVector(forward, cam.planeDistance);
    this.mesh.renderOrder = 10;
    const corners = [new THREE.Vector3(-width / 2, -height / 2, 0), new THREE.Vector3(width / 2, -height / 2, 0), new THREE.Vector3(width / 2, height / 2, 0), new THREE.Vector3(-width / 2, height / 2, 0)];
    this.border = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(corners), new THREE.LineBasicMaterial({ color: FRAME, transparent: true, opacity: 0.45 }));
    this.mesh.add(this.border);
    this.mesh.updateMatrixWorld(true);
    this.thumb = document.createElement('canvas');
    this.thumb.width = THUMB_WIDTH;
    this.thumb.height = Math.max(1, Math.round((THUMB_WIDTH * cam.height) / cam.width));
    this.refreshThumb();
  }

  get empty(): boolean {
    return this.ops.length === 0 && this.base === null;
  }

  /** Square-on it beats the model (an overlay); from elsewhere it is a plane in the scene, depth-tested. */
  setOverlay(overlay: boolean): void {
    (this.mesh.material as THREE.MeshBasicMaterial).depthTest = !overlay;
    (this.border.material as THREE.LineBasicMaterial).depthTest = !overlay;
  }

  setOpacity(opacity: number): void {
    (this.mesh.material as THREE.MeshBasicMaterial).opacity = opacity;
    (this.border.material as THREE.LineBasicMaterial).opacity = 0.45 * opacity;
  }

  /** An op applied on top of what is there: kept. */
  push(op: Op): void {
    this.ops.push(op);
    this.apply(op);
    this.texture.needsUpdate = true;
  }

  /** The stroke under way's newest segment drawn: a long drag is one segment a move, not the whole stroke again. */
  extend(): void {
    const op = this.ops[this.ops.length - 1];
    if (op?.kind !== 'stroke') return;
    this.stroke(op, Math.max(0, op.points.length - 4));
    this.texture.needsUpdate = true;
  }

  /** Every op drawn again from nothing: after an undo, or a move's preview put away. */
  redraw(): void {
    this.ctx.clearRect(0, 0, this.paint.width, this.paint.height);
    if (this.base) this.ctx.drawImage(this.base, 0, 0, this.paint.width, this.paint.height);
    for (const op of this.ops) this.apply(op);
    this.texture.needsUpdate = true;
    this.refreshThumb();
  }

  private apply(op: Op): void {
    if (op.kind === 'stroke') this.stroke(op, 0);
    else if (op.kind === 'erase-region') this.cut(op.mask);
    else {
      if (op.cut) this.cut(op.cut);
      this.ctx.drawImage(op.source, op.x, op.y);
    }
  }

  cut(mask: Mask): void {
    this.ctx.save();
    this.ctx.globalCompositeOperation = 'destination-out';
    this.ctx.fill(maskPath(mask));
    this.ctx.restore();
  }

  private stroke(op: Extract<Op, { kind: 'stroke' }>, from: number): void {
    const { points } = op;
    if (points.length === 0) return;
    const ctx = this.ctx;
    ctx.save();
    // The eraser cuts the drawing's alpha: the canvas has no backdrop of its own to paint with.
    ctx.globalCompositeOperation = op.erase ? 'destination-out' : 'source-over';
    ctx.strokeStyle = op.colour;
    ctx.fillStyle = op.colour;
    ctx.lineWidth = op.width;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    if (points.length === 2) {
      // A click with no drag is still a mark.
      ctx.beginPath();
      ctx.arc(points[0]!, points[1]!, op.width / 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.moveTo(points[from]!, points[from + 1]!);
      for (let i = from + 2; i + 1 < points.length; i += 2) ctx.lineTo(points[i]!, points[i + 1]!);
      ctx.stroke();
    }
    ctx.restore();
  }

  /** A move's preview: the drawing as it was, the region cut, the floating pixels at (`x`, `y`) -- no op yet. */
  previewMove(snapshot: HTMLCanvasElement, cut: Mask, floating: HTMLCanvasElement, x: number, y: number): void {
    this.ctx.clearRect(0, 0, this.paint.width, this.paint.height);
    this.ctx.drawImage(snapshot, 0, 0);
    this.cut(cut);
    this.ctx.drawImage(floating, x, y);
    this.texture.needsUpdate = true;
  }

  snapshot(): HTMLCanvasElement {
    const copy = document.createElement('canvas');
    copy.width = this.paint.width;
    copy.height = this.paint.height;
    copy.getContext('2d')!.drawImage(this.paint, 0, 0);
    return copy;
  }

  /** The pixels inside `mask`, cropped to its bounds and clipped to its shape. */
  extract(mask: Mask): { canvas: HTMLCanvasElement; x: number; y: number } {
    const b = maskBounds(mask);
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(b.w));
    canvas.height = Math.max(1, Math.round(b.h));
    const ctx = canvas.getContext('2d')!;
    ctx.drawImage(this.paint, -b.x, -b.y);
    ctx.save();
    ctx.globalCompositeOperation = 'destination-in';
    ctx.translate(-b.x, -b.y);
    ctx.fill(maskPath(mask));
    ctx.restore();
    return { canvas, x: b.x, y: b.y };
  }

  /** The drawing over the render: what a turn sends, and what the thumbnail shows. */
  composite(): HTMLCanvasElement {
    const out = document.createElement('canvas');
    out.width = this.cam.width;
    out.height = this.cam.height;
    const ctx = out.getContext('2d')!;
    ctx.drawImage(this.background, 0, 0);
    ctx.drawImage(this.paint, 0, 0);
    return out;
  }

  /** The thumbnail: the render, and over it the marks made to read at its size (`thumbInk`) -- a thin stroke scaled down would vanish. */
  refreshThumb(): void {
    const { width: tw, height: th } = this.thumb;
    const ctx = this.thumb.getContext('2d')!;
    ctx.clearRect(0, 0, tw, th);
    ctx.drawImage(this.background, 0, 0, tw, th);
    const ink = document.createElement('canvas');
    ink.width = tw;
    ink.height = th;
    const data = new ImageData(new Uint8ClampedArray(thumbInk(this.ctx.getImageData(0, 0, this.paint.width, this.paint.height).data, this.paint.width, this.paint.height, tw, th)), tw, th);
    ink.getContext('2d')!.putImageData(data, 0, 0);
    ctx.drawImage(ink, 0, 0);
  }

  dispose(): void {
    this.texture.dispose();
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
    this.border.geometry.dispose();
    (this.border.material as THREE.Material).dispose();
  }
}

/** An image from a `data:` URL, loaded. */
function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('the drawing could not be read'));
    image.src = url;
  });
}

/** A three.js camera where a canvas's was: its backdrop rendered again after a reload. */
function cameraOf(cam: CapturedCamera): THREE.Camera {
  const distance = Math.hypot(cam.position[0] - cam.target[0], cam.position[1] - cam.target[1], cam.position[2] - cam.target[2]) || 1;
  const far = distance * 50 + 100;
  let camera: THREE.PerspectiveCamera | THREE.OrthographicCamera;
  if (cam.projection === 'orthographic') {
    const h = cam.frustumHeight / 2;
    camera = new THREE.OrthographicCamera(-h * cam.aspect, h * cam.aspect, h, -h, -far, far);
  } else camera = new THREE.PerspectiveCamera(cam.fov, cam.aspect, Math.max(1e-3, distance * 0.01), far);
  camera.position.fromArray(cam.position);
  camera.quaternion.fromArray(cam.quaternion);
  camera.updateMatrixWorld(true);
  camera.updateProjectionMatrix();
  return camera;
}

/** A mask as a canvas path. */
export function maskPath(mask: Mask): Path2D {
  const path = new Path2D();
  if (mask.shape === 'rect') path.rect(mask.x, mask.y, mask.w, mask.h);
  else if (mask.shape === 'ellipse') path.ellipse(mask.x + mask.w / 2, mask.y + mask.h / 2, Math.abs(mask.w) / 2, Math.abs(mask.h) / 2, 0, 0, Math.PI * 2);
  else {
    const p = mask.points;
    if (p.length >= 2) {
      path.moveTo(p[0]!, p[1]!);
      for (let i = 2; i + 1 < p.length; i += 2) path.lineTo(p[i]!, p[i + 1]!);
      path.closePath();
    }
  }
  return path;
}

/** A canvas as a reload carries it (M28): values only, its strokes as a PNG. */
export interface CarriedCanvas {
  path: string;
  name: string;
  cam: CapturedCamera;
  note: string;
  selected: string[];
  hidden: string[];
  visible: boolean;
  stale: boolean;
  /** Its strokes, `data:image/png;base64,…`. */
  paint: string;
  /** The pose it was drawn over; null, the rest pose. */
  pose: PoseRef | null;
  /** The build trace's step it was drawn over; null, the model (optional: a page from before phase 5). */
  step?: StepRef | null;
  /** The export's version it was drawn over (size and time), null if unknown: another after the reload, it is stale (D74). */
  version: string | null;
}

/** Reads a carried canvas back, or null for anything else: a record from another build is not trusted blindly. */
export function readCarried(value: unknown): CarriedCanvas | null {
  const v = value as Partial<CarriedCanvas> | null;
  const nums = (a: unknown, n: number): boolean => Array.isArray(a) && a.length === n && a.every((x) => typeof x === 'number' && Number.isFinite(x));
  const c = v?.cam as Partial<CapturedCamera> | undefined;
  if (!v || typeof v.path !== 'string' || typeof v.name !== 'string' || typeof v.paint !== 'string' || !v.paint.startsWith('data:image/png;base64,') || !c) return null;
  if ((c.projection !== 'perspective' && c.projection !== 'orthographic') || !nums(c.position, 3) || !nums(c.target, 3) || !nums(c.quaternion, 4)) return null;
  if (![c.fov, c.frustumHeight, c.aspect, c.planeDistance, c.width, c.height].every((n) => typeof n === 'number' && Number.isFinite(n) && n > 0)) return null;
  if (c.width! > 4096 || c.height! > 4096) return null;
  const names = (a: unknown): string[] => (Array.isArray(a) ? a.filter((x): x is string => typeof x === 'string') : []);
  return { path: v.path, name: v.name, cam: c as CapturedCamera, note: typeof v.note === 'string' ? v.note : '', selected: names(v.selected), hidden: names(v.hidden), visible: v.visible !== false, stale: v.stale === true, paint: v.paint, pose: readPose(v.pose), step: readStepRef(v.step), version: typeof v.version === 'string' ? v.version : null };
}

/** A view of the stage, as the canvases see it. */
export interface PaintView {
  cam: ViewCamera;
  rect: Rect;
}

export interface CanvasesHost {
  /** The stage's scene: the canvases' quads go in it. */
  scene: THREE.Scene;
  renderer(): THREE.WebGLRenderer | null;
  /** The stage's background, baked into a capture. */
  background(): THREE.Color;
  /** The views as they are now. */
  views(): readonly PaintView[];
  /** Drawn over the model, never captured: the selection's outline. */
  overlays(): THREE.Object3D[];
  /** The model's radius: the plane's depth and "the same view"'s tolerance. */
  radius(): number;
  /** The parts selected and hidden now, by name, and put back (a canvas reopened, D29). */
  selected(): string[];
  hidden(): string[];
  restore(selected: readonly string[], hidden: readonly string[]): void;
  /** The pose shown -- a clip at a time, null the rest pose -- and put back (a canvas reopened, D89). */
  pose(): PoseRef | null;
  goToPose(pose: PoseRef | null): void;
  /** The build trace's step shown -- null, the model -- and put back (a canvas reopened, D69, D86). */
  step(): StepRef | null;
  goToStep(step: StepRef | null): void;
  /** The parts drawn now (a hidden one left out), for the marks' rays; the name of the part a hit object is of. */
  targets(step: StepRef | null): THREE.Object3D[];
  partName(object: THREE.Object3D): string | null;
  /** Where the ring and the marquee are drawn: the stage's own element, over the views. */
  overlay: HTMLElement;
  /** Something about the canvases changed: the list, the bars, the card's line read again. */
  changed(): void;
  /** A frame, please. */
  draw(): void;
  say(text: string): void;
}

export interface Canvases {
  readonly list: readonly Canvas[];
  readonly open: Canvas | null;
  /** Paint mode: the Canvases list is up, and the left button draws (D63). */
  readonly painting: boolean;
  setPainting(on: boolean): void;
  readonly tool: PaintTool;
  setTool(tool: PaintTool): void;
  readonly colour: string;
  setColour(hex: string): void;
  /** The brush's size, CSS pixels. */
  readonly size: number;
  setSize(px: number): void;
  /** Every visible canvas shown from everywhere (D25's ghosts), or only the open one from about its own direction (D50). */
  readonly ghosts: boolean;
  setGhosts(on: boolean): void;
  /** A press in a view: true if it is the painter's. */
  down(view: PaintView, x: number, y: number): boolean;
  move(x: number, y: number): void;
  up(): void;
  cancel(): void;
  /** The pointer over a view, or off the stage: the brush's true-size ring follows it. */
  hover(view: PaintView | null, x: number, y: number): void;
  /** A view about to be drawn: each canvas shown, faded, an overlay or a plane, for it. */
  prepare(view: PaintView): void;
  /** Every view drawn: the open canvas closed if no view shows it (D75); the marquee placed. */
  drawn(): void;
  /** A view came to rest after a gesture: within the open canvas's reach, swung onto it (D51). */
  rested(view: PaintView): void;
  select(id: string | null, reopen: boolean): void;
  remove(id: string): Canvas | null;
  /** Scripts the index says are gone: their canvases put away freed, textures and all (`canvas-books.ts`' `drop`). */
  forget(paths: readonly string[]): void;
  /** A canvas removed, put back where it was (the delete's undo). */
  restoreCanvas(canvas: Canvas, at: number): void;
  setVisible(id: string, on: boolean): void;
  setSkipped(id: string, skipped: boolean): void;
  setNote(text: string): void;
  rename(id: string, name: string): void;
  readonly hasMarquee: boolean;
  readonly canPaste: boolean;
  copy(): boolean;
  cutSelection(): boolean;
  paste(): boolean;
  deleteSelection(): boolean;
  clearMarquee(): boolean;
  /** The model rebuilt under them: each marked stale (D74). */
  markStale(): void;
  /** The parts selected changed: the open canvas, in paint mode, takes them (D29). */
  selectionChanged(names: readonly string[]): void;
  /**
   * The script open now (M28): the canvases of the one before put away -- their quads out of the scene -- and
   * this one's brought back, as they were left, open canvas and histories and all.
   */
  openFor(path: string | null): void;
  /** A model of the script shown at its export's `version`: drawn over another export (rebuilt meanwhile), they are stale (D74). */
  shown(version: string): void;
  /** Every script's canvases as values, for a reload the editor survives: strokes as PNG, camera, note, what they were drawn over. */
  carry(): CarriedCanvas[];
  /** Canvases carried across a reload, given back: each script's made again once a model of it is shown and drawn (`adopt`). */
  takeBack(carried: readonly CarriedCanvas[]): void;
  /**
   * A model of the open script is on screen, at its export's `version`, and the renderer up: canvases carried for it
   * made again, their backdrops rendered anew -- stale if drawn over another export (rebuilt across the reload, D74).
   * Answers how many.
   */
  adopt(version: string | null): Promise<number>;
  /** Is this canvas any script's still (not deleted for good): a delete's step frees it only if not. */
  owns(canvas: Canvas): boolean;
  /** Every canvas gone, every script's: the tab disposed. */
  clear(): void;
  /** The canvases a turn would carry, and those it would not, why. */
  sendable(): Canvas[];
  leftOut(): string[];
  /** The canvases for a turn: each one's facts and its composite as the turn's image `first + i`, at most `room`. */
  turn(first: number, room: number): Promise<{ canvases: CanvasTurn[]; images: TurnImage[]; left: string[] }>;
  dispose(): void;
}

export function createCanvases(host: CanvasesHost): Canvases {
  const group = new THREE.Group();
  group.name = 'canvases';
  host.scene.add(group);
  /** Each script's canvases, kept for the page's life (M28): `list` and `open` are the book out's. */
  const books = createBooks<Canvas>();
  let list: Canvas[] = books.book.items;
  let open: Canvas | null = null;
  /** Canvases a reload carried, by script, waiting for a model of it to be shown. */
  const waiting = new Map<string, CarriedCanvas[]>();
  /** The view the open canvas is drawn in: painting is confined to it. */
  let paintCam: ViewCamera | null = null;
  let painting = false;
  let tool: PaintTool = 'brush';
  let colour = BRUSH_COLOURS[0]!.hex;
  let size = 6;
  let ghosts = false;
  let marquee: Mask | null = null;
  let clipboard: { canvas: HTMLCanvasElement; place: ClipPlace } | null = null;
  /** The strongest facing any view had for the open canvas in the frame drawn: read after it (D75). */
  let seen = 1;
  const raycaster = new THREE.Raycaster();
  const ndc = new THREE.Vector2();

  type Drag =
    | { kind: 'stroke'; op: Extract<Op, { kind: 'stroke' }> }
    | { kind: 'marquee'; x: number; y: number; points: number[] }
    | { kind: 'move'; x: number; y: number; mask: Mask; snapshot: HTMLCanvasElement; floating: HTMLCanvasElement; ox: number; oy: number; dx: number; dy: number };
  let drag: Drag | null = null;
  let dragView: PaintView | null = null;

  // ---------------------------------------------------------------- the ring and the marquee, over the views

  const ring = document.createElement('div');
  ring.className = 'ed-mo-ring';
  ring.hidden = true;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('class', 'ed-mo-marquee');
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  svg.append(path);
  host.overlay.append(ring, svg);
  let ringTimer: ReturnType<typeof setTimeout> | undefined;

  function placeRing(x: number, y: number): void {
    const d = size;
    Object.assign(ring.style, { left: `${x - d / 2}px`, top: `${y - d / 2}px`, width: `${d}px`, height: `${d}px` });
    ring.classList.toggle('ed-mo-ring-erase', tool === 'eraser');
  }

  // ---------------------------------------------------------------- views and canvases

  const viewOf = (cam: ViewCamera | null): PaintView | undefined => (cam ? host.views().find((v) => v.cam === cam) : undefined);
  const vec = (v: THREE.Vector3): [number, number, number] => [v.x, v.y, v.z];
  const nowOf = (view: PaintView) => ({ projection: view.cam.projection, position: vec(view.cam.camera.position), target: vec(view.cam.target), frustumHeight: view.cam.frustumHeight() });
  const facingIn = (canvas: Canvas, view: PaintView): number => facing(alignment(canvas.cam, { position: vec(view.cam.camera.position), target: vec(view.cam.target) }));
  /** A canvas takes strokes: not stale (D80), and over the pose it was drawn over -- another pose starts another canvas (D89). */
  const takes = (canvas: Canvas): boolean => !canvas.stale && samePose(canvas.pose, host.pose()) && sameStep(canvas.step, host.step());

  /** The canvas already drawn from this view, if any (D27). */
  function matching(view: PaintView): Canvas | null {
    const radius = host.radius();
    return list.find((c) => takes(c) && sameView(c.cam, nowOf(view), radius)) ?? null;
  }

  /** The texel of `canvas` under (`x`, `y`) in `view`, or null: a ray onto its quad, which three answers with a UV. */
  function pick(canvas: Canvas, view: PaintView, x: number, y: number): { x: number; y: number } | null {
    const r = view.rect;
    if (x < r.x || x >= r.x + r.width || y < r.y || y >= r.y + r.height) return null;
    ndc.set(((x - r.x) / r.width) * 2 - 1, -((y - r.y) / r.height) * 2 + 1);
    view.cam.update();
    raycaster.setFromCamera(ndc, view.cam.camera);
    const hit = raycaster.intersectObject(canvas.mesh, false)[0];
    if (!hit?.uv) return null;
    return { x: hit.uv.x * canvas.cam.width, y: (1 - hit.uv.y) * canvas.cam.height };
  }

  /** The view as it is, rendered without the canvases or the outline, into a canvas of the drawing's size. */
  function backdrop(camera: THREE.Camera, cam: CapturedCamera): HTMLCanvasElement {
    const out = document.createElement('canvas');
    out.width = cam.width;
    out.height = cam.height;
    const gl = host.renderer();
    if (!gl) return out;
    const target = new THREE.WebGLRenderTarget(cam.width, cam.height);
    // Without it the read-back is linear and the backdrop darker than the view it was taken from.
    target.texture.colorSpace = THREE.SRGBColorSpace;
    const hide = [group, ...host.overlays()];
    const was = hide.map((o) => o.visible);
    for (const o of hide) o.visible = false;
    const clear = new THREE.Color();
    gl.getClearColor(clear);
    const alpha = gl.getClearAlpha();
    gl.setClearColor(host.background(), 1);
    gl.setRenderTarget(target);
    gl.setScissorTest(false);
    gl.setViewport(0, 0, cam.width, cam.height);
    gl.clear();
    gl.render(host.scene, camera);
    const pixels = new Uint8Array(cam.width * cam.height * 4);
    gl.readRenderTargetPixels(target, 0, 0, cam.width, cam.height, pixels);
    gl.setRenderTarget(null);
    gl.setClearColor(clear, alpha);
    hide.forEach((o, i) => (o.visible = was[i]!));
    target.dispose();
    const image = new ImageData(cam.width, cam.height);
    // GL reads bottom-up; a canvas is top-down.
    const row = cam.width * 4;
    for (let y = 0; y < cam.height; y++) image.data.set(pixels.subarray((cam.height - 1 - y) * row, (cam.height - y) * row), y * row);
    out.getContext('2d')!.putImageData(image, 0, 0);
    return out;
  }

  /** A view captured as a new canvas, and opened in it (D24, D26). */
  function capture(view: PaintView): Canvas {
    const cam = captureCamera(view.cam, view.rect.width, view.rect.height, host.radius(), Math.min(devicePixelRatio || 1, 2));
    const counter = ++books.book.counter;
    const label = viewLabel(view.cam.preset, view.cam.projection).split(' · ')[0]!;
    view.cam.update();
    const canvas = new Canvas(`c${counter}-${Date.now().toString(36)}`, `${label} ${counter}`, cam, backdrop(view.cam.camera, cam), host.selected(), host.hidden());
    canvas.pose = host.pose();
    canvas.step = host.step();
    list.push(canvas);
    group.add(canvas.mesh);
    open = canvas;
    paintCam = view.cam;
    seen = 1;
    host.changed();
    return canvas;
  }

  /** A view put at a canvas's camera -- widened where it is narrower now, so the whole drawing shows (D25). */
  function reopenIn(view: PaintView, cam: CapturedCamera): void {
    const pose = view.cam.pose();
    const height = reopenHeight(cam, view.rect.width / Math.max(view.rect.height, 1));
    const dir = new THREE.Vector3().fromArray(cam.position).sub(new THREE.Vector3().fromArray(cam.target)).normalize();
    const target = new THREE.Vector3().fromArray(cam.target);
    const distance = cam.projection === 'orthographic' ? new THREE.Vector3().fromArray(cam.position).distanceTo(target) || 1 : height / 2 / Math.tan(((cam.fov || FOV) * Math.PI) / 360);
    view.cam.setPose({ ...pose, projection: cam.projection, target: vec(target), position: vec(target.clone().addScaledVector(dir, distance)), height, zoom: 1 });
  }

  /** Swung onto a canvas's direction about the view's own target: the zoom and the target kept (D51). */
  function alignTo(view: PaintView, canvas: Canvas): void {
    const pose = view.cam.pose();
    const target = view.cam.target.clone();
    const distance = view.cam.distance || 1;
    const dir = new THREE.Vector3().fromArray(canvas.cam.position).sub(new THREE.Vector3().fromArray(canvas.cam.target));
    if (dir.lengthSq() < 1e-12) return;
    dir.normalize();
    view.cam.setPose({ ...pose, position: vec(target.clone().addScaledVector(dir, distance)) });
  }

  /** An op done and kept as a step of its canvas's history: Z takes it back while the canvas is open. */
  function step(canvas: Canvas, op: Op, label: string): void {
    canvas.history.push({
      label: `${label} on ${canvas.name}`,
      undo: () => {
        const at = canvas.ops.lastIndexOf(op);
        if (at >= 0) canvas.ops.splice(at, 1);
        marquee = null;
        canvas.redraw();
        host.changed();
        host.draw();
      },
      redo: () => {
        canvas.push(op);
        canvas.refreshThumb();
        host.changed();
        host.draw();
      },
    });
  }

  function finish(): void {
    const d = drag;
    const canvas = open;
    drag = null;
    dragView = null;
    if (!d || !canvas) return;
    if (d.kind === 'stroke') {
      canvas.refreshThumb();
      step(canvas, d.op, d.op.erase ? 'Erase' : `Stroke (${BRUSH_COLOURS.find((c) => c.hex === d.op.colour)?.name ?? d.op.colour})`);
    } else if (d.kind === 'move') {
      // The preview put away first: the canvas shows a state no op explains, and ops apply on top of what is there.
      canvas.redraw();
      if (d.dx !== 0 || d.dy !== 0) {
        const op: Op = { kind: 'paste', source: d.floating, x: d.ox + d.dx, y: d.oy + d.dy, cut: d.mask };
        canvas.push(op);
        canvas.refreshThumb();
        step(canvas, op, 'Move marks');
        marquee = translateMask(d.mask, d.dx, d.dy);
      }
    } else if (marquee && emptyMask(marquee)) marquee = null;
    host.changed();
    host.draw();
  }

  // ---------------------------------------------------------------- the marquee on screen

  /** The open canvas's quad in its view, in the stage's CSS pixels: square-on, an axis-aligned rectangle. */
  function surface(): { x: number; y: number; w: number; h: number } | null {
    const view = viewOf(paintCam);
    if (!open || !view) return null;
    const { width, height } = planeSize(open.cam);
    view.cam.update();
    const at = (lx: number, ly: number): THREE.Vector2 => {
      const p = open!.mesh.localToWorld(new THREE.Vector3(lx, ly, 0)).project(view.cam.camera);
      return new THREE.Vector2(view.rect.x + ((p.x + 1) / 2) * view.rect.width, view.rect.y + ((1 - p.y) / 2) * view.rect.height);
    };
    const a = at(-width / 2, height / 2);
    const b = at(width / 2, -height / 2);
    return { x: a.x, y: a.y, w: b.x - a.x, h: b.y - a.y };
  }

  function placeMarquee(): void {
    const view = viewOf(paintCam);
    const s = surface();
    if (!marquee || !open || !s || !view || facingIn(open, view) < 1) {
      svg.style.display = 'none';
      return;
    }
    const sx = s.w / open.cam.width;
    const sy = s.h / open.cam.height;
    const p = maskPolygon(marquee);
    let d = '';
    for (let i = 0; i + 1 < p.length; i += 2) d += `${i === 0 ? 'M' : 'L'} ${(s.x + p[i]! * sx).toFixed(1)} ${(s.y + p[i + 1]! * sy).toFixed(1)} `;
    path.setAttribute('d', `${d}Z`);
    svg.style.display = '';
  }

  // ---------------------------------------------------------------- the turn

  const sendable = (): Canvas[] => list.filter((c) => c.visible && !c.stale && !c.empty && !c.skipped);

  function leftOut(): string[] {
    const out: string[] = [];
    const stale = list.filter((c) => c.stale && c.visible && !c.empty).length;
    const hiddenN = list.filter((c) => !c.visible && !c.empty).length;
    const skipped = list.filter((c) => c.skipped && c.visible && !c.stale && !c.empty).length;
    if (stale > 0) out.push(`${stale} stale -- drawn over the model before it was rebuilt`);
    if (hiddenN > 0) out.push(`${hiddenN} hidden in the list`);
    if (skipped > 0) out.push(`${skipped} left out of this turn by the person`);
    return out;
  }

  /** A canvas's image as base64 for the turn: its composite, made smaller where the API wants. */
  const imageOf = async (canvas: Canvas, n: number): Promise<TurnImage> => {
    const blob = await new Promise<Blob>((resolve, reject) => canvas.composite().toBlob((b) => (b ? resolve(b) : reject(new Error(`${canvas.name} could not be read`))), 'image/png'));
    return imageFor(blob, `canvas-${n}-${canvas.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`);
  };

  const api: Canvases = {
    get list() {
      return list;
    },
    get open() {
      return open;
    },
    get painting() {
      return painting;
    },
    setPainting(on) {
      if (on === painting) return;
      painting = on;
      if (!on) {
        api.cancel();
        marquee = null;
        ring.hidden = true;
      } else {
        // Coming back to a view already drawn from reopens its canvas (D27).
        for (const view of host.views()) {
          const match = matching(view);
          if (match) {
            open = match;
            paintCam = view.cam;
            seen = 1;
            break;
          }
        }
      }
      placeMarquee();
      host.changed();
      host.draw();
    },
    get tool() {
      return tool;
    },
    setTool(next) {
      api.cancel();
      tool = next;
      if (!MARQUEES.includes(next)) marquee = null;
      placeMarquee();
      host.changed();
    },
    get colour() {
      return colour;
    },
    setColour(hex) {
      colour = hex;
      if (tool === 'eraser' || MARQUEES.includes(tool)) tool = 'brush';
      host.changed();
    },
    get size() {
      return size;
    },
    setSize(px) {
      size = Math.max(1, Math.min(80, Math.round(px)));
      // The slider is nowhere near the pointer: the ring shown a moment in the middle of the painting view, true size (D26).
      const view = viewOf(paintCam) ?? host.views()[0];
      if (view && painting) {
        placeRing(view.rect.x + view.rect.width / 2, view.rect.y + view.rect.height / 2);
        ring.hidden = false;
        clearTimeout(ringTimer);
        ringTimer = setTimeout(() => (ring.hidden = true), 700);
      }
      host.changed();
    },
    get ghosts() {
      return ghosts;
    },
    setGhosts(on) {
      ghosts = on;
      host.changed();
      host.draw();
    },
    down(view, x, y) {
      if (!painting) return false;
      // The open canvas takes the stroke only in its own view, square-on -- swung onto it if the view is within its reach (D51).
      let canvas = open && paintCam === view.cam && takes(open) ? open : null;
      if (canvas && facingIn(canvas, view) < 1) {
        if (facingIn(canvas, view) > 0) alignTo(view, canvas);
        if (facingIn(canvas, view) < 1) canvas = null;
      }
      let point = canvas ? pick(canvas, view, x, y) : null;
      if (!point) {
        // Panned off it, turned away, or none open: the canvas already drawn from here, else this view captured --
        // by a stroke alone: a marquee has nothing to select on a canvas not drawn yet (review: an empty one was made).
        const match = matching(view);
        if (match) {
          open = match;
          paintCam = view.cam;
          seen = 1;
          host.restore(match.selected, match.hidden);
        } else if (MARQUEES.includes(tool)) {
          host.say('Draw first: a marquee selects marks on a canvas, and there is none here -- the brush (X) starts one');
          return false;
        } else if (!host.renderer()) {
          // No context: the backdrop would go to Claude blank, as if the view showed nothing.
          host.say('No WebGL context just now: a canvas is drawn over the view as it shows, and none can be read -- tried again shortly');
          return false;
        } else capture(view);
        canvas = open;
        point = canvas ? pick(canvas, view, x, y) : null;
      }
      if (!canvas || !point) return false;
      dragView = view;
      if (MARQUEES.includes(tool)) {
        if (marquee && insideMask(marquee, point.x, point.y)) {
          const { canvas: floating, x: ox, y: oy } = canvas.extract(marquee);
          drag = { kind: 'move', x: point.x, y: point.y, mask: marquee, snapshot: canvas.snapshot(), floating, ox, oy, dx: 0, dy: 0 };
        } else {
          marquee = null;
          drag = { kind: 'marquee', x: point.x, y: point.y, points: [point.x, point.y] };
        }
      } else {
        const op: Extract<Op, { kind: 'stroke' }> = { kind: 'stroke', colour, width: brushTexels(size, canvas.cam.height, view.rect.height), erase: tool === 'eraser', points: [point.x, point.y] };
        canvas.push(op);
        drag = { kind: 'stroke', op };
      }
      placeMarquee();
      host.changed();
      host.draw();
      return true;
    },
    move(x, y) {
      if (drag && dragView && open) {
        const point = pick(open, dragView, x, y);
        if (point) {
          if (drag.kind === 'stroke') {
            drag.op.points.push(point.x, point.y);
            open.extend();
          } else if (drag.kind === 'marquee') {
            if (tool === 'lasso') drag.points.push(point.x, point.y);
            marquee = marqueeOf(tool === 'ellipse' ? 'ellipse' : tool === 'lasso' ? 'lasso' : 'rect', drag.x, drag.y, point.x, point.y, drag.points);
            placeMarquee();
          } else {
            drag.dx = Math.round(point.x - drag.x);
            drag.dy = Math.round(point.y - drag.y);
            open.previewMove(drag.snapshot, drag.mask, drag.floating, drag.ox + drag.dx, drag.oy + drag.dy);
          }
          host.draw();
        }
      }
      if (painting && (tool === 'brush' || tool === 'eraser')) {
        placeRing(x, y);
        ring.hidden = false;
      }
    },
    up() {
      finish();
    },
    cancel() {
      if (!drag) return;
      const d = drag;
      drag = null;
      dragView = null;
      // A press the browser took back: the move put back, a stroke kept as far as it went.
      if (d.kind === 'move') open?.redraw();
      else if (d.kind === 'stroke' && open) step(open, d.op, d.op.erase ? 'Erase' : 'Stroke');
      host.changed();
      host.draw();
    },
    hover(view, x, y) {
      if (!painting || !view || (tool !== 'brush' && tool !== 'eraser')) {
        if (!drag) ring.hidden = true;
        return;
      }
      placeRing(x, y);
      ring.hidden = false;
    },
    prepare(view) {
      for (const canvas of list) {
        const isOpen = canvas === open;
        if (ghosts) {
          // Every visible canvas from every angle; an overlay only where it is drawn into, square-on.
          const overlay = isOpen && painting && paintCam === view.cam && facingIn(canvas, view) >= 1;
          canvas.mesh.visible = canvas.visible;
          canvas.setOverlay(overlay);
          canvas.setOpacity(overlay ? 1 : 0.65);
          continue;
        }
        // Planes hidden: the open canvas, and only from about its own direction, fading as the view swings off it (D50) --
        // and only over its own pose: the model moved off it, it goes (D89).
        const f = isOpen && samePose(canvas.pose, host.pose()) && sameStep(canvas.step, host.step()) ? facingIn(canvas, view) : 0;
        if (isOpen) seen = Math.max(seen, f);
        canvas.mesh.visible = canvas.visible && f > 0;
        canvas.setOverlay(f >= 1);
        canvas.setOpacity(f);
      }
    },
    drawn() {
      const was = seen;
      seen = 0;
      // A canvas no view shows any more is not the one being worked on: closed, at the end of its fade (D75).
      if (open && !ghosts && was <= 0 && !drag) {
        open = null;
        paintCam = null;
        marquee = null;
        host.changed();
      }
      placeMarquee();
    },
    rested(view) {
      if (!painting || !open || !open.visible || paintCam !== view.cam) return;
      const f = facingIn(open, view);
      if (f > 0 && f < 1) {
        alignTo(view, open);
        host.draw();
      }
    },
    select(id, reopen) {
      api.cancel();
      marquee = null;
      const canvas = id === null ? null : (list.find((c) => c.id === id) ?? null);
      open = canvas;
      seen = 1;
      if (canvas && reopen) {
        // Going back to a canvas: its camera in the view painted last (else the first), what it was drawn over -- the parts
        // selected and hidden, the clip at its time (D89) -- the brush.
        canvas.visible = true;
        if (!samePose(canvas.pose, host.pose())) host.goToPose(canvas.pose);
        // Its build step shown again (D69) -- or, drawn over the model, the model: the trace left as it stands (D86).
        if (!sameStep(canvas.step, host.step())) host.goToStep(canvas.step);
        const view = viewOf(paintCam) ?? host.views()[0];
        if (view) {
          reopenIn(view, canvas.cam);
          paintCam = view.cam;
        }
        host.restore(canvas.selected, canvas.hidden);
      } else if (!canvas) paintCam = null;
      placeMarquee();
      host.changed();
      host.draw();
    },
    remove(id) {
      const at = list.findIndex((c) => c.id === id);
      const canvas = list[at];
      if (!canvas) return null;
      if (canvas === open) {
        api.cancel();
        open = null;
        paintCam = null;
        marquee = null;
      }
      list.splice(at, 1);
      group.remove(canvas.mesh);
      host.changed();
      host.draw();
      return canvas;
    },
    restoreCanvas(canvas, at) {
      if (list.includes(canvas)) return;
      list.splice(Math.min(at, list.length), 0, canvas);
      group.add(canvas.mesh);
      host.changed();
      host.draw();
    },
    setVisible(id, on) {
      const canvas = list.find((c) => c.id === id);
      if (!canvas) return;
      canvas.visible = on;
      host.changed();
      host.draw();
    },
    setSkipped(id, skipped) {
      const canvas = list.find((c) => c.id === id);
      if (!canvas) return;
      canvas.skipped = skipped;
      host.changed();
    },
    setNote(text) {
      if (!open || open.note === text) return;
      open.note = text;
      host.changed();
    },
    rename(id, name) {
      const canvas = list.find((c) => c.id === id);
      if (!canvas || name.trim() === '') return;
      canvas.name = name.trim();
      host.changed();
    },
    get hasMarquee() {
      return marquee !== null;
    },
    get canPaste() {
      return clipboard !== null;
    },
    copy() {
      if (!open || !marquee) return false;
      const { canvas, x, y } = open.extract(marquee);
      clipboard = { canvas, place: clipOf(x, y, canvas.width, canvas.height, open.cam.width, open.cam.height) };
      host.say('Copied the marks in the marquee -- paste them into any canvas, at the same place');
      host.changed();
      return true;
    },
    cutSelection() {
      if (!api.copy()) return false;
      return api.deleteSelection();
    },
    paste() {
      const canvas = open;
      const clip = clipboard;
      if (!canvas || !clip) return false;
      const at = placeClip(clip.place, canvas.cam.width, canvas.cam.height);
      // Rescaled only for a canvas of another size: a same-size paste is exact.
      let source = clip.canvas;
      if (at.w !== source.width || at.h !== source.height) {
        const scaled = document.createElement('canvas');
        scaled.width = at.w;
        scaled.height = at.h;
        const ctx = scaled.getContext('2d')!;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(source, 0, 0, at.w, at.h);
        source = scaled;
      }
      const op: Op = { kind: 'paste', source, x: at.x, y: at.y };
      canvas.push(op);
      canvas.refreshThumb();
      step(canvas, op, 'Paste');
      // Left selected: the next move -- dragging it where it goes -- is at hand.
      marquee = { shape: 'rect', x: at.x, y: at.y, w: at.w, h: at.h };
      if (!MARQUEES.includes(tool)) tool = 'rect';
      placeMarquee();
      host.changed();
      host.draw();
      return true;
    },
    deleteSelection() {
      if (!open || !marquee) return false;
      const op: Op = { kind: 'erase-region', mask: marquee };
      open.push(op);
      open.refreshThumb();
      step(open, op, 'Delete marks');
      marquee = null;
      placeMarquee();
      host.changed();
      host.draw();
      return true;
    },
    clearMarquee() {
      if (!marquee) return false;
      marquee = null;
      placeMarquee();
      host.changed();
      return true;
    },
    markStale() {
      let any = false;
      for (const canvas of list) {
        if (canvas.stale || canvas.empty) continue;
        canvas.stale = true;
        any = true;
      }
      if (any) host.changed();
    },
    selectionChanged(names) {
      if (!open || !painting) return;
      open.selected = [...names];
      host.changed();
    },
    clear() {
      api.cancel();
      for (const book of books.all()) {
        for (const canvas of book.items) {
          group.remove(canvas.mesh);
          canvas.dispose();
        }
        book.items.length = 0;
        book.open = null;
      }
      open = null;
      paintCam = null;
      marquee = null;
      placeMarquee();
      host.changed();
    },
    owns: (canvas) => books.all().some((b) => b.items.includes(canvas)),
    forget(paths) {
      for (const path of paths) {
        const book = books.drop(path);
        if (book) for (const canvas of book.items) canvas.dispose();
      }
    },
    openFor(path) {
      if (path === books.path) return;
      api.cancel();
      books.book.open = open;
      for (const canvas of list) group.remove(canvas.mesh);
      books.open(path);
      list = books.book.items;
      open = books.book.open;
      for (const canvas of list) group.add(canvas.mesh);
      paintCam = null;
      marquee = null;
      placeMarquee();
      host.changed();
      host.draw();
    },
    shown(version) {
      if (books.shown(version)) api.markStale();
    },
    carry() {
      books.book.open = open;
      const out: CarriedCanvas[] = [];
      for (const items of waiting.values()) out.push(...items);
      for (const [path, book] of books.entries()) {
        for (const c of book.items) {
          if (c.empty) continue;
          out.push({ path, name: c.name, cam: c.cam, note: c.note, selected: c.selected, hidden: c.hidden, visible: c.visible, stale: c.stale, paint: c.paint.toDataURL('image/png'), pose: c.pose, step: c.step, version: book.version });
        }
      }
      return out;
    },
    takeBack(carried) {
      for (const c of carried) {
        const had = waiting.get(c.path) ?? [];
        had.push(c);
        waiting.set(c.path, had);
      }
    },
    async adopt(version) {
      const path = books.path;
      const due = path === null ? undefined : waiting.get(path);
      if (!path || !due || !host.renderer()) return 0;
      waiting.delete(path);
      let made = 0;
      for (const c of due) {
        const image = await loadImage(c.paint).catch(() => null);
        // Another script opened while the image loaded: kept for when it comes back.
        if (books.path !== path) {
          waiting.set(path, [...(waiting.get(path) ?? []), c]);
          continue;
        }
        if (!image) continue;
        const counter = ++books.book.counter;
        const canvas = new Canvas(`c${counter}-${Date.now().toString(36)}`, c.name, c.cam, backdrop(cameraOf(c.cam), c.cam), c.selected, c.hidden);
        canvas.base = image;
        canvas.note = c.note;
        canvas.pose = c.pose;
        canvas.step = c.step ?? null;
        canvas.visible = c.visible;
        canvas.stale = c.stale || drifted(c.version, version);
        canvas.redraw();
        list.push(canvas);
        group.add(canvas.mesh);
        made++;
      }
      host.changed();
      host.draw();
      return made;
    },
    sendable,
    leftOut,
    async turn(first, room) {
      const going = sendable();
      const canvases: CanvasTurn[] = [];
      const images: TurnImage[] = [];
      const left = leftOut();
      for (const [i, canvas] of going.entries()) {
        // Its marks onto what it was drawn over: the model -- or the build step's meshes (D69).
        const targets = host.targets(canvas.step);
        const image = i < room ? await imageOf(canvas, i + 1) : null;
        if (image) images.push(image);
        const marks = anchorsOf(canvas.ctx.getImageData(0, 0, canvas.cam.width, canvas.cam.height).data, canvas.cam, targets, (o) => host.partName(o));
        canvases.push({
          name: canvas.name,
          image: image ? first + images.length - 1 : null,
          note: canvas.note,
          colours: coloursOf(marks),
          camera: { projection: canvas.cam.projection, position: canvas.cam.position, target: canvas.cam.target, up: upOf(canvas.cam), fov: canvas.cam.fov, frustumHeight: canvas.cam.frustumHeight, width: canvas.cam.width, height: canvas.cam.height },
          marks,
          selected: canvas.selected,
          hidden: canvas.hidden,
          pose: canvas.pose ? poseText(canvas.pose) : null,
          step: canvas.step ? stepText(canvas.step) : null,
        });
      }
      if (going.length > room) left.push(`${going.length - room} past the turn's images (4 at most, with any pasted on the box): sent as words, without their pictures`);
      return { canvases, images, left };
    },
    dispose() {
      clearTimeout(ringTimer);
      api.clear();
      host.scene.remove(group);
      ring.remove();
      svg.remove();
    },
  };
  return api;
}
