/**
 * The Model tab's left panel (Docs/modeler.md M13; Vibe3D D29, D65, D91),
 * docked where the Scene tab's tree is (`sidePanel('left')`): its header
 * `MODEL`, the model's name and the fold; the model's parts as rows -- a
 * caret where a part has parts under it, its kind's icon, its name (the
 * script's), its triangles, its eye; the totals at its foot, the selection's
 * above the model's in amber.
 *
 * - **What a click does is `parts.ts`'**: the row and its modifiers told to
 *   the tab (`choose`), which owns the selection; the eye the same (`eye`).
 * - **Drawn whole, again on each change**: a Gladius model has tens of parts
 *   (M13's cost: thousands of rows would want a virtual list).
 * - **The cursor** -- the row the arrows are on -- is the selection's first,
 *   kept in view; the rows take the focus on a click, so the arrows are theirs.
 * - **Two panes under the header** (Docs/modeler.md M28; Vibe3D D63): Parts,
 *   the outliner, and Canvases -- the painter's bar and the canvases' list
 *   (`canvas-panel.ts`) -- whose being up *is* the paint mode: the left button
 *   draws while it is. `C` switches; the tab says so.
 */
import { isMac, keyLabel } from '@vibe/engine/debug';
import { control, el, icon, iconButton } from '../dom.ts';
import type { IconName } from '../icons.ts';
import { clickHow, type ClickHow } from '../selection.ts';
import { sidePanel, type SidePanel } from '../shell.ts';
import type { ModelNode } from '@vibe/pipeline/assets-types';
import { count, eyeTitle, hiddenOf, rowsOf, totalsLine, withChildren, type Part, type PartKind, type PartTree } from './parts.ts';
import { partTotals } from './stats.ts';

const KIND_ICONS: Readonly<Record<PartKind, IconName>> = { mesh: 'mesh', skinned: 'skinned', bone: 'bone', empty: 'empty' };
const KIND_TITLES: Readonly<Record<PartKind, string>> = {
  mesh: 'A mesh',
  skinned: 'A skinned mesh: bones deform it',
  bone: 'A bone of the rig',
  empty: 'An empty: a transform with nothing drawn at it',
};

export interface OutlinerHost {
  /** A row clicked, with what its modifiers ask. */
  choose(id: string, how: ClickHow): void;
  /** A row's eye clicked. */
  eye(id: string): void;
  /** A row double-clicked: the views framed on it. */
  frame(id: string): void;
  /** A row's right-click: its menu at (`x`, `y`). */
  menu(id: string, x: number, y: number): void;
  /** The header's ×: the model closed, back to the list of scripts. */
  close(): void;
  /** The header's model button: New model…, Import model… (Docs/modeler.md M38, M39) -- its menu under `at`. Absent where the page may not write. */
  files?(at: HTMLElement): void;
  /** A pane's tab clicked: Parts, or Canvases (paint mode). */
  pane(pane: Pane): void;
}

/** The left panel's two panes: the parts, or the canvases (paint mode). */
export type Pane = 'parts' | 'canvases';

export interface Outliner {
  readonly root: HTMLElement;
  readonly side: SidePanel;
  /** The rows: their focus is the arrows' `when`. */
  readonly rows: HTMLElement;
  /** Drawn again: the model's name and path, its parts, what is selected and hidden. */
  draw(model: { name: string; path: string; gone?: boolean } | null, tree: PartTree | null, selection: readonly string[], hidden: ReadonlySet<string>, kernel: ReadonlyMap<string, ModelNode>): void;
  /** The Canvases pane's body: `canvas-panel.ts` fills it. */
  readonly canvasPane: HTMLElement;
  /** The pane up, its tab lit; `count`, the canvases, on its tab. */
  setPane(pane: Pane, count: number): void;
  /** The ids of the rows as drawn, top to bottom: what a Shift range and the arrows walk. */
  shown(): string[];
  /** A part's row scrolled into view. */
  reveal(id: string): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}

export function createOutliner(root: HTMLElement, host: OutlinerHost): Outliner {
  const card = el('div', 'ed-card ed-side ed-left ed-mo-left');
  card.hidden = true;
  const bar = el('div', 'ed-panel-head ed-panel-bar');
  const name = el('span', 'ed-mo-head-name');
  const ends = el('span', 'ed-head-end');
  const closer = iconButton('ui', 'close', 'Close the model: back to the list of scripts', () => host.close());
  closer.hidden = true;
  // New model and Import model, a press away whatever is open (M38, M39).
  const files = host.files ? iconButton('ui', 'model', 'New model… or Import model…: a script made, or a .glb or .fbx turned into one, and opened here', () => host.files!(files!)) : null;
  bar.append(el('div', 'ed-side-title', 'Model'), name, ...(files ? [files] : []), closer, ends);
  const rows = el('div', 'ed-mo-rows');
  rows.tabIndex = 0;
  rows.setAttribute('role', 'tree');
  rows.setAttribute('aria-label', 'The model\'s parts');
  const totals = el('div', 'ed-mo-totals');
  // The panes' tabs: Parts and Canvases, the second the paint mode (D63).
  const tabs = el('div', 'ed-mo-panes');
  tabs.setAttribute('role', 'tablist');
  const tabOf = (pane: Pane, words: string, glyph: IconName, title: string): HTMLButtonElement => {
    const b = control('ui', 'ed-mo-pane') as HTMLButtonElement;
    b.setAttribute('role', 'tab');
    b.append(icon(glyph), el('span', 'ed-mo-pane-words', words));
    b.title = title;
    b.addEventListener('click', () => {
      b.blur();
      host.pane(pane);
    });
    return b;
  };
  const partsTab = tabOf('parts', 'Parts', 'mesh', `The model's parts: select, hide, frame (${keyLabel('KeyC')} switches)`);
  const canvasesTab = tabOf('canvases', 'Canvases', 'brush', `Draw over a view for Claude: the left button paints while this is up (${keyLabel('KeyC')})`);
  tabs.append(partsTab, canvasesTab);
  const partsPane = el('div', 'ed-mo-partpane');
  partsPane.append(rows, totals);
  const canvasPane = el('div', 'ed-mo-canvaspane');
  canvasPane.hidden = true;
  card.append(bar, tabs, partsPane, canvasPane);
  root.append(card);
  const side = sidePanel(root, card, 'left', { name: 'Model' });
  ends.append(side.fold);
  /** Folded parts, by id: kept across a rebuild as the ids are. */
  const folded = new Set<string>();
  let order: string[] = [];
  let last: { model: { name: string; path: string; gone?: boolean } | null; tree: PartTree | null; selection: readonly string[]; hidden: ReadonlySet<string>; kernel: ReadonlyMap<string, ModelNode> } = { model: null, tree: null, selection: [], hidden: new Set(), kernel: new Map() };

  function row(part: Part, selection: readonly string[], hidden: ReadonlySet<string>): HTMLElement {
    const item = el('div', 'ed-mo-row');
    item.dataset.id = part.id;
    item.setAttribute('role', 'treeitem');
    item.style.paddingLeft = `${4 + part.depth * 14}px`;
    const at = selection.indexOf(part.id);
    item.setAttribute('aria-selected', String(at >= 0));
    if (at > 0) item.classList.add('ed-also');
    if (at === 0) item.classList.add('ed-mo-cursor');
    const off = hiddenOf(part, hidden);
    item.classList.toggle('ed-mo-hidden', off);
    const caret = el('span', 'ed-mo-caret', part.children.length > 0 ? (folded.has(part.id) ? '▸' : '▾') : '');
    if (part.children.length > 0) {
      item.setAttribute('aria-expanded', String(!folded.has(part.id)));
      caret.title = folded.has(part.id) ? 'Unfold: the parts under it' : 'Fold the parts under it away';
      // mcp: ui -- a part folded
      caret.addEventListener('click', (event) => {
        event.stopPropagation();
        if (folded.has(part.id)) folded.delete(part.id);
        else folded.add(part.id);
        redraw();
      });
    }
    const kind = el('span', `ed-mo-kind ed-mo-kind-${part.kind}`);
    kind.append(icon(KIND_ICONS[part.kind]));
    kind.title = KIND_TITLES[part.kind];
    const label = el('span', 'ed-mo-name', part.name);
    label.title = `${part.name}${part.material ? ` · ${part.material}` : ''}: its name in the script (emit{name=…})${off ? ' -- hidden' : ''}`;
    const tris = el('span', 'ed-mo-tris', part.triangles > 0 ? count(part.triangles) : '');
    if (part.triangles > 0) tris.title = `${count(part.triangles)} triangles`;
    const eye = control('ui', 'ed-mo-eye');
    eye.append(icon(hidden.has(part.id) ? 'eyeOff' : 'eye'));
    eye.setAttribute('aria-pressed', String(hidden.has(part.id)));
    eye.title = `${eyeTitle(hidden, selection, part.id, part.name)} (${keyLabel('Shift+KeyH')})`;
    eye.addEventListener('click', (event) => {
      event.stopPropagation();
      host.eye(part.id);
    });
    item.append(caret, kind, label, tris, eye);
    // mcp: ui -- the Model tab's selection, a double-click its views onto it
    item.addEventListener('click', (event) => {
      rows.focus({ preventScroll: true });
      // The second click of a double-click: the views onto it, the selection as the first left it.
      if (event.detail === 2) return host.frame(part.id);
      host.choose(part.id, clickHow(event, true, isMac()));
    });
    item.addEventListener('contextmenu', (event) => {
      event.preventDefault();
      event.stopPropagation();
      host.menu(part.id, event.clientX, event.clientY);
    });
    return item;
  }

  function redraw(): void {
    const { model, tree, selection, hidden, kernel } = last;
    name.textContent = model ? model.name : '';
    closer.hidden = model === null;
    closer.title = model ? `Close ${model.name}: back to the list of scripts` : '';
    name.title = model ? `${model.path}: the script open` : '';
    if (!tree) {
      order = [];
      rows.replaceChildren(el('div', 'ed-mo-nothing', model?.gone ? `${model.path} is not there: renamed, moved or deleted -- close it (×) and open it again under its new name.` : model ? 'Nothing to list yet: the model has not built.' : 'No model open: double-click a .lua in the Assets panel\'s Source tab, or choose one in the middle.'));
      totals.replaceChildren();
      totals.hidden = true;
      return;
    }
    if (tree.all.length === 0) {
      order = [];
      rows.replaceChildren(el('div', 'ed-mo-nothing', 'The script emits nothing: no parts to list.'));
      totals.replaceChildren(el('div', undefined, totalsLine(partTotals([], kernel))));
      totals.hidden = false;
      return;
    }
    // A fold that hides a selected part is opened: the selection is seen.
    for (const id of selection) for (let p = tree.byId.get(id)?.parent ?? null; p; p = p.parent) folded.delete(p.id);
    const drawn = rowsOf(tree, folded);
    order = drawn.map((p) => p.id);
    const fragment = document.createDocumentFragment();
    for (const part of drawn) fragment.append(row(part, selection, hidden));
    rows.replaceChildren(fragment);
    const lines: HTMLElement[] = [];
    if (selection.length > 0) {
      const picked = el('div', 'ed-mo-picked', `${count(selection.length)} selected · ${totalsLine(partTotals(withChildren(tree, selection), kernel))}`);
      lines.push(picked);
    }
    const totalled = partTotals(tree.all, kernel);
    const whole = el('div', undefined, totalsLine(totalled));
    whole.title = totalled.stored ? 'Stored vertices: as the GLB keeps them, split at every seam and hard edge -- no count from Gladius for every part' : 'Vertices as the kernel builds them -- the stats overlay\'s figure';
    lines.push(whole);
    if (hidden.size > 0) lines.push(el('div', undefined, `${count([...hidden].filter((id) => tree.byId.has(id)).length)} hidden · ${keyLabel('Alt+KeyH')} shows every part`));
    totals.replaceChildren(...lines);
    totals.hidden = false;
  }

  return {
    root: card,
    side,
    rows,
    canvasPane,
    setPane(pane, n) {
      partsTab.setAttribute('aria-selected', String(pane === 'parts'));
      canvasesTab.setAttribute('aria-selected', String(pane === 'canvases'));
      (canvasesTab.lastChild as HTMLElement).textContent = n > 0 ? `Canvases ${n}` : 'Canvases';
      partsPane.hidden = pane !== 'parts';
      canvasPane.hidden = pane !== 'canvases';
      card.classList.toggle('ed-mo-painting', pane === 'canvases');
    },
    draw(model, tree, selection, hidden, kernel) {
      last = { model, tree, selection, hidden, kernel };
      redraw();
    },
    shown: () => order,
    reveal(id) {
      rows.querySelector<HTMLElement>(`[data-id="${CSS.escape(id)}"]`)?.scrollIntoView({ block: 'nearest' });
    },
    setVisible(visible) {
      card.hidden = !visible;
      if (visible) side.refresh();
    },
    dispose() {
      side.dispose();
      card.remove();
    },
  };
}
