/**
 * The Model tab's undo (Docs/modeler.md M23; Vibe3D D64): every change the tab
 * makes to the open model -- a parameter committed to its record, a bake, a
 * material edited in its script -- and every change made to its script from
 * outside (a text editor, Claude) is a step on the tab's own stack
 * (`ToolInstance.history`), which the editor's Z, Y and History card work on
 * while the tab is up (`active-history.ts`).
 *
 * - **A script step is the whole file** (D64): its text before and after, each
 *   written back whole (`PUT script`) -- a Lua script is kilobytes, and a turn
 *   of Claude's can restructure all of it; a diff would buy nothing. Each
 *   write says what it expects on disk (`expect`): one that finds anything
 *   else is refused, never written over (`409`), and the stack says so.
 * - **An outside change is a step when it lands** (M23, beyond D64): the tab
 *   keeps the script's text as it last knew it; the index saying the script
 *   moved, it is read again -- a text the tab wrote itself (`expecting`) is
 *   its own, anything else an edit from outside, pushed as a step that is
 *   already done: Z takes it back, Y does it again. A first doing of the
 *   tab's own that finds the disk moved records that first, then builds on it.
 * - **A parameter is a record step**: the record's options before and after,
 *   written with `PUT sidecar` -- the Options block's own way (`optionsEdit`)
 *   -- read fresh as its turn comes, so two commits in a row never write over
 *   each other; one that changes nothing is no step (`Unchanged`).
 * - **Labelled with what they take back**: "size 1 → 2", "Crate roughness 0.7
 *   → 0.4", "Bake size, segments into crate.lua", "crate.lua edited outside
 *   (lines 12–14)" -- the bar's Undo says "Undo size 1 → 2".
 * - **Asynchronous, through the Assets tool's queue** (`steps.ts`): one call at
 *   a time, Undo and Redo do nothing while one is under way (`busy`), a failed
 *   one stops the run and puts the stack back.
 *
 * DOM-free and three-free: the api, the index's `reached` and the reads are
 * handed in (`script-steps.test.ts`).
 */
import type { Options, WriteAnswer } from '@vibe/pipeline/assets-types';
import { canonical } from '@vibe/pipeline/recipes';
import { recordPath } from '@vibe/pipeline/paths';
import type { History, SetAside, Step } from '../history.ts';
import { createSteps, Unchanged, type Steps } from '../assets/steps.ts';
import { recordOptions } from './params.ts';

/**
 * A step refused because the script moved on disk since the text it expects
 * (`PUT script`'s 409) -- a step put aside with the tab closed and the script
 * edited meanwhile -- said as what it means: "the script changed since -- this
 * step can't be taken back".
 */
export function refusedWords(message: string): string {
  return message.replace(/[^:]*\.lua changed on disk since it was read: read it again first$/, ' the script changed since -- this step can\'t be taken back');
}

export interface ScriptStepsHost {
  history: History;
  putScript(path: string, text: string, expect: string): Promise<WriteAnswer>;
  putSidecar(path: string, options: Options): Promise<WriteAnswer>;
  /** The record written back whole (`PUT record`): `text` null takes it away; refused unless its settings are still `expect`'s. */
  putRecord(path: string, text: string | null, expect: string | null): Promise<WriteAnswer>;
  /** A file's text as it is on disk now; null for none (a record not written yet). */
  read(path: string): Promise<string | null>;
  /** Resolves once the tab's index has reached `seq` (`live.until`). */
  reached(seq: number): Promise<void>;
  /** After a failure: the index read again. */
  reread(): Promise<void>;
  /** Why a step stopped, for the tab's line. */
  failed(message: string): void;
  /** An outside edit recorded as a step: the tab's line says so. */
  noticed?(label: string): void;
  /** Is a Claude turn holding the script's export just now: an edit landing then is the turn's, and labelled so. */
  claude?(): boolean;
}

export interface ScriptSteps {
  readonly steps: Steps;
  /** The script whose text is kept, or null. */
  readonly path: string | null;
  /** Its text as last known: read, written, or noticed. */
  readonly text: string | null;
  /**
   * A script opened: the stack emptied -- the steps were another model's -- and its text read; the script closed
   * last opened again, its steps back. None (`null`, the tab closed): the steps put aside meanwhile.
   */
  open(path: string | null): Promise<void>;
  /**
   * The script changed by the tab -- a bake, a material -- as one step:
   * `change` given the text on disk as its turn comes, answering the new
   * text, or `{ problem }` (said, no step). True once pushed.
   */
  edit(label: string, change: (text: string) => string | { problem: string }): Promise<boolean>;
  /** The record's options changed as one step -- a parameter committed, reset, Reset all. True once pushed. */
  options(label: string, change: (options: Options) => Options): Promise<boolean>;
  /**
   * Several as one step, written in order -- a bake: the script's defaults,
   * then the overrides taken away -- undone in the reverse order. True once pushed.
   */
  both(label: string, script: (text: string) => string | { problem: string }, options: (options: Options) => Options): Promise<boolean>;
  /** The index says the script moved: read it again, and an edit from outside recorded as a step. */
  check(): Promise<void>;
  /**
   * A Claude turn has just taken hold of the script (the held list names it now): the outside step the save that
   * made it held left, if it is the last and was just made, is the turn's -- relabelled so. The server holds a
   * script as its first save of the turn lands, so that save's word reaches the page before the hold's.
   */
  claimedByTurn(): void;
}

/** How soon after an outside step the turn's hold may still claim it, in ms. */
export const CLAIM_MS = 5000;

/**
 * The lines an edit changed, in the text after it, 1-based: from the first
 * line that differs to the last, as their common start and end leave them --
 * `null` for none.
 */
export function changedLines(before: string, after: string): { from: number; to: number } | null {
  if (before === after) return null;
  const a = before.split('\n');
  const b = after.split('\n');
  let start = 0;
  while (start < a.length && start < b.length && a[start] === b[start]) start++;
  let endA = a.length - 1;
  let endB = b.length - 1;
  while (endA >= start && endB >= start && a[endA] === b[endB]) {
    endA--;
    endB--;
  }
  // Lines only taken away: the line where they were.
  if (endB < start) return { from: start + 1, to: start + 1 };
  return { from: start + 1, to: endB + 1 };
}

/**
 * An outside edit's label: `crate.lua edited outside (line 12)`, `(lines 12–14)` -- or, landed while a Claude turn
 * holds the script (`claude`), `Claude's turn edited crate.lua (line 12)`.
 */
export function outsideLabel(path: string, before: string, after: string, claude = false): string {
  const file = path.split('/').pop() ?? path;
  const lines = changedLines(before, after);
  const where = !lines ? '' : lines.from === lines.to ? ` (line ${lines.from})` : ` (lines ${lines.from}–${lines.to})`;
  return claude ? `Claude's turn edited ${file}${where}` : `${file} edited outside${where}`;
}

export function createScriptSteps(host: ScriptStepsHost): ScriptSteps {
  const { history } = host;
  /**
   * Whose the stack is just now: a new one each time it becomes another's (a model opened, the tab closed), the
   * parked one's back with its steps. A call queued under one era and ending under another (`steps.ts`' `era`) never
   * moves the stack in use: a first doing that lands is pushed onto its model's parked steps, and a put-back that
   * cannot be made drops them.
   */
  let era: object = {};
  /** The steps of the script closed last, put aside (`History.setAside`), and their era: back if it is the next opened, else dropped. */
  let parked: { path: string; kept: SetAside; era: object } | null = null;
  const stray = (of: unknown, step: Step | null): void => {
    if (!parked || parked.era !== of) {
      // Its stack is gone already: nothing holds the step.
      step?.drop?.();
      return;
    }
    if (step) {
      const kept = parked.kept;
      for (const s of kept.ahead) s.drop?.();
      const back = [...kept.back, step];
      parked.kept = { back, ahead: [], kept: kept.kept, savedAt: kept.savedAt !== null && kept.savedAt > kept.back.length ? null : kept.savedAt };
    } else {
      // A put-back that could not be made: those steps no longer say what is on disk.
      parked = null;
    }
  };
  const steps = createSteps({
    history,
    reached: (seq) => host.reached(seq),
    reread: () => host.reread(),
    failed: (m) => host.failed(refusedWords(m)),
    era: () => era,
    stray,
  });
  let path: string | null = null;
  let known: string | null = null;
  /** Texts the tab has asked to be written and not yet heard back as written: its own, when the index says the file moved. */
  const expecting = new Set<string>();
  /** The last outside step pushed, its texts and when: a turn's hold arriving just after it claims it. */
  let lastOutside: { step: Step; at: string; before: string; after: string; when: number } | null = null;
  const pushOutside = (at: string, before: string, after: string): string => {
    const label = outsideLabel(at, before, after, host.claude?.() === true);
    const step = steps.asyncStep(label, ...pair(scriptDoings(at, before, after)));
    history.push(step);
    lastOutside = { step, at, before, after, when: Date.now() };
    host.noticed?.(label);
    return label;
  };
  /** Bumped by every open: a read for the script before is let go. */
  let ticket = 0;
  /** A check asked while the tab's own calls were under way: made as they end (the queue's last `touch`). */
  let recheck = false;
  history.on((event) => {
    if (event === 'label' && recheck && !steps.busy()) {
      recheck = false;
      void self.check();
    }
  });

  /** The script written: expected first, so the index's word of it, which may come before the answer, is known as ours. */
  async function write(at: string, text: string, expect: string): Promise<WriteAnswer> {
    expecting.add(text);
    try {
      const answer = await host.putScript(at, text, expect);
      if (at === path) known = text;
      return answer;
    } finally {
      expecting.delete(text);
    }
  }

  /** A script step's doings: the text after, expecting the text before -- and back. */
  const scriptDoings = (at: string, before: string, after: string): { do: () => Promise<WriteAnswer>; undo: () => Promise<WriteAnswer> } => ({
    do: () => write(at, after, before),
    undo: () => write(at, before, after),
  });

  const pair = (d: { do: () => Promise<WriteAnswer>; undo: () => Promise<WriteAnswer> }): [() => Promise<WriteAnswer>, () => Promise<WriteAnswer>] => [d.do, d.undo];

  /** The disk read against what the tab knew: a text it did not write, recorded as an outside step first. Answers the text on disk. */
  async function catchUp(at: string): Promise<string> {
    const now = await host.read(at);
    if (now === null) throw new Error(`${at.split('/').pop()} is not there`);
    if (at === path && known !== null && now !== known && !expecting.has(now)) pushOutside(at, known, now);
    if (at === path) known = now;
    return now;
  }

  const self: ScriptSteps = {
    steps,
    get path() {
      return path;
    },
    get text() {
      return known;
    },
    async open(next) {
      if (next === path) return;
      ticket++;
      const was = path;
      path = next;
      known = null;
      lastOutside = null;
      expecting.clear();
      if (next === null) {
        // Closed: its steps put aside, for the same script opened again before another is.
        if (was !== null) parked = { path: was, kept: history.setAside(), era };
        era = {};
        return;
      }
      if (parked) {
        const back = parked;
        parked = null;
        history.takeBack(back.kept);
        // The steps were another model's.
        if (back.path !== next) {
          history.reset();
          era = {};
        } else era = back.era;
      } else {
        history.reset();
        era = {};
      }
      const mine = ticket;
      const text = await host.read(next).catch(() => null);
      // A check may have read it meanwhile (a file just made, not in the index at the open): the later read stands.
      if (mine === ticket && known === null) known = text;
    },
    async edit(label, change) {
      const at = path;
      if (at === null) return false;
      let before = '';
      let after = '';
      return steps.run(label, async () => {
        before = await catchUp(at);
        const made = change(before);
        if (typeof made !== 'string') throw new Error(made.problem);
        if (made === before) throw new Unchanged('the script says so already');
        after = made;
        return write(at, after, before);
      }, { do: () => write(at, after, before), undo: () => write(at, before, after) });
    },
    async options(label, change) {
      const at = path;
      if (at === null) return false;
      // The record's own bytes, before and after: an undo writes them back as they were (`PUT record`), never options
      // re-derived -- PUT sidecar keeps only what differs from the defaults, and the record would come back rewritten.
      let before: string | null = null;
      let after: string | null = null;
      return steps.run(label, async () => {
        before = await host.read(recordPath(at));
        const was = recordOptions(before);
        const next = change(was);
        if (canonical(next) === canonical(was)) throw new Unchanged('it is so already');
        const answer = await host.putSidecar(at, next);
        after = await host.read(recordPath(at));
        return answer;
      }, { do: () => host.putRecord(at, after, before), undo: () => host.putRecord(at, before, after) });
    },
    async both(label, script, options) {
      const at = path;
      if (at === null) return false;
      let textBefore = '';
      let textAfter = '';
      let optsBefore: Options = {};
      let optsAfter: Options = {};
      // The record's bytes, as `options` keeps them: back as they were, not re-derived.
      let recordBefore: string | null = null;
      let recordAfter: string | null = null;
      const forth = async (): Promise<WriteAnswer> => {
        await write(at, textAfter, textBefore);
        return host.putRecord(at, recordAfter, recordBefore);
      };
      const back = async (): Promise<WriteAnswer> => {
        await host.putRecord(at, recordBefore, recordAfter);
        return write(at, textBefore, textAfter);
      };
      return steps.run(label, async () => {
        textBefore = await catchUp(at);
        const made = script(textBefore);
        if (typeof made !== 'string') throw new Error(made.problem);
        textAfter = made;
        recordBefore = await host.read(recordPath(at));
        optsBefore = recordOptions(recordBefore);
        optsAfter = options(optsBefore);
        if (textAfter === textBefore && canonical(optsAfter) === canonical(optsBefore)) throw new Unchanged('it is so already');
        await write(at, textAfter, textBefore);
        const answer = await host.putSidecar(at, optsAfter);
        recordAfter = await host.read(recordPath(at));
        return answer;
      }, { do: forth, undo: back });
    },
    async check() {
      const at = path;
      if (at === null) return;
      // The tab's own writes are under way: their answers say what is on disk, and an undo must not race a read.
      if (steps.busy()) {
        recheck = true;
        return;
      }
      const mine = ticket;
      const now = await host.read(at).catch(() => null);
      if (steps.busy()) {
        recheck = true;
        return;
      }
      if (mine !== ticket || now === null || now === known) return;
      // Never read yet -- the open's read found nothing (a script just made, not in the index yet): this text is the
      // baseline, no step; every later change is measured from it.
      if (known === null) {
        known = now;
        return;
      }
      if (expecting.has(now)) {
        known = now;
        return;
      }
      const before = known;
      known = now;
      pushOutside(at, before, now);
    },
    claimedByTurn() {
      const last = lastOutside;
      if (!last || last.at !== path || last.after !== known || Date.now() - last.when > CLAIM_MS) return;
      // Still the newest step, and done: anything pushed or undone since leaves it as it was said.
      if (history.steps[history.done - 1] !== last.step) return;
      const label = outsideLabel(last.at, last.before, last.after, true);
      if (label === last.step.label) return;
      last.step.label = label;
      history.touch();
      host.noticed?.(label);
    },
  };
  return self;
}
