/**
 * The Model tab's phase 4 (Docs/modeler.md §4, M31-M33): the model's clips
 * played, its bones drawn and picked, the selected bones' weight maps, and a
 * bone posed at a held frame written back as a key -- made once by
 * `model-tool.ts`, which hands it each model shown and the selection.
 *
 * - **The clips** (`animation.ts`' `Player`): the transport strip and the
 *   Animation block (`animation-panel.ts`); every view poses together, the
 *   selection's outline and the wires skinned with the mesh, the kernel's
 *   polygons -- the rest pose's -- drawn only at rest (`setPosed`).
 * - **The bones**: the overlay (Bones, `J`), a click on a bone's line picks it
 *   (`StagePose.pick`), and the bones selected -- in the outliner or so --
 *   draw their weight map (`weights.ts`) with the count of vertices they move.
 * - **The pose** (`posing.ts`): a frame held and a bone chosen, the gizmo on
 *   it or numbers typed; **Key** (`K`) writes the pose into the clip's
 *   `action{}` in the script (`pose-keys.ts`) as one whole-file step of the
 *   tab's undo -- "Key: LeftWing rot at fly 6" -- and the export follows, the
 *   rebuilt clip carrying the pose; **Auto key** writes as a bone is let go.
 *   Refused, with why, every time: no clip held, playing, an imported clip, a
 *   computed key, a rest key, a page that may not write, the script held for
 *   Claude's turn.
 * - **The pose shown is named** (`pose`, `fly@0.2`) for a canvas drawn over it
 *   and for Claude's turn, and put back (`goTo`) as a canvas is reopened.
 */
import * as THREE from 'three';
import { keyLabel } from '@vibe/engine/debug';
import { MODEL_SPEEDS, type ModelPrefs } from '../prefs.ts';
import { frameAt, poseText, type PoseRef } from './clips.ts';
import { Player } from './animation.ts';
import { createAnimationPanel, SCALE_WHY, type AnimationView } from './animation-panel.ts';
import type { PaintView } from './canvases.ts';
import { declaredActions, keyAt, poseEdit, type ScriptAction } from './pose-keys.ts';
import { describe } from './pose-math.ts';
import { Poser, type PoseMode } from './posing.ts';
import type { StagePose } from './stage.ts';
import { WeightMaps, type WeightFacts } from './weights.ts';

/** Typed numbers settle this long before Auto key writes them: three fields in a row are one pose (D122). */
const SETTLE_MS = 400;

export interface AnimatingHost {
  /** Where the bones, the weight maps and the gizmo go: the stage's overlays, out of sight with the model while a trace step is shown. */
  scene: THREE.Object3D;
  /** The stage's element over the views: the gizmo reads the pointer there. */
  element: HTMLElement;
  draw(): void;
  say(text: string): void;
  /** The model posed by a clip, or at rest: the stage's polygons follow. */
  setPosed(posed: boolean): void;
  /** The pose shown, or the weights, changed: the canvases, the stats, the card's line read again. */
  changed(): void;
  /** The script open, and its text as the tab knows it. */
  scriptPath(): string | null;
  scriptText(): string | null;
  /** Words put in the Claude card's box, not sent (M30's way): false where there is no card. */
  askClaude(text: string): boolean;
  /** The record's `anim` set to 0 -- every key kept -- as one step of the tab's undo, the export made again. True once pushed. */
  keepEveryKey(): Promise<boolean>;
  /** The script changed as one step of the tab's undo. */
  editScript(label: string, change: (text: string) => string | { problem: string }): Promise<boolean>;
  /** The tab's undo is writing. */
  writing(): boolean;
  /** Why the script may not be written here, or null. */
  readOnly(): string | null;
  /** The script's export is held for a Claude turn: its saves are previews. */
  held(): boolean;
  folds(): Readonly<Record<string, boolean>>;
  keepFold(key: string, folded: boolean): void;
  /** The kept choices: the bones overlay, auto key, the speed. */
  prefs(): Pick<ModelPrefs, 'bones' | 'autoKey' | 'speed'>;
  keepPrefs(change: Partial<Pick<ModelPrefs, 'bones' | 'autoKey' | 'speed'>>): void;
  /** A build trace's step is shown in the model's place (M34): the clips and the pose are the model's, and wait. */
  traced(): boolean;
  /** Back to the model from the trace -- a clip chosen while a step was shown -- said. */
  leaveTrace(): void;
}

export interface Animating {
  readonly block: HTMLElement;
  readonly strip: HTMLElement;
  /** The stage's hooks for the bones and the gizmo. */
  readonly stage: StagePose;
  /** The canvases' overlays, never captured into a backdrop: the bones, the weight maps, the gizmo. */
  readonly overlays: THREE.Object3D[];
  /**
   * A model shown, its clips with it -- `first` a model opened, else a rebuild
   * or a preview: the clip, its time and the pose edits carried by name.
   */
  setModel(scene: THREE.Object3D | null, animations: readonly THREE.AnimationClip[], first: boolean): void;
  /** The parts selected: the bones among them draw their weights, the first is posed. */
  selection(objects: readonly THREE.Object3D[]): void;
  /** The pose shown, `fly@0.2`'s parts; null at rest. */
  readonly pose: PoseRef | null;
  /** The pose shown, worded for Claude's turn; null at rest. */
  turnPose(): string | null;
  /** A recorded pose put back (a canvas reopened). */
  goTo(pose: PoseRef | null): void;
  /** Playback held (paint mode opened: a canvas is a drawing over one frame). */
  pause(): void;
  readonly hasClips: boolean;
  /** The clips of the model shown, by name (the studio's `model_info`). */
  clipNames(): string[];
  readonly rigged: boolean;
  /** The selected bones' weight map, for the stats. */
  readonly weights: WeightFacts | null;
  /** A pose field being typed in. */
  readonly typing: boolean;
  // The keys' doings.
  toggle(): void;
  step(by: number): void;
  toStart(): void;
  toEnd(): void;
  key(): void;
  toggleBones(): void;
  /** Whether the pose is being dragged by the gizmo: the stage's keys wait. */
  readonly dragging: boolean;
  /** A frame held and a bone posable: the gizmo's keys are live, fly's yield, a click on nothing keeps the bone. */
  readonly posing: boolean;
  /** The gizmo's mode, by its keys. */
  setMode(mode: PoseMode | 'scale'): void;
  /**
   * The script edited from outside -- another page, a text editor, Claude: a pose held and not keyed is kept, said;
   * Key writes it into the script as it is now (the key merged into its text, never the whole page's copy over it).
   */
  outside(label: string): void;
  /** The source's build failed (its first line), or a model came: a key just written is said built or not. */
  built(failed: string | null): void;
  redraw(): void;
  dispose(): void;
}

const isBone = (o: THREE.Object3D): o is THREE.Bone => (o as THREE.Bone).isBone === true;

export function createAnimating(host: AnimatingHost): Animating {
  const weights = new WeightMaps();
  let selectedBones: THREE.Bone[] = [];
  let facts: WeightFacts | null = null;
  /** The last word about a key: written, or why not -- until the pose moves on. */
  let message: { text: string; ok: boolean; keep?: boolean; sticky?: boolean } | null = null;
  /** A key was written: the model that arrives next has the pose in its clip, and the edit is let go. */
  let wrote = false;
  /** What the last key wrote, to check against the clip the export brings back: its pose, each joint's numbers. */
  let keyed: { pose: PoseRef; joints: Map<string, readonly [number, number, number]> } | null = null;
  let settle: ReturnType<typeof setTimeout> | undefined;
  /** The pose last told to the host and the poser: a change of it drops edits, said. */
  let shownPose: PoseRef | null = null;
  let shownPlaying = false;
  let shownClip: string | null = null;

  const player = new Player({
    draw: () => host.draw(),
    changed: (playing) => poseMoved(playing),
    afterApply: () => poser.applyHeld(),
  });
  const poser = new Poser(host.scene, host.element, {
    restOf: (bone) => player.restOf(bone),
    names: () => player.allBones.map((b) => (typeof b.userData.name === 'string' && b.userData.name !== '' ? b.userData.name : b.name)),
    dragging(active) {
      if (active) {
        message = null;
        return;
      }
      // Let go: the bounds are the pose's for picking, and Auto key writes what was let go of (D122).
      player.refreshBounds();
      if (host.prefs().autoKey && poser.hasEdits) void key(true);
      draw();
    },
    posed() {
      host.draw();
    },
    redraw: () => host.draw(),
    changed: () => draw(),
  });
  host.scene.add(weights.group, player.bones);

  const panel = createAnimationPanel({
    choose: (name, play) => {
      message = null;
      // A clip chosen over a build step: the model back first -- a clip plays on the model, never hidden under a step.
      if (host.traced()) host.leaveTrace();
      player.choose(name, 0, play && name !== null);
    },
    toggle: () => player.toggle(),
    step: (by) => player.step(by),
    toStart: () => player.seek(0),
    toEnd: () => player.seek(player.current?.duration ?? 0),
    seek: (time) => player.seek(time),
    setSpeed(speed) {
      const kept = MODEL_SPEEDS.find((v) => v === speed);
      if (kept === undefined) return;
      player.setSpeed(kept);
      host.keepPrefs({ speed: kept });
    },
    setLoop: (on) => player.setLoop(on),
    setBones: (on) => setBones(on),
    setMode: (mode) => setMode(mode),
    ask: () => ask(),
    keepEveryKey: () => void keepEveryKey(),
    setNumbers(values, done) {
      if (!editable()) return;
      message = null;
      poser.setNumbers(values);
      if (done) {
        player.refreshBounds();
        clearTimeout(settle);
        if (host.prefs().autoKey && poser.hasEdits) settle = setTimeout(() => void key(true), SETTLE_MS);
      }
    },
    reset() {
      poser.reset();
      message = null;
      player.apply();
    },
    key: () => void key(false),
    setAuto(on) {
      host.keepPrefs({ autoKey: on });
      host.say(on ? `Auto key on: a bone let go is written as a key at once${poser.hasEdits ? ' -- the pose held now too' : ''}` : 'Auto key off: Key writes the pose');
      // Turned on with a pose held: that pose is what "record from now" means (D122).
      if (on && poser.hasEdits) void key(true);
      draw();
    },
    folded: (folded) => host.keepFold('animation', folded),
    say: (text) => host.say(text),
  });
  panel.setFolded(host.folds().animation === true);

  // ---------------------------------------------------------------- the script's actions

  let actionsFor: { text: string | null; list: ScriptAction[] } = { text: null, list: [] };
  const actions = (): ScriptAction[] => {
    const text = host.scriptText();
    if (actionsFor.text !== text) actionsFor = { text, list: text ? declaredActions(text) : [] };
    return actionsFor.list;
  };
  const actionOf = (name: string | undefined): ScriptAction | undefined => (name === undefined ? undefined : actions().find((a) => a.name === name));

  // ---------------------------------------------------------------- what may be done

  /** A frame held and a bone chosen whose rest is known. */
  const held = (): boolean => player.current !== null && !player.playing && poser.bone !== null && player.restOf(poser.bone) !== undefined;
  /** ...and a key could be written there: the gizmo and the fields are live -- a pose that can never be keyed is not offered. */
  const editable = (): boolean => held() && refused() === null && !host.traced();

  /** The key at the frame held, when it is a computed pose: what Ask Claude names. */
  function computedKey(): { source: string } | null {
    const clip = player.current;
    const there = clip ? keyAt(actionOf(clip.name), player.time) : undefined;
    return there && !there.editable && !there.rest ? { source: there.poseSource ?? 'an expression' } : null;
  }

  /** Why no key can be written at this frame, whatever is done to the bone: the page, the turn, the clip, the key there. */
  function refused(): string | null {
    const clip = player.current;
    if (!clip) return null;
    const why = host.readOnly();
    if (why) return why;
    if (host.held()) return 'Claude\'s turn is editing the script: key it once the turn ends';
    const action = actionOf(clip.name);
    if (!action) return `"${clip.name}" has no action{} in the script -- an imported clip keeps its keys in the file it came from, so there is no key here to write`;
    if (action.problem) return `"${clip.name}": ${action.problem}`;
    const there = keyAt(action, player.time);
    if (there?.rest) return `The key at ${Number(player.time.toFixed(3))} s is a rest key ("back to the rest pose"): pose another frame, or take rest = true out of it`;
    if (there && !there.editable) return `The key at ${Number(player.time.toFixed(3))} s is computed -- pose=${there.poseSource ?? '…'} -- so it cannot be posed here: writing over it would lose what the script means. Pose a frame between keys, or ask Claude to change the call`;
    return null;
  }

  /** Why Key cannot write now, in the order a person meets them; null when it can. */
  function blocked(): string | null {
    if (host.traced()) return `A build step is shown in the model's place: ${keyLabel('Escape')} back to the model to pose`;
    if (!player.current) return 'Choose a clip and hold a frame: the rest pose is the script\'s own, not a key';
    if (player.playing) return `Pause (${keyLabel('Space')}): a pose belongs to one frame`;
    if (!poser.bone) return 'Select a bone to pose';
    const why = refused();
    if (why) return why;
    if (host.writing()) return 'A step is being written: a moment';
    return null;
  }

  /**
   * A computed key's way forward (M30's): words in the Claude card's box -- the script, the clip, the time and frame,
   * the bone, the call as written, and the pose wanted if one was made before it was refused -- for the person to
   * read, change and send. Never sent by itself.
   */
  function ask(): void {
    const clip = player.current;
    const bone = poser.bone;
    const key = computedKey();
    const path = host.scriptPath();
    if (!clip || !bone || !key || !path) return;
    const joint = poser.jointName(bone);
    const r = poser.readout();
    const now = r ? `forward ${r.forward}, left ${r.left}, twist ${r.twist}` : '';
    const wanted = r && poser.hasEdits ? `so that ${joint} is at ${now} (degrees from rest, Gladius's forward/left/twist)` : `so that ${joint} is posed as I describe: (it is at ${now} now -- degrees from rest, forward/left/twist)`;
    const text = `In ${path}, change the key of action "${clip.name}" at ${Number(player.time.toFixed(3))} s (frame ${frameAt(clip, player.time)}, ${poseText(player.pose)}) -- pose=${key.source} -- ${wanted}; keep the other joints there as they are.`;
    if (!host.askClaude(text)) return host.say('No Claude card here (it needs the dev server): change the key in the script');
    host.say('Written in the Claude card\'s box: finish it and send it to have the key changed');
  }

  /** The key smoothed away by the export's reduction: `anim` 0 written to the record, one step, the export made again. */
  async function keepEveryKey(): Promise<void> {
    message = null;
    draw();
    if (await host.keepEveryKey()) host.say(`anim 0: every key kept -- written to the record, the model exported again; ${keyLabel('KeyZ')} takes it back`);
  }

  function setMode(mode: PoseMode | 'scale'): void {
    if (mode === 'scale') return host.say(SCALE_WHY);
    poser.setMode(mode);
    host.say(mode === 'rotate' ? 'The gizmo turns the bone: its rings' : 'The gizmo moves the bone off its rest place: its arrows');
  }

  /** The pose written into the script as a key: one step of the tab's undo. */
  async function key(auto: boolean): Promise<void> {
    clearTimeout(settle);
    const why = blocked();
    if (why || !poser.hasEdits) {
      const words = why ?? 'Nothing posed to key: turn the bone first -- the gizmo, or the fields';
      message = { text: words, ok: false };
      draw();
      if (!auto) host.say(words);
      return;
    }
    const clip = player.current!;
    const time = player.time;
    const edits = poser.edits();
    const joints = Object.keys(edits);
    const turned = Object.values(edits).some((e) => e.rotation && (Math.abs(e.rotation.forward) > 1e-3 || Math.abs(e.rotation.left) > 1e-3 || Math.abs(e.rotation.twist) > 1e-3));
    const moved = Object.values(edits).some((e) => e.translate?.some((n) => Math.abs(n) > 1e-6));
    const what = turned && moved ? 'rot+move' : moved ? 'move' : 'rot';
    const label = `Key: ${joints.join(', ')} ${what} at ${clip.name} ${frameAt(clip, time)}`;
    let note = '';
    let problem: string | null = null;
    const pushed = await host.editScript(label, (text) => {
      const r = poseEdit(text, { clip: clip.name, time, joints: edits });
      if ('problem' in r) {
        problem = r.problem;
        return r;
      }
      note = r.note;
      return r.text;
    });
    if (pushed) {
      wrote = true;
      keyed = { pose: { action: clip.name, time }, joints: new Map(Object.entries(edits).map(([name, e]) => [name, [e.rotation?.forward ?? 0, e.rotation?.left ?? 0, e.rotation?.twist ?? 0] as const])) };
      // Exported is said once the export has come back -- built, or not (`built`).
      message = { text: `${label.slice(5)}: ${note} -- written into the script; building…`, ok: true };
      host.say(`${label}${auto ? ' (auto key)' : ''} -- ${note}, written; building -- ${keyLabel('KeyZ')} takes it back`);
    } else message = { text: problem ?? 'Not written: the line above says why', ok: false };
    draw();
  }

  /**
   * The export of a key just written, checked: each joint keyed read back at its frame. The export's animation
   * reduction (the record's `anim`, 5 % of 180° by default: about 9°) drops a change smaller than that -- said, with the
   * way to keep it, rather than a key that seems to have done nothing (Vibe3D D123).
   */
  function checkKeyed(was: NonNullable<typeof keyed>): void {
    const pose = player.pose;
    if (!pose || pose.action !== was.pose.action || Math.abs(pose.time - was.pose.time) > 1e-3) return;
    const off: string[] = [];
    for (const bone of player.allBones) {
      const name = poser.jointName(bone);
      const want = was.joints.get(name);
      const rest = player.restOf(bone);
      if (!want || !rest) continue;
      const got = describe(rest, bone.quaternion, bone.position);
      const most = Math.max(Math.abs(got.forward - want[0]), Math.abs(got.left - want[1]), Math.abs(got.twist - want[2]));
      if (most > 0.5) off.push(`${name} by ${most.toFixed(1)}°`);
    }
    if (off.length === 0) {
      message = { text: `${keyLine(was)} -- written into the script and exported; ${keyLabel('KeyZ')} takes it back`, ok: true };
      // The editor's line too: it said "written; building" -- the build has landed.
      host.say(`Key: ${keyLine(was)} -- written and built; ${keyLabel('KeyZ')} takes it back`);
      draw();
      return;
    }
    message = { text: `The key is in the script, but the export plays it off -- ${off.join(', ')}: its animation reduction (the record's anim, 5 % ≈ 9° by default) smooths away a change that small`, ok: false, keep: true };
    host.say(`The export smoothed the key away (${off.join(', ')}): the record's anim reduction -- 0 keeps every key`);
    draw();
  }

  /** The key just written, said: its joints at its clip and frame. */
  function keyLine(was: NonNullable<typeof keyed>): string {
    const clip = player.list.find((c) => c.name === was.pose.action);
    return `${[...was.joints.keys()].join(', ')} at ${was.pose.action} ${clip ? frameAt(clip, was.pose.time) : Number(was.pose.time.toFixed(3))}`;
  }

  /** The source's build ended without a model: a key just written did not build -- said, with the way back. */
  function built(failed: string | null): void {
    if (failed === null || !wrote || !keyed) return;
    const line = keyLine(keyed);
    wrote = false;
    keyed = null;
    message = { text: `${line} written; the build failed: ${failed} -- ${keyLabel('KeyZ')} takes it back`, ok: false };
    host.say(`The key (${line}) is written, but the script does not build: ${failed} -- ${keyLabel('KeyZ')} takes it back`);
    draw();
  }

  function setBones(on: boolean): void {
    player.setBones(on);
    host.keepPrefs({ bones: on });
    host.say(on ? 'Bones shown: a click on a bone\'s line picks it' : 'Bones hidden');
    draw();
  }

  // ---------------------------------------------------------------- the pose moving

  /** The clip, its time or its playing changed: edits of another frame dropped and said, the stage and the panel told. */
  function poseMoved(playing: boolean): void {
    const pose = player.pose;
    const held = playing ? null : pose;
    if (poser.setFrame(held)) host.say(`The pose ${poseText(shownPose)} was not keyed and is dropped: a pose belongs to its frame -- Key it before moving on (${keyLabel('KeyK')})`);
    const moved = poseText(pose) !== poseText(shownPose) || playing !== shownPlaying;
    // A frame of playback alone: the clock and the playhead; anything else -- it starts, stops, another clip -- the whole.
    const ticking = playing && shownPlaying && shownClip === (player.current?.name ?? null);
    if (moved) message = null;
    shownPose = held;
    shownPlaying = playing;
    shownClip = player.current?.name ?? null;
    host.setPosed(!player.atRest);
    if (ticking) panel.tick({ current: player.current, time: player.time, playing });
    else draw();
    if (moved && !playing) host.changed();
  }

  // ---------------------------------------------------------------- drawing

  function view(): AnimationView {
    const clip = player.current;
    const action = actionOf(clip?.name);
    return {
      clips: player.list,
      current: clip,
      time: player.time,
      playing: player.playing,
      speed: player.speed,
      loop: clip ? player.loops(clip) : false,
      rigged: player.allBones.length > 0,
      bones: player.bonesShown,
      keys: action ? action.keys.map((k) => k.time) : null,
      pose: {
        bones: selectedBones.map((b) => poser.jointName(b)),
        readout: poser.bone ? poser.readout() : null,
        mode: poser.currentMode,
        auto: host.prefs().autoKey,
        editable: editable(),
        blocked: host.traced() || (poser.bone && player.current) ? blocked() : null,
        message,
        weights: facts,
        ask: held() && computedKey() !== null,
        keepKeys: message?.keep === true,
      },
    };
  }

  function draw(): void {
    poser.setAvailable(editable());
    panel.draw(view());
  }

  function remap(): void {
    facts = weights.set(player.meshes, selectedBones, selectedBones.map((b) => poser.jointName(b)));
  }

  /** The view the pointer was last over -- its camera and its rectangle, GL's way up: the gizmo reads the pointer there, and goes back to it after each view is drawn. */
  let pointed: { view: PaintView; height: number } | null = null;
  const toPointed = (): void => {
    if (!pointed) return;
    const { view: v, height } = pointed;
    poser.view(v.cam.camera, v.rect.x, height - v.rect.y - v.rect.height, v.rect.width, v.rect.height);
  };
  /** The bone's name under the pointer, with Bones on: which line is which, before a click. */
  const nameTip = document.createElement('div');
  nameTip.className = 'ed-mo-bonetip';
  nameTip.hidden = true;
  host.element.append(nameTip);
  let lit: THREE.Bone | null = null;
  const stage: StagePose = {
    grabbing: () => poser.grabbing,
    hover(v, height, x, y) {
      let under: THREE.Bone | null = null;
      if (v) {
        pointed = { view: v, height };
        v.cam.update();
        toPointed();
        if (!poser.grabbing && !poser.dragging) under = player.pickBone(v.cam.camera, x - v.rect.x, y - v.rect.y, v.rect.width, v.rect.height);
      }
      nameTip.hidden = under === null;
      if (under) {
        nameTip.textContent = poser.jointName(under);
        nameTip.style.left = `${x + 14}px`;
        nameTip.style.top = `${y + 10}px`;
      }
      if (under !== lit) {
        lit = under;
        if (player.markBones(selectedBones, lit)) host.draw();
      }
    },
    drawing(v) {
      if (v) {
        poser.drawFor(v.cam.camera);
        player.bonesFor(v.rect.width, v.rect.height);
      } else toPointed();
    },
    pick(v, x, y) {
      v.cam.update();
      return player.pickBone(v.cam.camera, x - v.rect.x, y - v.rect.y, v.rect.width, v.rect.height);
    },
    place() {
      weights.place();
      player.placeBones();
    },
  };

  // The kept choices, once everything they reach is made.
  player.setSpeed(MODEL_SPEEDS.find((v) => v === host.prefs().speed) ?? 1);
  player.setBones(host.prefs().bones);

  return {
    block: panel.block,
    strip: panel.strip,
    stage,
    overlays: [player.bones, weights.group, poser.helper],
    setModel(scene, animations, first) {
      clearTimeout(settle);
      const bones: THREE.Bone[] = [];
      scene?.traverse((o) => {
        if (isBone(o)) bones.push(o);
      });
      // The edits onto the new bones by name -- unless the key just written is in this model's clip now.
      poser.carry(bones, first || wrote);
      const check = wrote && !first ? keyed : null;
      // A model not of the key just written -- opened, undone, saved elsewhere: what was said of a key is past.
      // ...but not the word that the script changed outside under a pose held: the rebuild that follows is that change.
      if (!check && !(message?.sticky && poser.hasEdits)) message = null;
      wrote = false;
      keyed = null;
      weights.clear();
      facts = null;
      player.setModel(scene, animations);
      if (check) checkKeyed(check);
      // The selection's bones are the new model's: `selection` follows from the tab.
      draw();
    },
    selection(objects) {
      selectedBones = objects.filter(isBone);
      poser.attach(selectedBones[0] ?? null);
      player.markBones(selectedBones, lit);
      remap();
      draw();
      host.draw();
      host.changed();
    },
    get pose() {
      return player.pose;
    },
    turnPose() {
      const pose = player.pose;
      if (!pose) return null;
      return `${poseText(pose)}${player.playing ? ' (playing)' : ''}${poser.hasEdits ? `, with ${poser.joints.join(', ')} posed by hand on top -- not keyed` : ''}`;
    },
    goTo(pose) {
      player.goTo(pose);
    },
    pause: () => player.pause(),
    get hasClips() {
      return player.list.length > 0;
    },
    clipNames: () => player.list.map((c) => c.name),
    get rigged() {
      return player.allBones.length > 0;
    },
    get weights() {
      return facts;
    },
    get typing() {
      return panel.typing;
    },
    toggle: () => player.toggle(),
    step: (by) => player.step(by),
    toStart: () => player.seek(0),
    toEnd: () => player.seek(player.current?.duration ?? 0),
    key: () => void key(false),
    toggleBones: () => setBones(!player.bonesShown),
    get dragging() {
      return poser.dragging;
    },
    get posing() {
      return editable();
    },
    setMode,
    built,
    outside(label) {
      if (!poser.hasEdits) return;
      const file = host.scriptPath()?.split('/').pop() ?? 'The script';
      message = { text: `${file} changed outside (${label.replace(/^.*edited outside\s*/, '').replace(/[()]/g, '') || 'another editor'}) -- your pose, not keyed yet, is kept: Key writes it into the script as it is now`, ok: false, sticky: true };
      host.say(`${file} changed outside while a pose was held: the pose is kept -- Key writes it into the new script`);
      draw();
    },
    redraw: draw,
    dispose() {
      clearTimeout(settle);
      poser.dispose();
      nameTip.remove();
      player.dispose();
      weights.dispose();
      host.scene.remove(weights.group, player.bones);
    },
  };
}

