/**
 * The build trace drawn (Docs/modeler.md M34-M37; Vibe3D D66, D70, D76, D77):
 * the trace's GLB decoded, one node a step, and what is on screen at a step --
 * with the move into it animated.
 *
 * - **One decode, every frame** (D66): the trace's scene is kept whole (its
 *   steps' nodes, their grow-from shapes and frames, the script's own emits);
 *   a step shown is a set of nodes visible, nothing built.
 * - **A one-step move animates** (D66, the length the panel says): **frames**
 *   where the op was built at growing amounts (played backwards stepping
 *   back), **edges** for an op that moves nothing (D70: its cut drawn, fading
 *   in, and kept while it is the step), a **morph** where the vertex count
 *   held (a translate slides; an extrude grows out of its grow-from shape),
 *   else a **fade** of the arriving mesh over a cloned material (the steps
 *   share their grey). Forward the transition is the step entered's; back,
 *   the step left's, run backwards.
 * - **A transition puts back its own step** (D77): it holds the geometry and
 *   materials it borrowed, and `end` writes exactly those back, whatever is
 *   current now -- never the step shown since. **A fault in a step's geometry
 *   costs that transition, not the frame**: `advance` catches it, says it
 *   once, ends the tween as best it can and drops it; the step shows as it is.
 * - **One line object for its life** (D76): the cut's `LineSegments2` and its
 *   material are made once; a new cut writes new positions, its program kept.
 *   A cut is worked out once per step and kept.
 */
import * as THREE from 'three';
import type { GLTF } from 'three/addons/loaders/GLTFLoader.js';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';
import type { TraceStep } from '@vibe/pipeline/assets-types';
import { disposeModel } from '@vibe/engine';
import { cutSegments, liveAt, sourceOf, type TraceView as Showing, type Tris } from './trace-steps.ts';

/** A cut's lines: added (a knife) and taken away (a dissolve), in the editor's blue and orange. */
const CUT_ADDED = 0x4aa8ff;
const CUT_REMOVED = 0xe0912a;
/** Wide enough to read over a lit surface without being a bar (D70). */
const CUT_PX = 3.5;

/** `__trace_0007`, `__trace_0007_from`, `__trace_0007_f03`. */
const NODE = /^__trace_(\d+)(?:_(from)|_f(\d+))?$/;

/** A transition under way, and what it borrowed -- to give back exactly (D77). */
interface Tween {
  elapsed: number;
  duration: number;
  /** The step it moves into, or out of: whose polygons hide while it moves. */
  step: number;
  morph?: { mesh: THREE.Mesh; attribute: THREE.BufferAttribute; from: Float32Array; to: Float32Array; culled: boolean };
  fade?: { mesh: THREE.Mesh; original: THREE.Material | THREE.Material[]; clone: THREE.Material }[];
  frames?: { nodes: THREE.Object3D[]; target: THREE.Object3D | undefined; shown: number };
  cut?: true;
}

const meshesOf = (node: THREE.Object3D | undefined): THREE.Mesh[] => {
  const out: THREE.Mesh[] = [];
  node?.traverse((o) => {
    if ((o as THREE.Mesh).isMesh && !o.userData.modelOverlay) out.push(o as THREE.Mesh);
  });
  return out;
};
const firstMesh = (node: THREE.Object3D | undefined): THREE.Mesh | undefined => meshesOf(node)[0];
const trisOf = (mesh: THREE.Mesh): Tris | null => {
  const p = mesh.geometry.getAttribute('position');
  return p ? { positions: p.array as ArrayLike<number>, index: mesh.geometry.index ? (mesh.geometry.index.array as ArrayLike<number>) : null } : null;
};

export class TraceDrawing {
  /** In the stage's scene while a step is shown (`Stage.setTrace`): the trace's scene, and the cut's lines. */
  readonly group = new THREE.Group();
  private gltf: GLTF | null = null;
  private steps: TraceStep[] = [];
  private readonly nodes = new Map<number, THREE.Object3D>();
  private readonly from = new Map<number, THREE.Mesh>();
  private readonly frames = new Map<number, THREE.Object3D[]>();
  /** The cut each edge-only step drew, worked out once (D76); null: none found. */
  private readonly cuts = new Map<number, { segments: number[]; removed: boolean } | null>();
  private readonly cutMaterial = new LineMaterial({ color: CUT_ADDED, linewidth: CUT_PX, transparent: true, depthTest: false, depthWrite: false });
  private readonly cutLines = new LineSegments2(new LineSegmentsGeometry(), this.cutMaterial);
  private tween: Tween | null = null;
  /** A fault already said: once a trace, not every frame. */
  private faulted = false;

  constructor() {
    this.group.name = 'model: trace';
    this.cutLines.name = 'model: trace cut';
    this.cutLines.frustumCulled = false;
    this.cutLines.visible = false;
    this.cutLines.renderOrder = 8;
    this.cutLines.raycast = () => {};
    // Not a surface: the shading leaves it alone (no wireframe flag on its material, no wires of its own).
    this.cutLines.userData.modelOverlay = true;
    this.group.add(this.cutLines);
  }

  /** A trace's scene taken whole (the one before let go): its steps found by name, every node hidden. */
  load(gltf: GLTF, steps: readonly TraceStep[]): void {
    this.clear();
    this.gltf = gltf;
    this.steps = [...steps];
    gltf.scene.traverse((o) => {
      const m = NODE.exec(o.name);
      if (!m) return;
      const index = Number(m[1]);
      if (m[2]) {
        const mesh = firstMesh(o);
        if (mesh) this.from.set(index, mesh);
      } else if (m[3]) {
        const list = this.frames.get(index) ?? [];
        list[Number(m[3]) - 1] = o;
        this.frames.set(index, list);
      } else this.nodes.set(index, o);
    });
    // Every child hidden: the script's own emits (the model, a second time) and the grow-from shapes never shown.
    for (const child of gltf.scene.children) child.visible = false;
    for (const node of this.nodes.values()) node.raycast = () => {};
    this.group.add(gltf.scene);
  }

  /** Has a trace in. */
  get loaded(): boolean {
    return this.gltf !== null;
  }

  /** The step's mesh in this trace -- kept within the budget -- or none. */
  has(index: number): boolean {
    return this.nodes.has(index);
  }

  /** The trace let go: its scene, its cuts, any tween -- freed. */
  clear(): void {
    this.end();
    this.cutLines.visible = false;
    this.cuts.clear();
    this.nodes.clear();
    this.from.clear();
    this.frames.clear();
    if (this.gltf) {
      this.group.remove(this.gltf.scene);
      disposeModel(this.gltf);
    }
    this.gltf = null;
    this.steps = [];
    this.faulted = false;
  }

  /**
   * Step `index` on screen (its own number; 0 the start, nothing), Total or
   * Last; moving in over `tweenMs` from `previous` -- 0 cuts.
   */
  show(index: number, view: Showing, tweenMs: number, previous: number | null): void {
    // A tween under way belongs to the step before: what it borrowed goes back first (D77).
    this.end();
    const live = new Set(liveAt(this.steps, index, view));
    for (const [at, node] of this.nodes) node.visible = live.has(at);
    for (const list of this.frames.values()) for (const f of list) if (f) f.visible = false;
    const cut = this.cutFor(index);
    if (tweenMs > 0 && previous !== null && previous !== index) {
      try {
        this.begin(index, previous, tweenMs, cut);
      } catch (err) {
        this.fault(err);
      }
    }
    this.cutLines.visible = cut;
    if (cut && !this.tween?.cut) this.cutMaterial.opacity = 1;
  }

  /** The step whose polygons are moving under a transition -- hidden till it lands -- or null. */
  get moving(): number | null {
    return this.tween?.step ?? null;
  }

  /** Is a transition under way: the frame loop goes on while it is. */
  get animating(): boolean {
    return this.tween !== null;
  }

  /**
   * A frame of the transition, `dt` milliseconds on. A throw in a step's
   * geometry is caught here (D77): said once, the tween ended as far as it can
   * be and dropped -- a jump cut, the frame drawn all the same.
   */
  advance(dt: number): void {
    const tw = this.tween;
    if (!tw) return;
    try {
      tw.elapsed += dt;
      const t = Math.min(1, tw.elapsed / Math.max(1, tw.duration));
      // Eased out: a move that slows into place reads as one motion.
      const eased = 1 - (1 - t) * (1 - t);
      if (tw.morph) {
        const { attribute, from, to } = tw.morph;
        const a = attribute.array as Float32Array;
        for (let i = 0; i < a.length; i++) a[i] = from[i]! + (to[i]! - from[i]!) * eased;
        attribute.needsUpdate = true;
      }
      if (tw.fade) for (const f of tw.fade) f.clone.opacity = eased;
      if (tw.cut) this.cutMaterial.opacity = eased;
      if (tw.frames) {
        const { nodes } = tw.frames;
        // One short of the end: the last thing shown is the real step, put back by `end`.
        const next = Math.min(nodes.length - 1, Math.floor(eased * nodes.length));
        if (next !== tw.frames.shown) {
          nodes.forEach((n, i) => void (n.visible = i === next));
          tw.frames.shown = next;
        }
      }
      if (t >= 1) this.end();
    } catch (err) {
      this.fault(err);
    }
  }

  /** The cut's width is in the pixels of the view drawn: set before each. */
  prepare(width: number, height: number): void {
    this.cutMaterial.resolution.set(Math.max(width, 1), Math.max(height, 1));
  }

  /** The meshes on screen now: what a canvas's marks are raycast onto while a step is shown. */
  shownMeshes(): THREE.Mesh[] {
    const out: THREE.Mesh[] = [];
    for (const node of this.nodes.values()) if (node.visible) out.push(...meshesOf(node));
    return out;
  }

  /** The cut's line object -- one for the drawing's life (D76) -- for a test to read. */
  get cutObject(): LineSegments2 {
    return this.cutLines;
  }

  /** The meshes on screen at step `index` -- shown or not: a canvas's marks raycast onto the step it was drawn over. */
  meshesAt(index: number, view: Showing): THREE.Mesh[] {
    const out: THREE.Mesh[] = [];
    for (const at of liveAt(this.steps, index, view)) out.push(...meshesOf(this.nodes.get(at)));
    return out;
  }

  /** The step a mesh shown belongs to, or null. */
  stepOf(object: THREE.Object3D): number | null {
    for (let o: THREE.Object3D | null = object; o; o = o.parent) {
      const m = NODE.exec(o.name);
      if (m && !m[2] && !m[3]) return Number(m[1]);
    }
    return null;
  }

  /** The node of a step: what the polygons of that step follow. */
  nodeOf(index: number): THREE.Object3D | null {
    return this.nodes.get(index) ?? null;
  }

  dispose(): void {
    this.clear();
    this.cutLines.geometry.dispose();
    this.cutMaterial.dispose();
  }

  // ---------------------------------------------------------------- the transitions

  /** The cut of an edge-only step, drawn into the one line object -- false where there is none to draw. */
  private cutFor(index: number): boolean {
    const step = this.steps.find((s) => s.index === index);
    if (!step?.edges) return false;
    let cut = this.cuts.get(index);
    if (cut === undefined) {
      const source = sourceOf(this.steps, index);
      const after = firstMesh(this.nodes.get(index));
      const before = source === null ? undefined : firstMesh(this.nodes.get(source));
      const a = after ? trisOf(after) : null;
      const b = before ? trisOf(before) : null;
      const found = a && b ? cutSegments(b, a) : null;
      cut = found && found.segments.length > 0 ? found : null;
      this.cuts.set(index, cut);
    }
    if (!cut) return false;
    // A cut of another length gets a geometry of its own: three keeps an instanced geometry's count from its first draw
    // (`_maxInstanceCount`, cleared only by dispose), so a longer cut written into the old one drew a part of it. The
    // line object and its material stay -- the program is never compiled again (D76).
    const had = this.cutLines.geometry as LineSegmentsGeometry;
    if (had.instanceCount !== cut.segments.length / 6) {
      had.dispose();
      this.cutLines.geometry = new LineSegmentsGeometry();
    }
    (this.cutLines.geometry as LineSegmentsGeometry).setPositions(cut.segments);
    this.cutMaterial.color.set(cut.removed ? CUT_REMOVED : CUT_ADDED);
    return true;
  }

  private begin(index: number, previous: number, duration: number, cut: boolean): void {
    const forward = index > previous;
    // Forward the step entered's own move; back, the step left's, run the other way.
    const owner = forward ? index : previous;
    const frames = this.frames.get(owner)?.filter((f) => f !== undefined);
    const target = this.nodes.get(index);
    if (frames && frames.length > 0) {
      if (target) target.visible = false;
      this.tween = { elapsed: 0, duration, step: owner, frames: { nodes: forward ? frames : [...frames].reverse(), target, shown: -1 } };
      return;
    }
    if (cut) {
      this.cutMaterial.opacity = 0;
      this.tween = { elapsed: 0, duration, step: index, cut: true };
      return;
    }
    const mesh = firstMesh(target);
    if (!mesh) return;
    // Out of: forward, the op's own grow-from shape, else the one mesh it was made from; back, the step left.
    const source = sourceOf(this.steps, index);
    const fromMesh = forward ? (this.from.get(index) ?? (source === null ? undefined : firstMesh(this.nodes.get(source)))) : firstMesh(this.nodes.get(previous));
    const to = mesh.geometry.getAttribute('position') as THREE.BufferAttribute | undefined;
    const was = fromMesh?.geometry.getAttribute('position') as THREE.BufferAttribute | undefined;
    if (to && was && to.count === was.count && to.itemSize === 3 && was.itemSize === 3) {
      const culled = mesh.frustumCulled;
      // Its bounds describe neither end of the move: a mesh that vanishes half way reads as a fault.
      mesh.frustumCulled = false;
      this.tween = { elapsed: 0, duration, step: index, morph: { mesh, attribute: to, from: Float32Array.from(was.array as ArrayLike<number>), to: Float32Array.from(to.array as ArrayLike<number>), culled } };
      return;
    }
    // The last resort: the arriving step fades in, over clones -- the steps share one grey, and fading it would fade them all.
    const fade = meshesOf(target).map((m) => {
      const original = m.material;
      const clone = (Array.isArray(original) ? original[0]! : original).clone();
      clone.transparent = true;
      clone.opacity = 0;
      m.material = clone;
      return { mesh: m, original, clone };
    });
    this.tween = { elapsed: 0, duration, step: index, fade };
  }

  /** What the tween borrowed, given back exactly -- its own, not the step current now (D77). Safe with none. */
  private end(): void {
    const tw = this.tween;
    if (!tw) return;
    this.tween = null;
    if (tw.morph) {
      (tw.morph.attribute.array as Float32Array).set(tw.morph.to);
      tw.morph.attribute.needsUpdate = true;
      tw.morph.mesh.frustumCulled = tw.morph.culled;
    }
    if (tw.fade) for (const f of tw.fade) {
      f.mesh.material = f.original;
      f.clone.dispose();
    }
    if (tw.cut) this.cutMaterial.opacity = 1;
    if (tw.frames) {
      for (const n of tw.frames.nodes) n.visible = false;
      // The step shown, held back while its frames played: a step is always among what is shown at it.
      if (tw.frames.target) tw.frames.target.visible = true;
    }
  }

  /** A transition that threw: said once a trace, ended as far as it can be, dropped. */
  private fault(err: unknown): void {
    if (!this.faulted) console.warn('[model] a build trace step could not be animated -- shown as it is', err);
    this.faulted = true;
    try {
      this.end();
    } catch {
      this.tween = null;
    }
    this.tween = null;
  }
}
