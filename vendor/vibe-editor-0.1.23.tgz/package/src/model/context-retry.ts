/**
 * The Model tab stage's WebGL context, kept (Docs/modeler.md M2): made when
 * first wanted; one that cannot be made -- a GPU process resetting, the
 * browser's sixteen or so contexts all taken -- tried again on a growing
 * delay (`RETRY_MS`) while the tab shows, and from the start as it is next
 * shown; one lost is dropped and made again after the first delay, never at
 * once (a context asked for while the GPU resets is refused, and the stage
 * stayed blank for good: review, Model tab).
 *
 * Pure: the making and the timers are handed in (`context-retry.test.ts`).
 */

/** The delays before each try again, in ms: then the last, for as long as the tab shows. */
export const RETRY_MS: readonly number[] = [250, 1000, 4000];

export interface RetryHost<T> {
  /** A context made, or a throw: none could be had. */
  make(): T;
  /** The tab shows: tries go on only while it does. */
  wanted(): boolean;
  /** Made, first or again: put in place. `again`: after a loss or a failed try. */
  made(value: T, again: boolean): void;
  /** A try failed, the `tries`th in a row. */
  failed(err: unknown, tries: number): void;
  setTimer(fn: () => void, ms: number): unknown;
  clearTimer(handle: unknown): void;
}

export interface ContextRetry<T> {
  /** What was made, or null. */
  readonly value: T | null;
  /** A try is waiting on its delay. */
  readonly waiting: boolean;
  /** The context, made now if there is none and no try is waiting or given up on while hidden: null while none can be had. */
  get(): T | null;
  /** The context lost: dropped, and made again after the first delay. */
  lost(): void;
  /** The tab shown again: the delays from the start, and a try now if there is no context. */
  again(): T | null;
  dispose(): void;
}

export function contextRetry<T>(host: RetryHost<T>): ContextRetry<T> {
  let value: T | null = null;
  let timer: unknown = null;
  /** Failed tries in a row since the last made or the last `again`. */
  let tries = 0;
  /** Lost, or failed: the next made is "again". */
  let lacking = false;
  let disposed = false;

  const cancel = (): void => {
    if (timer !== null) host.clearTimer(timer);
    timer = null;
  };
  const schedule = (ms: number): void => {
    if (disposed || timer !== null || !host.wanted()) return;
    timer = host.setTimer(() => {
      timer = null;
      if (value === null && !disposed && host.wanted()) attempt();
    }, ms);
  };
  function attempt(): T | null {
    try {
      value = host.make();
    } catch (err) {
      tries++;
      lacking = true;
      host.failed(err, tries);
      schedule(RETRY_MS[Math.min(tries, RETRY_MS.length) - 1]!);
      return null;
    }
    const again = lacking;
    tries = 0;
    lacking = false;
    host.made(value, again);
    return value;
  }

  return {
    get value() {
      return value;
    },
    get waiting() {
      return timer !== null;
    },
    get() {
      if (value !== null || disposed) return value;
      // On its delay, or failed while hidden: `again` as the tab shows.
      if (timer !== null || tries > 0) return null;
      return attempt();
    },
    lost() {
      value = null;
      lacking = true;
      cancel();
      // Not tried at once: the next ask waits on the delay too.
      tries = 0;
      if (host.wanted()) schedule(RETRY_MS[0]!);
      else tries = 1;
    },
    again() {
      if (value !== null || disposed) return value;
      cancel();
      tries = 0;
      return attempt();
    },
    dispose() {
      disposed = true;
      cancel();
      value = null;
    },
  };
}
