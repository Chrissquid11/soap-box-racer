/**
 * The model's parts, as the outliner and the stats have them (Docs/modeler.md
 * M12, M13; Vibe3D D29, D41, D65, D91): the tree of a loaded glTF, the rows as
 * drawn, what a click and an eye do, what survives a rebuild, and the totals --
 * three.js objects read, no DOM, so a node test holds every rule
 * (`parts.test.ts`).
 *
 * - **A part is a node of the glTF** under its scene: a mesh, a skinned mesh,
 *   a bone or an empty (D91), named as the script named it (`emit{name=…}`, as
 *   GLTFLoader keeps it). Flat in practice -- `emit` takes no parent -- any
 *   nesting a glTF has is kept.
 * - **Its id is its path of names** (`body/lid`, a second `lid` under one
 *   parent `lid#2`): the same after a rebuild while the script keeps its names,
 *   so the selection and the hidden parts are carried across by it (D29, D65);
 *   one the script dropped falls out.
 * - **A click selects as the Scene tree's** (`clickHow`): alone, the part;
 *   Mod, toggled; Shift, the rows as drawn from the first selected to it
 *   (D65's range, over D29's refusal) -- with Mod, added.
 * - **The eye acts on the selection** when its row is in it, alone otherwise;
 *   which way -- hide or show -- from the clicked row alone (D65).
 * - **Totals over a part and everything under it**, each once; a bone is no
 *   object (D111), and its triangles are none.
 */
import * as THREE from 'three';
import { combined, rangeOf, type ClickHow, type Combine } from '../selection.ts';

export type PartKind = 'mesh' | 'skinned' | 'bone' | 'empty';

export interface Part {
  /** Its path of names: stable across a rebuild while the script keeps them. */
  readonly id: string;
  /** As the script named it -- as three.js keeps it. */
  readonly name: string;
  readonly kind: PartKind;
  readonly object: THREE.Object3D;
  readonly parent: Part | null;
  readonly children: Part[];
  /** 0 for a part right under the model. */
  readonly depth: number;
  /** Its own, not its children's: 0 for a bone or an empty. */
  readonly triangles: number;
  /** As stored in the GLB -- split at every seam -- 0 for no mesh. */
  readonly vertices: number;
  /** Its material's name, or the names of several, '' for none or unnamed. */
  readonly material: string;
}

export interface PartTree {
  /** Those right under the model, in order. */
  readonly roots: readonly Part[];
  /** Every part, parents before children, in order: the rows with nothing folded. */
  readonly all: readonly Part[];
  readonly byId: ReadonlyMap<string, Part>;
  /** A three.js object's part: what a click in the views picked. */
  readonly byObject: ReadonlyMap<THREE.Object3D, Part>;
}

export function kindOf(object: THREE.Object3D): PartKind {
  if ((object as THREE.Bone).isBone) return 'bone';
  if ((object as THREE.SkinnedMesh).isSkinnedMesh) return 'skinned';
  return (object as THREE.Mesh).isMesh ? 'mesh' : 'empty';
}

/** A mesh's triangles, by its index or its positions. */
export function trianglesOf(geometry: THREE.BufferGeometry): number {
  const index = geometry.getIndex();
  const count = index ? index.count : (geometry.getAttribute('position')?.count ?? 0);
  return Math.floor(count / 3);
}

const materialName = (material: THREE.Material | THREE.Material[]): string =>
  (Array.isArray(material) ? material : [material]).map((m) => m.name).filter((n) => n !== '').join(', ');

/** The model's parts: every node under `model` -- the glTF's scene -- as a tree. */
export function partsOf(model: THREE.Object3D): PartTree {
  const all: Part[] = [];
  const byId = new Map<string, Part>();
  const byObject = new Map<THREE.Object3D, Part>();
  const walk = (objects: readonly THREE.Object3D[], parent: Part | null, depth: number): Part[] => {
    const out: Part[] = [];
    const used = new Map<string, number>();
    for (const object of objects) {
      const kind = kindOf(object);
      const name = object.name !== '' ? object.name : `(${kind})`;
      const n = (used.get(name) ?? 0) + 1;
      used.set(name, n);
      const own = n === 1 ? name : `${name}#${n}`;
      const mesh = kind === 'mesh' || kind === 'skinned' ? (object as THREE.Mesh) : null;
      const part: Part = {
        id: parent ? `${parent.id}/${own}` : own,
        name,
        kind,
        object,
        parent,
        children: [],
        depth,
        triangles: mesh ? trianglesOf(mesh.geometry) : 0,
        vertices: mesh ? (mesh.geometry.getAttribute('position')?.count ?? 0) : 0,
        material: mesh ? materialName(mesh.material) : '',
      };
      all.push(part);
      byId.set(part.id, part);
      byObject.set(object, part);
      out.push(part);
      part.children.push(...walk(object.children, part, depth + 1));
    }
    return out;
  };
  const roots = walk(model.children, null, 0);
  return { roots, all, byId, byObject };
}

/** The rows as drawn: every part, but those under a folded one. */
export function rowsOf(tree: PartTree, folded: ReadonlySet<string>): Part[] {
  const out: Part[] = [];
  const walk = (parts: readonly Part[]): void => {
    for (const part of parts) {
      out.push(part);
      if (!folded.has(part.id)) walk(part.children);
    }
  };
  walk(tree.roots);
  return out;
}

/** Every part `id`'s rows hide under a fold: its ancestors, which must be unfolded for it to be seen. */
export function ancestorsOf(tree: PartTree, id: string): string[] {
  const out: string[] = [];
  for (let p = tree.byId.get(id)?.parent ?? null; p; p = p.parent) out.push(p.id);
  return out;
}

/** The selection after a click on `id` with `how`, over `rows` -- the ids as drawn. The first is the one shown. */
export function clickPart(now: readonly string[], rows: readonly string[], id: string, how: ClickHow): string[] {
  if (how === 'one') return [id];
  if (how === 'add') return combined(now, [id], 'add');
  if (how === 'toggle') return combined(now, [id], 'toggle');
  // A range from the first selected -- the one shown -- to this one, in the rows' order; with nothing selected, this one.
  const from = now[0];
  const span = from === undefined ? null : rangeOf(rows, from, id);
  if (!span) return how === 'add-range' ? combined(now, [id], 'add') : [id];
  return how === 'range' ? span : combined(now, span, 'add');
}

/** Several at once -- a box drawn -- into the selection: in its place, added, or each turned over. */
export function boxParts(now: readonly string[], these: readonly string[], how: Combine): string[] {
  return combined(now, these, how);
}

/** Is a part hidden: itself, or any part above it? */
export function hiddenOf(part: Part, hidden: ReadonlySet<string>): boolean {
  for (let p: Part | null = part; p; p = p.parent) if (hidden.has(p.id)) return true;
  return false;
}

/**
 * The hidden parts after a click on `id`'s eye (D65): every selected part with
 * it when it is selected, it alone when not; hidden if it was shown, shown if
 * it was hidden -- its own state, not the set's.
 */
export function eyeClick(hidden: ReadonlySet<string>, selection: readonly string[], id: string): { hidden: Set<string>; ids: string[]; hide: boolean } {
  const ids = selection.includes(id) ? [...selection] : [id];
  const hide = !hidden.has(id);
  const next = new Set(hidden);
  for (const each of ids) {
    if (hide) next.add(each);
    else next.delete(each);
  }
  return { hidden: next, ids, hide };
}

/** What the eye says it will do, on its hover, before it is clicked: how far it reaches. */
export function eyeTitle(hidden: ReadonlySet<string>, selection: readonly string[], id: string, name: string): string {
  const hide = !hidden.has(id);
  const many = selection.includes(id) && selection.length > 1;
  const verb = hide ? 'Hide' : 'Show';
  return many ? `${verb} all ${selection.length} selected` : `${verb} ${name}`;
}

/** Ids that are still parts of the model rebuilt, in their order: a name the script dropped falls out. */
export function kept(ids: Iterable<string>, tree: PartTree): string[] {
  return [...ids].filter((id) => tree.byId.has(id));
}

/** These parts and every one under them, each once, in order. */
export function withChildren(tree: PartTree, ids: readonly string[]): Part[] {
  const seen = new Set<string>();
  const out: Part[] = [];
  const walk = (part: Part): void => {
    if (seen.has(part.id)) return;
    seen.add(part.id);
    out.push(part);
    for (const child of part.children) walk(child);
  };
  for (const id of ids) {
    const part = tree.byId.get(id);
    if (part) walk(part);
  }
  return out;
}

/**
 * A totals line's numbers: objects (no bones), triangles, vertices -- the
 * kernel's where it holds every mesh counted (`stats.ts`' `partTotals`), else
 * as the GLB stores them (`stored`: split at every seam), said so.
 */
export interface PartTotals {
  objects: number;
  triangles: number;
  vertices: number;
  stored: boolean;
}

/** The totals as the GLB has them: its stored vertices. */
export function totalsOf(parts: readonly Part[]): PartTotals {
  const totals: PartTotals = { objects: 0, triangles: 0, vertices: 0, stored: true };
  for (const part of parts) {
    if (part.kind === 'bone') continue;
    totals.objects++;
    totals.triangles += part.triangles;
    totals.vertices += part.vertices;
  }
  return totals;
}

/** A count as people read it: `1,234`. */
export const count = (n: number): string => n.toLocaleString('en');

/** A totals line: `2 objects · 24 triangles · 32 vertices` -- `32 stored vertices` where they are the GLB's. */
export function totalsLine(t: PartTotals): string {
  const said = (n: number, one: string, many: string): string => `${count(n)} ${n === 1 ? one : many}`;
  const vertices = t.stored ? said(t.vertices, 'stored vertex', 'stored vertices') : said(t.vertices, 'vertex', 'vertices');
  return `${said(t.objects, 'object', 'objects')} · ${said(t.triangles, 'triangle', 'triangles')} · ${vertices}`;
}
