/**
 * The Model tab's right panel (Docs/modeler.md §4), docked where the Scene
 * tab's inspector is (`sidePanel('right')`, sharing its width): with no part
 * selected, the **model** -- its script (a link to it in the Assets panel),
 * how its build stands, its export, Build now and Open script, its size and
 * totals; with parts selected, **the part** -- its name as the script has it,
 * its kind, its counts (the kernel's where they are had), its material and
 * size -- or, of several, how many and their totals. Under it, whichever is
 * shown, the blocks the tab mounts (`mount`): Parameters and Materials (phase
 * 2, `param-panel.ts`, `material-panel.ts`) -- made once, never redrawn with
 * the facts above them, so a slider in hand is never made again under it.
 */
import * as THREE from 'three';
import type { ModelDiagnostic, ModelNode } from '@vibe/pipeline/assets-types';
import { keyLabel } from '@vibe/engine/debug';
import { button, control, el, iconButton } from '../dom.ts';
import { sidePanel, type SidePanel } from '../shell.ts';
import { count, totalsLine, withChildren, type Part, type PartTree } from './parts.ts';
import { blocksShown, type BuildState } from './source.ts';
import { countsOf, partTotals } from './stats.ts';
import { metres } from './views.ts';

export interface InspectorHost {
  /** The script shown in the Assets panel, chosen. */
  reveal(path: string): void;
  /** Build now: the script exported again. */
  build(): void;
  /** The script opened in the application this machine edits it with. */
  edit(): void;
  /** The views onto the selection. */
  frame(): void;
  /** The selection hidden or shown, as Shift+H. */
  hide(): void;
  /** May this page write: Build now and Open script are not offered where not. */
  writes(): boolean;
  /** Why the script cannot be built (out of the build), or null: Build now is off, saying it. */
  unbuildable(): string | null;
  /** The card's export row (`export-row.ts`): cull, clean, merge -- made once by the tab, placed under the buttons. */
  exportRow(): HTMLElement;
  /** The model closed: a script gone has nothing else to offer. */
  close(): void;
}

export interface ModelFacts {
  path: string;
  name: string;
  exportPath: string | null;
  state: BuildState;
  /** What Gladius said of the model shown: its info() lines and warnings, with their lines. */
  told: readonly ModelDiagnostic[];
  /** Its export held for a Claude turn (M21): each save shown as a preview -- said so, as the toolbar's chip says it. */
  held?: boolean;
  /** What its last export did worth reading: hidden surfaces removed, samples dropped, a merge not made (M41, M42). */
  notes?: readonly string[];
}

/** The state line while the export is held for a Claude turn: the chip's words, not "Building…". */
export const HELD_WORDS = 'Held for Claude\'s turn -- each save shown as a preview; the export is made once no turn runs';

export interface Inspector {
  readonly root: HTMLElement;
  readonly side: SidePanel;
  draw(model: ModelFacts | null, tree: PartTree | null, selection: readonly string[], hidden: ReadonlySet<string>, kernel: ReadonlyMap<string, ModelNode>): void;
  /** Blocks of the tab's own under the facts, in order: shown while a model is open. */
  mount(...blocks: HTMLElement[]): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}

/** A build's state in a few words, and how it reads: good, busy, bad -- a fault: a failed build, a tool or the server missing, the script gone -- or quiet, a state. */
export function stateWords(state: BuildState): { words: string; tone: 'good' | 'busy' | 'bad' | 'quiet' } {
  switch (state.kind) {
    case 'ready':
      return { words: 'Built: the export is the script as it is', tone: 'good' };
    case 'building':
      return { words: `Building…${state.step ? ` (${state.step})` : ''}`, tone: 'busy' };
    case 'loading':
      return { words: 'Reading…', tone: 'busy' };
    case 'failed':
      return { words: `The last build failed: ${state.error}`, tone: 'bad' };
    case 'unmade':
      return { words: `Not made: ${state.reason}`, tone: 'bad' };
    case 'excluded':
      // A state the person chose, not a fault: said in the neutral tone (red is for what went wrong).
      if (state.underscore) return { words: 'Out of the build by its name (a _ file or folder): never exported -- rename it without the _ to build it', tone: 'quiet' };
      return { words: `Out of the build: never exported -- tick it in the Assets panel (${keyLabel('Shift+KeyB')}) to build it`, tone: 'quiet' };
    case 'gone':
      return { words: 'Not there: renamed, moved or deleted', tone: 'bad' };
    case 'offline':
      return { words: 'No dev server: nothing is built or read', tone: 'bad' };
    default:
      return { words: '', tone: 'quiet' };
  }
}

const size = new THREE.Vector3();
const box = new THREE.Box3();

/** What the objects measure, as `1 m × 25 cm × 1 m` (width, height, depth); '' for nothing. */
function measureOf(objects: readonly THREE.Object3D[]): string {
  box.makeEmpty();
  for (const o of objects) box.union(new THREE.Box3().setFromObject(o));
  if (box.isEmpty()) return '';
  box.getSize(size);
  return `${metres(size.x)} × ${metres(size.y)} × ${metres(size.z)}`;
}

export function createInspector(root: HTMLElement, host: InspectorHost): Inspector {
  const card = el('div', 'ed-card ed-side ed-right ed-mo-right');
  card.hidden = true;
  const bar = el('div', 'ed-panel-head ed-panel-bar');
  const title = el('div', 'ed-side-title', 'Model');
  const ends = el('span', 'ed-head-end');
  bar.append(title, el('span', 'ed-mo-head-name'), ends);
  const body = el('div', 'ed-mo-body');
  /**
   * The model's head -- or the part chosen -- drawn again with every `draw`, at the top; the tab's own blocks under
   * it (Parameters, Materials: what a person works with, in view as the model opens); the model's facts at the foot.
   */
  const info = el('div', 'ed-mo-info');
  const details = el('div', 'ed-mo-info');
  /** The tab's own blocks, made once: hidden together with no model, each block's own `hidden` left to its owner. */
  const mounted = el('div', 'ed-mo-blocks');
  body.append(info, mounted, details);
  card.append(bar, body);
  root.append(card);
  const side = sidePanel(root, card, 'right', { name: 'Inspector' });
  ends.append(side.fold);

  const facts = (pairs: readonly (readonly [string, string | HTMLElement])[]): HTMLElement => {
    const grid = el('div', 'ed-mo-facts');
    for (const [name, value] of pairs) grid.append(el('span', undefined, name), typeof value === 'string' ? el('span', undefined, value) : value);
    return grid;
  };

  function modelBlock(model: ModelFacts): HTMLElement[] {
    const out: HTMLElement[] = [];
    const head = el('div', 'ed-mo-title', model.name);
    out.push(head);
    const link = control('ui', 'ed-mo-link', model.path);
    link.title = 'Show it in the Assets panel, chosen';
    link.addEventListener('click', () => host.reveal(model.path));
    const { words, tone } = model.held ? { words: HELD_WORDS, tone: 'busy' as const } : stateWords(model.state);
    // One line, the whole on hover: its words change as it builds, and nothing under it may move for that.
    const state = el('div', `ed-mo-state ed-mo-one-line ed-mo-${tone}`, words);
    state.title = words;
    const pairs: [string, string | HTMLElement][] = [['Script', link]];
    if (model.exportPath) {
      const out = control('ui', 'ed-mo-link', model.exportPath);
      out.title = 'Show the export in the Assets panel, chosen: what the game loads';
      out.addEventListener('click', () => host.reveal(model.exportPath!));
      pairs.push(['Export', out]);
    }
    out.push(state, facts(pairs));
    // Gone -- renamed, moved or deleted -- there is nothing to build, set or change: Close is the way on.
    if (model.state.kind === 'gone') {
      const actions = el('div', 'ed-buttons');
      actions.append(button('ui', 'Close it', `Close ${model.name}: back to the list of scripts -- open it again under its new name`, () => host.close(), 'ed-small ed-accent'));
      out.push(actions);
      return out;
    }
    if (host.writes()) {
      const actions = el('div', 'ed-buttons');
      const why = host.unbuildable();
      const buildNow = button('model_export', 'Build now', why ?? 'Export the script again now, current or not (B)', () => host.build(), 'ed-small ed-accent');
      buildNow.disabled = why !== null;
      actions.append(
        buildNow,
        button('ui', 'Open script', 'In the application this machine edits it with: saved, it rebuilds here', () => host.edit(), 'ed-small'),
      );
      out.push(actions);
    }
    out.push(host.exportRow());
    // What the last export did worth reading: one line each, the whole on hover.
    for (const note of model.notes ?? []) {
      const line = el('div', 'ed-mo-built-note ed-mo-one-line', note);
      line.title = note;
      out.push(line);
    }
    return out;
  }

  /** The model's facts, under the blocks: its totals and size, what Gladius said. */
  function modelDetails(model: ModelFacts, tree: PartTree | null, kernel: ReadonlyMap<string, ModelNode>): HTMLElement[] {
    const out: HTMLElement[] = [];
    if (tree) {
      const whole = partTotals(tree.all, kernel);
      const measured = measureOf(tree.roots.map((p) => p.object));
      const kernelled = tree.all.filter((p) => kernel.size > 0 && countsOf(p, kernel).kernel).length;
      const rows: [string, string][] = [['Parts', count(tree.all.length)], ['Totals', totalsLine(whole)]];
      if (measured) rows.push(['Size', measured]);
      if (kernel.size > 0) rows.push(['Polygons', kernelled > 0 ? 'the kernel\'s, from Gladius' : 'not matched: the export\'s nodes are not the script\'s (merged?)']);
      out.push(el('div', 'ed-dim', 'The model'), facts(rows));
    }
    // What the script said as it built -- its info() lines, Gladius's warnings -- the first few, the line each names;
    // not the kernel's bookkeeping of every paint (GLD-3050: so many faces painted, so many vertices split).
    const said = model.told.filter((d) => d.severity !== 'error' && d.code !== 'GLD-3050');
    if (said.length > 0) {
      out.push(el('div', 'ed-dim', 'Gladius said'));
      const list = el('div', 'ed-mo-told');
      for (const d of said.slice(0, 8)) {
        const row = el('div', `ed-mo-diag${d.severity === 'warning' ? ' ed-mo-warn' : ''}`);
        row.append(el('span', 'ed-mo-diag-at', d.line !== undefined ? `line ${d.line}` : d.severity), el('span', undefined, d.message));
        list.append(row);
      }
      if (said.length > 8) list.append(el('div', 'ed-dim', `and ${said.length - 8} more`));
      out.push(list);
    }
    out.push(el('div', 'ed-dim', 'Select a part -- in the views or on the left -- to see it here.'));
    return out;
  }

  function partBlock(parts: readonly Part[], tree: PartTree, selection: readonly string[], hidden: ReadonlySet<string>, kernel: ReadonlyMap<string, ModelNode>): HTMLElement[] {
    const out: HTMLElement[] = [];
    const actions = el('div', 'ed-buttons');
    const hiding = selection.every((id) => !hidden.has(id));
    actions.append(
      button('ui', 'Frame', 'The view under the pointer -- or the last pressed -- onto it (F)', () => host.frame(), 'ed-small'),
      button('ui', hiding ? 'Hide' : 'Show', `${hiding ? 'Hide' : 'Show'} ${parts.length > 1 ? `all ${parts.length}` : 'it'} (${keyLabel('Shift+KeyH')})`, () => host.hide(), 'ed-small'),
    );
    if (parts.length === 1) {
      const part = parts[0]!;
      const nameRow = el('div', 'ed-line');
      const named = el('div', 'ed-mo-title', part.name);
      const copy = iconButton('ui', 'copy', 'Copy its name: the string to find in the script', () => void navigator.clipboard?.writeText(part.name).catch(() => {}));
      nameRow.append(named, copy);
      out.push(nameRow);
      const c = countsOf(part, kernel);
      const kinds = { mesh: 'Mesh', skinned: 'Skinned mesh', bone: 'Bone', empty: 'Empty' } as const;
      const pairs: [string, string][] = [['Kind', kinds[part.kind]]];
      if (part.parent) pairs.push(['Under', part.parent.name]);
      if (part.kind === 'mesh' || part.kind === 'skinned') {
        pairs.push(['Triangles', count(part.triangles)]);
        pairs.push(c.kernel ? ['Vertices', count(c.vertices)] : ['Stored vertices', count(c.vertices)]);
        pairs.push(['Edges', count(c.edges)], ['Faces', `${count(c.faces)}${c.kernel ? '' : ' (triangles: no answer from Gladius)'}`]);
        if (part.material) pairs.push(['Material', part.material]);
      }
      if (part.children.length > 0) pairs.push(['Parts under it', count(withChildren(tree, [part.id]).length - 1)]);
      const measured = measureOf([part.object]);
      if (measured) pairs.push(['Size', measured]);
      if (hidden.has(part.id)) pairs.push(['Shown', 'no: hidden by its eye']);
      out.push(facts(pairs), actions);
      return out;
    }
    out.push(el('div', 'ed-mo-title', `${count(parts.length)} parts`));
    const names = el('div', 'ed-dim', parts.map((p) => p.name).join(', '));
    names.style.userSelect = 'text';
    const measured = measureOf(parts.map((p) => p.object));
    const rows: [string, string][] = [['Totals', totalsLine(partTotals(withChildren(tree, selection), kernel))]];
    if (measured) rows.push(['Size', measured]);
    out.push(names, facts(rows), actions);
    return out;
  }

  return {
    root: card,
    side,
    draw(model, tree, selection, hidden, kernel) {
      const parts = tree ? selection.map((id) => tree.byId.get(id)).filter((p): p is Part => p !== undefined) : [];
      title.textContent = parts.length > 0 ? (parts.length > 1 ? 'Parts' : 'Part') : 'Model';
      // No model, or its script gone: no blocks -- nothing to set or change.
      mounted.hidden = !blocksShown(model?.path ?? null, model?.state ?? { kind: 'none' });
      if (!model) {
        info.replaceChildren(el('div', 'ed-nothing ed-dim', 'No model open.'));
        details.replaceChildren();
        return;
      }
      info.replaceChildren(...(parts.length > 0 && tree ? partBlock(parts, tree, selection, hidden, kernel) : modelBlock(model)));
      details.replaceChildren(...modelDetails(model, tree, kernel));
    },
    mount(...blocks) {
      mounted.append(...blocks);
    },
    setVisible(visible) {
      card.hidden = !visible;
      if (visible) side.refresh();
    },
    dispose() {
      side.dispose();
      card.remove();
    },
  };
}
