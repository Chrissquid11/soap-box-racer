/**
 * The build trace's controls (Docs/modeler.md §4, M34-M37; Vibe3D D66, D70),
 * in the animation's two places, never both at once:
 *
 * - **The Build trace block** in the right panel (after Materials, folded
 *   until asked): the cost or the state on its line -- tracing, stale while
 *   it traces again, a failure with the script's line -- and the step list:
 *   each row its number, its op and name, its triangles; the step shown lit,
 *   what has not happened yet faint, a step past the budget struck. A click
 *   on a row shows that step. **Step through** at its head shows the end --
 *   folded too (phase 6): the trace a press away without unfolding the block.
 * - **The trace strip** along the views' foot while a step is shown -- in the
 *   clips' strip's place, which gives way (the steps are static meshes, no
 *   clip plays on them): a slider of the steps (a drag scrubs), first, back,
 *   play or pause, on, last, where it stands (`12 of 30 · extrude lid`),
 *   Total or Last, the speed (a log slider 0.1x-32x and a box to type one),
 *   and **Back to the model** (Esc).
 * - **Drawn from a view of the state**; the list made again only when its
 *   steps change (its shape), the rows' classes as the step moves.
 */
import { keyLabel } from '@vibe/engine/debug';
import { button, control, el, icon, iconButton, tip } from '../dom.ts';
import { letGo } from '../shell.ts';
import type { TraceStep } from '@vibe/pipeline/assets-types';
import { MAX_SPEED, MIN_SPEED, SLIDER_STEPS, STEP_MS, sliderToSpeed, speedToSlider, stepWords, typedSpeed, type TraceView } from './trace-steps.ts';
import type { Mcp } from '../mcp/declare.ts';

export interface TracePanelHost {
  /** Show the step at this place of the list (the start is 0). */
  go(place: number): void;
  step(by: number): void;
  toStart(): void;
  toEnd(): void;
  toggle(): void;
  /** Step through: the trace shown, at its end -- or, shown, back to the model. */
  enter(): void;
  leave(): void;
  setView(view: TraceView): void;
  setSpeed(speed: number): void;
  /** The block folded or not: unfolded, it traces. */
  folded(folded: boolean): void;
  /** Trace again now. */
  retrace(): void;
}

/** What the controls show. */
export interface TracePanelView {
  /** The steps with the start first; empty with none yet. */
  steps: readonly TraceStep[];
  /** The place in `steps` stood at. */
  at: number;
  showing: boolean;
  playing: boolean;
  view: TraceView;
  speed: number;
  /** The block's line: what is so -- and its tone. */
  line: { text: string; tone: 'idle' | 'busy' | 'bad' };
  /** May a trace be asked for (Gladius, a page that may run it): else why not, on the block's buttons. */
  blocked: string | null;
  /** Is the list from a script that has changed since (being traced again, or failing). */
  stale: boolean;
}

export interface TracePanel {
  readonly block: HTMLElement;
  readonly strip: HTMLElement;
  draw(view: TracePanelView): void;
  setFolded(folded: boolean): void;
  readonly isFolded: boolean;
  /** The speed box is being typed in: the arrows and Space are its own. */
  readonly typing: boolean;
}

export function createTracePanel(host: TracePanelHost): TracePanel {
  // ---------------------------------------------------------------- the strip

  const strip = el('div', 'ed-mo-strip ed-mo-trace-strip');
  strip.hidden = true;
  const scrub = el('input', 'ed-mo-trace-scrub');
  scrub.type = 'range';
  scrub.min = '0';
  scrub.step = '1';
  scrub.title = 'The build, step by step: drag to scrub';
  scrub.setAttribute('aria-label', 'The step of the build shown');
  scrub.addEventListener('input', () => host.go(Number(scrub.value)));
  scrub.addEventListener('change', () => scrub.blur());
  const controls = el('div', 'ed-mo-transport');
  const tbtn = (mcp: Mcp, glyph: Parameters<typeof icon>[0], run: () => void): HTMLButtonElement => {
    const b = letGo(control(mcp, 'ed-bar-button'));
    b.append(icon(glyph));
    b.addEventListener('click', run);
    return b;
  };
  const firstB = tbtn('ui', 'toStart', () => host.toStart());
  const backB = tbtn('ui', 'stepBack', () => host.step(-1));
  const playB = tbtn('ui', 'play', () => host.toggle());
  const onB = tbtn('ui', 'stepOn', () => host.step(1));
  const lastB = tbtn('ui', 'toEnd', () => host.toEnd());
  tip(firstB, 'To the start: nothing built yet', keyLabel('Shift+ArrowLeft'));
  tip(backB, 'A step back: the operation undone, its move run backwards', keyLabel('ArrowLeft'));
  tip(onB, 'A step on: the next operation, its move animated', keyLabel('ArrowRight'));
  tip(lastB, 'To the end: the model as the script finishes it', keyLabel('Shift+ArrowRight'));
  const where = el('span', 'ed-mo-clock ed-mo-trace-where');
  const seg = el('div', 'ed-mo-seg ed-mo-trace-views');
  const segB = (words: string, why: string, view: TraceView): HTMLButtonElement => {
    const b = letGo(control('ui', 'ed-mo-seg-b', words));
    b.title = why;
    b.addEventListener('click', () => host.setView(view));
    return b;
  };
  const totalB = segB('Total', 'Total: everything that exists at this step -- the model as it stands, each mesh gone where its replacement is made', 'total');
  const lastViewB = segB('Last', 'Last: only what this operation made, on its own', 'last');
  seg.append(totalB, lastViewB);
  const speedRow = el('span', 'ed-mo-trace-speed');
  const speedSlider = el('input', 'ed-mo-trace-speed-slider');
  speedSlider.type = 'range';
  speedSlider.min = '0';
  speedSlider.max = String(SLIDER_STEPS);
  speedSlider.setAttribute('aria-label', 'Playback speed');
  speedSlider.addEventListener('input', () => host.setSpeed(sliderToSpeed(Number(speedSlider.value))));
  speedSlider.addEventListener('change', () => speedSlider.blur());
  const speedBox = el('input', 'ed-mo-trace-speed-box');
  speedBox.type = 'text';
  speedBox.inputMode = 'decimal';
  speedBox.setAttribute('aria-label', 'Playback speed, typed');
  speedBox.title = `Playback speed: type one, ${MIN_SPEED}× to ${MAX_SPEED}× -- Enter sets it`;
  let typingIn = false;
  let shownSpeed = 1;
  // The box is written back on commit always -- 999 typed reads 32 once it is in force (D66); never while typed in.
  const takeTyped = (): void => {
    const speed = typedSpeed(speedBox.value);
    if (speed !== null) host.setSpeed(speed);
    speedBox.value = String(speed ?? shownSpeed);
  };
  speedBox.addEventListener('focus', () => void (typingIn = true));
  speedBox.addEventListener('blur', () => {
    typingIn = false;
    takeTyped();
  });
  // Enter is the field's `change` -- the box committed and let go; no key listener of its own (MrDebug's rule).
  speedBox.addEventListener('change', () => {
    takeTyped();
    speedBox.blur();
  });
  speedRow.append(speedSlider, speedBox, el('span', 'ed-dim', '×'));
  const backToModel = letGo(button('ui', 'Back to the model', '', () => host.leave(), 'ed-small ed-accent ed-mo-trace-leave'));
  // "Back" alone in a short window, the strip one row (model.css).
  backToModel.replaceChildren(el('span', undefined, 'Back'), el('span', 'ed-mo-long', ' to the model'));
  tip(backToModel, 'The model as exported again: the trace kept where it stands, Step through returns to it', keyLabel('Escape'));
  controls.append(firstB, backB, playB, onB, lastB, where, seg, speedRow, backToModel);
  strip.append(scrub, controls);

  // ---------------------------------------------------------------- the block

  const block = el('section', 'ed-mo-sec ed-mo-trace');
  const bhead = el('div', 'ed-mo-sec-head');
  const caret = control('ui', 'ed-mo-sec-caret');
  const title = el('span', 'ed-mo-sec-title', 'Build trace');
  const count = el('span', 'ed-mo-sec-count');
  const ends = el('span', 'ed-mo-sec-ends');
  const throughB = button('model_trace', 'Step through', '', () => host.enter(), 'ed-small ed-quiet');
  const againB = iconButton('model_trace', 'build', 'Trace again now', () => host.retrace(), 'ed-icon-button ed-mo-trace-again');
  ends.append(throughB, againB);
  bhead.append(caret, title, count, ends);
  const status = el('div', 'ed-mo-sec-status');
  const list = el('div', 'ed-mo-steps');
  list.setAttribute('role', 'listbox');
  list.setAttribute('aria-label', 'The operations the script ran, in order');
  const body = el('div', 'ed-mo-sec-body');
  body.append(status, list);
  block.append(bhead, body);
  let folded = true;
  const fold = (next: boolean): void => {
    folded = next;
    block.classList.toggle('ed-mo-shut', folded);
    caret.textContent = folded ? '▸' : '▾';
    caret.title = folded ? 'Show the build trace: the script replayed op by op (traced as it opens)' : 'Fold the build trace away';
  };
  fold(true);
  const toggleFold = (): void => {
    fold(!folded);
    host.folded(folded);
  };
  caret.addEventListener('click', toggleFold);
  // mcp: ui -- the section folded
  title.addEventListener('click', toggleFold);

  // ---------------------------------------------------------------- drawing

  let listShape = '';
  let rows: HTMLElement[] = [];

  function drawList(view: TracePanelView): void {
    const of = view.steps.length - 1;
    const shape = view.steps.map((s) => `${s.index}|${s.op}|${s.label ?? ''}|${s.triangles}|${s.kept === false}`).join(';');
    if (shape !== listShape) {
      listShape = shape;
      rows = view.steps.map((s, place) => {
        const row = letGo(control('ui', `ed-mo-step${s.index === 0 ? ' ed-mo-step-start' : ''}${s.op === 'emit' ? ' ed-mo-step-emit' : ''}${s.kept === false ? ' ed-mo-step-gone' : ''}`));
        row.setAttribute('role', 'option');
        const what = s.index === 0 ? 'nothing built yet' : s.label ? `${s.op} ${s.label}` : s.op;
        row.append(el('span', 'ed-mo-step-n', s.index === 0 ? '' : String(s.index)), el('span', 'ed-mo-step-op', what), el('span', 'ed-mo-step-tris', s.index === 0 ? '' : s.triangles.toLocaleString('en-US')));
        row.title = s.index === 0
          ? 'The start: before the script built anything -- the first operation grows out of it'
          : `${stepWords(s, of)} -- ${s.triangles.toLocaleString('en-US')} triangles${s.consumedAt ? `, replaced at step ${s.consumedAt}` : ', there to the end'}${s.edges ? '; it moves nothing: drawn as the lines it cut' : ''}${s.kept === false ? '; past the trace\'s budget: listed, not kept to show' : ''}. A click shows it`;
        row.addEventListener('click', () => host.go(place));
        return row;
      });
      list.replaceChildren(...rows);
    }
    rows.forEach((row, place) => {
      const current = view.showing && place === view.at;
      row.classList.toggle('ed-mo-current', current);
      row.setAttribute('aria-selected', String(current));
      // What has not happened yet at the step shown: faint -- the list reads as a place, not a menu (D66).
      row.classList.toggle('ed-mo-future', view.showing && place > view.at);
    });
    list.classList.toggle('ed-mo-stale', view.stale);
    // The row shown kept in the list's own view -- the list scrolled, never the panel round it.
    const row = view.showing ? rows[view.at] : undefined;
    if (row) {
      const top = row.offsetTop;
      const bottom = top + row.offsetHeight;
      if (top < list.scrollTop) list.scrollTop = top;
      else if (bottom > list.scrollTop + list.clientHeight) list.scrollTop = bottom - list.clientHeight;
    }
  }

  function drawStrip(view: TracePanelView): void {
    strip.hidden = !view.showing;
    if (!view.showing) return;
    const last = Math.max(0, view.steps.length - 1);
    scrub.max = String(last);
    if (scrub.value !== String(view.at)) scrub.value = String(view.at);
    const step = view.steps[view.at];
    const words = step ? `${stepWords(step, last)}${step.kept === false ? ' -- not kept: past the trace\'s budget' : ''}${view.stale ? ' · stale' : ''}` : '';
    if (where.textContent !== words) where.textContent = words;
    where.title = words;
    firstB.disabled = backB.disabled = view.at <= 0;
    onB.disabled = lastB.disabled = view.at >= last;
    if (playB.dataset.playing !== String(view.playing)) {
      playB.dataset.playing = String(view.playing);
      playB.replaceChildren(icon(view.playing ? 'pause' : 'play'));
      tip(playB, view.playing ? 'Pause on the step shown' : 'Play the build step by step -- from the start, at the end', keyLabel('Space'));
    }
    totalB.setAttribute('aria-pressed', String(view.view === 'total'));
    lastViewB.setAttribute('aria-pressed', String(view.view === 'last'));
    shownSpeed = view.speed;
    const pos = String(speedToSlider(view.speed));
    if (speedSlider.value !== pos && document.activeElement !== speedSlider) speedSlider.value = pos;
    speedSlider.title = `Playback speed: ${view.speed}×, ${Math.round(STEP_MS / view.speed)} ms a step`;
    if (!typingIn) speedBox.value = String(view.speed);
  }

  return {
    block,
    strip,
    draw(view) {
      const n = Math.max(0, view.steps.length - 1);
      count.textContent = n > 0 ? `${n} ${n === 1 ? 'step' : 'steps'}` : '';
      status.textContent = view.line.text;
      status.hidden = view.line.text === '';
      status.classList.toggle('ed-mo-bad', view.line.tone === 'bad');
      status.classList.toggle('ed-mo-busy', view.line.tone === 'busy');
      // Offered with no trace yet too: it traces first, then shows the end (M34).
      throughB.disabled = n === 0 && view.blocked !== null;
      throughB.setAttribute('aria-pressed', String(view.showing));
      tip(throughB, view.showing ? 'Back to the model, the trace kept where it stands' : n > 0 ? 'Show the build\'s steps in the views, from its end: step back from the finished model' : (view.blocked ?? 'Trace the build, then show its steps in the views from its end'), keyLabel('Shift+KeyT'));
      throughB.textContent = view.showing ? 'Back to the model' : 'Step through';
      againB.disabled = view.blocked !== null;
      againB.title = view.blocked ?? 'Trace again now: the script built instrumented, every operation\'s mesh kept';
      drawList(view);
      drawStrip(view);
    },
    setFolded: fold,
    get isFolded() {
      return folded;
    },
    get typing() {
      return typingIn;
    },
  };
}
