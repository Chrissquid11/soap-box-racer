/**
 * The model's materials as the Materials block shows them (Docs/modeler.md
 * M24; Vibe3D D88, D94, D96): read off the model loaded -- what the script
 * built -- one entry per material the script named, in `material{}`'s words.
 *
 * - **One entry per name, not per three.js material**: GLTFLoader clones a
 *   material for each mesh with vertex colours, flat shading or no tangents,
 *   so one `material{}` arrives as several; grouped back by the name the
 *   script gave it -- the name its `material{ name = … }` call is found by.
 * - **In `material{}`'s vocabulary**: `base_color` and `emissive` linear (what
 *   the script takes -- an sRGB hex pasted there is wrong; the swatch shows
 *   display colour), `metallic`, `roughness`, `alpha_mode` from how three.js
 *   draws it (blend, a cutoff, opaque) with its `alpha_cutoff`, and each
 *   texture slot -- `texture`, `normal_texture`, `metallic_roughness_texture`,
 *   `occlusion_texture`, `emissive_texture` -- with its size, filtering and
 *   wrapping. Vertex colours said apart: on a white material they are its
 *   whole colour, and nothing else says so.
 * - **The parts drawn with it**, by part: a click on the entry selects them.
 * - **Live while a control moves** (`previewMaterial`): the tab's own decode is
 *   changed in place -- every instance of the name -- and put back as it was
 *   (`restore`) if the edit is not written; the script's write and the export
 *   that follows bring the model that has it for real (D94).
 *
 * Reads three.js objects, no DOM (`materials.test.ts`).
 */
import * as THREE from 'three';
import type { Part, PartTree } from './parts.ts';

export const TEXTURE_SLOTS = ['texture', 'normal_texture', 'metallic_roughness_texture', 'occlusion_texture', 'emissive_texture'] as const;
export type TextureSlot = (typeof TEXTURE_SLOTS)[number];

/** Which three.js map each slot is drawn through. */
const MAPS: Readonly<Record<TextureSlot, 'map' | 'normalMap' | 'roughnessMap' | 'aoMap' | 'emissiveMap'>> = {
  texture: 'map',
  normal_texture: 'normalMap',
  metallic_roughness_texture: 'roughnessMap',
  occlusion_texture: 'aoMap',
  emissive_texture: 'emissiveMap',
};

export interface TextureInfo {
  slot: TextureSlot;
  width: number;
  height: number;
  filter: 'nearest' | 'linear';
  wrap: 'clamp' | 'repeat' | 'mirror';
  texture: THREE.Texture;
}

export type AlphaMode = 'opaque' | 'mask' | 'blend';

export interface MaterialInfo {
  /** As the script named it: `material{ name = … }`. */
  name: string;
  /** Every three.js instance of it in the model. */
  materials: THREE.MeshStandardMaterial[];
  /** The parts drawn with it, in the outliner's order. */
  parts: Part[];
  /** Linear, as `material{}` takes it. */
  baseColor: [number, number, number];
  metallic: number;
  roughness: number;
  emissive: [number, number, number];
  alphaMode: AlphaMode;
  alphaCutoff: number;
  /** Drawn with the mesh's vertex colours times its base colour. */
  vertexColours: boolean;
  textures: TextureInfo[];
}

const rgb = (c: THREE.Color): [number, number, number] => [c.r, c.g, c.b];

/** How three.js draws a glTF material's alpha: blended, cut at a value, or neither. */
export function alphaOf(m: THREE.Material): { mode: AlphaMode; cutoff: number } {
  if (m.transparent) return { mode: 'blend', cutoff: 0.5 };
  if (m.alphaTest > 0) return { mode: 'mask', cutoff: m.alphaTest };
  return { mode: 'opaque', cutoff: 0.5 };
}

function textureOf(slot: TextureSlot, texture: THREE.Texture | null | undefined): TextureInfo | null {
  if (!texture) return null;
  const image = texture.image as { width?: number; height?: number } | null | undefined;
  return {
    slot,
    width: image?.width ?? 0,
    height: image?.height ?? 0,
    filter: texture.magFilter === THREE.NearestFilter ? 'nearest' : 'linear',
    wrap: texture.wrapS === THREE.RepeatWrapping ? 'repeat' : texture.wrapS === THREE.MirroredRepeatWrapping ? 'mirror' : 'clamp',
    texture,
  };
}

/**
 * The parts drawn with no material of the script's (an `emit` with none: the file's default, unnamed), listed as one
 * entry by this name -- never a `material{}` the script could hold.
 */
export const NO_MATERIAL = '(no material)';

/** Why an entry is read only, the script declaring no `material{}` of its name: said for what it is. */
export function undeclaredWords(name: string): string {
  if (name === NO_MATERIAL) return 'These parts have no material: give them one -- a material{ name = "Wood", base_color = v3(…) } call, passed to their emit as material = -- and its look is edited here (or ask Claude to).';
  return `Read only: the script has no material{ name = "${name}" } to write into -- an import's material, or a name worked out as it runs. Declare it in the script (or ask Claude to) and it is editable here.`;
}

/** Every material the model is drawn with, by the name the script gave it, in the order first met; unnamed ones as `NO_MATERIAL`. */
export function materialsOf(tree: PartTree, root: THREE.Object3D): MaterialInfo[] {
  const byName = new Map<string, MaterialInfo>();
  /** The part a mesh is of: itself, or its nearest part above it. */
  const partOf = (o: THREE.Object3D): Part | undefined => {
    for (let p: THREE.Object3D | null = o; p; p = p.parent) {
      const part = tree.byObject.get(p);
      if (part) return part;
    }
    return undefined;
  };
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const raw of list) {
      const m = raw as THREE.MeshStandardMaterial;
      if (!m) continue;
      const name = m.name || NO_MATERIAL;
      let info = byName.get(name);
      if (!info) {
        const alpha = alphaOf(m);
        info = {
          name,
          materials: [],
          parts: [],
          baseColor: m.color ? rgb(m.color) : [1, 1, 1],
          metallic: m.metalness ?? 0,
          roughness: m.roughness ?? 1,
          emissive: m.emissive ? rgb(m.emissive) : [0, 0, 0],
          alphaMode: alpha.mode,
          alphaCutoff: alpha.cutoff,
          vertexColours: false,
          textures: [],
        };
        byName.set(name, info);
      }
      if (!info.materials.includes(m)) info.materials.push(m);
      info.vertexColours ||= m.vertexColors === true;
      for (const slot of TEXTURE_SLOTS) {
        if (info.textures.some((t) => t.slot === slot)) continue;
        const got = textureOf(slot, m[MAPS[slot]] as THREE.Texture | null);
        if (got) info.textures.push(got);
      }
      const part = partOf(mesh);
      if (part && !info.parts.includes(part)) info.parts.push(part);
    }
  });
  const order = new Map(tree.all.map((p, i) => [p, i] as const));
  for (const info of byName.values()) {
    info.parts.sort((a, b) => (order.get(a) ?? 0) - (order.get(b) ?? 0));
    info.textures.sort((a, b) => TEXTURE_SLOTS.indexOf(a.slot) - TEXTURE_SLOTS.indexOf(b.slot));
  }
  return [...byName.values()];
}

/** What a live change touches on a material, kept to put back. */
interface Kept {
  color: THREE.Color;
  emissive: THREE.Color;
  metalness: number;
  roughness: number;
  transparent: boolean;
  alphaTest: number;
  depthWrite: boolean;
  filters: Array<[THREE.Texture, THREE.MagnificationTextureFilter, THREE.MinificationTextureFilter, THREE.Wrapping, THREE.Wrapping]>;
}

/** What a run of live changes keeps to put back: each material's first state. */
export type LiveState = Map<THREE.Material, Kept>;

/** A live change of the block's controls, as it moves. */
export interface LiveChange {
  base_color?: readonly [number, number, number];
  emissive?: readonly [number, number, number];
  metallic?: number;
  roughness?: number;
  alpha_mode?: AlphaMode;
  alpha_cutoff?: number;
  texture_filter?: 'nearest' | 'linear';
  texture_wrap?: 'clamp' | 'repeat';
}

/**
 * Every instance of a material changed as a control moves -- the tab's own
 * decode, nobody else's -- and the way to put each back as it was. Several
 * changes in a row keep the first state to go back to.
 */
export function previewMaterial(info: MaterialInfo, change: LiveChange, kept: LiveState = new Map()): { restore(): void } {
  for (const m of info.materials) {
    if (!kept.has(m)) {
      const filters: Kept['filters'] = [];
      if (m.map) filters.push([m.map, m.map.magFilter, m.map.minFilter, m.map.wrapS, m.map.wrapT]);
      kept.set(m, { color: m.color.clone(), emissive: m.emissive.clone(), metalness: m.metalness, roughness: m.roughness, transparent: m.transparent, alphaTest: m.alphaTest, depthWrite: m.depthWrite, filters });
    }
    if (change.base_color) m.color.setRGB(change.base_color[0], change.base_color[1], change.base_color[2]);
    if (change.emissive) m.emissive.setRGB(change.emissive[0], change.emissive[1], change.emissive[2]);
    if (change.metallic !== undefined) m.metalness = change.metallic;
    if (change.roughness !== undefined) m.roughness = change.roughness;
    if (change.alpha_mode !== undefined || change.alpha_cutoff !== undefined) {
      const mode = change.alpha_mode ?? alphaOf(m).mode;
      m.transparent = mode === 'blend';
      m.depthWrite = mode !== 'blend';
      m.alphaTest = mode === 'mask' ? (change.alpha_cutoff ?? (m.alphaTest > 0 ? m.alphaTest : 0.5)) : 0;
      m.needsUpdate = true;
    }
    if (m.map && (change.texture_filter || change.texture_wrap)) {
      if (change.texture_filter) {
        m.map.magFilter = change.texture_filter === 'nearest' ? THREE.NearestFilter : THREE.LinearFilter;
        m.map.minFilter = change.texture_filter === 'nearest' ? THREE.NearestFilter : THREE.LinearMipmapLinearFilter;
      }
      if (change.texture_wrap) m.map.wrapS = m.map.wrapT = change.texture_wrap === 'repeat' ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
      m.map.needsUpdate = true;
    }
  }
  return {
    restore() {
      for (const [m, k] of kept) {
        const s = m as THREE.MeshStandardMaterial;
        s.color.copy(k.color);
        s.emissive.copy(k.emissive);
        s.metalness = k.metalness;
        s.roughness = k.roughness;
        s.transparent = k.transparent;
        s.alphaTest = k.alphaTest;
        s.depthWrite = k.depthWrite;
        for (const [tex, mag, min, ws, wt] of k.filters) {
          tex.magFilter = mag;
          tex.minFilter = min;
          tex.wrapS = ws;
          tex.wrapT = wt;
          tex.needsUpdate = true;
        }
        s.needsUpdate = true;
      }
      kept.clear();
    },
  };
}

/** A linear colour as the `#rrggbb` a colour input shows -- display colour, sRGB. */
export function linearToHex(c: readonly [number, number, number]): string {
  return `#${new THREE.Color().setRGB(c[0], c[1], c[2], THREE.LinearSRGBColorSpace).getHexString(THREE.SRGBColorSpace)}`;
}

/** A colour input's `#rrggbb` as the linear colour the script takes. */
export function hexToLinear(hex: string): [number, number, number] {
  const c = new THREE.Color();
  c.setStyle(hex, THREE.SRGBColorSpace);
  // three's working space is linear: the components are what `material{}` wants.
  return [c.r, c.g, c.b];
}
