---
skill: studio
title: The Model tab
when: Before opening, building, tuning, recolouring, posing or looking at a Gladius model through the model_* tools, or making a script for a model file
covers:
  tools:
    - model_open
    - model_info
    - model_params_get
    - model_params_set
    - model_preview
    - model_export
    - model_trace
    - model_materials_set
    - model_pose
    - model_adopt
order: 40
---
# The Model tab

The Model tab (`3`) shows one model at a time: a **Gladius script** -- a `.lua` under `AssetsSource/models/` --
built live into its `.glb` under `src/assets/models/`, in one, two or four views, with its parts, its
parameters, its materials, its clips and poses, and canvases the person draws on to show you what they mean. The
Assets panel runs along its bottom as in the Scene tab.

**The script itself is the `gladius` skill's** (`vibe:gladius` in the studio's panel, `gladius` in a terminal): how
to write and change a model's Lua -- shapes, parts, `params{}`, `material{}`, rigs, `action{}`. Load it before
writing a script. This page is the tab's tools: what a person does with a model through the tab's blocks, without
writing Lua.

## Scripts and exports

- A script exports one `.glb`, keyed by its path: `AssetsSource/models/props/crate.lua` is
  `src/assets/models/props/crate.glb`, the key `props/crate` an entity's `Render.model` names.
- A script edited with Edit is rebuilt and exported by the dev server once the file is quiet; the tab shows it
  rebuilt. A new script is `asset_new` with `kind: 'model'` ([the assets](assets.md)).
- A script's **record**, `<name>.export.json` beside it, keeps its export options and the parameter values the tab
  set -- so the script's own text stays as written.
- The tab has **its own history**: each tool's write here is one step of it, which the person's `Z` in the Model tab
  undoes -- not the world's, so `history_undo` does not reach it. Undo this turn takes back the files.

## Read first

- **`model_info`** -- the model open (null when none): its script and export, its build (`ready`, `building`,
  `failed` with Gladius's line …), its parts (selected, hidden), its materials (each shown, and whether a
  `material{}` of the script declares it -- only those can be changed here), the export's clips and the script's
  actions with their keys' times, its parameters with their values, whether a preview is shown, and the tab's
  history.
- **`model_params_get`** with `script` -- a script's parameters without opening it: each one's type, value as
  exported, default, range or choices, doc, and whether the record sets it.
- **`model_trace`** with `script` -- the build replayed op by op at the export's values: its steps, the
  triangles each kept, the costliest, and a failed build's lines. Read it when a model is heavy or a build fails
  in a way the error does not explain (`steps: true` for every step).

## The jobs

**Open one** -- `model_open` with `script` (a `.lua` under `AssetsSource/models/`). It brings the Model tab up in
the person's studio, so open one when the job is about it. It answers at once; the build may still be coming
(`model_info` again). Refused while the tab shows a preview of values nobody wrote, unless `discard: true` --
which throws that preview away and asks the person under Auto.

**A script for a model file** -- a `.glb` delivered as it is under `src/assets/models/` has no script to change.
`model_adopt` with its `path`, as Make a script for it: a script `<stem>.lua` in its `AssetsSource/models/` twin
folder importing a copy of the file (`<stem>.source.glb`, parts, colours, skin and clips kept), built as that model's
export -- the key unchanged, so what names it keeps it. With the studio open it is one step of the Assets panel
(`Z` there takes the script away and puts the file back) and answers once its build ends; then `model_open` the
script. A new model from a file on the machine is `asset_import` with `script: true` ([the assets](assets.md)).

**Look** -- `view_shot` with `target: 'model'` draws the tab's views as they are ([play and view](play.md)).
**`model_preview`** draws the model built at other `values` (`{ "height": "2.5" }`; none: as the script is),
answers its image and puts the export back: nothing written. Use it to try values before setting them.

**Tune its parameters** -- `model_params_set` with `values`, name to value as text (`"2.5"`, `"true"`, `"oak"`;
null puts one back to its default): built as a preview, then written to the record and exported once -- one step.
`bake: true` writes them into the script's `params{}` defaults instead and clears the record's (the block's
Bake), also one step. Only names the script declares; a value its type refuses is refused.

**Build now** -- `model_export`: the script built into its `.glb`, current or not -- a job, answered within 20 s
when done, else `job_wait`.

**Change a material** -- `model_materials_set` with `material` (a `material{ name = … }` the script declares) and
`fields`: `base_color` and `emissive` as `[r, g, b]` linear 0 to 1, `metallic`, `roughness`, `alpha_cutoff`,
`alpha_mode` (`OPAQUE`, `MASK`, `BLEND`), `texture` and the other maps as an image's path beside the script,
`texture_filter`, `texture_wrap`, `compress`; null takes a field out. Written into that `material{}` call, one
step, then exported. A material the script does not declare (from an imported file) is refused: give the entity
a material file instead (`Render.material`, [the assets](assets.md)), or change the script.

**Pose a bone** -- `model_pose` keys joints into a clip, as `K` does: `clip` (an `action{}` the script declares),
`time` in seconds or `frame` (one of them), and `joints`, each name (as the script spells it; a rig's prefix may
be left off) to `{ forward, left, twist }` in degrees from rest and/or `translate` `[x, y, z]` metres from rest.
The key is made, or merged into the one there; one step, then exported. A key written as an expression, a rest
key, or a joint the key spells with `rotate` or `orient` is refused: change those in the script.

**The person's canvases** are drawings over the views -- marks, arrows, notes -- that come with their turn, to
show what they mean. Read them; they are the person's to make and clear, and no tool paints them.

## Refusals, and what they mean

| The answer says | What to do |
|---|---|
| No model is open in the Model tab: model_open opens one | open it first |
| … is no Gladius script: a model's script is AssetsSource/models/…/<name>.lua | name the `.lua`, not the `.glb` |
| The Model tab shows a preview of … at values nobody wrote | set them (`model_params_set`), or ask before `discard: true` |
| The Model tab is writing a change: try again in a moment | it is saving: try again shortly |
| … was not opened: a playtest runs -- the Model tab opens once it stops | stop it first ([play](play.md)), or wait |
| … was not opened: the editor is busy -- the status line says why | an Apply is landing, or the Model tab would not take the path (a script that changed meanwhile): read `studio_state`, try again in a moment |
| Read only: models are changed on the machine running the dev server | this page may not write models (another machine's browser): only reads and previews work here -- ask the person to make the change on that machine |
| Read only: out of the build by its _ name -- rename it without the _ … | a `_` file or folder is no source: `asset_move` with the name without the `_`, if the person wants it built |
| … is no material{} of … : the declared ones are … | use a declared one, or another way (above) |
| … declares no action{name="…"}: its actions are … | use one of them, or write the action in the script |
| Say when: time (seconds) or frame -- one of them | give exactly one |
| Out of the build: never exported -- tick it in the Assets panel | `asset_options` with `include: true` on the script ([the assets](assets.md)) |
| Not there: the script was renamed, moved or deleted | find it again (`asset_list`) |
| No preview: … | the build at those values failed: its words are Gladius's |
| A newer trace of … was asked for meanwhile | ask again |

## A job, end to end

"Make the lantern taller and warmer-coloured."

1. `asset_list` with `folder: 'AssetsSource/models/props'` -- `lantern.lua` is there. `model_params_get` with
   that `script` -- it has `height` (1.2, 0.5 to 3) and no colour parameter.
2. `model_open` with the script; `model_info` -- `ready`, a material `glass` declared.
3. `model_preview` with `values: { "height": "1.6" }` -- look at the image; good.
4. `model_params_set` with `values: { "height": "1.6" }` -- one step, the record written, exported.
5. `model_materials_set` with `material: 'glass'`, `fields: { "emissive": [1, 0.6, 0.2] }` -- one step, exported.
6. `view_shot` with `target: 'model'`, then say what changed: `Z` in the Model tab takes each step back.

## Rules that bite

- Change a model's shape in its script (the `gladius` skill); the tab's tools set what the script exposes.
- A parameter set here lives in the record, not the script: read the record's values (`model_params_get`) before
  calling a default wrong.
- Never write the `.glb` under `src/assets/models/`: it is the export, made again from the script.
- `model_open` moves the person's tab: open a model when the job is about it, not to look something up --
  `model_params_get` and `model_trace` read a script without opening it.
