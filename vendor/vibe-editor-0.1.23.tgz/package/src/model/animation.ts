/**
 * The model's clips played on it (Docs/modeler.md M31; Vibe3D D89's
 * `animationPanel.ts`, its clock and mixer without its DOM): one clip at a
 * time, the rest pose first, the clock the tab's own.
 *
 * - **The tab owns the clock**: the action's time is set and the mixer
 *   advanced by zero, never let run -- scrub, step, loop and speed are one
 *   number, not a negotiation with the action's own loop and pause.
 * - **One clip at a time**: stopping an action hands every property back, so a
 *   joint the next clip does not key goes back to rest.
 * - **Carried across a rebuild by name** (D89): the clip, its time and whether
 *   it plays -- the usual reason for a rebuild is someone editing the very
 *   action being watched. A clip gone, back to rest.
 * - **Held, the bounds are the pose's**: a skinned mesh's bounds were its rest
 *   pose's, and a raycast tests them first -- a click on a raised wing would
 *   miss. Recomputed while held, not while playing (nobody picks a moving
 *   target).
 * - **The bones overlay** (`SkeletonHelper`, Vibe3D's look: lines from each
 *   bone to its parent, over the mesh) and **a bone picked on screen** against
 *   those lines, not by a ray -- a ray hits the body every time.
 * - **Each bone's rest kept** as the model loads, before any clip: what every
 *   field of a key is measured from (D121).
 */
import * as THREE from 'three';
import { clipInfo, type ClipExtras } from '@vibe/engine';
import { advance, loops, round3, snapToFrame, stepFrame, type ClipInfo, type PoseRef } from './clips.ts';
import { BoneSticks } from './bones.ts';
import type { Rest } from './pose-math.ts';

export interface PlayerHost {
  /** A frame, please. */
  draw(): void;
  /** The pose shown changed -- another clip, a time, the rest pose -- or it plays on: `playing` says. */
  changed(playing: boolean): void;
  /** The clip has just been written onto the bones: a held edit goes back over it (D121). */
  afterApply(): void;
}

/** A clip as the player keeps it: three's and the tab's. */
interface Clip {
  clip: THREE.AnimationClip;
  info: ClipInfo;
}

export class Player {
  /** The bones overlay: one for the tab's life, its sticks the model's (`bones.ts`). */
  private readonly sticks = new BoneSticks();
  readonly bones = this.sticks.group;
  private showBones = false;
  private clips: Clip[] = [];
  private root: THREE.Object3D | null = null;
  private mixer: THREE.AnimationMixer | null = null;
  private action: THREE.AnimationAction | null = null;
  private index = -1;
  private at = 0;
  private running = false;
  private rate = 1;
  /** Loop turned by hand, by the clip's name: kept across a rebuild. */
  private readonly looping = new Map<string, boolean>();
  private skinned: THREE.SkinnedMesh[] = [];
  private readonly rests = new Map<THREE.Bone, Rest>();
  private frame = 0;
  private last = 0;
  private readonly host: PlayerHost;

  constructor(host: PlayerHost) {
    this.host = host;
    this.bones.name = 'model: bones';
  }

  get list(): readonly ClipInfo[] {
    return this.clips.map((c) => c.info);
  }
  /** The clip shown, or null for the rest pose. */
  get current(): ClipInfo | null {
    return this.clips[this.index]?.info ?? null;
  }
  get time(): number {
    return this.at;
  }
  get playing(): boolean {
    return this.running;
  }
  get speed(): number {
    return this.rate;
  }
  /** The model as the script builds it: no clip applied. */
  get atRest(): boolean {
    return this.index < 0;
  }
  /** The pose shown, as gladius_query names it; null at rest. */
  get pose(): PoseRef | null {
    const info = this.current;
    return info ? { action: info.name, time: round3(this.at) } : null;
  }
  /** Does this clip loop: the person's choice, else the file's. */
  loops(info: ClipInfo): boolean {
    return loops(info, this.looping);
  }
  /** The skinned meshes of the model. */
  get meshes(): readonly THREE.SkinnedMesh[] {
    return this.skinned;
  }
  /** Every bone of the model, in its order. */
  get allBones(): THREE.Bone[] {
    return [...this.rests.keys()];
  }
  /** A bone as the script builds it. */
  restOf(bone: THREE.Bone): Rest | undefined {
    return this.rests.get(bone);
  }

  /** A model in -- a first load, a rebuild, a preview -- with its clips: the clip, its time and its playing carried by name. */
  setModel(root: THREE.Object3D | null, animations: readonly THREE.AnimationClip[]): void {
    const keep = this.current?.name;
    this.mixer?.stopAllAction();
    if (this.mixer && this.root) this.mixer.uncacheRoot(this.root);
    this.action = null;
    this.root = root;
    this.mixer = root ? new THREE.AnimationMixer(root) : null;
    this.clips = root ? animations.map((clip) => ({ clip, info: clipInfo(clip.name, clip.tracks.map((tr) => ({ name: tr.name, samples: tr.times.length })), clip.duration, clip.userData as ClipExtras) })) : [];
    this.skinned = [];
    this.rests.clear();
    // Before any clip: the file's own values -- each bone's and its rotation in the model, the axes a key is in (M33).
    root?.updateMatrixWorld(true);
    const inModel = new THREE.Quaternion();
    const modelOf = (o: THREE.Object3D): THREE.Quaternion => inModel.copy(root!.getWorldQuaternion(new THREE.Quaternion())).invert().multiply(o.getWorldQuaternion(new THREE.Quaternion())).clone();
    root?.traverse((o) => {
      if ((o as THREE.SkinnedMesh).isSkinnedMesh) this.skinned.push(o as THREE.SkinnedMesh);
      if ((o as THREE.Bone).isBone) {
        this.rests.set(o as THREE.Bone, { quaternion: o.quaternion.clone(), position: o.position.clone(), world: modelOf(o), parentWorld: o.parent ? modelOf(o.parent) : new THREE.Quaternion() });
      }
    });
    this.makeBones();
    const index = keep === undefined ? -1 : this.clips.findIndex((c) => c.info.name === keep);
    this.index = -1;
    if (index >= 0) this.choose(this.clips[index]!.info.name, this.at, this.running);
    else {
      this.stop();
      this.at = 0;
      this.host.changed(false);
    }
  }

  /** A clip on screen at a time -- playing or held; null for the rest pose. The one place an action starts. */
  choose(name: string | null, time = 0, play = false): void {
    const index = name === null ? -1 : this.clips.findIndex((c) => c.info.name === name);
    const clip = this.clips[index];
    if (!clip || !this.mixer) return this.rest();
    if (index !== this.index || !this.action) {
      // One clip at a time: a joint the next does not key goes back to rest.
      this.mixer.stopAllAction();
      this.action = this.mixer.clipAction(clip.clip);
      this.action.play();
    }
    this.index = index;
    const t = Math.min(Math.max(0, time), clip.info.duration);
    this.at = play ? t : snapToFrame(clip.info, t);
    this.setRunning(play);
    this.apply();
  }

  /** Back to the pose the script builds. */
  rest(): void {
    this.mixer?.stopAllAction();
    this.action = null;
    this.index = -1;
    this.at = 0;
    this.setRunning(false);
    this.refreshBounds();
    this.host.changed(false);
    this.host.draw();
  }

  /** Go to a pose recorded (a canvas reopened): its clip held at its time, or the rest pose. */
  goTo(pose: PoseRef | null): void {
    if (!pose || !this.clips.some((c) => c.info.name === pose.action)) return this.rest();
    this.choose(pose.action, pose.time, false);
  }

  /** Play, or hold the frame shown: from a one-shot's end, playing again from its start. */
  toggle(): void {
    const info = this.current;
    if (!info) {
      const first = this.clips[0];
      if (first) this.choose(first.info.name, 0, true);
      return;
    }
    if (this.running) return this.pause();
    const from = !this.loops(info) && this.at >= info.duration ? 0 : this.at;
    this.choose(info.name, from, true);
  }

  /** Held on the frame nearest: a pose is one frame -- a canvas drawn over it, a bone posed at it. */
  pause(): void {
    const info = this.current;
    if (!this.running || !info) return;
    this.at = snapToFrame(info, this.at);
    this.setRunning(false);
    this.apply();
  }

  /** Held at a time, on its frame. */
  seek(time: number): void {
    const info = this.current;
    if (!info) return;
    this.setRunning(false);
    this.at = snapToFrame(info, Math.min(Math.max(0, time), info.duration));
    this.apply();
  }

  /** A frame on or back at the clip's rate (D89). */
  step(by: number): void {
    const info = this.current;
    if (!info) return;
    this.seek(stepFrame(info, this.at, by, this.loops(info)));
  }

  setSpeed(speed: number): void {
    this.rate = speed;
    this.host.changed(this.running);
  }

  setLoop(on: boolean): void {
    const info = this.current;
    if (!info) return;
    this.looping.set(info.name, on);
    this.host.changed(this.running);
  }

  setBones(on: boolean): void {
    this.showBones = on;
    this.bones.visible = on;
    this.host.draw();
  }

  get bonesShown(): boolean {
    return this.showBones && this.rests.size > 0;
  }

  /** Before a frame: the sticks where the bones are. */
  placeBones(): void {
    this.sticks.place();
  }

  /** Before a view is drawn: the sticks' widths in its pixels. */
  bonesFor(width: number, height: number): void {
    this.sticks.resolution(width, height);
  }

  /** The selected bones amber, the one under the pointer lit: true if that changed (a frame to draw). */
  markBones(chosen: readonly THREE.Bone[], lit: THREE.Bone | null): boolean {
    return this.sticks.mark(chosen, lit);
  }

  /** The bone whose stick is under a point of a view, with Bones on (D121, `bones.ts`): every bone a stick of its own, a leaf too. */
  pickBone(camera: THREE.Camera, x: number, y: number, width: number, height: number): THREE.Bone | null {
    return this.bonesShown ? this.sticks.pick(camera, x, y, width, height) : null;
  }

  /** The pose put on the bones again -- an edit forced over it after (`afterApply`). */
  apply(): void {
    if (this.mixer && this.action) {
      this.action.time = this.at;
      this.mixer.update(0);
    }
    this.host.afterApply();
    if (!this.running) this.refreshBounds();
    this.host.changed(this.running);
    this.host.draw();
  }

  /** Bones moved from outside (a pose held): what a pose puts out of date, put right. */
  refreshBounds(): void {
    for (const mesh of this.skinned) {
      mesh.skeleton.update();
      mesh.computeBoundingBox();
      mesh.computeBoundingSphere();
    }
  }

  dispose(): void {
    cancelAnimationFrame(this.frame);
    this.frame = 0;
    this.mixer?.stopAllAction();
    this.sticks.dispose();
  }

  // ---------------------------------------------------------------- inside

  private stop(): void {
    this.mixer?.stopAllAction();
    this.action = null;
    this.index = -1;
    this.setRunning(false);
  }

  private setRunning(on: boolean): void {
    this.running = on;
    if (on && this.frame === 0) {
      this.last = performance.now();
      this.frame = requestAnimationFrame((now) => this.tick(now));
    } else if (!on && this.frame !== 0) {
      cancelAnimationFrame(this.frame);
      this.frame = 0;
    }
  }

  /** A frame of playback: the clock moved by the page's time at the speed -- a loop wraps, a one-shot stops on its last frame. */
  private tick(now: number): void {
    this.frame = 0;
    const info = this.current;
    if (!this.running || !info) return;
    const seconds = Math.min(0.1, Math.max(0, (now - this.last) / 1000));
    this.last = now;
    const next = advance(info, this.at, seconds, this.rate, this.loops(info));
    this.at = next.time;
    this.running = next.playing;
    this.apply();
    if (this.running) this.frame = requestAnimationFrame((t) => this.tick(t));
  }

  /** The sticks measured for the model's bones, at rest: a root's alone a twentieth of the model's size. */
  private makeBones(): void {
    const size = this.root ? new THREE.Box3().setFromObject(this.root).getSize(new THREE.Vector3()).length() : 1;
    this.sticks.set([...this.rests.keys()], Math.max(size, 1e-3) / 20);
    this.bones.visible = this.showBones;
  }
}
