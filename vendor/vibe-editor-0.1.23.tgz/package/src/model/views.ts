/**
 * The Model tab's views as numbers (Docs/modeler.md M9, M11): the layouts and
 * their slots, each view's place in the stage, and the grid's scale and
 * readout -- pure, no three.js and no DOM, so a node test holds every rule
 * (`views.test.ts`). What a view is shared with the Scene tab's -- where it
 * looks from and its name, a rect, the cube's box, the numpad's views -- is
 * `../view/views.ts`.
 *
 * - **Fixed slots per layout** (Vibe3D D23): one view is Free in perspective;
 *   two are Free and Front; four are Top, Free, Front and Right -- the axis
 *   views orthographic, which is what makes them measurable.
 * - **The ground picks its scale** (D79): a 1-2-5 ladder walked until the
 *   model, measured from the origin, is covered by 5 to 15 major squares.
 */

import type { Preset, Projection, Rect } from '../view/views.ts';

export type Layout = 1 | 2 | 4;
export const LAYOUTS: readonly Layout[] = [1, 2, 4];

/** A view a layout makes: where it looks from first, and in which projection. */
export interface Slot {
  preset: Preset;
  projection: Projection;
}

/** Left to right, then top to bottom. The free view is the one modelled in; the axis views are for measuring (D23). */
export const SLOTS: Readonly<Record<Layout, readonly Slot[]>> = {
  1: [{ preset: 'free', projection: 'perspective' }],
  2: [
    { preset: 'free', projection: 'perspective' },
    { preset: 'front', projection: 'orthographic' },
  ],
  4: [
    { preset: 'top', projection: 'orthographic' },
    { preset: 'free', projection: 'perspective' },
    { preset: 'front', projection: 'orthographic' },
    { preset: 'right', projection: 'orthographic' },
  ],
};

/** The next layout, 1 → 2 → 4 → 1: what `L` does. */
export function nextLayout(layout: Layout): Layout {
  return LAYOUTS[(LAYOUTS.indexOf(layout) + 1) % LAYOUTS.length]!;
}

/** Each view's rect in a canvas `width` × `height`: one whole, two side by side, four in a grid -- whole pixels, no gap. */
export function rectsFor(layout: Layout, width: number, height: number): Rect[] {
  const w = Number.isFinite(width) ? Math.max(0, Math.floor(width)) : 0;
  const h = Number.isFinite(height) ? Math.max(0, Math.floor(height)) : 0;
  const halfW = Math.floor(w / 2);
  const halfH = Math.floor(h / 2);
  if (layout === 1) return [{ x: 0, y: 0, width: w, height: h }];
  if (layout === 2) return [{ x: 0, y: 0, width: halfW, height: h }, { x: halfW, y: 0, width: w - halfW, height: h }];
  return [
    { x: 0, y: 0, width: halfW, height: halfH },
    { x: halfW, y: 0, width: w - halfW, height: halfH },
    { x: 0, y: halfH, width: halfW, height: h - halfH },
    { x: halfW, y: halfH, width: w - halfW, height: h - halfH },
  ];
}

/** Which view a point of the canvas is in: its index, or -1 for none. */
export function viewAt(rects: readonly Rect[], x: number, y: number): number {
  return rects.findIndex((r) => x >= r.x && x < r.x + r.width && y >= r.y && y < r.y + r.height);
}

// ---------------------------------------------------------------- the ground's scale

/** The grid's spacing and size, in metres. */
export interface GridScale {
  /** Between light lines. */
  minor: number;
  /** Between heavy lines: ten minors. */
  major: number;
  /** Edge to edge. */
  size: number;
}

/** Ten minors to a major, at every scale. */
export const PER_MAJOR = 10;
/** The model is covered by between these many major squares (D79). */
export const MIN_SQUARES = 5;
export const MAX_SQUARES = 15;
const LADDER = [1, 2, 5] as const;

/**
 * The smallest rung of the 1-2-5 ladder whose major squares cover `reach` --
 * how far from the origin the model goes, in metres -- in 5 to 15 of them; the
 * count rounded up and one past an exact fit, so a model is never on the rim.
 * Nothing (0) is a half-metre: ground something can be put on.
 */
export function gridScale(reach: number): GridScale {
  const needed = 2 * (reach > 0 && Number.isFinite(reach) ? reach : 0.5);
  for (let power = -6; power <= 9; power++) {
    for (const step of LADDER) {
      // Rounded to the rung's own digits: 0.1 + 0.2 is not a scale.
      const major = Number((step * 10 ** power).toPrecision(3));
      // An exact fit read as one (1.4 / 0.1 is 13.999…): a square past it, so a model is never on the rim.
      const squares = Math.floor(needed / major + 1e-9) + 1;
      if (squares >= MIN_SQUARES && squares <= MAX_SQUARES) return { minor: Number((major / PER_MAJOR).toPrecision(3)), major, size: Number((squares * major).toPrecision(6)) };
    }
  }
  return { minor: 1, major: 10, size: 100 };
}

/** A length in the unit that suits it: `5 mm`, `10 cm`, `1 m`, `2.5 km`. */
export function metres(value: number): string {
  const a = Math.abs(value);
  const round = (n: number): string => String(Number(n.toPrecision(3)));
  if (a === 0) return '0 m';
  if (a < 0.01) return `${round(value * 1000)} mm`;
  if (a < 1) return `${round(value * 100)} cm`;
  if (a < 1000) return `${round(value)} m`;
  return `${round(value / 1000)} km`;
}

/** What the grid's readout says (D79): a light square, a heavy one, and the ground across. */
export function gridReadout(scale: GridScale): string {
  return `grid ${metres(scale.minor)} · ${metres(scale.major)} · ${metres(scale.size)} across`;
}
