/**
 * The Model tab's phase 2 (Docs/modeler.md §4, M22–M25): what changes a model
 * from the tab -- its parameters, its materials -- and the undo over all of it.
 * Made once by `model-tool.ts`, which hands it the model open and shows what
 * it builds.
 *
 * - **Parameters** (`param-panel.ts`): `GET params` read as a model opens, its
 *   script or its record moves; a value dragged built as a preview
 *   (`preview-client.ts`, `POST preview`) and shown in the views in place of
 *   the export, nothing written; let go, committed to the record's `params`
 *   (`PUT sidecar`) -- one step -- which exports the shipped model once, whose
 *   arrival puts the preview away. Bake writes the values into `params{}`'s
 *   defaults and clears the overrides, as one step (D45).
 * - **Materials** (`material-panel.ts`): read off the model shown, beside what
 *   the script declares; a control moving changes the tab's own decode live,
 *   let go is written into the `material{}` call -- one step -- and the export
 *   that follows has it for real; not written (nothing changed, refused), the
 *   model is put back as it was.
 * - **The undo** (`script-steps.ts`): the tab's own stack, the editor's Z, Y and
 *   History card while the tab has the keys; an outside edit of the script a
 *   step as it lands. Emptied for another model.
 */
import type * as THREE from 'three';
import type { GLTF } from 'three/addons/loaders/GLTFLoader.js';
import type { Entry, Options, ParamSpec } from '@vibe/pipeline/assets-types';
import { dirName, extOf, recordPath } from '@vibe/pipeline/paths';
import { decodeModel, disposeModel, extrasOntoClips } from '@vibe/engine';
import { keyLabel } from '@vibe/engine/debug';
import { ApiRefused, type Api } from '../assets/api.ts';
import type { Live } from '../assets/live.ts';
import { createHistory, type History } from '../history.ts';
import { createMaterialPanel } from './material-panel.ts';
import { materialsOf, previewMaterial, type LiveChange, type LiveState, type MaterialInfo } from './materials.ts';
import { createParamPanel } from './param-panel.ts';
import { createParamReader } from './param-reader.ts';
import { overrideText, rowsOf, sayValue, valueOf, withoutParams } from './params.ts';
import type { PartTree } from './parts.ts';
import { createPreviewClient } from './preview-client.ts';
import { declaredMaterials, type DeclaredMaterial, type MaterialField, type MaterialValue } from './script-edits.ts';
import { createScriptSteps } from './script-steps.ts';
import { bakeParams, commitMaterial, commitParams, createEditingAgent, type EditingAgent } from './editing-agent.ts';

export interface EditingHost {
  api: Api;
  live: Live;
  /** The script open, or null. */
  path(): string | null;
  /** May this page write. */
  writes(): boolean;
  /** Why nothing of this model may be written, though the page may write (a script out of the build by its `_`), or null. */
  readOnly(): string | null;
  /** A line on the editor's status line. */
  say(text: string): void;
  /** Is a Claude turn holding the open script's export: an edit of it landing now is the turn's. */
  heldForClaude?(): boolean;
  /** A preview's model shown in place of the export, its clips with it: as a rebuild -- cameras, selection, hidden parts kept. */
  showPreview(scene: THREE.Object3D, animations: readonly THREE.AnimationClip[]): void;
  /** The export shown again, the preview put away (`source.reshow`). */
  reshow(): void;
  /** Parts selected, by id. */
  select(ids: readonly string[]): void;
  /** The views drawn again: a material changed live. */
  draw(): void;
  /** The toolbar's chip and the panels drawn again: a preview building or not. */
  changed(): void;
  /** The script edited from outside -- a text editor, Claude, another page -- heard as a step: `label` says where. */
  outside?(label: string): void;
  /** The fold choices kept, and the way to keep one. */
  folds(): Readonly<Record<string, boolean>>;
  keepFold(key: string, folded: boolean): void;
}

export interface Editing {
  readonly history: History;
  busy(): boolean;
  /** The Parameters and Materials blocks, for the right panel. */
  readonly blocks: readonly HTMLElement[];
  /** A preview is shown in place of the export. */
  readonly previewing: boolean;
  /** A preview is being built. */
  readonly building: boolean;
  /** Every parameter in effect, as the script's `params{}` reads now: its value as Gladius takes it. */
  params(): { name: string; value: string }[];
  /** The script as saved built as a preview -- its export held for a Claude turn (Docs/modeler.md M21). */
  savedPreview(): void;
  /** Why the last such preview did not build, or null: quiet, on the chip alone (D44). */
  readonly savedError: string | null;
  /** A script opened -- or none: the stack emptied, the parameters read. */
  open(path: string | null): void;
  /** The export shown (a first load or a rebuild): the preview, if any, put away for it. */
  exportShown(): void;
  /** A model on screen -- the export or a preview -- with its parts: its materials read. */
  model(tree: PartTree | null, scene: THREE.Object3D | null): void;
  /** The selection changed: the materials it uses marked. */
  selection(ids: readonly string[]): void;
  /** Both blocks drawn again: whether the page may write is known now. */
  redraw(): void;
  /** The overrides the export is built with, by name: facts for Claude's turn. */
  overrides(): Readonly<Record<string, string>>;
  /** The script's text as the tab last knew it (read, written, noticed), or null: phase 4 reads its actions' keys from it. */
  scriptText(): string | null;
  /**
   * The script changed by the tab as one whole-file step of its undo (M23) -- a pose keyed (M33): `change` given the
   * text on disk as its turn comes. True once pushed.
   */
  editScript(label: string, change: (text: string) => string | { problem: string }): Promise<boolean>;
  /** A Claude turn has just taken hold of the open script: the outside step its first save left is the turn's (`claimedByTurn`). */
  claimedByTurn(): void;
  /** The tab's undo is writing: a key waits. */
  readonly writing: boolean;
  /** The source's record's options changed as one step of the tab's undo -- the Options block's own way (`PUT sidecar`). True once pushed. */
  editRecord(label: string, change: (options: Options) => Options): Promise<boolean>;
  /** The studio's model tools (Docs/mcp.md M6): the blocks' own steps, with no widget between. */
  readonly agent: EditingAgent;
  dispose(): void;
}

/** The images a material's slots may name: PNG and JPEG in the script's folder or under it, as the script names them. */
export function imagesFor(script: string, entries: Iterable<Entry>): string[] {
  const dir = dirName(script);
  const out: string[] = [];
  for (const e of entries) {
    if (!e.path.startsWith(`${dir}/`)) continue;
    if (!['png', 'jpg', 'jpeg'].includes(extOf(e.path))) continue;
    out.push(e.path.slice(dir.length + 1));
  }
  return out.sort();
}

export function createEditing(host: EditingHost): Editing {
  const { api, live } = host;
  const history = createHistory();
  const steps = createScriptSteps({
    history,
    putScript: (path, text, expect) => api.putScript(path, text, expect),
    putSidecar: (path, options) => api.putSidecar(path, options),
    putRecord: (path, text, expect) => api.putRecord(path, text, expect),
    async read(path) {
      // Not in the index: not there -- asked of no one, so no red line in the console for a script renamed away.
      if (live.index.loaded && !live.index.entries.has(path)) return null;
      try {
        return await (await api.file(path, { cache: 'no-store' })).text();
      } catch (err) {
        if (err instanceof ApiRefused && err.status === 404) return null;
        throw err;
      }
    },
    reached: (seq) => live.until(seq),
    reread: () => live.refresh(),
    failed: (message) => host.say(message),
    claude: () => host.heldForClaude?.() === true,
    noticed: (label) => {
      host.say(`${label} -- a step: ${keyLabel('KeyZ')} takes it back`);
      drawMaterials();
      host.outside?.(label);
    },
  });

  // ---------------------------------------------------------------- parameters

  let previewError: string | null = null;
  /** The value whose preview failed last, by name: said when that value is let go (it is written all the same, D47). */
  let failedValue: { name: string; text: string } | null = null;
  let previewing = false;
  /** Why the last preview of a save held for a Claude turn did not build (M21): the chip's, never the panel's. */
  let savedError: string | null = null;
  let building = false;
  /** The preview on screen, decoded for the tab alone: freed when the next comes or the export is shown again. */
  let previewModel: GLTF | null = null;

  /** Why this model is read-only here: the page may not write, or the script is out of the build by its name. */
  const why = (): string | null => (host.writes() ? host.readOnly() : 'Read only: models are changed on the machine running the dev server.');
  const canWrite = (): boolean => why() === null;

  /** `GET params` for the script opened -- that one alone (`param-reader.ts`). */
  const reader = createParamReader(async (path) => {
    if (live.index.loaded && !live.index.entries.has(path)) return { ok: false, ms: 0, params: null, set: {}, own: {}, diagnostics: [], problem: `${path} is not there` };
    return api.params(path);
  }, () => drawParams());
  /** The script opened: given to `open`, never asked of the tab, which opens it after. */
  const openPath = (): string | null => reader.path;
  const readParams = (): Promise<void> => reader.read();

  const paramPanel = createParamPanel({
    preview(name, text) {
      const path = openPath();
      // A row of the open script's alone: one left from a script before is never built as this one's.
      if (!path || !canWrite() || !reader.spec(name)) return;
      previews.ask({ path, params: { [name]: text } });
    },
    commit: (spec, text) => commitParam(spec, text),
    resetAll() {
      void steps.options('Every parameter back to its default', (o) => withoutParams(o)).then(settledParams);
    },
    bake: () => bake(),
    folded: (folded) => host.keepFold('params', folded),
  });

  function drawParams(): void {
    paramPanel.draw({ answer: reader.answer, reading: reader.reading, writes: canWrite(), readOnly: why(), building, previewError, busy: steps.steps.busy() });
  }

  /** After a step of the tab's: the parameters read again, whatever the index has said meanwhile. */
  const settledParams = (pushed: boolean): void => {
    // The drag is over: what its previews said is said; the build that follows has its own words (the banner).
    previewError = null;
    failedValue = null;
    if (!pushed && previewing) {
      // Nothing written: the export is what is so, and it is shown again.
      previews.stop();
      host.reshow();
    }
    void readParams();
  };

  function commitParam(asked: ParamSpec, text: string | undefined): void {
    const path = openPath();
    // Only a parameter the open script declares, as its latest answer has it: never one from a script before.
    const spec = reader.spec(asked.name);
    if (!path || !spec || steps.path !== path) return;
    const file = path.split('/').pop();
    const to = text !== undefined && text === overrideText(spec, spec.default) ? undefined : text;
    const fails = to !== undefined && failedValue !== null && failedValue.name === spec.name && failedValue.text === to ? previewError : null;
    void commitParams(steps, [{ spec, text }]).then(({ label, pushed }) => {
      if (pushed && fails) host.say(`${spec.name} ${sayValue(valueOf(spec, to!))} written: the script fails at it (${fails}) -- ↺ or ${keyLabel('KeyZ')} takes it back`);
      else if (pushed) host.say(`${label}: written to ${file?.replace(/\.lua$/, '.export.json')}, exported once -- ${keyLabel('KeyZ')} takes it back`);
      settledParams(pushed);
    });
  }

  function bake(): void {
    const path = openPath();
    const answer = reader.answer;
    if (!path || !answer || !answer.ok || steps.path !== path) return;
    const file = path.split('/').pop() ?? path;
    const changed = rowsOf(answer).filter((r) => r.changed);
    if (changed.length === 0) return host.say('Nothing to bake: every parameter is at its default');
    void bakeParams(steps, file, changed.map((r) => ({ spec: r.spec, value: r.spec.value }))).then(({ pushed, result: r }) => {
      if (pushed && r) {
        const skipped = r.skipped.length > 0 ? `; not ${r.skipped.map((s) => `${s.name} (${s.why})`).join(', ')} -- its override kept` : '';
        host.say(`Baked ${r.baked.join(', ')} into ${file}${skipped} -- ${keyLabel('KeyZ')} takes it back`);
      }
      settledParams(pushed);
    });
  }

  const previews = createPreviewClient({
    build: (ask) => api.preview(ask.path, ask.params),
    async show(ask, bytes, _ms, still) {
      if (ask.path !== openPath()) return false;
      let gltf: GLTF;
      try {
        gltf = await decodeModel({ bytes, name: 'preview.glb' });
      } catch (err) {
        previewError = `it did not decode: ${(err as Error).message}`;
        drawParams();
        return false;
      }
      // Another model open, or stopped while it decoded (the export landed: `exportShown`) -- not shown over it.
      if (ask.path !== openPath() || !still()) {
        disposeModel(gltf);
        return false;
      }
      extrasOntoClips(gltf);
      const before = previewModel;
      previewModel = gltf;
      previewing = true;
      previewError = null;
      failedValue = null;
      if (Object.keys(ask.params).length === 0) savedError = null;
      host.showPreview(gltf.scene, gltf.animations);
      if (before) disposeModel(before);
      drawParams();
      return true;
    },
    failed(ask, error) {
      if (ask.path !== openPath()) return;
      // A save of Claude's mid-turn that does not build yet (M21): quiet -- a script half edited is expected to be broken (D44).
      if (Object.keys(ask.params).length === 0) {
        savedError = error;
        host.changed();
        return;
      }
      previewError = error;
      const [name, text] = Object.entries(ask.params)[0] ?? [];
      failedValue = name !== undefined && text !== undefined ? { name, text } : null;
      drawParams();
    },
    busy(b) {
      building = b;
      drawParams();
      host.changed();
    },
  });

  // ---------------------------------------------------------------- materials

  let materials: MaterialInfo[] = [];
  let modelShown = false;
  let selected = new Set<string>();
  /** The live changes since the model was shown, to put back if a commit does not land. */
  let kept: LiveState = new Map();
  /** What the script declares, read from its text as last known, by that text. */
  let declaredFor: { text: string | null; map: Map<string, DeclaredMaterial> } = { text: null, map: new Map() };
  const declared = (): Map<string, DeclaredMaterial> => {
    const text = steps.text;
    if (declaredFor.text !== text) declaredFor = { text, map: new Map(text ? declaredMaterials(text).map((d) => [d.name, d] as const) : []) };
    return declaredFor.map;
  };

  const materialPanel = createMaterialPanel({
    select: (info) => host.select(info.parts.map((p) => p.id)),
    live(info, change: LiveChange) {
      previewMaterial(info, change, kept);
      host.draw();
    },
    commit(info, field: MaterialField, value: MaterialValue, from: string) {
      void commitMaterial(steps, info.name, { [field]: value }, from).then(({ label, pushed }) => {
        if (pushed) host.say(`${label}: written into the script, exported once -- ${keyLabel('KeyZ')} takes it back`);
        else {
          previewMaterial(info, {}, kept).restore();
          kept = new Map();
          host.draw();
        }
        drawMaterials();
      });
    },
    images: () => {
      const path = openPath();
      return path ? imagesFor(path, live.index.entries.values()) : [];
    },
    folded: (name, folded) => {
      host.keepFold(`m:${name}`, folded);
      drawMaterials();
    },
    foldedAll: (folded) => host.keepFold('materials', folded),
  });

  function drawMaterials(): void {
    const folds = host.folds();
    const many = materials.length > 1;
    // A material never folded or unfolded by hand: open when it is the only one (D94).
    const folded = new Set(materials.filter((m) => folds[`m:${m.name}`] ?? many).map((m) => m.name));
    materialPanel.draw({ list: materials, declared: declared(), selected, folded, writes: canWrite(), readOnly: why(), modelShown, reading: steps.text === null });
  }

  // ---------------------------------------------------------------- the index

  /** The script's and its record's versions as last heard: a move of either reads the parameters again. */
  let versions = '';
  const versionOf = (path: string): string => {
    const e = live.index.entries.get(path);
    return e ? `${e.mtime}:${e.size}` : '-';
  };
  const offChanged = live.on('changed', () => {
    const path = openPath();
    if (!path || !live.index.loaded) return;
    const script = versionOf(path);
    const now = `${script}|${versionOf(recordPath(path))}`;
    if (now === versions) return;
    const scriptMoved = versions.split('|')[0] !== script;
    versions = now;
    if (scriptMoved) void steps.check().then(() => drawMaterials());
    void readParams();
  });
  // A build of the script ended with a preview still up -- its bytes the same as the export's (a parameter the mesh does not
  // read), or failed: no new export arrives to put the preview away, so the export is shown again once the source settles.
  let backTimer: ReturnType<typeof setTimeout> | undefined;
  const offJob = live.on('job', (job) => {
    if (job.source !== openPath() || !['done', 'skipped', 'failed', 'unmade'].includes(job.state)) return;
    clearTimeout(backTimer);
    backTimer = setTimeout(() => {
      if (previewing && !building && !previews.busy && job.source === openPath()) host.reshow();
    }, 600);
  });
  // The bars' Undo follows the queue; the blocks' Bake and Reset wait while it works.
  const offHistory = history.on((event) => {
    drawParams();
    // Z and Y said on the editor's line, with what they took back -- not a put-back after a failure, which says its own.
    if (steps.steps.restoring) return;
    // The label as done, not as its call is under way (`steps.ts` marks that with an ellipsis).
    const done = (label: string): string => label.replace(/\s*…$/, '');
    if (event === 'undo' && history.redoLabel) host.say(`Undid ${done(history.redoLabel)}`);
    else if (event === 'redo' && history.undoLabel) host.say(`Redid ${done(history.undoLabel)}`);
  });

  const folds = host.folds();
  paramPanel.setFolded(folds.params === true);
  materialPanel.setFolded(folds.materials === true);

  // ---------------------------------------------------------------- the studio's model tools (Docs/mcp.md M6)

  const agent = createEditingAgent({
    steps,
    path: openPath,
    why: () => why(),
    readParams,
    answer: () => reader.answer,
    preview: {
      ask: (path, params) => previews.ask({ path, params }),
      idle: () => previews.idle(),
      stop: () => previews.stop(),
      error: () => previewError,
      clearError: () => void (previewError = null),
      showing: () => previewing,
    },
    reshow: () => host.reshow(),
    settled: (pushed) => settledParams(pushed),
    materials: () => materials,
    declared: () => declared(),
    drawMaterials: () => drawMaterials(),
  });

  return {
    history,
    agent,
    busy: () => steps.steps.busy(),
    blocks: [paramPanel.root, materialPanel.root],
    get previewing() {
      return previewing;
    },
    get building() {
      return building;
    },
    get savedError() {
      return savedError;
    },
    savedPreview() {
      const path = openPath();
      // The script as saved, its export held for a Claude turn (M21): built as a preview at its own parameters, shown as a rebuild.
      if (path) previews.ask({ path, params: {} });
    },
    open(path) {
      reader.open(path);
      previewError = null;
      failedValue = null;
      previews.stop();
      previewing = false;
      if (previewModel) disposeModel(previewModel);
      previewModel = null;
      versions = '';
      kept = new Map();
      // Once the tab's index is in: a script not in it (renamed away since it was last open) is asked of no one.
      const opened = path;
      void steps.open(null).then(() => live.start()).then(() => {
        if (reader.path !== opened) return;
        void steps.open(opened).then(() => drawMaterials());
        if (opened) void readParams();
      }, () => {
        if (reader.path === opened && opened) void readParams();
      });
      drawParams();
    },
    exportShown() {
      if (previewing) previews.stop();
      previewing = false;
      if (previewModel) disposeModel(previewModel);
      previewModel = null;
      kept = new Map();
      host.changed();
    },
    model(tree, scene) {
      materials = tree && scene ? materialsOf(tree, scene) : [];
      modelShown = scene !== null;
      selected = new Set();
      drawMaterials();
    },
    selection(ids) {
      const set = new Set(ids);
      selected = new Set(materials.filter((m) => m.parts.some((p) => set.has(p.id))).map((m) => m.name));
      drawMaterials();
    },
    redraw() {
      drawParams();
      drawMaterials();
    },
    overrides: () => reader.answer?.set ?? {},
    scriptText: () => steps.text,
    editScript: (label, change) => steps.edit(label, change),
    claimedByTurn: () => steps.claimedByTurn(),
    editRecord: (label, change) => steps.options(label, change),
    get writing() {
      return steps.steps.busy();
    },
    params: () => (reader.answer?.params ?? []).map((p) => ({ name: p.name, value: String(p.value) })),
    dispose() {
      clearTimeout(backTimer);
      offJob();
      offChanged();
      offHistory();
      previews.stop();
      if (previewModel) disposeModel(previewModel);
      previewModel = null;
    },
  };
}
