/**
 * One `History` the editor holds that is, at any moment, another's
 * (Docs/modeler.md M28): the Model tab's stack (M23) -- or, in paint mode
 * with a canvas open, that canvas's own, so the editor's Z, Y and History card
 * undo its strokes and nothing else (Vibe3D's per-layer undo). The host reads
 * a tool's `history` once and listens to it once; this keeps that one object,
 * hands every call to the stack in use, and tells its listeners when the
 * stack in use changes (`'label'`: read me again).
 *
 * Pure: node tests it (`history-switch.test.ts`).
 */
import type { History, HistoryEvent, SetAside, Step } from '../history.ts';

export interface SwitchingHistory extends History {
  /**
   * The stack in use from now on -- and, `under` it, the one Z and Y fall through to when it has nothing to undo or
   * redo (review round 2: a canvas open with an empty stack, Z must still bring back a deleted canvas).
   */
  use(next: History, under?: History | null): void;
  /** The stack in use now. */
  readonly current: History;
}

/**
 * `guard`, given: the first Z that would fall through to the stack under, right after the canvas's own steps ran out,
 * does nothing but say what the next does -- "Next Z undoes Key: … on the model" -- so a Z pressed once too many
 * after a run of strokes never rewrites the script unseen (M28). Any other doing lets the guard go.
 */
export function switchingHistory(first: History, guard?: (label: string) => void): SwitchingHistory {
  let current = first;
  let under: History | null = null;
  /** The canvas's last step was just undone: the next fall-through is held once, and said. */
  let armed = false;
  const listeners = new Set<(event: HistoryEvent) => void>();
  const tell = (event: HistoryEvent): void => {
    for (const fn of [...listeners]) fn(event);
  };
  let off = current.on(tell);
  let offUnder = (): void => {};
  /** The stack Z works on now: the one in use, or under it when it has nothing to undo. */
  const undoing = (): History => (!current.canUndo && under?.canUndo ? under : current);
  const redoing = (): History => (!current.canRedo && under?.canRedo ? under : current);
  return {
    use(next, below = null) {
      if (next === current && below === under) return;
      armed = false;
      off();
      offUnder();
      current = next;
      under = below === next ? null : below;
      off = current.on(tell);
      offUnder = under ? under.on(tell) : () => {};
      tell('label');
    },
    get current() {
      return current;
    },
    get canUndo() {
      return undoing().canUndo;
    },
    get canRedo() {
      return redoing().canRedo;
    },
    get undoLabel() {
      return undoing().undoLabel;
    },
    get redoLabel() {
      return redoing().redoLabel;
    },
    get labels() {
      return current.labels;
    },
    get steps() {
      return current.steps;
    },
    get done() {
      return current.done;
    },
    get saved() {
      return current.saved;
    },
    get aside() {
      return current.aside;
    },
    push(step: Step) {
      armed = false;
      current.push(step);
    },
    group: <T>(label: string, run: () => T): T => current.group(label, run),
    undo() {
      const stack = undoing();
      if (guard && armed && stack === under && stack !== current) {
        armed = false;
        guard(stack.undoLabel ?? '');
        return false;
      }
      const done = stack.undo();
      // The canvas's own steps run out with this one: the next Z, falling through, is held once.
      armed = done && stack === current && under !== null && !current.canUndo && under.canUndo;
      return done;
    },
    redo() {
      armed = false;
      return redoing().redo();
    },
    place: (step: Step, done: boolean) => current.place(step, done),
    markSaved: () => current.markSaved(),
    forgetSaved: () => current.forgetSaved(),
    reset: () => current.reset(),
    touch: () => current.touch(),
    setAside: (): SetAside => current.setAside(),
    takeBack: (kept: SetAside) => current.takeBack(kept),
    on(listener) {
      listeners.add(listener);
      return () => void listeners.delete(listener);
    },
  };
}
