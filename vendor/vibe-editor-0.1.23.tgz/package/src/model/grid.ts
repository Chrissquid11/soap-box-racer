/**
 * The Model tab's ground (Docs/modeler.md M11; Vibe3D D78, D79): real metres,
 * at a scale chosen to suit the model (`gridScale`, `views.ts`), heavy lines
 * every major square and light ones between, X red and Z blue through the
 * origin.
 *
 * - **Built, not helped**: each line belongs to one tier -- the minors skip
 *   the majors' places, both skip the axes -- so no two lie on each other and
 *   fight for the depth buffer as two `GridHelper`s would.
 * - **Only what changed is built again**: a rebuild at the same scale, the
 *   common case, costs nothing.
 * - **Drawn over the model's foot, never into it**: depth-tested, writing no
 *   depth, so a model standing on it hides it and it hides nothing.
 */
import * as THREE from 'three';
import { gridScale, PER_MAJOR, type GridScale } from './views.ts';

/** The tiers' colours: quiet against the stage's dark, the axes as the cube has X and Z. */
const MINOR = 0x3a4150;
const MAJOR = 0x5b6475;
const X_AXIS = 0xb4514a;
const Z_AXIS = 0x4a73b4;

export class Grid {
  readonly group = new THREE.Group();
  scale: GridScale = gridScale(0);
  private built = '';

  constructor() {
    this.group.name = 'model: grid';
    this.build();
  }

  /** Centre to corner: how far the far plane must reach to see it all (D78). */
  get reach(): number {
    return (Math.SQRT2 * this.scale.size) / 2;
  }

  /** The ground for a model reaching `reach` metres from the origin: true if its scale changed. */
  fit(reach: number): boolean {
    const next = gridScale(reach);
    if (next.major === this.scale.major && next.size === this.scale.size) return false;
    this.scale = next;
    this.build();
    return true;
  }

  private build(): void {
    const { minor, size } = this.scale;
    const key = `${minor}:${size}`;
    if (key === this.built) return;
    this.built = key;
    this.free();
    const half = size / 2;
    const majors: number[] = [];
    const minors: number[] = [];
    // In whole minor steps, so a major lands on its multiple exactly, not within a tolerance of it.
    const steps = Math.round(half / minor);
    for (let i = -steps; i <= steps; i++) {
      if (i === 0) continue;
      (i % PER_MAJOR === 0 ? majors : minors).push(i * minor);
    }
    this.group.add(lines(majors, half, MAJOR, 0.55), lines(minors, half, MINOR, 0.4));
    this.group.add(segments(Float32Array.of(-half, 0, 0, half, 0, 0), X_AXIS, 0.9), segments(Float32Array.of(0, 0, -half, 0, 0, half), Z_AXIS, 0.9));
  }

  private free(): void {
    for (const child of [...this.group.children]) {
      const line = child as THREE.LineSegments;
      line.geometry.dispose();
      (line.material as THREE.Material).dispose();
      this.group.remove(child);
    }
  }

  dispose(): void {
    this.free();
    this.built = '';
  }
}

/** One tier: a line each way at each offset. */
function lines(offsets: readonly number[], half: number, colour: number, opacity: number): THREE.LineSegments {
  const positions = new Float32Array(offsets.length * 12);
  let i = 0;
  for (const at of offsets) {
    positions.set([-half, 0, at, half, 0, at, at, 0, -half, at, 0, half], i);
    i += 12;
  }
  return segments(positions, colour, opacity);
}

function segments(positions: Float32Array, colour: number, opacity: number): THREE.LineSegments {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const material = new THREE.LineBasicMaterial({ color: colour, transparent: true, opacity, depthWrite: false });
  const line = new THREE.LineSegments(geometry, material);
  // The model's surfaces first: the ground under them is hidden where they stand.
  line.renderOrder = -1;
  line.raycast = () => {};
  return line;
}
