/**
 * A posed bone written back into the `action{}` that keys it (Docs/modeler.md
 * M33; Vibe3D D121, D122, its `poseKeys.ts` ported onto `lua-table.ts`'s
 * offset edits). The views hold any pose; the script is what the next build
 * reads, so a bone turned at a held frame is an edit only once it is a key in
 * the Lua: this finds the action by its name, its `keys` list, the key at the
 * held time -- or where a new one goes, in time order -- and merges the
 * joint's fields into its `pose`.
 *
 * - **In the vocabulary the key already uses.** Gladius spells a joint's
 *   rotation three ways and refuses them mixed (GLD-6050): `forward`/`left`/
 *   `twist` (what a person writes), `rotate` (world degrees), `orient` (axis
 *   times degrees in the joint's frame). Every spelling is handed in; the joint
 *   in the key decides. A joint the key does not name yet gets the readable
 *   trio -- or `orient` where its bone points along a swing's axis, which
 *   Gladius refuses (`degenerate`).
 * - **Joint names as the script spells them**: a key naming `Hips` matches a
 *   rig's `mixamorig:Hips` (Gladius resolves an action's joints by suffix).
 * - **Literals only.** A key whose pose is an expression -- the parrot's
 *   `pose = flight(60, 0.012, 5)` -- is refused by name, never rewritten: a new
 *   key between keys is still offered, and a joint left out of a key is
 *   interpolated from the keys either side (checked against Gladius 0.7.3 and
 *   0.8.0: the other joints' tracks are unchanged).
 * - **Laid out as its neighbours**: `time=0.2` or `time = 0.2` as the key
 *   beside it is spaced, `frame = n` where every key is by frame, a key a line
 *   where they are a line each.
 *
 * Pure (`pose-keys.test.ts`): text in, text out.
 */
import { additions, applyEdits, fieldTable, findCalls, numberLiteral, rangeAt, readTable, replaceValue, skippedRanges, stringLiteral, type Edit, type Entry, type Field, type LuaTable } from './lua-table.ts';

/** Two keys closer than this, in seconds, are the same key: a written time is kept to three places. */
export const SAME_TIME = 1e-3;

/** What Gladius assumes when an action does not say. */
const DEFAULT_FPS = 30;

/** The fields that spell a rotation: one spelling a joint. */
const ROTATION_FIELDS = ['forward', 'left', 'twist', 'rotate', 'orient'] as const;

/** One joint's new pose in every spelling Gladius takes; the key that gets it chooses. */
export interface JointEdit {
  rotation?: {
    forward: number;
    left: number;
    twist: number;
    /** Axis times degrees, in the joint's rest frame. */
    orient: [number, number, number];
    /** World X, Y, Z degrees. */
    rotate: [number, number, number];
    /** Swing axes this bone points along: `forward` or `left` there is refused, so a new joint is written as `orient`. */
    degenerate?: readonly ('forward' | 'left')[];
  };
  /** Metres in world axes, added to the joint's rest position. */
  translate?: [number, number, number];
}

export interface PoseWrite {
  /** The action's name: its clip. */
  clip: string;
  /** Seconds: the time held. */
  time: number;
  /** By the joint's name as the script should spell it. */
  joints: Record<string, JointEdit>;
  /**
   * The readable trio alone (`forward`, `left`, `twist`): a turn of a joint the key spells with `rotate` or `orient` is
   * refused before anything is edited -- those need the bone's own frame, which a caller with no gizmo (the studio's
   * `model_pose`) does not have; its `orient` and `rotate` are then never read.
   */
  trioOnly?: boolean;
}

export interface ScriptKey {
  /** Seconds: `time`, or `frame` at the action's rate. */
  time: number;
  /** A `rest = true` key: no joint is posed in it. */
  rest: boolean;
  /** The joints it names, as the script spells them. */
  joints: string[];
  /** False when its pose is an expression, not a table written here. */
  editable: boolean;
  /** That expression, shortened, to say why. */
  poseSource?: string;
}

export interface ScriptAction {
  name: string;
  fps: number;
  keys: ScriptKey[];
  /** Why no key of it can be edited, when that is so. */
  problem?: string;
}

interface ActionCall extends LuaTable {
  name: string;
  fps: number;
}

type Skip = ReadonlyArray<readonly [number, number]>;

const format = (value: number): string => {
  const n = Number(value.toFixed(3));
  return String(Object.is(n, -0) ? 0 : n);
};
const vec = (v: readonly [number, number, number]): string => `v3(${v.map(format).join(', ')})`;

function expression(text: string, field: Field): string {
  const source = text.slice(field.valueStart, field.valueEnd).trim().replace(/\s+/g, ' ');
  return source.length > 40 ? `${source.slice(0, 37)}…` : source;
}

function actionCalls(text: string, skip: Skip): ActionCall[] {
  const calls: ActionCall[] = [];
  for (const call of findCalls(text, 'action', skip)) {
    const nameField = call.fields.find((f) => f.key === 'name');
    const name = nameField && stringLiteral(text.slice(nameField.valueStart, nameField.valueEnd));
    if (name === undefined) continue;
    const fpsField = call.fields.find((f) => f.key === 'fps');
    const fps = (fpsField && numberLiteral(text.slice(fpsField.valueStart, fpsField.valueEnd))) || DEFAULT_FPS;
    calls.push({ ...call, name, fps });
  }
  return calls;
}

/** A key's time in seconds: `time`, or `frame` at the action's rate. */
function keyTime(text: string, table: LuaTable, fps: number): number | undefined {
  const timeField = table.fields.find((f) => f.key === 'time');
  if (timeField) return numberLiteral(text.slice(timeField.valueStart, timeField.valueEnd));
  const frameField = table.fields.find((f) => f.key === 'frame');
  const frame = frameField && numberLiteral(text.slice(frameField.valueStart, frameField.valueEnd));
  return frame === undefined ? undefined : frame / fps;
}

/** A list's entry without the comments before it -- `-- the top` on the line before a key is no part of it. */
function entryOf(text: string, entry: Entry, skip: Skip): Entry {
  let start = entry.start;
  for (;;) {
    while (start < entry.end && /\s/.test(text[start]!)) start++;
    const range = rangeAt(skip, start);
    if (!range || text[range[0]] !== '-' || range[1] >= entry.end) break;
    start = range[1];
  }
  return { ...entry, start };
}

/** One `{ time = …, pose = … }`, as far as the source says. */
function readKey(text: string, start: number, fps: number, skip: Skip): ScriptKey | undefined {
  if (text[start] !== '{') return undefined;
  const table = readTable(text, start, skip);
  if (!table) return undefined;
  const time = keyTime(text, table, fps);
  if (time === undefined) return undefined;
  const restField = table.fields.find((f) => f.key === 'rest');
  const poseField = table.fields.find((f) => f.key === 'pose');
  const pose = poseField && fieldTable(text, poseField, skip);
  return {
    time,
    rest: restField ? text.slice(restField.valueStart, restField.valueEnd).trim() === 'true' : false,
    joints: pose ? pose.fields.map((f) => f.key) : [],
    editable: poseField === undefined || pose !== undefined,
    ...(poseField && !pose ? { poseSource: expression(text, poseField) } : {}),
  };
}

/**
 * Every `action{}` with a literal name, and its keys: what the panel may offer.
 * A clip not here has no keys in the script -- an imported one, or a name
 * worked out at run time.
 */
export function declaredActions(text: string): ScriptAction[] {
  const skip = skippedRanges(text);
  const out: ScriptAction[] = [];
  for (const call of actionCalls(text, skip)) {
    const keysField = call.fields.find((f) => f.key === 'keys');
    if (!keysField) {
      out.push({ name: call.name, fps: call.fps, keys: [], problem: 'it has no keys list' });
      continue;
    }
    const list = fieldTable(text, keysField, skip);
    if (!list) {
      out.push({ name: call.name, fps: call.fps, keys: [], problem: `its keys are ${expression(text, keysField)}, not a list written here` });
      continue;
    }
    const keys: ScriptKey[] = [];
    for (const each of list.entries) {
      const key = readKey(text, entryOf(text, each, skip).start, call.fps, skip);
      if (key) keys.push(key);
    }
    out.push({ name: call.name, fps: call.fps, keys });
  }
  return out;
}

/** The key of `action` at `time`, if one is within `SAME_TIME`. */
export const keyAt = (action: ScriptAction | undefined, time: number): ScriptKey | undefined => action?.keys.find((k) => Math.abs(k.time - time) <= SAME_TIME);

/** A joint matches a key's by name, or by the part after a rig's prefix -- as Gladius resolves them. */
export function sameJoint(inScript: string, joint: string): boolean {
  if (inScript === joint) return true;
  const tail = (name: string): string => name.slice(name.lastIndexOf(':') + 1);
  return tail(inScript) === tail(joint);
}

/** `Hips = …`, or `["mixamorig:Hips"] = …` for a name that is no identifier. */
const luaKey = (joint: string): string => (/^[A-Za-z_]\w*$/.test(joint) ? joint : `["${joint.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"]`);

/**
 * One joint's fields in the spelling the key already uses (`present`: the
 * fields its table has; none, a joint being added -- the readable trio, or
 * `orient` where a swing it needs is degenerate).
 */
export function jointFields(edit: JointEdit, present: readonly string[]): [string, string][] {
  const out: [string, string][] = [];
  if (edit.rotation) {
    const { forward, left, twist, orient, rotate, degenerate = [] } = edit.rotation;
    const refused = (degenerate.includes('forward') && Math.abs(forward) >= 0.01) || (degenerate.includes('left') && Math.abs(left) >= 0.01);
    const spelled = present.some((p) => (ROTATION_FIELDS as readonly string[]).includes(p));
    if (present.includes('orient') || (!spelled && refused)) out.push(['orient', vec(orient)]);
    else if (present.includes('rotate')) out.push(['rotate', vec(rotate)]);
    else {
      // Swing and twist: each written when it is not zero, or there already and to be put to zero.
      for (const [name, value] of [['forward', forward], ['left', left], ['twist', twist]] as const) {
        if (Math.abs(value) >= 0.01 || present.includes(name)) out.push([name, format(value)]);
      }
    }
  }
  if (edit.translate) {
    const zero = edit.translate.every((n) => Math.abs(n) < 1e-5);
    if (!zero || present.includes('translate')) out.push(['translate', vec(edit.translate)]);
  }
  // A joint keyed at rest is a key all the same -- but `Joint = {}` is refused by Gladius (GLD-6050: "no rotate,
  // forward, left, twist, translate or scale"): one field says it, `twist = 0`, the one swing no bone is refused.
  if (out.length === 0) out.push(edit.rotation || !edit.translate ? ['twist', '0'] : ['translate', vec(edit.translate)]);
  return out;
}

/** `key = value` or `key=value`, as `spaced` says. */
const pairOf = (spaced: boolean, key: string, literal: string): string => (spaced ? `${key} = ${literal}` : `${key}=${literal}`);

/** A joint's whole table, for a joint the key does not name yet. */
function jointTable(edit: JointEdit, spaced: boolean): string {
  const fields = jointFields(edit, []);
  const inner = fields.map(([n, l]) => pairOf(spaced, n, l)).join(', ');
  return spaced ? `{ ${inner} }` : `{${inner}}`;
}

/** The pose table's body for these joints. */
function poseBody(write: PoseWrite, spaced: boolean): string {
  const inner = Object.entries(write.joints).map(([joint, edit]) => pairOf(spaced, luaKey(joint), jointTable(edit, spaced))).join(', ');
  return spaced ? `{ ${inner} }` : `{${inner}}`;
}

/** Is `key = value` spaced in this text: the first `name = ` or `name=` in it says; else yes. */
const spacedIn = (source: string): boolean => {
  const m = /[A-Za-z_\]]\s*=\s*[^=]/.exec(source);
  return m ? /\s=|=\s/.test(m[0]) : true;
};

const lineStart = (text: string, at: number): number => text.lastIndexOf('\n', at - 1) + 1;
const lineEnd = (text: string, at: number): number => {
  const n = text.indexOf('\n', at);
  return n < 0 ? text.length : n;
};
const indentOf = (text: string, at: number): string => /^[ \t]*/.exec(text.slice(lineStart(text, at)))![0];

export type PoseResult = { text: string; note: string } | { problem: string };

/** The script with `write`'s joints in the clip's key at its time -- the key made if there is none -- or why not. */
export function poseEdit(text: string, write: PoseWrite): PoseResult {
  const skip = skippedRanges(text);
  const call = actionCalls(text, skip).find((c) => c.name === write.clip);
  if (!call) {
    return { problem: `the script has no action{name="${write.clip}"}: an imported clip keeps its keys in the file it came from, so there is no key here to write -- it would need converting into an action{} first` };
  }
  const keysField = call.fields.find((f) => f.key === 'keys');
  const list = keysField && fieldTable(text, keysField, skip);
  if (!list) return { problem: `"${write.clip}" has no keys list written in the script to edit` };
  if (Object.keys(write.joints).length === 0) return { problem: 'nothing is posed: turn a bone first' };

  const entries = list.entries.map((each) => entryOf(text, each, skip)).map((entry) => ({ entry, key: readKey(text, entry.start, call.fps, skip) }));
  const hit = entries.find(({ key }) => key !== undefined && Math.abs(key.time - write.time) <= SAME_TIME);
  if (!hit || !hit.key) return insertKey(text, call, list, entries, write);
  if (hit.key.rest) return { problem: `the key at ${format(write.time)} s is a rest key -- "back to the rest pose" -- so no joint is posed in it: pose at another frame, or take rest = true out of it` };
  if (!hit.key.editable) return { problem: `the key at ${format(write.time)} s has a computed pose (${hit.key.poseSource ?? 'not a table'}): writing over it would throw away what the script means -- pose a frame between keys, or edit that call` };
  return mergeIntoKey(text, hit.entry.start, write, skip);
}

/** The joints merged into a key that is there: a joint it names has fields replaced or added, one it does not a table. */
function mergeIntoKey(text: string, keyStart: number, write: PoseWrite, skip: Skip): PoseResult {
  const key = readTable(text, keyStart, skip)!;
  const spaced = spacedIn(text.slice(key.open, key.close));
  const poseField = key.fields.find((f) => f.key === 'pose');
  const at = format(write.time);
  if (!poseField) {
    // A key with no pose at all -- `{ time = 0.4 }` -- gets one.
    const edits = additions(text, key, key.fields, [pairOf(spaced, 'pose', poseBody(write, spaced))]);
    return { text: applyEdits(text, edits), note: `keyed at ${at} s` };
  }
  const pose = fieldTable(text, poseField, skip);
  if (!pose) return { problem: `that key's pose is ${expression(text, poseField)}, not a table written here` };
  const edits: Edit[] = [];
  const added: string[] = [];
  const notes: string[] = [];
  for (const [joint, edit] of Object.entries(write.joints)) {
    const existing = pose.fields.find((f) => sameJoint(f.key, joint));
    if (!existing) {
      added.push(pairOf(spaced, luaKey(joint), jointTable(edit, spaced)));
      continue;
    }
    const table = fieldTable(text, existing, skip);
    if (!table) return { problem: `${existing.key}'s pose in that key is ${expression(text, existing)}, not a table` };
    const present = table.fields.map((f) => f.key);
    const spelling = present.find((p) => p === 'rotate' || p === 'orient');
    if (write.trioOnly && edit.rotation && spelling) {
      return { problem: `that key spells ${existing.key} with rotate or orient (${spelling} here), which needs the bone's own frame: pose it in the Model tab (its gizmo, then K), or edit the key in the script` };
    }
    const wanted = jointFields(edit, present);
    const fresh: string[] = [];
    const jointSpaced = table.fields.length > 0 ? spacedIn(text.slice(table.open, table.close)) : spaced;
    for (const [name, literal] of wanted) {
      const field = table.fields.find((f) => f.key === name);
      if (field) edits.push(replaceValue(field, literal));
      else fresh.push(pairOf(jointSpaced, name, literal));
    }
    edits.push(...additions(text, table, table.fields, fresh));
    // Said where the key is not in the readable spelling: the numbers written are not the ones in the fields.
    const kept = wanted.find(([n]) => n === 'rotate' || n === 'orient');
    if (edit.rotation && kept && present.includes(kept[0])) notes.push(`${existing.key} keeps its ${kept[0]} spelling`);
  }
  edits.push(...additions(text, pose, pose.fields, added));
  return { text: applyEdits(text, edits), note: [`the key at ${at} s changed`, ...notes].join('; ') };
}

/** A key the clip does not have, put in time order: laid out as its siblings, after the key before it. */
function insertKey(text: string, call: ActionCall, list: LuaTable, entries: { entry: { start: number; end: number; sepEnd: number }; key: ScriptKey | undefined }[], write: PoseWrite): PoseResult {
  const first = entries[0]?.entry;
  const spaced = first ? spacedIn(text.slice(first.start, first.end)) : true;
  const byFrame = entries.length > 0 && entries.every(({ entry }) => /^\{\s*frame\s*=/.test(text.slice(entry.start, entry.start + 40)));
  const when = byFrame ? pairOf(spaced, 'frame', String(Math.round(write.time * call.fps))) : pairOf(spaced, 'time', format(write.time));
  const body = `${when}, ${pairOf(spaced, 'pose', poseBody(write, spaced))}`;
  const entry = spaced ? `{ ${body} }` : `{${body}}`;
  const note = `a new key at ${format(write.time)} s`;
  if (entries.length === 0) return { text: applyEdits(text, [{ from: list.open + 1, to: list.open + 1, text: ` ${entry}, ` }]), note };
  // After the last key before this time, or before the first key after it.
  let previous = -1;
  entries.forEach(({ key }, i) => {
    if (key && key.time < write.time) previous = i;
  });
  const multiline = text.slice(list.open, list.close).includes('\n');
  if (previous < 0) {
    const where = entries[0]!.entry.start;
    return { text: applyEdits(text, [{ from: where, to: where, text: multiline ? `${entry},\n${indentOf(text, where)}` : `${entry}, ` }]), note };
  }
  const after = entries[previous]!.entry;
  // The key before it gets its comma if it is the last and has none.
  const comma = after.sepEnd === after.end ? ',' : '';
  let where = after.sepEnd;
  let added = ` ${entry},`;
  if (multiline) {
    // On a line of its own after the key before it: at that line's end (past a comment), or just after it where the list closes on its line.
    const end = lineEnd(text, after.sepEnd);
    where = list.close < end ? after.sepEnd : end;
    added = `\n${indentOf(text, after.start)}${entry},`;
  }
  const edits: Edit[] = where === after.end ? [{ from: where, to: where, text: `${comma}${added}` }] : [...(comma ? [{ from: after.end, to: after.end, text: comma }] : []), { from: where, to: where, text: added }];
  return { text: applyEdits(text, edits), note };
}
