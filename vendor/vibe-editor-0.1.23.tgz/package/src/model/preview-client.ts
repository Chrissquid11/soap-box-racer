/**
 * The Model tab's side of a preview build (Docs/modeler.md M22; Vibe3D D47):
 * a parameter being dragged built -- `POST preview` -- and shown, one at a
 * time, the newest value always the next.
 *
 * - **One in flight, latest wins**: an ask while one is out waits as the one
 *   pending, and a later ask takes its place -- a slider makes far more
 *   values than any build rate, and every one but the newest is stale before
 *   a slot frees. The decode is part of the flight: the next build is not
 *   asked for until the one before is on screen, so the model never steps
 *   backwards while the slider goes forwards.
 * - **A failure is quiet** (D47): its line said (`failed`), the last good
 *   preview kept on screen; a value merely passed over on the way must not
 *   fill the screen with errors. `superseded` -- another tab's ask replaced
 *   this one on the server -- is nothing at all.
 * - **`stop`** lets go of whatever is out and pending (a drag let go, the
 *   model closed, the export landed): an answer that comes after is dropped,
 *   never shown -- one still decoding as well (`show`'s `still`).
 *
 * Handed its build and its show (`preview-client.test.ts`); no DOM, no three.
 */
import type { PreviewFailure } from '@vibe/pipeline/assets-types';

export interface PreviewAsk {
  path: string;
  params: Readonly<Record<string, string>>;
}

export interface PreviewClientHost {
  build(ask: PreviewAsk): Promise<{ ok: true; bytes: Uint8Array; ms: number } | PreviewFailure>;
  /**
   * A preview built: decoded and shown before the next is asked for. False: the decode failed (said by the host).
   * `still()`, asked again after the decode: false once a `stop` came meanwhile -- the export that stopped it is
   * shown now, and the preview is dropped, not shown over it.
   */
  show(ask: PreviewAsk, bytes: Uint8Array, ms: number, still: () => boolean): Promise<boolean>;
  /** A preview that did not build: its line -- the last good one stays. */
  failed(ask: PreviewAsk, error: string, failure: PreviewFailure): void;
  /** Building or not changed: a quiet "building…" while it is. */
  busy(busy: boolean): void;
}

export interface PreviewClient {
  /** `ask` built and shown, after what is out -- in place of whatever was waiting. */
  ask(ask: PreviewAsk): void;
  /** What is out and pending let go: nothing more shown. */
  stop(): void;
  readonly busy: boolean;
  /** Resolves once nothing is out or pending. */
  idle(): Promise<void>;
}

export function createPreviewClient(host: PreviewClientHost): PreviewClient {
  let out = false;
  let pending: PreviewAsk | null = null;
  /** Bumped by `stop`: an answer for an ask before it is dropped. */
  let ticket = 0;
  let waiters: Array<() => void> = [];
  /** The ticket the flight out was asked under: one before a `stop` is nobody's any more. */
  let flying = 0;

  const settle = (): void => {
    if (out || pending) return;
    host.busy(false);
    const w = waiters;
    waiters = [];
    for (const fn of w) fn();
  };

  async function fly(ask: PreviewAsk): Promise<void> {
    out = true;
    const mine = ticket;
    flying = mine;
    try {
      const got = await host.build(ask);
      if (mine !== ticket) return;
      if (got.ok) await host.show(ask, got.bytes, got.ms, () => mine === ticket);
      else if (!got.superseded) host.failed(ask, got.error ?? 'the preview did not build', got);
    } catch (err) {
      if (mine === ticket) host.failed(ask, (err as Error).message, { ok: false, ms: 0, diagnostics: [], error: (err as Error).message });
    } finally {
      out = false;
      const next = pending;
      pending = null;
      // Pending is always newer than any `stop`, which clears it.
      if (next) void fly(next);
      else settle();
    }
  }

  return {
    ask(next) {
      if (out) {
        if (flying !== ticket && pending === null) host.busy(true);
        pending = next;
        return;
      }
      host.busy(true);
      void fly(next);
    },
    stop() {
      ticket++;
      pending = null;
      if (!out) settle();
      else host.busy(false);
    },
    get busy() {
      return (out && flying === ticket) || pending !== null;
    },
    idle() {
      if (!out && !pending) return Promise.resolve();
      return new Promise((resolve) => waiters.push(resolve));
    },
  };
}
