/**
 * Weight maps (Docs/modeler.md M32; Vibe3D D91): bones selected draw every
 * skinned mesh they deform again, coloured by the sum of their weights on
 * Blender's ramp -- dark blue at 0 through cyan, green and yellow to red at 1
 * -- with how many vertices they move at all, the question the faint blue edge
 * of a falloff leaves to squinting.
 *
 * - **Read in the shader** from `skinIndex` and `skinWeight` against a uniform
 *   list of bone indices: another bone is a uniform, not a pass over the
 *   vertices. Up to 16 bones are summed -- a run down a limb.
 * - **Skinned like the mesh**, bound to its skeleton, so the map stays on the
 *   wing while fly plays (M31); one map a mesh, since bone indices are a
 *   skeleton's.
 * - **Drawn over the surface** (a polygon offset), placed where its mesh is
 *   before each frame and shown only while it is; in a group of its own, which
 *   a canvas's backdrop leaves out, as it does the outline (D29).
 * - **The count** (`weightCount`) from the same attributes, pure: a vertex is
 *   moved when the selected bones' weights on it sum past 1e-4.
 */
import * as THREE from 'three';

/** The most bones a map sums. */
export const MAX_WEIGHT_BONES = 16;

/** Blender's ramp as CSS, for the key beside the count. */
export const RAMP_CSS = 'linear-gradient(90deg, rgb(0,0,115) 0%, rgb(0,191,255) 25%, rgb(26,230,51) 50%, rgb(255,230,0) 75%, rgb(255,26,13) 100%)';

/**
 * How many vertices the bones at these indices move: any weight past 1e-4 summed over the four influences.
 * Given the positions, counted by place -- the copies a GLB stores at a seam or a hard edge are one vertex -- so the
 * totals are the stats' (M12): `Weights 99 / 1,044` under `Vertices 1,044`, not the stored 1,132.
 */
export function weightCount(skinIndex: ArrayLike<number>, skinWeight: ArrayLike<number>, itemSize: number, bones: ReadonlySet<number>, positions?: ArrayLike<number>): { influenced: number; vertices: number } {
  const stored = Math.floor(skinIndex.length / itemSize);
  const moved = (v: number): boolean => {
    let weight = 0;
    for (let k = 0; k < itemSize; k++) if (bones.has(skinIndex[v * itemSize + k]!)) weight += skinWeight[v * itemSize + k]!;
    return weight > 1e-4;
  };
  if (!positions) {
    let influenced = 0;
    for (let v = 0; v < stored; v++) if (moved(v)) influenced++;
    return { influenced, vertices: stored };
  }
  // By place, to a hundredth of a millimetre: a place is moved if any copy at it is.
  const places = new Map<string, boolean>();
  for (let v = 0; v < stored; v++) {
    const key = `${Math.round(positions[v * 3]! * 1e5)},${Math.round(positions[v * 3 + 1]! * 1e5)},${Math.round(positions[v * 3 + 2]! * 1e5)}`;
    places.set(key, (places.get(key) ?? false) || moved(v));
  }
  let influenced = 0;
  for (const m of places.values()) if (m) influenced++;
  return { influenced, vertices: places.size };
}

/** `moves 412 of 518 vertices`. */
export function weightWords(w: { influenced: number; vertices: number }): string {
  const n = (x: number): string => x.toLocaleString('en');
  return `moves ${n(w.influenced)} of ${n(w.vertices)} ${w.vertices === 1 ? 'vertex' : 'vertices'}`;
}

const VERTEX = /* glsl */ `
  uniform float bones[${MAX_WEIGHT_BONES}];
  uniform int boneCount;
  varying float vWeight;
  varying float vShade;
  #include <common>
  #include <skinning_pars_vertex>
  void main() {
    #include <skinbase_vertex>
    #include <beginnormal_vertex>
    #include <skinnormal_vertex>
    #include <begin_vertex>
    #include <skinning_vertex>
    float weight = 0.0;
    #ifdef USE_SKINNING
      for (int i = 0; i < 4; i++) {
        for (int j = 0; j < ${MAX_WEIGHT_BONES}; j++) {
          if (j >= boneCount) break;
          if (abs(skinIndex[i] - bones[j]) < 0.5) weight += skinWeight[i];
        }
      }
    #endif
    vWeight = clamp(weight, 0.0, 1.0);
    // A little facing-ratio shading, or the map is a flat poster and the shape it is on disappears under it.
    vShade = 0.62 + 0.38 * abs(normalize(normalMatrix * objectNormal).z);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(transformed, 1.0);
  }
`;

const FRAGMENT = /* glsl */ `
  varying float vWeight;
  varying float vShade;
  void main() {
    float t = vWeight;
    vec3 c = t < 0.25 ? mix(vec3(0.0, 0.0, 0.45), vec3(0.0, 0.75, 1.0), t / 0.25)
           : t < 0.5  ? mix(vec3(0.0, 0.75, 1.0), vec3(0.1, 0.9, 0.2), (t - 0.25) / 0.25)
           : t < 0.75 ? mix(vec3(0.1, 0.9, 0.2), vec3(1.0, 0.9, 0.0), (t - 0.5) / 0.25)
           :            mix(vec3(1.0, 0.9, 0.0), vec3(1.0, 0.1, 0.05), (t - 0.75) / 0.25);
    gl_FragColor = vec4(c * vShade, 1.0);
  }
`;

/** What a weight map on screen covers: the bones' names, the vertices moved and in all. */
export interface WeightFacts {
  bones: string[];
  influenced: number;
  vertices: number;
}

export class WeightMaps {
  /** In the scene: a map a skinned mesh the selected bones deform. */
  readonly group = new THREE.Group();
  private maps: { overlay: THREE.SkinnedMesh; mesh: THREE.SkinnedMesh; material: THREE.ShaderMaterial }[] = [];

  constructor() {
    this.group.name = 'model: weight maps';
  }

  /** The maps of these bones on the meshes given: their facts, or null for no bone. */
  set(meshes: readonly THREE.SkinnedMesh[], bones: readonly THREE.Bone[], names: readonly string[]): WeightFacts | null {
    this.clear();
    if (bones.length === 0) return null;
    let influenced = 0;
    let vertices = 0;
    for (const mesh of meshes) {
      const indices = bones.map((bone) => mesh.skeleton.bones.indexOf(bone)).filter((i) => i >= 0).slice(0, MAX_WEIGHT_BONES);
      if (indices.length === 0) continue;
      const material = new THREE.ShaderMaterial({
        uniforms: {
          bones: { value: [...indices, ...Array<number>(MAX_WEIGHT_BONES - indices.length).fill(-1)] },
          boneCount: { value: indices.length },
        },
        vertexShader: VERTEX,
        fragmentShader: FRAGMENT,
        // Pulled toward the camera so it covers the surface it shares; the outline still shows past its edge.
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -4,
      });
      const overlay = new THREE.SkinnedMesh(mesh.geometry, material);
      overlay.name = 'model: weights';
      overlay.bind(mesh.skeleton, mesh.bindMatrix);
      overlay.frustumCulled = false;
      overlay.raycast = () => {};
      overlay.matrixAutoUpdate = false;
      overlay.renderOrder = 3;
      this.group.add(overlay);
      this.maps.push({ overlay, mesh, material });
      const skinIndex = mesh.geometry.getAttribute('skinIndex');
      const skinWeight = mesh.geometry.getAttribute('skinWeight');
      if (skinIndex && skinWeight) {
        const position = mesh.geometry.getAttribute('position');
        const c = weightCount(skinIndex.array as ArrayLike<number>, skinWeight.array as ArrayLike<number>, skinIndex.itemSize, new Set(indices), position && !(position as THREE.InterleavedBufferAttribute).isInterleavedBufferAttribute && position.itemSize === 3 ? (position.array as ArrayLike<number>) : undefined);
        influenced += c.influenced;
        vertices += c.vertices;
      }
    }
    return { bones: [...names], influenced, vertices };
  }

  /** Before a frame: each map where its mesh is, shown only while that mesh is drawn. */
  place(): void {
    for (const { overlay, mesh } of this.maps) {
      let seen = true;
      for (let o: THREE.Object3D | null = mesh; o && seen; o = o.parent) seen = o.visible;
      overlay.visible = seen;
      if (!seen) continue;
      mesh.updateWorldMatrix(true, false);
      overlay.matrix.copy(mesh.matrixWorld);
      overlay.matrixWorld.copy(mesh.matrixWorld);
      overlay.bindMatrixInverse.copy(mesh.bindMatrixInverse);
    }
  }

  clear(): void {
    for (const { overlay, material } of this.maps) {
      this.group.remove(overlay);
      material.dispose();
    }
    this.maps = [];
  }

  dispose(): void {
    this.clear();
  }
}
