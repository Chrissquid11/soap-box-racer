/**
 * A bone posed by hand at a held frame (Docs/modeler.md M33; Vibe3D D121's
 * `posing.ts`): the gizmo on the bone, or numbers typed; the pose held over
 * the clip until it is a key in the script (`pose-keys.ts`).
 *
 * - **An edit over the mixer, not instead of it**: the clip still poses every
 *   bone each time it is applied; the bones edited are then set again from
 *   what the person did (`applyHeld`). The rest of the body plays on, and
 *   Reset is a deletion, not a sum.
 * - **The pose belongs to its frame**: another frame or clip drops it, said --
 *   a turn at 0.2 s means nothing at 0.4 s, and carried along it would be
 *   written as a key nobody looked at.
 * - **The gizmo is three's `TransformControls`**, in whichever view the pointer
 *   is over (its `viewport` and camera set per view: the views are scissored
 *   out of one canvas), sized for each view as it is drawn; it takes a press
 *   on a handle before the stage does (`grabbing`). Rotate, or Move; Gladius
 *   bones have no scale.
 * - **Carried across a rebuild by name** -- unless the rebuild is the key just
 *   written arriving, which has the pose in it now.
 */
import * as THREE from 'three';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { altThrough } from '../view/alt-through.ts';
import { samePose, type PoseRef } from './clips.ts';
import type { JointEdit } from './pose-keys.ts';
import { describe, fromNumbers, jointName, type PoseNumbers, type Rest } from './pose-math.ts';

export type PoseMode = 'rotate' | 'translate';

export interface PoserHost {
  /** The bone as the script builds it: what the numbers are measured from. */
  restOf(bone: THREE.Bone): Rest | undefined;
  /** Every bone's name as the file has it: a joint's short name is checked against them. */
  names(): string[];
  /** The gizmo pressed or let go: true as a drag begins. */
  dragging(active: boolean): void;
  /** Bones moved by an edit: bounds, overlays, a frame. */
  posed(): void;
  /** The gizmo changed how it looks (a handle hovered): a frame. */
  redraw(): void;
  /** The numbers changed: the panel reads them again. */
  changed(): void;
}

/** What a bone's pose comes to, for the panel: its joint as the script spells it, its numbers, whether it is held. */
export interface Readout extends PoseNumbers {
  joint: string;
  /** Edited here and not written yet. */
  held: boolean;
}

const fileName = (bone: THREE.Object3D): string => (typeof bone.userData.name === 'string' && bone.userData.name !== '' ? bone.userData.name : bone.name);

export class Poser {
  private readonly controls: TransformControls;
  private readonly undoAlt: () => void;
  readonly helper: THREE.Object3D;
  private target: THREE.Bone | null = null;
  /** Every bone this frame's edit has touched, by bone: its local transform to force after the mixer. */
  private readonly held = new Map<THREE.Bone, { quaternion: THREE.Quaternion; position: THREE.Vector3 }>();
  private frame: PoseRef | null = null;
  private mode: PoseMode = 'rotate';
  private available = false;
  private readonly host: PoserHost;

  constructor(scene: THREE.Object3D, element: HTMLElement, host: PoserHost) {
    this.host = host;
    this.controls = new TransformControls(new THREE.PerspectiveCamera(), element);
    this.controls.setSpace('local');
    this.controls.setMode('rotate');
    this.controls.size = 0.8;
    this.controls.enabled = false;
    // Alt+left under Emulate 3 Button Mouse orbits, over a handle too (Docs/navigation.md §2): the gizmo stands aside.
    this.undoAlt = altThrough(element, this.controls);
    this.helper = this.controls.getHelper();
    this.helper.name = 'model: pose gizmo';
    this.helper.visible = false;
    scene.add(this.helper);
    this.controls.addEventListener('dragging-changed', (event) => host.dragging(Boolean((event as unknown as { value: boolean }).value)));
    // A handle hovered lights, as the Scene tab's gizmo does: three says `change`, and the stage draws on demand.
    this.controls.addEventListener('change', () => host.redraw());
    this.controls.addEventListener('objectChange', () => {
      this.record();
      host.posed();
      host.changed();
    });
  }

  /** The view the gizmo reads the pointer in, and is drawn for: its camera and its rectangle (GL's, from the bottom left). */
  view(camera: THREE.Camera, x: number, y: number, width: number, height: number): void {
    if (this.controls.dragging) return;
    this.useView(camera, x, y, width, height);
  }

  /** Before a view is drawn: the gizmo sized for its camera -- and after every view, back to the pointer's (`view`). */
  drawFor(camera: THREE.Camera): void {
    this.controls.camera = camera;
  }

  private useView(camera: THREE.Camera, x: number, y: number, width: number, height: number): void {
    this.controls.camera = camera;
    this.controls.viewport = new THREE.Vector4(x, y, width, height);
  }

  /** Posing offered: a clip held, a bone chosen, the page may write. */
  setAvailable(on: boolean): void {
    this.available = on;
    this.sync();
  }

  setMode(mode: PoseMode): void {
    this.mode = mode;
    this.controls.setMode(mode);
    this.host.changed();
  }

  get currentMode(): PoseMode {
    return this.mode;
  }

  /** The bone the gizmo is on, or none. */
  attach(bone: THREE.Bone | null): void {
    this.target = bone;
    this.sync();
    this.host.changed();
  }

  get bone(): THREE.Bone | null {
    return this.target;
  }

  private sync(): void {
    const on = this.available && this.target !== null;
    if (on) this.controls.attach(this.target!);
    else this.controls.detach();
    this.controls.enabled = on;
    this.helper.visible = on;
  }

  /** The frame the edits belong to: another drops them -- true when something was dropped, to be said. */
  setFrame(frame: PoseRef | null): boolean {
    const same = samePose(this.frame, frame);
    this.frame = frame;
    if (same || this.held.size === 0) return false;
    this.held.clear();
    this.host.changed();
    return true;
  }

  get hasEdits(): boolean {
    return this.held.size > 0;
  }

  /** A press on a handle, or one under way: the stage stands aside. `axis` is set while a handle is merely hovered. */
  get grabbing(): boolean {
    return this.controls.enabled && (this.controls.dragging || this.controls.axis !== null);
  }

  get dragging(): boolean {
    return this.controls.dragging;
  }

  /** The joints edited, as the script spells them. */
  get joints(): string[] {
    return [...this.held.keys()].map((b) => this.jointName(b));
  }

  /** What the script calls this bone (D122): the file's name, short where unambiguous. */
  jointName(bone: THREE.Bone): string {
    return jointName(fileName(bone), this.host.names());
  }

  /** The edits forgotten: the clip's pose again. */
  reset(): void {
    this.held.clear();
    this.host.changed();
  }

  /** After the mixer has written the clip's pose: the edited bones set again. */
  applyHeld(): void {
    for (const [bone, held] of this.held) {
      bone.quaternion.copy(held.quaternion);
      bone.position.copy(held.position);
    }
  }

  /**
   * A model rebuilt: the edits put on its bones of the same names -- or
   * dropped (`drop`: the key just written has them now). The bone chosen goes
   * to its namesake too.
   */
  carry(bones: readonly THREE.Bone[], drop: boolean): void {
    const byName = new Map(bones.map((b) => [fileName(b), b] as const));
    const was = [...this.held];
    this.held.clear();
    if (!drop) for (const [bone, held] of was) {
      const next = byName.get(fileName(bone));
      if (next) this.held.set(next, held);
    }
    this.target = this.target ? (byName.get(fileName(this.target)) ?? null) : null;
    this.sync();
    this.host.changed();
  }

  /** The chosen bone's pose as it is on screen -- the clip's, or the edit's -- in Gladius's words; null with none, or no rest known. */
  readout(): Readout | null {
    const bone = this.target;
    const rest = bone && this.host.restOf(bone);
    if (!bone || !rest) return null;
    return { ...describe(rest, bone.quaternion, bone.position), joint: this.jointName(bone), held: this.held.has(bone) };
  }

  /** Every edited joint, every spelling, for the writer. */
  edits(): Record<string, JointEdit> {
    const out: Record<string, JointEdit> = {};
    for (const [bone, held] of this.held) {
      const rest = this.host.restOf(bone);
      if (!rest) continue;
      const d = describe(rest, held.quaternion, held.position);
      // Both, always: a field the key names is written even at zero -- a joint put back to rest is so in the key -- and
      // a zero it does not name is left out (`jointFields`).
      out[this.jointName(bone)] = {
        rotation: { forward: d.forward, left: d.left, twist: d.twist, orient: d.orient, rotate: d.rotate, degenerate: d.degenerate },
        translate: d.translate,
      };
    }
    return out;
  }

  /** Typed (D121): degrees and metres in, the bone turned -- the gizmo's edit from the other side. */
  setNumbers(values: { forward: number; left: number; twist: number; translate: readonly [number, number, number] }): void {
    const bone = this.target;
    const rest = bone && this.host.restOf(bone);
    if (!bone || !rest) return;
    const { quaternion, position } = fromNumbers(rest, values);
    bone.quaternion.copy(quaternion);
    bone.position.copy(position);
    this.record();
    this.host.posed();
    this.host.changed();
  }

  /** What the gizmo, or the numbers, did to the chosen bone: held. */
  private record(): void {
    const bone = this.target;
    if (!bone) return;
    this.held.set(bone, { quaternion: bone.quaternion.clone(), position: bone.position.clone() });
  }

  dispose(): void {
    this.undoAlt();
    this.controls.detach();
    this.controls.dispose();
    this.helper.removeFromParent();
  }
}
