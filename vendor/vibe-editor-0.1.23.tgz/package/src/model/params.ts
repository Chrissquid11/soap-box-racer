/**
 * The Parameters block's rules (Docs/modeler.md M22; Vibe3D D45, D47, D58,
 * D67, D111): a script's `params{}` as Gladius reports it, the overrides that
 * apply -- the source's record's, over its folders' `export.json` -- and what
 * each row is: its widget, its step, whether it is changed, what a value is
 * written as.
 *
 * - **Three layers, one value**: the script's *default*, the *override* the
 *   export passes (`ParamsAnswer.set`, the record's `params` option over the
 *   folders'), and the *effective* value Gladius says it builds at. A row is
 *   **changed** when an override makes the value differ from the default; its
 *   ↺ takes the source's own override away (a folder's stays, said so).
 * - **Overrides are text end to end** (D45): what `--param` takes and what the
 *   record keeps -- `2`, `true`, `banded` -- so the page, the preview and the
 *   export cannot spell a number two ways.
 * - **The widget from the spec** (D67): choices a list (numbers or words),
 *   a boolean a tick, a number with both bounds a slider and a field, one
 *   without a field alone, a string that is a colour (`#rgb`, `#rrggbb`, by
 *   its value, never its name) a swatch and its text, any other string a
 *   line of text.
 * - **A slider's step from its span** (Vibe3D's `niceStep`): a power of ten
 *   about a hundredth of the range, so 42 millimetres and six metres both
 *   drag well; an integer steps by one.
 *
 * Pure (`params.test.ts`): no DOM.
 */
import type { OptionValue, Options, ParamSpec, ParamsAnswer } from '@vibe/pipeline/assets-types';

export type Widget = 'choice' | 'tick' | 'slider' | 'number' | 'colour' | 'text';

/** A row of the block: its spec, and what the layers say of it. */
export interface ParamRow {
  spec: ParamSpec;
  widget: Widget;
  /** The override the export passes, as text, if any. */
  set: string | undefined;
  /** Set by the source's own record -- what ↺ takes away. */
  own: boolean;
  /** Set by a folder's `export.json` above it, not the record: ↺ cannot take it away here. */
  inherited: boolean;
  /** An override makes it differ from the script's default. */
  changed: boolean;
}

/** `#abc` or `#aabbcc` as the `#aabbcc` a colour input takes; undefined for anything else. */
export function normaliseHex(value: string): string | undefined {
  const text = value.trim();
  const short = /^#([0-9a-f])([0-9a-f])([0-9a-f])$/i.exec(text);
  if (short) return `#${short[1]}${short[1]}${short[2]}${short[2]}${short[3]}${short[3]}`.toLowerCase();
  return /^#[0-9a-f]{6}$/i.test(text) ? text.toLowerCase() : undefined;
}

/** The widget a spec gets. */
export function widgetOf(spec: ParamSpec): Widget {
  if (spec.choices && spec.choices.length > 0) return 'choice';
  if (spec.type === 'boolean') return 'tick';
  if (spec.type === 'number' || spec.type === 'integer') return spec.min !== undefined && spec.max !== undefined && spec.max > spec.min ? 'slider' : 'number';
  return normaliseHex(String(spec.default)) !== undefined || normaliseHex(String(spec.value)) !== undefined ? 'colour' : 'text';
}

/** A slider's and an arrow key's step: one for an integer; else a power of ten near a hundredth of the span. */
/** A slider's positions on a log scale (`logSlider`): fine enough that each is a small step at any value. */
export const LOG_STEPS = 1000;

/**
 * A wide range is a log slider: a number (not an integer) whose min is above 0 and whose max is a thousand times it
 * or more -- 0.001 to 1000, an import's scale -- where a linear slider's first pixel is already 2 or 3 and every
 * value under 1 is out of reach. Each decade of it then takes the same length.
 */
export function isLog(spec: ParamSpec): boolean {
  return spec.type !== 'integer' && spec.min !== undefined && spec.max !== undefined && spec.min > 0 && Number.isFinite(spec.max) && spec.max / spec.min >= 1000;
}

/** A log slider's position (0..LOG_STEPS) for a value. */
export function logPosition(spec: ParamSpec, value: number): number {
  const min = spec.min!;
  const max = spec.max!;
  const v = Math.min(max, Math.max(min, value));
  return Math.round((LOG_STEPS * Math.log(v / min)) / Math.log(max / min));
}

/** A log slider's value at a position: three significant digits, so a drag reads 0.25, 1.5, 120 -- never 1.4962. */
export function logValue(spec: ParamSpec, position: number): number {
  const min = spec.min!;
  const max = spec.max!;
  const v = min * (max / min) ** (Math.min(LOG_STEPS, Math.max(0, position)) / LOG_STEPS);
  return Math.min(max, Math.max(min, Number(v.toPrecision(3))));
}

export function stepOf(spec: ParamSpec): number {
  if (spec.type === 'integer') return 1;
  // A log range's least step is its min's decade: 0.001 at 0.001 to 1000 -- a linear span's hundredth would be 10.
  if (isLog(spec)) return Math.max(10 ** Math.floor(Math.log10(spec.min!)), 1e-6);
  const span = (spec.max ?? 1) - (spec.min ?? 0);
  if (!(span > 0) || !Number.isFinite(span)) return 0.01;
  return Math.max(10 ** Math.floor(Math.log10(span / 100)), 1e-6);
}

/** Decimal places a value of this spec is shown and written to: its step's, at least. */
export function digitsOf(spec: ParamSpec): number {
  const step = stepOf(spec);
  return step >= 1 ? 0 : Math.min(6, Math.ceil(-Math.log10(step)) + 1);
}

/** A value as an override's text: a number to its digits, shortest; a boolean `true` or `false`; a word as it is. */
export function overrideText(spec: ParamSpec, value: number | string | boolean): string {
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'number') {
    if (spec.type === 'integer') return String(Math.round(value));
    return String(Number(value.toFixed(digitsOf(spec))));
  }
  return value;
}

/** A value as a person reads it in a label: `2`, `0.45`, `on`, `banded`. */
export function sayValue(value: number | string | boolean): string {
  if (typeof value === 'boolean') return value ? 'on' : 'off';
  if (typeof value === 'number') return String(Number(value.toPrecision(6)));
  return value;
}

/** The value a text stands for in a spec's type: what an override reads as. */
export function valueOf(spec: ParamSpec, text: string): number | string | boolean {
  if (spec.type === 'boolean') return text === 'true' || text === '1';
  if (spec.type === 'number' || spec.type === 'integer') {
    const n = Number(text);
    return text.trim() !== '' && Number.isFinite(n) ? n : text;
  }
  return text;
}

/** Is `value` one Gladius would take for `spec`: in its range, one of its choices, whole for an integer? Its words if not. */
export function refusal(spec: ParamSpec, value: number | string | boolean): string | null {
  if (spec.choices && !spec.choices.some((c) => String(c) === String(value))) return `${spec.name} is one of ${spec.choices.join(', ')}`;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return `${spec.name} is a number`;
    if (spec.min !== undefined && value < spec.min) return `${spec.name} is at least ${spec.min}`;
    if (spec.max !== undefined && value > spec.max) return `${spec.name} is at most ${spec.max}`;
  } else if ((spec.type === 'number' || spec.type === 'integer') && typeof value === 'string') return `${spec.name} is a number`;
  return null;
}

/** The rows of an answer, in declaration order. */
export function rowsOf(answer: Pick<ParamsAnswer, 'params' | 'set' | 'own'>): ParamRow[] {
  return (answer.params ?? []).map((spec) => {
    const set = answer.set[spec.name];
    const own = answer.own[spec.name] !== undefined;
    return { spec, widget: widgetOf(spec), set, own, inherited: set !== undefined && !own, changed: set !== undefined && String(spec.value) !== String(spec.default) };
  });
}

/** A row's shape, apart from its value: a row whose shape is the same is updated in place, never made again (D58). */
export function shapeOf(spec: ParamSpec): string {
  return JSON.stringify([spec.name, spec.type, spec.min, spec.max, spec.choices, spec.doc, widgetOf(spec)]);
}

/**
 * A record's options with one parameter's override set -- or, `undefined`,
 * taken away; an empty map is no option at all. The rest as they were.
 */
export function withParam(options: Options, name: string, text: string | undefined): Options {
  const now = options.params;
  const map: Record<string, OptionValue> = typeof now === 'object' && now !== null && !Array.isArray(now) ? { ...(now as Record<string, OptionValue>) } : {};
  if (text === undefined) delete map[name];
  else map[name] = text;
  const out: Options = { ...options };
  if (Object.keys(map).length === 0) delete out.params;
  else out.params = map as OptionValue;
  return out;
}

/** A record's options with every override of the source's own taken away (Reset all, a bake's second half). */
export function withoutParams(options: Options, names?: readonly string[]): Options {
  let out = options;
  const now = options.params;
  const map = typeof now === 'object' && now !== null && !Array.isArray(now) ? Object.keys(now) : [];
  for (const name of map) if (!names || names.includes(name)) out = withParam(out, name, undefined);
  return out;
}

/** A record file's text read to its options: `{}` for none, or one that does not parse (the server says why on export). */
export function recordOptions(text: string | null): Options {
  if (text === null) return {};
  try {
    const parsed = JSON.parse(text) as { options?: unknown };
    const options = parsed?.options;
    return typeof options === 'object' && options !== null && !Array.isArray(options) ? (options as Options) : {};
  } catch {
    return {};
  }
}
