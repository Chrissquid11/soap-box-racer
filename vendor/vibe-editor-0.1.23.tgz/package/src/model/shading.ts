/**
 * How the Model tab draws the model (Docs/modeler.md M10; Vibe3D D9, D73):
 * shaded, shaded with its wires, or wireframe -- and in the wire modes the
 * polygons the kernel built (`GET model`) heavy over the triangles faint.
 *
 * - **The triangles' overlay is built the first time a wire mode is on**, and
 *   kept until the model changes: three times the lines of the triangles, and
 *   most looks never leave shaded. A child of each mesh, so it follows it and
 *   is never picked (picking is not recursive).
 * - **Wireframe is the material's** (`wireframe`), not the surface hidden: the
 *   colours still read. With wires over the surface, the surface is pushed back
 *   a touch (`polygonOffset`) so the lines are not shredded by it.
 * - **The polygons as pixel-wide lines** (`LineSegments2`, 2 px; a plain line
 *   is one pixel whatever it is asked): one object a kernel node, hidden with
 *   the part it outlines, its width set for each view as it is drawn.
 * - **A model's materials are its own here**: the export was decoded for the
 *   tab alone (`scratch.ts`), so setting `wireframe` on them touches nothing the
 *   game draws.
 */
import * as THREE from 'three';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';
import type { ModelNode } from '@vibe/pipeline/assets-types';
import { ACCENT } from '../overlays.ts';
import type { Shading } from '../prefs.ts';

/** The wires' colour over the shaded surface; over nothing (wireframe), lighter. */
const WIRE = 0x0d0f14;
const WIRE_ALONE = 0xc9ced8;
/** The polygons' width, in CSS pixels. */
const POLYGON_PX = 2;

/**
 * A mesh's triangle edges as lines **over its own positions** -- the same
 * attribute, an index of its own (each edge once): a mesh whose positions move
 * (a build trace's step morphing into place, M36) takes its wires with it,
 * where three's `WireframeGeometry` copies them and is left behind (Vibe3D D69).
 */
export function edgesOver(geometry: THREE.BufferGeometry): THREE.BufferGeometry {
  const position = geometry.getAttribute('position');
  const lines = new THREE.BufferGeometry();
  if (!position) return lines;
  const index = geometry.index;
  const count = index ? index.count : position.count;
  const at = (i: number): number => (index ? index.getX(i) : i);
  const seen = new Set<number>();
  const pairs: number[] = [];
  for (let i = 0; i + 2 < count; i += 3) {
    for (let e = 0; e < 3; e++) {
      const a = at(i + e);
      const b = at(i + ((e + 1) % 3));
      const key = a < b ? a * 4294967296 + b : b * 4294967296 + a;
      if (seen.has(key)) continue;
      seen.add(key);
      pairs.push(a, b);
    }
  }
  lines.setAttribute('position', position);
  lines.setIndex(position.count > 65535 ? new THREE.Uint32BufferAttribute(pairs, 1) : new THREE.Uint16BufferAttribute(pairs, 1));
  return lines;
}

const materialsOf = (mesh: THREE.Mesh): THREE.Material[] => (Array.isArray(mesh.material) ? mesh.material : [mesh.material]);

/** A polygon outline of a kernel node, and the part it follows. */
interface Polygons {
  lines: LineSegments2;
  /** The object it outlines, or null when none matched: shown with the model then. */
  follows: THREE.Object3D | null;
}

export class Shading3D {
  /** In the scene: the polygons' lines, in the model's space. */
  readonly group = new THREE.Group();
  mode: Shading = 'shaded';
  private model: THREE.Object3D | null = null;
  private readonly overlays: THREE.Object3D[] = [];
  private readonly triangles = new THREE.LineBasicMaterial({ color: WIRE, transparent: true, opacity: 0.5 });
  private readonly skinnedTriangles = new THREE.MeshBasicMaterial({ color: WIRE, wireframe: true, transparent: true, opacity: 0.5 });
  private readonly polygonMaterial = new LineMaterial({ color: WIRE, linewidth: POLYGON_PX, transparent: true, depthWrite: false });
  /** A selected part's polygons in wireframe, where its hull outline would fill the see-through model: amber. */
  private readonly chosenMaterial = new LineMaterial({ color: new THREE.Color(ACCENT).getHex(), linewidth: POLYGON_PX + 0.5, transparent: true, depthWrite: false });
  private polygons: Polygons[] = [];
  private chosen = new Set<THREE.Object3D>();
  /** Posed by a clip: the polygons are the rest pose's, so they give way to the triangles, which follow it (M31). */
  private posed = false;
  /** Out of sight: the model while a build trace's step stands in for it (M34) -- its polygons with it. */
  private hidden = false;
  /** Objects whose polygons wait: a trace step moving into place (M36), its lines drawn again as it lands. */
  private away = new Set<THREE.Object3D>();

  constructor() {
    this.group.name = 'model: polygons';
    // After the surfaces: a line on the face it bounds is not fought by it; depth-tested, the far side's are hidden.
    this.group.renderOrder = 6;
  }

  /** Are the polygons from the kernel drawn: a wire mode, and an answer in. */
  get hasPolygons(): boolean {
    return this.polygons.length > 0;
  }

  /** Posed by a clip, or at rest: the kernel's polygons drawn at rest alone (Vibe3D D89). */
  setPosed(posed: boolean): void {
    if (posed === this.posed) return;
    this.posed = posed;
    this.apply();
  }

  /** The model out of sight -- a build trace's step shown in its place -- or back: its polygons with it. */
  setHidden(hidden: boolean): void {
    if (hidden === this.hidden) return;
    this.hidden = hidden;
    this.apply();
  }

  /** These objects' polygons held back (a trace step moving, its lines where it will land): none, all back. */
  setAway(objects: readonly THREE.Object3D[]): void {
    this.away = new Set(objects);
  }

  /** A new model: the overlays of the last one gone, the mode put on this one. */
  setModel(model: THREE.Object3D | null): void {
    this.dropOverlays();
    this.setPolygons(null, null);
    this.model = model;
    this.apply();
  }

  setMode(mode: Shading): void {
    this.mode = mode;
    this.apply();
  }

  /** The selection's objects: in wireframe their polygons are drawn amber (each and what is under it). */
  setSelected(objects: readonly THREE.Object3D[]): void {
    this.chosen = new Set();
    for (const o of objects) o.traverse((each) => void this.chosen.add(each));
    this.paint();
  }

  private paint(): void {
    const wire = this.mode === 'wireframe';
    for (const p of this.polygons) p.lines.material = wire && p.follows && this.chosen.has(p.follows) ? this.chosenMaterial : this.polygonMaterial;
  }

  /**
   * The kernel's polygons for this model -- each node's segments -- matched to
   * its parts by `find` (the part's object by the kernel node's name); null
   * takes them away (a rebuild, a failed query).
   */
  setPolygons(nodes: readonly ModelNode[] | null, find: ((node: ModelNode, index: number) => THREE.Object3D | null) | null): void {
    for (const p of this.polygons) {
      p.lines.geometry.dispose();
      this.group.remove(p.lines);
    }
    this.polygons = [];
    for (const [i, node] of (nodes ?? []).entries()) {
      if (node.segments.length === 0) continue;
      const geometry = new LineSegmentsGeometry();
      geometry.setPositions(node.segments);
      const lines = new LineSegments2(geometry, this.polygonMaterial);
      // Its bounds are the model's: one that blinks out with the model half off screen reads as a fault.
      lines.frustumCulled = false;
      lines.raycast = () => {};
      this.group.add(lines);
      this.polygons.push({ lines, follows: find?.(node, i) ?? null });
    }
    this.apply();
  }

  private apply(): void {
    const wires = this.mode !== 'shaded';
    const over = this.mode === 'shaded-wireframe';
    if (over && this.overlays.length === 0) this.buildOverlays();
    // Wireframe draws its triangles through the material; the overlay is for wires over the surface.
    for (const o of this.overlays) o.visible = over;
    const colour = this.mode === 'wireframe' ? WIRE_ALONE : WIRE;
    this.triangles.color.set(colour);
    this.skinnedTriangles.color.set(colour);
    this.polygonMaterial.color.set(colour);
    this.group.visible = wires && !this.posed && !this.hidden;
    this.paint();
    this.model?.traverse((object) => {
      if (!(object as THREE.Mesh).isMesh || object.userData.modelOverlay) return;
      for (const material of materialsOf(object as THREE.Mesh)) {
        if (!('wireframe' in material)) continue;
        (material as THREE.Material & { wireframe: boolean }).wireframe = this.mode === 'wireframe';
        // With wires over it, the surface a touch back: the lines are not shredded by the triangles they outline.
        material.polygonOffset = over;
        material.polygonOffsetFactor = 1;
        material.polygonOffsetUnits = 1;
        material.needsUpdate = true;
      }
    });
  }

  /** Each mesh's triangles as lines -- a skinned mesh's skinned with it, so the wires follow a pose (phase 4). */
  private buildOverlays(): void {
    const meshes: THREE.Mesh[] = [];
    this.model?.traverse((object) => {
      if ((object as THREE.Mesh).isMesh && !object.userData.modelOverlay) meshes.push(object as THREE.Mesh);
    });
    for (const mesh of meshes) {
      let overlay: THREE.Object3D;
      if ((mesh as THREE.SkinnedMesh).isSkinnedMesh) {
        const skinned = mesh as THREE.SkinnedMesh;
        const wire = new THREE.SkinnedMesh(skinned.geometry, this.skinnedTriangles);
        wire.bind(skinned.skeleton, skinned.bindMatrix);
        wire.frustumCulled = false;
        overlay = wire;
      } else {
        overlay = new THREE.LineSegments(edgesOver(mesh.geometry), this.triangles);
      }
      overlay.name = 'model: wires';
      overlay.userData.modelOverlay = true;
      overlay.raycast = () => {};
      mesh.add(overlay);
      this.overlays.push(overlay);
    }
  }

  private dropOverlays(): void {
    for (const o of this.overlays) {
      o.removeFromParent();
      // A skinned overlay shares its mesh's geometry, which is the model's to free; an edge overlay shares its positions
      // (`edgesOver`): they are let go of first, so freeing its own index never frees the buffer the mesh draws from.
      if (!(o as THREE.SkinnedMesh).isSkinnedMesh) {
        const geometry = (o as THREE.LineSegments).geometry;
        geometry.deleteAttribute('position');
        geometry.dispose();
      }
    }
    this.overlays.length = 0;
  }

  /**
   * Before a view is drawn: the polygons' width is in that view's pixels, and
   * each is shown only while the part it outlines is (hidden by the eye, or
   * under a part that is).
   */
  prepare(width: number, height: number): void {
    this.polygonMaterial.resolution.set(Math.max(width, 1), Math.max(height, 1));
    this.chosenMaterial.resolution.set(Math.max(width, 1), Math.max(height, 1));
    for (const p of this.polygons) {
      let seen = !(p.follows && this.away.has(p.follows));
      for (let o: THREE.Object3D | null = p.follows; o && seen; o = o.parent) seen = o.visible;
      p.lines.visible = seen;
    }
  }

  dispose(): void {
    this.setModel(null);
    this.triangles.dispose();
    this.skinnedTriangles.dispose();
    this.polygonMaterial.dispose();
    this.chosenMaterial.dispose();
  }
}
