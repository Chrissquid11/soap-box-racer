/**
 * The Model tab's stage (Docs/modeler.md M2, M7, M9): one canvas of its own,
 * a `WebGLRenderer` of its own, and one, two or four views of one scene
 * scissored into it (Vibe3D D19) -- each with its camera in both projections
 * (`../view/view-camera.ts`), its label, its cube (`../view/cube.ts`) and its projection's
 * switch -- the ground (`grid.ts`), the shading (`shading.ts`), the
 * selection's outline (`outline.ts`); the pointer and the wheel; a click, a
 * box and a right-click told to the tab.
 *
 * - **The editor's navigation** (M7, Blender's: Docs/navigation.md), the one
 *   driver's (`../view/navigator.ts`) as the Scene view has it: the middle
 *   button orbits, Shift pans, Ctrl zooms; the wheel zooms, a trackpad's two
 *   fingers orbit, a pinch zooms, Shift pans. A left drag is a box, from a part
 *   too; a press that does not move is a click: it picks. A right-click is the
 *   menu; a right drag nothing. A press on the cube orbits from there, a click
 *   on its cone or centre as ever.
 * - **The keys and the wheel go to the view under the pointer** (D19); the
 *   view last pressed in is lit (`active`), and is the one a key acts on with
 *   the pointer off the stage.
 * - **One frame for many asks** (`draw`): drawn on the next animation frame,
 *   once, whatever asked -- nothing is drawn while nothing changes.
 * - **Its own context, looked after** (as the Assets preview's): made as the
 *   tab first shows; remade on its own `webglcontextlost` (the scene the same,
 *   three uploads it again) after a short delay, never in the same breath --
 *   a context asked for while the GPU resets is refused; given back on
 *   dispose (`forceContextLoss`). One that cannot be made is said on the
 *   tab's line, not thrown, and tried again on a growing delay while the tab
 *   shows, and at once as it is next shown (`context-retry.ts`).
 * - **A layout change keeps the free view's direction** (D23): axis views snap
 *   to their axis; the free one is where it was left.
 */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { ModelNode } from '@vibe/pipeline/assets-types';
import { isMac } from '@vibe/engine/debug';
import { control, el, tip } from '../dom.ts';
import { loadPrefs, type Shading } from '../prefs.ts';
import { boxHow, clickHow, type ClickHow, type Combine } from '../selection.ts';
import { navigates, pastSlop } from '../view/navigation.ts';
import { buttonMask, createNavigator, noAutoscroll, type NavView } from '../view/navigator.ts';
import { contextRetry } from './context-retry.ts';
import { Cube, cubeTip } from '../view/cube.ts';
import { Grid } from './grid.ts';
import { Outline } from './outline.ts';
import { Shading3D } from './shading.ts';
import type { PaintView } from './canvases.ts';
import { ViewCamera, type ViewPose } from '../view/view-camera.ts';
import { overView } from '../view/over-view.ts';
import { armFly, arrowFly, beginWalk, type WalkTarget } from '../view/walker.ts';
import { cubeRect, DIRECTIONS, inside, presetOf, viewLabel, type Preset, type Rect, type Vec3 } from '../view/views.ts';
import { gridReadout, rectsFor, SLOTS, viewAt, type Layout } from './views.ts';


export interface StageOptions {
  /** Where the canvas and the views' chrome go: filled whole. */
  host: HTMLElement;
  /** The box the views are in, whose outer size says when they may have moved (the tab's room); the host by default. */
  room?: HTMLElement;
  /** An element whose inline style and classes lay the views out too (the editor's root: the panels' widths, the Assets panel's height). */
  watch?: HTMLElement;
  /** A click on a part's object -- or on nothing, null -- with what its modifiers ask. */
  click(object: THREE.Object3D | null, how: ClickHow): void;
  /** A box drawn: the parts' objects whose middles are inside it, with what its modifiers ask. */
  box(objects: THREE.Object3D[], how: Combine): void;
  /** A right-click that did not drag, on a part's object or on nothing: its menu at (`x`, `y`) on the page. */
  menu(object: THREE.Object3D | null, x: number, y: number): void;
  /** What a click or a box may take: the parts' objects drawn just now. */
  pickable(): readonly THREE.Object3D[];
  /** The view's object a hit object stands for -- a part's own, for a mesh deep in it. */
  partOf(object: THREE.Object3D): THREE.Object3D | null;
  /** A view was pressed in, its projection or layout changed: the toolbar reads again. */
  changed(): void;
  /**
   * The canvases (`canvases.ts`, Docs/modeler.md M28): in paint mode the left
   * button -- not with Alt, which orbits -- is theirs; each view is prepared
   * for them before it is drawn, and they are told when every view is drawn
   * and when a view comes to rest after a gesture (D51's magnet).
   */
  paint?: StagePaint;
  /** The bones and the pose gizmo (Docs/modeler.md M31-M33). */
  pose?: StagePose;
  /** The build trace's own lines (its cut, M36): their width set in each view's pixels before it is drawn. */
  trace?: { prepare(width: number, height: number): void };
  /** A line for the tab's banner: the context could not be made, or was made again. */
  said?(line: string): void;
  /** The wheel is read as another device now: what scrolling does, for the top bar's status line. */
  scrolled?(trackpad: boolean): void;
  /** The keys down now (MrDebug's `held`): what the right button's flight reads. None: a right press is the menu alone. */
  held?(code: string): boolean;
}

/** What the stage asks of the bones and the pose gizmo. */
export interface StagePose {
  /** The gizmo has the pointer -- a handle hovered, or dragged: a press is its, not the stage's. */
  grabbing(): boolean;
  /** The view under the pointer, or none, and where the pointer is (CSS pixels on the stage): where the gizmo reads it, a bone's name shown. `height`: the canvas's. */
  hover(view: PaintView | null, height: number, x: number, y: number): void;
  /** A view about to be drawn -- or every view drawn (null): the gizmo sized for each. */
  drawing(view: PaintView | null, height: number): void;
  /** A click in a view: the bone drawn there, with Bones on, before any part. */
  pick(view: PaintView, x: number, y: number): THREE.Object3D | null;
  /** Before a frame: what follows the model put where it is (the weight maps). */
  place(): void;
}

/** What the stage asks of the canvases. */
export interface StagePaint {
  /** Paint mode: the left button draws. */
  active(): boolean;
  down(view: PaintView, x: number, y: number): boolean;
  move(x: number, y: number): void;
  up(): void;
  cancel(): void;
  hover(view: PaintView | null, x: number, y: number): void;
  prepare(view: PaintView): void;
  drawn(): void;
  rested(view: PaintView): void;
}

/** One view: its camera, where it is, its chrome. */
interface View {
  cam: ViewCamera;
  preset: Preset;
  rect: Rect;
  cell: HTMLElement;
  label: HTMLElement;
  projection: HTMLButtonElement;
  /** The view as the driver moves it. */
  nav: NavView;
  /** Orthographic because an axis view made it so (Auto Perspective): perspective again once orbited off the axis. */
  autoOrtho: boolean;
}

export interface Stage {
  readonly layout: Layout;
  setLayout(layout: Layout): void;
  readonly shading: Shading;
  setShading(mode: Shading): void;
  /** Are the kernel's polygons drawn over the wires: false while there is no answer from Gladius. */
  readonly polygons: boolean;
  readonly grid: boolean;
  setGrid(on: boolean): void;
  /** The ground's readout element's words, for the toolbar's hover too. */
  readonly gridLine: string;
  /** Shown -- the tab up -- or not: the renderer is made the first time. */
  setVisible(visible: boolean): void;
  /**
   * The model shown -- the export decoded, the tab's own -- or none. `frame`:
   * every view framed on it (a model opened); else the cameras stay where they
   * are and only the sizes follow (a rebuild, D46) -- but the first build with
   * geometry after views framed on an empty one (New model) is framed.
   */
  setModel(model: THREE.Object3D | null, frame: boolean): void;
  /** The model posed by a clip (M31): the kernel's polygons, the rest pose's, give way to the triangles. */
  setPosed(posed: boolean): void;
  /**
   * A build trace's step shown in the model's place (M34) -- its group drawn,
   * shaded as the model is, with its own wires -- or null, the model back:
   * while one is, the model, its polygons, its outline and its overlays (the
   * bones, the weights, the gizmo: `overlayRoot`) are out of sight.
   */
  setTrace(group: THREE.Object3D | null): void;
  /** The trace's polygons, a node a step, matched to the step's node; null for none. */
  setTracePolygons(nodes: readonly ModelNode[] | null, find: ((node: ModelNode) => THREE.Object3D | null) | null): void;
  /** A trace step's node whose polygons wait while it moves into place (M36); empty for none. */
  setTraceAway(objects: readonly THREE.Object3D[]): void;
  /** Where what follows the model goes -- the bones, the weight maps, the gizmo -- out of sight with it while a trace step is shown. */
  readonly overlayRoot: THREE.Object3D;
  /** The kernel's polygons for the model shown, matched to its objects; null for none. */
  setPolygons(nodes: readonly ModelNode[] | null, find: ((node: ModelNode) => THREE.Object3D | null) | null): void;
  /** These objects outlined: the selection's. */
  setOutline(objects: readonly THREE.Object3D[]): void;
  /** The stats overlay's rows, in the first view; null hides it. */
  setStats(rows: readonly (readonly [string, string])[] | null): void;
  /**
   * The view a key acts on (the one under the pointer, else the one last
   * pressed) framed on these objects -- or the whole model for none; `all`
   * frames every view (Home).
   */
  frame(objects: readonly THREE.Object3D[] | null, all?: boolean): void;
  /** The key's view looking from `preset`'s side, at its distance. */
  look(preset: Preset): void;
  /** The key's view looking from the other side of where it looks. */
  flip(): void;
  /** The key's view, or view `index`, in the other projection. */
  toggleProjection(index?: number): void;
  /** The numpad's steps on the key's view (Docs/navigation.md §3): an orbit in turns, a pan in shares of the height seen, a zoom. */
  orbitBy(dx: number, dy: number): void;
  panBy(dx: number, dy: number): void;
  zoomBy(scale: number): void;
  /** Ask for a frame: drawn once on the next animation frame. */
  draw(): void;
  /** Something inside the room moved the views (the banner shown or hidden): laid out again on the next frame. */
  refit(): void;
  /** What the views show, as facts for a turn: each view's name. */
  views(): string[];
  /** Each view's camera as values, for a reload (M18). */
  poses(): ViewPose[];
  /** Each view put where a pose says -- null leaves one as it is. */
  setPoses(poses: readonly (ViewPose | null)[]): void;
  /** Is the pointer over a view: where flying and the numpad act. */
  readonly hovering: boolean;
  /**
   * The views drawn now, at once, and the canvas they are on -- to be copied in the same task (`view_shot`,
   * Docs/mcp.md M4): null while the tab is not shown or has no context.
   */
  snapshot(): HTMLCanvasElement | null;
  /** The scene the views draw, the renderer (null before the tab first shows), the background: what a canvas captures. */
  readonly scene: THREE.Scene;
  renderer(): THREE.WebGLRenderer | null;
  readonly background: THREE.Color;
  /** The views as they are, for the canvases. */
  paintViews(): PaintView[];
  /** The selection's outline: never captured into a canvas's backdrop. */
  readonly outlineGroup: THREE.Object3D;
  /** The model's radius, as framing measures it. */
  readonly radius: number;
  /** The element over the views where a stage's own marks go (the brush's ring, a marquee). */
  readonly overlay: HTMLElement;
  /** A fly key went down (`held` reads the keys down now, MrDebug's): the view under the pointer flies while any is held (D102). */
  fly(held: (code: string) => boolean): void;
  /** Blender's walk in the key's view (Docs/navigation.md §4, `../view/walker.ts`). */
  walk(held: (code: string) => boolean): void;
  /** The arrow keys' flight in the key's view (Docs/navigation.md §7), while any arrow is held. */
  arrowFly(held: (code: string) => boolean): void;
  dispose(): void;
}

export function createStage(options: StageOptions): Stage {
  const { host } = options;
  const scene = new THREE.Scene();
  // The Assets preview's light (`preview/renderer.ts`): a model looks here as it looks there -- a white face about 1, its sides told apart.
  scene.add(new THREE.HemisphereLight(0xffffff, 0x6a6a6a, 0.8));
  const key = new THREE.DirectionalLight(0xffffff, 1.5);
  key.position.set(3, 5, 4);
  scene.add(key);
  scene.environmentIntensity = 0.35;
  const modelRoot = new THREE.Group();
  modelRoot.name = 'model';
  const grid = new Grid();
  const shading = new Shading3D();
  const outline = new Outline();
  const overlayRoot = new THREE.Group();
  overlayRoot.name = 'model: overlays';
  /** A build trace's step in the model's place (M34), and its own shading -- its wires, its polygons. */
  let traceGroup: THREE.Object3D | null = null;
  const traceShading = new Shading3D();
  traceShading.group.name = 'model: trace polygons';
  scene.add(grid.group, modelRoot, shading.group, outline.group, overlayRoot, traceShading.group);
  const cube = new Cube();
  let model: THREE.Object3D | null = null;
  let layout: Layout = loadPrefs().model.layout;
  let gridOn = loadPrefs().model.grid;
  grid.group.visible = gridOn;
  shading.setMode(loadPrefs().model.shading);
  traceShading.setMode(shading.mode);
  outline.group.visible = shading.mode !== 'wireframe';
  let visible = false;
  /** The views, as the layout has them. */
  let views: View[] = [];
  /** The view last pressed in; the view under the pointer (-1 off the stage). */
  let active = 0;
  let hovered = -1;
  /** The free view's direction, kept across a layout change (D23). */
  const freeDirection = new THREE.Vector3(...DIRECTIONS.free).normalize();
  /** The model's bounds and radius, and how far the ground reaches: what framing and the clip planes measure. */
  const bounds = new THREE.Box3();
  /** The views last framed on nothing (New model's empty script): the first build with geometry is framed in its turn. */
  let framedEmpty = false;
  const centre = new THREE.Vector3();
  let radius = 1;
  /** The parts selected, as outlined: Orbit Around Selection's pivot. */
  let outlined: readonly THREE.Object3D[] = [];

  // ---------------------------------------------------------------- the canvas and the chrome

  const cells = el('div', 'ed-mo-cells');
  const statsBox = el('div', 'ed-mo-stats');
  statsBox.hidden = true;
  const readout = el('div', 'ed-mo-readout');
  const boxEl = el('div', 'ed-mo-box');
  boxEl.hidden = true;
  let renderer: THREE.WebGLRenderer | null = null;
  let environment: THREE.Texture | null = null;
  let width = 0;
  let height = 0;
  /** The stage's background, from the stylesheet's token. */
  const background = new THREE.Color(0x14171d);

  function make(): THREE.WebGLRenderer {
    const made = new THREE.WebGLRenderer({ antialias: true });
    made.setPixelRatio(Math.min(devicePixelRatio, 2));
    const token = getComputedStyle(host).getPropertyValue('--ed-mo-bg').trim();
    if (token) background.setStyle(token);
    made.setClearColor(background, 1);
    const canvas = made.domElement;
    canvas.className = 'ed-mo-canvas';
    canvas.addEventListener('webglcontextlost', onLost);
    // The standard materials' light: a room's, made on this context (and again on the next).
    const pmrem = new THREE.PMREMGenerator(made);
    const room = new RoomEnvironment();
    environment = pmrem.fromScene(room, 0.04).texture;
    room.dispose();
    pmrem.dispose();
    scene.environment = environment;
    if (width > 0 && height > 0) made.setSize(width, height, false);
    return made;
  }

  /** The renderer, made as first wanted, made again after a loss or a failed try (`context-retry.ts`). */
  const context = contextRetry<THREE.WebGLRenderer>({
    make,
    wanted: () => visible,
    made(made, again) {
      renderer = made;
      host.prepend(made.domElement);
      listen(made.domElement, true);
      if (again) {
        console.info('[model] the Model tab\'s WebGL context: made again');
        options.said?.('The view\'s WebGL context is back');
      }
      draw();
    },
    failed(err, tries) {
      if (tries > 1) return;
      console.warn('[model] no WebGL context could be made for the Model tab: tried again shortly, and as the tab is next shown', err);
      options.said?.('No WebGL context for the view just now (the GPU busy, or too many contexts open): tried again shortly');
    },
    setTimer: (fn, ms) => setTimeout(fn, ms),
    clearTimer: (handle) => clearTimeout(handle as ReturnType<typeof setTimeout>),
  });

  /** The renderer, made if it is not yet -- null while WebGL cannot be had. */
  function ensure(): THREE.WebGLRenderer | null {
    return context.get();
  }

  function onLost(event: Event): void {
    event.preventDefault();
    // A context of the browser's sixteen or so taken, or the GPU reset: the canvas dropped, a new one and renderer made
    // after a delay (the scene the same) -- one asked for at once, during a GPU reset, is refused.
    queueMicrotask(() => {
      const old = renderer;
      if (!old || old.domElement !== event.target) return;
      listen(old.domElement, false);
      old.domElement.removeEventListener('webglcontextlost', onLost);
      renderer = null;
      old.domElement.remove();
      environment?.dispose();
      environment = null;
      old.dispose();
      context.lost();
    });
  }

  /**
   * The views laid out again on the next frame, whatever moved them. Not a
   * ResizeObserver on the views themselves: their height follows the Assets
   * panel's (`--ed-panel-h`), which the editor sets inside its own observer's
   * callback, and a size changed there is one the browser cannot deliver in
   * that frame ("ResizeObserver loop"). So: the room's outer box (the window,
   * a panel's width -- never the dock), and the editor's root's inline style,
   * where the panels' widths, Claude's column docked and the Assets panel's height are set.
   */
  let fitting = 0;
  const soonFit = (): void => {
    if (fitting === 0) fitting = requestAnimationFrame(() => {
      fitting = 0;
      fit();
      draw();
    });
  };
  const resize = new ResizeObserver(soonFit);
  resize.observe(options.room ?? host, { box: 'border-box' });
  const styled = new MutationObserver(soonFit);
  if (options.watch) styled.observe(options.watch, { attributes: true, attributeFilter: ['style', 'class'] });
  host.append(cells, boxEl);

  /** The canvas the host's size, the views' rects with it. */
  function fit(): void {
    const w = Math.floor(host.clientWidth);
    const h = Math.floor(host.clientHeight);
    if (w === width && h === height) return;
    width = w;
    height = h;
    if (renderer && w > 0 && h > 0) renderer.setSize(w, h, false);
    place();
    draw();
  }

  /** Each view's rect, aspect and cell placed for the canvas as it is. */
  function place(): void {
    const rects = rectsFor(layout, width, height);
    views.forEach((view, i) => {
      view.rect = rects[i]!;
      view.cam.setAspect(view.rect.width / Math.max(view.rect.height, 1));
      const { x, y, width: w, height: h } = view.rect;
      Object.assign(view.cell.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });
      const c = cubeRect(view.rect);
      Object.assign(view.projection.style, { left: `${c.x - x + c.width / 2}px`, top: `${c.y - y + c.height + 2}px` });
      // A view too small for the overlay's five rows beside the cube, or the readout under them: they give way, the model first.
      view.cell.classList.toggle('ed-mo-cramped', w < 300 || h < 240);
    });
  }

  /** The views for `next`: as many as its slots, each on its slot's side and projection -- the free one where it was. */
  function build(next: Layout): void {
    keepFree();
    for (const view of views) view.cell.remove();
    const slots = SLOTS[next];
    // The free view's camera goes to the free slot, wherever it is in this layout -- its target and zoom with it;
    // the other cameras are used again in order, and new ones framed.
    const free = views.find((v) => v.preset === 'free')?.cam;
    const rest = views.filter((v) => v.cam !== free).map((v) => v.cam);
    const fresh = new Set<ViewCamera>();
    const made: View[] = slots.map((slot, i) => {
      let cam = slot.preset === 'free' ? free : rest.shift();
      if (!cam) {
        cam = new ViewCamera(slot.projection);
        fresh.add(cam);
      }
      cam.setProjection(slot.projection);
      const cell = el('div', 'ed-mo-cell');
      const label = el('span', 'ed-mo-label');
      const projection = control('ui', 'ed-mo-proj') as HTMLButtonElement;
      projection.addEventListener('click', (event) => {
        event.stopPropagation();
        toggleProjection(i);
      });
      cell.append(label, projection);
      if (i === 0) cell.append(statsBox, readout);
      cells.append(cell);
      const view: View = { cam, preset: slot.preset, rect: { x: 0, y: 0, width: 0, height: 0 }, cell, label, projection, nav: null as unknown as NavView, autoOrtho: false };
      view.nav = navViewOf(view);
      return view;
    });
    views = made;
    layout = next;
    active = Math.min(active, views.length - 1);
    hovered = -1;
    place();
    for (const view of views) {
      view.cam.rescale(radius, grid.reach, centre);
      if (model && fresh.has(view.cam)) view.cam.frame(bounds, radius);
      // An axis view snaps to its axis; the free one is where it was.
      if (view.preset !== 'free' || fresh.has(view.cam)) view.cam.lookFrom(view.preset === 'free' ? [freeDirection.x, freeDirection.y, freeDirection.z] : DIRECTIONS[view.preset]);
      view.cam.clip();
    }
    labels();
  }

  /** The free view's direction, as it is now, kept for the next layout. */
  function keepFree(): void {
    const free = views.find((v) => v.preset === 'free');
    if (free) free.cam.direction(freeDirection);
  }

  /** Each view's label and projection's switch, as its camera is. */
  function labels(): void {
    views.forEach((view, i) => {
      const preset = view.cam.preset;
      const words = viewLabel(preset, view.cam.projection);
      if (view.label.textContent !== words) view.label.textContent = words;
      const iso = view.cam.projection === 'orthographic';
      const switchWords = iso ? 'Iso' : 'Persp';
      if (view.projection.textContent !== switchWords) {
        view.projection.textContent = switchWords;
        tip(view.projection, iso ? 'Orthographic: click for perspective (or the cube\'s centre)' : 'Perspective: click for orthographic (or the cube\'s centre)', 'Numpad5');
      }
      view.cell.classList.toggle('ed-mo-active', views.length > 1 && i === active);
    });
  }

  // ---------------------------------------------------------------- drawing

  let queued = 0;
  function draw(): void {
    if (queued !== 0 || !visible) return;
    queued = requestAnimationFrame(() => {
      queued = 0;
      render();
    });
  }

  const direction = new THREE.Vector3();
  function render(): void {
    const gl = ensure();
    if (!gl || !visible || width === 0 || height === 0) return;
    outline.place();
    options.pose?.place();
    gl.setScissorTest(true);
    for (const [i, view] of views.entries()) {
      const { x, y, width: w, height: h } = view.rect;
      if (w <= 0 || h <= 0) continue;
      // CSS pixels: three multiplies by its pixel ratio itself (D19's note).
      const flipped = height - (y + h);
      gl.setViewport(x, flipped, w, h);
      gl.setScissor(x, flipped, w, h);
      gl.setClearColor(background, 1);
      gl.clear();
      shading.prepare(w, h);
      traceShading.prepare(w, h);
      options.trace?.prepare(w, h);
      outline.setViewport(w, h);
      view.cam.update();
      options.paint?.prepare(view);
      options.pose?.drawing(view, height);
      gl.render(scene, view.cam.camera);
      cube.render(gl, height, cubeRect(view.rect), view.cam.direction(direction), view.cam.camera.up, view.cam.projection === 'orthographic', i === cubeHovered);
    }
    gl.setScissorTest(false);
    options.pose?.drawing(null, height);
    options.paint?.drawn();
    labels();
  }

  // ---------------------------------------------------------------- the pointer

  /** The view a key acts on: the one under the pointer, else the one last pressed. */
  const keyView = (): View | undefined => views[hovered >= 0 ? hovered : active] ?? views[0];
  /** A pointer's place on the canvas, in CSS pixels. */
  function local(event: { clientX: number; clientY: number }): { x: number; y: number } {
    const r = host.getBoundingClientRect();
    return { x: event.clientX - r.left, y: event.clientY - r.top };
  }
  const ray = new THREE.Raycaster();
  const ndc = new THREE.Vector2();

  /** The part's object under a point of view `view`, or null: the nearest hit among what may be picked. */
  function pickAt(view: View, x: number, y: number): THREE.Object3D | null {
    ndc.set(((x - view.rect.x) / view.rect.width) * 2 - 1, -((y - view.rect.y) / view.rect.height) * 2 + 1);
    view.cam.update();
    ray.setFromCamera(ndc, view.cam.camera);
    for (const hit of ray.intersectObjects(options.pickable() as THREE.Object3D[], true)) {
      const part = options.partOf(hit.object);
      if (part) return part;
    }
    return null;
  }

  /** The cube's view hovered, -1 for none. */
  let cubeHovered = -1;

  type Drag = { id: number; button: number; x: number; y: number; view: number; does: 'nav' | 'box' | 'click' | 'paint'; moved: boolean; event: PointerEvent };
  let drag: Drag | null = null;

  /** The driver (Docs/navigation.md D2): every view's orbit, pan and zoom, by the pointer and the wheel. */
  const nav = createNavigator({ device: (device) => options.scrolled?.(device === 'trackpad') });
  const hostBox = (): DOMRect => host.getBoundingClientRect();
  /** A view as the driver moves it: its box on the page, and what follows a step -- the free view's direction kept, a frame. */
  function navViewOf(view: View): NavView {
    return {
      cam: view.cam,
      box: () => {
        const r = hostBox();
        return { left: r.left + view.rect.x, top: r.top + view.rect.y, width: view.rect.width, height: view.rect.height };
      },
      moved: () => {
        autoBack(view);
        if (view.preset === 'free') view.cam.direction(freeDirection);
        draw();
      },
      rested: () => options.paint?.rested(view),
      pivot: () => selectedMiddle(),
      look: (direction, axis, up) => lookAlong(view, direction, axis, up),
      pointAt: (x, y) => {
        const r = hostBox();
        return hitAt(view, x - r.left, y - r.top);
      },
    };
  }
  const hitPoint = new THREE.Vector3();
  /** The nearest point of a part under (`x`, `y`) of the stage, or null: where an Alt+middle click centres a view. */
  function hitAt(view: View, x: number, y: number): THREE.Vector3 | null {
    ndc.set(((x - view.rect.x) / view.rect.width) * 2 - 1, -((y - view.rect.y) / view.rect.height) * 2 + 1);
    view.cam.update();
    ray.setFromCamera(ndc, view.cam.camera);
    const hit = ray.intersectObjects(options.pickable() as THREE.Object3D[], true)[0];
    return hit ? hitPoint.copy(hit.point) : null;
  }
  /** The middle of the parts selected (outlined), or null: Orbit Around Selection's pivot. */
  const pivotBox = new THREE.Box3();
  const pivotPoint = new THREE.Vector3();
  function selectedMiddle(): THREE.Vector3 | null {
    pivotBox.makeEmpty();
    for (const object of outlined) pivotBox.union(box3.setFromObject(object));
    return pivotBox.isEmpty() ? null : pivotBox.getCenter(pivotPoint);
  }

  function onDown(event: PointerEvent): void {
    const { x, y } = local(event);
    const index = viewAt(views.map((v) => v.rect), x, y);
    const view = views[index];
    if (!view) return;
    if (index !== active) {
      active = index;
      labels();
      options.changed();
    }
    const start = (does: Drag['does']): void => {
      event.preventDefault();
      host.setPointerCapture?.(event.pointerId);
      drag = { id: event.pointerId, button: event.button, x, y, view: index, does, moved: false, event };
    };
    // The cube first: a press on it orbits from there; let go unmoved, a click on a cone looks down it, on the centre swaps the projection.
    if (event.button === 0) {
      const c = cubeRect(view.rect);
      if (inside(c, x, y)) {
        const hit = cube.pick(c, x - c.x, y - c.y, view.cam.direction(direction), view.cam.camera.up, view.cam.projection === 'orthographic');
        start('nav');
        nav.grab(event, view.nav, 'orbit', hit ? () => (hit.kind === 'centre' ? toggleProjection(index) : lookAlong(view, hit.direction)) : undefined);
        return;
      }
    }
    // The pose gizmo's handle under the pointer, or paint mode: the left button is theirs (D121, M28) -- but Alt with it under
    // Emulate 3 Button Mouse, which is the middle button's.
    const grabbing = event.button === 0 && (options.pose?.grabbing() ?? false);
    const painting = event.button === 0 && (options.paint?.active() ?? false);
    const action = nav.press(event, view.nav, { taken: grabbing || painting });
    if (navigates(action)) return start('nav');
    if (grabbing) return;
    if (painting) {
      if (!options.paint!.down(view, x, y)) return;
      return start('paint');
    }
    // The left button boxes, from anywhere -- let go unmoved, a click that picks; the right, let go unmoved, the menu.
    if (action === 'box') start('box');
    else if (action === 'menu') {
      start('click');
      // The right button held may yet fly (Docs/navigation.md §7): moved, or a fly key pressed; let go, the menu as ever.
      const target = options.held ? walkTargetOf(view) : null;
      if (target && options.held) armFly(target, options.held, event);
    }
  }

  function onMove(event: PointerEvent): void {
    const { x, y } = local(event);
    if (!drag) {
      const index = viewAt(views.map((v) => v.rect), x, y);
      hovered = index;
      overView('model', index >= 0);
      // The cube's part under the pointer lit.
      const view = views[index];
      const c = view ? cubeRect(view.rect) : null;
      const over = view && c && inside(c, x, y) ? { box: c, x: x - c.x, y: y - c.y, direction: view.cam.direction(new THREE.Vector3()), up: view.cam.camera.up, orthographic: view.cam.projection === 'orthographic' } : null;
      const was = cubeHovered;
      cubeHovered = over ? index : -1;
      // The cube says what it does as the pointer comes onto it: on a laptop it is the numpad's views.
      const canvas = renderer?.domElement;
      if (canvas && (cubeHovered >= 0) !== (was >= 0)) canvas.title = cubeHovered >= 0 ? cubeTip() : '';
      if (cube.hover(over) || was !== cubeHovered) draw();
      options.paint?.hover(view && cubeHovered < 0 ? view : null, x, y);
      options.pose?.hover(view && cubeHovered < 0 ? view : null, height, x, y);
      return;
    }
    if (event.pointerId !== drag.id) return;
    if (drag.does === 'nav') {
      // Its button found up -- its release went elsewhere (a walk begun): the driver's drag is over, and so is this.
      if (!nav.move(event) && !nav.dragging) onCancel(event);
      return;
    }
    // A box, a click or a stroke whose button is no longer down: dropped where it is, never stuck to the hover.
    if ((event.buttons & buttonMask(drag.button)) === 0) return onCancel(event);
    if (drag.does === 'paint') {
      options.paint?.move(x, y);
      return;
    }
    if (!drag.moved && !pastSlop(x - drag.x, y - drag.y)) return;
    drag.moved = true;
    const view = views[drag.view];
    if (!view || drag.does !== 'box') return;
    const r = view.rect;
    const cx = Math.max(r.x, Math.min(r.x + r.width, x));
    const cy = Math.max(r.y, Math.min(r.y + r.height, y));
    boxEl.hidden = false;
    Object.assign(boxEl.style, { left: `${Math.min(drag.x, cx)}px`, top: `${Math.min(drag.y, cy)}px`, width: `${Math.abs(cx - drag.x)}px`, height: `${Math.abs(cy - drag.y)}px` });
  }

  function onUp(event: PointerEvent): void {
    if (!drag || event.pointerId !== drag.id) return;
    const d = drag;
    drag = null;
    if (host.hasPointerCapture?.(event.pointerId)) host.releasePointerCapture(event.pointerId);
    if (d.does === 'nav') return void nav.up(event);
    const view = views[d.view];
    if (!view) return;
    if (d.does === 'paint') return options.paint?.up();
    if (d.does === 'box' && d.moved) {
      boxEl.hidden = true;
      const { x, y } = local(event);
      const r = view.rect;
      const x1 = Math.max(r.x, Math.min(r.x + r.width, x));
      const y1 = Math.max(r.y, Math.min(r.y + r.height, y));
      options.box(insideBox(view, Math.min(d.x, x1), Math.min(d.y, y1), Math.max(d.x, x1), Math.max(d.y, y1)), boxHow(d.event, isMac()));
      return;
    }
    if (d.moved) return;
    // A press let go where it went down: a click -- the left picks, the right is the menu.
    if (d.button === 0) options.click(options.pose?.pick(view, d.x, d.y) ?? pickAt(view, d.x, d.y), clickHow(d.event, false, isMac()));
    else if (d.button === 2) options.menu(pickAt(view, d.x, d.y), event.clientX, event.clientY);
  }

  /** What a walk or a right-button flight asks of `view` (`../view/walker.ts`); null before the canvas is made. */
  function walkTargetOf(view: View): WalkTarget | null {
    const canvas = renderer?.domElement;
    if (!canvas) return null;
    return {
      cam: view.cam,
      element: canvas,
      cancel: () => dropDrag(),
      perspective: () => {
        if (view.cam.projection === 'perspective') return;
        view.autoOrtho = false;
        view.cam.setProjection('perspective');
      },
      // Put back on Esc: the pose and Auto Perspective's flag with it.
      saved: () => {
        const pose = view.cam.pose();
        const auto = view.autoOrtho;
        return () => {
          view.cam.setPose(pose);
          view.autoOrtho = auto;
        };
      },
      moved: () => {
        if (view.preset === 'free') view.cam.direction(freeDirection);
        render();
      },
      ended: () => {
        labels();
        options.changed();
        draw();
      },
    };
  }

  /** A press the browser took back (a gesture, a lost pointer): a box under way is dropped, never selected; a drag ends where it is. */
  /** Whatever drag is under way dropped where it is: a walk begins, whose window listeners take its release. */
  function dropDrag(): void {
    if (!drag) return;
    if (drag.does === 'paint') options.paint?.cancel();
    nav.cancel();
    if (host.hasPointerCapture?.(drag.id)) host.releasePointerCapture(drag.id);
    drag = null;
    boxEl.hidden = true;
  }

  function onCancel(event: PointerEvent): void {
    if (!drag || event.pointerId !== drag.id) return;
    if (drag.does === 'paint') options.paint?.cancel();
    if (drag.does === 'nav') nav.cancel();
    drag = null;
    boxEl.hidden = true;
    if (host.hasPointerCapture?.(event.pointerId)) host.releasePointerCapture(event.pointerId);
  }

  const middle = new THREE.Vector3();
  const box3 = new THREE.Box3();
  /** The parts whose middles -- their bounds' centres, as the view sees them -- are inside the box (`marquee.ts`' rule). */
  function insideBox(view: View, x0: number, y0: number, x1: number, y1: number): THREE.Object3D[] {
    view.cam.update();
    const found: THREE.Object3D[] = [];
    for (const object of options.pickable()) {
      box3.setFromObject(object);
      if (box3.isEmpty()) continue;
      box3.getCenter(middle).project(view.cam.camera);
      if (middle.z > 1) continue;
      const px = view.rect.x + ((middle.x + 1) / 2) * view.rect.width;
      const py = view.rect.y + ((1 - middle.y) / 2) * view.rect.height;
      if (px >= x0 && px <= x1 && py >= y0 && py <= y1) {
        const part = options.partOf(object);
        if (part && !found.includes(part)) found.push(part);
      }
    }
    return found;
  }

  function onWheel(event: WheelEvent): void {
    event.preventDefault();
    if (drag) return;
    const { x, y } = local(event);
    const view = views[viewAt(views.map((v) => v.rect), x, y)];
    if (view) nav.wheel(event, view.nav);
  }

  /** A right-click is the stage's own: the browser's menu never. */
  const onMenu = (event: MouseEvent): void => event.preventDefault();
  const onLeave = (): void => {
    hovered = -1;
    overView('model', false);
    options.pose?.hover(null, height, 0, 0);
    options.paint?.hover(null, 0, 0);
    if (cubeHovered >= 0) {
      cubeHovered = -1;
      cube.hover(null);
      draw();
    }
  };

  function listen(canvas: HTMLCanvasElement, on: boolean): void {
    const how = on ? 'addEventListener' : 'removeEventListener';
    canvas[how]('pointerdown', onDown as EventListener);
    canvas[how]('pointermove', onMove as EventListener);
    canvas[how]('pointerup', onUp as EventListener);
    canvas[how]('pointercancel', onCancel as EventListener);
    canvas[how]('pointerleave', onLeave);
    canvas[how]('contextmenu', onMenu as EventListener);
    canvas[how]('mousedown', noAutoscroll as EventListener);
    canvas[how]('wheel', onWheel as EventListener, { passive: false } as AddEventListenerOptions);
  }
  // A drag goes on past the canvas's edge: the host has the capture.
  host.addEventListener('pointermove', (event) => {
    if (drag && event.target !== renderer?.domElement) onMove(event);
  });
  host.addEventListener('pointerup', (event) => {
    if (drag && event.target !== renderer?.domElement) onUp(event);
  });
  host.addEventListener('pointercancel', (event) => {
    if (drag && event.target !== renderer?.domElement) onCancel(event);
  });

  // ---------------------------------------------------------------- the views turned

  /**
   * `view` looking from `along`: from an axis (`axis`: a key, a cone, an Alt+middle snap), orthographic with Auto
   * Perspective (Docs/navigation.md §3); from between them, back to perspective if an axis view had made it orthographic.
   */
  function lookAlong(view: View, along: Vec3, axis = presetOf(along) !== 'free', up?: Vec3): void {
    // Upright from an axis; between them (an Alt+middle drag's own turn), its own up -- upside down too.
    view.cam.lookFrom(along, axis ? undefined : up);
    if (axis && view.cam.projection === 'perspective' && loadPrefs().nav.autoPerspective) {
      view.cam.setProjection('orthographic');
      view.autoOrtho = true;
      options.changed();
    } else if (!axis) autoBack(view);
    view.cam.clip();
    if (view.preset === 'free') view.cam.direction(freeDirection);
    labels();
    draw();
  }

  /** Auto Perspective: orbited off the axis an axis view made orthographic -- perspective again, as Numpad5 swaps it. */
  function autoBack(view: View): void {
    if (!view.autoOrtho || view.cam.preset !== 'free') return;
    view.autoOrtho = false;
    view.cam.setProjection('perspective');
    labels();
    options.changed();
  }

  /** A numpad step on the key's view (Docs/navigation.md §3), then what follows any move. */
  function stepView(move: (view: View) => void): void {
    const view = keyView();
    if (!view) return;
    move(view);
    view.cam.clip();
    view.nav.moved();
  }

  function toggleProjection(index?: number): void {
    const view = index === undefined ? keyView() : views[index];
    if (!view) return;
    // Chosen: Auto Perspective leaves it be from now.
    view.autoOrtho = false;
    view.cam.toggleProjection();
    labels();
    options.changed();
    draw();
  }

  /** The model's bounds and the ground for them: what framing and the clip planes measure. */
  function measure(): void {
    bounds.makeEmpty();
    if (model) {
      model.updateMatrixWorld(true);
      bounds.setFromObject(model);
    }
    radius = bounds.isEmpty() ? 0.5 : Math.max(bounds.getBoundingSphere(new THREE.Sphere()).radius, 1e-3);
    const reach = bounds.isEmpty() ? 0 : Math.max(Math.abs(bounds.min.x), Math.abs(bounds.max.x), Math.abs(bounds.min.z), Math.abs(bounds.max.z));
    grid.fit(reach);
    bounds.getCenter(centre);
    for (const view of views) view.cam.rescale(radius, grid.reach, centre);
  }

  // ---------------------------------------------------------------- flying (D102)

  /** The keys that fly, and which way: W S ahead and back, A D left and right, Q E down and up. */
  const FLY: readonly (readonly [string, 'ahead' | 'side' | 'rise', 1 | -1])[] = [['KeyW', 'ahead', 1], ['KeyS', 'ahead', -1], ['KeyD', 'side', 1], ['KeyA', 'side', -1], ['KeyE', 'rise', 1], ['KeyQ', 'rise', -1]];
  let flying = 0;
  let flewAt = 0;
  let flyHeld: ((code: string) => boolean) | null = null;
  /** A frame of flight: the keys held read now, the view under the pointer moved for the time since the last; on while any is held. */
  function flyFrame(now: number): void {
    flying = 0;
    const held = flyHeld;
    if (!held || !visible) return;
    const way = { ahead: 0, side: 0, rise: 0 };
    for (const [code, axis, sign] of FLY) if (held(code)) way[axis] += sign;
    if (!FLY.some(([code]) => held(code))) {
      const view = keyView();
      if (view) options.paint?.rested(view);
      return;
    }
    const dt = Math.min(0.1, Math.max(0, (now - flewAt) / 1000));
    flewAt = now;
    const view = keyView();
    if (view) {
      view.cam.fly(way.ahead, way.side, way.rise, dt, held('ShiftLeft') || held('ShiftRight') ? 4 : 1);
      view.cam.clip();
      if (view.preset === 'free') view.cam.direction(freeDirection);
      render();
    }
    flying = requestAnimationFrame(flyFrame);
  }

  build(layout);

  return {
    get layout() {
      return layout;
    },
    setLayout(next) {
      if (next === layout) return;
      build(next);
      options.changed();
      draw();
    },
    get shading() {
      return shading.mode;
    },
    setShading(mode) {
      shading.setMode(mode);
      traceShading.setMode(mode);
      // A hull round a see-through model fills it: in wireframe the selection is its polygons in amber instead.
      outline.group.visible = mode !== 'wireframe' && traceGroup === null;
      draw();
    },
    get polygons() {
      return shading.hasPolygons;
    },
    get grid() {
      return gridOn;
    },
    setGrid(on) {
      gridOn = on;
      grid.group.visible = on;
      readout.hidden = !on;
      draw();
    },
    get gridLine() {
      return readout.textContent ?? '';
    },
    setVisible(show) {
      visible = show;
      if (!show) overView('model', false);
      if (show) {
        // Shown again: a context that could not be made is tried at once, its delays from the start.
        context.again();
        fit();
        draw();
      }
    },
    setModel(next, frame) {
      if (model) modelRoot.remove(model);
      if (next !== model) outline.clear();
      model = next;
      if (model) modelRoot.add(model);
      shading.setModel(model);
      measure();
      // Framed on an empty build -- New model's starter -- the cameras on the bare grid: the first geometry is framed.
      if (frame || (framedEmpty && !bounds.isEmpty())) {
        framedEmpty = bounds.isEmpty();
        for (const view of views) {
          view.cam.frame(bounds, radius);
          view.cam.lookFrom(view.preset === 'free' ? [freeDirection.x, freeDirection.y, freeDirection.z] : DIRECTIONS[view.preset]);
          view.cam.clip();
        }
      }
      readout.textContent = model ? gridReadoutOf() : '';
      readout.hidden = !gridOn || !model;
      labels();
      draw();
    },
    setPosed(posed) {
      shading.setPosed(posed);
      draw();
    },
    setTrace(group) {
      if (group === traceGroup) return;
      if (traceGroup) scene.remove(traceGroup);
      traceGroup = group;
      if (group) scene.add(group);
      const away = group !== null;
      modelRoot.visible = !away;
      overlayRoot.visible = !away;
      shading.setHidden(away);
      outline.group.visible = shading.mode !== 'wireframe' && !away;
      traceShading.setModel(group);
      draw();
    },
    setTracePolygons(nodes, find) {
      traceShading.setPolygons(nodes, find ? (node) => find(node) : null);
      draw();
    },
    setTraceAway(objects) {
      traceShading.setAway(objects);
    },
    overlayRoot,
    setPolygons(nodes, find) {
      shading.setPolygons(nodes, find ? (node) => find(node) : null);
      draw();
    },
    setOutline(objects) {
      outlined = objects;
      outline.set(objects);
      shading.setSelected(objects);
      draw();
    },
    setStats(rows) {
      statsBox.hidden = rows === null;
      if (rows) statsBox.replaceChildren(...rows.flatMap(([name, value]) => [el('span', undefined, name), el('span', 'ed-mo-stat', value)]));
      readout.classList.toggle('ed-mo-below', rows !== null);
    },
    frame(objects, all = false) {
      const target = new THREE.Box3();
      if (objects && objects.length > 0) for (const o of objects) target.union(new THREE.Box3().setFromObject(o));
      // A bone, an empty: a point -- framed with a quarter of the model round it.
      if (objects && objects.length > 0 && target.isEmpty()) for (const o of objects) target.expandByPoint(o.getWorldPosition(new THREE.Vector3()));
      const box = target.isEmpty() ? bounds : target;
      if (!box.isEmpty() && box.getSize(new THREE.Vector3()).length() < radius * 0.05) box.expandByScalar(radius * 0.25);
      for (const view of all ? views : [keyView()].filter((v): v is View => v !== undefined)) {
        view.cam.frame(box, radius);
        if (view.preset === 'free') view.cam.direction(freeDirection);
      }
      draw();
    },
    look(preset) {
      const view = keyView();
      if (view) lookAlong(view, DIRECTIONS[preset]);
    },
    flip() {
      const view = keyView();
      if (!view) return;
      // From an axis view the opposite one; from between them, half a turn round the pivot keeping the elevation (Numpad9).
      const d = view.cam.direction(new THREE.Vector3()).negate();
      if (presetOf([d.x, d.y, d.z]) === 'free') stepView((v) => v.cam.orbit(0.5, 0, 1));
      else lookAlong(view, [d.x, d.y, d.z]);
    },
    toggleProjection,
    orbitBy: (dx, dy) => stepView((view) => view.cam.orbit(dx, dy, 1, loadPrefs().nav.orbitSelection ? selectedMiddle() : null)),
    panBy: (dx, dy) => stepView((view) => view.cam.pan(-dx, dy, 1)),
    zoomBy: (scale) => stepView((view) => view.cam.zoom(scale)),
    draw,
    refit: soonFit,
    views: () => views.map((v) => viewLabel(v.cam.preset, v.cam.projection)),
    poses: () => views.map((v) => v.cam.pose()),
    setPoses(poses) {
      views.forEach((view, i) => {
        const pose = poses[i];
        if (pose) view.cam.setPose(pose);
        if (view.preset === 'free') view.cam.direction(freeDirection);
      });
      labels();
      draw();
    },
    get hovering() {
      return hovered >= 0;
    },
    snapshot() {
      if (!visible || width === 0 || height === 0 || !ensure()) return null;
      render();
      return renderer?.domElement ?? null;
    },
    scene,
    renderer: () => renderer,
    background,
    paintViews: () => views.map((v) => ({ cam: v.cam, rect: v.rect })),
    outlineGroup: outline.group,
    get radius() {
      return radius;
    },
    overlay: host,
    walk(held) {
      const view = keyView();
      const target = view ? walkTargetOf(view) : null;
      if (target) beginWalk(target, held);
    },
    arrowFly(held) {
      const view = keyView();
      if (view) arrowFly({ cam: view.cam, moved: () => view.nav.moved() }, held);
    },
    fly(held) {
      flyHeld = held;
      if (flying !== 0) return;
      flewAt = performance.now();
      flying = requestAnimationFrame(flyFrame);
    },
    dispose() {
      cancelAnimationFrame(queued);
      cancelAnimationFrame(fitting);
      cancelAnimationFrame(flying);
      resize.disconnect();
      styled.disconnect();
      outline.dispose();
      shading.dispose();
      traceShading.dispose();
      grid.dispose();
      cube.dispose();
      environment?.dispose();
      context.dispose();
      if (renderer) {
        listen(renderer.domElement, false);
        renderer.domElement.removeEventListener('webglcontextlost', onLost);
        renderer.dispose();
        // Three's dispose frees its objects, not the context: given back, or Chrome counts it until it is collected.
        renderer.forceContextLoss();
        renderer.domElement.remove();
        renderer = null;
      }
      cells.remove();
      boxEl.remove();
    },
  };

  function gridReadoutOf(): string {
    return gridReadout(grid.scale);
  }
}
