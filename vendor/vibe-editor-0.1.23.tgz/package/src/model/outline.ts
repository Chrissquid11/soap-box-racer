/**
 * The selection's outline in the Model tab (Docs/modeler.md M14; Vibe3D D29):
 * each selected part's meshes drawn again as an inverted hull -- pushed out
 * along its normals in screen space, back faces only -- so a fringe of the
 * editor's amber shows round its silhouette, the same weight at any zoom.
 *
 * - **Screen space**: the push is in pixels of the view being drawn
 *   (`setViewport`, before each view), so dollying in does not swell it into
 *   a slab.
 * - **Closed at hard edges**: a hull of a copy whose normals are averaged where
 *   positions meet -- a box's corners split per face would open the outline
 *   at every crease, and Gladius makes boxes. The copies are kept per geometry
 *   and dropped with the model; the model's own normals are untouched.
 * - **Depth-tested, writing none**: hidden where the part is behind another,
 *   and pushing nothing out of the way.
 * - **Not for what is not drawn**: a part hidden (or under one hidden) is not
 *   outlined -- a silhouette of nothing reads as a fault.
 * - **Skinned with its mesh**, so a pose (phase 4) carries it along.
 */
import * as THREE from 'three';
import { ACCENT } from '../overlays.ts';

/** The fringe, in CSS pixels. */
const OUTLINE_PX = 2.5;

const VERTEX = /* glsl */ `
  uniform float thickness;
  uniform vec2 viewportSize;
  #include <common>
  #include <skinning_pars_vertex>
  void main() {
    #include <skinbase_vertex>
    #include <beginnormal_vertex>
    #include <skinnormal_vertex>
    #include <begin_vertex>
    #include <skinning_vertex>
    vec4 clip = projectionMatrix * modelViewMatrix * vec4(transformed, 1.0);
    vec4 clipNormal = projectionMatrix * vec4(normalize(normalMatrix * objectNormal), 0.0);
    // A normal straight at the camera projects to nothing: no push, never a NaN across the triangle.
    float len = length(clipNormal.xy);
    vec2 direction = len > 1e-6 ? clipNormal.xy / len : vec2(0.0);
    // Clip space spans two on each axis: a pixel is worth more on the short one, or the fringe goes oval.
    vec2 perPixel = vec2(2.0) / viewportSize;
    clip.xy += direction * perPixel * thickness * clip.w;
    gl_Position = clip;
  }
`;

const FRAGMENT = /* glsl */ `
  uniform vec3 color;
  void main() { gl_FragColor = vec4(color, 1.0); }
`;

export class Outline {
  /** In the scene: a hull a selected mesh, placed where its mesh is. */
  readonly group = new THREE.Group();
  private readonly material = new THREE.ShaderMaterial({
    uniforms: {
      color: { value: new THREE.Color(ACCENT) },
      thickness: { value: OUTLINE_PX },
      viewportSize: { value: new THREE.Vector2(1, 1) },
    },
    vertexShader: VERTEX,
    fragmentShader: FRAGMENT,
    side: THREE.BackSide,
    depthTest: true,
    depthWrite: false,
  });
  /** The smoothed copies, by the geometry they copy. */
  private readonly copies = new Map<THREE.BufferGeometry, THREE.BufferGeometry>();
  /** Each hull and the mesh it outlines: placed again before a frame. */
  private hulls: { hull: THREE.Mesh; mesh: THREE.Mesh }[] = [];

  constructor() {
    this.group.name = 'model: selection outline';
  }

  /** Outline the meshes of these objects (each and everything under it); none for an empty list. */
  set(objects: readonly THREE.Object3D[]): void {
    for (const { hull } of this.hulls) this.group.remove(hull);
    this.hulls = [];
    const seen = new Set<THREE.Mesh>();
    for (const object of objects) {
      object.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (!mesh.isMesh || o.userData.modelOverlay || seen.has(mesh)) return;
        seen.add(mesh);
        const geometry = this.copyOf(mesh.geometry);
        let hull: THREE.Mesh;
        if ((mesh as THREE.SkinnedMesh).isSkinnedMesh) {
          const skinned = mesh as THREE.SkinnedMesh;
          const s = new THREE.SkinnedMesh(geometry, this.material);
          s.bind(skinned.skeleton, skinned.bindMatrix);
          s.frustumCulled = false;
          hull = s;
        } else hull = new THREE.Mesh(geometry, this.material);
        hull.matrixAutoUpdate = false;
        // After the model: the fringe is not drawn over by what is drawn later without testing against it.
        hull.renderOrder = 4;
        hull.raycast = () => {};
        this.group.add(hull);
        this.hulls.push({ hull, mesh });
      });
    }
  }

  /** Before a frame: each hull where its mesh is, and shown only while that mesh is drawn. */
  place(): void {
    for (const { hull, mesh } of this.hulls) {
      let seen = true;
      for (let o: THREE.Object3D | null = mesh; o && seen; o = o.parent) seen = o.visible;
      hull.visible = seen;
      if (!seen) continue;
      mesh.updateWorldMatrix(true, false);
      hull.matrix.copy(mesh.matrixWorld);
      hull.matrixWorld.copy(mesh.matrixWorld);
    }
  }

  /** The view about to be drawn, in CSS pixels: the fringe's width is in its pixels. */
  setViewport(width: number, height: number): void {
    (this.material.uniforms.viewportSize!.value as THREE.Vector2).set(Math.max(width, 1), Math.max(height, 1));
  }

  private copyOf(source: THREE.BufferGeometry): THREE.BufferGeometry {
    const cached = this.copies.get(source);
    if (cached) return cached;
    const geometry = source.clone();
    if (!geometry.getAttribute('normal')) geometry.computeVertexNormals();
    averageNormals(geometry);
    this.copies.set(source, geometry);
    return geometry;
  }

  /** A new model: the copies of the last one's geometry freed. */
  clear(): void {
    this.set([]);
    for (const copy of this.copies.values()) copy.dispose();
    this.copies.clear();
  }

  dispose(): void {
    this.clear();
    this.material.dispose();
  }
}

/** Normals averaged where positions meet (to a hundredth of a millimetre): a hull with no seams. */
export function averageNormals(geometry: THREE.BufferGeometry): void {
  const position = geometry.getAttribute('position');
  const normal = geometry.getAttribute('normal');
  if (!position || !normal) return;
  const sums = new Map<string, THREE.Vector3>();
  const key = (i: number): string => `${Math.round(position.getX(i) * 1e5)},${Math.round(position.getY(i) * 1e5)},${Math.round(position.getZ(i) * 1e5)}`;
  for (let i = 0; i < position.count; i++) {
    const k = key(i);
    const sum = sums.get(k);
    if (sum) sum.add(new THREE.Vector3(normal.getX(i), normal.getY(i), normal.getZ(i)));
    else sums.set(k, new THREE.Vector3(normal.getX(i), normal.getY(i), normal.getZ(i)));
  }
  for (let i = 0; i < position.count; i++) {
    const sum = sums.get(key(i));
    if (!sum || sum.lengthSq() < 1e-12) continue;
    const n = sum.clone().normalize();
    normal.setXYZ(i, n.x, n.y, n.z);
  }
  normal.needsUpdate = true;
}
