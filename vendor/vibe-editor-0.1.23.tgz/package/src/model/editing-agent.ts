/**
 * The Model tab's Parameters and Materials blocks as the studio's model tools work them (Docs/mcp.md M6): the blocks'
 * own steps -- a drag's preview and its let go into the record, Bake into the script's `params{}`, a material's let go
 * into its `material{}` -- each one step of the tab's undo (`script-steps.ts`), with no widget between. Made by
 * `editing.ts` from its parts; node-safe, so the page's model tools are tested through it (`model/model-tools.test.ts`).
 */
import type { ParamsAnswer, ParamSpec } from '@vibe/pipeline/assets-types';
import type { MaterialInfo } from './materials.ts';
import { overrideText, sayValue, valueOf, withoutParams, withParam } from './params.ts';
import { bakeDefaults, editMaterial, luaValue, type DeclaredMaterial, type MaterialField, type MaterialValue } from './script-edits.ts';
import type { ScriptSteps } from './script-steps.ts';

/** A material as the model tools read it: its fields as shown, whether the script declares it, the parts it draws. */
export interface MaterialFacts {
  name: string;
  declared: boolean;
  line: number | null;
  parts: string[];
  baseColor: [number, number, number];
  metallic: number;
  roughness: number;
  emissive: [number, number, number];
  alphaMode: string;
}

// ---------------------------------------------------------------- the blocks' steps, the tab's and the tools' one way

/** A parameter's step as the tab's history says it: set to a value (an override's text), or back to its default (undefined). */
export function paramLabel(spec: ParamSpec, to: string | undefined): string {
  return to === undefined ? `${spec.name} back to its default (${sayValue(spec.default)})` : `${spec.name} ${sayValue(spec.value)} → ${sayValue(valueOf(spec, to))}`;
}

/**
 * The Parameters block's let go: each value written to the record's `params` as one step of the tab's undo -- an
 * override's text, or undefined (or the default's own text): no override, as the block writes it. Its label, and
 * whether it was pushed. The block's commit and `model_params_set` both.
 */
export async function commitParams(steps: ScriptSteps, set: ReadonlyArray<{ spec: ParamSpec; text: string | undefined }>): Promise<{ label: string; pushed: boolean }> {
  const list = set.map(({ spec, text }) => ({ spec, to: text !== undefined && text === overrideText(spec, spec.default) ? undefined : text }));
  const label = list.length === 1
    ? paramLabel(list[0]!.spec, list[0]!.to)
    : `Parameters: ${list.map(({ spec, to }) => (to === undefined ? `${spec.name} back to its default` : `${spec.name} → ${sayValue(valueOf(spec, to))}`)).join(', ')}`;
  const pushed = await steps.options(label, (o) => list.reduce((acc, { spec, to }) => withParam(acc, spec.name, to), o));
  return { label, pushed };
}

/** What a bake did: the values baked, those skipped and why. */
export type Baked = ReturnType<typeof bakeDefaults>;

/**
 * The Parameters block's Bake: values written into the script's `params{}` defaults and their overrides cleared, as
 * one step (D45). `file` the script's name, for the label. Its label, whether it was pushed, and what was baked (null:
 * the script was not read). The block's Bake and `model_params_set`'s `bake` both.
 */
export async function bakeParams(steps: ScriptSteps, file: string, values: ReadonlyArray<{ spec: ParamSpec; value: number | string | boolean }>): Promise<{ label: string; pushed: boolean; result: Baked | null }> {
  const list = values.map(({ spec, value }) => ({ name: spec.name, type: spec.type, value }));
  const label = values.length === 1
    ? `Bake ${values[0]!.spec.name} ${sayValue(values[0]!.spec.default)} → ${sayValue(values[0]!.value)} into ${file}`
    : `Bake ${values.map((v) => v.spec.name).join(', ')} into ${file}`;
  let result: Baked | null = null;
  const pushed = await steps.both(label, (text) => {
    result = bakeDefaults(text, list);
    return result.baked.length > 0 ? result.text : { problem: result.skipped.map((x) => `${x.name}: ${x.why}`).join('; ') };
  }, (o) => withoutParams(o, result?.baked ?? []));
  return { label, pushed, result: result as Baked | null };
}

/**
 * The Materials block's let go: a declared material's fields written into its `material{}` as one step. `from`, the
 * one field's value before, said in the label as the block says it. Its label, whether it was pushed, and the edit's
 * refusal if it made one. The block's commit and `model_materials_set` both.
 */
export async function commitMaterial(steps: ScriptSteps, name: string, set: Readonly<Partial<Record<MaterialField, MaterialValue>>>, from?: string): Promise<{ label: string; pushed: boolean; problem: string | null }> {
  const words = (v: MaterialValue | undefined): string => (v === null || v === undefined ? 'removed' : typeof v === 'string' ? v : luaValue(v));
  const fields = Object.keys(set) as MaterialField[];
  const label = `${name} ${fields.map((f) => `${f}${from !== undefined && fields.length === 1 ? ` ${from}` : ''} → ${words(set[f])}`).join(', ')}`;
  let problem: string | null = null;
  const pushed = await steps.edit(label, (text) => {
    const r = editMaterial(text, name, set);
    if ('problem' in r) problem = r.problem;
    return 'text' in r ? r.text : r;
  });
  return { label, pushed, problem };
}

/** What the studio's model tools do through the Parameters and Materials blocks' own steps (Docs/mcp.md M6). */
export interface EditingAgent {
  /** `GET params` as last answered for the script open (read again first), or null: none open. */
  params(): Promise<ParamsAnswer | null>;
  /** A preview of these parameter values built and shown, as a drag shows it -- nothing written: null once shown, else why not. */
  preview(values: Readonly<Record<string, string>>): Promise<string | null>;
  /** The export shown again, a preview put away. */
  unpreview(): void;
  /**
   * Parameter values set, as the block's let go: written to the record's `params` (null: back to its default) as one
   * step of the tab's undo, exported once. `bake`: written into the script's `params{}` defaults instead, their
   * overrides cleared -- the block's Bake, one step. The step's label, or why nothing was written.
   */
  setParams(values: Readonly<Record<string, string | null>>, bake: boolean): Promise<{ label: string; baked: string[]; skipped: string[] } | { problem: string }>;
  /** The materials on the model shown, and those the script declares. */
  materials(): MaterialFacts[];
  /** A declared material's fields written into its `material{}`, as the block's let go: one step. Its label, or why not. */
  setMaterial(name: string, set: Readonly<Partial<Record<MaterialField, MaterialValue>>>): Promise<{ label: string } | { problem: string }>;
  /** Why nothing may be written here now, or null. */
  blocked(): string | null;
}

/** What the agent works through: `editing.ts`' own parts. */
export interface EditingAgentParts {
  steps: ScriptSteps;
  /** The script open, or null. */
  path(): string | null;
  /** Why nothing of this model may be written here, or null. */
  why(): string | null;
  /** `GET params` read again for the script open, and its last answer. */
  readParams(): Promise<void>;
  answer(): ParamsAnswer | null;
  /** The preview client, as a drag uses it: asked, waited for, stopped; its last error, and whether one is shown. */
  preview: {
    ask(path: string, params: Readonly<Record<string, string>>): void;
    idle(): Promise<void>;
    stop(): void;
    error(): string | null;
    clearError(): void;
    showing(): boolean;
  };
  /** The export shown again. */
  reshow(): void;
  /** After a step: the parameters read again, a preview not written put away. */
  settled(pushed: boolean): void;
  /** The materials of the model shown, and those the script declares. */
  materials(): readonly MaterialInfo[];
  declared(): ReadonlyMap<string, DeclaredMaterial>;
  drawMaterials(): void;
}

export function createEditingAgent(parts: EditingAgentParts): EditingAgent {
  const { steps } = parts;
  const agent: EditingAgent = {
    blocked: () => parts.why() ?? (steps.steps.busy() ? 'The Model tab is writing a change: try again in a moment' : null),
    async params() {
      const path = parts.path();
      if (!path) return null;
      await parts.readParams();
      return parts.answer();
    },
    async preview(values) {
      const path = parts.path();
      if (!path) return 'No model open';
      const blocked = parts.why();
      if (blocked) return blocked;
      for (const name of Object.keys(values)) if (!parts.answer()?.params?.some((p) => p.name === name)) return `${name} is no parameter of ${path.split('/').pop()}: model_params_get lists them`;
      parts.preview.clearError();
      parts.preview.ask(path, { ...values });
      await parts.preview.idle();
      const error = parts.preview.error();
      if (error !== null) return `the preview did not build: ${error}`;
      return parts.preview.showing() ? null : 'the preview was not shown (another model opened, or the export came first)';
    },
    unpreview() {
      if (!parts.preview.showing()) return;
      parts.preview.stop();
      parts.reshow();
    },
    async setParams(values, bake) {
      const path = parts.path();
      if (!path || steps.path !== path) return { problem: 'No model open' };
      const blocked = agent.blocked();
      if (blocked) return { problem: blocked };
      await parts.readParams();
      const answer = parts.answer();
      if (!answer?.ok || !answer.params) return { problem: answer?.error ?? answer?.problem ?? 'the script\'s parameters could not be read' };
      const specs = new Map(answer.params.map((p) => [p.name, p] as const));
      for (const [name, text] of Object.entries(values)) {
        const spec = specs.get(name);
        if (!spec) return { problem: `${name} is no parameter of ${path.split('/').pop()}: it has ${[...specs.keys()].join(', ') || 'none'}` };
        if (text === null) continue;
        const v = valueOf(spec, text);
        if ((spec.type === 'number' || spec.type === 'integer') && typeof v !== 'number') return { problem: `${name} is a ${spec.type}: "${text}" is none` };
        if (spec.type === 'integer' && !Number.isInteger(v)) return { problem: `${name} is a whole number: ${text} is not` };
        if (spec.type === 'boolean' && !['true', 'false', '1', '0'].includes(text)) return { problem: `${name} is true or false: "${text}" is neither` };
        if (spec.choices && !spec.choices.map(String).includes(String(v))) return { problem: `${name} is one of ${spec.choices.join(', ')}` };
      }
      const file = path.split('/').pop() ?? path;
      const names = Object.keys(values);
      if (names.length === 0) return { problem: 'No parameter given' };
      if (bake) {
        // The block's Bake: the values into params{}'s defaults, their overrides cleared -- one step.
        const { label, pushed, result } = await bakeParams(steps, file, names.map((n) => {
          const spec = specs.get(n)!;
          return { spec, value: values[n] === null ? spec.value : valueOf(spec, values[n]!) };
        }));
        parts.settled(pushed);
        if (!pushed || !result) return { problem: result && result.skipped.length > 0 ? result.skipped.map((x) => `${x.name}: ${x.why}`).join('; ') : 'not written: the status line says why' };
        return { label, baked: result.baked, skipped: result.skipped.map((x) => `${x.name} (${x.why})`) };
      }
      // As a drag: built as a preview, shown; let go, the block's commit -- one step -- exported once.
      const set = names.map((n) => {
        const spec = specs.get(n)!;
        return { spec, text: values[n] === null ? undefined : overrideText(spec, valueOf(spec, values[n]!)) };
      });
      const shown: Record<string, string> = {};
      for (const { spec, text } of set) if (text !== undefined) shown[spec.name] = text;
      if (Object.keys(shown).length > 0) await agent.preview(shown);
      const { label, pushed } = await commitParams(steps, set);
      parts.settled(pushed);
      if (!pushed) return { problem: 'not written: nothing changed, or the status line says why' };
      return { label, baked: [], skipped: [] };
    },
    materials() {
      const decl = parts.declared();
      const shown = parts.materials();
      const shownNames = new Set(shown.map((m) => m.name));
      const out: MaterialFacts[] = shown.map((m) => ({
        name: m.name,
        declared: decl.has(m.name),
        line: decl.get(m.name)?.line ?? null,
        parts: m.parts.map((p) => p.name),
        baseColor: m.baseColor,
        metallic: m.metallic,
        roughness: m.roughness,
        emissive: m.emissive,
        alphaMode: m.alphaMode,
      }));
      for (const d of decl.values()) if (!shownNames.has(d.name)) out.push({ name: d.name, declared: true, line: d.line, parts: [], baseColor: [1, 1, 1], metallic: 0, roughness: 1, emissive: [0, 0, 0], alphaMode: 'OPAQUE' });
      return out;
    },
    async setMaterial(name, set) {
      if (!parts.path()) return { problem: 'No model open' };
      const blocked = agent.blocked();
      if (blocked) return { problem: blocked };
      if (Object.keys(set).length === 0) return { problem: 'No field given' };
      const { label, pushed, problem } = await commitMaterial(steps, name, set);
      parts.drawMaterials();
      return pushed ? { label } : { problem: problem ?? 'not written: nothing changed, or the status line says why' };
    },
  };

  return agent;
}
