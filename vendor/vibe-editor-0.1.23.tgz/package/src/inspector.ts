/**
 * The entity tool's right-hand panel: the entity selected -- its name (its id,
 * prefab and phase on its hover), whether it is hidden or switched off, its layer and
 * its tags, a block a component, its labels, and the systems it is in -- or
 * every one of several at once. The blocks are `inspector-blocks.ts`,
 * `-transform.ts`, `-relations.ts` and `-state.ts`; what they do to the world
 * is the tool's (`InspectorHost`).
 *
 * - **Always there, docked on the right**: its header, `Inspector`, its lock
 *   and its fold, then the name of what is shown -- just the name, a click
 *   renames -- or, with nothing selected, "Nothing selected".
 * - **Locked** (the lock, `Alt+L`; `inspector-lock.ts`): it shows what it
 *   showed as it was locked, whatever is chosen since -- `host.selected()` is
 *   that, the tool's pin -- and every edit here is that one's; all of it
 *   gone, "Nothing selected (locked: it was removed)".
 * - **In this order**: the blocks' list (`blocks.ts`) -- Transform (with
 *   `WorldTransform` folded under it), Render, then the game's own components,
 *   a project's own blocks where their orders put them -- then its relations,
 *   and its systems; the name, the labels and the tags on the lines above. What the world keeps for
 *   itself (`internal`) is neither shown nor offered to add; nor are `Hidden`,
 *   `Disabled`, `Labels` and the tags as components: they have their own lines.
 *   Nor is `View`: the engine's own slot for what `Render` draws (Docs/render.md §1).
 * - **A system it left because a component is off** is listed, dimmed, with
 *   what is off -- `off: Health` (`world.outOf`); switched off itself, it is in
 *   none, and the list says so and by whom.
 * - **What the game will overwrite is said**: a system it is in that writes
 *   `Transform` is marked in the list and named under Transform -- an edit there
 *   lasts until the game runs.
 * - **Several selected are edited as one** (`multi.ts`): the title is how many
 *   and of what prefabs, and renames them all, numbered; a block for each
 *   component they all have, every field showing what they share or `—`; what
 *   only some have in a block of its own, "Only on 2 of 3", to add to the rest;
 *   a tag only some have "(some)"; relations every one is in; the systems any
 *   is in, with how many. Every edit is one step, `Set Spin.speed × 3`.
 */
import { type AnyComponent, type Component, Disabled, type Entity, label, madeFromText, membership, type Membership, Name, NONE, type Relation, Transform } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import { addComponentButton, adderState, shutAdder, type AdderState } from './add-component.ts';
import { offered } from './component-menu.ts';
import { textEdit } from './fields.ts';
import type { Mcp } from './mcp/declare.ts';
import { BUILT_IN_BLOCKS, foldable, type Blocks } from './inspector-blocks.ts';
import { blocksFor, onlySome, type BlockItem } from './blocks.ts';
import { relationBlocks } from './inspector-relations.ts';
import { stateLine } from './inspector-state.ts';
import { instanceLine, markOverrides, marksOf, type OverridesHost, type OverridesState } from './inspector-overrides.ts';
import { labelsState, openLabels, shutLabels, type LabelsState } from './labels-drop.ts';
import { createTransformBlocks, type TransformBlocks } from './inspector-transform.ts';
import { agreed, entities, onOf, tally, times } from './multi.ts';
import { renameAll as renameEach, setName } from './names.ts';
import { button, el, icon, lockButton, sidePanel } from './shell.ts';
import type { CameraHost } from './inspector-camera.ts';
import { REMOVED, type LockHost } from './inspector-lock.ts';
import { causeOf, type Switch } from './switches.ts';
import { shutTags, tagsState, type TagsState } from './tags-drop.ts';

/** Every entity's, shown on lines of their own (`inspector-state.ts`): never a block, nor offered to add. */

/** With several selected, the facts list this many ids; the rest are counted. */
const IDS = 6;

export interface InspectorHost {
  /** The entity shown first: the first selected, or NONE. */
  primary(): Entity;
  /** Every entity selected, the first first. */
  selected(): readonly Entity[];
  select(e: Entity): void;
  /** A structural edit has been queued: flushed, everything read again, one step of history called `label`. */
  changed(label: string): void;
  /** A value has been written in place: the frame drawn again, the panel left as it is. */
  redraw(): void;
  /** A value edit is done: one step of history called `label`. */
  commit(label: string): void;
  reparent(child: Entity, parent: Entity): void;
  duplicate(): void;
  destroy(): void;
  /** Hide or show, switch off or on, every one of `es`, as one step (`edits.toggle`). */
  toggle(which: Switch, es: readonly Entity[]): void;
  /** Pick the target of a new link of `relation` from every one selected; again to stop. */
  link(relation: Relation<any>): void;
  /** Pick whom every selected one's `component.field` -- a `ref()` -- points at; again to stop. */
  pickRef(component: Component, field: string): void;
  /**
   * What a pick of `e` would do -- a drop of it (`drop-target.ts`), through the pick's own write: every one shown
   * pointed at it (`component.field`) or linked to each of `targets` (`relation`), one step. Null if done, else why
   * not: itself alone, or one a typed ref cannot hold -- the pick's own refusals. None: no drop taken (a prefab's
   * own inspector, whose refs point inside it, not at the scene's entities).
   */
  dropRef?(component: Component, field: string, e: Entity): string | null;
  dropLink?(relation: Relation<any>, targets: readonly Entity[]): string | null;
  /** What a pick is under way for, or null: a relation's name, or a ref's `Component.field`. */
  readonly picking: string | null;
  /** A prefab opened to edit is shown (Docs/prefabs.md §7): its runtime fields dimmed, never written to it. */
  opened?(): boolean;
  /** The keys to the side this inspector is in (`EditorContext.focus`): an asset file dropped on a key field of it. */
  focus?(): void;
  /** A model's (or, `'Texture'`, a texture's) thumbnail for a key picker's row and field (`EditorContext.modelThumb`); left out, none. */
  thumb?(key: string, type?: 'Model' | 'Texture'): Promise<string | null>;
  /** An instance's overrides: marked, listed, reverted, applied, unpacked (`inspector-overrides.ts`). */
  readonly overrides?: OverridesHost;
  /** The blocks' list, sorted -- the editor's and a project's (`EditorContext.blocks`); the editor's alone when not said. */
  readonly blocks?: readonly BlockItem[];
  /** The right panel's lock (`EditorContext.lock`): its button in the header, beside the fold. */
  readonly lock?: LockHost;
  /** Locked, and every entity it pinned gone: the empty words say so. */
  removed?(): boolean;
  /** The editor's view, for the Camera block's Align buttons (`inspector-camera.ts`); left out, they do nothing. */
  readonly camera?: CameraHost;
}

export interface Inspector {
  /** Its card, on the right: a press in it gives the Scene tab's keys to the entities' side. */
  readonly panel: HTMLElement;
  /** Built again from the world: the selection changed, or what it has. */
  refresh(): void;
  /** The numbers read again in place, the one being typed in left alone: while the gizmo drags. */
  showValues(): void;
  /**
   * A step committed (an edit, a gizmo drag let go): what the instance shown
   * overrides worked out again, the panel built again only if its marks
   * differ -- the field that had the focus given it back.
   */
  checkMarks(): void;
  /** The title made the field to rename what is shown -- one, or all of several -- as a click on it does. */
  rename(): void;
  /** The focus in the labels' field, to add one to what is shown: "Add label…". */
  addLabel(): void;
  /** Is its tags drop-down down? Esc puts it up (`shut`), as the tool's `cancel`. */
  readonly dropped: boolean;
  shut(): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}

/** What `entityBlocks` is handed besides the blocks: what it keeps from one build to the next. */
export interface EntityParts {
  /** The Transform block's maker, which keeps the angles shown (`createTransformBlocks`). */
  transform: TransformBlocks;
  /** Which drop-down of the state line is down: kept across builds. */
  tags: TagsState;
  labels: LabelsState;
  /** Whether the Add Component card is open, kept across builds (`add-component.ts`). */
  adder: AdderState;
  /** The tool a pick in it is (`scene_component` when not said; a prefab's Root block's, `prefab_edit`). */
  addMcp?: Mcp;
  /** The blocks' list (`blocks.ts`): the editor's own when not said. */
  items?: readonly BlockItem[];
}

/** What an entity is made of, drawn: the state line, a block a component, and the adder. */
export interface EntityBlocks {
  /** The switches, the layer, the tags and the labels (`stateLine`). */
  state: HTMLElement;
  /** The list's blocks -- Transform, Render, the game's own as defined, a project's where their orders put them; of several, what only some have after. */
  components: HTMLElement[];
  /** "Add Component": what none -- or not every one -- of them has, by category and searched (`add-component.ts`). */
  adder: HTMLButtonElement;
}

/**
 * What every one of `es` is made of, as the Entities inspector draws it --
 * the state line, Transform, Render, a block a component, "Only on 2 of 3",
 * and the adder -- every edit through `blocks.host`. The Entities
 * inspector's, and the Assets tool's Root block's on a prefab's root in a
 * scratch world (`prefab-root-block.ts`): one drawing for both.
 */
export function entityBlocks(blocks: Blocks, es: readonly Entity[], parts: EntityParts): EntityBlocks {
  const { world, host } = blocks;
  const many = es.length;
  /** `component` on every one of `es` that has none: one step, `Add Spin × 2`. */
  const addTo = (component: AnyComponent): void => {
    const without = es.filter((e) => !world.has(e, component));
    for (const e of without) world.add(e, component);
    host.changed(times(`Add ${component.name}`, without.length));
  };

  /** Of several, what only some have, by how many: "Only on 2 of 3", each with the way to put it on the rest. */
  const someBlock = (count: number, components: readonly AnyComponent[]): HTMLElement => {
    const section = el('div', 'ed-component ed-some');
    section.append(el('div', 'ed-component-head', `Only on ${count} of ${es.length}`));
    for (const component of components) {
      const line = el('div', 'ed-line');
      line.append(el('span', 'ed-some-name', component.name));
      line.append(button('scene_component', 'Add to all', `Add ${component.name} to the ${es.length - count} without it`, () => addTo(component), 'ed-quiet'));
      section.append(line);
    }
    return section;
  };

  // The Add Component button (`add-component.ts`): what not every one has, by category, searched -- never a relation
  // (Link with…), a tag, the world's own, View or a switch (`component-menu.ts`' `offered`).
  const adder = addComponentButton(parts.adder, { entries: () => offered(world, es), add: addTo, many, mcp: parts.addMcp ?? 'scene_component' });

  // The list's blocks, of what every one has: the engine's own first, each its own way; then the game's, as defined, and a
  // project's where their orders put them (`blocks.ts`). No Name block: the title is the name, and a click on it renames.
  const made: Blocks = { ...blocks, transform: parts.transform };
  const components = blocksFor(world, es, parts.items ?? BUILT_IN_BLOCKS).map(({ item, component }) => item.make(made, es, component));
  // Of several, what only some have, by how many have it (View never: Render says how each is drawn).
  for (const [count, some] of onlySome(world, es)) components.push(someBlock(count, some));
  return { state: stateLine(blocks, es, parts.tags, parts.labels), components, adder };
}

export function createInspector(root: HTMLElement, game: Game, host: InspectorHost): Inspector {
  const world = game.world;
  const panel = el('div', 'ed-card ed-side ed-right ed-inspector');
  root.append(panel);
  // Its left edge drags it wider, and it folds away to the right: both kept for next time.
  const side = sidePanel(root, panel, 'right', { name: 'Inspector' });
  let visible = true;
  /** What `showValues` reads again: one updater a field. */
  let live: (() => void)[] = [];
  const blocks: Blocks = {
    world,
    host,
    live: (update) => void live.push(update),
    wrote() {
      host.redraw();
      showValues();
    },
  };
  const transform = createTransformBlocks(blocks, () => refresh());
  const names = (): { value: unknown[] } => world.rawStore(Name) as { value: unknown[] };
  /** `e`'s name as kept, or '' for none. */
  const nameOf = (e: Entity): string => (world.has(e, Name) ? String(names().value[e] ?? '') : '');

  /** The name typed (`names.ts`, the tools' path too): `Name` written, added if there is none; an empty one takes it off. */
  function rename(e: Entity, text: string): void {
    if (setName(world, e, text)) host.changed('Rename');
    else refresh();
  }

  /** One name typed for several: each its own, numbered in the selection's order -- `wall`, `wall 2` -- one step; empty takes every one's off. */
  function renameAll(es: readonly Entity[], text: string): void {
    if (renameEach(world, es, text)) host.changed(times('Rename', es.length));
    else refresh();
  }

  /** The title of what is shown, while it is a title and not the field renaming it. */
  let titleLine: HTMLElement | null = null;
  /** Whether the labels drop-down is down, and its field typed in: kept across the panel being built again. */
  const labels = labelsState(root);
  /** Whether the tags drop-down is down: kept across the panel being built again after each tick. */
  const tags = tagsState(root);
  /** Whether the Add Component card is open: kept across the panel being built again. */
  const adder = adderState(root);
  /** Whether the Overrides list is open, and Apply all's prefab: kept across the panel being built again. */
  const overrides: OverridesState = { open: false, target: new Map() };
  /** What the marks shown say (`marksOf`): a step that leaves them so leaves the panel. */
  let marksShown = '';

  /** The name as the panel's title: a click makes it the field that renames it -- Enter commits, Esc cancels. */
  function title(e: Entity, facts: string): HTMLElement {
    const line = el('div', 'ed-side-title ed-name-edit ed-inspector-name', label(world, e));
    line.title = `${facts}\nClick to rename`;
    // mcp: scene_rename -- the name made the field to rename the entity
    line.addEventListener('click', () => {
      if (!line.isConnected) return;
      titleLine = null;
      const form = textEdit({
        value: world.has(e, Name) ? String(names().value[e] ?? '') : '',
        placeholder: `${madeFromText(world, e)} ${e}`,
        commit: (text) => rename(e, text),
        cancel: refresh,
      });
      line.replaceWith(form);
    });
    titleLine = line;
    return line;
  }

  /** Several: how many, as the title; a click names them all, numbered. What they are called already, if they share it, to start from. */
  function titleMany(es: readonly Entity[], facts: string): HTMLElement {
    const line = el('div', 'ed-side-title ed-name-edit ed-inspector-name', entities(es.length));
    line.title = `${facts}\nClick to name them all: numbered in the order selected -- wall, wall 2, wall 3`;
    // mcp: scene_rename -- the field to name them all
    line.addEventListener('click', () => {
      if (!line.isConnected) return;
      titleLine = null;
      const shared = agreed(es.map(nameOf)) ?? '';
      const form = textEdit({
        value: shared,
        placeholder: `A name for all ${es.length}, numbered`,
        // Left as it began -- a blur, an Enter on nothing typed -- is no rename: their own names stay.
        commit: (text) => (text.trim() === shared ? refresh() : renameAll(es, text)),
        cancel: refresh,
      });
      line.replaceWith(form);
    });
    titleLine = line;
    return line;
  }

  /**
   * Taking the old panel away can take the focus from a field in it, and its
   * blur commit an edit that reads everything again: that edit is in the world
   * by the time this one reads it, so the second build is not needed.
   */
  let building = false;

  /**
   * The inputs typed in and not entered yet: a person's `input` (never a value
   * the code set), until the field commits it (`change`). Only their text is
   * given back by a build; a field merely focused shows what the build put
   * in -- the value an undo, a live update or a landing brought.
   */
  const typed = new WeakSet<HTMLInputElement | HTMLTextAreaElement>();
  // A text area too: a data component's multiline string (`inspector-data.ts`).
  const typable = (x: EventTarget | null): x is HTMLInputElement | HTMLTextAreaElement => x instanceof HTMLInputElement || (typeof HTMLTextAreaElement !== 'undefined' && x instanceof HTMLTextAreaElement);
  panel.addEventListener('input', (event) => {
    if (typable(event.target)) typed.add(event.target);
  }, true);
  panel.addEventListener('change', (event) => {
    if (typable(event.target)) typed.delete(event.target);
  }, true);

  /**
   * The field focused, by what it shows (`data-field`) and which of its
   * inputs, with its caret, and its text if it is being typed in: what a
   * build gives back -- a live update landing mid-typing, a step's marks
   * changing -- so the typing goes on where it was. Null for none.
   */
  function typing(): { key: string; nth: number; text: string | null; start: number | null; end: number | null } | null {
    const focused = typable(document.activeElement) && panel.contains(document.activeElement) ? document.activeElement : null;
    const holder = focused?.closest<HTMLElement>('[data-field]') ?? null;
    if (!focused || !holder) return null;
    return {
      key: holder.dataset.field!, nth: [...holder.querySelectorAll('input, textarea')].indexOf(focused),
      text: typed.has(focused) ? focused.value : null, start: focused.selectionStart, end: focused.selectionEnd,
    };
  }

  function giveBack(was: NonNullable<ReturnType<typeof typing>>): void {
    const again = [...panel.querySelectorAll<HTMLElement>('[data-field]')].find((x) => x.dataset.field === was.key)?.querySelectorAll<HTMLInputElement | HTMLTextAreaElement>('input, textarea')[Math.max(0, was.nth)];
    if (!again) return;
    // What was typed and not yet entered stays typed: Enter still commits it. Nothing typed: the new value shows.
    if (was.text !== null) {
      if (again.value !== was.text) again.value = was.text;
      typed.add(again);
    }
    again.focus();
    try {
      if (was.start !== null) again.setSelectionRange(was.start, was.end ?? was.start);
    } catch {
      // An input that keeps no caret (a number's): the focus is enough.
    }
  }

  function refresh(): void {
    if (building) return;
    const was = typing();
    const shown = host.selected().join(' ');
    building = true;
    try {
      build();
    } finally {
      building = false;
    }
    // Only to the same entities: another's field of the same name is not the one typed in.
    if (was && host.selected().join(' ') === shown) giveBack(was);
  }

  /** The panel's header, always there: `Inspector`, the lock, and the control that folds it away. */
  function header(): HTMLElement {
    const bar = el('div', 'ed-panel-head ed-panel-bar');
    bar.append(el('div', 'ed-side-title', 'Inspector'), ...(host.lock ? [lockButton(host.lock).button] : []), side.fold);
    return bar;
  }

  function build(): void {
    panel.replaceChildren();
    live = [];
    titleLine = null;
    const es = host.selected();
    const e = es[0] ?? NONE;
    // Docked on the right whatever is selected: with nothing, its header and a quiet line.
    panel.hidden = !visible;
    panel.append(header());
    if (e === NONE) {
      panel.append(el('div', 'ed-dim ed-nothing', host.removed?.() ? `Nothing selected ${REMOVED}` : 'Nothing selected'));
      shutTags(tags);
      shutAdder(adder);
      return shutLabels(labels);
    }
    const many = es.length;

    // Just the name -- of several, how many -- what it is on its hover: the ids, the prefab, the phase.
    let facts: string;
    if (many > 1) {
      const ids = es.slice(0, IDS).map((x) => `#${x}`).join(' ') + (many > IDS ? ` +${many - IDS}` : '');
      facts = `${tally(es.map((x) => madeFromText(world, x)))} · ${ids}\n`
        + 'Edits here are every one\'s, one step each; the gizmo moves, turns and scales them all about the first; D copies the first; Delete destroys them all';
    } else {
      // Its index, the prefab it is an instance of -- and which entity of it, inside one -- or entity for none, and the
      // slot its index decides: the tick of each system's period it runs on.
      facts = `#${e} · ${madeFromText(world, e)} · phase ${e % 60} (the tick of each system's period it runs on)`;
    }
    const top = el('div', 'ed-panel-head');
    top.append(many > 1 ? titleMany(es, facts) : title(e, facts));
    const made = entityBlocks(blocks, es, { transform, tags, labels, adder, ...(host.blocks ? { items: host.blocks } : {}) });
    panel.append(top, made.state);
    // An entity of an instance: its prefab, and on its root the Overrides list -- worked out now, never kept.
    const instance = many === 1 && host.overrides ? host.overrides.of(e) : null;
    marksShown = marksOf(instance);
    if (instance && host.overrides) panel.append(instanceLine(world, e, instance, host.overrides, overrides, refresh));

    // Where it hangs is the tree's to show, and Unparent the tree's and the menu's: not here.

    // The systems each is in, and which of them write its Transform: marked in the list.
    const memberships = es.map((x) => membership(world, x));
    const writes = new Map(world.systemInfo().map((info) => [info.name, info.writes]));
    const writer = (m: Membership): boolean => writes.get(m.system)?.includes(Transform.name) ?? false;

    panel.append(...made.components, ...relationBlocks(blocks, es));
    // Duplicate and Destroy are the tree's, the menu's and the keys': not here as well. Add Component goes under the
    // blocks it adds to, full width, as Unity's; the systems after.
    const actions = el('div', 'ed-line ed-addc-line');
    actions.append(made.adder);
    panel.append(actions, systemsBlock(es, memberships, writer));
    // Every block folds, kept by its name for every entity to come: the editor's folds, no prefix.
    foldable(panel, '');
    // What it changes from its prefab, marked where it is shown.
    if (instance && host.overrides) markOverrides(panel, world, e, instance, host.overrides);
  }

  /**
   * The systems any of `es` is in, in the order they run, each with when it
   * runs them -- the slots they are in -- and, of several, how many are in it.
   */
  function systemsBlock(es: readonly Entity[], memberships: readonly Membership[][], writer: (m: Membership) => boolean): HTMLElement {
    const many = es.length;
    const systems = el('div', 'ed-component');
    systems.append(el('div', 'ed-component-head', 'Systems'));
    const order = world.loop.info().map((info) => info.name);
    const by = new Map<string, { m: Membership; slots: Set<number>; count: number }>();
    for (const list of memberships) {
      for (const m of list) {
        const seen = by.get(m.system) ?? { m, slots: new Set<number>(), count: 0 };
        seen.slots.add(m.slot);
        seen.count++;
        by.set(m.system, seen);
      }
    }
    const listed = [...by.values()].sort((a, b) => order.indexOf(a.m.system) - order.indexOf(b.m.system));
    for (const { m, slots, count } of listed) {
      const sorted = [...slots].sort((a, b) => a - b);
      const at = sorted.length === 1 ? `slot ${sorted[0]}` : sorted.length <= 4 ? `slots ${sorted.join(', ')}` : `${sorted.length} slots`;
      const when = m.rate === 0 ? 'every frame' : m.period === 1 ? '60 Hz · every tick' : `${m.rate} Hz · ${at} of ${m.period}`;
      const line = el('div', 'ed-line');
      const name = el('span', 'ed-system', m.system);
      if (writer(m)) {
        const mark = el('span', 'ed-writes');
        mark.append(icon('warn'), el('span', undefined, 'writes Transform'));
        mark.title = many > 1
          ? `${m.system} writes the Transform of ${count === many ? `all ${many}` : `${count} of them`} when the game runs: an edit to it here lasts until then`
          : `${m.system} writes this entity's Transform when the game runs: an edit to it here lasts until then`;
        name.append(mark);
      }
      line.append(name, el('span', 'ed-dim', count < many ? `${when} · ${onOf(count, many)}` : when));
      systems.append(line);
    }
    // Left because a component is off: what they would be in, dimmed, and what is off.
    const left = new Map<string, { off: Set<string>; count: number }>();
    for (const x of es) {
      for (const { system, off } of world.outOf(x)) {
        const seen = left.get(system) ?? { off: new Set<string>(), count: 0 };
        for (const c of off) seen.off.add(c.name);
        seen.count++;
        left.set(system, seen);
      }
    }
    for (const system of order.filter((name) => left.has(name))) {
      const { off, count } = left.get(system)!;
      const line = el('div', 'ed-line ed-left-system');
      const names = [...off].join(', ');
      line.title = `${system} would have ${count === many ? (many > 1 ? 'them' : 'it') : `${count} of them`}, but ${names} ${off.size > 1 ? 'are' : 'is'} switched off`;
      line.append(el('span', 'ed-system', system), el('span', 'ed-dim', `off: ${names}${count < many ? ` · ${onOf(count, many)}` : ''}`));
      systems.append(line);
    }
    // Switched off itself, or under one that is: in none, and by whom.
    const out = es.filter((x) => !world.active(x));
    if (out.length > 0) {
      const by = many === 1 ? causeOf(world, es[0]!, Disabled) : NONE;
      // A system that takes the switched-off (`includeDisabled`) still has them: listed above.
      const none = listed.length > 0 ? 'in no system but those above, which take the switched-off' : 'in no system';
      const said = many > 1 ? `${out.length} of ${many} switched off: ${none}` : `Switched off${by !== NONE && by !== es[0] ? ` by ${label(world, by)}` : ''}: ${none}`;
      systems.append(el('div', 'ed-dim ed-out-note', said));
    } else if (listed.length === 0 && left.size === 0) {
      systems.append(el('div', 'ed-dim', many > 1 ? 'None in any system.' : 'In no system.'));
    }
    return systems;
  }

  function showValues(): void {
    if (host.primary() === NONE) return;
    for (const update of live) update();
  }

  function checkMarks(): void {
    const es = host.selected();
    if (panel.hidden || es.length !== 1 || !host.overrides || building) return;
    if (marksOf(host.overrides.of(es[0]!)) === marksShown) return;
    // The field typed in given back once built again (`refresh`).
    refresh();
  }

  return {
    panel,
    refresh,
    showValues,
    checkMarks,
    rename: () => titleLine?.click(),
    addLabel() {
      if (side.folded) side.setFolded(false);
      shutTags(tags);
      openLabels(labels);
      refresh();
    },
    get dropped() {
      return tags.open !== null || labels.open !== null || adder.card !== null;
    },
    shut: () => {
      shutTags(tags);
      shutLabels(labels);
      shutAdder(adder);
    },
    setVisible(show) {
      visible = show;
      panel.hidden = !show;
      if (!show) {
        shutTags(tags);
        shutLabels(labels);
        shutAdder(adder);
      } else side.refresh();
    },
    dispose() {
      shutTags(tags);
      shutLabels(labels);
      shutAdder(adder);
      side.dispose();
      panel.remove();
    },
  };
}
