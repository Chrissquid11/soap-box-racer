/**
 * The tags of one entity or several, as a control (Docs/ecs.md §13): a button
 * that says which they have -- "None", the one, or the first and how many
 * more, "Wanderer +2" (`dropText`) -- and
 * drops down every tag the game defines with a tick each: on all, on some
 * (half), on none. A tick toggles it for every one, one step, and the list
 * stays down until a press elsewhere. The inspector's state line has one
 * (`inspector-state.ts`), and so has every row of the tree (`tree.ts`): the
 * one place to set what systems query by.
 *
 * - **The list floats over the editor**, in its root, under the button
 *   (`drop.ts`' `dropUnder`, which the tree's column chooser uses too): a tree row and a
 *   side card cut off whatever is inside them.
 * - **It outlives its button**: the inspector is built again after each tick,
 *   and a tree row as the list scrolls. `TagsState`, kept by the place, says
 *   which of its buttons is down, and that button, built again, shows the list
 *   again under itself.
 * - **Cheap until dropped down**: a button reads only what it says; the ticks
 *   are made as the list is shown.
 */
import { type Entity, type World } from '@vibe/engine';
import { dropUnder } from './drop.ts';
import { times } from './multi.ts';
import { control, el } from './shell.ts';

/** What the control edits with: the world, and the tool's way of making an edit one step. */
export interface TagsHost {
  readonly world: World;
  /** A structural edit has been made: flushed, everything read again, one step of history called `label`. */
  changed(label: string): void;
}

/** A place's drop-downs -- the inspector's one, the tree's one a row: which is down, kept as their buttons are built again. */
export interface TagsState {
  /** Where the list floats: the editor's root. */
  readonly root: HTMLElement;
  /** The one down -- a tree row's entity, 0 for a place with one -- or null. */
  open: number | null;
  /** Takes the list on screen away; null while none is. */
  shown: (() => void) | null;
}

export const tagsState = (root: HTMLElement): TagsState => ({ root, open: null, shown: null });

/** Up again, none down: a press elsewhere, the panel hidden, nothing selected. */
export function shutTags(state: TagsState): void {
  state.open = null;
  state.shown?.();
  state.shown = null;
}

/**
 * What a drop-down's button says of a list of names -- those every one has,
 * then those only some have: "None"; the one; or the first and how many more,
 * "seat +2". A first only some have says so. The whole list is its title.
 */
export function dropText(on: readonly string[], some: readonly string[]): { text: string; more: string; all: string } {
  const all = [...on, ...some.map((name) => `${name} (some)`)];
  if (all.length === 0) return { text: 'None', more: '', all: '' };
  return { text: all[0]!, more: all.length > 1 ? `+${all.length - 1}` : '', all: all.join(', ') };
}

/** A drop-down's button: what `dropText` says, then the mark that it drops down. */
export function dropButton(said: { text: string; more: string; all: string }, title: string): HTMLButtonElement {
  const button = control('ui', said.all ? 'ed-tags-drop' : 'ed-tags-drop ed-none');
  button.title = title;
  button.setAttribute('aria-haspopup', 'true');
  button.setAttribute('aria-expanded', 'false');
  button.append(el('span', 'ed-tags-text', said.text));
  if (said.more) button.append(el('span', 'ed-tags-more', said.more));
  button.append(el('span', 'ed-tags-mark'));
  return button;
}

// `tagsOf` lives in `switches.ts` (no DOM: the studio's page tools ask it too); said from here as ever.
import { tagsOf } from './switches.ts';
export { tagsOf };

export interface TagsOptions {
  /** Which of the state's buttons this is: a tree row's entity. 0, the default, for a place with one. */
  at?: number;
  /** Whose tags the button says, if not those it edits: a tree row's own, while its list is the whole selection's. */
  shows?: readonly Entity[];
}

/**
 * The control for `es`: its button, and the list it drops down -- put on the
 * screen by the control itself, under the button. Null when the game defines
 * no tags.
 */
export function tagsDrop(
  host: TagsHost,
  es: readonly Entity[],
  state: TagsState,
  { at = 0, shows = es }: TagsOptions = {},
): { button: HTMLButtonElement; list: HTMLElement } | null {
  const { world } = host;
  const tags = tagsOf(world);
  if (tags.length === 0) return null;
  const many = es.length;

  // What it says: the tags every one shown has, then those only some have.
  const on: string[] = [];
  const some: string[] = [];
  for (const tag of tags) {
    let n = 0;
    for (const e of shows) if (world.has(e, tag)) n++;
    if (n > 0 && n === shows.length) on.push(tag.name);
    else if (n > 0) some.push(tag.name);
  }
  const said = dropText(on, some);
  const button = dropButton(said, `${said.all || 'No tags'} · every tag the game defines, a tick each: tick to put one on${many > 1 ? ` all ${many} selected` : ''}, untick to take it off`);

  const list = el('div', 'ed-card ed-menu ed-ticks');
  /** The ticks, as the world is now. */
  const fill = (): void => {
    list.replaceChildren(el('div', 'ed-menu-title', many > 1 ? `Tags · all ${many}` : 'Tags'));
    for (const tag of tags) {
      const count = es.filter((e) => world.has(e, tag)).length;
      const row = el('label', 'ed-menu-item ed-tick');
      const box = el('input');
      box.type = 'checkbox';
      box.checked = count === many;
      box.indeterminate = count > 0 && count < many;
      box.title = count === many ? (many > 1 ? `On all ${many}` : 'On') : count > 0 ? `On ${count} of ${many}: a tick puts it on all` : many > 1 ? `A tick puts it on all ${many}` : 'A tick puts it on';
      box.addEventListener('change', () => {
        if (box.checked) {
          for (const e of es) if (!world.has(e, tag)) world.add(e, tag);
          host.changed(times(`Add ${tag.name}`, many - count));
        } else {
          for (const e of es) if (world.has(e, tag)) world.remove(e, tag);
          host.changed(times(`Remove ${tag.name}`, count));
        }
      });
      row.append(box, el('span', 'ed-tick-name', tag.name));
      if (count > 0 && count < many) row.append(el('span', 'ed-dim ed-count', `${count} of ${many}`));
      list.append(row);
    }
  };
  const show = (): void => {
    fill();
    state.shown = dropUnder(state.root, button, list, () => shutTags(state));
  };

  // mcp: ui -- the tags list opened
  button.addEventListener('click', () => {
    const was = state.open === at;
    shutTags(state);
    if (was) return;
    state.open = at;
    show();
  });
  // Down already, from the button this one replaces: that one's list goes now, and this one's comes once the button is in place.
  if (state.open === at) {
    state.shown?.();
    state.shown = null;
    queueMicrotask(() => {
      if (state.open === at && !state.shown && button.isConnected) show();
    });
  }
  return { button, list };
}
