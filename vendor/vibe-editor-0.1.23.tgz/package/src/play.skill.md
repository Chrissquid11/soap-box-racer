---
skill: studio
title: Playtests and the view
when: Before running, pausing, stepping or stopping a playtest, keeping what changed in one, moving the editor's view, or taking an image of a view
covers:
  tools:
    - play_state
    - play_start
    - play_pause
    - play_step
    - play_stop
    - view_shot
    - view_get
    - view_set
    - view_focus
    - game_view_state
    - game_view_set
    - game_view_preset
order: 50
---
# Playtests and the view

A **playtest** runs the game in the studio from the world as it stands -- the scene open, edits nobody saved and
all -- and puts that world back when it stops. The person drives one with the play strip in the top bar and its
keys: `F5` (or `T`) plays, `F6` (or `P`) pauses with the editor over the game's world, `F10` steps one tick while
paused, `Shift+F5` (or Esc) stops. The `play_*` tools are those same four buttons. A playtest plays **docked** -- in
the scene's room between the editor's cards, which stay in sight but take no clicks while it runs -- unless Maximize
on Play is on: then it fills the window with every card hidden (`game_view_set`, below).

**Play shows the game.** Pressed on a tab that covers the scene -- the Config page, the Studio tab (any of its cards:
the Code card is the Studio page), the Model tab, a project tool's page (`page: true`) -- Play goes to the Scene tab
first; a tool with a side card over the scene (Tiles) stays. `play_start` does the same: it moves the person off the
page they are on, as their own F5 would, and `play_stop` takes them back. Stop goes back to the tab Play was pressed
on unless the tab was changed at all during the playtest (a round trip to Config and back included): then it stays
where it is. A paused playtest run on from such a tab goes to the scene again. Pause and Step move nothing, and cards
slid away (the key left of 1) stay away. `studio_state` says the tab up after either.

The **view** is the editor's camera onto the scene -- the person's own, moved by them as in Blender (the middle
button, the wheel, the numpad, walk -- Shift and the key left of 1), by `F` (frame the selection) and the view cube. The `view_*` tools read it, move it, and draw images of any view.

## The playtest

- **`play_state`** -- `none`, `running` (the game the player's, the editor hidden under it) or `paused` (the editor
  over the playtest's world); the loop's tick, the ticks and seconds since it began; and every change made while
  paused, each by an `id` and in words. It answers while one runs.
- **`play_start`** -- as `F5`: a playtest from the world as it is, or a paused one run on. Refused if one runs
  already.
- **`play_pause`** -- as `F6`: the game stops where it is, the editor over its world. Nothing is put back.
- **`play_step`** -- as `F10`, `n` times (1 by default, at most 600 -- ten seconds at 60 Hz): the paused game runs
  `n` ticks and pauses again. Only while paused.
- **`play_stop`** -- as `Shift+F5`, running or paused: the game stops, the world is put back as the playtest found
  it, and the editor's history as it was.

**While one runs**, the editor is the game's: every scene tool -- its reads too (`scene_query`, `scene_entity`,
`scene_describe`) -- `prefab_info`, the Model tab's tools (`model_info` too), `history_undo`, `history_redo` and the
project's own tools answer "A playtest is running in the studio". What still works: `studio_state`, `play_*`,
`view_*`, `history_list`, the asset writes (`asset_new` … `asset_export`, `material_set`, `prefab_edit`,
`model_adopt`) and every server tool (`asset_list`, `asset_info`, tests, code, git, jobs). To read the world as it
runs, pause it: `play_pause`, then `scene_query` and `scene_entity` ([the scene](scene.md)) read the game's world as
it stands.

**While paused**, the scene's reads and edits work on the playtest's world: each edit is a step (`history_undo`
works too), `view_shot` shows it, `play_step` runs it on a few ticks to see what follows. These edits are of the
playtest's world, which `play_stop` puts back -- unless they are kept. What would save that world or load another
over it is refused until the playtest stops ("a playtest is on: stop it first", "a playtest is paused -- Stop puts
the world back, then Mod+S saves the scene"):
`scene_save` (a prefab open's too), `scene_save_as`, `scene_open`, `scene_new`, `scene_import`, `scene_open_prefab`
and `scene_close_prefab`.

## Keeping what changed while paused

Stop offers what was changed while paused, as the person's dialog does (Keep all, Keep none, Keep ticked).
`play_stop`'s `keep` answers it with no dialog: `'all'`, `'none'`, or a list of the ids `play_state` gave. Left out,
the person's preference decides (Config ▸ Editor ▸ Preferences, "After a playtest": keep, drop, or ask -- then the
dialog is shown to them). What is kept lands on the world put back as **one step, "Kept from the playtest"**, that
`Z` undoes.

- Read `play_state` just before stopping: its ids are the changes as they stand now.
- Each `play_step` (and the person's `F10`) keeps the pause's edits for Stop and starts the pause's history afresh:
  an undo there would rewind the tick with it.
- An unknown id refuses the stop whole -- nothing stopped -- so a stale list never drops the wrong thing.
- If the person started the playtest, ask before stopping it, and before dropping what they changed.

There is no tool that presses the game's own keys: the person plays. You run, pause, step, look and stop.

## Looking: `view_shot`

An image of a view, drawn as the screen draws it; the person's view does not move.

- `target: 'scene'` (the default) -- the editor's scene view as the person sees it, with the grid, gizmo, outlines,
  the camera icons and shapes and the selected camera's frustum (`overlays: false` to leave them out).
- `target: 'camera'` with `camera` (a camera entity's ref or path) -- what that camera sees.
- `target: 'main'` -- the game's own view: every camera it draws through, laid out as the game lays them out (a
  split screen's too), with the HUD only while a playtest runs; otherwise the 3D world alone, as the answer says.
- `target: 'model'` -- the Model tab's views ([the Model tab](model.md)).

`width` and `height` in pixels (by default the view's own shape, about 1024 wide; at most 2048 on the long side,
smaller if the canvas holds less -- the answer says); `format` `webp` (the default) or `png`. A paused or stopped
world is drawn as it stands. Refused while the WebGL context is lost: look again once it is back.

Look when the look is the question -- a placement, a colour, what a camera frames -- and say what you see.

## Moving the view

The editor's view is the person's: moving it moves what they are looking at, and it is **no step** -- `Z` does not
bring the old view back. Move it when they ask to be shown something; `view_shot` looks without moving it.

When you tell the person how to move it themselves, say it in their keymap (Config ▸ Preferences ▸ Navigation's
Keymap). **Industry Compatible**, the default: Alt+left-drag orbits, Alt+middle-drag pans, Alt+right-drag zooms; W E
R the gizmo's Move, Rotate, Scale; F1 F2 F3 front, right, top (Ctrl the opposite), F4 through the camera; F frames the
selection, A everything. **Blender**: middle-drag orbits, Shift pans, Ctrl zooms; G R S the gizmo; Numpad1 3 7 the
views, Numpad0 the camera; F frames the selection, Home everything. Under both the numpad works, the wheel zooms, the
right button held flies with W A S D, and the keys card (`?`) lists the live keys.

- **`view_get`** -- where the camera is and what it turns round, its projection (perspective with its field of
  view, or orthographic with the height it sees), the side it looks from (front, right, top … or free), the room
  past the editor's cards, the canvas's size. Read it first if the view should be put back after: `view_set` with
  its pose does it.
- **`view_set`** -- one of: `pose` `{ position: [x, y, z], target: [x, y, z] }` in metres; `numpad` `front`,
  `back`, `left`, `right`, `top` or `bottom` (as the numpad -- or F1 F2 F3 under Industry Compatible -- and the cube's
  cones, at the distance it has -- and, as they do with Auto Perspective on, orthographic; an orbit off the axis by the
  person brings perspective back);
  `projection` `perspective` or `orthographic` (as Numpad5). Answers the view after.
- **`view_focus`** -- frame `entities` (by ref or path), as `F` frames the selection, from the side it looks from
  now. The selection does not move.

## The game view: where the game is drawn

The game is drawn into a **frame**: in the studio, the scene's room between the editor's cards -- the editor's own
camera, a docked playtest's cameras, the game's HUD and its pointer all measure it -- or the whole window with the
cards put away (the key left of 1) or in a playtest maximized.

**Previewing a resolution** is a preset, chosen in the play strip's dropdown (Unity's Game view): Free Aspect (the
room as it is), the aspects `16:9`, `16:10`, `4:3`, `21:9`, `9:16`, the resolutions `1920×1080`, `1280×720`,
`640×360 Stretch`, `320×180 Pixel`, then the project's own. It shapes the frame while the game's own cameras draw --
a playtest running, or the dropdown's **Game** look, which shows the stopped or paused scene through them -- into the
largest box of its aspect, black bars round it. A pause without the Game look is the editor's camera filling the room,
for editing; with it, the game's cameras and the preset hold through the pause. **Fit** draws at the screen's sharpness; **Pixel** at exactly its resolution,
scaled by a whole number of the screen's device pixels, nearest; **Stretch** at exactly its resolution, scaled by any factor, nearest or linear.
The HUD is laid out in the box and drawn sharp in every mode; the pointer comes in the resolution's pixels. The
editor's own camera always fills the room. Only the editor previews: a release build is the window.

- **`game_view_state`** -- the frame (`x`, `y`, `width`, `height`, CSS pixels from the canvas's top left: the
  preset's box while it applies), the canvas's size, `fills` (`room` or `window`), `maximizeOnPlay`, `preset` and
  whether it `applies` now, `pixels` (the resolution the world is drawn at) and `scale` (device pixels per game pixel for Pixel and Stretch, 1 for Fit), `look` (`scene` or `game`),
  and every preset (`presets`, the project's marked `own`). Only reads; answers while a playtest runs.
- **`game_view_set`** -- any of: `preset` (a name as listed), `look` (`game` or `scene`, the dropdown's Game),
  `maximizeOnPlay` (`true`: a playtest fills the window, every card hidden; `false`: docked in the room, as the play
  strip's toggle and Config ▸ Preferences). The person's preferences, no step; a playtest running moves at once.
- **`game_view_preset`** -- one of the project's presets, by `name`: a new name with a `size` (`16:9` or `640x360`),
  `mode` (`fit`, `pixel`, `stretch`) and `filter` (`nearest`, `linear`) adds it, as the dropdown's Add…; an
  existing one is changed (`rename`, a new size or mode), moved (`move: -1` or `1`) or taken out (`remove: true`), as
  Config ▸ Game view. The built-ins stay as they are.

To see a resolution as the player will: `game_view_set` with `preset: '320×180 Pixel'` and `look: 'game'`, then
`view_shot` with target `main` -- the image is the box, bars excluded. A shot through the editor's view or a camera
entity is of the whole room at the screen's sharpness: the preset shapes only the game's own picture.

## Refusals, and what they mean

| The answer says | What to do |
|---|---|
| A playtest is running in the studio: play_pause pauses it …, play_stop stops it | pause or stop it (above), or wait; ask first if the person started it |
| A playtest is running already | `play_pause` pauses it, `play_stop` ends it |
| The playtest is paused already / No playtest runs: play_start begins one | read `play_state`, then decide |
| The playtest is running: play_pause first, then step it | `play_step` only steps a paused one |
| No playtest: play_start begins one, play_pause pauses it | `play_step` needs a paused playtest: start one, pause it, then step |
| No playtest to stop | `play_stop` with none on: nothing to do |
| n is a whole number of ticks, 1 to 600 | give `n` from 1 to 600 |
| keep is all, none, or a list of change ids | `keep` is `'all'`, `'none'` or ids from `play_state` |
| No change has the id … -- nothing was stopped | read `play_state` again and use its ids |
| Not started / Not paused / Not stopped: the editor did not take it -- a card or a question has its keys, or an Apply is landing | something of the person's is open: ask them, or try again in a moment |
| view_set takes one of pose, numpad or projection | give one per call |
| None of them is anywhere to frame | the entities have no transform or view: name others |
| the WebGL context is lost: look again once it is back | wait, then look again |

## A job, end to end

"The crate falls through the floor -- look at it."

1. `play_state` -- none. `studio_state` -- the scene is open, nothing unsaved worth worrying about.
2. `play_start`; then `play_pause` a moment later. `play_state` -- paused at tick 95.
3. `scene_query` with `name: 'crate'` -- ref 7; `scene_entity` on it -- its `Transform.py` is -3.2, below the floor.
4. `view_focus` on 7 if the person wants to see it, and `view_shot` to look; `play_step` with `n: 10` and look again
   to see it keep falling.
5. `play_stop` with `keep: 'none'` -- the world as it was before. Say what you saw, then fix the cause in the game's
   code or the prefab ([the assets](assets.md)), and playtest again.

## Rules that bite

- A playtest's world is put back at Stop: an edit made while paused is gone unless it is kept.
- Stopping drops what the person changed while paused unless kept: name what will go, or let their preference ask.
- `view_set` and `view_focus` move the person's view, with no undo: `view_shot` looks without moving it.
- The game's simulation is the game's: read it paused, change it in code, not by editing a running world.
