/**
 * Markdown, read into a tree and drawn as DOM: the Assets tool's preview of a
 * `.md` -- a README beside the art, a designer's notes (Docs/assets-tool.md
 * §6.2) -- and the agent's words in its transcript (Docs/agent.md §4), each as
 * a page, not as its source. Two halves, so node tests the first:
 *
 * - **`parseMarkdown(text)`** is pure: headings, paragraphs, `-` `*` `+` and
 *   numbered lists (nested by indent), fenced code, block quotes, rules,
 *   tables, and inline code, bold, italic, strikethrough, links and images.
 *   What it does not know it leaves as text.
 * - **`renderMarkdown(blocks, links)`** builds elements, never `innerHTML`:
 *   a file's text cannot bring markup or script with it. A link is kept only
 *   where `links.href` allows it (`http`, `https`, `mailto`, a relative path);
 *   an image is drawn only where `links.image` gives it an address -- the
 *   caller resolves a relative one through `GET file` beside the document.
 */

export type Inline =
  | { kind: 'text'; text: string }
  | { kind: 'code'; text: string }
  | { kind: 'strong' | 'em' | 'del'; parts: Inline[] }
  | { kind: 'link'; href: string; parts: Inline[] }
  | { kind: 'image'; src: string; alt: string }
  | { kind: 'break' };

export type Block =
  | { kind: 'heading'; level: number; parts: Inline[] }
  | { kind: 'paragraph'; parts: Inline[] }
  | { kind: 'code'; lang: string; text: string }
  | { kind: 'quote'; blocks: Block[] }
  | { kind: 'list'; ordered: boolean; start: number; items: Block[][] }
  | { kind: 'rule' }
  | { kind: 'table'; head: Inline[][]; rows: Inline[][][]; align: ('left' | 'center' | 'right' | null)[] };

const FENCE = /^(`{3,}|~{3,})\s*(\S*)\s*$/;
const HEADING = /^(#{1,6})\s+(.*?)\s*#*\s*$/;
const RULE = /^(?:-{3,}|\*{3,}|_{3,})\s*$/;
const BULLET = /^(\s*)([-*+])\s+(.*)$/;
const NUMBERED = /^(\s*)(\d{1,9})[.)]\s+(.*)$/;
const QUOTE = /^\s{0,3}>\s?(.*)$/;
const TABLE_RULE = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/;

/** The text split into blocks: the parser's one pass over the lines. */
export function parseMarkdown(text: string): Block[] {
  return parseLines(text.replace(/\r\n?/g, '\n').split('\n'));
}

function parseLines(lines: readonly string[]): Block[] {
  const out: Block[] = [];
  let i = 0;
  while (i < lines.length) {
    const raw = lines[i]!;
    const line = raw.trimEnd();
    if (line.trim() === '') { i++; continue; }

    const fence = FENCE.exec(line.trim());
    if (fence) {
      const mark = fence[1]![0]!;
      const body: string[] = [];
      i++;
      while (i < lines.length && !(lines[i]!.trim().startsWith(mark.repeat(3)) && lines[i]!.trim().replace(/[`~]/g, '') === '')) body.push(lines[i++]!);
      i++;
      out.push({ kind: 'code', lang: fence[2] ?? '', text: body.join('\n') });
      continue;
    }

    const heading = HEADING.exec(line);
    if (heading) { out.push({ kind: 'heading', level: heading[1]!.length, parts: parseInline(heading[2]!) }); i++; continue; }
    if (RULE.test(line.trim())) { out.push({ kind: 'rule' }); i++; continue; }

    if (QUOTE.test(line)) {
      const inner: string[] = [];
      while (i < lines.length && QUOTE.test(lines[i]!)) inner.push(QUOTE.exec(lines[i++]!)![1]!);
      out.push({ kind: 'quote', blocks: parseLines(inner) });
      continue;
    }

    if (BULLET.test(line) || NUMBERED.test(line)) {
      const list = readList(lines, i);
      out.push(list.block);
      i = list.next;
      continue;
    }

    if (line.includes('|') && i + 1 < lines.length && TABLE_RULE.test(lines[i + 1]!)) {
      const head = cells(line).map(parseInline);
      const align = cells(lines[i + 1]!).map((c) => {
        const t = c.trim();
        const left = t.startsWith(':');
        const right = t.endsWith(':');
        return left && right ? 'center' : right ? 'right' : left ? 'left' : null;
      });
      const rows: Inline[][][] = [];
      i += 2;
      while (i < lines.length && lines[i]!.includes('|') && lines[i]!.trim() !== '') rows.push(cells(lines[i++]!).map(parseInline));
      out.push({ kind: 'table', head, rows, align });
      continue;
    }

    // A paragraph: lines until a blank one or a block that begins (a fence, a heading, a list, a quote, a rule).
    const para: string[] = [];
    while (i < lines.length) {
      const l = lines[i]!;
      if (l.trim() === '' || FENCE.test(l.trim()) || HEADING.test(l) || RULE.test(l.trim()) || QUOTE.test(l) || BULLET.test(l) || NUMBERED.test(l)) break;
      if (para.length > 0 && l.includes('|') && i + 1 < lines.length && TABLE_RULE.test(lines[i + 1]!)) break;
      para.push(l);
      i++;
    }
    // Lines joined by a space; two trailing spaces are a break, and the space after one is not kept.
    if (para.length > 0) out.push({ kind: 'paragraph', parts: parseInline(para.map((l, n) => (n < para.length - 1 && /\s{2,}$/.test(l) ? `${l.trimEnd()}\0` : l.trim())).join(' ').replace(/\0 /g, '\0')) });
    else i++;
  }
  return out;
}

/** A table row's cells, the outer pipes dropped, `\|` kept as a pipe. */
function cells(line: string): string[] {
  const t = line.trim().replace(/^\|/, '').replace(/\|$/, '');
  const out: string[] = [];
  let cur = '';
  for (let i = 0; i < t.length; i++) {
    const c = t[i]!;
    if (c === '\\' && t[i + 1] === '|') { cur += '|'; i++; continue; }
    if (c === '|') { out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  out.push(cur.trim());
  return out;
}

/** A list from line `start`: items by their marker's indent, a deeper indent a nested list, until a line that is neither. */
function readList(lines: readonly string[], start: number): { block: Block; next: number } {
  const first = BULLET.exec(lines[start]!) ?? NUMBERED.exec(lines[start]!)!;
  const indent = first[1]!.length;
  const ordered = !BULLET.test(lines[start]!);
  const begins = ordered ? Number(first[2]) : 1;
  const items: Block[][] = [];
  let i = start;
  while (i < lines.length) {
    const m = BULLET.exec(lines[i]!) ?? NUMBERED.exec(lines[i]!);
    if (!m || m[1]!.length !== indent || (ordered !== !BULLET.test(lines[i]!))) break;
    // The item: its first line, then every line indented past the marker (a nested list, a wrapped line) until the next item at this indent.
    const body: string[] = [m[3]!];
    i++;
    while (i < lines.length) {
      const l = lines[i]!;
      if (l.trim() === '') {
        // A blank line ends the item unless the next is indented past the marker.
        const n = lines[i + 1];
        if (n !== undefined && /^\s+/.test(n) && n.search(/\S/) > indent) { body.push(''); i++; continue; }
        break;
      }
      const lead = l.search(/\S/);
      const next = BULLET.exec(l) ?? NUMBERED.exec(l);
      if (next && next[1]!.length <= indent) break;
      if (lead <= indent && !next) break;
      body.push(l.slice(Math.min(lead, indent + 2)));
      i++;
    }
    items.push(parseLines(body));
  }
  return { block: { kind: 'list', ordered, start: begins, items }, next: i };
}

const INLINE_LINK = /^\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/;
const INLINE_IMAGE = /^!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/;
const AUTO_LINK = /^<(https?:\/\/[^>\s]+)>/;
const BARE_URL = /^https?:\/\/[^\s<>()]+[^\s<>().,;:!?'"]/;

/** A line's inlines: code spans first (nothing inside them is read), then emphasis, links and images. */
export function parseInline(text: string): Inline[] {
  const out: Inline[] = [];
  let buf = '';
  const flush = (): void => { if (buf) { out.push({ kind: 'text', text: buf }); buf = ''; } };
  let i = 0;
  while (i < text.length) {
    const c = text[i]!;
    if (c === '\0') { flush(); out.push({ kind: 'break' }); i++; continue; }
    if (c === '\\' && i + 1 < text.length && /[\\`*_~\[\]()#!|]/.test(text[i + 1]!)) { buf += text[i + 1]; i += 2; continue; }
    if (c === '`') {
      const run = /^`+/.exec(text.slice(i))![0];
      const end = text.indexOf(run, i + run.length);
      if (end > 0) { flush(); out.push({ kind: 'code', text: text.slice(i + run.length, end).trim() }); i = end + run.length; continue; }
    }
    const rest = text.slice(i);
    const image = INLINE_IMAGE.exec(rest);
    if (image) { flush(); out.push({ kind: 'image', src: image[2]!, alt: image[1]! }); i += image[0].length; continue; }
    const link = INLINE_LINK.exec(rest);
    if (link) { flush(); out.push({ kind: 'link', href: link[2]!, parts: parseInline(link[1]!) }); i += link[0].length; continue; }
    const auto = AUTO_LINK.exec(rest) ?? BARE_URL.exec(rest);
    if (auto) { flush(); const href = auto[1] ?? auto[0]; out.push({ kind: 'link', href, parts: [{ kind: 'text', text: href }] }); i += auto[0].length; continue; }
    const span = emphasis(text, i);
    if (span) { flush(); out.push({ kind: span.kind, parts: parseInline(span.inner) }); i = span.end; continue; }
    buf += c;
    i++;
  }
  flush();
  return out;
}

/** `**strong**`, `__strong__`, `*em*`, `_em_`, `~~del~~` at `i`, if closed on the same line and not a bare `*` in a word. */
function emphasis(text: string, i: number): { kind: 'strong' | 'em' | 'del'; inner: string; end: number } | null {
  for (const [mark, kind] of [['**', 'strong'], ['__', 'strong'], ['~~', 'del'], ['*', 'em'], ['_', 'em']] as const) {
    if (!text.startsWith(mark, i)) continue;
    const after = text[i + mark.length];
    if (after === undefined || /\s/.test(after)) continue;
    // `_` inside a word (snake_case) is no emphasis.
    if (mark === '_' && i > 0 && /\w/.test(text[i - 1]!)) continue;
    const end = text.indexOf(mark, i + mark.length + 1);
    if (end < 0 || /\s/.test(text[end - 1]!)) continue;
    if (mark === '_' && /\w/.test(text[end + 1] ?? '')) continue;
    return { kind, inner: text.slice(i + mark.length, end), end: end + mark.length };
  }
  return null;
}

/** Where a link or an image may go: null keeps the text and drops the address. */
export interface MarkdownLinks {
  /** An `href` the page may open: the address as given, or null for one it must not (`javascript:` and the like). */
  href(href: string): string | null;
  /** An image's address as the page can fetch it, or null to show its alt text instead. */
  image(src: string): string | null;
}

/** The safe default: web and mail addresses as they are, relative paths kept for the caller's resolver, images not drawn. */
export const SAFE_LINKS: MarkdownLinks = {
  href: (href) => (/^(https?:|mailto:)/i.test(href) || !/^[a-z][a-z0-9+.-]*:/i.test(href) ? href : null),
  image: () => null,
};

/** The blocks as elements, into a fragment: every string through `textContent`, never markup. */
export function renderMarkdown(blocks: readonly Block[], links: MarkdownLinks = SAFE_LINKS): DocumentFragment {
  const frag = document.createDocumentFragment();
  for (const block of blocks) frag.append(renderBlock(block, links));
  return frag;
}

function renderBlock(block: Block, links: MarkdownLinks): HTMLElement {
  switch (block.kind) {
    case 'heading': {
      const h = document.createElement(`h${Math.min(6, block.level)}` as 'h1');
      h.append(renderInline(block.parts, links));
      return h;
    }
    case 'paragraph': {
      const p = document.createElement('p');
      p.append(renderInline(block.parts, links));
      return p;
    }
    case 'code': {
      const pre = document.createElement('pre');
      const code = document.createElement('code');
      if (block.lang) code.dataset.lang = block.lang;
      code.textContent = block.text;
      pre.append(code);
      return pre;
    }
    case 'quote': {
      const q = document.createElement('blockquote');
      for (const b of block.blocks) q.append(renderBlock(b, links));
      return q;
    }
    case 'list': {
      const list = block.ordered ? document.createElement('ol') : document.createElement('ul');
      if (list instanceof HTMLOListElement && block.start !== 1) list.start = block.start;
      for (const item of block.items) {
        const li = document.createElement('li');
        // One paragraph alone is the item's text; more keeps its blocks.
        if (item.length === 1 && item[0]!.kind === 'paragraph') li.append(renderInline(item[0]!.parts, links));
        else for (const b of item) li.append(renderBlock(b, links));
        list.append(li);
      }
      return list;
    }
    case 'rule':
      return document.createElement('hr');
    case 'table': {
      const table = document.createElement('table');
      const thead = document.createElement('thead');
      const tr = document.createElement('tr');
      block.head.forEach((cell, n) => {
        const th = document.createElement('th');
        if (block.align[n]) th.style.textAlign = block.align[n]!;
        th.append(renderInline(cell, links));
        tr.append(th);
      });
      thead.append(tr);
      const tbody = document.createElement('tbody');
      for (const row of block.rows) {
        const r = document.createElement('tr');
        row.forEach((cell, n) => {
          const td = document.createElement('td');
          if (block.align[n]) td.style.textAlign = block.align[n]!;
          td.append(renderInline(cell, links));
          r.append(td);
        });
        tbody.append(r);
      }
      table.append(thead, tbody);
      return table;
    }
  }
}

function renderInline(parts: readonly Inline[], links: MarkdownLinks): DocumentFragment {
  const frag = document.createDocumentFragment();
  for (const part of parts) {
    switch (part.kind) {
      case 'text': frag.append(part.text); break;
      case 'break': frag.append(document.createElement('br')); break;
      case 'code': {
        const code = document.createElement('code');
        code.textContent = part.text;
        frag.append(code);
        break;
      }
      case 'strong': case 'em': case 'del': {
        const e = part.kind === 'strong' ? document.createElement('strong') : part.kind === 'em' ? document.createElement('em') : document.createElement('del');
        e.append(renderInline(part.parts, links));
        frag.append(e);
        break;
      }
      case 'link': {
        const href = links.href(part.href);
        if (href === null) { frag.append(renderInline(part.parts, links)); break; }
        const a = document.createElement('a');
        a.href = href;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.title = part.href;
        a.append(renderInline(part.parts, links));
        frag.append(a);
        break;
      }
      case 'image': {
        const src = links.image(part.src);
        if (src === null) { frag.append(part.alt || part.src); break; }
        const img = document.createElement('img');
        img.src = src;
        img.alt = part.alt;
        img.loading = 'lazy';
        frag.append(img);
        break;
      }
    }
  }
  return frag;
}
