---
skill: engine
title: A project's own editor tools
when: Before adding to the editor for this game -- a tab, a Config page, an inspector block, a data kind, a dev-server route, an MCP tool -- under src/tools/
covers:
  modules: [tool.ts, blocks.ts, dom.ts, mcp/declare.ts, index.ts]
order: 99
---
# A project's own editor tools

Anything the editor does through a list, a project adds to the list -- **never a change to the editor for one
game**. A project's tools live in `src/tools/` (or the folders `vibe({ tools })` names), are listed in
`src/tools/index.ts`, and are debug code: `main.ts` reaches them only through its `DEBUG`-gated `import()`, and a
release that carries any of them fails to build. **Every action a person has in a tool comes with its MCP tool**,
so Claude can do it too, and **every tool with its page** in the studio skill. The contract is `@vibe/editor`'s
(`node_modules/@vibe/editor/src/tool.ts`; `index.ts` lists everything it exports).

## What a project can add

| Point | What | Where |
|---|---|---|
| a tool | a tab with its cards, or a panel `within` another tab; one with a built-in's id in its place | `tools` in `src/tools/index.ts`, `EditorTool` |
| a page | a tab whose card covers the scene's room (as Config's and Studio's do): Play goes to the Scene tab first and Stop comes back; `ownScene: true` for a tab drawing a scene of its own | the tool instance's `page: true` (no example tool sets it: Tiles sits beside the scene) |
| keys | a tool's keys, MrDebug actions with a `when` (`anyTab` for one live from any tab) | the tool's `ctx.keys.add(ToolKey)` |
| a Config page | a page in the Config tree, under a group of its own | `pages`, `ConfigPage` |
| an inspector block | a block under a component or a kind of entity, before, between or in place of the built-ins (transform 10, render 20, the fields 30: `BLOCK_ORDER`) | `blocks`, `BlockItem { id, for, order, each?, make }` |
| turn facts | what the tool shows, told to Claude with each turn | the tool instance's `context()` |
| an MCP tool | `project_<name>` to Claude and to outside clients, its edits one step `Z` undoes | `mcpTools`, `ProjectMcpTool` |
| components | a tool's own components, defined before the world is made, on the page and in the worker | `src/tools/components.ts`, importing `@vibe/engine` alone |
| a data kind | a folder under `src/assets/`, its key union, `Assets.data(kind, key)`, listed in the Assets panel | `vibe({ kinds })` in `vite.config.ts`, `ProjectKind` |
| a dev-server route | `/__tools/<name>/...` through the pipeline's guards, and a push back to the page | `vibe({ routes })`, `ToolRoute` |

`src/tools/index.ts` exports the lists: `tools`, `pages`, `blocks`, `mcpTools`. The example tools are the shapes to
copy: the tile tool touches every point (a tab, a key, a block, a kind, a route, an MCP tool and its page).

## A tool with its MCP tool

```ts
// src/tools/spin/index.ts
import type { Entity, World } from '@vibe/engine';
import { button, el, type EditorTool, type ProjectMcpTool } from '@vibe/editor';
import { Spin } from '../../game/components.ts';

/** Every spinning thing stopped: what the button and the MCP tool both do. How many. */
function stopAll(world: World): number {
  const spin = world.store(Spin);
  let stopped = 0;
  for (let e = 1; e < world.extent; e++) {
    if (!world.alive(e as Entity) || !world.has(e as Entity, Spin) || spin.speed[e] === 0) continue;
    spin.speed[e] = 0;
    stopped++;
  }
  return stopped;
}

/** `project_spin_stop`: in a file of its own in a real tool, so a node test can run it on a world. */
export const spinStop: ProjectMcpTool = {
  name: 'spin_stop',
  description: 'Stop every spinning entity (Spin.speed to 0), as the Spin tab\'s Stop all does. One step Z undoes.',
  input: { type: 'object', properties: {} },
  annotations: { idempotent: true },
  run({ world }) {
    const stopped = stopAll(world);
    return stopped === 0 ? { words: 'Nothing was spinning.' } : { words: `Stopped ${stopped}.`, json: { stopped }, step: 'Stop every spin' };
  },
};

export const spinTool: EditorTool = {
  id: 'spin',
  name: 'Spin',
  icon: 'grid',
  help: 'Stop what spins',
  create(ctx) {
    const card = el('div', 'ed-card ed-side ed-left');
    const stop = button('project_spin_stop', 'Stop all', 'Every spinning entity stopped: one step', () => {
      if (stopAll(ctx.world) === 0) return;
      ctx.draw();
      if (ctx.worldSteps.commit('Stop every spin')) ctx.emit('changed');
    });
    card.append(el('div', 'ed-side-title', 'Spin'), stop);
    ctx.root.append(card);
    return {
      setVisible: (visible) => void (card.hidden = !visible),
      dispose: () => card.remove(),
    };
  },
};
```

and in `src/tools/index.ts`, `export const tools: EditorTool[] = [spinTool];` and `export const mcpTools:
ProjectMcpTool[] = [spinStop];`.

- **Edits are world steps**: change `ctx.world`, then `ctx.worldSteps.commit('Label')` -- one step `Z` undoes -- and
  `ctx.emit('changed')` so the rest of the editor reads it again. `ctx.history` for a step of your own.
- **The MCP tool** is a `ProjectMcpTool`: `name` in lowercase words joined by `_` (Claude calls it `project_<name>`),
  `description` (what a person does with it, its arguments, its answer, that it is one step), `input` as JSON Schema
  (no zod; at most 16 KB, no `$ref`), `annotations` (`readOnly` never asks and is put back if it wrote; `destructive`
  asks under Auto; neither, a write: asks under Ask) and `run({ world, selection }, args)`, answering `{ words,
  json?, step? }`. **It throws to refuse**: the message is the error, the world put back -- unless an async `run`
  was awaited while the person edited too: then what changed is kept as a step `Z` takes back, and the error says so. It runs in the studio tab,
  on the editor's world, and not while a playtest runs (paused, it does). A tool added is Claude's from its next
  conversation (or Clear): the tools are read as a session starts.
- Keep `run` node-safe -- the engine's types and the tool's components, no DOM -- in a file of its own beside the
  tool, so a test runs it on a world (the sandbox's `src/tools/tiles-paint.test.ts` is the shape).

## Every action declares its MCP tool

Each button, menu entry and key of a tool says which MCP tool does the same, and the typecheck holds it:
`button(mcp, text, title, run)`, `iconButton(mcp, ...)` and `control(mcp, className?, text?)` take it first;
`MenuItem.mcp`, `ToolKey.mcp` and an Assets tool's `AssetsToolKey.mcp` are fields. It is one of:

- a studio tool's name, or the project's own (`'project_spin_stop'`), or several (`['scene_create', 'scene_component']`);
- `'ui'` -- only the editor's view changes (a tab, a fold, a palette's choice): never for something that changes the
  project;
- `projectNone('<why>')` (from `@vibe/editor`) -- while its tool is still to write. Then write it: an `mcpTools`
  entry and a line of the page. A bare `{ none: '<why>' }` does not build: the editor's own nones are its gap list's.

Anything else clickable in a tool folder needs `// mcp: <tool>` (or `ui`, `none: <why>`) on its line or the one
above: a raw `el('button')` or `<button` in markup, a `MrDebug.add`, a `click` / `dblclick` listener on an element
the helpers did not make, an `onclick`, a `role` of `button`, a `createElement(tag)` with no literal tag. `npm
test`'s `mcp` check fails on one that says nothing. (Not read: a field's own `change` or `input`, a drag, a drop.)

## Its page

A tool comes with a page in the **studio** skill: `src/tools/<tool>/<id>.skill.md`, named as the tool's `id`, its
frontmatter `skill: studio`, a `title`, a `when` line, and `covers: tools: [project_spin_stop]` -- then how to do a
job with its tools, its refusals, an example end to end. `npm test`'s `skills` check fails on a `project_<name>` tool
no page covers, and on a page naming a tool that is not there; `vibe sync` (and the dev server before each turn)
copies it into `.claude/skills/studio/`.

## A data kind and a route

```ts
import type { ProjectKind } from '@vibe/pipeline/kinds';

/** `src/assets/tilemaps/*.tilemap`: `Assets.data('tilemaps', key)`, its keys in keys.d.ts. */
export const TILEMAPS: ProjectKind = { dir: 'tilemaps', type: 'Tilemap', ext: ['tilemap'], data: true };
```

named in `vite.config.ts` -- `vibe({ port, kinds: { tilemaps: TILEMAPS }, routes: [tilesRoute] })`. A route is a
`ToolRoute` from `@vibe/pipeline` (`{ name, handler(req, res, ctx) }`, answering `/__tools/<name>/<path>`): a path it
writes checked with `checkPath`, written with `writeAtomic` (`keepUid` keeps the file's uid), refused with
`throw new Refused(status, words)`, and `ctx.push(message)` to tell the page. The tool calls it with
`assetApi().tool(name).call(path, body)` and hears the push through `createLive(api).on('tool', ...)`. The example
tile tool's `kind.ts` and `server.ts` are both whole.

## The rules that bite

- The game never imports a tool, nor `@vibe/editor`; a tool's components go in `src/tools/components.ts`,
  importing `@vibe/engine` alone (the game's worker imports it too).
- A debug key of a tool is a `ToolKey` (or a `MrDebug.add` with its `// mcp:`), never a listener of its own.
- No button without its declaration; no `none` left without its gap closed when the tool can be written.
- A tool's edits go through `worldSteps` (or `history`): never a change `Z` cannot take back.
