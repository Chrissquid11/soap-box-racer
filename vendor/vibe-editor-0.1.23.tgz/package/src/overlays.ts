/**
 * What the editor draws over the world: a ground grid, an outline round the
 * selected entity's view, a fainter one round each of the rest of a selection,
 * and a box round whatever the pointer is over -- and, for a moment as one lands, a box in Claude's violet round each
 * entity an edit of Claude's changed (`flash`, Docs/ai-panel.md D8).
 *
 * Drawn over everything and never picked -- picking tests views only -- and in
 * the scene only while the editor is open (`viewport.ts` puts them there). A
 * box goes round a view whether it is drawn or not: a hidden entity selected
 * keeps its outline, as it keeps the gizmo, so it can be found and moved.
 */
import * as THREE from 'three';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';
import { fitResolution } from './pick-lines.ts';

/** How wide the flash's lines are, in CSS pixels: fat, as the relation links are, so a moment's box reads. */
const FLASH_WIDTH = 3;
/** A box's twelve edges, as pairs of its eight corners (bit 0 x, bit 1 y, bit 2 z: max where set). */
const EDGES = [0, 1, 2, 3, 4, 5, 6, 7, 0, 2, 1, 3, 4, 6, 5, 7, 0, 4, 1, 5, 2, 6, 3, 7];

/** The shell's amber, for what is chosen; white for what only the pointer is over. */
export const ACCENT = '#f0a63c';
const HOVER = '#ffffff';
/** Claude's colour (shell.css' `--claude`): what an edit of Claude's changed, outlined for a moment. */
export const CLAUDE = '#b49cff';
/** The editor's quiet line: the panels' dark, for what is drawn but not chosen (a camera not selected). */
export const QUIET = '#10141c';
/** A light line under a quiet one, wider: the dark line read over a dark sky or clear colour too. */
export const HALO = '#ffffff';

/** A box round an object, drawn over everything. */
function boxHelper(color: string, opacity: number, order: number): THREE.BoxHelper {
  const box = new THREE.BoxHelper(new THREE.Object3D(), color);
  const material = box.material as THREE.LineBasicMaterial;
  material.depthTest = false;
  material.transparent = opacity < 1;
  material.opacity = opacity;
  box.renderOrder = order;
  box.visible = false;
  return box;
}

/** `box` round `object`, or away for null. */
function fitBox(box: THREE.BoxHelper, object: THREE.Object3D | null): void {
  box.visible = !!object;
  if (!object) return;
  object.updateMatrixWorld(true);
  box.setFromObject(object);
}

export interface Overlays {
  /** What goes in the scene while the editor is open. */
  readonly objects: readonly THREE.Object3D[];
  /** Round these views, each null for none: the one selected, the rest of the selection, the one under the pointer. */
  fit(selected: THREE.Object3D | null, rest: readonly (THREE.Object3D | null)[], hovered: THREE.Object3D | null): void;
  /** Round these views in Claude's colour (an edit of Claude's landing); none, none. */
  flash(views: readonly (THREE.Object3D | null)[]): void;
  dispose(): void;
}

export function createOverlays(): Overlays {
  // A metre a square, just over the ground so the two do not fight for the same depth.
  const grid = new THREE.GridHelper(60, 60, ACCENT, HOVER);
  const gridMaterial = grid.material as THREE.LineBasicMaterial;
  gridMaterial.transparent = true;
  gridMaterial.opacity = 0.22;
  gridMaterial.depthWrite = false;
  grid.position.y = 0.004;
  const outline = boxHelper(ACCENT, 1, 999);
  const hover = boxHelper(HOVER, 0.55, 998);
  /** Boxes for the rest of a selection, made as many are needed and kept. */
  const also = new THREE.Group();
  also.name = 'editor: the rest of the selection';
  /** Fat boxes for what an edit of Claude's changed, for a moment: one set of segments, written in place. */
  const flashGeometry = new LineSegmentsGeometry();
  const flashMaterial = new LineMaterial({ color: CLAUDE, linewidth: FLASH_WIDTH, depthTest: false, depthWrite: false });
  const flashed = new LineSegments2(flashGeometry, flashMaterial);
  flashed.name = 'editor: what Claude just changed';
  flashed.renderOrder = 996;
  flashed.frustumCulled = false;
  flashed.visible = false;
  // A pixel of width as the viewport in effect has it (the game's frame), as the relation links measure theirs.
  flashed.onBeforeRender = (renderer) => fitResolution(flashMaterial, renderer);
  const flashBox = new THREE.Box3();

  return {
    objects: [grid, outline, hover, also, flashed],
    fit(selected, rest, hovered) {
      fitBox(outline, selected);
      while (also.children.length < rest.length) also.add(boxHelper(ACCENT, 0.5, 997));
      also.children.forEach((box, i) => fitBox(box as THREE.BoxHelper, rest[i] ?? null));
      fitBox(hover, hovered);
    },
    flash(views) {
      const ends: number[] = [];
      for (const view of views) {
        if (!view) continue;
        view.updateMatrixWorld(true);
        if (flashBox.setFromObject(view).isEmpty()) continue;
        const { min, max } = flashBox;
        for (const corner of EDGES) ends.push(corner & 1 ? max.x : min.x, corner & 2 ? max.y : min.y, corner & 4 ? max.z : min.z);
      }
      flashed.visible = ends.length > 0;
      if (ends.length > 0) flashGeometry.setPositions(ends);
    },
    dispose() {
      grid.geometry.dispose();
      gridMaterial.dispose();
      outline.dispose();
      hover.dispose();
      for (const box of also.children) (box as THREE.BoxHelper).dispose();
      flashGeometry.dispose();
      flashMaterial.dispose();
    },
  };
}
