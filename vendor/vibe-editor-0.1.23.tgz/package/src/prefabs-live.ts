/**
 * Prefabs compiled live (Docs/prefabs.md §7): a prefab file added, changed or
 * removed in the dev server -- the editor writing it, or a person in their
 * editor -- compiled again into the running game, no reload.
 *
 * The rules:
 *   - **Atomic.** `compilePrefabs` resolves everything first and commits after,
 *     so a recompile that throws leaves the last good one whole: the error is
 *     kept and shown (`livePrefabs.error`, the Assets tool's prefab inspector,
 *     the console), never thrown at the page.
 *   - **New instances take the new data at once**: `instantiate` reads the
 *     compiled tables, which the commit replaced; a new prefab is spawnable at
 *     once (the tree's Create menu is the compiled prefabs).
 *   - **Parked instances are made again**: a changed prefab's pool is drained
 *     before the compile -- what is parked and resting was made from the one
 *     before -- and warmed after, from the new `full` (or the old, if the
 *     compile failed). A parked instance is a new one, so nothing is lost.
 *     That moves the world's `extent` and generations with nothing edited:
 *     the editor runs the recompile `around` its steps, so it is no step.
 *   - **Live instances out are brought up** (Docs/prefabs.md §7): each
 *     one's overrides worked out against the compile it was made from, before
 *     the compile (`pending`), then -- the caller's, `livePrefabs.update` --
 *     every value, component and entity it holds no override of taken from the
 *     new one (`applyUpdates`): one step Z undoes in the editor, in place
 *     outside it. One given back to a pool is reset from the new `full` if its
 *     nodes are the same kinds, and destroyed for real if not (`World.park`).
 *   - **A node whose components changed gets a new kind** of the same name
 *     (`kindAgain`): the world grows its per-kind counters as it meets it. A
 *     release never recompiles: this module is the editor's.
 *   - **Workers need nothing.** A worker thread runs parallel systems over the
 *     member lists and the shared columns the page hands it, and never looks
 *     at a kind; a kind made here is the page's alone (`?workers=2` checked).
 *
 * Free of `import.meta.glob` and three: the files and the world are handed in,
 * so a node test drives it (`prefabs-live.test.ts`); `boot.ts` wires it to
 * the engine's `prefabs.ts`' hot updates.
 */
import { compiledPrefab, compileLive, kindAgain, nestedKey, pendingUpdates, untypedPrefab as prefab, type Pending, type PrefabFile, type World } from '@vibe/engine';
import type { CompileOptions } from '@vibe/engine';

/** What one recompile did. */
export interface Recompiled {
  /** Keys new since the last good compile. */
  added: string[];
  /** Keys gone. */
  removed: string[];
  /** Keys whose file changed, or that nest one that did (added and removed apart). */
  changed: string[];
  /** The compile's error, the last good one kept; null when it compiled. */
  error: string | null;
  /** The prefab the error names, when it names one: for a cycle, the one it starts from. */
  errorKey: string | null;
  /** Every prefab the error is shown on: the one it names -- or each of a cycle's chain, any of which can break it. */
  errorKeys: string[];
  /** The line for the console and the Assets tool. */
  line: string;
  /**
   * Every instance out of a prefab changed, with its overrides against the
   * compile it was made from, worked out before this one: what the live
   * update brings up (`applyUpdates`). Empty when the compile failed.
   */
  pending: Pending[];
}

/** Each key's file as JSON text: what the last good compile compiled. */
export type Snapshot = Map<string, string>;

export function snapshot(files: Record<string, PrefabFile>): Snapshot {
  return new Map(Object.entries(files).map(([key, file]) => [key, JSON.stringify(file)]));
}

/** The prefabs `file` nests, by key. */
function nested(file: PrefabFile | undefined): string[] {
  const out: string[] = [];
  for (const e of file?.entities ?? []) {
    const key = nestedKey(e);
    if (key !== null) out.push(key);
  }
  return out;
}

/** Every key whose file differs between `before` and `files`, and every prefab that nests one of them, either side. */
export function changedKeys(before: Snapshot, files: Record<string, PrefabFile>): { added: string[]; removed: string[]; changed: string[] } {
  const now = snapshot(files);
  const added = [...now.keys()].filter((k) => !before.has(k)).sort();
  const removed = [...before.keys()].filter((k) => !now.has(k)).sort();
  const touched = new Set<string>([...added, ...removed]);
  for (const [k, text] of now) if (before.has(k) && before.get(k) !== text) touched.add(k);
  // Upward through nesting, in the files as they were and as they are.
  const parse = (text: string | undefined): PrefabFile | undefined => (text === undefined ? undefined : (JSON.parse(text) as PrefabFile));
  const keys = new Set([...before.keys(), ...now.keys()]);
  for (let grew = true; grew; ) {
    grew = false;
    for (const k of keys) {
      if (touched.has(k)) continue;
      const inner = [...nested(parse(before.get(k))), ...nested(files[k])];
      if (inner.some((n) => touched.has(n))) {
        touched.add(k);
        grew = true;
      }
    }
  }
  const changed = [...touched].filter((k) => !added.includes(k) && !removed.includes(k)).sort();
  return { added, removed, changed };
}

/**
 * `files` compiled into `world`, against `before` (the last good compile's
 * snapshot, brought up to date when this one compiles). Outside a tick.
 */
export function recompile(world: World, files: Record<string, PrefabFile>, before: Snapshot, options: Pick<CompileOptions, 'model' | 'parts'> = {}): Recompiled {
  const { added, removed, changed } = changedKeys(before, files);
  // Each instance out, against the compile it was made from -- worked out now, before that compile is replaced.
  let pending = pendingUpdates(world, changed);
  // What is parked of a prefab changed or gone was made from the compile before: let go now, warmed again below.
  for (const key of [...changed, ...removed]) if (compiledPrefab(key)?.pool) world.pool(prefab(key)).drain();
  let error: string | null = null;
  try {
    compileLive(files, options, kindAgain);
    before.clear();
    for (const [k, text] of snapshot(files)) before.set(k, text);
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
    pending = [];
  }
  world.warmPools();
  const known = (k: string | undefined): k is string => k !== undefined && (k in files || before.has(k));
  // A cycle names its chain, the prefab it starts from first: `[prefab] a cycle: c/a -> c/b -> c/a`.
  const cycle = error === null ? null : /^\[prefab\] a cycle: (.+)$/m.exec(error);
  const errorKeys = error === null ? [] : cycle
    ? [...new Set(cycle[1]!.split(' -> ').map((k) => k.trim()).filter(known))]
    : [/^\[prefab\] (?:prefab\('([^']+)'\)|([^\s:(]+))/.exec(error)?.slice(1).find(known)].filter(known);
  const errorKey = errorKeys[0] ?? null;
  const what = [added.length ? `added ${added.join(', ')}` : '', changed.length ? `changed ${changed.join(', ')}` : '', removed.length ? `removed ${removed.join(', ')}` : ''].filter(Boolean).join('; ');
  const line = error === null ? `prefabs recompiled: ${what || 'nothing changed'}` : `prefabs not recompiled (${what || 'nothing changed'}), the last good compile kept: ${error}`;
  return { added, removed, changed, error, errorKey, errorKeys, line, pending };
}

/** A prefab file the dev server could not parse (its push, `problem`): the key, and the parser's words. */
export interface FileProblem {
  key: string;
  message: string;
  line?: number;
}

/** What the editor shows of the live compile: the last one's line and error, and files that do not parse. */
export const livePrefabs = {
  last: null as Recompiled | null,
  /** Recompiles so far: what a prefab's preview is drawn again for. */
  compiles: 0,
  /** By key: a file the dev server found broken; gone once it parses again. */
  unparsed: new Map<string, FileProblem>(),
  heard: new Set<() => void>(),
  /**
   * What a recompile runs inside: the editor's, while it is up -- an edit
   * under way committed first, the world after it the known state
   * (`WorldSteps.unedited`) -- so the pools it drains and warms are no edit.
   * By itself, just the run.
   */
  around: <T>(run: () => T): T => run(),
  /**
   * What the live update of instances out runs inside (`run` brings them up;
   * `label` names it): the editor's makes it one step Z undoes, and passes it
   * by while a prefab is open (the opened mode follows what it nests itself).
   * By itself, just the run: a game running in the dev server updates in place.
   */
  update: (_label: string, run: () => void): void => run(),
  /**
   * The texts of the last good compile, by key (`boot.ts`' snapshot, kept up
   * to date by `recompile`): what the instances out were made from. What an
   * Apply checks a file against before it writes (`on-disk.ts`), and what
   * tells it its write has landed (`whenLanded`). Null before boot wires it.
   */
  compiled: null as Snapshot | null,
  /**
   * While an Apply waits for its write to compile (`overrides-steps.ts`): the
   * live update runs through it, not as a step of its own -- the Apply's step
   * holds it, files and world together -- and after an Apply's undo or redo
   * whose compile came late, until it comes (or another write). One that says
   * `false` passes: not the compile it waits for, the update run as ever.
   * Null otherwise. `keys`: the prefabs the update brings instances up to.
   */
  hold: null as ((update: () => void, keys: readonly string[]) => boolean | void) | null,
  /** Told after each recompile and each file problem. Returns the undo. */
  onChange(listener: () => void): () => void {
    this.heard.add(listener);
    return () => void this.heard.delete(listener);
  },
  tell(): void {
    for (const fn of this.heard) fn();
  },
  /** The problem to show for `key`: its file's parse error, or the compile's error naming it. */
  problemOf(key: string): string | null {
    const unparsed = this.unparsed.get(key);
    if (unparsed) return unparsed.line !== undefined ? `line ${unparsed.line}: ${unparsed.message}` : unparsed.message;
    if (this.last?.error && this.last.errorKeys.includes(key)) return this.last.error;
    return null;
  },
};

/**
 * Settles once every file of `texts` (key to the text written) is what the
 * last good compile compiled -- its live update run -- null; or with the
 * compile's error naming one of them, or after `ms`, what went wrong.
 */
export function whenLanded(texts: ReadonlyMap<string, string>, ms = 5000): Promise<string | null> {
  const want = new Map([...texts].map(([k, text]) => [k, JSON.stringify(JSON.parse(text))]));
  const now = (): boolean => [...want].every(([k, json]) => livePrefabs.compiled?.get(k) === json);
  if (now()) return Promise.resolve(null);
  return new Promise((resolve) => {
    const done = (why: string | null): void => {
      clearTimeout(timer);
      off();
      resolve(why);
    };
    const timer = setTimeout(() => done('it was not compiled in time'), ms);
    const off = livePrefabs.onChange(() => {
      if (now()) return done(null);
      for (const k of want.keys()) {
        const problem = livePrefabs.problemOf(k);
        if (problem !== null) return done(problem);
      }
    });
  });
}

/**
 * Settles once `key` is compiled (`present`) or gone from the compile (not
 * `present`) -- at once if it is so already -- true; false if a recompile
 * names it in its error, or `ms` go by first. What a step that writes a
 * prefab file and then makes an instance of it waits for: the dev server's
 * push, the 250 ms the files settle, the compile.
 */
export function whenCompiled(key: string, present: boolean, ms = 5000): Promise<boolean> {
  const now = (): boolean => (compiledPrefab(key) !== undefined) === present;
  if (now()) return Promise.resolve(true);
  return new Promise((resolve) => {
    const done = (ok: boolean): void => {
      clearTimeout(timer);
      off();
      resolve(ok);
    };
    const timer = setTimeout(() => done(false), ms);
    const off = livePrefabs.onChange(() => {
      if (now()) done(true);
      else if (present && livePrefabs.problemOf(key) !== null) done(false);
    });
  });
}
