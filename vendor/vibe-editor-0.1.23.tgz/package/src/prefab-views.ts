/**
 * How the editor draws what a prefab draws outside the world: the whole prefab
 * as its file places it (`prefabLook`, the Assets preview's).
 *
 * The rules:
 *   - **Nothing in the world is drawn here**: every entity with a `Render` --
 *     an instance's, a plain copy of one (Duplicate on a rider, a partial
 *     paste), one given Render by hand -- is drawn by the engine's `render`
 *     system (`installRender`, `src/render.ts`), the game's one way.
 *   - **The models are handed in** (`useModels`, from `editor.ts`): the editor's
 *     node tests import what imports this, and nothing they import may reach
 *     the asset globs. Until then -- in a test -- nothing is drawn.
 *   - **The editor's alone**, so none of it ships in a release.
 */
import * as THREE from 'three';
import { type CompiledPrefab, splitModel, Transform } from '@vibe/engine';

let modelFor: ((key: AssetKeys.Model, part: string | null) => THREE.Object3D) | null = null;

/** The models the editor draws with: `Assets.instance` on the page, null to stop. */
export function useModels(model: ((key: AssetKeys.Model, part: string | null) => THREE.Object3D) | null): void {
  modelFor = model;
}

const FIELDS = ['px', 'py', 'pz', 'qx', 'qy', 'qz', 'qw', 'sx', 'sy', 'sz'] as const;
const FIELD = FIELDS.map((name) => Transform.fields.findIndex((f) => f.name === name));

/**
 * The whole prefab as its file places and draws it: a group per node, posed by
 * its compiled `Transform` under its parent's, each with its `Render`'s model. The
 * root's own position is left out -- the caller puts the group where it will go.
 * Null if no node draws anything, or before `useModels`.
 */
export function prefabLook(p: CompiledPrefab): THREE.Object3D | null {
  if (!modelFor) return null;
  const pose = new Float64Array(p.count * FIELDS.length);
  for (let n = 0; n < p.count; n++) for (let f = 0; f < FIELDS.length; f++) pose[n * FIELDS.length + f] = Transform.fields[FIELD[f]!]!.initial;
  for (const run of p.full) {
    if (run.component !== Transform.id) continue;
    const f = FIELD.indexOf(run.field);
    if (f >= 0) for (let j = 0; j < run.node.length; j++) pose[run.node[j]! * FIELDS.length + f] = run.value[j]!;
  }
  const groups: THREE.Group[] = [];
  let drawn = false;
  for (let n = 0; n < p.count; n++) {
    const g = new THREE.Group();
    const at = n * FIELDS.length;
    if (n > 0) g.position.set(pose[at]!, pose[at + 1]!, pose[at + 2]!);
    g.quaternion.set(pose[at + 3]!, pose[at + 4]!, pose[at + 5]!, pose[at + 6]!);
    g.scale.set(pose[at + 7]!, pose[at + 8]!, pose[at + 9]!);
    const text = p.views[n];
    if (text) {
      const { model, part } = splitModel(text);
      try {
        g.add(modelFor(model as AssetKeys.Model, part));
        drawn = true;
      } catch {
        // A model or a part not loaded: that node draws nothing in the preview, as the game says once.
      }
    }
    groups.push(g);
    if (n > 0) groups[p.parents[n]!]!.add(g);
  }
  return drawn ? groups[0]! : null;
}
