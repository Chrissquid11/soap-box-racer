/**
 * The editor's tabs and the `studio` skill page each is in (Docs/skills.md §2 rule 8, §9 S3): every tool of the
 * editor's own -- a tab on the strip, or a panel `within` one -- takes its id from here (`tabId`), and the editor's
 * list of its own tools is typed to these ids (`EditorTab`), so a new tab cannot build without a line here naming its
 * page; the pipeline's `skills` check reads this module (node strips its types) and fails while a page named here is
 * not among the editor's pages.
 *
 * A project's own tools are not here: the check reads their ids from its tool folders, and wants a page named as each
 * (the tile tool's `tiles` is `tiles.skill.md`) -- or one of these ids, a project's tool in the editor's place (a
 * game's own Assets tool).
 *
 * Node-safe: nothing imported, nothing at module level but the list.
 */

/** Each tab's id, and the name of the `studio` page about it (`<name>.skill.md` in the editor's `src/`). */
export const TAB_PAGES = {
  entities: 'scene',
  config: 'config',
  model: 'model',
  studio: 'code',
  assets: 'assets',
} as const;

/** An id of one of the editor's own tabs. */
export type TabId = keyof typeof TAB_PAGES;

/** A tab's id, held to the list: the way the editor's tools write theirs. */
export const tabId = <Id extends TabId>(id: Id): Id => id;
