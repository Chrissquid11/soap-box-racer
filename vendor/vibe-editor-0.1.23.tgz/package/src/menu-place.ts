/**
 * Where a menu card goes and which of its items the arrows reach (`menu.ts`):
 * pure, so a node test holds them.
 *
 * - **Kept on screen**: a card at a point goes below and right of it, or above
 *   it where there is no room below; a submenu beside its item, to the right of
 *   the card it hangs from, or to its left where there is no room right, its
 *   top level with the item's and pulled up from the window's foot.
 * - **A field's list floats over its panel** (`placeDrop`): under the field,
 *   or above it where there is more room, clamped inside the panel's body --
 *   the part of it under its sticky header (`visibleBody`). Placed only as
 *   something moves, and let go (`dropFate`) once the field leaves the page,
 *   is scrolled out of the body, or the window is resized.
 * - **The arrows go round**: past the last item to the first, and before the
 *   first to the last; with none focused, the first down or the last up.
 */

/** A box on the page, as `getBoundingClientRect` has it. */
export interface Box {
  readonly left: number;
  readonly top: number;
  readonly right: number;
  readonly bottom: number;
}

/** A card's size, and the window's. */
export interface Size {
  readonly width: number;
  readonly height: number;
}

/** How far a card stays from the window's edges, in CSS pixels. */
export const MARGIN = 8;

/** A card's top left, for one opened at a point -- or under `under`, a button it hangs from. */
export function placeAt(at: { x: number; y: number }, card: Size, view: Size, under?: Box): { left: number; top: number } {
  const x = under ? under.left : at.x;
  const y = under ? under.bottom + 4 : at.y;
  const left = Math.max(MARGIN, Math.min(x, view.width - card.width - MARGIN));
  const low = y + card.height > view.height - MARGIN;
  const top = Math.max(MARGIN, low ? (under ? under.top - card.height - 4 : y - card.height) : y);
  return { left, top };
}

/** A submenu's top left: beside `item`, out from `parent` -- the card the item is in -- to the right, else to the left. */
export function placeBeside(item: Box, parent: Box, card: Size, view: Size): { left: number; top: number } {
  const right = parent.right - 2;
  const left = right + card.width <= view.width - MARGIN ? right : Math.max(MARGIN, parent.left - card.width + 2);
  // Level with the item, the card's own padding above it; pulled up from the foot, never past the top.
  const top = Math.max(MARGIN, Math.min(item.top - 5, view.height - card.height - MARGIN));
  return { left, top };
}

/** How far a list dropped from a field stays inside the panel it is clamped to, in CSS pixels. */
export const DROP_INSET = 4;

/** A list dropped from a field: its box on the page, and whether it went above the field. */
export interface Dropped {
  readonly left: number;
  readonly top: number;
  readonly width: number;
  /** Its height: its own, or less where the room is less (it scrolls). */
  readonly height: number;
  readonly above: boolean;
}

/**
 * A list dropped from `field` (a key picker's: `key-field.ts`), floating over the panel it is in rather than pushing
 * what is under the field down: at least the field's width, its left edge on the field's, both clamped inside
 * `panel`'s visible box; below the field where it fits, else above where there is more room, cut to the room it has.
 */
export function placeDrop(field: Box, list: Size, panel: Box, gap = 3): Dropped {
  const room = Math.max(0, panel.right - panel.left - 2 * DROP_INSET);
  const width = Math.min(Math.max(list.width, field.right - field.left), room);
  const left = Math.max(panel.left + DROP_INSET, Math.min(field.left, panel.right - DROP_INSET - width));
  const below = panel.bottom - DROP_INSET - (field.bottom + gap);
  const overhead = field.top - gap - (panel.top + DROP_INSET);
  const above = list.height > below && overhead > below;
  const height = Math.max(0, Math.min(list.height, above ? overhead : below));
  return { left, top: above ? field.top - gap - height : field.bottom + gap, width, height, above };
}

/**
 * What of `panel` -- a side card, scrolling -- its fields are seen in: below its sticky header (`head`, null for none),
 * so a field scrolled under the header is out of view as one scrolled off its top.
 */
export function visibleBody(panel: Box, head: Box | null): Box {
  if (head === null) return panel;
  return { left: panel.left, top: Math.min(panel.bottom, Math.max(panel.top, head.bottom)), right: panel.right, bottom: panel.bottom };
}

/**
 * What a floating list does as something moves: `'place'` it against its field again; `'detached'`, the field gone from
 * the page (the inspector built again under it) -- let go quietly; `'away'`, the field wholly out of `body`'s visible box
 * (`visibleBody`) or the window not the size it was as the list opened (`opened`) -- given up.
 */
export type DropFate = 'place' | 'detached' | 'away';

export function dropFate(field: Box, body: Box, connected: boolean, window: Size, opened: Size): DropFate {
  if (!connected) return 'detached';
  if (window.width !== opened.width || window.height !== opened.height) return 'away';
  if (field.bottom <= body.top || field.top >= body.bottom) return 'away';
  return 'place';
}

/** The item `by` past `at` among `count`, round from the end; with none (-1), the first down or the last up. -1 if there are none. */
export function stepIndex(at: number, by: 1 | -1, count: number): number {
  if (count === 0) return -1;
  if (at < 0) return by > 0 ? 0 : count - 1;
  return (at + by + count) % count;
}
