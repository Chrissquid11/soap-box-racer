/**
 * Debug overlay: FPS/ms/memory graphs plus a live tweak panel.
 *
 * Both libraries ship inside the `three` package, so this costs no extra
 * dependency. **The module is dropped from a normal production build**:
 * a project's main.ts hands it to `boot` as a dynamic import of `@vibe/editor/panel`
 * behind `DEBUG`, a literal `false` in `npm run build`. Never import it statically. It implements boot's
 * `PanelModule` (`@vibe/engine/boot`): `createDebugTools(game)`, the panel's
 * folders -- the renderer's, the loop's, the ECS's -- its own.
 *
 * **Its buttons are MrDebug's** (`mr-debug.ts`): the `actions` folder lists
 * every debug action, each button running through `MrDebug.run`, its keys and
 * chords on its label (`editor: undo  (Z · ⌘Z)`) -- so a debug button and a debug key are one thing, under one
 * switch, the checkbox at the top. Never add a button here or anywhere else
 * that does not go through MrDebug; values and readouts (sliders, numbers)
 * are fine.
 */
import Stats from 'three/addons/libs/stats.module.js';
import GUI from 'three/addons/libs/lil-gui.module.min.js';
import type { WebGLRenderer } from 'three';
import type { DebugTools, Game } from '@vibe/engine/boot';
import { keyLabel, keysOf, MrDebug } from '@vibe/engine/debug';

/**
 * The panel and the stats over the game. `setEditing` is told by boot as the
 * editor (studio mode) opens, and as a playtest -- the game running -- begins and
 * ends: the FPS box is the game's, so it is hidden meanwhile. This module knows
 * nothing of the editor; it is told.
 */
export function createDebugTools(game: Game): DebugTools & { gui: GUI } {
  const renderer = game.renderer;
  const stats = new Stats();
  // Bottom left: the HUD's top corners are its own.
  Object.assign(stats.dom.style, { position: 'absolute', left: '8px', top: 'auto', bottom: '8px' });
  stats.dom.id = 'debug-stats';
  document.body.appendChild(stats.dom);

  const gui = new GUI({ title: 'Debug' });
  // Top middle and shut until asked for: open over the HUD it reads as the HUD being broken.
  Object.assign(gui.domElement.style, { position: 'absolute', left: '50%', right: 'auto', top: '8px', transform: 'translateX(-50%)', maxHeight: '70vh', overflowY: 'auto', zIndex: '30' });
  gui.close();

  // The one switch, first: every debug key and button off at once.
  gui.add(MrDebug, 'enabled').name('debug keys and buttons').listen();

  // Every debug action as a button, kept in step with MrDebug's list.
  const actions = gui.addFolder('actions');
  const buttons: Array<{ destroy(): void }> = [];
  const showActions = (): void => {
    for (const button of buttons.splice(0)) button.destroy();
    for (const action of MrDebug.list()) {
      const keys = keysOf(action).map((key) => keyLabel(key));
      const label = keys.length > 0 ? `${action.name}  (${keys.join(' · ')})` : action.name;
      const button = actions.add({ run: () => MrDebug.run(action.name) }, 'run').name(label);
      button.domElement.title = action.help;
      if (!MrDebug.enabled) button.disable();
      buttons.push(button);
    }
  };
  MrDebug.onChange(showActions);

  // The shared context lost and given back a second later: the test for both
  // renderers' recovery. The game should come back drawing, UI and all, with
  // no reload -- running or paused.
  // mcp: ui -- a test of the renderers' recovery: nothing of the project changes
  MrDebug.add({ name: 'lose context', help: 'Lose the WebGL context and get it back a second later: everything should come back', run: () => loseContext(renderer) });
  showActions();

  const info = gui.addFolder('renderer');
  const counts = { calls: 0, triangles: 0, programs: 0 };
  info.add(counts, 'calls').listen().disable();
  info.add(counts, 'triangles').listen().disable();
  info.add(counts, 'programs').listen().disable();

  const loopFolder = gui.addFolder('loop').close();
  loopFolder.add(game.loop, 'seed').disable();
  loopFolder.add(game.loop, 'tick').listen().disable();
  loopFolder.add(game.loop, 'timeScale', 0, 2, 0.05);
  const load = { peak: 0 };
  loopFolder.add(load, 'peak').name('peak load (per tick)').listen().disable();
  setInterval(() => (load.peak = Math.max(...game.loop.loads())), 500);
  // The ECS's counters: how full the world is, and the three places that can still allocate.
  const ecsFolder = gui.addFolder('ecs').close();
  const world = game.world.stats;
  const heap = { mb: 0 };
  ecsFolder.add(world, 'entities').listen().disable();
  ecsFolder.add(world, 'capacity').listen().disable();
  ecsFolder.add(world, 'growths').name('storage growths').listen().disable();
  ecsFolder.add(world, 'poolMisses').name('pool misses').listen().disable();
  ecsFolder.add(world, 'commandGrowths').name('command buffer growths').listen().disable();
  ecsFolder.add(world, 'refused').name('spawns refused').listen().disable();
  ecsFolder.add(heap, 'mb').name('JS heap (MB)').listen().disable();
  // Chrome only: a heap that climbs and drops in a sawtooth is allocating every frame.
  const memory = (performance as { memory?: { usedJSHeapSize: number } }).memory;
  if (memory) setInterval(() => (heap.mb = Math.round(memory.usedJSHeapSize / 1024 / 102.4) / 10), 500);

  /** The overlays on (`U` turns them off), and the editor not open over the game: the FPS box shows only with both. */
  let overlays = true;
  let editing = false;
  const showStats = (): void => void (stats.dom.style.display = overlays && !editing ? '' : 'none');

  return {
    gui,
    showOverlays(on: boolean): void {
      overlays = on;
      showStats();
      gui.domElement.style.display = on ? '' : 'none';
    },
    setEditing(on: boolean): void {
      editing = on;
      showStats();
    },
    begin: () => stats.begin(),
    end: () => {
      counts.calls = renderer.info.render.calls;
      counts.triangles = renderer.info.render.triangles;
      counts.programs = renderer.info.programs?.length ?? 0;
      stats.end();
    },
  };
}

function loseContext(renderer: WebGLRenderer): void {
  // Asked for before the loss: a lost context hands out no extensions.
  const lose = renderer.getContext().getExtension('WEBGL_lose_context');
  if (!lose) {
    console.warn('[debug] WEBGL_lose_context is not available here');
    return;
  }
  lose.loseContext();
  setTimeout(() => lose.restoreContext(), 1000);
}
