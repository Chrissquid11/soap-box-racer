/**
 * Live entities of a prefab brought up to its new compile (Docs/prefabs.md
 * §7): where an entity still has what the old compile gave it, it takes what
 * the new one gives; where it holds an edit of its own, it keeps it. What the
 * opened-prefab mode does to the prefab it shows when a prefab it nests is
 * saved (an inner one opened from it, or the file changed beside it), and
 * the live update of every instance out (Docs/prefabs.md §7), on the same rule.
 *
 * The rules:
 *   - **An edit is a value that is not the old compile's** (`same`, by the
 *     field's type): a field, a component or tag had or not, a switch, the
 *     layer, the name. Those the entity has as made are brought up; the rest
 *     are left.
 *   - **Only what it can bring up**: the same entities in the same tree (ids
 *     and parents), the same refs, links, objects and views. Anything else --
 *     a link's data, a ref -- is refused whole (`false`, nothing changed), and
 *     the caller keeps comparing against the old compile, so nothing is lost
 *     or written twice.
 *   - **Entities added or removed are the caller's** (`structureOf`): what the
 *     prefab gained and lost, by path, where everything both compiles have is
 *     the same in the tree, refs, links, objects and views -- the opened mode
 *     takes the lost out of its world and puts the gained in (`opened.ts`),
 *     then brings up the rest here, entity by entity, each by its path in
 *     either compile.
 *   - Runtime fields (`component(..., { runtime })`) and transient components
 *     are the systems', not the prefab's: left alone.
 *   - **Entities replaced by an instance keep what systems set** (`takeRuntime`,
 *     `putRuntime`): "Save as prefab" makes the instance fresh, and its
 *     runtime fields are carried over from the entities it replaces, each to
 *     its counterpart -- a ref into what was replaced re-pointed at the new
 *     entity, as a paste re-points one -- so a marker that followed the rider
 *     still does.
 *
 * Free of the page: the world is handed in, so a node test drives it
 * (`opened.test.ts`).
 */
import { allComponents, Name, NO_REF, NONE, Transform, type AnyComponent, type CompiledPrefab, type Component, type Entity, type EntityRef, type World } from '@vibe/engine';
import { same } from './prefab-write.ts';

/** One entity to bring up, and which entity of the prefab it is: its node's id path (`''` the root). */
export interface Member {
  e: Entity;
  path: string;
}

/** A node's value of a field in `p`, defaults included. */
function valueOf(p: CompiledPrefab, c: Component, field: number, node: number): number {
  for (const run of p.full) {
    if (run.component !== c.id || run.field !== field) continue;
    for (let j = 0; j < run.node.length; j++) if (run.node[j] === node) return run.value[j]!;
  }
  return c.fields[field]!.initial;
}

/**
 * What of `p` bring-up does not touch, as text, for the nodes whose paths are
 * in `keep` and by path: each one's parent, whether it is named, its view, its
 * refs, its links and their data, its objects. A ref or link to a path not
 * kept is written as that path, so one to a node gained or lost differs.
 */
function fixed(p: CompiledPrefab, keep: ReadonlySet<string>): string {
  const out: Record<string, unknown[]> = {};
  p.paths.forEach((path, n) => {
    if (keep.has(path)) out[path] = [p.parents[n]! < 0 ? null : p.paths[p.parents[n]!], p.names[n] !== null, p.views[n] ?? null];
  });
  for (const r of p.refs) {
    r.node.forEach((n, j) => void out[p.paths[n]!]?.push(['ref', r.component, r.field, p.paths[r.target[j]!]]));
  }
  for (const l of p.links) {
    l.source.forEach((n, j) => {
      const data = l.writes.flatMap((w) => {
        const at = Array.from(w.link).indexOf(j);
        return at >= 0 ? [[w.field, w.value[at]]] : [];
      });
      out[p.paths[n]!]?.push(['link', l.relation.name, p.paths[l.target[j]!], data]);
    });
  }
  for (const o of p.objects) if (o.component !== Name) out[p.paths[o.node]!]?.push(['object', o.component.name, o.data]);
  // Each node's parts in one order, whichever order the compile listed them in.
  return JSON.stringify(Object.keys(out).sort().map((path) => [path, out[path]!.slice(0, 3), out[path]!.slice(3).map((x) => JSON.stringify(x)).sort()]));
}

/** What a prefab gained and lost between two compiles, by node path: the paths each has that the other has not. */
export interface Structure {
  added: string[];
  removed: string[];
}

/**
 * `old` to `now` as entities gained and lost (`added` in `now`'s node order,
 * parents first), or null if anything bring-up leaves alone changed among the
 * entities both have -- the tree, a ref or link (one to an entity gained or
 * lost included), an object, a view.
 */
export function structureOf(old: CompiledPrefab, now: CompiledPrefab): Structure | null {
  const had = new Set(old.paths);
  const has = new Set(now.paths);
  const both = new Set(old.paths.filter((p) => has.has(p)));
  if (fixed(old, both) !== fixed(now, both)) return null;
  return { added: now.paths.filter((p) => !had.has(p)), removed: old.paths.filter((p) => !has.has(p)) };
}

/** Can `members` go from `old` to `now` here: nothing changed that bring-up leaves alone, no entity gained or lost. */
export const canBringUp = (old: CompiledPrefab, now: CompiledPrefab): boolean => {
  const change = structureOf(old, now);
  return change !== null && change.added.length === 0 && change.removed.length === 0;
};

/**
 * `members` -- entities made from `old` -- brought up to `now` where they
 * hold no edit of their own: each by its path, in either compile, so one
 * gained or lost is passed over (the caller's, `structureOf`). False, and
 * nothing changed, if `structureOf` says no. Writes outside a tick, as an
 * editor's edit does: flush to see it.
 */
export function bringUp(world: World, members: readonly Member[], old: CompiledPrefab, now: CompiledPrefab): boolean {
  if (structureOf(old, now) === null) return false;
  const names = world.rawStore(Name) as { value: (string | null)[] };
  const kept = (c: AnyComponent): boolean => c.bit >= 0 && c !== Name && (c.kind !== 'data' || !c.transient);
  for (const { e, path } of members) {
    const node = now.paths.indexOf(path);
    const then = old.paths.indexOf(path);
    if (node < 0 || then < 0 || !world.alive(e)) continue;
    const before = new Set(old.kinds[then]!.components.filter(kept));
    const after = new Set(now.kinds[node]!.components.filter(kept));
    // Had as made, gone from the prefab: taken off. New in the prefab, and not taken off here before: put on.
    for (const c of before) if (!after.has(c) && world.has(e, c)) world.remove(e, c);
    for (const c of after) if (!before.has(c) && !world.has(e, c)) world.add(e, c);
    let moved = false;
    for (const c of after) {
      if (c.kind !== 'data' || !world.has(e, c)) continue;
      const columns = world.rawStore(c) as Record<string, { [i: number]: number }>;
      c.fields.forEach((f, fi) => {
        if (f.runtime || (c.schema as Record<string, { ref?: true }>)[f.name]?.ref) return;
        const was = before.has(c) ? valueOf(old, c, fi, then) : f.initial;
        const to = valueOf(now, c, fi, node);
        if (same(to, was, f.type) || !same(columns[f.name]![e]!, was, f.type)) return;
        columns[f.name]![e] = to;
        if (c === Transform) moved = true;
      });
    }
    if (moved) world.moved(e);
    // Switched off or on as made: as the prefab says now.
    const offThen = new Set(old.off.filter((x) => x.node === then).map((x) => x.component));
    const offNow = new Set(now.off.filter((x) => x.node === node).map((x) => x.component));
    for (const id of new Set([...offThen, ...offNow])) {
      const c = allComponents()[id]!;
      if (offThen.has(id) === offNow.has(id) || !world.has(e, c)) continue;
      if (world.enabled(e, c) === !offThen.has(id)) world.enable(e, c, !offNow.has(id));
    }
    if (world.layerOfEntity(e) === old.layers[then] && old.layers[then] !== now.layers[node]) world.setLayer(e, now.layers[node]!);
    const name = now.names[node];
    if (name !== null && world.has(e, Name) && names.value[e] === old.names[then] && old.names[then] !== name) names.value[e] = name;
  }
  return true;
}

/** One runtime field's value on an entity: a number, or a ref -- at a place in what was taken, or (-1) kept as it is. */
interface RuntimeValue {
  component: Component;
  field: string;
  value: number;
  /** For a ref: the place in `from` of what it points at, or -1 for one outside it. */
  to: number;
}

/** Every runtime field of each of `from`, numeric components only: what `putRuntime` gives their counterparts. */
export function takeRuntime(world: World, from: readonly Entity[]): RuntimeValue[][] {
  const place = new Map(from.map((e, i) => [e, i]));
  return from.map((e) => {
    const out: RuntimeValue[] = [];
    for (const c of world.allComponents) {
      if (c.kind !== 'data' || c.transient || !world.has(e, c)) continue;
      const columns = world.rawStore(c) as Record<string, { [i: number]: number }>;
      for (const f of c.fields) {
        if (!f.runtime) continue;
        const value = columns[f.name]![e]!;
        const ref = (c.schema as Record<string, { ref?: true }>)[f.name]?.ref === true;
        const target = ref ? world.deref(value as EntityRef) : NONE;
        out.push({ component: c, field: f.name, value, to: target === NONE ? -1 : (place.get(target) ?? -1) });
      }
    }
    return out;
  });
}

/** What `takeRuntime` took, given to `to[i]` (null: none): a ref into what was taken re-pointed at its counterpart, or none if it has none. */
export function putRuntime(world: World, taken: readonly RuntimeValue[][], to: readonly (Entity | null)[]): void {
  taken.forEach((values, i) => {
    const e = to[i];
    if (e === null || e === undefined || !world.alive(e)) return;
    for (const { component, field, value, to: at } of values) {
      if (!world.has(e, component)) continue;
      const target = at >= 0 ? to[at] : undefined;
      (world.rawStore(component) as Record<string, { [i: number]: number }>)[field]![e] = at < 0 ? value : target ? world.ref(target) : NO_REF;
    }
  });
}
