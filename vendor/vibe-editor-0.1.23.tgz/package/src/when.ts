/**
 * When something happened, as a person says it: `just now`, `5 min ago`,
 * `yesterday`. For the scenes tool's list and the editor's subtitle. Pure:
 * node tests it.
 */

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

/** `at` (as `Date.now()` gave it) from `now`; a week or more back, the date itself. */
export function ago(at: number, now: number): string {
  const past = now - at;
  // A clock put back, or a save from another machine: not in the future.
  if (past < 45_000) return 'just now';
  if (past < 90_000) return '1 min ago';
  if (past < HOUR) return `${Math.round(past / MINUTE)} min ago`;
  if (past < DAY) return `${Math.floor(past / HOUR)} h ago`;
  if (past < 2 * DAY) return 'yesterday';
  if (past < 7 * DAY) return `${Math.floor(past / DAY)} days ago`;
  return dateOf(at);
}

/** The date and time, in this browser's way of writing them. */
export const dateOf = (at: number): string => new Date(at).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
