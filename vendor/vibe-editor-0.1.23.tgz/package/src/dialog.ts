/**
 * The editor's one modal dialog (`showDialog`): a card centred over the
 * editor on a dimmed backdrop -- a title, a line of text, a name field if
 * asked, its buttons -- for the questions that stop what the person was
 * doing until they answer. Never `prompt`, `confirm` or `alert`: those stop
 * the page, and the game and any automation driving it with it.
 *
 * Its first use is "lose what changed?" (`askUnsaved`): opening, loading,
 * importing or emptying a scene over changes nobody saved, and Back from a
 * prefab opened to edit with changes -- **Save** (then on), **Don't save**
 * (on), **Cancel**. A question of the panels' own (a name, "replace it?", a
 * delete) stays a line where it was asked (`ask.ts`).
 *
 * - **One at a time**: a dialog put while one is up takes its place, the one
 *   before cancelled.
 * - **Cancel is always the way out**: Esc and Cancel take it down while a
 *   button's promise is still pending (a Save writing) too; what that button
 *   was to do after is then not done (`unsavedDialog`) -- Save, Esc, and Back
 *   from a prefab never goes Back after all.
 * - **Its keys are MrDebug actions** (`dialogKeys`, registered by the host
 *   before any other of the editor's, which rest while it is up): Enter the
 *   button focused -- or the default, the accent one, else Cancel -- Esc
 *   Cancel; typed into its name field (`data-keys-field="dialog"`), Enter and
 *   Esc the same. Space and Tab are the browser's, on the button focused.
 * - **The focus stays in it**: two stops at its ends send Tab round, and a
 *   focus that lands outside it (a click on nothing) is brought back.
 * - **Esc as the browser's close request** too, where it has one
 *   (`onCloseRequest`): Cancel.
 * - **A list to tick** (`list`), where the question is about several things
 *   at once -- Stop's "Keep what you changed while paused?" (`keepDialog`):
 *   a row each, ticked or not, the ticks handed to each button's `run`. Its
 *   way out may be one of its own buttons (`cancelButton: false`): Esc then
 *   means what that button says (`cancel`).
 *
 * One root (`mountDialogs`, the editor's own element, whose tokens it draws
 * with: `shell.css`'s `.ed-dialog`).
 */
import type { DebugAction } from '@vibe/engine/debug';
import { button, el } from './dom.ts';
import { onCloseRequest, textInput } from './fields.ts';
import { keyed } from './editor-keys.ts';

/** A button of the dialog's. `run` is handed the name typed, where there is a field. */
export interface DialogButton {
  readonly label: string;
  readonly title?: string;
  /** Its look: `accent` the one Enter presses, `danger` what cannot be had back, `quiet` the way out. */
  readonly kind?: 'accent' | 'danger' | 'quiet';
  /** It needs the name field filled: empty, the focus goes there instead. */
  readonly takesName?: boolean;
  /**
   * What it does, the dialog taken down first. A promise that answers false
   * keeps it up -- a name refused -- its buttons back on; anything else, down.
   * `up`: is the dialog still up -- false once Esc or Cancel took it down while
   * the promise was pending: what was to follow is then not done.
   */
  run(name: string, choice?: string, up?: () => boolean, ticks?: readonly boolean[], second?: string): void | boolean | Promise<boolean | void>;
}

/** A row of a dialog's list: its words, ticked at first or not, and its whole text on hover. */
export interface DialogRow {
  readonly text: string;
  readonly ticked: boolean;
  readonly title?: string;
}

export interface DialogSpec {
  readonly title: string;
  readonly text: string;
  /** A name to type, in the dialog: its value at first, and its label. */
  readonly field?: { readonly value: string; readonly label: string };
  /** A second line to type, under the name -- the game view's Add…: a preset's size. Its text goes to each button's `run` last. */
  readonly second?: { readonly value: string; readonly label: string; readonly title?: string };
  /**
   * One of a list, under the name -- New model's folder: its value at first, its label, the options (value and the
   * words shown), a tip. The value chosen goes to each button's `run` with the name.
   */
  readonly choice?: { readonly value: string; readonly label: string; readonly title?: string; readonly options: readonly { readonly value: string; readonly text: string }[] };
  /** Rows to tick, under the text: their ticks go to each button's `run`. */
  readonly list?: { readonly label: string; readonly rows: readonly DialogRow[] };
  /** In order, left to right; Cancel comes after them -- unless `cancelButton` is false: Esc is then `cancel` alone. */
  readonly buttons: readonly DialogButton[];
  readonly cancelButton?: false;
  /** Cancel, Esc or a dialog put in its place: told once. */
  cancel?(): void;
}

/** The field's name for MrDebug: its Enter and Esc. */
export const DIALOG_FIELD = 'dialog';

let host: HTMLElement | null = null;
/** The dialog up: its backdrop, how it is taken down, what Enter presses. */
let up: { backdrop: HTMLElement; down: (cancelled: boolean) => void; enter: () => void; note: HTMLElement } | null = null;

/** Is a dialog up: the editor's other keys rest while it is. */
export const dialogOpen = (): boolean => up !== null;

/** Where dialogs go: the editor's own element. Returns the undo, which takes one that is up down. */
export function mountDialogs(root: HTMLElement): () => void {
  host = root;
  return () => {
    closeDialog();
    if (host === root) host = null;
  };
}

/** The dialog up, cancelled: Cancel, as Esc does. */
export function closeDialog(): void {
  up?.down(true);
}

/** A line under the dialog's text, in the danger colour: why an answer was refused (a name taken), the dialog kept up to choose again. */
export function dialogNote(text: string): void {
  if (!up) return;
  up.note.textContent = text;
  up.note.hidden = text === '';
}

/** `spec` up, in place of any before it. */
export function showDialog(spec: DialogSpec): void {
  closeDialog();
  if (!host) return;
  const backdrop = el('div', 'ed-dialog-backdrop');
  const card = el('div', 'ed-card ed-dialog');
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-modal', 'true');
  const title = el('div', 'ed-dialog-title', spec.title);
  title.id = 'ed-dialog-title';
  card.setAttribute('aria-labelledby', title.id);
  const text = el('div', 'ed-dialog-text', spec.text);
  card.append(title, text);

  let field: HTMLInputElement | null = null;
  if (spec.field) {
    const line = el('label', 'ed-dialog-field');
    field = textInput(spec.field.value, spec.field.label);
    field.dataset.keysField = DIALOG_FIELD;
    line.append(el('span', 'ed-dim', spec.field.label), field);
    card.append(line);
  }
  let second: HTMLInputElement | null = null;
  if (spec.second) {
    const line = el('label', 'ed-dialog-field');
    second = textInput(spec.second.value, spec.second.label);
    second.dataset.keysField = DIALOG_FIELD;
    if (spec.second.title) second.title = spec.second.title;
    line.append(el('span', 'ed-dim', spec.second.label), second);
    card.append(line);
  }
  let pick: HTMLSelectElement | null = null;
  if (spec.choice) {
    const line = el('label', 'ed-dialog-field');
    pick = el('select', 'ed-input');
    pick.setAttribute('aria-label', spec.choice.label);
    if (spec.choice.title) pick.title = spec.choice.title;
    for (const o of spec.choice.options) pick.append(Object.assign(el('option', undefined, o.text), { value: o.value }));
    pick.value = spec.choice.value;
    line.append(el('span', 'ed-dim', spec.choice.label), pick);
    card.append(line);
  }

  const ticks: HTMLInputElement[] = [];
  if (spec.list) {
    const list = el('div', 'ed-dialog-list');
    list.setAttribute('role', 'group');
    list.setAttribute('aria-label', spec.list.label);
    for (const r of spec.list.rows) {
      const line = el('label', 'ed-check-line ed-dialog-row');
      if (r.title) line.title = r.title;
      const box = el('input', 'ed-check');
      box.type = 'checkbox';
      box.checked = r.ticked;
      ticks.push(box);
      line.append(box, el('span', undefined, r.text));
      list.append(line);
    }
    card.append(list);
  }

  const note = el('div', 'ed-dialog-note');
  note.hidden = true;
  card.append(note);
  const row = el('div', 'ed-buttons ed-dialog-buttons');
  const made: HTMLButtonElement[] = [];
  let busy = false;
  const press = (b: DialogButton): void => {
    if (busy) return;
    const name = field?.value.trim() ?? '';
    if (field && b.takesName && name === '') {
      field.focus();
      return;
    }
    const answer = b.run(name, pick?.value, () => up?.backdrop === backdrop, ticks.map((box) => box.checked), second?.value.trim() ?? '');
    if (answer instanceof Promise) {
      // Waited on, the buttons off: a refusal keeps the dialog up to try again.
      busy = true;
      for (const m of made) m.disabled = true;
      answer.then(
        (ok) => {
          busy = false;
          for (const m of made) m.disabled = false;
          if (ok === false) return (field ?? made[0])?.focus();
          down(false);
        },
        () => {
          busy = false;
          for (const m of made) m.disabled = false;
        },
      );
      return;
    }
    if (answer === false) return;
    down(false);
  };
  for (const b of spec.buttons) {
    const one = button('ui', b.label, b.title ?? '', () => press(b), b.kind === 'accent' ? 'ed-accent' : b.kind === 'danger' ? 'ed-danger' : b.kind === 'quiet' ? 'ed-quiet' : '');
    made.push(one);
    row.append(one);
  }
  const cancel = button('ui', 'Cancel', 'Leave it as it is (Esc)', () => closeDialog(), 'ed-quiet');
  if (spec.cancelButton !== false) row.append(cancel);
  card.append(row);

  // Tab round: a stop at each end sends the focus to the other.
  const first = (): HTMLElement => field ?? made[0] ?? cancel;
  const startStop = el('div', 'ed-dialog-stop');
  const endStop = el('div', 'ed-dialog-stop');
  startStop.tabIndex = 0;
  endStop.tabIndex = 0;
  startStop.addEventListener('focus', () => (spec.cancelButton === false ? (made[made.length - 1] ?? first()) : cancel).focus());
  endStop.addEventListener('focus', () => first().focus());
  backdrop.append(startStop, card, endStop);
  // A press on the backdrop is no answer: the focus kept in the card.
  backdrop.addEventListener('pointerdown', (event) => {
    if (event.target === backdrop) {
      event.preventDefault();
      first().focus();
    }
  });
  const keepIn = (event: FocusEvent): void => {
    if (!backdrop.contains(event.target as Node)) first().focus();
  };
  document.addEventListener('focusin', keepIn);
  const unwatch = onCloseRequest(() => closeDialog());

  const before = document.activeElement as HTMLElement | null;
  function down(cancelled: boolean): void {
    if (!up || up.backdrop !== backdrop) return;
    up = null;
    document.removeEventListener('focusin', keepIn);
    unwatch();
    backdrop.remove();
    if (before && before.isConnected) before.focus({ preventScroll: true });
    if (cancelled) spec.cancel?.();
  }
  /**
   * Enter: the button focused, or the default -- the accent one -- or, with none, Cancel: never a loss by default.
   * With no name to type, the accent one has the focus at first, so Enter is it whichever place it has in the row.
   */
  const enter = (): void => {
    const at = document.activeElement;
    const i = made.findIndex((m) => m === at);
    const b = i >= 0 ? spec.buttons[i] : spec.buttons.find((x) => x.kind === 'accent');
    if (b) press(b);
    else closeDialog();
  };
  up = { backdrop, down, enter, note };
  host.append(backdrop);
  if (field) {
    field.focus();
    field.select();
  } else (made[spec.buttons.findIndex((b) => b.kind === 'accent')] ?? first()).focus();
}

/**
 * The dialog's keys, for the host to register first: Enter and Esc on its
 * buttons, and the same typed into its name field.
 */
export function dialogKeys(): DebugAction[] {
  const enter = (): void => up?.enter();
  return [
    { ...keyed('dialog enter'), help: 'A dialog up: the button focused -- else its default, Save', when: dialogOpen, run: enter },
    { ...keyed('dialog cancel'), help: 'A dialog up: Cancel', when: dialogOpen, run: closeDialog },
    { name: 'dialog name enter', key: ['Enter', 'NumpadEnter'], field: DIALOG_FIELD, help: 'Typed into a dialog\'s name: its default, Save as…', when: dialogOpen, run: enter },
    { name: 'dialog name cancel', key: 'Escape', field: DIALOG_FIELD, help: 'Typed into a dialog\'s name: Cancel', when: dialogOpen, run: closeDialog },
  ];
}

/** What `askUnsaved` asks about, and what each answer does. */
export interface UnsavedQuestion {
  /** What has the changes, as said: `'cave'`, `the new scene`. */
  readonly what: string;
  /** What is about to happen, said after: "Open forest?" -- optional. */
  readonly doing?: string;
  /** Don't save, and Save once it has saved: what was asked for. */
  go(): void;
  /**
   * Save: its own file written -- resolved true once it is -- or, with a
   * `name`, a new one named so. Null: nothing can save it now (`why` says),
   * so no Save is offered.
   */
  save: ((name?: string) => Promise<boolean>) | null;
  /** No file yet: Save is "Save as…", the name asked in the dialog, this its first value. */
  readonly named?: string;
  /** Why it cannot be saved, when `save` is null. */
  readonly why?: string;
  cancel?(): void;
}

/** "'cave' has changes that are not saved": Save (then on), Don't save (on), Cancel. */
export function askUnsaved(q: UnsavedQuestion): void {
  showDialog(unsavedDialog(q));
}

/**
 * `askUnsaved`'s dialog, as a spec: what node tests drive (`dialog.test.ts`).
 * Cancelled -- Cancel, Esc, another dialog in its place -- while its Save is
 * still writing, the Save lands but nothing goes on: what was cancelled is
 * never done after all.
 */
export function unsavedDialog(q: UnsavedQuestion): DialogSpec {
  const lead = `${q.what.charAt(0).toUpperCase()}${q.what.slice(1)} has changes that are not saved`;
  const text = `${lead}${q.why ? `, and they cannot be: ${q.why}` : ''}.${q.doing ? ` ${q.doing}` : ''}`;
  const buttons: DialogButton[] = [];
  /** Cancel, Esc, or a dialog put in its place: a Save still writing goes no further once it lands. */
  let cancelled = false;
  const save = q.save;
  if (save) {
    const asName = q.named !== undefined;
    buttons.push({
      label: asName ? 'Save as…' : 'Save',
      title: asName ? 'Write it as a new file named here, then go on' : 'Write it, then go on',
      kind: 'accent',
      takesName: asName,
      run: (name) =>
        save(asName ? name : undefined).then((ok) => {
          if (ok && !cancelled) q.go();
          return ok;
        }),
    });
  }
  buttons.push({ label: 'Don\'t save', title: 'Go on: what changed since it was last saved is lost', kind: 'danger', run: () => q.go() });
  return {
    title: 'Unsaved changes',
    text,
    ...(save && q.named !== undefined ? { field: { value: q.named, label: 'Name' } } : {}),
    buttons,
    cancel: () => {
      cancelled = true;
      q.cancel?.();
    },
  };
}

/**
 * Stop's question after a playtest whose pauses changed things (Docs/studio.md §1): "Keep what you changed while
 * paused?", a row each ticked as `rows` says, and **Keep all**, **Keep none** and **Keep ticked** -- the first two
 * ignoring the ticks; Keep ticked the accent, Enter's, as the ticks are what is on screen. Esc, or a dialog put in
 * its place, is Keep none. `keep` is told once: every row's tick (all
 * true for Keep all, all false for Keep none).
 */
export function keepDialog(rows: readonly DialogRow[], keep: (ticked: readonly boolean[]) => void): DialogSpec {
  let told = false;
  const once = (ticked: readonly boolean[]): void => {
    if (told) return;
    told = true;
    keep(ticked);
  };
  const n = rows.length;
  return {
    title: 'Keep what you changed while paused?',
    text: `The scene is as the playtest found it. ${n === 1 ? 'This was' : `These ${n} were`} changed while it was paused: kept, as one step Z undoes.`,
    list: { label: 'What changed while paused', rows },
    buttons: [
      { label: 'Keep all', title: 'Every change, whatever is ticked', run: () => once(rows.map(() => true)) },
      { label: 'Keep none', title: 'The scene as the playtest found it (Esc)', kind: 'quiet', run: () => once(rows.map(() => false)) },
      { label: 'Keep ticked', title: 'Only the changes ticked (Enter)', kind: 'accent', run: (_name, _choice, _up, ticks) => once(ticks ?? rows.map((r) => r.ticked)) },
    ],
    cancelButton: false,
    cancel: () => once(rows.map(() => false)),
  };
}
