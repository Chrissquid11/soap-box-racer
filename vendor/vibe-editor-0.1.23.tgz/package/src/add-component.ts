/**
 * The inspector's Add Component button and its card, Unity's way (Docs/ecs.md §3, "Where the menu lists it"): a
 * full-width button under the blocks that drops a card down under itself -- a search field at its top, focused, and
 * under it the categories (`component-menu.ts`), each a row with ▸ that opens it *in place*, the card showing what is
 * in it under a ← header that goes back up. In place rather than `menu.ts`' submenus beside it: the inspector is at
 * the window's right edge and as narrow as 240 px, where a submenu beside it has no room and would open over the
 * scene on the left, a second card away from the first.
 *
 * - **Typed, a flat list**: every component whose name matches, best first (`searchMenu`), its category dim beside
 *   it; nothing typed, the categories again.
 * - **Its keys are MrDebug's** (`addComponentKeys`, the Scene tab's): field actions of `data-keys-field="add-component"`
 *   (`ADD_FIELD`), never a listener of the field's own (CLAUDE.md). ↑ ↓ walk the rows, Enter adds the one lit (the
 *   first by default) or opens it if a category, → opens a category lit, ← or Backspace with nothing typed go back a
 *   level, Esc clears what is typed -- or, with nothing typed, closes the card.
 * - **A pick adds through the inspector's own `addTo`**: to every one shown that has it not, one step (`Add BoxCollider
 *   × 2`). The card closes first.
 * - **It outlives its button** as the tags' drop-down does: the inspector is built again after an edit or a tick, so
 *   the card is kept by the place (`AdderState`) and the button built again takes it over (`rebind`), what is typed and
 *   where it is kept. It floats through `drop.ts`' `dropUnder`: a window resized leaves it open, placed again against
 *   its button, as a scroll does. A press anywhere else, or the button again, closes it; so does the button leaving
 *   the page for good (nothing selected).
 */
import type { AnyComponent } from '@vibe/engine';
import { menuRows, menuTree, nodeAt, type MenuEntry, type MenuNode, type MenuRow } from './component-menu.ts';
import { control, el } from './dom.ts';
import { textInput } from './fields.ts';
import type { Mcp } from './mcp/declare.ts';
import { dropUnder, type Dropped } from './drop.ts';
import type { ToolKey } from './tool.ts';

/** The card's search field's key scope (MrDebug's `data-keys-field`): its ↑ ↓ ← → Enter Backspace and Esc. */
export const ADD_FIELD = 'add-component';

/** What a button offers and how it adds: read again as the card fills. */
export interface AdderSource {
  /** What may be added (`offered`). */
  entries(): readonly MenuEntry[];
  /** `component` added to every one shown that has it not: one step. */
  add(component: AnyComponent): void;
  /** How many are shown: the button's hover says so for several. */
  readonly many: number;
  /** The tool that does what a row does: `scene_component` in the scene, `prefab_edit` on a prefab's root. */
  readonly mcp: Mcp;
}

/** A place's card -- the inspector's, the Assets tool's Root block's -- kept as its button is built again. */
export interface AdderState {
  /** Where the card floats: the editor's root. */
  readonly root: HTMLElement;
  card: Card | null;
}

export const adderState = (root: HTMLElement): AdderState => ({ root, card: null });

/** The place's card closed, if it is open. */
export function shutAdder(state: AdderState): void {
  state.card?.close();
}

/** An open card: what its keys do. */
interface Card {
  rebind(button: HTMLButtonElement, source: AdderSource): void;
  step(by: number): void;
  enter(): void;
  /** Into the category lit; false if the row lit is none. */
  open(): boolean;
  /** Up a level; false at the top. */
  back(): boolean;
  escape(): void;
  close(): void;
  /** Nothing typed, and down in a category: ← and Backspace go back. */
  canBack(): boolean;
  /** Nothing typed, and the row lit a category: → opens it. */
  canOpen(): boolean;
  inPage(): boolean;
}

/** The card open now, if any: what the keys work. */
let current: Card | null = null;

/** Is an Add Component card open? One whose button left the page with it open is let go. */
export function adderOpen(): boolean {
  if (current !== null && !current.inPage()) current.close();
  return current !== null;
}

/** The card's keys, for the Scene tab to register: field actions, typed into its search alone. */
export function addComponentKeys(): ToolKey[] {
  const when = adderOpen;
  return [
    { name: 'add component up', mcp: 'ui', key: 'ArrowUp', field: ADD_FIELD, view: true, anySide: true, help: 'In Add Component: the row above', when, run: () => current?.step(-1) },
    { name: 'add component down', mcp: 'ui', key: 'ArrowDown', field: ADD_FIELD, view: true, anySide: true, help: 'In Add Component: the row below', when, run: () => current?.step(1) },
    { name: 'add component', mcp: ['scene_component', 'prefab_edit'], key: ['Enter', 'NumpadEnter'], field: ADD_FIELD, anySide: true, help: 'In Add Component: add the component lit, or open the category lit', when, run: () => current?.enter() },
    { name: 'add component open', mcp: 'ui', key: 'ArrowRight', field: ADD_FIELD, view: true, anySide: true, help: 'In Add Component: open the category lit', when: () => adderOpen() && current!.canOpen(), run: () => void current?.open() },
    { name: 'add component back', mcp: 'ui', key: ['ArrowLeft', 'Backspace'], field: ADD_FIELD, view: true, anySide: true, help: 'In Add Component, nothing typed: back up a level', when: () => adderOpen() && current!.canBack(), run: () => void current?.back() },
    { name: 'add component cancel', mcp: 'ui', key: 'Escape', field: ADD_FIELD, view: true, anySide: true, help: 'In Add Component: clear the search, or close it', when, run: () => current?.escape() },
  ];
}

/** The card is at least this wide, over a narrow inspector. */
const MIN_WIDTH = 220;

/**
 * The Add Component button for `source`: a click drops the card down under it, or takes it up. If `state`'s card is
 * open, this button -- the inspector built again -- takes it over.
 */
export function addComponentButton(state: AdderState, source: AdderSource): HTMLButtonElement {
  const button = control('ui', 'ed-button ed-addc-button', 'Add Component');
  button.setAttribute('aria-haspopup', 'listbox');
  button.setAttribute('aria-expanded', 'false');
  const none = source.entries().length === 0;
  button.disabled = none;
  button.title = none
    ? 'Every component there is is on it already'
    : source.many > 1
      ? `Add a component to every one of the ${source.many} that has none: search, or open a category`
      : 'Add a component: search, or open a category';
  button.addEventListener('click', () => {
    if (state.card) return state.card.close();
    openCard(state, button, source);
  });
  if (state.card) state.card.rebind(button, source);
  return button;
}

/** The card, open under `button`. */
function openCard(state: AdderState, first: HTMLButtonElement, firstSource: AdderSource): void {
  let button = first;
  let source = firstSource;
  const card = el('div', 'ed-card ed-menu ed-addc');
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-label', 'Add Component');
  const head = el('div', 'ed-addc-head');
  const search = textInput('', 'Search components…');
  search.classList.add('ed-addc-search');
  search.dataset.keysField = ADD_FIELD;
  search.setAttribute('role', 'combobox');
  search.setAttribute('aria-label', 'Search components');
  const list = el('div', 'ed-addc-list');
  list.setAttribute('role', 'listbox');
  card.append(head, search, list);

  /** Where it is: the categories opened, outermost first. */
  let path: string[] = [];
  /** The rows shown and the one lit. */
  let rows: MenuRow[] = [];
  let at = 0;
  /** What the rows were filled from, to fill them again only when it changes: a tick's rebuild leaves them be. */
  let filled = '';
  let entries: readonly MenuEntry[] = [];
  let top: MenuNode = menuTree([]);

  const light = (): void => {
    const shown = list.children;
    for (let i = 0; i < shown.length; i++) {
      const row = shown[i] as HTMLElement;
      const lit = i === at;
      row.classList.toggle('ed-at', lit);
      row.setAttribute('aria-selected', String(lit));
      if (lit) {
        if (row.offsetTop < list.scrollTop) list.scrollTop = row.offsetTop;
        else if (row.offsetTop + row.offsetHeight > list.scrollTop + list.clientHeight) list.scrollTop = row.offsetTop + row.offsetHeight - list.clientHeight;
      }
    }
  };

  const drawHead = (): void => {
    head.textContent = '';
    if (path.length === 0 || search.value.trim() !== '') {
      head.append(el('div', 'ed-menu-title ed-addc-title', search.value.trim() !== '' ? 'Search' : 'Add Component'));
      return;
    }
    const back = control('ui', 'ed-menu-item ed-addc-back');
    back.title = 'Back up a level (← or Backspace)';
    back.append(el('span', 'ed-addc-arrow', '←'), el('span', 'ed-addc-path', path.join(' / ')));
    back.addEventListener('pointerdown', (event) => event.preventDefault());
    back.addEventListener('click', () => void goBack());
    head.append(back);
  };

  /** The rows drawn again: `keepAt`, the one lit stays lit where it can. */
  const fill = (keepAt: boolean): void => {
    entries = source.entries();
    top = menuTree(entries);
    // A category opened that is empty now (its last component added elsewhere): back up to one that is not.
    while (path.length > 0 && nodeAt(top, path) === null) path = path.slice(0, -1);
    rows = menuRows(top, path, search.value, entries);
    filled = `${path.join('/')}|${search.value}|${entries.map((x) => x.name).join(',')}`;
    at = keepAt ? Math.max(0, Math.min(at, rows.length - 1)) : 0;
    drawHead();
    list.textContent = '';
    const typed = search.value.trim() !== '';
    rows.forEach((row, i) => list.append(rowOf(row, i, typed)));
    if (rows.length === 0) list.append(el('div', 'ed-menu-note ed-dim', typed ? `No component matches “${search.value.trim()}”` : 'Nothing to add here'));
    light();
    place();
  };

  const rowOf = (row: MenuRow, i: number, typed: boolean): HTMLElement => {
    if (row.kind === 'category') {
      const b = control('ui', 'ed-menu-item ed-addc-row ed-addc-category');
      b.setAttribute('role', 'option');
      b.title = `${row.node.path.join(' / ')}: ${row.node.count} component${row.node.count === 1 ? '' : 's'}`;
      b.append(el('span', 'ed-addc-name', row.node.name), el('span', 'ed-addc-more', `${row.node.count} ▸`));
      hook(b, i);
      return b;
    }
    const { entry } = row;
    const b = control(source.mcp, 'ed-menu-item ed-addc-row');
    b.setAttribute('role', 'option');
    b.title = entry.help ? `${entry.name} -- ${entry.help}` : entry.name;
    b.append(el('span', 'ed-addc-name', entry.name));
    // In a search, where each is: its category, dim.
    if (typed) b.append(el('span', 'ed-addc-where ed-dim', entry.path.join(' / ')));
    hook(b, i);
    return b;
  };
  /** A row's pointer: lit as it is moved over, chosen as it is clicked -- the search keeping the focus. */
  const hook = (b: HTMLElement, i: number): void => {
    b.addEventListener('pointerdown', (event) => event.preventDefault());
    b.addEventListener('pointermove', () => {
      if (at === i) return;
      at = i;
      light();
    });
    b.addEventListener('click', () => {
      at = i;
      choose();
    });
  };

  /** The row lit: a category opened, a component added. */
  const choose = (): void => {
    const row = rows[at];
    if (!row) return;
    if (row.kind === 'category') {
      path = [...row.node.path];
      search.value = '';
      fill(false);
      search.focus();
      return;
    }
    const component = row.entry.component;
    const adding = source;
    close();
    adding.add(component);
  };
  const goBack = (): boolean => {
    if (path.length === 0) return false;
    const left = path[path.length - 1]!;
    path = path.slice(0, -1);
    fill(false);
    // The category just left lit, as a list's back does.
    const i = rows.findIndex((r) => r.kind === 'category' && r.node.name === left);
    if (i >= 0) {
      at = i;
      light();
    }
    search.focus();
    return true;
  };

  let closed = false;
  function close(): void {
    if (closed) return;
    closed = true;
    dropped?.();
    if (state.card === handle) state.card = null;
    if (current === handle) current = null;
  }
  /** Floated under its button (`dropUnder`, the tags' list's): placed, followed, let go on a press elsewhere. */
  let dropped: Dropped | null = null;
  const place = (): void => dropped?.place();

  const handle: Card = {
    rebind(next, from) {
      const had = document.activeElement === search;
      button = next;
      source = from;
      dropped?.rebind(button);
      const now = `${path.join('/')}|${search.value}|${source.entries().map((x) => x.name).join(',')}`;
      if (now !== filled) fill(true);
      else place();
      if (had && document.activeElement !== search) search.focus();
    },
    step(by) {
      if (rows.length === 0) return;
      at = (at + by + rows.length) % rows.length;
      light();
    },
    enter: choose,
    open() {
      const row = rows[at];
      if (row?.kind !== 'category') return false;
      choose();
      return true;
    },
    back: goBack,
    escape() {
      if (search.value !== '') {
        search.value = '';
        fill(false);
      } else close();
    },
    close,
    canBack: () => search.value === '' && path.length > 0,
    canOpen: () => search.value === '' && rows[at]?.kind === 'category',
    inPage: () => button.isConnected,
  };

  search.addEventListener('input', () => fill(false));
  // One card open at a time: another place's goes.
  current?.close();
  current = handle;
  state.card = handle;
  dropped = dropUnder(state.root, button, card, close, { minWidth: MIN_WIDTH, fit: true });
  fill(false);
  search.focus();
}

