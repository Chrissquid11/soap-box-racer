/**
 * The tree's filter (Docs/ecs.md §13): what is typed, read into what a row
 * must have to be listed. Pure, so node tests it.
 *
 * - **Words**, each of which a row must match somewhere -- its name, a
 *   component's name or a label: `crate wander` is a crate that wanders.
 * - **`#spawn`**: a label with `spawn` in it; `#` alone, any label at all.
 * - **`layer:Enemies`, `layer:2`**: on that layer, by its name or its number.
 * - **`prefab:crates/big`**: made by a prefab with that in its key -- its
 *   instances' roots and every entity inside them; `prefab:crates`, any crate.
 * - **`overridden`**: an instance's root that changes anything of its prefab
 *   (Docs/prefabs.md §7) -- worked out only when asked for.
 *
 * Case is never minded.
 */

/** What the filter reads of an entity. */
export interface FilterFacts {
  name: string;
  components: readonly string[];
  labels: readonly string[];
  layer: number;
  layerName: string;
  /** The key of the prefab that made it; '' for none. */
  prefab: string;
  /** An instance's root with any override: asked only of a filter with `overridden` (it is worked out, not kept). */
  overridden?: () => boolean;
}

/** A filter as read: every part must match. */
export interface Filter {
  words: string[];
  /** After a `#`; '' for any label. */
  labels: string[];
  /** After `layer:`. */
  layers: string[];
  /** After `prefab:`. */
  prefabs: string[];
  /** `overridden`: only instances' roots that change their prefab. */
  overridden: boolean;
}

/** What was typed, read; null for nothing typed, which lists every row in the tree. */
export function readFilter(text: string): Filter | null {
  const filter: Filter = { words: [], labels: [], layers: [], prefabs: [], overridden: false };
  for (const part of text.toLowerCase().split(/\s+/)) {
    if (!part) continue;
    if (part.startsWith('#')) filter.labels.push(part.slice(1));
    else if (part.startsWith('layer:') && part.length > 6) filter.layers.push(part.slice(6));
    else if (part.startsWith('prefab:') && part.length > 7) filter.prefabs.push(part.slice(7));
    else if (part === 'overridden') filter.overridden = true;
    else filter.words.push(part);
  }
  return filter.words.length + filter.labels.length + filter.layers.length + filter.prefabs.length > 0 || filter.overridden ? filter : null;
}

/** Does an entity with these facts pass? A layer by number is that number; by name, one with it in its name. */
export function passes(filter: Filter, facts: FilterFacts): boolean {
  const labels = facts.labels.map((label) => label.toLowerCase());
  const named = facts.layerName.toLowerCase();
  if (!filter.layers.every((layer) => (/^\d+$/.test(layer) ? Number(layer) === facts.layer : named.includes(layer)))) return false;
  const prefab = facts.prefab.toLowerCase();
  if (!filter.prefabs.every((key) => prefab !== '' && prefab.includes(key))) return false;
  if (!filter.labels.every((label) => (label === '' ? labels.length > 0 : labels.some((l) => l.includes(label))))) return false;
  if (filter.overridden && !(facts.overridden?.() ?? false)) return false;
  const hay = [facts.name, ...facts.components, ...labels].join('\n').toLowerCase();
  return filter.words.every((word) => hay.includes(word));
}
