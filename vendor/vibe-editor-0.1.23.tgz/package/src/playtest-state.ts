/**
 * A playtest's three states, and what each key and button does in them (Docs/studio.md §1, "Playtest"):
 *
 * - **`none`**: the editor as ever. `F5`, `T` or the strip's Play start one from the world as it is.
 * - **`running`**: the game runs, its HUD up, the editor hidden under it. `F6` or `P` (boot's key, studio mode) pause
 *   it; `Shift+F5`, `T`, Esc or the pill's Stop end it -- the world it found put back, history as it was.
 * - **`paused`**: the game paused and the editor over its world as the playtest has it now -- nothing put back --
 *   its edits steps on that world. `F10` steps one tick; `F5`, `P`, `T` or the strip's Play run it on from there;
 *   `Shift+F5`, Esc or Stop end it as from `running`.
 *
 * The keys of every debugger: F5 play or continue, F6 pause, Shift+F5 stop, F10 step (`PLAY_KEYS`).
 * `next` is the rule, pure; `editor.ts` runs what it says. `playtestBar` is what the play strip and the pill show of
 * it. Node tests both (`playtest-state.test.ts`).
 */
import { tabKey } from './editor-keys.ts';

export type PlaytestState = 'none' | 'running' | 'paused';

/** The four buttons of the play strip and the pill, by the event each sends: Play, Pause, Stop, Step. */
export type PlayButton = 'F5' | 'F6' | 'stop' | 'step';

/**
 * A key, or a button: `T`, `P` (boot's, in studio mode), Esc; `F5` (and Play), `F6` (and Pause), `stop` (Shift+F5, the
 * strip's or the pill's Stop, the app's Game ▸ Stop), `step` (F10, Step); a pause or a resume asked by name (boot's
 * `pausePlaytest`, `resumePlaytest`) -- each of those only in the one state it names, nothing elsewhere.
 */
export type PlaytestEvent = 'T' | 'P' | 'Esc' | 'pause' | 'resume' | PlayButton;

/** What the editor does: begin one, pause it under the editor, run it on, end it with the world put back, run one tick -- or nothing. */
export type PlaytestAction = 'start' | 'pause' | 'resume' | 'stop' | 'step' | null;

/** The MrDebug keys of the four (`KeyboardEvent.code`, a chord for Stop): the editor's actions, the app menu's accelerators. */
export const PLAY_KEYS: Record<PlayButton, string> = { F5: tabKey('play'), F6: tabKey('pause'), stop: tabKey('stop'), step: tabKey('step') };

const NOTHING = (state: PlaytestState): { state: PlaytestState; action: PlaytestAction } => ({ state, action: null });

/** The state `event` leads to from `state`, and what to do on the way. */
export function next(state: PlaytestState, event: PlaytestEvent): { state: PlaytestState; action: PlaytestAction } {
  switch (state) {
    case 'none':
      // P closes nothing here (boot's `staysOpen` in studio mode); Esc and Stop have no playtest to end.
      return event === 'T' || event === 'F5' ? { state: 'running', action: 'start' } : NOTHING(state);
    case 'running':
      if (event === 'P' || event === 'pause' || event === 'F6') return { state: 'paused', action: 'pause' };
      if (event === 'T' || event === 'Esc' || event === 'stop') return { state: 'none', action: 'stop' };
      // F5 plays what plays already; a resume has nothing to resume; a step is for a paused game.
      return NOTHING(state);
    case 'paused':
      if (event === 'Esc' || event === 'stop') return { state: 'none', action: 'stop' };
      if (event === 'step') return { state, action: 'step' };
      if (event === 'pause' || event === 'F6') return NOTHING(state);
      return { state: 'running', action: 'resume' };
  }
}

/** What the play strip and the pill show in a state: which of the four buttons are on, the words in the accent, Play's tooltip. */
export interface PlaytestBar {
  /** Play (F5): to start one, or run a paused one on. */
  play: boolean;
  /** Pause (F6): while running. */
  pause: boolean;
  /** Stop (Shift+F5): while there is one. */
  stop: boolean;
  /** Step (F10): while paused. */
  step: boolean;
  /** Play's tooltip, before its key: Play, or Resume while paused; none while running, Play then off (its last one kept). */
  playTip?: string;
  /** The pill's words: `PLAYING · 12.3 s`, `PAUSED · tick 740`; null with no playtest (no pill). */
  words: string | null;
  /** After the title, as the name line says a scene's: ` · playtest paused`, or nothing. */
  title: string;
}

/** The ticks of a 60 Hz loop as seconds, one decimal: `12.3`. */
const seconds = (ticks: number): string => (Math.max(0, ticks) / 60).toFixed(1);

/** The strip and the pill in `state`, `ticks` the ticks the playtest has run (the loop's, since it began). */
export function playtestBar(state: PlaytestState, ticks = 0): PlaytestBar {
  if (state === 'paused') {
    return {
      play: true, pause: false, stop: true, step: true,
      playTip: 'Resume the playtest: the game runs on from the world as it is now, your changes in it',
      words: `PAUSED · tick ${Math.max(0, ticks)}`, title: ' · playtest paused',
    };
  }
  if (state === 'running') {
    return { play: false, pause: true, stop: true, step: false, words: `PLAYING · ${seconds(ticks)} s`, title: '' };
  }
  return { play: true, pause: false, stop: false, step: false, playTip: 'Play: the game runs from the world as it is, the editor out of the way', words: null, title: '' };
}

/** Said once, the first time a playtest pauses: what Stop and Resume do with the edits made now. */
export const PAUSED_HINT = 'Stop puts the world back as the playtest found it; Resume keeps what you changed';

/**
 * Why the scene is not saved during a playtest (Mod+S, the bar's Save, the Scenes page's, the agent's): the world is the
 * playtest's, not the scene's -- written, the save would hold what the game made of it, and Stop puts the other back.
 */
export const notSavedPlaying = (state: 'running' | 'paused'): string => `a playtest is ${state} -- Stop puts the world back, then Mod+S saves the scene`;

/** Why another world is not opened, made or imported during a playtest: Stop would load the found one over it. */
export const STOP_FIRST = 'Stop the playtest first';
