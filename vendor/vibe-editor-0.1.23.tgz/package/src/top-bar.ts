/**
 * The middle of the top bar, the host's (`createTopBar`, into the shell's
 * `controls`): the gizmo's three modes, World or Local, snapping (V) and --
 * while it is on -- its three steps, each a click to the next; the camera onto
 * everything (Home); the History and keys cards' toggles; and the status line:
 * empty but for a while after something is said -- what was saved, refused,
 * undone -- or while the tool up has a line of its own (`hint`: an entity
 * being picked). No standing hint of what the keys and the mouse do: the keys
 * card (`?`) lists them; and no word for the side with the keys: its focus
 * ring says it.
 *
 * - **Icons only**: each control's name and key are its tooltip (`tip`,
 *   `Move · W`), the active ones lit (`aria-pressed`).
 * - **The gizmo's icons only while the scene is worked in**: with the
 *   viewport inactive -- the Systems and Scenes tabs -- the modes, World, Snap
 *   and its steps and Home are hidden, not dimmed; History, Keys and the line
 *   stay.
 * - **Their keys only where they are keys**: G R S X V are the entity tool's,
 *   so with the Assets panel focused (G is grid or list there) the icons work by
 *   click and their tooltips name no key (`gizmoKeys`).
 * - **The status line gives way first**: one line between these and the
 *   actions, cut with an ellipsis, its whole text on hover.
 *
 * Read on every frame drawn (`refresh`), so it touches only what changed.
 */
import { keyLabel, modName } from '@vibe/engine/debug';
import { editorKey } from './editor-keys.ts';
import { GIZMO_MODES } from './gizmo.ts';
import type { IconName } from './icons.ts';
import { TOGGLE } from './keys-card.ts';
import { cycle, STEPS, stepText, type SnapStep } from './prefs.ts';
import { control, el, icon, letGo, tip } from './shell.ts';
import type { Viewport } from './viewport.ts';
import type { Mcp } from './mcp/declare.ts';
import type { CollidersShown } from './mcp/host.ts';

export interface TopBar {
  /** Read the gizmo's mode and space, the cards' toggles and the line again. */
  refresh(): void;
}

export interface TopBarOptions {
  /** The shell's middle of the bar (`Shell.controls`), between the scene's name and the actions: filled here. */
  into: HTMLElement;
  viewport: Viewport;
  /** What the line says just now -- what the editor said a moment ago, or the tool up's own line -- or null: nothing. */
  said(): string | null;
  /** The whole of what the editor said, where the line is short of it: its hover text. Null: the line itself. */
  saidFull?(): string | null;
  /** Is the History card open, and the way to open or shut it: its toggle is on this bar. */
  historyOpen(): boolean;
  toggleHistory(): void;
  /** The same for the keys card. */
  keysOpen(): boolean;
  toggleKeys(): void;
  /** Are the gizmo's keys -- G R S X V -- live with the tool up? Their tooltips name them only then. */
  gizmoKeys(): boolean;
  /** The keys card's key as a person reads it, for its toggle's tooltip: `?`. */
  keysKey: string;
  /** The collider overlay (Docs/physics.md §7): what it draws now, and the next choice -- none, the selection's, every one. */
  colliders?(): CollidersShown;
  setColliders?(shown: CollidersShown): void;
  /** Physics is off in the project (`physics.json`): the colliders are drawn from the components all the same, and said so. */
  physicsOff?(): boolean;
}

/** The collider overlay's choices in the order a click goes through them. */
const COLLIDER_CYCLE: readonly CollidersShown[] = ['selected', 'all', 'none'];
const COLLIDER_WORDS: Record<CollidersShown, string> = {
  selected: 'Colliders: the selection\'s drawn -- click for every collider',
  all: 'Colliders: every one drawn (green dynamic, blue kinematic, grey static, cyan triggers, dim asleep) -- click for none',
  none: 'Colliders: none drawn -- click for the selection\'s',
};

/** What each snap step is for, as its button's tooltip says it. */
const STEP_NAMES: Record<SnapStep, string> = { move: 'moving', turn: 'turning', scale: 'scaling' };

export function createTopBar(options: TopBarOptions): TopBar {
  const { viewport, keysKey, into } = options;
  // Every button here lets go of the focus after a click (`letGo`): the tool up has the keys.
  const button = (mcp: Mcp, glyph: IconName, run: () => void): HTMLButtonElement => {
    const b = letGo(control(mcp, 'ed-bar-button'));
    b.append(icon(glyph));
    b.addEventListener('click', run);
    return b;
  };
  // Each mode itself, not a copy: its key is read live, the keymap's now (Docs/navigation.md §8).
  const modes = GIZMO_MODES.map((spec) => ({ spec, button: button('ui', spec.icon, () => viewport.setMode(spec.mode)) }));
  const space = button('ui', 'world', () => viewport.toggleSpace());
  const snap = button('ui', 'magnet', () => viewport.setSnap({ on: !viewport.snap.on }));
  // Its steps beside it while snapping is on, each a button of its own: a click is the next in its list, Shift-click the one before.
  const steps = el('span', 'ed-steps');
  const stepButtons = (Object.keys(STEPS) as SnapStep[]).map((which) => {
    const b = letGo(control('ui', 'ed-step'));
    b.addEventListener('click', (event) => viewport.setSnap({ [which]: cycle(which, viewport.snap[which], event.shiftKey) }));
    return { which, b };
  });
  stepButtons.forEach(({ b }, i) => steps.append(...(i > 0 ? [el('span', 'ed-step-dot', '·'), b] : [b])));
  const all = button('view_focus', 'frame', () => viewport.frameAll());
  const colliders = button('view_set', 'colliders', () => {
    const now = options.colliders?.() ?? 'none';
    options.setColliders?.(COLLIDER_CYCLE[(COLLIDER_CYCLE.indexOf(now) + 1) % COLLIDER_CYCLE.length]!);
  });
  colliders.hidden = options.colliders === undefined;
  const historyButton = button('ui', 'history', () => options.toggleHistory());
  tip(historyButton, 'History: every step, a click on one undoes or redoes to it', 'H');
  const keysButton = button('ui', 'keys', () => options.toggleKeys());
  tip(keysButton, 'Keys: every editor key live just now, by tool', keysKey);
  keysButton.classList.add(TOGGLE);
  const gap = (): HTMLElement => el('i', 'ed-hint-gap');
  // The gizmo's own, shown while the scene is worked in; the cards' toggles always.
  const gizmo: HTMLElement[] = [...modes.map((m) => m.button), gap(), space, snap, steps, all, ...(options.colliders ? [colliders] : []), gap()];
  const text = el('div', 'ed-hint-text');
  const line = el('div', 'ed-hint-line');
  line.append(text);
  into.append(...gizmo, historyButton, keysButton, line);

  // Read on every frame drawn, so only what changed is touched.
  let said = '';
  let axes = '';
  let snapped = '';
  let scene: boolean | null = null;
  return {
    refresh() {
      if (viewport.active !== scene) {
        scene = viewport.active;
        for (const part of gizmo) part.hidden = !scene;
      }
      // Frame all's key as the keymap has it now (Docs/navigation.md §8: A under Industry Compatible, Home under Blender).
      tip(all, 'Frame all: the camera onto everything drawn', keyLabel(editorKey('frame all')[0]!));
      const named = options.gizmoKeys();
      for (const { spec: m, button: b } of modes) {
        tip(b, `${m.name}: ${m.help.charAt(0).toLowerCase()}${m.help.slice(1)}`, named ? keyLabel(m.key) : undefined);
        b.setAttribute('aria-pressed', String(m.mode === viewport.mode));
      }
      if (options.colliders) {
        const shown = options.colliders();
        colliders.setAttribute('aria-pressed', String(shown !== 'none'));
        tip(colliders, options.physicsOff?.() ? `${COLLIDER_WORDS[shown]} (physics is off in this project: drawn from the components, nothing simulated)` : COLLIDER_WORDS[shown]);
      }
      historyButton.setAttribute('aria-pressed', String(options.historyOpen()));
      keysButton.setAttribute('aria-pressed', String(options.keysOpen()));
      const local = viewport.space === 'local';
      if (viewport.space !== axes) {
        axes = viewport.space;
        space.replaceChildren(icon(local ? 'local' : 'world'));
      }
      tip(space, local ? 'Local axes: the gizmo along the selection\'s own -- click for the world\'s' : 'World axes: the gizmo along the world\'s -- click for the selection\'s own', named ? 'X' : undefined);
      const { on } = viewport.snap;
      const nowSnapped = JSON.stringify(viewport.snap);
      const stepsSaid = stepButtons.map(({ which }) => stepText(which, viewport.snap[which])).join(' · ');
      tip(snap, `Snap ${on ? 'on' : 'off'} (${stepsSaid}); ${modName()} held while dragging turns it over`, named ? 'V' : undefined);
      if (nowSnapped !== snapped) {
        snapped = nowSnapped;
        snap.setAttribute('aria-pressed', String(on));
        // The steps beside the magnet only while they are what a drag snaps to.
        steps.classList.toggle('ed-off', !on);
        for (const { which, b } of stepButtons) {
          const value = viewport.snap[which];
          b.textContent = stepText(which, value);
          const list = STEPS[which].map((v) => stepText(which, v)).join(', ');
          tip(b, `The step for ${STEP_NAMES[which]}: ${stepText(which, value)}. Click for the next of ${list}; Shift-click for the one before`);
        }
      }
      const now = options.said() ?? '';
      if (now !== said) text.textContent = said = now;
      // The whole of it on hover, so a line cut at the bar's edge is never lost.
      const full = options.saidFull?.() ?? now;
      if (text.title !== full) text.title = full;
    },
  };
}
