/**
 * What a load or a paste skipped (`world.load`, `pasteIn`), and what a load
 * brought up to its prefabs (`refreshInstances`), as sentences to follow what
 * it did: the Scenes tool's Load and Import, Paste, the world brought back
 * across a reload and the game's code swapped in all say it this way.
 *
 * - **Two kinds of item**: what this build has not -- `component Shield`,
 *   `prefab crates/old`, `entity Crate` -- each a noun the one sentence `This
 *   build has no ...` lists; and what changed in a prefab since -- `prefab
 *   crates/big: rider no longer in it; flag added since` -- a sentence of its
 *   own already (`refindNodes`, Docs/prefabs.md §6), told apart by its colon.
 * - **Appended**: '' for nothing skipped, else `. ` and the sentences, so
 *   `Loaded ‘level 2’` reads `Loaded ‘level 2’. Prefab crates/big: flag added
 *   since.`
 */
export function skippedText(skipped: readonly string[]): string {
  if (skipped.length === 0) return '';
  const missing = skipped.filter((s) => !s.includes(': '));
  const changed = skipped.filter((s) => s.includes(': '));
  const sentences: string[] = [];
  if (missing.length > 0) {
    const list = missing.length === 1 ? missing[0]! : `${missing.slice(0, -1).join(', ')} or ${missing[missing.length - 1]!}`;
    sentences.push(`This build has no ${list}.`);
  }
  for (const s of changed) sentences.push(`${s[0]!.toUpperCase()}${s.slice(1)}.`);
  return `. ${sentences.join(' ')}`;
}

/**
 * What a load brought up to the prefabs as compiled now (`refreshInstances`), said after its line:
 * entities made, overrides dropped. The Scenes tool's Open and Import and a swap of the game's code
 * (`rebuild-follow.ts`) all say it this way; '' for nothing.
 */
export function updatedText(updated: readonly string[] | undefined): string {
  return updated && updated.length > 0 ? ` · its instances brought up to their prefabs: ${updated.join('; ')}` : '';
}
