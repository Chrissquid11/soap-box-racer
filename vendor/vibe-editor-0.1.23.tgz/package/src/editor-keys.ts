/**
 * The editor's keys -- the one record of them -- and how they give way to a game's (Docs/studio.md, "Keys"). Node-safe:
 * no DOM; the pipeline's `keys` check reads this file as text, one `'<name>': [<keys>],` a line of `EDITOR_KEYS`.
 *
 * - **`EDITOR_KEYS`**: every key the editor takes outside a field, by its action's name (after `editor: `) -- the
 *   host's, each of its own tools', the dialog's. **The source**: each of those actions takes its keys from here
 *   (`keyed('save')`, its name and keys at once, typed to the names; a generated family -- the numpad's views, their emulated twins -- by
 *   `editorKeyOf`, which throws on a name not here), and the menus' and tooltips' captions read them here too. Nowhere
 *   else writes one: `editor-keys.test.ts` builds what the node-safe definitions register and scans the rest of the
 *   editor's source for the names, failing on a name here nothing registers, one registered not here, and a key written
 *   at a definition by hand. A project's tools' keys are not here: they are the project's.
 * - **`giveWay`**: an editor key added through MrDebug without the keys an action already there always takes -- a
 *   game's debug key with no `when`, registered before the editor was made (MrDebug would throw, and one throw out of
 *   `createEditor` is no editor at all). The editor's action keeps its other keys (the walk's left on A and Alt+A, the
 *   game's on Shift+A), and with none left is registered with no key (a keymap switched may free one); each key
 *   given up kept for `clashText`'s notice. A
 *   game's key that has a `when` is no clash here: both are registered, and MrDebug's lookup takes the first live one
 *   -- the game's, registered first -- while its `when` holds (the check notes it).
 */
import { keyLabel, type DebugAction, type DebugRouter } from '@vibe/engine';

/** Every key the editor takes outside a field: each action's name (after `editor: `) and its keys, as written. */
export const EDITOR_KEYS = {
  'dialog enter': ['Enter', 'NumpadEnter'],
  'dialog cancel': ['Escape'],
  'walk forward': ['KeyW', 'Shift+KeyW', 'Alt+KeyW'],
  'walk back': ['KeyS', 'Shift+KeyS', 'Alt+KeyS'],
  'walk left': ['KeyA', 'Shift+KeyA', 'Alt+KeyA'],
  'walk right': ['KeyD', 'Shift+KeyD', 'Alt+KeyD'],
  'walk up': ['KeyE', 'Shift+KeyE', 'Alt+KeyE'],
  'walk down': ['KeyQ', 'Shift+KeyQ', 'Alt+KeyQ'],
  'walk keep': ['Enter', 'NumpadEnter', 'Space'],
  'walk put back': ['Escape'],
  'entities': ['Digit1'],
  'config': ['Digit2'],
  'model': ['Digit3'],
  'studio': ['Digit5'],
  'assets': ['Digit4'],
  'quick prompt': ['Mod+KeyK'],
  'claude': ['Mod+Semicolon'],
  'ai card': ['Mod+KeyI'],
  'claude new tab': ['Alt+KeyT'],
  'claude close tab': ['Alt+KeyW'],
  'claude next tab': ['Alt+BracketRight'],
  'claude previous tab': ['Alt+BracketLeft'],
  'claude tab 1': ['Alt+Digit1'],
  'claude tab 2': ['Alt+Digit2'],
  'claude tab 3': ['Alt+Digit3'],
  'claude tab 4': ['Alt+Digit4'],
  'claude tab 5': ['Alt+Digit5'],
  'claude tab 6': ['Alt+Digit6'],
  'save': ['Mod+KeyS'],
  'playtest': ['KeyT'],
  'play': ['F5'],
  'pause': ['F6'],
  'stop': ['Shift+F5'],
  'step': ['F10'],
  'undo': ['KeyZ', 'Mod+KeyZ'],
  'redo': ['KeyY', 'Mod+Shift+KeyZ', 'Mod+KeyY'],
  'history': ['KeyH'],
  'frame all': ['Home', 'Shift+KeyC'],
  'keys': ['Shift+Slash', 'Slash'],
  'cards': ['Backquote', 'IntlBackslash'],
  'close quick prompt': ['Escape'],
  'cards back': ['Escape'],
  'prefab back': ['Alt+ArrowUp'],
  'close keys': ['Escape'],
  'close game view menu': ['Escape'],
  'game view menu up': ['ArrowUp'],
  'game view menu down': ['ArrowDown'],
  'close claude menu': ['Escape'],
  'claude menu up': ['ArrowUp'],
  'claude menu down': ['ArrowDown'],
  'cancel': ['Escape'],
  'close history': ['Escape'],
  'stop playtest': ['Escape'],
  'prefab unsaved': ['Escape'],
  'move': ['KeyG'],
  'rotate': ['KeyR'],
  'scale': ['KeyS'],
  'world or local': ['KeyX'],
  'snap': ['KeyV'],
  'focus': ['KeyF', 'NumpadDecimal'],
  'view front': ['Numpad1'],
  'view back': ['Mod+Numpad1', 'Ctrl+Numpad1'],
  'view right': ['Numpad3'],
  'view left': ['Mod+Numpad3', 'Ctrl+Numpad3'],
  'view top': ['Numpad7'],
  'view bottom': ['Mod+Numpad7', 'Ctrl+Numpad7'],
  'view flip': ['Numpad9'],
  'view projection': ['Numpad5'],
  'view orbit down': ['Numpad2'],
  'view orbit up': ['Numpad8'],
  'view orbit left': ['Numpad4'],
  'view orbit right': ['Numpad6'],
  'view pan down': ['Mod+Numpad2', 'Ctrl+Numpad2'],
  'view pan up': ['Mod+Numpad8', 'Ctrl+Numpad8'],
  'view pan left': ['Mod+Numpad4', 'Ctrl+Numpad4'],
  'view pan right': ['Mod+Numpad6', 'Ctrl+Numpad6'],
  'view zoom in': ['NumpadAdd'],
  'view zoom out': ['NumpadSubtract'],
  'walk': ['Shift+Backquote', 'Shift+IntlBackslash'],
  'view camera': ['Numpad0'],
  'camera to view': ['Mod+Alt+Numpad0', 'Ctrl+Alt+Numpad0'],
  'fly arrows': ['ArrowUp', 'Shift+ArrowUp', 'ArrowDown', 'Shift+ArrowDown', 'ArrowLeft', 'Shift+ArrowLeft', 'ArrowRight', 'Shift+ArrowRight'],
  'menu item above': ['ArrowUp'],
  'menu item below': ['ArrowDown'],
  'submenu open': ['ArrowRight'],
  'submenu close': ['ArrowLeft'],
  'row above': ['ArrowUp'],
  'row below': ['ArrowDown'],
  'fold row': ['ArrowLeft'],
  'unfold row': ['ArrowRight'],
  'duplicate': ['KeyD', 'Mod+KeyD'],
  'copy': ['Mod+KeyC'],
  'paste': ['Mod+KeyV'],
  'select all': ['Mod+KeyA'],
  'select none': ['Mod+Shift+KeyA'],
  'hide': ['Shift+KeyH'],
  'lock picking': ['Shift+KeyL'],
  'switch off': ['Shift+KeyE'],
  'lock inspector': ['Alt+KeyL'],
  'save as prefab': ['Shift+KeyS'],
  'delete': ['Delete'],
  'delete (backspace)': ['Backspace'],
  'view front (numpad emulated)': ['Digit1'],
  'view back (numpad emulated)': ['Mod+Digit1', 'Ctrl+Digit1'],
  'view right (numpad emulated)': ['Digit3'],
  'view left (numpad emulated)': ['Mod+Digit3', 'Ctrl+Digit3'],
  'view top (numpad emulated)': ['Digit7'],
  'view bottom (numpad emulated)': ['Mod+Digit7', 'Ctrl+Digit7'],
  'view flip (numpad emulated)': ['Digit9'],
  'view projection (numpad emulated)': ['Digit5'],
  'view orbit down (numpad emulated)': ['Digit2'],
  'view orbit up (numpad emulated)': ['Digit8'],
  'view orbit left (numpad emulated)': ['Digit4'],
  'view orbit right (numpad emulated)': ['Digit6'],
  'view pan down (numpad emulated)': ['Mod+Digit2', 'Ctrl+Digit2'],
  'view pan up (numpad emulated)': ['Mod+Digit8', 'Ctrl+Digit8'],
  'view pan left (numpad emulated)': ['Mod+Digit4', 'Ctrl+Digit4'],
  'view pan right (numpad emulated)': ['Mod+Digit6', 'Ctrl+Digit6'],
  'view zoom in (numpad emulated)': ['Equal'],
  'view zoom out (numpad emulated)': ['Minus'],
  'view camera (numpad emulated)': ['Digit0'],
  'camera to view (numpad emulated)': ['Mod+Alt+Digit0', 'Ctrl+Alt+Digit0'],
  'config up': ['ArrowUp'],
  'config down': ['ArrowDown'],
  'config fold': ['ArrowLeft'],
  'config unfold': ['ArrowRight'],
  'config toggle': ['Enter'],
  'model frame': ['KeyF', 'NumpadDecimal'],
  'model layout': ['KeyL'],
  'model shading': ['Shift+KeyZ'],
  'model grid': ['KeyG'],
  'model stats': ['KeyI'],
  'model front': ['Numpad1'],
  'model back': ['Mod+Numpad1', 'Ctrl+Numpad1'],
  'model right': ['Numpad3'],
  'model left': ['Mod+Numpad3', 'Ctrl+Numpad3'],
  'model top': ['Numpad7'],
  'model bottom': ['Mod+Numpad7', 'Ctrl+Numpad7'],
  'model flip': ['Numpad9'],
  'model projection': ['Numpad5'],
  'model orbit down': ['Numpad2'],
  'model orbit up': ['Numpad8'],
  'model orbit left': ['Numpad4'],
  'model orbit right': ['Numpad6'],
  'model pan down': ['Mod+Numpad2', 'Ctrl+Numpad2'],
  'model pan up': ['Mod+Numpad8', 'Ctrl+Numpad8'],
  'model pan left': ['Mod+Numpad4', 'Ctrl+Numpad4'],
  'model pan right': ['Mod+Numpad6', 'Ctrl+Numpad6'],
  'model zoom in': ['NumpadAdd'],
  'model zoom out': ['NumpadSubtract'],
  'model hide': ['Shift+KeyH'],
  'model show all': ['Alt+KeyH'],
  'model select all': ['Mod+KeyA'],
  'model fly ahead': ['ArrowUp', 'ArrowDown', 'Shift+ArrowUp', 'Shift+ArrowDown'],
  'model fly across': ['ArrowLeft', 'ArrowRight', 'Shift+ArrowLeft', 'Shift+ArrowRight'],
  'model part above': ['ArrowUp'],
  'model part below': ['ArrowDown'],
  'model build': ['KeyB'],
  'model fly forward': ['KeyW', 'Shift+KeyW'],
  'model fly back': ['KeyS', 'Shift+KeyS'],
  'model fly left': ['KeyA', 'Shift+KeyA'],
  'model fly right': ['KeyD', 'Shift+KeyD'],
  'model fly down': ['KeyQ', 'Shift+KeyQ'],
  'model fly up': ['KeyE', 'Shift+KeyE'],
  'model walk': ['Shift+Backquote', 'Shift+IntlBackslash'],
  'model canvases': ['KeyC'],
  'model brush or eraser': ['KeyX'],
  'model marquee': ['KeyM'],
  'model brush smaller': ['BracketLeft'],
  'model brush bigger': ['BracketRight'],
  'model copy marks': ['Mod+KeyC'],
  'model cut marks': ['Mod+KeyX'],
  'model paste marks': ['Mod+KeyV'],
  'model delete marks': ['Delete', 'Backspace'],
  'model delete part': ['Delete', 'Backspace'],
  'model play': ['Space'],
  'model frame back': ['ArrowLeft'],
  'model frame on': ['ArrowRight'],
  'model clip start': ['Shift+ArrowLeft'],
  'model clip end': ['Shift+ArrowRight'],
  'model key pose': ['KeyK'],
  'model pose move': ['KeyG'],
  'model pose rotate': ['KeyR'],
  'model pose scale': ['KeyS'],
  'model bones': ['KeyJ'],
  'model trace': ['Shift+KeyT'],
  'model trace play': ['Space'],
  'model trace back': ['ArrowLeft'],
  'model trace on': ['ArrowRight'],
  'model trace start': ['Shift+ArrowLeft'],
  'model trace end': ['Shift+ArrowRight'],
  'model menu up': ['ArrowUp'],
  'model menu down': ['ArrowDown'],
  'model front (numpad emulated)': ['Digit1'],
  'model back (numpad emulated)': ['Mod+Digit1', 'Ctrl+Digit1'],
  'model right (numpad emulated)': ['Digit3'],
  'model left (numpad emulated)': ['Mod+Digit3', 'Ctrl+Digit3'],
  'model top (numpad emulated)': ['Digit7'],
  'model bottom (numpad emulated)': ['Mod+Digit7', 'Ctrl+Digit7'],
  'model flip (numpad emulated)': ['Digit9'],
  'model projection (numpad emulated)': ['Digit5'],
  'model orbit down (numpad emulated)': ['Digit2'],
  'model orbit up (numpad emulated)': ['Digit8'],
  'model orbit left (numpad emulated)': ['Digit4'],
  'model orbit right (numpad emulated)': ['Digit6'],
  'model pan down (numpad emulated)': ['Mod+Digit2', 'Ctrl+Digit2'],
  'model pan up (numpad emulated)': ['Mod+Digit8', 'Ctrl+Digit8'],
  'model pan left (numpad emulated)': ['Mod+Digit4', 'Ctrl+Digit4'],
  'model pan right (numpad emulated)': ['Mod+Digit6', 'Ctrl+Digit6'],
  'model zoom in (numpad emulated)': ['Equal'],
  'model zoom out (numpad emulated)': ['Minus'],
  'studio console': ['Mod+Alt+Digit1'],
  'studio problems': ['Mod+Alt+Digit2'],
  'studio tests': ['Mod+Alt+Digit3'],
  'studio build': ['Mod+Alt+Digit4'],
  'studio code': ['Mod+Alt+Digit5'],
  'studio git': ['Mod+Alt+Digit6'],
  'code tree rename': ['F2'],
  'code tree delete': ['Delete', 'Backspace'],
  'code menu item above': ['ArrowUp'],
  'code menu item below': ['ArrowDown'],
  'files menu item above': ['ArrowUp'],
  'files menu item below': ['ArrowDown'],
  'folders up': ['ArrowUp'],
  'folders down': ['ArrowDown'],
  'folders fold': ['ArrowLeft'],
  'folders unfold': ['ArrowRight'],
  'folders next tab': ['BracketRight'],
  'folders previous tab': ['BracketLeft'],
  'files up': ['ArrowUp'],
  'files down': ['ArrowDown'],
  'files tile before': ['ArrowLeft'],
  'files tile after': ['ArrowRight'],
  'files extend up': ['Shift+ArrowUp'],
  'files extend down': ['Shift+ArrowDown'],
  'files extend before': ['Shift+ArrowLeft'],
  'files extend after': ['Shift+ArrowRight'],
  'assets page up': ['PageUp'],
  'assets page down': ['PageDown'],
  'assets last': ['End'],
  'assets open': ['Enter', 'NumpadEnter'],
  'assets import': ['Enter', 'NumpadEnter'],
  'assets next card': ['F6', 'Alt+ArrowRight'],
  'assets previous card': ['Shift+F6', 'Alt+ArrowLeft'],
  'assets menu': ['ContextMenu', 'Shift+F10'],
  'assets play': ['Space'],
  'assets frame': ['KeyF'],
  'assets preview before': ['ArrowLeft'],
  'assets preview after': ['ArrowRight'],
  'assets grid or list': ['KeyG'],
  'assets smaller thumbs': ['BracketLeft'],
  'assets larger thumbs': ['BracketRight'],
  'assets export': ['KeyE'],
  'assets export again': ['Shift+KeyE'],
  'assets rename': ['F2', 'Shift+Enter'],
  'assets trash': ['Delete'],
  'assets trash (backspace)': ['Backspace'],
  'assets duplicate': ['Mod+KeyD'],
  'assets import files': ['KeyI'],
  'assets new folder': ['Shift+KeyN'],
  'assets fold': ['Shift+Space'],
  'assets issues': ['Shift+KeyI'],
  'assets build': ['Shift+KeyB'],
  'assets folder up': ['Mod+ArrowUp'],
  'assets select all': ['Mod+KeyA'],
  'assets select none': ['Mod+Shift+KeyA'],
  'assets copy key': ['Mod+KeyC'],
  'assets copy path': ['Mod+Shift+KeyC'],
  'assets search': ['Mod+KeyF'],
} as const satisfies Readonly<Record<string, readonly string[]>>;

/** The name of one of the editor's keyed actions (after `editor: `). */
export type EditorKeyName = keyof typeof EDITOR_KEYS;

/**
 * Blender's Industry Compatible keymap (Docs/navigation.md §8, read from Blender's `industry_compatible_data.py`): each
 * entry of `EDITOR_KEYS` it changes, by the same name, its keys under it -- the rest are the same under both. The 3D
 * views' keys alone (D9): the editor's own keep theirs. The numpad and Home, which Industry binds to nothing in the 3D
 * view, are kept beside its keys (D10); the Model tab's held flight is off (none). The `keys` check reads it as text, as
 * `EDITOR_KEYS`, one `'<name>': [<keys>],` a line.
 */
export const INDUSTRY_KEYS = {
  'move': ['KeyW'],
  'rotate': ['KeyE'],
  'scale': ['KeyR'],
  'frame all': ['KeyA', 'Home'],
  'duplicate': ['Mod+KeyD'],
  'hide': ['Ctrl+KeyH'],
  'view front': ['F1', 'Numpad1'],
  'view back': ['Mod+F1', 'Ctrl+F1', 'Mod+Numpad1', 'Ctrl+Numpad1'],
  'view right': ['F2', 'Numpad3'],
  'view left': ['Mod+F2', 'Ctrl+F2', 'Mod+Numpad3', 'Ctrl+Numpad3'],
  'view top': ['F3', 'Numpad7'],
  'view bottom': ['Mod+F3', 'Ctrl+F3', 'Mod+Numpad7', 'Ctrl+Numpad7'],
  'view camera': ['F4', 'Numpad0'],
  'model front': ['F1', 'Numpad1'],
  'model back': ['Mod+F1', 'Ctrl+F1', 'Mod+Numpad1', 'Ctrl+Numpad1'],
  'model right': ['F2', 'Numpad3'],
  'model left': ['Mod+F2', 'Ctrl+F2', 'Mod+Numpad3', 'Ctrl+Numpad3'],
  'model top': ['F3', 'Numpad7'],
  'model bottom': ['Mod+F3', 'Ctrl+F3', 'Mod+Numpad7', 'Ctrl+Numpad7'],
  'model hide': ['Ctrl+KeyH'],
  'model fly forward': [],
  'model fly back': [],
  'model fly left': [],
  'model fly right': [],
  'model fly down': [],
  'model fly up': [],
  'model pose move': ['KeyW'],
  'model pose rotate': ['KeyE'],
  'model pose scale': ['KeyR'],
} as const satisfies Readonly<Partial<Record<EditorKeyName, readonly string[]>>>;

/** The two keymaps (Docs/navigation.md §8): Blender's Industry Compatible -- the default -- and Blender's own. */
export type Keymap = 'industry' | 'blender';
export const KEYMAPS: readonly Keymap[] = ['industry', 'blender'];
/** Each keymap as a person reads it. */
export const KEYMAP_NAMES: Record<Keymap, string> = { industry: 'Industry Compatible', blender: 'Blender' };
/** The keymap a person who has never chosen one has (D8). */
export const DEFAULT_KEYMAP: Keymap = 'industry';

/** The keymap every lookup reads: set by the editor from the preference before it registers a key, and as it switches. */
let live: Keymap = DEFAULT_KEYMAP;
/** The keymap the lookups read now. */
export const keymapNow = (): Keymap => live;
/** The keymap the lookups read from now on -- the keys already registered re-keyed by `rekeyEditor`. */
export function setKeymap(keymap: Keymap): void {
  live = keymap;
}

/** Any name's keys under `keymap`, or undefined for a name not in the table. */
function lookup(name: string, keymap: Keymap): readonly string[] | undefined {
  if (!Object.hasOwn(EDITOR_KEYS, name)) return undefined;
  if (keymap === 'industry' && Object.hasOwn(INDUSTRY_KEYS, name)) return (INDUSTRY_KEYS as Readonly<Record<string, readonly string[]>>)[name];
  return (EDITOR_KEYS as Readonly<Record<string, readonly string[]>>)[name];
}

/** An action's keys, from the table -- the live keymap's, or `keymap`'s. */
export const editorKey = (name: EditorKeyName, keymap: Keymap = live): readonly string[] => lookup(name, keymap)!;

/** An action's name and its keys, from the table: spread into its definition (`{ ...keyed('save'), mcp, run }`), so the name is written once. */
export const keyed = <N extends EditorKeyName>(name: N): { name: N; key: readonly string[] } => ({ name, key: editorKey(name) });

/** The one key of an action that has one (a tool's tab, Save's caption), in the live keymap: throws on an entry of none or several. */
export function tabKey(name: EditorKeyName): string {
  const keys = editorKey(name);
  if (keys.length !== 1) throw new Error(`[editor] '${name}' has ${keys.length} keys in editor-keys.ts' EDITOR_KEYS, not one`);
  return keys[0]!;
}

/** A generated name's keys (`view front`, `model front (numpad emulated)`), in the live keymap: throws on one not in the table. */
export function editorKeyOf(name: string, keymap: Keymap = live): readonly string[] {
  const keys = lookup(name, keymap);
  if (keys === undefined) throw new Error(`[editor] no key '${name}' in editor-keys.ts' EDITOR_KEYS`);
  return keys;
}

/**
 * `make` run, and on a throw every undo it pushed onto `keys` run -- the last first -- before the throw goes on:
 * `createEditor`'s keys taken back off MrDebug, so boot's next try (studio mode's P) never fails on their names.
 */
export function undoOnThrow<T>(keys: (() => void)[], make: () => T): T {
  try {
    return make();
  } catch (err) {
    for (const off of keys.splice(0).reverse()) off();
    throw err;
  }
}

/** Is there a line for this name? */
export const hasEditorKey = (name: string): boolean => Object.hasOwn(EDITOR_KEYS, name);

/** An editor key that gave way: the editor's action (after `editor: `), the action that holds the key, and the key. */
export interface KeyClash {
  editor: string;
  other: string;
  key: string;
}

/** The prefix of every editor action's MrDebug name. */
export const EDITOR_PREFIX = 'editor: ';

/**
 * `action` added through `router` without each key an action already there always takes (`router.clashes`), each
 * pushed onto `given`: the editor's key gives way, its other keys kept -- and with none left registered with no key,
 * so a keymap switched later finds it to re-key (`rekeyEditor`). Returns the undo.
 */
export function giveWay(router: Pick<DebugRouter, 'add' | 'clashes'>, action: DebugAction, given: KeyClash[]): () => void {
  const clashes = router.clashes(action);
  if (clashes.length === 0) return router.add(action);
  const editor = action.name.startsWith(EDITOR_PREFIX) ? action.name.slice(EDITOR_PREFIX.length) : action.name;
  for (const c of clashes) given.push({ editor, other: c.name, key: c.key });
  const taken = new Set(clashes.map((c) => c.declared));
  const declared = action.key === undefined ? [] : typeof action.key === 'string' ? [action.key] : action.key;
  const left = declared.filter((key) => !taken.has(key));
  // None left: registered all the same, with no key -- a keymap switched later (`rekeyEditor`) may give it a free one.
  return router.add({ ...action, key: left });
}

/**
 * Every editor action registered through `router` (named `editor: <name>`, the name in the table) given its keys under
 * the live keymap, in place (`router.rekey`) -- each without the keys an action already there always takes, as
 * `giveWay` registers them (Docs/navigation.md D13). `given`'s entries for the table's names are made again -- what gave
 * way under the keymap now -- the rest (a project tool's) kept, for the editor's one notice. A project tool's own keys, not in the table, are left as they are.
 */
export function rekeyEditor(router: Pick<DebugRouter, 'list' | 'clashes' | 'rekey'>, given: KeyClash[]): void {
  // Only the table's entries are made again: a project tool's key that gave way (not in the table) stays said.
  for (let i = given.length - 1; i >= 0; i--) if (lookup(given[i]!.editor, live) !== undefined) given.splice(i, 1);
  for (const action of [...router.list()]) {
    if (!action.name.startsWith(EDITOR_PREFIX)) continue;
    const editor = action.name.slice(EDITOR_PREFIX.length);
    const keys = lookup(editor, live);
    if (keys === undefined) continue;
    const clashes = router.clashes({ key: keys, field: action.field, when: action.when }).filter((c) => c.name !== action.name);
    for (const c of clashes) given.push({ editor, other: c.name, key: c.key });
    const taken = new Set(clashes.map((c) => c.declared));
    router.rekey(action.name, keys.filter((key) => !taken.has(key)));
  }
}

/** What of the editor's notices the keys' one notice needs (`notices.ts`). */
export interface KeyNotices {
  add(kind: 'keys', text: string): { id: number };
  update(id: number, text: string): boolean;
  dismiss(id: number): void;
}

/**
 * The editor's one `keys` notice said for `given` (`clashText`): updated in place where it is up (`id`), added where
 * not, dismissed when nothing gave way. Returns its id now, or null for none. At registration and at a keymap's switch.
 */
export function sayGivenWay(notices: KeyNotices, id: number | null, given: readonly KeyClash[]): number | null {
  const text = clashText(given);
  if (text === '') {
    if (id !== null) notices.dismiss(id);
    return null;
  }
  if (id !== null && notices.update(id, text)) return id;
  return notices.add('keys', text).id;
}

/** What a keymap's switch touches (`switchKeymap`): the preference, MrDebug, what gave way and its notice, the keys card. */
export interface KeymapSwitch {
  /** The keymap kept as the person's preference. */
  keep(keymap: Keymap): void;
  router: Pick<DebugRouter, 'list' | 'clashes' | 'rekey'>;
  given: KeyClash[];
  notices: KeyNotices;
  /** The `keys` notice up now, or null. */
  notice: number | null;
  /** The keys card: read again, if open, for the new map's keys. */
  card?: { readonly open: boolean; close(): void; toggle(): void };
}

/**
 * The keymap switched (Config ▸ Preferences, Docs/navigation.md D8, D13): kept, the lookups' keymap set, every editor
 * key re-keyed in place (`rekeyEditor`), the notice said again or dismissed, the keys card read again if open. Returns
 * the notice's id now. The mouse follows by itself: the rule reads the preference at each press.
 */
export function switchKeymap(keymap: Keymap, s: KeymapSwitch): number | null {
  s.keep(keymap);
  setKeymap(keymap);
  rekeyEditor(s.router, s.given);
  const id = sayGivenWay(s.notices, s.notice, s.given);
  if (s.card?.open) {
    s.card.close();
    s.card.toggle();
  }
  return id;
}

/** What an existing person is told once, their 3D views' keys having changed under them (D8). */
export const KEYMAP_NEWS = 'The 3D views now use Blender\'s Industry Compatible keys (Alt+drag to orbit, W E R the gizmo, F1-F4 the views) -- Config ▸ Preferences ▸ Navigation\'s Keymap to switch back to Blender\'s';

/** Whose an action is, in the notice's words: the editor's own (another of its keys, a project tool's) or the game's. */
const whose = (name: string): string => (name.startsWith(EDITOR_PREFIX) ? `the editor's own '${name.slice(EDITOR_PREFIX.length)}'` : `the game's '${name}'`);

/** The notice for the keys given way: each key held in the person's words, what of the editor's is off on it, and what to do. Empty for none. */
export function clashText(given: readonly KeyClash[], mac?: boolean): string {
  if (given.length === 0) return '';
  // One clause a key held: the editor's actions off on it together (Shift+A is the walk's left and the Model tab's).
  const held = new Map<string, { other: string; key: string; off: string[] }>();
  for (const c of given) {
    const at = `${c.other}\n${c.key}`;
    const one = held.get(at) ?? { other: c.other, key: c.key, off: [] };
    if (!one.off.includes(`'${c.editor}'`)) one.off.push(`'${c.editor}'`);
    held.set(at, one);
  }
  const each = [...held.values()].map((h) =>
    `${whose(h.other)} takes ${keyLabel(h.key, mac)}, so the editor's ${h.off.length === 1 ? `${h.off[0]} is` : `${h.off.slice(0, -1).join(', ')} and ${h.off.at(-1)} are`} off on ${keyLabel(h.key, mac)}`);
  const others = [...new Set(given.map((c) => `'${c.other}'`))];
  const said = each.length === 1 ? `A debug key: ${each[0]}` : `Debug keys: ${each.join('; ')}`;
  return `${said} -- give ${others.length === 1 ? `${others[0]} another key` : `${others.slice(0, -1).join(', ')} and ${others.at(-1)} other keys`}, or a \`when\` (MrDebug.add)`;
}
