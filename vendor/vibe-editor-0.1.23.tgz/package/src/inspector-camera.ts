/**
 * The Camera block (Docs/camera.md §3, 8.3): `Camera`'s fields as a person
 * reads them, and three buttons -- built as `renderBlock` is, the component's
 * own block in place of the generic one (`blocks.ts`' `camera` item).
 *
 * - **The fields**, each labelled, bounded and helped as its maker says
 *   (`render-components.ts`): `projection` a drop-down of `CameraProjection`'s
 *   names (Perspective, Orthographic); `fov` shown for a perspective camera,
 *   `size` for an orthographic one -- both while those selected differ
 *   (`cameraFieldsShown`); `near`, `far`; `main` a tick; `depth`; the
 *   viewport rect under its group's heading (`Viewport`), X, Y, Width, Height
 *   in one row; `clear` a drop-down of `CameraClear`'s (None, Colour, Sky) --
 *   a `<select>`, not the generic enum picker, so the fields that follow it
 *   are shown or hidden as it is changed -- with `clearColor`'s swatch while
 *   any clears to its colour; `layers` a tick for each of the project's named
 *   layers (the layer drop-down's names), writing the mask -- the unnamed
 *   layers' bits left as they are (`tickLayer`). Each line is marked as any
 *   field is -- `data-field`, its name first, where an override's bar goes
 *   (`labelOf`) -- and a drop-down or a tick writes as a number field does: in
 *   place, `wrote`, one step; `fov`, `size` and the swatch shown or hidden as
 *   the values say, without building the block again.
 * - **Isometric**: orthographic, and the entity turned 45° about Y then
 *   35.264° down (`isometricRotation`), its position kept -- one step for both.
 * - **Align with view**: the entity's `Transform` put where the editor's
 *   camera is, turned as it is (in its parent's space), and its projection,
 *   field of view or size with it -- one step.
 * - **Align view with camera**: the editor's camera put where the camera is,
 *   in its projection -- the first selected's -- a view change, no step.
 * - **Several selected**: each field as any block's (`—` where they differ);
 *   each button acts on every one.
 */
import { allLayers, Camera, type Entity, fileFieldOf, labelOf, spaced, Transform } from '@vibe/engine';
import { alignedLens, cameraFieldsShown, isometricRotation, parentPose, placedTransform, tickLayer, writeRows } from './camera-entity.ts';
import type { EditorView } from './camera-entity.ts';
import { head, type Blocks, type Columns } from './inspector-blocks.ts';
import { groupEnd, groupHead, numberLine } from './inspector-fields.ts';
import { checkLine, colorLine } from './key-field.ts';
import { times } from './multi.ts';
import { button, el } from './shell.ts';

/** What the block asks of the editor's view: its numbers, and the way to look through a camera (`InspectorHost.camera`). */
export interface CameraHost {
  view(): EditorView;
  lookThrough(e: Entity): void;
}

export function cameraBlock(blocks: Blocks, es: readonly Entity[], camera: CameraHost | undefined): HTMLElement {
  const { world, host } = blocks;
  const section = el('div', 'ed-component');
  section.append(head(blocks, Camera, es));
  const lens = world.store(Camera);
  const columns = (): Columns => world.rawStore(Camera) as Columns;

  /** A field's label and help, as its maker says them: what a tick's and a swatch's line show. */
  const said = (field: string): { label: string; help?: string } => {
    const f = fileFieldOf(Camera, field)!;
    return { label: labelOf(f), ...(f.field.help !== undefined ? { help: f.field.help } : {}) };
  };

  /** A number field on one of Camera's columns, as the generic block makes it: its label, bounds and help its maker's. */
  const number = (field: string): HTMLElement => {
    const f = fileFieldOf(Camera, field)!;
    const made = numberLine(blocks, Camera, f, es, { label: labelOf(f), ...(f.field.help !== undefined ? { help: f.field.help } : {}) });
    made.dataset.field = `Camera.${field}`;
    return made;
  };

  /**
   * The lens and the clear's own fields shown as the values now say: `fov`,
   * `size`, `clearColor` -- after a drop-down's write, and as values are read
   * again, without building the block again.
   */
  const follow = (): void => {
    const now = cameraFieldsShown(es.map((e) => lens.projection[e]!), es.map((e) => lens.clear[e]!));
    fov.hidden = !now.fov;
    size.hidden = !now.size;
    clearColor.hidden = !now.clearColor;
  };

  /**
   * A drop-down on a small whole-number column, a line as the tick's and the
   * key's are (`data-field`; its name first, where `labelOf` puts an
   * override's bar): written as a number field writes -- in place, `wrote`,
   * one step (`commit`) -- and the fields that follow it shown or hidden.
   */
  const choice = (field: string, title: string): HTMLElement => {
    const f = fileFieldOf(Camera, field)!;
    // Its names the enum's (`CameraProjection`, `CameraClear`), each its index: one list, the maker's.
    const options = (f.field.enum ?? []).map((n, i) => [spaced(n), i] as const);
    const line = el('div', 'ed-keyline ed-cam-choice');
    line.dataset.field = `Camera.${field}`;
    const name = el('span', 'ed-keyline-name', labelOf(f));
    name.title = `Camera.${field}: ${title}`;
    const pick = el('select', 'ed-input');
    pick.dataset.mcp = 'scene_set';
    pick.title = title;
    pick.setAttribute('aria-label', `Camera.${field}`);
    const mixed = new Option('—', '');
    mixed.disabled = true;
    pick.append(mixed);
    for (const [words, value] of options) pick.append(new Option(words, String(value)));
    const show = (): void => {
      const values = es.map((e) => columns()[field]![e]!);
      const same = values.every((v) => v === values[0]) ? values[0] : undefined;
      mixed.hidden = same !== undefined;
      const want = same === undefined ? '' : String(same);
      if (pick.value !== want) pick.value = want;
    };
    show();
    pick.addEventListener('change', () => {
      if (pick.value === '') return;
      const moved = writeRows(columns()[field]!, es, Number(pick.value));
      follow();
      if (moved === 0) return;
      blocks.wrote();
      host.commit(times(`Set Camera.${field}`, moved));
    });
    blocks.live(() => {
      show();
      follow();
    });
    line.append(name, pick);
    return line;
  };

  const fov = number('fov');
  const size = number('size');
  const clearColor = colorLine(blocks, Camera, 'clearColor', es, said('clearColor'));
  const grid = el('div', 'ed-fields');
  grid.append(choice('projection', 'How it sees: perspective, through its field of view, or orthographic, through its size'));
  grid.append(fov, size);
  grid.append(number('near'), number('far'), checkLine(blocks, Camera, 'main', es, said('main')), number('depth'));
  section.append(grid);

  // The viewport rect, fractions of the canvas from its bottom left, under its group's heading (`group: 'Viewport'`).
  const rect = el('div', 'ed-fields ed-cam-rect');
  rect.title = 'The viewport: the part of the canvas it draws into, fractions from its bottom left';
  rect.append(groupHead(fileFieldOf(Camera, 'x')!.field.group ?? 'Viewport'), number('x'), number('y'), number('w'), number('h'));
  // The group ends where the clear begins: a field of none, as the generic block ends one (`fieldLayout`).
  rect.append(groupEnd());
  section.append(rect);

  const clearing = el('div', 'ed-fields');
  clearing.append(choice('clear', 'What its rect is cleared to first: the scene\'s own background, its colour, or nothing (drawn over what is under it)'));
  clearing.append(clearColor);
  section.append(clearing);
  section.append(layersLine(blocks, es));
  follow();

  const buttons = el('div', 'ed-buttons ed-cam-buttons');
  const each = es.length > 1 ? ` -- each of the ${es.length}` : '';
  buttons.append(
    button('scene_set', 'Isometric', `Orthographic, turned 45° about Y and 35.264° down: the isometric view${each}`, () => isometric(blocks, es)),
    button('scene_set', 'Align with view', `Where the editor's camera is, turned as it is, its projection and its field of view or size${each}`, () => {
      if (camera) alignWithView(blocks, es, camera.view());
    }),
    button('view_set', 'Align view with camera', 'The editor\'s camera put where this camera is, in its projection: the view changes, nothing is edited', () => {
      if (es[0] !== undefined) camera?.lookThrough(es[0]);
    }),
  );
  section.append(buttons);
  return section;
}

/** A tick for each named layer: seen by every one, by none, or by some (neither); a click writes it into every one's mask. */
function layersLine(blocks: Blocks, es: readonly Entity[]): HTMLElement {
  const { world } = blocks;
  const line = el('div', 'ed-keyline ed-cam-layers');
  line.dataset.field = 'Camera.layers';
  const name = el('span', 'ed-keyline-name', labelOf(fileFieldOf(Camera, 'layers')!));
  name.title = 'Camera.layers: the layers it sees -- never the layer its own entity is on';
  const ticks = el('div', 'ed-cam-layer-ticks');
  line.append(name, ticks);
  const names = allLayers();
  const mask = (): Uint32Array => world.store(Camera).layers as unknown as Uint32Array;
  const boxes: { layer: number; box: HTMLInputElement }[] = [];
  for (let layer = 0; layer < 32; layer++) {
    const called = names[layer];
    if (!called) continue;
    const label = el('label', 'ed-cam-layer');
    const box = el('input', 'ed-check');
    box.type = 'checkbox';
    box.setAttribute('aria-label', `Camera.layers: ${called}`);
    box.addEventListener('change', () => {
      // As a number field writes: in place, `wrote`, one step -- the unnamed layers' bits kept (`tickLayer`).
      const moved = tickLayer(mask(), es, layer, box.checked);
      if (moved === 0) return;
      blocks.wrote();
      blocks.host.commit(times(`Set Camera.layers`, moved));
    });
    label.append(box, el('span', undefined, called));
    label.title = `Layer ${layer}, ${called}`;
    ticks.append(label);
    boxes.push({ layer, box });
  }
  if (boxes.length === 0) ticks.append(el('span', 'ed-dim', 'no layers named'));
  const show = (): void => {
    const m = mask();
    for (const { layer, box } of boxes) {
      const seeing = es.filter((e) => ((m[e]! >>> layer) & 1) === 1).length;
      box.indeterminate = seeing > 0 && seeing < es.length;
      box.checked = seeing === es.length;
    }
  };
  show();
  blocks.live(show);
  return line;
}

/** Isometric on every one: orthographic, turned as the preset is in the world, where it is. One step. */
function isometric({ world, host }: Blocks, es: readonly Entity[]): void {
  const lens = world.store(Camera);
  const q = isometricRotation();
  for (const e of es) {
    lens.projection[e] = 1;
    if (!world.has(e, Transform)) continue;
    const placed = placedTransform(parentPose(world, e), [0, 0, 0], q);
    if (!placed) continue;
    const t = world.store(Transform);
    [t.qx[e], t.qy[e], t.qz[e], t.qw[e]] = placed.q;
    world.moved(e);
  }
  host.changed(times('Isometric', es.length));
}

/** Every one where the editor's view is, turned as it is, seeing as it does. One step. */
function alignWithView({ world, host }: Blocks, es: readonly Entity[], view: EditorView): void {
  alignCamerasWithView(world, es, view, (label) => host.changed(label));
}

/** Align with view, for the block's button and the Scene tab's Ctrl+Alt+Numpad0 (Docs/navigation.md §3): one step, `done` its label. */
export function alignCamerasWithView(world: Blocks['world'], es: readonly Entity[], view: EditorView, done: (label: string) => void): void {
  const lens = world.store(Camera);
  const { projection, fov, size } = alignedLens(view);
  for (const e of es) {
    lens.projection[e] = projection;
    if (projection === 0) lens.fov[e] = fov;
    else lens.size[e] = size;
    if (!world.has(e, Transform)) continue;
    const placed = placedTransform(parentPose(world, e), view.position, view.quaternion);
    if (!placed) continue;
    const t = world.store(Transform);
    [t.px[e], t.py[e], t.pz[e]] = placed.p;
    [t.qx[e], t.qy[e], t.qz[e], t.qw[e]] = placed.q;
    world.moved(e);
  }
  done(times('Align with view', es.length));
}
