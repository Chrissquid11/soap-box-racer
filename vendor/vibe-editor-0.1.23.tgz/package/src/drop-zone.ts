/**
 * Where a drop on the tree's rows goes (`tree.ts`): the same for a row dragged
 * to reorder it and a prefab dragged from the Assets panel. Pure, so a node
 * test holds it.
 *
 * - **Three zones a row**: its upper quarter is in front of it, its lower
 *   quarter after it -- a sibling either way, shown by the insertion line --
 *   and its middle is under it, the row outlined.
 * - **Rows dragged together land together** (`moveRows`): each not under
 *   another of them, in the tree's order, in front of the same place.
 * - **A sibling takes the row's parent**, at the row's place or the one after
 *   it: the tree lists children in the hierarchy's sibling order. Beside a
 *   root it is a root, at that place among the roots, which the ECS keeps in
 *   order as it does children (Docs/ecs.md §8).
 */
import { Hierarchy, inTreeOrder, NONE, type Entity, type World } from '@vibe/engine';

/** In front of the row, under it, or after it. */
export type Zone = 'before' | 'into' | 'after';

/** How much of a row, from its top or its bottom edge, is the insertion line's rather than the row's own. */
export const EDGE = 1 / 4;

/** The zone a pointer `y` down a row is in, from 0 (its top edge) to 1 (its bottom). */
export const zoneAt = (y: number): Zone => (y < EDGE ? 'before' : y > 1 - EDGE ? 'after' : 'into');

/** The hierarchy's links, as `world.store(Hierarchy)` has them. */
export interface Links {
  readonly parent: ArrayLike<number>;
  readonly firstChild: ArrayLike<number>;
  readonly nextSibling: ArrayLike<number>;
}

/** Where a drop lands: under `parent` (NONE, a root), in front of `before` (NONE, last); `index` among `parent`'s children -- or the roots -- as they are now. */
export interface Place {
  parent: Entity;
  before: Entity;
  index: number;
}

/**
 * What a drop in `zone` of `e`'s row makes of what is dropped: its parent, its
 * place among that parent's children -- among the roots, from `firstRoot`
 * (`world.firstRoot`), beside a root.
 */
export function dropPlace(links: Links, e: Entity, zone: Zone, firstRoot: Entity = NONE): Place {
  const parent = (zone === 'into' ? e : links.parent[e]!) as Entity;
  const before = (zone === 'into' ? NONE : zone === 'before' ? e : links.nextSibling[e]!) as Entity;
  let index = 0;
  for (let c = parent === NONE ? firstRoot : links.firstChild[parent]!; c !== NONE && c !== before; c = links.nextSibling[c]!) index++;
  return { parent, before, index };
}

/**
 * `rows` under `parent` in front of `before` (NONE, last) -- the roots, for a
 * `parent` of NONE -- through `world.setParent`, to land at the boundary:
 * each alive, not under another of them, neither `parent` nor above it, in
 * the tree's order, so they stay together as they were. Those moved, in that
 * order; none, nothing to do.
 */
export function moveRows(world: World, rows: readonly Entity[], parent: Entity, before: Entity): Entity[] {
  const links = world.store(Hierarchy);
  const chosen = new Set<number>(rows);
  const under = (e: number, is: (a: number) => boolean): boolean => {
    for (let a = links.parent[e]!; a !== NONE; a = links.parent[a]!) if (is(a)) return true;
    return false;
  };
  // Under another of them: it goes with that one. Above `parent`: a cycle, which the world refuses loudly.
  const moving = inTreeOrder(world, rows).filter((c) => c !== parent && !under(c, (a) => chosen.has(a)) && !under(parent, (a) => a === c));
  // In front of one of those moving is in front of the first after it that stays.
  const going = new Set<number>(moving);
  while (before !== NONE && going.has(before)) before = links.nextSibling[before]! as Entity;
  for (const c of moving) {
    // Last of the children it is one of already: out and in again, as the world leaves one where it is otherwise.
    if (parent !== NONE && before === NONE && links.parent[c] === parent) world.setParent(c, NONE);
    world.setParent(c, parent, before);
  }
  return moving;
}
