/**
 * Fat lines the editor draws over the world and a click can take: three's
 * `LineSegments2`, a few pixels wide whatever the screen, whose own raycast hits
 * only within half its width -- under a pixel either side of a camera shape's
 * line. These widen the hit to `LINE_PICK_PX` either side of the line,
 * whatever the raycaster's `params.Line2` (set for the one call, then put back).
 * Node-safe -- three and its line addons, no DOM -- so `pick-lines.test.ts`
 * aims a ray a few pixels off a line.
 */
import * as THREE from 'three';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';

/** How far from a line a click still takes it, in CSS pixels either side. */
export const LINE_PICK_PX = 8;

/** What `drawnResolution` reads of the renderer: the viewport in effect, the target bound, the drawing buffer and its ratio. */
export type DrawingRenderer = Pick<THREE.WebGLRenderer, 'getCurrentViewport' | 'getRenderTarget' | 'getDrawingBufferSize' | 'getPixelRatio'>;

const viewportNow = new THREE.Vector4();
const buffer = new THREE.Vector2();
/**
 * The size of the viewport in effect, in the units a fat line's width is given in -- what its material's `resolution`
 * must be, for its shader and for its raycast: the game's frame (or the Game view's box), not the whole canvas. The
 * viewport is in the target's pixels: the canvas's and the kept frame's (a target the drawing buffer's size) are
 * device pixels, so CSS pixels are the viewport over the pixel ratio; a resolution's target (Pixel, Stretch) is the
 * game's own pixels, taken as they are.
 */
export function drawnResolution(renderer: DrawingRenderer, out: THREE.Vector2): THREE.Vector2 {
  renderer.getCurrentViewport(viewportNow);
  const target = renderer.getRenderTarget();
  renderer.getDrawingBufferSize(buffer);
  const ratio = target === null || (target.width === buffer.x && target.height === buffer.y) ? renderer.getPixelRatio() : 1;
  return out.set(Math.max(1, viewportNow.z / ratio), Math.max(1, viewportNow.w / ratio));
}

/** A pixel of width as the viewport in effect has it, whatever drew this frame and into whatever target: a fat line's `onBeforeRender`. */
const drawnSize = new THREE.Vector2();
export function fitResolution(material: LineMaterial, renderer: DrawingRenderer): void {
  drawnResolution(renderer, drawnSize);
  if (!material.resolution.equals(drawnSize)) material.resolution.copy(drawnSize);
}

/** The threshold three adds to the line's whole width, for one call. */
const params = { threshold: 0 };

/** Lines a click takes within `LINE_PICK_PX` of: picked through `raycast` as it is, the threshold widened for the call. */
class PickLines extends LineSegments2 {
  /** False: drawn, never picked (a halo under the lines that are). */
  pickable = true;

  override raycast(raycaster: THREE.Raycaster, intersects: THREE.Intersection[]): void {
    if (!this.pickable) return;
    const had = raycaster.params.Line2;
    params.threshold = Math.max(0, 2 * LINE_PICK_PX - (this.material as LineMaterial).linewidth);
    raycaster.params.Line2 = params;
    try {
      super.raycast(raycaster, intersects);
    } finally {
      if (had === undefined) delete raycaster.params.Line2;
      else raycaster.params.Line2 = had;
    }
  }
}

/**
 * Fat lines over the world in `material`, drawn in `order`: its buffer changes under it, so never culled by a
 * bounding sphere worked out once; its material's resolution the viewport's as each is drawn (`fitResolution`).
 */
export function pickLines(material: LineMaterial, order: number, geometry = new LineSegmentsGeometry()): PickLines {
  const lines = new PickLines(geometry, material);
  lines.renderOrder = order;
  lines.frustumCulled = false;
  // Whichever of the materials it has now.
  lines.onBeforeRender = (renderer) => fitResolution(lines.material, renderer);
  return lines;
}

export type { PickLines };
