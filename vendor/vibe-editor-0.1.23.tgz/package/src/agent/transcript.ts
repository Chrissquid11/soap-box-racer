/**
 * The agent's transcript (Docs/agent.md §4, "The card"): the log's entries as
 * the card draws them, and the words the card says of the state. Two halves,
 * so node tests the first:
 *
 * - **The model, pure**: the entries kept (`merged`: in `seq` order, a
 *   `reset` rule dropping what came before, the last 500 drawn whole), the
 *   cards settled (`settled`), how many turns came after one (`turnsAfter`,
 *   for Undo's preview), whether the list follows the newest (`follows`),
 *   and the words -- a result's (`resultWords`), a review's against its bar
 *   (`reviewWords`), Undo's preview (`rewindWords`, `turnUndoWords`, the
 *   editor's part led with where no file is put back), an editor tool's row
 *   and its step (`editorRowWords`, `stepWords`: denied, in another tab, from
 *   before the reload), the head's line for the state and its failures
 *   (`headLine`), the clock (`clock`).
 * - **The view** (`createTranscript`), DOM built of elements, never markup:
 *   the prompt with its images counted and its context folded; the agent's
 *   text as a page (`../markdown.ts`), streaming in as plain text first; a
 *   tool call as one row, its detail on hover, a subagent's with `↳`, an
 *   `Edit` or `Write` row unfolding to its change (`GET input`, "not kept"
 *   after a restart); a checklist the next one replaces; notes dim; errors red
 *   with their next step; a review against its bar, its report folded; a
 *   result row -- the time, the files (a click reveals one; one a command
 *   deleted marked so), the cost, notional on a subscription, and **Undo this
 *   turn**, a dry run's preview first -- the agent's edits, the files a
 *   command changed, deleted or made, from the turn's snapshot, by name, and
 *   the editor edits it made in this tab, walked back on the editor's undo
 *   stack or, from before a reload, put back by value -- read again as the
 *   editor's history moves; on a second click the editor's part first, here
 *   and now, then the rewind, of what the preview listed; a studio tool's
 *   call (`mcp__studio__…`, Docs/mcp.md) as a row of its own, "Studio ·
 *   set Transform.px = 3 on big crate", in the page's words once it is
 *   answered (the `editor` entry), "— denied" when its card was, "in another
 *   tab" when another tab ran it, and -- for an `scene_set` this tab ran --
 *   its step: Undo while it is on top of the editor's stack, else where it is
 *   ("undone", "from before the reload"); permission cards (Allow, Always ▾ -- a small menu
 *   of where it is kept, two places one click away and two more behind More…,
 *   scrolled into view as it opens -- Deny) and question cards, greyed once
 *   answered. A card answered here hands the focus back to the prompt box, so
 *   the next words typed are words, not the editor's keys.
 * - **A subagent's rows under its call** (`parent`, its `Agent` call's id): the call's row holds them folded under
 *   it ("4 steps"), rather than interleaved with the turn's own; one whose call's row is gone (the cap) is a row of its
 *   own as before. `reveal` brings a call's row into view, unfolded (the subagents strip's row clicked).
 * - **`/btw`** (`btw` entries): a block apart -- "btw", the question, the answer as a page (thinking… until it comes),
 *   its cost and time, "not in the conversation" -- dismissed by its ×, kept dismissed for this browser tab
 *   (`dismissed`). **`aside`**: a block of the card's own at the end, never an entry (`/usage`'s card), dismissed by its ×.
 * - **At the newest unless scrolled up**, hidden or not: whether the list
 *   follows is measured only while it is shown, and kept while the card is
 *   folded or a playtest hides the dock; `shown()`, as
 *   it comes back, brings the card waiting into view, else the newest.
 *
 * Imports only `../dom.ts`, `../markdown.ts`, `../mcp/gaps.ts` and types -- the contract's (and its
 * `AGENT_TOOLS`, a value), `mcp/page.ts`' -- and touches the DOM only when its view is made.
 */
import type {
  AgentState,
  Card,
  CardOutcome,
  Delta,
  Entry,
  EntryBody,
  PermissionCard,
  QuestionCard,
  RewindAnswer,
} from '@vibe/pipeline/agent-types';
import { AGENT_TOOLS } from '@vibe/pipeline/agent-types';
import { control, el } from '../dom.ts';
import { parseMarkdown, renderMarkdown } from '../markdown.ts';
import type { StepState, TurnSteps } from '../mcp/page.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';

/** Entries kept and drawn, at most: the server's own cap. */
export const KEEP = 500;

// ---------------------------------------------------------------- the model

type Of<K extends EntryBody['kind']> = Extract<Entry, { kind: K }>;

/** The terminal's turns' fold, in a line (Docs/terminal.md D10). */
export const terminalSummary = (n: number): string => `In the terminal: ${n === 1 ? '1 turn' : `${n} turns`} -- read back from the session`;

/**
 * The entries as the page keeps them after `incoming`: in `seq` order, each
 * once; a rule with `reset` drops everything before it (Clear); `all`, the
 * whole log in place of what was here. The last `KEEP`.
 */
export function merged(now: readonly Entry[], incoming: readonly Entry[], all = false): { entries: Entry[]; reset: boolean } {
  let entries = all ? [] : [...now];
  let reset = all;
  const seen = new Set(entries.map((e) => e.seq));
  for (const entry of [...incoming].sort((a, b) => a.seq - b.seq)) {
    if (entry.kind === 'rule' && entry.reset) {
      entries = [entry];
      seen.clear();
      seen.add(entry.seq);
      reset = true;
      continue;
    }
    if (seen.has(entry.seq)) continue;
    seen.add(entry.seq);
    entries.push(entry);
  }
  entries.sort((a, b) => a.seq - b.seq);
  if (entries.length > KEEP) entries = entries.slice(-KEEP);
  return { entries, reset };
}

/** Each card answered so far: how, and what was answered or kept. */
export function settled(entries: readonly Entry[]): Map<string, { outcome: CardOutcome; detail: string | null }> {
  const out = new Map<string, { outcome: CardOutcome; detail: string | null }>();
  for (const e of entries) if (e.kind === 'answer') out.set(e.card, { outcome: e.outcome, detail: e.detail });
  return out;
}

/** How many turns were sent after `turn`'s: what rewinding to it puts back too. */
export function turnsAfter(entries: readonly Entry[], turn: string): number {
  const at = entries.findIndex((e) => e.kind === 'prompt' && e.turn === turn);
  if (at < 0) return 0;
  return entries.slice(at + 1).filter((e) => e.kind === 'prompt').length;
}

/**
 * How many editor edits of `turn` and the turns after it another tab made
 * (`editor` entries with a step, run by a tab not this one): Undo this turn
 * here leaves them -- the tab that ran them keeps them, and undoes them. An
 * edit this tab's editor knows (`known`, its step's state) is its own, its id
 * made anew or not.
 */
export function editsElsewhere(entries: readonly Entry[], turn: string, mine: string | null, known: (use: string) => StepState): number {
  const at = entries.findIndex((x) => (x.kind === 'prompt' || x.kind === 'result') && x.turn === turn);
  if (at < 0 || mine === null) return 0;
  let n = 0;
  for (const x of entries.slice(at)) {
    if (x.kind !== 'editor' || !x.ok || x.turn === null || x.tab == null || x.tab === mine || x.set?.step == null) continue;
    if (known(x.id) === null) n++;
  }
  return n;
}

/** A time as a person reads it: `41 s`, `2 min 5 s`, `1 h 3 min`. */
export function seconds(ms: number): string {
  const s = Math.max(0, Math.round(ms / 1000));
  if (s < 60) return `${s} s`;
  if (s < 3600) return `${Math.floor(s / 60)} min${s % 60 ? ` ${s % 60} s` : ''}`;
  return `${Math.floor(s / 3600)} h${Math.floor((s % 3600) / 60) ? ` ${Math.floor((s % 3600) / 60)} min` : ''}`;
}

/** The head's clock while a turn runs: `0:03`, `12:40`, `1:02:03`. */
export function clock(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const two = (n: number): string => String(n).padStart(2, '0');
  return s < 3600 ? `${Math.floor(s / 60)}:${two(s % 60)}` : `${Math.floor(s / 3600)}:${two(Math.floor((s % 3600) / 60))}:${two(s % 60)}`;
}

const plural = (n: number, one: string, many = `${one}s`): string => `${n} ${n === 1 ? one : many}`;

/**
 * A result's line: how it ended and how long it took -- a turn Claude Code
 * started itself said so -- the files with their lines (and how many a
 * command deleted), and the cost: the turn's own, or, the first turn after a
 * restart, the conversation's so far.
 */
export function resultWords(r: Of<'result'>): { how: string; files: string; cost: string | null } {
  const ended = r.how === 'done' ? `Done in ${seconds(r.ms)}` : r.how === 'stopped' ? `Stopped after ${seconds(r.ms)}` : `Ended by an error after ${seconds(r.ms)}${r.why ? `: ${r.why}` : ''}`;
  const how = r.origin === 'cli' ? `Went on by itself: ${ended.charAt(0).toLowerCase()}${ended.slice(1)}` : ended;
  // A file a command deleted has no lines to count: said as deleted, not as +0 −0.
  const gone = r.files.filter((f) => f.deleted).length;
  const files =
    r.files.length === 0
      ? 'no files changed'
      : gone === r.files.length
        ? `${plural(gone, 'file')} deleted`
        : `${plural(r.files.length, 'file')} +${r.added} −${r.removed}${gone > 0 ? `, ${gone} deleted` : ''}`;
  const usd = r.cost === null ? null : `≈ $${r.cost < 0.01 && r.cost > 0 ? r.cost.toFixed(3) : r.cost.toFixed(2)}`;
  const cost = usd === null ? null : r.costSoFar ? `${usd} so far this conversation` : `${usd} at API prices`;
  return { how, files, cost };
}

/** What a result's cost is, for its tooltip. */
export function costTitle(r: Of<'result'>): string {
  const notional = 'At API prices: on a subscription it is notional, and nothing is charged.';
  return r.costSoFar
    ? `What the whole conversation has cost so far: the dev server restarted, so this turn's own share is not known. ${notional}`
    : `What this turn cost: the conversation's running total less the turn before's. ${notional}`;
}

/** The list's scroll, as the browser reports it: hidden, its client height is 0. */
export interface ScrollView {
  scrollTop: number;
  scrollHeight: number;
  clientHeight: number;
}

/**
 * Does the list follow the newest? Shown, it does when it is at the end
 * (within 24 px); hidden -- folded, or a playtest -- nothing
 * can be measured, so what was last measured, `stuck`, stands.
 */
export function follows(view: ScrollView, stuck: boolean): boolean {
  if (view.clientHeight === 0) return stuck;
  return view.scrollHeight - view.scrollTop - view.clientHeight < 24;
}

/** A review round's line: launched, or its score against the bar it was sent with, or why none was read. */
export function reviewWords(r: Of<'review'>): string {
  const round = `Review ${r.round}/${r.of}`;
  const bar = r.bar === null ? '' : ` · bar ${r.bar}/10`;
  if (r.note !== null) return `${round}: ${r.note}`;
  if (r.score === null) return `${round} · the critic is reading${bar}`;
  if (r.bar === null) return `${round}: ${r.score}/10`;
  return `${round}: ${r.score}/10 · ${r.score >= r.bar ? 'meets' : 'under'} the bar ${r.bar}/10`;
}

/**
 * The files the preview lists that another conversation's later turn changed
 * too, by its title -- "Also changed since by “Crate work”: a.ts, b.ts" --
 * put back with the rest only as listed, so said before the second click.
 * Null: none.
 */
export function othersWords(answer: RewindAnswer | null): string | null {
  const others = answer?.others ?? [];
  if (others.length === 0) return null;
  const by = new Map<string, string[]>();
  for (const o of others) by.set(o.by, [...(by.get(o.by) ?? []), o.path]);
  return [...by].map(([title, paths]) => `Also changed since by “${title}”: ${paths.join(', ')}`).join(' · ');
}

/**
 * Undo's preview: what putting the turn back would do -- the turns after it
 * too: the agent's edits, the files a command changed or deleted (an export
 * the dev server made, a command the agent ran), put back from the turn's
 * snapshot, and those a command made, removed -- and what it cannot: a file
 * git ignores, which no snapshot has, or any with no snapshot of the turn.
 */
export function rewindWords(answer: RewindAnswer, after: number): string {
  if (!answer.canRewind) return `This turn cannot be undone${answer.error ? `: ${answer.error}` : ''}`;
  const which = after === 0 ? 'this turn' : `this turn and the ${after === 1 ? 'one' : after} after it`;
  const { put, kept } = rewindParts(answer, after);
  return `${put === null ? `Nothing of ${which} to put back` : `${put}: ${which}`}${kept ? ` · ${kept}` : ''}`;
}

/** Of the agent's edits a rewind puts back, those that made a file (`created`): putting them back removes it. */
const madeByAgent = (answer: RewindAnswer): string[] => (answer.canRewind ? answer.files.filter((f) => answer.created.includes(f)) : []);

/**
 * Undo's preview in two parts: what it puts back and removes ("Put back 3
 * files, +40 −12"; "Remove 2 files the turn made" -- a file a turn made comes
 * back as nothing), null for nothing; and what it cannot ("not undone: …").
 */
function rewindParts(answer: RewindAnswer, after = 0): { put: string | null; kept: string | null } {
  const made = madeByAgent(answer);
  const edited = answer.canRewind ? answer.files.length - made.length : 0;
  const lines = `+${answer.added} −${answer.removed}`;
  const back: string[] = [];
  if (edited > 0) back.push(`${plural(edited, 'file')}${made.length === 0 ? `, ${lines}` : ''}`);
  if (answer.canRewind && answer.changed.length > 0) back.push(`${plural(answer.changed.length, 'file')} a command changed or deleted`);
  let put = back.length > 0 ? `Put back ${back.join(', and ')}` : '';
  const removes: string[] = [];
  if (made.length > 0) removes.push(`${plural(made.length, 'file')} the ${after === 0 ? 'turn' : 'turns'} made${edited > 0 ? ` (${lines} in all)` : ''}`);
  if (answer.canRewind && answer.made.length > 0) removes.push(`${plural(answer.made.length, 'file')} a command made`);
  if (removes.length > 0) put += `${put === '' ? 'Remove' : '; remove'} ${removes.join(' and ')}`;
  const kept = answer.kept.length === 0 ? null : `not undone: ${plural(answer.kept.length, 'file')} ${answer.snapshot ? 'git ignores, which no snapshot has' : 'changed outside the agent\'s edits, with no snapshot of the turn'}`;
  return { put: put === '' ? null : put, kept };
}

/** What a stand-in needs to be a menu: shown or not, and brought into view. */
export interface MenuLike {
  hidden: HTMLElement['hidden'];
  scrollIntoView(options: ScrollIntoViewOptions): void;
}

/**
 * Always ▾'s menu: opened and shut by its button, and grown by More… --
 * scrolled into view each time it opens or grows: a card arrives at the
 * list's end, and a menu opening below it would be under the list's edge,
 * a click that seems to do nothing.
 */
export function alwaysMenu(menu: MenuLike, rest: MenuLike | null, more: MenuLike | null): { toggle(): boolean; more(): void; shut(): void } {
  const shown = (): void => menu.scrollIntoView({ block: 'nearest' });
  return {
    toggle() {
      menu.hidden = !menu.hidden;
      if (!menu.hidden) shown();
      return !menu.hidden;
    },
    more() {
      if (rest) rest.hidden = false;
      if (more) more.hidden = true;
      shown();
    },
    shut() {
      menu.hidden = true;
    },
  };
}

/** What the studio's tools are called by the agent (Docs/mcp.md): `mcp__studio__scene_set`. */
export const STUDIO_TOOLS = 'mcp__studio__';

/** Where an editor row's call stands, as this tab sees it: its step's state (`mcp/page.ts`), or run in another tab. */
export type RowState = StepState | 'elsewhere';

/**
 * An editor tool's row (§8): "Editor", what it did -- the page's words once it
 * has answered (the `editor` entry), the call's own until then, and "— denied"
 * when its card was -- the hover's detail, and whether it was not done (and
 * why, on the row itself). Where the step is is the step's words', beside it:
 * a log from before the page said so has its old claim ("Z undoes it") dropped.
 */
export function editorRowWords(tool: Of<'tool'>, answer: Of<'editor'> | null, refused: CardOutcome | null = null): { name: string; words: string; title: string; bad: boolean } {
  const name = tool.tool.startsWith(STUDIO_TOOLS) ? tool.tool.slice(STUDIO_TOOLS.length) : tool.tool;
  if (!answer) {
    if (refused === 'denied' || refused === 'stopped') {
      const why = refused === 'denied' ? 'you denied it, and the agent was told' : 'the turn was stopped before anyone answered its card';
      return { name: 'Studio', words: `${tool.detail} — ${refused}`, title: `${name}: ${tool.detail}\nNot done: ${why}`, bad: true };
    }
    return { name: 'Studio', words: tool.detail, title: `${name}: ${tool.detail}`, bad: false };
  }
  if (!answer.ok) return { name: 'Studio', words: `${answer.words} -- not done: ${answer.detail ?? 'the studio did not say why'}`, title: `${name}: ${answer.words}\nNot done: ${answer.detail ?? 'the studio did not say why'}`, bad: true };
  const detail = answer.detail?.replace(/: Z undoes it$/, '') ?? null;
  return { name: 'Studio', words: answer.words, title: `${name}: ${answer.words}${detail ? `\n${detail}` : ''}`, bad: false };
}

/**
 * What an editor row's step says beside it: Undo while it is on top of the
 * editor's stack, else where it is -- under a later edit, undone, gone from
 * the stack, from before the page reloaded (Undo this turn puts it back) --
 * or that another tab ran it; nothing for a call that made no step here.
 */
export function stepWords(state: RowState): { undo: boolean; text: string; title: string } | null {
  switch (state) {
    case 'top':
      return { undo: true, text: 'Undo', title: 'Undo this edit: the editor\'s own undo, as Z would -- Y does it again' };
    case 'undone':
      return { undo: false, text: 'undone', title: 'Undone in the editor: Y does it again while nothing else is done' };
    case 'under':
      return { undo: false, text: 'under a later edit', title: 'A later edit is on top of it: Z undoes that one first' };
    case 'gone':
      return { undo: false, text: 'gone from the undo stack', title: 'The editor\'s history let it go -- another scene loaded, the game ran, or it is older than the steps it keeps: Undo this turn says which' };
    case 'before':
      return {
        undo: false,
        text: 'from before the reload: Undo this turn puts it back',
        title: 'Made before the page reloaded, and the undo stack starts afresh with a reload: Z does not reach it. Undo this turn, on its result, puts the value it had back -- where nobody has changed it since',
      };
    case 'elsewhere':
      return { undo: false, text: 'in another tab', title: 'Done in the editor of another tab -- the one that sent the turn: this tab\'s world is as it was' };
    default:
      return null;
  }
}

/** Undo this turn's step for edits from before a reload, by the turn's words: "Undo Claude's edits (turn “move this crate…”)". */
export function undoLabel(prompt: string | null): string {
  const words = (prompt ?? '').replace(/\s+/g, ' ').trim();
  if (words === '') return 'Undo Claude\'s edits';
  return `Undo Claude's edits (turn “${words.length > 24 ? `${words.slice(0, 23).trimEnd()}…` : words}”)`;
}

/**
 * Undo this turn's preview with its editor edits (§8): the files
 * (`rewindWords`) "· and 2 editor edits" -- walked back on the editor's undo
 * stack, the later turns' among them, or put back by value from before a
 * reload, a field changed since left as it is -- or why those cannot be:
 * gone from the stack, an edit of the person's on top. With no file to put
 * back it leads with the edits ("Undo 1 editor edit: this turn"), the files'
 * reason after. `can`: a second click does something.
 */
export function turnUndoWords(files: { answer: RewindAnswer; after: number } | null, steps: TurnSteps | null, after = files?.after ?? 0, elsewhere = 0): { text: string; can: boolean } {
  const which = after === 0 ? 'this turn' : `this turn and the ${after === 1 ? 'one' : after} after it`;
  const answer = files?.answer ?? null;
  const parts = answer ? rewindParts(answer, after) : { put: null, kept: null };
  const filesCan = answer !== null && answer.canRewind && answer.files.length + answer.changed.length + answer.made.length > 0;
  const filesCannot = answer !== null && !answer.canRewind ? (answer.error ?? 'nothing to put back') : null;
  const kept = parts.kept ? ` · ${parts.kept}` : '';
  const own = steps?.own ?? 0;
  const n = (steps?.count ?? 0) + (steps?.values ?? 0);
  const editsCan = steps !== null && steps.why === null && n > 0;
  // The editor's part: what it undoes, and which of them are whose.
  let edits = plural(n, 'editor edit');
  if (steps && editsCan) {
    const whose: string[] = [];
    if (steps.values === n) edits += ' from before the reload';
    else if (steps.values > 0) whose.push(`${steps.values} from before the reload`);
    if (steps.later > 0) whose.push(steps.later === 1 ? '1 from a later turn' : `${steps.later} from later turns`);
    if (whose.length > 0) edits += ` (${whose.join(', ')})`;
  }
  const left = steps && editsCan && steps.left.length > 0 ? ` · left as ${steps.left.length === 1 ? 'it is' : 'they are'}, changed since: ${steps.left.join(', ')}` : '';
  // What of this turn's own the editor cannot undo, and why: gone from the stack -- all, or some -- or not walked back.
  const of = (whose: string): string | null => {
    if (!steps || own === 0) return null;
    const said: string[] = [];
    if (steps.lost >= own) said.push(`${whose} ${plural(own, 'editor edit')} ${own === 1 ? 'is' : 'are'} gone from the undo stack (${steps.gone})`);
    else if (steps.lost > 0) said.push(`${steps.lost} of ${whose === 'its' ? 'its' : whose.toLowerCase()} ${own} editor edits ${steps.lost === 1 ? 'is' : 'are'} gone from the undo stack (${steps.gone})`);
    if (steps.why !== null && steps.lost < own) said.push(`${said.length > 0 ? 'the rest' : `${whose} ${plural(own, 'editor edit')}`} cannot be undone: ${steps.why}`);
    return said.length > 0 ? said.join(' · ') : null;
  };
  // Made in another tab, which keeps them: undone there, never here.
  const away = elsewhere > 0 ? ` · ${elsewhere === 1 ? 'its 1 editor edit was' : `its ${elsewhere} editor edits were`} made in another tab: undo ${elsewhere === 1 ? 'it' : 'them'} there` : '';
  const note = of('its');
  const noted = `${note ? ` · ${note}` : ''}${away}`;
  if (parts.put !== null && filesCan) {
    return { text: `${parts.put}: ${which}${editsCan ? ` · and ${edits}` : ''}${left}${noted}${kept}`, can: true };
  }
  if (editsCan) {
    return { text: `Undo ${edits}: ${which}${left}${noted}${filesCannot ? ` · its files cannot be put back: ${filesCannot}` : ''}${kept}`, can: true };
  }
  if (filesCannot && answer?.error) return { text: `This turn cannot be undone: ${answer.error}${noted}${kept}`, can: false };
  const alone = of('This turn\'s');
  return { text: `${alone ?? `Nothing of ${which} to put back`}${away}${kept}`, can: false };
}

/** What a settled card says it came to. */
export function outcomeWords(outcome: CardOutcome, detail: string | null): string {
  switch (outcome) {
    case 'allowed':
      return 'Allowed';
    case 'always':
      return detail ? `Always · ${detail}` : 'Always';
    case 'denied':
      return 'Denied: the agent was told you declined';
    case 'answered':
      return detail ? `Answered · ${detail}` : 'Answered';
    case 'skipped':
      return 'Skipped: the agent was told you chose not to answer';
    case 'stopped':
      return 'Stopped: nobody answered';
  }
}

/** The head's line: what is going on, how it sounds, and whether Retry would help. */
export interface HeadLine {
  text: string;
  /** `run` a turn under way; `wait` a card waiting; `bad` a failure; `idle` nothing going on. */
  tone: 'run' | 'wait' | 'bad' | 'idle';
  /** What to do next, for a failure. */
  next: string | null;
  /** `POST attach` again would start what failed. */
  retry: boolean;
}

/**
 * The head's line for the state (§4, The card; §2, Failures): a turn's
 * progress while one runs -- starting, a review round against its bar,
 * retrying, a card waiting, stopping -- and otherwise a failure with its next
 * step, or what a bar costs, while one is set; else nothing (the head hidden).
 */
export function headLine(state: AgentState | null, entries: readonly Entry[], page: { unavailable: string | null; offline: boolean; home: string }): HeadLine {
  const line = (text: string, tone: HeadLine['tone'] = 'idle', next: string | null = null, retry = false): HeadLine => ({ text, tone, next, retry });
  // A designer on the same Mac who used the Network URL is refused too: the address to use, named.
  if (page.unavailable !== null) return line(`Claude Code is ${page.unavailable}: open ${page.home} on the machine running the dev server`, 'bad');
  if (page.offline) return line('The dev server is not answering: the page reloads when it is back', 'bad');
  if (state === null) return line('Connecting to Claude Code…');
  if (!state.available) return line(state.why ?? 'Claude Code is not available here', 'bad');
  const run = state.running;
  if (run) {
    if (run.stopping) return line('Stopping…', 'run');
    if (state.session === 'starting') return line('Starting Claude Code…', 'run');
    if (state.pending.length > 0) return line('Waiting for you', 'wait');
    if (run.origin === 'cli') return line('Claude Code went on by itself: a task it left running told it something', 'run');
    if (state.retrying) return line(`Retrying (${state.retrying.attempt}/${state.retrying.of})…`, 'run');
    // A Gladius script the turn wrote being built, or the turn sent back to fix it (Docs/modeler.md M29, D110).
    if (run.fixing?.checking) return line('Checking the script builds…', 'run');
    if (run.fixing) return line(`Fixing build errors (${run.fixing.attempt}/${run.fixing.of})…`, 'run');
    if (run.round > 0) {
      const last = run.last !== null ? ` · last ${run.last}/10` : '';
      return line(`Review ${run.round}/${state.review.max}${last}${run.bar !== null ? ` · bar ${run.bar}/10` : ''}`, 'run');
    }
    return line('Working…', 'run');
  }
  if (state.session === 'starting') return line('Starting Claude Code…', 'run');
  // Not logged in is the state's alone: an entry saying so may be from before a restart, and the CLI is logged in now.
  if (state.login) return line(state.login.text, 'bad', state.login.next, true);
  // The last failure since the last turn was sent, said by this dev-server process: said until the next turn is.
  let failure: Of<'error'> | null = null;
  for (const e of entries) {
    if (e.epoch !== state.epoch) continue;
    if (e.kind === 'prompt' || (e.kind === 'rule' && e.reset)) failure = null;
    else if (e.kind === 'error' && e.code !== 'login') failure = e;
  }
  if (state.session === 'failed') return line(failure?.text.split('\n')[0] ?? 'Claude Code would not start', 'bad', failure?.next ?? 'Retry, or run `claude` in a terminal to see why.', true);
  if (failure) return line(failure.text.split('\n')[0]!, 'bad', failure.next, false);
  const bar = state.review.bars.find((b) => b.value === state.settings.review);
  if (state.review.available && bar && bar.score !== null) return line(`Reviewed until it scores ${bar.score}/10 · a turn takes several times longer`);
  return line('');
}

/** The head's code line: changed files held until the turn ends, and the way to have them now. */
export const heldWords = (n: number): string => `Code changed · ${plural(n, 'file')} · Reload now`;

/** The head's context line after a turn: past 80 %, the way out too. */
export const contextWords = (percent: number): string => `context ${percent} %${percent > 80 ? ' · Clear to start fresh' : ''}`;

// ---------------------------------------------------------------- the view

export interface TranscriptOptions {
  /** `GET input?id=`: an Edit or Write row's whole input. */
  input(id: string): Promise<unknown>;
  /** `POST answer`; its refusal, thrown, is said on the card. */
  answer(request: { id: string; allow: boolean; always?: PermissionCard['always'][number]['destination']; answers?: Record<string, string | string[]> }): Promise<void>;
  /** `POST rewind`; a real one with what its preview listed from the snapshot. */
  rewind(turn: string, dryRun: boolean, shown?: { changed: string[]; made: string[] }): Promise<RewindAnswer>;
  /** A file of a result clicked, with the result's turn: shown where it is (in studio mode a text file's diff from the turn's start). Answers what was done, for its title. */
  reveal(path: string, turn?: string): Promise<string>;
  /** Is a turn running: Undo waits for it to end. */
  running(): boolean;
  /** A card came in, live: the card's to unfold and show it. */
  cardIn(element: HTMLElement): void;
  /** A card answered here: the focus back in the prompt box, if it was on the card or nowhere. */
  focusBox(): void;
  /** The editor steps the agent made in this tab (`mcp/page.ts`): a row's Undo, Undo this turn's editor edits. */
  editor?: {
    stepOf(use: string): StepState;
    undo(use: string): string | null;
    turnSteps(turn: string): TurnSteps | null;
    undoTurn(turn: string, label?: string): { undone: number; left: string[] } | { error: string };
    /** Why nothing may be undone just now -- an Apply, its undo or its redo landing ("Undoing the Apply: a moment") -- or null. */
    holding?(): string | null;
    /** History moved: each row's step read again, and each Undo this turn's preview. Returns the undo. */
    on(listener: () => void): () => void;
  };
  /** This tab's id (its hello's): an editor row another tab ran says so. */
  tab?(): string | null;
  /** The `/btw` blocks dismissed in this browser tab, by id: not drawn again. */
  dismissed?: { has(id: string): boolean; add(id: string): void };
}

export interface Transcript {
  /** The scrolling list. */
  readonly root: HTMLElement;
  /** Entries in order; `all`, the whole log in place of what is drawn. */
  add(entries: readonly Entry[], all: boolean): void;
  /** Streaming text, before its entry. */
  delta(delta: Delta): void;
  /**
   * The cards still open, as the state that came with a whole log has them: a
   * card drawn that is not among them and has no answer -- its process gone --
   * greys as stopped. Only with a whole log: a later state may be older than
   * a card pushed since.
   */
  pending(cards: readonly Card[]): void;
  /** The newest in view. */
  toEnd(): void;
  /** Shown again -- unfolded, after a playtest, the editor opened: the card waiting in view, else the newest unless scrolled up. */
  shown(): void;
  /** The first card still waiting, if any. */
  waiting(): HTMLElement | null;
  /** The editor rows read again: this tab's id was made anew, and whose rows are whose with it. */
  refresh(): void;
  /**
   * A block of the card's own, at the end -- never an entry, gone with a reload (`/usage`'s card) -- its × dismissing
   * it; `key` names it, one of the same key taking the last one's place.
   */
  aside(key: string, block: HTMLElement): void;
  /** A subagent's call brought into view, its steps unfolded and its row lit a moment. False: its row is not drawn. */
  reveal(id: string): boolean;
  readonly entries: readonly Entry[];
  /** Its observer let go: the card is going. */
  dispose(): void;
}

/** Each checklist item's mark. */
const TICKS = { pending: '☐', in_progress: '◐', completed: '☑' } as const;

/** The tools whose row unfolds to its change. */
const CHANGERS = new Set(['Edit', 'MultiEdit', 'Write', 'NotebookEdit']);


/** A step count: "1 step", "4 steps". */
export const stepsWords = (n: number): string => `${n} step${n === 1 ? '' : 's'}`;

/**
 * A `/btw` block's foot: how long, the fork's own tokens (≈: its turn's `usage`), and that it is not in the conversation.
 * An entry kept before `tokens` (a43c0d7b's, with a `cost`) has none: said as not said.
 */
export function btwWords(e: { answer: string | null; error: string | null; tokens?: { read: number; written: number } | null; ms: number | null }): string {
  if (e.answer === null && e.error === null) return 'asking a copy of the conversation, with no tools…';
  const k = (n: number): string => (n < 1000 ? String(n) : `${(n / 1000).toFixed(n < 10_000 ? 1 : 0)}k`);
  const parts = [...(e.ms !== null ? [seconds(e.ms)] : []), e.tokens != null ? `≈ ${k(e.tokens.read)} tokens read, ${k(e.tokens.written)} written` : 'its tokens not said', 'not in the conversation'];
  return parts.join(' · ');
}

export function createTranscript(options: TranscriptOptions): Transcript {
  const list = el('div', 'ed-ag-list');
  let entries: Entry[] = [];
  /** The cards drawn, by id: greyed when their answer comes. */
  const cards = new Map<string, { root: HTMLElement; settle(outcome: CardOutcome, detail: string | null): void }>();
  /** The checklist shown, a subagent's apart: the next one takes its place. */
  const todos = new Map<boolean, HTMLElement>();
  /** Each review round's row, by its call: its score, when it comes, takes the launch's place. */
  const reviews = new Map<string, HTMLElement>();
  /** Each editor tool's row, by its call: the page's answer, when it comes, its words; its card's refusal; its step read again as history moves. */
  const editorRows = new Map<string, { root: HTMLElement; answer(entry: Of<'editor'>): void; refused(outcome: CardOutcome): void; paint(): void }>();
  /** Each permission card's call, by the card: a refusal marks the call's row. */
  const cardUses = new Map<string, string>();
  /** Each subagent's call's row, by its id: its steps go in its group. */
  const groups = new Map<string, { row: HTMLElement; group: HTMLDetailsElement; head: HTMLElement; count: number }>();
  /** Each `/btw` block, by its id: the answer takes the question's place. */
  const btws = new Map<string, HTMLElement>();
  /** The card's own blocks, by key: one at a time each. */
  const asides = new Map<string, HTMLElement>();
  /** Undo this turn's previews up: their words read again as the editor's history moves -- the walk back may now be done, or not. */
  const previews = new Map<HTMLElement, () => void>();
  options.editor?.on(() => {
    for (const row of editorRows.values()) row.paint();
    for (const [row, paint] of previews) {
      if (row.isConnected) paint();
      else previews.delete(row);
    }
  });
  /** Streaming text, until an entry comes. */
  let streaming: HTMLElement | null = null;
  let streamed = '';

  /** Following the newest -- unless scrolled up -- and where it was, as last measured while shown. */
  let stuck = true;
  let top = 0;
  list.addEventListener('scroll', () => {
    if (list.clientHeight === 0) return;
    stuck = follows(list, stuck);
    top = list.scrollTop;
  });
  // Made shorter -- the window, the grip, a History card above -- it stays at the newest if it was there.
  const resized = new ResizeObserver(() => {
    if (stuck && list.clientHeight > 0) list.scrollTop = list.scrollHeight;
  });
  resized.observe(list);
  /** At the newest, unless scrolled up: measured while shown, else as last measured. */
  const atEnd = (): boolean => follows(list, stuck);
  const toEnd = (): void => {
    list.scrollTop = list.scrollHeight;
    if (list.clientHeight > 0) {
      stuck = true;
      top = list.scrollTop;
    }
  };
  /** A row the cap took out: nothing kept of it. */
  const forget = (row: Element): void => {
    // A subagent's call takes its steps with it: each of them forgotten too.
    for (const one of [row, ...row.querySelectorAll('[data-card], [data-use], [data-review], [data-agent], [data-btw]')]) {
      const { card, review, use, agent, btw } = (one as HTMLElement).dataset;
      if (card !== undefined) cards.delete(card);
      if (use !== undefined && editorRows.get(use)?.root === one) editorRows.delete(use);
      if (review !== undefined && reviews.get(review) === one) reviews.delete(review);
      if (agent !== undefined && groups.get(agent)?.row === one) groups.delete(agent);
      if (btw !== undefined && btws.get(btw) === one) btws.delete(btw);
    }
    for (const [key, shown] of todos) if (shown === row || row.contains(shown)) todos.delete(key);
  };

  const sub = (row: HTMLElement, on: boolean): HTMLElement => {
    if (on) {
      row.classList.add('ed-ag-subagent');
      row.prepend(el('span', 'ed-ag-arrow', '↳'));
    }
    return row;
  };

  function page(text: string): HTMLElement {
    const block = el('div', 'ed-ag-page');
    block.append(renderMarkdown(parseMarkdown(text)));
    return block;
  }

  function drawPrompt(e: Of<'prompt'>): HTMLElement {
    const row = el('div', 'ed-ag-e ed-ag-you');
    if (e.text.trim() !== '') row.append(el('div', 'ed-ag-you-text', e.text));
    const meta: string[] = [];
    if (e.images > 0) meta.push(plural(e.images, 'image'));
    if (meta.length > 0) row.append(el('div', 'ed-ag-meta', meta.join(' · ')));
    if (e.context) {
      const fold = el('details', 'ed-ag-context');
      fold.append(el('summary', undefined, 'What the editor showed'), el('pre', undefined, e.context));
      row.append(fold);
    }
    return row;
  }

  /** A card's refusal of the call `use`, from the entries drawn: denied, or stopped unanswered; null for none. */
  function refusalOf(use: string): CardOutcome | null {
    const card = entries.find((x): x is Of<'card'> => x.kind === 'card' && x.card.kind === 'permission' && x.card.use === use);
    if (!card) return null;
    const answer = entries.find((x): x is Of<'answer'> => x.kind === 'answer' && x.card === card.card.id);
    return answer && (answer.outcome === 'denied' || answer.outcome === 'stopped') ? answer.outcome : null;
  }

  /**
   * A studio tool's call (Docs/mcp.md): "Studio" and what it did, the page's words once
   * answered, "— denied" when its card was; another tab's, said so; an
   * `scene_set` this tab ran, its step beside it -- Undo while on top, else
   * where it is.
   */
  function drawEditor(e: Of<'tool'>, answered: Of<'editor'> | null): HTMLElement {
    const row = el('div', 'ed-ag-e ed-ag-tool ed-ag-editor');
    row.dataset.use = e.id;
    const line = el('div', 'ed-ag-tool-line');
    const name = el('span', 'ed-ag-tool-name');
    const detail = el('span', 'ed-ag-tool-detail');
    const undo = control('history_undo', 'ed-ag-link ed-ag-step-undo', 'Undo');
    const where = el('span', 'ed-ag-step');
    line.append(name, detail, undo, where);
    row.append(sub(line, e.sub));
    let answer = answered;
    let refused = answer ? null : refusalOf(e.id);
    const paint = (): void => {
      const words = editorRowWords(e, answer, refused);
      name.textContent = words.name;
      detail.textContent = words.words;
      row.classList.toggle('ed-ag-editor-bad', words.bad);
      // Run in another tab: nothing of it is here. Else its step, as this tab's editor has it.
      const mine = options.tab?.() ?? null;
      const elsewhere = answer?.tab != null && mine !== null && answer.tab !== mine;
      const step = stepWords(elsewhere ? 'elsewhere' : options.editor ? options.editor.stepOf(e.id) : null);
      line.title = step ? `${words.title}\n${step.title}` : words.title;
      undo.hidden = !step?.undo;
      where.hidden = step === null || step.undo;
      if (step) {
        undo.title = step.title;
        where.textContent = step.text;
        where.title = step.title;
      }
    };
    undo.addEventListener('click', () => {
      const why = options.editor?.undo(e.id) ?? null;
      paint();
      if (why !== null) {
        undo.hidden = true;
        where.hidden = false;
        where.textContent = why;
      }
    });
    editorRows.set(e.id, { root: row, answer: (entry) => ((answer = entry), paint()), refused: (outcome) => ((refused = outcome), paint()), paint });
    paint();
    return row;
  }

  function drawTool(e: Of<'tool'>): HTMLElement {
    if (e.tool.startsWith(STUDIO_TOOLS)) {
      // The last answer: a call that timed out and was done all the same has a second, saying what it did.
      const answered = entries.filter((x): x is Of<'editor'> => x.kind === 'editor' && x.id === e.id).at(-1) ?? null;
      return drawEditor(e, answered);
    }
    const row = el('div', 'ed-ag-e ed-ag-tool');
    if (AGENT_TOOLS.has(e.tool)) {
      // A subagent's call: its steps go under it, folded by a summary -- hidden until the first.
      row.classList.add('ed-ag-agent');
      row.dataset.agent = e.id;
      const group = el('details', 'ed-ag-group');
      group.open = true;
      group.hidden = true;
      const head = el('summary', 'ed-ag-group-head', stepsWords(0));
      group.append(head);
      groups.set(e.id, { row, group, head, count: 0 });
    }
    const line = el(e.input || CHANGERS.has(e.tool) ? 'button' : 'div', 'ed-ag-tool-line');
    if (line instanceof HTMLButtonElement) line.type = 'button';
    line.title = `${e.tool}: ${e.detail}`;
    line.append(el('span', 'ed-ag-tool-name', e.tool), el('span', 'ed-ag-tool-detail', e.detail === e.tool ? '' : e.detail));
    row.append(sub(line, e.sub));
    if (line instanceof HTMLButtonElement) {
      line.title += '\nClick for the change';
      let shown: HTMLElement | null = null;
      // mcp: ui -- a tool call's line unfolded
      line.addEventListener('click', () => {
        if (shown) {
          shown.remove();
          shown = null;
          line.removeAttribute('aria-expanded');
          return;
        }
        line.setAttribute('aria-expanded', 'true');
        const change = (shown = el('div', 'ed-ag-change', 'reading…'));
        row.append(change);
        if (!e.input) {
          change.textContent = 'not kept: the change of a call from before the dev server last started';
          return;
        }
        options.input(e.id).then(
          (input) => change.replaceChildren(...changeOf(e.tool, input)),
          (err: Error) => void (change.textContent = /not kept/.test(err.message) ? 'not kept: the dev server keeps the last 20 turns\' changes, and none from before it last started' : err.message),
        );
      });
    }
    const own = groups.get(e.id);
    if (own?.row === row) row.append(own.group);
    return row;
  }

  /** A `/btw` block: the question, then the answer as a page -- thinking… until it comes -- its × dismissing it. */
  function drawBtw(e: Of<'btw'>): HTMLElement {
    const row = el('div', 'ed-ag-e ed-ag-btw');
    row.dataset.btw = e.id;
    const head = el('div', 'ed-ag-btw-head');
    const off = control('ui', 'ed-ag-link ed-ag-btw-off', '×');
    off.title = 'Dismiss this side question: it was never in the conversation, and stays out of it';
    off.addEventListener('click', () => {
      options.dismissed?.add(e.id);
      btws.delete(e.id);
      row.remove();
    });
    head.append(el('span', 'ed-ag-btw-tag', 'btw'), el('span', 'ed-ag-btw-q', e.question), off);
    row.append(head);
    if (e.answer !== null) row.append(page(e.answer));
    else if (e.error !== null) row.append(el('div', 'ed-ag-error-text', e.error));
    row.append(el('div', `ed-ag-btw-foot${e.answer === null && e.error === null ? ' ed-ag-btw-wait' : ''}`, btwWords(e)));
    row.title = 'A side question (/btw): answered by a copy of the conversation with no tools -- never added to it, nor to Undo';
    return row;
  }

  /** An Edit or Write call's input, as what it took out and what it put in. */
  function changeOf(tool: string, input: unknown): HTMLElement[] {
    const r = (typeof input === 'object' && input !== null ? input : {}) as Record<string, unknown>;
    const str = (v: unknown): string => (typeof v === 'string' ? v : '');
    const pair = (old: string, now: string): HTMLElement[] => [
      ...(old !== '' ? [el('pre', 'ed-ag-old', old)] : []),
      el('pre', 'ed-ag-new', now === '' ? '(nothing)' : now),
    ];
    if (tool === 'Write') return [el('div', 'ed-ag-meta', 'The whole file, as written:'), el('pre', 'ed-ag-new', str(r.content))];
    if (tool === 'MultiEdit' && Array.isArray(r.edits)) return r.edits.flatMap((edit) => pair(str((edit as Record<string, unknown>).old_string), str((edit as Record<string, unknown>).new_string)));
    if (tool === 'NotebookEdit') return [el('div', 'ed-ag-meta', `Cell ${str(r.cell_id) || '(new)'}, ${str(r.edit_mode) || 'replace'}:`), el('pre', 'ed-ag-new', str(r.new_source))];
    return [...(r.replace_all === true ? [el('div', 'ed-ag-meta', 'Every match:')] : []), ...pair(str(r.old_string), str(r.new_string))];
  }

  function drawTodo(e: Of<'todo'>): HTMLElement {
    const row = el('div', 'ed-ag-e ed-ag-todo');
    for (const item of e.items) {
      const line = el('div', `ed-ag-todo-item ed-ag-${item.status.replace('_', '-')}`);
      line.append(el('span', 'ed-ag-tick', TICKS[item.status]), el('span', undefined, item.text));
      row.append(line);
    }
    return sub(row, e.sub);
  }

  function drawReview(e: Of<'review'>): HTMLElement {
    const row = el('div', 'ed-ag-e ed-ag-review');
    row.dataset.review = e.id;
    const line = el('div', 'ed-ag-review-line', reviewWords(e));
    if (e.score !== null && e.bar !== null) line.classList.add(e.score >= e.bar ? 'ed-ag-met' : 'ed-ag-under');
    row.append(line);
    if (e.report) {
      const fold = el('details', 'ed-ag-report');
      fold.append(el('summary', undefined, 'The critic\'s report'), page(e.report));
      row.append(fold);
    }
    return row;
  }

  function drawResult(e: Of<'result'>): HTMLElement {
    const row = el('div', `ed-ag-e ed-ag-result${e.ok ? '' : ' ed-ag-result-bad'}`);
    const words = resultWords(e);
    const line = el('div', 'ed-ag-result-line');
    line.append(el('span', 'ed-ag-how', words.how), el('span', 'ed-ag-dot', '·'), el('span', undefined, words.files));
    if (words.cost) {
      const cost = el('span', 'ed-ag-cost', words.cost);
      cost.title = costTitle(e);
      line.append(el('span', 'ed-ag-dot', '·'), cost);
    }
    const undo = control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-link', 'Undo this turn');
    undo.title = 'Put this turn\'s files back as they were before it, and undo its editor edits: first what it would do, then a second click does it';
    /** The editor edits the turn made in this tab, walked back with it: read again at each click, history moving meanwhile. */
    const steps = (): TurnSteps | null => options.editor?.turnSteps(e.turn) ?? null;
    // A turn that changed no file git sees and made no editor edit here has nothing to put back; one Claude Code
    // started itself has no message to rewind to.
    if ((e.files.length > 0 || (steps()?.own ?? 0) > 0) && e.origin !== 'cli') line.append(el('span', 'ed-ag-dot', '·'), undo);
    row.append(line);
    if (e.files.length > 0) {
      const files = el('div', 'ed-ag-files');
      for (const file of e.files) {
        const b = control('ui', 'ed-ag-file');
        b.title = `${file.path}${file.created ? ' (new)' : ''}${file.deleted ? ' (deleted: Undo this turn brings it back)' : ''}${file.before ? ' -- uncommitted before the turn too' : ''}`;
        if (file.deleted) b.classList.add('ed-ag-file-gone');
        b.append(el('span', undefined, file.path));
        if (file.added !== null) b.append(el('span', 'ed-ag-plus', `+${file.added}`), el('span', 'ed-ag-minus', `−${file.removed ?? 0}`));
        b.addEventListener('click', () => {
          options.reveal(file.path, e.turn ?? undefined).then((said) => void (b.title = said), (err: Error) => void (b.title = err.message));
        });
        files.append(b);
      }
      row.append(files);
    }
    const preview = el('div', 'ed-ag-rewind');
    preview.hidden = true;
    row.append(preview);
    /** The dry run's answer, while its preview is up: the files' half, which the editor's history does not move. */
    let files: RewindAnswer | null = null;
    let asked = false;
    const said = el('span');
    const named = el('div', 'ed-ag-meta ed-ag-rewind-files');
    const also = el('div', 'ed-ag-meta ed-ag-rewind-files ed-ag-rewind-others');
    const go = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-danger', 'Put back');
    const keep = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-quiet', 'Keep them');
    const after = (): number => turnsAfter(entries, e.turn);
    /** The editor edits of this turn and those after it another tab made -- and keeps: said, and left to it. */
    const away = (): number => editsElsewhere(entries, e.turn, options.tab?.() ?? null, (use) => options.editor?.stepOf(use) ?? null);
    /** The preview's words, from the files' answer and the editor's steps as they are now: Put back only where it would do something. */
    const paint = (): void => {
      const words = turnUndoWords(files && { answer: files, after: after() }, steps(), after(), away());
      said.textContent = words.text;
      // The files a command touched, by name: what the second click puts back, or removes, from the snapshot.
      const listed = files ? [...files.changed, ...files.made.map((f) => `${f} (removed)`)] : [];
      named.hidden = listed.length === 0;
      named.textContent = `From the turn's snapshot: ${listed.join(', ')}`;
      // Another conversation's later turn changed some of them too: named, by its title -- never put back unsaid.
      const others = othersWords(files);
      also.hidden = others === null;
      also.textContent = others ?? '';
      // Another conversation's turn running: its files may be these, mid-edit -- the server refuses until it ends.
      const busy = files?.busy ?? null;
      if (busy !== null) said.textContent = `${words.text} -- but a turn is running in "${busy}": Undo waits until it ends`;
      go.hidden = !words.can || busy !== null;
      keep.textContent = words.can && busy === null ? 'Keep them' : 'Close';
      const made = files ? madeByAgent(files) : [];
      const put = files?.canRewind ? [...files.files.filter((f) => !made.includes(f)), ...files.changed] : [];
      const removed = files?.canRewind ? [...made, ...files.made] : [];
      const s = steps();
      const edits = s && s.why === null && s.count + s.values > 0 ? [plural(s.count + s.values, 'editor edit')] : [];
      go.title = `Put back: ${[...put, ...edits].join(', ')}${removed.length > 0 ? `; remove: ${removed.join(', ')}` : ''}`;
    };
    const close = (): void => {
      preview.hidden = true;
      previews.delete(row);
      undo.disabled = false;
      asked = false;
    };
    keep.addEventListener('click', close);
    /** Held while an Apply lands: the whole of it refused -- files and editor edits alike -- said in the preview, never half done. */
    const held = (): string | null => {
      const line = options.editor?.holding?.() ?? null;
      return line === null ? null : `Not now -- ${line}`;
    };
    undo.addEventListener('click', () => {
      if (options.running()) {
        preview.hidden = false;
        preview.textContent = 'A turn is running: Undo waits until it ends';
        return;
      }
      if (asked) return;
      const not = held();
      if (not !== null) {
        preview.hidden = false;
        preview.textContent = not;
        return;
      }
      asked = true;
      undo.disabled = true;
      preview.hidden = false;
      preview.textContent = 'Asking what it would put back…';
      preview.scrollIntoView({ block: 'nearest' });
      // A turn that changed no file asks the dev server nothing: its editor edits are this tab's.
      (e.files.length > 0 ? options.rewind(e.turn, true) : Promise.resolve(null)).then(
        (answer) => {
          files = answer;
          go.disabled = keep.disabled = false;
          preview.replaceChildren(said, named, also, go, keep);
          paint();
          previews.set(row, paint);
          preview.scrollIntoView({ block: 'nearest' });
        },
        (err: Error) => {
          preview.textContent = err.message;
          undo.disabled = false;
          asked = false;
        },
      );
    });
    go.addEventListener('click', () => {
      // The preview stays up, its buttons too, with the line: Put back again once it has landed.
      const not = held();
      if (not !== null) {
        said.textContent = `${not} -- Put back again once it has landed`;
        return;
      }
      go.disabled = keep.disabled = true;
      previews.delete(row);
      // The editor's part first: here and now, whatever the dev server answers next -- and before a reload its files may cause.
      const s = steps();
      let edits: string | null = null;
      if (s && s.why === null && s.count + s.values > 0) {
        const prompt = entries.find((x): x is Of<'prompt'> => x.kind === 'prompt' && x.turn === e.turn);
        const walked = options.editor!.undoTurn(e.turn, undoLabel(prompt?.text ?? null));
        edits = 'error' in walked
          ? `the editor edits not undone: ${walked.error}`
          : `undid ${plural(walked.undone, 'editor edit')}${walked.left.length > 0 ? ` (left as changed since: ${walked.left.join(', ')})` : ''}`;
      }
      const answer = files;
      const put = answer?.canRewind ? answer.files.length + answer.changed.length + answer.made.length : 0;
      const done: string[] = [];
      const finish = (): void => {
        if (edits) done.push(edits);
        const text = done.join(' · ');
        preview.replaceChildren(el('span', undefined, text === '' ? 'Nothing to put back' : `${text.charAt(0).toUpperCase()}${text.slice(1)}`));
        undo.disabled = false;
        asked = false;
      };
      (answer !== null && put > 0 ? options.rewind(e.turn, false, { changed: answer.changed, made: answer.made }) : Promise.resolve(null)).then(
        (back) => {
          if (back) {
            const made = madeByAgent(back).length;
            const n = back.files.length - made + back.changed.length;
            const gone = made + back.made.length;
            const did = [...(n > 0 ? [`put back ${plural(n, 'file')}`] : []), ...(gone > 0 ? [`removed ${plural(gone, 'file')}`] : [])];
            done.push(back.canRewind ? `${did.join(', ') || 'put back the files'}${back.skippedLinks ? `; ${plural(back.skippedLinks, 'link')} left as they are` : ''}` : rewindWords(back, 0));
          }
          finish();
        },
        (err: Error) => {
          done.push(`the files not put back: ${err.message}`);
          finish();
        },
      );
    });
    return row;
  }

  /** A card's buttons settled -- greyed, the outcome said -- by an answer here, elsewhere, or a Stop. */
  function settler(row: HTMLElement, buttons: () => Iterable<HTMLButtonElement | HTMLInputElement>, said: HTMLElement): (outcome: CardOutcome, detail: string | null) => void {
    return (outcome, detail) => {
      row.classList.add('ed-ag-settled');
      row.classList.toggle('ed-ag-refused', outcome === 'denied' || outcome === 'stopped' || outcome === 'skipped');
      for (const b of buttons()) b.disabled = true;
      said.hidden = false;
      said.textContent = outcomeWords(outcome, detail);
    };
  }

  function drawPermission(card: PermissionCard): HTMLElement {
    const row = el('div', 'ed-ag-e ed-ag-card');
    row.dataset.card = card.id;
    const head = sub(el('div', 'ed-ag-card-title', card.title), card.sub);
    row.append(head);
    if (card.description) row.append(el('div', 'ed-ag-card-text', card.description));
    // Auto on and a card all the same: the rule that made it, so it does not read as Auto being broken.
    if (card.auto) row.append(el('div', 'ed-ag-meta ed-ag-card-auto', card.auto));
    if (card.reason) row.append(el('div', 'ed-ag-meta', card.reason));
    if (card.detail && card.detail !== card.title && card.detail !== card.description) row.append(el('div', 'ed-ag-card-detail', card.detail));
    const actions = el('div', 'ed-ag-card-actions');
    const said = el('div', 'ed-ag-card-said');
    said.hidden = true;
    const buttons: HTMLButtonElement[] = [];
    const answer = (allow: boolean, always?: PermissionCard['always'][number]['destination']): void => {
      for (const b of buttons) b.disabled = true;
      menuOf.shut();
      options.focusBox();
      options.answer({ id: card.id, allow, ...(always ? { always } : {}) }).catch((err: Error) => {
        said.hidden = false;
        said.textContent = err.message;
        if (!/already answered/.test(err.message)) for (const b of buttons) b.disabled = false;
      });
    };
    const make = (text: string, title: string, extra: string, run: () => void): void => {
      const b = control(NOT_FOR_CLAUDE.claudeControl, `ed-button ed-small ${extra}`, text);
      b.title = title;
      b.addEventListener('click', run);
      buttons.push(b);
      actions.append(b);
    };
    // Always ▾: where it is kept, a small menu -- this conversation and this machine at hand, the project and everywhere behind More….
    const menu = el('div', 'ed-ag-menu');
    menu.hidden = true;
    let menuOf = alwaysMenu(menu, null, null);
    const item = (choice: PermissionCard['always'][number], into: HTMLElement): void => {
      const b = control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-menu-item', choice.label);
      b.title = `Allow it, and calls like it from now on -- kept ${where(choice.destination)}: ${choice.rules.join(', ')}`;
      b.addEventListener('click', () => answer(true, choice.destination));
      buttons.push(b);
      into.append(b);
    };
    make('Allow', 'Allow this call, this once', 'ed-accent', () => answer(true));
    if (card.always.length > 0) {
      make('Always ▾', `Allow it, and calls like it from now on: ${card.always[0]!.rules.join(', ')}. Pick where it is kept.`, 'ed-ag-always', () => {
        always.setAttribute('aria-expanded', String(menuOf.toggle()));
      });
      const always = buttons.at(-1)!;
      always.setAttribute('aria-haspopup', 'true');
      always.setAttribute('aria-expanded', 'false');
      for (const choice of card.always) if (!choice.more) item(choice, menu);
      const further = card.always.filter((choice) => choice.more);
      if (further.length > 0) {
        const more = control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-menu-item ed-ag-menu-more', 'More…');
        more.title = 'Keep it somewhere further reaching: the project\'s settings, committed for everyone, or your own, for every project';
        const rest = el('div', 'ed-ag-menu-rest');
        rest.hidden = true;
        for (const choice of further) item(choice, rest);
        menuOf = alwaysMenu(menu, rest, more);
        more.addEventListener('click', () => menuOf.more());
        buttons.push(more);
        menu.append(more, rest);
      }
    }
    make('Deny', 'Refuse it: the agent is told you declined, and goes on', 'ed-quiet ed-danger', () => answer(false));
    row.append(actions, menu, said);
    cards.set(card.id, { root: row, settle: settler(row, () => buttons, said) });
    return row;
  }

  function drawQuestion(card: QuestionCard): HTMLElement {
    const row = el('div', 'ed-ag-e ed-ag-card ed-ag-question');
    row.dataset.card = card.id;
    row.append(sub(el('div', 'ed-ag-card-title', card.questions.length === 1 ? 'Claude asks' : `Claude asks ${card.questions.length} things`), card.sub));
    const chosen = card.questions.map(() => new Set<string>());
    const others = card.questions.map(() => '');
    const controls: (HTMLButtonElement | HTMLInputElement)[] = [];
    const said = el('div', 'ed-ag-card-said');
    said.hidden = true;
    const answerOf = (n: number): string | string[] | null => {
      const picked = [...chosen[n]!];
      const other = others[n]!.trim();
      if (other !== '') picked.push(other);
      if (picked.length === 0) return null;
      return card.questions[n]!.multiSelect ? picked : picked[0]!;
    };
    const send = (): void => {
      const answers: Record<string, string | string[]> = {};
      for (let n = 0; n < card.questions.length; n++) {
        const a = answerOf(n);
        if (a === null) return;
        answers[card.questions[n]!.question] = a;
      }
      for (const c of controls) c.disabled = true;
      options.focusBox();
      options.answer({ id: card.id, allow: true, answers }).catch((err: Error) => {
        said.hidden = false;
        said.textContent = err.message;
        if (!/already answered/.test(err.message)) for (const c of controls) c.disabled = false;
      });
    };
    const submit = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-accent', 'Answer');
    submit.disabled = true;
    const refresh = (): void => void (submit.disabled = card.questions.some((_, n) => answerOf(n) === null));
    card.questions.forEach((q, n) => {
      const block = el('div', 'ed-ag-q');
      const title = el('div', 'ed-ag-q-title');
      if (q.header) title.append(el('span', 'ed-ag-chip', q.header));
      title.append(el('span', undefined, q.question));
      block.append(title);
      const opts = el('div', 'ed-ag-card-actions');
      const mine: HTMLButtonElement[] = [];
      for (const option of q.options) {
        const b = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small', q.multiSelect ? `☐ ${option.label}` : option.label);
        b.title = option.description;
        b.addEventListener('click', () => {
          const set = chosen[n]!;
          if (q.multiSelect) {
            if (set.has(option.label)) set.delete(option.label);
            else set.add(option.label);
          } else {
            set.clear();
            set.add(option.label);
            others[n] = '';
            other.value = '';
          }
          for (const [i, o] of q.options.entries()) {
            const on = set.has(o.label);
            mine[i]!.setAttribute('aria-pressed', String(on));
            if (q.multiSelect) mine[i]!.textContent = `${on ? '☑' : '☐'} ${o.label}`;
          }
          refresh();
          // One question, one choice: answered as it is clicked.
          if (card.questions.length === 1 && !q.multiSelect) send();
        });
        mine.push(b);
        controls.push(b);
        opts.append(b);
      }
      const form = el('form', 'ed-ag-other');
      form.noValidate = true;
      const other = el('input', 'ed-input');
      other.type = 'text';
      other.placeholder = 'Other: say it in your words';
      other.spellcheck = false;
      other.addEventListener('input', () => {
        others[n] = other.value;
        if (!q.multiSelect && other.value.trim() !== '') {
          chosen[n]!.clear();
          for (const b of mine) b.setAttribute('aria-pressed', 'false');
        }
        refresh();
      });
      // Enter in "Other" is the form's submit: the answers sent, if every question has one.
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        send();
      });
      controls.push(other);
      form.append(other);
      block.append(opts, form);
      row.append(block);
    });
    const actions = el('div', 'ed-ag-card-actions');
    const skip = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-quiet', 'Skip');
    skip.title = 'Answer nothing: the agent is told you chose not to, and goes on';
    skip.addEventListener('click', () => {
      for (const c of controls) c.disabled = true;
      options.focusBox();
      options.answer({ id: card.id, allow: false }).catch((err: Error) => {
        said.hidden = false;
        said.textContent = err.message;
      });
    });
    submit.addEventListener('click', send);
    controls.push(submit, skip);
    actions.append(submit, skip);
    row.append(actions, said);
    cards.set(card.id, { root: row, settle: settler(row, () => controls, said) });
    return row;
  }

  /**
   * The turns made in the terminal (Docs/terminal.md D10), read back from the session: folded under one line, each the
   * person's words, Claude's text and its tool calls counted -- shown, not this column's turns (no Undo, no files).
   */
  function drawTerminal(e: Extract<Entry, { kind: 'terminal' }>): HTMLElement {
    const row = el('details', 'ed-ag-e ed-ag-term-turns');
    row.append(el('summary', undefined, terminalSummary(e.turns.length + e.more)));
    for (const turn of e.turns) {
      const one = el('div', 'ed-ag-term-turn');
      one.append(el('div', 'ed-ag-term-prompt', turn.prompt));
      if (turn.text !== '') one.append(page(turn.text));
      if (turn.tools > 0) one.append(el('div', 'ed-ag-note', turn.tools === 1 ? '1 tool call' : `${turn.tools} tool calls`));
      row.append(one);
    }
    if (e.more > 0) row.append(el('div', 'ed-ag-note', `and ${e.more} more, earlier`));
    return row;
  }

  function drawOne(e: Entry, live: boolean): HTMLElement | null {
    switch (e.kind) {
      case 'prompt':
        todos.clear();
        return drawPrompt(e);
      case 'text': {
        const row = el('div', 'ed-ag-e ed-ag-text');
        row.append(page(e.text));
        return sub(row, e.sub);
      }
      case 'tool':
        return drawTool(e);
      case 'editor': {
        // The page's answer: its words in the call's row, drawn already -- or to be, later in this batch.
        const shown = editorRows.get(e.id);
        if (shown) {
          shown.answer(e);
          return null;
        }
        if (entries.some((x) => x.kind === 'tool' && x.id === e.id)) return null;
        // Its call's row cut by the cap: a row of its own.
        return drawEditor({ kind: 'tool', id: e.id, tool: e.tool, detail: e.words, sub: false, input: false, seq: e.seq, at: e.at }, e);
      }
      case 'todo': {
        // The next list replaces the last one of the turn.
        todos.get(e.sub)?.remove();
        const row = drawTodo(e);
        todos.set(e.sub, row);
        return row;
      }
      case 'review': {
        const row = drawReview(e);
        // The round's score in place of its launch line, where that is drawn.
        const launched = reviews.get(e.id);
        reviews.set(e.id, row);
        if (launched?.isConnected) {
          launched.replaceWith(row);
          return null;
        }
        return row;
      }
      case 'result':
        return drawResult(e);
      case 'card': {
        if (e.card.kind === 'permission' && e.card.use !== undefined) cardUses.set(e.card.id, e.card.use);
        const row = e.card.kind === 'permission' ? drawPermission(e.card) : drawQuestion(e.card);
        if (live) queueMicrotask(() => options.cardIn(row));
        return row;
      }
      case 'answer': {
        // Denied, or stopped unanswered: the call's row says so -- an editor tool's, which would read as done.
        const use = cardUses.get(e.card);
        if (use !== undefined && (e.outcome === 'denied' || e.outcome === 'stopped')) editorRows.get(use)?.refused(e.outcome);
        const card = cards.get(e.card);
        if (card) {
          card.settle(e.outcome, e.detail);
          return null;
        }
        return el('div', 'ed-ag-e ed-ag-note', outcomeWords(e.outcome, e.detail));
      }
      case 'note': {
        if (!e.more) return el('div', 'ed-ag-e ed-ag-note', e.text);
        const row = el('details', 'ed-ag-e ed-ag-note ed-ag-folded-note');
        row.append(el('summary', undefined, `${e.text} · ${e.more.summary}`), el('div', 'ed-ag-note-items', e.more.items.join(', ')));
        return row;
      }
      case 'error': {
        const row = el('div', 'ed-ag-e ed-ag-error');
        row.append(el('div', 'ed-ag-error-text', e.text));
        if (e.next) row.append(el('div', 'ed-ag-next', e.next));
        return row;
      }
      case 'rule': {
        const row = el('div', 'ed-ag-e ed-ag-rule');
        row.append(el('span', undefined, e.text));
        return row;
      }
      case 'terminal':
        return drawTerminal(e);
      case 'btw': {
        if (options.dismissed?.has(e.id)) return null;
        const row = drawBtw(e);
        // The answer in the question's place, where that is drawn.
        const asked = btws.get(e.id);
        btws.set(e.id, row);
        if (asked?.parentNode) {
          asked.replaceWith(row);
          return null;
        }
        return row;
      }
    }
  }

  /** The first card still waiting, if any. */
  function waiting(): HTMLElement | null {
    for (const card of cards.values()) if (!card.root.classList.contains('ed-ag-settled')) return card.root;
    return null;
  }

  function endStream(): void {
    streaming?.remove();
    streaming = null;
    streamed = '';
  }

  return {
    root: list,
    get entries() {
      return entries;
    },
    add(incoming, all) {
      const stick = all || atEnd();
      const before = entries;
      const next = merged(before, incoming, all);
      entries = next.entries;
      endStream();
      const known = new Set(before.map((e) => e.seq));
      const fresh = next.reset ? entries : entries.filter((e) => !known.has(e.seq));
      if (next.reset) {
        list.replaceChildren();
        groups.clear();
        btws.clear();
        asides.clear();
        cards.clear();
        todos.clear();
        reviews.clear();
        editorRows.clear();
        cardUses.clear();
        previews.clear();
      }
      // Cut by the cap: the oldest rows go with their entries, and nothing is kept of them.
      while (list.childElementCount > 0 && list.childElementCount + fresh.length > KEEP) {
        const gone = list.firstElementChild!;
        forget(gone);
        gone.remove();
      }
      for (const e of fresh) {
        const row = drawOne(e, !all);
        if (!row) continue;
        // A subagent's step: under its call, where that is drawn.
        const parent = 'parent' in e ? e.parent : undefined;
        const group = parent !== undefined ? groups.get(parent) : undefined;
        if (group) {
          group.count++;
          group.head.textContent = stepsWords(group.count);
          group.group.hidden = false;
          group.group.append(row);
        } else list.append(row);
      }
      // The card's own blocks stay last.
      for (const block of asides.values()) list.append(block);
      if (stick) toEnd();
    },
    delta(d) {
      const stick = atEnd();
      if (!streaming) {
        streaming = el('div', 'ed-ag-e ed-ag-text ed-ag-streaming');
        if (d.sub) sub(streaming, true);
        list.append(streaming);
      }
      streamed += d.text;
      const last = streaming.lastChild;
      if (last && last.nodeType === Node.TEXT_NODE) (last as Text).data = streamed;
      else streaming.append(streamed);
      if (stick) toEnd();
    },
    pending(open) {
      const ids = new Set(open.map((c) => c.id));
      const answered = settled(entries);
      // A card the server no longer waits on and never said the answer to -- the process that asked is gone: nobody can answer it.
      for (const [id, card] of cards) if (!ids.has(id) && !answered.has(id) && !card.root.classList.contains('ed-ag-settled')) card.settle('stopped', null);
    },
    toEnd,
    shown() {
      const card = waiting();
      if (card) card.scrollIntoView({ block: 'nearest' });
      else if (stuck) toEnd();
      // Scrolled up before it was hidden: back where it was (a list not displayed forgets its scroll).
      else list.scrollTop = top;
    },
    waiting,
    refresh() {
      for (const row of editorRows.values()) row.paint();
    },
    aside(key, block) {
      asides.get(key)?.remove();
      const row = el('div', 'ed-ag-e ed-ag-aside');
      const off = control('ui', 'ed-ag-link ed-ag-aside-off', '×');
      off.title = 'Dismiss: nothing of it was sent';
      off.addEventListener('click', () => {
        if (asides.get(key) === row) asides.delete(key);
        row.remove();
      });
      row.append(off, block);
      asides.set(key, row);
      list.append(row);
      toEnd();
    },
    reveal(id) {
      const shown = groups.get(id);
      if (!shown || !list.contains(shown.row)) return false;
      shown.group.open = true;
      shown.row.scrollIntoView({ block: 'nearest' });
      shown.row.classList.remove('ed-ag-lit');
      // Lit a moment: the class's animation, started again.
      void shown.row.offsetWidth;
      shown.row.classList.add('ed-ag-lit');
      return true;
    },
    dispose: () => resized.disconnect(),
  };
}

/** Where an Always is kept, as its button's title says it. */
function where(destination: PermissionCard['always'][number]['destination']): string {
  switch (destination) {
    case 'session':
      return 'for this conversation';
    case 'localSettings':
      return 'on this machine, in .claude/settings.local.json';
    case 'projectSettings':
      return 'for the project, in .claude/settings.json (committed)';
    case 'userSettings':
      return 'everywhere, in your own ~/.claude/settings.json';
  }
}
