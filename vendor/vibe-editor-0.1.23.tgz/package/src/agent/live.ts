/**
 * The agent's push channel and its reads (Docs/agent.md §2, "The push"): the
 * state, the log's entries in order, and the streaming text, kept current for
 * the card.
 *
 * - **Attach first**: `start()` is `POST attach` from `since=0` -- the first
 *   one starts the conversation's CLI, a later one after a reload finds it up
 *   and hands back the whole log, so a page that reloads (the agent's code
 *   arriving) has its transcript intact. Pushes heard before its answer are
 *   kept and applied after it, by the same rule. A page on another machine,
 *   or this one by its LAN address, is refused the write -- a `403` -- which
 *   is the read's answer said another way: unavailable, "on this machine
 *   only", never "Connecting…" for good. `retry()` is the Retry button's
 *   attach, the one that starts a failed CLI again.
 * - **Entries by `seq`**: one at or before the last is a no-op, the next one
 *   is applied, one past it a gap -- filled with `GET state?since=`, one at a
 *   time, once more if another gap came meanwhile.
 * - **A new `epoch` is a restart, not a gap**: the whole log asked for again
 *   and put in place of what is here.
 * - **`{ delta }`**: streaming text, never kept -- the `text` entry that
 *   follows replaces it.
 * - **Offline** on Vite's `vite:ws:disconnect`, which a restart is; on
 *   `vite:ws:connect` again the log is asked for since the last entry.
 * - **`{ mcp }`**: an editor tool's call (Docs/agent.md §8), pushed to this
 *   tab alone because it said which tab it is: its hello, `{ tab }` on the
 *   same socket (`vibebase:agent:hello`), as it starts, on every reconnect --
 *   a restarted dev server knows no tab until told -- and when the tab's id
 *   is made anew (`setTab`: it was a duplicate's, `tab.ts`).
 *
 * The channel is handed in (`import.meta.hot` by default), so a node test
 * drives it by hand. The card's is one conversation's (`hub.ts`): a channel
 * that hears that conversation's pushes alone, the hub saying the tab's
 * hello for them all.
 */
import type { AgentState, Delta, Entry, Hello, HelloEvent, McpCall, StateAnswer, TabMessage, TerminalPush, Unavailable } from '@vibe/pipeline/agent-types';
import { AgentRefused, isUnavailable, type AgentApi } from './api.ts';

/** The push channel's event, as `api-types.ts` names it. */
const EVENT = 'vibebase:agent';
/** The page's hello, on the same socket. */
const HELLO: HelloEvent = 'vibebase:agent:hello';

/** What a page refused the write is told: the server's own answer to its read. */
const ELSEWHERE: Unavailable = { available: false, why: 'on this machine only' };

/** An attach, a `403` -- another machine, another origin -- taken for the read's `{ available: false }`. */
async function attachOrElsewhere(attach: Promise<StateAnswer | Unavailable>): Promise<StateAnswer | Unavailable> {
  try {
    return await attach;
  } catch (err) {
    if (err instanceof AgentRefused && err.status === 403) return ELSEWHERE;
    throw err;
  }
}

/** What `import.meta.hot` is to this module: a way to hear an event, to stop, and to say something to the server. */
export interface HotChannel {
  on(event: string, listener: (data: never) => void): void;
  off?(event: string, listener: (data: never) => void): void;
  send?(event: string, data?: unknown): void;
}

export interface LiveEvents {
  /** Entries, in order: `all` when they are the whole log in place of what was there (an attach, a restart). */
  entries: (entries: readonly Entry[], all: boolean) => void;
  state: (state: AgentState) => void;
  delta: (delta: Delta) => void;
  /** The dev server stopped answering, or answered again. */
  offline: (offline: boolean) => void;
  /** This page may not read the transcript -- another machine -- and why. */
  unavailable: (why: string) => void;
  /** An editor tool's call, for this tab to run and answer. */
  mcp: (call: McpCall) => void;
  /** The conversation's terminal (Docs/terminal.md D3): output to draw, or its CLI ended. */
  terminal: (push: TerminalPush) => void;
}

export interface AgentLive {
  readonly state: AgentState | null;
  /** Why this page has no transcript (another machine), or null. */
  readonly unavailable: string | null;
  readonly offline: boolean;
  /** The last entry applied. */
  readonly seq: number;
  /** `POST attach`, the whole log; once -- later calls answer the same. */
  start(): Promise<void>;
  /** `POST attach { retry: true }`: a CLI that failed, or is not logged in, started again. */
  retry(): Promise<void>;
  /** States heard so far, pushed or read: what an answer's state is checked against (`take`). */
  readonly heard: number;
  /** This tab's id made anew (a duplicate's was another's): said in a hello at once, once started. */
  setTab(id: string): void;
  /**
   * A state an answer brought (`POST settings`, `stop`…), as if pushed -- but
   * only if no state was heard since the call went (`asOf`, `heard` then): an
   * answer computed before a push can arrive after it, and the push is newer.
   */
  take(state: AgentState, asOf?: number): void;
  on<E extends keyof LiveEvents>(event: E, listener: LiveEvents[E]): () => void;
  dispose(): void;
}

/**
 * `tab`: this tab's id, said in its hello so the editor tools' calls reach it;
 * null, none said (a test's, or a page that runs no tools).
 */
export function createAgentLive(api: AgentApi, hot: HotChannel | undefined = import.meta.hot as HotChannel | undefined, tab: string | null = null): AgentLive {
  let state: AgentState | null = null;
  let unavailable: string | null = null;
  let offline = false;
  let seq = 0;
  let started: Promise<void> | null = null;
  /** Pushes heard while the attach is on its way, applied after it. */
  let early: TabMessage[] | null = null;
  let filling: Promise<void> | null = null;
  let again = false;
  const listeners: { [E in keyof LiveEvents]: Set<LiveEvents[E]> } = { entries: new Set(), state: new Set(), delta: new Set(), offline: new Set(), unavailable: new Set(), mcp: new Set(), terminal: new Set() };
  const tell = <E extends keyof LiveEvents>(event: E, ...args: Parameters<LiveEvents[E]>): void => {
    for (const fn of listeners[event]) (fn as (...a: Parameters<LiveEvents[E]>) => void)(...args);
  };

  /** States heard, pushed or read. */
  let heard = 0;

  function setState(next: AgentState): void {
    state = next;
    heard++;
    tell('state', next);
  }

  /** A whole answer -- an attach, a restart's log -- in place of what was here. */
  function replace(answer: StateAnswer | Unavailable): void {
    if (isUnavailable(answer)) {
      unavailable = answer.why;
      tell('unavailable', answer.why);
      return;
    }
    unavailable = null;
    seq = answer.entries.reduce((n, e) => Math.max(n, e.seq), 0);
    tell('entries', answer.entries, true);
    setState(answer.state);
  }

  /** The entries after `seq`, from a gap filled: in order, the old ones dropped. */
  function append(entries: readonly Entry[]): void {
    const fresh = entries.filter((e) => e.seq > seq);
    if (fresh.length === 0) return;
    seq = fresh.reduce((n, e) => Math.max(n, e.seq), seq);
    tell('entries', fresh, false);
  }

  /** `GET state?since=` the last entry: a gap filled, or the log after a reconnect. */
  function fill(): Promise<void> {
    if (filling) {
      again = true;
      return filling;
    }
    filling = (async () => {
      try {
        do {
          again = false;
          const answer = await api.state(seq);
          if (isUnavailable(answer)) return replace(answer);
          if (state !== null && answer.state.epoch !== state.epoch) return replace(await api.state(0));
          append(answer.entries);
          setState(answer.state);
        } while (again);
      } finally {
        filling = null;
      }
    })();
    return filling;
  }

  function apply(message: TabMessage): void {
    // The list of conversations is the hub's (`hub.ts`), no one conversation's.
    if ('conversations' in message || 'page' in message) return;
    if ('delta' in message) return tell('delta', message.delta);
    if ('mcp' in message) return tell('mcp', message.mcp);
    if ('terminal' in message) return tell('terminal', message.terminal);
    if ('state' in message) {
      // Another process: a restart, not a gap -- the whole log again.
      if (state !== null && message.state.epoch !== state.epoch) {
        state = message.state;
        void api.state(0).then(replace, () => {});
        return;
      }
      return setState(message.state);
    }
    const { entry } = message;
    if (entry.seq <= seq) return;
    if (entry.seq === seq + 1) {
      seq = entry.seq;
      tell('entries', [entry], false);
      return;
    }
    void fill().catch(() => {});
  }

  const hear = (data: unknown): void => {
    const message = data as TabMessage;
    if (typeof message !== 'object' || message === null) return;
    if (early) early.push(message);
    else if (started !== null) apply(message);
  };
  const down = (): void => {
    offline = true;
    tell('offline', true);
  };
  /** Which tab this socket is: the editor tools' calls come to it. */
  const hello = (): void => {
    if (tab !== null) hot?.send?.(HELLO, { tab, multi: true } satisfies Hello);
  };
  const up = (): void => {
    // Said on every connect: a dev server that restarted knows no tab.
    if (started !== null) hello();
    if (!offline) return;
    offline = false;
    tell('offline', false);
    if (started !== null) void fill().catch(() => {});
  };
  hot?.on(EVENT, hear as (data: never) => void);
  hot?.on('vite:ws:disconnect', down as (data: never) => void);
  hot?.on('vite:ws:connect', up as (data: never) => void);

  async function attach(): Promise<void> {
    hello();
    early ??= [];
    try {
      replace(await attachOrElsewhere(api.attach(0)));
    } finally {
      const heardMeanwhile = early ?? [];
      early = null;
      for (const message of heardMeanwhile) apply(message);
    }
  }

  return {
    get state() {
      return state;
    },
    get unavailable() {
      return unavailable;
    },
    get offline() {
      return offline;
    },
    get seq() {
      return seq;
    },
    start() {
      return (started ??= attach());
    },
    async retry() {
      if (started === null) return this.start();
      const answer = await attachOrElsewhere(api.attach(seq, true));
      if (isUnavailable(answer)) return replace(answer);
      append(answer.entries);
      setState(answer.state);
    },
    get heard() {
      return heard;
    },
    setTab(id) {
      tab = id;
      if (started !== null) hello();
    },
    take(next, asOf) {
      if (asOf !== undefined && asOf !== heard) return;
      if (state !== null && next.epoch !== state.epoch) return apply({ state: next });
      setState(next);
    },
    on(event, listener) {
      const set = listeners[event] as Set<typeof listener>;
      set.add(listener);
      return () => void set.delete(listener);
    },
    dispose() {
      hot?.off?.(EVENT, hear as (data: never) => void);
      hot?.off?.('vite:ws:disconnect', down as (data: never) => void);
      hot?.off?.('vite:ws:connect', up as (data: never) => void);
      for (const set of Object.values(listeners)) set.clear();
    },
  };
}
