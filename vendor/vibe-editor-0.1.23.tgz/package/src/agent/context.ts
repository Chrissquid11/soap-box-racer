/**
 * What the editor shows, as a turn's facts (Docs/agent.md §5): the host's
 * lines and the tools' into a `TurnContext`, which the dev server alone puts
 * into words (`packages/pipeline/src/agent/turn.ts`). Pure, so node tests it against a
 * world.
 *
 * - **The host's**: the game's name, a playtest running or paused, the scene -- its
 *   key, unsaved or not, a file under src/assets/scenes/ -- and the tool up.
 * - **The tools'**: each one's `context()`, the tool up's first; a tool with
 *   nothing to say is left out.
 * - **The selection**: its first eight, and how many more -- per entity its
 *   id, `Name`, prefab and node (`madeFrom`), `Labels`, and the model keys its `View` carries (the
 *   asset store tags each model's scene `userData.assetKey`), each once.
 *
 * - **A quick prompt's target** (`entitiesTarget`, Docs/ai-panel.md §4): the
 *   entities it was opened at, as the selection's facts; the tools give theirs
 *   (`ToolInstance.quickTarget`).
 *
 * Facts, no words: no sentence is made here.
 */
import type { ModelTurn, SelectedEntity, ToolContext, TurnContext, TurnImage, TurnTarget } from '@vibe/pipeline/agent-types';
import { type Entity, Labels, madeFrom, Name, View, type World } from '@vibe/engine';
import type { ToolFact } from '../tool.ts';

/** The contract's shape, for the host, which may not import the pipeline itself (`src/assets/imports.test.ts`). */
export type { TurnContext, TurnTarget } from '@vibe/pipeline/agent-types';

/**
 * What the tool up sends with the next turn beyond its facts (Docs/modeler.md
 * M26): the Model tab's model and its canvases, their images. The card shows
 * it over the box -- "With: crate.lua · Front 1 × · Top 2 ×" -- so a person
 * knows, and can leave a canvas out of this turn.
 */
export interface TurnAttachments {
  /** What it is about, in a word: "crate.lua". */
  subject: string;
  /** The canvases that would go, oldest first. */
  canvases: { id: string; name: string; note: boolean }[];
  /** Those that would not, and why: "1 stale -- drawn over the model before it was rebuilt". */
  left: string[];
  /** A canvas left out of the next turn, or put back in. */
  skip(id: string, skipped: boolean): void;
  /** Its facts and its canvases' images, the images numbered from `first` in the turn's, at most `room` of them. */
  gather(first: number, room: number): Promise<{ model: ModelTurn; images: TurnImage[] }>;
  /** The turn went: canvases left out of it are back in for the next. */
  sent(): void;
}

/** Entities a turn names, at most: the server takes eight. */
export const SELECTED_MAX = 8;

/** What the host says of the editor: the game, a playtest, the scene, the tool up. */
export interface HostFacts {
  game: string;
  /** A playtest running (not paused): the editor hidden under the game. */
  playtest: boolean;
  /** The playtest, running or paused with the editor over its world (Docs/terminal.md D9); absent with none. */
  play?: 'running' | 'paused';
  /** The scene open, a file under src/assets/scenes/ by its key -- null for the game's own world, none saved or opened. */
  scene: { name: string | null; unsaved: boolean } | null;
  /** The tool up, by its name. */
  tool: string | null;
}

/** A tool's own facts, by its name; `up`, the tool up. */
export interface ToolFacts {
  tool: string;
  up: boolean;
  facts: readonly ToolFact[] | null;
}

/** Something a `View` can be: a three.js object's tree, as far as the keys are read. */
interface Tagged {
  userData?: { assetKey?: unknown };
  children?: readonly Tagged[];
}

/** Every model key in an object's tree, each once, in the order met. */
export function modelKeysOf(object: Tagged | null | undefined, out: string[] = []): string[] {
  if (!object) return out;
  const key = object.userData?.assetKey;
  if (typeof key === 'string' && key !== '' && !out.includes(key)) out.push(key);
  for (const child of object.children ?? []) modelKeysOf(child, out);
  return out;
}

/** One selected entity, as the turn says it. */
export function selectedEntity(world: World, e: Entity): SelectedEntity {
  const name = world.has(e, Name) ? (world.rawStore(Name) as { value: (string | null)[] }).value[e] ?? null : null;
  const labels = world.has(e, Labels) ? [...((world.rawStore(Labels) as { value: (string[] | null)[] }).value[e] ?? [])] : [];
  const view = world.has(e, View) ? ((world.rawStore(View) as { value: (Tagged | null)[] }).value[e] ?? null) : null;
  const made = madeFrom(world, e);
  return { id: e, name, prefab: made?.prefab ?? null, node: made?.node ?? null, labels, models: modelKeysOf(view) };
}

/** The selection's first `SELECTED_MAX` living entities, and how many more. */
export function selectionFacts(world: World, selected: readonly Entity[]): { selection: SelectedEntity[]; more: number } {
  const alive = selected.filter((e) => world.alive(e));
  return { selection: alive.slice(0, SELECTED_MAX).map((e) => selectedEntity(world, e)), more: Math.max(0, alive.length - SELECTED_MAX) };
}

/** A quick prompt's target in the scene (Docs/ai-panel.md §4): the entities selected, as the selection's facts say them. */
export function entitiesTarget(world: World, selected: readonly Entity[]): TurnTarget {
  const { selection, more } = selectionFacts(world, selected);
  return { kind: 'entities', entities: selection, more };
}

/** The tools' facts, the tool up's first, those with none left out; each value a string or a list. */
export function toolFacts(tools: readonly ToolFacts[]): ToolContext[] {
  const ordered = [...tools.filter((t) => t.up), ...tools.filter((t) => !t.up)];
  return ordered
    .filter((t) => t.facts !== null && t.facts.length > 0)
    .map((t) => ({ tool: t.tool, facts: t.facts!.map((f) => ({ name: f.name, value: typeof f.value === 'string' ? f.value : [...f.value] })) }));
}

/** The whole of a turn's context: the host's, the tools', the selection. */
export function turnContext(host: HostFacts, tools: readonly ToolFacts[], world: World, selected: readonly Entity[]): TurnContext {
  return { ...host, tools: toolFacts(tools), ...selectionFacts(world, selected) };
}
