/**
 * This tab's id for the agent's editor tools (Docs/agent.md §8): the id its
 * hello says on the socket and its turns carry, so a call the dev server
 * relays reaches this tab's editor alone. One per live tab, kept in
 * `sessionStorage` so a reload is the same tab.
 *
 * - **A duplicated tab copies `sessionStorage`**, the id with it (Chrome's
 *   Duplicate, a `window.open` from the page): told apart two ways, and given
 *   an id of its own.
 * - **Let go on `pagehide`**: the id is marked free as the page goes
 *   (`vibebase.agent.tab.free`), and taken again as one loads. A page that
 *   finds its id not let go is a copy of a page still open, and makes a new
 *   one; a reload, a tab brought back, finds it let go and keeps it. Back
 *   from the back-forward cache (`pageshow`), it is taken again.
 * - **Claimed on a `BroadcastChannel('vibebase.agent.tab')`** as it loads: a
 *   live page that holds the id answers, and the newcomer makes a new one --
 *   the one place the mark cannot say (a page whose `pagehide` never came, a
 *   duplicate made as the first one reloaded). Two claiming at once: the
 *   lower claim keeps it. A page that heard no answer in `SETTLE_MS` holds
 *   the id, and answers for it.
 * - A new id is told (`on`): the card says hello with it.
 *
 * Its effects are handed in (`TabHost`), so node tests it with stand-ins.
 */

/** Where the id is kept: this tab's, across a reload. */
export const TAB_KEY = 'vibebase.agent.tab';
/** Set as the page goes, to the id it lets go of; cleared as one takes it. */
export const FREE_KEY = 'vibebase.agent.tab.free';
/** The channel live pages claim and answer for their ids on. */
export const TAB_CHANNEL = 'vibebase.agent.tab';
/** A claim with no answer in this long, in milliseconds, holds: the page answers for its id from then on. */
export const SETTLE_MS = 400;

/** A message on the channel: a claim, or the answer that the id is taken -- to the claim it names. */
export type TabMessage = { type: 'claim'; id: string; claim: string } | { type: 'taken'; id: string; claim: string };

/** What the claim needs of the page: its tab's storage, the channel, the page's coming and going, a clock, and a fresh id. */
export interface TabHost {
  storage: Pick<Storage, 'getItem' | 'setItem' | 'removeItem'> | null;
  channel: { postMessage(message: TabMessage): void; addEventListener(type: 'message', listener: (event: { data: unknown }) => void): void; close(): void } | null;
  /** `pagehide` and `pageshow`: the id let go, and taken again. Returns the undo. */
  page(going: () => void, back: () => void): () => void;
  later(run: () => void, ms: number): void;
  fresh(): string;
}

export interface TabClaim {
  /** The id now: this tab's alone, once claimed. */
  readonly id: string;
  /** The id was found to be another live tab's, and a new one made. Returns the undo. */
  on(listener: (id: string) => void): () => void;
  dispose(): void;
}

export function claimTab(host: TabHost): TabClaim {
  const read = (key: string): string | null => {
    try {
      return host.storage?.getItem(key) ?? null;
    } catch {
      return null;
    }
  };
  const write = (key: string, value: string | null): void => {
    try {
      if (value === null) host.storage?.removeItem(key);
      else host.storage?.setItem(key, value);
    } catch {
      // Storage refused: the id is this page's alone, which is still one per tab.
    }
  };
  const listeners = new Set<(id: string) => void>();
  let claim = host.fresh();
  let settled = false;
  // Kept and let go as the page went (a reload): this tab's still. Kept and not let go: a copy of a page still open.
  const kept = read(TAB_KEY);
  let id = kept !== null && kept !== '' && read(FREE_KEY) === kept ? kept : host.fresh();
  write(TAB_KEY, id);
  write(FREE_KEY, null);

  /** Another live page holds it: a new one, said, and claimed in its turn. */
  function renew(): void {
    id = host.fresh();
    write(TAB_KEY, id);
    for (const listener of listeners) listener(id);
    claimNow();
  }

  function claimNow(): void {
    claim = host.fresh();
    settled = false;
    const asked = claim;
    host.channel?.postMessage({ type: 'claim', id, claim });
    host.later(() => {
      if (claim === asked) settled = true;
    }, SETTLE_MS);
  }

  host.channel?.addEventListener('message', (event) => {
    const m = event.data as Partial<TabMessage> | null;
    if (typeof m !== 'object' || m === null || m.id !== id || typeof m.claim !== 'string') return;
    if (m.type === 'taken') {
      if (m.claim === claim) renew();
    } else if (m.type === 'claim' && m.claim !== claim) {
      // Held, or both claiming and this claim the lower: it is this page's -- the other is told. Else the other keeps it.
      if (settled || claim < m.claim) host.channel?.postMessage({ type: 'taken', id, claim: m.claim });
      else renew();
    }
  });
  const offPage = host.page(
    () => write(FREE_KEY, id),
    () => write(FREE_KEY, null),
  );
  claimNow();

  return {
    get id() {
      return id;
    },
    on(listener) {
      listeners.add(listener);
      return () => void listeners.delete(listener);
    },
    dispose() {
      offPage();
      listeners.clear();
      host.channel?.close();
    },
  };
}

/** The page's own `TabHost`: `sessionStorage`, the channel, `pagehide` and `pageshow`, `setTimeout`, `crypto.randomUUID`. */
export function pageTabHost(): TabHost {
  let storage: Storage | null = null;
  try {
    storage = sessionStorage;
  } catch {
    // Blocked: each page its own id.
  }
  return {
    storage,
    channel: typeof BroadcastChannel === 'function' ? (new BroadcastChannel(TAB_CHANNEL) as unknown as TabHost['channel']) : null,
    page(going, back) {
      const shown = (event: PageTransitionEvent): void => {
        if (event.persisted) back();
      };
      addEventListener('pagehide', going);
      addEventListener('pageshow', shown);
      return () => {
        removeEventListener('pagehide', going);
        removeEventListener('pageshow', shown);
      };
    },
    later: (run, ms) => void setTimeout(run, ms),
    fresh: () => (typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : `tab-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`),
  };
}
