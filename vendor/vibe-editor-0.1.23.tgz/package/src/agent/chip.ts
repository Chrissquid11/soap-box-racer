/**
 * The settings chip's words (Docs/ai-panel.md D4): one quiet line under the prompt box -- "Opus · high · Auto · bar 7"
 * -- for the conversation's model, effort, permission level and review bar, which its popover changes. Pure, for node
 * (`chip.test.ts`); the card draws it (`agent-card.ts`).
 */
import type { AgentState, PermissionLevel } from '@vibe/pipeline/agent-types';

/** The level's word on the chip: Unsafe auto (what the plan called Bypass) its own, in the danger colour. */
const LEVEL_WORD: Record<PermissionLevel, string> = { ask: 'Ask', auto: 'Auto', unsafe: 'Unsafe auto' };

export interface ChipWords {
  /** "Opus · high · Auto · bar 7". */
  readonly text: string;
  /** The level, for its colour: Unsafe auto is said in the danger colour, as its picker is. */
  readonly level: PermissionLevel;
  /** "Model Opus 4.1, effort high, …": the chip's hover, every setting whole. */
  readonly title: string;
}

/** A model's label shortened for the chip: what is in brackets dropped ("Default (recommended)" is "Default"). */
export function shortModel(label: string): string {
  const short = label.replace(/\s*\([^)]*\)\s*/g, ' ').trim();
  return short === '' ? label : short;
}

/** The chip's words for `state` (none yet: the defaults, as the pickers show them before the session is up). */
export function chipWords(state: AgentState | null): ChipWords {
  const wanted = state?.settings.model ?? 'default';
  const model = state?.models.find((m) => m.value === wanted);
  const label = model?.label ?? (wanted === 'default' ? 'Default' : wanted);
  const effort = state?.settings.effort ?? null;
  const level = state?.settings.level ?? 'auto';
  const bar = state?.review.bars.find((b) => b.value === state.settings.review) ?? null;
  const score = bar?.score ?? null;
  const parts = [shortModel(label), ...(effort ? [effort] : []), LEVEL_WORD[level], ...(score !== null ? [`bar ${score}`] : [])];
  const title = [
    `Model: ${label}`,
    `Effort: ${effort ?? 'default'}`,
    `Permissions: ${LEVEL_WORD[level]}`,
    `Review: ${score !== null ? `${bar!.label} ${score}/10` : 'none'}`,
  ].join(' · ');
  return { text: parts.join(' · '), level, title: `${title} -- click to change them` };
}
