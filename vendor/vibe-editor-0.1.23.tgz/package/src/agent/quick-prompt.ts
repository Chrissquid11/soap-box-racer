/**
 * The quick prompt (Docs/ai-panel.md §4, D6): `Mod+K` opens a one-line box where the person is working -- at the
 * selection's top in the scene, a file's row in the Assets panel, the Model tab's views, the Code card's caret, else
 * the focused card's top (the host finds where: `QuickAt`, placed by `quick.ts`' `placeQuick`) -- its target named in
 * a chip ("big crate (#38)"; its × drops it). Enter sends the words to the conversation shown in Claude's column, with
 * that conversation's settings (the card's `quick.send`), the target going with the turn as a fact
 * (`TurnContext.target`), never as words in the box; Esc closes it, as a press anywhere else does.
 *
 * - **The column is not opened**: while the turn runs a pill stands where the box was -- "Claude is on it…", "Claude
 *   needs you", "Done" (`quickStatus`) -- a click on it opens the column; done, it goes after a while. A permission or
 *   question card opens the column as it always does (the card's own rule).
 * - **Its keys are MrDebug field actions** (field `agent-quick`, `QUICK_FIELD`), registered by the host: Enter sends,
 *   Esc closes, ↑ ↓ walk the prompts sent before -- the column box's history (`PromptHistory`, the same list in
 *   `localStorage`). No key listener here.
 *
 * Its look is `agent.css`' `ed-qp-` classes, in the page while the card is.
 */
import type { ConversationInfo, TurnTarget } from '@vibe/pipeline/agent-types';
import { control, el } from '../dom.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import { keepPrompt, PromptHistory, promptsKept, storage } from './prompt-box.ts';
import { placeQuick, quickStatus, targetLabel, type QuickAt } from './quick.ts';

/** The field the box's keys are scoped to. */
export const QUICK_FIELD = 'agent-quick';
/** How long "Done" stays on the pill, in milliseconds. */
const DONE_MS = 8000;

export interface QuickPromptHost {
  /** The editor's root: the box and the pill go in it. */
  readonly root: HTMLElement;
  /** The card's way in: the turn sent to the conversation shown, a row of the list, the shown one's title. */
  readonly quick: {
    send(text: string, target: TurnTarget | null): Promise<{ conversation: string | null; ended: number }>;
    info(conversation: string | null): ConversationInfo | null;
    title(): string;
  };
  /** Told with each list the server pushes. Returns the undo. */
  onTurns(fn: (running: boolean) => void): () => void;
  /** Claude's column shown, the box there focused: the pill clicked. */
  openColumn(): void;
}

export interface QuickPrompt {
  /** The box is up. */
  readonly open: boolean;
  /** Up at `at`, empty, focused -- or, up already, closed (Mod+K again). */
  toggle(at: QuickAt): void;
  /** Up at `at` with `text` in it for the person to send, change or clear -- never sent (Ask Claude, Fix, Explain). */
  ask(at: QuickAt, text?: string): void;
  close(): void;
  /** The box's own keys, for the host to register as MrDebug field actions. */
  readonly keys: {
    send(): void;
    canRecall(step: -1 | 1): boolean;
    recall(step: -1 | 1): void;
  };
  dispose(): void;
}

export function createQuickPrompt(host: QuickPromptHost): QuickPrompt {
  const history = new PromptHistory();
  let target: TurnTarget | null = null;
  let sending = false;

  const box = el('div', 'ed-card ed-qp');
  box.hidden = true;
  const head = el('div', 'ed-qp-head');
  const chip = el('span', 'ed-qp-target');
  const chipText = el('span', 'ed-qp-target-text');
  const drop = control('ui', 'ed-qp-target-x', '×');
  drop.title = 'Not about this: the prompt goes with no target';
  chip.append(chipText, drop);
  const to = el('span', 'ed-qp-to');
  head.append(chip, to);
  const input = el('input', 'ed-input ed-qp-input');
  input.type = 'text';
  input.dataset.keysField = QUICK_FIELD;
  input.autocomplete = 'off';
  input.spellcheck = false;
  const said = el('div', 'ed-qp-said');
  said.hidden = true;
  box.append(head, input, said);

  // The pill: what the turn sent is doing; a click opens the column.
  const pill = control(NOT_FOR_CLAUDE.claudeControl, 'ed-card ed-qp-pill');
  pill.hidden = true;
  const pillDot = el('span', 'ed-qp-dot');
  const pillText = el('span', 'ed-qp-pill-text');
  pill.append(pillDot, pillText);
  host.root.append(box, pill);

  /** The turn the pill follows: its conversation and its last result as it went. */
  let following: { conversation: string | null; ended: number } | null = null;
  let doneTimer: ReturnType<typeof setTimeout> | undefined;

  function drawTarget(): void {
    chip.hidden = target === null;
    chipText.textContent = target ? targetLabel(target) : '';
    chip.title = target ? `About ${targetLabel(target)}: it goes with the turn, so "this" means it` : '';
    input.placeholder = target ? `Ask Claude about ${targetLabel(target)} -- Enter sends, Esc closes` : 'Ask Claude -- Enter sends, Esc closes';
  }
  drop.addEventListener('click', () => {
    target = null;
    drawTarget();
    input.focus();
  });

  /** What had the focus as the box opened -- Monaco's caret, the scene's card: given it back as the box closes. */
  let returnTo: HTMLElement | null = null;
  /** A press anywhere but the box closes it -- capturing, so it is heard before what the press is for, which takes the focus. */
  const outside = (event: PointerEvent): void => {
    if (event.target instanceof Node && box.contains(event.target)) return;
    returnTo = null;
    close();
  };

  function show(at: QuickAt, text = ''): void {
    const had = document.activeElement;
    returnTo = had instanceof HTMLElement && had !== document.body && !box.contains(had) ? had : null;
    // At the end of the list as kept now: a walk left half-way last time is over.
    history.remember('');
    history.sync(promptsKept(storage('localStorage')));
    target = at.target;
    input.value = text;
    said.hidden = true;
    drawTarget();
    to.textContent = `to ${host.quick.title()}`;
    box.hidden = false;
    const place = placeQuick(at, box.offsetHeight || 84, { width: innerWidth, height: innerHeight });
    box.style.left = `${place.left}px`;
    box.style.top = `${place.top}px`;
    box.style.width = `${place.width}px`;
    document.addEventListener('pointerdown', outside, true);
    input.focus();
  }

  function close(): void {
    if (box.hidden) return;
    box.hidden = true;
    document.removeEventListener('pointerdown', outside, true);
    const back = returnTo;
    returnTo = null;
    if (back?.isConnected) back.focus();
    else if (box.contains(document.activeElement)) (document.activeElement as HTMLElement).blur();
  }

  function say(text: string): void {
    said.textContent = text;
    said.hidden = false;
  }

  async function send(): Promise<void> {
    if (sending) return;
    const text = input.value;
    if (text.trim() === '') return say('Say what to do');
    sending = true;
    try {
      following = await host.quick.send(text, target);
    } catch (err) {
      sending = false;
      return say(err instanceof Error ? err.message : String(err));
    }
    sending = false;
    keepPrompt(storage('localStorage'), history, text);
    // The pill where the box was.
    pill.style.left = box.style.left;
    pill.style.top = box.style.top;
    close();
    drawPill();
  }

  function drawPill(): void {
    clearTimeout(doneTimer);
    const status = following ? quickStatus(host.quick.info(following.conversation), following.ended) : null;
    pill.hidden = status === null;
    pill.dataset.state = status ?? '';
    pillText.textContent = status === 'waiting' ? 'Claude needs you -- open' : status === 'done' ? 'Done -- open the column' : 'Claude is on it…';
    pill.title = 'Open Claude\'s column: the turn\'s transcript';
    if (status === 'done') doneTimer = setTimeout(() => {
      pill.hidden = true;
      following = null;
    }, DONE_MS);
  }
  const offTurns = host.onTurns(() => {
    if (following) drawPill();
  });
  pill.addEventListener('click', () => {
    pill.hidden = true;
    following = null;
    clearTimeout(doneTimer);
    host.openColumn();
  });

  return {
    get open() {
      return !box.hidden;
    },
    toggle(at) {
      if (!box.hidden) close();
      else show(at);
    },
    ask(at, text) {
      if (!box.hidden) close();
      show(at, text);
      input.setSelectionRange(input.value.length, input.value.length);
    },
    close,
    keys: {
      send: () => void send(),
      canRecall: (step) => history.can(step),
      recall(step) {
        const text = history.step(step, input.value);
        if (text !== null) input.value = text;
      },
    },
    dispose() {
      clearTimeout(doneTimer);
      offTurns();
      close();
      box.remove();
      pill.remove();
    },
  };
}
