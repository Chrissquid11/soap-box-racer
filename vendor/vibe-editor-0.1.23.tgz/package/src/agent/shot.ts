/**
 * Images for a turn (Docs/agent.md §4, "Images and the screenshot"): the
 * scene's screenshot, and images dropped or pasted on the box, each made fit
 * for the API.
 *
 * - **The size rule** (`fitSize`, pure): at most 1568 px on the long edge --
 *   past it the API scales an image down anyway, and pays for the pixels
 *   first -- the aspect kept, whole pixels.
 * - **An image** (`imageFor`): kept as it is where it is a PNG, JPEG, GIF or
 *   WebP within that size and the API's 5 MB; else drawn again at its fitted
 *   size and re-encoded as WebP.
 * - **The screenshot** (`shoot`): the editor's frame drawn (`draw`, the
 *   host's: the grid, the selection's outline and the gizmo, which show which
 *   one "this" is) and copied off the canvas in the same task -- the canvas is
 *   not preserved between frames (`still.ts`) -- at its fitted size. The
 *   editor's cards are DOM, and not in it.
 */
import type { TurnImage } from '@vibe/pipeline/agent-types';

/** The long edge at most, in pixels. */
export const LONG_EDGE = 1568;
/** An image's bytes at most, decoded: the API's limit. */
export const IMAGE_BYTES = 5 * 1024 * 1024;
/** Images in a turn, at most. */
export const IMAGES_MAX = 4;
/** The quality an image re-encoded as WebP is written at. */
const QUALITY = 0.9;

const MEDIA: readonly TurnImage['media'][] = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];

/** `width` × `height` fitted to `max` on the long edge, the aspect kept, never upscaled, never below a pixel. */
export function fitSize(width: number, height: number, max = LONG_EDGE): { width: number; height: number } {
  const w = Math.max(1, Math.round(width));
  const h = Math.max(1, Math.round(height));
  const scale = Math.min(1, max / Math.max(w, h));
  return { width: Math.max(1, Math.round(w * scale)), height: Math.max(1, Math.round(h * scale)) };
}

/** Does an image of this type, size and byte count go as it is? */
export function keepsAsIs(media: string, width: number, height: number, bytes: number): media is TurnImage['media'] {
  return (MEDIA as readonly string[]).includes(media) && Math.max(width, height) <= LONG_EDGE && bytes <= IMAGE_BYTES;
}

/** A pasted file's name, which usually has none: `pasted.png`. */
export function imageName(name: string, media: string): string {
  if (name !== '') return name;
  const ext = media.split('/')[1]?.replace(/[^a-z0-9]/gi, '') || 'png';
  return `pasted.${ext}`;
}

/** A blob's bytes as base64, with no `data:` prefix. */
async function base64Of(blob: Blob): Promise<string> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = '';
  // In chunks: a spread of megabytes would pass the argument limit.
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}

/** A canvas as WebP, or why not. */
function webpOf(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('the image could not be encoded'))), 'image/webp', QUALITY));
}

/** `source` drawn onto a canvas of its fitted size. */
function fitted(source: CanvasImageSource, width: number, height: number): HTMLCanvasElement {
  const size = fitSize(width, height);
  const canvas = document.createElement('canvas');
  canvas.width = size.width;
  canvas.height = size.height;
  const g = canvas.getContext('2d');
  if (!g) throw new Error('no 2D canvas to draw the image on');
  g.drawImage(source, 0, 0, size.width, size.height);
  return canvas;
}

/** A file dropped or pasted, made fit for a turn: as it is, or drawn again smaller as WebP. */
export async function imageFor(file: Blob, name: string): Promise<TurnImage> {
  const bitmap = await createImageBitmap(file).catch(() => {
    throw new Error(`${name} is not an image this browser can read`);
  });
  try {
    if (keepsAsIs(file.type, bitmap.width, bitmap.height, file.size)) return { name, media: file.type, data: await base64Of(file) };
    const blob = await webpOf(fitted(bitmap, bitmap.width, bitmap.height));
    if (blob.size > IMAGE_BYTES) throw new Error(`${name} is over 5 MB even made smaller`);
    return { name: name.replace(/\.[a-z0-9]+$/i, '') + '.webp', media: 'image/webp', data: await base64Of(blob) };
  } finally {
    bitmap.close();
  }
}

/**
 * The editor's view as an image: `draw` -- the frame drawn, overlays and all --
 * and the canvas copied in the same task, before the browser can clear it.
 */
export async function shoot(draw: () => void, canvas: HTMLCanvasElement): Promise<TurnImage> {
  draw();
  const copy = fitted(canvas, canvas.width, canvas.height);
  const blob = await webpOf(copy);
  return { name: 'view.webp', media: 'image/webp', data: await base64Of(blob) };
}

/** An image's bytes, decoded, from its base64: what the API counts. */
export const bytesOf = (image: TurnImage): number => Math.floor((image.data.length * 3) / 4) - (image.data.endsWith('==') ? 2 : image.data.endsWith('=') ? 1 : 0);
