/**
 * The quick prompt's pure parts -- and Ask Claude's, Fix with Claude's and Explain's, which open it (A3) -- (Docs/ai-panel.md §4, D6): where its box goes (`placeQuick`), what its target chip
 * says (`targetLabel`), and what its pill says while the turn it sent runs (`quickStatus`). The box itself is
 * `quick-prompt.ts`; node tests these (`quick.test.ts`).
 */
import type { ConversationInfo, TurnTarget } from '@vibe/pipeline/agent-types';
import type { Box } from '../room.ts';

/** Where a quick prompt opens and what it is about: a point on the page, the room it stays inside, its target. */
export interface QuickAt {
  /** What it is about; null for nothing in particular (the focused card's top). */
  readonly target: TurnTarget | null;
  /** The point it is about, on the page: the selection's top, a file's row, the caret. */
  readonly anchor: { readonly x: number; readonly y: number };
  /** What it stays inside: the scene's room clear of the cards and Claude's column, a card's box. */
  readonly room: Box;
}

/** The box's width at most and at least, its gap from the point and from the room's edge, in CSS pixels. */
export const QUICK_WIDTH = 440;
export const QUICK_MIN = 280;
const GAP = 14;
const EDGE = 8;

/**
 * The box's top-left for a box `height` tall: centred over the point -- so it never covers what it is about -- under it
 * where there is no room above, held
 * inside the room `EDGE` from its sides -- and, on a room narrower than the least box, inside the window instead.
 * Its width: the room's less its edges, between `QUICK_MIN` and `QUICK_WIDTH`.
 */
export function placeQuick(at: QuickAt, height: number, window: { width: number; height: number }): { left: number; top: number; width: number } {
  const whole: Box = { left: 0, top: 0, right: window.width, bottom: window.height };
  const room = at.room.right - at.room.left >= QUICK_MIN + 2 * EDGE && at.room.bottom - at.room.top >= height + 2 * EDGE ? at.room : whole;
  const width = Math.max(Math.min(QUICK_MIN, window.width - 2 * EDGE), Math.min(QUICK_WIDTH, room.right - room.left - 2 * EDGE));
  const clamp = (v: number, lo: number, hi: number): number => Math.max(lo, Math.min(v, Math.max(lo, hi)));
  const left = clamp(at.anchor.x - width / 2, room.left + EDGE, room.right - EDGE - width);
  const above = at.anchor.y - GAP - height;
  const top = above >= room.top + EDGE ? above : at.anchor.y + GAP;
  return { left: Math.round(left), top: Math.round(clamp(top, room.top + EDGE, room.bottom - EDGE - height)), width: Math.round(width) };
}

/** A path's last part: `crates/big.prefab` of `src/assets/prefabs/crates/big.prefab`, `hop.ts`. */
const last = (path: string, parts = 1): string => path.split('/').slice(-parts).join('/');

/** The target chip's words: "big crate (#38)", "3 entities", "crates/big.prefab", "lid · crate.lua", "hop.ts:42". */
export function targetLabel(target: TurnTarget): string {
  switch (target.kind) {
    case 'entities': {
      const count = target.entities.length + target.more;
      if (count === 1) {
        const e = target.entities[0]!;
        return `${e.name || (e.prefab ? last(e.prefab) : 'entity')} (#${e.id})`;
      }
      return `${count} entities`;
    }
    case 'asset':
      return last(target.path, 2);
    case 'parts':
      return `${target.parts.length === 1 ? target.parts[0]! : `${target.parts.length} parts`} · ${last(target.script)}`;
    case 'file':
      return `${last(target.path)}${target.line !== null ? `:${target.line}` : ''}`;
    case 'problem':
      return `${target.code ? `${target.code} ` : ''}${last(target.file)}${target.line > 0 ? `:${target.line}` : ''}`;
    case 'log': {
      const text = target.text.replace(/\s+/g, ' ').trim();
      return `log: ${text.length > 40 ? `${text.slice(0, 39)}…` : text}`;
    }
  }
}

/** The most a problem's message or a console line may be as a target (the server's cap). */
export const TEXT_MAX = 4000;

/** `text` within `max`: whole, or its head and tail with what was cut between, marked -- the server refuses longer. */
export function cutText(text: string, max = TEXT_MAX): string {
  if (text.length <= max) return text;
  const mark = (n: number): string => `\n… [${n} characters cut] …\n`;
  const room = max - mark(text.length).length;
  const head = Math.ceil(room * 0.6);
  const tail = room - head;
  return `${text.slice(0, head)}${mark(text.length - room)}${text.slice(text.length - tail)}`;
}

/** A target whose output (a problem's message, a console line) is held within the server's cap (`cutText`). */
export function capTarget(target: TurnTarget): TurnTarget {
  if (target.kind === 'problem') return { ...target, message: cutText(target.message) };
  if (target.kind === 'log') return { ...target, text: cutText(target.text) };
  return target;
}

/** What the pill says of the turn a quick prompt sent: running, needs you (a card waits), done -- or nothing to say. */
export type QuickStatus = 'running' | 'waiting' | 'done' | null;

/**
 * The pill's state from the conversation's row in the list (`hub.ts`): `ended` its last result's `seq` when the turn
 * went. A card waiting is "needs you" first; running, "running"; a result after `ended`, "done". Its row gone (the
 * conversation closed), nothing.
 */
export function quickStatus(info: ConversationInfo | null, ended: number): QuickStatus {
  if (!info) return null;
  if (info.waiting) return 'waiting';
  if (info.running) return 'running';
  return info.ended > ended ? 'done' : 'running';
}
