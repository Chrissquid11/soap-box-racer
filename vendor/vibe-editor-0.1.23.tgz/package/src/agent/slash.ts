/**
 * Slash commands in the prompt box (Docs/agent.md §4, "Slash commands"): pure, so node tests it.
 *
 * - **The list** is the card's own first -- `/usage`, `/btw`, `/clear`, `/agents`, which the card does itself and never
 *   sends -- then the CLI's (`AgentState.commands`: its `/compact`, `/cost`, the project's commands and the skills),
 *   which go to Claude Code as the prompt they are, as typed. One of the CLI's named as the card's own (by name or
 *   alias) is the card's.
 * - **It opens** while the box holds a `/` and a name being typed -- the caret in the first word, nothing before the
 *   slash (`slashAt`) -- filtered as typed (`matchCommands`: a name starting so first, then an alias, then a name
 *   holding it), each with its description.
 * - **Tab completes** to `/name ` (`completion`); **Enter** completes and, for one taking nothing (`runsAtOnce`), sends
 *   it at once, as Claude Code does.
 * - **Sent**, a box reading `/name rest` is parsed (`parseSlash`): the card's own is done here, the rest is the prompt.
 */
import type { CommandRow } from '@vibe/pipeline/agent-types';

/** A command the list shows. `card`: the card's own, done here and never sent. */
export interface SlashCommand {
  name: string;
  description: string;
  /** Its argument, as a hint ("<question>"); '' for none. */
  hint: string;
  aliases: string[];
  card: boolean;
}

/** The card's own: done by the card, never sent to Claude Code. */
export const CARD_COMMANDS: readonly SlashCommand[] = [
  { name: 'usage', description: "The plan's limits, this conversation's cost and tokens, the context window -- nothing sent", hint: '', aliases: [], card: true },
  { name: 'btw', description: 'A side question about the conversation, answered beside it with no tools -- a turn running goes on', hint: '<question>', aliases: [], card: true },
  { name: 'clear', description: 'Forget this conversation and start a new one in its tab (asked first)', hint: '', aliases: ['reset', 'new'], card: true },
  { name: 'agents', description: 'Show or hide the subagents and background tasks of this turn', hint: '', aliases: [], card: true },
];

/** The list: the card's own, then the CLI's -- one the card has by name or alias left out. */
export function commandsOf(cli: readonly CommandRow[] | undefined): SlashCommand[] {
  const taken = new Set(CARD_COMMANDS.flatMap((c) => [c.name, ...c.aliases]));
  const theirs = (cli ?? []).filter((c) => !taken.has(c.name)).map((c) => ({ name: c.name, description: c.description, hint: c.hint, aliases: c.aliases ?? [], card: false }));
  return [...CARD_COMMANDS, ...theirs];
}

/**
 * The name being typed, while the list should be open: the box starts with `/`, and the caret is in its first word
 * (no space or line between the slash and it). Lowercased. Null: no list.
 */
export function slashAt(value: string, caret: number): string | null {
  if (!value.startsWith('/')) return null;
  const head = value.slice(0, caret);
  if (caret < 1 || /\s/.test(head)) return null;
  // The rest of the first word, after the caret, is part of the name too: the list is for the word as a whole.
  const word = /^\/(\S*)/.exec(value)![1]!;
  return word.toLowerCase();
}

/** The commands matching `query`: a name starting so, then an alias starting so, then a name holding it -- each in list order. */
export function matchCommands(list: readonly SlashCommand[], query: string): SlashCommand[] {
  const q = query.toLowerCase();
  const starts = list.filter((c) => c.name.toLowerCase().startsWith(q));
  const alias = list.filter((c) => !starts.includes(c) && c.aliases.some((a) => a.toLowerCase().startsWith(q)));
  const holds = q === '' ? [] : list.filter((c) => !starts.includes(c) && !alias.includes(c) && c.name.toLowerCase().includes(q));
  return [...starts, ...alias, ...holds];
}

/** What Tab puts in the box: the command and a space, the words after it (if any) kept. */
export function completion(command: SlashCommand, value: string): string {
  const rest = value.replace(/^\/\S*/, '').replace(/^\s+/, '');
  return `/${command.name} ${rest}`;
}

/** Enter sends it at once, completed: it takes nothing. */
export const runsAtOnce = (command: SlashCommand): boolean => command.hint.trim() === '';

/** A box reading `/name rest`: the name (lowercased) and what follows, trimmed. Null: no command. */
export function parseSlash(text: string): { name: string; rest: string } | null {
  const m = /^\/([A-Za-z0-9][\w:.-]*)(?:\s+([\s\S]*))?$/.exec(text.trim());
  return m ? { name: m[1]!.toLowerCase(), rest: (m[2] ?? '').trim() } : null;
}

/** The card's own command a box's words name -- by name or alias -- or null: the words go to Claude Code. */
export function cardCommand(text: string): { command: SlashCommand; rest: string } | null {
  const parsed = parseSlash(text);
  if (!parsed) return null;
  const command = CARD_COMMANDS.find((c) => c.name === parsed.name || c.aliases.includes(parsed.name));
  return command ? { command, rest: parsed.rest } : null;
}

/**
 * Where the list's selection goes on ↑ (-1) or ↓ (1): round, from `at` among `count`; nothing selected yet, ↓ is the
 * first and ↑ the last.
 */
export function stepSelection(at: number, count: number, by: 1 | -1): number {
  if (count === 0) return -1;
  if (at < 0) return by > 0 ? 0 : count - 1;
  return (at + by + count) % count;
}

/** What the card's Send/Stop button is for (`goMode`): Send, Stop, or one of the card's own commands -- its command. */
export type GoMode = { mode: 'send' | 'stop'; command: null } | { mode: 'own'; command: SlashCommand };

/**
 * What the card's Send/Stop button is for, from the turn running and the box's words: while a turn runs it is Stop,
 * but for a box reading one of the card's own commands done beside the turn (`/btw why?`, `/usage`, `/agents`) --
 * never sent to Claude Code -- which it runs as Send would. `/clear` (and its aliases) is no such: it interrupts the
 * turn, so the button stays Stop for it (Enter on it still asks first).
 */
export function goMode(running: boolean, value: string): GoMode {
  if (!running) return { mode: 'send', command: null };
  const own = cardCommand(value);
  return own && own.command.name !== 'clear' ? { mode: 'own', command: own.command } : { mode: 'stop', command: null };
}

/** A click this soon after the button changed under the pointer was aimed at what it was, in milliseconds. */
export const GO_GUARD_MS = 800;

/**
 * What a click on the button does, from its mode and how long ago (ms) it last turned from Stop into Send at a turn's
 * end (`sinceTurned`) and from Send into Stop as the person's words stopped being a command (`sinceWordsStopped`):
 * `stop` the turn, `send` (the box's words, or the card's own command beside the turn), or nothing -- `turned`, the
 * click was aimed at the Stop that was; `words`, at the Send that was.
 */
export function goClick(mode: GoMode['mode'], sinceTurned: number, sinceWordsStopped: number): 'stop' | 'send' | 'turned' | 'words' {
  if (mode === 'stop') return sinceWordsStopped < GO_GUARD_MS ? 'words' : 'stop';
  if (mode === 'send' && sinceTurned < GO_GUARD_MS) return 'turned';
  return 'send';
}
