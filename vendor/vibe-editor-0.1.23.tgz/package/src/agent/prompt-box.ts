/**
 * The prompt box (Docs/agent.md §4): a textarea, the images on it, the
 * prompts sent before, and the draft.
 *
 * - **Its keys are MrDebug's, scoped to it** (`data-keys-field="agent"`, the
 *   field scope of `src/debug/actions.ts`), registered by the host
 *   (`editor.ts`) under "Prompt" on the keys card: Enter and Mod+Enter send,
 *   ↑ and ↓ walk the history when the caret is on the first or last line with
 *   nothing selected (`caretOnEdge`, Vibe3D's). Shift+Enter is nobody's: the
 *   textarea's own newline. No key listener here, and nothing called
 *   `prompt(` -- the routes check's dialog rule (`checks/routes.ts`) would take it for
 *   `window.prompt`.
 * - **Esc lets go of the box**: the browser's close request (`fields.ts`'
 *   `onCloseRequest`), made on each focus and undone on blur -- one-shot, so
 *   one per focus. The next Esc is the editor's.
 * - **The history** is the last 100 prompts in `localStorage`
 *   (`vibebase.agent.prompts@<id>`, the project's: `projectKey`), one entry for the same prompt sent twice
 *   running; the draft kept while stepping, back at the end of the list
 *   (`PromptHistory`, pure).
 * - **The draft** -- the words, and whether Attach view is ticked -- is this
 *   tab's and the project's (`sessionStorage`, `vibebase.agent.draft@<id>`), written as it is typed:
 *   a reload, the agent's code arriving, leaves it as it was; a new tab starts
 *   empty, Attach view off.
 * - **Images** dropped or pasted on the box (`drop` and `paste`, no key), at
 *   most four, each made fit (`shot.ts`); a chip each, its × taking it off.
 *
 * The history ring and the caret rule are pure; the box itself touches the DOM
 * only when made.
 */
import type { TurnImage } from '@vibe/pipeline/agent-types';
import { projectKey } from '@vibe/engine/project-key';
import { control, el } from '../dom.ts';
import { onCloseRequest } from '../fields.ts';
import { IMAGES_MAX, imageFor, imageName } from './shot.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';

/** Where the prompts sent are kept -- at the project's id (`projectKey`): they name its files -- and how many. */
export const HISTORY_KEY = 'vibebase.agent.prompts';
export const HISTORY_MAX = 100;
/** Where this tab's draft is kept, at the project's id: the words, and Attach view. */
export const DRAFT_KEY = 'vibebase.agent.draft';
/** The field the box's keys are scoped to. */
export const FIELD = 'agent';
/** The box's rows: two to start, growing to six as it is typed in. */
const ROWS = 2;
const ROWS_MAX = 6;

/** The prompts as kept, read: strings only, the last `HISTORY_MAX`; anything odd, none. */
export function readHistory(text: string | null): string[] {
  try {
    const data: unknown = JSON.parse(text ?? '[]');
    return Array.isArray(data) ? data.filter((s): s is string => typeof s === 'string').slice(-HISTORY_MAX) : [];
  } catch {
    return [];
  }
}

/**
 * The prompts sent, oldest first, and where the box is among them: at the end
 * (`length`) it shows the draft -- what was being typed before stepping back,
 * kept so stepping forward again brings it back rather than an empty box.
 */
export class PromptHistory {
  readonly list: string[];
  private at: number;
  private draft = '';

  constructor(kept: readonly string[] = []) {
    this.list = kept.slice(-HISTORY_MAX);
    this.at = this.list.length;
  }

  /** Where the box is: `list.length` for the draft. */
  get cursor(): number {
    return this.at;
  }

  /** Is there a prompt `step` away: -1 an earlier one, 1 a later one or the draft. */
  can(step: -1 | 1): boolean {
    const to = this.at + step;
    return to >= 0 && to <= this.list.length;
  }

  /** One step back or on: the text to show, the draft kept as the box leaves it; null where there is none. */
  step(step: -1 | 1, now: string): string | null {
    if (!this.can(step)) return null;
    if (this.at === this.list.length) this.draft = now;
    this.at += step;
    return this.at === this.list.length ? this.draft : this.list[this.at]!;
  }

  /**
   * The list as kept now -- another box (the quick prompt, the column's) may have added to it -- taken while this one is
   * at its end, not walking: a walk under way keeps the list it began on.
   */
  sync(kept: readonly string[]): void {
    if (this.at !== this.list.length) return;
    this.list.splice(0, this.list.length, ...kept.slice(-HISTORY_MAX));
    this.at = this.list.length;
  }

  /** A prompt sent: kept last (once, if it was the last already), the oldest going past `HISTORY_MAX`; the box at the end again, the draft gone. */
  remember(text: string): void {
    if (text.trim() !== '' && this.list[this.list.length - 1] !== text) {
      this.list.push(text);
      if (this.list.length > HISTORY_MAX) this.list.splice(0, this.list.length - HISTORY_MAX);
    }
    this.at = this.list.length;
    this.draft = '';
  }
}

/** Where the prompts are kept: `localStorage`, or a stand-in in a test. */
export interface PromptStore {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

/** The prompts every box has sent, as kept now (`HISTORY_KEY`, the project's). */
export function promptsKept(store: PromptStore | null): string[] {
  try {
    return readHistory(store?.getItem(projectKey(HISTORY_KEY)) ?? null);
  } catch {
    return [];
  }
}

/**
 * `history`'s prompt sent: added to the list as kept now -- not to the box's own copy, which another box may have
 * added to since (the column's and the quick prompt's share one list) -- written back, and taken by `history`.
 */
export function keepPrompt(store: PromptStore | null, history: PromptHistory, text: string): void {
  history.sync(promptsKept(store));
  history.remember(text);
  try {
    store?.setItem(projectKey(HISTORY_KEY), JSON.stringify(history.list));
  } catch {
    // Full or blocked: not remembered, then.
  }
}

/** Is the caret, nothing selected, on the text's first line (`first`) or its last? Where ↑ and ↓ walk the history rather than the lines. */
export function caretOnEdge(value: string, start: number, end: number, edge: 'first' | 'last'): boolean {
  if (start !== end) return false;
  return edge === 'first' ? !value.slice(0, start).includes('\n') : !value.slice(end).includes('\n');
}

/** This tab's draft as kept, read. */
export function readDraft(text: string | null): { text: string; attachView: boolean } {
  try {
    const data = JSON.parse(text ?? 'null') as { text?: unknown; attachView?: unknown } | null;
    return { text: typeof data?.text === 'string' ? data.text : '', attachView: data?.attachView === true };
  } catch {
    return { text: '', attachView: false };
  }
}

export interface PromptBoxOptions {
  /** Something to say about the box for a moment: an image refused, too many. */
  say(text: string): void;
  /** The box changed size: its card measures itself again. */
  resized?(): void;
  /** Its words changed, or it took or lost the focus: the slash list read again (`slash.ts`). */
  typed?(): void;
}

export interface PromptBox {
  readonly root: HTMLElement;
  readonly textarea: HTMLTextAreaElement;
  /** The words in the box. */
  value: string;
  /** Where the caret is (`selectionStart`). */
  readonly caret: number;
  /** Has it the focus. */
  readonly focused: boolean;
  /** Attach view: a screenshot with each turn, this tab only. */
  attachView: boolean;
  readonly images: readonly TurnImage[];
  /** The images taken off the box: they go with a turn. */
  takeImages(): TurnImage[];
  /** Images put back: a turn refused keeps what it had. */
  putImages(images: readonly TurnImage[]): void;
  /** May ↑ (-1) or ↓ (1) walk the history now: the caret on the edge it would leave by, a prompt that way. */
  canRecall(step: -1 | 1): boolean;
  recall(step: -1 | 1): void;
  /** A prompt sent: kept in the history, the box emptied. */
  sent(text: string): void;
  focus(): void;
  /** The draft into this tab's storage now: before a reload. */
  keep(): void;
  dispose(): void;
}

/** The page's storage of a kind, or null where it is blocked (a test, a private window). */
export const storage = (kind: 'localStorage' | 'sessionStorage'): Storage | null => {
  try {
    return globalThis[kind] ?? null;
  } catch {
    return null;
  }
};

export function createPromptBox(options: PromptBoxOptions): PromptBox {
  const history = new PromptHistory(promptsKept(storage('localStorage')));
  const draft = readDraft(storage('sessionStorage')?.getItem(projectKey(DRAFT_KEY)) ?? null);
  let attachView = draft.attachView;
  const images: TurnImage[] = [];

  const root = el('div', 'ed-ag-box');
  const chips = el('div', 'ed-ag-chips');
  chips.hidden = true;
  const textarea = el('textarea', 'ed-input ed-ag-input');
  textarea.dataset.keysField = FIELD;
  textarea.rows = ROWS;
  textarea.spellcheck = true;
  textarea.placeholder = 'Ask Claude Code to change the game -- / for commands, Enter sends, Shift+Enter a new line, ↑ an earlier one';
  textarea.value = draft.text;
  root.append(chips, textarea);

  const keep = (): void => {
    try {
      storage('sessionStorage')?.setItem(projectKey(DRAFT_KEY), JSON.stringify({ text: textarea.value, attachView }));
    } catch {
      // Full or blocked: this reload forgets it.
    }
  };

  /** Two rows to start, growing with what is typed to six, then scrolling (the box is `border-box`). */
  const grow = (): void => {
    const style = getComputedStyle(textarea);
    const line = parseFloat(style.lineHeight) || 18;
    const pad = parseFloat(style.paddingTop) + parseFloat(style.paddingBottom);
    const border = parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);
    textarea.style.height = 'auto';
    const fits = textarea.scrollHeight + border;
    textarea.style.height = `${Math.min(line * ROWS_MAX + pad + border, Math.max(line * ROWS + pad + border, fits))}px`;
    options.resized?.();
  };
  textarea.addEventListener('input', () => {
    grow();
    keep();
    options.typed?.();
  });

  // Esc lets go of the box: the browser's close request, one per focus.
  let unwatch: (() => void) | null = null;
  textarea.addEventListener('focus', () => {
    options.typed?.();
    unwatch?.();
    unwatch = onCloseRequest(() => {
      unwatch = null;
      textarea.blur();
    });
  });
  textarea.addEventListener('blur', () => {
    unwatch?.();
    unwatch = null;
    options.typed?.();
  });

  function drawChips(): void {
    chips.replaceChildren();
    chips.hidden = images.length === 0;
    images.forEach((image, n) => {
      const chip = el('span', 'ed-ag-chip-image');
      const thumb = el('img');
      thumb.src = `data:${image.media};base64,${image.data}`;
      thumb.alt = '';
      const off = control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-chip-off', '×');
      off.title = `Take ${image.name} off`;
      off.addEventListener('click', () => {
        images.splice(n, 1);
        drawChips();
      });
      chip.title = image.name;
      chip.append(thumb, el('span', undefined, image.name), off);
      chips.append(chip);
    });
    options.resized?.();
  }

  /** The image files a drop or a paste carried, made fit and put on the box, four at most. */
  async function absorb(files: readonly File[]): Promise<void> {
    for (const file of files) {
      if (!file.type.startsWith('image/')) {
        options.say(`${file.name || 'That'} is not an image: drop or paste images on the box`);
        continue;
      }
      if (images.length >= IMAGES_MAX) {
        options.say(`At most ${IMAGES_MAX} images a turn`);
        break;
      }
      try {
        images.push(await imageFor(file, imageName(file.name, file.type)));
      } catch (err) {
        options.say(err instanceof Error ? err.message : String(err));
      }
      drawChips();
    }
  }

  const imageFiles = (transfer: DataTransfer | null): File[] => [...(transfer?.files ?? [])];
  const carriesFiles = (event: DragEvent): boolean => [...(event.dataTransfer?.types ?? [])].includes('Files');
  root.addEventListener('dragover', (event) => {
    if (!carriesFiles(event)) return;
    // After the Assets tab's guard on the window, which refuses a drop on no folder of its own: this box takes it.
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
    root.classList.add('ed-ag-dropping');
  });
  root.addEventListener('dragleave', (event) => {
    if (!root.contains(event.relatedTarget as Node | null)) root.classList.remove('ed-ag-dropping');
  });
  root.addEventListener('drop', (event) => {
    root.classList.remove('ed-ag-dropping');
    if (!carriesFiles(event)) return;
    event.preventDefault();
    void absorb(imageFiles(event.dataTransfer));
  });
  textarea.addEventListener('paste', (event) => {
    const files = imageFiles(event.clipboardData);
    // Plain text is the textarea's to paste. (The Assets tab's paste, an import, leaves one typed into a field alone.)
    if (files.length === 0) return;
    event.preventDefault();
    void absorb(files);
  });

  // As it was left: grown to its draft once it is in the page.
  requestAnimationFrame(grow);

  return {
    root,
    textarea,
    get value() {
      return textarea.value;
    },
    set value(text) {
      textarea.value = text;
      grow();
      keep();
      options.typed?.();
    },
    get caret() {
      return textarea.selectionStart;
    },
    get focused() {
      return document.activeElement === textarea;
    },
    get attachView() {
      return attachView;
    },
    set attachView(on) {
      attachView = on;
      keep();
    },
    get images() {
      return images;
    },
    takeImages() {
      const taken = images.splice(0, images.length);
      drawChips();
      return taken;
    },
    putImages(back) {
      images.unshift(...back.slice(0, IMAGES_MAX - images.length));
      drawChips();
    },
    canRecall(step) {
      // What the quick prompt sent meanwhile is in the walk too.
      history.sync(promptsKept(storage('localStorage')));
      return history.can(step) && caretOnEdge(textarea.value, textarea.selectionStart, textarea.selectionEnd, step < 0 ? 'first' : 'last');
    },
    recall(step) {
      const text = history.step(step, textarea.value);
      if (text === null) return;
      textarea.value = text;
      const end = text.length;
      textarea.setSelectionRange(end, end);
      grow();
      keep();
    },
    sent(text) {
      keepPrompt(storage('localStorage'), history, text);
      textarea.value = '';
      grow();
      keep();
    },
    focus() {
      textarea.focus();
      const end = textarea.value.length;
      textarea.setSelectionRange(end, end);
    },
    keep,
    dispose() {
      unwatch?.();
      root.remove();
    },
  };
}
