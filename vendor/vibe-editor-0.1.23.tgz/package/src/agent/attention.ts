/**
 * A turn's end noticed (Docs/ai-panel.md §8): what a conversation's tab, the top bar's AI button and the page's title say
 * of a turn ended, failed or waiting on the person while nobody looks at that conversation -- and whether the column's
 * terminal, its CLI gone with the dev server before, is opened again by itself (Docs/terminal.md D12).
 *
 * - **Looking** at a conversation is its tab shown, in the column shown, in the window that has the focus (`lookingAt`).
 *   While looked at, what it did is seen (`seenOf`): its marks go.
 * - **A mark** (`markOf`): `waiting` -- a permission or question card, or the terminal's CLI asking; `failed` -- the last
 *   turn ended in an error; `done` -- a turn ended since it was last seen. A turn running is no mark: the tab's pulse and
 *   the AI button's turning sparkle say that already.
 * - **The tab** (`tabLook`): its dot, the shown tab's none but waiting -- a card waits in it whoever looks.
 * - **The AI button** (`buttonMark`): the strongest mark of any conversation not looked at (waiting, then failed, then
 *   done) -- so with the column hidden, the window away, or another tab shown.
 * - **The page's title** (`titled`): a dot before it while a mark waits and the window is away. The Squidwright app keeps
 *   its windows' titles its own (main refuses the page's), so it is a browser's alone.
 *
 * Pure: the card hands it the list, what was seen and what is looked at. Tested by `attention.test.ts`.
 */
import type { ConversationInfo, TerminalState } from '@vibe/pipeline/agent-types';

/** What a conversation says to someone not looking at it. */
export type Mark = 'waiting' | 'failed' | 'done';

/** A tab's look: its dot. */
export type TabLook = 'running' | Mark | 'idle';

/** What of a conversation was last seen: its last result's `seq`, and when a turn in the terminal last ended. */
export interface Seen {
  ended: number;
  terminal: number;
}

/** What is seen of it now: looked at, its marks go. */
export const seenOf = (info: ConversationInfo): Seen => ({ ended: info.ended, terminal: info.terminalEnded ?? 0 });

/** A kept value read back: a number (a page before this one kept the result's `seq` alone) or a `Seen`. */
export function readSeen(value: unknown): Seen | undefined {
  if (typeof value === 'number') return { ended: value, terminal: 0 };
  const v = value as Partial<Seen> | null;
  if (typeof v !== 'object' || v === null || typeof v.ended !== 'number') return undefined;
  return { ended: v.ended, terminal: typeof v.terminal === 'number' ? v.terminal : 0 };
}

/** A card waiting, or the terminal's CLI asking. */
const waits = (info: ConversationInfo): boolean => info.waiting || info.terminalTurn === 'waiting';
/** A turn of the column's, or of the terminal's, running. */
const runs = (info: ConversationInfo): boolean => info.running || info.terminalTurn === 'running';

/** Its mark, against what was seen of it -- none seen, it is seen as it is (a conversation new to the page has nothing to say). */
export function markOf(info: ConversationInfo, seen: Seen | undefined): Mark | null {
  if (waits(info)) return 'waiting';
  if (runs(info)) return null;
  const was = seen ?? seenOf(info);
  const ended = info.ended > was.ended || (info.terminalEnded ?? 0) > was.terminal;
  if (!ended) return null;
  return info.failed ? 'failed' : 'done';
}

/** A tab's dot: waiting above running; a mark only on a tab not shown (shown, it is cleared). */
export function tabLook(info: ConversationInfo, seen: Seen | undefined, shown: boolean): TabLook {
  if (waits(info)) return 'waiting';
  if (runs(info)) return 'running';
  if (shown) return 'idle';
  return markOf(info, seen) ?? 'idle';
}

/** How strong a mark is: the AI button says the strongest. */
const RANK: Record<Mark, number> = { done: 1, failed: 2, waiting: 3 };

/** The AI button's mark: the strongest of every conversation but the one looked at (`looking`: its id, or null for none). */
export function buttonMark(list: readonly ConversationInfo[], seen: (id: string) => Seen | undefined, looking: string | null): Mark | null {
  let best: Mark | null = null;
  for (const info of list) {
    if (info.id === looking) continue;
    const mark = markOf(info, seen(info.id));
    if (mark !== null && (best === null || RANK[mark] > RANK[best])) best = mark;
  }
  return best;
}

/** The conversation looked at: the shown one, while the column is shown and the window has the focus; else none. */
export const lookingAt = (shown: string | null, column: boolean, focused: boolean): string | null => (column && focused ? shown : null);

/** The words of the AI button's tooltip for its mark. */
export const MARK_WORDS: Record<Mark, string> = {
  waiting: 'Claude is waiting for you',
  failed: 'a turn ended in an error',
  done: 'a turn finished',
};

/** The mark before the page's title while the window is away. */
export const TITLE_MARK = '● ';

/** The page's title: `base`, with the mark before it while a mark waits and the window is away. */
export const titled = (base: string, mark: Mark | null, focused: boolean): string => (mark !== null && !focused ? `${TITLE_MARK}${base}` : base);

/**
 * Open the column's terminal again by itself (Docs/terminal.md D12)? The conversation shown is in the column's terminal
 * and its CLI went with the dev server before (`live` false), while the column is shown -- once a server process: the
 * server marks the attempt (`tried`, gone with the process), so a page reloaded after a refusal does not try and say it
 * again; `asking`, this page's own call under way. One that fails is said, with Back. The person's own terminal is theirs: never.
 */
export function reopenNow(state: TerminalState | null, column: boolean, asking: boolean): boolean {
  return state !== null && state.where === 'column' && !state.live && state.tried !== true && column && !asking;
}
