/**
 * The column's terminal (Docs/terminal.md, T4): while the conversation shown is in the terminal (`AgentState.terminal`),
 * this takes the transcript's and the foot's place in Claude's column.
 *
 * - **In the column** (`where: 'column'`, D2): xterm.js drawing the dev server's PTY -- the `claude` CLI resuming the
 *   conversation -- fitted to the column (`@xterm/addon-fit`, again as the column is resized); its output heard on the
 *   conversation's push channel (`terminal` pushes), the screen kept by the server drawn first after a reload (`GET
 *   terminal`); keys and the size sent back over the same socket (`send`, `vibebase:agent:terminal`). xterm's own textarea
 *   holds the focus while typing: it is marked `data-keys-field="agent-terminal"` (`TERMINAL_FIELD`), so the editor's
 *   keys leave what is typed there to the CLI (Esc, Enter, the arrows), as any field's; no key listener of its own.
 * - **In your own terminal** (`where: 'own'`, D5): the command to paste (Copy), Open in Terminal.app again in the app.
 * - **The bar over it**: what runs where, Copy resume command and Back to the column -- every control the person's
 *   control of Claude (`NOT_FOR_CLAUDE.claudeControl`, D11). Back, refused because the session was written seconds ago
 *   (D5), asks before Back anyway.
 * - **A terminal ended** (the dev server restarted under it, `live` false): opened again by the card as the conversation
 *   is shown in the column (Docs/terminal.md D12; `starting` while it comes, `restart` to draw the new run afresh) -- or,
 *   refused (no node-pty, the CLI would not start), said, with Back. The person's own terminal after a restart keeps its
 *   run (the server adopts its token); one that could not be kept is said: its tools are gone.
 * - **A CLI that ends by itself** at once or failing (a mode it refused, a login it wants): the column comes back with an
 *   error in the transcript -- its exit code and last lines (the server's) -- so it is never a silent dead terminal.
 *
 * xterm is imported as the pane is first shown: the editor's bundle stays as it was for everyone else.
 */
import type { TerminalPush, TerminalState } from '@vibe/pipeline/agent-types';
import xtermCss from '@xterm/xterm/css/xterm.css?inline';
import { isMac } from '@vibe/engine/debug';
import { showDialog } from '../dialog.ts';
import { addSheet, control, el } from '../shell.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';

/** The field xterm's textarea is marked as: what is typed there is the CLI's. */
export const TERMINAL_FIELD = 'agent-terminal';

/**
 * Typing in the column's terminal where Mod is Ctrl (Windows, Linux): the quick prompt's Mod+K -- an `anywhere` action,
 * taken while typing -- is left to the CLI then, whose Ctrl+K is its own (D11). On a Mac Cmd+K reaches no terminal
 * program, and stays the quick prompt's.
 */
export const typingInTerminal = (): boolean => !isMac() && (globalThis.document?.activeElement?.getAttribute('data-keys-field') ?? null) === TERMINAL_FIELD;

/** What the pane needs of the card. */
export interface TerminalPaneHost {
  /** The conversation shown's terminal state now. */
  state(): TerminalState | null;
  /** `GET terminal`: the screen kept, to draw again, and where it ends in all the output (`TerminalPush.at`). */
  screen(): Promise<{ screen: string; end: number }>;
  /** Keys or a size to the conversation's terminal (`vibebase:agent:terminal`). */
  send(message: { data: string } | { cols: number; rows: number }): void;
  /** Back to the column (`POST terminal/close`); `force`, past a session written just now. */
  back(force: boolean): Promise<void>;
  /** Terminal.app again (the app's bridge, D5); none in a browser. */
  openOwn?(): Promise<void>;
  /** A line in the card's head. */
  say(text: string, tone?: 'bad' | 'idle'): void;
}

export interface TerminalPane {
  readonly root: HTMLElement;
  /** Drawn for the conversation shown -- its terminal, or none: hidden. A new conversation's: its screen read again. */
  draw(conversation: string | null): void;
  /** Output, or its end, for the conversation shown. */
  heard(push: TerminalPush): void;
  /** The column's size changed: the terminal fitted again. */
  fit(): void;
  /** The terminal focused, if one is drawn. */
  focus(): void;
  /** Back to the column, as its button does (the ⋯ menu's). */
  back(): Promise<void>;
  /** The terminal being opened again after a restart (D12): said in the bar while it comes. */
  starting(on: boolean): void;
  /** A new run of the conversation shown: its screen read and drawn afresh at the next draw. */
  restart(): void;
  dispose(): void;
}

/** What `back` is refused with when Terminal.app's session was written just now (the server's words, D5). */
const RECENT = /^The session was written/;

/** What is used of xterm's `Terminal` and its fit addon. */
interface Xterm {
  open(parent: HTMLElement): void;
  write(data: string): void;
  reset(): void;
  focus(): void;
  dispose(): void;
  onData(fn: (data: string) => void): { dispose(): void };
  onResize(fn: (size: { cols: number; rows: number }) => void): { dispose(): void };
  readonly cols: number;
  readonly rows: number;
  readonly textarea: HTMLTextAreaElement | undefined;
}

export function createTerminalPane(host: TerminalPaneHost): TerminalPane {
  const dropSheet = addSheet(xtermCss);
  const root = el('div', 'ed-ag-term');
  root.hidden = true;
  const bar = el('div', 'ed-ag-term-bar');
  const where = el('span', 'ed-ag-term-where');
  const copy = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-quiet ed-ag-term-copy', 'Copy resume command');
  copy.title = 'The command that resumes this conversation in a terminal, with the studio\'s tools and context: copied';
  const own = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-quiet ed-ag-term-own', 'Open in Terminal.app');
  own.title = 'Run the resume command in Terminal.app (the Squidwright app)';
  const back = control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-accent ed-ag-term-back', 'Back to the column');
  back.title = 'End Claude Code in the terminal and go on here: the turns made there are shown, and the conversation remembers them';
  bar.append(where, copy, own, back);
  const screenHost = el('div', 'ed-ag-term-screen');
  const note = el('div', 'ed-ag-term-note');
  const command = el('pre', 'ed-ag-term-command');
  root.append(bar, screenHost, note, command);

  let shownFor: string | null | undefined;
  let term: Xterm | null = null;
  let fitter: { fit(): void } | null = null;
  let making: Promise<void> | null = null;
  const offs: { dispose(): void }[] = [];
  let backing = false;
  /** Opened again after a restart, under way (`starting`). */
  let again = false;
  /** Where the screen drawn ends in all the run's output; null while the kept screen is being read (pushes wait). */
  let drawnTo: number | null = null;
  /** Pushes heard while the screen kept was read: drawn after it, less what it already had. */
  const waiting: TerminalPush[] = [];

  /** A push's output drawn from where the screen ends: what the screen kept had already, skipped. */
  function draw(push: TerminalPush): void {
    if (push.data !== undefined && term) {
      const at = push.at ?? drawnTo ?? 0;
      const skip = Math.max(0, (drawnTo ?? 0) - at);
      if (skip < push.data.length) term.write(push.data.slice(skip));
      drawnTo = Math.max(drawnTo ?? 0, at + push.data.length);
    }
    if (push.exited !== undefined) term?.write(`\r\n\x1b[2m[Claude Code ended${push.exited === null ? '' : ` (${push.exited})`}]\x1b[0m\r\n`);
  }

  /** xterm made the first time it is needed, in the screen's place. */
  async function make(): Promise<void> {
    if (term) return;
    const [{ Terminal }, { FitAddon }] = await Promise.all([import('@xterm/xterm'), import('@xterm/addon-fit')]);
    const t = new Terminal({ cursorBlink: true, fontSize: 12, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', scrollback: 5000, allowProposedApi: false }) as unknown as Xterm & { loadAddon(a: unknown): void };
    const fit = new FitAddon();
    t.loadAddon(fit);
    t.open(screenHost);
    // What is typed into xterm is the CLI's: the editor's keys leave a field's typing alone (D11).
    t.textarea?.setAttribute('data-keys-field', TERMINAL_FIELD);
    offs.push(
      t.onData((data) => host.send({ data })),
      t.onResize(({ cols, rows }) => host.send({ cols, rows })),
    );
    term = t;
    fitter = fit;
  }

  async function fill(): Promise<void> {
    await (making ??= make().finally(() => (making = null)));
    if (!term) return;
    term.reset();
    drawnTo = null;
    const kept = await host.screen().catch(() => ({ screen: '', end: 0 }));
    term.write(kept.screen);
    drawnTo = kept.end;
    for (const push of waiting.splice(0)) draw(push);
    fitNow();
    host.send({ cols: term.cols, rows: term.rows });
  }

  function fitNow(): void {
    if (!term || root.hidden || screenHost.hidden) return;
    try {
      fitter?.fit();
    } catch {
      // Not laid out yet.
    }
  }

  async function goBack(force: boolean): Promise<void> {
    if (backing) return;
    backing = true;
    back.disabled = true;
    try {
      await host.back(force);
    } catch (err) {
      const words = (err as Error).message;
      if (!force && RECENT.test(words)) {
        showDialog({ title: 'Back to the column?', text: words, buttons: [{ label: 'Back anyway', kind: 'danger', run: () => void goBack(true) }] });
      } else host.say(words, 'bad');
    } finally {
      backing = false;
      back.disabled = false;
    }
  }

  copy.addEventListener('click', () => {
    const line = host.state()?.command ?? '';
    navigator.clipboard.writeText(line).then(() => host.say('The resume command is copied: paste it into a terminal', 'idle'), () => host.say('Not copied: the browser would not let it', 'bad'));
  });
  own.addEventListener('click', () => {
    host.openOwn?.().catch((err: Error) => host.say(err.message, 'bad'));
  });
  back.addEventListener('click', () => void goBack(false));

  const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(() => fitNow());
  observer?.observe(screenHost);

  return {
    root,
    draw(conversation) {
      const state = host.state();
      root.hidden = state === null;
      if (state === null) {
        shownFor = undefined;
        return;
      }
      const column = state.where === 'column';
      const ended = column && !state.live;
      // The person's own terminal after a restart whose run could not be kept: its CLI has lost the studio's tools (D5).
      const lost = !column && !state.live;
      where.textContent = column ? (ended ? (again ? 'Starting Claude Code again in the terminal…' : 'The terminal ended (the dev server restarted under it)') : 'Claude Code, in the terminal') : lost ? 'In your own terminal, without the studio\'s tools' : 'Continued in your own terminal';
      screenHost.hidden = !column;
      own.hidden = column || !host.openOwn;
      note.hidden = column && (!ended || again);
      note.textContent = ended
        ? 'Back to the column takes the conversation back: the turns made there are shown, and Claude remembers them.'
        : lost
        ? 'The dev server restarted and the run could not be kept: the studio\'s tools and the editor\'s context are gone from that Claude Code. Back to the column, then continue again for them.'
        : 'Claude Code runs in a terminal of your own, with the studio\'s tools and what the editor shows with each prompt. Paste the command if it is not running yet; quit it there (or not) and come Back to the column.';
      command.hidden = column;
      command.textContent = state.command;
      if (column && shownFor !== conversation) {
        shownFor = conversation;
        void fill();
      }
      fitNow();
    },
    heard(push) {
      if (drawnTo === null) waiting.push(push);
      else draw(push);
    },
    fit: fitNow,
    focus: () => term?.focus(),
    back: () => goBack(false),
    starting(on) {
      again = on;
      if (shownFor !== undefined) this.draw(shownFor);
    },
    restart() {
      shownFor = undefined;
    },
    dispose() {
      observer?.disconnect();
      for (const off of offs) off.dispose();
      term?.dispose();
      root.remove();
      dropSheet();
    },
  };
}
