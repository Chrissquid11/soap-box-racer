/**
 * The push channel the card's conversations share (Docs/agent.md §4, "The
 * tabs"): one listener on the page's socket, each conversation's messages
 * handed to its own `AgentLive` (`live.ts`), the list of open conversations
 * kept, and the editor tools' calls handed to the card.
 *
 * - **The list** -- id, title, running, waiting, the last result's `seq` --
 *   read with `GET conversations` as the card starts, and pushed whole
 *   (`{ conversations }`) whenever it changes; an answer that carries it (a
 *   create, a close, a rename) is taken too.
 * - **One channel a conversation** (`channel(id)`): a `HotChannel` that hears
 *   the `vibebase:agent` messages whose `conversation` is that id (a message
 *   naming none, the server's first) and Vite's own events as they are -- so
 *   each conversation's live keeps its `seq`, its epoch and its gaps as one
 *   alone did. A conversation's live is made when it is first shown, and
 *   kept: its state goes on being heard.
 * - **The hello is the hub's**: `{ tab, multi: true }` as it starts, on every
 *   reconnect, and when the tab's id is made anew -- `multi`, so the server
 *   pushes every conversation's messages and the list here, not only the
 *   first's.
 * - **`{ mcp }`** is no conversation's: the card runs it, whoever's turn.
 * - **`{ page }`**, the hello's answer: the page's secret, kept for `POST settings`'
 *   level and outside clients' (`secret`).
 *
 * The page's socket is handed in (`import.meta.hot` by default), so a node
 * test drives it by hand.
 */
import type { ConversationInfo, ConversationsAnswer, Hello, HelloEvent, McpCall, ProjectToolDecl, TabMessage } from '@vibe/pipeline/agent-types';
import { isUnavailable, type AgentApi } from './api.ts';
import type { HotChannel } from './live.ts';

/** The push channel's event, as `api-types.ts` names it. */
const EVENT = 'vibebase:agent';
/** The page's hello, on the same socket. */
const HELLO: HelloEvent = 'vibebase:agent:hello';

export interface Hub {
  /** The open conversations, in order; empty until read (or on another machine). */
  readonly list: readonly ConversationInfo[];
  /** The page's secret, as the server's answer to the hello told it (`PageSecret`); null before, or where none came. */
  readonly secret: string | null;
  /** `GET conversations`, once: the list. Null where there is none to read -- another machine, no answer -- and the card goes on with the server's first. */
  start(): Promise<readonly ConversationInfo[] | null>;
  /** An answer that carries the list (a create, a close, a rename, an order): taken. */
  take(answer: ConversationsAnswer): void;
  /** A conversation's own channel, for its live: its messages alone. */
  channel(id: string | null): HotChannel;
  /** This tab's id made anew (it was a duplicate's): said in a hello at once. */
  setTab(id: string): void;
  on(event: 'list', listener: (list: readonly ConversationInfo[]) => void): () => void;
  on(event: 'mcp', listener: (call: McpCall) => void): () => void;
  dispose(): void;
}

export function createHub(api: AgentApi, hot: HotChannel | undefined = import.meta.hot as HotChannel | undefined, tab: string | null = null, tools: readonly ProjectToolDecl[] = []): Hub {
  let list: readonly ConversationInfo[] = [];
  let started: Promise<readonly ConversationInfo[] | null> | null = null;
  const lists = new Set<(list: readonly ConversationInfo[]) => void>();
  /** The page's secret, told by the server at the hello: a change of the level or the outside clients' carries it. */
  let secret: string | null = null;
  const calls = new Set<(call: McpCall) => void>();
  /** Each conversation's channel's listeners of `vibebase:agent`, by its id ('' the server's first). */
  const heard = new Map<string, Set<(data: unknown) => void>>();

  const setList = (next: readonly ConversationInfo[]): void => {
    list = next;
    for (const fn of lists) fn(next);
  };

  const hello = (): void => {
    // The project's own MCP tools said with it (Docs/mcp.md M7): what the dev server registers as project_<name>.
    if (tab !== null) hot?.send?.(HELLO, { tab, multi: true, ...(tools.length > 0 ? { tools: [...tools] } : {}) } satisfies Hello);
  };

  const hear = (data: unknown): void => {
    const message = data as TabMessage;
    if (typeof message !== 'object' || message === null) return;
    if ('conversations' in message) return setList(message.conversations);
    if ('page' in message) {
      secret = typeof message.page?.secret === 'string' ? message.page.secret : null;
      return;
    }
    if ('mcp' in message) {
      for (const fn of calls) fn(message.mcp);
      return;
    }
    // A message naming no conversation is the first's: a server's one.
    const id = message.conversation ?? list[0]?.id ?? '';
    for (const fn of heard.get(id) ?? []) fn(message);
    // The first, asked for by no id (another machine, or before the list came): its channel is ''.
    if (id !== '' && id === list[0]?.id) for (const fn of heard.get('') ?? []) fn(message);
  };
  const up = (): void => hello();
  hot?.on(EVENT, hear as (data: never) => void);
  hot?.on('vite:ws:connect', up as (data: never) => void);

  return {
    get list() {
      return list;
    },
    get secret() {
      return secret;
    },
    start() {
      return (started ??= (async () => {
        hello();
        try {
          const answer = await api.conversations();
          if (isUnavailable(answer)) return null;
          setList(answer.conversations);
          return list;
        } catch {
          return null;
        }
      })());
    },
    take(answer) {
      setList(answer.conversations);
    },
    channel(id) {
      const key = id ?? '';
      return {
        on(event, listener) {
          if (event !== EVENT) return hot?.on(event, listener);
          const set = heard.get(key) ?? new Set();
          set.add(listener as (data: unknown) => void);
          heard.set(key, set);
        },
        off(event, listener) {
          if (event !== EVENT) return hot?.off?.(event, listener);
          heard.get(key)?.delete(listener as (data: unknown) => void);
        },
        send: (event, data) => hot?.send?.(event, data),
      };
    },
    setTab(id) {
      tab = id;
      if (started !== null) hello();
    },
    on(event: 'list' | 'mcp', listener: ((list: readonly ConversationInfo[]) => void) | ((call: McpCall) => void)) {
      const set = (event === 'list' ? lists : calls) as Set<typeof listener>;
      set.add(listener);
      return () => void set.delete(listener);
    },
    dispose() {
      hot?.off?.(EVENT, hear as (data: never) => void);
      hot?.off?.('vite:ws:connect', up as (data: never) => void);
      lists.clear();
      calls.clear();
      heard.clear();
    },
  };
}
