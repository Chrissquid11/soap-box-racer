/**
 * The words of `/usage` and of the subagents strip (Docs/agent.md §4): pure, so node tests them -- the card draws them.
 *
 * - **`/usage`** (`usageRows`): each of the plan's limits as Claude Code's `/usage` has them -- "34 % used", when it
 *   resets ("resets 15:00", "resets Mon 09:00"), a limit reached in the danger tone -- then this conversation's cost
 *   (at API prices: notional on a plan, and said so), its tokens, and the context window. A part never heard is "not
 *   known yet", with why: no limit event since the dev server started, the CLI not up -- never a guess. A limit whose
 *   reset has passed says so, its percent no longer this window's.
 * - **The popover's line** (`usageLine`): the session's and the week's percent, or "not known yet".
 * - **The strip** (`agentsSummary`, `agentRowWords`): "3 agents running" folded; a row each unfolded -- its type, what
 *   it is for, its state, its time, its calls, its tokens, what it did last.
 */
import type { AgentRow, UsageFacts, UsageLimit } from '@vibe/pipeline/agent-types';

/** One line of the `/usage` card: what, the value, and `tone` -- `bad` a limit reached, `warn` near one. */
export interface UsageRow {
  label: string;
  value: string;
  title: string;
  tone: 'bad' | 'warn' | null;
  /** 0-100 for a bar under it; null: none. */
  bar: number | null;
}

const two = (n: number): string => String(n).padStart(2, '0');
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** When a limit resets, as the person reads it: the time today, else the day and time, else the date. */
export function resetWords(at: number, now: number): string {
  const d = new Date(at);
  const time = `${two(d.getHours())}:${two(d.getMinutes())}`;
  const today = new Date(now);
  const sameDay = d.getFullYear() === today.getFullYear() && d.getMonth() === today.getMonth() && d.getDate() === today.getDate();
  if (sameDay) return time;
  if (at - now < 6 * 86_400_000 && at > now) return `${DAYS[d.getDay()]} ${time}`;
  return `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())} ${time}`;
}

/** A count as people say it: 1.2k, 3.4M. */
export function tokensWords(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) return `${(n / 1000).toFixed(n < 10_000 ? 1 : 0)}k`;
  return `${(n / 1_000_000).toFixed(1)}M`;
}

/** Dollars, to the cent -- or "under a cent". */
export const dollars = (n: number): string => (n > 0 && n < 0.005 ? 'under $0.01' : `$${n.toFixed(2)}`);

/** How long ago, roughly: "just now", "4 min ago", "2 h ago". */
export function agoWords(at: number, now: number): string {
  const s = Math.max(0, Math.round((now - at) / 1000));
  if (s < 45) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86_400) return `${Math.round(s / 3600)} h ago`;
  return `${Math.round(s / 86_400)} d ago`;
}

/** One limit's line. */
export function limitRow(limit: UsageLimit, now: number): UsageRow {
  const over = limit.resets !== null && limit.resets <= now;
  const heard = `heard ${agoWords(limit.at, now)}${limit.from === 'event' ? ' (a rate-limit event)' : " (Claude Code's usage call)"}`;
  if (over) return { label: limit.label, value: 'reset since', title: `It reset at ${resetWords(limit.resets!, now)}: the next turn says how much of the new window is used. ${heard}`, tone: null, bar: null };
  const used = limit.used !== null ? `${Math.round(limit.used)} % used` : limit.status === 'rejected' ? 'reached' : limit.status === 'allowed_warning' ? 'near its limit' : 'within it';
  const resets = limit.resets !== null ? ` · resets ${resetWords(limit.resets, now)}` : '';
  const tone = limit.status === 'rejected' || (limit.used ?? 0) >= 100 ? 'bad' : limit.status === 'allowed_warning' || (limit.used ?? 0) >= 80 ? 'warn' : null;
  return { label: limit.label, value: `${used}${resets}`, title: `${limit.label}: ${used}${resets}. ${heard}`, tone, bar: limit.used };
}

/** The `/usage` card's lines, and a note under them. `live`: Claude Code's usage call answered just now. */
export function usageRows(usage: UsageFacts | undefined, now: number, live: boolean): { rows: UsageRow[]; note: string | null } {
  const rows: UsageRow[] = [];
  const u = usage ?? null;
  if (u?.plan === false) rows.push({ label: 'Plan limits', value: 'none here', title: 'Plan limits do not apply to this login (an API key, Bedrock or Vertex): what it costs is billed as used', tone: null, bar: null });
  else if (!u || u.limits.length === 0) rows.push({ label: 'Plan limits', value: 'not known yet', title: 'Claude Code has said nothing of the plan\'s limits to this dev server yet: it does with a turn\'s first rate-limit event, or its usage call once it is up', tone: null, bar: null });
  else for (const limit of u.limits) rows.push(limitRow(limit, now));
  const plan = u?.subscription ? ` on ${u.subscription}` : '';
  rows.push(
    u?.cost != null
      ? { label: 'This conversation', value: `${dollars(u.cost)} at API prices`, title: `What this conversation has cost so far, as Claude Code counts it (its running total, kept across a resume)${plan ? `: notional${plan}, where the plan's limits are what count` : ''}`, tone: null, bar: null }
      : { label: 'This conversation', value: 'nothing yet', title: 'No turn has ended in this conversation since it began, or since it was cleared', tone: null, bar: null },
  );
  if (u?.tokens) {
    const t = u.tokens;
    rows.push({ label: 'Tokens', value: `${tokensWords(t.input)} in · ${tokensWords(t.output)} out · ${tokensWords(t.cacheRead)} cached`, title: `Input ${t.input}, output ${t.output}, read from the cache ${t.cacheRead}, written to it ${t.cacheWrite}: every model's together, this conversation so far`, tone: null, bar: null });
  }
  if (u?.context) {
    const c = u.context;
    const of = c.max > 0 ? ` · ${tokensWords(c.used)} of ${tokensWords(c.max)}` : '';
    rows.push({ label: 'Context', value: `${c.percent} %${of}`, title: 'How much of the model\'s context window the conversation fills, after its last turn: past 80 %, Clear to start fresh (or /compact)', tone: c.percent > 80 ? 'warn' : null, bar: c.percent });
  } else rows.push({ label: 'Context', value: 'not known yet', title: 'Said after the conversation\'s first turn', tone: null, bar: null });
  // Not asked just now (Claude Code not up, or without its usage call): when it was heard, said.
  const note = live ? null : u?.at != null ? `As last heard, ${agoWords(u.at, now)}` : 'Nothing heard yet: send a prompt, and the next /usage says more';
  return { rows, note };
}

/** The settings popover's one line: the session's and the week's limits, or "not known yet". */
export function usageLine(usage: UsageFacts | undefined, now: number): string {
  if (usage?.plan === false) return 'No plan limits (API key)';
  const pick = (kind: string): string | null => {
    const l = usage?.limits.find((x) => x.kind === kind);
    if (!l || l.used === null || (l.resets !== null && l.resets <= now)) return null;
    return `${Math.round(l.used)} %`;
  };
  const parts = [pick('five_hour') !== null ? `Session ${pick('five_hour')}` : null, pick('seven_day') !== null ? `Week ${pick('seven_day')}` : null].filter((p): p is string => p !== null);
  const cost = usage?.cost != null ? dollars(usage.cost) : null;
  if (parts.length === 0) return cost ? `${cost} · limits not known yet` : 'Not known yet: /usage';
  return [...parts, ...(cost ? [cost] : [])].join(' · ');
}

/** A time running or taken: "8 s", "2 m 05 s", "1 h 04 m". */
export function elapsed(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  if (s < 60) return `${s} s`;
  if (s < 3600) return `${Math.floor(s / 60)} m ${two(s % 60)} s`;
  return `${Math.floor(s / 3600)} h ${two(Math.floor((s % 3600) / 60))} m`;
}

const noun = (row: AgentRow): string => (row.kind === 'shell' ? 'shell' : row.kind === 'task' ? 'task' : 'agent');

/** The strip folded: "3 agents running", "1 agent running · 2 done", "2 agents · done", "1 shell running". */
export function agentsSummary(rows: readonly AgentRow[]): string {
  if (rows.length === 0) return '';
  const running = rows.filter((r) => r.state === 'running');
  const failed = rows.filter((r) => r.state === 'failed').length;
  const kinds = new Set(rows.map(noun));
  const word = kinds.size === 1 ? [...kinds][0]! : 'task';
  const many = (n: number, w: string): string => `${n} ${w}${n === 1 ? '' : 's'}`;
  const runWord = new Set(running.map(noun)).size === 1 && running.length > 0 ? noun(running[0]!) : word;
  if (running.length > 0) {
    const done = rows.length - running.length;
    return `${many(running.length, runWord)} running${done > 0 ? ` · ${done} done` : ''}${failed > 0 ? ` (${failed} failed)` : ''}`;
  }
  return `${many(rows.length, word)} · ${failed > 0 ? `${failed} failed` : 'done'}`;
}

/** One row unfolded: its name, its state's words, its numbers, and its title. */
export function agentRowWords(row: AgentRow, now: number): { name: string; state: string; meta: string; last: string; title: string } {
  const name = row.type ?? (row.kind === 'shell' ? 'Shell' : row.kind === 'task' ? 'Task' : 'Agent');
  const time = elapsed((row.endedAt ?? now) - row.startedAt);
  const state = row.state === 'running' ? (row.background ? 'in the background' : 'running') : row.state === 'done' ? 'done' : row.state === 'failed' ? 'failed' : 'stopped';
  const meta = [time, ...(row.tools > 0 ? [`${row.tools} call${row.tools === 1 ? '' : 's'}`] : []), ...(row.tokens !== null ? [`${tokensWords(row.tokens)} tokens`] : [])].join(' · ');
  // An agent that has done nothing yet is starting; a background shell says nothing of itself.
  const last = row.last ?? (row.state === 'running' && row.kind === 'agent' && row.tools === 0 ? 'starting…' : '');
  const title = `${name}${row.description ? `: ${row.description}` : ''}\n${state}, ${meta}${row.last ? `\nLast: ${row.last}` : ''}${row.kind === 'agent' ? '\nClick: its calls in the transcript' : ''}`;
  return { name, state, meta, last, title };
}
