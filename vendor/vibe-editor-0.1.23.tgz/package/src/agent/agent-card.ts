/**
 * The agent's card (Docs/agent.md §4, "The card"; Docs/ai-panel.md §3): Claude's
 * column, a full-height docked column at the window's right edge, right of the
 * inspector, Claude Code behind it on the dev server. The host's, like the
 * History card -- there on every tab, the host making it a column
 * (`shell.ts`' `aiColumn`: its grip, its kept width, docked or over the scene)
 * -- and made only where `import.meta.hot` is: a build served without a dev
 * server has none.
 *
 * - **Shown or hidden** (D2; hidden kept in `prefs.ts`' `agentMinimized`, and
 *   in the host's resume record): there whole, or gone from the page -- nothing
 *   of it drawn, its room given back. No folded state. The host's AI button
 *   and Mod+I (`AI_KEY`) show it and hide it; Mod+; shows it to focus the box;
 *   a card waiting for the person brings it back -- in the tab shown. One
 *   waiting in another tab, or in one hidden again, is not seen, so the AI
 *   button says so -- and so of a turn done or failed where nobody looked
 *   (Docs/ai-panel.md §8, `attention.ts`): a dot on it, the warning colour,
 *   the danger colour or the accent (`badge`, the host's `aiButton`), and a
 *   dot before the page's title while the window is away. A permission or question card scrolls to itself: a question
 *   nobody can see is a hung agent. While a playtest runs maximized the column
 *   is hidden with every card and a card waiting badges the playtest's pill;
 *   docked, it stays live. When it is back (`shown`: the playtest over, the
 *   editor opened) the card waiting is brought into view -- else the newest,
 *   unless scrolled up. A card answered here hands the focus back to the box.
 * - **The top row** (D3): the tabs, then the context used after the last turn,
 *   a `⋯` menu (Clear, Claude's settings in Config) and Hide.
 * - **The transcript** (`transcript.ts`) the column's whole height between
 *   them, at the newest unless scrolled up.
 * - **The foot**: the head line -- while a turn runs, a spinner and its clock
 *   (a 1 Hz timer only then, from the state's `startedAt`, so it survives a
 *   reload) and what is going on; otherwise a failure with its next step (and
 *   Retry, where starting again would help) or what a review bar costs
 *   (`headLine`); then "Code changed · 2 files · Reload now" while code is
 *   held. Nothing going on: no head row. Under it the "With:" line, the box
 *   (`prompt-box.ts`), and one row: the **settings chip** (D4, `chip.ts`:
 *   "Opus · high · Auto · bar 7", Unsafe auto in the danger colour) opening a
 *   popover with Model, Effort, Review and the permission level; Attach view,
 *   an icon toggle; Send -- Stop while a turn runs. Clear, in the `⋯` menu,
 *   asks first on that row ("Forget this conversation? Clear · Keep"): a slip
 *   would lose the conversation for good.
 * - **Settings are the server's**: model, effort, review and Auto are drawn
 *   from the state and changed through `POST settings`, so two tabs and a
 *   restart agree. Attach view is this tab's (`prompt-box.ts`).
 * - **A turn** carries the editor's context as facts (`context.ts`, the
 *   host's `context()`), the box's images, and the screenshot with Attach
 *   view. Sent while one runs: said -- "A turn is running: Stop first" -- the
 *   words kept, nothing queued.
 * - **Its keys** are the host's (`editor.ts`): Mod+; focuses the box (the
 *   column shown if hidden); Mod+I shows it or hides it; the box's own --
 *   Enter, Mod+Enter, ↑ ↓ -- are MrDebug field actions it registers from
 *   `keys` here.
 * - **The studio as tools** (Docs/mcp.md): this tab has an id, in
 *   its `sessionStorage` so a reload is the same tab, a duplicated tab's made
 *   anew (`tab.ts`), said on the socket (`live.ts`' hello) and with each turn;
 *   a call the dev server relays to it is run against the editor
 *   (`../mcp/page.ts`, the page tools, over the host's `tools`) and answered with `POST
 *   mcp/answer`. Its edits are the transcript's: a row's Undo, Undo this
 *   turn's editor edits -- kept as values across a reload (`carry`, the
 *   host's resume record, and `carried`, back from it).
 * - **A click on the card's head, or on an empty part of it**, puts the focus
 *   in the box: the next letters typed are words, not the editor's keys.
 *   Send waits while Claude Code is not logged in: the head says what to do.
 * - **Tabs: conversations, several at once** (Docs/agent.md §4, "The tabs"):
 *   a row in the head, one tab a conversation, in the server's order -- its
 *   title (from the first prompt; double-click to rename, an inline field
 *   whose Enter and Esc are MrDebug's), and what it is doing: running (the
 *   accent, pulsing), needs you (a card waiting, or the terminal's CLI
 *   asking: the warning colour), a turn done or failed since it was looked
 *   at (the accent's dot, the danger colour's), idle. `+` makes
 *   one with the shown one's settings and shows it, the box focused; `×`
 *   closes one -- running, the editor's dialog asks "Stop and close?" -- and
 *   the last one's `×` is Clear. Everything below the row is the shown
 *   conversation's: the transcript, the draft (each conversation's own, kept
 *   as the draft is), the pickers, Auto, Undo this turn, the cards. Every
 *   conversation once shown keeps its own push channel (`hub.ts`, `live.ts`)
 *   and transcript, drawn only while shown; one never shown starts no CLI.
 *   The tab shown is this browser tab's (`sessionStorage`): a reload comes
 *   back on it. Its keys (`tabKeys`) are the host's to register.
 *
 * - **Slash commands, `/usage`, `/btw`, the subagents** (Docs/agent.md §4): `/` typed first in the box opens the
 *   list over it (`slash.ts`), its keys the host's field actions (`keys.slash`); the card's own commands are done
 *   here and never sent -- `/usage` a card at the transcript's end (`aside`, `usage-words.ts`), asked of the server
 *   (`POST usage`); `/btw` `POST btw`, its answer a `btw` entry; `/clear` the ⋯ menu's Clear, asked; `/agents` the
 *   strip over the box unfolded or folded -- the subagents and background tasks of the turn (`state.agents`), a row
 *   clicked to its call in the transcript (`reveal`). The chip's popover has `/usage` in a line.
 *
 * Its stylesheet is `agent.css`, `ed-ag-` classes, through `addSheet`.
 */
import type { AgentRow, AgentState, ConversationInfo, Entry, SettingsRequest, TerminalEvent, TurnContext, TurnImage, TurnTarget, UsageFacts } from '@vibe/pipeline/agent-types';
import { keyLabel } from '@vibe/engine/debug';
import { projectKey } from '@vibe/engine/project-key';
import { showDialog } from '../dialog.ts';
import { keepPref, loadPrefs } from '../prefs.ts';
import { addSheet, control, el, icon, letGo } from '../shell.ts';
import { createMenu, type Menu } from '../menu.ts';
import { chipWords } from './chip.ts';
import { createSettingsPicks } from './settings-picks.ts';
import css from './agent.css?inline';
import { createAgentApi, type AgentApi } from './api.ts';
import { createPageTools, readCarry, type PageHost } from '../mcp/page.ts';
import { createHub, type Hub } from './hub.ts';
import { buttonMark, lookingAt, readSeen, reopenNow, seenOf, tabLook, titled, type Mark, type Seen } from './attention.ts';
import { createAgentLive, type AgentLive } from './live.ts';
import type { TurnAttachments } from './context.ts';
import { createPromptBox } from './prompt-box.ts';
import { IMAGES_MAX, shoot } from './shot.ts';
import { claimTab, pageTabHost, type TabHost } from './tab.ts';
import { clock, contextWords, createTranscript, headLine, heldWords, type Transcript } from './transcript.ts';
import { cardCommand, commandsOf, completion, goClick, goMode, matchCommands, runsAtOnce, slashAt, stepSelection, type SlashCommand } from './slash.ts';
import { agentRowWords, agentsSummary, usageLine, usageRows } from './usage-words.ts';
import { NOT_FOR_CLAUDE } from '../mcp/gaps.ts';
import { appShell } from '../studio/app-shell.ts';
import { createTerminalPane } from './terminal-pane.ts';
import { editorKeyOf, hasEditorKey, tabKey } from '../editor-keys.ts';

export interface AgentCardHost {
  /** What the editor shows, as a turn's facts. */
  context(): TurnContext;
  /** What the tool up sends besides -- the Model tab's model and canvases (Docs/modeler.md M26) -- or none. */
  attachments?(): TurnAttachments | null;
  /** The editor's frame drawn now, overlays and all: a screenshot's first half. */
  draw(): void;
  /** The canvas it is drawn on. */
  readonly canvas: HTMLCanvasElement;
  /** Is a playtest running maximized: the column is hidden with every card, and a card waiting badges the pill. */
  playing(): boolean;
  /** The playtest pill's badge: "Claude is waiting for you", or none. */
  badge(text: string | null): void;
  /** A card waits for the person: the editor's cards, if they were put away, brought back so it is seen. */
  attention?(): void;
  /**
   * A file of a turn's result, clicked: shown where it is, or its path copied -- a text file opened in the Studio
   * tab's Code card, its diff from the turn's start when the row has its turn. What was done, said in
   * the head.
   */
  reveal(path: string, turn?: string): Promise<string>;
  /** The card shown or hidden: the host's column and the room past it measured again. */
  resized(): void;
  /** Config ▸ Claude ▸ Settings shown: the `⋯` menu's way to the settings the chip has not (Fix a failed boot, Outside clients). */
  settingsPage?(): void;
  /**
   * The host's AI button as the card is: lit while it shows (hidden or brought back -- by its button, a key, a card
   * waiting); `mark` (Docs/ai-panel.md §8, `attention.ts`' `buttonMark`) the strongest of any conversation not looked at
   * -- the column hidden, the window away, another tab shown: Claude waiting for you (as the playtest's pill says it
   * while one runs), a turn failed, a turn done -- a dot on the button. Called as any of them changes.
   */
  aiButton?(shown: boolean, mark: Mark | null, running: boolean): void;
  /** Hidden as the reload before left it (the resume record's `agentMinimized`); else as the preferences keep it. */
  readonly minimized?: boolean;
  /** The editor as the agent's editor tools act on it (§8). */
  readonly tools: PageHost;
  /** What the reload just survived kept of the agent's edits in this tab (`mcp/page.ts`' `EditorCarry`, read there), or nothing. */
  readonly carried?: unknown;
}

export interface AgentCard {
  /** The column: the host places it (`shell.ts`' `aiColumn`); hidden while minimized. */
  readonly root: HTMLElement;
  /** Gone from the page, its room given back (Hide; the AI button and Mod+I): kept with the preferences. */
  readonly minimized: boolean;
  setMinimized(minimized: boolean): void;
  /** Out of the page now: hidden by the person (`minimized`) or set aside for a docked playtest (`setAside`). */
  readonly hidden: boolean;
  /** Set aside by the host (Docs/ai-panel.md D5): hidden while a docked playtest runs over its room, the preference untouched. */
  readonly aside: boolean;
  /** Out of the way, or back as it was -- `setMinimized(false)` (Mod+I, the AI button, a card waiting) brings it back too. */
  setAside(aside: boolean): void;
  /** Its ⋯ menu or the chip's popover is open: Esc is theirs (the host's Escape and arrows, as menu.ts asks). */
  holdsEscape(): boolean;
  /** Esc: the ⋯ menu closed, else the popover. */
  cancel(): void;
  /** ↑ ↓ in the ⋯ menu, open. */
  menuStep(by: 1 | -1): void;
  /** Is the ⋯ menu open: its arrows are live. */
  menuOpen(): boolean;
  /** Mod+; and Mod+I: the column shown, the box focused. */
  focusBox(): void;
  /** Words put in the box for the person to send, the column shown and the box focused -- never sent (the Model tab's Delete, M30). */
  prefill(text: string): void;
  /** What the tool up sends with a turn changed: the line over the box drawn again. */
  refreshWith(): void;
  /**
   * The quick prompt's way in (`Mod+K`, Docs/ai-panel.md §4): words and a target sent as a turn of the conversation
   * shown, with its settings -- the column left as it is, hidden or not. `send` resolves with the conversation's id and
   * its last result's `seq` as it went (the pill's `quickStatus`), and rejects with why not (a turn running, not up).
   */
  readonly quick: {
    send(text: string, target: TurnTarget | null): Promise<{ conversation: string | null; ended: number }>;
    /** A conversation's row in the list now; null once it is gone. */
    info(conversation: string | null): ConversationInfo | null;
    /** The conversation shown's title: where Enter sends. */
    title(): string;
  };
  /** The box's own keys, for the host to register as MrDebug field actions. */
  readonly keys: {
    /** Enter, Mod+Enter: the turn sent -- or, while one runs, said why not; the card's own slash command done here. */
    send(): void;
    /** Is the slash list open (`/` typed first): its ↑ ↓, Tab, Enter and Esc are the list's. */
    slashOpen(): boolean;
    /** The slash list's keys: ↑ ↓ walk it, Tab completes, Enter completes (and sends one taking nothing), Esc shuts it. */
    slash(key: 'up' | 'down' | 'tab' | 'enter' | 'escape'): void;
    canRecall(step: -1 | 1): boolean;
    recall(step: -1 | 1): void;
  };
  /** Before a reload: the draft kept. */
  keep(): void;
  /** Before a reload: the agent's edits in this tab, as values -- for the host's resume record (`carried` after it). */
  carry(): unknown;
  /** A playtest began or ended: the badge; ended, the card waiting brought into view. */
  playtest(): void;
  /** The dock is shown again (the editor opened): the card waiting in view, else the newest unless scrolled up. */
  shown(): void;
  /** Its settings, the server's, for another set of controls (Config ▸ Claude): the state, whether they can change, a change, and each new state heard. */
  readonly settings: AgentSettings;
  /** A turn's number in its conversation (its prompt's place among the prompts), where a transcript shown holds it; else null. */
  turnNumber(turn: string): number | null;
  /** Is a turn of any conversation running, as the last list said? */
  running(): boolean;
  /** Told with each list the server pushes: whether any conversation's turn runs (studio mode's recovery hears a turn's end). Returns the undo. */
  onTurns(fn: (running: boolean) => void): () => void;
  /** The tab row's keys, for the host to register as MrDebug actions (`tabKeys`). */
  readonly tabs: {
    /** A new conversation, shown, the box focused. */
    create(): void;
    /** The shown one closed (asked first while it runs; the last one's is Clear). */
    close(): void;
    /** The next tab (1) or the one before (-1), round. */
    step(by: 1 | -1): void;
    /** The `n`th tab, from 1; none there, nothing. */
    show(n: number): void;
    /** A tab's title being typed: Enter keeps it, Esc lets it go. */
    renaming(): boolean;
    commitRename(): void;
    cancelRename(): void;
  };
  dispose(): void;
}

/** The agent's settings as the card has them (`AgentCard.settings`): the shown conversation's. */
export interface AgentSettings {
  state(): AgentState | null;
  /** The shown conversation's title: whose settings these are. */
  title(): string;
  /** The session up: they can be changed. */
  up(): boolean;
  /** `POST settings`, as the card's own pickers do. */
  set(request: SettingsRequest): void;
  /** Told after each draw of the card's: the state may have changed. Returns the undo. */
  on(fn: () => void): () => void;
}

/** How long a line the card says itself stays in its head, in milliseconds. */
const SAY_MS = 5000;

/** The host's key for the card (`editor.ts` registers it): the column shown, the box focused. */
export const FOCUS_KEY = tabKey('claude');
/** The host's AI key: the column shown, the box focused -- or hidden again (`setMinimized`). */
export const AI_KEY = tabKey('ai card');

/**
 * The tab row's keys (MrDebug's, the host registering them): Alt with a
 * letter, `]`/`[` or a digit -- Cmd+T, W, Tab and 1–9 are the browser's own.
 * On a Mac, Option gives these `KeyboardEvent.code`s as it gives any; typed
 * into the box, new, close, next and previous are the box's field keys too,
 * the digits not (Option+5 and 6 type [ and ] on some layouts).
 */
export const TAB_KEYS = { create: tabKey('claude new tab'), close: tabKey('claude close tab'), next: tabKey('claude next tab'), previous: tabKey('claude previous tab') } as const;

/** A tab's title, being typed: its field, for MrDebug's Enter and Esc. */
export const TAB_FIELD = 'agent-tab';

/**
 * This browser tab's own, in its `sessionStorage`: the conversation shown, each one's draft, and each one's last
 * result seen -- at the project's id (`projectKey`): conversations are its dev server's, and another project on the
 * same port shares the origin.
 */
const SHOWN_KEY = projectKey('vibebase.agent.shown');
const DRAFTS_KEY = projectKey('vibebase.agent.drafts');
const SEEN_KEY = projectKey('vibebase.agent.seen');
/** The `/btw` blocks dismissed in this browser tab, by id. */
const DISMISSED_KEY = projectKey('vibebase.agent.btw-dismissed');

/** A conversation as the card holds it: its calls, its push channel, its transcript, its state -- drawn only while shown. */
interface Pane {
  /** Null: the server's first, with no list to name it (another machine, a server that would not say). */
  readonly id: string | null;
  readonly api: AgentApi;
  readonly live: AgentLive;
  readonly transcript: Transcript;
  state: AgentState | null;
  entries: readonly Entry[];
  /** A send under way: no second one before the state says the first is running. */
  sending: boolean;
  /** The next state is the one that came with a whole log: cards it no longer waits on grey. */
  wholeLog: boolean;
  /** When Stop last became Send again at a turn's end (`goClick`'s guard). */
  turned: number;
  /** When the person's words last turned the button from Send (a card's own command) back into Stop (`goClick`'s guard). */
  wordsStopped: number;
  /** What the button was last drawn as for this conversation (`drawGo`). */
  goWas: 'send' | 'stop' | 'own';
  /** Images on the box while another tab was shown. */
  images: TurnImage[];
  readonly offs: (() => void)[];
}

/** A map kept in `sessionStorage`, read; anything else, empty. */
function readMap(key: string): Map<string, unknown> {
  try {
    const data = JSON.parse(sessionStorage.getItem(key) ?? 'null') as unknown;
    return typeof data === 'object' && data !== null && !Array.isArray(data) ? new Map(Object.entries(data)) : new Map();
  } catch {
    return new Map();
  }
}

function keepMap(key: string, map: ReadonlyMap<string, unknown>): void {
  try {
    sessionStorage.setItem(key, JSON.stringify(Object.fromEntries(map)));
  } catch {
    // Full or blocked: this reload forgets it.
  }
}


export function createAgentCard(host: AgentCardHost, options: { api?: AgentApi; hub?: Hub; tab?: TabHost } = {}): AgentCard {
  const dropSheet = addSheet(css);
  const api = options.api ?? createAgentApi();
  /** This tab's id: one per live tab, a duplicate's made anew -- and said again then. */
  const claim = claimTab(options.tab ?? pageTabHost());
  let tab = claim.id;
  /** The push channel every conversation shares, and the list of them. */
  // The project's own MCP tools, declared (no handler) in the hello: the page runs them (`host.tools.project`).
  const declared = (host.tools.project?.() ?? []).map(({ name, description, input, annotations }) => ({ name, description, input, ...(annotations ? { annotations } : {}) }));
  const hub = options.hub ?? createHub(api, undefined, tab, declared);
  /** The editor tools' half that runs here: each call relayed to this tab, and the edits it made -- those from before a reload too. */
  const tools = createPageTools(host.tools, readCarry(host.carried));
  let minimized = host.minimized ?? loadPrefs().agentMinimized;
  /** Set aside for a docked playtest (`setAside`): hidden, the preference untouched. */
  let aside = false;
  let said: { text: string; until: number; tone: 'bad' | 'idle' } | null = null;
  let timer: ReturnType<typeof setInterval> | undefined;
  /** Each conversation shown so far, by id ('' the server's first, with no list). */
  const panes = new Map<string, Pane>();
  /** Each conversation's draft, kept while another is shown -- the shown one's is the box's own. */
  const drafts = new Map([...readMap(DRAFTS_KEY)].filter((e): e is [string, string] => typeof e[1] === 'string'));
  /** What of each conversation was last seen here (its last result's `seq`, its terminal turn's end): a later one is marked (`attention.ts`). */
  const seen = new Map<string, Seen>();
  for (const [id, value] of readMap(SEEN_KEY)) {
    const was = readSeen(value);
    if (was) seen.set(id, was);
  }
  /** The conversations whose column terminal this page is opening again now (`reopenNow`'s `asking`), by id and the server's epoch. */
  const reopening = new Set<string>();
  /** The page's title without a mark (`titled`), and the one last set: another since (a scene's name) is the base from then on. */
  let baseTitle = document.title;
  let titleSet: string | null = null;
  /** The conversation shown: a pane is made before anything is drawn (`start`). */
  let cur: Pane;
  /** The `/btw` blocks dismissed in this browser tab: kept in its `sessionStorage`, so a reload leaves them gone. */
  const dismissedIds = new Set([...readMap(DISMISSED_KEY).keys()]);
  const dismissed = {
    has: (id: string) => dismissedIds.has(id),
    add(id: string) {
      dismissedIds.add(id);
      keepMap(DISMISSED_KEY, new Map([...dismissedIds].slice(-200).map((d) => [d, 1])));
    },
  };

  const root = el('div', 'ed-card ed-ag');

  // ---------------------------------------------------------------- the top row

  // The tabs (scrolling sideways), then the context used, the ⋯ menu and Hide, kept in view at the right.
  const top = el('div', 'ed-ag-top');
  const tabsRow = el('div', 'ed-ag-tabs');
  tabsRow.setAttribute('role', 'tablist');
  const plus = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-tab-new', '+'));
  plus.title = `A new conversation, with this one's settings (${keyLabel(TAB_KEYS.create)})`;
  /** A title being typed: its tab's id and its field. */
  let renamingTab: { id: string; input: HTMLInputElement } | null = null;
  const used = el('span', 'ed-ag-context');
  // Continue in terminal (Docs/terminal.md): the conversation handed to the claude CLI in a terminal in the column.
  const toTerminal = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-icon ed-ag-to-term'));
  toTerminal.append(icon('terminal'));
  toTerminal.title = 'Continue in terminal: this conversation in Claude Code\'s own CLI, here in the column -- Back to the column brings it back';
  // The ⋯ menu (D3): Clear, and Claude's settings in Config -- what the chip's popover has not.
  const more = letGo(control('ui', 'ed-ag-icon ed-ag-more', '⋯'));
  more.title = 'More: Clear this conversation, Claude\'s settings';
  more.setAttribute('aria-haspopup', 'menu');
  /** The ⋯ menu, made as it is first opened: its cards go in the editor's root, where the column is. */
  let menu: Menu | null = null;
  // Hide: the whole column out of the page (`setMinimized`), its room given back.
  const hide = letGo(control('ui', 'ed-ag-icon ed-ag-hide'));
  hide.title = `Hide Claude's column (${keyLabel(AI_KEY)} or the AI button brings it back)`;
  hide.append(icon('minimize'));
  hide.addEventListener('click', () => setMinimized(true));
  top.append(tabsRow, used, toTerminal, more, hide);

  // ---------------------------------------------------------------- the head line, over the box

  const head = el('div', 'ed-ag-head');
  const spin = el('span', 'ed-ag-spin');
  const time = el('span', 'ed-ag-clock');
  const status = el('span', 'ed-ag-status');
  const retry = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-link', 'Retry'));
  retry.title = 'Start Claude Code again: after a login, or whatever stopped it';
  const held = letGo(control('ui', 'ed-ag-held'));
  held.title = 'The code the turn changed reaches the page as one reload when the turn ends: this reloads now. The editor comes back as it is.';
  head.append(spin, time, status, retry, held);

  // ---------------------------------------------------------------- the transcript

  const body = el('div', 'ed-ag-body');
  const offTab = claim.on((id) => {
    tab = id;
    hub.setTab(id);
    for (const pane of panes.values()) pane.transcript.refresh();
  });

  // ---------------------------------------------------------------- the foot

  // Typed: the slash list, and the button -- Send for one of the card's own commands while a turn runs.
  const box = createPromptBox({
    say,
    resized: () => {},
    typed: () => {
      drawSlash();
      drawGo(true);
    },
  });

  // What goes with the next turn besides the words, while the tool up sends something (Docs/modeler.md M26): the model and
  // each canvas, one removable from this turn by its ×, and what will not go, said.
  const withLine = el('div', 'ed-ag-with');
  withLine.hidden = true;
  /** The line, drawn again from the tool up. */
  function drawWith(): void {
    const a = host.attachments?.() ?? null;
    if (!a) {
      withLine.hidden = true;
      withLine.replaceChildren();
      return;
    }
    const parts: (string | Node)[] = [el('span', 'ed-ag-with-head', 'With:'), el('span', 'ed-ag-with-subject', a.subject)];
    for (const c of a.canvases) {
      const chip = el('span', 'ed-ag-with-chip');
      chip.title = `${c.name}${c.note ? ', with its note' : ''}: its picture, camera and marks go with the turn -- × leaves it out of this one`;
      const x = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-with-x', '×'));
      x.title = `Leave ${c.name} out of this turn`;
      x.addEventListener('click', () => {
        a.skip(c.id, true);
        drawWith();
      });
      chip.append(el('span', undefined, c.name), x);
      parts.push(chip);
    }
    if (a.left.length > 0) {
      const left = el('span', 'ed-ag-with-left', `not sent: ${a.left.join('; ')}`);
      left.title = `Not sent: ${a.left.join('; ')} -- canvases that will not go with the turn, and why: the Canvases list in the Model tab shows them`;
      parts.push(left);
    }
    withLine.replaceChildren(...parts);
    withLine.hidden = false;
  }

  // ---------------------------------------------------------------- the slash list, over the box

  // `/` typed first (Docs/agent.md §4, "Slash commands"): the commands, filtered as the name is typed -- the card's own
  // and the CLI's. Its keys are MrDebug field actions (the host's), never a listener; a press on a row keeps the focus.
  const slashList = el('div', 'ed-card ed-ag-slash');
  slashList.setAttribute('role', 'listbox');
  slashList.setAttribute('aria-label', 'Slash commands');
  slashList.hidden = true;
  box.root.prepend(slashList);
  /** The rows shown, and the one Enter takes (the first unless walked). */
  let slashItems: SlashCommand[] = [];
  let slashSel = 0;
  /** Shut by Esc: open again with the next change of the words. */
  let slashShutFor: string | null = null;

  /** The list read again from the box: open while a `/` and a name are being typed in it, focused. */
  function drawSlash(): void {
    const query = box.focused ? slashAt(box.value, box.caret) : null;
    if (slashShutFor !== null && slashShutFor !== box.value) slashShutFor = null;
    const items = query === null || slashShutFor !== null ? [] : matchCommands(commandsOf(cur?.state?.commands), query);
    if (items.map((c) => c.name).join() !== slashItems.map((c) => c.name).join()) slashSel = 0;
    slashItems = items;
    slashList.hidden = items.length === 0;
    if (slashList.hidden) {
      slashList.replaceChildren();
      return;
    }
    slashList.replaceChildren(
      ...items.map((command, n) => {
        const row = control('ui', 'ed-ag-slash-item');
        row.setAttribute('role', 'option');
        row.setAttribute('aria-selected', String(n === slashSel));
        row.title = `/${command.name}${command.hint ? ` ${command.hint}` : ''}: ${command.description}${command.card ? '\nThe card does it here: nothing goes to Claude Code' : '\nSent to Claude Code as the prompt'}`;
        row.append(
          el('span', 'ed-ag-slash-name', `/${command.name}`),
          el('span', 'ed-ag-slash-hint', command.hint),
          el('span', 'ed-ag-slash-what', command.description),
        );
        if (command.card) row.classList.add('ed-ag-slash-own');
        // Pressed, the box keeps the focus: the list is the box's.
        row.addEventListener('pointerdown', (event) => event.preventDefault());
        row.addEventListener('click', () => {
          slashSel = n;
          slashKey('enter');
        });
        return row;
      }),
    );
    slashList.children[slashSel]?.scrollIntoView({ block: 'nearest' });
  }

  /** The list's keys (the host's MrDebug field actions, while it is open). */
  function slashKey(key: 'up' | 'down' | 'tab' | 'enter' | 'escape'): void {
    if (key === 'escape') {
      slashShutFor = box.value;
      return drawSlash();
    }
    if (key === 'up' || key === 'down') {
      slashSel = stepSelection(slashSel, slashItems.length, key === 'up' ? -1 : 1);
      return drawSlash();
    }
    const command = slashItems[slashSel];
    if (!command) return;
    box.value = completion(command, box.value);
    box.focus();
    drawSlash();
    drawGo(true);
    if (key === 'enter' && runsAtOnce(command)) void send();
  }

  // ---------------------------------------------------------------- the subagents strip, over the box

  // While a turn runs and after it, until the next (Docs/agent.md §4, "Subagents"): its subagents and background tasks
  // -- folded, "3 agents running"; unfolded, a row each, clicked to its calls in the transcript. `/agents` folds it.
  const strip = el('div', 'ed-ag-agents');
  strip.hidden = true;
  const stripHead = letGo(control('ui', 'ed-ag-agents-head'));
  stripHead.title = 'The subagents and background tasks of this turn (/agents)';
  const stripRows = el('div', 'ed-ag-agents-rows');
  strip.append(stripHead, stripRows);
  let stripOpen = false;
  stripHead.addEventListener('click', () => {
    stripOpen = !stripOpen;
    drawAgents();
  });

  function drawAgents(): void {
    const rows: readonly AgentRow[] = cur?.state?.agents ?? [];
    strip.hidden = rows.length === 0;
    if (strip.hidden) return;
    const now = Date.now();
    const running = rows.some((r) => r.state === 'running');
    stripHead.textContent = `${stripOpen ? '▾' : '▸'} ${agentsSummary(rows)}`;
    stripHead.setAttribute('aria-expanded', String(stripOpen));
    strip.classList.toggle('ed-ag-agents-running', running);
    stripRows.hidden = !stripOpen;
    if (!stripOpen) return;
    stripRows.replaceChildren(
      ...rows.map((r) => {
        const words = agentRowWords(r, now);
        const line = control('ui', `ed-ag-agent-row ed-ag-agent-${r.state}`);
        line.title = words.title;
        // Its type and what it is for in one line (cut at the column's edge), its state and numbers at the right.
        const who = el('span', 'ed-ag-agent-who');
        who.append(el('span', 'ed-ag-agent-name', words.name), el('span', 'ed-ag-agent-what', r.description ? ` · ${r.description}` : ''));
        // The first line its own, the type and what it is for; under it the state the dot does not show, the numbers and
        // what it did last.
        const under = el('span', 'ed-ag-agent-under');
        const plain = (r.state === 'running' && !r.background) || r.state === 'done';
        const said = plain ? words.meta : `${words.state} · ${words.meta}`;
        under.append(el('span', 'ed-ag-agent-meta', said));
        if (words.last) under.append(el('span', 'ed-ag-agent-last', words.last));
        line.append(el('span', 'ed-ag-agent-dot'), who, under);
        line.addEventListener('click', () => {
          if (!cur.transcript.reveal(r.id)) say(r.kind === 'agent' ? 'Its calls are not in the transcript shown (from before a reload, or past its 500 rows)' : 'A background task: its calls are its own', 'idle');
        });
        return line;
      }),
    );
  }

  /** `/agents`: the strip unfolded or folded -- or, with none, said so. */
  function toggleAgents(): void {
    if ((cur.state?.agents ?? []).length === 0) return say('No subagents or background tasks in this turn', 'idle');
    stripOpen = !stripOpen;
    drawAgents();
  }

  // ---------------------------------------------------------------- /usage

  /** The `/usage` card's body: its lines, each with a bar where it has a percent, and its note. */
  function usageBlock(usage: UsageFacts | undefined, live: boolean, asking: boolean): HTMLElement {
    const block = el('div', 'ed-ag-usage');
    block.append(el('div', 'ed-ag-usage-title', asking ? 'Usage · asking Claude Code…' : 'Usage'));
    const { rows, note } = usageRows(usage, Date.now(), live);
    for (const row of rows) {
      const line = el('div', `ed-ag-usage-row${row.tone ? ` ed-ag-usage-${row.tone}` : ''}`);
      line.title = row.title;
      line.append(el('span', 'ed-ag-usage-label', row.label), el('span', 'ed-ag-usage-value', row.value));
      if (row.bar !== null) {
        const meter = el('span', 'ed-ag-usage-bar');
        const fill = el('span', 'ed-ag-usage-fill');
        fill.style.width = `${Math.max(0, Math.min(100, row.bar))}%`;
        meter.append(fill);
        line.append(meter);
      }
      block.append(line);
    }
    if (note && !asking) block.append(el('div', 'ed-ag-usage-note', note));
    return block;
  }

  /** `/usage`: a card in the transcript -- what is known at once, then what Claude Code says now. Never a turn. */
  function showUsage(): void {
    const pane = cur;
    pane.transcript.aside('usage', usageBlock(pane.state?.usage, false, pane.live.unavailable === null && pane.state?.session === 'up'));
    if (pane.live.unavailable !== null || pane.state === null) return;
    pane.api.usage().then(
      (answer) => pane.transcript.aside('usage', usageBlock(answer.usage, answer.live, false)),
      (err: Error) => {
        pane.transcript.aside('usage', usageBlock(pane.state?.usage, false, false));
        say(err.message);
      },
    );
  }

  /** `/btw <question>`: asked of a copy of the conversation; its answer comes as an entry. A turn running goes on. */
  function askAside(text: string, question: string): void {
    const pane = cur;
    if (question === '') return say('Ask something: /btw <question>');
    if (pane.live.unavailable !== null || pane.state === null || !pane.state.available) return say(headLine(pane.state, pane.entries, page()).text);
    box.sent(text);
    pane.api.btw(question).catch((err: Error) => {
      say(err.message);
      if (pane === cur && box.value === '') box.value = text;
      if (pane === cur) drawGo();
    });
  }

  /** A box reading one of the card's own commands: done here, never sent. True: it was one. */
  function runOwn(text: string): boolean {
    const own = cardCommand(text);
    if (!own) return false;
    switch (own.command.name) {
      case 'usage':
        box.sent(text);
        showUsage();
        break;
      case 'btw':
        askAside(text, own.rest);
        break;
      case 'clear':
        if (!canClear) {
          say('Not now: Claude Code is not up, or a Stop is under way');
          break;
        }
        box.sent(text);
        asking(true);
        break;
      case 'agents':
        box.sent(text);
        toggleAgents();
        break;
    }
    drawGo();
    return true;
  }

  const bar = el('div', 'ed-ag-bar');
  // The settings chip (D4): the model, effort, level and bar in a line, its popover the pickers -- the server's
  // settings (`settings-picks.ts`), as Config ▸ Claude has them too.
  const picks_ = createSettingsPicks((request) => setting(request));
  // The chip only opens its popover: 'ui' (its pickers are `claude_settings`' but the level, which is the person's).
  const chip = letGo(control('ui', 'ed-ag-chip-settings'));
  chip.setAttribute('aria-haspopup', 'dialog');
  chip.setAttribute('aria-expanded', 'false');
  const chipText = el('span', 'ed-ag-chip-text');
  chip.append(chipText, el('span', 'ed-menu-more', '▴'));
  // `/usage` in a line, the session's and the week's: a click puts its card in the transcript.
  const usageLink = letGo(control('ui', 'ed-ag-link ed-ag-usage-line'));
  usageLink.title = 'The plan\'s limits, this conversation\'s cost and tokens, the context window: /usage';
  usageLink.addEventListener('click', () => {
    closePop();
    showUsage();
  });
  const pop = el('div', 'ed-card ed-ag-pop');
  pop.setAttribute('role', 'dialog');
  pop.setAttribute('aria-label', 'Claude\'s settings for this conversation');
  pop.hidden = true;
  /** A setting's row in the popover: its name, its picker. */
  const popRow = (name: string, control: HTMLElement): HTMLElement => {
    const line = el('label', 'ed-ag-pop-row');
    line.append(el('span', 'ed-ag-pop-name', name), control);
    return line;
  };
  pop.append(
    el('div', 'ed-ag-pop-title', 'This conversation'),
    popRow('Model', picks_.model),
    popRow('Effort', picks_.effort),
    popRow('Review', picks_.review),
    popRow('Permissions', picks_.level),
    popRow('Usage', usageLink),
  );
  // Attach view (`prompt-box.ts`): this tab's, an icon toggle, lit while on.
  const view = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-icon ed-ag-view'));
  view.append(icon('frame'));
  view.title = 'Attach view: a screenshot of the editor\'s view goes with each turn -- the grid, the selection\'s outline and the gizmo show which one "this" is. This tab only: off in a new one.';
  // Clear's second step, as Undo this turn's: said, then done or kept -- in the chip's place while it asks.
  const forget = el('span', 'ed-ag-confirm');
  forget.hidden = true;
  const forgetYes = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-danger', 'Clear'));
  forgetYes.title = 'Forget it: Claude Code starts a new conversation. The turns\' edits stay; Undo this turn goes.';
  const forgetNo = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-quiet', 'Keep'));
  forgetNo.title = 'Keep the conversation';
  forget.append(el('span', 'ed-ag-confirm-text', 'Forget this conversation?'), forgetYes, forgetNo);
  const go = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-button ed-small ed-accent ed-ag-send', 'Send'));
  bar.append(chip, forget, view, go);
  // The conversation in the terminal (Docs/terminal.md): in the transcript's and the foot's place while it is there.
  const shell = appShell();
  const terminalKeys: TerminalEvent = 'vibebase:agent:terminal';
  const termPane = createTerminalPane({
    state: () => cur.state?.terminal ?? null,
    screen: async () => {
      const kept = await cur.api.terminal();
      return { screen: kept.screen ?? '', end: kept.end ?? 0 };
    },
    send: (message) => {
      const conversation = cur.id ?? hub.list[0]?.id;
      if (conversation) import.meta.hot?.send(terminalKeys, { conversation, ...message });
    },
    back: async (force) => {
      const pane = cur;
      const asOf = pane.live.heard;
      pane.live.take((await pane.api.terminalClose({ ...(force ? { force: true } : {}), ...(hub.secret === null ? {} : { secret: hub.secret }) })).state, asOf);
    },
    ...(shell?.terminal ? { openOwn: () => openOwn(cur.state?.terminal?.command ?? '') } : {}),
    say,
  });
  root.append(top, body, termPane.root, head, strip, withLine, box.root, bar, pop);

  // ---------------------------------------------------------------- a conversation's pane

  /** A conversation's pane: its calls, its own push channel and its transcript, heard from now on. */
  function paneOf(id: string | null): Pane {
    const key = id ?? '';
    const had = panes.get(key);
    if (had) return had;
    const own = api.of(id);
    const live = createAgentLive(own, hub.channel(id), null);
    const pane: Pane = {
      id,
      api: own,
      live,
      transcript: createTranscript({
        input: (input) => own.input(input),
        answer: async (request) => {
          const asOf = live.heard;
          live.take(await own.answer(request), asOf);
        },
        rewind: (turn, dryRun, shown) => own.rewind(turn, dryRun, shown),
        reveal: async (path, turn) => {
          const done = await host.reveal(path, turn);
          say(done, 'idle');
          return done;
        },
        running: () => pane.state?.running != null,
        cardIn: (row) => {
          // Another tab's card: its tab says "needs you", and the playtest's pill; this one's, shown at once.
          if (pane !== cur) return badge();
          host.attention?.();
          setMinimized(false);
          row.scrollIntoView({ block: 'nearest' });
          badge();
        },
        // Answered with a click, the button greys and the focus falls to the page: the next letters would be the editor's keys.
        focusBox: () => {
          const at = document.activeElement;
          if (at === null || at === document.body || at.closest('.ed-ag-card')) box.focus();
        },
        editor: tools,
        tab: () => tab,
        dismissed,
      }),
      state: null,
      entries: [],
      sending: false,
      wholeLog: false,
      turned: 0,
      wordsStopped: 0,
      goWas: 'send',
      images: [],
      offs: [],
    };
    pane.offs.push(
      live.on('entries', (incoming, all) => {
        pane.transcript.add(incoming, all);
        pane.entries = pane.transcript.entries;
        if (all) pane.wholeLog = true;
        if (pane === cur) drawHead();
      }),
      live.on('state', (next) => {
        pane.state = next;
        if (pane.wholeLog) {
          pane.wholeLog = false;
          pane.transcript.pending(next.pending);
          // A card waiting as the page comes: the column shown, and the card brought into view (`setMinimized`).
          if (pane === cur && next.pending.length > 0 && pane.transcript.waiting()) setMinimized(false);
        }
        if (next.running) pane.sending = false;
        if (pane === cur) draw();
        else badge();
      }),
      live.on('delta', (d) => pane.transcript.delta(d)),
      live.on('terminal', (push) => pane === cur && termPane.heard(push)),
      live.on('offline', () => pane === cur && draw()),
      live.on('unavailable', () => pane === cur && draw()),
    );
    panes.set(key, pane);
    return pane;
  }

  /** A pane let go: its conversation closed. */
  function dropPane(key: string): void {
    const pane = panes.get(key);
    if (!pane) return;
    panes.delete(key);
    for (const off of pane.offs) off();
    pane.live.dispose();
    pane.transcript.dispose();
    pane.transcript.root.remove();
  }

  /** The conversation `id` shown: the draft and images of the one before kept, its own put in the box, its CLI started. */
  function show(id: string | null): void {
    const next = paneOf(id);
    if (cur === next) return;
    if (cur && cur.id !== null) {
      drafts.set(cur.id, box.value);
      cur.images = box.takeImages();
      keepMap(DRAFTS_KEY, drafts);
    }
    cancelRename();
    cur = next;
    box.value = drafts.get(next.id ?? '') ?? '';
    box.putImages(next.images);
    next.images = [];
    body.replaceChildren(next.transcript.root);
    asking(false);
    try {
      if (next.id !== null) sessionStorage.setItem(SHOWN_KEY, next.id);
    } catch {
      // A reload comes back on the first, then.
    }
    markSeen();
    next.live.start().catch((err: Error) => {
      say(`Claude Code could not be reached: ${err.message}`);
      draw();
    });
    if (!root.hidden) next.transcript.shown();
    draw();
  }

  /** The window has the focus, and is shown: a conversation can be looked at. */
  const focused = (): boolean => document.visibilityState === 'visible' && document.hasFocus();
  /** The conversation looked at now (`lookingAt`): the shown one, while the column is shown and the window has the focus. */
  const looking = (): string | null => lookingAt(cur?.id ?? null, root.hidden !== true, focused());

  /** The conversation looked at: what it did is seen, its marks go (Docs/ai-panel.md §8). Not looked at, kept as it was. */
  function markSeen(): void {
    const id = looking();
    const info = id === null ? undefined : hub.list.find((c) => c.id === id);
    if (!info) return;
    const now = seenOf(info);
    const was = seen.get(info.id);
    if (was && was.ended === now.ended && was.terminal === now.terminal) return;
    seen.set(info.id, now);
    keepMap(SEEN_KEY, seen);
  }

  // ---------------------------------------------------------------- the tab row drawn

  /** The tabs, from the list: each one's title, its state, its ×; the shown one marked. */
  function drawTabs(): void {
    const list = hub.list;
    tabsRow.hidden = list.length === 0;
    const rows: HTMLElement[] = list.map((info, n) => {
      const shown = info.id === cur?.id;
      const state = tabLook(info, seen.get(info.id), shown);
      const t = el('div', 'ed-ag-tab');
      t.dataset.state = state;
      t.classList.toggle('ed-ag-tab-on', shown);
      t.setAttribute('role', 'tab');
      t.setAttribute('aria-selected', String(shown));
      const dot = el('span', 'ed-ag-tab-dot');
      const label = renamingTab?.id === info.id ? renamingTab.input : el('span', 'ed-ag-tab-title', info.title);
      const why = { running: 'a turn running', waiting: info.waiting ? 'needs you: a card is waiting' : 'needs you: Claude Code asks in the terminal', done: 'a turn finished since you looked', failed: 'a turn ended in an error since you looked', idle: '' }[state];
      t.title = `${info.title}${why ? ` -- ${why}` : ''} (${(hasEditorKey(`claude tab ${n + 1}`) ? keyLabel(editorKeyOf(`claude tab ${n + 1}`)[0]!) : 'no key')}; double-click to rename)`;
      const x = letGo(control(NOT_FOR_CLAUDE.claudeControl, 'ed-ag-tab-x', '×'));
      x.title = list.length === 1 ? 'Clear this conversation -- asked first' : `Close this conversation${info.running ? ' -- its turn is stopped, asked first' : ''} (${keyLabel(TAB_KEYS.close)})`;
      x.addEventListener('click', (event) => {
        event.stopPropagation();
        closeTab(info.id);
      });
      // mcp: none: NOT_FOR_CLAUDE.claudeControl -- a conversation's tab, shown
      t.addEventListener('click', () => {
        if (renamingTab?.id !== info.id) show(info.id);
      });
      // mcp: none: NOT_FOR_CLAUDE.claudeControl -- a conversation's tab, renamed
      if (label instanceof HTMLSpanElement) label.addEventListener('dblclick', () => startRename(info.id));
      t.append(dot, label, x);
      return t;
    });
    tabsRow.replaceChildren(...rows, plus);
    // The waiting dot: the playtest's pill and the AI button say it as well.
    badge();
  }

  function startRename(id: string): void {
    const info = hub.list.find((c) => c.id === id);
    if (!info) return;
    const input = el('input', 'ed-input ed-ag-tab-input');
    input.value = info.title;
    input.dataset.keysField = TAB_FIELD;
    input.maxLength = 48;
    input.addEventListener('blur', () => commitRename());
    // mcp: ui -- the rename field keeps its own click
    input.addEventListener('click', (event) => event.stopPropagation());
    renamingTab = { id, input };
    drawTabs();
    input.focus();
    input.select();
  }

  function commitRename(): void {
    const r = renamingTab;
    if (!r) return;
    renamingTab = null;
    const title = r.input.value.trim();
    const was = hub.list.find((c) => c.id === r.id)?.title;
    drawTabs();
    if (title === '' || title === was) return;
    api.rename(r.id, title).then((answer) => hub.take(answer), (err: Error) => say(err.message));
  }

  function cancelRename(): void {
    if (!renamingTab) return;
    renamingTab = null;
    drawTabs();
  }

  /** A new conversation, with the shown one's settings: shown, the box focused. A seventh is refused, said. */
  function createTab(): void {
    api.create(cur.id).then(
      (answer) => {
        hub.take(answer);
        if (answer.conversation) show(answer.conversation);
        box.focus();
      },
      (err: Error) => say(err.message),
    );
  }

  /** A tab's close sent and not yet answered: × and Alt+W wait for it. */
  let closingTab = false;

  /** A tab's ×: running, asked first ("Stop and close?"); the last one is Clear, asked as Clear is. */
  function closeTab(id: string): void {
    const list = hub.list;
    const info = list.find((c) => c.id === id);
    if (!info) return;
    if (list.length <= 1) {
      if (cur.id !== id) show(id);
      asking(true);
      return;
    }
    // A close in flight: the list is about to change, and the last-one rule above would be read from the old one.
    if (closingTab) return;
    if (info.running) {
      showDialog({
        title: 'Stop and close?',
        text: `"${info.title}" is running a turn. Closing it stops the turn -- what it changed so far stays -- and forgets the conversation.`,
        buttons: [{ label: 'Stop and close', kind: 'danger', run: () => closeNow(id) }],
      });
      return;
    }
    // A turn ended in it: its Undo goes with it, so asked as Clear is. Never a turn: closed at once.
    if (info.ended === 0) return void closeNow(id);
    showDialog({
      title: 'Close and forget?',
      text: `Closing "${info.title}" forgets the conversation, and Undo this turn with it. What its turns changed stays.`,
      buttons: [{ label: 'Close', kind: 'danger', run: () => closeNow(id) }],
    });
  }

  function closeNow(id: string): void {
    if (closingTab) return;
    closingTab = true;
    // The list that comes back -- pushed, or the answer -- lets it go, its neighbour shown in its place.
    api.closeConversation(id).then(
      (answer) => {
        closingTab = false;
        drafts.delete(id);
        seen.delete(id);
        keepMap(DRAFTS_KEY, drafts);
        keepMap(SEEN_KEY, seen);
        hub.take(answer);
      },
      (err: Error) => {
        closingTab = false;
        say(err.message);
      },
    );
  }

  /** The tab `by` along, round. */
  function step(by: 1 | -1): void {
    const list = hub.list;
    if (list.length < 2) return;
    const at = list.findIndex((c) => c.id === cur.id);
    show(list[(at + by + list.length) % list.length]!.id);
  }

  // ---------------------------------------------------------------- saying things

  /** A line of the card's own in its head for a few seconds: a send refused, an image too big (`bad`); a path copied. */
  function say(text: string, tone: 'bad' | 'idle' = 'bad'): void {
    said = { text, until: Date.now() + SAY_MS, tone };
    drawHead();
    setTimeout(drawHead, SAY_MS + 50);
  }

  /**
   * Claude is waiting for you -- a card waits in any conversation -- said where the card is not seen: by the playtest's
   * pill while one runs (maximized, the column is hidden with every card), by the AI button's amber dot while it is hidden.
   */
  function badge(): void {
    const waiting = hub.list.some((c) => c.waiting) || (cur?.state?.pending.length ?? 0) > 0;
    // The pill only while a maximized playtest hides every card; docked, the column is live or set aside, and the AI button says it.
    host.badge(host.playing() && waiting ? 'Claude is waiting for you' : null);
    // The AI button's dot (Docs/ai-panel.md §8): the strongest mark of a conversation not looked at -- with no list (another
    // machine, before it came), the shown one's card waiting while the column is hidden, as before.
    const at = looking();
    const mark = hub.list.length > 0 ? buttonMark(hub.list, (id) => seen.get(id), at) : root.hidden === true && waiting ? 'waiting' : null;
    // Running: a turn of any conversation (Docs/ai-panel.md D8), the sparkle turning -- the terminal's too, as its hooks tell it.
    host.aiButton?.(!root.hidden, mark, hub.list.some((c) => c.running || c.terminalTurn === 'running') || cur?.state?.running != null);
    // The page's title, while the window is away (a browser's: the app keeps its windows' titles).
    if (titleSet !== null && document.title !== titleSet) baseTitle = document.title;
    const want = titled(baseTitle, mark, focused());
    if (document.title !== want) document.title = want;
    titleSet = document.title;
  }

  /** The window's focus come or gone: the conversation looked at is seen, and every mark drawn again. */
  const refocus = (): void => {
    markSeen();
    drawTabs();
  };
  window.addEventListener('focus', refocus);
  window.addEventListener('blur', refocus);
  document.addEventListener('visibilitychange', refocus);

  // ---------------------------------------------------------------- drawing the state

  function drawHead(): void {
    const state = cur.state;
    const line = headLine(state, cur.entries, page());
    const flash = said !== null && said.until > Date.now() ? said.text : null;
    const flashTone = said?.tone ?? 'bad';
    if (!flash) said = null;
    const run = state?.running ?? null;
    spin.hidden = run === null && state?.session !== 'starting';
    time.hidden = run === null;
    if (run) time.textContent = clock(Date.now() - run.startedAt);
    status.textContent = flash ?? line.text;
    status.title = flash ?? (line.next ? `${line.text}\n${line.next}` : line.text);
    head.dataset.tone = flash ? flashTone : line.tone;
    // A failure's next step: after its line, where there is room; whole in the title.
    if (!flash && line.next) status.textContent = `${line.text} ${line.next}`;
    retry.hidden = flash !== null || !line.retry;
    const files = state?.held.length ?? 0;
    held.hidden = files === 0;
    held.textContent = heldWords(files);
    held.title = `${state?.held.join(', ') ?? ''}\nThe code the turns changed reaches the page as one reload when the last running turn ends: this reloads now. The editor comes back as it is.`;
    const context = state?.context ?? null;
    used.hidden = context === null;
    if (context !== null) {
      used.textContent = contextWords(context);
      used.classList.toggle('ed-ag-full', context > 80);
      used.title = 'How much of the model\'s context window this conversation uses after its last turn';
    }
    // Nothing to say -- no turn, no failure, no code held, no bar's cost: no head row at all.
    head.hidden = spin.hidden && time.hidden && status.textContent === '' && retry.hidden && held.hidden;
  }

  function drawBar(): void {
    const s = cur.state;
    const up = isUp();
    const run = s?.running ?? null;
    picks_.draw(s, up);
    const words = chipWords(s);
    chipText.textContent = words.text;
    chip.title = words.title;
    chip.classList.toggle('ed-ag-unsafe', words.level === 'unsafe');
    chip.classList.toggle('ed-ag-on', s?.review.bars.find((b) => b.value === s.settings.review)?.score != null);
    drawGo();
    canClear = up && !(run?.stopping ?? false);
    forgetYes.disabled = !canClear;
  }

  /**
   * The button (Docs/agent.md §4): Send with no turn running; while one runs, Stop -- but for a box reading one of the
   * card's own commands done beside the turn (`/btw why?`, `/usage`, `/agents`; not `/clear`, which interrupts it),
   * where it is Send and runs it (`goMode`). Drawn with the bar and as the box's words change; `edited`: the person's
   * edit changed them (a command sent and the box emptied is not).
   */
  function drawGo(edited = false): void {
    const s = cur.state;
    const run = s?.running ?? null;
    const go_ = goMode(run !== null, box.value);
    const mode = go_.mode;
    const stopping = run?.stopping ?? false;
    // Stop turning back into Send under a pointer on its way to Stop: a click just after is no Send.
    if (run === null && cur.goWas === 'stop') cur.turned = Date.now();
    // Send (a command) turning into Stop as the person's words changed: a click just after is no Stop.
    if (edited && mode === 'stop' && cur.goWas === 'own') cur.wordsStopped = Date.now();
    cur.goWas = mode;
    const own = go_.command?.name ?? null;
    go.textContent = mode === 'stop' ? (stopping ? 'Stopping…' : 'Stop') : 'Send';
    go.classList.toggle('ed-accent', mode !== 'stop');
    go.classList.toggle('ed-danger', mode === 'stop');
    // Not logged in: nothing a Send could do -- the head says what to do, and Retry.
    go.disabled = !isUp() || (mode === 'stop' && stopping) || (mode === 'send' && (cur.sending || s?.login != null));
    go.title =
      mode === 'stop' ? 'Stop the turn: what it changed so far stays'
      : own === 'btw' ? 'Ask /btw beside the turn running: it goes on (Enter)'
      : own !== null ? `/${own} here, beside the turn running: nothing stopped, nothing sent to Claude Code (Enter)`
      : 'Send the prompt, with what the editor shows (Enter)';
  }

  /** The 1 Hz timer: the head's clock and the subagents' times. */
  function tick(): void {
    drawHead();
    drawAgents();
  }

  /** Clear can be asked for: the session up, no Stop under way (the ⋯ menu's Clear). */
  let canClear = false;
  /** Those told after each draw: Config ▸ Claude's controls. */
  const drawn = new Set<() => void>();
  const isUp = (): boolean => cur.state !== null && cur.state.available && cur.live.unavailable === null;

  function draw(): void {
    // In the terminal (Docs/terminal.md): its pane in the transcript's and the foot's place; the column's again after.
    const away = cur.state?.terminal ?? null;
    root.classList.toggle('ed-ag-away', away !== null);
    termPane.draw(cur.id);
    reopenTerminal();
    toTerminal.disabled = away !== null || (cur.state?.running ?? null) !== null || cur.state === null;
    toTerminal.title = away !== null ? 'This conversation is in the terminal: Back to the column (over it) brings it back' : cur.state?.running ? 'A turn is running: Stop it, or wait for its end, then continue in the terminal' : 'Continue in terminal: this conversation in Claude Code\'s own CLI, here in the column -- Back to the column brings it back';
    drawTabs();
    drawHead();
    drawBar();
    drawAgents();
    // The CLI's commands may have come with this state: the list, if open, has them.
    if (!slashList.hidden || box.value.startsWith('/')) drawSlash();
    usageLink.textContent = usageLine(cur.state?.usage, Date.now());
    badge();
    for (const fn of drawn) fn();
    // The clock, once a second, only while a turn runs -- or a subagent or background task does.
    const run = (cur.state?.running ?? null) !== null || (cur.state?.agents ?? []).some((r) => r.state === 'running');
    if (run && timer === undefined) timer = setInterval(tick, 1000);
    else if (!run && timer !== undefined) {
      clearInterval(timer);
      timer = undefined;
    }
  }

  // ---------------------------------------------------------------- what the server says

  /** The list as it was before the last one came: a closed tab's neighbours. */
  let known: readonly ConversationInfo[] = [];
  /** Those told whether any turn runs, with each list. */
  const turnsHeard = new Set<(running: boolean) => void>();
  const offs = [
    hub.on('list', (list) => {
      const any = list.some((c) => c.running);
      for (const fn of turnsHeard) fn(any);
      // A conversation new to this page: seen as it is; one gone (closed in another browser tab): let go, the first shown if it was this.
      for (const info of list) if (!seen.has(info.id)) seen.set(info.id, seenOf(info));
      if (cur?.id === null && list.length > 0) {
        known = list;
        return firstShow(list);
      }
      for (const key of [...panes.keys()]) if (key !== '' && !list.some((c) => c.id === key)) {
        // The shown one closed: its neighbour in its place -- the one after it, else the one before.
        if (cur?.id === key) {
          const at = known.findIndex((c) => c.id === key);
          const near = [...known.slice(at + 1), ...known.slice(0, Math.max(0, at)).reverse()].find((c) => list.some((l) => l.id === c.id));
          show(near?.id ?? list[0]?.id ?? null);
        }
        dropPane(key);
      }
      known = list;
      if (cur) markSeen();
      drawTabs();
    }),
    // A studio page tool's call (Docs/mcp.md), relayed to this tab -- whichever conversation's turn: run now, answered -- an Apply
    // once its file is compiled. One no longer waited for (its deadline gone) is the server's 409.
    hub.on('mcp', (call) => {
      void Promise.resolve(tools.run(call)).then((answer) => api.mcpAnswer(answer)).catch(() => {});
    }),
  ];

  // ---------------------------------------------------------------- what the person does

  /** A call whose answer is the state: taken unless a push has said something newer meanwhile. */
  const stated = (pane: Pane, call: Promise<AgentState>): void => {
    const asOf = pane.live.heard;
    call.then((next) => pane.live.take(next, asOf), (err: Error) => {
      say(err.message);
      draw();
    });
  };
  // The page's secret with each change: the level and the outside clients' are taken from a page's socket, no curl's.
  const setting = (request: SettingsRequest): void => stated(cur, cur.api.settings(hub.secret === null ? request : { ...request, secret: hub.secret }));
  /** Attach view as the box has it: the icon lit while on. */
  function drawView(): void {
    view.setAttribute('aria-pressed', String(box.attachView));
    view.classList.toggle('ed-ag-lit', box.attachView);
  }
  view.addEventListener('click', () => {
    box.attachView = !box.attachView;
    drawView();
  });
  drawView();
  /** Clear's question on the foot's row, in the chip's place -- or the chip back. */
  function asking(on: boolean): void {
    if (on) closePop();
    chip.hidden = on;
    view.hidden = on;
    forget.hidden = !on;
  }
  forgetNo.addEventListener('click', () => asking(false));
  forgetYes.addEventListener('click', () => {
    asking(false);
    // A new conversation in this tab, untitled until its first prompt.
    stated(cur, cur.api.clear());
  });

  // ---------------------------------------------------------------- the terminal (Docs/terminal.md)

  /** The resume command on the clipboard, said. */
  function copyCommand(line: string): void {
    navigator.clipboard.writeText(line).then(() => say('The resume command is copied: paste it into a terminal', 'idle'), () => say('Not copied: the browser would not let it'));
  }
  /** The app runs the run's `resume.command` in Terminal.app (`window.squidwright.terminal`). */
  async function openOwn(line: string, file?: string): Promise<void> {
    const at = file ?? (await cur.api.terminal()).file;
    if (!shell?.terminal || !at) return copyCommand(line);
    await shell.terminal(at);
    say('Opened in Terminal.app: Back to the column when you are done there', 'idle');
  }
  /** Tries left to wait for the page's secret (the hello's answer) before a terminal is opened again, a conversation's own: 300 ms apart. */
  const secretWaits = new Map<string, number>();
  /**
   * The column's terminal opened again by itself (Docs/terminal.md D12): the conversation shown was in it when the dev
   * server went, and the column is shown -- `POST terminal/open` resumes the same session there, as Back and Continue
   * would by hand. Once a server process: the server marks the attempt (`tried`), so a reload after a refusal neither
   * tries nor says it again; a refusal is said, and the pane offers Back.
   */
  function reopenTerminal(): void {
    const pane = cur;
    const state = pane.state;
    const key = `${pane.id ?? ''} ${state?.epoch ?? ''}`;
    if (!reopenNow(state?.terminal ?? null, root.hidden !== true, reopening.has(key))) return;
    // The secret comes with the hello's answer: a moment after the page.
    if (hub.secret === null) {
      const left = secretWaits.get(key) ?? 20;
      secretWaits.set(key, left - 1);
      if (left > 0) setTimeout(() => pane === cur && reopenTerminal(), 300);
      return;
    }
    reopening.add(key);
    termPane.starting(true);
    const asOf = pane.live.heard;
    pane.api.terminalOpen({ where: 'column', secret: hub.secret }).then(
      (answer) => {
        reopening.delete(key);
        termPane.starting(false);
        termPane.restart();
        pane.live.take(answer.state, asOf);
        if (pane === cur) say('Claude Code resumed in the terminal, as the dev server left it', 'idle');
      },
      (err: Error) => {
        // Kept: not asked again by this page. The server marked the attempt (`tried`): its next state says so, and no reload tries again.
        termPane.starting(false);
        if (pane === cur) draw();
        say(`Claude Code did not start again in the terminal: ${err.message}`);
      },
    );
  }

  /** Continue in terminal: here in the column, or the person's own (copied, or Terminal.app in the app). */
  async function openTerminal(where: 'column' | 'own'): Promise<void> {
    const pane = cur;
    const asOf = pane.live.heard;
    try {
      const answer = await pane.api.terminalOpen({ where, ...(hub.secret === null ? {} : { secret: hub.secret }) });
      pane.live.take(answer.state, asOf);
      if (where === 'own') await openOwn(answer.state.terminal?.command ?? '', answer.file);
      else termPane.focus();
    } catch (err) {
      say((err as Error).message);
    }
  }
  toTerminal.addEventListener('click', () => void openTerminal('column'));

  // ---------------------------------------------------------------- the chip's popover, and the ⋯ menu

  /** A press anywhere but the popover and its chip closes it -- capturing, so it is heard before what the press is for. */
  const outside = (event: PointerEvent): void => {
    const target = event.target as Node | null;
    if (target && (pop.contains(target) || chip.contains(target))) return;
    closePop();
  };
  function openPop(): void {
    if (!pop.hidden) return;
    pop.hidden = false;
    chip.setAttribute('aria-expanded', 'true');
    document.addEventListener('pointerdown', outside, true);
  }
  function closePop(): void {
    if (pop.hidden) return;
    pop.hidden = true;
    chip.setAttribute('aria-expanded', 'false');
    document.removeEventListener('pointerdown', outside, true);
  }
  chip.addEventListener('click', () => (pop.hidden ? openPop() : closePop()));
  more.addEventListener('click', () => {
    menu ??= createMenu(root.parentElement ?? document.body, host.canvas);
    if (menu.open) return menu.close();
    const away = cur.state?.terminal ?? null;
    const busy = (cur.state?.running ?? null) !== null;
    menu.show(more, [
      ...(away === null
        ? [
            {
              label: 'Continue in terminal',
              mcp: NOT_FOR_CLAUDE.claudeControl,
              title: busy ? 'Not while a turn runs: Stop it, or wait for its end' : 'This conversation in Claude Code\'s own CLI, in a terminal here in the column; Back to the column brings it back',
              run: () => (busy ? say('Not while a turn runs: Stop it, or wait for its end') : void openTerminal('column')),
            },
            {
              label: shell?.terminal ? 'Open in Terminal.app' : 'Copy resume command',
              mcp: NOT_FOR_CLAUDE.claudeControl,
              title: busy ? 'Not while a turn runs: Stop it, or wait for its end' : shell?.terminal ? 'This conversation in Claude Code in Terminal.app, with the studio\'s tools and context; Back to the column brings it back' : 'This conversation handed to a terminal of your own: the command that resumes it, with the studio\'s tools and context, copied',
              run: () => (busy ? say('Not while a turn runs: Stop it, or wait for its end') : void openTerminal('own')),
            },
          ]
        : [
            {
              label: 'Back to the column',
              mcp: NOT_FOR_CLAUDE.claudeControl,
              title: 'End Claude Code in the terminal and go on here: the turns made there are shown, and the conversation remembers them',
              run: () => void termPane.back(),
            },
            {
              label: 'Copy resume command',
              mcp: NOT_FOR_CLAUDE.claudeControl,
              title: 'The command that resumes this conversation in a terminal, with the studio\'s tools and context',
              run: () => copyCommand(away.command),
            },
          ]),
      {
        label: 'Clear…',
        mcp: NOT_FOR_CLAUDE.claudeControl,
        rule: true,
        title: canClear ? 'Forget this conversation and start a new one in its tab -- asked first. The turns\' edits stay; Undo this turn goes with the conversation.' : 'Not now: Claude Code is not up, or a Stop is under way',
        danger: true,
        run: () => {
          if (canClear) asking(true);
          else say('Not now: Claude Code is not up, or a Stop is under way');
        },
      },
      ...(host.settingsPage ? [{ label: 'Claude\'s settings…', mcp: 'ui' as const, title: 'Config ▸ Claude ▸ Settings: these and the project\'s own -- Fix a failed boot, Outside clients', rule: true, run: () => host.settingsPage?.() }] : []),
    ]);
  });
  go.addEventListener('click', () => {
    const now = Date.now();
    switch (goClick(goMode((cur.state?.running ?? null) !== null, box.value).mode, now - cur.turned, now - cur.wordsStopped)) {
      case 'stop':
        stated(cur, cur.api.stop());
        break;
      case 'words':
        say('The box no longer reads a command: nothing stopped, nothing sent');
        break;
      case 'turned':
        say('The turn had ended: nothing stopped, nothing sent');
        break;
      case 'send':
        // Send, or one of the card's own commands while a turn runs (`send` does those first).
        void send();
        break;
    }
  });
  retry.addEventListener('click', () => {
    cur.live.retry().catch((err: Error) => say(err.message));
  });
  held.addEventListener('click', () => {
    api.reload().catch((err: Error) => say(err.message));
  });
  plus.addEventListener('click', () => createTab());
  // A click on the head, or on an empty part of the card, is the box's: the next letters typed go in it, not to the editor's keys.
  // mcp: ui -- the prompt box focused
  root.addEventListener('click', (event) => {
    const target = event.target as Element | null;
    if (!target || target.closest('button, a, input, select, textarea, summary, label, .ed-ag-e, .ed-grip, .ed-ag-menu, .ed-ag-tab, .ed-ag-pop, .ed-ag-term')) return;
    // Words selected to copy stay selected.
    if ((getSelection()?.toString() ?? '') !== '') return;
    box.focus();
  });

  /**
   * A quick prompt's words and target (`Mod+K`) as one turn of the shown conversation, with its settings and the
   * editor's context -- the Model tab's model facts too, but no images -- the column's box untouched. Refused as Send is: a turn running, Claude Code not up or
   * not logged in.
   */
  async function quickSend(text: string, target: TurnTarget | null): Promise<{ conversation: string | null; ended: number }> {
    const pane = cur;
    const state = pane.state;
    if (state?.running || pane.sending) throw new Error('A turn is running: Stop first');
    if (pane.live.unavailable !== null || state === null || !state.available) throw new Error(headLine(state, pane.entries, page()).text);
    if (state.login) throw new Error(`${state.login.text} ${state.login.next}`);
    if (text.trim() === '') throw new Error('Say what to do');
    const ended = hub.list.find((c) => c.id === pane.id)?.ended ?? 0;
    pane.sending = true;
    drawBar();
    try {
      const context = host.context();
      context.target = target;
      // The tool up's model facts (the Model tab's build, parameters set, pose, trace) as the column's turn has them --
      // but no images: a quick prompt is words about a target, and its canvases stay for the column's next turn.
      const attached = host.attachments?.() ?? null;
      if (attached) context.model = (await attached.gather(0, 0)).model;
      await pane.api.turn({ prompt: text, context, images: [], tab });
    } catch (err) {
      pane.sending = false;
      if (pane === cur) drawBar();
      throw err instanceof Error ? new Error(err.message.replace(/^a turn is running/, 'A turn is running')) : err;
    }
    if (pane === cur) drawBar();
    return { conversation: pane.id, ended };
  }

  /** The box's words, its images and -- ticked -- the view, with the editor's context, as one turn of the shown conversation. */
  async function send(): Promise<void> {
    // The card's own commands first -- /usage, /btw, /clear, /agents -- a turn running or not: never sent.
    if (runOwn(box.value)) return;
    const pane = cur;
    const state = pane.state;
    if (state?.running) return say('A turn is running: Stop first');
    if (pane.sending) return;
    if (pane.live.unavailable !== null || state === null || !state.available) return say(headLine(state, pane.entries, page()).text);
    if (state.login) return say(`${state.login.text} ${state.login.next}`);
    const text = box.value;
    const attached = host.attachments?.() ?? null;
    // A canvas's note is the person's words beside the drawing they are about: a turn of its own (D80).
    const noted = attached?.canvases.some((c) => c.note) ?? false;
    if (text.trim() === '' && box.images.length === 0 && !noted) {
      if (attached && attached.canvases.length > 0) say('Say what to do -- in the box, or in a canvas\'s note');
      return;
    }
    pane.sending = true;
    drawBar();
    const theirs = box.takeImages();
    const images: TurnImage[] = [];
    try {
      const context = host.context();
      // The canvases first: they are what the turn is about; the box's images and the view after, in what room is left.
      if (attached) {
        const got = await attached.gather(0, IMAGES_MAX - Math.min(theirs.length, IMAGES_MAX - 1));
        context.model = got.model;
        images.push(...got.images);
      }
      for (const image of theirs) {
        if (images.length < IMAGES_MAX) images.push(image);
        else say(`At most ${IMAGES_MAX} images a turn: ${image.name} did not go`);
      }
      if (box.attachView) {
        if (images.length >= IMAGES_MAX) say(`At most ${IMAGES_MAX} images a turn: the view did not go`);
        else images.push(await shoot(host.draw, host.canvas));
      }
      box.sent(text);
      await pane.api.turn({ prompt: text, context, images, tab });
      attached?.sent();
      drawWith();
    } catch (err) {
      // Refused -- a turn running, the CLI not up: the words and the images kept, nothing queued.
      pane.sending = false;
      if (pane === cur) {
        if (box.value === '') box.value = text;
        box.putImages(theirs);
      } else drafts.set(pane.id ?? '', text);
      say(err instanceof Error ? err.message.replace(/^a turn is running/, 'A turn is running') : String(err));
    }
    if (pane === cur) drawBar();
  }

  // ---------------------------------------------------------------- shown or hidden

  /**
   * Hidden: the column out of the page, nothing of it drawn, its room given back -- a focus in it let go of, so no key
   * lands in a box out of sight, its popover and menu closed. Shown: the newest in view, or the card waiting. Kept with
   * the preferences; the host measures the room again (`resized`).
   */
  function setMinimized(next: boolean): void {
    if (next !== minimized) {
      minimized = next;
      keepPref('agentMinimized', minimized);
    }
    // Shown by the person or by a card waiting: no longer set aside either.
    if (!next) aside = false;
    applyHidden();
  }

  /** Set aside, or back as the person left it (Docs/ai-panel.md D5): never kept. */
  function setAside(next: boolean): void {
    if (next === aside) return;
    aside = next;
    applyHidden();
  }

  /** Hidden while minimized or set aside: what goes with it, and the room measured again. */
  function applyHidden(): void {
    root.hidden = minimized || aside;
    if (root.hidden) {
      closePop();
      menu?.close();
      const at = document.activeElement;
      if (at instanceof HTMLElement && root.contains(at)) at.blur();
    } else cur?.transcript.shown();
    host.resized();
    // Shown: the conversation is looked at again, its marks seen; then the AI button lit or not, and its dot.
    markSeen();
    if (cur) drawTabs();
    else badge();
    // The column's terminal of a conversation shown after a restart: opened again now it can be seen (D12).
    if (cur) reopenTerminal();
  }

  /** What the head's line knows of the page: another machine, the server away, and the address that works. */
  function page(): { unavailable: string | null; offline: boolean; home: string } {
    return { unavailable: cur.live.unavailable, offline: cur.live.offline, home: `${location.protocol}//localhost${location.port ? `:${location.port}` : ''}/` };
  }

  /** The column shown again (the editor opened, a playtest over): the card waiting -- or the newest, unless scrolled up -- in view. */
  function shown(): void {
    badge();
    if (!root.hidden) cur.transcript.shown();
  }

  // The server's first, until the list says which: then the one this browser tab showed last, if it is still open.
  cur = paneOf(null);
  body.replaceChildren(cur.transcript.root);
  setMinimized(minimized);
  draw();
  void hub.start().then((list) => {
    if (list === null || list.length === 0) {
      // No list -- another machine, a server that would not say: the server's first, as one conversation alone was.
      cur.live.start().catch((err: Error) => {
        say(`Claude Code could not be reached: ${err.message}`);
        draw();
      });
      return;
    }
    if (cur.id === null) firstShow(list);
  });

  /**
   * The list come: the conversation this browser tab showed last, if it is
   * still open, else the first -- the box's draft its -- in place of the
   * server's first, shown until the list said which.
   */
  function firstShow(list: readonly ConversationInfo[]): void {
    let wanted: string | null = null;
    try {
      wanted = sessionStorage.getItem(SHOWN_KEY);
    } catch {
      // The first, then.
    }
    const first = list.find((c) => c.id === wanted) ?? list[0]!;
    drafts.set(first.id, box.value);
    show(first.id);
    dropPane('');
  }

  return {
    root,
    settings: {
      state: () => cur.state,
      title: () => hub.list.find((c) => c.id === cur.id)?.title ?? 'this conversation',
      up: isUp,
      set: (request) => setting(request),
      on(fn) {
        drawn.add(fn);
        return () => void drawn.delete(fn);
      },
    },
    get minimized() {
      return minimized;
    },
    setMinimized,
    get hidden() {
      return root.hidden === true;
    },
    get aside() {
      return aside;
    },
    setAside,
    holdsEscape: () => (menu?.open ?? false) || !pop.hidden,
    cancel: () => {
      if (menu?.open) menu.close();
      else closePop();
    },
    menuStep: (by) => menu?.step(by),
    menuOpen: () => menu?.open ?? false,
    focusBox() {
      setMinimized(false);
      // In the terminal: its keys are the CLI's.
      if (cur.state?.terminal) termPane.focus();
      else box.focus();
    },
    prefill(text) {
      setMinimized(false);
      // Words of the person's already there are kept, after a line: nothing they typed is lost.
      box.value = box.value.trim() === '' ? text : `${box.value.replace(/\s+$/, '')}\n${text}`;
      box.focus();
      // News, not a warning: the idle tone.
      say('Written in the box for you to send -- or change, or clear', 'idle');
    },
    refreshWith: drawWith,
    quick: {
      send: quickSend,
      info: (id) => hub.list.find((c) => c.id === id) ?? null,
      title: () => hub.list.find((c) => c.id === cur.id)?.title ?? 'this conversation',
    },
    running: () => hub.list.some((c) => c.running),
    turnNumber(turn) {
      for (const pane of panes.values()) {
        let n = 0;
        for (const e of pane.entries) {
          if (e.kind !== 'prompt') continue;
          n++;
          if (e.turn === turn) return n;
        }
      }
      return null;
    },
    onTurns(fn) {
      turnsHeard.add(fn);
      return () => void turnsHeard.delete(fn);
    },
    keys: {
      send: () => void send(),
      slashOpen: () => !slashList.hidden,
      slash: slashKey,
      canRecall: (step) => box.canRecall(step),
      recall: (step) => {
        box.recall(step);
        drawGo(true);
      },
    },
    tabs: {
      create: createTab,
      close: () => {
        if (cur.id !== null) closeTab(cur.id);
      },
      step,
      show: (n) => {
        const info = hub.list[n - 1];
        if (info) show(info.id);
      },
      renaming: () => renamingTab !== null,
      commitRename,
      cancelRename,
    },
    keep: () => {
      box.keep();
      drafts.set(cur.id ?? '', box.value);
      keepMap(DRAFTS_KEY, drafts);
    },
    carry: () => tools.carry(),
    playtest: () => {
      badge();
      // Over: the column is back if a maximized playtest hid it -- a card that came meanwhile is brought into view.
      if (!host.playing()) shown();
    },
    shown,
    dispose() {
      clearInterval(timer);
      window.removeEventListener('focus', refocus);
      window.removeEventListener('blur', refocus);
      document.removeEventListener('visibilitychange', refocus);
      for (const off of offs) off();
      for (const key of [...panes.keys()]) dropPane(key);
      if (!options.hub) hub.dispose();
      tools.dispose();
      offTab();
      claim.dispose();
      box.dispose();
      closePop();
      menu?.dispose();
      termPane.dispose();
      root.remove();
      dropSheet();
    },
  };
}
