/**
 * The dev server's agent API (Docs/agent.md §2, "The routes", under
 * `/__agent/`) as typed calls, each answering the shape `api-types.ts` names
 * -- the file the server is written against, imported here as types only.
 *
 * - **From the page's own origin**: relative URLs, so the browser sends the
 *   `Origin` the server's guard checks against `Host`; a write is JSON.
 * - **A conversation's calls** carry its id (`?conversation=`): `of(id)` is
 *   the API bound to one, each card tab's; unbound, the server's first. The
 *   list's own calls -- `conversations`, `create`, `closeConversation`,
 *   `rename`, `order` -- and `reload`, the held reload every conversation
 *   shares, are no one conversation's.
 * - **A refusal is thrown** as `AgentRefused`, its status and the server's
 *   words (`{ refused }`): `409` "a turn is running: Stop first", `503` the CLI
 *   not up, `422` a body the server would not take. No answer at all is
 *   status 0.
 * - **A read from another machine** answers `{ available: false, why }`
 *   (`Unavailable`), a `200`: handed back as it is, for the card to say. A
 *   write from there -- `POST attach` first of all -- is a `403`, thrown like
 *   any refusal; `live.ts` takes it for the same answer.
 *
 * No DOM, no `import.meta`: a node test makes one with a stand-in `fetch`.
 */
import type {
  AgentState,
  AnswerRequest,
  BtwAnswer,
  ConversationsAnswer,
  McpAnswerRequest,
  NewSkillAnswer,
  RewindAnswer,
  SettingsRequest,
  SkillsAnswer,
  StateAnswer,
  TerminalAnswer,
  TerminalCloseRequest,
  TerminalOpenRequest,
  TurnAnswer,
  TurnRequest,
  Unavailable,
  UsageAnswer,
} from '@vibe/pipeline/agent-types';

/** Where the API is mounted on the dev server. */
export const AGENT_BASE = '/__agent/';

/** A call refused -- by the server, its status and words -- or never answered (status 0). */
export class AgentRefused extends Error {
  readonly status: number;
  constructor(status: number, refused: string) {
    super(refused);
    this.name = 'AgentRefused';
    this.status = status;
  }
}

export interface AgentApi {
  /**
   * `POST attach`: the session started if it is not up (the first attach);
   * `retry`, the Retry button, starts again one that failed or is not logged
   * in. The state, and the entries after `since`.
   */
  attach(since?: number, retry?: boolean): Promise<StateAnswer | Unavailable>;
  /** `GET state?since=`: the same, starting nothing. */
  state(since?: number): Promise<StateAnswer | Unavailable>;
  /** `POST turn`: one turn; its uuid. `409` while one runs or stops. */
  turn(request: TurnRequest): Promise<TurnAnswer>;
  /** `POST stop`: the turn interrupted; the state. */
  stop(): Promise<AgentState>;
  /** `POST clear`: a fresh conversation; the state. */
  clear(): Promise<AgentState>;
  /** `POST answer`: a card's answer; the state. `409` once it is settled. */
  answer(request: AnswerRequest): Promise<AgentState>;
  /** `POST settings`: the model, effort, review or Auto; the state. */
  settings(request: SettingsRequest): Promise<AgentState>;
  /**
   * `POST rewind`: what putting a turn's files back would do (`dryRun`), or
   * doing it -- `shown`, what the preview listed from the turn's snapshot, the
   * only files put back from it or removed. `409` while a turn runs.
   */
  rewind(turn: string, dryRun: boolean, shown?: { changed: string[]; made: string[] }): Promise<RewindAnswer>;
  /** `POST usage`: what `/usage` shows -- the CLI asked afresh where it is up, else as last heard. Never a turn. */
  usage(): Promise<UsageAnswer>;
  /** `POST btw`: a side question (`/btw`), its answer a `btw` entry by the id; `409` with no conversation yet. */
  btw(question: string): Promise<BtwAnswer>;
  /** `GET terminal`: the conversation's terminal state and the screen kept (Docs/terminal.md). */
  terminal(): Promise<TerminalAnswer>;
  /** `POST terminal/open`: continue in the terminal -- the column's, or the person's own; with the page's secret. */
  terminalOpen(request: TerminalOpenRequest): Promise<TerminalAnswer>;
  /** `POST terminal/close`: back to the column; `force` past a session written just now (`409` without it). */
  terminalClose(request: TerminalCloseRequest): Promise<TerminalAnswer>;
  /** `POST reload`: the code held for the turn, sent now. False with nothing held. */
  reload(): Promise<boolean>;
  /** `GET input?id=`: an `Edit` or `Write` call's whole input; `404` "not kept". */
  input(id: string): Promise<unknown>;
  /** `POST mcp/answer`: an editor tool's call, relayed to this tab, answered (`mcp/page.ts`). `409` once it is not waiting. */
  mcpAnswer(answer: McpAnswerRequest): Promise<void>;
  /** The conversation this API's calls act on; null, the server's first. */
  readonly conversation: string | null;
  /** The same API, its calls acting on conversation `id`. */
  of(id: string | null): AgentApi;
  /** `GET conversations`: the open ones, in order -- or, read from another machine, unavailable. */
  conversations(): Promise<ConversationsAnswer | Unavailable>;
  /** `POST conversations/new`: one more, with the settings of `from`; its id with the list. `409` past six. */
  create(from: string | null): Promise<ConversationsAnswer>;
  /** `POST conversations/close`: one closed -- its turn stopped, its folder gone; the last one cleared. */
  closeConversation(id: string): Promise<ConversationsAnswer>;
  /** `POST conversations/rename`. */
  rename(id: string, title: string): Promise<ConversationsAnswer>;
  /** `POST conversations/order`: every open id, once. */
  order(ids: readonly string[]): Promise<ConversationsAnswer>;
  /** `GET skills`: the project's, the plugin's and the person's own (Config ▸ Claude ▸ Skills) -- or, from another machine, unavailable. */
  skills(): Promise<SkillsAnswer | Unavailable>;
  /** `POST skills { name }`: `.claude/skills/<name>/SKILL.md` made from the template; `400` a bad name, `409` one there. */
  newSkill(name: string): Promise<NewSkillAnswer>;
}

export interface AgentApiOptions {
  /** The page's `fetch` by default. */
  fetch?: typeof fetch;
  /** The conversation the calls act on (`?conversation=`); none, the first. */
  conversation?: string | null;
}

/** What a failed answer says: the server's `refused`, or its status. */
function refusalOf(status: number, statusText: string, body: unknown): string {
  if (typeof body === 'object' && body !== null && typeof (body as { refused?: unknown }).refused === 'string') return (body as { refused: string }).refused;
  return status === 0 ? 'the dev server did not answer' : `the dev server answered ${status}${statusText ? ` ${statusText}` : ''}`;
}

export function createAgentApi(options: AgentApiOptions = {}): AgentApi {
  const doFetch = (input: string, init?: RequestInit): Promise<Response> => (options.fetch ?? fetch)(input, init);

  async function call<T>(method: 'GET' | 'POST', route: string, body?: unknown): Promise<T> {
    let res: Response;
    try {
      res = await doFetch(`${AGENT_BASE}${route}`, method === 'GET' ? undefined : { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body ?? {}) });
    } catch {
      throw new AgentRefused(0, refusalOf(0, '', undefined));
    }
    const text = await res.text();
    let parsed: unknown;
    try {
      parsed = text === '' ? {} : JSON.parse(text);
    } catch {
      parsed = undefined;
    }
    if (!res.ok) throw new AgentRefused(res.status, refusalOf(res.status, res.statusText, parsed));
    return parsed as T;
  }

  const conversation = options.conversation ?? null;
  /** A route of the conversation's: its id said, where it has one. */
  const of = (route: string, query = ''): string => {
    const params = conversation === null ? query : `${query}${query === '' ? '?' : '&'}conversation=${encodeURIComponent(conversation)}`;
    return `${route}${params}`;
  };
  const since = (n = 0): string => `?since=${Math.max(0, Math.floor(n))}`;

  return {
    conversation,
    of: (id) => createAgentApi({ ...options, conversation: id }),
    attach: (n, retry) => call('POST', of('attach', since(n)), retry ? { retry: true } : {}),
    state: (n) => call('GET', of('state', since(n))),
    turn: (request) => call('POST', of('turn'), request),
    stop: async () => (await call<{ state: AgentState }>('POST', of('stop'))).state,
    clear: async () => (await call<{ state: AgentState }>('POST', of('clear'))).state,
    answer: async (request) => (await call<{ state: AgentState }>('POST', of('answer'), request)).state,
    settings: async (request) => (await call<{ state: AgentState }>('POST', of('settings'), request)).state,
    rewind: (turn, dryRun, shown) => call('POST', of('rewind'), { turn, dryRun, ...shown }),
    usage: () => call('POST', of('usage')),
    btw: (question) => call('POST', of('btw'), { question }),
    terminal: () => call('GET', of('terminal')),
    terminalOpen: (request) => call('POST', of('terminal/open'), request),
    terminalClose: (request) => call('POST', of('terminal/close'), request),
    reload: async () => (await call<{ reloaded: boolean }>('POST', 'reload')).reloaded,
    input: async (id) => (await call<{ input: unknown }>('GET', of('input', `?id=${encodeURIComponent(id)}`))).input,
    mcpAnswer: async (answer) => void (await call('POST', 'mcp/answer', answer)),
    conversations: () => call('GET', 'conversations'),
    create: (from) => call('POST', 'conversations/new', from === null ? {} : { from }),
    closeConversation: (id) => call('POST', 'conversations/close', { id }),
    rename: (id, title) => call('POST', 'conversations/rename', { id, title }),
    order: (ids) => call('POST', 'conversations/order', { ids }),
    skills: () => call('GET', 'skills'),
    newSkill: (name) => call('POST', 'skills', { name }),
  };
}

/** A read from another machine, or one that will not say: no transcript here. */
export const isUnavailable = (answer: StateAnswer | ConversationsAnswer | SkillsAnswer | Unavailable): answer is Unavailable => 'available' in answer && answer.available === false;
