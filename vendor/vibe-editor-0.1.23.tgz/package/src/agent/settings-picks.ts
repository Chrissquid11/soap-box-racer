/**
 * The agent's server-side settings as controls (Docs/agent.md §4): Model,
 * Effort (hidden for a model with no levels), Review, the permission level --
 * Ask, Auto or Unsafe auto (Docs/mcp.md §7 D3), Unsafe in the danger colour --
 * the Fix a failed boot tick and what outside clients of `/__mcp` may do (Docs/mcp.md M7) -- drawn from the state (`draw`) and changed through
 * `POST settings` (`set`). The card's settings chip has one set in its popover (all but Fix a
 * failed boot and Outside clients, a setting too many there; `tick` is Config's alone now); Config ▸ Claude ▸ Settings
 * another, over the same state and the same call, so the two always agree.
 */
import type { AgentState, OutsideLevel, PermissionLevel, SettingsRequest } from '@vibe/pipeline/agent-types';
import { el } from '../shell.ts';

export interface SettingsPicks {
  readonly model: HTMLSelectElement;
  readonly effort: HTMLSelectElement;
  readonly review: HTMLSelectElement;
  /** The permission level: Ask, Auto, Unsafe auto. The person's alone -- no tool of Claude's sets it. */
  readonly level: HTMLSelectElement;
  /** Studio mode's recovery hands a failed boot to Claude (Docs/studio.md §1): Config's page alone shows it. */
  readonly fixBoot: { line: HTMLLabelElement; box: HTMLInputElement };
  /** What outside clients of the dev server's `/__mcp` may do (Docs/mcp.md M7): Config's page alone shows it. */
  readonly outside: HTMLSelectElement;
  /** Each control as the state says, off while the session is not `up`. */
  draw(state: AgentState | null, up: boolean): void;
}

/** The three levels, the pick's order. */
const LEVELS: readonly { value: PermissionLevel; label: string }[] = [
  { value: 'ask', label: 'Ask' },
  { value: 'auto', label: 'Auto' },
  { value: 'unsafe', label: 'Unsafe auto' },
];

/** What outside clients may do, the pick's order and words (`OUTSIDE_WORDS`, the server's). */
const OUTSIDE: readonly { value: OutsideLevel; label: string }[] = [
  { value: 'off', label: 'Off' },
  { value: 'read', label: 'Read-only' },
  { value: 'write', label: 'Read and write' },
  { value: 'destructive', label: 'Read, write and destructive' },
];

/** A tick with its label, its words on hover: Attach view, Fix a failed boot. */
export function tick(label: string, title: string): { line: HTMLLabelElement; box: HTMLInputElement } {
  const line = el('label', 'ed-ag-tick-line');
  const input = el('input', 'ed-check');
  input.type = 'checkbox';
  line.title = title;
  line.append(input, el('span', undefined, label));
  return { line, box: input };
}

/** `s`'s options as given, written only where they differ, and `value` chosen. */
function fill(s: HTMLSelectElement, options: readonly { value: string; label: string }[], value: string): void {
  const now = [...s.options].map((o) => `${o.value}\n${o.textContent}`).join('\n\n');
  const next = options.map((o) => `${o.value}\n${o.label}`).join('\n\n');
  if (now !== next) s.replaceChildren(...options.map((o) => {
    const option = el('option', undefined, o.label);
    option.value = o.value;
    return option;
  }));
  if (s.value !== value) s.value = value;
}

/** The controls, each change sent through `set` (`POST settings`): the state that answers draws them again. */
export function createSettingsPicks(set: (request: SettingsRequest) => void): SettingsPicks {
  const select = (cls: string, title: string): HTMLSelectElement => {
    const s = el('select', `ed-ag-select ${cls}`);
    s.title = title;
    return s;
  };
  const model = select('ed-ag-pick-model', 'Model: what Claude Code runs on, from its own list. Default is its own choice. Changed at once, mid-conversation too.');
  const effort = select('ed-ag-pick-effort', 'Effort: how hard the model may think -- only the levels this model reports. Changed at once.');
  const review = select('ed-ag-pick-review', '');
  const level = select('ed-ag-pick-level', '');
  fill(level, LEVELS.map((l) => ({ value: l.value, label: l.label })), 'auto');
  const autoTitle = (
    'Auto is a seatbelt against an agent\'s accidental damage, not a sandbox: a command whose code it cannot read can do anything, and a determined agent could get past it. Auto: allow every tool call no rule of yours asks about -- never one your own ask rules name, nor one outside the project -- but a plain read through the engine\'s own link, node_modules/@vibe/ -- nor git beyond reading, add, commit, rm, mv and a new branch in this project, nor a deletion it can read (a recursive rm of anything but a plain path in dist/, the caches or what git ignores -- never .trash/ or the conversations -- find -delete …). Those three -- the engine\'s link, git beyond reading, a recursive rm -- only on a plain line: literal words, no wrapper, variable, glob or $, no node, npm or npx, cd only to the project, the shell at the project\'s root; any other line asks. A card it does show says which of these made it. What it cannot read -- an interpreter\'s code, a script, npm run, make, your own aliases -- goes ahead unread and can do anything: these lists are no boundary, and Undo this turn puts back only the project\'s files and the engine\'s. Ask: each call that changes anything waits here as a card. Every level, nothing under .git/ or .claude/ is written unasked.'
  );
  const titles: Record<PermissionLevel, string> = {
    ask: 'Ask: every tool call that changes anything waits here as a card -- the studio\'s reads (studio_state, prefab_info …) go by, as they never change a thing. Pick Auto or Unsafe auto to let ordinary work go ahead.',
    auto: autoTitle,
    unsafe: 'Unsafe auto: Auto, plus everything Auto still asks about -- the studio\'s destructive tools, git push and git pull, git that discards work (reset, clean, stash, rebase, restore, checkout --, commit --amend), a script it cannot read (curl … | sh), a recursive delete of what the project holds (git-tracked files too), git on a line that is not plain. Only its floor still asks: a write under .git/ or .claude/, anything outside the project (but a read through the engine\'s own link) -- git pointed at another repository, a line after a cd away, a delete whose targets it cannot read -- and your own ask rules. Undo this turn puts back the project\'s files, not a push nor what git threw away. For a turn you trust whole.',
  };
  const fixBoot = tick(
    'Fix a failed boot',
    'Fix a failed boot: when the game cannot load in studio mode, Claude is sent the error and asked to fix it, in a conversation titled Recovery -- three tries, then it is yours. Every conversation\'s: the project\'s, not one conversation\'s.',
  );
  fixBoot.box.addEventListener('change', () => {
    fixBoot.box.blur();
    set({ fixBoot: fixBoot.box.checked });
  });
  const outside = select('ed-ag-pick-outside', 'Outside clients: what an MCP client outside this page -- a terminal Claude Code, another tool -- may do through the dev server\'s /__mcp endpoint, with the token vibe mcp prints. Off: nothing. Read-only (the default): the reads alone. Read and write: the edits too, each a step Z undoes (labelled MCP: …). Read, write and destructive: the destructive tools too -- deletes, git push and pull, discarding what nobody saved. Such a client asks its own person by its own rules; this is the studio\'s limit on it. The project\'s, every conversation\'s.');
  fill(outside, OUTSIDE, 'read');
  outside.addEventListener('change', () => {
    outside.blur();
    set({ outside: outside.value as OutsideLevel });
  });
  model.addEventListener('change', () => {
    model.blur();
    set({ model: model.value === 'default' ? null : model.value });
  });
  effort.addEventListener('change', () => {
    effort.blur();
    set({ effort: effort.value === '' ? null : effort.value });
  });
  review.addEventListener('change', () => {
    review.blur();
    set({ review: review.value as AgentState['settings']['review'] });
  });
  level.addEventListener('change', () => {
    level.blur();
    set({ level: level.value as PermissionLevel });
  });
  return {
    model,
    effort,
    review,
    level,
    fixBoot,
    outside,
    draw(s, up) {
      // Model: the CLI's list, flat -- "Default" until the session is up.
      const models = s?.models ?? [];
      const wanted = s?.settings.model ?? 'default';
      const options = models.length > 0 ? models.map((m) => ({ value: m.value, label: m.label })) : [{ value: 'default', label: 'Default' }];
      if (!options.some((o) => o.value === wanted)) options.push({ value: wanted, label: wanted });
      fill(model, options, wanted);
      model.disabled = !up;
      // Effort: the model's levels; none, no picker.
      const levels = models.find((m) => m.value === wanted)?.efforts ?? [];
      effort.hidden = levels.length === 0;
      fill(effort, [{ value: '', label: 'Effort: default' }, ...levels.map((l) => ({ value: l, label: `Effort: ${l}` }))], s?.settings.effort ?? '');
      effort.disabled = !up;
      // Review: the server's bar table.
      const bars = s?.review.bars ?? [{ value: 'none' as const, label: 'None', score: null }];
      fill(review, bars.map((b) => ({ value: b.value, label: b.score === null ? 'No review' : `Review: ${b.label} ${b.score}/10` })), s?.settings.review ?? 'none');
      review.disabled = !up || s?.review.available === false;
      const chosen = bars.find((b) => b.value === (s?.settings.review ?? 'none'));
      review.classList.toggle('ed-ag-on', chosen?.score != null);
      review.title = s?.review.available === false
        ? `Review is off: ${s.review.why ?? 'the critic did not load'}`
        : `Review: a separate critic (code-critic, the vibe plugin's) scores the result out of 10 -- does it do what was asked, is it right, is it the codebase's way -- and the agent works on until the bar is met or ${s?.review.max ?? 5} reviews are spent. From the next turn.`;
      const now = s?.settings.level ?? 'auto';
      fill(level, LEVELS.map((l) => ({ value: l.value, label: l.label })), now);
      level.disabled = !up;
      level.title = titles[now];
      // Unsafe auto in the danger colour: said in its border and words, as Review's bar is in the accent.
      level.classList.toggle('ed-ag-unsafe', now === 'unsafe');
      fixBoot.box.checked = s?.settings.fixBoot ?? true;
      fixBoot.box.disabled = !up;
      fill(outside, OUTSIDE, s?.settings.outside ?? 'read');
      outside.disabled = !up;
      outside.classList.toggle('ed-ag-unsafe', s?.settings.outside === 'destructive');
    },
  };
}
