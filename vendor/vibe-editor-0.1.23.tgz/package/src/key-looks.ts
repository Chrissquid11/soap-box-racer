/**
 * What a key of each kind looks like in a key picker, and a sound's play button (Docs/properties.md D6, Docs/ecs.md
 * §13) -- the page's `KeySources.look` and `play` (`key-field.ts` draws them):
 *
 * - **A picture**: a model's and a texture's thumbnail, the Assets panel's (through its one queue: made once, made
 *   again after a re-export); a prefab's, the thumbnail of the model its first drawn entity wears (its root first);
 *   an icon its own image.
 * - **A swatch**: a material's colour, as compiled.
 * - **A font**: its name drawn in itself -- the face loaded once (a `FontFace`), kept by key.
 * - **A glyph**: a scene, a level, an atlas, a data file -- the editor's own.
 * - **A sound** (`Sfx`, `UiSfx`, `Music`): played through the game's mixer (`Audio.preview`, on the ui bus) -- a
 *   sfx's or a ui sound's buffer as the game decoded it, a music track fetched from its built URL and decoded
 *   (`decodeSound`), only the last one kept. Never `new Audio()`. Stopped by the stop it returns; muted in the game's
 *   settings (`soundNote`), not played at all and said why.
 *
 * Cheap and cached: each look is made as a row or the field is drawn, never each frame. What it asks of the page
 * (`Assets`, `Audio`, a fetch, a `FontFace`) is handed in (`LookPage`), so node tests it (`key-looks.test.ts`).
 */
import { prefabFiles, refText, resolveRef, soundKind, splitModel, type PrefabFile } from '@vibe/engine';
import type { AudioPreview } from '@vibe/engine/assets';
import { NOTE_WORDS, soundNote, type Mixer } from './assets/preview/audio.ts';
import { kindGlyph, type KeyLook, type KeySources } from './key-field.ts';

/** A key's thumbnail by its kind's key type -- the Assets panel's (`EditorContext.modelThumb`). */
export type KeyThumb = (key: string, type?: 'Model' | 'Texture') => Promise<string | null>;


/**
 * The model a prefab is drawn as: its first entity's `Render.model` with a model -- the root first, a nested prefab's
 * own looked into (`files`, by key) -- its part dropped; null for none.
 */
export function prefabModel(file: PrefabFile | undefined, files: Readonly<Record<string, PrefabFile>> = {}, depth = 0): string | null {
  if (!file || !Array.isArray(file.entities) || depth > 8) return null;
  const drawn = (e: PrefabFile['entities'][number]): string | null => {
    const nested = (e as { prefab?: unknown }).prefab;
    if (nested !== undefined) {
      const key = resolveRef('prefabs', nested);
      return key === null ? null : prefabModel(files[key], files, depth + 1);
    }
    const text = refText((e as { data?: Record<string, Record<string, unknown>> }).data?.Render?.model);
    return text === '' ? null : splitModel(text).model;
  };
  const roots = file.entities.filter((e) => e.parent === null);
  for (const e of [...roots, ...file.entities]) {
    const model = drawn(e);
    if (model !== null) return model;
  }
  return null;
}

/** A colour as a swatch's: `#rrggbb`. */
const hexOf = (c: { getHexString(): string }): string => `#${c.getHexString()}`;

/**
 * What the looks ask of the page -- `Assets`, `Audio`, the built files -- handed in (the inspector's `pageLooks`), so
 * this module imports none of `@vibe/engine/assets` and node tests it with stand-ins (`key-looks.test.ts`).
 */
export interface LookPage {
  readonly assets: {
    fontUrl(key: string): string;
    iconUrl(key: string): string;
    /** A material file's compiled material, or null: its `color` the swatch. */
    materialIfPresent(key: string): { color?: { getHexString(): string } } | null;
  };
  /** The game's mixer (`Audio`): a decoded sound, a preview, and whether it would be heard (`soundNote`). */
  readonly audio: Pick<Mixer, 'preview' | 'isMuted' | 'running'> & { buffer(key: string): AudioBuffer | null };
  /** A built sound file of the registry kind `kind` (`music`) fetched and decoded; null for one that will not. */
  decode(kind: string, key: string): Promise<AudioBuffer | null>;
  /** A font file's face loaded (a `FontFace` added to the page): its family, or null (a bitmap font's layout). */
  loadFont(key: string, href: string): Promise<string | null>;
}

/** The page's looks and play, over `page` and the Assets panel's thumbnails (`thumb`, absent with no panel: pictures none). */
export function keyLooks(page: LookPage, thumb?: KeyThumb): Required<Pick<KeySources, 'look' | 'play'>> {
  const fonts = new Map<string, Promise<string | null>>();
  /** The one music track decoded, by kind and key: a three-minute track is some 70 MB decoded, so only the last is kept. */
  let track: { id: string; buffer: Promise<AudioBuffer | null> } | null = null;
  const picture = (promise: Promise<string | null> | undefined): KeyLook => ({ thumb: promise ?? Promise.resolve(null) });

  /** A font's face loaded once: its family, or null (a bitmap font's layout, or one that will not load). */
  const font = (key: string): Promise<string | null> => {
    let made = fonts.get(key);
    if (!made) {
      made = Promise.resolve()
        .then(() => {
          const href = page.assets.fontUrl(key);
          return /\.json(\?|$)/i.test(href) ? null : page.loadFont(key, href);
        })
        .catch(() => null);
      fonts.set(key, made);
    }
    return made;
  };

  /** A sound's buffer: the game's, else (a music track) its built file decoded -- the last one kept, the one before let go. */
  const sound = (kind: string, key: string): Promise<AudioBuffer | null> => {
    const decoded = page.audio.buffer(key);
    if (decoded) return Promise.resolve(decoded);
    const id = `${kind}\0${key}`;
    if (track?.id !== id) {
      const registry = soundKind(kind);
      track = { id, buffer: registry === undefined ? Promise.resolve(null) : page.decode(registry, key).catch(() => null) };
    }
    return track.buffer;
  };

  return {
    look(kind, key) {
      if (soundKind(kind) !== undefined) return null;
      switch (kind) {
        case 'Model':
          return picture(thumb?.(splitModel(key).model, 'Model'));
        case 'Texture':
          return picture(thumb?.(key, 'Texture'));
        case 'Prefab': {
          const files = prefabFiles();
          const model = prefabModel(files[key], files);
          return model === null ? { glyph: 'props' } : picture(thumb?.(model, 'Model'));
        }
        case 'Material': {
          const color = page.assets.materialIfPresent(key)?.color;
          return color ? { swatch: hexOf(color) } : null;
        }
        case 'Icon':
          try {
            return picture(Promise.resolve(page.assets.iconUrl(key)));
          } catch {
            return { glyph: kindGlyph(kind) };
          }
        case 'Font':
          return { font: font(key) };
        default:
          return { glyph: kindGlyph(kind) };
      }
    },
    play(kind, key, ended) {
      // Muted in the game's settings: nothing heard, so nothing played -- said on the button. Before the page's first
      // gesture the press itself is one (boot's listener unlocks the context ahead of this), so that plays on.
      if (soundNote(page.audio) === 'muted') return NOTE_WORDS.muted;
      let stopped = false;
      let playing: AudioPreview | null = null;
      let done: ReturnType<typeof setTimeout> | undefined;
      void sound(kind, key).then((buffer) => {
        if (stopped) return;
        if (!buffer) return ended();
        playing = page.audio.preview(buffer);
        // Its end, told once: the button put back. A preview has no end of its own to listen to; its length is known.
        done = setTimeout(() => {
          if (!stopped) ended();
        }, buffer.duration * 1000 + 60);
      });
      return () => {
        stopped = true;
        clearTimeout(done);
        playing?.stop();
      };
    },
  };
}
