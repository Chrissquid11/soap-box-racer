/**
 * An entity's name as the inspector's title writes it (`Name`, an object component): the one path every
 * rename takes -- the title's field, one entity or several, and the studio tools' `scene_rename` and
 * `scene_set` Name (Docs/mcp.md §2 rule 2). Pure ECS, no page: node tests it, and the tools run it.
 *
 * - **Trimmed**: what is typed is the name less the spaces around it; an empty one takes `Name` off.
 * - **Several, numbered**: one name typed for several is each its own, in the order given -- `wall`,
 *   `wall 2` (`numbered`).
 * - **No change, no step**: each says whether it wrote anything, so its caller makes a step only then.
 */
import { type Entity, Name, type World } from '@vibe/engine';
import { numbered } from './multi.ts';

const names = (world: World): (string | null)[] => (world.rawStore(Name) as { value: (string | null)[] }).value;

/** `e`'s name: "" for none. */
export const nameOf = (world: World, e: Entity): string => (world.has(e, Name) ? String(names(world)[e] ?? '') : '');

/** `e` named `text`, trimmed -- `Name` added if it has none, taken off for "": whether that changed it. */
export function setName(world: World, e: Entity, text: string): boolean {
  const name = text.trim();
  if (nameOf(world, e) === name) return false;
  if (!name) world.remove(e, Name);
  else if (world.has(e, Name)) names(world)[e] = name;
  else world.add(e, Name).value[e] = name;
  return true;
}

/** One name typed for several: each its own, numbered in `es`' order (`wall`, `wall 2`); "" takes every one's off. Whether any changed. */
export function renameAll(world: World, es: readonly Entity[], text: string): boolean {
  const name = text.trim();
  const want = name ? numbered(name, es.length) : es.map(() => '');
  if (es.every((e, i) => nameOf(world, e) === want[i])) return false;
  es.forEach((e, i) => setName(world, e, want[i]!));
  return true;
}
