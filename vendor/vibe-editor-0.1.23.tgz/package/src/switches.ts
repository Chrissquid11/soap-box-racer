/**
 * The switches every entity has (Docs/ecs.md §21), as the editor shows and
 * flips them: out of sight (`Hidden`: not drawn, still running), out of play
 * (`Disabled`: in no system and not drawn) and out of reach (`Unpickable`: not
 * picked in the scene, selected in the tree), each for the entity and
 * everything under it. Pure ECS, no page: node tests it.
 *
 * - **Each has a key**, Shift and a letter -- `H` is History and `E` the
 *   gizmo's turn -- that flips the whole selection as one step.
 * - **Who set it** is said wherever it shows (`causeOf`, `why`): an entity
 *   under a hidden one is hidden too, and its row says by whom.
 */
import { type AnyComponent, Disabled, Hidden, Hierarchy, label, NONE, Unpickable, type Entity, type Tag, type World } from '@vibe/engine';
import { tabKey } from './editor-keys.ts';

export type Switch = 'hidden' | 'disabled' | 'unpickable';

export interface SwitchSpec {
  tag: Tag;
  /** The key that flips the selection. */
  readonly key: string;
  /** The step that sets it, and the one that takes it off: `Hide 3`, `Show`. */
  set: string;
  unset: string;
  /** What it means, for a title: after "Hidden" or "Hidden by big crate". */
  means: string;
}

export const SWITCHES: Readonly<Record<Switch, SwitchSpec>> = {
  // The live keymap's (Docs/navigation.md §8: Ctrl+H under Industry Compatible, Shift+H under Blender), read as shown.
  hidden: { tag: Hidden, get key() { return tabKey('hide'); }, set: 'Hide', unset: 'Show', means: 'not drawn, still running' },
  disabled: { tag: Disabled, key: tabKey('switch off'), set: 'Disable', unset: 'Enable', means: 'in no system, not drawn' },
  unpickable: { tag: Unpickable, key: tabKey('lock picking'), set: 'Lock picking', unset: 'Unlock picking', means: 'not picked in the scene, selected in the tree' },
};

/** A switch's step for `n` at once: `Hide 3`, `Enable`. */
export const switchStep = (which: Switch, on: boolean, n: number): string => {
  const verb = on ? SWITCHES[which].set : SWITCHES[which].unset;
  return n > 1 ? `${verb} ${n}` : verb;
};

/** Whoever puts `e` under `tag`: itself, or the nearest ancestor that has it; NONE if nobody does. */
export function causeOf(world: World, e: Entity, tag: Tag): Entity {
  const parent = world.store(Hierarchy).parent;
  for (let a = e; a !== NONE; a = parent[a]! as Entity) if (world.has(a, tag)) return a;
  return NONE;
}

/**
 * Is `e` under the switch, itself or by an ancestor? Hidden and switched off as
 * the world has it worked out; unpickable by a walk up the tree, the editor's.
 */
export const isOut = (world: World, e: Entity, which: Switch): boolean =>
  which === 'hidden' ? !world.seenEntity(e) : which === 'disabled' ? !world.active(e) : causeOf(world, e, Unpickable) !== NONE;

/** Can a click or a box in the scene pick `e`: drawn, and not locked, itself or above? */
export const pickable = (world: World, e: Entity): boolean => !isOut(world, e, 'hidden') && !isOut(world, e, 'disabled') && !isOut(world, e, 'unpickable');

/**
 * Why `e` is out of sight or out of play, as a title says it -- `Hidden by big
 * crate: not drawn, still running` -- or '' if it is neither.
 */
export function why(world: World, e: Entity): string {
  const said: string[] = [];
  for (const which of ['disabled', 'hidden', 'unpickable'] as const) {
    if (!isOut(world, e, which)) continue;
    const by = causeOf(world, e, SWITCHES[which].tag);
    const name = which === 'hidden' ? 'Hidden' : which === 'disabled' ? 'Switched off' : 'Unpickable';
    said.push(`${name}${by !== NONE && by !== e ? ` by ${label(world, by)}` : ''}: ${SWITCHES[which].means}`);
  }
  return said.join(' · ');
}

/** The tags a game defines: its `tag()`s, but `Hidden`, `Disabled` and `Unpickable`, which are switches of their own. */
export const tagsOf = (world: World): AnyComponent[] =>
  world.allComponents.filter((c) => c.kind === 'tag' && c.bit >= 0 && c !== Hidden && c !== Disabled && c !== Unpickable);
