/**
 * The inspector's Transform block -- position, rotation in degrees, scale, a
 * row each of x y z -- shown in the parent's space or the world's, one switch
 * for all three rows. A typed or scrubbed axis is the step a gizmo drag of it
 * is: Move, Rotate, Scale.
 *
 * - **The angles are the editor's own**, kept per entity with the rotation they
 *   were for: a quaternion turned back into angles can give another three for
 *   the same rotation, and typing one axis must leave the other two as shown.
 *   Local and world angles are kept apart.
 * - **World** (the Local/World toggle, kept with the preferences) reads
 *   `WorldTransform` and writes back into the local `Transform` as the
 *   gizmo's drags do, in the parent's space and never through a round trip
 *   of the world (`worldAxisLocal`, `worldTurnLocal`, `worldScaleLocal`, `parentPoseOf`): a world
 *   axis typed moves the local position by that axis's change alone, seen
 *   from the parent; a world angle writes the rotation alone, by the turn it
 *   makes; a world scale the scale alone, by its factor. What the change does
 *   not move stays as it was, to the bit -- no float noise, near the origin or far out
 *   (an instance would show each bit as an override). `WorldTransform` is
 *   never written: the world works it out again from the local transform.
 * - **Several at once** (`valuesField`): each axis shows what they share or
 *   `—`; typed, every one gets it; scrubbed or stepped, each moves from its
 *   own -- its own angles, its own scale kept in proportion under the lock.
 *   In the world, one under another selected is written after it, the world
 *   flushed between, so it lands where it was told and not twice as far.
 */
import * as THREE from 'three';
import { Hierarchy, Transform, WorldTransform, type Entity, type EntityRef } from '@vibe/engine';
import { movers, worldAxisLocal, worldScaleLocal, worldTurnLocal, type Pose, type Quat, type Vec3 } from './gesture.ts';
import { parentPoseOf } from './gizmo.ts';
import { head, valuesField, type Blocks, type Columns } from './inspector-blocks.ts';
import { keepPref, loadPrefs } from './prefs.ts';
import { control, el, icon, iconButton } from './shell.ts';

/** The angles shown for an entity, in degrees, and the rotation they were worked out for or written as. */
interface Angles {
  x: number;
  y: number;
  z: number;
  q: [number, number, number, number];
}

type Axis = 'x' | 'y' | 'z';
const AXES: readonly Axis[] = ['x', 'y', 'z'];

/** One axis's field: how each entity's is read and written -- not drawn -- and the step it makes, called as a gizmo drag's: Move. */
interface AxisOptions {
  did: string;
  step: number;
  digits: number;
  title: string;
  read(e: Entity): number;
  write(e: Entity, value: number): void;
}

export interface TransformBlocks {
  /** Position, rotation, scale of every one of `es`. */
  transform(es: readonly Entity[]): HTMLElement;
}

/**
 * The two blocks, and what they keep from one entity shown to the next: the
 * angles, scale's lock, Position's space, and whether `WorldTransform` is
 * unfolded. `refresh` builds the inspector again: Position's space toggled.
 */
export function createTransformBlocks(blocks: Blocks, refresh: () => void): TransformBlocks {
  const { world } = blocks;
  /** Position shown and typed in the world's space, not its parent's: kept with the editor's preferences. */
  let inWorld = loadPrefs().worldPosition;
  /** Scale's lock: on, a change to one axis scales all three by as much. The editor's, for every entity. */
  let locked = true;
  const angles = new Map<EntityRef, Angles>();
  /** The angles shown in the world, apart from the local ones: each set keeps its own three. */
  const worldAngles = new Map<EntityRef, Angles>();
  const links = (): { parent: { [i: number]: number }; depth: { [i: number]: number } } => world.store(Hierarchy);

  const transform = (): Columns => world.store(Transform) as unknown as Columns;
  const quat = new THREE.Quaternion();
  const euler = new THREE.Euler();

  /** `e`'s rotation in degrees: as last shown or typed while the rotation is still that, else worked out afresh. */
  function anglesOf(e: Entity, q: Angles['q'] = localQuat(e), kept = angles): Angles {
    const ref = world.ref(e);
    const had = kept.get(ref);
    if (had && had.q.every((v, i) => v === q[i])) return had;
    euler.setFromQuaternion(quat.set(...q), 'XYZ');
    const fresh = { x: THREE.MathUtils.radToDeg(euler.x), y: THREE.MathUtils.radToDeg(euler.y), z: THREE.MathUtils.radToDeg(euler.z), q };
    kept.set(ref, fresh);
    return fresh;
  }

  const localQuat = (e: Entity): Angles['q'] => {
    const t = transform();
    return [t.qx![e]!, t.qy![e]!, t.qz![e]!, t.qw![e]!];
  };

  /** `e`'s rotation in the world, in degrees. */
  function worldAnglesOf(e: Entity): Angles {
    const w = world.store(WorldTransform);
    return anglesOf(e, [w.qx[e]!, w.qy[e]!, w.qz[e]!, w.qw[e]!], worldAngles);
  }

  /** `e`'s pose in the world, as the world worked it out when the frame was last drawn. */
  function worldPose(e: Entity): Pose {
    const w = world.store(WorldTransform);
    return { p: [w.px[e]!, w.py[e]!, w.pz[e]!], q: [w.qx[e]!, w.qy[e]!, w.qz[e]!, w.qw[e]!], s: [w.sx[e]!, w.sy[e]!, w.sz[e]!] };
  }

  /** `e`'s local rotation turned so its world rotation goes from `was` to `to` (`worldTurnLocal`): the rotation alone written. */
  function turnWorld(e: Entity, was: Quat, to: Quat): void {
    const t = transform();
    const q = worldTurnLocal(parentPoseOf(world, e), [t.qx![e]!, t.qy![e]!, t.qz![e]!, t.qw![e]!], was, to);
    [t.qx![e], t.qy![e], t.qz![e], t.qw![e]] = q;
    world.moved(e);
  }

  /** `e`'s local scale times the factor that takes its world scale from `was` to `to` (`worldScaleLocal`): the scale alone written. */
  function scaleWorld(e: Entity, was: Vec3, to: Vec3): void {
    const t = transform();
    [t.sx![e], t.sy![e], t.sz![e]] = worldScaleLocal(parentPoseOf(world, e), [t.sx![e]!, t.sy![e]!, t.sz![e]!], was, to);
    world.moved(e);
  }

  /** One world angle typed: the world rotation from all three, the other two as shown, turned into the local one through the parent. */
  function setWorldAngle(e: Entity, axis: Axis, degrees: number): void {
    const a = worldAnglesOf(e);
    a[axis] = degrees;
    const r = THREE.MathUtils.degToRad;
    quat.setFromEuler(euler.set(r(a.x), r(a.y), r(a.z), 'XYZ'));
    const q: Quat = [quat.x, quat.y, quat.z, quat.w];
    turnWorld(e, worldPose(e).q, q);
    // What the next read compares with: the world's own, once it has it. Until then these angles stand.
    a.q = q;
  }

  /** One angle typed: the quaternion from all three, the other two as they were shown. */
  function setAngle(e: Entity, axis: Axis, degrees: number): void {
    const a = anglesOf(e);
    a[axis] = degrees;
    const r = THREE.MathUtils.degToRad;
    quat.setFromEuler(euler.set(r(a.x), r(a.y), r(a.z), 'XYZ'));
    const t = transform();
    t.qx![e] = quat.x;
    t.qy![e] = quat.y;
    t.qz![e] = quat.z;
    t.qw![e] = quat.w;
    // As stored, in 32 bits: what the next read compares with.
    a.q = [t.qx![e]!, t.qy![e]!, t.qz![e]!, t.qw![e]!];
    world.moved(e);
  }

  /** `e`'s position in the world, as the world worked it out when the frame was last drawn. */
  function worldPosition(e: Entity): Vec3 {
    const w = world.store(WorldTransform);
    return [w.px[e]!, w.py[e]!, w.pz[e]!];
  }

  /**
   * One axis of `e`'s world position typed: its local position moved by that
   * axis's change alone, seen from what it hangs from (`vectorToLocal`) -- the
   * gizmo's way. The other two axes stay where they are in the world, and a
   * local axis the change does not reach is not touched, to the bit.
   */
  function setWorldAxis(e: Entity, i: number, value: number): void {
    const t = transform();
    const local = worldAxisLocal(parentPoseOf(world, e), [t.px![e]!, t.py![e]!, t.pz![e]!], worldPosition(e), i, value);
    // Under a parent scaled to nothing on an axis: nowhere puts it there.
    if (!local) return;
    [t.px![e], t.py![e], t.pz![e]] = local;
    world.moved(e);
  }

  function transformBlock(es: readonly Entity[]): HTMLElement {
    // As kept, each time it is built: Config ▸ Editor ▸ Preferences may have set it meanwhile.
    inWorld = loadPrefs().worldPosition;
    const section = el('div', 'ed-component');
    section.append(head(blocks, Transform, es));
    // Local or World, a line of its own under the name and folded with the rest: two words, the one in force lit.
    // The panel is built again either way.
    const space = el('span', 'ed-segments');
    for (const world_ of [false, true]) {
      const seg = control('ui', 'ed-segment', world_ ? 'World' : 'Local');
      seg.title = world_ ? 'Where it is in the world; typed, written back relative to its parent' : 'Relative to its parent';
      seg.setAttribute('aria-pressed', String(inWorld === world_));
      seg.addEventListener('click', () => {
        if (inWorld === world_) return;
        inWorld = world_;
        keepPref('worldPosition', inWorld);
        refresh();
      });
      space.append(seg);
    }
    const spaceLine = el('div', 'ed-space-line');
    spaceLine.append(space);
    section.append(spaceLine);
    const grid = el('div', 'ed-vector');
    const row = (name: string, extra?: HTMLElement, title?: string): HTMLElement => {
      const cell = el('span', 'ed-vector-name', name);
      if (extra) cell.append(extra);
      if (title) cell.title = title;
      grid.append(cell);
      return cell;
    };
    /**
     * In the world, one under another selected is written after it, with the
     * world flushed between: its parent's world transform is then where the
     * parent was put, and it lands where it was told.
     */
    const nested = movers(es, (x) => links().parent[x]! as Entity).length < es.length;
    const inOrder = nested ? [...es].sort((a, b) => links().depth[a]! - links().depth[b]!) : es;
    // A step called as the gizmo's are: what a typed or scrubbed axis did is what a drag of it does.
    const axisField = (axis: Axis, { did, read, write, ...options }: AxisOptions, order: readonly Entity[] = es): void => {
      const field = valuesField(blocks, {
        ...options,
        label: axis.toUpperCase(),
        labelClass: `ed-axis-${axis}`,
        did,
        read: () => order.map(read),
        write: (i, value) => write(order[i]!, value),
      });
      // What the overrides' marks find it by (`inspector-overrides.ts`): a rotation by the axis of its angles that differ --
      // local ones; the world's angles are not the ones the prefab's differ by, so in World the row's name is marked, and
      // each angle has a key no override has -- what a build finds it by to give the focus back, typing in it (`giveBack`).
      if (did !== 'Rotate') field.label.dataset.field = `Transform.${did === 'Move' ? 'p' : 's'}${axis}`;
      else field.label.dataset.field = inWorld ? `Transform.worldRotation.${axis}` : `Transform.rotation.${axis}`;
      grid.append(field.label);
    };

    row('Position', undefined, inWorld ? 'Position in the world' : 'Position relative to its parent');
    AXES.forEach((axis, i) => {
      const column = `p${axis}`;
      if (inWorld) {
        axisField(axis, {
          did: 'Move', step: 0.1, digits: 4, title: `Position ${axis}, metres, in the world`,
          read: (e) => worldPosition(e)[i]!,
          write: (e, value) => {
            setWorldAxis(e, i, value);
            if (nested) world.flush();
          },
        }, inOrder);
        return;
      }
      axisField(axis, {
        did: 'Move', step: 0.1, digits: 4, title: `Position ${axis}, metres, relative to its parent`,
        read: (e) => transform()[column]![e]!,
        write: (e, value) => {
          transform()[column]![e] = value;
          world.moved(e);
        },
      });
    });

    const turn = row('Rotation', undefined, inWorld ? 'Rotation in the world, in degrees (Euler, XYZ)' : 'Rotation relative to its parent, in degrees (Euler, XYZ)');
    if (inWorld) turn.dataset.field = 'Transform.rotation';
    for (const axis of AXES) {
      if (inWorld) {
        axisField(axis, {
          did: 'Rotate', step: 1, digits: 2, title: `Rotation about ${axis}, degrees (Euler, XYZ), in the world`,
          read: (e) => worldAnglesOf(e)[axis],
          write: (e, value) => {
            setWorldAngle(e, axis, value);
            if (nested) world.flush();
          },
        }, inOrder);
        continue;
      }
      axisField(axis, {
        did: 'Rotate', step: 1, digits: 2, title: `Rotation about ${axis}, degrees (Euler, XYZ), relative to its parent`,
        read: (e) => anglesOf(e)[axis],
        write: (e, value) => setAngle(e, axis, value),
      });
    }

    // Locked, each axis of each keeps its share of the size it had when the change began.
    const bases = new Map<Entity, [number, number, number]>();
    const lock = iconButton('ui', 'lock', '', () => {
      locked = !locked;
      showLock();
    }, 'ed-lock');
    const showLock = (): void => {
      lock.replaceChildren(icon(locked ? 'lock' : 'unlock'));
      lock.title = locked
        ? 'Scaled together: one axis changes all three. Click to scale each by itself'
        : 'Each axis by itself. Click to scale all three together';
      lock.setAttribute('aria-pressed', String(locked));
    };
    showLock();
    row('Scale', lock, inWorld ? 'Scale in the world: its own times its parents\'' : 'Scale relative to its parent');
    /** The three scales as `value` on axis `i` makes them: all three in proportion under the lock, from where the change began. */
    const scaled = (e: Entity, now: Vec3, i: number, value: number): Vec3 => {
      if (!locked) return now.map((v, j) => (j === i ? value : v)) as Vec3;
      let base = bases.get(e);
      if (!base) bases.set(e, (base = [...now] as [number, number, number]));
      const from = base[i]!;
      return AXES.map((_, j) => (j === i ? value : from === 0 ? value : (base[j]! * value) / from)) as Vec3;
    };
    AXES.forEach((axis, i) => {
      const column = `s${axis}`;
      if (inWorld) {
        axisField(axis, {
          did: 'Scale', step: 0.1, digits: 4, title: `Scale along ${axis}, in the world`,
          read: (e) => worldPose(e).s[i]!,
          write: (e, value) => {
            const was = worldPose(e).s;
            scaleWorld(e, was, scaled(e, was, i, value));
            if (nested) world.flush();
          },
        }, inOrder);
        return;
      }
      axisField(axis, {
        did: 'Scale', step: 0.1, digits: 4, title: `Scale along ${axis}`,
        read: (e) => transform()[column]![e]!,
        write: (e, value) => {
          const t = transform();
          const s = scaled(e, [t.sx![e]!, t.sy![e]!, t.sz![e]!], i, value);
          [t.sx![e], t.sy![e], t.sz![e]] = s;
          world.moved(e);
        },
      });
    });
    // A change over, committed: the next one starts from the size it left.
    grid.addEventListener('change', () => bases.clear());
    grid.addEventListener('pointerup', () => bases.clear());
    section.append(grid);
    return section;
  }

  return { transform: transformBlock };
}
