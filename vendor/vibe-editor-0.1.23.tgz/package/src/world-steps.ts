/**
 * World edits as steps of history: the whole world before and after, as saves.
 *
 * - **A step is the whole world**: `world.save()` as JSON, taken after an edit
 *   and compared with the state known before it, so an edit that changed
 *   nothing is no step. Not inverse operations: every edit is undoable without
 *   saying how, and so is one the editor learns later.
 * - **Undo puts the save before back** through `restore` -- `Game.load`, which
 *   keeps indices and generations, so a selection held as an `EntityRef` still
 *   points where it did and one destroyed comes back under the same ref, and
 *   dresses the views again, so what was destroyed is drawn again.
 * - **A gesture is one step**: a drag of the gizmo, a scrub of a field, a number
 *   typed in. Its edits reach the world as they happen; the tool commits once,
 *   when it ends. So there is no `merge`.
 * - **What a compile owns is no edit**: a save carries each prefab's node table
 *   (`instances.nodes`, `instances.names`) as compiled now, so a prefab
 *   compiled anew with an entity more or less changes it with nothing edited.
 *   Compared without it, so a recompile is never an `Edit` step -- a Save
 *   inside an opened prefab, then Back, asks nothing. A step keeps the save
 *   whole, for undo.
 * - **What is no edit runs `unedited`**: a recompile drains a changed pooled
 *   prefab's pool and warms it again, which moves the world's `extent` and
 *   generations with nothing edited. An edit under way is committed first, a
 *   step of its own, and the world after the run is the known state: no step
 *   for it, and no edit hidden in it -- chosen over comparing without
 *   `extent` and generations, which would hide one (an entity destroyed and
 *   one made alike at its index, a ref to the old one still in a column).
 *   So a recompile that lands mid-gesture -- the files' debounce firing
 *   between a drag's pointer moves -- makes that gesture two steps: Z takes
 *   back its second half, Z again the first. Nothing is lost; holding the
 *   commit until the gesture ends would leave the run's changes in the
 *   gesture's step.
 * - **Each save is of its era** (`createWorldSteps`' `era`, the editor's
 *   count of prefab renames, `renames.ts`): put back with the era it was taken
 *   in, so only the renames made since are replayed on it -- never one onto a
 *   world saved after it, where the old key may name another prefab.
 * - **Its size is its JSON's length**: the save before is the step behind's save
 *   after, the same string, so one is counted.
 * - **The known state follows the history**: read again after any undo or redo,
 *   and after a step of another kind is pushed -- it was applied already, and
 *   may have touched the world. Inside a group nothing is pushed until the end:
 *   a step of another kind there that changes the world calls `sync` itself
 *   before a world step comes after it.
 *
 * - **Held while a step lands** (`guard`): an Apply's undo or redo loads its
 *   world once its files compile, so an edit made meanwhile would be loaded
 *   over -- or, a step, drop the Apply from redo. The editor stops the edits
 *   it can before they start (the panels, the gizmo, a drop, the agent's
 *   tools wait); one that gets through anyway (a key) is put back here as it
 *   is committed, the world as known, and said: never a step.
 *
 * - **Watched** (`observe`): each step pushed is told with the world's save
 *   before and after it, as JSON -- the strings it keeps anyway -- so a
 *   playtest paused records what each step changed (`playtest-edits.ts`).
 *
 * What the world being changed by something else means -- the game ran, a scene
 * was loaded -- is the editor's to decide (`drifted`, then `history.reset()`
 * and `sync()`); this only says so.
 */
import type { World, WorldSave } from '@vibe/engine';
import type { History, Step } from './history.ts';

/**
 * The label of an edit still under way -- a number typed, not committed yet --
 * made a step of its own before anything that has to know of it: an undo, a
 * save, a playtest, a load.
 */
export const PENDING = 'Edit';

export interface WorldSteps {
  /**
   * After an edit, or at the end of a gesture: the world as it is now, against
   * the last known state, becomes one step with this label. Nothing if unchanged.
   */
  commit(label: string): boolean;
  /** Take the world as the known state without a step: after a load, a playtest that put the world back, or on open when the host decides to go on. */
  sync(): void;
  /** Has the world changed since the known state (the game ran, something else edited it)? */
  drifted(): boolean;
  /** `run`, which changes the world but is no edit (a recompile): an edit under way a step first, the world after it the known state. */
  unedited<T>(run: () => T): T;
  /** The world put back as last known -- no step: what was done since undone (a `batch` of the agent's that failed part-way). */
  revert(): void;
  /**
   * The world as it is now, marked: the answer says whether it has changed since -- by anyone, as an edit is compared
   * (a project's tool awaited, `mcp/page.ts`: anything changed while it was awaited is not told apart from a person's).
   */
  mark(): () => boolean;
}

/** What may refuse an edit: a step of the world's still landing (an Apply's undo or redo), whose world would be loaded over it. */
export interface WorldStepsGuard {
  /** While a step lands, what an edit committed meanwhile is refused with; else null. */
  held(): string | null;
  /** An edit was refused (`held`) and the world put back as it was: say `line`, and read the world again. */
  refused(line: string): void;
}

/** Told of each world step as it is pushed: the step, and the world's save (`world.save()`, as JSON) before and after it. */
export type StepObserver = (step: Step, before: string, after: string) => void;

export function createWorldSteps(
  history: History, world: World, restore: (save: WorldSave, era: number) => void, guard?: WorldStepsGuard, era: () => number = () => 0, observe?: StepObserver,
): WorldSteps {
  /** The world now: whole, for a step, and what is compared -- without the node tables a compile owns -- with the era it was taken in. */
  const snap = (): Snap => {
    const save = world.save();
    const whole = JSON.stringify(save);
    const at = era();
    const inst = save.instances;
    if (!inst || (inst.nodes === undefined && inst.names === undefined)) return { whole, edits: whole, era: at };
    save.instances = { ...inst, nodes: undefined, names: undefined };
    return { whole, edits: JSON.stringify(save), era: at };
  };
  /** The world as last committed, synced or put back. */
  let known = snap();
  /** A world step of ours is being pushed: the world is as known already. */
  let pushing = false;

  history.on((event) => {
    // Read again rather than taken as loaded: a save made after a load can list
    // the same links in another order, and that is not an edit.
    if (event === 'undo' || event === 'redo' || (event === 'push' && !pushing)) known = snap();
  });

  return {
    commit(label) {
      const now = snap();
      if (now.edits === known.edits) return false;
      // A step still landing would load its world over this edit, or have it drop that step from redo: put back, said.
      const held = guard?.held() ?? null;
      if (held !== null) {
        restore(JSON.parse(known.whole) as WorldSave, known.era);
        known = snap();
        guard!.refused(held);
        return false;
      }
      const step = worldStep(label, known, now, restore);
      const before = known.whole;
      known = now;
      pushing = true;
      try {
        history.push(step);
      } finally {
        pushing = false;
      }
      observe?.(step, before, now.whole);
      return true;
    },
    sync() {
      known = snap();
    },
    drifted: () => snap().edits !== known.edits,
    revert() {
      if (snap().edits === known.edits) return;
      restore(JSON.parse(known.whole) as WorldSave, known.era);
      known = snap();
    },
    mark() {
      const then = snap().edits;
      return () => snap().edits !== then;
    },
    unedited(run) {
      this.commit(PENDING);
      try {
        return run();
      } finally {
        known = snap();
      }
    },
  };
}

/** The world as JSON: whole, and as compared for an edit. */
interface Snap {
  whole: string;
  edits: string;
  /** `era` as it was taken: what the editor's renames (`renames.ts`) replay from as it is put back. */
  era: number;
}

/**
 * The editor opening (`editor.ts`' `open`): history goes on from where it was
 * if the world is as the steps know it -- a step another host pushed (the
 * agent's card, Undo this turn's step carried across a reload) is known as
 * it was pushed. If the world changed since -- the game ran -- an undo would
 * rewind the simulation with it, so history starts again, unsaved: the world
 * has moved on from any save. `resetting` runs the reset with its reason in
 * force (the agent's rows read why). Either way the world as it is now is
 * the known state. True if history started again.
 */
export function openHistory(history: History, steps: WorldSteps, resetting: (why: string, reset: () => void) => void = (_why, reset) => reset()): boolean {
  const drifted = steps.drifted();
  if (drifted) {
    resetting('the game ran since', () => history.reset());
    history.forgetSaved();
  }
  steps.sync();
  return drifted;
}

function worldStep(label: string, before: Snap, after: Snap, restore: (save: WorldSave, era: number) => void): Step {
  return {
    label,
    size: after.whole.length,
    undo: () => restore(JSON.parse(before.whole) as WorldSave, before.era),
    redo: () => restore(JSON.parse(after.whole) as WorldSave, after.era),
  };
}
