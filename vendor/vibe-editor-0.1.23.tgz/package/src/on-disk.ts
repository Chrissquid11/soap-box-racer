/**
 * A prefab file changed on disk since the editor last read or wrote it
 * (Docs/prefabs.md §7): by hand, by the agent, by a teammate's pull. What
 * every writer of a prefab file the editor holds open checks before it writes
 * -- the opened mode's Save (`opened.ts`), and Apply (`overrides-steps.ts`) -- so a write
 * never silently drops someone else's edit.
 *
 * - **Compared as the editor writes a file** (`prefabText`): the page holds
 *   each file parsed, so whitespace alone is no change; anything a file says
 *   is.
 * - **A write of our own is no change**: the text written is what is known
 *   since, and until the dev server's push brings it, the page may still hold
 *   any text before it -- the one it held, or one of our own earlier writes
 *   whose push lands late (two quick Saves) -- which is no change either
 *   (`ours`), until the page holds what was written last and they are let go.
 * - **A file gone** was trashed, or renamed: one now on disk with the text
 *   last known is where it went (the Assets tool's Rename moves the file as
 *   it is) -- never one that said that text already (`twins`: two New
 *   prefabs in one folder are alike), so a trash beside a twin is a trash.
 *   Written back at the old key it would be a file nobody asked for.
 *
 * Pure: the files are handed in, so a node test drives it (`opened.test.ts`).
 */
import type { PrefabFile } from '@vibe/engine';
import { prefabText } from './assets/ui/prefab-steps.ts';

/** What the editor last knew of one prefab file on disk. */
export interface Known {
  /** Its text, as read at open or as last written. */
  text: string;
  /** Texts before our writes that the page may still hold (their pushes not in yet); empty once it holds `text`. */
  ours: string[];
  /** Other files that said `text` when it was known: a twin, never where this one went. */
  twins: string[];
}

/** What changed: the file says something else now (`text`), or it is gone -- renamed (`to`, its key now) or trashed (`to` null). */
export type DiskChange = { how: 'changed'; text: string } | { how: 'gone'; to: string | null };

/** The keys besides `key` whose file says `text`. */
function twinsOf(key: string, text: string, files: Readonly<Record<string, PrefabFile>>): string[] {
  return Object.keys(files).filter((k) => k !== key && prefabText(files[k]!) === text);
}

/** `key`'s file as read, among `files` (every prefab file as the page holds it): known as it is. */
export function knownOf(key: string, file: PrefabFile, files: Readonly<Record<string, PrefabFile>>): Known {
  const text = prefabText(file);
  return { text, ours: [], twins: twinsOf(key, text, files) };
}

/** `known` after a write of ours of `text` to `key`, over what the page holds now (`files`). */
export function wroteOver(known: Known, key: string, text: string, files: Readonly<Record<string, PrefabFile>>): Known {
  const now = files[key];
  const ours = new Set([...known.ours, known.text]);
  if (now !== undefined) ours.add(prefabText(now));
  ours.delete(text);
  return { text, ours: [...ours], twins: twinsOf(key, text, files) };
}

/**
 * How `key`'s file differs from what was last known of it, in `files` (every
 * prefab file as the page holds it): null if it does not. Lets go of
 * `known.ours` once the page holds what was written.
 */
export function diskChange(key: string, known: Known, files: Readonly<Record<string, PrefabFile>>): DiskChange | null {
  const file = files[key];
  if (file === undefined) {
    const to = Object.keys(files).find((k) => k !== key && !known.twins.includes(k) && prefabText(files[k]!) === known.text);
    return { how: 'gone', to: to ?? null };
  }
  const text = prefabText(file);
  if (text === known.text) {
    known.ours = [];
    return null;
  }
  if (known.ours.includes(text)) return null;
  return { how: 'changed', text };
}

/** `change` to `key` said, for a line: what happened to the file. */
export function diskWords(key: string, change: DiskChange): string {
  if (change.how === 'changed') return `${key} changed on disk since you opened it`;
  return change.to !== null ? `${key} was renamed to ${change.to} since you opened it` : `${key} is gone from disk since you opened it -- trashed`;
}
