/**
 * Entities as a prefab file (Docs/prefabs.md §2, §7): what "Save as prefab…"
 * writes from the scene, and what the opened-prefab mode's Save writes back.
 * From a clip (`clip.ts`' `copyOut`), so what is taken out of the world is
 * what Copy takes; pure, no page and no three: node tests it
 * (`prefab-write.test.ts`, round trips compared field by field).
 *
 * The rules:
 *   - **Only what differs from a component's defaults is written**: a field
 *     at its initial value, a layer of 0, an empty list -- left out. Compared
 *     as the column holds it (`same`): an integer or an `f64` exactly, an
 *     `f32` as the 32-bit float it is (`Math.fround`). A field systems set as
 *     the game runs (`component(..., { runtime })`) is never written.
 *   - **Numbers as a person writes them** (`tidy`): an `f32` as the shortest
 *     decimal that reads back to the same 32-bit float (1.15, not
 *     1.149999976), an `f64` as JavaScript prints it.
 *   - **An instance stays an instance**: an entity a prefab made, with its
 *     instance's root among what is written, is a nested instance of that
 *     prefab -- `{ id, prefab, parent, overrides }` -- and what it changed
 *     from the prefab its entities were made from (`compiled`) is worked out
 *     here, never tracked: a field's value, a component or tag added or
 *     removed, one switched off or on again, the layer, the name,
 *     a ref, an object's data, a link's data, an inner entity under another
 *     of the instance (`parent`), an entity of it gone (`removed`). An entity
 *     put under one of its entities is a plain entity of the file whose
 *     parent is a path into it. Which entity of the prefab each is goes by
 *     its kind's name, the node's id path, which stays the same across a
 *     recompile and a load (Docs/prefabs.md §6).
 *   - **Refs and links inside what is written point by id** (a path into a
 *     nested instance); one pointing out of it is left out -- and said.
 *   - **What an override cannot say is said, not guessed** (`notes`): a link
 *     made from an entity of a nested instance, or one of its links gone; a
 *     ref from one to an entity outside its instance, or to nothing; an inner
 *     entity moved out of its instance; an inner entity's name taken off.
 *   - **A look is data**: an entity's model is its `Render`, written as any
 *     component's fields -- a key field (`key()`) as its text (`"model":
 *     "props/crate"`), never its id. A plain copy of a rider has the rider's
 *     `Render`, so it writes it; a file in the old form (`"view"`) is written
 *     in the new one at its next Save (Docs/render.md §1, rule 8).
 *   - **Placed where it is used**: "Save as prefab" writes the root at the
 *     origin and says where it stood (`placed`), so the instance that
 *     replaces the selection stands there. Several roots go under an empty
 *     root, each at its offset from the middle of them across the ground.
 *   - **Opened** (`unpack`): the clip's root is an instance of the prefab
 *     being edited, and its entities are written as that file's own -- each
 *     plain entity of the file by its id, each instance the file nests as
 *     that instance again, with its overrides worked out afresh -- **in the
 *     file's own layout** (`keepLayout`): its entity order, each object's
 *     key order, its overrides' order and grouping; what is new after. So a
 *     Save of what was opened and left alone writes the same file
 *     (`unchanged`), and a field changed is a line changed. A value the
 *     file's own override sets is kept while the entity has it, though the
 *     nested prefab comes to say the same: it is the file's statement, and
 *     means something again when the prefab changes. A `removed` is written
 *     only for an entity the nested prefab still has as compiled now.
 *   - **Each instance against its own compile** (`compiled(key, root)`): one
 *     spawned before its prefab changed was made from the compile then, and
 *     its overrides are worked out against that. **One its compile cannot
 *     place is refused**, never written plain: an entity of an instance whose
 *     node the compile it was made from has not, or an instance of a prefab
 *     not compiled -- written, the file would compile and say something else
 *     than what is in the world.
 */
import {
  allComponents, carried, compiledPrefab, dataDefault, dataPlain, isData, mapFields, mapRefs, fieldIsText, fieldText, fieldValue, fileEntry, foldVectors, keyRef, Name, nestedKey, same, Transform,
  type AnyComponent, type DataComponentOf, type FileValue, type CompiledPrefab, type Component, type FieldType, type Override, type PrefabEntity, type PrefabFile,
} from '@vibe/engine';
import { isClipRef, type Clip, type ClipEntity } from './clip.ts';
import { settled } from './gesture.ts';

/**
 * A field's value as the file writes it: a key field's reference (`{ uid, key }`, or its key: `fieldText`), an enum's
 * name, flags' names, a `colorA`'s `#rrggbbaa`, any other number tidied (`tidy`). A vector's axes are numbers here,
 * folded into `[x, y, z]` once the entity's are written (`foldVectors`).
 */
const written = (c: Component, field: string, v: number, type: FieldType | string): FileValue => (fieldIsText(c, field) ? fieldText(c, field, v) : tidy(v, type));

/** What `clipToPrefab` is told. */
export interface WriteOptions {
  /**
   * The compiled prefab each instance's entities were made from, by key:
   * `compiledPrefab`, or what an opened frame was opened against
   * (`opened.ts`), or a test's own. Overrides are worked out against it.
   * `root`, for an instance whose root is in the clip, is that root's place
   * in it: each such instance may have been made from a compile of its own
   * (one spawned before the prefab changed).
   */
  compiled: (key: string, root?: number) => CompiledPrefab | undefined;
  /**
   * The opened-prefab mode: the clip's one root is an instance of `key`, and
   * is written as `file`'s own entities, its root where it is, in its
   * layout. Without it, "Save as prefab": the root at the origin.
   */
  unpack?: {
    key: string;
    file: PrefabFile;
    /** Entities an earlier Save of this opening wrote -- plain ones, and the roots of instances placed in it -- by place in the clip: the id it gave each, kept. */
    ids?: ReadonlyMap<number, string>;
  };
  /** Several roots: the name of the empty root put above them. */
  name?: string;
}

export interface Written {
  file: PrefabFile;
  /** Where the root stood (the middle of several, on the ground): an instance put there stands where the entities did. */
  placed: { x: number; y: number; z: number };
  /** What the file could not keep, each a line. */
  notes: string[];
  /** Opened (`unpack`): the file says what it said -- nothing to write. */
  unchanged: boolean;
  /** Each plain entity of the file, and each instance's root, by its place in the clip: its id, for the next Save to keep (`unpack.ids`). */
  ids: Map<number, string>;
  /**
   * Each clip entity's node in the prefab written, by its path (`''` the
   * root), or null for one not in it: which entity of an instance of it each
   * one is -- what "Save as prefab" carries the runtime state across by.
   */
  paths: (string | null)[];
}

const componentByName = (name: string): AnyComponent | undefined => allComponents().find((c) => c.name === name);


/** An id from a name: `big crate` is `big-crate`; nothing usable, `entity`. Never with `/`. */
export function idFrom(name: string | null | undefined): string {
  const id = (name ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return id === '' ? 'entity' : id;
}

/** `stem`, or `stem-2`, `stem-3`… -- the first `taken` lacks, then taken. */
function freeId(stem: string, taken: Set<string>): string {
  let id = stem;
  for (let n = 2; taken.has(id); n++) id = `${stem}-${n}`;
  taken.add(id);
  return id;
}

/** Is `field` of `c` a `ref()`: an entity, not a number. */
const isRef = (c: Component, field: string): boolean => (c.schema as Record<string, { ref?: true }>)[field]?.ref === true;

/**
 * A value as the file says it: an `f32` as the shortest decimal that reads
 * back to the same 32-bit float -- 1.15 for the column's 1.149999976, up to
 * nine figures where it needs them -- and anything else as it is, which
 * JavaScript prints shortest already. A value worked out in 64 bits for an
 * `f32` field (an offset from the middle) is the float the column would hold.
 */
export function tidy(v: number, type: FieldType | string): number {
  if (type !== 'f32') return v;
  const f = Math.fround(v);
  if (Number.isInteger(f) || !Number.isFinite(f)) return f === 0 ? 0 : f;
  for (let p = 1; p <= 9; p++) {
    const s = Number(f.toPrecision(p));
    if (Math.fround(s) === f) return s;
  }
  return f;
}

/** Equal as the column holds them (`src/ecs/overrides.ts`, which compares an instance with its prefab the same way). */
export { same };

/** A prefab node's value of a field, defaults included (`full`). */
function fullValue(p: CompiledPrefab, component: Component, field: number, node: number): number {
  for (const run of p.full) {
    if (run.component !== component.id || run.field !== field) continue;
    for (let j = 0; j < run.node.length; j++) if (run.node[j] === node) return run.value[j]!;
  }
  return component.fields[field]!.initial;
}

/** The node a prefab node's ref field points at, or -1 for none. */
function refTarget(p: CompiledPrefab, component: Component, field: number, node: number): number {
  for (const run of p.refs) {
    if (run.component !== component.id || run.field !== field) continue;
    for (let j = 0; j < run.node.length; j++) if (run.node[j] === node) return run.target[j]!;
  }
  return -1;
}

/** A link's data as the prefab makes it, or null if the prefab makes no such link. */
function linkData(p: CompiledPrefab, relation: string, from: number, to: number): Record<string, number> | null {
  for (const run of p.links) {
    if (run.relation.name !== relation) continue;
    for (let j = 0; j < run.source.length; j++) {
      if (run.source[j] !== from || run.target[j] !== to) continue;
      const data: Record<string, number> = {};
      for (const f of run.relation.fields) data[f.name] = f.initial;
      for (const w of run.writes) {
        const at = Array.from(w.link).indexOf(j);
        if (at >= 0) data[run.relation.fields[w.field]!.name] = w.value[at]!;
      }
      return data;
    }
  }
  return null;
}

/** What an instance of `p` has in an object component at `node` as made: the file's data, or a new one's as `save` says it. */
function objectThen(p: CompiledPrefab, c: AnyComponent, node: number): unknown {
  const given = p.objects.find((o) => o.component === c && o.node === node);
  if (given) return given.data;
  return c.kind === 'object' && c.create && c.save ? c.save(c.create()) : undefined;
}

/**
 * A data component's value from a clip as a prefab file writes it: only its fields that differ from their defaults
 * (a file says what differs), each ref through `ref` -- a copy's id or path inside the file, nobody else.
 */
function dataFile(c: DataComponentOf, value: unknown, ref: (r: unknown) => unknown): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  const given = mapFields(c.data, value, ref) as Record<string, unknown>;
  for (const [f, el] of Object.entries(c.data)) {
    // A field systems fill as the game runs is never a prefab's.
    if (!(f in given) || c.runtime.includes(f)) continue;
    if (JSON.stringify(given[f]) !== JSON.stringify(dataPlain(el, dataDefault(el), () => null))) out[f] = given[f];
  }
  return out;
}

/** The node path of a kind of prefab `key` -- `crates/big/rider` is `rider` -- or null if the kind is not one of its. */
export const pathOf = (kind: string, key: string): string | null => (kind === key ? '' : kind.startsWith(`${key}/`) ? kind.slice(key.length + 1) : null);

/** A path of ids as a file writes it: `''` is `[]`. */
const pathList = (path: string): string[] => (path === '' ? [] : path.split('/'));

/** A nested instance being written: the prefab, its id, and its entities' nodes. */
interface Unit {
  id: string;
  key: string;
  /** What a refusal calls it: the file's id for one the file nests, else its root's name, else its prefab. */
  name: string;
  p: CompiledPrefab;
  /** The clip entity that is its root; -1 until found. */
  root: number;
}

/** Who owns a node of the opened prefab: one of its file's plain entities, or an instance it nests, at a path inside that. */
export type Owner = { plain: string } | { nested: string; prefab: string; inner: string };

/** A prefab's node paths, each to the entity of its file that makes it: a plain one by its id, or an instance it nests and the path inside that. */
export function ownersOf(file: PrefabFile): (path: string) => Owner | null {
  const [first, ...rest] = file.entities;
  return (path) => {
    for (const f of rest) {
      if (f.prefab === undefined) {
        if (path === f.id) return { plain: f.id };
      } else if (path === f.id || path.startsWith(`${f.id}/`)) return { nested: f.id, prefab: nestedKey(f) ?? '', inner: path === f.id ? '' : path.slice(f.id.length + 1) };
    }
    if (!first) return null;
    // The root: its path is '', and for a variant every path its base makes is its own, relative as the compile makes it.
    if (first.prefab === undefined) return path === '' ? { plain: first.id } : null;
    return { nested: first.id, prefab: nestedKey(first) ?? '', inner: path };
  };
}

/**
 * `clip` as a prefab file. The clip's roots are its first entities with no
 * parent; one is the root, several go under a new empty one.
 */
export function clipToPrefab(source: Clip, options: WriteOptions): Written {
  const clip = structuredClone(source);
  const notes: string[] = [];
  const { entities } = clip;
  const roots = entities.flatMap((e, i) => (e.parent < 0 ? [i] : []));
  if (roots.length === 0) throw new Error('[prefab] nothing to write: no entities');
  if (options.unpack && roots.length !== 1) throw new Error('[prefab] an opened prefab is written from its one root');
  // Each key field as this page's id, from the text the clip carries (`ClipEntity.keys`): compared as ids, written as text.
  for (const e of entities) {
    for (const [at, text] of Object.entries(e.keys ?? {})) {
      const [cname, fname] = at.split('.') as [string, string];
      const c = componentByName(cname);
      const id = c?.kind === 'data' ? fieldValue(c, fname, text) : null;
      if (id !== null && e.data[cname]) e.data[cname]![fname] = id;
    }
  }
  const nameOf = (e: ClipEntity): string | null => (typeof e.objects[Name.name] === 'string' ? (e.objects[Name.name] as string) : null);

  // Placed where it is used: the root at the origin -- several, round the middle of them on the ground.
  let placed = { x: 0, y: 0, z: 0 };
  if (!options.unpack) {
    const pos = roots.map((i) => entities[i]!.data[Transform.name]);
    const have = pos.filter((t): t is Record<string, number> => t !== undefined);
    if (have.length > 0) {
      placed = roots.length === 1
        ? { x: have[0]!.px!, y: have[0]!.py!, z: have[0]!.pz! }
        : { x: have.reduce((s, t) => s + t.px!, 0) / have.length, y: 0, z: have.reduce((s, t) => s + t.pz!, 0) / have.length };
    }
    // What is only float noise from the origin is the origin, to the bit: no -2.2e-16 in a file.
    // (Relative to the two numbers taken one from the other: a difference of large ones is as noisy as they are large.)
    for (const t of have) {
      t.px = settled(t.px! - placed.x, 0, Math.max(Math.abs(t.px!), Math.abs(placed.x)));
      t.py = settled(t.py! - placed.y, 0, Math.max(Math.abs(t.py!), Math.abs(placed.y)));
      t.pz = settled(t.pz! - placed.z, 0, Math.max(Math.abs(t.pz!), Math.abs(placed.z)));
    }
  }

  // What each entity is: a plain entity of the file, or an entity of a nested instance at a node of its prefab.
  const taken = new Set<string>();
  const units: Unit[] = [];
  const unitOf = new Array<number>(entities.length).fill(-1);
  const nodeIn = new Array<number>(entities.length).fill(-1);
  const innerOf = new Array<string>(entities.length).fill('');
  const plainId = new Array<string>(entities.length).fill('');
  const unitAt = new Map<string, number>();
  /**
   * Instances with entities their compile has no place for, by what each is
   * called, and those entities: written, the file would be wrong and compile
   * -- refused.
   */
  const unplaced = new Map<string, string[]>();
  const refuse = (instance: string, what: string): void => {
    const list = unplaced.get(instance) ?? [];
    list.push(what);
    unplaced.set(instance, list);
  };
  const join = (i: number, unit: number, inner: string): void => {
    const u = units[unit]!;
    const node = u.p.paths.indexOf(inner);
    if (node < 0) {
      refuse(`${u.name} (${u.key})`, `${nameOf(entities[i]!) ?? inner} (${u.key}'s ${inner}, which the ${u.key} it was made from has not)`);
      return;
    }
    unitOf[i] = unit;
    nodeIn[i] = node;
    innerOf[i] = inner;
    if (inner === '') u.root = i;
  };
  const owner = options.unpack ? ownersOf(options.unpack.file) : null;
  if (options.unpack) {
    // The file's own ids stay its ids, and the instances it nests theirs.
    for (const f of options.unpack.file.entities) taken.add(f.id);
  }
  entities.forEach((e, i) => {
    const inst = e.instance;
    if (!inst) return;
    if (owner && inst.root === roots[0] && inst.prefab === options.unpack!.key) {
      const path = pathOf(e.kind, inst.prefab);
      const o = path === null ? null : owner(path);
      if (!o) return;
      if ('plain' in o) {
        plainId[i] = o.plain;
        return;
      }
      let unit = unitAt.get(`file:${o.nested}`);
      if (unit === undefined) {
        const p = options.compiled(o.prefab);
        if (!p) return void refuse(`${o.nested} (${o.prefab})`, `${o.prefab} is not compiled`);
        unit = units.push({ id: o.nested, key: o.prefab, name: o.nested, p, root: -1 }) - 1;
        unitAt.set(`file:${o.nested}`, unit);
      }
      join(i, unit, o.inner);
      return;
    }
    // An instance with its root among what is written is an instance in the file.
    if (entities[inst.root]?.instance?.root !== inst.root) return;
    const path = pathOf(e.kind, inst.prefab);
    if (path === null) return;
    let unit = unitAt.get(`clip:${inst.root}`);
    if (unit === undefined) {
      const p = options.compiled(inst.prefab, inst.root);
      const name = nameOf(entities[inst.root]!) ?? inst.prefab;
      if (!p) return void refuse(`${name} (${inst.prefab})`, `${inst.prefab} is not compiled`);
      unit = units.push({ id: '', key: inst.prefab, name, p, root: -1 }) - 1;
      unitAt.set(`clip:${inst.root}`, unit);
    }
    join(i, unit, path);
  });
  if (unplaced.size > 0) {
    // The instance first, and what to do: placed anew it is of the compile now. Back and open again would not do -- its Save fails the same.
    const each = [...unplaced].map(([instance, what]) => `${instance}: delete it and place it again -- ${what.join(', ')}`);
    throw new Error(`${each.join('; ')}: its prefab changed since in a way this cannot follow, and written it would say something else than what is here -- nothing written`);
  }
  // An instance whose root is not written (an entity reparented out of it) writes what is left plain.
  entities.forEach((_e, i) => {
    if (unitOf[i]! >= 0 && units[unitOf[i]!]!.root < 0) unitOf[i] = -1;
  });
  // A variant's own ids may not be its base's: the base's first level is taken too.
  const top = unitOf[roots[0]!]!;
  if (roots.length === 1 && top >= 0) for (const path of units[top]!.p.paths) if (path !== '' && !path.includes('/')) taken.add(path);
  /** One an earlier Save of this opening wrote: its id is the file's now, and stays -- once. */
  const claimed = new Set<string>();
  const kept = (i: number): string | null => {
    const had = options.unpack?.ids?.get(i);
    if (had === undefined || claimed.has(had)) return null;
    claimed.add(had);
    return had;
  };
  for (const u of units) if (u.root >= 0 && u.id === '') u.id = kept(u.root) ?? freeId(idFrom(nameOf(entities[u.root]!) ?? u.key.slice(u.key.lastIndexOf('/') + 1)), taken);
  entities.forEach((e, i) => {
    if (unitOf[i]! >= 0 || plainId[i] !== '') return;
    plainId[i] = kept(i) ?? freeId(idFrom(nameOf(e)), taken);
  });
  const wrapper = roots.length > 1 ? freeId('root', taken) : null;

  /** Where the file finds clip entity `i`: an id, or a path into a nested instance. */
  const address = (i: number): string | string[] => {
    const unit = unitOf[i]!;
    if (unit < 0) return plainId[i]!;
    const inner = innerOf[i]!;
    return inner === '' ? units[unit]!.id : [units[unit]!.id, ...inner.split('/')];
  };
  const parentOf = (i: number): string | string[] | null => {
    const parent = entities[i]!.parent;
    return parent >= 0 ? address(parent) : wrapper;
  };
  const said = (i: number): string => (typeof address(i) === 'string' ? (address(i) as string) : (address(i) as string[]).join('/'));
  /** A value JSON can hold: infinity and NaN it cannot (it writes null, which no file reads as a number) -- left out, and said. */
  const finite = (i: number, what: string, v: number): boolean => {
    if (Number.isFinite(v)) return true;
    notes.push(`${said(i)}: ${what} is ${v}, which a file cannot hold -- left out`);
    return false;
  };
  /** What of entity `i` points out of what is written: left out, and said. */
  const sayOutside = (i: number): void => {
    for (const o of entities[i]!.outside ?? []) {
      const c = componentByName(o.what.split('.')[0]!);
      // A field systems set is not the file's to keep: nothing to say of it.
      if (c?.kind === 'data' && c.fields.find((f) => `${c.name}.${f.name}` === o.what)?.runtime) continue;
      notes.push(`${said(i)}: ${o.what.includes('.') ? o.what : `its ${o.what} link`} points at ${o.to}, outside what is written -- left out`);
    }
  };

  const out: PrefabEntity[] = [];
  if (wrapper) out.push({ id: wrapper, name: options.name ?? 'prefab', parent: null, components: [Transform.name] });

  entities.forEach((e, i) => {
    const unit = unitOf[i]!;
    if (unit >= 0) {
      // The nested prefab by its reference (Docs/asset-ids.md §3): its uid where it has one, so a move does not break it.
      if (units[unit]!.root === i) out.push({ id: units[unit]!.id, parent: parentOf(i), prefab: keyRef('prefabs', units[unit]!.key), overrides: [] });
      return;
    }
    out.push(plainEntity(e, i));
  });

  // Each nested instance's overrides: what its entities changed from its prefab, entity by entity in tree order.
  for (const [u, unit] of units.entries()) {
    if (unit.root < 0) continue;
    const entry = out.find((x) => x.id === unit.id && nestedKey(x) === unit.key)!;
    const overrides: Override[] = [];
    const present = new Map<number, number>();
    entities.forEach((_e, i) => {
      if (unitOf[i] === u) present.set(nodeIn[i]!, i);
    });
    entities.forEach((e, i) => {
      if (unitOf[i] !== u) return;
      const o = overrideOf(e, i, u, present);
      if (o) overrides.push(o);
    });
    // An entity of the prefab gone: removed, once at the top of what went -- and only one the prefab still has as
    // compiled now: one it lost since these entities were made is no override, and one at it would not compile.
    const current = compiledPrefab(unit.key);
    for (let node = 1; node < unit.p.count; node++) {
      if (!present.has(node) && present.has(unit.p.parents[node]!) && (!current || current.paths.includes(unit.p.paths[node]!))) overrides.push({ at: unit.p.paths[node]!.split('/'), removed: true });
    }
    if (overrides.length > 0) entry.overrides = overrides;
    else delete entry.overrides;
  }

  // The file's own uid kept, first as the pipeline stamps it (Docs/asset-ids.md §1): a save is the same asset.
  const own = options.unpack?.file.uid;
  const file: PrefabFile = { ...(typeof own === 'string' ? { uid: own } : {}), is: 'vibebase.prefab', version: 1, ...(options.unpack?.file.pool ? { pool: options.unpack.file.pool } : {}), entities: out };
  const ids = new Map(plainId.flatMap((id, i) => (id !== '' && unitOf[i]! < 0 ? [[i, id] as const] : [])));
  for (const u of units) if (u.root >= 0) ids.set(u.root, u.id);
  // A path is relative to the root: the one root's own id is '', and a variant's root nests its base at the top.
  const lone = wrapper === null ? roots[0]! : -1;
  const paths = entities.map((_e, i): string | null => {
    const u = unitOf[i]!;
    if (u < 0) return i === lone ? '' : plainId[i] || null;
    const unit = units[u]!;
    const inner = innerOf[i]!;
    if (unit.root === lone) return inner;
    return inner === '' ? unit.id : `${unit.id}/${inner}`;
  });
  if (!options.unpack) return { file, placed, notes, unchanged: false, ids, paths };
  const laid = keepLayout(file, options.unpack.file);
  return { file: laid, placed, notes, unchanged: sameFile(laid, options.unpack.file), ids, paths };

  /** A plain entity of the file: everything it has that differs from the defaults. */
  function plainEntity(e: ClipEntity, i: number): PrefabEntity {
    const name = nameOf(e);
    const ent: PrefabEntity = { id: plainId[i]!, ...(name !== null ? { name } : {}), parent: parentOf(i) };
    const components: string[] = [];
    const data: NonNullable<PrefabEntity['data']> = {};
    const refs: Record<string, Record<string, string | string[]>> = {};
    for (const [cname, fields] of Object.entries(e.data)) {
      const c = componentByName(cname);
      if (!carried(c) || c.kind !== 'data') continue;
      components.push(cname);
      for (const f of c.fields) {
        const v = fields[f.name];
        if (v === undefined || f.runtime) continue;
        if (isRef(c, f.name)) {
          const to = e.refs[`${cname}.${f.name}`];
          if (to !== undefined) (refs[cname] ??= {})[f.name] = address(to);
          continue;
        }
        if (!same(v, f.initial, f.type) && finite(i, `${cname}.${f.name}`, v)) (data[cname] ??= {})[f.name] = written(c, f.name, v, f.type);
      }
      // A vector any axis of which differs from its default: written whole, `[x, y, z]`.
      if (data[cname]) foldVectors(c, data[cname] as Record<string, FileValue>, (column) => tidy(fields[column] ?? 0, c.fields.find((x) => x.name === column)!.type));
    }
    if (components.length > 0) ent.components = components;
    if (Object.keys(data).length > 0) ent.data = data;
    const tags = e.tags.filter((t) => carried(componentByName(t)));
    if (tags.length > 0) ent.tags = tags;
    const objects: Record<string, unknown> = {};
    for (const [cname, value] of Object.entries(e.objects)) {
      const c = componentByName(cname);
      if (!carried(c)) continue;
      objects[cname] = isData(c) ? dataFile(c, value, (r) => (isClipRef(r) ? address(r.clip) : null)) : value;
    }
    if (Object.keys(objects).length > 0) ent.objects = objects;
    if (Object.keys(refs).length > 0) ent.refs = refs;
    const links = clip.links.filter((l) => l.source === i).map((l) => {
      const r = componentByName(l.relation);
      const differs: Record<string, number> = {};
      if (r?.kind === 'relation') for (const f of r.fields) if (l.data[f.name] !== undefined && !same(l.data[f.name]!, f.initial, f.type) && finite(i, `its ${l.relation} link's ${f.name}`, l.data[f.name]!)) differs[f.name] = tidy(l.data[f.name]!, f.type);
      return { relation: l.relation, to: address(l.target), ...(Object.keys(differs).length > 0 ? { data: differs } : {}) };
    });
    if (links.length > 0) ent.links = links;
    if ((e.layer ?? 0) !== 0) ent.layer = e.layer;
    const off = (e.off ?? []).filter((o) => carried(componentByName(o)));
    if (off.length > 0) ent.off = off;
    sayOutside(i);
    return ent;
  }

  /** What entity `i` of nested instance `u` changed from its node of the prefab; null for nothing. `present`: each node of it written, to its clip entity. */
  function overrideOf(e: ClipEntity, i: number, u: number, present: ReadonlyMap<number, number>): Override | null {
    const unit = units[u]!;
    const { p } = unit;
    const node = nodeIn[i]!;
    const inner = innerOf[i]!;
    const o: Override = { at: pathList(inner) };
    /** What the opened file's own overrides of this instance said at this entity: kept while it still says what the entity has. */
    const own = (options.unpack?.file.entities.find((x) => x.id === unit.id && nestedKey(x) === unit.key)?.overrides ?? []).filter((x) => x.at.join('/') === inner);
    const stated = (c: Component, f: string, v: number, type: FieldType): boolean => own.some((x) => {
      const was = fileEntry(c, x.set?.[c.name], f);
      // A key field's text as this page's id; a number as it is.
      return was !== undefined && same(fieldValue(c, f, was) ?? NaN, v, type);
    });
    const has = new Set<AnyComponent>();
    for (const cname of [...Object.keys(e.data), ...e.tags, ...Object.keys(e.objects)]) {
      const c = componentByName(cname);
      if (carried(c)) has.add(c);
    }
    const made = new Set(p.kinds[node]!.components.filter(carried));
    const add = [...has].filter((c) => !made.has(c)).map((c) => c.name);
    const remove = [...made].filter((c) => !has.has(c)).map((c) => c.name);
    if (add.length > 0) o.add = add;
    if (remove.length > 0) o.remove = remove;
    const set: NonNullable<Override['set']> = {};
    const refs: Record<string, Record<string, string[] | null>> = {};
    const objects: Record<string, unknown> = {};
    for (const c of has) {
      if (isData(c)) {
        // Field by field (D9): each that differs from the prefab's (its default where it gives none) written whole, its
        // refs paths inside the instance; one pointing out of it is left out, and said.
        const now = e.objects[c.name];
        if (now === undefined) continue;
        const then = made.has(c) ? (objectThen(p, c, node) as Record<string, unknown> | undefined) : undefined;
        const mine = mapFields(c.data, now, (r, path) => {
          if (!isClipRef(r)) return null;
          if (unitOf[r.clip] === u) return nodeIn[r.clip]!;
          notes.push(`${said(i)}: ${c.name}.${path} points at ${said(r.clip)}, outside ${unit.id} -- an override's ref points inside its instance: not kept`);
          return null;
        }) as Record<string, unknown>;
        const fields: Record<string, unknown> = {};
        for (const [f, el] of Object.entries(c.data)) {
          if (c.runtime.includes(f)) continue;
          const was = then && f in then ? then[f] : dataPlain(el, dataDefault(el), () => null);
          const stated = own.some((x) => (x.objects?.[c.name] as Record<string, unknown> | undefined)?.[f] !== undefined);
          if (f in mine && (stated || JSON.stringify(mine[f]) !== JSON.stringify(was))) fields[f] = mapRefs(el, mine[f], (r) => (typeof r === 'number' ? pathList(p.paths[r]!) : r));
        }
        if (Object.keys(fields).length > 0) objects[c.name] = fields;
        continue;
      }
      if (c.kind === 'object') {
        const now = e.objects[c.name];
        const then = made.has(c) ? objectThen(p, c, node) : undefined;
        if (now !== undefined && JSON.stringify(now) !== JSON.stringify(then)) objects[c.name] = now;
        continue;
      }
      if (c.kind !== 'data') continue;
      const fields = e.data[c.name]!;
      for (const [fi, f] of c.fields.entries()) {
        const v = fields[f.name];
        if (v === undefined || f.runtime) continue;
        if (isRef(c, f.name)) {
          const key: string = `${c.name}.${f.name}`;
          const then = made.has(c) ? refTarget(p, c, fi, node) : -1;
          const to = e.refs[key];
          if (to !== undefined && unitOf[to] === u) {
            if (nodeIn[to] !== then) (refs[c.name] ??= {})[f.name] = pathList(innerOf[to]!);
          } else if (to !== undefined) {
            notes.push(`${said(i)}: ${key} points at ${said(to)}, outside ${unit.id} -- an override's ref points inside its instance: not kept`);
          } else if (!(e.outside ?? []).some((x) => x.what === key) && then >= 0) {
            // Pointed at nobody where the nested prefab points it at one of its own: cleared, `null` (Docs/prefabs.md §2).
            (refs[c.name] ??= {})[f.name] = null;
          }
          continue;
        }
        const was = made.has(c) ? fullValue(p, c, fi, node) : f.initial;
        // The file's own override kept while it says this value, though the prefab has come to say it too: it is the
        // file's statement, and the prefab may change again.
        if ((!same(v, was, f.type) || stated(c, f.name, v, f.type)) && finite(i, `${c.name}.${f.name}`, v)) (set[c.name] ??= {})[f.name] = written(c, f.name, v, f.type);
      }
      // A vector overridden on any axis: the override holds it whole, `[x, y, z]`, as `overridesOf` writes it.
      if (set[c.name]) foldVectors(c, set[c.name] as Record<string, FileValue>, (column) => tidy(fields[column] ?? 0, c.fields.find((x) => x.name === column)!.type));
    }
    if (Object.keys(set).length > 0) o.set = set;
    const offNow = (e.off ?? []).filter((n) => carried(componentByName(n)));
    const offThen = new Set(p.off.filter((x) => x.node === node).map((x) => allComponents()[x.component]!.name));
    const off = offNow.filter((n) => !offThen.has(n));
    if (off.length > 0) o.off = off;
    // Switched on again: what the prefab switches off, the entity still has, and has on.
    const on = [...offThen].filter((n) => !offNow.includes(n) && [...has].some((c) => c.name === n));
    if (on.length > 0) o.on = on;
    if ((e.layer ?? 0) !== p.layers[node]) o.layer = e.layer ?? 0;
    const name = nameOf(e);
    if (name !== null && name !== p.names[node]) o.name = name;
    if (name === null && p.names[node] !== null) notes.push(`${said(i)}: its name ${p.names[node]} taken off -- an override names, never unnames: not kept`);
    if (Object.keys(objects).length > 0) o.objects = objects;
    if (Object.keys(refs).length > 0) o.refs = refs;
    // Under another entity of the instance than the prefab puts it: a parent override. Out of it: said.
    if (inner !== '') {
      const parent = e.parent;
      if (parent >= 0 && unitOf[parent] === u) {
        if (nodeIn[parent] !== p.parents[node]) o.parent = pathList(innerOf[parent]!);
      } else notes.push(`${said(i)}: moved out of ${unit.id}, under ${parent >= 0 ? said(parent) : 'nothing'} -- an override moves an entity within its instance: not kept`);
    }
    const links: NonNullable<Override['links']> = [];
    for (const l of clip.links) {
      if (l.source !== i) continue;
      const then = unitOf[l.target] === u ? linkData(p, l.relation, node, nodeIn[l.target]!) : null;
      if (!then) {
        notes.push(`${said(i)}: its ${l.relation} link to ${said(l.target)} is not kept -- an override sets a link's data, not a new link`);
        continue;
      }
      const differs: Record<string, number> = {};
      const r = componentByName(l.relation);
      for (const [fname, v] of Object.entries(l.data)) {
        const type = r?.kind === 'relation' ? (r.fields.find((f) => f.name === fname)?.type ?? 'f64') : 'f64';
        if (then[fname] !== undefined && !same(v, then[fname]!, type) && finite(i, `its ${l.relation} link's ${fname}`, v)) differs[fname] = tidy(v, type);
      }
      if (Object.keys(differs).length > 0) links.push({ relation: l.relation, to: pathList(innerOf[l.target]!), set: differs });
    }
    if (links.length > 0) o.links = links;
    // A link the prefab makes from it, both ends written, that the entity no longer has.
    for (const run of p.links) {
      for (let j = 0; j < run.source.length; j++) {
        if (run.source[j] !== node) continue;
        const target = present.get(run.target[j]!);
        if (target === undefined || clip.links.some((l) => l.source === i && l.target === target && l.relation === run.relation.name)) continue;
        notes.push(`${said(i)}: its ${run.relation.name} link to ${said(target)} is gone -- an override cannot take a link away: not kept`);
      }
    }
    sayOutside(i);
    return Object.keys(o).length > 1 ? o : null;
  }
}

// ---------------------------------------------------------------- the file's own layout

const isObject = (v: unknown): v is Record<string, unknown> => v !== null && typeof v === 'object' && !Array.isArray(v);
/** The lists that are sets of names: their order is the file's, not their meaning. */
const NAME_LISTS = new Set(['components', 'tags', 'off', 'on', 'add', 'remove']);

/** `neu` in `old`'s order: `old`'s keys first as `old` has them, then the new; a list of names likewise; a yes or no a file wrote kept where the number is its own. */
function ordered(neu: unknown, old: unknown, key = ''): unknown {
  if (typeof old === 'boolean' && typeof neu === 'number' && neu === (old ? 1 : 0)) return old;
  if (Array.isArray(neu) && Array.isArray(old) && NAME_LISTS.has(key)) {
    return [...old.filter((x) => neu.includes(x)), ...neu.filter((x) => !old.includes(x))];
  }
  if (Array.isArray(neu) && Array.isArray(old) && key === 'links') {
    const id = (l: unknown): string => JSON.stringify([(l as { relation?: unknown }).relation, (l as { to?: unknown }).to]);
    const olds = new Map(old.map((l) => [id(l), l]));
    const kept = old.flatMap((l) => neu.filter((n) => id(n) === id(l)));
    return [...kept, ...neu.filter((n) => !olds.has(id(n)))].map((n) => ordered(n, olds.get(id(n))));
  }
  if (!isObject(neu) || !isObject(old)) return neu;
  // `old`'s keys in its order; a new one after the key `neu` has before it (`data` after `components`), so it is a line of its own.
  const keys = Object.keys(old).filter((k) => k in neu);
  const theirs = Object.keys(neu);
  theirs.forEach((k, i) => {
    if (keys.includes(k)) return;
    let at = -1;
    for (let j = i - 1; j >= 0 && at < 0; j--) at = keys.indexOf(theirs[j]!);
    keys.splice(at + 1, 0, k);
  });
  const out: Record<string, unknown> = {};
  for (const k of keys) out[k] = k in old ? ordered(neu[k], old[k], k) : neu[k];
  return out;
}

/**
 * A nested instance's overrides in the order and grouping its file had: each
 * old override takes, at its `at`, what it said before; what is new for an
 * `at` joins the first that has it, and an `at` new to the file goes after.
 */
function orderedOverrides(neu: readonly Override[], old: readonly Override[]): Override[] {
  const atOf = (o: Override): string => o.at.join('/');
  const left = new Map(neu.map((o) => [atOf(o), { ...o } as Record<string, unknown>]));
  const out: Record<string, unknown>[] = [];
  const firstAt = new Map<string, Record<string, unknown>>();
  for (const was of old) {
    const now = left.get(atOf(was));
    if (!now) continue;
    const part: Record<string, unknown> = { at: now.at };
    for (const k of Object.keys(was)) {
      if (k === 'at' || !(k in now)) continue;
      part[k] = ordered(now[k], (was as unknown as Record<string, unknown>)[k], k);
      delete now[k];
    }
    if (Object.keys(part).length > 1) {
      out.push(part);
      if (!firstAt.has(atOf(was))) firstAt.set(atOf(was), part);
    }
  }
  for (const [at, now] of left) {
    const rest = Object.keys(now).filter((k) => k !== 'at');
    if (rest.length === 0) continue;
    const first = firstAt.get(at);
    if (first) for (const k of rest) first[k] = now[k];
    else out.push(now);
  }
  return out as unknown as Override[];
}

/** `file` laid out as `old`: its entities in `old`'s order by id, the new after; each in `old`'s key order; overrides as `orderedOverrides`. */
export function keepLayout(file: PrefabFile, old: PrefabFile): PrefabFile {
  const olds = new Map(old.entities.map((e) => [e.id, e]));
  const byId = new Map(file.entities.map((e) => [e.id, e]));
  const order = [...old.entities.filter((e) => byId.has(e.id)).map((e) => byId.get(e.id)!), ...file.entities.filter((e) => !olds.has(e.id))];
  const entities = order.map((e) => {
    const was = olds.get(e.id);
    if (!was) return e;
    const laid = ordered(e, was) as PrefabEntity;
    if (e.overrides && was.overrides) laid.overrides = orderedOverrides(e.overrides, was.overrides);
    return laid;
  });
  return ordered({ ...file, entities }, old) as PrefabFile;
}

/** The same file in meaning as JSON says it: every value alike, keys in any order. */
export function sameFile(a: unknown, b: unknown): boolean {
  if (Array.isArray(a) || Array.isArray(b)) return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((x, i) => sameFile(x, b[i]));
  if (isObject(a) || isObject(b)) {
    if (!isObject(a) || !isObject(b)) return false;
    const ka = Object.keys(a).filter((k) => a[k] !== undefined);
    const kb = Object.keys(b).filter((k) => b[k] !== undefined);
    return ka.length === kb.length && ka.every((k) => sameFile(a[k], b[k]));
  }
  return a === b;
}
