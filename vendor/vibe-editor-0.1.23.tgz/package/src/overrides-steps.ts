/**
 * Revert, Apply and Unpack as steps of the editor's history (Docs/prefabs.md
 * §7): what the inspector's marks, the Overrides list and the agent's
 * `scene_override` do (`overrides-edit.ts` works out each).
 *
 * - **Revert and Unpack are world steps**: the world changed, committed --
 *   `Revert OvTurn.speed`, `Unpack big crate` -- no file.
 * - **Apply is one step with files in it**, as Save as prefab is: the target
 *   prefab's file (and each between, taken out of the way) written through
 *   `PUT prefab`, the dev server's push recompiling it, and the live update
 *   that brings every instance out up to it run inside the step
 *   (`livePrefabs.hold`) rather than as a step of its own. Undone, each file
 *   is written back to its text before the Apply, through the same route, and
 *   once compiled the world put back as it was before the update; redone, the
 *   files written again and, once compiled, the world after it put back. The
 *   files always land first: a save is loaded against the compile it was made
 *   under, else its instances' nodes are found in the wrong prefab (an Apply
 *   that added or removed a node). The file's own
 *   history is git's.
 * - **Each side's world keeps its instances' overrides** (`sceneSave`), and is
 *   brought up to the prefabs as compiled when it is put back (`putBack`):
 *   another prefab compiled anew while it landed -- its live update held with
 *   the landing's -- is brought up to inside the step, and said, never loaded
 *   over (its instances would show the old values as overrides).
 * - **Held while it lands**: from the Apply's first write to its compile, and
 *   from its undo's or redo's to theirs, `holding` says why -- "Undoing the
 *   Apply: a moment" -- and every way of changing the world or its history
 *   waits or is refused, said ("Playtest: not now -- Undoing the Apply: a
 *   moment"). Held in one place each, so what is added later is held unless
 *   it says it only looks: the list of what is held, and what waits, is
 *   `hold.ts`' header, and only there.
 * - **An entity added, applied, is the instance's own**: the update makes it
 *   as a node of the prefab, and the one that was added goes with the step --
 *   what pointed at it (a ref anywhere in the world, the selection) pointed
 *   at the node made in its place, and what systems set on it carried over
 *   (`takeRuntime`), as Save as prefab does.
 * - **Refused up front, nothing written, for what game code names**: an Apply
 *   that would leave a node game code names (`BigCrate.node('rider')`) no
 *   entity is the compile's check's (`checkPrefab`), and says where the code
 *   is -- `export const RiderOfBig = BigCrate.node('rider')` in
 *   `src/game/prefabs.ts:20` -- as a rename of a prefab game code names does.
 * - **Never over someone else's edit**: a file whose text on the page is not
 *   what the instances out were compiled from -- changed on disk since, by
 *   hand, the agent or a pull, its compile failed or not in yet -- is refused
 *   once, in words (`on-disk.ts`); the same Apply again, the file still saying
 *   the same, writes over it.
 * - **Its file calls run one after another**, never two at once (`inTurn`).
 *
 * Pure but for the host handed in: node tests it with a fake dev server
 * (`overrides-steps.test.ts`).
 */
import { Hierarchy, NO_REF, NONE, plainSave, sceneSave, type Component, type Entity, type EntityRef, type PrefabFile, type World, type WorldSave } from '@vibe/engine';
import { prefabPathOf } from './assets/ui/prefab-steps.ts';
import { putRuntime, takeRuntime } from './bring-up.ts';
import type { History, Step } from './history.ts';
import { diskChange, knownOf } from './on-disk.ts';
import { planApply, revertItems, unpack, type Item } from './overrides-edit.ts';
import { PENDING, type WorldSteps } from './world-steps.ts';

export interface OverrideStepsHost {
  readonly world: World;
  /** The world's history -- never a tool's own. */
  readonly history: History;
  readonly worldSteps: WorldSteps;
  /**
   * A save put back, as an undo puts one back (`Game.load`): where it holds its
   * instances' overrides (a scene save's table), they are brought up to the
   * prefabs as compiled now, as a scene's are as it loads. `era`: what `era`
   * said as the save was taken -- the renames made since are replayed on it.
   */
  load(save: WorldSave, era: number): void;
  /** The editor's count of prefab renames (`renames.ts`): the era a save taken now is of. Absent: always 0. */
  era?(): number;
  /**
   * Prefab files by key, written in `era`, as they are to be written now: each under its key now, the prefabs it
   * nests named as now (`renames.followFiles`) -- an Apply's undo after its prefab was renamed writes the renamed
   * file, never the old key's made again. Absent: as they are.
   */
  followFiles?(files: ReadonlyMap<string, string>, era: number): Map<string, string>;
  /** Every prefab file as the page holds it. */
  files(): Readonly<Record<string, PrefabFile>>;
  /** The file `key` as the last good compile compiled it -- what the instances out were made from -- or undefined. */
  compiled(key: string): PrefabFile | undefined;
  /** `PUT prefab`: a file's text written. */
  put(path: string, text: string): Promise<unknown>;
  /** Settles once every file of `texts` is compiled, its live update run: null; else what went wrong (`whenLanded`). */
  landed(texts: ReadonlyMap<string, string>): Promise<string | null>;
  /**
   * While set, the live update runs through `hold`, not as a step of its own
   * (`livePrefabs.hold`) -- unless it says `false`: not its compile, the update
   * run as ever. `keys`: the prefabs it brings instances up to.
   */
  hold(hold: ((update: () => void, keys: readonly string[]) => boolean | void) | null): void;
  /**
   * Is the editor up, its world the one the stack is of -- not closed with the
   * game running, not in a playtest? A late landing (`notLanded`) puts its world
   * back only then; otherwise the plain live update runs, the step left where it
   * is. Absent: always.
   */
  live?(): boolean;
  /** The compile's checks of a file about to be written: null if it compiles, else why not. */
  check?(key: string, files: Record<string, PrefabFile>): string | null;
  /** The world changed under the tools, later than the step (an undo's or a redo's files landing, or not): read it again, the bars too. */
  told(): void;
  /** The editor's line, saying what went wrong: an Apply's undo or redo that could not land -- short, and `full` on hover. */
  say?(line: string, full?: string): void;
  /**
   * An Apply, or its undo or redo, began landing (`line`: what to say
   * meanwhile, "Undoing the Apply: a moment"), or every one is done (null):
   * world edits are held until then (`holding`).
   */
  landing?(line: string | null): void;
  /** The lines of game code (`.ts`, outside the editor) holding `literal` as a string: where a node it names is (`GET uses`). */
  uses?(literal: string): Promise<readonly { file: string; line: number; text: string }[]>;
  /** The selection, and the selection made: an entity applied and made anew is selected as it was. */
  selected?(): readonly Entity[];
  choose?(es: readonly Entity[]): void;
}

/** How long a `PUT prefab` may take before the dev server is taken for gone, in milliseconds. */
const PUT_MS = 8000;
/** What a write the dev server never answered says. */
const SILENT = 'the dev server did not answer';

/** An entity added and about to be applied: where it hangs, what it is, and what points at it -- to carry over to the node made. */
interface Carried {
  parent: Entity;
  /** It and everything under it, depth first. */
  subtree: Entity[];
  runtime: ReturnType<typeof takeRuntime>;
  /** Each ref in the world pointing into it: the holder (or its place in `subtree`), and the target's place. */
  refs: { holder: Entity; inside: number; component: Component; field: string; at: number }[];
}

type Tree = Record<'parent' | 'firstChild' | 'nextSibling', { [i: number]: number }>;

/** `e` and everything under it, depth first. */
function subtreeOf(world: World, e: Entity): Entity[] {
  const tree = world.rawStore(Hierarchy) as Tree;
  const out: Entity[] = [];
  const walk = (x: Entity): void => {
    out.push(x);
    for (let c = tree.firstChild[x]!; c !== 0; c = tree.nextSibling[c]!) walk(c as Entity);
  };
  walk(e);
  return out;
}

/** What of the world points at `e`'s subtree, taken before it is destroyed. */
function carryOut(world: World, e: Entity): Carried {
  const parent = (world.rawStore(Hierarchy) as Tree).parent[e]! as Entity;
  const subtree = subtreeOf(world, e);
  const place = new Map(subtree.map((x, i) => [x, i]));
  const refs: Carried['refs'] = [];
  for (const c of world.allComponents) {
    if (c.kind !== 'data') continue;
    const fields = c.fields.filter((f) => (c.schema as Record<string, { ref?: true }>)[f.name]?.ref === true);
    if (fields.length === 0) continue;
    const columns = world.rawStore(c) as Record<string, { [i: number]: number }>;
    for (let h = 1; h < world.extent; h++) {
      if (!world.alive(h as Entity) || !world.has(h as Entity, c)) continue;
      for (const f of fields) {
        const at = place.get(world.deref(columns[f.name]![h]! as EntityRef));
        if (at !== undefined) refs.push({ holder: h as Entity, inside: place.get(h as Entity) ?? -1, component: c as Component, field: f.name, at });
      }
    }
  }
  return { parent, subtree, runtime: takeRuntime(world, subtree), refs };
}

/** The children of each parent of `carried` as they are before the update, by ref: one made later in a destroyed one's slot is not one of them. */
function childrenOf(world: World, carried: readonly Carried[]): Set<EntityRef> {
  const tree = world.rawStore(Hierarchy) as Tree;
  const out = new Set<EntityRef>();
  for (const c of carried) for (let x = tree.firstChild[c.parent]!; x !== 0; x = tree.nextSibling[x]!) out.add(world.ref(x as Entity));
  return out;
}

/**
 * The nodes the update made under each parent of `carried`: the instance's
 * entities there that were not (`had`, by ref), in node order -- the order
 * the writer wrote them in, which is `carried`'s -- each paired with its
 * carried entity by that place. Never by name: two added under one parent
 * may share one.
 */
function madeFor(world: World, root: Entity, had: ReadonlySet<EntityRef>, carried: readonly Carried[]): (Entity | undefined)[] {
  const tree = world.rawStore(Hierarchy) as Tree;
  const byParent = new Map<Entity, Entity[]>();
  return carried.map((c) => {
    if (!world.alive(c.parent)) return undefined;
    let made = byParent.get(c.parent);
    if (!made) {
      made = [];
      for (let x = tree.firstChild[c.parent]!; x !== 0; x = tree.nextSibling[x]!) {
        const e = x as Entity;
        if (world.instanceRoot(e) === root && !had.has(world.ref(e))) made.push(e);
      }
      made.sort((a, b) => world.nodeOf(a) - world.nodeOf(b));
      byParent.set(c.parent, made);
    }
    return made.shift();
  });
}

/** `c` given to `made`, the node the update made in its place: refs re-pointed, runtime values carried; each old entity to its new in `moved`. */
function carryIn(world: World, c: Carried, made: Entity | undefined, moved: Map<Entity, Entity>): void {
  if (made === undefined) return;
  const subtree = subtreeOf(world, made);
  // Matched place for place, as the writer writes the clip in order; one that differs is matched as far as it goes.
  const to = c.subtree.map((_, i) => subtree[i] ?? null);
  c.subtree.forEach((old, i) => {
    if (to[i]) moved.set(old, to[i]!);
  });
  putRuntime(world, c.runtime, to);
  for (const r of c.refs) {
    const holder = r.inside >= 0 ? to[r.inside] : r.holder;
    const target = to[r.at];
    if (!holder || !world.alive(holder) || !world.has(holder, r.component)) continue;
    (world.rawStore(r.component) as Record<string, { [i: number]: number }>)[r.field]![holder] = target ? world.ref(target) : NO_REF;
  }
}

/** Whose step it is, and the step once made: the agent's are `Claude: Revert …`, and it keeps its own step, not the one on top. */
export interface StepOptions {
  /** Before the step's label: `Claude: `. */
  prefix?: string;
  /** The step, as it goes on the stack. */
  made?(step: Step): void;
}

export interface OverrideSteps {
  /** `items` reverted: one world step. What to say; throws while an Apply's undo or redo lands (`holding`). */
  revert(root: Entity, items: readonly Item[], options?: StepOptions): string;
  /** Unpacked, one level or `completely`: one world step. What to say; throws, in words, for what cannot be (one landing too). */
  unpack(root: Entity, completely: boolean, options?: StepOptions): string;
  /** `items` applied to prefab `target`: one step, files and world. Resolves to what to say; rejects with why nothing was done (one landing too). */
  apply(root: Entity, items: readonly Item[], target: string, options?: StepOptions): Promise<string>;
  /** An Apply, or its undo or redo, still landing: every stack waits (`active-history.ts`'s `worldBusy`). */
  busy(): boolean;
  /**
   * While one lands, what a world edit is refused with -- "Undoing the Apply:
   * a moment" -- else null: the inspector, the gizmo, the tree, Spawn, a drop
   * and the agent's editor tools wait for it (`world-steps.ts`' `held` puts
   * back one that got through), or the world it loads would be loaded over them.
   */
  holding(): string | null;
  /** Resolves once nothing lands: at once if nothing does. What the agent's editor tools wait for. */
  idle(): Promise<void>;
  /**
   * While an Apply's undo or redo lands with its files written: the world it
   * puts back once they compile -- what a reload meanwhile keeps, as the page
   * after it compiles those files (`editor.ts`' `prepareReload`). Else null.
   */
  landingTo(): WorldSave | null;
  /**
   * What a reload has to be told (the resume record's `notes`): each Apply
   * whose undo or redo could not land, and so is in the prefab files as the
   * stack no longer is after the reload -- and how to take it back.
   */
  notes(): string[];
}

export function createOverrideSteps(host: OverrideStepsHost): OverrideSteps {
  const { world, history, worldSteps } = host;
  /** The file calls of every step, one after another. */
  let queue: Promise<unknown> = Promise.resolve();
  /** Jobs queued and not yet done, and an Apply under way. */
  let waiting = 0;
  /** What `holding` says of the one landing now: "Undoing the Apply: a moment". */
  let holdText = '';
  /** An Apply under way, settled once it is done either way: what `idle` waits for besides the queue. */
  let applying: Promise<unknown> = Promise.resolve();
  /** Its own world steps, while a job makes one (a landing under another edit): not held. */
  let ours = false;
  /** Each Apply whose undo or redo could not land, what a reload is told of it (`notes`): until it lands. */
  const stranded = new Map<Step, string>();
  /** The world a landing under way puts back once its files are written: what a reload meanwhile keeps (`landingTo`). */
  let landingWorld: string | null = null;
  const holdLine = (): string => holdText;
  const landingText = (what: 'undo' | 'redo'): string => `${what === 'undo' ? 'Undoing' : 'Redoing'} the Apply: a moment`;
  /** Edits held from now (`holding`), saying `text`, until `waiting` is back to 0. */
  const begin = (text: string): void => {
    waiting++;
    if (waiting === 1) {
      holdText = text;
      host.landing?.(text);
    }
  };
  /**
   * `job` after every one before it. The last one done, the tools are told --
   * once nothing waits, so the bars drawn then have Undo and Redo back.
   */
  const inTurn = (what: 'undo' | 'redo', job: () => Promise<unknown>): void => {
    begin(landingText(what));
    queue = queue.then(() => {
      holdText = landingText(what);
      return job();
    })
      .catch((err: unknown) => console.warn(`[editor] apply: ${err instanceof Error ? err.message : String(err)}`))
      .finally(() => {
        waiting--;
        if (waiting > 0) return;
        host.landing?.(null);
        host.told();
      });
  };
  /** Is `step` where the stack put it as its undo (`undoing`) or redo began: just above what is done, or the last done? */
  const inPlace = (step: Step, undoing: boolean): boolean => history.steps[undoing ? history.done : history.done - 1] === step;
  /**
   * The files landed but the stack moved on meanwhile (an edit got past the
   * hold, a scene was loaded): the world from before is not loaded over what
   * is there. The live update the landing held runs instead, as any change
   * on disk does -- a step of its own.
   */
  function landedUnder(undoing: boolean, updates: readonly Held[]): void {
    ours = true;
    try {
      worldSteps.commit(PENDING);
      for (const { run } of updates) run();
      world.flush();
      worldSteps.commit('Prefabs updated');
    } finally {
      ours = false;
    }
    host.say?.(`The Apply's ${undoing ? 'undo' : 'redo'} landed under another edit: the prefab files are ${undoing ? 'undone' : 'redone'}, and the world followed them as a step of its own · Z undoes that`);
  }
  /** A file's text on the page refused once because it is not what was compiled: the same text again writes over it. */
  const warned = new Map<string, string>();

  /** `PUT prefab`, given up on after `PUT_MS`: a dev server that took the connection and hangs never holds Undo for long. */
  async function put(key: string, text: string): Promise<void> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const late = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(SILENT)), PUT_MS);
    });
    try {
      await Promise.race([host.put(prefabPathOf(key), text), late]);
    } catch (err) {
      // Nothing came back, or the connection failed (fetch's TypeError): the words a person needs.
      throw new Error(err instanceof Error && (err.message === SILENT || err instanceof TypeError) ? SILENT : err instanceof Error ? err.message : String(err));
    } finally {
      clearTimeout(timer);
    }
  }

  /** Is every file of `texts` what the last good compile compiled? */
  const compiledAs = (texts: ReadonlyMap<string, string>): boolean =>
    [...texts].every(([k, text]) => {
      const now = host.compiled(k);
      return now !== undefined && JSON.stringify(now) === JSON.stringify(JSON.parse(text));
    });

  /**
   * `texts` written, waited for, with the live update passed by -- kept in
   * `held`: the world is put back after, from a save. Null once they compiled; else why not, and
   * whether they are on disk (`written`: their compile did not come in time)
   * -- a write that failed part way through is written back to `back` first.
   */
  async function writeQuiet(texts: ReadonlyMap<string, string>, back: ReadonlyMap<string, string>, held: Held[] = [], landsAs?: string): Promise<{ why: string; written: boolean } | null> {
    // Kept, not run: the world is loaded instead -- unless the stack moved on meanwhile (`landedUnder`).
    // A host from before the keys were passed names none: nothing to say of it.
    host.hold((run, keys) => void held.push({ run, keys: keys ?? [] }));
    try {
      const done: string[] = [];
      try {
        for (const [key, text] of texts) {
          await put(key, text);
          done.push(key);
        }
        // On disk: a reload from here on finds the files as the step's other side has them, so it keeps that world.
        if (landsAs !== undefined) landingWorld = landsAs;
      } catch (err) {
        const why = err instanceof Error ? err.message : String(err);
        try {
          for (const key of done.reverse()) await put(key, back.get(key)!);
        } catch {
          return { why: `${why} -- and ${done.join(', ')} could not be written back: Z or Y again once it answers`, written: false };
        }
        return { why, written: false };
      }
      const why = await host.landed(texts);
      return why === null ? null : { why, written: true };
    } finally {
      host.hold(null);
      landingWorld = null;
    }
  }

  /**
   * `save` -- the world a side of an Apply keeps, with its instances' overrides
   * -- put back once its files landed: its instances brought up to the
   * prefabs as compiled now (`host.load`). A prefab outside the step's files
   * compiled anew meanwhile (`held`: its live update was held with the
   * step's) is so brought up to inside it, and said: never loaded over.
   */
  function putBack(save: string, era: number, texts: ReadonlyMap<string, string>, held: readonly Held[], what: 'undo' | 'redo'): void {
    host.load(JSON.parse(save) as WorldSave, era);
    worldSteps.sync();
    const others = [...new Set(held.flatMap((h) => h.keys))].filter((k) => !texts.has(k));
    if (others.length > 0) host.say?.(`${others.join(', ')} changed while the Apply's ${what} landed: brought up to it as the world was put back`);
  }

  /**
   * An Apply's undo (`done` false: the stack had moved it to undone) or redo
   * that could not land: the step back where it was, unrun -- the world and
   * the files still as that side has them -- and the line says why, short,
   * the whole of it on hover and on the step's row in the History card
   * (`Step.note`). Files written whose compile did not come in time may yet:
   * until another write, the live update of exactly them is held, and
   * finishes the move then -- `world` loaded, the step moved on -- never a
   * step of its own.
   */
  function notLanded(step: Step, undoing: boolean, failed: { why: string; written: boolean }, world: string, era: number, texts: ReadonlyMap<string, string>, applied: string): void {
    const what = undoing ? 'undo' : 'redo';
    const back = history.place(step, undoing);
    const name = step.label.replace(/^.*?Apply to /, '');
    const key = undoing ? 'Z' : 'Y';
    // What works once the stack cannot -- the reload a dev server's restart makes takes it -- and only that: undone,
    // the instances hold the prefab's values (no override to Revert); redone, the instance applied from still shows its own.
    const ways = undoing
      ? `open ${name}, put back what it took (${applied}) and save it -- or take ${prefabPathOf(name)} back with git, if it was committed before the Apply`
      : `Apply ${applied} to ${name} again from the instance that shows it`;
    if (!failed.written) {
      const holds = undoing ? `the prefab files still hold the Apply to ${name}` : `the prefab files still hold the Apply to ${name} undone`;
      // Short to its ` -- ` (the line after the reload says that much, the rest on hover), the value before named in it.
      stranded.set(step, undoing
        ? `${name} still holds the Apply (before it: ${applied}) -- its undo could not land before the reload: open ${name}, put back what it took and save it, or git`
        : `${name} still holds the Apply undone -- its redo could not land before the reload: Apply ${applied} again`);
      const full = back
        ? `Could not ${what} the Apply to ${name}: ${failed.why}. ${cap(holds)}, and the world and the stack are as they were: ${key} again once the dev server answers. If it restarts, the page reloads and the history goes with it: then ${ways}.`
        : `Could not ${what} the Apply to ${name}: ${failed.why}. ${cap(holds)}, and the stack has moved on -- it is no step there any more: ${ways}.`;
      step.note = back ? full : undefined;
      history.touch();
      host.say?.(back ? `Could not ${what} the Apply to ${name} (${failed.why}): ${key} again once it answers` : `Could not ${what} the Apply to ${name} (${failed.why}): the files still hold it`, full);
      return;
    }
    const full = back
      ? `Could not ${what} the Apply to ${name}: ${failed.why}. The prefab files hold the ${what}; the world and the stack follow them once they compile -- else ${key} again.`
      : `Could not ${what} the Apply to ${name}: ${failed.why}. The prefab files hold the ${what}; the stack has moved on, and the world follows them as a step of its own once they compile.`;
    step.note = back ? full : undefined;
    history.touch();
    host.say?.(`The Apply's ${what} is written, not compiled yet (${failed.why}): the world follows once it is`, full);
    // The update itself is not run: the world the step keeps for that side is loaded instead.
    host.hold((_run, keys) => {
      if (!compiledAs(texts)) return false;
      host.hold(null);
      // The editor closed, or a playtest running: the world live is not the stack's to load over. The update runs
      // plain, as any change on disk does; the step stays where it is, its note saying Z or Y again.
      if (host.live && !host.live()) return false;
      // The stack moved on since: what is on disk now is brought up to as any change is, a step of its own.
      if (history.steps[undoing ? history.done - 1 : history.done] !== step) return false;
      stranded.delete(step);
      step.note = undefined;
      putBack(world, era, texts, [{ run: () => undefined, keys: keys ?? [] }], what);
      history.place(step, !undoing);
      host.say?.(`The Apply's ${what} landed late: ${undoing ? 'undone' : 'redone'}, files and world`);
      host.told();
    });
  }

  /**
   * A refusal that names a node game code names (`crates/big.node('rider')`):
   * where in the code, as a rename's does. Asked of the dev server; without
   * one, the words as they are.
   */
  async function whereNamed(why: string): Promise<string> {
    const named = [...why.matchAll(/\.node\('([^']+)'\)/g)].map((m) => m[1]!);
    if (named.length === 0 || !host.uses) return why;
    const lines: string[] = [];
    for (const name of new Set(named)) {
      const found = await host.uses(name).catch(() => []);
      for (const u of found) if (u.file.endsWith('.ts') && /\.node\(/.test(u.text)) lines.push(`${u.text} in ${u.file}:${u.line}`);
    }
    return lines.length > 0 ? `${why}: ${lines.join(', ')}` : why;
  }

  /** `apply`, planned and checked: its files written, the update held into its step. */
  async function applyPlanned(root: Entity, plan: ReturnType<typeof planApply>, target: string, options: StepOptions): Promise<string> {
    /**
     * The world before the Apply, with its instances' overrides against the compile they were made from (`sceneSave`):
     * what Undo puts back, once its files land -- brought up then to the prefabs as compiled, so one another prefab
     * changed meanwhile is never loaded over (`putBack`).
     */
    const before = JSON.stringify(sceneSave(world));
    /** The renames made so far: `before` and `after` are of this era, put back with only the renames made since. */
    const era = host.era?.() ?? 0;
    /** Whether the live update ran: only then is there a world to put back if the Apply fails. */
    let updated = false;
    const texts = new Map(plan.writes.map((w) => [w.key, w.text]));
    const befores = new Map(plan.writes.map((w) => [w.key, w.before]));
    /** This era's files as they are to be written now: the renames made since followed. */
    const follow = (files: ReadonlyMap<string, string>): Map<string, string> => host.followFiles?.(files, era) ?? new Map(files);
    host.hold((update) => {
      worldSteps.commit(PENDING);
      updated = true;
      // An entity added and applied is the prefab's now: the update makes it as the instance's own, so the one
      // added goes -- else it would be there twice -- and what pointed at it points at the one made.
      const added = plan.applied.filter((i) => i.part.kind === 'added' && world.alive(i.entity));
      const carried = added.map((i) => carryOut(world, i.entity));
      const chosen = host.selected?.() ?? [];
      const had = childrenOf(world, carried);
      for (const i of added) world.destroy(i.entity);
      world.flush();
      update();
      if (carried.length === 0) return;
      const moved = new Map<Entity, Entity>();
      const made = madeFor(world, root, had, carried);
      carried.forEach((c, i) => carryIn(world, c, made[i], moved));
      world.flush();
      if (chosen.some((e) => moved.has(e))) host.choose?.(chosen.map((e) => moved.get(e) ?? e).filter((e) => e !== NONE && world.alive(e)));
    });
    let why: string | null = null;
    const done: string[] = [];
    try {
      for (const w of plan.writes) {
        await put(w.key, w.text);
        done.push(w.key);
      }
      why = await host.landed(texts);
    } catch (err) {
      why = err instanceof Error ? err.message : String(err);
    } finally {
      host.hold(null);
    }
    if (why !== null) {
      // Back as it was: each file written back, the world as it was before any update.
      // The files first, so the save is loaded against the compile it was made under.
      const undo = new Map([...befores].filter(([k]) => done.includes(k)).reverse());
      if (undo.size > 0) await writeQuiet(undo, texts).catch(() => undefined);
      // Exactly as it was, nothing brought up: the files may not be back.
      if (updated) host.load(plainSave(JSON.parse(before) as WorldSave), era);
      worldSteps.sync();
      host.told();
      throw new Error(`nothing applied: ${why}`);
    }
    world.flush();
    // With its overrides against the compile the Apply made, as `before` is against the one before (`putBack`).
    const after = JSON.stringify(sceneSave(world));
    const was = before;
    const what = plan.applied.length === 1 ? plan.applied[0]!.what : `${plan.applied.length} overrides`;
    /** What was applied, by name, for a line that says how to set it back: the first few. */
    const first = (list: string[]): string => (list.length <= 3 ? list.join(', ') : `${list.slice(0, 2).join(', ')} and ${list.length - 2} more`);
    const named = first(plan.applied.map((i) => i.what));
    // For an undo, with the value before -- what the prefab gave, `Spin.speed 0.6` -- which neither Z nor the person has after a reload.
    const namedWas = first(plan.applied.map((i) => (i.part.kind === 'set' || i.part.kind === 'layer' || i.part.kind === 'name' ? `${i.what} ${i.was}` : i.what)));
    const label = `${options.prefix ?? ''}Apply to ${target}`;
    const step: Step = {
      label,
      size: was.length + after.length,
      // As redo: the files back and compiled first, then the world loaded against that compile.
      // One that cannot land puts the step back (`notLanded`).
      // Each checks the step is still where the stack put it before it loads anything: else the world is not its to put back.
      undo: () => {
        inTurn('undo', async () => {
          // Under the keys they have now: a prefab renamed since the Apply is written as itself.
          const back = follow(new Map([...befores].reverse()));
          const held: Held[] = [];
          const failed = await writeQuiet(back, follow(texts), held, was);
          if (failed) return notLanded(step, true, failed, was, era, back, namedWas);
          stranded.delete(step);
          step.note = undefined;
          if (!inPlace(step, true)) return landedUnder(true, held);
          putBack(was, era, back, held, 'undo');
        });
      },
      redo: () => {
        inTurn('redo', async () => {
          const held: Held[] = [];
          const forth = follow(texts);
          const failed = await writeQuiet(forth, follow(befores), held, after);
          if (failed) return notLanded(step, false, failed, after, era, forth, named);
          stranded.delete(step);
          step.note = undefined;
          if (!inPlace(step, false)) return landedUnder(false, held);
          putBack(after, era, forth, held, 'redo');
        });
      },
    };
    history.push(step);
    options.made?.(step);
    const also = plan.writes.filter((w) => w.key !== target).map((w) => w.key);
    const left = plan.left.length > 0 ? ` · ${plan.left.length} left: ${target} cannot hold ${plan.left.map((i) => i.what).join(', ')}` : '';
    return `Applied ${what} to ${target}${also.length > 0 ? `, and taken out of ${also.join(', ')}, which overrode it` : ''}: every instance takes it where it holds no override of its own · Z undoes, files and world${left}`;
  }

  return {
    busy: () => waiting > 0,
    holding: () => (waiting > 0 && !ours ? holdLine() : null),
    notes: () => [...stranded.values()],
    landingTo: () => (landingWorld === null ? null : (JSON.parse(landingWorld) as WorldSave)),
    async idle() {
      while (waiting > 0) await Promise.all([queue, applying]);
    },
    revert(root, items, options = {}) {
      // While an Apply's undo or redo lands, its world would be loaded over this: said, nothing done.
      if (waiting > 0) throw new Error(holdLine());
      worldSteps.commit(PENDING);
      revertItems(world, root, items);
      const label = `${options.prefix ?? ''}Revert ${items.length === 1 ? items[0]!.what : `${items.length} overrides`}`;
      if (worldSteps.commit(label)) options.made?.(history.steps[history.done - 1]!);
      return label;
    },
    unpack(root, completely, options = {}) {
      if (waiting > 0) throw new Error(holdLine());
      worldSteps.commit(PENDING);
      const n = unpack(world, root, completely);
      world.flush();
      const label = completely ? 'Unpack completely' : 'Unpack';
      if (worldSteps.commit(`${options.prefix ?? ''}${label}`)) options.made?.(history.steps[history.done - 1]!);
      return `${label}: ${n} ${n === 1 ? 'entity' : 'entities'} no longer linked to the prefab${completely ? '' : ' -- what it nests stays an instance of its own prefab'} · Z undoes`;
    },
    async apply(root, items, target, options = {}) {
      if (waiting > 0) throw new Error(holdLine());
      worldSteps.commit(PENDING);
      world.flush();
      const files = host.files();
      let plan: ReturnType<typeof planApply>;
      try {
        plan = planApply(world, root, items, target, files, host.check);
      } catch (err) {
        throw new Error(await whereNamed(err instanceof Error ? err.message : String(err)));
      }
      // A file the page holds that is not what was compiled: someone else's edit, said once before it is written over.
      for (const w of plan.writes) {
        const was = host.compiled(w.key);
        if (!was) continue;
        const change = diskChange(w.key, knownOf(w.key, was, files), files);
        if (!change) continue;
        const now = change.how === 'changed' ? change.text : '';
        if (change.how === 'changed' && warned.get(w.key) === now) continue;
        if (change.how === 'changed') warned.set(w.key, now);
        throw new Error(change.how === 'changed'
          ? `${w.key} changed on disk since it was compiled -- an Apply would write over that: Apply again to write over it, or wait for it to compile`
          : `${w.key} is gone from disk since it was compiled: nothing to apply to`);
      }
      for (const w of plan.writes) warned.delete(w.key);
      // Held from here until it is done, as its undo and redo are: an edit made meanwhile would be in the world the update
      // brings up, and in no step -- or, an undo, loaded under it.
      begin(`Applying to ${target}: a moment`);
      const run = applyPlanned(root, plan, target, options);
      applying = run.catch(() => undefined);
      try {
        return await run;
      } finally {
        waiting--;
        if (waiting === 0) host.landing?.(null);
      }
    },
  };
}

/** A live update held while an Apply or its undo or redo lands: its run, and the prefabs it brings instances up to. */
interface Held {
  run(): void;
  keys: readonly string[];
}

/** `text` with its first letter a capital. */
const cap = (text: string): string => text.charAt(0).toUpperCase() + text.slice(1);
