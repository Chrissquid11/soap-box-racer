/**
 * The History card, the host's (`H`, and its toggle on the top bar): the
 * start, then every step of the one stack by its label, newest at the bottom.
 * The step Undo would take back is marked; those undone, that Redo would do
 * again, are dimmed.
 *
 * A click on a step is `travel(n)`: undone or redone until `n` steps are done,
 * one step at a time -- the start is none. Shut, it reads nothing. A step
 * with a note (`Step.note`: an Apply's undo that could not land, and the
 * ways on) is marked, and its hover text is the note.
 *
 * **Whose history** is a getter, read on every refresh: the tool up's own stack
 * if it has one, else the world's (`active-history.ts`). Another stack is drawn
 * afresh, and the title names whose it is: "History · Assets".
 *
 * **It hears the stack it shows itself**: every change of that history -- a
 * push, an undo, a label read again -- redraws it, not only the host's
 * `refresh()` after a step: after undos, the step pushed in the place of those
 * undone is drawn at once (the rows: `historyRows`, `history.ts`, tested).
 *
 * **Claude's steps** (Docs/ai-panel.md D8): each marked with the sparkle; two or more of one turn (`Step.turn`) side by
 * side are one row -- "Claude · 4 edits" -- folded, a click on its chevron showing the steps under it (`groupHistory`,
 * `claude-steps.ts`, tested). A click on the group goes to its last step, as a step's does; Z still undoes one step.
 */
import { groupHistory, turnHue, type HistoryEntry } from './claude-steps.ts';
import { historyRows, type History, type HistoryRow } from './history.ts';
import { control, el, icon, letGo } from './shell.ts';

export interface HistoryCard {
  readonly root: HTMLElement;
  readonly open: boolean;
  setOpen(open: boolean): void;
  /** The list read again from the history: after a step, an undo, a redo, a reset. Nothing while shut. */
  refresh(): void;
}

export function createHistoryCard(history: () => History, name: () => string, travel: (to: number) => void, startOpen: boolean, ordinalOf: (turn: string) => number | null = () => null): HistoryCard {
  const card = el('div', 'ed-card ed-history');
  const title = el('div', 'ed-side-title');
  const list = el('div', 'ed-past-list');
  card.append(title, list);
  let open = startOpen;
  card.hidden = !open;
  /** What the list was drawn from, so a refresh that changed nothing leaves it -- and its scroll -- alone. */
  let drawn = '';
  /** The stack it was drawn from: another one (a tab switch) is drawn afresh. */
  let shown: History | null = null;
  /** The turns unfolded, by id: their steps shown under them. */
  const unfolded = new Set<string>();
  /** The stack it listens to, and how to stop: every change of it -- a push after undos too -- redraws the card, whoever else listens. */
  let heard: History | null = null;
  let unhear: (() => void) | null = null;

  function refresh(): void {
    if (!open) return;
    const now = history();
    if (heard !== now) {
      unhear?.();
      heard = now;
      unhear = now.on(() => refresh());
    }
    const whose = name();
    const { labels, done } = now;
    // A step's note -- an Apply's undo that could not land, and the ways on -- on its row, on hover.
    const notes = now.steps.map((s) => s.note ?? null);
    const steps = now.steps.map((s) => ({ label: s.label, turn: s.turn ?? null }));
    const ordinals = [...new Set(steps.map((s) => s.turn).filter((x): x is string => x !== null))].map((x) => ordinalOf(x));
    const text = JSON.stringify([whose, labels, done, notes, steps.map((s) => s.turn), [...unfolded], ordinals]);
    if (now === shown && text === drawn) return;
    shown = now;
    drawn = text;
    title.textContent = `History · ${whose} · ${labels.length}`;
    list.replaceChildren();
    /** One step's row: its number, its label -- Claude's with the sparkle -- a click going there. */
    /** A turn's tint on a row (D8): its steps share a hue, so a turn's edits read as one. */
    const tint = (b: HTMLElement, turn: string | null, ordinal: number | null): void => {
      if (turn === null) return;
      b.classList.add('ed-past-tinted');
      b.style.setProperty('--turn-hue', String(turnHue(turn, ordinal)));
    };
    const stepRow = (row: HistoryRow, claude: boolean, inner = false): HTMLElement => {
      // Lets go of the focus after a click (`letGo`): the tool up has the keys.
      const b = letGo(control(['history_undo', 'history_redo'], row.state === 'undone' ? 'ed-past ed-undone' : 'ed-past'));
      const note = row.n > 0 ? notes[row.n - 1] : null;
      b.title = note ?? row.tip;
      if (note) b.classList.add('ed-noted');
      if (inner) b.classList.add('ed-past-inner');
      if (row.state === 'current') b.setAttribute('aria-current', 'true');
      b.append(el('span', 'ed-past-n', row.n === 0 ? '' : String(row.n)));
      if (claude) {
        b.classList.add('ed-past-claude');
        b.append(icon('sparkle'));
      }
      b.append(el('span', undefined, row.label));
      b.addEventListener('click', () => travel(row.n));
      return b;
    };
    const entries: HistoryEntry[] = groupHistory(historyRows(labels, done), steps, ordinalOf);
    for (const entry of entries) {
      if (entry.kind === 'step') {
        const b = stepRow(entry.row, entry.claude);
        tint(b, entry.turn, entry.ordinal);
        list.append(b);
        continue;
      }
      // A turn's steps as one row: the chevron folds them; the rest of the row goes to its last step.
      const open = unfolded.has(entry.turn);
      const line = el('div', 'ed-past-group');
      const fold = letGo(control('ui', 'ed-past-fold', open ? '▾' : '▸'));
      fold.title = open ? 'Fold this turn\'s steps' : `Show this turn's ${entry.rows.length} steps`;
      fold.setAttribute('aria-expanded', String(open));
      fold.addEventListener('click', () => {
        if (open) unfolded.delete(entry.turn);
        else unfolded.add(entry.turn);
        drawn = '';
        refresh();
      });
      const b = letGo(control(['history_undo', 'history_redo'], entry.state === 'undone' ? 'ed-past ed-past-claude ed-undone' : 'ed-past ed-past-claude'));
      b.title = `${entry.rows.map((r) => r.label).join('\n')}\n\nGo to the turn's last step (Z still undoes one step at a time)`;
      // Where you are: the group's mark while folded -- part of it undone too, the current step inside it -- unfolded, the
      // step's own row under it: one mark in the list.
      if (entry.holdsCurrent && !open) b.setAttribute('aria-current', 'true');
      if (entry.state === 'part') b.classList.add('ed-past-part');
      tint(b, entry.turn, entry.ordinal);
      b.append(el('span', 'ed-past-n', `${entry.rows[0]!.n}–${entry.n}`), icon('sparkle'), el('span', undefined, entry.label));
      b.addEventListener('click', () => travel(entry.n));
      line.append(fold, b);
      list.append(line);
      if (open) {
        for (const row of entry.rows) {
          const inner = stepRow(row, true, true);
          tint(inner, entry.turn, entry.ordinal);
          list.append(inner);
        }
      }
    }
    // The marked step in view: the newest is at the bottom, where the list mostly is.
    list.querySelector<HTMLElement>('[aria-current="true"]')?.scrollIntoView({ block: 'nearest' });
  }

  return {
    root: card,
    get open() {
      return open;
    },
    setOpen(next) {
      open = next;
      card.hidden = !open;
      drawn = '';
      refresh();
    },
    refresh,
  };
}
