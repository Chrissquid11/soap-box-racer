/**
 * What was changed while a playtest was paused, as data (Docs/studio.md §1, "What you changed while paused"): so
 * Stop, which puts the found world back, can offer to keep it.
 *
 * - **An edit is a step's diff** (`diffSaves`): the world's save before a step taken while paused against the one
 *   after it -- the editor's `world-steps.ts` has both. What the game did itself between pauses is in no step, so
 *   never an edit.
 * - **Entities are matched by id and generation**: the found world's entities keep both through the playtest unless
 *   destroyed (a death moves the generation on, `world.ts`), and Stop loads them back with both. An id whose
 *   generation differs between the two saves is another entity -- the old one destroyed, the index reused -- so it
 *   is a removal and an addition, never a field change.
 * - **What it says**: a numeric field changed (`field`: component, field, `was`, `now`), an object component's value
 *   (`field` null, by JSON), a component gained or lost on an entity both saves have (`component`), an entity added
 *   (`added`: it and everything added under it, as their part of the save) and one removed (`removed`, everything
 *   under it with it). A prefab instance's overrides are its fields as they are in the save -- set on the instance,
 *   they are its overrides again (`sceneSave` works them out). Not said: a parent changed, a layer, a component
 *   switched off or on, a relation on two entities the found world has.
 * - **One pause's steps fold into one list** (`mergeEdits`): the last `now` wins over the first `was`; an entity
 *   added then edited is one `added` with its final data; added then removed is nothing, and so is one added under
 *   an entity of the found world's that was then removed (the removal takes it with it).
 * - **Judged from the found world to now**: given the found world's save -- the world Stop put back, which the edits
 *   go onto -- a field or component whose `now` is what the found world has already is no edit (`mergeEdits`), is
 *   said with the found value as what it was (`editWords`: the game may have moved it between pauses), and is
 *   skipped as "already so" if it comes to `applyEdits` all the same.
 * - **Kept** (`applyEdits`) onto the found world: a field set through its store, a component added or removed, an
 *   added entity put in through the world's own `load` -- the world's save with the entity's part appended, never a
 *   copy of how a load builds one -- and a removal a destroy. What the found world lacks is skipped, with words.
 *
 * Pure but for `applyEdits`, which takes a `World`: node tests it all (`playtest-edits.test.ts`).
 */
import { caseKey, fieldValue, fileFieldOf, refText, unfoldEntry, type AnyComponent, type Entity, type KeyRef, type World, type WorldSave } from '@vibe/engine';
import type { AfterPlaytest } from './prefs.ts';

/** One component of one entity, as its part of a save: numbers by field, an object's value, switched off or not. */
/** One field's value in a save (`WorldSave`'s). */
type SavedValue = number | string | KeyRef | string[] | number[];

export interface SavedComponent {
  /** By field: a number, a key field's reference (`key()`: `{ uid, key }` or the key), an enum's name, flags' names, a vector's numbers, as the save holds it. */
  fields?: Record<string, SavedValue>;
  value?: unknown;
  disabled?: true;
}

/** One entity's part of a save: what an added one is put back from. */
export interface SavedEntity {
  id: number;
  gen: number;
  kind: string;
  layer: number;
  /** Its parent's id and generation; 0 and 0 for a root. */
  parent: number;
  parentGen: number;
  /** Of a prefab instance: its prefab's reference (`{ uid, key }` or the key), its node, its root's id, and the prefab's node table as saved. */
  instance: { key: string | KeyRef; node: number; root: number; nodes?: string[]; names?: (string | null)[] } | null;
  components: Record<string, SavedComponent>;
}

/** A link of an added entity's, to or from it: put back if its other end is there. */
export interface SavedLink {
  relation: string;
  source: number;
  target: number;
  fields: Record<string, number>;
}

/** One thing changed while paused. `id` and `gen` say which entity; `name` how it is said. */
export type Edit =
  | { kind: 'field'; id: number; gen: number; name: string; component: string; field: string | null; was: unknown; now: unknown }
  | { kind: 'component'; id: number; gen: number; name: string; component: string; was: SavedComponent | null; now: SavedComponent | null }
  | { kind: 'added'; id: number; gen: number; name: string; entities: SavedEntity[]; links: SavedLink[]; edited: boolean }
  | { kind: 'removed'; id: number; gen: number; name: string; under: { id: number; gen: number }[] };

/** An entity as one string: its id and generation. */
const who = (id: number, gen: number): string => `${id}.${gen}`;

/** A save read by entity: where each is, its generation, parent, children, name and components. */
interface Read {
  save: WorldSave;
  at: Map<number, number>;
  parent: Map<number, number>;
  children: Map<number, number[]>;
  components: Map<number, Record<string, SavedComponent>>;
}

function read(save: WorldSave): Read {
  const at = new Map<number, number>();
  save.entities.forEach((e, i) => at.set(e, i));
  const parent = new Map<number, number>();
  const children = new Map<number, number[]>();
  for (let i = 0; i < save.parents.length; i += 2) {
    const child = save.parents[i]!;
    const p = save.parents[i + 1]!;
    parent.set(child, p);
    const list = children.get(p) ?? [];
    list.push(child);
    children.set(p, list);
  }
  const components = new Map<number, Record<string, SavedComponent>>();
  for (const [name, entry] of Object.entries(save.components)) {
    const off = new Set(entry.disabled ?? []);
    entry.entities.forEach((e, i) => {
      const one: SavedComponent = {};
      if (entry.fields) {
        one.fields = {};
        for (const [field, values] of Object.entries(entry.fields)) one.fields[field] = values[i]!;
      } else if (entry.values) one.value = entry.values[i];
      if (off.has(e)) one.disabled = true;
      const all = components.get(e) ?? {};
      all[name] = one;
      components.set(e, all);
    });
  }
  return { save, at, parent, children, components };
}

/** Each save read once: the found world's, read again by every row the dialog says. */
const reads = new WeakMap<WorldSave, Read>();
const readOnce = (save: WorldSave): Read => {
  let r = reads.get(save);
  if (!r) reads.set(save, (r = read(save)));
  return r;
};

const genOf = (r: Read, e: number): number => r.save.generations[e] ?? 0;
const has = (r: Read, e: number, gen: number): boolean => r.at.has(e) && genOf(r, e) === gen;

/** How an entity is said: its name, else its prefab's last word, else its kind, else its id. */
function nameIn(r: Read, e: number): string {
  const named = r.components.get(e)?.Name?.value;
  if (typeof named === 'string' && named !== '') return named;
  const i = r.at.get(e);
  const inst = r.save.instances;
  const key = i !== undefined && inst ? refText(inst.keys[inst.prefab[i] ?? 0]) : '';
  if (key) return key.slice(key.lastIndexOf('/') + 1);
  const kind = i !== undefined ? r.save.kinds[i] : undefined;
  return kind && kind !== 'Bare' ? `${kind} ${e}` : `entity ${e}`;
}

/** `e` and every entity under it that `keep` takes, parents before their children, each parent's in their order. */
function subtree(r: Read, e: number, keep: (e: number) => boolean): number[] {
  const out: number[] = [];
  const walk = (x: number): void => {
    out.push(x);
    for (const c of r.children.get(x) ?? []) if (keep(c)) walk(c);
  };
  walk(e);
  return out;
}

const sameValue = (a: unknown, b: unknown): boolean => a === b || (Number.isNaN(a) && Number.isNaN(b)) || JSON.stringify(a) === JSON.stringify(b);

/**
 * What the found world `r` has where a field or component edit is -- the field's number, the object's value, the
 * component's part of the save or null -- or `absent` when the entity is not there at the edit's generation.
 */
const absent = Symbol('absent');
function foundValue(r: Read, edit: Extract<Edit, { kind: 'field' | 'component' }>): unknown {
  if (!has(r, edit.id, edit.gen)) return absent;
  const c = r.components.get(edit.id)?.[edit.component];
  if (edit.kind === 'component') return c ?? null;
  return edit.field === null ? c?.value : c?.fields?.[edit.field];
}

/** Is a field or component edit's `now` what the found world `r` has already (or, without it, its own `was`)? */
function alreadySo(edit: Extract<Edit, { kind: 'field' | 'component' }>, r?: Read): boolean {
  const found = r ? foundValue(r, edit) : absent;
  return sameValue(found === absent ? edit.was : found, edit.now);
}

/** `e`'s part of the save `r` reads. */
function savedEntity(r: Read, e: number): SavedEntity {
  const i = r.at.get(e)!;
  const p = r.parent.get(e) ?? 0;
  const inst = r.save.instances;
  const k = inst?.prefab[i] ?? 0;
  return {
    id: e,
    gen: genOf(r, e),
    kind: r.save.kinds[i] ?? 'Bare',
    layer: r.save.layers[i] ?? 0,
    parent: p,
    parentGen: p === 0 ? 0 : genOf(r, p),
    instance: inst && k !== 0 ? { key: inst.keys[k]!, node: inst.node[i]!, root: inst.root[i]!, nodes: inst.nodes?.[k], names: inst.names?.[k] } : null,
    components: structuredClone(r.components.get(e) ?? {}),
  };
}

/**
 * What one step changed, from the world's save before it to the save after: fields, object values, components gained
 * or lost on the entities both have, entities added (each with all added under it) and removed (likewise). Nothing
 * for two saves alike.
 */
export function diffSaves(before: WorldSave, after: WorldSave): Edit[] {
  const b = read(before);
  const a = read(after);
  const out: Edit[] = [];
  const added = (e: number): boolean => !has(b, e, genOf(a, e));
  const removed = (e: number): boolean => !has(a, e, genOf(b, e));

  for (const e of before.entities) {
    if (!removed(e)) continue;
    const p = b.parent.get(e) ?? 0;
    if (p !== 0 && removed(p)) continue;
    const under = subtree(b, e, removed).slice(1).map((x) => ({ id: x, gen: genOf(b, x) }));
    out.push({ kind: 'removed', id: e, gen: genOf(b, e), name: nameIn(b, e), under });
  }

  for (const e of after.entities) {
    if (added(e)) continue;
    const gen = genOf(a, e);
    const was = b.components.get(e) ?? {};
    const now = a.components.get(e) ?? {};
    const name = nameIn(b, e);
    for (const c of new Set([...Object.keys(was), ...Object.keys(now)])) {
      const w = was[c];
      const n = now[c];
      if (!w || !n) {
        out.push({ kind: 'component', id: e, gen, name, component: c, was: w ?? null, now: n ?? null });
        continue;
      }
      if (w.fields || n.fields) {
        for (const field of new Set([...Object.keys(w.fields ?? {}), ...Object.keys(n.fields ?? {})])) {
          const x = w.fields?.[field];
          const y = n.fields?.[field];
          if (!sameValue(x, y)) out.push({ kind: 'field', id: e, gen, name, component: c, field, was: x, now: y });
        }
      } else if ('value' in w || 'value' in n) {
        if (!sameValue(w.value, n.value)) out.push({ kind: 'field', id: e, gen, name, component: c, field: null, was: w.value, now: n.value });
      }
    }
  }

  for (const e of after.entities) {
    if (!added(e)) continue;
    const p = a.parent.get(e) ?? 0;
    if (p !== 0 && added(p)) continue;
    const ids = subtree(a, e, added);
    const set = new Set(ids);
    const links: SavedLink[] = [];
    for (const [relation, rows] of Object.entries(after.relations)) {
      rows.source.forEach((s, i) => {
        const t = rows.target[i]!;
        if (!set.has(s) && !set.has(t)) return;
        const fields: Record<string, number> = {};
        for (const [f, values] of Object.entries(rows.fields)) fields[f] = values[i]!;
        links.push({ relation, source: s, target: t, fields });
      });
    }
    out.push({ kind: 'added', id: e, gen: genOf(a, e), name: nameIn(a, e), entities: ids.map((x) => savedEntity(a, x)), links, edited: false });
  }
  return out;
}

/**
 * One pause's steps' edits, in order, as one list: a field's first `was` and last `now` (none if `now` is what the
 * found world has -- `found`, its save -- or, without it, the first `was`), an added entity's later edits folded into
 * its data (`edited`), one added then removed gone -- one added under an entity then removed too -- and what was
 * edited on an entity before it was removed gone with it.
 */
export function mergeEdits(steps: readonly (readonly Edit[])[], found?: WorldSave): Edit[] {
  const out: Edit[] = [];
  /** Each added entity, to the `added` edit that holds it. */
  const addedBy = new Map<string, Extract<Edit, { kind: 'added' }>>();
  const drop = (gone: (x: Edit) => boolean): void => {
    for (let i = out.length - 1; i >= 0; i--) if (gone(out[i]!)) out.splice(i, 1);
  };
  const entityIn = (edit: Extract<Edit, { kind: 'added' }>, id: number, gen: number): SavedEntity | undefined => edit.entities.find((s) => s.id === id && s.gen === gen);

  for (const step of steps) {
    for (const edit of step) {
      const key = who(edit.id, edit.gen);
      if (edit.kind === 'added') {
        const mine = structuredClone(edit);
        out.push(mine);
        for (const s of mine.entities) addedBy.set(who(s.id, s.gen), mine);
        continue;
      }
      const host = addedBy.get(key);
      if (edit.kind === 'removed') {
        // Everything it takes with it: an entity added this playtest under it too, whoever's it is.
        const gone = new Set([key, ...edit.under.map((u) => who(u.id, u.gen))]);
        for (const k of gone) {
          const holder = addedBy.get(k);
          if (!holder) continue;
          addedBy.delete(k);
          if (who(holder.id, holder.gen) === k) {
            for (const s of holder.entities) addedBy.delete(who(s.id, s.gen));
            drop((x) => x === holder);
            continue;
          }
          holder.entities = holder.entities.filter((s) => who(s.id, s.gen) !== k);
          holder.links = holder.links.filter((l) => holder.entities.some((s) => s.id === l.source) || holder.entities.some((s) => s.id === l.target));
          holder.edited = true;
        }
        // One added this playtest goes as if it never was; one of the found world's is a removal.
        if (host) continue;
        drop((x) => x.kind !== 'added' && gone.has(who(x.id, x.gen)));
        out.push(structuredClone(edit));
        continue;
      }
      if (host) {
        // An entity added this playtest: its data as it is now.
        const s = entityIn(host, edit.id, edit.gen)!;
        if (edit.kind === 'component') {
          if (edit.now) s.components[edit.component] = structuredClone(edit.now);
          else delete s.components[edit.component];
        } else {
          const c = (s.components[edit.component] ??= {});
          if (edit.field === null) c.value = structuredClone(edit.now);
          else (c.fields ??= {})[edit.field] = edit.now as SavedValue;
        }
        host.edited = true;
        continue;
      }
      if (edit.kind === 'component') {
        const before = out.find((x) => x.kind === 'component' && who(x.id, x.gen) === key && x.component === edit.component) as Extract<Edit, { kind: 'component' }> | undefined;
        // Its fields' edits are in what it is now.
        drop((x) => x.kind === 'field' && who(x.id, x.gen) === key && x.component === edit.component);
        if (before) before.now = structuredClone(edit.now);
        else out.push(structuredClone(edit));
        continue;
      }
      const gained = out.find((x) => x.kind === 'component' && who(x.id, x.gen) === key && x.component === edit.component && x.now !== null) as Extract<Edit, { kind: 'component' }> | undefined;
      if (gained) {
        if (edit.field === null) gained.now!.value = structuredClone(edit.now);
        else (gained.now!.fields ??= {})[edit.field] = edit.now as SavedValue;
        continue;
      }
      const before = out.find((x) => x.kind === 'field' && who(x.id, x.gen) === key && x.component === edit.component && x.field === edit.field) as Extract<Edit, { kind: 'field' }> | undefined;
      if (before) before.now = structuredClone(edit.now);
      else out.push(structuredClone(edit));
    }
  }
  // What the found world has already -- or, without it, back where they began: no edit.
  const r = found ? readOnce(found) : undefined;
  return out.filter((x) => (x.kind === 'field' || x.kind === 'component' ? !alreadySo(x, r) : true));
}

/** A step taken while paused and what it changed: `step` null once it is off the history's end, done for good. */
export interface Recorded<S> {
  step: S | null;
  edits: Edit[];
  undone: boolean;
  /** Seen on the history once: a step pushed inside a group is not, until the group is. */
  seen?: boolean;
  /** Claude's own step (`Claude: …`), not the person's: what the kept step's label is judged by (`keptLabel`). */
  claude?: boolean;
}

/**
 * The recorded steps followed as the history moved (`steps`, `done` of them done; a group's parts inside it): one
 * there is done or undone as it stands; one gone from it was either done -- off the end of the history's bound, a
 * hundred steps or 64 MB, and kept, its step let go of -- or undone, dropped from redo by a new step, and gone too.
 * One never seen there yet is inside a group still being run: left as it is. In order, as recorded: what a pause's
 * end reads (`!undone`).
 */
export function followRecorded<S extends { readonly parts?: readonly S[] }>(recorded: readonly Recorded<S>[], steps: readonly S[], done: number): Recorded<S>[] {
  const undone = new Map<S, boolean>();
  steps.forEach((top, i) => {
    const walk = (step: S): void => {
      undone.set(step, i >= done);
      for (const part of step.parts ?? []) walk(part);
    };
    walk(top);
  });
  return recorded.filter((r) => {
    if (r.step === null) return true;
    const now = undone.get(r.step);
    if (now !== undefined) {
      r.undone = now;
      r.seen = true;
      return true;
    }
    if (!r.seen) return true;
    if (r.undone) return false;
    r.step = null;
    return true;
  });
}

/** A number as a person reads it: an f32's 0.10000000149 as 0.1. */
function numberText(v: unknown): string {
  if (typeof v !== 'number') return v === undefined ? '–' : JSON.stringify(v);
  return Number.isInteger(v) ? String(v) : String(Number(v.toPrecision(6)));
}

/** An object's value, short. */
function valueText(v: unknown): string {
  if (v === undefined) return '–';
  const text = JSON.stringify(v) ?? String(v);
  return text.length > 40 ? `${text.slice(0, 39)}…` : text;
}

/**
 * An edit in words, as the dialog lists it: "little crate 1 · Transform.px 2.5 → 5", "crate · + Spin",
 * "+ tree (spawned, then edited)", "− crate 3". With `found`, the found world's save, an entity it has at the edit's
 * generation is said by its name there, and a field by what it is there -- what keeping it changes -- as `was`.
 */
export function editWords(edit: Edit, found?: WorldSave): string {
  let name = edit.name;
  let was = edit.kind === 'field' ? edit.was : undefined;
  if (edit.kind === 'added') {
    const named = edit.entities[0]?.components.Name?.value;
    if (typeof named === 'string' && named !== '') name = named;
  } else if (found) {
    const r = readOnce(found);
    if (has(r, edit.id, edit.gen)) {
      name = nameIn(r, edit.id);
      if (edit.kind === 'field') was = foundValue(r, edit);
    }
  }
  switch (edit.kind) {
    case 'field':
      return edit.field === null
        ? `${name} · ${edit.component} ${valueText(was)} → ${valueText(edit.now)}`
        : `${name} · ${edit.component}.${edit.field} ${numberText(was)} → ${numberText(edit.now)}`;
    case 'component':
      return `${name} · ${edit.now ? '+' : '−'} ${edit.component}`;
    case 'added':
      return `+ ${name} (spawned${edit.edited ? ', then edited' : ''})`;
    case 'removed':
      return `− ${name}`;
  }
}

/** The one history step the edits kept are: Z undoes it whole. */
export const KEPT = 'Kept from the playtest';

/** What keeping said on the status line: "2 kept, 1 skipped: crate 3 is not in the scene · Z undoes". */
export function keptLine(applied: number, skipped: readonly string[]): string {
  const rest = skipped.length > 0 ? `, ${skipped.length} skipped: ${skipped.join('; ')}` : '';
  return `${applied} kept${rest}${applied > 0 ? ' · Z undoes' : ''}`;
}

/** What dropping them said, the preference's: "3 changes from the playtest dropped (Preferences: after a playtest)". */
export const droppedLine = (n: number): string => `${n} ${n === 1 ? 'change' : 'changes'} from the playtest dropped (Preferences: after a playtest)`;

/** Ticked in the dialog at first: everything but a removal, which is chosen one by one. */
export const tickedAtFirst = (edit: Edit): boolean => edit.kind !== 'removed';

/**
 * An edit's id, as `play_state` lists it and `play_stop`'s `keep` names it (Docs/mcp.md M4): what it changed, never
 * where it is in the list -- the entity by id and generation, and the component and field -- so a list read before
 * more edits were made still names the same ones. One pause's steps fold into one edit per id (`mergeEdits`).
 */
export function editId(edit: Edit): string {
  const who = `${edit.id}.${edit.gen}`;
  switch (edit.kind) {
    case 'field':
      return `f:${who}:${edit.component}${edit.field === null ? '' : `.${edit.field}`}`;
    case 'component':
      return `c:${who}:${edit.component}`;
    case 'added':
      return `a:${who}`;
    case 'removed':
      return `r:${who}`;
  }
}

/** `play_stop`'s `keep` as the dialog's ticks: all, none, or the edits whose ids are listed -- and the ids that name none. */
export function keepTicks(edits: readonly Edit[], keep: 'all' | 'none' | readonly string[]): { ticked: boolean[]; unknown: string[] } {
  if (keep === 'all' || keep === 'none') return { ticked: edits.map(() => keep === 'all'), unknown: [] };
  const ids = edits.map(editId);
  const wanted = new Set(keep);
  return { ticked: ids.map((id) => wanted.has(id)), unknown: [...wanted].filter((id) => !ids.includes(id)) };
}

/** What Stop does with what was changed while paused: nothing with nothing; else as the preference says -- ask, keep all, or drop all. */
export function keepDecision(edits: readonly Edit[], preference: AfterPlaytest): 'ask' | Edit[] {
  if (edits.length === 0 || preference === 'drop') return [];
  return preference === 'keep' ? [...edits] : 'ask';
}

/** A step taken while paused, as Stop offers it: what it changed, and whether it was Claude's own (a `Claude: …` step). */
export interface PausedStep {
  edits: Edit[];
  claude: boolean;
}

/** The entities an edit touches, by id: it, and those added or removed with it. */
function touched(edit: Edit): number[] {
  if (edit.kind === 'added') return [edit.id, ...edit.entities.map((e) => e.id)];
  if (edit.kind === 'removed') return [edit.id, ...edit.under.map((e) => e.id)];
  return [edit.id];
}

/**
 * The label of the step the kept edits are: Claude's (`<prefix>Kept from the playtest`, `prefix` its call's) only when
 * Claude's call keeps them and every one came from Claude's own steps -- no step of the person's touched an entity it
 * touches -- else the plain one, the person's, which `history_undo` takes back only with `any`.
 */
export function keptLabel(steps: readonly PausedStep[], kept: readonly Edit[], prefix: string): string {
  if (prefix === '') return KEPT;
  const theirs = new Set(steps.filter((s) => !s.claude).flatMap((s) => s.edits.flatMap(touched)));
  return kept.every((edit) => touched(edit).every((id) => !theirs.has(id))) ? `${prefix}${KEPT}` : KEPT;
}

/** The steps' edits, a list a step, as `mergeEdits` takes them. */
export const editsOf = (steps: readonly PausedStep[]): Edit[][] => steps.map((s) => s.edits);

/** How Stop answered the offer: as `play_stop`'s `keep` said, as the preference said, or the dialog shown (`asked`). */
export type StopHow = 'all' | 'none' | 'listed' | 'preference: keep' | 'preference: drop' | 'asked';

/** Stop's answer to what was changed while paused, before anything is kept (`stopAnswer`). */
export interface StopAnswer {
  how: StopHow;
  /** The edits to keep now, by their place in `edits`: none while the dialog asks. */
  ticked: boolean[];
  /** How many are dropped unkept: those not ticked -- none while the dialog asks, its answer the person's. */
  discarded: number;
  /** `asked`: the dialog's rows, each edit in words (judged from `found`) and ticked as at first; else none. */
  rows: { text: string; ticked: boolean; title: string }[];
}

/**
 * What Stop does with `edits` -- merged against `found`, the world put back -- as `keep` says (Claude's `play_stop`,
 * no dialog: all, none, or ids), else as the preference says: the dialog's rows to ask with, all ticked, or none.
 * The editor's `offerKept` keeps what it ticks; node tests it as it is (`playtest-edits.test.ts`).
 */
export function stopAnswer(edits: readonly Edit[], found: WorldSave, keep: 'all' | 'none' | readonly string[] | undefined, preference: AfterPlaytest): StopAnswer {
  const answer = (how: StopHow, ticked: boolean[]): StopAnswer => ({ how, ticked, discarded: ticked.filter((x) => !x).length, rows: [] });
  if (keep !== undefined) return answer(keep === 'all' || keep === 'none' ? keep : 'listed', keepTicks(edits, keep).ticked);
  const decision = keepDecision(edits, preference);
  if (decision === 'ask') {
    const rows = edits.map((edit) => {
      const text = editWords(edit, found);
      return { text, ticked: tickedAtFirst(edit), title: text };
    });
    return { how: 'asked', ticked: [], discarded: 0, rows };
  }
  return answer(decision.length > 0 ? 'preference: keep' : 'preference: drop', edits.map(() => decision.length > 0));
}

export interface Applied {
  applied: Edit[];
  skipped: { edit: Edit; why: string }[];
}

type Rows = Record<string, { [i: number]: number }> & { value: unknown[] };

/**
 * The ticked ones of `edits` onto `world` -- the found world, put back -- by id and generation: a field set through
 * its store, a component added or removed, a removal a destroy, and the added entities appended to the world's save
 * and put in by `load` (the world's own, or `Game.load`, which dresses them) -- each at its own id when the found
 * world has it free, else at a new one past the end. What the world lacks is skipped and said why, and so is a field
 * or component that is already as the edit would make it ("already so").
 */
export function applyEdits(world: World, edits: readonly Edit[], ticked: readonly boolean[], load: (save: WorldSave) => void = (save) => void world.load(save)): Applied {
  const out: Applied = { applied: [], skipped: [] };
  const chosen = edits.filter((_, i) => ticked[i] === true);
  const now = world.save();
  const found = read(now);
  const there = (id: number, gen: number): boolean => world.alive(id as Entity) && now.generations[id] === gen;
  const notThere = (edit: Edit): string => `${edit.name} is not in the scene`;
  const byName = (name: string): AnyComponent | undefined => world.allComponents.find((c) => c.name === name);

  const adds = chosen.filter((e): e is Extract<Edit, { kind: 'added' }> => e.kind === 'added');
  if (adds.length > 0) {
    const taken = new Set(now.entities);
    for (const edit of adds) {
      appendAdded(now, edit, taken, there);
      out.applied.push(edit);
    }
    load(now);
  }

  for (const edit of chosen) {
    if (edit.kind !== 'field' && edit.kind !== 'component') continue;
    const e = edit.id as Entity;
    if (!there(edit.id, edit.gen)) {
      out.skipped.push({ edit, why: notThere(edit) });
      continue;
    }
    if (alreadySo(edit, found)) {
      out.skipped.push({ edit, why: `${edit.name} · ${edit.component}${edit.kind === 'field' && edit.field !== null ? `.${edit.field}` : ''} is already so` });
      continue;
    }
    const component = byName(edit.component);
    if (!component || component.kind === 'relation') {
      out.skipped.push({ edit, why: `there is no component ${edit.component} now` });
      continue;
    }
    if (edit.kind === 'component') {
      if (edit.now === null) {
        if (world.has(e, component)) world.remove(e, component);
      } else {
        if (!world.has(e, component)) world.add(e, component);
        write(world, e, component, edit.now);
      }
      out.applied.push(edit);
      continue;
    }
    if (!world.has(e, component)) {
      out.skipped.push({ edit, why: `${edit.name} has no ${edit.component}` });
      continue;
    }
    if (edit.field !== null && component.kind === 'data' && !fileFieldOf(component, edit.field)) {
      out.skipped.push({ edit, why: `${edit.component} has no field ${edit.field} now` });
      continue;
    }
    write(world, e, component, edit.field === null ? { value: edit.now } : { fields: { [edit.field]: edit.now as SavedValue } });
    out.applied.push(edit);
  }

  for (const edit of chosen) {
    if (edit.kind !== 'removed') continue;
    if (!there(edit.id, edit.gen)) {
      out.skipped.push({ edit, why: notThere(edit) });
      continue;
    }
    world.destroy(edit.id as Entity);
    out.applied.push(edit);
  }
  world.flush();
  return out;
}

/** `data` into `e`'s `component`: its numbers, or its object through the component's own `load`. */
function write(world: World, e: Entity, component: AnyComponent, data: SavedComponent): void {
  const rows = world.rawStore(component) as Rows;
  if (component.kind === 'data') {
    // A key field's text interned (`fieldValue`): the save holds keys as text, enums and flags as names; a vector its numbers, an axis a column.
    for (const [field, given] of Object.entries(data.fields ?? {})) {
      const each = unfoldEntry(component, field, given);
      if (each === null || 'error' in each) continue;
      for (const { column, value } of each) rows[column]![e] = fieldValue(component, column, value) ?? 0;
    }
    if (component.name === 'Transform') world.moved(e);
  } else if (component.kind === 'object' && 'value' in data) {
    rows.value[e] = component.load ? (component.load(structuredClone(data.value), rows.value[e]) ?? rows.value[e]) : structuredClone(data.value);
  }
}

/** `edit`'s entities appended to `save`, each at its own id if free there (`taken` says what is not), else past the end; their links whose other end is there. */
function appendAdded(save: WorldSave, edit: Extract<Edit, { kind: 'added' }>, taken: Set<number>, there: (id: number, gen: number) => boolean): void {
  const moved = new Map<number, number>();
  for (const s of edit.entities) {
    let id = s.id;
    if (taken.has(id)) id = Math.max(save.extent, 1);
    while (save.generations.length <= id) save.generations.push(0);
    save.generations[id] = id === s.id ? s.gen : 0;
    save.extent = Math.max(save.extent, id + 1);
    taken.add(id);
    moved.set(s.id, id);
  }
  const idOf = (x: number): number => moved.get(x) ?? x;
  const inst = (save.instances ??= { keys: [''], prefab: save.entities.map(() => 0), node: save.entities.map(() => 0), root: save.entities.map(() => 0), next: save.entities.map(() => 0), nodes: [[]], names: [[]] });
  for (const s of edit.entities) {
    const id = idOf(s.id);
    save.entities.push(id);
    save.kinds.push(s.kind);
    save.layers.push(s.layer);
    let k = 0;
    if (s.instance) {
      // By its key: a reference is an object, one per save.
      const key = caseKey(refText(s.instance.key));
      k = inst.keys.findIndex((x, j) => j > 0 && caseKey(refText(x)) === key);
      if (k < 0) {
        k = inst.keys.push(s.instance.key) - 1;
        inst.nodes?.push(s.instance.nodes ?? []);
        inst.names?.push(s.instance.names ?? []);
      }
    }
    inst.prefab.push(k);
    inst.node.push(s.instance?.node ?? 0);
    inst.root.push(s.instance ? idOf(s.instance.root) : 0);
    inst.next.push(0);
    for (const [name, c] of Object.entries(s.components)) {
      const entry = (save.components[name] ??= c.fields ? { entities: [], fields: {} } : 'value' in c ? { entities: [], values: [] } : { entities: [] });
      const at = entry.entities.length;
      entry.entities.push(id);
      if (entry.fields) {
        for (const f of new Set([...Object.keys(entry.fields), ...Object.keys(c.fields ?? {})])) {
          const column = (entry.fields[f] ??= new Array<SavedValue>(at).fill(0));
          column.push(c.fields?.[f] ?? 0);
        }
      }
      if (entry.values) entry.values.push(structuredClone(c.value));
      if (c.disabled) (entry.disabled ??= []).push(id);
    }
    // Under its parent where that is the found world's (or one of these), else a root, last.
    const inside = moved.has(s.parent);
    if (s.parent !== 0 && (inside || there(s.parent, s.parentGen))) save.parents.push(id, idOf(s.parent));
    else save.roots?.push(id);
  }
  for (const link of edit.links) {
    const source = idOf(link.source);
    const target = idOf(link.target);
    if (!taken.has(source) || !taken.has(target)) continue;
    const rows = (save.relations[link.relation] ??= { source: [], target: [], fields: {} });
    rows.source.push(source);
    rows.target.push(target);
    for (const f of new Set([...Object.keys(rows.fields), ...Object.keys(link.fields)])) {
      const column = (rows.fields[f] ??= new Array<number>(rows.source.length - 1).fill(0));
      column.push(link.fields[f] ?? 0);
    }
  }
}
