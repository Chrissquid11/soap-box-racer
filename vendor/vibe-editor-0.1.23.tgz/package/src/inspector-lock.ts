/**
 * The inspector's lock (Docs/ecs.md §13): what a side's inspector shows,
 * given what is chosen on it, whether the right panel is locked, and what the
 * lock pinned -- the host's `Sides.lock` keeps whose the panel is, this what
 * it shows. Unlocked, the live choice; locked, the subject pinned as the lock
 * shut (entities as `EntityRef`s, files as paths), each resolved as it is
 * drawn -- one gone dropped; every one gone, nothing, and the panel says it
 * was removed.
 *
 * A world loaded lets go of the lock only if it is another world (`letsGo`):
 * a scene loaded, a prefab opened or gone Back from. The same world loaded
 * again -- a code swap, a prefab renamed, an opened prefab refreshed, Stop --
 * keeps every entity's index and generation, so what it pinned still derefs.
 * A lock on files pins paths, of no world: no world loaded lets it go.
 *
 * Pure: node tests it (`inspector-lock.test.ts`).
 */
import { tabKey } from './editor-keys.ts';

/** What an inspector draws: its subject, and whether a lock's subject was all removed (the empty words say so). */
export interface Shown<T> {
  readonly subject: readonly T[];
  readonly removed: boolean;
}

/** What the lock button reads and does: the host's one state, shared by both sides' inspectors. */
export interface LockHost {
  /** Has the tab up a lock (the Scene tab): the button shown only then. */
  readonly lockable: boolean;
  readonly locked: boolean;
  toggle(): void;
}

/** What `lockHost` reads of the editor: its context's lock (`EditorContext.lockable`, `locked`, `lock`). */
export interface LockContext {
  readonly lockable: boolean;
  readonly locked: boolean;
  lock(on: boolean): void;
}

/** The lock button's host, either side's inspector's: the context's one state, the toggle flipping it. */
export function lockHost(ctx: LockContext): LockHost {
  return {
    get lockable() {
      return ctx.lockable;
    },
    get locked() {
      return ctx.locked;
    },
    toggle: () => ctx.lock(!ctx.locked),
  };
}

/** The lock button's words, shut and open: the Scale lock's icon, these on its hover. */
export const LOCK_WORDS = { locked: 'Unlock the inspector', open: 'Lock the inspector to what it shows' } as const;

/** Its key, the Scene tab's either side (`entities.ts`): `Shift+L` is Lock picking's (`switches.ts`), so Alt with L. */
export const LOCK_KEY = tabKey('lock inspector');

/**
 * A world loaded (`emit('loaded', …)`): `'another'` -- a scene loaded, a prefab opened or gone Back from -- or
 * `'again'`, the same world loaded back into itself -- the game's code swapped, a prefab renamed in it, an opened
 * prefab refreshed, Stop after a pause -- its entities' indices and generations kept, so refs to them still deref.
 */
export type Load = 'another' | 'again';

/** Does a world loaded let go of a lock: only another world, and only a lock on entities -- one on paths (`pinsPaths`) belongs to no world. */
export function letsGo(load: Load, pinsPaths: boolean): boolean {
  return load === 'another' && !pinsPaths;
}

/**
 * Whose the right panel is as the lock opens: the side that chose last while it was shut (`chose`, the side whose
 * choice would have taken the panel, unlocked) -- locked on an entity, a prefab chosen in the Assets panel, unlocked:
 * the Assets inspector on the prefab -- or, nothing chosen meanwhile (null), the side it was locked to, showing its
 * own live selection, which may now be empty.
 */
export function afterUnlock(lockedSide: string, lastChoseDuringLock: string | null): string {
  return lastChoseDuringLock ?? lockedSide;
}

/** Said after the empty words while what the lock pinned is gone. */
export const REMOVED = '(locked: it was removed)';

/**
 * What the inspector shows: unlocked (`pinned` null), `live`; locked, each of
 * `pinned` that `resolve` still finds -- a dead entity's ref, a deleted file's
 * path, null -- in its order. A lock on nothing shows nothing, and is not
 * "removed".
 */
export function shownOf<P, T>(live: readonly T[], pinned: readonly P[] | null, resolve: (p: P) => T | null): Shown<T> {
  if (pinned === null) return { subject: live, removed: false };
  const subject: T[] = [];
  for (const p of pinned) {
    const x = resolve(p);
    if (x !== null) subject.push(x);
  }
  return { subject, removed: pinned.length > 0 && subject.length === 0 };
}
