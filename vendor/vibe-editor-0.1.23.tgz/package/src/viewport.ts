/**
 * The editor in the scene, every tool's (`ctx.viewport`): its own camera,
 * perspective or orthographic (`camera.ts`), the view cube over the scene
 * (`scene-cube.ts`), the gizmo on the selection (`gizmo.ts`), clicks and box
 * selection on the world (`picking.ts`, `marquee.ts`), and the grid and boxes
 * over it (`overlays.ts`) -- the gizmo, picking and the box all through
 * whichever of the camera's two is drawn through.
 *
 * - **Nothing of it is in the scene, or listening, while the editor is closed**
 *   -- nor a tool's own objects (`add`), which come and go with the rest.
 * - **One frame for many asks**: the camera, a handle, the pointer coming onto
 *   an entity each ask for the frame soon, and it is drawn once; a step of a
 *   gizmo drag draws it at once, so what a tool draws from the world keeps up.
 */
import * as THREE from 'three';
import { MrDebug } from '@vibe/engine/debug';
import { type Entity, NONE, Transform, View, WorldTransform } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import { createCamera, SCENE_FOV, type CameraPose, type ViewRect } from './camera.ts';
import { createGizmo, type GizmoMode, type GizmoSpace } from './gizmo.ts';
import { createOverlays } from './overlays.ts';
import { createPicking } from './picking.ts';
import type { Snap, WheelMode } from './prefs.ts';
import { createSceneCube } from './scene-cube.ts';
import { cameraFocusBox, lookThroughPose, type EditorView } from './camera-entity.ts';
import { createCameraView } from './camera-view.ts';
import type { Selection } from './selection.ts';
import { DIRECTIONS, presetOf, type Preset, type Projection, type Vec3 } from './view/views.ts';

export type { GizmoMode, GizmoSpace } from './gizmo.ts';

/**
 * - `moved`   a gizmo step wrote the selection's `Transform`, and the world is
 *             flushed: told just before the frame is drawn, so what a tool
 *             draws from the world keeps up with it
 * - `gizmo`   the gizmo's mode, space or snapping changed
 * - `update`  a frame is about to be drawn, the views placed: a tool puts its own things where they go
 */
export type ViewportEvent = 'moved' | 'gizmo' | 'update';

/** How long what an edit of Claude's changed stays outlined, in milliseconds. */
const FLASH_MS = 1600;

export interface ViewportOptions {
  game: Game;
  /** The gizmo is on the first; the rest get fainter boxes; a click in the scene chooses, unless a tool takes it. */
  selection: Selection;
  /** A drag of the gizmo is over: one step of history, called this. */
  edited(label: string): void;
  /** Draw the frame again: flush, place the views, `update` this, render. */
  draw(): void;
  /** The editor's root: a box being drawn over the scene is an element in it. */
  root: HTMLElement;
  /** World edits held (an Apply's undo or redo landing): the gizmo off the selection until they are not -- one held mid-drag finishes. */
  held?(): boolean;
  /**
   * The scene's room on the page, in client pixels -- between the side cards,
   * under the top bar, above the Assets panel -- which framing fills; null, or
   * none given, for the whole canvas.
   */
  room?(): Room | null;
  /** The wheel is read as another device now: what scrolling does, for the top bar's status line. */
  scrolled?(trackpad: boolean): void;
  /**
   * The view cube's room: `room`'s top, left and right, its foot the
   * canvas's, however short the room is cut from below; null, or none given,
   * for the whole canvas (the cards away).
   */
  cubeRoom?(): Room | null;
  /** Where a camera's preview goes: the room, clear of what lies over its right end (Claude's column overlaid); else `room`. */
  previewRoom?(): Room | null;
}

/** A rectangle of the page, in client pixels: where the scene is seen past the editor's cards. */
export interface Room {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

export interface Viewport {
  open(): void;
  close(): void;
  /** Gizmo, outline, hover and picking: on while a tool that works in the scene is up -- the entity tool. The camera works either way. */
  setActive(active: boolean): void;
  readonly active: boolean;
  /** Before each frame is drawn, with the views placed: the gizmo, the outline and the hover box onto them. */
  update(): void;
  readonly mode: GizmoMode;
  setMode(mode: GizmoMode): void;
  /** The gizmo off the selection for a while, and back: a tool placing things, where a click near one just placed is the tool's, not a handle's. */
  setGizmoAway(away: boolean): void;
  readonly space: GizmoSpace;
  toggleSpace(): void;
  /** Snapping: on or off, and its steps (`prefs.ts`). Ctrl or Cmd held while dragging turns it over. */
  readonly snap: Readonly<Snap>;
  /** Some of it changed: kept as the editor's preferences, the gizmo told, `gizmo` heard. */
  setSnap(snap: Partial<Snap>): void;
  /** What the wheel is -- `auto`, `trackpad` or `mouse` (`wheel.ts`) -- kept with the editor's preferences. */
  readonly wheel: WheelMode;
  setWheel(mode: WheelMode): void;
  /** Does scrolling orbit just now -- a trackpad's two fingers -- rather than zoom? */
  readonly trackpad: boolean;
  /**
   * No box selection for a while, and back: a tool whose clicks in the scene
   * are its own -- placing, picking an entity -- where a left drag then does
   * nothing (the middle button navigates, Docs/navigation.md D3).
   */
  setBoxAway(away: boolean): void;
  /** Where the editor's camera is, or was left (null before it first opened), and the way to put it somewhere: kept across a reload. */
  readonly pose: CameraPose | null;
  setPose(pose: CameraPose): void;
  /** The editor's camera in perspective or orthographic (the cube's centre, its button, Numpad5): what is seen at the target kept the same size. */
  readonly projection: Projection;
  setProjection(projection: Projection): void;
  /** The editor's camera looking from `preset`'s side at the distance it has (a cone of the cube, Numpad1, 3, 7): orthographic with Auto Perspective. */
  look(preset: Preset): void;
  /** From the other side of where it looks (Numpad9). */
  flip(): void;
  /** The numpad's steps (Docs/navigation.md §3): an orbit in turns, a pan in shares of the height seen, a zoom toward the middle. */
  orbitBy(dx: number, dy: number): void;
  panBy(dx: number, dy: number): void;
  zoomBy(scale: number): void;
  /** Blender's walk in the Scene view (Docs/navigation.md §4), `held` the keys down now (MrDebug's). */
  walk(held: (code: string) => boolean): void;
  /** The arrow keys' flight over the Scene view (Docs/navigation.md §7), `held` the keys down now. */
  arrowFly(held: (code: string) => boolean): void;
  /** The room past the cards may have moved -- a card slid away or back: the camera's shape (the game's frame), the cube and the camera preview follow. */
  relayout(): void;
  /** The editor's view now as numbers: what Align with view and Create ▸ Camera take. */
  view(): EditorView;
  /** The editor's camera put where `e`'s camera is, looking as it looks, in its projection (Align view with camera): a view change, no step. */
  lookThrough(e: Entity): void;
  /** The camera onto the selection, near enough that it fills the view; with nothing selected, `frameAll`. */
  focus(): void;
  /** The camera onto everything drawn, every view in the scene. */
  frameAll(): void;
  /** The camera onto these entities, as `focus` onto the selection (`view_focus`): false if none of them is anywhere. */
  frameOn(list: readonly Entity[]): boolean;
  /** The camera drawn through now (the perspective or the orthographic one): what `view_shot` copies. */
  readonly camera: THREE.Camera;
  /** The editor's grid, gizmo, boxes, camera icons, shapes and frustum, and the tools' own out of the scene for a moment (`view_shot`), and back. */
  hideOverlays(hidden: boolean): void;
  /** The camera looked through's shape, icon and frustum out for a moment (`view_shot` through it), and back; null, every camera's. */
  hideCamera(e: Entity | null, hidden: boolean): void;
  /** Where the middle of the view meets the ground: where something new goes. */
  lookAt(): THREE.Vector3;
  /** Where a pointer at (`x`, `y`) on the page meets the ground, into `out`; null if it looks above the horizon, or too far off. */
  groundAt(x: number, y: number, out: THREE.Vector3): THREE.Vector3 | null;
  /** The entity drawn under a point of the page, as a click picks it (`picking.ts`); NONE for none. */
  entityAt(x: number, y: number): Entity;
  /** Is this point of the world in front of the camera and inside the view? */
  sees(point: THREE.Vector3): boolean;
  /**
   * Where these entities are on the page: the top of their bounds, as framing measures them, through the editor's camera
   * and the game's frame -- for what opens at them (the quick prompt, Docs/ai-panel.md §4). Null for none anywhere, or
   * behind the camera.
   */
  screenOf(list: readonly Entity[]): { x: number; y: number } | null;
  /** These entities outlined in Claude's colour for a moment (`FLASH_MS`): an edit of Claude's landing (Docs/ai-panel.md D8). */
  flash(list: readonly Entity[]): void;
  /**
   * A click in the scene -- the entity under it, NONE for empty space, `add`
   * with Shift held, and the pointer, for any other modifier -- before the
   * selection gets it: the handler added last first, and one that returns true
   * has taken it. Returns the undo. A box drawn is the selection's alone.
   */
  onPick(handler: (e: Entity, add: boolean, pointer: PointerEvent) => boolean): () => void;
  /**
   * A right-click in the scene, not a right drag: the entity under it (NONE for
   * none) and the pointer. The handler added last first, as `onPick`. Returns the undo.
   */
  onContext(handler: (e: Entity, pointer: PointerEvent) => boolean): () => void;
  /** Hear a `ViewportEvent`. Returns the undo. */
  on(event: ViewportEvent, fn: () => void): () => void;
  /** Objects of a tool's in the scene while the editor's scene is up: out while closed, or a playtest runs. Returns the undo. */
  add(...objects: THREE.Object3D[]): () => void;
  dispose(): void;
}

export function createViewport({ game, selection, edited, draw, root, held, room, cubeRoom, previewRoom, scrolled }: ViewportOptions): Viewport {
  const { world, scene } = game;
  let isOpen = false;
  let active = false;
  /** A tool has asked for the gizmo out of the way (`setGizmoAway`). */
  let away = false;
  const heard: Record<ViewportEvent, Set<() => void>> = { moved: new Set(), gizmo: new Set(), update: new Set() };
  const tell = (event: ViewportEvent): void => {
    for (const fn of heard[event]) fn();
  };

  /** Drawn soon, once, however many asked: a gizmo step is a `change` and an `objectChange`. */
  let queued = false;
  const soon = (): void => {
    if (queued) return;
    queued = true;
    queueMicrotask(() => {
      if (!queued) return;
      queued = false;
      draw();
    });
  };

  // The orbit round the selection's middle with Orbit Around Selection; what scrolling does said as the wheel's device changes.
  const camera = createCamera(game, soon, { pivot: () => selectionMiddle(), scrolled: (trackpad) => scrolled?.(trackpad), held: (code) => MrDebug.held(code) });
  const gizmo = createGizmo({
    game,
    // Read as it is needed: a projection swapped, the gizmo sizes and picks its handles through the other camera.
    camera: () => camera.object,
    selection,
    hold: (held) => camera.hold(held),
    edited,
    moved: () => {
      tell('moved');
      queued = false;
      draw();
    },
    changed: soon,
  });
  // The camera icons stand for their cameras, which draw nothing: read as picking needs them (the camera view is made below).
  const picking = createPicking({ game, camera, gizmo, selection, root, active: () => active, changed: soon, standIns: () => cameraView.standIns });
  const cube = createSceneCube({ game, camera, root, room: () => cubeRoom?.() ?? null, changed: soon });
  const overlays = createOverlays();
  /** Was each of ours and theirs shown, as the preview hid them: put back as it was. */
  const wasShown: boolean[] = [];
  /** One of the editor's things hidden for the preview, its `i`th, or shown again as it was. */
  const hide = (object: THREE.Object3D, hidden: boolean, i: number): void => {
    if (hidden) wasShown[i] = object.visible;
    object.visible = hidden ? false : wasShown[i] ?? true;
  };
  const cameraView = createCameraView({
    game,
    camera,
    selection,
    root,
    room: () => (previewRoom ?? room)?.() ?? null,
    // The cards up with no room left between them: no preview, rather than one under a card.
    roomless: () => (cubeRoom?.() ?? null) !== null,
    hideOurs(hidden) {
      // Two loops, nothing made for a draw: ours by index, then the tools' own.
      let i = 0;
      for (let n = 0; n < ours.length; n++) hide(ours[n]!, hidden, i++);
      for (const object of theirs) hide(object, hidden, i++);
    },
    changed: soon,
  });
  const ours = [...overlays.objects, ...gizmo.objects, ...cameraView.objects];
  /** `Game.onDrawWorld` while open: the cube, then the selected camera's preview. */
  const drawOver = (renderer: THREE.WebGLRenderer): void => {
    cube.draw(renderer);
    cameraView.draw(renderer);
  };
  /** The tools' own, in the scene with ours. */
  const theirs = new Set<THREE.Object3D>();

  const viewOf = (e: Entity): THREE.Object3D | null => (e !== NONE && world.alive(e) && world.has(e, View) ? world.store(View).value[e] ?? null : null);

  const bounds = new THREE.Box3();
  const box = new THREE.Box3();
  const metre = new THREE.Vector3(1, 1, 1);
  const centre = new THREE.Vector3();
  const along = new THREE.Vector3();

  /** The camera onto these entities: each one's view, or a metre round where it is if it has none. Nowhere if none of them is anywhere: false. */
  function frame(list: Iterable<Entity>): boolean {
    bounds.makeEmpty();
    const w = world.store(WorldTransform);
    for (const e of list) {
      const object = viewOf(e);
      if (object && (object as THREE.Camera).isCamera) {
        // A camera has no bounds of its own: a small box round where it is, so F brings it into view.
        object.getWorldPosition(centre);
        bounds.union(cameraFocusBox([centre.x, centre.y, centre.z], box));
      } else if (object) {
        object.updateMatrixWorld(true);
        bounds.union(box.setFromObject(object));
      } else if (world.alive(e) && world.has(e, Transform)) {
        bounds.union(box.setFromCenterAndSize(centre.set(w.px[e]!, w.py[e]!, w.pz[e]!), metre));
      }
    }
    if (bounds.isEmpty()) return false;
    camera.frame(bounds, inView());
    return true;
  }

  const middle = new THREE.Vector3();
  /** What an edit of Claude's just changed, outlined until `FLASH_MS` is up. */
  let flashing: Entity[] = [];
  let flashTimer: ReturnType<typeof setTimeout> | undefined;
  /** The middle of what is selected, as framing measures it -- null for nothing: Orbit Around Selection's pivot. */
  function selectionMiddle(): THREE.Vector3 | null {
    bounds.makeEmpty();
    for (const e of selection.list) {
      const object = viewOf(e);
      if (object) {
        object.updateMatrixWorld(true);
        if (!box.setFromObject(object).isEmpty()) bounds.union(box);
        else bounds.expandByPoint(object.getWorldPosition(centre));
      }
    }
    return bounds.isEmpty() ? null : bounds.getCenter(middle);
  }

  /**
   * The room past the editor's cards as a part of the view, -1 to 1 each way (`ViewRect`); null for all of it. The view
   * is drawn into the game's frame (`Game.frame`), which is that room itself (Docs/game-view.md §3): all of it then.
   */
  function inView(): ViewRect | null {
    const at = room?.();
    if (!at) return null;
    const page = game.renderer.domElement.getBoundingClientRect();
    const f = game.frame;
    if (f.width === 0 || f.height === 0) return null;
    const left = page.left + f.x;
    const top = page.top + f.y;
    const x = (px: number): number => Math.max(-1, Math.min(1, ((px - left) / f.width) * 2 - 1));
    const y = (px: number): number => Math.max(-1, Math.min(1, 1 - ((px - top) / f.height) * 2));
    const rect = { x0: x(at.left), x1: x(at.right), y0: y(at.bottom), y1: y(at.top) };
    // The frame is the room, to the pixel: the whole view.
    return rect.x0 <= -0.999 && rect.x1 >= 0.999 && rect.y0 <= -0.999 && rect.y1 >= 0.999 ? null : rect;
  }

  /** Every entity alive and drawn: one hidden or switched off is not framed with everything, only when selected. */
  function* everyone(): Generator<Entity> {
    for (let e = 1; e < world.extent; e++) if (world.alive(e as Entity) && world.seenEntity(e as Entity) && world.active(e as Entity)) yield e as Entity;
  }

  const viewport: Viewport = {
    get mode() {
      return gizmo.mode;
    },
    setMode(mode) {
      gizmo.setMode(mode);
      tell('gizmo');
    },
    setGizmoAway(next) {
      if (next === away) return;
      away = next;
      soon();
    },
    get space() {
      return gizmo.space;
    },
    toggleSpace() {
      gizmo.toggleSpace();
      tell('gizmo');
    },
    open() {
      if (isOpen) return;
      isOpen = true;
      scene.add(...ours);
      for (const object of theirs) scene.add(object);
      // In the order they must hear a press: the cube (a press on it is its alone), snapping and the gizmo, the camera,
      // then picking -- which needs to know whether the gizmo took it.
      cube.open();
      cameraView.open();
      game.onDrawWorld = drawOver;
      gizmo.connect();
      camera.open();
      picking.connect();
    },
    close() {
      if (!isOpen) return;
      isOpen = false;
      cube.close();
      cameraView.close();
      if (game.onDrawWorld === drawOver) game.onDrawWorld = null;
      gizmo.disconnect();
      camera.close();
      picking.disconnect();
      gizmo.show(NONE);
      picking.forget();
      queued = false;
      scene.remove(...ours);
      for (const object of theirs) scene.remove(object);
    },
    get active() {
      return active;
    },
    setActive(on) {
      if (on === active) return;
      active = on;
      picking.forget();
      // The cube and its button are the Scene page's: not drawn, nor reachable by Tab, under the Model, Studio or Config page.
      cube.setShown(on);
      cameraView.setShown(on);
      // Off, the gizmo and the boxes leave the frame now, not at the next edit.
      soon();
    },
    update() {
      const e = selection.primary;
      const shown = isOpen && active && e !== NONE && world.alive(e);
      gizmo.show(shown && !away && (gizmo.dragging || !(held?.() ?? false)) ? e : NONE);
      const rest = shown ? selection.list.slice(1) : [];
      const { hovered } = picking;
      overlays.fit(shown ? viewOf(e) : null, rest.map(viewOf), isOpen && active && hovered !== e && !rest.includes(hovered) ? viewOf(hovered) : null);
      overlays.flash(isOpen ? flashing.map(viewOf) : []);
      cameraView.update();
      tell('update');
    },
    get snap() {
      return gizmo.snap;
    },
    setSnap(next) {
      gizmo.setSnap(next);
      tell('gizmo');
    },
    get wheel() {
      return camera.wheel;
    },
    setWheel(mode) {
      camera.setWheel(mode);
      // The top bar's status line says what scrolling does now.
      scrolled?.(camera.trackpad);
      soon();
    },
    get trackpad() {
      return camera.trackpad;
    },
    setBoxAway: (away) => picking.setBoxAway(away),
    get pose() {
      return camera.pose;
    },
    setPose(pose) {
      camera.setPose(pose);
      if (isOpen) soon();
    },
    get projection() {
      return camera.projection;
    },
    setProjection: (projection) => camera.setProjection(projection),
    look: (preset) => camera.snapTo(DIRECTIONS[preset]),
    flip() {
      // From an axis view the opposite one (top and bottom, front and back): an axis view's, Auto Perspective's. From
      // between them, half a turn round the pivot keeping the elevation (Blender's Numpad9).
      const d = camera.direction(along).negate();
      const direction: Vec3 = [d.x, d.y, d.z];
      if (presetOf(direction) === 'free') camera.orbitBy(0.5, 0);
      else camera.snapTo(direction);
    },
    orbitBy: (dx, dy) => camera.orbitBy(dx, dy),
    panBy: (dx, dy) => camera.panBy(dx, dy),
    zoomBy: (scale) => camera.zoomBy(scale),
    walk: (held) => camera.walk(held),
    arrowFly: (held) => camera.arrowFly(held),
    relayout() {
      camera.reshape();
      cube.relayout();
      cameraView.relayout();
    },
    view: () => camera.view(),
    lookThrough(e) {
      const object = viewOf(e);
      if (!object || !(object as THREE.Camera).isCamera) return;
      object.updateMatrixWorld(true);
      object.getWorldPosition(centre);
      object.getWorldDirection(along);
      const o = object as THREE.OrthographicCamera;
      const orthographic = o.isOrthographicCamera === true;
      camera.setPose(lookThroughPose([centre.x, centre.y, centre.z], [along.x, along.y, along.z], camera.view(), {
        projection: orthographic ? 'orthographic' : 'perspective',
        fov: orthographic ? SCENE_FOV : (object as THREE.PerspectiveCamera).fov,
        height: orthographic ? (o.top - o.bottom) / o.zoom : 0,
      }));
      if (isOpen) soon();
    },
    focus() {
      const list = selection.list;
      if (list.length === 0) return viewport.frameAll();
      frame(list);
    },
    frameAll() {
      frame(everyone());
    },
    frameOn(list) {
      const framed = frame(list);
      if (framed && isOpen) soon();
      return framed;
    },
    get camera() {
      return camera.object;
    },
    hideOverlays(hidden) {
      // As the camera preview hides them: ours by index, then the tools' own -- each put back as it was.
      let i = 0;
      for (let n = 0; n < ours.length; n++) hide(ours[n]!, hidden, i++);
      for (const object of theirs) hide(object, hidden, i++);
    },
    hideCamera: (e, hidden) => cameraView.hideThrough(e, hidden),
    lookAt: () => camera.lookAt(),
    groundAt: (x, y, out) => camera.groundAt(x, y, out),
    entityAt: (x, y) => picking.at(x, y),
    sees: (point) => camera.sees(point),
    flash(list) {
      flashing = list.filter((e) => world.alive(e));
      clearTimeout(flashTimer);
      flashTimer = setTimeout(() => {
        flashing = [];
        soon();
      }, FLASH_MS);
      soon();
    },
    screenOf(list) {
      bounds.makeEmpty();
      const w = world.store(WorldTransform);
      for (const e of list) {
        const object = viewOf(e);
        if (object) {
          object.updateMatrixWorld(true);
          if (!box.setFromObject(object).isEmpty()) bounds.union(box);
          else bounds.expandByPoint(object.getWorldPosition(centre));
        } else if (world.alive(e) && world.has(e, Transform)) bounds.expandByPoint(centre.set(w.px[e]!, w.py[e]!, w.pz[e]!));
      }
      if (bounds.isEmpty()) return null;
      bounds.getCenter(middle);
      middle.y = bounds.max.y;
      middle.project(camera.object);
      if (middle.z > 1 || middle.z < -1) return null;
      const canvas = game.renderer.domElement.getBoundingClientRect();
      const f = game.frame;
      return { x: canvas.left + f.x + ((middle.x + 1) / 2) * f.width, y: canvas.top + f.y + ((1 - middle.y) / 2) * f.height };
    },
    onPick: (handler) => picking.onPick(handler),
    onContext: (handler) => picking.onContext(handler),
    on(event, fn) {
      heard[event].add(fn);
      return () => void heard[event].delete(fn);
    },
    add(...objects) {
      for (const object of objects) {
        theirs.add(object);
        if (isOpen) scene.add(object);
      }
      if (isOpen) soon();
      return () => {
        for (const object of objects) {
          theirs.delete(object);
          scene.remove(object);
        }
        if (isOpen) soon();
      };
    },
    dispose() {
      clearTimeout(flashTimer);
      // Their listeners went with `close`; what is left is the gizmo's meshes and ours.
      viewport.close();
      cube.dispose();
      cameraView.dispose();
      gizmo.dispose();
      picking.dispose();
      overlays.dispose();
      camera.dispose();
    },
  };
  return viewport;
}
