/**
 * Whether leaving the page asks first (`config/scenes.ts`' `beforeunload`
 * guard), and what "the scene is edited" means while a prefab is open over it.
 *
 * - **The scene's own mark, wherever its steps are**: opening a prefab puts
 *   the world's history aside (`history.setAside`), and the stack the history
 *   shows is the prefab's -- empty and as saved when it opens. So the scene's
 *   saved mark is read from what was put aside (`opened.outerSaved`) while one
 *   is open, never from `history.saved`; and the prefab's own pushes, undos and
 *   saves are not the scene's edits (`editedAfter`).
 * - **Any world, named or not**: the game's own world edited, or a new scene
 *   not saved yet, asks as a scene file does -- no file is no reason to drop it.
 * - **A reload the editor survives passes** (`passing`): the world goes with
 *   the resume record.
 *
 * Pure: node tests it (`leave-guard.test.ts`).
 */
import type { HistoryEvent } from './history.ts';

export interface LeaveState {
  /** A reload the editor survives is under way (`letReloadPass`). */
  passing: boolean;
  /** The scene was edited since it was saved or loaded (`editedAfter`) -- not just the game run. */
  edited: boolean;
  /** The scene's steps are at their save: `history.saved`, or, with a prefab open, the mark put aside under it. */
  sceneSaved: boolean;
  /** A prefab open with edits not saved, at any level (`opened.unsavedAny`). */
  besideUnsaved: boolean;
}

/** Does leaving the page now lose something nobody saved, so the browser asks first? */
export const asksOnLeave = (s: LeaveState): boolean => !s.passing && ((s.edited && !s.sceneSaved) || s.besideUnsaved);

/**
 * The scene's `edited` after history told `event`. While the history is set
 * aside (`aside > 0`: a prefab open) its moves are the prefab's, and leave it
 * as it was; `'aside'` -- set aside or taken back -- moves nothing of it.
 */
export function editedAfter(edited: boolean, event: HistoryEvent, history: { readonly saved: boolean; readonly aside: number }): boolean {
  if (history.aside > 0) return edited;
  if (event === 'push') return true;
  if (event === 'undo' || event === 'redo') return !history.saved;
  if (event === 'saved' && history.saved) return false;
  return edited;
}
