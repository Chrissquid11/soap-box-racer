/**
 * Which stack the host's Undo, Redo and History card work on (Docs/assets.md
 * §6, "The host change"): the focused tool's own `history`, if it has one,
 * else the world's. The host's rules, pure, so a node test holds them:
 *
 * - **The side decides**: `tool()` is the tool with the keys -- the tab's own,
 *   or in the Scene tab the side last pressed in (`sides.ts`): Z with the
 *   Assets panel focused is the asset stack, with the tree, the scene or the
 *   entity inspector focused the world's -- the keys, the bars' buttons and
 *   the History card alike (`sides.test.ts`).
 * - **An edit under way is a step of its own first** (`commit`, the world's
 *   `worldSteps.commit(PENDING)`), but only before the world's undo, redo or
 *   travel: a tool's stack has no pending world edit in it.
 * - **Busy means no Undo**: while the tool up says `busy()` -- its steps still
 *   on their way to the disk -- Undo, Redo and a travel do nothing, and
 *   `canUndo` and `canRedo` say so. Every stack is busy too while a step of
 *   the world's is still landing (`worldBusy`: an Apply, or its undo or redo,
 *   whose files go first and whose world is loaded once they compile) -- a
 *   step under it undone meanwhile would be loaded over, and a tool's own
 *   (the Assets tool's file steps) would write and recompile under it.
 * - **Nothing here, something there** (`elsewhere`): Z or Y with the focused
 *   side's stack empty that way, and the world's not, says so -- naming the
 *   world's step and how to reach it -- rather than doing nothing unsaid.
 * - **A travel** -- a step of the History card clicked -- is each step's own
 *   `undo` or `redo`, one at a time, as Z and Y would take them; on a tool's
 *   stack each queues its call (`assets/steps.ts`).
 */
import type { History } from './history.ts';

/** What the host asks of the tool up: `ToolInstance`'s two members. */
export interface HistoryHolder {
  history?: History;
  busy?(): boolean;
}

export interface HistoryHostOptions {
  /** The world's stack: every tool's without one of its own. */
  world: History;
  /** The tool with the keys, if any: the tab's own, or the focused side of a tab of several. */
  tool(): HistoryHolder | undefined;
  /** An edit under way made a step of the world's first: `worldSteps.commit(PENDING)`. */
  commit(): void;
  /** A step of the world's still landing (`OverrideSteps.busy`): every stack waits for it. */
  worldBusy?(): boolean;
}

export interface HistoryHost {
  /** The stack the host shows and works on just now. */
  readonly history: History;
  /** Is it the world's? */
  readonly isWorld: boolean;
  /** The tool up is busy: nothing may be undone or redone until it is not. */
  readonly busy: boolean;
  readonly canUndo: boolean;
  readonly canRedo: boolean;
  readonly undoLabel: string | null;
  readonly redoLabel: string | null;
  /** Z: false if nothing was undone (busy, or nothing to undo). */
  undo(): boolean;
  /** Y: the same. */
  redo(): boolean;
  /** Undone or redone, one step at a time, until `to` steps are done. False, and nothing done, while busy. */
  travel(to: number): boolean;
}

export function createHistoryHost({ world, tool, commit, worldBusy }: HistoryHostOptions): HistoryHost {
  const active = (): History => tool()?.history ?? world;
  /** A step of the world's still landing, while the world's stack is the one up. */
  const landing = (): boolean => active() === world && (worldBusy?.() ?? false);
  // A tool's stack waits too: the Assets tool's undo may write a prefab file the landing is writing, or recompile under it.
  const busy = (): boolean => (tool()?.busy?.() ?? false) || (worldBusy?.() ?? false);
  /** The world's pending edit first, before anything moves on its stack. */
  const settle = (history: History): void => {
    if (history === world) commit();
  };
  return {
    get history() {
      return active();
    },
    get isWorld() {
      return active() === world;
    },
    get busy() {
      return busy();
    },
    get canUndo() {
      return !busy() && active().canUndo;
    },
    get canRedo() {
      return !busy() && active().canRedo;
    },
    get undoLabel() {
      return active().undoLabel;
    },
    get redoLabel() {
      return active().redoLabel;
    },
    undo() {
      if (busy()) return false;
      const history = active();
      settle(history);
      return history.undo();
    },
    redo() {
      if (busy()) return false;
      const history = active();
      settle(history);
      return history.redo();
    },
    travel(to) {
      if (busy()) return false;
      const history = active();
      // An edit under way is a step of its own first, after the rest: the step clicked is where it was.
      settle(history);
      // A step that lands later (an Apply's) stops the travel there: what is under it waits for it.
      while (history.done > to && !landing() && history.undo());
      while (history.done < to && !landing() && history.redo());
      return true;
    },
  };
}

/**
 * Z (`undo`) or Y with a tool's own stack up that has nothing that way, and
 * the world's has: the line that says so -- `name` the tool's -- for the host
 * to say. Null when the stack up is the world's, could move, is busy, or the
 * world's has nothing either.
 */
export function elsewhere(host: HistoryHost, world: History, name: string, what: 'undo' | 'redo'): string | null {
  if (host.isWorld || host.busy) return null;
  const undo = what === 'undo';
  if (undo ? host.canUndo : host.canRedo) return null;
  const label = undo ? world.undoLabel : world.redoLabel;
  if (label === null) return null;
  return `${name}: nothing to ${what} -- click in the scene or the tree for the world's ${undo ? 'Undo' : 'Redo'} (${label})`;
}
