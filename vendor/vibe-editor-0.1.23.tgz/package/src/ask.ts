/**
 * A question in a panel (`createAsk`), never `prompt`, `confirm` or `alert`:
 * those stop the page, and the game and any automation driving it with it
 * (`vibe test`'s routes check, the pipeline's `checks/routes.ts`, fails on one anywhere in `packages/editor/src/`). The Scenes tool's
 * name and "replace it?", the Assets tool's "Delete characters/ and the 14
 * files under it?" -- a line of amber where the buttons that asked it are,
 * with its own buttons and Cancel.
 *
 * - **One at a time**: a question put while one is up takes its place.
 * - **Esc says no**: the browser's close request where it has one
 *   (`onCloseRequest`), and the tool's `holdsEscape` and `cancel` -- `open`,
 *   `close` -- everywhere, so Esc closes the question before the editor.
 * - **A form**: a name typed is sent by Enter, the browser's own.
 */
import { onCloseRequest, textInput } from './fields.ts';
import { button, control, el } from './shell.ts';

export interface Ask {
  /** A question up: what `holdsEscape` reads. */
  readonly open: boolean;
  /** `text`, and its buttons, then Cancel: up in place of any question before it. */
  put(text: string, ...parts: HTMLElement[]): void;
  /** "Are you sure?": `yes` runs `run`, in red for what cannot be had back (`danger`); `closed` told as it goes down, whichever way -- before `run`. */
  askFirst(text: string, yes: string, run: () => void, danger?: boolean, closed?: () => void): void;
  /** A name, typed: Enter or `ok` takes it; an empty one is no answer. */
  askName(text: string, value: string, done: (name: string) => void, ok?: string): void;
  /** Down, as Cancel or Esc takes it: no answer. */
  close(): void;
}

/**
 * The question's place in `panel` -- a `<form class="ed-ask">`, hidden until
 * a question is put -- appended now, so a caller makes it where it wants it:
 * after its buttons (Scenes), or in a box under its head that its redraws
 * leave alone (the asset inspector).
 */
export function createAsk(panel: HTMLElement): Ask {
  const form = el('form', 'ed-ask');
  form.hidden = true;
  panel.append(form);
  /** The question up, if any: what takes it down. */
  let question: (() => void) | null = null;

  function close(): void {
    const down = question;
    question = null;
    down?.();
  }

  function put(text: string, ...parts: HTMLElement[]): void {
    close();
    const unwatch = onCloseRequest(close);
    question = () => {
      unwatch();
      form.hidden = true;
      form.onsubmit = null;
      form.replaceChildren();
    };
    const line = el('div', 'ed-buttons');
    line.append(...parts, button('ui', 'Cancel', 'Leave it (Esc)', close, 'ed-quiet'));
    form.replaceChildren(el('div', 'ed-ask-text', text), line);
    form.hidden = false;
  }

  return {
    get open() {
      return question !== null;
    },
    put,
    askFirst(text, yes, run, danger = false, closed) {
      put(text, button('ui', yes, '', () => {
        close();
        run();
      }, danger ? 'ed-danger' : 'ed-accent'));
      if (closed) {
        const down = question!;
        question = () => {
          down();
          closed();
        };
      }
    },
    askName(text, value, done, ok = 'Save') {
      const input = textInput(value, 'Name');
      const send = control('ui', 'ed-button ed-accent', ok);
      send.type = 'submit';
      put(text, input, send);
      form.onsubmit = (event) => {
        event.preventDefault();
        const typed = input.value.trim();
        if (!typed) return input.focus();
        close();
        done(typed);
      };
      queueMicrotask(() => {
        input.focus();
        input.select();
      });
    },
    close,
  };
}
