/**
 * Which device a wheel event came from, a trackpad's or a mouse's, and its
 * deltas as a drag: what the navigation's rule (`view/navigation.ts`,
 * `wheelAction`) reads to say what it does. Pure: node tests it.
 *
 * - **Pinch is a wheel event with Ctrl held**, as every browser delivers it.
 * - **Which device it is** is the editor's preference (`prefs.ts`): `trackpad`,
 *   `mouse`, or `auto` -- read off the event. A wheel in lines or pages is a
 *   mouse; in pixels with any sideways delta, or a small one, a trackpad; a big
 *   vertical step alone (or, Shift held, sideways alone: a Mac's turned wheel),
 *   a mouse. A gesture is one device from end to end: a
 *   trackpad's flick can end in big steps, which go on orbiting.
 */
import type { WheelMode } from './prefs.ts';

export type WheelDevice = 'trackpad' | 'mouse';

/** What of a `WheelEvent` the rule reads. */
export interface WheelInput {
  deltaX: number;
  deltaY: number;
  /** 0 pixels, 1 lines, 2 pages. */
  deltaMode: number;
  ctrlKey: boolean;
  shiftKey: boolean;
  /** Milliseconds, as the event has it: what tells one gesture from the next. */
  timeStamp: number;
}

/** A pixel step at least this big, and straight up or down, is a mouse wheel's notch; a trackpad moves by less. */
export const NOTCH = 50;
/** Wheel events closer than this, in milliseconds, are one gesture, of one device. */
export const GESTURE = 300;

/** The last wheel event read: its device and when, for the next to go on with. */
export interface WheelLast {
  device: WheelDevice;
  at: number;
}

/** The device `event` came from, as the preference has it, or as it looks: `last` the one before it, if any. */
export function wheelDevice(event: WheelInput, mode: WheelMode, last: WheelLast | null): WheelDevice {
  if (mode !== 'auto') return mode;
  if (event.deltaMode !== 0) return 'mouse';
  // A Mac turns a mouse's wheel sideways while Shift is held: a sideways step alone, with Shift, is read as the wheel's own.
  const sideways = event.shiftKey && event.deltaY === 0;
  const step = sideways ? event.deltaX : event.deltaY;
  if ((!sideways && event.deltaX !== 0) || Math.abs(step) < NOTCH) return 'trackpad';
  // A big step in the middle of a trackpad's gesture -- the end of a flick -- is the trackpad still.
  return last?.device === 'trackpad' && event.timeStamp - last.at < GESTURE ? 'trackpad' : 'mouse';
}

/**
 * The event's deltas as a pointer drag that would do the same, in CSS pixels:
 * the scene follows the fingers, as it follows the pointer in a drag. Lines and
 * pages are made pixels as OrbitControls makes them.
 */
export function wheelDrag(event: WheelInput): { dx: number; dy: number } {
  const scale = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? 100 : 1;
  return { dx: -event.deltaX * scale, dy: -event.deltaY * scale };
}
