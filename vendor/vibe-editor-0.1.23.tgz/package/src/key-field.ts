/**
 * A `key(kind)` field, a `color()` field and a `bool()` field in the inspector
 * (Docs/render.md §6, Docs/ecs.md §13): an asset key picked from a list, a
 * colour from a swatch, a yes or no a tick.
 *
 * - **A key field is a picker** (`picker`): a line of text showing the key the
 *   column's id stands for (`keyText`), `none` for 0 -- or `—` for several that
 *   differ, their keys on hover. Focused, a list drops down under it of every
 *   key of its kind loaded now (`Assets.keysOf`, handed in as `KeySources`),
 *   `none` first; typing filters it. The list floats over the panel (`floatList`,
 *   in the editor's root, placed by `menu-place.ts`' `placeDrop`): what is under
 *   the field never moves. It follows a scroll of the panel -- placed as
 *   something moves, never each frame -- and is let go once the field is
 *   scrolled out of the panel's body (under its header too) or the window resized. A pick writes the id (`internKey`) into
 *   every one selected and is one step of history, `Set Render.model` (× 3), as
 *   a number's edit is -- so an instance's override, its bar, Revert and Apply
 *   are a number's too. **Every kind** (Docs/properties.md D6): `keysOf` lists
 *   what the project has of it -- a Sfx, a Prefab, a Scene, a project's own data
 *   kind -- a mounted pack's marked with its pack.
 * - **Each key its look** (`KeyLook`, the page's `key-looks.ts`): on its row and
 *   before the field, a thumbnail (a model, a texture, a prefab's model, an
 *   icon), a swatch (a material), a glyph (a scene, a level, an atlas, a data
 *   file), a font's name in its own face; a sound (`Sfx`, `UiSfx`, `Music`) a
 *   play button on each row and after the field -- through the game's mixer,
 *   one at a time, a row's stopped as its list shuts. Made as drawn, never each
 *   frame.
 * - **An asset file dropped on it is picked** (`drops`, `asset-drag.ts`): a
 *   drag from the Assets panel of one file of its kind lights the field (an
 *   outline in the accent) and, dropped, sets it as a pick would -- one step,
 *   an override on an instance, every one selected; several of its kind are
 *   refused, the field saying one; any other drag, the cursor says no. Never
 *   the selection's or the inspector's to change. `Clip` takes none: a clip is
 *   no file.
 * - **Its keys are MrDebug's** (`keyPickKeys`, the Scene tab's): ↑ ↓ walk the
 *   list, Enter picks, Esc lets go -- field actions of `data-keys-field="key-pick"`,
 *   never a listener of the field's own (CLAUDE.md).
 * - **`Render.model` and a `mesh()` have a second picker, its part** (`parts`): the named objects
 *   of the model chosen (`Assets.partsOf`), `none` first; a part picked writes
 *   `model#part` as the one key (Docs/render.md §2). A model picked drops the
 *   part, unless it is the model it is already; a model file dropped asks for
 *   the part next -- the part's list dropped down, none (the whole model) first.
 * - **A `Clip` key lists the entity's model's clips** (`clips`, Docs/render.md
 *   §6): the names of the clips of the model it is drawn with, `none` first;
 *   several selected, the names they all share. `Animation.clip` is one.
 * - **A colour is a swatch** (`<input type=color>`): each change written live,
 *   the swatch let go one step; several that differ show `—` beside it.
 * - **A yes or no is a tick** (`bool()`, `checkLine`): a click one step,
 *   `Set Render.castShadow` (× 3); several that differ show it indeterminate.
 *
 * Made with `dom.ts`' `el`, and the engine's pure side only: node tests it over
 * a stand-in page (`key-field.test.ts`).
 */
import { type Component, type Entity, internKey, keyKindOf, keyText, soundKind, splitModel, type World } from '@vibe/engine';
import { dragTakes, droppedKey } from './asset-drag.ts';
import { dragging, fits, type DragFacts } from './drag-record.ts';
import { dropTarget, refusing } from './drop-target.ts';
import { el } from './dom.ts';
import { ICON, type IconName } from './icons.ts';
import { textInput } from './fields.ts';
import { dropFate, placeDrop, visibleBody } from './menu-place.ts';
import { agreed, eachOwn, MIXED, times } from './multi.ts';
import type { ToolKey } from './tool.ts';

/** A key field asks nothing of the world: what is dragged is an asset or it is not. */
const NO_FACTS: DragFacts = { alive: () => false, has: () => false, name: () => '' };

/** The pickers' key scope (MrDebug's `data-keys-field`): their ↑ ↓ Enter and Esc. */
export const KEY_FIELD = 'key-pick';

/** What a picker offers: the keys of a kind loaded now, a model's parts, an entity's clips, and a model's thumbnail. The page's are `Assets`'. */
export interface KeySources {
  keysOf(kind: string): readonly string[];
  partsOf(model: string): readonly string[];
  /** The names of the clips of the model `e` is drawn with, as keys are spelt (lowercased): what a `Clip` key may be on it. Left out, a `Clip` field lists `keysOf('Clip')`. */
  clips?(e: Entity): readonly string[];
  /** A model's thumbnail as a URL to draw, or null for none to be had: the Assets panel's. Left out, rows have none. */
  thumb?(model: string): Promise<string | null>;
  /** What a key of `kind` looks like in a row and on the field (`KeyLook`), or null for nothing to show. Left out, a model's `thumb` alone. */
  look?(kind: string, key: string): KeyLook | null;
  /**
   * A sound key of `kind` (`Sfx`, `UiSfx`, `Music`) played through the game's mixer, `ended` told as it ends of itself:
   * its stop -- or, played nowhere, why it would not be heard ("muted in the game's settings"). Left out, no play button.
   */
  play?(kind: string, key: string, ended: () => void): (() => void) | string;
}

/**
 * What a key looks like beside its text (Docs/properties.md D6): a picture (a model's, a texture's, a prefab's model's,
 * an icon's own), a swatch (a material's colour), a glyph of the editor's (a scene, a level, an atlas, a data file),
 * or a font's family -- the name drawn in it once loaded. Made only as a row or the field is drawn: no frame's work.
 */
export type KeyLook =
  | { readonly thumb: Promise<string | null> }
  | { readonly swatch: string }
  | { readonly glyph: IconName }
  | { readonly font: Promise<string | null> };


/** The glyph a kind with no picture of its own shows: a scene's, a level's, an atlas's, a data file's. */
export function kindGlyph(kind: string): IconName {
  return kind === 'Scene' ? 'scenes' : kind === 'Level' ? 'grid' : kind === 'Atlas' ? 'assets' : 'file';
}

/** `look` drawn into `into` (emptied first): an image, a swatch, a glyph; a font's family set on `text` once loaded, while `still()`. Null draws nothing. */
function drawLook(into: HTMLElement, look: KeyLook | null, text: HTMLElement | null, still: () => boolean = () => true): void {
  into.textContent = '';
  into.className = 'ed-keypick-look';
  into.hidden = look === null || 'font' in look;
  if (look === null) return;
  if ('thumb' in look) {
    const pic = el('img', 'ed-keypick-thumb');
    pic.alt = '';
    into.append(pic);
    void look.thumb.then((url) => (url ? void (pic.src = url) : pic.classList.add('ed-keypick-blank')), () => pic.classList.add('ed-keypick-blank'));
  } else if ('swatch' in look) {
    into.classList.add('ed-keypick-swatch');
    into.style.background = look.swatch;
    into.title = look.swatch;
  } else if ('glyph' in look) {
    into.classList.add('ed-keypick-glyph');
    into.innerHTML = ICON[look.glyph];
  } else if (text) void look.font.then((family) => (family && still() ? void (text.style.fontFamily = `"${family}", sans-serif`) : undefined), () => undefined);
}

/** A key of a mounted pack (`reef:props/coral`): its pack, for the row's mark; null for the boot set's. */
export const packOf = (key: string): string | null => (key.includes(':') ? key.slice(0, key.indexOf(':')) : null);

/** The sound playing from a picker -- a row's or a field's button -- and its button: one at a time, stopped as its picker shuts. */
let sounding: { stop(): void; button: HTMLElement; owner: HTMLElement | null } | null = null;

/** Whatever a picker is playing, stopped -- or, `ended`, done of itself: its button put back. */
export function stopSound(ended = false): void {
  const was = sounding;
  sounding = null;
  if (!was) return;
  if (!ended) was.stop();
  was.button.classList.remove('ed-keypick-sounding');
  was.button.setAttribute('aria-pressed', 'false');
  was.button.innerHTML = ICON.play;
}

/** A play button for `key`: pressed, plays it (anything else playing stopped); pressed again, or another, stops it. `owner`: the list it is a row of, stopped as that shuts. */
function playButton(key: () => string, play: (key: string, ended: () => void) => (() => void) | string, title: string, owner: HTMLElement | null = null): HTMLElement {
  // A preview heard, nothing changed: the sound's key is the field's, scene_set's.
  const button = el('button', 'ed-keypick-play'); // mcp: ui
  button.type = 'button';
  button.title = title;
  button.setAttribute('aria-label', title);
  button.setAttribute('aria-pressed', 'false');
  button.dataset.mcp = 'ui';
  button.innerHTML = ICON.play;
  // Pressed, not clicked: in a row the field keeps the focus, so the list stays down.
  button.addEventListener('pointerdown', (event) => {
    (event as Event).preventDefault();
    (event as Event).stopPropagation?.();
    const mine = sounding?.button === button;
    stopSound();
    const k = key();
    if (mine || k === '') return;
    const playing = { stop: () => {}, button, owner };
    sounding = playing;
    // Ended of itself: its button put back, if it is still the one playing.
    const started = play(k, () => (sounding === playing ? stopSound(true) : undefined));
    if (typeof started === 'string') {
      // Not played -- muted, say: never lit as playing, the reason on the button.
      sounding = null;
      button.title = `${title} -- not played: ${started}`;
      button.classList.add('ed-keypick-unheard');
      return;
    }
    playing.stop = started;
    button.title = title;
    button.classList.remove('ed-keypick-unheard');
    button.classList.add('ed-keypick-sounding');
    button.setAttribute('aria-pressed', 'true');
    // Playing: pressed again stops it, and says so.
    button.innerHTML = ICON.stop;
  });
  return button;
}

/** What a key or colour field writes with: the inspector's `Blocks`, as much of it as these need. */
export interface KeyBlocks {
  readonly world: World;
  /**
   * `commit`, one step; `focus`, the keys to the side whose inspector it is -- an asset file dropped on a key field is
   * that side's step, so Z is its after it (the drag began on the other side, which had them).
   */
  readonly host: { commit(label: string): void; focus?(): void };
  /** Read again with the other fields' numbers (`showValues`). */
  live(update: () => void): void;
  /** Written in place: drawn, and the numbers read again. */
  wrote(): void;
}

export interface PickerOptions {
  /** What it is, for its hover and its list. */
  title: string;
  /** The key shown: its text, `''` for none, null for several that differ (`note` on hover). */
  value: string | null;
  note?: string;
  /** What none is called: `none`, `as authored` -- the list's first row. Left out, there is no none: an enum's names alone. */
  none?: string;
  /** The keys to pick from now, none left out: read as the list drops down. */
  choices(): readonly string[];
  /** A row's thumbnail (a model's). */
  thumb?(key: string): Promise<string | null>;
  /** A row's and the field's look (`KeyLook`): a thumbnail, a swatch, a glyph, a font. Over `thumb` where both are given. */
  look?(key: string): KeyLook | null;
  /** A sound's preview, `ended` told as it ends of itself; its stop: a play button on each row and beside the field. Stopped as the list shuts. */
  play?(key: string, ended: () => void): (() => void) | string;
  /** Shown, never picked: a runtime field of an opened prefab, or nothing to pick from. */
  fixed?: boolean;
  /** A key picked -- `''` for none: written, one step. */
  pick(text: string): void;
  /** The key type an asset file dropped on it must be (`Model`, `Material`, `Texture`): taken as a pick. Left out, no drop. */
  drops?: string;
  /**
   * After `pick`, for a dropped file it took -- never a drop refused: the host gives the keys to the side whose field
   * it is, so Z undoes the drop (the drag began on the Assets panel, which had them).
   */
  dropped?(): void;
}

export interface Picker {
  readonly root: HTMLElement;
  readonly input: HTMLInputElement;
  /** What it stands for now -- unless it is being typed in. */
  show(value: string | null, note?: string): void;
  /** Shown, or not pickable: the part's picker while the model is mixed or none. */
  fix(fixed: boolean): void;
}

/** The picker whose list is down, if any: what its keys walk. */
interface Open {
  /** Still in the page: the inspector built again under it takes it out with no blur, and its own live hooks with it. */
  inPage(): boolean;
  step(by: number): void;
  enter(): void;
  cancel(): void;
}
let open: Open | null = null;

/** Is a picker's list down? Not one taken out of the page with it down (the inspector built again under it): let go. */
export function keyPickOpen(): boolean {
  if (open !== null && !open.inPage()) open = null;
  return open !== null;
}

/**
 * The pickers' keys, for the Scene tab to register (field actions: typed into a
 * picker alone). ↑ ↓ only look, so they are live while an Apply lands.
 */
export function keyPickKeys(): ToolKey[] {
  const when = keyPickOpen;
  return [
    { name: 'key pick up', mcp: 'ui', key: 'ArrowUp', field: KEY_FIELD, view: true, anySide: true, help: 'In a key\'s picker: the row above', when, run: () => open?.step(-1) },
    { name: 'key pick down', mcp: 'ui', key: 'ArrowDown', field: KEY_FIELD, view: true, anySide: true, help: 'In a key\'s picker: the row below', when, run: () => open?.step(1) },
    { name: 'key pick', mcp: 'ui', key: ['Enter', 'NumpadEnter'], field: KEY_FIELD, anySide: true, help: 'In a key\'s picker: pick the row lit', when, run: () => open?.enter() },
    { name: 'key pick cancel', mcp: 'ui', key: 'Escape', field: KEY_FIELD, view: true, anySide: true, help: 'In a key\'s picker: let go, nothing picked', when, run: () => open?.cancel() },
  ];
}

/** How long a field says why a drop was refused (a key not loaded), in ms: there is no leaving after a drop to end it. */
const SAID_FOR = 3000;

/** A picker's list is at least this wide, over a narrow field (the part's). */
const LIST_MIN_WIDTH = 160;

/** What a floating list does: placed again as its rows change (`measure`, after each fill), put back as the picker shuts (`land`). */
interface Floating {
  measure(): void;
  land(): void;
}

/** The sticky header of a side card (`.ed-panel-bar`), which the card's fields scroll under; null for none. */
function headOf(panel: HTMLElement): HTMLElement | null {
  for (const child of Array.from(panel.children) as HTMLElement[]) if (child.classList.contains('ed-panel-bar')) return child;
  return null;
}

/**
 * `list` floated over the editor while `input`'s picker is down: moved into the editor's root (`.ed`, fixed over the
 * window, so its box is the page's) -- out of the side panel, whose `overflow` would cut it and whose layout it would
 * push -- and placed against the field, clamped to the panel's body below its sticky header (`visibleBody`,
 * `placeDrop`). Placed only as something moves -- its rows filled (`measure`, the one time its height is read), a
 * scroll in the panel (a capturing `scroll`), the field or the panel resized (a `ResizeObserver`, which also hears the
 * field taken out of the page), the window resized -- never each frame. `gone` (`dropFate`): `true` once the field
 * leaves the page (the inspector built again under it); `false` once it is scrolled out of the body or the window is
 * resized. Moved before it is filled, so its rows never land in the panel. `land` puts it back, hidden, in `home`, and
 * takes every listener off. Off a page (no `.ed` over the field: a node test's stand-in page), the list stays where
 * it is.
 */
function floatList(input: HTMLElement, list: HTMLElement, home: HTMLElement, gone: (out: boolean) => void): Floating {
  const layer = typeof input.closest === 'function' ? input.closest<HTMLElement>('.ed') : null;
  if (layer === null) return { measure: () => {}, land: () => {} };
  const panel = input.closest<HTMLElement>('.ed-side') ?? layer;
  const head = headOf(panel);
  const opened = { width: innerWidth, height: innerHeight };
  list.classList.add('ed-keypick-float');
  layer.append(list);
  /** Its own height, as the stylesheet caps it: read once a fill, not each placing. */
  let height = 0;
  let landed = false;
  const place = (): void => {
    if (landed) return;
    const field = input.getBoundingClientRect();
    const body = visibleBody(panel.getBoundingClientRect(), head?.getBoundingClientRect() ?? null);
    const fate = dropFate(field, body, input.isConnected, { width: innerWidth, height: innerHeight }, opened);
    if (fate !== 'place') return gone(fate === 'detached');
    const at = placeDrop(field, { width: LIST_MIN_WIDTH, height }, body);
    list.style.left = `${at.left}px`;
    list.style.top = `${at.top}px`;
    list.style.width = `${at.width}px`;
    list.style.maxHeight = `${at.height}px`;
    list.classList.toggle('ed-above', at.above);
  };
  const resized = new ResizeObserver(place);
  resized.observe(input);
  resized.observe(panel);
  panel.addEventListener('scroll', place, true);
  addEventListener('resize', place);
  return {
    measure() {
      // Measured with nothing of the last placing on it.
      list.style.maxHeight = '';
      height = list.offsetHeight;
      place();
    },
    land() {
      landed = true;
      resized.disconnect();
      panel.removeEventListener('scroll', place, true);
      removeEventListener('resize', place);
      list.classList.remove('ed-keypick-float', 'ed-above');
      list.removeAttribute('style');
      home.append(list);
    },
  };
}

/** Does `key` match what is typed: any part of it, in any case; `none`'s own word for none. */
const matches = (text: string, said: string, typed: string): boolean => typed === '' || said.toLowerCase().includes(typed) || text.toLowerCase().includes(typed);

/**
 * A key picked from a list: a line showing the key, a list under it as it is
 * focused (the module's header).
 */
export function picker(o: PickerOptions): Picker {
  const root = el('div', 'ed-keypick');
  const input = textInput('');
  input.classList.add('ed-keypick-input');
  input.dataset.keysField = KEY_FIELD;
  input.setAttribute('role', 'combobox');
  input.setAttribute('aria-expanded', 'false');
  input.setAttribute('aria-label', o.title);
  const list = el('div', 'ed-keypick-list');
  list.setAttribute('role', 'listbox');
  list.hidden = true;
  /** What a key looks like, by `look` or a model's `thumb`. */
  const lookOf = (key: string): KeyLook | null => (key === '' ? null : o.look ? o.look(key) : o.thumb ? { thumb: o.thumb(key) } : null);
  /** On the field: its look before it (a thumbnail, a swatch, a glyph) and a sound's play button after -- for the key it holds. */
  const fieldLook = o.look ? el('span', 'ed-keypick-look') : null;
  const fieldPlay = o.play ? playButton(() => value ?? '', o.play, `Play ${o.title}`) : null;
  if (fieldLook || fieldPlay) {
    const line = el('div', 'ed-keypick-line');
    if (fieldLook) line.append(fieldLook);
    line.append(input);
    if (fieldPlay) line.append(fieldPlay);
    root.append(line, list);
  } else root.append(input, list);
  /** The key whose look the field shows: drawn again only when it changes. */
  let looked: string | null = null;

  /** What it stands for: a key, `''` none, null mixed. */
  let value = o.value;
  let note = o.note;
  let fixed = o.fixed === true;
  const said = (v: string | null): string => (v === null ? '' : v === '' ? (o.none ?? '') : v);
  const draw = (): void => {
    input.value = said(value);
    input.placeholder = value === null ? MIXED : '';
    input.classList.toggle('ed-mixed', value === null);
    input.classList.toggle('ed-keypick-none', value === '');
    input.title = value === null && note ? `${o.title}\n${note}` : `${o.title}: ${said(value)}`;
    input.disabled = fixed;
    const holds = value ?? '';
    if (fieldLook && holds !== looked) {
      looked = holds;
      input.style.fontFamily = '';
      drawLook(fieldLook, lookOf(holds), input, () => looked === holds);
    }
    if (fieldPlay) (fieldPlay as HTMLButtonElement).disabled = holds === '';
  };
  draw();

  /** The list's rows as shown, by key (`''` none), and the one lit. */
  let rows: string[] = [];
  let at = 0;
  const light = (): void => {
    const shown = list.children as unknown as ArrayLike<HTMLElement>;
    for (let i = 0; i < rows.length; i++) {
      const row = shown[i];
      if (!row) continue;
      row.classList.toggle('ed-at', i === at);
      row.setAttribute('aria-selected', String(i === at));
      // The list scrolled to it, nothing else: it floats (positioned, its rows' offsets its own), and `scrollIntoView`
      // would scroll whatever is behind it too.
      if (i === at && list.classList.contains('ed-keypick-float')) {
        if (row.offsetTop < list.scrollTop) list.scrollTop = row.offsetTop;
        else if (row.offsetTop + row.offsetHeight > list.scrollTop + list.clientHeight) list.scrollTop = row.offsetTop + row.offsetHeight - list.clientHeight;
      }
    }
  };
  const fill = (typed: string): void => {
    const q = typed.trim().toLowerCase();
    rows = [...(o.none !== undefined ? [''] : []), ...o.choices()].filter((text) => matches(text, said(text), q));
    list.textContent = '';
    rows.forEach((text, i) => {
      const row = el('div', 'ed-keypick-row');
      row.setAttribute('role', 'option');
      row.title = said(text);
      const words = el('span', text === '' ? 'ed-keypick-text ed-dim' : 'ed-keypick-text', said(text));
      if (o.look || o.thumb) {
        // Each row its kind's look -- none's the ground alone -- so the names stay in one column.
        const look = el('span', 'ed-keypick-look');
        const seen = lookOf(text);
        drawLook(look, seen, words);
        if (text === '' && o.thumb && !o.look) {
          look.hidden = false;
          look.append(Object.assign(el('img', 'ed-keypick-thumb ed-keypick-blank'), { alt: '' }));
        }
        row.append(look);
      }
      row.append(words);
      const pack = packOf(text);
      if (pack !== null) {
        const mark = el('span', 'ed-keypick-pack', pack);
        mark.title = `In the pack ${pack}, mounted now`;
        row.append(mark);
      }
      if (o.play && text !== '') row.append(playButton(() => text, o.play, `Play ${text}`, list));
      // Pressed, not clicked: the field keeps the focus, so its blur does not take the list away first.
      row.addEventListener('pointerdown', (event) => {
        event.preventDefault();
        choose(i);
      });
      list.append(row);
    });
    if (rows.length === 0) list.append(el('div', 'ed-keypick-empty ed-dim', `No ${o.title} matches`));
    // What it holds, if listed; else the first match -- past none when none is listed too.
    const now = value === null ? -1 : rows.indexOf(value);
    at = now >= 0 ? now : q === '' ? 0 : rows[0] === '' ? Math.min(1, rows.length - 1) : 0;
    light();
  };
  /** The floating list's placing, while it floats. */
  let floating: Floating | null = null;
  const shut = (): void => {
    // A sound a row played stops with its list; the field's own button plays on until pressed again.
    if (sounding !== null && sounding.owner === list) stopSound();
    floating?.land();
    floating = null;
    list.hidden = true;
    list.textContent = '';
    rows = [];
    input.setAttribute('aria-expanded', 'false');
    if (open === handle) open = null;
    draw();
  };
  const choose = (i: number): void => {
    const text = rows[i];
    if (text === undefined) return;
    input.blur();
    shut();
    value = text;
    draw();
    o.pick(text);
  };
  const handle: Open = {
    inPage: () => root.isConnected,
    step(by) {
      if (rows.length === 0) return;
      at = Math.max(0, Math.min(rows.length - 1, at + by));
      light();
    },
    enter: () => choose(at),
    cancel() {
      input.blur();
      shut();
    },
  };

  input.addEventListener('focus', () => {
    if (fixed) return;
    open = handle;
    input.setAttribute('aria-expanded', 'true');
    list.hidden = false;
    // Over the panel, not in it: out of the page with the field, let go; scrolled out of view or resized, given up.
    floating = floatList(input, list, root, (out) => (out ? shut() : handle.cancel()));
    fill('');
    floating.measure();
    input.select();
  });
  input.addEventListener('input', () => {
    fill(input.value);
    floating?.measure();
  });
  if (o.drops !== undefined) takeDrops(o.drops);

  /**
   * A drag of the Assets panel's files over it: one of its kind lit and, dropped, picked; several of its kind refused,
   * said in the field; anything else left to the window's guard, which says no. One of its kind whose key the list
   * does not offer -- in a pack not mounted (`reef:props/crate`), exported but not yet in the bundle -- refused on the
   * drop, said in the field a while. Nothing chosen, nothing focused.
   */
  function takeDrops(kind: string): void {
    /**
     * Saying why a drag is refused, over the field (`data-refused`, drawn by the stylesheet's `::after`): until it
     * leaves -- or, of a drop, for `SAID_FOR`. Never in the input: what it holds, or a filter typed in it, is untouched.
     */
    let quiet: ReturnType<typeof setTimeout> | undefined;
    const say = (text: string): void => {
      clearTimeout(quiet);
      root.dataset.refused = text;
      root.classList.add('ed-keypick-refused');
    };
    const hush = (): void => {
      clearTimeout(quiet);
      delete root.dataset.refused;
      root.classList.remove('ed-keypick-refused');
    };
    const unlight = (): void => {
      root.classList.remove('ed-keypick-drop');
      hush();
    };
    // Lit or dimmed while any drag in the page is under way (`drop-target.ts`): a tree row, a component, an asset of
    // another kind -- each says why it is no key of this kind. The drop itself is taken below, by the drag's types.
    if (!fixed) dropTarget(root, (record) => fits({ kind: 'key', keyKind: kind }, record, NO_FACTS));
    root.addEventListener('dragover', (event) => {
      const takes = fixed ? null : dragTakes(event.dataTransfer?.types ?? [], kind);
      if (takes === null) {
        unlight();
        const record = fixed ? null : dragging();
        const fit = record ? fits({ kind: 'key', keyKind: kind }, record, NO_FACTS) : null;
        if (fit && !fit.ok) {
          say(fit.why.charAt(0).toUpperCase() + fit.why.slice(1));
          // Let go here: said on the Scene tab's line too, as a ref field's refusal is.
          refusing(fit.why);
        }
        return;
      }
      if (takes === 'many') {
        if (event.dataTransfer) event.dataTransfer.dropEffect = 'none';
        root.classList.remove('ed-keypick-drop');
        say(`One ${kind.toLowerCase()} at a time`);
        refusing(`one ${kind.toLowerCase()} at a time`);
        return;
      }
      refusing(null);
      hush();
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
      root.classList.add('ed-keypick-drop');
    });
    root.addEventListener('dragleave', (event) => {
      const into = event.relatedTarget;
      if (typeof Node !== 'undefined' && into instanceof Node && root.contains(into)) return;
      unlight();
      // Into somewhere else: its refusal no longer this field's to say. Into nothing: let go here, said.
      if (into !== null && into !== undefined) refusing(null);
    });
    root.addEventListener('drop', (event) => {
      const takes = fixed ? null : dragTakes(event.dataTransfer?.types ?? [], kind);
      unlight();
      if (takes !== 'one') return;
      event.preventDefault();
      const key = droppedKey(event.dataTransfer);
      if (key === null) return;
      // Only a key loaded now, as the list offers: one in a pack not mounted, say, is no pick -- and the field says so,
      // having lit for it.
      if (!o.choices().includes(key)) {
        say(`${key} is not loaded`);
        quiet = setTimeout(hush, SAID_FOR);
        return;
      }
      if (open === handle) handle.cancel();
      value = key;
      draw();
      o.pick(key);
      o.dropped?.();
    });
    // Focused, it is a picker again: what it says taken off what it holds.
    input.addEventListener('focus', hush);
  }
  // A press on the list but not on a row (its scrollbar, its edge): the field keeps the focus, the list stays down.
  list.addEventListener('pointerdown', (event) => event.preventDefault());
  input.addEventListener('blur', () => shut());

  return {
    root,
    input,
    show(now, why) {
      if (open === handle) return;
      value = now;
      note = why;
      draw();
    },
    fix(on) {
      fixed = on;
      draw();
    },
  };
}

/** A column of a component, as the inspector writes it. */
type Columns = Record<string, { [i: number]: number }>;

/** What a line of a field says of it: shown only, its label, its help (D8's options, Docs/properties.md). */
export interface LineOptions {
  /** Shown, never changed: a runtime field of an opened prefab, or a `readonly` one. */
  fixed?: boolean;
  /** The name shown; the field's own by default. */
  label?: string;
  /** Its tooltip, before what kind of field it is. */
  help?: string;
}

/** A field's title on hover: its help, if it has any, then what it is. */
export const titled = (options: LineOptions, said: string): string => (options.help ? `${options.help}\n${said}` : said);

export interface KeyLineOptions extends LineOptions {
  /** A model key with a part: the second picker (`Render.model`, a `mesh()`). */
  parts?: boolean;
}

/**
 * A `key(kind)` field of `component` for every one of `es`: its name, then its
 * picker -- and, for a model with `parts`, the part's -- each pick one step.
 * `data-field` is the field's, for an override's bar.
 */
export function keyLine(blocks: KeyBlocks, sources: KeySources, component: Component, field: string, es: readonly Entity[], options: KeyLineOptions = {}): HTMLElement {
  const kind = keyKindOf(component, field) ?? '';
  const did = times(`Set ${component.name}.${field}`, es.length);
  const column = (): { [i: number]: number } => (blocks.world.rawStore(component) as Columns)[field]!;
  const texts = (): string[] => es.map((e) => keyText(kind, column()[e]!) ?? '');
  const write = (each: (text: string) => string): void => {
    const now = texts();
    es.forEach((e, i) => void (column()[e] = internKey(kind, each(now[i]!))));
    // Drawn and read again, then one step: as a number's edit.
    blocks.wrote();
    blocks.host.commit(did);
  };
  const line = el('div', 'ed-keyline');
  line.dataset.field = `${component.name}.${field}`;
  const name = el('span', 'ed-keyline-name', options.label ?? field);
  name.title = titled(options, `${component.name}.${field}: a ${kind} key`);
  const picks = el('div', 'ed-keyline-picks');
  line.append(name, picks);

  /** What the model picker shows: the whole key, or -- with parts -- the model's half of it. */
  const base = (text: string): string => (options.parts ? splitModel(text).model : text);
  const part = (text: string): string => splitModel(text).part ?? '';
  const shown = (values: readonly string[]): { value: string | null; note?: string } => {
    const same = agreed(values);
    return same === null ? { value: null, note: eachOwn(values.map((v) => v || 'none')) } : { value: same };
  };

  const first = texts();
  const whole = shown(first.map(base));
  let partPicker: Picker | null = null;
  const main = picker({
    title: `${component.name}.${field}`,
    ...whole,
    none: kind === 'Material' ? 'as authored' : 'none',
    choices: () => (kind === 'Clip' && sources.clips ? shared(es.map((e) => sources.clips!(e))) : sources.keysOf(kind)),
    thumb: kind === 'Model' ? sources.thumb : undefined,
    // Its kind's look, on each row and the field: a thumbnail, a swatch, a glyph, a font -- a clip none.
    ...(sources.look && kind !== 'Clip' ? { look: (key: string) => sources.look!(kind, key) } : {}),
    ...(sources.play && soundKind(kind) !== undefined ? { play: (key: string, ended: () => void): (() => void) | string => sources.play!(kind, key, ended) } : {}),
    fixed: options.fixed,
    // An asset file of its kind dropped on it: a clip is no file. A model dropped on a mesh asks for its part next:
    // the part's list dropped down (none, the whole model, is its first row).
    ...(kind !== '' && kind !== 'Clip'
      ? {
          drops: kind,
          dropped: () => {
            blocks.host.focus?.();
            if (!partPicker || options.fixed) return;
            partPicker.fix(model(texts()) === null);
            if (!partPicker.input.disabled) partPicker.input.focus();
          },
        }
      : {}),
    // The model it is already keeps its part; another drops it.
    pick: (text) => write((was) => (options.parts && text !== '' && base(was) === text ? was : text)),
  });
  picks.append(main.root);

  /** The model every one shares, or null: what the part's list is of. */
  const model = (values: readonly string[]): string | null => {
    const same = agreed(values.map(base));
    return same === null || same === '' ? null : same;
  };
  if (options.parts) {
    const parts = shown(first.map(part));
    partPicker = picker({
      title: `${component.name}.${field}'s part`,
      ...parts,
      none: 'none',
      choices: () => {
        const of = model(texts());
        return of === null ? [] : sources.partsOf(of);
      },
      fixed: options.fixed || model(first) === null,
      pick: (text) => {
        const of = model(texts());
        if (of !== null) write(() => (text === '' ? of : `${of}#${text}`));
      },
    });
    partPicker.root.classList.add('ed-keypick-part');
    picks.append(partPicker.root);
  }

  blocks.live(() => {
    const now = texts();
    const m = shown(now.map(base));
    main.show(m.value, m.note);
    if (partPicker) {
      const p = shown(now.map(part));
      partPicker.show(p.value, p.note);
      partPicker.fix(options.fixed === true || model(now) === null);
    }
  });
  return line;
}

/** The names in every one of `lists`, in the first's order: the clips several selected entities all have. */
export function shared(lists: readonly (readonly string[])[]): string[] {
  if (lists.length === 0) return [];
  return lists[0]!.filter((name, i, first) => first.indexOf(name) === i && lists.every((list) => list.includes(name)));
}

/** `0xRRGGBB` as a swatch's value: `#rrggbb`. */
export const hexOf = (value: number): string => `#${(value >>> 0 & 0xffffff).toString(16).padStart(6, '0')}`;
/** `0xRRGGBBAA` (`colorA`) as a swatch's value: its colour, `#rrggbb`, the alpha left out. */
export const hexOfA = (value: number): string => `#${((value >>> 8) & 0xffffff).toString(16).padStart(6, '0')}`;

/** A swatch's `#rrggbb` as the column's `0xRRGGBB`; null for what is no colour. */
export function colourOf(hex: string): number | null {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  return m ? parseInt(m[1]!, 16) : null;
}

/**
 * A `color()` field of `component` for every one of `es`: its name and a
 * swatch -- each change written to all, live; the swatch let go one step.
 * Several that differ: `—` beside it, their colours on hover. A `colorA()`
 * field (`0xRRGGBBAA`) has an alpha slider after the swatch: the swatch
 * changes the colour and keeps each one's alpha, the slider the alpha and
 * keeps each one's colour.
 */
export function colorLine(blocks: KeyBlocks, component: Component, field: string, es: readonly Entity[], options: LineOptions = {}): HTMLElement {
  const fixed = options.fixed === true;
  const alpha = (component.schema as Record<string, { alpha?: true } | undefined>)[field]?.alpha === true;
  const did = times(`Set ${component.name}.${field}`, es.length);
  const column = (): { [i: number]: number } => (blocks.world.rawStore(component) as Columns)[field]!;
  const line = el('div', 'ed-keyline');
  line.dataset.field = `${component.name}.${field}`;
  const name = el('span', 'ed-keyline-name', options.label ?? field);
  name.title = titled(options, `${component.name}.${field}: a colour, ${alpha ? '0xRRGGBBAA -- the swatch its colour, the slider its alpha' : '0xRRGGBB'}`);
  const swatch = el('input', 'ed-swatch');
  swatch.type = 'color';
  swatch.disabled = fixed;
  swatch.dataset.mcp = 'scene_set';
  const mixed = el('span', 'ed-dim ed-swatch-mixed', MIXED);
  const picks = el('div', 'ed-keyline-picks');
  picks.append(swatch, mixed);
  /** The alpha slider, 0 to 255, for a `colorA`. */
  const slider = alpha ? el('input', 'ed-slider ed-alpha') : null;
  if (slider) {
    slider.type = 'range';
    slider.min = '0';
    slider.max = '255';
    slider.step = '1';
    slider.disabled = fixed;
    slider.dataset.mcp = 'scene_set';
    picks.append(slider);
  }
  line.append(name, picks);
  /** The colour part, as the swatch shows it. */
  const hexes = (): string[] => es.map((e) => (alpha ? hexOfA(column()[e]!) : hexOf(column()[e]!)));
  /** Being changed: the person's, left alone by `live`. */
  let changing = false;
  const show = (): void => {
    const all = hexes();
    const same = agreed(all);
    swatch.value = same ?? all[0] ?? '#ffffff';
    if (slider) {
      const alphas = es.map((e) => column()[e]! & 0xff);
      const a = agreed(alphas);
      slider.value = String(a ?? alphas[0] ?? 255);
      slider.title = a === null ? `${component.name}.${field}'s alpha\n${eachOwn(alphas.map(String))}` : `${component.name}.${field}'s alpha: ${a} of 255`;
      mixed.hidden = same !== null && a !== null;
    } else mixed.hidden = same !== null;
    swatch.title = same === null ? `${component.name}.${field}\n${eachOwn(all)}` : `${component.name}.${field}: ${same}`;
  };
  show();
  swatch.addEventListener('input', () => {
    const value = colourOf(swatch.value);
    if (value === null) return;
    changing = true;
    for (const e of es) column()[e] = alpha ? ((value * 256 + (column()[e]! & 0xff)) >>> 0) : value;
    mixed.hidden = slider === null || agreed(es.map((e) => column()[e]! & 0xff)) !== null;
    blocks.wrote();
  });
  swatch.addEventListener('change', () => {
    changing = false;
    blocks.host.commit(did);
  });
  slider?.addEventListener('input', () => {
    changing = true;
    const a = Number(slider.value) & 0xff;
    for (const e of es) column()[e] = ((column()[e]! & 0xffffff00) + a) >>> 0;
    mixed.hidden = agreed(hexes()) !== null;
    slider.title = `${component.name}.${field}'s alpha: ${a} of 255`;
    blocks.wrote();
  });
  slider?.addEventListener('change', () => {
    changing = false;
    blocks.host.commit(did);
  });
  blocks.live(() => {
    if (!changing) show();
  });
  return line;
}

/**
 * A `bool()` field of `component` for every one of `es`: its name and a tick --
 * a click writes 1 or 0 to all, one step. Several that differ: indeterminate,
 * how many are yes on hover. `fixed`: shown, never changed.
 */
export function checkLine(blocks: KeyBlocks, component: Component, field: string, es: readonly Entity[], options: LineOptions = {}): HTMLElement {
  const fixed = options.fixed === true;
  const did = times(`Set ${component.name}.${field}`, es.length);
  const column = (): { [i: number]: number } => (blocks.world.rawStore(component) as Columns)[field]!;
  const line = el('div', 'ed-keyline ed-tickline');
  line.dataset.field = `${component.name}.${field}`;
  const name = el('span', 'ed-keyline-name', options.label ?? field);
  name.title = titled(options, `${component.name}.${field}: a yes or no`);
  const box = el('input', 'ed-check');
  box.type = 'checkbox';
  box.disabled = fixed;
  box.dataset.mcp = 'scene_set';
  box.setAttribute('aria-label', `${component.name}.${field}`);
  line.append(name, box);
  const show = (): void => {
    const yes = es.filter((e) => column()[e] !== 0).length;
    // Some yes, some no: neither, until clicked -- then every one is what it says.
    box.indeterminate = yes > 0 && yes < es.length;
    box.checked = yes === es.length && yes > 0;
    box.title = box.indeterminate ? `${component.name}.${field}: ${yes} of ${es.length} yes` : `${component.name}.${field}: ${box.checked ? 'yes' : 'no'}`;
  };
  show();
  box.addEventListener('change', () => {
    const value = box.checked ? 1 : 0;
    for (const e of es) column()[e] = value;
    blocks.wrote();
    blocks.host.commit(did);
  });
  blocks.live(show);
  return line;
}
