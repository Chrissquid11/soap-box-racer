/**
 * Prefab files that are none (Docs/prefabs.md §2) -- a `.json` under
 * `prefabs/`, a `.prefab` anywhere else -- as the dev server's tree has them:
 * what the Assets tool marks red, for `prefab_info`' `broken`
 * (`packages/editor/src/mcp/`), so an agent that wrote `foo.json`
 * hears why nothing compiled it. Each by its path, with the fix the Assets
 * tool offers (`strayPrefab`, `packages/pipeline/src/assets/paths.ts`).
 *
 * In `packages/editor/src/assets/`, the one place of `src/` that may import the pure
 * modules of `packages/pipeline/src/assets/` (`src/assets/imports.test.ts`).
 */
import { strayPrefab } from '@vibe/pipeline/paths';
import type { Api } from './api.ts';

/** Every stray prefab file in `api`'s tree, by path; none if the tree cannot be had. */
export async function prefabStrays(api: Api): Promise<{ key: string; problem: string }[]> {
  let answer: Awaited<ReturnType<Api['tree']>>;
  try {
    answer = await api.tree();
  } catch {
    return [];
  }
  if (!('tree' in answer)) return [];
  return answer.tree.flatMap((entry) => {
    const stray = strayPrefab(entry.path);
    if (!stray) return [];
    return [{ key: entry.path, problem: stray.renameTo ? `${stray.problem} (to ${stray.renameTo}; the Assets tool's Rename does it)` : stray.problem }];
  }).sort((a, b) => a.key.localeCompare(b.key));
}
