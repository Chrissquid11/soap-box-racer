/**
 * An export changed under `src/assets/`: fetched again, decoded as the game
 * decodes it, put in the store, and swapped into what is drawn -- during a
 * playtest too, and with no step made (Docs/assets.md §8, "Live reload into
 * the game"). `boot.ts` calls it for each `reload` message, one at a time.
 *
 * - **A model**: its bytes (`{ cache: 'reload' }`: the dev server's URL is
 *   unhashed, so the same address serves the new bytes) through `decodeModel`
 *   with `resolveBeside` as at boot; `replaceModel`; `swap` with
 *   `Assets.instance(key)` for each instance; the old GLTF disposed after the
 *   walk. With `beside` (an image under `models/` changed), only if the stored
 *   model names that image -- an image URI `resolveBeside` sends to it -- and
 *   then its images fetched afresh too.
 * - **A texture**, in place (`replaceTexture`): every material holding it
 *   draws the new image next frame.
 * - **An atlas**: its sheet in place, then `Atlas.reread` with its `.json`.
 * - **A sound**: `Audio.addSound`, which replaces by key. **Music**, when that
 *   track is not playing: `Audio.replaceTrack`.
 * - **Icons and fonts** are URLs: their next use reads the new file.
 *
 * Each answers a line the tool can show, its limits said: "3 entities given
 * the new crate". What a game's render system wrote into the old object's
 * material, an `AnimationMixer` made for it, a `texture.clone()` of its own,
 * an icon already drawn: a page reload away (§8, "Limits, said").
 */
import type * as THREE from 'three';
import type { ReloadMessage } from '@vibe/pipeline/assets-types';
import { Assets, Audio, pathUrl, sibling, url as registryUrl } from '@vibe/engine/assets';
import { atlases, decodeModel, decodeTexture, disposeModel, models, refill, replaceModel, replaceTexture, type Resolve, resolveBeside } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import { swap } from './swap.ts';

/** What a reload did, in a line the tool can show; `entities` for a model, how many were given the new one. */
export interface Reloaded {
  kind: string;
  key: string;
  line: string;
  entities?: number;
}

/** A key's or a path's last part, as a person names the thing: `props/crate` is the crate. */
const named = (key: string): string => key.slice(key.lastIndexOf('/') + 1);

/** The bytes at `url`, never the browser's cached copy. */
async function fresh(url: string): Promise<Response> {
  const res = await fetch(url, { cache: 'reload' });
  if (!res.ok) throw new Error(`${url}: the dev server answered ${res.status}`);
  return res;
}

/** The registry's URL for a model's key, or undefined: where its own images are looked for from. */
function modelUrl(key: string): string | undefined {
  try {
    return registryUrl('models', key);
  } catch {
    return undefined;
  }
}

/**
 * How a model's image URIs resolve, as at boot: each found by name beside it or
 * in `textures/`. The dev server answers those with `Cache-Control: no-cache`
 * and an `ETag` of size and mtime, so the loader gets the image as it is now.
 */
function besideOf(key: string, href: string | undefined): Resolve {
  return (uri) => resolveBeside(key, uri, pathUrl, href);
}

/** Does the stored model name `image` (its path under `models/`): an image URI of its that resolves to that file? */
function names(key: string, image: string): boolean {
  const gltf = models.get(key);
  const wanted = pathUrl('models', image);
  if (!gltf || wanted === undefined) return false;
  const href = modelUrl(key);
  const images = (gltf.parser.json as { images?: Array<{ uri?: string }> }).images ?? [];
  return images.some((i) => i.uri !== undefined && resolveBeside(key, i.uri, pathUrl, href) === wanted);
}

async function reloadModel(game: Game, message: ReloadMessage, redraw: () => void): Promise<Reloaded | null> {
  const { key } = message;
  if (message.beside !== undefined && !names(key, message.beside)) return null;
  const bytes = new Uint8Array(await (await fresh(message.url)).arrayBuffer());
  const gltf = await decodeModel({ bytes, name: `${key}.glb` }, besideOf(key, modelUrl(key)));
  const old = replaceModel(key, gltf);
  const entities = swap(game.world, key, (part) => Assets.instance(key as AssetKeys.Model, part), () => {
    if (old) disposeModel(old);
  });
  redraw();
  const what = message.beside !== undefined ? `the ${named(key)} with its new ${named(message.beside)}` : `the new ${named(key)}`;
  return { kind: 'models', key, entities, line: `${entities} ${entities === 1 ? 'entity' : 'entities'} given ${what}` };
}

/**
 * The texture at `url`, fetched afresh and finished for its use: a KTX2 from its
 * bytes, by a name that says so (a blob URL ends in a UUID); an image the
 * browser decodes through a blob URL, as at boot (the same `flipY`).
 */
async function textureOf(key: string, url: string, use: 'texture' | 'atlas'): Promise<THREE.Texture> {
  const bytes = new Uint8Array(await (await fresh(url)).arrayBuffer());
  if (/\.ktx2$/i.test(url)) return decodeTexture({ bytes, name: `${key}.ktx2` }, use);
  const blobUrl = URL.createObjectURL(new Blob([bytes as BlobPart]));
  try {
    return await decodeTexture({ url: blobUrl }, use);
  } finally {
    URL.revokeObjectURL(blobUrl);
  }
}

/** `w×h`. */
const size = ({ width, height }: { width: number; height: number }): string => `${width}×${height}`;

/** One `reload` message carried out: what it did, or null for nothing to do (a model that does not name the image). */
export async function reload(game: Game, message: ReloadMessage, redraw: () => void): Promise<Reloaded | null> {
  const { kind, key } = message;
  switch (kind) {
    case 'models':
      return reloadModel(game, message, redraw);
    case 'textures': {
      const texture = await textureOf(key, message.url, 'texture');
      const { resized, was } = replaceTexture(key, texture);
      redraw();
      return { kind, key, line: `the new ${named(key)} texture, in place${resized ? `: ${size(was)} → ${size(texture)} (a clone the game made keeps the old one)` : ''}` };
    }
    case 'atlases': {
      const atlas = atlases.get(key);
      if (!atlas) return null;
      // The sheet and its frames both, whichever of the two changed.
      const [sheet, json] = await Promise.all([textureOf(key, registryUrl('atlases', key), 'atlas'), fresh(sibling('atlases', key, '.json')).then((r) => r.json())]);
      refill(atlas.texture, sheet);
      const gone = atlas.reread(json);
      redraw();
      return { kind, key, line: `the new ${named(key)} sheet, its sprites cut again${gone.length > 0 ? `; ${gone.join(', ')} gone from it, ${gone.length === 1 ? 'its crop' : 'their crops'} kept` : ''} (a style already painted keeps the old pixels)` };
    }
    case 'sfx':
    case 'uiSfx': {
      await Audio.addSound(key, await (await fresh(message.url)).arrayBuffer());
      return { kind, key, line: `the new ${named(key)} sound, from its next play (a loop playing keeps the old one until started again)` };
    }
    case 'music': {
      const res = await fresh(message.url);
      const bytes = new Uint8Array(await res.arrayBuffer());
      const replaced = Audio.replaceTrack(key, bytes, res.headers.get('content-type') ?? 'audio/ogg');
      return { kind, key, line: replaced ? `the new ${named(key)} track, from its next start` : `${named(key)} is playing: the new track is heard after a page reload` };
    }
    case 'icons':
    case 'fonts':
      return { kind, key, line: `the new ${named(key)} ${kind === 'icons' ? 'icon' : 'font'}, at its next use (one already drawn stays until the page reloads)` };
    default:
      return null;
  }
}
