/**
 * The browser's conversion (Docs/assets.md §8): a `browser-to-glb` step --
 * an `.fbx`, `.obj`, `.dae` or `.stl` that only three's loaders read -- done
 * by a game tab for the dev server.
 *
 * On `convert: { job, source, parts }` every tab whose `online` is `'write'`
 * claims the job (`POST convert/claim`); the first gets it, the rest a `409`,
 * and a loser says nothing (a designer with two tabs open would otherwise see
 * an error every export). The winner loads the source with its format's
 * `PREVIEWERS` loader -- its parts fetched through `GET file`, found by name
 * by the manager's URL modifier -- exports it with `GLTFExporter` (a GLB embeds
 * its images by itself; `trs` comes with animations), and sends it with `PUT
 * intermediate`, with `three.REVISION` for the record's `built.tools`.
 *
 * Any tab will do, editor open or not: `watchAssets` listens from boot, and once
 * subscribed claims any job already waiting (`GET jobs`), so a tab that
 * connects after its `convert` went out still gets it. The jobs it holds --
 * won, and not yet sent -- it says (`holds`, `onHolding`): the server keeps
 * such a job `parked` until the file arrives, and the Assets tool says
 * "converting in this tab" for it, not "waiting for a game tab".
 */
import * as THREE from 'three';
import type { ConvertMessage } from '@vibe/pipeline/assets-types';
import { baseName, dirName, extOf, joinPath, resolveRel } from '@vibe/pipeline/paths';
import { fileName } from '@vibe/engine';
import { API_BASE, type Api } from './api.ts';
import { PREVIEWERS, type Loaded, type Previewer } from './preview/previewers.ts';

export interface Converter {
  /** A `convert` message: claimed if this tab may write, converted if it won. */
  heard(message: ConvertMessage): Promise<void>;
  /** Every job already waiting for a tab (`GET jobs`), claimed as if its message had come now. */
  claimWaiting(): Promise<void>;
  /** Is this job's conversion this tab's, claimed and not yet sent? The tool says "converting in this tab" for it. */
  holds(job: string): boolean;
  /** Told as this tab takes a conversion and as it is done with one. Returns the undo. */
  onHolding(listener: () => void): () => void;
}

/** A URI's path as a file's: its query and fragment off, its escapes decoded (a malformed one kept as written). */
function decodedPath(uri: string): string {
  const path = uri.replace(/[?#].*$/, '');
  try {
    return decodeURIComponent(path);
  } catch {
    return path;
  }
}

/**
 * Where each file a loader asks for is fetched from: the source by its own
 * URL; anything else by its name among the job's parts, else by its path from
 * the source's folder -- through `GET file` either way. A `data:` or `blob:`
 * URL carries its own bytes, and one the path rule refuses (out of the
 * folders `GET file` serves) is left as it is, to fail on its own terms.
 * Pure: `convert.test.ts` holds each case.
 */
export function partUrls(api: Pick<Api, 'fileUrl'>, source: string, parts: readonly string[]): (url: string) => string {
  const own = api.fileUrl(source);
  return (url) => {
    if (url === own || url.startsWith(`${API_BASE}file?`) || /^(data:|blob:)/i.test(url)) return url;
    const name = fileName(url);
    const part = parts.find((p) => baseName(p) === name);
    if (part !== undefined) return api.fileUrl(part);
    // A relative URI resolved by the loader against the API's folder: the rest is the path from the source's.
    const rel = url.startsWith(API_BASE) ? decodedPath(url.slice(API_BASE.length)) : name;
    const path = resolveRel(dirName(source), rel) ?? joinPath(dirName(source), name);
    try {
      return api.fileUrl(path);
    } catch {
      return url;
    }
  };
}

/**
 * A manager watched: what it has in flight, counted as each item starts and
 * ends (an error ends one too); the function resolves once none is, or after
 * `ms` -- a texture that hangs does not hold the conversion for ever. 45 s: a
 * slow link's 6 MB texture still comes in, and the export is sent within the
 * 60 s the server gives a tab that claimed it (§A.4, Jobs).
 */
export function whenIdle(manager: THREE.LoadingManager, ms = 45000): () => Promise<void> {
  let busy = 0;
  let waiting: Array<() => void> = [];
  const start = manager.itemStart.bind(manager);
  const end = manager.itemEnd.bind(manager);
  manager.itemStart = (url: string): void => {
    busy++;
    start(url);
  };
  manager.itemEnd = (url: string): void => {
    end(url);
    busy = Math.max(0, busy - 1);
    if (busy > 0) return;
    const told = waiting;
    waiting = [];
    for (const fn of told) fn();
  };
  return () => (busy === 0 ? Promise.resolve() : new Promise<void>((resolve) => {
    waiting.push(resolve);
    setTimeout(resolve, ms);
  }));
}

/**
 * A texture whose image never loaded -- a name an `.fbx` holds that is in no
 * folder, a search part not dropped with it (§A.3) -- taken off its material,
 * said once: `GLTFExporter` throws on one ("No valid image data"), and the
 * model converts without it, as the game would draw it. Its parts are the
 * index's to say.
 */
export function dropUnloaded(scene: THREE.Object3D, source: string, without = 'converts'): string[] {
  const dropped = new Set<string>();
  scene.traverse((node) => {
    const material = (node as THREE.Mesh).material;
    for (const m of Array.isArray(material) ? material : material ? [material] : []) {
      for (const [slot, value] of Object.entries(m)) {
        if (!(value instanceof THREE.Texture)) continue;
        const image = value.image as { width?: number } | undefined;
        if (image && (image.width ?? 0) > 0) continue;
        (m as unknown as Record<string, unknown>)[slot] = null;
        m.needsUpdate = true;
        dropped.add(value.name || slot);
      }
    }
  });
  if (dropped.size > 0) console.warn(`[assets] ${source}: ${[...dropped].join(', ')} did not load, and ${without} without ${dropped.size === 1 ? 'it' : 'them'}`);
  return [...dropped];
}

/**
 * `source` read by its format's previewer with all it asks for in: its parts
 * through `GET file` (`partUrls`), the textures that load after the model --
 * an OBJ's MTL images, an FBX's -- waited for (`whenIdle`), and one that never
 * does taken off (`dropUnloaded`, saying it `without` it). The browser's
 * conversion and the preview's decode (`scratch.ts`) both read a source so:
 * neither exports, draws or posts a thumbnail of a model before its textures
 * are on it.
 */
export async function loadWhole(previewer: Previewer, api: Pick<Api, 'fileUrl'>, source: string, parts: readonly string[], without = 'converts', ms?: number): Promise<Loaded> {
  const manager = new THREE.LoadingManager();
  manager.setURLModifier(partUrls(api, source, parts));
  const idle = whenIdle(manager, ms);
  const loaded = await previewer.load(api.fileUrl(source), manager);
  // A model's textures load after the model itself: waited for, as the exporter reads their pixels and a capture draws them.
  await idle();
  dropUnloaded(loaded.scene, source, without);
  return loaded;
}

/** `source` read by its format's loader and written as a binary glTF. */
export async function toGlb(api: Api, source: string, parts: readonly string[]): Promise<ArrayBuffer> {
  const make = PREVIEWERS[extOf(source)];
  if (!make) throw new Error(`no loader for .${extOf(source)} here`);
  const loaded = await loadWhole(await make(), api, source, parts);
  const { GLTFExporter } = await import('three/addons/exporters/GLTFExporter.js');
  const glb = await new GLTFExporter().parseAsync(loaded.scene, { binary: true, onlyVisible: false, animations: loaded.animations ?? [] });
  if (!(glb instanceof ArrayBuffer)) throw new Error('GLTFExporter gave JSON where a .glb was asked for');
  return glb;
}

export function createConverter(api: Api): Converter {
  /** The jobs this tab has claimed or is claiming: one attempt each, however often it is asked. */
  const mine = new Set<string>();
  /** Those it won and is converting, until the file is sent or it gave up. */
  const holding = new Set<string>();
  const listeners = new Set<() => void>();
  const told = (): void => {
    for (const fn of listeners) fn();
  };

  async function heard({ job, source, parts }: ConvertMessage): Promise<void> {
    if (mine.has(job)) return;
    mine.add(job);
    try {
      if ((await api.online()) !== 'write') return;
      // Lost to another tab, or no longer waiting: nothing to say.
      if (!(await api.claim(job))) return;
      holding.add(job);
      told();
      const started = performance.now();
      const glb = await toGlb(api, source, parts);
      await api.putIntermediate(job, glb, THREE.REVISION);
      console.info(`[assets] ${source} converted in this tab: ${Math.round(glb.byteLength / 1024)} kB, ${Math.round(performance.now() - started)} ms`);
    } catch (err) {
      // Its job ended meanwhile -- its source deleted, an import undone: nothing to say but that.
      if ((err as { status?: unknown }).status === 409) console.info(`[assets] ${source}: its conversion was no longer wanted (${(err as Error).message})`);
      else console.error(`[assets] ${source} could not be converted in this tab:`, err);
    } finally {
      if (holding.delete(job)) told();
    }
  }

  return {
    holds: (job) => holding.has(job),
    onHolding(listener) {
      listeners.add(listener);
      return () => void listeners.delete(listener);
    },
    heard,
    async claimWaiting() {
      try {
        if ((await api.online()) !== 'write') return;
        const parked = (await api.jobs()).filter((j) => j.state === 'parked');
        if (parked.length === 0) return;
        // `GET jobs` has no parts: the index has them.
        const answer = await api.tree();
        const entries = 'tree' in answer ? answer.tree : [];
        for (const { id, source } of parked) {
          void heard({ job: id, source, parts: entries.find((e) => e.path === source)?.parts ?? [] });
        }
      } catch (err) {
        console.warn('[assets] the jobs waiting for a tab could not be read', err);
      }
    },
  };
}
