/**
 * The push channel (Docs/assets.md §5, §8): the client index kept current, and
 * what the server says told to whoever listens.
 *
 * - **By `seq`** (`model.ts`): each response's diff applied the moment it
 *   comes (`take`, which `api.ts` calls), each `changed` message's too; one
 *   at or before the index's `seq` is a no-op, one past it a gap, filled with
 *   `GET tree?since=` -- one at a time, once more if another gap came
 *   meanwhile. `trash` comes whole and replaces the copy. Messages that come
 *   while the first tree is on its way are kept and applied after it, by the
 *   same rule; those before `start()` are not kept at all -- the tree brings
 *   them -- so a session that never opens the tab holds nothing.
 * - **Told**: `changed` (the index moved), `job`, `tools`, `held`, `tool` (a
 *   project route's push, `vibe({ routes })`: its name and its message); the
 *   studio's pushes, each by its kind (`studio:log`, `studio:task`,
 *   `studio:problems`, `studio:dist`, `studio:preview`, `studio:download`: the
 *   Studio tab's cards, the Tools page's Download row); and `offline` on
 *   Vite's `vite:ws:disconnect` -- after which, in 8.3.2, Vite's client polls
 *   the server and reloads the page when it is back.
 * - **`until(seq)`**, the step queue's confirmation (`steps.ts`): resolves once
 *   the index has reached `seq`. While the server is down it waits -- the
 *   tool `busy()` -- until the page reloads, which Vite does when the server
 *   is back: nothing is lost by not giving up sooner.
 *
 * `reload` and `convert` are not the tool's: `boot.ts` hears them from boot.
 * The channel is handed in (`import.meta.hot` by default), so a node test
 * drives it by hand (`live.test.ts`).
 */
import type { Diff, JobMessage, PushMessage, ToolLook, TreeAnswer, WriteAnswer } from '@vibe/pipeline/assets-types';
import { PUSH_EVENT } from '@vibe/pipeline/kinds';
import type { StudioMessage } from '@vibe/pipeline/studio-types';
import type { Api } from './api.ts';
import { createIndex, type ClientIndex } from './model.ts';

/** The push channel's event (`PUSH_EVENT`). */
const EVENT = PUSH_EVENT;

/** What `import.meta.hot` is to this module: a way to hear an event, its payload what the sender sent, and to stop. */
export interface HotChannel {
  on(event: string, listener: (data: unknown) => void): void;
  off?(event: string, listener: (data: unknown) => void): void;
}

/** A studio push's kind: `studio:log`, `studio:task`, … */
export type StudioKind = StudioMessage['kind'];

/** Each studio push, told by its kind with its message. */
export type StudioEvents = { [K in StudioKind]: (message: Extract<StudioMessage, { kind: K }>) => void };

export interface LiveEvents extends StudioEvents {
  /** The index moved: by a response, a message or a gap filled. */
  changed: (diff: Diff | TreeAnswer) => void;
  job: (job: JobMessage) => void;
  tools: (tools: ToolLook[]) => void;
  /** The Gladius scripts whose export waits for a Claude turn's end, the whole list (Docs/modeler.md M21). */
  held: (held: string[]) => void;
  /** A project route's message (`vibe({ routes })`, its handler's `ctx.push`): the route's name, and what it sent. */
  tool: (name: string, message: unknown) => void;
  /** The dev server stopped answering. */
  offline: () => void;
}

export interface Live {
  readonly index: ClientIndex;
  /** The dev server stopped answering (`vite:ws:disconnect`). */
  readonly offline: boolean;
  /** The first tree (or bundle view's index), then the messages that came meanwhile. Once; later calls answer the same. */
  start(): Promise<void>;
  /** A response's diff, at once: `api.ts` hands every mutating call's answer here. */
  take(answer: WriteAnswer): void;
  /** Resolves once the index has reached `seq`. */
  until(seq: number): Promise<void>;
  /** `GET tree?since=` the index's `seq`, applied: after a gap, or a failed step. */
  refresh(): Promise<void>;
  on<E extends keyof LiveEvents>(event: E, listener: LiveEvents[E]): () => void;
  /** The channel let go of, every listener dropped: the tool disposed. */
  dispose(): void;
}

export function createLive(api: Api, hot: HotChannel | undefined = import.meta.hot): Live {
  const index = createIndex();
  let offline = false;
  let started: Promise<void> | null = null;
  /** `changed` messages heard while the first tree is on its way: none kept before `start()`, which the tree covers. */
  let early: Diff[] | null = null;
  let refreshing: Promise<void> | null = null;
  let again = false;
  const waiting: Array<{ seq: number; resolve: () => void }> = [];
  /** Each event's listeners, its set made as the first comes. */
  const listeners = new Map<keyof LiveEvents, Set<(...args: never[]) => void>>();
  const of = <E extends keyof LiveEvents>(event: E): Set<LiveEvents[E]> => {
    let set = listeners.get(event);
    if (!set) listeners.set(event, (set = new Set()));
    return set as unknown as Set<LiveEvents[E]>;
  };

  /** Every wait the index has now reached, resolved. */
  const settle = (): void => {
    for (let i = waiting.length - 1; i >= 0; i--) {
      if (index.seq < waiting[i]!.seq) continue;
      waiting[i]!.resolve();
      waiting.splice(i, 1);
    }
  };

  /** A diff or a tree into the index, by `seq`: told if it moved it, a gap filled. */
  function apply(diff: Diff | TreeAnswer): void {
    const applied = index.apply(diff);
    if (applied === 'applied') {
      settle();
      for (const fn of of('changed')) fn(diff);
    } else if (applied === 'gap' && index.loaded) {
      // The server gone: `offline` says so.
      void live.refresh().catch(() => {});
    }
  }

  const heard = (sent: unknown): void => {
    const data = sent as PushMessage;
    switch (data.type) {
      case 'changed':
        // Before `start()`: the first tree will have it.
        if (started === null) return;
        if (early) early.push(data.diff);
        else apply(data.diff);
        return;
      case 'job':
        for (const fn of of('job')) fn(data.job);
        return;
      case 'tools':
        for (const fn of of('tools')) fn(data.tools);
        return;
      case 'held':
        for (const fn of of('held')) fn(data.held);
        return;
      case 'tool':
        for (const fn of of('tool')) fn(data.tool, data.message);
        return;
      case 'studio': {
        const { type: _type, ...message } = data;
        for (const fn of listeners.get(message.kind) ?? []) (fn as (m: StudioMessage) => void)(message);
        return;
      }
      default:
        return;
    }
  };
  const gone = (): void => {
    offline = true;
    for (const fn of of('offline')) fn();
  };
  if (hot) {
    hot.on(EVENT, heard);
    hot.on('vite:ws:disconnect', gone);
  }

  const live: Live = {
    index,
    get offline() {
      return offline;
    },
    start() {
      // Kept from now on until the first tree is in: what comes while it is on its way.
      early ??= started === null ? [] : null;
      return (started ??= (async () => {
        api.connect({
          get seq() {
            return index.seq;
          },
          take: (answer) => live.take(answer),
        });
        apply(await api.tree());
        const heard = early ?? [];
        early = null;
        for (const diff of heard) apply(diff);
      })());
    },
    take(answer) {
      if (!index.loaded) return;
      apply(answer.diff);
    },
    until(seq) {
      if (index.seq >= seq) return Promise.resolve();
      const reached = new Promise<void>((resolve) => waiting.push({ seq, resolve }));
      // Not brought by the answer it came with: the server is further on than the index knows.
      // The server gone: `offline` says so, and this waits on (below).
      if (index.loaded) void live.refresh().catch(() => {});
      return reached;
    },
    refresh() {
      if (refreshing) {
        again = true;
        return refreshing;
      }
      refreshing = (async () => {
        try {
          do {
            again = false;
            apply(await api.tree(index.loaded ? index.seq : undefined));
          } while (again);
        } finally {
          refreshing = null;
        }
      })();
      return refreshing;
    },
    on(event, listener) {
      const set = of(event);
      set.add(listener);
      return () => void set.delete(listener);
    },
    dispose() {
      hot?.off?.(EVENT, heard);
      hot?.off?.('vite:ws:disconnect', gone);
      for (const set of listeners.values()) set.clear();
      early = null;
    },
  };
  return live;
}
