/**
 * A model re-exported, swapped into every entity drawn with it, where it stands
 * (Docs/assets.md §8, "Live reload into the game").
 *
 * Every model the store holds has its scene tagged `userData.assetKey = key`,
 * which each `Assets.instance` carries. Every live or parked entity with a `View` has its
 * View's subtree searched for nodes tagged with the key -- the View itself
 * included, and nothing inside a tagged node -- and each found is replaced by
 * `fresh()`:
 *
 * - **the View itself** → `swapView` (`view.ts`): in the scene and in the
 *   store in its place, drawn where the old one was;
 * - **a node inside it** -- a game that attached a `Group` with the model
 *   inside as a pivot -- → the new one added to its parent with its place
 *   (`position`, `quaternion`, `scale`, or its `matrix` where the game writes
 *   that), its `layers` and `visible`, and the old one taken out.
 *
 * `after` runs once the walk is over, however it ended: the old model's
 * geometry, materials and textures disposed there (`reload.ts`) -- not before,
 * since instances share them by reference. The walk reaches a pooled prefab's
 * parked instances as well as the live ones (`world.parked`); an object it did
 * not reach (the editor's placement preview) keeps drawing the old model.
 *
 * Free of the registry and of three's renderer: a node test installs the view
 * on a stand-in scene and swaps (`swap.test.ts`).
 */
import type * as THREE from 'three';
import type { Entity, World } from '@vibe/engine';
import { swapView, View } from '@vibe/engine';

/** Every node under `node` (itself included) tagged with `key`, not looking inside one found. */
function tagged(node: THREE.Object3D, key: string, out: THREE.Object3D[]): void {
  if (node.userData.assetKey === key) {
    out.push(node);
    return;
  }
  for (const child of node.children) tagged(child, key, out);
}

/** `next` where `old` was, under the same parent, and `old` taken out. */
function replaceNode(old: THREE.Object3D, next: THREE.Object3D): void {
  const parent = old.parent;
  if (!parent) return;
  next.position.copy(old.position);
  next.quaternion.copy(old.quaternion);
  next.scale.copy(old.scale);
  next.matrixAutoUpdate = old.matrixAutoUpdate;
  if (!old.matrixAutoUpdate) next.matrix.copy(old.matrix);
  next.layers.mask = old.layers.mask;
  next.visible = old.visible;
  parent.add(next);
  parent.remove(old);
}

/**
 * Every live or parked entity drawn with `key` given `fresh()` in place of the old: how
 * many entities were -- `fresh(part)` the part a view was made of, null for the whole. `after` runs when the walk is done.
 */
export function swap(world: World, key: string, fresh: (part: string | null) => THREE.Object3D, after?: () => void): number {
  try {
    const views = world.store(View);
    // Found first, replaced after: the walk does not see what it put in.
    const found: Array<{ e: Entity; node: THREE.Object3D }> = [];
    for (let i = 1; i < world.extent; i++) {
      const e = i as Entity;
      // A pooled instance parked too: its view is swapped hidden, through `swapView`, which the `render`
      // system (`installRender`) hears and keeps as its own, so the reset keeps the new one.
      if (!world.alive(e) && !world.parked(e)) continue;
      const view = views.value[e];
      if (!view) continue;
      const nodes: THREE.Object3D[] = [];
      tagged(view, key, nodes);
      for (const node of nodes) found.push({ e, node });
    }
    const entities = new Set<Entity>();
    for (const { e, node } of found) {
      // A part of the model (`Render.model` `key#part`, `Assets.instance(key, part)`) comes back as that part.
      const part = typeof node.userData.assetPart === 'string' ? node.userData.assetPart : null;
      if (node === views.value[e]) swapView(world, e, fresh(part));
      else replaceNode(node, fresh(part));
      entities.add(e);
    }
    return entities.size;
  } finally {
    after?.();
  }
}
