/**
 * Scene files as the editor names and writes them (Docs/ecs.md §19): a scene
 * is `src/assets/scenes/<key>.scene`, a world save inside (the engine's `scenes.ts`
 * reads them), written through the dev server's `PUT prefab` as a prefab file
 * is.
 *
 * - **A scene's name is its file's, as typed; its key the name lowercased**
 *   (`caseKey`, CLAUDE.md): "My Camp" is `My Camp.scene`, the key `my camp`.
 *   A name is checked, never made into another (`sceneNameFrom`): each part
 *   between `/` a name `validName` takes (no `/ \ : * ? " < > | # %`, no space
 *   or dot at either end, not another file's but for case), and none starting
 *   with `_`, which the build skips -- no scene at all. Only a name that came
 *   from elsewhere (an old browser scene, an imported file's) is made one
 *   (`madeSceneName`, `suggestName`'s).
 * - **A key leads to its file** (`scenePathOf`): the path on disk of the file
 *   with that key (the engine's `scenes.ts`' `sceneName`, handed in at boot,
 *   `useSceneNames`), else the key as written -- a new file's own name.
 * - **A key taken gets `-2`, `-3`…** (`freeKey`), as a duplicate does in the
 *   Assets tool.
 * - **The text is one line** of JSON, a newline after it, as a level exported
 *   from the Scenes page was: a save is mostly long arrays. The start scene's
 *   file says `"start": true` first (`sceneText`).
 * - **New scene** (the Assets panel's menus in `scenes/`): `new-scene.scene`
 *   (`-2`… when taken), a new scene's save (`newSceneSave`): empty but for
 *   its `Main Camera`, as Config ▸ Scenes' New makes it.
 * - **The one-time move out of the browser** (`legacyScenes`,
 *   `migrationPlan`): the scenes the editor kept in `localStorage`
 *   (`vibebase.scenes`) before scenes were files, each given a key by its
 *   name, a key taken -- by a file or by one before it -- with `-2`.
 * - **The open scene follows its file** (`sceneKeyAfter`): renamed or moved
 *   -- in the Assets panel, on the Scenes page, or by an undo of either -- its
 *   key is the file's new one; deleted, it has none.
 *
 * Pure: node tests it (`scene-files.test.ts`).
 */
import { KINDS, ROOTS, SCENE_SUFFIX } from '@vibe/pipeline/kinds';
import { suggestName, validName } from '@vibe/pipeline/paths';
import { caseKey, Loop, World } from '@vibe/engine';
import type { WorldSave } from '@vibe/engine';
import { newSceneWorld } from '../camera-entity.ts';

/** Where the scene files are: `src/assets/scenes`. */
export const SCENES_DIR = `${ROOTS.boot.dir}/${KINDS.scenes.dir}`;

/** Each key's name on disk (its path under `scenes/`, no `.scene`): the engine's `scenes.ts`' `sceneName`, once `useSceneNames` hands it in; none in a node test. */
let namesOf: (key: string) => string | undefined = () => undefined;

/** Where a key's file is: the engine's `scenes.ts`' `sceneName`, handed in by the editor's boot. */
export function useSceneNames(names: (key: string) => string | undefined): void {
  namesOf = names;
}

/** A scene's file, by key (in any case): the file with that key as it is on disk, else the key as written -- a new file's name. */
export const scenePathOf = (key: string): string => sceneFileOf(namesOf(key) ?? key);

/** A scene's file by its name exactly as given: what a new file, or a rename's new name, is written as. */
export const sceneFileOf = (name: string): string => `${SCENES_DIR}/${name}${SCENE_SUFFIX}`;

/** A scene file's key -- its path under `scenes/` without `.scene`, lowercased -- or undefined for a path that is none (not a `.scene` under `scenes/`). */
export function sceneKeyOf(path: string): string | undefined {
  if (!path.startsWith(`${SCENES_DIR}/`) || !path.endsWith(SCENE_SUFFIX)) return undefined;
  const key = path.slice(SCENES_DIR.length + 1, -SCENE_SUFFIX.length);
  return key === '' || key.split('/').some((part) => part.startsWith('_')) ? undefined : caseKey(key);
}

/** What the dev server answered moved and deleted: each file moved, from and to, and each path gone -- a file, or a folder with all it held. */
export interface FilesWent {
  moved: readonly (readonly [from: string, to: string])[];
  removed: readonly string[];
}

/** `path` is `at`, or inside the folder `at`, in any case: a key's file, however it is spelled. */
const under = (path: string, at: string): boolean => {
  const [p, a] = [caseKey(path), caseKey(at)];
  return p === a || p.startsWith(`${a}/`);
};

/**
 * Scene `key` after files moved or went (`FilesWent`): the key its file has
 * now -- renamed, or moved with its folder -- the same key if none of them was
 * its file, or null if its file is no scene any more: deleted, or moved out of
 * `scenes/` (or to a `_` name the build skips). A move answers every file,
 * but a folder's pair is followed too.
 */
export function sceneKeyAfter(key: string, went: FilesWent): string | null {
  const path = scenePathOf(key);
  for (const [from, to] of went.moved) {
    if (!under(path, from)) continue;
    return sceneKeyOf(to + path.slice(from.length)) ?? null;
  }
  return went.removed.some((gone) => under(path, gone)) ? null : key;
}

/**
 * A name as typed, checked as a scene's: its path under `scenes/`, case and
 * spaces kept (`My Camp`, `Forest/Old Camp`), spaces around each `/` and at
 * the ends let go of. Each folder a name `validName` takes as a folder's, the
 * last one as a file's with `.scene`, none starting with `_` (the build skips
 * it: no scene). The name, or why not -- never another name made of it.
 */
export function sceneNameFrom(typed: string): { name: string } | { refused: string } {
  const parts = typed.split('/').map((part) => part.trim());
  if (parts.every((part) => part === '')) return { refused: 'a scene needs a name' };
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i]!;
    const last = i === parts.length - 1;
    if (part === '') return { refused: `‘${typed.trim()}’ has an empty folder name` };
    if (part.startsWith('_')) return { refused: `‘${part}’ starts with _, which keeps a file out of the build: no scene` };
    const check = validName(last ? `${part}${SCENE_SUFFIX}` : part, { folder: !last });
    if ('refused' in check) return { refused: `‘${part}’: ${check.refused}` };
  }
  return { name: parts.join('/') };
}

/** A name from elsewhere -- an old browser scene's, an imported file's -- made a scene's: each part `suggestName`'s, a leading `_` let go of. Null when nothing is left of it. */
export function madeSceneName(raw: string): string | null {
  const parts = raw
    .split('/')
    .map((part) => part.trim().replace(/^_+/, ''))
    .filter((part) => part !== '')
    .map((part, i, all) => (i === all.length - 1 ? suggestName(`${part}${SCENE_SUFFIX}`).slice(0, -SCENE_SUFFIX.length) : suggestName(part, true)));
  return parts.length === 0 ? null : parts.join('/');
}

/** `stem`, or `stem-2`, `stem-3`… -- the first nobody has (`taken` is asked in the case given; `sceneIfPresent` takes any). */
export function freeKey(stem: string, taken: (key: string) => boolean): string {
  if (!taken(stem)) return stem;
  let n = 2;
  while (taken(`${stem}-${n}`)) n++;
  return `${stem}-${n}`;
}

/**
 * A new scene's save: a world empty but for its main camera (`newSceneWorld`,
 * what Config ▸ Scenes' New makes), as `world.save()` gives it -- what the
 * Assets panel's New scene and `asset_new`'s scene write. Made in a scratch
 * world, thrown away after -- one holding every component registered at
 * module level, as the game's does -- so the file is always what
 * `newSceneWorld` makes, never a hand-written literal that drifts from it. No streams --
 * content: a load starts each from the run's seed -- and no instances:
 * `scene(key)`, `Game.load` and the Scenes page take it.
 */
export function newSceneSave(): WorldSave {
  const world = new World({ loop: new Loop() });
  newSceneWorld(world);
  const { instances: _none, ...save } = world.save();
  return { ...save, loop: { tick: 0, streams: {} } };
}

/** The name New scene starts from, `new-scene-2`… when taken (`freeKey`). */
export const NEW_SCENE = 'new-scene';

/** A scene file's text: the save on one line, `"start": true` first for the start scene. */
export function sceneText(save: WorldSave, start: boolean): string {
  const { start: _was, ...plain } = save as WorldSave & { start?: unknown };
  return `${JSON.stringify(start ? { start: true, ...plain } : plain)}\n`;
}

/** Why `data` is not a save this build can load, or null if it is one. */
export function whyNotSave(data: unknown): string | null {
  if (typeof data !== 'object' || data === null) return 'it is not a world save';
  const save = data as Partial<WorldSave>;
  if (typeof save.version === 'number' && save.version !== 1) return `it is a save of version ${save.version}, and this build reads version 1`;
  const shaped =
    save.version === 1 && typeof save.extent === 'number' && typeof save.loop === 'object' && save.loop !== null &&
    [save.generations, save.entities, save.kinds, save.parents].every(Array.isArray) &&
    typeof save.components === 'object' && save.components !== null && typeof save.relations === 'object' && save.relations !== null;
  return shaped ? null : 'it is not a world save';
}

/** The browser's old entry: where the editor kept its scenes before they were files. */
export const LEGACY_KEY = 'vibebase.scenes';
/** The same entry once moved: kept, renamed, never deleted. */
export const LEGACY_MOVED = `${LEGACY_KEY}.migrated`;

/** What the old entry held: each scene by its name, and the one opened on start. */
export interface Legacy {
  scenes: { name: string; save: WorldSave }[];
  start: string | null;
}

/** The old entry read: its scenes that are saves, in its order, and its start if that is one of them. Null for none, or garbled. */
export function legacyScenes(raw: string | null): Legacy | null {
  if (raw === null) return null;
  try {
    const data = JSON.parse(raw) as { start?: unknown; scenes?: Record<string, { save?: unknown } | null> } | null;
    const scenes: Legacy['scenes'] = [];
    // Entries, not keys of an object: a scene may have been called anything, `__proto__` too.
    for (const [name, kept] of Object.entries(data?.scenes ?? {})) {
      if (kept && whyNotSave(kept.save) === null) scenes.push({ name, save: kept.save as WorldSave });
    }
    const start = typeof data?.start === 'string' && scenes.some((s) => s.name === data.start) ? data.start : null;
    return { scenes, start };
  } catch {
    return null;
  }
}

/** Each old scene's key: its name made one, `scene` for a name with nothing left, `-2` for a key a file or an earlier one has. */
export function migrationPlan(names: readonly string[], taken: (key: string) => boolean): { name: string; key: string }[] {
  const planned = new Set<string>();
  return names.map((name) => {
    const key = freeKey(madeSceneName(name) ?? 'scene', (k) => taken(k) || planned.has(caseKey(k)));
    planned.add(caseKey(key));
    return { name, key };
  });
}
