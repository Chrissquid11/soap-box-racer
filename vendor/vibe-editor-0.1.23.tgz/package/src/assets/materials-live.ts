/**
 * What the editor knows of the material files beyond the engine's store
 * (Docs/render.md §4): the files the dev server found broken (its push,
 * `problem` of kind `materials`), kept until they parse again -- the engine
 * keeps the last good one meanwhile, and the Material block says why it is
 * read-only. Told to whoever listens (the Assets tool's inspector).
 */

/** A material file the dev server could not parse: the parser's words, and the line. */
export interface MaterialProblem {
  key: string;
  message: string;
  line?: number;
}

export const liveMaterials = {
  /** By key: a file found broken; gone once it parses again. */
  unparsed: new Map<string, MaterialProblem>(),
  heard: new Set<() => void>(),
  /** Told after each file problem. Returns the undo. */
  onChange(listener: () => void): () => void {
    this.heard.add(listener);
    return () => void this.heard.delete(listener);
  },
  tell(): void {
    for (const fn of this.heard) fn();
  },
  /** `key`'s parse error as a line -- `line 4: Expected ...` -- or null. */
  problemOf(key: string): string | null {
    const p = this.unparsed.get(key);
    return p ? (p.line !== undefined ? `line ${p.line}: ${p.message}` : p.message) : null;
  },
};
