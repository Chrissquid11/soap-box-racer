/**
 * The Assets tool's material actions as steps (Docs/render.md §4, Docs/assets-tool.md
 * "Materials"): what each writes, and its undo -- run on the tool's queue like every
 * file edit, so Z undoes it.
 *
 * | Action | Calls | Undo |
 * | --- | --- | --- |
 * | New material | `PUT prefab { create }`: a `standard`, the defaults | the file to the trash |
 * | An edit in the Material block | `PUT prefab`, the file whole in the editor's layout (`materialText`) | `PUT prefab` of the text before |
 * | Rename, Move, Delete | the tool's own (`file-steps.ts`): what names it follows by uid, rewritten by the server's move in the same call; a Delete refused while anything names it |
 *
 * - **A material's key is its path**: `src/assets/materials/Props/Rust.material` is
 *   `props/rust`; a prefab names it by reference (`Render.material`, `{ uid, key }`, in
 *   its data or an override's `set`), and so does a level or a scene -- by uid, so a
 *   rename or a move needs nothing of these steps: the server's repair pass rewrites
 *   their keys in the move's own call (Docs/asset-ids.md §4). `wearersOf` reads them by
 *   the key each names now, for the Prefab block's and the Material block's Used by.
 * - **The block's edits are whole files** (`materialWriteEdit`): each the file as the
 *   block has it, written over what is there, and told (`written`) the text in force
 *   after each doing -- so the block reads what it wrote before the dev server's
 *   update comes back, and what an undo put back (`materialDrafts`: a draft a key,
 *   kept until the page's file says the same, gone with a file an undo took away).
 *
 * Pure but for the API handed in: node tests it (`material-steps.test.ts`).
 */
import { KINDS, MATERIAL_SUFFIX, ROOTS } from '@vibe/pipeline/kinds';
import { caseKey, materialDiff, materialText, parseMaterialFile, resolveRef, type MaterialFile, type PrefabFile } from '@vibe/engine';
import type { WriteAnswer } from '@vibe/pipeline/assets-types';
import type { Answered } from '../steps.ts';
import type { Edit } from './file-steps.ts';
import type { PrefabsApi } from './prefab-steps.ts';

/** Where the material files are: `src/assets/materials`. */
export const MATERIALS_DIR = `${ROOTS.boot.dir}/${KINDS.materials.dir}`;

/** A folder materials live in: `src/assets/materials` and under it. */
export const inMaterials = (path: string): boolean => path === MATERIALS_DIR || path.startsWith(`${MATERIALS_DIR}/`);

/** A material file's key from its path -- `src/assets/materials/Props/Rust.material` is `props/rust` -- or undefined for any other. */
export function materialKeyOf(path: string): string | undefined {
  if (!path.startsWith(`${MATERIALS_DIR}/`) || !path.toLowerCase().endsWith(MATERIAL_SUFFIX)) return undefined;
  const key = path.slice(MATERIALS_DIR.length + 1, -MATERIAL_SUFFIX.length);
  return key.split('/').some((s) => s.startsWith('_')) ? undefined : caseKey(key);
}

/** Each key's name on disk (its path under `materials/`): the engine's `materialName`, handed in by the editor's boot; none in a node test. */
let namesOf: (key: string) => string | undefined = () => undefined;

/** Where a key's file is: the engine's `materialName`, handed in by the editor's boot. */
export function useMaterialNames(names: (key: string) => string | undefined): void {
  namesOf = names;
}

/** A key's path: the file with that key as it is on disk, else the key as written. */
export const materialPathOf = (key: string): string => `${MATERIALS_DIR}/${namesOf(key) ?? key}${MATERIAL_SUFFIX}`;

/** Each `Render` holding a material a prefab file writes -- each entity's `data`, each override's `set` -- handed to `visit` with its key now (a reference's by its uid, `resolveRef`). */
function eachRender(file: PrefabFile, visit: (render: { material: unknown }, material: string) => void): void {
  const of = (data: unknown): void => {
    const render = (data as { Render?: { material?: unknown } } | undefined)?.Render;
    const m = resolveRef('materials', render?.material) ?? '';
    if (m !== '') visit(render as { material: unknown }, m);
  };
  for (const e of (file.entities ?? []) as { data?: unknown; overrides?: unknown }[]) {
    of(e.data);
    for (const o of Array.isArray(e.overrides) ? (e.overrides as { set?: unknown }[]) : []) of(o.set);
  }
}

/** Every `Render.material` text a prefab file writes: each entity's `data`, each override's `set`. */
function materialsIn(file: PrefabFile): string[] {
  const out: string[] = [];
  eachRender(file, (_render, m) => void out.push(m));
  return out;
}

/** The keys of the prefabs whose files name material `key` as a `Render.material` (any case), sorted. */
export function wearersOf(key: string, files: Readonly<Record<string, PrefabFile>>): string[] {
  const own = caseKey(key);
  return Object.keys(files).filter((k) => materialsIn(files[k]!).some((m) => caseKey(m) === own)).sort();
}

/**
 * A material file written whole as one step, `label` its name: `text` in place of
 * what is there (`create`: a new file, refused if one is). `written` is told the
 * text in force after each doing -- `text`, or on undo the text before (null for a
 * file the undo took away).
 */
export function materialWriteEdit(api: PrefabsApi, path: string, text: string, label: string, written: (text: string | null) => void, create = false): Edit {
  let before: string | null = null;
  const go = async (): Promise<Answered> => {
    const answer = await api.putPrefab(path, text, create && before === null);
    before = answer.before;
    written(text);
    return answer;
  };
  const back = async (): Promise<Answered> => {
    let answer: WriteAnswer;
    if (before === null) answer = await api.remove([path], true);
    else answer = await api.putPrefab(path, before);
    written(before);
    return answer;
  };
  return { label, first: go, redo: go, undo: back };
}

/** A material file's contents in the one layout the editor writes, or undefined for none: two that say the same are equal. */
export const sameMaterial = (json: unknown): string | undefined => (json === undefined ? undefined : materialText(materialDiff(parseMaterialFile(json).file)));

/** The Material block's writes standing in for the page's files until they say the same (`materialDrafts`). */
export interface MaterialDrafts {
  /** `key`'s file as the block reads it: its last write while it stands, else the page's; null for none. */
  read(key: string): MaterialFile | null;
  /** A write's `written`: the text in force after a doing or an undo -- held as `key`'s draft; null (a file an undo took away) drops it. */
  written(key: string, text: string | null): void;
  /** `onMaterialFiles` told of `keys`: each draft the page's file now says the same as, or with no draft, dropped. */
  heard(keys: readonly string[]): void;
  /** Is a draft standing in for `key`'s file? */
  holds(key: string): boolean;
}

/** The drafts over `fileOf`, the page's material file by key (the engine's `materialFile`). */
export function materialDrafts(fileOf: (key: string) => unknown): MaterialDrafts {
  const drafts = new Map<string, string>();
  return {
    read(key) {
      const draft = drafts.get(key);
      const json = draft !== undefined ? (JSON.parse(draft) as unknown) : fileOf(key);
      return json === undefined ? null : parseMaterialFile(json).file;
    },
    written(key, text) {
      if (text === null) drafts.delete(key);
      else drafts.set(key, sameMaterial(JSON.parse(text))!);
    },
    heard(keys) {
      for (const key of keys) {
        const draft = drafts.get(key);
        if (draft === undefined || draft === sameMaterial(fileOf(key))) drafts.delete(key);
      }
    },
    holds: (key) => drafts.has(key),
  };
}
