/**
 * An export as one step (Docs/assets-tool.md §8, "Undo"): E, Shift+E, Export
 * now and Export all stale are each one `POST export`, confirmed when the last
 * job its answer named has ended, on the tool's own stack (`steps.ts`).
 *
 * - **Its undo is each job that ended `done`**, the last first: the previous
 *   export restored from the slot its `done` named (`replace`, so the new one
 *   goes to the trash in its place) -- after a first export, which has no
 *   slot, the export and its record taken off. **Its redo** restores the slot
 *   the undo filled. Each call takes the slot the one before it answered, so
 *   Z and Y go round as often as asked, and each leaves a slot in the trash
 *   (part one's restore: what `replace` displaces is kept, never dropped).
 * - **None done is no step**: the stack as it was, and why on the bar --
 *   the job's own error, said once ("Export crate.lua failed: gladius exited
 *   1"), not wrapped in what the server said before it.
 * - **Some done** is a step of those, and the rest are said ("2 of 3 exported;
 *   the rest say why in the strip").
 * - **One at a time**: the steps run in series (`steps.ts`), so one export is
 *   under way at most, and `progress` -- the bar's "Exporting 12 · 5 done" --
 *   is one number.
 *
 * Everything it touches is handed in, so `export-step.test.ts` drives it with
 * a stand-in API and the real queue.
 */
import type { Entry, JobMessage } from '@vibe/pipeline/assets-types';
import { recordPath } from '@vibe/pipeline/paths';
import type { Api } from '../api.ts';
import type { Answered, Doing, Steps } from '../steps.ts';
import { jobEnded } from './marks.ts';

export interface ExportStepHost {
  api: Pick<Api, 'exportSources' | 'remove' | 'restore'>;
  /** Hear the `job` messages (`live.on('job', …)`): the step waits for its own jobs to end. Returns the undo. */
  jobs(listener: (job: JobMessage) => void): () => void;
  /** The client index's entries: a source's exports, and which of them are there to take off. */
  entries(): ReadonlyMap<string, Entry>;
  steps: Pick<Steps, 'run'>;
  /** How far the export under way has come -- its jobs ended of all -- or null once it is over. */
  progress(at: { total: number; ended: number } | null): void;
  /** Some exported, not all: said on the bar, the rest in the strip. */
  partial(text: string): void;
}

/** What the server says before a job's own error when an export failed: said once, by the step, not twice. */
const FAILED_BEFORE = /^the last export failed:\s*/i;

/** A job's error as the step says it: its own words, not the server's preamble. */
export const jobError = (error: string): string => error.replace(FAILED_BEFORE, '');

/** One job's undo: the previous export put back from its slot, or a first export taken off. */
interface Exported {
  source: string;
  slot: string | undefined;
  first: boolean;
  paths: string[];
}

/**
 * `label` -- "Export crate.lua", "Export 12", "Export all stale under props"
 * -- for `what`, `force` current or not, as one step: resolves true once it is
 * on the stack, false when nothing was exported (or the call was refused).
 */
export type ExportStep = (label: string, what: { paths: readonly string[] } | { under: string }, force: boolean) => Promise<boolean>;

export function createExportStep(host: ExportStepHost): ExportStep {
  const { api } = host;
  return (label, what, force) => {
    let made: Exported[] = [];
    const first: Doing = async () => {
      const ended = new Map<string, JobMessage>();
      const waiting = new Set<string>();
      let total = 0;
      let all: () => void = () => {};
      const finished = new Promise<void>((resolve) => (all = resolve));
      // Heard from before the call: a job may end before its answer comes.
      const off = host.jobs((job) => {
        if (!jobEnded(job.state)) return;
        ended.set(job.id, job);
        if (!waiting.delete(job.id)) return;
        host.progress({ total, ended: total - waiting.size });
        if (waiting.size === 0) all();
      });
      try {
        const answer = await api.exportSources(what, force);
        total = answer.jobs.length;
        for (const job of answer.jobs) if (!ended.has(job.id)) waiting.add(job.id);
        host.progress({ total, ended: total - waiting.size });
        if (waiting.size > 0) await finished;
        const done = answer.jobs.filter((job) => ended.get(job.id)?.state === 'done');
        if (done.length === 0) {
          if (total === 0) throw new Error('nothing under it needed exporting');
          // Each current by its turn -- a job ahead of it made the export: nothing to undo, and no failure.
          if (answer.jobs.every((job) => ended.get(job.id)?.state === 'skipped')) throw new Error(`nothing to export: ${total === 1 ? 'it is' : 'each is'} current`);
          const why = answer.jobs.map((job) => ended.get(job.id)?.error).find((e): e is string => typeof e === 'string' && e !== '');
          const said = why !== undefined ? jobError(why) : 'nothing was exported';
          throw new Error(total === 1 ? said : `none of the ${total} exported -- the first: ${said}`);
        }
        made = done.map((job) => {
          const slot = ended.get(job.id)!.slot;
          const exports = host.entries().get(job.source)?.exports ?? [];
          return { source: job.source, slot, first: slot === undefined, paths: [...exports, recordPath(job.source)] };
        });
        if (done.length < total) host.partial(`${label}: ${done.length} of ${total} exported; the rest say why in the strip`);
        return answer as Answered;
      } finally {
        off();
        host.progress(null);
      }
    };
    const undo: Doing = async () => {
      let last: Answered | undefined;
      for (const job of [...made].reverse()) {
        if (job.first) {
          const answer = await api.remove(job.paths.filter((p) => host.entries().has(p)), true);
          job.slot = answer.slot;
          last = answer;
        } else {
          const answer = await api.restore(job.slot!, { replace: true });
          job.slot = answer.slot;
          last = answer;
        }
      }
      return last;
    };
    const redo: Doing = async () => {
      let last: Answered | undefined;
      for (const job of made) {
        const answer = await api.restore(job.slot!, { replace: true });
        // A first export's slot is the one its undo filled, whatever this displaced: none.
        if (!job.first) job.slot = answer.slot;
        last = answer;
      }
      return last;
    };
    return host.steps.run(label, first, { do: redo, undo }, `${label} …`);
  };
}
