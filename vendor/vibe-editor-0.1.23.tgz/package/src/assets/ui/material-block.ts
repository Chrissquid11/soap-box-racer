/**
 * The Assets tool's Material block (Docs/render.md §4, §6; Docs/assets-tool.md
 * "Materials"): what the inspector says of a material file under its preview,
 * and where it is edited.
 *
 * - **Problems** first, in red: its file not parsing (the dev server's
 *   `problem`, with the line -- the block is read-only until it does), then
 *   what the compile found (`materialProblems`: a field wrong, one the type has
 *   no use for, a map no texture has).
 * - **Material**: its fields by its type, as `material-file.ts` has them --
 *   `type` a list, the colours swatches (`<input type=color>`), the numbers
 *   scrubbed (`numberField`), the yes-or-no fields ticks, `side` a list, each map
 *   a texture's picker (`key-field.ts`' `picker`, over the textures loaded,
 *   with their thumbnails; a texture file dropped on it picked), and a `physical`'s own numbers. A field the type
 *   draws without is not shown.
 * - **Each committed edit is one write** -- a scrub's end, Enter, a swatch let
 *   go, a tick, a pick -- the file whole in the editor's layout (`materialDiff`,
 *   `materialText`), one step of the tool's history (Z undoes). While a number
 *   is scrubbed or a swatch dragged, the shared material follows it live
 *   (`live`), and the panel is not built again under it (`Holding`).
 * - **Used by**: the prefabs whose `Render.material` names it, each a link to
 *   its file; a Rename or a Move follows in each by its uid (the server's
 *   move rewrites their keys), a Delete is refused while one does.
 *
 * Made with `dom.ts`' `el` and the engine's pure side: node tests it over a
 * stand-in page (`material-block.test.ts`).
 */
import { FIELD_KIND, MATERIAL_FIELDS, MATERIAL_SIDES, MATERIAL_TYPES, NUMBER_RANGE, PHYSICAL_FIELDS, usesField, type MaterialField, type MaterialFile, type PhysicalFields } from '@vibe/engine';
import { button, el } from '../../dom.ts';
import { numberField } from '../../fields.ts';
import { picker } from '../../key-field.ts';
import { holdWhileTyped, type Holding } from './assets-options.ts';

/** What the block asks of the tool. */
export interface MaterialBlockHost {
  /** The material as the block edits it -- the last write, else the file as the page has it -- or null for none handed in yet. */
  read(key: string): MaterialFile | null;
  /** Its file's parse error with its line, or null: the block is read-only while there is one. */
  unparsed(key: string): string | null;
  /** What its last compile found wrong, each a line. */
  problems(key: string): readonly string[];
  /** May this page write files. */
  writes(): boolean;
  /** `file` written as `key`'s file, one step called `label`. */
  write(key: string, file: MaterialFile, label: string): void;
  /** `file` shown on the shared material now, written nowhere: a scrub, a swatch dragged. */
  live(key: string, file: MaterialFile): void;
  /** The texture keys loaded now: a map's choices. */
  textures(): readonly string[];
  /** A texture's thumbnail, or null for none to be had. */
  thumb?(texture: string): Promise<string | null>;
  /** The prefabs whose `Render.material` names it, by key. */
  wearers(key: string): string[];
  /** A file's folder opened with it chosen. */
  reveal(path: string): void;
  /** A prefab's file by its key. */
  prefabPath(key: string): string;
  /** The keys to the tool whose block it is: a texture dropped on a map is its step. */
  focus?(): void;
}

const section = (title: string): HTMLElement => {
  const s = el('div', 'ed-component ed-as-block');
  s.append(el('div', 'ed-component-head', title));
  return s;
};

/** A field's words on hover. */
const TITLES: Partial<Record<MaterialField | keyof PhysicalFields, string>> = {
  type: 'standard: lit, rough or shiny · physical: standard and its clearcoat, glass · basic: unlit, its colour as it is · toon: banded light',
  color: 'Its colour, multiplied into its map',
  emissive: 'The light it gives off itself, in the dark too',
  side: 'Which faces are drawn: front, back, or both',
  alphaTest: 'A pixel less opaque than this is not drawn: a cut-out, no sorting',
  transparent: 'Blended with what is behind it by its opacity (and its alpha map)',
  depthWrite: 'Hides what is drawn after it, behind it: off for a glow over others',
  map: 'Its colour, from a texture (sRGB)',
  normalMap: 'Its bumps, from a texture (linear)',
};

/** The Material block for `key`, and what holds the panel while a field of it is typed in or scrubbed. */
export function materialBlock(key: string, host: MaterialBlockHost): { blocks: HTMLElement[]; hold: Holding } {
  const out: HTMLElement[] = [];
  const unparsed = host.unparsed(key);
  const problems = host.problems(key);
  if (unparsed !== null || problems.length > 0) {
    const s = section('Problems');
    if (unparsed !== null) {
      s.append(el('div', 'ed-as-red ed-as-pf-problem', `The file does not parse, ${unparsed}`));
      s.append(el('div', 'ed-dim', 'The game wears the last good one until the file is fixed in a text editor: no reload needed'));
    }
    for (const p of problems) s.append(el('div', 'ed-as-red ed-as-pf-problem', p));
    out.push(s);
  }

  const s = section('Material');
  const hold = holdWhileTyped(s);
  out.push(s);
  const now = host.read(key);
  if (now === null) {
    s.append(el('div', 'ed-dim', 'Not loaded yet: just made, or its problem is above'));
  } else {
    const fixed = unparsed !== null || !host.writes();
    if (fixed) s.append(el('div', 'ed-dim', unparsed !== null ? 'Read-only: the file does not parse' : 'Read-only: this page writes no files'));
    let file: MaterialFile = { ...now, physical: { ...now.physical } };
    /** `file` with `change` made: written, one step. */
    const write = (label: string, change: (f: MaterialFile) => void): void => {
      const next: MaterialFile = { ...file, physical: { ...file.physical } };
      change(next);
      file = next;
      host.write(key, next, `${key}: ${label}`);
    };
    /** `file` with `change` made, on the shared material alone: a drag under way. */
    const live = (change: (f: MaterialFile) => void): void => {
      const next: MaterialFile = { ...file, physical: { ...file.physical } };
      change(next);
      file = next;
      host.live(key, next);
    };
    const set = file as unknown as Record<string, unknown>;

    const grid = el('div', 'ed-fields');
    /** A list of words, a line of the grid: `type`, `side`. */
    const choice = (field: 'type' | 'side', words: readonly string[]): HTMLElement => {
      const line = el('div', 'ed-keyline');
      line.dataset.field = field;
      const name = el('span', 'ed-keyline-name', field);
      const pick = el('select', 'ed-input ed-small');
      pick.setAttribute('aria-label', field);
      for (const w of words) {
        const o = el('option', undefined, w);
        o.value = w;
        pick.append(o);
      }
      pick.value = file[field];
      pick.disabled = fixed;
      if (TITLES[field]) name.title = pick.title = TITLES[field]!;
      pick.addEventListener('change', () => write(`${field} ${pick.value}`, (f) => void ((f as unknown as Record<string, unknown>)[field] = pick.value)));
      line.append(name, pick);
      return line;
    };
    /** A colour, a swatch: each change live, let go one write. */
    const swatch = (field: MaterialField): HTMLElement => {
      const line = el('div', 'ed-keyline ed-tickline');
      line.dataset.field = field;
      const name = el('span', 'ed-keyline-name', field);
      const input = el('input', 'ed-swatch');
      input.type = 'color';
      input.value = String(set[field]);
      input.disabled = fixed;
      input.setAttribute('aria-label', field);
      if (TITLES[field]) name.title = input.title = TITLES[field]!;
      input.addEventListener('input', () => live((f) => void ((f as unknown as Record<string, unknown>)[field] = input.value.toLowerCase())));
      input.addEventListener('change', () => write(`${field} ${input.value.toLowerCase()}`, (f) => void ((f as unknown as Record<string, unknown>)[field] = input.value.toLowerCase())));
      line.append(name, input);
      return line;
    };
    /** A yes or no, a tick: a click one write. */
    const tick = (field: MaterialField): HTMLElement => {
      const line = el('div', 'ed-keyline ed-tickline');
      line.dataset.field = field;
      const name = el('span', 'ed-keyline-name', field);
      const box = el('input', 'ed-check');
      box.type = 'checkbox';
      box.checked = set[field] === true;
      box.disabled = fixed;
      box.setAttribute('aria-label', field);
      if (TITLES[field]) name.title = box.title = TITLES[field]!;
      box.addEventListener('change', () => write(`${field} ${box.checked ? 'on' : 'off'}`, (f) => void ((f as unknown as Record<string, unknown>)[field] = box.checked)));
      line.append(name, box);
      return line;
    };
    /** A number, scrubbed: each change live, the scrub's end (or Enter) one write. */
    const number = (field: string, read: () => number, put: (f: MaterialFile, v: number) => void): DocumentFragment | HTMLElement => {
      const range = NUMBER_RANGE[field];
      const made = numberField({
        label: field,
        title: `${TITLES[field as MaterialField] ?? field}${range ? ` -- ${range.min} to ${range.max}` : ''}: drag the name to scrub`,
        value: read(),
        step: range && range.max - range.min <= 1 ? 0.01 : 0.1,
        digits: 3,
        ...(range ? { min: range.min, max: range.max } : {}),
        fixed,
        set: (v) => live((f) => put(f, v)),
        commit: () => write(`${field} ${read()}`, () => undefined),
      });
      made.input.dataset.field = field;
      return made.label;
    };
    /** A map: the texture's picker, `none` first. */
    const map = (field: MaterialField): HTMLElement => {
      const line = el('div', 'ed-keyline');
      line.dataset.field = field;
      const name = el('span', 'ed-keyline-name', field);
      name.title = `${TITLES[field] ?? `${field}, from a texture (linear)`}: a texture's key`;
      const picks = el('div', 'ed-keyline-picks');
      const p = picker({
        title: `${key}'s ${field}`,
        value: (set[field] as string | null) ?? '',
        none: 'none',
        choices: () => host.textures(),
        ...(host.thumb ? { thumb: host.thumb } : {}),
        fixed,
        // A texture dragged from the Assets panel and dropped on it: picked.
        drops: 'Texture',
        dropped: () => host.focus?.(),
        pick: (text) => write(`${field} ${text || 'none'}`, (f) => void ((f as unknown as Record<string, unknown>)[field] = text === '' ? null : text)),
      });
      picks.append(p.root);
      line.append(name, picks);
      return line;
    };

    grid.append(choice('type', MATERIAL_TYPES));
    for (const field of MATERIAL_FIELDS) {
      if (field === 'type' || !usesField(file.type, field)) continue;
      switch (FIELD_KIND[field]) {
        case 'colour':
          grid.append(swatch(field));
          break;
        case 'number':
          grid.append(number(field, () => (file as unknown as Record<string, number>)[field]!, (f, v) => void ((f as unknown as Record<string, unknown>)[field] = v)));
          break;
        case 'bool':
          grid.append(tick(field));
          break;
        case 'side':
          grid.append(choice('side', MATERIAL_SIDES));
          break;
        case 'map':
          grid.append(map(field));
          break;
        default:
          break;
      }
    }
    s.append(grid);
    if (file.type === 'physical') {
      const phys = el('div', 'ed-fields ed-as-mat-physical');
      phys.append(el('div', 'ed-keyline ed-dim', 'physical'));
      for (const field of PHYSICAL_FIELDS) phys.append(number(field, () => file.physical[field], (f, v) => void (f.physical[field] = v)));
      s.append(phys);
    }
  }

  const used = section('Used by');
  const wearers = host.wearers(key);
  if (wearers.length === 0) used.append(el('div', 'ed-dim', 'no prefab wears it: a Render.material names it'));
  for (const k of wearers) {
    const line = el('div', 'ed-line');
    line.append(button('ui', k, `Open ${k}'s folder with it chosen: its Render.material is ${key}`, () => host.reveal(host.prefabPath(k)), 'ed-small ed-quiet ed-as-link'));
    used.append(line);
  }
  if (wearers.length > 0) used.append(el('div', 'ed-dim', 'a Rename or a Move follows in each by its uid, in its step; a Delete is refused while one wears it'));
  out.push(used);
  return { blocks: out, hold };
}
