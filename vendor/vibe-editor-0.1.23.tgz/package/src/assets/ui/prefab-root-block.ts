/**
 * The Assets tool's Root block (Docs/prefabs.md §7, Docs/assets-tool.md
 * "Prefabs"): a prefab's root -- the entity whose `parent` is null; a
 * variant's, the nested instance at its root -- shown and edited in the
 * inspector without opening the prefab, as Unity's inspector does on a
 * prefab asset.
 *
 * - **The Entities inspector's own drawing** (`entityBlocks`), pointed at the
 *   root of a fresh instance in a scratch world (`root-edit.ts`, which says
 *   why that shape): its name (a click renames it), the state line -- off,
 *   the layer, the tags, the labels -- Transform, then a block a component
 *   with its fields as typed -- a number scrubbed or stepped, a component's
 *   box, a `ref()` as a choice of the prefab's own entities -- each foldable,
 *   with its ×, and Add Component. Runtime fields dimmed, shown only,
 *   as in the opened mode.
 * - **Each committed edit is one write** (Enter, a scrub's end, a box, a
 *   choice, add, remove): the tool's `commit` -- checked, then `PUT prefab`
 *   as one step of the tool's own history (`writePrefabsEdit`). The live
 *   recompile brings every instance up where it holds no override; the
 *   block is drawn again from it.
 * - **Read-only, and why**, with every control off: a compile error, the
 *   prefab open in the opened mode ("open: edit it there"), an Apply landing,
 *   a page that cannot write. A refused edit is said under the name -- and a
 *   file changed on disk since it was read offers to write over it.
 * - **Not drawn again under a field** typed in or scrubbed (`holdWhileTyped`):
 *   the redraw waits, and comes as it lets go.
 */
import { label as labelOf, Name, type Entity } from '@vibe/engine';
import { textEdit } from '../../fields.ts';
import { entityBlocks } from '../../inspector.ts';
import type { Blocks } from '../../inspector-blocks.ts';
import type { InspectorHost } from '../../inspector.ts';
import { createTransformBlocks } from '../../inspector-transform.ts';
import type { AdderState } from '../../add-component.ts';
import type { LabelsState } from '../../labels-drop.ts';
import type { MenuItem } from '../../menu.ts';
import type { RootEdit } from '../../root-edit.ts';
import { button, el } from '../../shell.ts';
import { SWITCHES, switchStep } from '../../switches.ts';
import type { TagsState } from '../../tags-drop.ts';
import { holdWhileTyped, type Holding } from './assets-options.ts';

/** What the block asks of the tool. */
export interface RootBlockHost {
  /** `key`'s root ready to edit -- kept while its compile stands -- or null for one not compiled. */
  edit(key: string): RootEdit | null;
  /** Why `key`'s root cannot be edited just now, or null. */
  refusal(key: string): string | null;
  /** An edit made on `edit`'s world, called `label`: written, one step -- or refused and said. */
  commit(key: string, edit: RootEdit, label: string): void;
  /** The last edit refused, for this key: what was said, and the way to write over a file changed on disk if that was it. */
  refused(key: string): { line: string; overwrite: (() => void) | null } | null;
  /** A menu under a control: a ref's choices. */
  menu(at: HTMLElement, items: readonly MenuItem[], title: string): void;
  /** Which drop-down of the state line is down, kept across builds. */
  readonly tags: TagsState;
  readonly labels: LabelsState;
  /** Whether its Add Component card is open, kept across builds. */
  readonly adder: AdderState;
  /** The keys to the tool whose block it is: an asset file dropped on a key field of it is its step. */
  focus?(): void;
}

/** The Root block for `key`, and what holds the panel while it is typed in; null for a prefab not compiled. */
export function rootBlock(key: string, host: RootBlockHost): { root: HTMLElement; hold: Holding } | null {
  const edit = host.edit(key);
  if (!edit) return null;
  const { world } = edit;
  const e = edit.root;
  const section = el('div', 'ed-component ed-as-block ed-as-pf-root');
  const hold = holdWhileTyped(section);
  section.append(el('div', 'ed-component-head', 'Root'));
  const why = host.refusal(key);
  const changed = (label: string): void => {
    world.flush();
    host.commit(key, edit, label);
  };

  // Its name, as the inspector's title: a click makes it the field that renames it.
  const names = (): { value: unknown[] } => world.rawStore(Name) as { value: unknown[] };
  const nameNow = world.has(e, Name) ? String(names().value[e] ?? '') : '';
  const top = el('div', 'ed-line ed-as-root-top');
  const title = el('span', 'ed-as-root-name ed-name-edit', labelOf(world, e));
  title.title = why ? `${key}'s root` : 'Click to rename';
  const path = edit.parts[0]?.path ?? '';
  const facts = el('span', 'ed-dim ed-as-root-facts', `${path === '' ? 'parent null' : path}${edit.parts.length > 1 ? ` · ${edit.parts.length - 1} under it` : ''}`);
  facts.title = 'The prefab\'s first entity, the one with no parent -- a variant\'s is the instance of its base at its root, and what is set here is an override of it in this file';
  top.append(title, facts);
  if (!why) {
    // mcp: prefab_edit -- the name made the field to rename the prefab's root
    title.addEventListener('click', () => {
      const form = textEdit({
        value: nameNow,
        placeholder: key.slice(key.lastIndexOf('/') + 1),
        commit: (text) => {
          const name = text.trim();
          if (name === nameNow) return void form.replaceWith(title);
          if (!name) world.remove(e, Name);
          else if (world.has(e, Name)) names().value[e] = name;
          else world.add(e, Name).value[e] = name;
          changed('Rename');
        },
        cancel: () => form.replaceWith(title),
      });
      title.replaceWith(form);
    });
  }
  section.append(top);
  if (why) section.append(el('div', 'ed-dim ed-as-root-why', `Read-only: ${why}`));
  const refused = host.refused(key);
  if (refused) {
    const line = el('div', 'ed-as-red ed-as-root-why', refused.line);
    if (refused.overwrite) line.append(' ', button('prefab_edit', 'Write over it', `Write this edit to ${key} over what is on disk now`, refused.overwrite, 'ed-small'));
    section.append(line);
  }

  /** What `showValues` reads again: one updater a field. */
  const live: (() => void)[] = [];
  const inspector: InspectorHost = {
    primary: () => e,
    selected: () => [e],
    // Whom a ref points at is in the prefab, not the scene: nothing to select there.
    select: () => undefined,
    changed,
    redraw: () => undefined,
    commit: (label) => host.commit(key, edit, label),
    reparent: () => undefined,
    duplicate: () => undefined,
    destroy: () => undefined,
    toggle(which, es) {
      const { tag } = SWITCHES[which];
      const on = !es.every((x) => world.has(x, tag));
      for (const x of es) {
        if (on && !world.has(x, tag)) world.add(x, tag);
        else if (!on && world.has(x, tag)) world.remove(x, tag);
      }
      changed(switchStep(which, on, 1));
    },
    link: () => undefined,
    // A ref of the root points at an entity of the prefab: a choice of them, under its Pick….
    pickRef(component, field) {
      const at = body.querySelector<HTMLElement>(`[data-field="${component.name}.${field}"] .ed-pick`);
      if (!at) return;
      const column = (): { [i: number]: number } => (world.rawStore(component) as unknown as Record<string, { [i: number]: number }>)[field]!;
      const point = (to: Entity): void => {
        column()[e] = world.ref(to);
        changed(`Set ${component.name}.${field}`);
      };
      host.menu(at, edit.parts.map((p) => ({
        mcp: 'prefab_edit',
        label: `${p.label}${p.path === '' ? ' (its root)' : ''}`,
        title: `Point ${component.name}.${field} at ${p.path || 'its root'}`,
        run: () => point(p.entity),
      })), `${component.name}.${field} points at`);
    },
    picking: null,
    // Its runtime fields dimmed, as the opened mode's: no file keeps them.
    opened: () => true,
    focus: () => host.focus?.(),
  };
  const blocks: Blocks = {
    world,
    host: inspector,
    live: (update) => void live.push(update),
    wrote() {
      for (const update of live) update();
    },
  };
  const made = entityBlocks(blocks, [e], { transform: createTransformBlocks(blocks, () => undefined), tags: host.tags, labels: host.labels, adder: host.adder, addMcp: 'prefab_edit' });
  const body = el('div', 'ed-as-root-body');
  const adder = el('div', 'ed-line ed-addc-line');
  adder.append(made.adder);
  body.append(made.state, ...made.components, adder);
  // A runtime ref is shown, never pointed: no file keeps it.
  for (const b of body.querySelectorAll<HTMLButtonElement>('.ed-runtime button')) b.disabled = true;
  if (why) {
    body.classList.add('ed-as-readonly');
    for (const c of body.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLButtonElement>('input, select, button')) c.disabled = true;
  }
  section.append(body);
  return { root: section, hold };
}
