/**
 * The Assets tool's Options block (Docs/assets-tool.md §6.5): a source's
 * recipe options as fields drawn from the recipe's own schema (`recipes.ts`,
 * imported, §A.3) -- a number a `numberField` (its `min`, `max`, `step`, and
 * its unit in the label), a boolean a tick, an enum a list, a map (`params`)
 * a list of names and values -- and a folder's `export.json` the same way,
 * every option a row of its kind has (`kindOptions`). A folder above the
 * kinds' folders (the Source root, `audio/`) has none: "set defaults in a kind's
 * folder" (`aboveKinds`), as `PUT sidecar` answers too.
 *
 * - **What applies is worked out as the server does it** (`planFields`): the
 *   recipe's defaults, then every `export.json` above -- those the client
 *   index lists, role `record`, so no folder without one is asked -- root to
 *   leaf, then the source's own record, the nearest winning, as
 *   `resolveOptions` merges them; a value its schema refuses is said under its
 *   field, and does not stand. A field not set here is empty, what applies
 *   grey in it; where a folder sets that, the field says so ("default 90 from
 *   models/export.json").
 * - **The records are read through `GET file`** and kept for the session by
 *   path and mtime (`createRecords`): one rewritten is read again, and one the
 *   index does not list is never asked for.
 * - **A change is a step** (`optionsEdit`): the record read fresh as its turn
 *   comes on the tool's queue -- so two changes in a row never write over each
 *   other -- the one option changed, written with `PUT sidecar`, which
 *   re-exports: "angle 70 → 90". Undone, the options before are written back,
 *   and the export that follows is the very file it was (§A.3: exports are
 *   deterministic). Several are one step of a call each: "textureMax 2048 →
 *   1024 × 3".
 * - **Reset** (↺) takes an option off where it is set, so the default -- or
 *   the folder's -- applies again; **Reset all** takes every one.
 * - **Several chosen** share one block only when their recipe's options are
 *   one (`shareFields`): each field the value they agree on (`agreed`), or `—`
 *   with the values on hover (`spread`); a typed value is every one's, a scrub
 *   moves each from its own.
 * - **What `PUT sidecar` would refuse is said first**: `checkOptions`' words
 *   under the field, and nothing sent.
 *
 * The plan, the labels, the records and the step are pure or handed what they
 * call; the block makes its elements only when called (`dom.ts`, `fields.ts`),
 * so node imports this file (`assets-options.test.ts`).
 */
import type { Entry, ExportRecord, OptionSchema, OptionValue, Options } from '@vibe/pipeline/assets-types';
import { ROOTS, type KindName } from '@vibe/pipeline/kinds';
import { baseName, folderChain, folderRecordPath, joinPath, locate, recordPath, under } from '@vibe/pipeline/paths';
import { aboveKinds, canonical, checkOption, checkOptions, isFound, kindOptions, RECIPES, recipeFor, type Schemas } from '@vibe/pipeline/recipes';
import { button, control, el } from '../../dom.ts';
import { numberField, shown, textInput } from '../../fields.ts';
import { agreed, MIXED, spread, times } from '../../multi.ts';
import type { Api } from '../api.ts';
import { Unchanged, type Answered } from '../steps.ts';
import type { Edit } from './file-steps.ts';

// ---------------------------------------------------------------- what is set: a source's record, a folder's export.json

/** What an Options block sets: a source's record, or a folder's `export.json`. */
export interface Target {
  /** The source, or the folder on the Source side: what `PUT sidecar` is given. */
  path: string;
  folder: boolean;
  /** The file it writes: `<stem>.export.json` beside a source, a folder's `export.json`. */
  file: string;
  /** Its options: the recipe's schemas, or every option a row of the folder's kind has. */
  schemas: Schemas;
  /** The `export.json` files that apply to it, root first: the folders above. */
  layers: readonly string[];
  /** What applies with nothing set anywhere -- a recipe's defaults; for a folder, null where its kind's formats differ. */
  defaults: Readonly<Record<string, OptionValue | null>>;
  /** A folder's options whose default is the format's: said under the field ("false for .lua, .stl; true for the rest"). */
  byFormat?: Readonly<Record<string, string>>;
}

/** A path said from the Source root: `AssetsSource/models/export.json` is `models/export.json`. */
export const fromSourceRoot = (path: string): string => (under(path, ROOTS.source.dir) && path !== ROOTS.source.dir ? path.slice(ROOTS.source.dir.length + 1) : path);

/** An option's value as a label says it: a number as typed, a boolean on or off, a map its pairs. */
export function sayValue(value: OptionValue): string {
  if (typeof value === 'number') return shown(value);
  if (typeof value === 'boolean') return value ? 'on' : 'off';
  if (typeof value === 'string') return value;
  const pairs = Object.entries(value);
  return pairs.length === 0 ? 'none' : pairs.map(([k, v]) => `${k}=${v}`).join(', ');
}

/**
 * Each option's default under a folder of `kind`: one value where every format
 * there agrees, else null and what each has -- a folder's `keepNormals` is
 * false for a `.lua` and true for an `.fbx`.
 */
export function kindDefaults(kind: KindName): { defaults: Record<string, OptionValue | null>; byFormat: Record<string, string> } {
  const seen = new Map<string, Map<string, { value: OptionValue; where: string[] }>>();
  for (const [ext, row] of Object.entries(RECIPES[kind] ?? {})) {
    if (!('to' in row)) continue;
    for (const [name, schema] of Object.entries(row.options ?? {})) {
      const values = seen.get(name) ?? new Map<string, { value: OptionValue; where: string[] }>();
      const at = canonical(schema.default);
      const had = values.get(at) ?? { value: schema.default, where: [] };
      if (!had.where.includes(`.${ext}`)) had.where.push(`.${ext}`);
      values.set(at, had);
      seen.set(name, values);
    }
  }
  const defaults: Record<string, OptionValue | null> = {};
  const byFormat: Record<string, string> = {};
  for (const [name, values] of seen) {
    const list = [...values.values()];
    if (list.length === 1) {
      defaults[name] = list[0]!.value;
      continue;
    }
    defaults[name] = null;
    // The fewest named, the most said as the rest.
    const sorted = list.sort((a, b) => a.where.length - b.where.length);
    const named = sorted.slice(0, -1).map((v) => `${sayValue(v.value)} for ${v.where.join(', ')}`);
    byFormat[name] = `by format: ${named.join('; ')}; ${sayValue(sorted[sorted.length - 1]!.value)} for the rest`;
  }
  return { defaults, byFormat };
}

/** A folder whose `export.json` the tool will not write, and why: above the kinds' folders (`aboveKinds`). */
export interface NoTarget {
  refused: string;
}

/**
 * What a source's Options block sets, or a folder's: undefined for what has no
 * options -- a file copied as it is, `reference/`, anything outside `AssetsSource/`
 * -- and for a folder above the kinds' folders, the line that says where
 * defaults are set instead, in `PUT sidecar`'s words.
 */
export function targetOf(path: string, folder: false): Target | undefined;
export function targetOf(path: string, folder: boolean): Target | NoTarget | undefined;
export function targetOf(path: string, folder: boolean): Target | NoTarget | undefined {
  // Options live on the Source side: a record beside its source, an `export.json` in its folder.
  if (!under(path, ROOTS.source.dir)) return undefined;
  if (folder) {
    const inside = joinPath(path, 'x');
    const where = locate(inside);
    if (where?.reference) return undefined;
    // Above the kinds: sources of several would read it, and their options share names, not meanings.
    if (where?.kind === undefined) return { refused: aboveKinds(path) };
    const schemas = kindOptions(where.kind);
    if (Object.keys(schemas).length === 0) return undefined;
    const { defaults, byFormat } = kindDefaults(where.kind);
    // The folders above it: its own export.json is what it sets.
    const layers = folderChain(inside).slice(0, -1).map(folderRecordPath);
    return { path, folder: true, file: folderRecordPath(path), schemas, layers, defaults, ...(Object.keys(byFormat).length > 0 ? { byFormat } : {}) };
  }
  const found = recipeFor(path);
  const schemas = isFound(found) ? found.row.options : undefined;
  if (!schemas || Object.keys(schemas).length === 0) return undefined;
  const defaults: Record<string, OptionValue> = {};
  for (const [name, schema] of Object.entries(schemas)) defaults[name] = schema.default;
  return { path, folder: false, file: recordPath(path), schemas, layers: folderChain(path).map(folderRecordPath), defaults };
}

/**
 * Several sources' targets, when they share one Options block: their recipes'
 * options are one object -- a script's, a model format's, a picture's (an
 * `.fbx` and an `.obj` share theirs; a `.lua` and an `.stl`, a sound effect and
 * a piece of music, do not). Null when none of them has options; 'differ' when
 * some do and they are not one.
 */
export function sharedTargets(sources: readonly string[]): Target[] | 'differ' | null {
  const targets = sources.map((path) => targetOf(path, false));
  if (!targets.some((t) => t !== undefined)) return null;
  const first = targets[0];
  return first !== undefined && targets.every((t) => t !== undefined && t.schemas === first.schemas) ? (targets as Target[]) : 'differ';
}

// ---------------------------------------------------------------- the plan

/** One layer of options: a folder's `export.json` -- where, and what it sets (undefined: none there). */
export interface Layer {
  path: string;
  options: Readonly<Record<string, unknown>> | undefined;
}

/** A field as the block draws it: of one file, or of several (`shareFields`). */
export interface Field {
  name: string;
  schema: OptionSchema;
  /** What applies: the value set here, else what is inherited -- null for several that differ, or a folder's default by format. */
  value: OptionValue | null;
  /** Set here: on every one ('all'), on some, or on none -- Reset takes it off where it is. */
  set: 'all' | 'some' | 'none';
  /** What applies with it not set here: the recipe's default or a folder's above -- null where they differ. */
  inherited: OptionValue | null;
  /** Where `inherited` is set: a folder's `export.json`, '' for the recipe's default, null where they differ. */
  from: string | null;
  /** The values, when several differ: on hover. */
  note?: string;
  /** A value set by hand that its schema refuses, and where: said under the field; the default stands. */
  problem?: string;
}

/**
 * The fields of one file (`Target`): `schemas` merged as `resolveOptions`
 * merges them -- `defaults`, then each layer root to leaf, then `own`, the
 * nearest winning, an option a layer sets that its schema refuses said and
 * passed over.
 */
export function planFields(schemas: Schemas, layers: readonly Layer[], own: Readonly<Record<string, unknown>> | undefined, defaults?: Readonly<Record<string, OptionValue | null>>, ownPath = ''): Field[] {
  const out: Field[] = [];
  for (const [name, schema] of Object.entries(schemas)) {
    let inherited: OptionValue | null = defaults !== undefined && name in defaults ? (defaults[name] ?? null) : schema.default;
    let from: string | null = '';
    const problems: string[] = [];
    for (const layer of layers) {
      const v = layer.options?.[name];
      if (v === undefined) continue;
      const why = checkOption(schema, v);
      if (why) problems.push(`${name}: must be ${why} -- ${fromSourceRoot(layer.path)} sets ${JSON.stringify(v)}, so it is passed over`);
      else {
        inherited = v as OptionValue;
        from = layer.path;
      }
    }
    let set: OptionValue | undefined;
    const mine = own?.[name];
    if (mine !== undefined) {
      const why = checkOption(schema, mine);
      if (why) problems.push(`${name}: must be ${why} -- ${ownPath ? fromSourceRoot(ownPath) : 'its record'} sets ${JSON.stringify(mine)}, so it is passed over`);
      else set = mine as OptionValue;
    }
    out.push({
      name,
      schema,
      value: set ?? inherited,
      set: set !== undefined ? 'all' : 'none',
      inherited,
      from,
      ...(problems.length > 0 ? { problem: problems.join('; ') } : {}),
    });
  }
  return out;
}

const same = (a: OptionValue | null, b: OptionValue | null): boolean => canonical(a) === canonical(b);

/**
 * Several files' fields as one block: each field the value they agree on, or
 * null -- `—`, the values on hover; set on all, some or none. They share one
 * recipe's options, so their lists name the same options in the same order.
 */
export function shareFields(lists: readonly (readonly Field[])[]): Field[] {
  if (lists.length === 0) return [];
  if (lists.length === 1) return [...lists[0]!];
  return lists[0]!.map((first, i) => {
    const all = lists.map((list) => list[i]!);
    const values = all.map((f) => f.value);
    const value = agreed(values, same);
    const sets = all.filter((f) => f.set !== 'none').length;
    const inherited = agreed(all.map((f) => f.inherited), same);
    const from = agreed(all.map((f) => f.from));
    const problems = [...new Set(all.map((f) => f.problem).filter((p): p is string => p !== undefined))];
    return {
      name: first.name,
      schema: first.schema,
      value,
      set: sets === 0 ? 'none' : sets === all.length ? 'all' : 'some',
      inherited,
      from,
      ...(value === null ? { note: spread(values.map((v) => (v === null ? 'by format' : sayValue(v)))) } : {}),
      ...(problems.length > 0 ? { problem: problems.join('; ') } : {}),
    };
  });
}

/**
 * `own` with `name` set to `to`, or taken off (`to` undefined). A source's
 * record keeps only what differs from what it inherits (`PUT sidecar` strips
 * the rest), so a value set to that is taken off; a folder's `export.json`
 * keeps it as typed, pinned whatever the folders above say.
 */
export function withOption(own: Readonly<Options>, name: string, to: OptionValue | undefined, inherited: OptionValue | null, folder: boolean): Options {
  const out: Options = { ...own };
  if (to === undefined || (!folder && inherited !== null && same(to, inherited))) delete out[name];
  else out[name] = to;
  return out;
}

/** A number held to its schema: within `min` and `max`, on its `step` from `min`. */
export function onSchema(schema: OptionSchema, value: number): number {
  let v = Math.min(schema.max ?? Infinity, Math.max(schema.min ?? -Infinity, value));
  if (schema.step !== undefined) {
    const base = schema.min ?? 0;
    v = base + Math.round((v - base) / schema.step) * schema.step;
    v = Math.min(schema.max ?? Infinity, Math.max(schema.min ?? -Infinity, Number(v.toFixed(6))));
  }
  return v;
}

/** Why `PUT sidecar` would refuse this value for this field, in `checkOptions`' words; undefined when it would take it. */
export function refusalOf(field: Pick<Field, 'name' | 'schema'>, to: OptionValue): string | undefined {
  return checkOptions({ [field.name]: field.schema }, { [field.name]: to })[0];
}

/**
 * A step's label (§6.5): "angle 70 → 90", "textureMax 2048 → 1024 × 3";
 * several that differed, "angle → 90 × 3"; moved, each from its own, "angle
 * +20 × 3".
 */
export function optionLabel(name: string, from: OptionValue | null, to: OptionValue | { by: number }, n: number): string {
  if (typeof to === 'object' && 'by' in to && typeof to.by === 'number' && Object.keys(to).length === 1) {
    return times(`${name} ${to.by < 0 ? '−' : '+'}${shown(Math.abs(to.by))}`, n);
  }
  const value = to as OptionValue;
  return times(`${name} ${from === null ? '→ ' : `${sayValue(from)} → `}${sayValue(value)}`, n);
}

// ---------------------------------------------------------------- the records

/** A record's or an `export.json`'s options as read: or 'reading', or why it could not be read. */
export type RecordRead = { options: Options } | 'reading' | { problem: string };

/** What the records are read through: the index, and `GET file`. */
export interface RecordsHost {
  entries(): ReadonlyMap<string, Entry>;
  file(path: string, init?: RequestInit): Promise<Response>;
}

export interface Records {
  /**
   * A record's options, or a folder's `export.json`'s, kept by path and
   * mtime: 'reading' until it answers, and `then` told -- a file rewritten,
   * what it held before until then; none, for a file the index does not list
   * -- never asked for.
   */
  read(path: string, then: () => void): RecordRead;
  /** The whole record, its `built` too, as `read` keeps it: null while it is read, or for none. */
  record(path: string, then: () => void): ExportRecord | null;
  /** Read now, past what is kept: what a step changes, as its turn comes. Throws for one that does not parse. */
  fresh(path: string): Promise<Options>;
}

/** A record's text read: its options, or why not -- in the server's words for one that does not parse. */
function parseRecord(path: string, text: string): { record: ExportRecord } | { problem: string } {
  const problem = { problem: `${baseName(path)} does not parse: fix it in a text editor, or delete it` };
  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    return problem;
  }
  if (typeof json !== 'object' || json === null || Array.isArray(json)) return problem;
  const options = (json as { options?: unknown }).options ?? {};
  if (typeof options !== 'object' || options === null || Array.isArray(options)) return problem;
  return { record: { ...(json as ExportRecord), options: options as Options } };
}

export function createRecords(host: RecordsHost): Records {
  type Read = { record: ExportRecord } | { problem: string };
  /** By path: what was read at `mtime`, or 'reading' -- with `last`, what the file held before it was rewritten, shown meanwhile. */
  const kept = new Map<string, { mtime: number; read: Read | 'reading'; last?: Read }>();
  const none: { options: Options } = { options: {} };

  function look(path: string, then: () => void): Read | 'reading' | null {
    const entry = host.entries().get(path);
    if (!entry) return null;
    const had = kept.get(path);
    // Rewritten and read again: what it held until then stands meanwhile, so a block drawn from it does not
    // fall back to "reading…" for the moment it takes -- its fields, their height and the focus on them stay.
    if (had && had.mtime === entry.mtime) return had.read === 'reading' ? (had.last ?? 'reading') : had.read;
    const mtime = entry.mtime;
    const last = had ? (had.read !== 'reading' ? had.read : had.last) : undefined;
    kept.set(path, { mtime, read: 'reading', ...(last ? { last } : {}) });
    host.file(path).then((res) => res.text()).then(
      (text) => {
        if (kept.get(path)?.mtime !== mtime) return;
        kept.set(path, { mtime, read: parseRecord(path, text) });
        then();
      },
      (err: Error) => {
        if (kept.get(path)?.mtime !== mtime) return;
        kept.set(path, { mtime, read: { problem: `${baseName(path)} could not be read: ${err.message}` } });
        then();
      },
    );
    return last ?? 'reading';
  }

  return {
    read(path, then) {
      const at = look(path, then);
      if (at === null) return none;
      if (at === 'reading' || 'problem' in at) return at;
      return { options: at.record.options };
    },
    record(path, then) {
      const at = look(path, then);
      return at !== null && at !== 'reading' && 'record' in at ? at.record : null;
    },
    async fresh(path) {
      if (!host.entries().has(path)) return {};
      const res = await host.file(path, { cache: 'no-store' });
      const read = parseRecord(path, await res.text());
      if ('problem' in read) throw new Error(read.problem);
      return { ...read.record.options };
    },
  };
}

/**
 * The fields of these targets as the records read just now: each one's own,
 * and one list of them all (`shareFields`) -- null while any record is read.
 * A record that does not parse is a problem, said; its options the defaults.
 */
export function fieldsFor(targets: readonly Target[], read: (path: string) => RecordRead): { shared: Field[] | null; each: Field[][]; problems: string[] } {
  const problems: string[] = [];
  const each: Field[][] = [];
  let reading = false;
  const options = (path: string): Readonly<Record<string, unknown>> | undefined => {
    const at = read(path);
    if (at === 'reading') {
      reading = true;
      return undefined;
    }
    if ('problem' in at) {
      if (!problems.includes(at.problem)) problems.push(at.problem);
      return undefined;
    }
    return at.options;
  };
  for (const target of targets) {
    const layers = target.layers.map((path) => ({ path, options: options(path) }));
    const own = options(target.file);
    each.push(planFields(target.schemas, layers, own, target.defaults, target.file));
  }
  return { shared: reading ? null : shareFields(each), each, problems };
}

// ---------------------------------------------------------------- the step

/** One file's options changed: read as the step's turn comes, then what `change` makes of them written. */
export interface OptionsWrite {
  /** The source, or the folder: what `PUT sidecar` is given. */
  path: string;
  /** Its record, or the folder's `export.json`: what is read first. */
  file: string;
  change(own: Readonly<Options>): Options;
}

/**
 * The options changed as one step on the tool's queue (`steps.run`): each
 * file's options read fresh (`read`), changed, and written with `PUT sidecar`
 * -- which re-exports -- in order; one unchanged is not written. Its undo
 * writes back what each held, the last first; its redo what it wrote. One
 * refused stops the rest: none written throws it, naming the file; some
 * written is a step of those (`named`), the rest said (`partial`). Nothing
 * that differs, read fresh, is `Unchanged`: no step, and nothing said.
 */
export function optionsEdit(api: Pick<Api, 'putSidecar'>, read: (file: string) => Promise<Options>, writes: readonly OptionsWrite[], label: (n: number) => string, partial?: (text: string) => void): Edit {
  let done: Array<{ path: string; before: Options; after: Options }> = [];
  const put = async (list: ReadonlyArray<{ path: string; options: Options }>): Promise<Answered | undefined> => {
    let last: Answered | undefined;
    for (const { path, options } of list) {
      try {
        last = await api.putSidecar(path, options);
      } catch (err) {
        throw new Error(`${baseName(path)}: ${reasonOf(err)}`);
      }
    }
    return last;
  };
  return {
    label: label(writes.length),
    async first() {
      done = [];
      let last: Answered | undefined;
      for (const write of writes) {
        try {
          const before = await read(write.file);
          const after = write.change(before);
          if (canonical(after) === canonical(before)) continue;
          last = await api.putSidecar(write.path, after);
          done.push({ path: write.path, before, after });
        } catch (err) {
          const said = `${baseName(write.path)}: ${reasonOf(err)}`;
          if (done.length === 0) throw new Error(said);
          partial?.(`${label(writes.length)}: ${done.length} of ${writes.length} written; ${said} -- the rest left as they were`);
          break;
        }
      }
      // Nothing differed, read as its turn came: no step, nothing said, and what is queued behind goes on.
      if (done.length === 0) throw new Unchanged(writes.length === 1 ? 'it is so already' : 'each is so already');
      return last;
    },
    redo: () => put(done.map((d) => ({ path: d.path, options: d.after }))),
    undo: () => put([...done].reverse().map((d) => ({ path: d.path, options: d.before }))),
    named: () => label(done.length),
  };
}

/** A move of a number of several that differ: `{ by }`, each from its own. */
export const isMove = (to: OptionValue | { by: number } | undefined): to is { by: number } =>
  typeof to === 'object' && to !== null && Object.keys(to).length === 1 && typeof (to as { by?: unknown }).by === 'number';

/**
 * One option's change on these targets, as writes for `optionsEdit` (§6.5):
 * each worked out from the record read fresh as the step's turn comes -- set,
 * moved by `by` from its own value then (so a press of an arrow key queued
 * behind another builds on it, one step a press), or taken off where it is
 * set. A map typed on several that differ adds its pairs to each one's. `from`
 * gathers each one's value as read: what the label says it was.
 */
export function optionWrites(targets: readonly Target[], each: readonly (readonly Field[])[], field: Field, to: OptionValue | { by: number } | undefined): { writes: OptionsWrite[]; from: Array<OptionValue | null> } {
  const writes: OptionsWrite[] = [];
  const from: Array<OptionValue | null> = [];
  targets.forEach((target, i) => {
    const mine = each[i]?.find((f) => f.name === field.name);
    if (!mine) return;
    const { inherited } = mine;
    writes.push({
      path: target.path,
      file: target.file,
      change(own) {
        const v = own[field.name];
        // What applies now: its own, if its schema takes it; else what it inherits.
        const before = v !== undefined && checkOption(field.schema, v) === undefined ? (v as OptionValue) : inherited;
        from.push(before);
        let next: OptionValue | undefined;
        if (to === undefined) next = undefined;
        else if (isMove(to)) {
          if (typeof before !== 'number') return { ...own };
          next = onSchema(field.schema, before + to.by);
        } else if (field.schema.type === 'map' && field.value === null && typeof to === 'object' && before !== null && typeof before === 'object') {
          next = { ...before, ...(to as Record<string, string>) };
        } else next = to;
        return withOption(own, field.name, next, inherited, target.folder);
      },
    });
  });
  return { writes, from };
}

/** A change's label, from what each held as read (`from`), or as drawn until it is read: "angle 71 → 72", "angle +1 × 3", "angle 72 → 70" for a Reset. */
export function changeLabel(field: Field, to: OptionValue | { by: number } | undefined, from: readonly (OptionValue | null)[], n: number): string {
  const was = from.length > 0 ? agreed(from, same) : field.value;
  if (to === undefined) return field.inherited === null ? times(`Reset ${field.name}`, n) : optionLabel(field.name, was, field.inherited, n);
  return optionLabel(field.name, isMove(to) ? null : was, to, n);
}

/** What a number field's commit is: a move of several, the option taken off (emptied), a value set -- or nothing. */
export type Commit = { by: number } | { to: number } | 'reset' | null;

/**
 * A number field's commit, read from the field as it is now (§6.5): a scrub or
 * an arrow of several that differ, by how much; emptied, taken off where it is
 * set -- never the last value typed before it was emptied; else the number in
 * it, unless it is the one set already (`now`: what the field last committed,
 * or as drawn).
 */
export function commitOf(text: string, moved: number | null, now: { value: OptionValue | null; set: Field['set'] }): Commit {
  if (moved !== null) return moved !== 0 ? { by: moved } : null;
  if (text.trim() === '') return now.set !== 'none' ? 'reset' : null;
  const to = Number(text);
  if (Number.isNaN(to)) return null;
  if (now.value !== null && now.set === 'all' && to === now.value) return null;
  return { to };
}

/** A refusal's words, or an error's message. */
function reasonOf(err: unknown): string {
  const refused = (err as { body?: { refused?: unknown } } | null)?.body?.refused;
  return typeof refused === 'string' ? refused : err instanceof Error ? err.message : String(err);
}

// ---------------------------------------------------------------- the block

/** What the block is drawn from, and what it calls. */
export interface OptionsBlockSpec {
  /** The fields, as planned; null while a record is read. */
  fields: readonly Field[] | null;
  /** A line under the block's title: whose options these are. */
  about?: string;
  /** In place of fields: why there are none -- "their recipes differ". */
  none?: string;
  /** Problems with what is written: a record that does not parse. */
  problems?: readonly string[];
  /** A folder's options whose default is the format's: said under the field. */
  byFormat?: Readonly<Record<string, string>>;
  /** May it be changed: read mode and bundle view show the values, no control that writes. */
  writes: boolean;
  /** A field changed: to a value, moved by `by` (a number of several that differ, scrubbed or stepped), or taken off (undefined). */
  change(field: Field, to: OptionValue | { by: number } | undefined): void;
  /** Reset all: every option taken off where it is set. */
  resetAll(): void;
  /** A value offered and refused, said under its field (`why`), or a field saying none any more (null): the import sheet holds Import on it. */
  refused?(field: Field, why: string | null): void;
}

/** What one field's row needs of the block it is in: the import sheet's rows are drawn by it too. */
export type RowSpec = Pick<OptionsBlockSpec, 'writes' | 'change' | 'byFormat' | 'refused'>;

/** A block the panel is not built again under while it is typed in or scrubbed: the Options block, a prefab's Root block. */
export interface Holding {
  /** A number or a text of it typed in, or a field scrubbed: the panel is not built again under it. */
  holding(): boolean;
  /** Told once it lets go: the focus gone from its typing, the scrub ended. */
  onLetGo(fn: () => void): void;
}

export interface OptionsBlock extends Holding {
  /** The block, an `ed-component` "Options". */
  readonly root: HTMLElement;
}

/** A field's label: its name, and its unit. */
const labelOf = (field: Field): string => `${field.name}${field.schema.unit ? ` (${field.schema.unit})` : ''}`;

/** Is this a control typed in -- a number, a text -- and not a tick, a list or a button: what holds the panel while it has the focus. */
const typedIn = (node: Element | null): boolean => node instanceof HTMLInputElement && node.type !== 'checkbox';

/** What a control of an option is known by across the panel's redraws: the focus goes back to it (`data-focus`). */
const focusKey = (node: HTMLElement, key: string): void => void (node.dataset.focus = key);

/**
 * `root` held while typed in or scrubbed: a tick, a list, a ↺ focused hold
 * nothing -- the panel is drawn again round them, and the focus goes back to
 * the control it was on (the inspector's `data-focus`).
 */
export function holdWhileTyped(root: HTMLElement): Holding {
  let pressed = false;
  let letGo: (() => void) | null = null;
  const holding = (): boolean => pressed || (root.contains(document.activeElement) && typedIn(document.activeElement));
  const maybeLetGo = (): void => {
    queueMicrotask(() => {
      if (!holding()) letGo?.();
    });
  };
  root.addEventListener('focusout', maybeLetGo);
  root.addEventListener('pointerdown', () => {
    pressed = true;
    const up = (): void => {
      pressed = false;
      removeEventListener('pointerup', up, true);
      removeEventListener('pointercancel', up, true);
      maybeLetGo();
    };
    addEventListener('pointerup', up, true);
    addEventListener('pointercancel', up, true);
  }, true);
  return { holding, onLetGo: (fn) => void (letGo = fn) };
}

export function optionsBlock(spec: OptionsBlockSpec): OptionsBlock {
  const root = el('div', 'ed-component ed-as-block ed-as-options');
  root.append(el('div', 'ed-component-head', 'Options'));
  if (spec.about) root.append(el('div', 'ed-dim ed-as-options-about', spec.about));
  for (const problem of spec.problems ?? []) root.append(el('div', 'ed-as-reason ed-as-red', problem));
  const block: OptionsBlock = { root, ...holdWhileTyped(root) };

  if (spec.none) {
    root.append(el('div', 'ed-dim', spec.none));
    return block;
  }
  if (spec.fields === null) {
    root.append(el('div', 'ed-dim', 'reading…'));
    return block;
  }
  const grid = el('div', 'ed-as-opts');
  for (const field of spec.fields) grid.append(...optionRow(field, spec, spec.fields));
  root.append(grid);
  if (spec.writes && spec.fields.some((f) => f.set !== 'none')) {
    const reset = button('asset_options', 'Reset all', 'Every option set here taken off: the defaults, and the folders\', apply again -- one step, Z undoes it', () => spec.resetAll(), 'ed-small ed-quiet ed-as-reset-all');
    focusKey(reset, 'opt::reset-all');
    root.append(reset);
  }
  return block;
}

/**
 * The Options block asked to be shown and lit (the Model tab's All options…, Docs/modeler.md M41): pending
 * until a draw of that file's block **with its fields read** -- a block still "reading…" is drawn again as
 * its records come -- then held for `HOLD_MS`, so each redraw in that time (the preview, the stats, a run
 * arriving rebuild the panel) scrolls to it and lights it again. `draw` answers what that draw does:
 * `first` (scroll smoothly, light), `again` (scroll at once, keep it lit), or null.
 */
export interface FlashWant {
  want(path: string, now: number): void;
  draw(path: string, fieldsRead: boolean, now: number): 'first' | 'again' | null;
}

export const FLASH_HOLD_MS = 2500;
/** A want never met (the file's block never drawn with its fields) is let go after this. */
export const FLASH_WAIT_MS = 10_000;

export function flashWant(): FlashWant {
  let path: string | null = null;
  let asked = 0;
  let shown: number | null = null;
  return {
    want(p, now) {
      path = p;
      asked = now;
      shown = null;
    },
    draw(p, fieldsRead, now) {
      if (path === null || p !== path) return null;
      if (shown === null) {
        if (now - asked > FLASH_WAIT_MS) {
          path = null;
          return null;
        }
        if (!fieldsRead) return null;
        shown = now;
        return 'first';
      }
      if (now - shown > FLASH_HOLD_MS) {
        path = null;
        return null;
      }
      return fieldsRead ? 'again' : null;
    },
  };
}

/**
 * A field's cells: its label, its control, its Reset, and a line under it when
 * there is something to say. The Options block's rows, and the import sheet's.
 */
export function optionRow(field: Field, spec: RowSpec, all: readonly Field[] = []): HTMLElement[] {
  const { schema } = field;
  // A knob of another option's choice (a cull method's): dimmed, and said, while that choice is another.
  const by = schema.when ? all.find((f) => f.name === schema.when!.option) : undefined;
  const off = schema.when !== undefined && by !== undefined && by.value !== null && !schema.when.values.includes(String(by.value));
  const where = field.from ? ` from ${fromSourceRoot(field.from)}` : '';
  const fallback = field.inherited === null ? (spec.byFormat?.[field.name] ?? 'differs') : `${sayValue(field.inherited)}${where || ' (the default)'}`;
  const title = `${schema.help}\nWith it not set here: ${fallback}.`;
  const grey = field.set === 'none';
  /** The line under the field: why a value is refused before it is sent, a value refused by hand, where its default comes from. */
  const under = el('div', 'ed-as-opt-under');
  const say = (text: string | null, bad: boolean): void => {
    under.replaceChildren();
    under.hidden = text === null;
    if (text !== null) under.append(el('span', bad ? 'ed-as-red' : 'ed-dim', text));
  };
  let refusing = false;
  const settled = (): void => {
    if (refusing) {
      refusing = false;
      spec.refused?.(field, null);
    }
    if (field.problem) return say(field.problem, true);
    if (off) return say(`applies with ${schema.when!.option} ${schema.when!.values.join(' or ')}`, false);
    if (grey && field.from) return say(`default ${sayValue(field.inherited!)}${where}`, false);
    if (grey && field.inherited === null && spec.byFormat?.[field.name]) return say(spec.byFormat[field.name]!, false);
    say(null, false);
  };
  settled();
  /** A value from the control: refused in `checkOptions`' words, or changed. */
  const offer = (to: OptionValue): void => {
    const no = refusalOf(field, to);
    if (no) {
      refusing = true;
      spec.refused?.(field, no);
      return say(no, true);
    }
    settled();
    spec.change(field, to);
  };

  let label: HTMLElement;
  let control: HTMLElement;
  if (schema.type === 'number') {
    const fallbackNumber = typeof field.inherited === 'number' ? field.inherited : undefined;
    let moved: number | null = null;
    /** What the field last committed -- or as drawn: a commit of the same again sends nothing. */
    const now: { value: OptionValue | null; set: Field['set'] } = { value: field.value, set: field.set };
    const number = numberField({
      label: labelOf(field),
      value: field.value === null ? null : grey ? undefined : (field.value as number),
      ...(field.note !== undefined ? { note: field.note } : {}),
      step: schema.step ?? 1,
      ...(schema.min !== undefined ? { min: schema.min } : {}),
      ...(schema.max !== undefined ? { max: schema.max } : {}),
      title,
      ...(field.inherited !== null ? { placeholder: sayValue(field.inherited) } : {}),
      ...(fallbackNumber !== undefined ? { fallback: fallbackNumber } : {}),
      fixed: !spec.writes,
      set: () => void (moved = null),
      move: (by) => void (moved = by),
      commit: () => {
        // Read from the field as it is now: emptied is a Reset, never the last value typed before it was emptied.
        const done = commitOf(number.input.value, moved, now);
        moved = null;
        if (done === null) return;
        if (done === 'reset') {
          now.value = field.inherited;
          now.set = 'none';
          settled();
          return spec.change(field, undefined);
        }
        if ('by' in done) return spec.change(field, done);
        if (refusalOf(field, done.to) === undefined) {
          now.value = done.to;
          now.set = 'all';
        }
        offer(done.to);
      },
    });
    focusKey(number.input, `opt:${field.name}`);
    label = number.label;
    control = el('span');
    control.hidden = true;
  } else {
    label = el('span', 'ed-scrub ed-fixed', labelOf(field));
    label.title = title;
    if (schema.type === 'boolean') {
      const tick = el('input', grey ? 'ed-as-default' : undefined);
      tick.type = 'checkbox';
      tick.checked = field.value === true;
      tick.indeterminate = field.value === null;
      tick.title = field.note ? `${title}\n${field.note}` : title;
      tick.disabled = !spec.writes;
      focusKey(tick, `opt:${field.name}`);
      tick.addEventListener('change', () => offer(tick.checked));
      control = el('label', 'ed-as-opt-tick');
      control.append(tick, el('span', 'ed-dim', field.value === null ? MIXED : grey && !field.from ? 'default' : ''));
    } else if (schema.type === 'enum') {
      const pick = el('select', `ed-input${grey ? ' ed-as-default' : ''}`);
      if (field.value === null) {
        const o = el('option', undefined, MIXED);
        o.value = '';
        o.disabled = true;
        pick.append(o);
      }
      for (const v of schema.values ?? []) {
        const o = el('option', undefined, field.inherited !== null && v === field.inherited ? `${v} (${field.from ? `from ${fromSourceRoot(field.from)}` : 'default'})` : v);
        o.value = v;
        pick.append(o);
      }
      pick.value = field.value === null ? '' : String(field.value);
      pick.title = field.note ? `${title}\n${field.note}` : title;
      pick.disabled = !spec.writes;
      focusKey(pick, `opt:${field.name}`);
      pick.addEventListener('change', () => offer(pick.value));
      control = pick;
    } else {
      control = mapControl(field, spec.writes, title, offer);
    }
  }
  const reset = el('span', 'ed-as-opt-reset');
  if (spec.writes && field.set !== 'none') {
    const b = button('asset_options', '↺', `Reset ${field.name}: ${fallback} applies again${field.set === 'some' ? ' -- on those that set it' : ''}; Z undoes it`, () => spec.change(field, undefined), 'ed-small ed-quiet');
    focusKey(b, `opt:${field.name}:reset`);
    reset.append(b);
  } else if (!spec.writes && grey && (schema.type === 'number' || schema.type === 'map')) {
    // Read mode: every control is grey, so a default says it is one -- a value set here has no such word.
    reset.append(el('span', 'ed-dim ed-as-small', 'default'));
  }
  if (off) for (const cell of [label, control, reset]) cell.classList.add('ed-as-opt-off');
  return [label, control, reset, under];
}

/** A map (`params`): a name and a value a pair, each a text line; an empty pair at the end adds one. Changed, the whole map is offered. */
function mapControl(field: Field, writes: boolean, title: string, offer: (to: OptionValue) => void): HTMLElement {
  const list = el('div', 'ed-as-opt-map');
  // Several that differ: a pair typed is added to each one's map, the rest of each kept (`optionWrites`).
  list.title = field.note ? `${title}\n${field.note}\nA pair typed here is added to each one's.` : title;
  const pairs: Array<{ key: HTMLInputElement; value: HTMLInputElement }> = [];
  const current = field.value !== null && typeof field.value === 'object' ? Object.entries(field.value) : [];
  const read = (): Record<string, string> => {
    const out: Record<string, string> = {};
    // A pair with a name and a value: one half typed so far is no change yet.
    for (const { key, value } of pairs) if (key.value.trim() !== '' && value.value !== '') out[key.value.trim()] = value.value;
    return out;
  };
  const changed = (): void => {
    const map = read();
    if (field.value !== null && canonical(map) === canonical(field.value)) return;
    offer(map);
  };
  const row = (k: string, v: string): void => {
    const key = textInput(k, field.value === null && pairs.length === 0 ? MIXED : 'name');
    const value = textInput(v, 'value');
    key.disabled = value.disabled = !writes;
    focusKey(key, `opt:${field.name}:k${pairs.length}`);
    focusKey(value, `opt:${field.name}:v${pairs.length}`);
    for (const input of [key, value]) input.addEventListener('change', changed);
    const line = el('form', 'ed-as-opt-pair');
    line.noValidate = true;
    line.addEventListener('submit', (event) => {
      event.preventDefault();
      (document.activeElement as HTMLElement | null)?.blur?.();
    });
    // Two fields: Enter submits only with a button to submit (implicit submission), hidden -- then lets go of the field.
    const enter = control('ui');
    enter.type = 'submit';
    enter.hidden = true;
    enter.tabIndex = -1;
    line.append(key, el('span', 'ed-dim', '='), value, enter);
    if (writes && k !== '') {
      const off = button('asset_options', '×', `Take ${k} off`, () => {
        key.value = '';
        changed();
      }, 'ed-small ed-quiet');
      focusKey(off, `opt:${field.name}:x${pairs.length}`);
      line.append(off);
    }
    pairs.push({ key, value });
    list.append(line);
  };
  for (const [k, v] of current) row(k, v);
  if (writes) row('', '');
  else if (current.length === 0) list.append(el('span', 'ed-dim', field.value === null ? MIXED : 'none'));
  return list;
}
