/**
 * The Assets tool's selection, its own (Docs/assets-tool.md §4): paths, not
 * entities -- the editor's `Selection` is typed to entities and tells every
 * tool; the Scene tab's one selection across its sides is the host's
 * (`ctx.chose`). What a tile's drag carries (`draggedPaths`). What a
 * click, a key or a box asks of it, on `selection.ts`'s own rules (`clickHow`,
 * `boxHow`, `rangeOf`, `combined`); what a folder row takes (`folderTakes`),
 * the one rule the menu, the keys and the hint read; why a drag cannot drop
 * where it is (`moveRefused`, `importRefused`), said as it passes; and where a
 * path is shown -- `folderOf`, `nearestFolder`, `shownAt`, `isFolderPath` --
 * so the files card never opens a folder the index lacks. What the inspector
 * shows while locked (`pinnedShowing`), and ◂ ▸ over it (`stepPinned`).
 *
 * Pure: node tests it (`files-selection.test.ts`).
 */
import { KINDS, ROOTS, TRASH, type KindName } from '@vibe/pipeline/kinds';
import { baseName, dirName, fromTrash, joinPath, locate, under } from '@vibe/pipeline/paths';
import { combined, rangeOf, type ClickHow, type Combine } from '../../selection.ts';
import type { Entry } from '@vibe/pipeline/assets-types';
import { PROJECT, type ClientIndex, type Shown } from '../model.ts';
import type { Naming } from './naming.ts';
import { shownOf } from '../../inspector-lock.ts';

/** What the Assets inspector shows: a file, several -- `at` the one previewed -- a folder, or, locked, what it pinned removed. */
export type Showing = { kind: 'file'; path: string } | { kind: 'many'; paths: readonly string[]; at: string } | { kind: 'folder'; path: string } | { kind: 'gone' };

/** What is chosen in the files card: every path, the first shown (`primary`), and the one the keys go on from (`latest`). */
export interface PathSelection {
  readonly paths: readonly string[];
  /** The one the inspector shows, the range's anchor: the first chosen. */
  readonly primary: string | null;
  /** The one chosen last: the keys walk on from it. */
  readonly latest: string | null;
}

export const NO_PATHS: PathSelection = { paths: [], primary: null, latest: null };

/** These, the first the primary, `latest` the one the keys go on from (the first, if it is not among them). */
export function chosen(paths: readonly string[], latest?: string | null): PathSelection {
  const unique = [...new Set(paths)];
  const first = unique[0] ?? null;
  return { paths: unique, primary: first, latest: latest !== undefined && latest !== null && unique.includes(latest) ? latest : first };
}

/**
 * A click on `path`, as `how` asks -- `clickHow(event, true)`: alone, it alone;
 * Mod, in or out; Shift, the range from the primary in the order shown (`rangeOf`),
 * the primary kept first; Mod and Shift, that range added (`combined`). A
 * range with nothing chosen, or from a path not shown, is `path` alone.
 */
export function clickOnPath(selection: PathSelection, path: string, how: ClickHow, shown: readonly string[]): PathSelection {
  if (how === 'range' || how === 'add-range') {
    const range = selection.primary === null ? null : rangeOf(shown, selection.primary, path);
    if (!range) return chosen([path]);
    return chosen(how === 'range' ? range : combined(selection.paths, range, 'add'), path);
  }
  if (how === 'toggle') {
    if (selection.paths.includes(path)) {
      const rest = selection.paths.filter((p) => p !== path);
      return chosen(rest, selection.latest === path ? rest[rest.length - 1] : selection.latest);
    }
    return chosen([...selection.paths, path], path);
  }
  if (how === 'add') return chosen(combined(selection.paths, [path], 'add'), path);
  return chosen([path]);
}

/** Several at once -- a box, Select all -- as `boxHow` says: in place of what is, added, or each turned over. */
export function choosePaths(selection: PathSelection, these: readonly string[], how: Combine): PathSelection {
  return chosen(combined(selection.paths, these, how), these[0] ?? selection.latest);
}

/**
 * An arrow key: the file `by` on from the one the keys go from (`latest`) --
 * a row of tiles at a time, `by` a row's count -- held to the first and the
 * last. With nothing chosen, the first going down, the last going up.
 * `extend` (Shift): the range from the primary to it, as the Finder and
 * Explorer do, the primary kept first.
 */
export function stepOn(selection: PathSelection, by: number, shown: readonly string[], extend = false): PathSelection {
  if (shown.length === 0) return selection;
  const from = selection.latest !== null && shown.includes(selection.latest) ? selection.latest : selection.primary;
  const at = from === null ? -1 : shown.indexOf(from);
  const next = at < 0 ? (by > 0 ? 0 : shown.length - 1) : Math.max(0, Math.min(shown.length - 1, at + by));
  const to = shown[next]!;
  if (!extend || selection.primary === null || !shown.includes(selection.primary)) return chosen([to]);
  return chosen(rangeOf(shown, selection.primary, to) ?? [to], to);
}

/**
 * Of several chosen, the one the inspector previews (§6, "Several selected"):
 * the one stepped to (`at`) while it is chosen, else the first -- the primary.
 */
export function previewedOf(selection: PathSelection, at: string | null): string | null {
  return at !== null && selection.paths.includes(at) ? at : selection.primary;
}

/**
 * ◂ ▸ over several chosen: the one previewed stepped `by`, round them in the
 * order chosen. It becomes `latest`, so the keys walk on from it; what is
 * chosen, and the primary, stay as they are. One or none chosen: as it was.
 */
export function stepPreviewed(selection: PathSelection, at: string | null, by: 1 | -1): { selection: PathSelection; at: string | null } {
  const { paths } = selection;
  if (paths.length < 2) return { selection, at };
  const now = paths.indexOf(previewedOf(selection, at)!);
  const to = paths[(now + by + paths.length) % paths.length]!;
  return { selection: { ...selection, latest: to }, at: to };
}

/**
 * What a tile's drag carries: the selection, if the pressed tile is in it; else that tile alone -- not chosen
 * for it: a drag never changes what is chosen, nor what the inspector shows (Docs/assets-tool.md §4).
 */
export function draggedPaths(selection: PathSelection, path: string): readonly string[] {
  return selection.paths.includes(path) ? selection.paths : [path];
}

/**
 * Locked, what the inspector shows of what it pinned (`shownOf`): the paths still there (`has`), a deleted one
 * dropped -- several becoming one, that one a file or a folder (`isFolder`, or pinned as the open folder); `at`
 * kept while it is there, else the first; every one gone, `gone`.
 */
export function pinnedShowing(pinned: Showing, has: (path: string) => boolean, isFolder: (path: string) => boolean): Showing {
  if (pinned.kind === 'gone') return pinned;
  const paths = pinned.kind === 'many' ? pinned.paths : [pinned.path];
  const { subject } = shownOf([], paths, (p) => (has(p) ? p : null));
  if (subject.length === 0) return { kind: 'gone' };
  if (pinned.kind === 'many' && subject.length > 1) return { kind: 'many', paths: subject, at: subject.includes(pinned.at) ? pinned.at : subject[0]! };
  const one = subject[0]!;
  return pinned.kind === 'folder' || isFolder(one) ? { kind: 'folder', path: one } : { kind: 'file', path: one };
}

/**
 * ◂ ▸ locked on several: the one previewed stepped `by` among those pinned still there (`has`) -- never onto a
 * deleted one -- from where `pinnedShowing` shows it. The pin's paths kept as they are; anything but several still
 * there, as it was.
 */
export function stepPinned(pinned: Showing, has: (path: string) => boolean, by: 1 | -1): Showing {
  if (pinned.kind !== 'many') return pinned;
  const there = pinned.paths.filter(has);
  if (there.length < 2) return pinned;
  const at = there.includes(pinned.at) ? pinned.at : there[0]!;
  return { ...pinned, at: stepPreviewed(chosen(there), at, by).at ?? at };
}

/** Only the paths still there (`has`): one a change removed, dropped -- the primary too, the next taking its place. */
export function stillThere(selection: PathSelection, has: (path: string) => boolean): PathSelection {
  if (selection.paths.every(has)) return selection;
  return chosen(selection.paths.filter(has), selection.latest !== null && has(selection.latest) ? selection.latest : undefined);
}

// ---------------------------------------------------------------- where a path is shown

/**
 * The folder whose list has `path` in it -- what to open to show it chosen: a
 * trashed file's slot (a slot's files are listed flat in it, never under the
 * folders of the path they had), any other's the folder it is in.
 */
export function folderOf(path: string): string {
  const trashed = fromTrash(path);
  return trashed ? `${TRASH}/${trashed.slot}` : dirName(path);
}

/**
 * `folder` if the index `has` it, else the nearest folder up from it that it
 * has -- a folder removed on disk, a kept preference the index no longer
 * knows -- the project (`''`) last, which every tree has; else, for one that
 * has not even that, `fallback`: the files card shows only folders that are.
 */
export function nearestFolder(folder: string, has: (path: string) => boolean, fallback: string): string {
  for (let at = folder; ; at = dirName(at)) {
    if (has(at)) return at;
    if (at === PROJECT) return fallback;
  }
}

/** The index's row at `path`: its entry, or a file in a trash slot (which has none); undefined for neither. */
export function shownAt(index: Pick<ClientIndex, 'entries' | 'childrenOf'>, path: string): Shown | undefined {
  const entry = index.entries.get(path);
  if (entry) return entry;
  const trashed = fromTrash(path);
  return trashed ? index.childrenOf(`${TRASH}/${trashed.slot}`).files.find((f) => f.path === path) : undefined;
}

/** Is `path` a folder of the index's -- listed in the tree, and no file -- rather than a file? */
export function isFolderPath(index: Pick<ClientIndex, 'entries' | 'tree'>, path: string): boolean {
  return !index.entries.has(path) && index.tree().has(path);
}

// ---------------------------------------------------------------- what a folder row takes

/** What may be done to a folder from its row, by menu or by key; and why not, for the hint. */
export interface Takes {
  /** Rename, Delete, Duplicate, Move: none for the project, a root, a kind's own folder or a trash slot. */
  rename: boolean;
  delete: boolean;
  move: boolean;
  /** New folder in it: a folder, a pack (under Packs), or none (the project, the Trash and its slots). */
  newFolder: 'folder' | 'pack' | null;
  /** Files from the desktop import here: every folder but the project, the Trash, its slots, and the packs' homes (a pack is a folder of its own). */
  import: boolean;
  /** Export all stale under it: every folder but the Trash's -- the project's, every source there is. */
  exportStale: boolean;
  /** The Trash root's: Empty, Restore all. A slot's: Restore. */
  empty: boolean;
  restoreAll: boolean;
  restore: boolean;
  /** Why Rename, Delete and Move are not here, in the hint's words; null where they are. */
  why: string | null;
}

/** The roots' folders. */
const ROOT_DIRS: readonly string[] = Object.values(ROOTS).map((root) => root.dir);

/** The folders the pipeline itself goes by: each kind's (`models`, `audio/sfx`) and what holds them (`audio`), in any root or pack; the packs' and reference's homes. */
function ownFolder(path: string): boolean {
  if (path === ROOTS.packs.source || path === ROOTS.source.reference) return true;
  const where = locate(path);
  if (!where || where.reference) return false;
  let rel = where.rel;
  if (where.pack !== undefined) {
    // Under a pack: the pack's own folder is the pack's to rename; its kinds are below it.
    const home = where.root === 'packs' ? ROOTS.packs.dir : ROOTS.packs.source;
    const inPack = path.slice(home.length + 1);
    const slash = inPack.indexOf('/');
    if (slash < 0) return false;
    rel = inPack.slice(slash + 1);
  }
  return Object.values(KINDS).some((kind) => kind.dir === rel || kind.dir.startsWith(rel + '/'));
}

/** Why the project row takes no write: what the hint says, and the menu leaves out. */
export const PROJECT_WHY = 'the project itself: its roots take files';

/**
 * What a folder row takes (§3, "Roots and slots"): the project takes no
 * write -- no Rename, Delete, Move, New folder or import, its roots take
 * files -- but Export all stale, of everything; a root -- Source, Assets,
 * Packs, the Trash, a game's -- and a trash slot have no Rename, Delete,
 * Duplicate or Move, nor has a folder the pipeline goes by (a kind's, the
 * packs' and reference's homes); New folder under Packs makes a pack, and
 * under the Trash there is none; Export all stale is on every folder but the
 * Trash's; the Trash has Empty and Restore all, a slot Restore. `title` is
 * the row's own, for the words.
 */
export function folderTakes(path: string, title = baseName(path)): Takes {
  if (path === PROJECT) {
    return { rename: false, delete: false, move: false, newFolder: null, import: false, exportStale: true, empty: false, restoreAll: false, restore: false, why: PROJECT_WHY };
  }
  const trash = path === TRASH;
  const slot = dirName(path) === TRASH && !trash;
  const root = ROOT_DIRS.includes(path) || trash;
  const own = !root && !slot && ownFolder(path);
  const fixed = root || slot || own;
  const why = slot
    ? 'a trash slot is restored or emptied, not renamed'
    : root
      ? `${title} is a root: its folders can be renamed, not it`
      : own
        ? `${title}/ is a folder the pipeline goes by: the folders under it can be renamed, not it`
        : null;
  return {
    rename: !fixed,
    delete: !fixed,
    move: !fixed,
    newFolder: trash || slot || under(path, TRASH) ? null : path === ROOTS.packs.dir ? 'pack' : 'folder',
    import: !under(path, TRASH) && path !== ROOTS.packs.dir && path !== ROOTS.packs.source,
    exportStale: !under(path, TRASH),
    empty: trash,
    restoreAll: trash,
    restore: slot,
    why,
  };
}

// ---------------------------------------------------------------- why a drag cannot drop here

/** A kind as one of it, and as many: "a model", "textures". */
const KIND_WORDS: Readonly<Record<KindName, readonly [string, string]>> = {
  models: ['a model', 'models'],
  textures: ['a texture', 'textures'],
  atlases: ['a sprite sheet', 'sprite sheets'],
  icons: ['an icon', 'icons'],
  fonts: ['a font', 'fonts'],
  sfx: ['a sound', 'sounds'],
  uiSfx: ['a UI sound', 'UI sounds'],
  music: ['music', 'music'],
  levels: ['a level', 'levels'],
  prefabs: ['a prefab', 'prefabs'],
  scenes: ['a scene', 'scenes'],
  materials: ['a material', 'materials'],
};

/** A folder as the refusals say it: its path under its root, `textures/props/` -- a root by its title. */
function folderWords(folder: string, naming: Pick<Naming, 'rootOf' | 'title'>): string {
  const root = naming.rootOf(folder);
  return root === undefined || root === folder ? naming.title(folder) : `${folder.slice(root.length + 1)}/`;
}

/** Where a drop on the project goes instead, in the refusal's words: "drop it on a root's folder: Source, Assets or a pack". */
export function projectRefusal(naming: Pick<Naming, 'title'>): string {
  return `drop it on a root's folder: ${naming.title(ROOTS.source.dir)}, ${naming.title(ROOTS.boot.dir)} or a pack`;
}

/** Why files from the desktop cannot be imported into `folder` (§3, §5.1), or null. */
export function importRefused(folder: string, naming: Pick<Naming, 'rootOf' | 'title'>): string | null {
  if (folder === PROJECT) return `Can't import here: ${projectRefusal(naming)}`;
  if (under(folder, TRASH)) return 'Can\'t import here: the trash holds what Delete sent it';
  if (!folderTakes(folder).import) return `Can't import here: ${folderWords(folder, naming)} holds packs -- drop into one, or make one with New folder`;
  return null;
}

/**
 * The family each path moves or copies as (§A.6, "What moves together"),
 * once: a source itself; an export's, a record's or an intermediate's
 * source; a part its owner's, where that is among them too -- so a model and
 * its texture dragged together are one move. A part whose owners are not all
 * among them stays itself: `partAlone` refuses it.
 */
export function familyHeads(paths: readonly string[], entries: ReadonlyMap<string, Entry>): string[] {
  const heads = paths.map((p) => {
    const e = entries.get(p);
    return e && (e.role === 'export' || e.role === 'intermediate' || e.role === 'record') && e.source !== undefined && entries.has(e.source) ? e.source : p;
  });
  const dragged = new Set(heads);
  return [...new Set(heads.map((h) => {
    const e = entries.get(h);
    return e?.role === 'part' ? ((e.owners ?? []).find((o) => dragged.has(o)) ?? h) : h;
  }))];
}

/**
 * A part among `paths` whose model is not -- every owner of it, or the
 * families of them -- with its owners: moved, copied or duplicated alone,
 * the server refuses it ("robot-diffuse.png is part of robot.fbx: move it with
 * its model"), so the tool says so first. Null if none is.
 */
export function partAlone(paths: readonly string[], entries: ReadonlyMap<string, Entry>): { part: string; owners: readonly string[] } | null {
  const heads = new Set(familyHeads(paths, entries));
  for (const p of paths) {
    const e = entries.get(p);
    const owners = e?.role === 'part' ? (e.owners ?? []) : [];
    if (owners.length > 0 && !owners.every((o) => heads.has(o))) return { part: p, owners };
  }
  return null;
}

/**
 * Why `paths` -- files, folders, trashed files -- cannot be dropped on
 * `folder` (§3, "Drop targets"), or null: the project (a root's folder takes
 * them), the Trash (Delete is the way there), the folder they are in, another kind's folder, `reference/` from
 * outside it or out of it, a folder into itself or one the pipeline goes by,
 * a part without its model (`partAlone`). The first path refused is the one
 * said: "Can't move here: crate.lua is a model, and textures/props/ takes
 * textures". With `copy`, the same for Copy to…, but for its own folder: a
 * copy there is a duplicate.
 */
export function moveRefused(paths: readonly string[], folder: string, index: Pick<ClientIndex, 'entries' | 'tree'>, naming: Pick<Naming, 'rootOf' | 'title'>, copy = false): string | null {
  const verb = copy ? 'copy' : 'move';
  if (folder === PROJECT) return `Can't ${verb} here: ${projectRefusal(naming)}`;
  if (under(folder, TRASH)) return `Can't ${verb} here: the trash takes what Delete sends it -- Delete is the way there`;
  const to = locate(joinPath(folder, 'x'));
  const where = folderWords(folder, naming);
  const alone = partAlone(paths.filter((p) => fromTrash(p) === undefined), index.entries);
  for (const path of paths) {
    const trashed = fromTrash(path);
    const was = trashed?.path ?? path;
    const name = baseName(was);
    const folderMoving = !trashed && isFolderPath(index, path);
    // A copy into its own folder is a duplicate.
    if (!trashed && !copy && dirName(path) === folder) return `Can't move here: ${name} is in ${where} already`;
    if (alone?.part === path) return `Can't ${verb} here: ${name} is part of ${alone.owners.map(baseName).join(', ')} -- ${copy ? 'copy its model, and it comes too' : 'move its model, and it goes with it'}`;
    if (folderMoving && under(folder, path)) return `Can't ${verb} here: ${name}/ would go into itself`;
    if (folderMoving) {
      const takes = folderTakes(path, name);
      if (!takes.move) return `Can't ${verb} here: ${takes.why}`;
    }
    const from = locate(folderMoving ? joinPath(path, 'x') : was);
    if (from?.reference !== to?.reference) {
      return to?.reference ? `Can't ${verb} here: reference/ holds what nothing is made from -- import a copy there` : `Can't ${verb} here: ${name} is reference, which nothing is made from`;
    }
    if (from?.reference) continue;
    if (from?.kind === undefined) continue;
    if (to?.kind === undefined) return `Can't ${verb} here: ${where} is no kind's folder -- ${name} goes under ${KINDS[from.kind].dir}/`;
    if (to.kind !== from.kind) return `Can't ${verb} here: ${name} is ${KIND_WORDS[from.kind][0]}, and ${where} takes ${KIND_WORDS[to.kind][1]}`;
  }
  return null;
}
