/**
 * The files card's columns, its one sort and its grid's geometry
 * (Docs/assets-tool.md §4, §12), as the entity tree's `columns.ts` has its own:
 *
 * - **`FILE_COLUMNS`**: what the list shows past the name -- Build (a tick:
 *   in the build or not, `marks.ts`' `tickOf`), Status, Role, Kind, Size,
 *   Export size, Key, Twin (a link to the twin, `Cell.link`), Modified -- each a row of its own: a name it is
 *   kept by, a title, a width, and a `cell` for any row, an index entry or a
 *   file in a trash slot. A cell with nothing to say reads `—`, so it reads as
 *   none and not as not loaded yet. A game adds one as a row.
 * - **`fileGrid`**: one CSS grid for the header and every row, so the columns
 *   line up down the list.
 * - **`sortEntries`**: the one sort -- by name, status (what needs a hand
 *   first), size, modified or kind -- folders first, always; ties by name.
 * - **`gridLayout`, `tilesIn`**: where each tile of the grid is, from the
 *   card's width, and which a box drawn over the grid takes -- those not drawn
 *   included.
 * - **`thumbSize`, `wantOrder`**: the thumbnail a tile draws, sharp on a
 *   screen of two pixels a point; and the order they are made in -- what is
 *   chosen first, then the tiles in view, then the rest of the folder.
 *
 * Pure: node tests it (`files-columns.test.ts`).
 */
import type { Entry, Status } from '@vibe/pipeline/assets-types';
import { KINDS } from '@vibe/pipeline/kinds';
import { baseName, fromTrash, locate } from '@vibe/pipeline/paths';
import { entryKey } from '@vibe/pipeline/code-naming';
import { STRIP_MIN, THUMBS, type AssetSort } from '../../prefs.ts';
import { perRowOf, type Span } from '../../virtual.ts';
import type { ThumbWant } from '../preview/thumbs.ts';
import type { Shown } from '../model.ts';
import { sayBytes } from './budget.ts';
import { excludedOf, isEntry, markOf, statusOf, tickOf, type Shows, type Tick } from './marks.ts';

/** What a cell with nothing to say reads: none, not "not loaded yet". */
export const NOTHING = '—';

/** One cell: its text, its hover, and a mark drawn before the text -- or, in a tick's column, the tick (`text` then for a row with none). */
export interface Cell {
  text: string;
  title?: string;
  mark?: Shows;
  tick?: Tick;
  /** A path the cell links to, in a column with `link`: its text a link that shows that file chosen in its folder (the Twin's). */
  link?: string;
}

/** A column of the list past the name. */
export interface FileColumn {
  /** What it is kept by, in the preferences: plain, lowercase. */
  name: string;
  /** Its header, and its line on the chooser -- unless `label` names it there (a glyph's head). */
  title: string;
  /** Its line on the chooser, where its header is a glyph: Build's `☑`. */
  label?: string;
  /** What it is, on hover over the header and on the chooser. */
  help: string;
  /** Its width in the grid: `92px`, `minmax(0, 1fr)`. */
  width: string;
  /** Right-aligned: a number. */
  numeric?: boolean;
  /** A tick's column: its cell is a tick a click flips (`Cell.tick`), its head a glyph. */
  tick?: boolean;
  /** Its cells may be links (`Cell.link`): a click shows that file, never the row's own click. */
  link?: boolean;
  /** What it says for a row; `entries` is the client index, for what a row's family says. */
  cell(row: Shown, entries: ReadonlyMap<string, Entry>): Cell;
}

/** A folder among the rows: it sorts first. */
export interface FolderRow {
  folder: string;
}

/** What the files card lists: the open folder's folders, then its files. */
export type Listed = FolderRow | Shown;

export const isFolder = (row: Listed): row is FolderRow => 'folder' in row;

/** A date as the list says it, to the minute, in this machine's time: `2026-10-04 09:00`. */
export function sayDate(ms: number): string {
  if (!Number.isFinite(ms) || ms <= 0) return NOTHING;
  const d = new Date(ms);
  const two = (n: number): string => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())} ${two(d.getHours())}:${two(d.getMinutes())}`;
}

/** The key a row ships as: an export's or a loose file's own; a source's its export's -- worked out before that exists. */
export function keyOfRow(row: Shown, entries: ReadonlyMap<string, Entry>): string | undefined {
  return isEntry(row) ? entryKey(row, entries) : undefined;
}

/** The other side of a row's family: a source's export, an export's source -- none for any other, nor for a source out of the build, which has no export. */
export function twinOfRow(row: Shown, entries: ReadonlyMap<string, Entry>): string | undefined {
  if (!isEntry(row)) return undefined;
  if (row.role === 'export' || row.role === 'intermediate') return row.source;
  if (row.role !== 'source' || !row.included) return undefined;
  const first = row.exports?.[0];
  return first !== undefined && entries.has(first) ? first : undefined;
}

/** The kind a row is of: its own, or for a file in the trash the one the path it had says. */
export function kindOfRow(row: Shown): string | undefined {
  if (isEntry(row)) return row.kind;
  const had = fromTrash(row.path)?.path;
  return had === undefined ? undefined : locate(had)?.kind;
}

const none: Cell = { text: NOTHING };

export const FILE_COLUMNS: readonly FileColumn[] = [
  {
    name: 'build', title: '☑', label: 'Build', help: 'In the build: ticked, it ships -- a source exported, a loose file under its own name; unticked, a source is never exported and a loose file is named _ (⇧B flips the files chosen)', width: '30px', tick: true,
    cell(row, entries) {
      const tick = tickOf(row, entries);
      return tick ? { text: '', title: tick.stuck ? `${tick.title} -- not now: ${tick.stuck}` : tick.title, tick } : { text: NOTHING, title: isEntry(row) ? 'No tick: it ships under no name it can have (a reference, a record, an extra of no kind\'s)' : 'In the trash: Restore puts it back' };
    },
  },
  {
    name: 'status', title: 'Status', help: 'A source\'s status, and an export its source\'s: what needs a hand, a glyph and a word', width: '112px',
    cell(row, entries) {
      const status = statusOf(row, entries);
      const mark = markOf(row, entries);
      if (!mark) return none;
      // No status of its own but a mark: an `_` name out of the build, or a pointer.
      return { text: status ?? (excludedOf(row, entries) ? 'excluded' : 'pointer'), title: mark.title, mark };
    },
  },
  {
    name: 'role', title: 'Role', help: 'What the file is: source, part, intermediate, export, loose, reference or extra', width: '92px',
    cell: (row) => (isEntry(row) ? { text: row.role } : none),
  },
  {
    name: 'kind', title: 'Kind', help: 'The kind of asset its folder is for: models, textures, sfx…', width: '84px',
    cell(row) {
      const kind = kindOfRow(row);
      return kind === undefined ? none : { text: kind, title: `${kind}: under ${KINDS[kind as keyof typeof KINDS]?.dir ?? kind}/` };
    },
  },
  {
    name: 'size', title: 'Size', help: 'Its bytes on disk', width: '72px', numeric: true,
    cell: (row) => ({ text: sayBytes(row.size), title: `${row.size.toLocaleString('en')} bytes` }),
  },
  {
    name: 'export', title: 'Export size', help: 'A source\'s export\'s bytes: what the game downloads of it', width: '84px', numeric: true,
    cell(row, entries) {
      if (!isEntry(row) || row.role !== 'source') return none;
      const first = row.exports?.[0];
      const made = first !== undefined ? entries.get(first) : undefined;
      return made ? { text: sayBytes(made.size), title: `${baseName(made.path)}: ${made.size.toLocaleString('en')} bytes` } : none;
    },
  },
  {
    name: 'key', title: 'Key', help: 'What the game loads it by: Assets.instance(\'props/crate\'); a pack\'s with its name, reef:props/crate', width: 'minmax(0, 1fr)',
    cell(row, entries) {
      const key = keyOfRow(row, entries);
      if (key === undefined) return none;
      // Out of the build: no key it ships as -- the one it would have, on hover.
      if (isEntry(row) && row.role === 'source' && !row.included) return { text: NOTHING, title: `out of the build: no key -- in it, ${key}` };
      return { text: key, title: isEntry(row) && row.role === 'source' ? `ships as ${key}` : key };
    },
  },
  {
    name: 'twin', title: 'Twin', help: 'The other side of its family: a source\'s export, an export\'s source -- a click shows it, chosen in its folder', width: 'minmax(0, 1fr)', link: true,
    cell(row, entries) {
      const twin = twinOfRow(row, entries);
      return twin === undefined ? none : { text: baseName(twin), title: `${twin}: a click shows it, chosen in its folder`, link: twin };
    },
  },
  {
    name: 'modified', title: 'Modified', help: 'When the file last changed on disk', width: '124px',
    cell: (row) => ({ text: sayDate(row.mtime) }),
  },
];

/** Shown until chosen otherwise: in the build, the status, the size and the key. */
export const DEFAULT_COLUMNS: readonly string[] = ['build', 'status', 'size', 'key'];

/** The columns `names` asks for that `all` has, in `all`'s order, each once: a kept name a game no longer has is dropped. */
export function columnsOf(names: readonly string[], all: readonly FileColumn[] = FILE_COLUMNS): FileColumn[] {
  return all.filter((column) => names.includes(column.name));
}

/** `names` with `name` ticked on, or off if it is on: in `all`'s order either way, those `all` lacks dropped. */
export function flipColumn(names: readonly string[], name: string, all: readonly FileColumn[] = FILE_COLUMNS): string[] {
  const on = names.includes(name) ? names.filter((n) => n !== name) : [...names, name];
  return columnsOf(on, all).map((column) => column.name);
}

/** The least the name is given, in pixels: a glyph and a few words. */
export const NAME_MIN = 140;

/** The grid the header and every row share: the name, then the Folder column for a search's flat list, then each column on, in order. */
export function fileGrid(columns: readonly FileColumn[], folder = false): string {
  return [`minmax(${NAME_MIN}px, 2fr)`, ...(folder ? ['minmax(80px, 1fr)'] : []), ...columns.map((column) => column.width)].join(' ');
}

// ---------------------------------------------------------------- the one sort

/** Status, what needs a hand first: a pointer among them. */
const STATUS_ORDER: readonly (Status | 'pointer')[] = ['failed', 'conflict', 'pointer', 'missing', 'stale', 'unmade', 'checking', 'current', 'reference', 'excluded'];

const lower = (text: string): string => text.toLowerCase();
const byName = (a: string, b: string): number => {
  const x = lower(baseName(a));
  const y = lower(baseName(b));
  return x < y ? -1 : x > y ? 1 : a < b ? -1 : a > b ? 1 : 0;
};

const EMPTY: ReadonlyMap<string, Entry> = new Map();

/**
 * `rows` in the order shown: folders first, always, by name; then the files
 * by `by` -- `down` the other way -- ties by name. Status puts what needs a
 * hand first. A row with nothing to sort by -- a file in the trash by status
 * or kind, a loose file by status -- comes last, in name order, either way.
 */
export function sortEntries(rows: readonly Listed[], by: AssetSort, down: boolean, entries: ReadonlyMap<string, Entry> = EMPTY): Listed[] {
  const folders = rows.filter(isFolder).sort((a, b) => byName(a.folder, b.folder));
  if (by === 'name' && down) folders.reverse();
  const files = rows.filter((row): row is Shown => !isFolder(row));
  /** What a file sorts by, or undefined for nothing: it goes last. */
  const value = (row: Shown): number | string | undefined => {
    switch (by) {
      case 'name':
        return lower(baseName(row.path));
      case 'size':
        return row.size;
      case 'modified':
        return row.mtime;
      case 'kind':
        return isEntry(row) ? row.kind : undefined;
      case 'status': {
        const status = statusOf(row, entries);
        // A pointer among what needs a hand -- but out of the build, which nothing reads, last.
        if (isEntry(row) && row.pointer && status !== 'excluded') return STATUS_ORDER.indexOf('pointer');
        return status === undefined ? undefined : STATUS_ORDER.indexOf(status);
      }
    }
  };
  const keyed = files.map((row) => ({ row, v: value(row) }));
  keyed.sort((a, b) => {
    if (a.v === undefined || b.v === undefined) {
      if (a.v === undefined && b.v === undefined) return byName(a.row.path, b.row.path);
      return a.v === undefined ? 1 : -1;
    }
    const c = a.v < b.v ? -1 : a.v > b.v ? 1 : 0;
    if (c !== 0) return down ? -c : c;
    return byName(a.row.path, b.row.path);
  });
  return [...folders, ...keyed.map((k) => k.row)];
}

// ---------------------------------------------------------------- the grid's geometry

/** A tile's room about its thumbnail, its name's line, its size's line (at 128 and 256), the gap between tiles, the list's edge: CSS pixels. */
export const TILE_PAD = 6;
export const TILE_NAME = 18;
export const TILE_SIZE = 15;
export const TILE_GAP = 10;
export const GRID_EDGE = 10;
/** A row's room over its tiles for their groups' labels, where the grid has groups (the project's: Not shipped, Shipped). */
export const TILE_BAND = 20;

/** Where the grid's tiles are: how many a row, each tile's size, a row's height, the room over each row's tiles for a label, and how many there are. */
export interface GridLayout {
  perRow: number;
  tileWidth: number;
  tileHeight: number;
  rowHeight: number;
  gap: number;
  edge: number;
  /** Over each row's tiles, the room its groups' labels take (`TILE_BAND`); 0 in a grid of no groups. */
  band: number;
  count: number;
}

/** The grid for a card `width` wide, thumbnails `thumb` square, `count` tiles; `band` over each row's, where the tiles are in groups. */
export function gridLayout(width: number, thumb: number, count: number, band = 0): GridLayout {
  const tileWidth = thumb + 2 * TILE_PAD;
  const tileHeight = thumb + 2 * TILE_PAD + TILE_NAME + (thumb >= 128 ? TILE_SIZE : 0);
  return {
    perRow: perRowOf(width - 2 * GRID_EDGE, tileWidth, TILE_GAP),
    tileWidth,
    tileHeight,
    rowHeight: tileHeight + TILE_GAP + band,
    gap: TILE_GAP,
    edge: GRID_EDGE,
    band,
    count,
  };
}

/** Tile `i`'s left edge and top, in the list's own coordinates (it scrolls with them): under its row's band. */
export function tileAt(i: number, layout: GridLayout): { x: number; y: number } {
  const col = i % layout.perRow;
  const row = Math.floor(i / layout.perRow);
  return { x: layout.edge + col * (layout.tileWidth + layout.gap), y: row * layout.rowHeight + layout.band };
}

/** A group's label over its tiles: what it says, and how many tiles of its row it is over. */
export interface GroupLabel {
  group: string;
  span: number;
}

/**
 * The labels over a grid of tiles in groups (§4: the project's roots, Not
 * shipped and Shipped): `groups[i]` is tile i's group, or null for none (the
 * Trash). A label goes over the first tile of a group in each row it is in --
 * again on the next row, where a group wraps -- over as many of that row's
 * tiles as are in it; every other tile has none (null).
 */
export function groupLabels(groups: readonly (string | null)[], perRow: number): (GroupLabel | null)[] {
  const per = Math.max(1, Math.floor(perRow));
  return groups.map((group, i) => {
    if (group === null) return null;
    if (i % per !== 0 && groups[i - 1] === group) return null;
    let span = 1;
    while ((i + span) % per !== 0 && groups[i + span] === group) span++;
    return { group, span };
  });
}

/**
 * The tiles' side in a strip (§2): of `chosen` and the sizes below it, the
 * largest whose tile -- its name and size line too -- fits `room`, the list's
 * height; the smallest if none does. A 240 px strip draws 64s with their names
 * though 128 is chosen; made taller, the 128s come back.
 */
export function stripTile(chosen: number, room: number): number {
  const sizes = THUMBS.filter((size) => size <= chosen).reverse();
  for (const size of sizes) if (gridLayout(1, size, 1).tileHeight <= room) return size;
  return THUMBS[0];
}

/** The strip's least height in the grid: its card's own (`chrome` -- the title row, the status line, padding) and one row of the smallest tiles with their names. */
export function stripMin(chrome: number): number {
  return Math.max(STRIP_MIN, Math.ceil(chrome + gridLayout(1, THUMBS[0], 1).tileHeight));
}

/** A box drawn over the grid, from where it began to where it is, in the list's own coordinates. */
export interface Box {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

/** Every tile the box touches, in order -- those scrolled out of view too, from the geometry alone. A box of no size takes none. */
export function tilesIn(box: Box, layout: GridLayout): number[] {
  const left = Math.min(box.x0, box.x1);
  const right = Math.max(box.x0, box.x1);
  const top = Math.min(box.y0, box.y1);
  const bottom = Math.max(box.y0, box.y1);
  if (right - left <= 0 || bottom - top <= 0 || layout.count === 0) return [];
  const rows = Math.ceil(layout.count / layout.perRow);
  const firstRow = Math.max(0, Math.floor(top / layout.rowHeight));
  const lastRow = Math.min(rows - 1, Math.floor(bottom / layout.rowHeight));
  const out: number[] = [];
  for (let r = firstRow; r <= lastRow; r++) {
    for (let c = 0; c < layout.perRow; c++) {
      const i = r * layout.perRow + c;
      if (i >= layout.count) break;
      const { x, y } = tileAt(i, layout);
      if (x < right && x + layout.tileWidth > left && y < bottom && y + layout.tileHeight > top) out.push(i);
    }
  }
  return out;
}

// ---------------------------------------------------------------- the grid's thumbnails

/** What tells a file's content changed when the index has no hash of it: its size and mtime -- the queue's (`thumbs.ts`). */
export { contentStamp } from '../preview/thumbs.ts';

/** The sizes a thumbnail is made at (§A.5, `GET thumb`). */
export const THUMB_SIZES = [64, 128, 256] as const;

/**
 * The thumbnail a tile `tile` CSS pixels square draws, on a screen of `ratio`
 * device pixels a CSS pixel: the smallest made at least that many device
 * pixels across (two a pixel at most), else the largest -- a 64 tile on a
 * Retina screen draws the 128.
 */
export function thumbSize(tile: number, ratio = 1): number {
  const want = tile * Math.min(2, Math.max(1, ratio));
  return THUMB_SIZES.find((size) => size >= want) ?? THUMB_SIZES[THUMB_SIZES.length - 1];
}

/**
 * The thumbnails to make, in the order to make them (§9): `first` (the
 * preview's own: the model shown, its 256), then each file chosen, then the
 * tiles in view (`view`, items of `shown`) in view order, then the rest of the
 * folder -- each path and size once, and none `want` answers null for (a
 * folder, a file with no picture to be had).
 */
export function wantOrder(shown: readonly string[], view: Span, chosen: readonly string[], want: (path: string) => ThumbWant | null, first: readonly ThumbWant[] = []): ThumbWant[] {
  const out: ThumbWant[] = [];
  const seen = new Set<string>();
  const put = (item: ThumbWant | null): void => {
    if (!item) return;
    const id = `${item.path}\n${item.size}`;
    if (seen.has(id)) return;
    seen.add(id);
    out.push(item);
  };
  for (const item of first) put(item);
  for (const path of chosen) put(want(path));
  const from = Math.max(0, Math.min(view.first, shown.length));
  const to = Math.max(from, Math.min(view.last, shown.length));
  for (let i = from; i < to; i++) put(want(shown[i]!));
  for (let i = to; i < shown.length; i++) put(want(shown[i]!));
  for (let i = 0; i < from; i++) put(want(shown[i]!));
  return out;
}
