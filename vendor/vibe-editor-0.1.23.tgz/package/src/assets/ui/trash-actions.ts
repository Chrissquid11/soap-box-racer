/**
 * The Trash root's actions (Docs/assets-tool.md §7): a trashed file is
 * restored where it was, or into another folder -- a trashed tile dropped on
 * one, or Restore to… -- as one step; a slot restored whole; the whole Trash
 * restored, or emptied for good.
 *
 * - **Restore says first what comes back as `-2`**: the client index knows
 *   what is taken, and a name taken is made `crate-2.lua` on the way back
 *   (§A.6): `restoring` works each one out, `restoreQuestion` asks it -- in the
 *   inspector, through `ask.ts` -- or answers null when nothing is renamed and
 *   it may go at once.
 * - **What a trashed path is**: the slot it is in and the path it had
 *   (`fromTrash`); a slot's own paths, as `POST restore` takes them; Restore
 *   all, every slot but the automatic one, the newest first; what a Restore of
 *   one source leaves in its slot (`restoreNote`).
 *
 * Pure: node tests it (`trash-actions.test.ts`).
 */
import type { TrashSlot } from '@vibe/pipeline/assets-types';
import { AUTO_SLOT, baseName, dirName, familyStem, fromTrash, isRecordName, locate, numbered, slotTime, twin } from '@vibe/pipeline/paths';

/** One trashed file on its way back: the slot, the path it had, and the path it comes back as. */
export interface Restoring {
  slot: string;
  path: string;
  as: string;
}

/**
 * Each trashed path (`.trash/<slot>/<path it had>`) as it comes back: where
 * it was, or `-2`, `-3`… where that is taken (`taken`, the client index) --
 * the smallest free, as the server makes it. A path that is no trashed file is
 * left out.
 */
export function restoring(trashed: readonly string[], taken: (path: string) => boolean): Restoring[] {
  const claimed = new Set<string>();
  const out: Restoring[] = [];
  for (const p of trashed) {
    const at = fromTrash(p);
    if (!at) continue;
    let n = 1;
    while (n < 10000 && (taken(numbered(at.path, n)) || claimed.has(numbered(at.path, n)))) n++;
    const as = numbered(at.path, n);
    claimed.add(as);
    out.push({ slot: at.slot, path: at.path, as });
  }
  return out;
}

/** The question a restore asks first -- "crate.lua comes back as crate-2.lua: crate.lua is taken. Restore it?" -- or null when every name is free. */
export function restoreQuestion(back: readonly Restoring[]): string | null {
  const renamed = back.filter((r) => r.as !== r.path);
  if (renamed.length === 0) return null;
  const first = renamed[0]!;
  const rest = renamed.length > 1 ? `, and ${renamed.length - 1} more as -2` : '';
  return `${baseName(first.path)} comes back as ${baseName(first.as)}: ${baseName(first.path)} is taken${rest}. Restore ${back.length === 1 ? 'it' : `all ${back.length}`}?`;
}

/**
 * Restore all: every slot, the newest first -- but the automatic one, which
 * holds the export before the last of every source exported by itself:
 * brought back, each would be a `-2` beside the export it was replaced by.
 * Its own Restore, on its slot, still brings it back; `auto` lists it, last.
 */
export function slotsNewestFirst(slots: readonly TrashSlot[], auto = false): string[] {
  const time = (slot: string): number => (slot === AUTO_SLOT ? -Infinity : (slotTime(slot)?.getTime() ?? 0));
  return slots.map((s) => s.slot).filter((slot) => auto || slot !== AUTO_SLOT).sort((a, b) => time(b) - time(a));
}

/**
 * What a Restore of one trashed source leaves (§7: the trash holds files, not
 * families): its record, intermediate and export stay in the slot, and it is
 * exported again once back -- said on the item, or null when nothing of its
 * family is left there. `inSlot` lists a slot's files by the paths they had.
 */
export function restoreNote(trashed: readonly string[], inSlot: (slot: string) => readonly string[]): string | null {
  if (trashed.length !== 1) return null;
  const at = fromTrash(trashed[0]!);
  const name = at ? baseName(at.path) : '';
  if (!at || locate(at.path)?.root !== 'source' || isRecordName(name) || name.startsWith('_')) return null;
  const stem = familyStem(name);
  const dir = dirName(at.path);
  const left = inSlot(at.slot).filter((p) => p !== at.path && familyStem(baseName(p)) === stem && (dirName(p) === dir || dirName(p) === twin(dir)));
  return left.length > 0 ? 'its record and export stay in the trash: it is exported again once back' : null;
}

/** "Restore crate.lua", "Restore 3 files", "Restore 3 files here". */
export function restoreLabel(back: readonly Restoring[], here = false): string {
  const what = back.length === 1 ? baseName(back[0]!.path) : `${back.length} files`;
  return `Restore ${what}${here ? ' here' : ''}`;
}
