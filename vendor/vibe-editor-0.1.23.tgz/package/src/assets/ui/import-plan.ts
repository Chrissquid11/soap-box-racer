/**
 * The import sheet's plan (Docs/assets-tool.md §5): a drop -- files from the
 * desktop, a folder, a picker, a paste -- read into rows, each with its final
 * name, its role, what it is part of, what it replaces and why it cannot go,
 * and what `PUT import` gets for it. Decided with part one's own code --
 * `recipeFor` and `kindsTaking`, `validName`, `suggestName` and `IGNORED`, the
 * scanners' answers and `matchNames` -- so the sheet and the server cannot
 * disagree.
 *
 * - **Derived, never kept**: `planImport(input, choices, scans, names)` works
 *   every row out again from the drop, what the person changed (`Choice`),
 *   what each owner was read to name (`Scan`, `parts-browser.ts`) and what
 *   `GET names` answered -- so a name typed, a tick, a part found or a row
 *   moved is one call, and nothing can go stale.
 * - **Roles** (§5.3): a `.glb` or `.fbx` for a models folder, Gladius here, may
 *   be a **script** that imports it (Docs/modeler.md M39) -- the default from
 *   the Model tab's Import model…, a switch on its row anywhere -- its target
 *   the script, its file the copy beside it; a
 *   converting recipe a source (its `to`); a copying one,
 *   or a `.glb` already Draco, meshopt or KTX2, as delivered, switchable; a
 *   `NotFound` with `asDelivered` as delivered, its refusal the row's grey
 *   line; an `extra` kept, not converted; a `.glb` beside a `.blend` this
 *   machine cannot make its hand export, sent as `_crate.glb`; `levels/` as
 *   delivered with no switch; under `reference/` as it is; anything else
 *   refused word for word, with a button for each folder `kindsTaking` gives.
 *   A file in a model's folder in the drop goes to the Source side either way: an
 *   image a source copied as it is, until its model names it.
 * - **Parts**: a model's scan matched against the drop -- a `search` scanner's
 *   names through `matchNames`, any other's paths resolved from the model's
 *   folder (`resolveRel`) and matched as they are, an `.mtl` among them read
 *   in turn -- and every match **part of robot.fbx**.
 * - **One stem, one source**: a row whose file is there already, or whose key
 *   a source or a loose file has, **replaces** it -- refused until ticked or
 *   renamed. A source out of the build has no key to take -- but beside a
 *   source row of its stem, whose record it would share.
 * - **In the build** (§5's tick, on by default): a source row unticked is sent
 *   `include=false`, its record written saying so and no export queued; a row
 *   as delivered unticked is named `_name`, which no build takes -- its tick is
 *   its name's `_`, so the name field shows it.
 * - **What is sent** (`sends`): owners first by `MODEL_SOURCE_EXT`, then the
 *   rest, each `PUT import` with its `dest` (the shipping side for a source, a
 *   part, a hand export or an extra; for one as delivered too; a
 *   `reference/` folder as it is), `source` and `replace`; `left` counting
 *   down. The label is "Import robot.fbx" for one family, "Import 3 files"
 *   else. The totals, and the boot set against the budget.
 * - **When a row is in** (`arrival`): its file in the index and every job it
 *   queued ended -- the sheet's closing rule, the index having the last word.
 * - **The folders it makes** (`newFolders`), both sides: what its undo takes
 *   away again.
 *
 * Pure: node tests it (`import-plan.test.ts`).
 */
import type { Entry, JobMessage, NameAnswer, Options } from '@vibe/pipeline/assets-types';
import { KINDS, ROOTS, TRASH, kindDef, packed, shipped, type KindName } from '@vibe/pipeline/kinds';
import { IMPORT_EXT, matchNames, PART_DEPS, type Deps } from '@vibe/pipeline/parts';
import { baseName, dirName, exportKey, extOf, globbed, ignored, joinPath, keyOf, locate, resolveRel, resolveTo, splitName, suggestName, twin, under, validName } from '@vibe/pipeline/paths';
import { isFound, kindsTaking, MODEL_SOURCE_EXT, recipeFor, type RecipeAnswer, type Schemas } from '@vibe/pipeline/recipes';
import { bootBytes, inBootSet, sayBytes } from './budget.ts';
import { COMPRESSED, type GlbHead } from './parts-browser.ts';

/** A file of a drop: where it was in what was dropped -- `robot.fbx`, `robot/textures/skin.png` -- and its bytes. */
export interface Dropped {
  rel: string;
  size: number;
}

/** What the sheet plans for. */
export interface PlanInput {
  /** The folder the sheet is for: what was dropped on. */
  dest: string;
  files: readonly Dropped[];
  /** Names the reader skipped as the OS's leavings (`dnd.ts`): counted with those skipped here. */
  skipped?: readonly string[];
  /** The client index. */
  entries: ReadonlyMap<string, Entry>;
  /** Blender found on this machine (`GET tools`): a `.glb` beside a `.blend` is then no hand export. */
  blender?: boolean;
  /**
   * Gladius found on this machine: a `.glb` or `.fbx` for a models folder may then be imported **as a Gladius
   * script** that imports it (Docs/modeler.md M39) -- its row's switch; the default where the Model tab asked
   * (`Choice.script`), the file's own source anywhere else.
   */
  gladius?: boolean;
  /** The boot set's budget, in bytes. */
  budget: number;
  /** A path as the tool says it (`naming.ts`): where a row lands. As it is by default. */
  say?: (path: string) => string;
}

/** What a row was read for: an owner's parts, a `.glb`'s head, an `.mtl`'s maps. */
export interface Scan {
  state: 'reading' | 'done' | 'failed';
  /** Bytes read so far. */
  read: number;
  /** What the scanner found: paths relative to the file's folder, a `search` scanner's bare names. */
  names?: readonly string[];
  /** A `.glb`'s head: its parts and its extensions. */
  head?: GlbHead;
  error?: string;
}

/** What the person changed of a row. */
export interface Choice {
  name?: string;
  /** × : left out. */
  skip?: boolean;
  /** As a source (true) or as delivered (false), where it may be either. */
  source?: boolean;
  /** Its tick: what it replaces goes to the trash first. */
  replace?: boolean;
  /** Moved by a fix ("drop it on audio/sfx"), with `source`. */
  folder?: string;
  /** Its recipe's options, the overrides alone. */
  options?: Options;
  /** A source's tick, in the build (default) or out: sent as `include=false`. As delivered, the tick is the name's `_`. */
  include?: boolean;
  /** A `.glb` or `.fbx` under models: as a Gladius script that imports it (true), or the file as its own source or as delivered (false). */
  script?: boolean;
}

/** What a row is to the import. */
export type Role = 'source' | 'script' | 'delivered' | 'part' | 'hand' | 'extra' | 'reference' | 'refused';

/** A button that moves a refused row where its kind goes. */
export interface Fix {
  label: string;
  folder: string;
  source: boolean;
}

/** A row's name as `GET names` and the local checks say it. */
export type NameState = { state: 'checking' } | { state: 'ok'; note?: string } | { state: 'refused'; refused: string; suggested?: string };

/** One file of the drop, planned. */
export interface PlanRow {
  /** Its place in `PlanInput.files`: stable while files are added. */
  id: number;
  rel: string;
  size: number;
  /** Its name as dropped. */
  original: string;
  /** Its name as it will be written: the original, or a valid one made of it, or what was typed. */
  name: string;
  /** The folder it goes into, as the sheet shows it: what was dropped on, with the drop's subfolders. */
  folder: string;
  role: Role;
  /** The role in words: "source → .glb", "as delivered", "part of robot.fbx". */
  says: string;
  /** A grey line under it: why it is as delivered, what it is kept as, where it lands, what is being read. */
  line?: string;
  /** Why it cannot go as it is, word for word: a refused row. */
  refused?: string;
  /** For a refused row, a button for each folder that would take it. */
  fixes: Fix[];
  /** As delivered and as a source are both possible: the switch. */
  switchable: boolean;
  /** A `.glb` or `.fbx` under models, Gladius here: as a script, or not -- the second switch (Docs/modeler.md M39). */
  scriptable: boolean;
  /** The rows of models that name it. */
  owners: number[];
  /** What is there already that it would replace: its own path, or a file with its key (one stem, one source). */
  replaces: string[];
  replace: boolean;
  skip: boolean;
  /** Its name, checked: here, then by `GET names`. */
  checked: NameState;
  /** Why Import waits for this row, or null. */
  blocked: string | null;
  /** `PUT import`'s `dest` and `source`. */
  dest: string;
  source: boolean;
  /** Where it will be written: for a script row, the script -- its file goes beside it as `copy`. */
  target: string;
  /** A script row's copy of the file, beside its script: `robot.source.glb`. */
  copy?: string;
  /** Read for its parts or its head: this row's file. */
  scans?: 'parts' | 'head';
  /** Its recipe's options, for a source: the schema, and the overrides chosen. */
  schemas?: Schemas;
  options: Options;
  /** Rows sharing a recipe share this: "same for all". */
  recipe?: string;
  /** A model source: sent before the rest. */
  owner: boolean;
  /** It has a tick (a source; one as delivered): what `include` says is the person's. */
  tick: boolean;
  /** In the build: a source's tick, or for one as delivered its name with no `_`. */
  include: boolean;
}

/** The plan: every row, what is sent, and what it adds up to. */
export interface Plan {
  rows: PlanRow[];
  /** "3 .DS_Store files skipped", or null. */
  skipped: string | null;
  /** The rows sent, in order: owners first. */
  sends: PlanRow[];
  /** "Import robot.fbx", "Import 3 files". */
  label: string;
  bytes: number;
  /** For a destination under Assets: the boot set now, what lands in it as delivered, and after, against the budget. */
  boot: { now: number; adds: number; after: number; budget: number } | null;
  /** The first row Import waits for, or null: Import is disabled while one is. */
  blocked: PlanRow | null;
  /** Rows to read: an owner for its parts, a `.glb` for its head, an `.mtl` named by an `.obj`. */
  reads: Array<{ id: number; what: 'parts' | 'head'; path: string; deps?: Deps }>;
}

// ---------------------------------------------------------------- small rules

/** A dropped path with a part the OS or an sourceSide tool left (`IGNORED`): never imported. */
export const ignoredPath = (rel: string): boolean => rel.split('/').some((part) => part !== '' && ignored(part));

/** A name made valid where it is not: the original, or `suggestName`'s. */
const valid = (name: string, folder = false): string => ('ok' in validName(name, { folder }) ? name : suggestName(name, folder));

/** A folder's side where its sources are, and where its exports go. */
function sidesOf(folder: string): { source: string; ship: string } {
  const other = twin(folder);
  if (locate(folder)?.root === 'source' || folder === ROOTS.source.dir) return { source: folder, ship: other ?? folder };
  return { source: other ?? folder, ship: folder };
}

/** Where a refused row's fixes go: the Source side's and the shipping side's base -- a pack's own, or the roots'. None under Packs itself. */
function basesOf(folder: string): { source: string; ship: string; pack: boolean } | null {
  const where = locate(joinPath(folder, 'x'));
  if (where?.pack !== undefined && where.pack !== 'x') return { source: joinPath(ROOTS.packs.source, where.pack), ship: joinPath(ROOTS.packs.dir, where.pack), pack: true };
  if (under(folder, ROOTS.packs.dir) || under(folder, ROOTS.packs.source)) return null;
  return { source: ROOTS.source.dir, ship: ROOTS.boot.dir, pack: false };
}

/** `path` relative to `dir`, or undefined outside it. */
function relativeTo(dir: string, path: string): string | undefined {
  if (dir === '') return path;
  return path.startsWith(dir + '/') ? path.slice(dir.length + 1) : undefined;
}

/** A model source: owners are sent first, so the server reads them before the files they name (§A.5). */
const isModelSource = (target: string): boolean => locate(target)?.kind === 'models' && MODEL_SOURCE_EXT.includes(extOf(target));

/** `robot.glb` -> `robot.source.glb`: a script row's copy, its extension kept (Docs/modeler.md M39). */
const copyName = (name: string): string => `${splitName(name).stem}.source.${extOf(name)}`;

/** "a.fbx", "a.fbx and b.obj". */
const andList = (names: readonly string[]): string => (names.length <= 1 ? names.join('') : `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`);

/** How a step is said while an export runs: what §1's designer sees. */
export const STEP_WORDS: Readonly<Record<string, string>> = {
  'browser-to-glb': 'converting in this tab',
  gladius: 'Gladius',
  blender: 'Blender',
  'pack-gltf': 'packing the glTF',
  flatten: 'flattening',
  kra: 'reading the Krita file',
  finish: 'finish',
  'webp-textures': 'textures to WebP',
  draco: 'Draco',
  image: 'to WebP',
  aseprite: 'Aseprite',
  ffmpeg: 'ffmpeg',
  copy: 'copying',
};

// ---------------------------------------------------------------- the plan

/** What a row is before parts are matched: its role from its recipe, its folder and its name. */
interface Base {
  id: number;
  file: Dropped;
  original: string;
  name: string;
  folder: string;
  choice: Choice;
  answer: RecipeAnswer | null;
  kind?: KindName;
  role: Role;
  says: string;
  line?: string;
  refused?: string;
  fixes: Fix[];
  switchable: boolean;
  scriptable: boolean;
}

/** The roles a model's naming turns into a part: what the server takes as a source on the Source side. */
const PARTABLE: ReadonlySet<Role> = new Set(['source', 'delivered', 'extra']);

/**
 * The plan for `input`, with what the person `choices`, what was read
 * (`scans`) and what `GET names` answered (`names`, by row; an answer for a
 * name the row no longer has is not used).
 */
export function planImport(
  input: PlanInput,
  choices: ReadonlyMap<number, Choice> = new Map(),
  scans: ReadonlyMap<number, Scan> = new Map(),
  names: ReadonlyMap<number, NameAnswer> = new Map(),
): Plan {
  const say = input.say ?? ((path: string): string => path);
  const skippedNames = [...(input.skipped ?? [])];
  const kept: Array<{ id: number; file: Dropped }> = [];
  input.files.forEach((file, id) => {
    // A `.uid` sidecar dropped with its file (copied from another project, Docs/asset-ids.md §1): never imported -- the
    // imported file is a new asset, and the pipeline gives it a uid of its own (rule 7).
    if (ignoredPath(file.rel) || file.rel.toLowerCase().endsWith('.uid')) skippedNames.push(baseName(file.rel));
    else kept.push({ id, file });
  });

  /** The folder a file goes into as dropped: `dest` with the drop's own folders, each a valid folder name. */
  const shownFolder = (rel: string): string => joinPath(input.dest, ...dirName(rel).split('/').filter((p) => p !== '').map((p) => valid(p, true)));

  // The folders a model source of the drop is in: an image beside it goes to the Source side either way.
  const modelFolders = new Set<string>();
  // The `.blend`s beside which a `.glb` is a hand export: the index's and the drop's, by Source-side path.
  const blends = new Set<string>();
  for (const { id, file } of kept) {
    const choice = choices.get(id) ?? {};
    if (choice.skip) continue;
    const folder = choice.folder ?? shownFolder(file.rel);
    const name = valid(baseName(file.rel));
    const path = joinPath(sidesOf(folder).source, name);
    if (isModelSource(path) && choice.source !== false) modelFolders.add(folder);
    if (extOf(name) === 'blend') blends.add(path);
  }
  for (const path of input.entries.keys()) if (extOf(path) === 'blend') blends.add(path);

  const bases: Base[] = kept.map(({ id, file }) => classify(id, file));

  function classify(id: number, file: Dropped): Base {
    const choice = choices.get(id) ?? {};
    const original = baseName(file.rel);
    const folder = choice.folder ?? shownFolder(file.rel);
    const { source: sourceSide } = sidesOf(folder);
    const plain = valid(original);
    // A .glb beside a .blend that cannot be made here: its export by hand, `_crate.glb` (§A.3).
    const stem = splitName(plain).stem.replace(/^_/, '');
    const hand = extOf(plain) === 'glb' && !input.blender && blends.has(joinPath(sourceSide, `${stem}.blend`)) && (choice.name === undefined || choice.name.startsWith('_'));
    const name = choice.name ?? (hand ? `_${stem}.glb` : plain);
    const base: Base = { id, file, original, name, folder, choice, answer: null, role: 'refused', says: '', fixes: [], switchable: false, scriptable: false };
    if (under(folder, TRASH)) return { ...base, says: 'refused', refused: 'the trash takes no files: Delete is the way there' };
    if (under(folder, ROOTS.source.reference)) return { ...base, role: 'reference', says: 'reference', line: 'nothing is made from it: kept as it is' };
    const path = joinPath(folder, name);
    const answer = recipeFor(path);
    const where = locate(path);
    const kind = where?.kind;
    const ext = extOf(name);
    const ships = kind === undefined ? [] : where?.pack !== undefined ? packed(kind) : shipped(kind);
    const withAnswer = { ...base, answer, ...(kind !== undefined ? { kind } : {}) };
    // A kind with no sources (levels/): what it ships, as delivered, with no switch.
    if (kind !== undefined && !kindDef(kind).source) {
      if ((KINDS[kind].ext as readonly string[]).includes(ext)) return { ...withAnswer, role: 'delivered', says: 'as delivered', line: refusalOf(answer) };
      return { ...withAnswer, says: 'refused', refused: refusalOf(answer) };
    }
    if (isFound(answer)) {
      const delivers = ships.includes(ext);
      if (hand) return { ...withAnswer, role: 'hand', says: `hand export of ${stem}.blend`, line: `sent as ${name}: ${stem}.blend's export, made by hand` };
      const head = scans.get(id)?.head;
      const compressed = head !== undefined && 'compressed' in head && head.compressed ? head.extensions.filter((e) => COMPRESSED.includes(e)) : null;
      // A .glb or .fbx under models, Gladius here: a script that imports it, by default (Docs/modeler.md M39).
      const scriptable = kind === 'models' && input.gladius === true && (IMPORT_EXT as readonly string[]).includes(ext) && !name.startsWith('_');
      // A script by default only where asked from the Model tab (`Choice.script` set as the files came); else the file's own source.
      if (scriptable && choice.script === true) {
        const decodes = compressed !== null ? `${compressed.join(', ')} decoded on the way in -- Gladius reads plain geometry` : undefined;
        return {
          ...withAnswer,
          role: 'script',
          says: 'Gladius script → .glb',
          line: [`${splitName(name).stem}.lua imports it, kept beside it as ${copyName(name)}`, decodes].filter(Boolean).join(' · '),
          scriptable: true,
        };
      }
      // Copied as it is, or a .glb compressed already: as delivered -- unless it sits beside a model of the drop.
      const asIs = answer.copy ? !modelFolders.has(folder) : compressed !== null;
      const source = delivers ? (choice.source ?? !asIs) : true;
      if (!source) {
        const line = compressed !== null ? `${compressed.join(', ')}: compressed already, and through Draco again it would be lossy twice` : undefined;
        return { ...withAnswer, role: 'delivered', says: 'as delivered', switchable: true, scriptable, ...(line !== undefined ? { line } : {}) };
      }
      const to = resolveTo(path, answer.row.to);
      const line =
        head !== undefined && 'tooBig' in head ? `its head is ${sayBytes(head.tooBig)}, past what is read here: the server finds its parts`
        : head !== undefined && 'notGlb' in head ? 'not a GLB by its first bytes: its export will fail'
        : answer.copy ? 'beside a model of this drop: on the Source side, a part once the model names it'
        : undefined;
      return {
        ...withAnswer,
        role: 'source',
        says: answer.copy ? `source, copied as .${to[0]}` : `source → .${to.join(' + .')}`,
        switchable: delivers,
        scriptable,
        ...(line !== undefined ? { line } : {}),
      };
    }
    if (answer.asDelivered) return { ...withAnswer, role: 'delivered', says: 'as delivered', line: answer.refused };
    if (answer.extra) return { ...withAnswer, role: 'extra', says: 'kept, not converted', line: answer.refused };
    return { ...withAnswer, says: 'refused', refused: answer.refused, fixes: fixesFor(ext, folder, kind) };
  }

  // ---------------------------------------------------------------- parts

  const byRel = new Map(bases.map((b) => [b.file.rel, b]));
  const owners = new Map<number, number[]>();
  const reads: Plan['reads'] = [];
  const named = (part: Base | undefined, owner: Base): void => {
    if (!part || part === owner || part.choice.skip || !PARTABLE.has(part.role)) return;
    const list = owners.get(part.id) ?? [];
    if (!list.includes(owner.id)) list.push(owner.id);
    owners.set(part.id, list);
  };
  // Every .glb a model source or delivered: its head says which, and what it names (§5.3).
  for (const b of bases) {
    if (b.choice.skip || extOf(b.name) !== 'glb' || b.kind !== 'models' || (b.role !== 'source' && b.role !== 'delivered' && b.role !== 'script')) continue;
    reads.push({ id: b.id, what: 'head', path: joinPath(sidesOf(b.folder).source, b.name) });
  }
  for (const owner of bases) {
    if (owner.choice.skip || owner.role !== 'source' || !owner.answer || !isFound(owner.answer)) continue;
    const deps = owner.answer.row.deps;
    const glb = extOf(owner.name) === 'glb';
    if (!deps) continue;
    if (!glb) reads.push({ id: owner.id, what: 'parts', path: joinPath(sidesOf(owner.folder).source, owner.name), deps });
    const scan = scans.get(owner.id);
    if (scan?.state !== 'done') continue;
    const found = glb ? (scan.head && 'uris' in scan.head ? scan.head.uris : []) : (scan.names ?? []);
    const dir = dirName(owner.file.rel);
    if (deps?.search) {
      // Bare names, matched in the model's folder and a textures/ under it, as the index matches them.
      const near = bases.map((b) => ({ b, at: relativeTo(dir, b.file.rel) })).filter((x): x is { b: Base; at: string } => x.at !== undefined);
      const hits = new Set(matchNames(found, near.map((x) => x.at)));
      for (const x of near) if (hits.has(x.at)) named(x.b, owner);
      continue;
    }
    // Paths that must exist as written: resolved from the model's folder, matched as they are.
    for (const ref of found) {
      const at = resolveRel(dir, ref);
      const part = at === undefined ? undefined : byRel.get(at);
      named(part, owner);
      // An .obj's .mtl is read in turn, its maps matched the same way (§A.3).
      if (!part || extOf(part.file.rel) !== 'mtl' || !owners.get(part.id)?.includes(owner.id)) continue;
      reads.push({ id: part.id, what: 'parts', path: joinPath(sidesOf(part.folder).source, part.name), deps: PART_DEPS.mtl! });
      const mtl = scans.get(part.id);
      if (mtl?.state !== 'done') continue;
      for (const map of mtl.names ?? []) {
        const mapAt = resolveRel(dirName(part.file.rel), map);
        named(mapAt === undefined ? undefined : byRel.get(mapAt), owner);
      }
    }
  }
  const nameOf = new Map(bases.map((b) => [b.id, b.name]));

  // ---------------------------------------------------------------- each row's place, name and whether it may go

  /**
   * The paths with each key, sources and loose files: what a second source for
   * a key is looked up in. A source out of the build has no key to take: kept
   * apart, for the one case it counts -- a source row beside it, of its stem,
   * which would share its record (one stem, one record).
   */
  const withKey = new Map<string, string[]>();
  const outWithKey = new Map<string, string[]>();
  for (const e of input.entries.values()) {
    if (e.key === undefined || (e.role !== 'source' && e.role !== 'loose')) continue;
    const into = e.role === 'source' && !e.included ? outWithKey : withKey;
    const list = into.get(e.key) ?? [];
    list.push(e.path);
    into.set(e.key, list);
  }
  const taken = new Map<string, number>();
  const rows: PlanRow[] = bases.map((b) => {
    const partOf = owners.get(b.id) ?? [];
    const role: Role = partOf.length > 0 ? 'part' : b.role;
    const says = role === 'part' ? `part of ${andList(partOf.map((o) => nameOf.get(o)!))}` : b.says;
    const { source: sourceSide, ship } = sidesOf(b.folder);
    const scripted = role === 'script';
    const source = role === 'source' || role === 'script' || role === 'part' || role === 'hand' || role === 'extra';
    const dest = role === 'reference' ? b.folder : ship;
    // A script row: the script is what it writes, keyed as the file would be; its file goes beside it as the copy.
    const target = role === 'reference' ? joinPath(b.folder, b.name) : scripted ? joinPath(sourceSide, `${splitName(b.name).stem}.lua`) : joinPath(source ? sourceSide : ship, b.name);
    const copy = scripted ? joinPath(sourceSide, copyName(b.name)) : undefined;
    const answered = b.answer && isFound(b.answer) ? b.answer : undefined;
    const scriptRow = scripted ? recipeFor(target) : undefined;
    const found = scriptRow !== undefined ? (isFound(scriptRow) ? scriptRow : undefined) : answered;
    const key = (role === 'source' || scripted) && found ? exportKey(target, found.row.to) : role === 'delivered' ? keyOf(target) : undefined;
    const beside = (role === 'source' || scripted) && key !== undefined ? (outWithKey.get(key) ?? []).filter((p) => dirName(p) === dirName(target)) : [];
    const replaces = role === 'refused' ? [] : [...new Set([...(input.entries.has(target) ? [target] : []), ...(copy !== undefined && input.entries.has(copy) ? [copy] : []), ...(key !== undefined ? (withKey.get(key) ?? []).filter((p) => p !== target) : []), ...beside.filter((p) => p !== target)])];
    const replace = replaces.length > 0 && b.choice.replace === true;
    const skip = b.choice.skip === true;
    // A part's own line: none -- what it was before its model named it is said no more -- but a name its model will not find.
    let line = role === 'part' ? undefined : b.line;
    if (role === 'part' && b.name.toLowerCase() !== b.original.toLowerCase()) line = `its model names it ${b.original}: renamed, the model will not find it`;
    else if (role === 'delivered' && b.folder !== ship) line = [line, `lands in ${say(ship)}`].filter(Boolean).join(' · ');
    // Its name: valid, not asked for twice here, then what GET names said -- a refusal a tick answers set aside.
    let checked: NameState = { state: 'checking' };
    const local = validName(b.name);
    const lower = `${dest}/${b.name}`.toLowerCase();
    if ('refused' in local) checked = { state: 'refused', refused: local.refused, ...(local.suggested !== undefined ? { suggested: local.suggested } : {}) };
    else if (!skip && role !== 'refused' && taken.has(lower)) checked = { state: 'refused', refused: `${b.name} is asked for twice: one of them needs another name` };
    else {
      const answer = names.get(b.id);
      // What the tick answers -- the name taken, or its key -- is the replace line's to say, not a red name.
      if (answer && answer.name === b.name) {
        if ('ok' in answer) checked = { state: 'ok', ...(answer.note !== undefined ? { note: answer.note } : {}) };
        else if (replaces.length > 0) checked = { state: 'ok' };
        else checked = { state: 'refused', refused: answer.refused, ...(answer.suggested !== undefined ? { suggested: answer.suggested } : {}) };
      }
    }
    if (!skip && role !== 'refused' && !taken.has(lower)) taken.set(lower, b.id);
    let blocked: string | null = null;
    if (!skip) {
      if (role === 'refused') blocked = b.refused ?? 'refused';
      else if (checked.state === 'refused') blocked = checked.refused;
      else if (replaces.length > 0 && !replace) blocked = `replaces ${andList(replaces.map(baseName))}: tick it to replace, or name it differently -- one stem, one source`;
      else if (checked.state === 'checking') blocked = 'its name is being checked';
    }
    const owner = (role === 'source' || scripted) && isModelSource(target);
    const schemas = (role === 'source' || scripted) && found?.row.options ? found.row.options : undefined;
    // The tick: a source's own, sent as include=false; one as delivered, its name's `_`.
    const tick = role === 'source' || scripted || role === 'delivered';
    const include = role === 'source' || scripted ? b.choice.include !== false : role === 'delivered' ? !b.name.startsWith('_') : true;
    const scanned = reads.find((r) => r.id === b.id);
    const scan = scans.get(b.id);
    if (scanned && scan?.state === 'reading') {
      const percent = b.file.size > 0 ? Math.min(99, Math.floor((scan.read / b.file.size) * 100)) : 0;
      line = scanned.what === 'head' ? `reading ${b.name}'s head` : `reading ${b.name} for its parts · ${percent} %`;
    } else if (scanned && scan?.state === 'failed') line = `${b.name} could not be read for its parts (${scan.error ?? 'unreadable'}): the server finds them`;
    return {
      id: b.id,
      rel: b.file.rel,
      size: b.file.size,
      original: b.original,
      name: b.name,
      folder: b.folder,
      role,
      says,
      ...(line !== undefined ? { line } : {}),
      ...(role === 'refused' && b.refused !== undefined ? { refused: b.refused } : {}),
      fixes: role === 'refused' ? b.fixes : [],
      switchable: role !== 'part' && b.switchable,
      scriptable: role !== 'part' && b.scriptable,
      owners: partOf,
      replaces,
      replace,
      skip,
      checked,
      blocked,
      dest,
      source,
      target,
      ...(copy !== undefined ? { copy } : {}),
      ...(scanned ? { scans: scanned.what } : {}),
      ...(schemas ? { schemas } : {}),
      options: schemas ? (b.choice.options ?? {}) : {},
      ...(found && (role === 'source' || scripted) ? { recipe: `${found.kind}.${found.ext}` } : {}),
      owner,
      tick,
      include,
    };
  });

  // ---------------------------------------------------------------- what is sent, and what it adds up to

  const going = rows.filter((r) => !r.skip && r.role !== 'refused');
  const sends = [...going.filter((r) => r.owner), ...going.filter((r) => !r.owner)];
  const bytes = sends.reduce((sum, r) => sum + r.size, 0);
  const boot = bootOf(input, sends);
  return {
    rows,
    skipped: skippedText(skippedNames),
    sends,
    label: labelOf(sends),
    bytes,
    boot,
    blocked: rows.find((r) => r.blocked !== null) ?? null,
    reads,
  };
}

/** A recipe answer's words, refused or not. */
const refusalOf = (answer: RecipeAnswer): string => ('refused' in answer ? answer.refused : '');

/**
 * A button for each folder that takes this extension (`kindsTaking`), read
 * from its two lists, not the words: "drop it on audio/sfx" as a source,
 * "import it as delivered into fonts" as it is -- in the dropped folder's own
 * root or pack.
 */
function fixesFor(ext: string, folder: string, kind: KindName | undefined): Fix[] {
  const bases = basesOf(folder);
  if (!bases) return [];
  const taking = kindsTaking(ext);
  const fits = (k: KindName): boolean => k !== kind && (!bases.pack || kindDef(k).inPacks === true);
  return [
    ...taking.source.filter((k) => fits(k) && kindDef(k).source).map((k) => ({ label: `drop it on ${KINDS[k].dir}`, folder: joinPath(bases.source, KINDS[k].dir), source: true })),
    ...taking.delivered.filter(fits).map((k) => ({ label: `import it as delivered into ${KINDS[k].dir}`, folder: joinPath(bases.ship, KINDS[k].dir), source: false })),
  ];
}

/** "3 .DS_Store files skipped", "2 files skipped: .DS_Store, Thumbs.db~". */
function skippedText(names: readonly string[]): string | null {
  if (names.length === 0) return null;
  const kinds = [...new Set(names)];
  if (kinds.length === 1) return `${names.length} ${kinds[0]} ${names.length === 1 ? 'file' : 'files'} skipped`;
  return `${names.length} files skipped: ${kinds.slice(0, 3).join(', ')}${kinds.length > 3 ? ', …' : ''}`;
}

/** "Import robot.fbx" for one file, or one family -- a model and the files it names; "Import 3 files" else. */
function labelOf(sends: readonly PlanRow[]): string {
  if (sends.length === 0) return 'Import';
  if (sends.length === 1) return `Import ${sends[0]!.name}`;
  const heads = sends.filter((r) => r.role !== 'part');
  if (heads.length === 1 && sends.every((r) => r === heads[0] || r.owners.includes(heads[0]!.id))) return `Import ${heads[0]!.name}`;
  return `Import ${sends.length} files`;
}

/** The boot set before and after, for a drop landing under Assets: what lands in it as delivered; sources add their exports once made. */
function bootOf(input: PlanInput, sends: readonly PlanRow[]): Plan['boot'] {
  if (!sends.some((r) => under(r.dest, ROOTS.boot.dir))) return null;
  const now = bootBytes(input.entries.values());
  let adds = 0;
  let gone = 0;
  for (const r of sends) {
    if (r.source || !under(r.target, ROOTS.boot.dir) || !globbed(r.target)) continue;
    adds += r.size;
    if (r.replace) for (const p of r.replaces) {
      const e = input.entries.get(p);
      if (e && inBootSet(e)) gone += e.size;
    }
  }
  return { now, adds, after: now - gone + adds, budget: input.budget };
}

/** What `GET names` is asked, by `dest`: each group's names in row order, every row that goes. */
export function nameQueries(plan: Plan): Array<{ dest: string; ids: number[]; names: string[] }> {
  const groups = new Map<string, { dest: string; ids: number[]; names: string[] }>();
  for (const row of plan.rows) {
    if (row.skip || row.role === 'refused') continue;
    const group = groups.get(row.dest) ?? { dest: row.dest, ids: [], names: [] };
    group.ids.push(row.id);
    group.names.push(row.name);
    groups.set(row.dest, group);
  }
  return [...groups.values()];
}

/** `PUT import`'s question for a row, `left` the rows sent after it: a source unticked out of the build (`include: false`). */
export function importQuery(row: PlanRow, drop: string, left: number): { dest: string; name: string; source: boolean; replace: boolean; options?: Options; include?: false; script?: true; drop: string; left: number } {
  return {
    dest: row.dest,
    name: row.name,
    source: row.source,
    replace: row.replace,
    ...(Object.keys(row.options).length > 0 ? { options: row.options } : {}),
    ...((row.role === 'source' || row.role === 'script') && !row.include ? { include: false as const } : {}),
    ...(row.role === 'script' ? { script: true as const } : {}),
    drop,
    left,
  };
}

/**
 * The name a row as delivered has with its tick `on` (§5): itself, or with
 * an `_` put before it -- what no build takes -- or taken off again.
 */
export function tickedName(name: string, on: boolean): string {
  if (on) return name.startsWith('_') ? name.slice(1) : name;
  return name.startsWith('_') ? name : `_${name}`;
}

/**
 * The folders an import makes (§8, "Import 3 files"): where each row sent puts
 * a file -- a source, a part, a hand export or an extra on the Source side (its
 * `dest`'s twin when it was dropped on the shipping side), a source's and a
 * hand export's export on the shipping side, a file as delivered or under
 * `reference/` in its `dest` -- and each folder up from there to one that is
 * already (`has`: the index's tree, folders kept by New folder among them);
 * each before the one it is in. Its undo removes them again, each if empty,
 * so no folder is left on disk that the index, which lists files, would never
 * show; and none is asked for that no file of it made.
 */
export function newFolders(rows: ReadonlyArray<Pick<PlanRow, 'dest' | 'role' | 'source'>>, has: (folder: string) => boolean): string[] {
  const out = new Set<string>();
  for (const row of rows) {
    const sourceSide = locate(joinPath(row.dest, 'x'))?.root === 'source' ? row.dest : twin(row.dest);
    const ship = sourceSide === row.dest ? twin(row.dest) : row.dest;
    const sides = !row.source ? [row.dest] : row.role === 'source' || row.role === 'script' || row.role === 'hand' ? [sourceSide, ship] : [sourceSide];
    for (const side of sides) {
      for (let dir = side; dir !== undefined && dir !== '' && !has(dir); dir = dirName(dir)) out.add(dir);
    }
  }
  // Longer first: a folder before every folder it is in.
  return [...out].sort((a, b) => b.length - a.length || (a < b ? -1 : a > b ? 1 : 0));
}

/** The extension a pasted image's type gives: `image/png` is `png`. */
const PASTED: Readonly<Record<string, string>> = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'image/avif': 'avif', 'image/svg+xml': 'svg' };

/**
 * A pasted image's name (§5, "Paste is the browser's"): `pasted-` and when, in
 * this machine's time to the second -- `pasted-2026-10-04-091233.png` --
 * editable in its row like any other. A file the browser gives with a name of
 * its own (one copied in the Finder) keeps it; one it calls `image.png`, or
 * nothing, is pasted.
 */
export function pastedName(file: { name: string; type: string }, at: Date): string {
  if (file.name !== '' && !/^image\.[a-z0-9]+$/i.test(file.name)) return file.name;
  const two = (n: number): string => String(n).padStart(2, '0');
  const stamp = `${at.getFullYear()}-${two(at.getMonth() + 1)}-${two(at.getDate())}-${two(at.getHours())}${two(at.getMinutes())}${two(at.getSeconds())}`;
  return `pasted-${stamp}.${PASTED[file.type] ?? 'png'}`;
}

// ---------------------------------------------------------------- a row sent: when it is in

/** A row's file after its `PUT import`: still on its way, in, or in with a failure that keeps the sheet up. */
export interface Arrival {
  state: 'waiting' | 'done' | 'bad';
  /** What its line says. */
  words: string;
}

/**
 * Where a sent row's file is (§5, "The sheet closes"): in the index, and every
 * job it queued ended -- a loose file, a part, an extra or a `reference/` file
 * queues none; a source waits for its export, `done`, `failed` or `unmade`,
 * the last two keeping the sheet up with their line. **The index has the last
 * word**: a source `current` with no job under way is in, whatever its last
 * job said -- one that found it current already (`skipped`), or failed while
 * another made it. `job` is the last `job` message for it (the drop's own,
 * once the import's answer named it), `running` whether one is under way, and
 * `here` whether this tab holds its browser step (`convert.ts`): a parked job
 * this tab converts is "converting in this tab", not "waiting for a game tab".
 */
export function arrival(path: string, entries: ReadonlyMap<string, Entry>, job: JobMessage | undefined, running: boolean, here = false): Arrival {
  const entry = entries.get(path);
  if (!entry) return { state: 'waiting', words: 'written; the index has it next' };
  if (entry.role !== 'source') {
    const as = entry.role === 'part' ? `part of ${andList((entry.owners ?? []).map(baseName))}` : entry.role === 'loose' ? 'as delivered' : entry.role === 'extra' ? 'kept, not converted' : entry.role;
    return { state: 'done', words: `in · ${as}` };
  }
  // Out of the build, ticked off in the sheet: in, and nothing to wait for -- no export is made of it.
  if (entry.status === 'excluded') return { state: 'done', words: 'in · out of the build: not exported' };
  const exported = (): string => {
    const made = entries.get(entry.exports?.[0] ?? '');
    return made ? `current · ${sayBytes(made.size)} from ${sayBytes(entry.size)}` : 'current';
  };
  if (entry.status === 'current' && !running) return { state: 'done', words: exported() };
  if (job && (job.state === 'done' || job.state === 'failed' || job.state === 'unmade' || job.state === 'dropped')) {
    if (job.state === 'done') return { state: entry.status === 'current' || entry.status === undefined ? 'done' : 'waiting', words: exported() };
    if (job.state === 'dropped') return { state: 'done', words: 'its export was stopped: the file was deleted' };
    if (job.state === 'failed') return { state: 'bad', words: `failed: ${job.error ?? entry.reason ?? 'its export failed'}` };
    return { state: 'bad', words: `unmade: ${entry.reason ?? job.error ?? 'nothing here can make it'}` };
  }
  if (running && job && job.state !== 'skipped') {
    if (job.state === 'queued') return { state: 'waiting', words: 'queued' };
    if (job.state === 'parked') return { state: 'waiting', words: here ? STEP_WORDS['browser-to-glb']! : 'waiting for a game tab' };
    const found = recipeFor(path);
    const step = isFound(found) ? found.row.steps[job.step - 1] : undefined;
    return { state: 'waiting', words: `${step ? (STEP_WORDS[step] ?? step) : 'exporting'}${job.of > 0 ? ` · ${job.step} of ${job.of}` : ''}` };
  }
  if (running) return { state: 'waiting', words: 'queued' };
  switch (entry.status) {
    case 'failed':
    case 'conflict':
      return { state: 'bad', words: `${entry.status}: ${entry.reason ?? ''}` };
    case 'unmade':
      return { state: 'bad', words: `unmade: ${entry.reason ?? 'nothing here can make it'}` };
    case 'reference':
      return { state: 'done', words: 'in · reference' };
    default:
      return { state: 'waiting', words: entry.status === 'checking' || entry.status === undefined ? 'in · being read' : `in · ${entry.status}, its export queued with the drop` };
  }
}
