/**
 * The Assets tool's prefab actions as steps (Docs/prefabs.md §7,
 * Docs/assets-tool.md §8): what each writes, and its undo -- run on the tool's
 * queue like every file edit (`file-steps.ts`), so Z undoes it.
 *
 * | Action | Calls | Undo |
 * | --- | --- | --- |
 * | New prefab crate | `PUT prefab { create }`: one entity, `Transform`, named from the folder | the file to the trash; redo writes it again |
 * | Make variant of crates/big | `PUT prefab { create }`: a root that is an instance of it, no overrides | the same |
 * | Pool of crates/chip: warm 8, max 32 | `PUT prefab`, the file's text with its `"pool"` | `PUT prefab` of the text before |
 * | Rename, Move, Duplicate, Delete | the tool's own (`file-steps.ts`): what nests it or holds an instance of it follows by uid, rewritten by the server's move in the same call; Delete refused while anything names it, naming it |
 *
 * - **Text, not objects**: a pool or a renamed key is changed in the file's
 *   text where it is, so a hand-written file keeps its layout and its diff is
 *   the one line.
 * - **The key follows the path**: `src/assets/prefabs/Crates/Big.prefab` is
 *   `crates/big` (the path lowercased, `caseKey`); a prefab nested elsewhere,
 *   a level or a scene names it by reference -- `{ uid, key }` -- so a rename
 *   or a move needs nothing of these steps: the uid keeps resolving, and the
 *   server's move rewrites the keys in its own call (Docs/asset-ids.md §4).
 *
 * Pure but for the API handed in: node tests it (`prefab-steps.test.ts`).
 */
import type { PrefabAnswer, WriteAnswer } from '@vibe/pipeline/assets-types';
import { KINDS, PREFAB_SUFFIX, ROOTS } from '@vibe/pipeline/kinds';
import { suggestName, validName } from '@vibe/pipeline/paths';
import type { PrefabFile } from '@vibe/engine';
import { caseKey, keyRef, nestedKey } from '@vibe/engine';
import type { Api } from '../api.ts';
import type { Answered } from '../steps.ts';
import type { Edit } from './file-steps.ts';

/** What the prefab edits call. */
export type PrefabsApi = Pick<Api, 'putPrefab' | 'remove' | 'move' | 'file'>;

/** Where the prefab files are: `src/assets/prefabs`. */
export const PREFABS_DIR = `${ROOTS.boot.dir}/${KINDS.prefabs.dir}`;

/** A prefab file's key from its path -- `src/assets/prefabs/Crates/Big.prefab` is `crates/big`, lowercased -- or undefined for any other (a stray `.json` there too). */
export function prefabKeyOf(path: string): string | undefined {
  if (!path.startsWith(`${PREFABS_DIR}/`) || !path.endsWith(PREFAB_SUFFIX)) return undefined;
  const key = path.slice(PREFABS_DIR.length + 1, -PREFAB_SUFFIX.length);
  return key.split('/').some((s) => s.startsWith('_')) ? undefined : caseKey(key);
}

/** Each key's name on disk (its path under `prefabs/`, no `.prefab`): the engine's `prefabs.ts`' `prefabName`, once `usePrefabNames` hands it in; none in a node test. */
let namesOf: (key: string) => string | undefined = () => undefined;

/** Where a key's file is: the engine's `prefabs.ts`' `prefabName`, handed in by the editor's boot. */
export function usePrefabNames(names: (key: string) => string | undefined): void {
  namesOf = names;
}

/** A key's path (in any case): the file with that key as it is on disk, else the key as written -- a new file's name. */
export const prefabPathOf = (key: string): string => prefabFileOf(namesOf(key) ?? key);

/**
 * Why `name` -- a path under `prefabs/` as typed, `Test Case/Big Thing` -- is
 * no new prefab's name, or null: a name in a folder, each part one
 * `validName` takes (the last as a `.prefab`'s), none starting with `_`
 * (the build skips it: no prefab). Taken or not is the caller's to ask.
 */
export function prefabNameProblem(name: string): string | null {
  const parts = name.split('/');
  if (parts.length < 2) return `‘${name}’ is no prefab name: a name in a folder -- crates/stack, Test Case/Big Thing`;
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i]!;
    const last = i === parts.length - 1;
    if (part.startsWith('_')) return `‘${part}’ starts with _, which keeps a file out of the build: no prefab`;
    const check = validName(last ? `${part}${PREFAB_SUFFIX}` : part, { folder: !last });
    if ('refused' in check) return `‘${part}’ in ${name}: ${check.refused}`;
  }
  return null;
}

/** A prefab file's name (no `.prefab`) made of an entity's: as it is, or what `suggestName` makes of it; `prefab` for none. */
export function prefabNameOf(entity: string | null | undefined): string {
  const own = (entity ?? '').replace(/^_+/, '');
  return own.trim() === '' ? 'prefab' : suggestName(`${own}${PREFAB_SUFFIX}`).slice(0, -PREFAB_SUFFIX.length);
}

/** A prefab's file by its name exactly as given (`Test Case/Big Thing`): what a new file is written as. */
export const prefabFileOf = (name: string): string => `${PREFABS_DIR}/${name}${PREFAB_SUFFIX}`;

/** The keys of the prefabs whose files nest `key` directly, sorted: a nested `"prefab"` read in any case. */
export function nestersOf(key: string, files: Readonly<Record<string, PrefabFile>>): string[] {
  const own = caseKey(key);
  return Object.keys(files)
    .filter((k) => caseKey(k) !== own && (files[k]!.entities ?? []).some((e) => nestedKey(e) === own))
    .sort();
}

/** The longest line `prefabText` keeps a list or an object on, indent and key included. */
const PREFAB_WIDTH = 100;

/**
 * A prefab file as the editor writes every one, laid out as one written by
 * hand: two spaces; the file, its `entities` and each entity a line a key;
 * below that a list or an object on one line -- `["Transform", "Spin"]`,
 * `{ "px": 0.9, "py": 1.15 }` -- while its line stays within 100 characters,
 * else a line an element, by the same rule; a newline at the end. So a field
 * changed is a line changed in git, and an agent reads the file as a person
 * does. Keys in the order the object has them: `clipToPrefab` keeps a file's own.
 */
export function prefabText(file: PrefabFile): string {
  const inline = (v: unknown): string => {
    if (Array.isArray(v)) return v.length === 0 ? '[]' : `[${v.map(inline).join(', ')}]`;
    if (v !== null && typeof v === 'object') {
      const entries = Object.entries(v).filter(([, x]) => x !== undefined);
      return entries.length === 0 ? '{}' : `{ ${entries.map(([k, x]) => `${JSON.stringify(k)}: ${inline(x)}`).join(', ')} }`;
    }
    return JSON.stringify(v);
  };
  /** `v` after `lead` (the indent and key) on a line: inline if it fits and is deep enough, else a line an element. */
  const print = (v: unknown, indent: string, lead: number, depth: number): string => {
    const one = inline(v);
    // The file, its `entities` and each entity: a line a key, always.
    const always = depth === 0 || depth === 2 || (depth === 1 && Array.isArray(v));
    if (v === null || typeof v !== 'object' || one.length <= 2 || (!always && lead + one.length + 1 <= PREFAB_WIDTH)) return one;
    const inner = `${indent}  `;
    if (Array.isArray(v)) return `[\n${v.map((x) => `${inner}${print(x, inner, inner.length, depth + 1)}`).join(',\n')}\n${indent}]`;
    const entries = Object.entries(v).filter(([, x]) => x !== undefined);
    return `{\n${entries.map(([k, x]) => {
      const key = `${JSON.stringify(k)}: `;
      return `${inner}${key}${print(x, inner, inner.length + key.length, depth + 1)}`;
    }).join(',\n')}\n${indent}}`;
  };
  return `${print(file, '', 0, 0)}\n`;
}

/** A new prefab: one entity, `Transform`, called `name`. */
export function newPrefab(name: string): PrefabFile {
  return { is: 'vibebase.prefab', version: 1, entities: [{ id: 'root', name, parent: null, components: ['Transform'] }] };
}

/** A variant of `base`: a prefab whose root is an instance of it -- by its reference, `{ uid, key }` where it has a uid -- no overrides. */
export function variantOf(base: string): PrefabFile {
  return { is: 'vibebase.prefab', version: 1, entities: [{ id: 'base', prefab: keyRef('prefabs', base), parent: null }] };
}

/** A name for a new prefab in `folder` from the folder's name: `crates` gives `crate`, `props` `prop`; `prefab` at the top. */
export function nameFromFolder(folder: string): string {
  const last = folder === PREFABS_DIR || !folder.startsWith(`${PREFABS_DIR}/`) ? 'prefab' : folder.slice(folder.lastIndexOf('/') + 1);
  return last.length > 3 && last.endsWith('s') && !last.endsWith('ss') ? last.slice(0, -1) : last;
}

/** The first of `stem`, `stem-2`, `stem-3`… that `taken` does not have: a file name, `.prefab` on. */
export function freeName(stem: string, taken: (name: string) => boolean): string {
  for (let n = 1; ; n++) {
    const name = `${n === 1 ? stem : `${stem}-${n}`}${PREFAB_SUFFIX}`;
    if (!taken(name)) return name;
  }
}

/**
 * `text` with its `"pool"` as `pool` -- in its place if it has one, else
 * after `"version"` -- or taken out, for null. Written whole if the text is
 * not laid out as a prefab file usually is.
 */
export function withPool(text: string, pool: { warm: number; max: number } | null): string {
  const said = pool ? `"pool": { "warm": ${pool.warm}, "max": ${pool.max} }` : '';
  const at = /"pool"\s*:\s*\{[^{}]*\}/;
  if (at.test(text)) {
    if (pool) return text.replace(at, said);
    return text.replace(/\n?[ \t]*"pool"\s*:\s*\{[^{}]*\}\s*,/, '').replace(/,\s*"pool"\s*:\s*\{[^{}]*\}/, '');
  }
  if (!pool) return text;
  const version = /("version"\s*:\s*\d+\s*,)(\s*)/;
  if (version.test(text)) return text.replace(version, (_m, v: string, gap: string) => `${v}${gap}${said},${gap}`);
  const file = JSON.parse(text) as PrefabFile;
  return prefabText({ ...file, pool });
}

/** One file written, as `PUT prefab` takes it. */
export interface PrefabWrite {
  path: string;
  text: string;
  /** A new file: `PUT prefab { create }`, refused if one is there. */
  create?: boolean;
}

/**
 * `writes` in order as one step, `label` its name. Undone the last first: a
 * file it made to the trash, a file it changed written back as it was; redone
 * as first done. One refused stops the rest, and those done are undone with it
 * -- a half-done write of several is never a step.
 */
export function writePrefabsEdit(api: PrefabsApi, label: string, writes: readonly PrefabWrite[]): Edit {
  /** Each write's text before, as the last doing answered: null for one it made. */
  let before: (string | null)[] = [];
  const doAll = async (): Promise<Answered> => {
    before = [];
    let last: PrefabAnswer | undefined;
    try {
      for (const w of writes) {
        last = await api.putPrefab(w.path, w.text, w.create ?? false);
        before.push(last.before);
      }
    } catch (err) {
      if (before.length > 0) await undoAll().catch(() => undefined);
      throw err;
    }
    return last!;
  };
  const undoAll = async (): Promise<Answered> => {
    let last: WriteAnswer | undefined;
    for (let i = before.length - 1; i >= 0; i--) {
      const w = writes[i]!;
      const was = before[i]!;
      last = was === null ? await api.remove([w.path], true) : await api.putPrefab(w.path, was);
    }
    return last!;
  };
  return { label, first: doAll, redo: doAll, undo: undoAll };
}
