/**
 * The Assets panel's Folders column, on its left (Docs/assets-tool.md §3): a
 * tab a root across its head -- **Assets** (`src/assets/`), **Packs** while
 * there is a pack, **Source** (`AssetsSource/`), any other a game has, and the
 * **Trash** -- and under it the chosen root's folders at the top level, no
 * project, root or section row above them -- the Trash's its slots as dated
 * folders -- from the client index (`model.ts`'s `folderTree`), drawn with
 * `virtual.ts`'s `mount`, one row a folder keyed by its path.
 *
 * - **A column of the panel, not a side card**: its width its own, dragged by
 *   the grip on its right edge (`panels['assets-folders']`, as the side card
 *   it was kept it), folded to a tab at the panel's left edge -- and folded
 *   first when the panel is narrow (`FILES_ROOM`): the tab then shows it over
 *   the files until a folder is chosen. `side` answers as a side panel does.
 *
 * - **The tab is the open folder's root**: a folder opened anywhere -- a
 *   twin, Show in Assets, a search's Folder cell, a drop landed -- brings its
 *   tab up (the tool's `openFolder`); a tab pressed opens the folder last open
 *   under it this session, else its root, whose own files the files card
 *   lists with its folders. A tab is a drop target for its root, and carries
 *   the root's marks, `⚠` and size, as a root's row did.
 * - **Each row says what needs a hand under it** (`marks.ts`): the worst
 *   one's glyph in its colour and how many in all, `↻ 2`; the counts in words
 *   on hover -- the project's, everything's -- and how many are out of the
 *   build, which never need a hand ("2 out of the build").
 * - **And what it holds** (`budget.ts`, kept up the changed paths): a folder
 *   under Assets or a pack its bytes, what ships from it -- Assets' own the
 *   boot set's, amber over the budget; one on the Source side how many files,
 *   their bytes on hover.
 * - **Twins**: a folder under Source shows `⇄` to its twin under Assets or
 *   Packs, and back, where the twin has files; a click opens it.
 * - **Tools**: a root with a source under it unmade for a tool `GET tools`
 *   says is missing or lacking carries `⚠`; a click opens Config ▸ Assets ▸
 *   Tools, that tool's path field focused.
 * - **Named by `naming.ts`**: the roots by their titles, the Trash's slots by
 *   when, each row's hover what it is.
 * - **The open folder is the files card's**: a click, or the arrows with the
 *   focus here, opens one; Enter takes the focus to the files.
 * - **A row is a drop target** -- files from the desktop import into it, tiles
 *   move -- found by the tool's `dnd.ts` from its `data-path`; and its name is
 *   made the rename field in place (`editName`).
 */
import { ROOTS, TRASH } from '@vibe/pipeline/kinds';
import { AUTO_SLOT, baseName, twin } from '@vibe/pipeline/paths';
import { keepPref, loadPrefs, PANEL_MIN } from '../../prefs.ts';
import { control, el, icon, iconButton, letGo, type SidePanel } from '../../shell.ts';
import { mount, type Mounted } from '../../virtual.ts';
import type { ClientIndex } from '../model.ts';
import { sayBytes, sizeSaid, type FolderSizes } from './budget.ts';
import { COLOUR_CLASS, excludedText, folderMark, type FolderCounts } from './marks.ts';
import type { Naming } from './naming.ts';

/** A row's height in the tree, in CSS pixels. */
const ROW = 24;
/** How far in each level of depth puts a folder's name. */
const INDENT = 14;
/** The column's width as it first opens, and its preference's name -- as the side card it was kept it. */
const FOLDERS_WIDTH = 240;
const PREF = 'assets-folders';
/** What the files keep beside the column at least: a panel narrower than the column and this folds the column first. */
const FILES_ROOM = 300;

/** What the Folders card asks of the tool. */
export interface FoldersHost {
  readonly index: ClientIndex;
  readonly naming: Naming;
  readonly counts: FolderCounts;
  /** Every folder's size, kept as files change. */
  readonly sizes: FolderSizes;
  /** The boot set's budget, in bytes. */
  readonly budget: number;
  /** The folder open in the files card; null while a search of every folder is up -- no folder is marked open then. */
  open(): string | null;
  /** The roots that have a tab, in order; and the one up, whose folders the tree shows. */
  tabs(): readonly string[];
  tab(): string;
  /** A tab pressed: its root's folder last open, or the root. */
  chooseTab(root: string): void;
  /** The folders unfolded. */
  expanded(): readonly string[];
  /** One unfolded or folded, kept. */
  setExpanded(folder: string, on: boolean): void;
  /** A row clicked, or walked to by key: open in the files card. */
  choose(folder: string): void;
  /** A row's menu, at a point on the page. */
  menu(folder: string, at: { x: number; y: number }, byKey: boolean): void;
  /** The tools a root has a source unmade for that are missing or lacking: its `⚠`. */
  toolsWanted(root: string): string[];
  /** Config ▸ Assets ▸ Tools brought up, that tool's path field focused. */
  openTools(tool?: string): void;
  /** The card folded away, or back: a focus on it moves to a card that is seen. */
  folded(folded: boolean): void;
}

export interface Folders {
  readonly card: HTMLElement;
  /** The title row: lit while the card has the focus. */
  readonly head: HTMLElement;
  readonly side: SidePanel;
  /** The rows read again from the index, and drawn the next frame. */
  refresh(): void;
  /** The open folder's row in view: only just, or in the middle. */
  reveal(middle?: boolean): void;
  /** ↑ ↓, PageUp, PageDown: the folder `by` rows on opened. */
  walk(by: number): void;
  /** The last row opened. */
  last(): void;
  /** ← →: fold or unfold the open folder; folded, ← to its parent; unfolded, → into its first folder. */
  fold(open: boolean): void;
  /** Rows a page holds, as the list is now. */
  readonly page: number;
  /** The open folder's row, if it is drawn: where the menu key puts the menu. */
  row(): HTMLElement | undefined;
  /** `field` in place of `path`'s name, its row brought into view; false if it is not drawn. Taken away by `endEdit`. */
  editName(path: string, field: HTMLElement): boolean;
  endEdit(): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}

interface FolderRow {
  path: string;
  depth: number;
  folders: number;
}

/**
 * The column made foldable and as wide as dragged, answering as a side panel
 * does (`SidePanel`): `folded` is true while it is out of sight -- folded, or
 * the panel too narrow for it -- and `setFolded(false)` brings it back,
 * over the files while the panel is narrow.
 */
function foldersColumn(within: HTMLElement, column: HTMLElement, changed: (folded: boolean) => void): SidePanel & { chosen(): void } {
  const kept = loadPrefs().panels[PREF];
  let width = kept?.width ?? FOLDERS_WIDTH;
  let folded = kept?.folded ?? false;
  /** The panel narrower than the column and the files' room: the column out of sight unless asked over the files. */
  let narrow = false;
  let over = false;
  const keep = (): void => keepPref('panels', { ...loadPrefs().panels, [PREF]: { width, folded } });

  const grip = el('div', 'ed-as-col-grip');
  grip.title = 'Drag to make the folders wider or narrower; double-click for their usual width';
  const fold = letGo(iconButton('ui', 'foldLeft', 'Fold the folders away: the tab at the panel\'s edge brings them back', () => setFolded(true), 'ed-icon-button ed-fold'));
  const tab = letGo(control('ui', 'ed-as-col-tab'));
  const marked = el('span', 'ed-tab-mark');
  marked.hidden = true;
  tab.append(icon('foldRight'), el('span', undefined, 'Folders'), marked);
  let markTitle = '';
  tab.addEventListener('click', () => (folded ? setFolded(false) : narrow ? setOver(!over) : undefined));
  column.before(tab);
  column.after(grip);

  const seen = (): boolean => !folded && (!narrow || over);
  /** Seen as last told: `changed` hears only a change, never the first draw. */
  let shown = seen();
  const show = (): void => {
    column.style.width = `${width}px`;
    column.classList.toggle('ed-as-over', narrow && over && !folded);
    column.hidden = !seen();
    grip.hidden = !seen() || narrow;
    tab.hidden = seen() && !narrow;
    tab.setAttribute('aria-pressed', String(seen()));
    tab.title = `${folded ? 'Show the folders again' : narrow ? (over ? 'Put the folders away: the panel is narrow' : 'Show the folders over the files: the panel is too narrow for both') : ''}${markTitle ? `: ${markTitle}` : ''}`;
    if (shown !== seen()) {
      shown = seen();
      changed(!shown);
    }
  };
  const setOver = (next: boolean): void => {
    over = next;
    show();
  };
  function setFolded(next: boolean): void {
    if (!next && narrow) over = true;
    if (next === folded) return show();
    folded = next;
    if (folded) over = false;
    keep();
    show();
  }
  // The panel's width as it lays out: too narrow for both, the column goes first.
  const watch = new ResizeObserver(() => {
    const now = within.clientWidth > 0 && within.clientWidth < width + FILES_ROOM;
    if (now === narrow) return;
    narrow = now;
    if (!narrow) over = false;
    show();
  });
  watch.observe(within);

  let press: { id: number; x: number; from: number } | null = null;
  grip.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    press = { id: event.pointerId, x: event.clientX, from: width };
    grip.setPointerCapture(event.pointerId);
    grip.classList.add('ed-dragging');
  });
  grip.addEventListener('pointermove', (event) => {
    if (!press || press.id !== event.pointerId) return;
    // Held so the files keep their room, and never under a side card's least.
    width = Math.round(Math.max(PANEL_MIN, Math.min(press.from + event.clientX - press.x, within.clientWidth - FILES_ROOM)));
    column.style.width = `${width}px`;
  });
  const release = (event: PointerEvent): void => {
    if (!press || press.id !== event.pointerId) return;
    press = null;
    grip.classList.remove('ed-dragging');
    if (grip.hasPointerCapture(event.pointerId)) grip.releasePointerCapture(event.pointerId);
    keep();
  };
  grip.addEventListener('pointerup', release);
  grip.addEventListener('pointercancel', release);
  // mcp: ui -- the column's width put back
  grip.addEventListener('dblclick', () => {
    width = FOLDERS_WIDTH;
    keep();
    show();
  });
  show();

  return {
    fold,
    get folded() {
      return !seen();
    },
    setFolded,
    refresh: show,
    mark(text, title = '') {
      marked.textContent = text;
      marked.hidden = text === '';
      markTitle = title;
      show();
    },
    // A folder chosen while they were shown over the files: put away, the files seen again.
    chosen() {
      if (over) setOver(false);
    },
    dispose() {
      watch.disconnect();
      grip.remove();
      tab.remove();
      fold.remove();
    },
  };
}

export function createFolders(parent: HTMLElement, host: FoldersHost): Folders {
  const { index, naming } = host;
  const card = el('div', 'ed-as-folders');
  const head = el('div', 'ed-line ed-as-head');
  const tabRow = el('div', 'ed-as-tabs');
  tabRow.setAttribute('role', 'tablist');
  const tools = el('span', 'ed-tree-tools');
  // Every folder of every tab folded: the top level stays in sight.
  const foldAll = iconButton('ui', 'collapse', 'Fold every folder', () => {
    for (const path of [...host.expanded()]) host.setExpanded(path, false);
    refresh();
  });
  tools.append(foldAll);
  head.append(tabRow, tools);
  const list = el('div', 'ed-rows ed-as-folder-list');
  list.setAttribute('role', 'tree');
  card.append(head, list);
  parent.append(card);
  // Told only as it changes, after this is made: `mounted` is there by then.
  const side = foldersColumn(parent, card, (folded) => {
    if (!folded) mounted.invalidate();
    host.folded(folded);
  });
  tools.append(side.fold);

  let rows: FolderRow[] = [];
  /** A row's name made a field: whose, and the label it hides. */
  let editing: { path: string; field: HTMLElement; label: HTMLElement } | null = null;

  function endEdit(): void {
    if (!editing) return;
    editing.field.remove();
    editing.label.hidden = false;
    editing = null;
  }

  /** The folders in `folder`, in name order -- the Trash's slots newest first, the automatic one first of all. */
  function foldersIn(folder: string): string[] {
    const folders = index.childrenOf(folder).folders;
    if (folder === TRASH) return folders.sort((a, b) => (baseName(a) === AUTO_SLOT ? -1 : baseName(b) === AUTO_SLOT ? 1 : a < b ? 1 : -1));
    return folders.sort((a, b) => (baseName(a).toLowerCase() < baseName(b).toLowerCase() ? -1 : 1));
  }

  function read(): void {
    const open = new Set(host.expanded());
    rows = [];
    const walk = (path: string, depth: number): void => {
      const kids = foldersIn(path);
      rows.push({ path, depth, folders: kids.length });
      if (open.has(path)) for (const kid of kids) walk(kid, depth + 1);
    };
    // The tab's root's folders, at the top level: the root itself is the tab.
    for (const kid of foldersIn(host.tab())) walk(kid, 0);
    drawTabs();
  }

  /** The tabs, drawn again with the rows: each its root's title, marks, ⚠ and size, the one up pressed. */
  function drawTabs(): void {
    const up = host.tab();
    const made = host.tabs().map((root) => {
      const tab = letGo(control('ui', 'ed-as-tab'));
      tab.dataset.path = root;
      tab.setAttribute('role', 'tab');
      tab.setAttribute('aria-selected', String(root === up));
      tab.append(el('span', 'ed-as-tab-name', naming.title(root)));
      const hover = [naming.about(root)];
      const out = excludedText(host.counts.of(root));
      if (out) hover.push(out);
      // What it holds, as a root's row said it: the boot set's bytes against its budget, amber over it.
      const shipping = naming.shipsAt(root);
      if (root === ROOTS.boot.dir) {
        const bytes = host.sizes.of(root).ships;
        const over = bytes > host.budget;
        hover.push(`The boot set: ${sayBytes(bytes)} downloads before the first frame, of a budget of ${sayBytes(host.budget)}${over ? ' -- over it' : ''}`);
        if (over) tab.append(el('span', 'ed-as-mark ed-as-amber', '!'));
      } else if (shipping !== undefined) hover.push(sizeSaid(host.sizes.of(root), shipping).title);
      // The tools its unmade sources want: ⚠, a click to where their paths are set.
      const wanted = host.toolsWanted(root);
      if (wanted.length > 0) {
        const warn = el('span', 'ed-as-chip ed-as-amber', '⚠');
        warn.title = `Sources under here are unmade for want of ${wanted.join(', ')}: set ${wanted.length === 1 ? 'its path' : 'their paths'} in Config ▸ Tools`;
        // mcp: ui -- Config's Tools page opened
        warn.addEventListener('click', (event) => {
          event.stopPropagation();
          host.openTools(wanted[0]);
        });
        tab.append(warn);
      }
      const mark = folderMark(host.counts.of(root));
      if (mark) {
        const shown = el('span', `ed-as-mark ${COLOUR_CLASS[mark.colour]}`, mark.glyph);
        shown.title = mark.title;
        tab.append(shown);
      }
      tab.title = hover.join('\n');
      tab.addEventListener('click', () => host.chooseTab(root));
      tab.addEventListener('contextmenu', (event) => {
        event.preventDefault();
        host.menu(root, { x: event.clientX, y: event.clientY }, false);
      });
      return tab;
    });
    tabRow.replaceChildren(...made);
  }

  const mounted: Mounted = mount({
    list,
    rowHeight: () => ROW,
    perRow: () => 1,
    count: () => rows.length,
    key: (i) => rows[i]!.path,
    make: (i) => make(rows[i]!.path),
    update: (row, i) => update(row, rows[i]!),
  });

  /** A row's element: the parts that stay, its handlers reading its path from the element. */
  function make(path: string): HTMLElement {
    const row = el('div', 'ed-row ed-as-folder');
    row.dataset.path = path;
    row.setAttribute('role', 'treeitem');
    const caret = el('span', 'ed-caret');
    // mcp: ui -- a folder unfolded
    caret.addEventListener('click', (event) => {
      event.stopPropagation();
      const at = row.dataset.path!;
      host.setExpanded(at, !host.expanded().includes(at));
      refresh();
    });
    const name = el('span', 'ed-cell-name');
    name.append(caret, el('span', 'ed-name'));
    const extra = el('span', 'ed-as-folder-extra');
    row.append(name, extra);
    // mcp: ui -- a folder shown
    row.addEventListener('click', (event) => {
      if (editing && editing.field.contains(event.target as Node)) return;
      host.choose(row.dataset.path!);
      side.chosen();
    });
    row.addEventListener('contextmenu', (event) => {
      if (editing && editing.field.contains(event.target as Node)) return;
      event.preventDefault();
      host.menu(row.dataset.path!, { x: event.clientX, y: event.clientY }, false);
    });
    return row;
  }

  function update(row: HTMLElement, { path, depth, folders }: FolderRow): void {
    row.dataset.path = path;
    const open = host.open();
    row.setAttribute('aria-selected', String(open === path));
    row.setAttribute('aria-expanded', String(folders > 0 && host.expanded().includes(path)));
    const name = row.firstElementChild as HTMLElement;
    name.style.paddingLeft = `${depth * INDENT}px`;
    const caret = name.firstElementChild as HTMLElement;
    caret.textContent = folders === 0 ? '' : host.expanded().includes(path) ? '▾' : '▸';
    // By its class: a rename field may sit after it.
    const label = name.querySelector(':scope > .ed-name') as HTMLElement;
    label.textContent = naming.title(path);
    // A kind's folder titled by its key type, dim beside its name: `tilemaps  Tilemap`.
    const kind = naming.kindOf(path);
    if (kind) label.append(el('span', 'ed-dim ed-as-kind', ` ${kind.type}`));
    // What is out of the build under it, on hover: never a need, so no mark of its own.
    const out = excludedText(host.counts.of(path));
    label.title = `${naming.about(path)}${out ? `\n${out}` : ''}`;
    const extra = row.lastElementChild as HTMLElement;
    extra.replaceChildren();
    // The twin, where it has files.
    const other = twin(path);
    if (other !== undefined && index.tree().has(other)) {
      const go = control('ui', 'ed-as-chip ed-as-twin', '⇄');
      go.title = `Its twin: ${naming.say(other)}`;
      go.addEventListener('click', (event) => {
        event.stopPropagation();
        host.choose(other);
      });
      extra.append(go);
    }
    // What it holds: where it ships its bytes, on the Source side its files.
    const shipping = naming.shipsAt(path);
    if (shipping !== undefined) {
      const { text, title } = sizeSaid(host.sizes.of(path), shipping);
      const said = el('span', 'ed-as-bytes', text);
      said.title = title;
      extra.append(said);
    }
    const mark = folderMark(host.counts.of(path));
    if (mark) {
      const shown = el('span', `ed-as-mark ${COLOUR_CLASS[mark.colour]}`, mark.glyph);
      shown.title = mark.title;
      extra.append(shown);
    }
  }

  function refresh(): void {
    read();
    mounted.invalidate();
  }

  const at = (): number => {
    const open = host.open();
    return open === null ? -1 : rows.findIndex((r) => r.path === open);
  };

  function reveal(middle = false): void {
    const i = at();
    if (i >= 0) mounted.reveal(i, middle);
  }

  /** The row `i` opened, held to the list's ends. */
  function go(i: number): void {
    const next = rows[Math.max(0, Math.min(rows.length - 1, i))];
    if (next) host.choose(next.path);
  }

  return {
    card,
    head,
    side,
    refresh,
    reveal,
    walk(by) {
      const i = at();
      go(i < 0 ? (by > 0 ? 0 : rows.length - 1) : i + by);
    },
    last: () => go(rows.length - 1),
    fold(open) {
      const i = at();
      if (i < 0) return;
      const { path, folders } = rows[i]!;
      const shown = host.expanded().includes(path);
      if (folders > 0 && shown !== open) {
        host.setExpanded(path, open);
        refresh();
      } else if (open) {
        if (folders > 0) go(i + 1);
      } else {
        // Folded already: to the folder it is in -- a top-level one's the tab's root.
        const up = naming.parent(path);
        if (up !== null) host.choose(up);
      }
    },
    get page() {
      return Math.max(1, Math.floor(list.clientHeight / ROW) - 1);
    },
    row: () => {
      const open = host.open();
      return open === null ? undefined : mounted.shown(open);
    },
    editName(path, field) {
      endEdit();
      const i = rows.findIndex((r) => r.path === path);
      if (i < 0) return false;
      mounted.reveal(i);
      const row = mounted.shown(path);
      const label = row?.querySelector<HTMLElement>(':scope > .ed-cell-name > .ed-name');
      if (!row || !label) return false;
      label.hidden = true;
      label.after(field);
      editing = { path, field, label };
      return true;
    },
    endEdit,
    // The panel it is in comes and goes with the tool: the column only draws again as it comes.
    setVisible(visible) {
      if (!visible) return;
      side.refresh();
      refresh();
    },
    dispose() {
      mounted.dispose();
      side.dispose();
      card.remove();
    },
  };
}
