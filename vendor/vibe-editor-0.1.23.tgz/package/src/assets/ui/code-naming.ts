/**
 * What game code names, before a move or a rename (Docs/asset-ids.md rule 5):
 * files name an asset by uid and follow it wherever it goes, but code holds
 * keys -- `prefab('crates/big')`, `Assets.instance('props/crate')`,
 * `Audio.sfx('ui/click')` -- so an asset any code names keeps its key until
 * the code changes first. One check for every kind:
 *
 * - **`keysOf`**: the keys a move or a rename of a path changes -- a file's
 *   own (a source's, each of its exports'), or every key under a folder and
 *   its twin, a prefab's too.
 * - **`codeNaming`**: each key's uses in `.ts` files (`GET uses`, matched in
 *   any case, as a lookup takes it), by file and line -- the refusal's words,
 *   or null.
 *
 * The rules are the pipeline's (`@vibe/pipeline/code-naming`), one implementation for the panel and the studio's
 * `asset_move` with no tab (Docs/mcp.md M3). Pure: node tests it (`code-naming.test.ts`).
 */
import type { Entry } from '@vibe/pipeline/assets-types';
import { codeNaming, namedKeys } from '@vibe/pipeline/code-naming';
import { prefabPathOf } from './prefab-steps.ts';

/**
 * The keys a move or a rename of `path` changes: a file's own (a source's, each export's), or every key under a
 * folder and its twin, and every prefab's of `prefabs` (the keys the game has) under it -- at most `cap`. The
 * pipeline's `namedKeys`, each prefab's file where this page has it (`prefabPathOf`).
 */
export function keysOf(path: string, isDir: boolean, entries: ReadonlyMap<string, Entry>, prefabs: readonly string[], cap = Infinity): string[] {
  return namedKeys(path, isDir, entries, prefabs.map((key) => ({ key, path: prefabPathOf(key) })), cap);
}

export { codeNaming };
