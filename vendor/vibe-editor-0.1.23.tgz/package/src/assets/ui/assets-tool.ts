/**
 * The editor's Assets panel (`assetsTool`, key `4`; Docs/assets-tool.md): art
 * in and out of the game -- one card along the bottom of the Scene tab
 * (`within` it), the folders in its left column (`folders.ts`), the open
 * folder's files on its right (`files.ts`), their
 * title row across its top; the chosen file in the tab's right panel
 * (`assets-inspector.ts`) while a file was chosen last -- a file chosen
 * clears the entities chosen, and an entity chosen the files (`ctx.chose`,
 * `letGo`), one selection across the tab -- built on part one's
 * client library (`api.ts`, `live.ts`, `model.ts`, `steps.ts`). This file is
 * the wiring: the panel, the focus, the keys, the hint, the menus, the steps.
 *
 * - **The files' side of the Scene tab**: a press in the panel, or in the
 *   inspector while it shows a file, gives it the keys (`cards`, the host's
 *   `sides.ts`); the tree, the scene and the entity inspector are the world's
 *   side. Its keys act only while it has them -- Delete trashes a file here,
 *   destroys an entity there -- but its fold (`Shift+Space`, `anySide`).
 * - **Its own stack**: every step is a call to the dev server, on the tool's
 *   own `History` (`ToolInstance.history`, `busy()`): while the panel has the
 *   keys Z, Y, the bars and the History card ("History · Assets") are its. An
 *   export is one step (`export-step.ts`).
 * - **One card has the keys**: Folders, Files or the preview has the focus,
 *   lit on its title row while the panel has the keys; F6 or Alt+→ moves it
 *   (Tab is the browser's), Enter goes forward, Esc back. A key acts on the
 *   focused card's choice. A card folded away -- or the preview, while the
 *   right panel is the entity inspector -- gives the focus to the next one seen.
 * - **The panel's height** is dragged by its top edge and kept (`stripHeight`);
 *   folded (`Shift+Space`, its head's button) it is a small tab on the bottom
 *   edge, as a side panel folded is on its own -- `ASSETS` and the unfold
 *   arrow, a click on it unfolding it -- and kept so. The editor's dock sits
 *   on it either way (`ed-bottom-card`).
 * - **One guard, by scope**: every key's `when` is made from its row's scope
 *   word (`assets-keys.ts`) and its two flags, from one `scoped` record --
 *   no key's condition is written anywhere else. A control of the editor's
 *   with the focus stands the card keys still; every button a pointer used
 *   lets the focus go, the tool's and the host's alike (`shell.ts`'s `letGo`).
 * - **Esc, the last first**: the menu, a drop-down (the columns, Move to…),
 *   the rename field (its own, the browser's close request), the import sheet,
 *   a question in the inspector, the focus in the preview back to the files.
 *   Never while the tab is away.
 * - **Only folders that are**: a file is revealed in the folder that lists it
 *   (`folderOf`: a trashed one's slot), and a folder gone from disk gives way
 *   to its nearest one that is (`settle`) -- past the roots, the tab's root,
 *   never the project -- so no phantom is shown or kept in the preferences.
 * - **A tab a root** in the Folders column (Assets, Source, Trash): the tab
 *   up is the open folder's root, so every way to a folder brings its tab up
 *   (`openFolder`, kept as `tab`); a tab pressed, or `]` `[` in Folders,
 *   opens the folder last open under it this session, else its root.
 * - **The project** (`''`, `model.ts`' `PROJECT`): the index's top, what a
 *   search of every folder is over; no tab, never opened here; no write but
 *   Export all stale (`folderTakes`), a drop on it refused.
 * - **Issues** (`Shift+I`, on the files card's title row): only what needs a
 *   hand under the open folder, flat, kept; it writes nothing, so read mode
 *   keeps it.
 * - **Art comes in** (§5): files from the desktop dropped on a folder, the
 *   files card or the inspector (`dnd.ts`), Import ▾ and `I`, a paste -- each
 *   the import sheet over the files card (`import-sheet.ts`), one step.
 * - **Every edit a step** (`file-steps.ts`, §8's Undo table): rename where the
 *   name is (F2, Shift+Enter, the menu, the inspector head's name), Move to…
 *   and a tile dragged onto a folder, Delete -- a folder asking first -- New
 *   folder, Duplicate, Copy to…, Keep this one, a hand export, Restore and
 *   Restore here, Restore all, in the build or out of it (a row's tick, the
 *   inspector's, the menu, `Shift+B` for the files chosen); Empty, for good,
 *   asks first and is no step.
 * - **A job's message is cheap** (§9): the strip, and its family's marks where
 *   they are drawn -- nothing else is drawn again.
 * - **It degrades**: read mode (another machine) has no write control and no
 *   key that writes; bundle view (no dev server) lists what the build bundled;
 *   a server gone says so (`banners.ts`).
 * - **What the game will see** (§6.2, §9): the chosen file previewed in the
 *   inspector (`assets-preview.ts`) through the tool's one preview renderer,
 *   one scratch decode and one sound player, made here and handed in; the
 *   tiles' thumbnails through one queue (`thumbs.ts`), asked in the order the
 *   files card says -- the preview's own first -- held while a clip or a sound
 *   plays, the preview is dragged or the grid scrolls; Stats and warnings
 *   (`assets-stats.ts`, `warnings.ts`).
 * - **Options are fields, defaults grey** (§6.5, `assets-options.ts`): a
 *   change of a source's -- or of several sharing a recipe, or of a folder's
 *   `export.json` -- is one step through `PUT sidecar`, which re-exports;
 *   undone, the export is made again, byte for byte. Uses (§6.6) are `GET
 *   uses`, asked once a key.
 * - **Several chosen step through the preview** (◂ ▸, and ← → with it
 *   focused): the one stepped to is `latest`, so the keys walk on from it.
 * - **Drag and drop across the tab**: a prefab's or a model's tile onto the
 *   scene or a tree row is placed by the Scene tool (`edits.ts`, `tree.ts`), a
 *   material's onto an entity there worn by it -- this one only says where it
 *   would land -- and the tree's rows onto a folder under
 *   `prefabs/` are saved as a prefab there (`entitiesDropped`).
 * - **A game's tool** is `createAssetsTool({…})`: a budget, its own menu
 *   items, list columns, root titles, keys, previews, warnings and stats -- in
 *   its own file, nothing here touched (§12; the example in
 *   `examples/tools/assets-tool/index.ts`).
 */
import { isMac, keyLabel, modName } from '@vibe/engine/debug';
import type { ExportAsAnswer, Options, OptionValue, ToolLook, Use } from '@vibe/pipeline/assets-types';
import { KINDS, MATERIAL_SUFFIX, PREFAB_SUFFIX, ROOTS, SCENE_SUFFIX, TRASH } from '@vibe/pipeline/kinds';
import { baseName, dirName, exportAsValue, extOf, folderRecordPath, fromTrash, joinPath, keyOf, locate, recordPath, splitName, strayFile, twin, under } from '@vibe/pipeline/paths';
import { Assets, Audio } from '@vibe/engine/assets';
import {
  caseKey, checkPrefab, type Component, type Entity, fieldProblem, fieldValue, isTyping, label, level, levelKeys, materialDiff, materialFile, materialProblems, materialSet, materialText,
  newMaterial, NONE, onMaterialFiles, type PrefabFile, prefabFiles, sceneIfPresent, showMaterial, startScene,
} from '@vibe/engine';
import { carriesMaterial } from '../../prefab-drop.ts';
import { liveMaterials } from '../materials-live.ts';
import { materialBlock, type MaterialBlockHost } from './material-block.ts';
import { inPhysmats, NEW_PHYSMAT, PHYSMAT_SUFFIX, PHYSMATS_DIR, physmatKeyOf, physmatSet, physmatText } from '../physmat.ts';
import { dataIfPresent, parsePhysicsMaterial, PHYSICS_MATERIAL_DEFAULTS, type PhysicsMaterialFile } from '@vibe/engine';
import { physmatBlock, type PhysmatBlockHost } from '../../physics/physmat-block.ts';
import { inMaterials, MATERIALS_DIR, materialDrafts, materialKeyOf, materialPathOf, materialWriteEdit, wearersOf } from './material-steps.ts';
import { createHistory } from '../../history.ts';
import { createMenu, type MenuItem } from '../../menu.ts';
import { keepPref, loadPrefs, withOpen, type AssetsPrefs } from '../../prefs.ts';
import { addSheet, control, el, icon, iconButton, letGo } from '../../shell.ts';
import { dropUnder } from '../../drop.ts';
import type { EditorContext, EditorTab, ToolFact, ToolInstance } from '../../tool.ts';
import { tabId } from '../../tab-pages.ts';
import type { Mcp } from '../../mcp/declare.ts';
import type { Online } from '../api.ts';
import { assetApi, convertingHere, onConverting } from '../boot.ts';
import { createLive } from '../live.ts';
import { PROJECT, type Shown } from '../model.ts';
import { createSoundPlayer, decodeSound } from '../preview/audio.ts';
import { createPreviewRenderer, type PreviewRenderer } from '../preview/renderer.ts';
import { createScratchStore, decodeScratch, previewPath } from '../preview/scratch.ts';
import { createThumbs, thumbWantOf, thumbWhenReady, type ThumbWant } from '../preview/thumbs.ts';
import { createSteps, reasonOf } from '../steps.ts';
import { createAssetsInspector } from './assets-inspector.ts';
import { lockHost } from '../../inspector-lock.ts';
import { changeLabel, createRecords, fromSourceRoot, optionsEdit, optionWrites, type Field, type OptionsWrite, type Target } from './assets-options.ts';
import { createPreview, PREVIEWS, type PreviewRow } from './assets-preview.ts';
import { createStatsCache, STATS, statsKey, type StatsRow } from './assets-stats.ts';
import { ASSETS_KEYS, type AssetsKeyName, type Scope } from './assets-keys.ts';
import css from './assets.css?inline';
import { createBanners, writableUrl } from './banners.ts';
import { BUDGET, createSizes, sayBytes, sizeAll, sizeChanged } from './budget.ts';
import { createDnd, keyedFile, readList, type ReadDrop } from './dnd.ts';
import { createExportStep } from './export-step.ts';
import { adoptEdit, newModelEdit, type Adopted, type ModelStepHost } from './model-steps.ts';
import { dialogNote, showDialog } from '../../dialog.ts';
import { copyEdit, deleteFolderEdit, exportAsEdit, handExportEdit, includeEdit, keepEdit, moveEdit, newFolderEdit, renameEdit, restoreEdit, stemOf, trashEdit, type Edit, type EditHost } from './file-steps.ts';
import { codeNaming as codeNames, keysOf as namedKeys } from './code-naming.ts';
import { FILE_COLUMNS, keyOfRow, type FileColumn } from './files-columns.ts';
import { chosen, choosePaths, draggedPaths, familyHeads, folderOf, folderTakes, importRefused, isFolderPath, moveRefused, nearestFolder, NO_PATHS, partAlone, pinnedShowing, previewedOf, shownAt, stepOn, stepPinned, stepPreviewed, stillThere, type PathSelection, type Showing } from './files-selection.ts';
import { createFiles, type FilesMenu } from './files.ts';
import { createFolders } from './folders.ts';
import { pastedName } from './import-plan.ts';
import { createImportSheet } from './import-sheet.ts';
import { createJobsStrip } from './jobs-strip.ts';
import { countAll, countChanged, createCounts, flipsTo, isEntry, jobEnded, sourceOf, tickOf, ticksOf } from './marks.ts';
import { CLAUDE, createAgentRunner, useAgentAssets, type AgentAssets, type AgentDone } from './agent-assets.ts';
import { createNaming, filesText, keyWithStem, usesLine } from './naming.ts';
import { renameField, type RenameField, type Refused } from './rename-field.ts';
import { createToolsBlock } from './tools-block.ts';
import { restoreLabel, restoreNote, restoreQuestion, restoring, slotsNewestFirst } from './trash-actions.ts';
import { WARNINGS, type Warning } from './warnings.ts';
import { waveStrip } from './waveform.ts';
import { livePrefabs } from '../../prefabs-live.ts';
import { prefabBlock, strayBlock } from './prefab-block.ts';
import { holdsPrefab } from '../../level-keys.ts';
import { openScene, scenesHolding } from '../../config/scenes.ts';
import { newSceneSave, freeKey, NEW_SCENE, SCENES_DIR, sceneKeyOf, scenePathOf, sceneText } from '../scene-files.ts';

import { sceneBlock } from './scene-block.ts';
import { TOOLS_PAGE, toolsPage } from '../../config/tools.ts';
import * as THREE from 'three';
import { adderState } from '../../add-component.ts';
import { labelsState } from '../../labels-drop.ts';
import { changeRoot, createRootEdit, refusal as rootRefusal, type RootEdit, withPoolPlanned } from '../../root-edit.ts';
import { tagsState } from '../../tags-drop.ts';
import type { RootBlockHost } from './prefab-root-block.ts';
import { rootsOfChoice, saveAsPrefab, suggestKey } from '../../save-prefab.ts';
import { type PrefabsApi, freeName, nameFromFolder, newPrefab, PREFABS_DIR, prefabKeyOf, prefabPathOf, prefabText, variantOf, withPool, writePrefabsEdit } from './prefab-steps.ts';
import { tabKey } from '../../editor-keys.ts';

/** What New material names a file before it is named in place: `new-material.material`, `-2`… when taken. */
const NEW_MATERIAL = 'new-material';

/** What a game's key is told as it runs (§12): where the tool is, and a way to say what it did. */
export interface AssetsKeyAt {
  /** The folder open in the files card. */
  readonly folder: string;
  /** The files chosen there, the first shown first. */
  readonly paths: readonly string[];
  /** The card with the keys. */
  readonly card: 'folders' | 'files' | 'preview';
  /** A line on the bar and on the files card's status line for a few seconds; `bad`, said as a refusal. */
  say(text: string, bad?: boolean): void;
}

/** A key of a game's, for `createAssetsTool({ keys })`: `ASSETS_KEYS`' shape, with what it does. */
export interface AssetsToolKey {
  /** Global to MrDebug, as `editor: <name>`: begin it with the card or `assets`. */
  name: string;
  key?: string | readonly string[];
  help: string;
  /** The MCP tool that does what it does, `'ui'`, or why none does (`Mcp`: Docs/skills.md §2 rule 7). */
  mcp: Mcp;
  /** Where it is live: `free` if it names none. */
  scope?: Scope;
  /** It changes the project: off in read mode and bundle view. */
  writes?: boolean;
  /** It copies: off while text on the page is selected. */
  copy?: boolean;
  /** What it does: told where the tool is (the folder, the files chosen, the focused card) and how to say what it did. */
  run(at: AssetsKeyAt): void;
}

/**
 * What a game's own Assets tool may add (§12), each a row: nothing under
 * `packages/editor/src/assets/ui/` touched. The tables -- `previews`, `warnings`,
 * `stats` -- are merged over the tool's own by key, so a row of a game's
 * replaces the tool's of that name and the rest stay.
 */
export interface AssetsToolOptions {
  /** The boot set's budget, in bytes: 8 MB by default. */
  budget?: number;
  /** Every menu the tool opens, and the inspector's actions: the tool's items for those entries in, the list shown out. */
  menu?(entries: readonly Shown[], items: MenuItem[]): MenuItem[];
  /** List columns of the game's, after `FILE_COLUMNS`. */
  columns?: readonly FileColumn[];
  /** Root titles over `ROOT_TITLES`, by a root's key in `ROOTS` (`{ packs: 'DLC' }`), `trash` for the Trash's, `project` for the project's above them ("Project"). */
  titles?: Readonly<Record<string, string>>;
  /** Keys of the game's, after the tool's own. */
  keys?: readonly AssetsToolKey[];
  /** Preview rows over `PREVIEWS`, by extension (`usdz`) or kind (`levels`): `{ make(entry, ctx) → { root, play?, frame?, dispose } }`. */
  previews?: Readonly<Record<string, PreviewRow>>;
  /** Warnings over `WARNINGS`, by name: `{ when(entry, stats), say(entry, stats) }`, a threshold a named constant. */
  warnings?: Readonly<Record<string, Warning>>;
  /** Stats rows over `STATS`, by an entry's kind (`models`) or by what `GET stats` read (`model`): `{ lines(entry, stats) }`. */
  stats?: Readonly<Record<string, StatsRow>>;
}

/** The cards, in the order F6 walks them. */
type Card = 'folders' | 'files' | 'preview';
const CARDS: readonly Card[] = ['folders', 'files', 'preview'];

/** How long a line of what was done stays in the hint, in milliseconds. */
const SAID = 6000;
/** More than this many to export asks in the inspector first. */
const ASK_OVER = 10;
/** The files chosen that the agent's turn names, at most: the server takes 64 values a fact. */
const CHOSEN_SAID = 32;

/** The Assets tool with a game's additions (§12); `assetsTool` is it with none. A key name taken throws here, naming it. */
export function createAssetsTool(options: AssetsToolOptions = {}): EditorTab {
  const own = new Set<string>(ASSETS_KEYS.map((row) => row.name));
  for (const key of options.keys ?? []) {
    if (own.has(key.name)) throw new Error(`[assets] the key '${key.name}' is the Assets tool's own: name it otherwise`);
    own.add(key.name);
  }
  return {
    id: tabId('assets'),
    name: 'Assets',
    icon: 'assets',
    key: tabKey('assets'),
    // No tab of its own: the panel along the bottom of the Scene tab and the Model tab (Docs/modeler.md M6) -- its key
    // brings it up in whichever of them is up, else Scene, with the keys in the panel.
    within: ['entities', 'model'],
    // Locked on files, it pins their paths: another world loaded keeps the lock.
    pins: 'paths',
    help: 'The Assets panel along the bottom of the Scene and Model tabs, the keys in it: the originals in AssetsSource/, what ships, packs and the trash',
    create: (ctx) => createAssets(ctx, options),
  };
}

export const assetsTool: EditorTab = createAssetsTool();

function createAssets(ctx: EditorContext, options: AssetsToolOptions): ToolInstance {
  const { root } = ctx;
  const dropSheet = addSheet(css);
  const api = assetApi();
  // Made now for the index the cards read; it keeps nothing it hears until the tab first comes up (`start`).
  const live = createLive(api);
  const { index } = live;
  const history = createHistory();
  const counts = createCounts();
  /** Every folder's size -- its bytes, or on the Source side its files -- kept up the changed paths as the counts are. */
  const sizes = createSizes();
  const budget = options.budget ?? BUDGET;
  const columns = [...FILE_COLUMNS, ...(options.columns ?? [])];
  const naming = createNaming(options.titles ?? {}, () => index.trash, () => index.kinds);
  const previews = { ...PREVIEWS, ...options.previews };
  const warnings = { ...WARNINGS, ...options.warnings };
  const statsRows = { ...STATS, ...options.stats };

  let online: Online | null = null;
  let offline = false;
  let unanswered = false;
  let started = false;
  /** A file asked to be shown (`revealAsset`) before the index came: shown once it has, in place of the folder kept last time. */
  let revealing: string | null = null;
  /** The index in: what `start` waits for, so a reveal asked meanwhile lands after it. */
  let ready = false;
  let visible = false;
  /** The right panel is this tool's inspector: a file or a folder was chosen last, not an entity (`ctx.inspect`). */
  let inspecting = false;
  let prefs: AssetsPrefs = loadPrefs().assets;
  /** The folder open: the one kept, else the kept tab's root (Assets by default), the nearest that is once the index comes. */
  let folder = prefs.folder !== '' ? prefs.folder : prefs.tab !== '' ? prefs.tab : ROOTS.boot.dir;
  /** Each tab's folder last open this session, by its root: what its tab pressed opens again. */
  const lastIn = new Map<string, string>();
  {
    const root = naming.rootOf(folder);
    if (root !== undefined) lastIn.set(root, folder);
  }
  let selection: PathSelection = NO_PATHS;
  /** The right panel locked (`ctx.lock`): what its inspector showed as it was -- files, the folder -- followed as they move. Null unlocked. */
  let pinned: Showing | null = null;
  /** Of several chosen, the one ◂ ▸ stepped to and previewed: null for the first. */
  let stepped: string | null = null;
  let focus: Card = 'files';
  let tools: ToolLook[] | null = null;
  /** What was just done, for the hint, and until when. */
  let message: { text: string; bad: boolean; until: number } | null = null;
  /**
   * The export under way: how many jobs, how many ended. One number, not a
   * list: the steps run in series (`steps.ts`), so one export is under way at
   * most.
   */
  let exporting: { total: number; ended: number } | null = null;

  const writes = (): boolean => online === 'write';
  const keep = (change: Partial<AssetsPrefs>): void => {
    // The folder open is under the tab up: kept with it, so the tab comes back over a reload.
    const opened = change.folder;
    if (opened !== undefined) {
      const root = naming.rootOf(opened);
      if (root !== undefined) {
        change = { ...change, tab: root };
        lastIn.set(root, opened);
      }
    }
    prefs = { ...prefs, ...change };
    keepPref('assets', { ...loadPrefs().assets, ...change });
  };
  const hasFolder = (path: string): boolean => index.tree().has(path);
  /** Where a folder that is not there gives way to: the tab's root, else Assets', else the first root's. */
  const home = (): string => (prefs.tab !== '' && hasFolder(prefs.tab) ? prefs.tab : hasFolder(ROOTS.boot.dir) ? ROOTS.boot.dir : naming.roots[0]!);
  /** `path`, or the nearest folder up that is -- never the project, above the tabs: the tab's root in its place. */
  const settle = (path: string): string => {
    const there = nearestFolder(path, hasFolder, home());
    return there === PROJECT ? home() : there;
  };
  /**
   * The roots with a tab, in order: Assets, Packs while it holds a pack, any other that ships, Source, any other that
   * does not, the Trash -- each where the index has it (bundle view has no Source).
   */
  function tabRoots(): string[] {
    const rank = (r: string): number => (r === ROOTS.boot.dir ? 0 : r === ROOTS.packs.dir ? 1 : r === TRASH ? 9 : r === ROOTS.source.dir ? 5 : naming.shipsAt(r) ? 2 : 6);
    return naming.roots
      .filter((r) => hasFolder(r) && (r !== ROOTS.packs.dir || index.childrenOf(r).folders.length > 0 || naming.rootOf(folder) === r))
      .sort((a, b) => rank(a) - rank(b));
  }
  /** The tab up: the open folder's root. */
  const tabNow = (): string => naming.rootOf(folder) ?? home();

  // ---------------------------------------------------------------- the hint, read again at most once a frame

  let nudged = 0;
  /** The line changed: the host reads the bars again, the next frame (`history.touch()`, its cue). */
  function nudge(): void {
    if (nudged !== 0) return;
    nudged = requestAnimationFrame(() => {
      nudged = 0;
      history.touch();
    });
  }
  let quiet: ReturnType<typeof setTimeout> | undefined;
  /** What was done, or why not: the hint and the files card's status line, for a few seconds. */
  function say(text: string, bad = false): void {
    message = { text, bad, until: Date.now() + SAID };
    files.say(text, bad);
    clearTimeout(quiet);
    quiet = setTimeout(nudge, SAID + 50);
    nudge();
  }

  // ---------------------------------------------------------------- the steps

  const steps = createSteps({
    history,
    reached: (seq) => live.until(seq),
    reread: () => live.refresh(),
    failed(text) {
      say(text, true);
      if (/the dev server (did not answer|answered 5\d\d)/.test(text)) {
        unanswered = true;
        drawBanners();
      }
    },
  });
  const exportStep = createExportStep({
    api,
    jobs: (fn) => live.on('job', fn),
    entries: () => index.entries,
    steps,
    progress(at) {
      exporting = at;
      nudge();
    },
    partial: (text) => say(text, true),
  });

  /** What every edit tells the tool and asks of the index (`file-steps.ts`). */
  const editHost: EditHost = {
    moved(from, to) {
      follow(from, to);
      // A prefab's key is its path: the world's own instances of each prefab that moved named anew (a rename, a move,
      // a folder's, their undos) -- its files' references follow by uid, in the move's own call.
      for (const [a, b] of prefabsMoved(from, to)) ctx.renamedPrefab(a, b);
    },
    made(dir) {
      index.keepFolder(dir);
      soon();
    },
    gone(dir) {
      index.forgetFolder(dir);
      // The open folder deleted: its parent, said as what was done, not as a folder gone from disk.
      if (under(folder, dir)) {
        folder = settle(dirName(dir));
        keep({ folder });
      }
      soon();
    },
    has: (path) => index.entries.has(path),
    partial: (text) => say(text, true),
  };

  /** The prefab keys a move of `from` to `to` changes, `[was, now]`: the file's, or each under a folder's; none for a case-only one. */
  function prefabsMoved(from: string, to: string): Array<[string, string]> {
    const pairs: Array<[string, string]> = [];
    const add = (a: string, b: string): void => {
      const was = prefabKeyOf(a);
      const now = prefabKeyOf(b);
      if (was !== undefined && now !== undefined && was !== now) pairs.push([was, now]);
    };
    if (from.endsWith(PREFAB_SUFFIX)) add(from, to);
    else for (const key of Object.keys(prefabFiles())) {
      const file = prefabPathOf(key);
      if (under(file, from)) add(file, joinPath(to, file.slice(from.length + 1)));
    }
    return pairs;
  }

  /** An edit run as one step on the tool's queue. True once it is on the stack. */
  const runEdit = (edit: Edit, saying = `${edit.label} …`): Promise<boolean> =>
    steps.run(edit.label, edit.first, { do: edit.redo, undo: edit.undo, ...(edit.named ? { label: edit.named } : {}) }, saying);

  /** A drag's line, or a rename's: held on the hint while it lasts. */
  let held: string | null = null;

  // ---------------------------------------------------------------- what the game will see: one renderer, one decode, one player, one queue

  /** The one preview renderer (§A.7): a WebGL context of its own, made the first time a model, a KTX2 or a thumbnail asks. */
  let renderer: PreviewRenderer | null = null;
  const theRenderer = (): PreviewRenderer => (renderer ??= createPreviewRenderer());
  const entryAt = (path: string) => index.entries.get(path);
  const scratch = createScratchStore({ api, entryAt });
  const sound = createSoundPlayer(Audio);
  const stats = createStatsCache(api);
  /** The records and folders' `export.json`, read through `GET file`, kept by path and mtime: the Options blocks', Status's `built`. */
  const records = createRecords({ entries: () => index.entries, file: (path, init) => api.file(path, init) });
  /** An editor colour token, read off the editor's root: what a canvas is drawn in. */
  const colour = (token: string): string => getComputedStyle(root).getPropertyValue(token).trim() || 'currentColor';
  const thumbs = createThumbs({
    api,
    capture: (size, what) => theRenderer().capture(size, what),
    decode: (path) => decodeScratch(path, { api, entryAt }),
    // The preview's open decode: the shown model's thumbnail is made from it.
    shown: () => scratch.current,
    from(path) {
      const entry = index.entries.get(path);
      return entry ? previewPath(entry) : path;
    },
    strip: (peaks, size) => waveStrip(peaks, size, colour('--as-wave')),
    decodeSound,
  });
  /** Why the queue holds still just now: a clip or a sound playing, the preview dragged (the grid scrolling holds only what is made: `scrolled`). */
  const holds = new Set<string>();
  function hold(why: string, on: boolean): void {
    const was = holds.size > 0;
    if (on) holds.add(why);
    else holds.delete(why);
    if (was !== holds.size > 0) thumbs.pause(holds.size > 0);
  }
  let scrolling: ReturnType<typeof setTimeout> | undefined;
  /**
   * The grid scrolled -- `moved`, onto other rows: what is made here (a render, a decode) held until it has been
   * still 120 ms, while what is made already keeps coming, in view order -- asked again only as the rows in view
   * change and as the hold lets go.
   */
  function scrolled(moved: boolean): void {
    if (scrolling === undefined) thumbs.holdMaking(true);
    clearTimeout(scrolling);
    scrolling = setTimeout(() => {
      scrolling = undefined;
      thumbs.holdMaking(false);
      wantSoon();
    }, 120);
    if (moved) wantSoon();
  }

  /** The thumbnail a path's tile wants made at a size (`thumbWantOf`): none for a folder, a pointer, a master, or what has no picture to be had. */
  function thumbOf(path: string, size: number): ThumbWant | null {
    // Bundle view: GET thumb is the dev server's.
    if (online === false) return null;
    const row = shownAt(index, path);
    if (!row) return null;
    return thumbWantOf(row, size, isEntry(row) ? previewPath(row) : row.path, (p) => index.entries.get(p));
  }

  /** A key picker's row's thumbnail size: sharp at twice its CSS pixels. */
  const KEY_THUMB = 64;
  /** A model's (or a texture's) thumbnail for a key picker's row and field (`EditorContext.modelThumb`): its file in the index, through the one queue. */
  function modelThumb(key: string, type: 'Model' | 'Texture' = 'Model'): Promise<string | null> {
    return keyThumb(type === 'Texture' ? 'textures' : 'models', key);
  }

  /** The thumbnail of `kind`'s key -- a model's, a texture's (a material's map picker) -- through the one queue; null for none. */
  function keyThumb(kind: 'models' | 'textures', key: string): Promise<string | null> {
    if (!ready) return Promise.resolve(null);
    const want = caseKey(key);
    for (const path of index.entries.keys()) {
      if (locate(path)?.kind !== kind || keyOf(path) !== want) continue;
      const item = thumbOf(path, KEY_THUMB);
      return item ? thumbWhenReady(thumbs, item) : Promise.resolve(null);
    }
    return Promise.resolve(null);
  }

  let wanting = 0;
  /** The queue asked again, the next frame: the preview's own first, then the files card's order -- each path and size once. */
  function wantSoon(): void {
    if (wanting !== 0) return;
    wanting = requestAnimationFrame(() => {
      wanting = 0;
      if (!visible) return;
      thumbs.want(files.thumbOrder(preview.wants()));
    });
  }

  const preview = createPreview({
    api,
    table: previews,
    renderer: theRenderer,
    scratch,
    sound,
    thumbs,
    entryAt,
    stats(path, then) {
      // Kept as the Stats block keeps it (`statsKey`).
      const row = shownAt(index, path);
      const key = row ? statsKey(row) : undefined;
      const told = (answer: ReturnType<typeof stats.get>): void => {
        if (answer !== 'reading' && !('failed' in answer)) then(answer);
      };
      told(stats.get(path, key, () => told(stats.get(path, key, () => {}))));
    },
    prefs: () => prefs.preview,
    keep: (change) => keep({ preview: { ...prefs.preview, ...change } }),
    hold,
    changed() {
      wantSoon();
      nudge();
    },
    copy,
    colour,
  });

  // ---------------------------------------------------------------- the cards

  const banners = createBanners();
  const strip = createJobsStrip({
    reveal: (source) => reveal(source),
    show(source) {
      reveal(source);
      setFocus('preview');
      inspector.showOutput();
    },
    // A failure dismissed, `GET jobs` taken in: several marks may have changed.
    changed: () => {
      files.redraw();
      inspector.refresh();
      nudge();
    },
    converting: convertingHere,
  });
  /** What a tool's path set or Check again came to: on the Tools page, where it was done, and on the files card's line. */
  const toldTools = (text: string, bad = false): void => {
    say(text, bad);
    toolsBlock.say(text, bad);
  };
  const toolsBlock = createToolsBlock({
    tools: () => tools,
    writes,
    async setPath(tool, path) {
      try {
        const answer = await api.setTool(tool, path);
        tools = answer.tools ?? tools;
        wanted = null;
        toldTools(answer.jobs.length > 0 ? `${tool}: ${answer.jobs.length} queued to export now that it can` : path ? `${tool}: looking at ${path}` : `${tool}: looking on the PATH again`);
      } catch (err) {
        toldTools(`${tool}'s path was not set: ${(err as Error).message}`, true);
      }
      drawTools();
    },
    async checkAgain() {
      try {
        const answer = await api.checkTools();
        tools = answer.tools ?? tools;
        wanted = null;
        toldTools(answer.jobs.length > 0 ? `Looked again: ${answer.jobs.length} queued to export` : 'Looked for every tool again');
      } catch (err) {
        toldTools(`The tools were not looked for again: ${(err as Error).message}`, true);
      }
      drawTools();
    },
  });
  // Config ▸ Assets ▸ Tools: the block on a page of its own. Shown before the panel ever was, it asks the server itself.
  const offToolsPage = ctx.pages.add(toolsPage(toolsBlock, (shown) => {
    if (!shown || tools !== null) return;
    void api.online().then((now) => {
      online ??= now;
      toolsBlock.refresh();
      if (now === false) return;
      return api.tools().then((answer) => {
        tools ??= answer.tools;
        wanted = null;
        drawTools();
      });
    }, () => {});
  }));

  /** The tools each root's unmade sources want and lack: worked out again as the index or the tools change. */
  let wanted: Map<string, string[]> | null = null;
  function toolsWanted(rootDir: string): string[] {
    if (!wanted) {
      wanted = new Map();
      const lacking = (tools ?? []).filter((t) => t.state !== 'found');
      if (lacking.length > 0) {
        for (const e of index.entries.values()) {
          if (e.role !== 'source' || e.status !== 'unmade') continue;
          const at = naming.rootOf(e.path);
          if (at === undefined) continue;
          for (const look of lacking) {
            if (!(e.reason ?? '').includes(look.tool)) continue;
            const list = wanted.get(at) ?? [];
            if (!list.includes(look.tool)) list.push(look.tool);
            wanted.set(at, list);
          }
        }
      }
    }
    return wanted.get(rootDir) ?? [];
  }

  // ---------------------------------------------------------------- the panel: one card along the bottom of the Scene tab

  /** The Assets panel: its top edge the grip, its title row across it, then the folders' column and the files'. */
  const panel = el('div', 'ed-card ed-bottom-card ed-as-panel');
  panel.hidden = true;
  const panelHead = el('div', 'ed-as-panel-head');
  const cols = el('div', 'ed-as-cols');
  panel.append(panelHead, cols);
  root.append(panel);
  /** Fold the panel to a tab on the bottom edge, or back: its head's own button, as `Shift+Space` does. */
  const foldButton = letGo(iconButton('ui', 'foldDown', '', () => setFolded(!prefs.folded), 'ed-icon-button ed-as-panel-fold'));
  // Folded, the panel is a tab on the bottom edge: a click anywhere on it unfolds it -- but on its button, whose own it is.
  // The event's path, not `contains`: the button's click has just swapped its glyph (`showFolded`), so the path element
  // clicked is out of the button by now, and the click would unfold what it had folded.
  // mcp: ui -- the folded panel unfolded
  panel.addEventListener('click', (event) => {
    if (prefs.folded && !event.composedPath().includes(foldButton)) setFolded(false);
  });

  const folders = createFolders(cols, {
    index,
    naming,
    counts,
    sizes,
    budget,
    open: () => (files.query?.everywhere ? null : folder),
    // The project's fold is its own preference, open until folded: `open` lists the rest.
    tabs: tabRoots,
    tab: tabNow,
    chooseTab: (root) => {
      const last = lastIn.get(root);
      openFolder(last !== undefined && hasFolder(last) ? last : root);
    },
    expanded: () => prefs.open,
    setExpanded: (path, on) => keep({ open: withOpen(prefs.open, path, on) }),
    choose: (path) => openFolder(path),
    menu: (path, at, byKey) => folderMenu(path, at, byKey, true),
    toolsWanted,
    openTools,
    folded: (away) => foldedAway('folders', away),
  });

  const files = createFiles(cols, {
    frame: panel,
    folded: () => prefs.folded,
    index,
    naming,
    counts,
    sizes,
    columns,
    banners,
    strip: strip.root,
    prefs: () => prefs,
    keep,
    folder: () => folder,
    selection: () => selection,
    select,
    open: (path, then) => openFolder(path, then),
    openFile,
    reveal: (path) => reveal(path),
    menu: filesMenu,
    writes,
    running: (source) => strip.running(source),
    changed: () => {
      folders.refresh();
      inspector.refresh();
      nudge();
    },
    importMenu,
    importFiles: () => pick(filesInput),
    importFolder: () => pick(folderInput),
    dragStart: (event, path) => dnd.start(event, path),
    flipBuild: (paths, on) => setBuild(paths, on),
    thumbs,
    thumbOf,
    wantThumbs: wantSoon,
    scrolled,
    boxed: (paths, how) => select(choosePaths(selection, paths, how)),
  });
  // The grip on the panel's top edge; across its top the title, the files' title row, the fold.
  panel.prepend(files.grip);
  panelHead.append(el('div', 'ed-side-title ed-as-panel-title', 'Assets'), files.head, foldButton);

  const inspector = createAssetsInspector(root, {
    index,
    naming,
    counts,
    api,
    budget,
    showing,
    lock: lockHost(ctx),
    writes,
    tools: () => tools,
    failure: (source) => strip.failure(source),
    running: (source) => strip.running(source),
    reveal,
    openTools,
    openModel: (path) => {
      const script = modelScriptOf(path);
      return script === undefined ? null : () => openModel(script);
    },
    makeScript: (path) => (adoptable(path) ? () => void adoptModel(path) : null),
    modelUp: () => ctx.tool === 'model',
    exportNow: (sources, force) => exportSources(sources, force),
    exportUnder,
    copy,
    folded: (away) => foldedAway('preview', away),
    rename: () => rename('head'),
    renames: (what) => writes() && what.kind !== 'gone' && renames(what.kind === 'many' ? null : what.path, what.kind === 'folder'),
    preview,
    stats,
    statsRows,
    warnings,
    online: () => online,
    records,
    changeOption,
    resetOptions,
    uses: (keys, then) => usesOf(keys, then),
    step: (by) => stepPreview(by),
    build: (paths, on) => setBuild(paths, on),
    prefabBlocks: (path, hold) => {
      // A scene file: its key, its entities, its size and time, Open.
      const scene = sceneKeyOf(path);
      if (scene !== undefined) {
        const entry = index.entries.get(path);
        return [sceneBlock(scene, { file: sceneIfPresent, size: entry?.size ?? 0, mtime: entry?.mtime ?? 0, start: startScene(), open: (k) => {
          const no = openScene(k);
          if (no) say(no, true);
        } })];
      }
      // A physics material: its fields to edit (Docs/physics.md §7).
      const physmat = physmatKeyOf(path);
      if (physmat !== undefined) return [physmatBlock(path, physmat, physmatHost)];
      // A material file: its problems, its fields to edit, who wears it.
      const material = materialKeyOf(path);
      if (material !== undefined) {
        const made = materialBlock(material, materialHost);
        hold(made.hold);
        return made.blocks;
      }
      const key = prefabKeyOf(path);
      const stray = key === undefined ? strayFile(path) : undefined;
      if (stray) return [strayBlock(stray, writes(), (name) => void commitRename(path, false, name))];
      return key === undefined
        ? []
        : prefabBlock(key, { world: ctx.world, files: prefabFiles, problem: (k) => livePrefabs.problemOf(k), writes, setPool: (k, size) => void setPool(k, size), reveal, open: (k) => ctx.openPrefab(k), levels: levelsHolding, scenes: scenesHolding, levelPath, scenePath: scenePathOf, root: rootHost }, hold);
    },
  });

  const sheet = createImportSheet({
    index,
    naming,
    api,
    steps,
    budget,
    // Over the panel, and up over the scene as tall as it needs (assets.css): a row of tiles is no room for a form.
    card: panel,
    records,
    edits: editHost,
    tools: () => tools,
    onJob: (fn) => live.on('job', fn),
    onChanged: (fn) => live.on('changed', () => fn()),
    running: (source) => strip.running(source),
    converting: convertingHere,
    changed: () => {
      nudge();
      if (!sheet.open) refold();
    },
    say,
    // Where the files landed, shown: the first chosen -- the owner, sent first -- the inspector following it. A file
    // imported as a Gladius script opens in the Model tab (Docs/modeler.md M39).
    folders: (at) => kindFolders(at),
    landed: (paths, scripts) => {
      openFolder(folderOf(paths[0]!), paths[0]!);
      if (scripts.length > 0) openModel(scripts[0]!, true);
      refold();
    },
  });

  /** The panel's fold before the Model tab's Import model… unfolded it for the sheet: put back as the import lands or the sheet closes. */
  let refoldAfterSheet: boolean | null = null;
  function refold(): void {
    if (refoldAfterSheet === true && !prefs.folded) setFolded(true);
    refoldAfterSheet = null;
  }
  /** Where the picker's files go when another tab asked (the Model tab's Import model…): its folder, not the one open. */
  let pickInto: string | null = null;
  /** The pickers Import ▾ opens: files, and a folder with its folders kept. In the editor's root, never seen. */
  const filesInput = el('input');
  filesInput.type = 'file';
  filesInput.multiple = true;
  const folderInput = el('input');
  folderInput.type = 'file';
  folderInput.webkitdirectory = true;
  for (const input of [filesInput, folderInput]) {
    // The picker cancelled: nothing comes, so a panel unfolded for it is folded back.
    input.addEventListener('cancel', () => {
      pickInto = null;
      refold();
    });
    input.hidden = true;
    input.tabIndex = -1;
    input.addEventListener('change', () => {
      const list = input.files;
      if (list && list.length > 0) importInto(pickInto ?? folder, readList(list), pickInto !== null);
      pickInto = null;
      input.value = '';
    });
    root.append(input);
  }

  /** Where a prefab dragged over the scene meets the ground. */
  const dropGround = new THREE.Vector3();
  const dnd = createDnd({
    targetAt,
    importRefusal: (to) => (writes() ? importRefused(to, naming) : readOnlyLine()),
    moveRefusal: (paths, to) => (writes() ? moveRefused(paths, to, index, naming) : readOnlyLine()),
    saying(what, to, paths) {
      if (what === 'entities') return `Drop to save them as a prefab in ${naming.say(to)}: they become its instance`;
      if (what === 'files') return sheet.open ? `Drop to join the import into ${naming.say(sheet.folder!)}` : `Drop to import into ${naming.say(to)}`;
      // Tiles from another tab: what they are is read only on the drop.
      if (paths.length === 0) return `Drop to move them into ${naming.say(to)}`;
      const n = paths.length === 1 ? baseName(paths[0]!) : `${paths.length}`;
      return paths.every((p) => fromTrash(p)) ? `Drop to restore ${n} into ${naming.say(to)}` : `Drop to move ${n} to ${naming.say(to)}`;
    },
    say(text, bad) {
      held = text;
      files.note(text, bad);
      nudge();
    },
    refused: (text) => say(text, true),
    dropped: (to, read) => void read.then((drop) => importInto(to, drop), (err) => say(`The drop could not be read: ${reasonOf(err)}`, true)),
    moved: (paths, to) => moveInto(paths, to),
    entitiesRefusal(to) {
      if (!writes()) return readOnlyLine();
      if (to === PREFABS_DIR) return 'A prefab goes in a folder under prefabs/ -- crates, props: drop them on one';
      return to.startsWith(`${PREFABS_DIR}/`) ? null : 'Entities are saved as a prefab in a folder under prefabs/: drop them there';
    },
    entitiesDropped(ids, to) {
      const chosen = ids.map((i) => i as Entity).filter((e) => ctx.world.alive(e));
      const roots = rootsOfChoice(ctx, chosen);
      if (roots.length === 0) return say('Not saved: those entities are gone', true);
      const key = suggestKey(ctx, to.slice(PREFABS_DIR.length + 1), roots, prefabFiles());
      say(`Saving ${key}…`);
      saveAsPrefab(ctx, key, chosen, () => ctx.emit('changed')).then(
        (said) => {
          ctx.emit('changed');
          ctx.draw();
          // A world step: the drag began in the tree, whose side has the keys, so Z is the world's.
          say(`${said} · Z undoes`);
        },
        (err: Error) => say(`Not saved as a prefab: ${err.message}`, true),
      );
    },
    prefabs(paths) {
      const keys = paths.map(prefabKeyOf);
      return keys.length > 0 && keys.every((k) => k !== undefined) ? (keys as string[]) : null;
    },
    models(paths) {
      const keys = paths.map((p) => (locate(p)?.kind === 'models' ? keyOf(p) : undefined));
      return keys.length > 0 && keys.every((k) => k !== undefined) ? (keys as string[]) : null;
    },
    materials(paths) {
      const keys = paths.map(materialKeyOf);
      return keys.length > 0 && keys.every((k) => k !== undefined) ? (keys as string[]) : null;
    },
    kinds: () => index.kinds,
    sceneAt(event) {
      if (event.target !== ctx.game.renderer.domElement) return null;
      if (carriesMaterial(event)) {
        const on = ctx.viewport.entityAt(event.clientX, event.clientY);
        return on === NONE ? { say: 'Drop on an entity drawn here to wear it', takes: false } : { say: `Drop to wear it on ${label(ctx.world, on)}`, takes: true };
      }
      // Above the horizon too: placed where the camera looks (`placeDropped`), as the scene's own listener takes it.
      const at = ctx.viewport.groundAt(event.clientX, event.clientY, dropGround);
      return { say: at ? 'Drop to place it here, on the ground' : 'Above the horizon: drop on the ground to place it', takes: true };
    },
    // Not chosen for it: a drag leaves what is chosen, and what the right panel shows, as they were.
    dragging: (path) => draggedPaths(selection, path),
  });

  /**
   * What the inspector shows: the files chosen, else the open folder -- or, locked, what it pinned that is still
   * there (`shownOf`), a deleted one dropped, every one deleted `gone`.
   */
  function showing(): Showing {
    // Kept while the Scene tab is away, but the Model tab's panel has no lock: there, what is chosen.
    if (pinned === null || !ctx.locked) return liveShowing();
    return pinnedShowing(pinned, pinnedThere, (p) => isFolderPath(index, p));
  }

  /** Is a path the lock pinned still there: the project's own root always. */
  function pinnedThere(path: string): boolean {
    return path === PROJECT || has(path);
  }

  /** What the inspector shows unlocked: the files chosen, else the open folder. */
  function liveShowing(): Showing {
    if (selection.paths.length > 1) return { kind: 'many', paths: selection.paths, at: previewedOf(selection, stepped)! };
    const one = selection.primary;
    if (one !== null && !isFolderPath(index, one)) return { kind: 'file', path: one };
    return { kind: 'folder', path: one ?? folder };
  }

  const menu = createMenu(root, ctx.game.renderer.domElement);

  // ---------------------------------------------------------------- what is open, what is chosen

  /** A folder opened in the files card, `then` chosen in it -- or, gone from the index, the nearest one up that is. */
  function openFolder(path: string, then?: string): void {
    if (files.query) files.clearSearch();
    // Its tab brought up with it (`keep`): the folder's root.
    const there = settle(path);
    folder = there;
    keep({ folder: there });
    // Its folders unfolded on the way to it, so its row is there to see -- below its root, which is its tab.
    let open = prefs.open;
    for (let up = dirName(there); up !== '' && naming.rootOf(up) !== undefined && naming.rootOf(up) !== up; up = dirName(up)) if (!open.includes(up)) open = withOpen(open, up);
    if (open !== prefs.open) keep({ open });
    selection = then !== undefined && there === path ? chosen([then]) : NO_PATHS;
    // Drawn now, not next frame: a click that follows lands on this folder's tiles, never on the last one's.
    files.refresh();
    files.redraw();
    folders.refresh();
    folders.reveal();
    // A folder opened is chosen, as a file is: the right panel shows it.
    if (visible) ctx.inspect();
    inspector.refresh();
    if (then !== undefined && there === path) files.reveal(then, true);
    nudge();
  }

  function select(next: PathSelection): void {
    // Another set chosen: its preview from the first again.
    if (next.paths.length !== selection.paths.length || next.paths.some((p, i) => p !== selection.paths[i])) stepped = null;
    selection = next;
    // Chosen last, the files are what the right panel shows (not while it is locked); something chosen, the entities
    // chosen let go -- one selection across the tab. Nothing chosen (a click on nothing) clears only this side.
    if (visible) {
      ctx.inspect();
      // Only folders chosen is browsing: the entities let go as ever, but a lock does not take it for a choice.
      if (next.paths.length > 0) ctx.chose(next.paths.every((p) => isFolderPath(index, p)));
    }
    files.redraw();
    if (next.latest !== null) files.reveal(next.latest);
    inspector.refresh();
    nudge();
  }

  /** A file shown chosen in the folder that lists it -- a twin, a job, a search's Folder cell -- wherever that is: a trashed one in its slot. */
  function reveal(path: string): void {
    openFolder(folderOf(path), path);
  }

  /** Config ▸ Assets ▸ Tools brought up, `tool`'s path field focused: where a wanting tool is set. */
  function openTools(tool?: string): void {
    if (ctx.pages.show(TOOLS_PAGE)) toolsBlock.show(tool);
  }

  /** A file double-clicked: in the application this machine opens it with -- in read mode, previewed, as Enter does. */
  /** A Gladius script -- the file, or the export or record of one -- its script's path: what the Model tab opens. */
  const modelScriptOf = (path: string): string | undefined => {
    const from = sourcePath(path) ?? (index.entries.get(path)?.role === 'source' ? path : undefined);
    if (from !== undefined && extOf(from) === 'lua') return from;
    // A script out of the build by its name (`_wip.lua`, a `_` folder) is no source, but still a Gladius script: the Model
    // tab opens it and says why it shows nothing -- never the machine's own application in its place.
    const where = locate(path);
    return extOf(path) === 'lua' && where?.root === 'source' && where.kind === 'models' ? path : undefined;
  };

  /** Its script opened in the Model tab (Docs/modeler.md M19): said if there is no such tab. */
  function openModel(script: string, made = false): void {
    if (!ctx.openModel(script, made ? { room: true } : undefined)) say(`${baseName(script)} did not open: no Model tab here`, true);
  }

  function openFile(path: string): void {
    // A Gladius script -- or its export -- opens in the Model tab, built and shown (Docs/modeler.md M19).
    const script = modelScriptOf(path);
    if (script !== undefined && !under(path, TRASH)) return openModel(script);
    // A prefab opens in the editor itself, to edit (Docs/prefabs.md §7), read-only or not.
    const prefabKey = prefabKeyOf(path);
    if (prefabKey !== undefined && prefabFiles()[prefabKey]) return ctx.openPrefab(prefabKey);
    // A scene opens in place of the world, the open scene's changes asked about here first.
    const sceneKey = sceneKeyOf(path);
    if (sceneKey !== undefined && sceneIfPresent(sceneKey)) {
      const no = openScene(sceneKey);
      if (no) say(no, true);
      return;
    }
    if (!writes()) {
      setFocus('preview');
      return;
    }
    api.reveal(path, true).then(
      () => say(`Opened ${baseName(path)} in the application this machine opens it with`),
      (err: Error) => say(`${baseName(path)} did not open: ${err.message}`, true),
    );
  }

  /** A path shown where it is on the machine -- the project's folder as Source's reveal opens it: the folder its roots are in. */
  function revealOnDisk(path: string): void {
    const project = path === PROJECT;
    const what = project ? 'the project folder' : baseName(path);
    api.reveal(project ? ROOTS.source.dir : path).then(
      () => say(`${revealWords()}: ${what}`),
      (err: Error) => say(`${what} was not shown: ${err.message}`, true),
    );
  }

  /** Reveal as the machine names it. */
  const revealWords = (): string => (isMac() ? 'Reveal in Finder' : /Win/.test(globalThis.navigator?.platform ?? '') ? 'Show in Explorer' : 'Show in file manager');

  function copy(text: string, what: string): void {
    navigator.clipboard.writeText(text).then(
      () => say(`Copied ${what}: ${text}`),
      (err: Error) => say(`The clipboard refused it: ${err.message}`, true),
    );
  }

  /** One file downloaded, through an `<a download>` made, clicked and taken away at once -- never focused. */
  function download(path: string): void {
    const url = api.fileUrl(path);
    if (!url) return say(`${baseName(path)} has no address to download from`, true);
    const a = document.createElement('a');
    a.href = url;
    a.download = baseName(path);
    a.hidden = true;
    document.body.append(a);
    a.click();
    a.remove();
    say(`Downloading ${baseName(path)}`);
  }

  // ---------------------------------------------------------------- exports, as steps

  /** The source of the family a path is of, by its path: a source itself; an export's, a record's or an intermediate's. */
  const sourcePath = (path: string): string | undefined => {
    const row = index.entries.get(path);
    return row ? sourceOf(row, index.entries)?.path : undefined;
  };

  /** These sources exported, `force` current or not: one step; more than ten asks in the inspector first -- unfolded to ask. */
  function exportSources(sources: readonly string[], force: boolean): void {
    if (!writes()) return;
    const list = [...new Set(sources)];
    if (list.length === 0) return say('Nothing to export: choose a source, or an export of one', true);
    const label = list.length === 1 ? `Export ${baseName(list[0]!)}` : `Export ${list.length}`;
    const go = (): void => void exportStep(label, { paths: list }, force);
    // More than ten: the question goes in the inspector, seen, so it is there to answer -- and Esc, which it holds, is not a mystery.
    if (list.length > ASK_OVER) ask(`Export ${list.length} files${force ? ' again' : ''}? Z undoes it, one restore each.`, `Export ${list.length}`, go);
    else go();
  }

  /** Export all stale under a folder: one step. The project's is Source's -- every source lives under it, the packs' too. */
  function exportUnder(path: string): void {
    if (!writes() || under(path, TRASH)) return;
    void exportStep(path === PROJECT ? 'Export all stale' : `Export all stale under ${naming.title(path)}`, { under: path === PROJECT ? ROOTS.source.dir : path }, false);
  }

  /** E, Shift+E: in Folders, all stale under the folder; else the selection's -- what needs it, or (`force`) all of it. */
  function exportKey(force: boolean): void {
    if (focus === 'folders' && !force) return exportUnder(folder);
    const paths = focus === 'folders' ? [folder] : selection.paths;
    if (paths.length === 0) return say('Nothing chosen to export', true);
    const sources = [...new Set(paths.map(sourcePath).filter((p): p is string => p !== undefined))];
    const wanting = force ? sources : sources.filter((s) => ['stale', 'missing', 'failed'].includes(index.entries.get(s)?.status ?? ''));
    if (wanting.length === 0) return say(force ? 'Nothing chosen is a source or an export of one' : 'Nothing chosen needs exporting: Shift+E exports it again anyway');
    exportSources(wanting, force);
  }

  // ---------------------------------------------------------------- options, as steps

  /** What a step of options on these targets is called: a folder's says which `export.json`. */
  const optionsWhere = (targets: readonly Target[]): string => (targets.length === 1 && targets[0]!.folder ? ` in ${fromSourceRoot(targets[0]!.file)}` : '');

  /**
   * An option of the Options block changed (§6.5): on every target -- set,
   * moved each from its own, or taken off where it is set -- one step through
   * `PUT sidecar`, which re-exports: "angle 70 → 90", "textureMax 2048 → 1024
   * × 3". Each record is read fresh as the step's turn comes and the change
   * worked out from it (`optionWrites`), so a change queued behind another --
   * an arrow key's press behind the last -- builds on it, and one that changes
   * nothing is no step and says nothing (`Unchanged`).
   */
  function changeOption(targets: readonly Target[], each: readonly (readonly Field[])[], field: Field, to: OptionValue | { by: number } | undefined): void {
    if (!writes()) return;
    const { writes: list, from } = optionWrites(targets, each, field, to);
    if (list.length === 0) return;
    const where = optionsWhere(targets);
    const label = (n: number): string => `${changeLabel(field, to, from, n)}${where}`;
    void runEdit(optionsEdit(api, (file) => records.fresh(file), list, label, (text) => say(text, true)))
      .then((ok) => ok && say(`${label(list.length)}: re-exporting · Z undoes`));
  }

  /** Reset all: every option set on these targets taken off -- the defaults and the folders' apply again -- one step. */
  function resetOptions(targets: readonly Target[], each: readonly (readonly Field[])[]): void {
    if (!writes()) return;
    const list: OptionsWrite[] = targets
      .filter((_, i) => (each[i] ?? []).some((f) => f.set !== 'none'))
      .map((target) => ({ path: target.path, file: target.file, change: () => ({}) }));
    if (list.length === 0) return;
    const one = targets.length === 1 ? targets[0]! : undefined;
    const label = (n: number): string => (one?.folder ? `Reset ${fromSourceRoot(one.file)}` : n === 1 ? `Reset the options of ${stemOf(baseName(list[0]!.path))}` : `Reset the options × ${n}`);
    void runEdit(optionsEdit(api, (file) => records.fresh(file), list, label, (text) => say(text, true)))
      .then((ok) => ok && say(`${label(list.length)}: re-exporting · Z undoes`));
  }

  /** ◂ ▸, and ← → with the preview focused: of several chosen, the one previewed stepped -- `latest`, so the keys walk on from it. */
  function stepPreview(by: 1 | -1): void {
    // Locked on several: the one previewed among those pinned, what is chosen left as it is.
    if (pinned?.kind === 'many' && ctx.locked) {
      pinned = stepPinned(pinned, pinnedThere, by);
      inspector.refresh();
      return nudge();
    }
    if (selection.paths.length < 2) return;
    const next = stepPreviewed(selection, stepped, by);
    selection = next.selection;
    stepped = next.at;
    files.redraw();
    if (selection.latest !== null) files.reveal(selection.latest);
    inspector.refresh();
    nudge();
  }

  // ---------------------------------------------------------------- the panel folded to a tab

  /** The panel folded or not, on screen: its body, its grip, its button's glyph and words. */
  function showFolded(): void {
    const on = prefs.folded;
    panel.classList.toggle('ed-as-folded', on);
    files.grip.hidden = on;
    foldButton.replaceChildren(icon(on ? 'foldUp' : 'foldDown'));
    foldButton.title = `${on ? 'Unfold the Assets panel: its folders and files again' : 'Fold the Assets panel to a tab on the bottom edge: the scene the room'} (${keyLabel('Shift+Space')})`;
    foldButton.setAttribute('aria-expanded', String(!on));
  }

  /** Shift+Space, the fold on its title row: the panel folded to that row -- the scene the room -- or back as tall as kept. Kept. */
  function setFolded(on: boolean): void {
    if (on === prefs.folded) return;
    keep({ folded: on });
    showFolded();
    // As tall as kept again, held to this window; and the files drawn into the room they have now.
    if (!on && visible) {
      files.place();
      files.refresh();
      folders.refresh();
    }
    nudge();
  }

  // ---------------------------------------------------------------- menus

  type Point = { x: number; y: number };
  const NEW_SCENE_TITLE = 'An empty scene in it, named in place -- not opened: a double-click opens it; Z undoes';
  const NEW_MATERIAL_TITLE = 'A new material in it: a standard, white, named in place -- a prefab wears it by its Render.material; Z undoes';
  const NEW_PHYSMAT_TITLE = 'A new physics material in it: friction 0.5, no bounce, named in place -- a collider wears it by its material field; Z undoes';
  const NEW_MODEL_TITLE = 'A Gladius script in it, empty and documented, built once and opened in the Model tab -- named first; Z undoes';
  const IMPORT_MODEL_TITLE = 'A .glb or .fbx into it, as a Gladius script that imports it -- parts, colours, skin and clips kept -- opened in the Model tab as it lands; Z undoes';
  /** Import model…: the picker, its files imported into `dir` as scripts (as the Model tab's own, Docs/modeler.md M39). */
  const importModelInto = (dir: string): void => {
    if (dir !== folder) openFolder(dir);
    pickInto = dir;
    pick(filesInput);
  };
  /** Where the last menu opened: what Move to… drops its list from. */
  let anchor: HTMLElement | Point | null = null;

  /** The menu up: a game's items applied, opened by key with its first item focused. */
  function showMenu(at: Point, entries: readonly Shown[], items: MenuItem[], title: string, byKey: boolean): void {
    const shown = options.menu ? options.menu(entries, items) : items;
    if (shown.length === 0) return;
    anchor = at;
    menu.show(at, shown, { title, focus: byKey });
  }

  /**
   * A folder's items: from the tree (`fromTree`) the folder is the open one;
   * from a tile, Open goes in. A root and a trash slot have no Rename, Move or
   * Delete (`folderTakes`); the Trash has Empty and Restore all, a slot Restore.
   */
  function folderItems(path: string, fromTree: boolean): MenuItem[] {
    const takes = folderTakes(path, naming.title(path));
    const items: MenuItem[] = [];
    const where = fromTree ? 'folders' : 'files';
    if (!fromTree) items.push({ mcp: 'ui', label: 'Open', title: 'Its files in this card', run: () => openFolder(path) });
    if (writes()) {
      if (inScenes(path)) items.push({ mcp: 'asset_new', label: 'New scene', title: NEW_SCENE_TITLE, run: () => void newSceneIn(path) });
      if (inModels(path)) items.push({ mcp: 'asset_new', label: 'New model…', title: NEW_MODEL_TITLE, run: () => newModelIn(path) });
      if (inModels(path) && importRefused(path, naming) === null) items.push({ mcp: 'asset_import', label: 'Import model…', title: IMPORT_MODEL_TITLE, run: () => importModelInto(path) });
      if (takes.newFolder) items.push({ mcp: 'asset_new', label: takes.newFolder === 'pack' ? 'New pack' : 'New folder', key: keyLabel('Shift+KeyN'), title: takes.newFolder === 'pack' ? 'A pack: packs/<name>/, its sources\' folder under AssetsSource/packs/ with it' : 'A folder in it, named in place', run: () => {
        if (path !== folder) openFolder(path);
        newFolder();
      } });
      if (inPrefabs(path)) items.push({ mcp: 'asset_new', label: 'New prefab', title: 'An empty prefab in it: one entity, a Transform, named from the folder -- Z undoes', run: () => void newPrefabIn(path) });
      if (inMaterials(path)) items.push({ mcp: 'asset_new', label: 'New material', title: NEW_MATERIAL_TITLE, run: () => void newMaterialIn(path) });
      if (inPhysmats(path) || path === ROOTS.boot.dir) items.push({ mcp: 'asset_new', label: 'New physics material', title: NEW_PHYSMAT_TITLE, run: () => void newPhysmatIn(inPhysmats(path) ? path : PHYSMATS_DIR) });
      if (takes.rename) items.push({ mcp: 'asset_move', label: 'Rename', key: keyLabel('F2'), title: 'Its name a field where it is: its twin is renamed with it', run: () => {
        if (fromTree && path !== folder) openFolder(path);
        if (!fromTree) select(chosen([path]));
        rename(where);
      } });
      if (takes.move) items.push({ mcp: 'asset_move', label: 'Move to…', title: 'Another folder of its kind: every family in it, both sides', run: (byKey) => moveTo([path], byKey) });
      if (takes.exportStale) items.push(path === PROJECT
        ? { mcp: 'asset_export', label: 'Export all stale', rule: true, title: 'Every stale or missing source in the project, exported as one step', run: () => exportUnder(path) }
        : { mcp: 'asset_export', label: 'Export all stale under it', rule: true, title: 'Every stale or missing source under it, exported as one step', run: () => exportUnder(path) });
      if (takes.restore) items.push({ mcp: 'asset_restore', label: 'Restore', title: 'Every file in this slot, back where it was', run: () => restoreTrashed(index.childrenOf(path).files.map((f) => f.path)) });
      if (takes.restoreAll) items.push({ mcp: 'asset_restore', label: 'Restore all', title: 'Every file in the trash, back where it was, but the automatic exports\' slot (its own Restore): one step', run: () => restoreAll() });
      if (!under(path, TRASH)) items.push({ mcp: 'ui', label: revealWords(), rule: true, title: path === PROJECT ? 'The project\'s folder, its roots in it, on the machine running the dev server' : 'This folder, on the machine running the dev server', run: () => revealOnDisk(path) });
    }
    // The project has no path but the repository's root, which is no path of the tool's.
    if (path !== PROJECT) items.push({ mcp: 'ui', label: 'Copy path', key: keyLabel('Mod+Shift+KeyC'), title: path, run: () => copy(path, 'the path') });
    if (writes() && takes.delete) items.push({ mcp: 'asset_delete', label: 'Delete', key: keyLabel('Delete'), rule: true, title: 'To the trash, every family in it, both sides: it asks first if anything is in it; Z undoes', run: () => trashPaths([path]) });
    if (writes() && takes.empty) items.push({ mcp: 'asset_empty_trash', label: 'Empty', danger: true, rule: true, title: 'Everything in the trash removed for good: it asks first, and Z cannot bring it back', run: () => emptyTrash() });
    return items;
  }

  /** The items for these files (§4): a trashed file's are Restore, Restore to…, Download, Copy path. */
  function fileItems(paths: readonly string[]): MenuItem[] {
    const rows = paths.map((p) => shownAt(index, p)).filter((r): r is Shown => r !== undefined);
    const one = paths.length === 1 ? rows[0] : undefined;
    const items: MenuItem[] = [];
    if (rows.length > 0 && rows.every((r) => !isEntry(r))) {
      if (writes()) {
        const note = restoreNote(paths, (slot) => index.trash.find((s) => s.slot === slot)?.files.map((f) => f.path) ?? []);
        items.push(
          { mcp: 'asset_restore', label: 'Restore', title: `Back where it was -- named -2 where that name is taken, said first${note ? `; ${note}` : ''}`, run: () => restoreTrashed(paths) },
          { mcp: 'asset_restore', label: 'Restore to…', title: 'Back into another folder of its kind: a restore, then a move, one step', run: (byKey) => moveTo(paths, byKey) },
        );
      }
      if (one) {
        items.push(
          { mcp: 'ui', label: 'Download', rule: items.length > 0, title: 'This file, to this machine\'s downloads', run: () => download(one.path) },
          { mcp: 'ui', label: 'Copy path', key: keyLabel('Mod+Shift+KeyC'), title: one.path, run: () => copy(one.path, 'the path') },
        );
      }
      return items;
    }
    const entry = one && isEntry(one) ? one : undefined;
    // A conflict's two ways out, first: they are what it needs (§2, one stem, one source).
    if (entry && writes()) {
      const others = conflictOthers(entry);
      if (others.length > 0) items.push({ mcp: 'asset_delete', label: 'Keep this one', title: `${others.map(baseName).join(', ')} to the trash: ${baseName(entry.path)} ships as ${entry.key}; Z undoes`, run: () => keepThis(entry.path, others) });
      // Rule 8's way out (Docs/asset-ids.md): this source ships under a name of its own, the other keeps the stem.
      if (others.length > 0 && entry.role === 'source') items.push({ mcp: 'asset_options', label: 'Rename the export…', title: `${baseName(entry.path)} ships under a name of its own -- its record's "as" -- and the conflict goes; Z undoes`, run: () => renameExport(entry.path) });
      const blend = handBlend(entry);
      if (blend) items.push({ mcp: 'asset_move', label: 'This is its hand export', title: `${baseName(entry.path)} renamed _${baseName(entry.path)}: ${baseName(blend)}'s export by hand, as no Blender here can make it`, run: () => handExport(entry.path, blend) });
    }
    const script = one ? modelScriptOf(one.path) : undefined;
    if (script !== undefined) items.push({ mcp: 'model_open', label: 'Open in Model tab', rule: items.length > 0, title: `${baseName(script)} built and shown in the Model tab: its views, its parts, rebuilt as it is saved`, run: () => openModel(script) });
    else if (one && adoptable(one.path)) items.push({ mcp: 'model_adopt', label: 'Make a script for it', rule: items.length > 0, title: `A Gladius script importing ${baseName(one.path)}, built as its export (the key unchanged) and opened in the Model tab -- Z undoes`, run: () => void adoptModel(one.path) });
    if (one && writes()) {
      // A script's Open is the Model tab's (above); its text is edited in the application the machine opens it with.
      const external = (): void => void api.reveal(one.path, true).then(() => say(`Opened ${baseName(one.path)} in the application this machine opens it with`), (err: Error) => say(`${baseName(one.path)} did not open: ${err.message}`, true));
      items.push(script !== undefined
        ? { mcp: 'ui', label: 'Open in its application', title: 'In the application this machine opens it with -- for a script, the text editor', run: external }
        : { mcp: 'ui', label: 'Open', rule: items.length > 0, title: 'In the application this machine opens it with -- for a source, what it is edited in', run: () => openFile(one.path) });
    }
    const sources = [...new Set(paths.map(sourcePath).filter((p): p is string => p !== undefined))];
    if (writes() && sources.length > 0) {
      items.push(
        { mcp: 'asset_export', label: 'Export', key: 'E', title: 'Export what needs it of these: stale, missing or failed', run: () => exportKey(false) },
        { mcp: 'asset_export', label: 'Export again', key: keyLabel('Shift+KeyE'), title: 'Export these again, current or not', run: () => exportSources(sources, true) },
      );
      // A source's export named (rule 8): the same field the conflict mark offers, any time after.
      const only = sources.length === 1 && one && one.path === sources[0] && !(entry && conflictOthers(entry).length > 0) ? sources[0] : undefined;
      if (only !== undefined) items.push({ mcp: 'asset_options', label: 'Rename the export…', title: `The name ${baseName(only)}'s export ships as -- its key -- written as its record's "as"; what names it follows by uid; Z undoes`, run: () => renameExport(only) });
    }
    const built = writes() ? ticksOf(rows, index.entries) : null;
    if (built) {
      const putIn = built.on !== true;
      items.push({
        mcp: ['asset_options', 'asset_move'],
        label: putIn ? 'Put in the build' : 'Leave out of the build',
        key: keyLabel('Shift+KeyB'),
        rule: true,
        title: putIn ? 'Ticked in the build: a source exported, a loose file under its own name -- Z undoes' : 'Out of the build: a source never exported, its export to the trash; a loose file named _ -- Z undoes',
        run: () => setBuild(paths, putIn),
      });
    }
    const prefabKey = one ? prefabKeyOf(one.path) : undefined;
    if (writes() && prefabKey !== undefined) {
      items.push({ mcp: 'asset_new', label: 'Make variant', rule: items.length > 0, title: `A new prefab beside it whose root is an instance of ${prefabKey}, with no overrides: Z undoes`, run: () => void makeVariant(prefabKey) });
      items.push({ mcp: 'asset_new', label: 'New prefab', title: 'An empty prefab in this folder: one entity, a Transform, named from the folder -- Z undoes', run: () => void newPrefabIn(dirName(one!.path)) });
    }
    if (writes() && one && materialKeyOf(one.path) !== undefined) {
      items.push({ mcp: 'asset_new', label: 'New material', rule: items.length > 0, title: NEW_MATERIAL_TITLE, run: () => void newMaterialIn(dirName(one.path)) });
    }
    if (writes() && one && physmatKeyOf(one.path) !== undefined) {
      items.push({ mcp: 'asset_new', label: 'New physics material', rule: items.length > 0, title: NEW_PHYSMAT_TITLE, run: () => void newPhysmatIn(dirName(one.path)) });
    }
    if (writes()) {
      if (one) items.push({ mcp: 'asset_move', label: 'Rename', rule: true, key: keyLabel('F2'), title: 'Its name a field where it is: the whole family renamed with it', run: () => {
        select(chosen([one.path]));
        rename('files');
      } });
      items.push(
        { mcp: 'asset_copy', label: 'Duplicate', key: keyLabel('Mod+KeyD'), rule: !one, title: 'A copy of each in its own folder, its family with it, named -2', run: () => duplicate(paths) },
        { mcp: 'asset_move', label: 'Move to…', title: 'Another folder of its kind: the family, both sides', run: (byKey) => moveTo(paths, byKey) },
        { mcp: 'asset_copy', label: 'Copy to…', title: 'A copy into another folder of its kind: the family, both sides', run: (byKey) => copyTo(paths, byKey) },
      );
    }
    if (one) {
      items.push({ mcp: 'ui', label: 'Download', rule: true, title: 'This file, to this machine\'s downloads', run: () => download(one.path) });
      const key = keyOfRow(one, index.entries);
      if (key !== undefined) items.push({ mcp: 'ui', label: 'Copy key', key: keyLabel('Mod+KeyC'), title: key, run: () => copy(key, 'the key') });
      items.push({ mcp: 'ui', label: 'Copy path', key: keyLabel('Mod+Shift+KeyC'), title: one.path, run: () => copy(one.path, 'the path') });
      if (writes()) items.push({ mcp: 'ui', label: revealWords(), title: 'On the machine running the dev server', run: () => revealOnDisk(one.path) });
    }
    if (writes()) items.push({ mcp: 'asset_delete', label: 'Delete', key: keyLabel('Delete'), rule: true, title: 'To the trash, each with its family: Z undoes', run: () => trashPaths(paths) });
    return items;
  }

  /**
   * A folder's menu. From the tree (`fromTree`) the folder is opened first, as
   * a row's menu acts on the open one; from a folder's tile or row in the files
   * card it is only chosen -- the tile stays under its menu -- and Open is
   * there to go in.
   */
  function folderMenu(path: string, at: Point, byKey: boolean, fromTree: boolean): void {
    if (fromTree && path !== folder) openFolder(path);
    showMenu(at, index.childrenOf(path).files, folderItems(path, fromTree), naming.title(path), byKey);
  }

  function filesMenu(what: FilesMenu, at: Point, byKey: boolean): void {
    if (what.kind === 'sort') return sortMenu(at, byKey);
    if (what.kind === 'space') {
      const items: MenuItem[] = [];
      const takes = folderTakes(folder, naming.title(folder));
      if (writes() && inScenes(folder)) items.push({ mcp: 'asset_new', label: 'New scene', title: NEW_SCENE_TITLE, run: () => void newSceneIn(folder) });
      if (writes() && inModels(folder)) items.push({ mcp: 'asset_new', label: 'New model…', title: NEW_MODEL_TITLE, run: () => newModelIn(folder) });
      if (writes() && inModels(folder) && importRefused(folder, naming) === null) items.push({ mcp: 'asset_import', label: 'Import model…', title: IMPORT_MODEL_TITLE, run: () => importModelInto(folder) });
      if (writes() && takes.newFolder) items.push({ mcp: 'asset_new', label: takes.newFolder === 'pack' ? 'New pack' : 'New folder', key: keyLabel('Shift+KeyN'), title: 'A folder in this one, named in place', run: () => newFolder() });
      if (writes() && inPrefabs(folder)) items.push({ mcp: 'asset_new', label: 'New prefab', title: 'An empty prefab here: one entity, a Transform, named from the folder -- Z undoes', run: () => void newPrefabIn(folder) });
      if (writes() && inMaterials(folder)) items.push({ mcp: 'asset_new', label: 'New material', title: NEW_MATERIAL_TITLE, run: () => void newMaterialIn(folder) });
      // In its folder, and on the assets' root: the folder made with the first one where the project has none yet.
      if (writes() && (inPhysmats(folder) || folder === ROOTS.boot.dir)) items.push({ mcp: 'asset_new', label: 'New physics material', title: NEW_PHYSMAT_TITLE, run: () => void newPhysmatIn(inPhysmats(folder) ? folder : PHYSMATS_DIR) });
      if (writes() && takes.import) {
        items.push(
          { mcp: 'asset_import', label: 'Import Files…', key: keyLabel('KeyI'), title: 'Choose files to import into this folder', run: () => pick(filesInput) },
          { mcp: 'asset_import', label: 'Import Folder…', title: 'Choose a folder to import into this one, its folders kept', run: () => pick(folderInput) },
        );
        // An image is no scene, no prefab and no material: no Paste image where they live.
        if (!inScenes(folder) && !inPrefabs(folder) && !inMaterials(folder)) items.push({ mcp: 'asset_import', label: 'Paste image', title: `The image on the clipboard -- the browser may ask to allow it first; ${keyLabel('Mod+KeyV')}, a paste, never asks`, run: () => void pasteImage() });
      }
      items.push({ mcp: 'ui', label: 'Sort by ▸', rule: items.length > 0, title: 'Name, status, size, modified or kind', run: () => sortMenu(at, true) });
      if (writes() && !under(folder, TRASH)) items.push({ mcp: 'ui', label: `${revealWords()}: this folder`, title: naming.say(folder), run: () => revealOnDisk(folder) });
      if (writes() && takes.restoreAll) items.push({ mcp: 'asset_restore', label: 'Restore all', title: 'Every file in the trash, back where it was, but the automatic exports\' slot (its own Restore): one step', run: () => restoreAll() });
      if (writes() && takes.empty) items.push({ mcp: 'asset_empty_trash', label: 'Empty', danger: true, title: 'Everything in the trash removed for good: it asks first', run: () => emptyTrash() });
      items.push({ mcp: 'ui', label: 'Select all', key: keyLabel('Mod+KeyA'), title: 'Every file shown', run: () => selectAll() });
      return showMenu(at, [], items, naming.title(folder), byKey);
    }
    const path = what.path;
    if (isFolderPath(index, path)) return folderMenu(path, at, byKey, false);
    const paths = selection.paths.includes(path) ? selection.paths : [path];
    const rows = paths.map((p) => shownAt(index, p)).filter((r): r is Shown => r !== undefined);
    showMenu(at, rows, fileItems(paths), paths.length === 1 ? baseName(paths[0]!) : filesText(paths.length), byKey);
  }

  /** Import ▾ (§4's title row): Files…, Folder…, Paste image -- under it. */
  function importMenu(at: HTMLElement): void {
    const r = at.getBoundingClientRect();
    showMenu({ x: r.left, y: r.bottom + 4 }, [], [
      { mcp: 'asset_import', label: 'Files…', key: keyLabel('KeyI'), title: 'Choose files to import into this folder', run: () => pick(filesInput) },
      { mcp: 'asset_import', label: 'Folder…', title: 'Choose a folder to import into this one, its folders kept', run: () => pick(folderInput) },
      { mcp: 'asset_import', label: 'Paste image', title: `The image on the clipboard -- the browser may ask to allow it first; ${keyLabel('Mod+KeyV')}, a paste, never asks`, run: () => void pasteImage() },
    ], `Import into ${naming.title(folder)}`, false);
  }

  // ---------------------------------------------------------------- the folder picker: Move to…, Copy to…, Restore to…

  /** The drop-down of folders open, if one is: its buttons the menu keys walk. */
  let picker: { shut: () => void; buttons: HTMLButtonElement[] } | null = null;

  function shutPicker(): void {
    const was = picker;
    picker = null;
    was?.shut();
    if (was) nudge();
  }

  /** The folders in `path`, by name: as the tree lists them. */
  const foldersIn = (path: string): string[] => index.childrenOf(path).folders.sort((a, b) => (baseName(a).toLowerCase() < baseName(b).toLowerCase() ? -1 : 1));

  /**
   * The folder tree in a drop-down (§6.7, `dropUnder`), under the button that
   * asked or where the menu was: every folder of every root but the Trash, a
   * folder `refuse` refuses dim, its reason on hover. A click chooses; the
   * menu's arrows walk it, Enter chooses, Esc puts it away.
   */
  function pickFolder(title: string, refuse: (path: string) => string | null, chose: (path: string) => void, byKey: boolean): void {
    shutPicker();
    menu.close();
    const list = el('div', 'ed-card ed-menu ed-as-picker');
    list.setAttribute('role', 'menu');
    list.append(el('div', 'ed-menu-title', title));
    const buttons: HTMLButtonElement[] = [];
    const walk = (path: string, depth: number): void => {
      const no = refuse(path);
      const b = control('ui', 'ed-menu-item ed-as-pick');
      b.style.paddingLeft = `${8 + depth * 14}px`;
      b.append(el('span', no ? 'ed-dim' : undefined, naming.title(path)));
      b.title = no ?? naming.say(path);
      b.setAttribute('aria-disabled', String(no !== null));
      b.addEventListener('click', () => {
        if (no) return say(no, true);
        shutPicker();
        chose(path);
      });
      list.append(b);
      if (!no) buttons.push(b);
      for (const kid of foldersIn(path)) walk(kid, depth + 1);
    };
    for (const r of naming.roots) if (r !== TRASH && hasFolder(r)) walk(r, 0);
    const at = anchor ?? files.head;
    let shut: () => void;
    if (at instanceof HTMLElement && at.isConnected) shut = dropUnder(root, at, list, shutPicker);
    else {
      // At the point the menu was opened at, kept on screen; a press elsewhere puts it away.
      const point = at instanceof HTMLElement ? { x: at.getBoundingClientRect().left, y: at.getBoundingClientRect().bottom } : at;
      root.append(list);
      const { width, height } = list.getBoundingClientRect();
      list.style.left = `${Math.max(8, Math.min(point.x, innerWidth - width - 8))}px`;
      list.style.top = `${Math.max(8, Math.min(point.y, innerHeight - height - 8))}px`;
      const outside = (event: PointerEvent): void => {
        if (!list.contains(event.target as Node)) shutPicker();
      };
      document.addEventListener('pointerdown', outside, true);
      shut = () => {
        list.remove();
        document.removeEventListener('pointerdown', outside, true);
      };
    }
    picker = { shut, buttons };
    if (byKey) buttons[0]?.focus();
    nudge();
  }

  function stepPicker(by: 1 | -1): void {
    const buttons = picker?.buttons ?? [];
    if (buttons.length === 0) return;
    const at = buttons.indexOf(document.activeElement as HTMLButtonElement);
    buttons[at < 0 ? (by > 0 ? 0 : buttons.length - 1) : (at + by + buttons.length) % buttons.length]!.focus();
  }

  const many = (paths: readonly string[]): string => (paths.length === 1 ? baseName(fromTrash(paths[0]!)?.path ?? paths[0]!) : `${paths.length}`);

  function moveTo(paths: readonly string[], byKey: boolean): void {
    const trashed = paths.every((p) => fromTrash(p) !== undefined);
    pickFolder(`${trashed ? 'Restore' : 'Move'} ${many(paths)} to…`, (f) => moveRefused(paths, f, index, naming), (f) => moveInto(paths, f), byKey);
  }

  function copyTo(paths: readonly string[], byKey: boolean): void {
    pickFolder(`Copy ${many(paths)} to…`, (f) => moveRefused(paths, f, index, naming, true), (f) => copyInto(paths, f), byKey);
  }

  // ---------------------------------------------------------------- edits

  /** The pack a path is in, or undefined for the boot set. */
  const packOf = (path: string): string | undefined => locate(path)?.pack;

  /** A key and, for a pack's, its other spelling (§A.6: a move between the boot set and a pack). */
  const spellings = (key: string): string[] => (key.includes(':') ? [key, key.slice(key.indexOf(':') + 1)] : [key]);

  /** Tiles dropped on a folder, or Move to…: a move of each family -- a trashed file restored there -- one step; between the boot set and a pack, the uses asked first. */
  async function moveInto(paths: readonly string[], to: string): Promise<void> {
    if (!writes()) return say(readOnlyLine(), true);
    const no = moveRefused(paths, to, index, naming);
    if (no) return say(no, true);
    // What names them -- a prefab nesting one, a scene, a material's map -- follows by uid: the server's move rewrites
    // their keys in the same call, and the step puts them back with it (Docs/asset-ids.md §4). Nothing is refused for it.
    // But code holds keys, never uids (rule 5): one game code names -- a prefab, a model, a sound, any kind -- is refused,
    // as its rename is, naming the lines.
    const named = await codeNaming(paths.filter((p) => fromTrash(p) === undefined).flatMap((p) => keysOf(p, isFolderPath(index, p))));
    if (named !== null) return say(`Not moved: ${named}`, true);
    const trashed = paths.filter((p) => fromTrash(p) !== undefined);
    if (trashed.length > 0) restoreInto(trashed, to);
    const rest = paths.filter((p) => fromTrash(p) === undefined);
    if (rest.length === 0) return;
    const heads = familyHeads(rest, index.entries);
    const pairs = heads.map((p) => [p, joinPath(to, baseName(p))] as const);
    const label = (n: number): string => `Move ${n === 1 ? stemOf(baseName(heads[0]!)) : n} to ${naming.title(to)}`;
    const go = (): void => void runEdit(moveEdit(api, editHost, pairs, label)).then((ok) => ok && say(`${label(pairs.length)} · Z undoes`));
    // Between the boot set and a pack: what else names it as written (a data file's key in src/) asked about.
    const crossing = heads.filter((p) => packOf(isFolderPath(index, p) ? joinPath(p, 'x') : p) !== packOf(joinPath(to, 'x')));
    const keys = crossing.flatMap((p) => {
      const row = index.entries.get(p);
      const key = row ? keyOfRow(row, index.entries) : undefined;
      return key === undefined ? [] : spellings(key);
    });
    if (keys.length === 0) return go();
    const lines = await usesNow(keys);
    if (lines.length === 0) return go();
    ask(`${usesLine(lines)}: moving between the boot set and a pack changes its key. Move ${many(rest)} all the same?`, 'Move', go);
  }

  /** The keys a move or a rename of `path` changes (`code-naming.ts`). */
  const keysOf = (path: string, isDir: boolean, cap?: number): string[] => namedKeys(path, isDir, index.entries, Object.keys(prefabFiles()), cap);
  /** Game code naming any of `keys` (rule 5): the refusal's words, or null. */
  const codeNaming = (keys: readonly string[]): Promise<string | null> => codeNames(keys, (key) => api.uses(key));

  function copyInto(paths: readonly string[], to: string): void {
    if (!writes()) return say(readOnlyLine(), true);
    const no = moveRefused(paths, to, index, naming, true);
    if (no) return say(no, true);
    const heads = familyHeads(paths, index.entries);
    const label = (n: number): string => `Copy ${n === 1 ? stemOf(baseName(heads[0]!)) : n} to ${naming.title(to)}`;
    void runEdit(copyEdit(api, editHost, heads.map((p) => [p, to] as const), label)).then((ok) => ok && say(`${label(heads.length)} · Z undoes`));
  }

  /** Mod+D, the menu's Duplicate: a copy of each in its own folder, its family with it, named `-2`: one step. */
  function duplicate(paths: readonly string[] = selection.paths): void {
    if (!writes()) return;
    if (focus === 'folders' && paths === selection.paths) return say('Duplicate copies files: choose them in the files', true);
    if (paths.length === 0) return say('Nothing chosen to duplicate', true);
    if (paths.some((p) => under(p, TRASH))) return say('That is in the trash: restore it first', true);
    if (paths.some((p) => !index.entries.has(p))) return say('A folder is not duplicated: copy what is in it, or make a new folder', true);
    const alone = partAlone(paths, index.entries);
    if (alone) return say(`Can't duplicate: ${baseName(alone.part)} is part of ${alone.owners.map(baseName).join(', ')} -- duplicate its model, and it comes too`, true);
    const heads = familyHeads(paths, index.entries);
    const label = (n: number): string => (n === 1 ? `Duplicate ${stemOf(baseName(heads[0]!))}` : `Duplicate ${n}`);
    void runEdit(copyEdit(api, editHost, heads.map((p) => [p, dirName(p)] as const), label)).then((ok) => ok && say(`${label(heads.length)}: named -2 · Z undoes`));
  }

  /** How many of these paths' keys `GET uses` found named in `src/`, from what was asked already: the delete line's. */
  function namedInSrc(paths: readonly string[]): number {
    let n = 0;
    for (const p of paths) {
      const row = index.entries.get(p);
      const key = row ? keyOfRow(row, index.entries) : undefined;
      const found = key === undefined ? undefined : uses.get(key);
      if (Array.isArray(found) && found.length > 0) n++;
    }
    return n;
  }

  /** Delete, Backspace and the menu's Delete: one `trash()`, whichever way it came (§6). */
  function trash(): void {
    if (!writes()) return;
    const paths = focus === 'folders' ? [folder] : selection.paths.length > 0 ? selection.paths : focus === 'preview' ? [folder] : [];
    trashPaths(paths);
  }

  /** The world's instances of `keys`, as the step's words: ` · 3 instances of crates/pair-z here go plain` -- or nothing. */
  function instancesOf(keys: ReadonlySet<string>): string {
    const world = ctx.world;
    const by = new Map<string, number>();
    for (let e = 1; e < world.extent; e++) {
      if (!world.alive(e as Entity) || world.instanceRoot(e as Entity) !== e) continue;
      const key = world.prefabOf(e as Entity)?.key;
      if (key !== undefined && keys.has(key)) by.set(key, (by.get(key) ?? 0) + 1);
    }
    if (by.size === 0) return '';
    const n = [...by.values()].reduce((a, b) => a + b, 0);
    return ` · ${n === 1 ? 'its instance' : `${n} instances`} of ${[...by.keys()].sort().join(', ')} here ${n === 1 ? 'goes' : 'go'} plain (entities as they are, no prefab)`;
  }

  /**
   * `paths` to the trash, as one step; `asked`, a prefab open with unsaved edits among them already asked about;
   * `checked`, the server asked already that nothing names them.
   */
  function trashPaths(paths: readonly string[], asked = false, checked = false): void {
    if (!writes()) return;
    if (paths.length === 0) return say('Nothing chosen to delete', true);
    if (paths.some((p) => under(p, TRASH))) return say('That is in the trash already: Restore brings it back, and Empty removes everything there for good', true);
    const dirs = paths.filter((p) => !index.entries.has(p) && hasFolder(p));
    for (const d of dirs) {
      const takes = folderTakes(d, naming.title(d));
      if (!takes.delete) return say(takes.why ?? `${naming.title(d)} is not deleted`, true);
    }
    const chosenFiles = paths.filter((p) => index.entries.has(p));
    const going = new Set([...chosenFiles, ...[...index.entries.keys()].filter((p) => dirs.some((d) => under(p, d)))].map(prefabKeyOf).filter((k): k is string => k !== undefined));
    // Anything a data file still names -- by uid, a stale key too, or by a bare key: a prefab nesting it, a scene holding
    // an instance of it, a material wearing a texture, a prefab drawn with a model -- would be left broken: refused, naming
    // them (the server's `POST referrers`, Docs/asset-ids.md §4). Those deleted with it are no referrers.
    const everything = [...new Set([...chosenFiles, ...[...index.entries.keys()].filter((p) => dirs.some((d) => under(p, d) || (twin(d) !== undefined && under(p, twin(d)!))))])];
    if (!checked && everything.length > 0) {
      void api.referrers(everything).then(
        ({ referrers }) => {
          if (referrers.length === 0) return trashPaths(paths, asked, true);
          const names = [...new Set(referrers.flatMap((r) => r.names))].sort();
          const who = referrers.map((r) => referrerName(r.path));
          say(`Not deleted: ${who.join(', ')} ${who.length === 1 ? 'names' : 'name'} ${names.join(', ')} -- take ${names.length === 1 ? 'it' : 'them'} out of ${who.length === 1 ? 'that one' : 'those'} first`, true);
        },
        (err) => say(`Not deleted: ${reasonOf(err)}`, true),
      );
      return;
    }
    // One open in the editor with edits not saved: they could only be dropped after -- asked first.
    const open = ctx.prefabsUnsaved.filter((k) => going.has(k));
    if (open.length > 0 && !asked) return ask(`${openWords(open)}: deleted, ${open.length === 1 ? 'its' : 'their'} edits can only be dropped (Back without them). Delete anyway? Z undoes.`, 'Delete', () => trashPaths(paths, true, true), true);
    const named = namedInSrc(chosenFiles);
    // Instances of it in the world open now: allowed -- a scene is the person's, not shipped -- but they go plain, so said.
    const plain = instancesOf(going);
    const what = paths.length === 1 ? (dirs.length === 1 ? `${baseName(paths[0]!)}/` : baseName(paths[0]!)) : `${paths.length}`;
    const said = (ok: boolean): void => {
      if (ok) say(`Moved ${what} to the trash${named > 0 ? ` · ${named} ${named === 1 ? 'is' : 'are'} named in src/` : ''}${plain} · Z undoes`);
    };
    if (dirs.length === 0) {
      void runEdit(trashEdit(api, chosenFiles, chosenFiles.length === 1 ? `Delete ${baseName(chosenFiles[0]!)}` : `Delete ${chosenFiles.length}`)).then(said);
      return;
    }
    // A folder: every family under it and its twin, then each folder left, the deepest first (§8).
    const sides = dirs.flatMap((d) => {
      const other = twin(d);
      return other !== undefined && hasFolder(other) ? [d, other] : [d];
    });
    const below = (path: string): string[] => [path, ...foldersIn(path).flatMap(below)];
    const folderList = [...new Set(sides.flatMap(below))];
    const inside = [...index.entries.keys()].filter((p) => sides.some((d) => under(p, d)));
    const count = inside.filter((p) => index.entries.get(p)?.role !== 'record').length;
    const label = dirs.length === 1 && chosenFiles.length === 0 ? `Delete ${baseName(dirs[0]!)}/` : `Delete ${paths.length}`;
    const go = (): void => void runEdit(deleteFolderEdit(api, editHost, label, [...new Set([...chosenFiles, ...inside])], folderList)).then(said);
    if (count === 0 && chosenFiles.length === 0) return go();
    const these = dirs.length === 1 ? `${baseName(dirs[0]!)}/` : `${dirs.length} folders`;
    ask(`Delete ${these} and the ${filesText(count + chosenFiles.length)} under ${dirs.length === 1 ? 'it' : 'them'}? They go to the trash; Z undoes.`, 'Delete', go);
  }

  /**
   * Rename the export… (Docs/asset-ids.md rule 8, §4): a small field asking the name a source's export ships as, written
   * as its record's `"as"` by the server (`PUT export-as`) -- its exports moved, what names its key following by uid --
   * one step, Z undoing it. Its own stem typed takes the `"as"` out.
   */
  /** Rename the export's step: the menu's and `asset_options`' `as`. */
  const exportAsLabel = (path: string, name: string): string => `Rename the export of ${baseName(path)} → ${name}`;

  function renameExport(path: string): void {
    if (!writes()) return;
    const row = index.entries.get(path);
    if (row?.role !== 'source') return say(`${baseName(path)} is no source: only a source's export is named`, true);
    const stem = splitName(baseName(path)).stem;
    const now = row.key === undefined ? stem : row.key.slice(row.key.lastIndexOf('/') + 1);
    if (inspector.side.folded) inspector.side.setFolded(false);
    const from = focus;
    setFocus('preview');
    inspector.ask.askName(`${baseName(path)} ships as… -- its export's name, no extension`, now === stem && row.status === 'conflict' ? `${stem}-2` : now, (name) => {
      if (focus === 'preview' && from !== 'preview') setFocus(from);
      if (caseKey(name) === caseKey(now)) return say(`${baseName(path)} ships as ${now} already`);
      const label = exportAsLabel(path, name);
      void runEdit(exportAsEdit(api, editHost, path, exportAsValue(path, name), label)).then((ok) => ok && say(`${label} · Z undoes`));
    }, 'Rename');
  }

  /** The other files of a conflict: those with its key, sources and loose files -- Keep this one's to trash. */
  function conflictOthers(row: Shown): string[] {
    if (!isEntry(row) || row.status !== 'conflict' || row.key === undefined) return [];
    // A source out of the build ships nothing: it is in no conflict, and no other of one.
    return [...index.entries.values()].filter((e) => e.path !== row.path && e.key === row.key && ((e.role === 'source' && e.included) || e.role === 'loose')).map((e) => e.path);
  }

  /** A `.glb` source in conflict beside a `.blend` with its stem, where no Blender can make it: its `.blend`. */
  function handBlend(row: Shown): string | undefined {
    if (!isEntry(row) || row.role !== 'source' || row.status !== 'conflict' || extOf(row.path) !== 'glb') return undefined;
    if ((tools ?? []).some((t) => t.tool === 'blender' && t.state === 'found')) return undefined;
    const blend = joinPath(dirName(row.path), `${splitName(baseName(row.path)).stem}.blend`);
    return index.entries.has(blend) ? blend : undefined;
  }

  function keepThis(path: string, others: readonly string[]): void {
    void runEdit(keepEdit(api, path, others)).then((ok) => ok && say(`Kept ${baseName(path)}: ${others.map(baseName).join(', ')} to the trash · Z undoes`));
  }

  function handExport(glb: string, blend: string): void {
    void runEdit(handExportEdit(api, editHost, glb, blend)).then((ok) => ok && say(`${baseName(glb)} is ${baseName(blend)}'s hand export now: _${baseName(glb)} · Z undoes`));
  }

  // ---------------------------------------------------------------- in the build

  /**
   * These files put in the build (`on`) or left out of it (§4, §6, §8): every
   * flip their ticks make toward it (`flipsTo`) -- a source's record, a name's
   * `_` -- one step (`includeEdit`). A row's tick, the inspector's, the menu
   * and `Shift+B` all come here.
   */
  function setBuild(paths: readonly string[], on: boolean): void {
    if (!writes()) return;
    const rows = paths.map((p) => shownAt(index, p)).filter((r): r is Shown => r !== undefined);
    const ticks = rows.map((r) => tickOf(r, index.entries)).filter((tick) => tick !== null);
    if (ticks.length === 0) return say('Nothing chosen has a tick: a reference, a record or a file in the trash ships under no name it can have', true);
    const { flips, stuck } = flipsTo(ticks, on);
    if (stuck !== undefined) return say(`Not now: ${stuck} -- rename it, or delete it, first`, true);
    if (flips.length === 0) return say(on ? 'In the build already' : 'Out of the build already');
    const first = flips[0]!;
    // Named as it is in the build: `rock.glb`, never its `_` name.
    const name = baseName('record' in first ? first.record : first.from).replace(/^_/, '');
    const label = (n: number): string => (on ? `Put ${n === 1 ? name : n} in the build` : `Leave ${n === 1 ? name : n} out of the build`);
    void runEdit(includeEdit(api, editHost, flips, on, label)).then((ok) => ok && say(`${label(flips.length)}${on ? '' : ': it ships nothing'} · Z undoes`));
  }

  /** `Shift+B`: the files chosen, one tick for all -- in, unless every one is in already. */
  function toggleBuild(): void {
    if (focus === 'folders') return say(`A folder is in the build as its files are: choose them in Files, then ${keyLabel('Shift+KeyB')}`, true);
    if (selection.paths.length === 0) return say(`Nothing chosen: ${keyLabel('Shift+KeyB')} puts the files chosen in the build, or out of it`, true);
    const rows = selection.paths.map((p) => shownAt(index, p)).filter((r): r is Shown => r !== undefined);
    const all = ticksOf(rows, index.entries);
    if (!all) return say('Nothing chosen has a tick: a reference, a record or a file in the trash ships under no name it can have', true);
    setBuild(selection.paths, all.on !== true);
  }

  // ---------------------------------------------------------------- the trash

  /** Trashed paths by slot, as `POST restore` takes them: the paths they had. */
  function bySlot(trashed: readonly string[]): Array<{ slot: string; paths: string[] }> {
    const slots = new Map<string, string[]>();
    for (const p of trashed) {
      const at = fromTrash(p);
      if (!at) continue;
      slots.set(at.slot, [...(slots.get(at.slot) ?? []), at.path]);
    }
    return [...slots].map(([slot, paths]) => ({ slot, paths }));
  }

  /** Restore: back where they were, one step -- asking first if any comes back as -2 (§7). */
  function restoreTrashed(trashed: readonly string[]): void {
    if (!writes() || trashed.length === 0) return;
    const back = restoring(trashed, (p) => index.entries.has(p));
    const go = (): void => void runEdit(restoreEdit(api, editHost, bySlot(trashed), restoreLabel(back))).then((ok) => ok && say(`${restoreLabel(back)} · Z undoes`));
    const question = restoreQuestion(back);
    if (question) ask(question, 'Restore', go);
    else go();
  }

  /** Restore here: a trashed tile dropped on a folder, or Restore to… -- a restore, then a move, one step. */
  function restoreInto(trashed: readonly string[], to: string): void {
    const back = restoring(trashed, (p) => index.entries.has(p));
    void runEdit(restoreEdit(api, editHost, bySlot(trashed), restoreLabel(back, true), to)).then((ok) => ok && say(`${restoreLabel(back, true)}: into ${naming.say(to)} · Z undoes`));
  }

  /** Restore all: every slot but the automatic exports', the newest first, one step -- the automatic slot's own Restore brings that back. */
  function restoreAll(): void {
    const slots = slotsNewestFirst(index.trash);
    if (slots.length === 0) return say(index.trash.length > 0 ? 'Only the automatic exports\' slot is in the trash: its own Restore brings it back' : 'Nothing in the trash');
    const every = slots.flatMap((slot) => index.childrenOf(`${TRASH}/${slot}`).files.map((f) => f.path));
    const back = restoring(every, (p) => index.entries.has(p));
    const go = (): void => void runEdit(restoreEdit(api, editHost, slots.map((slot) => ({ slot })), 'Restore all')).then((ok) => ok && say(`Restored ${filesText(every.length)} · Z undoes`));
    const question = restoreQuestion(back);
    if (question) ask(question, 'Restore all', go);
    else go();
  }

  /** Empty: for good -- asked first, and no step (§8). */
  function emptyTrash(): void {
    const n = index.trash.reduce((sum, slot) => sum + slot.files.length, 0);
    if (n === 0) return say('Nothing in the trash');
    ask(`Empty the trash? ${filesText(n)} go for good: Empty is no step, and Z cannot bring them back.`, 'Empty', () => {
      api.emptyTrash().then(() => say(`The trash is empty: ${filesText(n)} gone for good`), (err) => say(`The trash was not emptied: ${reasonOf(err)}`, true));
    }, true);
  }

  /**
   * A question in the inspector, unfolded to ask (§6, "Delete"), the keys with
   * it while it is up (Esc says no); answered or not, the keys go back to the
   * card that asked -- Folders after a folder's Delete -- unless a press took
   * them elsewhere meanwhile.
   */
  function ask(text: string, yes: string, run: () => void, danger = false): void {
    if (inspector.side.folded) inspector.side.setFolded(false);
    const from = focus;
    setFocus('preview');
    inspector.ask.askFirst(text, yes, run, danger, () => {
      if (focus === 'preview' && from !== 'preview') setFocus(from);
    });
  }

  // ---------------------------------------------------------------- uses, asked once a key

  /** `GET uses` by key, for the session (§9): asked once, when a rename field or a move first needs it. */
  const uses = new Map<string, Use[] | 'asking'>();

  /** Every use of these keys found so far, or null while any is asked -- `then` told when it is in. */
  function usesOf(keys: readonly string[], then: () => void): Use[] | null {
    let out: Use[] | null = [];
    for (const key of keys) {
      const had = uses.get(key);
      if (Array.isArray(had)) {
        if (out) out.push(...had);
        continue;
      }
      out = null;
      if (had === 'asking') continue;
      uses.set(key, 'asking');
      api.uses(key).then((found) => {
        uses.set(key, found);
        then();
      }, () => {
        uses.delete(key);
      });
    }
    return out;
  }

  /** Every use of these keys, once all are asked. */
  function usesNow(keys: readonly string[]): Promise<Use[]> {
    return new Promise((resolve) => {
      const go = (): void => {
        const found = usesOf(keys, go);
        if (found) resolve(found);
      };
      go();
      // A key that could not be asked is not waited for.
      setTimeout(() => resolve(keys.flatMap((k) => (Array.isArray(uses.get(k)) ? (uses.get(k) as Use[]) : []))), 4000);
    });
  }

  // ---------------------------------------------------------------- rename, where the name is

  /** The name made a field: whose, where, and what was typed last -- the uses line follows it. */
  let renaming: { field: RenameField; path: string; folder: boolean; where: 'files' | 'folders' | 'head' | 'new'; typed: string } | null = null;

  /** Why a path cannot be renamed, or null. */
  function renameRefusal(path: string, isDir: boolean): string | null {
    if (under(path, TRASH)) return isDir ? (folderTakes(path, naming.title(path)).why ?? 'the trash is not renamed') : `${baseName(fromTrash(path)?.path ?? path)} is in the trash: restore it, then rename it`;
    if (isDir) return folderTakes(path, naming.title(path)).why;
    const row = index.entries.get(path);
    if (!row) return `${baseName(path)} is not in the index`;
    if (row.role === 'part' && (row.owners ?? []).length > 0) return `${baseName(path)} is part of ${(row.owners ?? []).map(baseName).join(', ')}: its model names it, so it keeps its name`;
    return null;
  }

  function renames(path: string | null, isDir: boolean): boolean {
    return path !== null && renameRefusal(path, isDir) === null;
  }

  /**
   * F2, Shift+Enter, the menu's Rename, the head's name (§6.1): the focused
   * card's name a field where it is -- the tile's or the row's in Files, the
   * open folder's row in Folders, the inspector's head with the focus in the
   * preview; of several, the primary's.
   */
  function rename(where?: 'files' | 'folders' | 'head'): void {
    if (!writes()) return;
    const card = where ?? (focus === 'folders' ? 'folders' : focus === 'preview' ? 'head' : 'files');
    const what = showing();
    const path = card === 'folders' ? folder : card === 'head' ? (what.kind === 'many' || what.kind === 'gone' ? null : what.path) : selection.primary;
    if (path === null) return say(card === 'head' && what.kind === 'many' ? 'Several chosen: rename one at a time' : 'Nothing chosen to rename: the arrows choose a file', true);
    const isDir = card === 'folders' || (card === 'head' && what.kind === 'folder') || isFolderPath(index, path);
    const why = renameRefusal(path, isDir);
    if (why) return say(why, true);
    endRename();
    if (card === 'files' && files.query) files.clearSearch();
    const field = renameField({
      name: baseName(path),
      folder: isDir,
      typed: (name, refused) => renameSaid(name, refused),
      commit: (name) => commitRename(path, isDir, name),
      done: () => endRename(),
    });
    const placed = card === 'folders' ? folders.editName(path, field.form) : card === 'head' ? inspector.editName(field.form) : files.editName(path, field.form);
    if (!placed) {
      field.cancel();
      return say(`${baseName(path)} is not drawn to rename: open its folder`, true);
    }
    renaming = { field, path, folder: isDir, where: card, typed: baseName(path) };
    renameSaid(baseName(path), null);
  }

  /** The keys a rename changes: a file's own -- a pack's in both spellings -- or every key under a folder, at most forty. */
  function renameKeys(path: string, isDir: boolean): string[] {
    return isDir ? keysOf(path, true, 40) : keysOf(path, false).flatMap(spellings);
  }

  /** The rename's line, in the inspector and on the status line (§6.1): the uses, what the key becomes; or the refusal, its suggestion a click away. */
  function renameSaid(name: string, refused: Refused | null): void {
    const now = renaming;
    if (!now) return;
    now.typed = name;
    if (now.where === 'new') return;
    if (refused) {
      const text = `${refused.refused}${refused.suggested ? ` -- ${refused.suggested} would do` : ''}`;
      files.note(text, true);
      inspector.note(refused.refused, true, refused.suggested !== undefined ? { label: `Use ${refused.suggested}`, run: () => renaming?.field.use(refused.suggested!) } : undefined);
      held = text;
      nudge();
      return;
    }
    const keys = renameKeys(now.path, now.folder);
    const found = usesOf(keys, () => {
      if (renaming === now) renameSaid(now.typed, null);
    });
    let text: string;
    if (now.folder) {
      text = keys.length === 0 ? 'nothing under it has a key: no code names it' : found === null ? 'looking for uses in src/…' : found.length === 0 ? `no literal uses in src/ of its ${keys.length === 1 ? 'key' : `${keys.length} keys`}` : usesLine(found);
    } else {
      const row = index.entries.get(now.path);
      const key = row ? keyOfRow(row, index.entries) : undefined;
      const becomes = key !== undefined && name !== baseName(now.path) ? keyWithStem(key, stemOf(name)) : undefined;
      text = key === undefined ? 'it has no key: no code names it' : usesLine(found, becomes);
    }
    files.note(text);
    inspector.note(text);
    held = text;
    nudge();
  }

  /** Enter in the field: `GET names`, then the move as a step -- or the refusal, the field kept open with it. */
  async function commitRename(path: string, isDir: boolean, name: string): Promise<Refused | null> {
    const dir = dirName(path);
    const to = joinPath(dir, name);
    if (to === path) return null;
    // A case-only rename is the same name to GET names, and the same key: the move makes it through a temporary
    // name (and `git mv` for a file git tracks), and nothing that names the key changes.
    const caseOnly = caseKey(name) === caseKey(baseName(path));
    if (!caseOnly) {
      try {
        const [answer] = await api.names(dir, [name], isDir ? { folder: true } : {});
        if (answer && 'refused' in answer) {
          say(`Not renamed: ${answer.refused}`, true);
          return { refused: answer.refused, ...(answer.suggested !== undefined ? { suggested: answer.suggested } : {}) };
        }
      } catch (err) {
        say(`Not renamed: ${reasonOf(err)}`, true);
        return { refused: reasonOf(err) };
      }
    }
    const fromKey = isDir ? undefined : prefabKeyOf(path);
    // An asset game code names (`prefab('crates/marker')`, `Assets.instance('props/crate')`): renamed, its code would
    // no longer typecheck -- refused, naming the file and the line, so the code changes first (rule 5; Docs/prefabs.md
    // §9, authoring). A case-only rename keeps the key.
    const why = caseOnly ? null : await codeNaming(keysOf(path, isDir));
    if (why !== null) {
      say(`Not renamed: ${why}`, true);
      return { refused: why };
    }
    // Open in the editor with edits not saved: renamed, they could only be dropped (its Save never writes at a key the file left) -- asked first.
    const open = caseOnly ? [] : isDir ? ctx.prefabsUnsaved.filter((k) => under(prefabPathOf(k), path)) : ctx.prefabsUnsaved.filter((k) => k === fromKey);
    if (open.length > 0) {
      ask(`${openWords(open)}: renamed, ${open.length === 1 ? 'its' : 'their'} edits can only be dropped (Back without them). Rename anyway? Z undoes.`, 'Rename', () => renameNow(path, to), true);
      return null;
    }
    renameNow(path, to);
    return null;
  }

  /**
   * The rename itself, as a step: the path changes, and whatever names it -- a prefab nesting it, a scene holding an
   * instance, a material wearing a texture, a prefab drawn with a model -- follows by uid, rewritten by the server's
   * move in the same call and put back with its undo (Docs/asset-ids.md §4; `moveEdit`). The world's own instances of
   * a renamed prefab are named anew as it moves (`editHost.moved`).
   */
  function renameNow(path: string, to: string): void {
    const name = baseName(to);
    // The stem kept (a stray prefab's .json made .prefab): the names said whole.
    const said = stemOf(baseName(path)) === stemOf(name) ? `${baseName(path)} → ${name}` : `${stemOf(baseName(path))} → ${stemOf(name)}`;
    void runEdit(renameEdit(api, editHost, path, to)).then((ok) => ok && say(`Renamed ${said} · Z undoes`));
  }

  /** A data file naming something, as a refusal names it: `prefab crates/big`, `scene camp`, `material props/rust`, `level beach`; else its path. */
  function referrerName(path: string): string {
    for (const kind of ['prefabs', 'scenes', 'materials', 'levels'] as const) {
      const dir = `${ROOTS.boot.dir}/${KINDS[kind].dir}/`;
      if (path.startsWith(dir)) return `${KINDS[kind].type.toLowerCase()} ${path.slice(dir.length, path.lastIndexOf('.'))}`;
    }
    return path;
  }

  /** Prefabs open in the editor with unsaved edits, said: `crates/big is open in the editor with edits not saved`. */
  const openWords = (keys: readonly string[]): string => `${keys.join(', ')} ${keys.length === 1 ? 'is' : 'are'} open in the editor with edits not saved`;

  // ---------------------------------------------------------------- prefabs (Docs/prefabs.md §7)

  /** The levels holding an instance of prefab `key`, by key (Docs/prefabs.md §6: a level names an instance's prefab by key). */
  const levelsHolding = (key: string): string[] => levelKeys().filter((k) => holdsPrefab(level(k), key));
  /** A level's file. */
  const levelPath = (key: string): string => `${ROOTS.boot.dir}/${KINDS.levels.dir}/${key}.json`;

  /** Is `name` in `dir` taken, in any case -- another file's key, and its name to macOS? */
  const takenIn = (dir: string, name: string): boolean => {
    const wanted = caseKey(joinPath(dir, name));
    for (const path of index.entries.keys()) if (caseKey(path) === wanted) return true;
    return false;
  };

  /** A folder prefabs live in: `src/assets/prefabs` and under it. */
  const inPrefabs = (path: string): boolean => path === PREFABS_DIR || under(path, PREFABS_DIR);

  /**
   * New material: a `standard` with the defaults written as `new-material.material` in `dir` (`-2`… when taken)
   * through `PUT prefab` -- one step, Z trashing it -- chosen, its name in the rename field so it is named where
   * it is (as New scene asks).
   */
  async function newMaterialIn(dir: string): Promise<void> {
    const stem = freeKey(NEW_MATERIAL, (s) => takenIn(dir, `${s}${MATERIAL_SUFFIX}`));
    const path = joinPath(dir, `${stem}${MATERIAL_SUFFIX}`);
    const ok = await runEdit(materialWriteEdit(api, path, materialText(newMaterial()), `New material ${stem}`, () => undefined, true));
    if (!ok) return;
    say(`New material ${materialKeyOf(path) ?? stem}: a standard, white -- name it here; a prefab wears it by its Render.material · Z undoes`);
    openFolder(dir, path);
    rename('files');
  }

  /**
   * New physics material: the defaults (`{}`) written as `new-physics-material.physmat` in `dir` (`-2`… when taken) --
   * one step, Z trashing it -- chosen, its name in the rename field (Docs/physics.md §7).
   */
  async function newPhysmatIn(dir: string): Promise<void> {
    const stem = freeKey(NEW_PHYSMAT, (s) => takenIn(dir, `${s}${PHYSMAT_SUFFIX}`));
    const path = joinPath(dir, `${stem}${PHYSMAT_SUFFIX}`);
    const ok = await runEdit(materialWriteEdit(api, path, physmatText(PHYSICS_MATERIAL_DEFAULTS), `New physics material ${stem}`, () => undefined, true));
    if (!ok) return;
    say(`New physics material ${physmatKeyOf(path) ?? stem}: friction 0.5, no bounce -- name it here; a collider wears it by its material field · Z undoes`);
    openFolder(dir, path);
    rename('files');
  }

  /** New prefab: an empty prefab file in `dir` -- one entity, a Transform, a name from the folder -- one step, chosen once made. */
  async function newPrefabIn(dir: string): Promise<void> {
    const name = nameFromFolder(dir);
    const file = freeName(name, (n) => takenIn(dir, n));
    const path = joinPath(dir, file);
    const ok = await runEdit(writePrefabsEdit(api, `New prefab ${stemOf(file)}`, [{ path, text: prefabText(newPrefab(name)), create: true }]));
    if (ok) {
      say(`New prefab ${prefabKeyOf(path)}: in Spawn as soon as it compiles · Z undoes`);
      openFolder(dir, path);
    }
  }

  // ---------------------------------------------------------------- the Model tab's files (Docs/modeler.md M38, M39)

  /** A folder a model's script may go in: a models folder, either side, a pack's too -- not the trash, not reference/. */
  const inModels = (path: string): boolean => {
    const where = locate(joinPath(path, 'x'));
    return where?.kind === 'models' && !where.reference && !under(path, TRASH);
  };

  const modelHost: ModelStepHost = { api, jobs: (fn) => live.on('job', fn), entries: () => index.entries };

  /**
   * New model (M38; Vibe3D D34): its name asked first -- as typed, the case-key rules, the server's own check (`GET
   * names`, as the import asks) said in the dialog with a free name -- then one step: the script written, its export
   * queued, the Model tab brought up on it. Z takes the script, its record and its export to the trash.
   */
  /**
   * Every folder under `at`'s kind's own (AssetsSource/models for a models folder) that takes an import -- the import
   * sheet's Into list, New model's In list. None outside a kind's folders.
   */
  function kindFolders(at: string): string[] {
    const probe = joinPath(at, 'x');
    const where = locate(probe);
    if (!where?.kind || where.under === undefined || where.reference) return [];
    const top = probe.slice(0, probe.length - where.under.length - 1);
    if (!hasFolder(top)) return [];
    const out: string[] = [];
    const walk = (dir: string): void => {
      if (importRefused(dir, naming) === null) out.push(dir);
      for (const sub of index.childrenOf(dir).folders) walk(sub);
    };
    walk(top);
    return out;
  }

  /**
   * Where the Model tab's New model and Import model… go -- one rule for both: the models folder this panel shows,
   * else the one asked (the open model's), else the models folder open or `AssetsSource/models`.
   */
  const modelTarget = (dir: string | undefined): string => (inModels(folder) ? folder : (dir ?? modelsHome()));

  function newModelIn(dir: string): void {
    if (!writes()) return say('This page may not write: New model is the dev server\'s, on this machine', true);
    const sourceOf = (d: string): string => (locate(joinPath(d, 'x'))?.root === 'source' ? d : (twin(d) ?? d));
    const first = sourceOf(dir);
    const shipOf = (d: string): string => twin(d) ?? d;
    const free = freeKey('model', (s) => takenIn(first, `${s}.lua`) || takenIn(shipOf(first), `${s}.glb`));
    // The folder shown, and changeable: every Source models folder a script may go in.
    const folders = [...new Set([first, ...kindFolders(first)])].sort();
    showDialog({
      title: 'New model',
      text: `A Gladius script${folders.length > 1 ? '' : ` in ${naming.say(first)}`}, empty and documented -- the units, params{}, emit -- built once and opened in the Model tab. Draw over a view and ask Claude, or write it. Z undoes it.`,
      field: { value: free, label: 'Name' },
      ...(folders.length > 1 ? { choice: { value: first, label: 'In', title: 'The folder the script is written in: its export goes in the twin under src/assets', options: folders.map((f) => ({ value: f, text: naming.crumbs(f).filter((c) => c.path !== PROJECT).map((c) => c.text).join(' › ') })) } } : {}),
      buttons: [
        {
          label: 'Make it',
          kind: 'accent',
          takesName: true,
          title: 'The script written and built, the Model tab brought up on it (Enter)',
          run: async (typed, chosen, up) => {
            const source = chosen ?? first;
            const ship = shipOf(source);
            const name = typed.replace(/\.lua$/i, '');
            if (/\.source$/i.test(name)) return refuse(`${name}: a name ending in .source is an import's copy`);
            try {
              const [answer] = await api.names(source, [`${name}.lua`], { source: true });
              // A refusal with no name to offer (another case of a name there): the first free one, as a taken name has.
              if (answer && 'refused' in answer) return refuse(answer.refused, answer.suggested ?? `${freeKey(name, (x) => takenIn(source, `${x}.lua`) || takenIn(ship, `${x}.glb`))}.lua`);
            } catch (err) {
              return refuse(reasonOf(err));
            }
            // Esc or Cancel while the name was checked: no model made after all.
            if (up && !up()) return true;
            void runEdit(newModelEdit(modelHost, source, name, (made) => {
              say(`New model ${name}: ${baseName(made.path)} written, building -- open in the Model tab · Z undoes`);
              openModel(made.path, true);
            }));
            return true;
          },
        },
      ],
    });
  }

  /** A refusal said in the dialog, kept up to try again: false. */
  function refuse(why: string, suggested?: string): false {
    dialogNote(suggested !== undefined ? `${why} -- ${splitName(suggested).stem} is free` : why);
    return false;
  }

  /** Where New model and Import model… go when no folder is said: the models folder open here, else AssetsSource/models. */
  const modelsHome = (): string => (inModels(folder) ? folder : `${ROOTS.source.dir}/${KINDS.models.dir}`);

  /** A `.glb` delivered as it is under models, no source of its key, this page writing: Make a script is offered (M39). */
  function adoptable(path: string): boolean {
    const e = index.entries.get(path);
    return writes() && e?.role === 'loose' && e.kind === 'models' && extOf(path) === 'glb' && !baseName(path).startsWith('_') && twin(dirName(path)) !== undefined;
  }

  /** Make a script for a `.glb` (Vibe3D D49): one step, its export waited for; opened in the Model tab once built. */
  async function adoptModel(path: string): Promise<void> {
    const ok = await runEdit(adoptEdit(modelHost, path, ({ answer, job }) => {
      const decoded = answer.decoded && answer.decoded.length > 0 ? ` (${answer.decoded.join(', ')} decoded)` : '';
      const built = job?.state === 'done' ? `, built over ${baseName(path)}` : job?.state === 'failed' ? `; its build failed: ${job.error ?? ''}` : '';
      say(`${baseName(answer.path)} imports ${baseName(answer.copy ?? '')}${decoded}${built} · Z undoes`, job?.state === 'failed');
    }), `Making a script for ${baseName(path)} …`);
    if (!ok) return;
    const script = joinPath(twin(dirName(path))!, `${splitName(baseName(path)).stem}.lua`);
    openModel(script, true);
  }

  /** A folder scenes live in: `src/assets/scenes` and under it. */
  const inScenes = (path: string): boolean => path === SCENES_DIR || under(path, SCENES_DIR);

  /**
   * New scene: a world empty but for its Main Camera, its save written as `new-scene.scene` in `dir` (`-2`… when taken) through `PUT prefab`, as
   * the Scenes page writes one -- one step, Z trashing it. Not opened, the world untouched: chosen, its name in the
   * rename field, so it is named where it is; a double-click opens it.
   */
  async function newSceneIn(dir: string): Promise<void> {
    const stem = freeKey(NEW_SCENE, (s) => takenIn(dir, `${s}${SCENE_SUFFIX}`));
    const path = joinPath(dir, `${stem}${SCENE_SUFFIX}`);
    const ok = await runEdit(writePrefabsEdit(api, `New scene ${stem}`, [{ path, text: sceneText(newSceneSave(), false), create: true }]));
    if (!ok) return;
    say(`New scene ${sceneKeyOf(path) ?? stem}: empty but for its Main Camera -- name it here; a double-click opens it · Z undoes`);
    openFolder(dir, path);
    rename('files');
  }

  /** Make variant: a new prefab beside `key` whose root is an instance of it, no overrides -- one step. */
  async function makeVariant(key: string): Promise<void> {
    const dir = dirName(prefabPathOf(key));
    const file = freeName(`${stemOf(baseName(prefabPathOf(key)))}-variant`, (n) => takenIn(dir, n));
    const path = joinPath(dir, file);
    const ok = await runEdit(writePrefabsEdit(api, `Make variant of ${key}`, [{ path, text: prefabText(variantOf(key)), create: true }]));
    if (ok) {
      say(`${prefabKeyOf(path)}: a variant of ${key} · Z undoes`);
      openFolder(dir, path);
    }
  }

  /** A prefab's pool, from the inspector: written into its file's text where it is -- one step. */
  async function setPool(key: string, size: { warm: number; max: number } | null): Promise<void> {
    const path = prefabPathOf(key);
    try {
      const text = await (await api.file(path)).text();
      const next = withPool(text, size);
      if (next === text) return;
      const label = size ? `Pool of ${key}: warm ${size.warm}, max ${size.max}` : `No pool for ${key}`;
      if (await runEdit(writePrefabsEdit(api, label, [{ path, text: next }]))) say(`${label} · Z undoes`);
    } catch (err) {
      say(`The pool of ${key} not written: ${reasonOf(err)}`, true);
    }
  }

  // ---------------------------------------------------------------- a prefab's root, edited in the inspector (prefab-root-block.ts)

  /** The root being edited, by key: kept while the compile it was made from stands (its text), so a redraw keeps its edits. */
  let rootEdit: { key: string; made: string; edit: RootEdit } | null = null;
  /** The last edit of a root refused, said in its block until the next is made. */
  let rootRefused: { key: string; line: string; overwrite: (() => void) | null } | null = null;
  /** The compile's checks, the models known: what the opened mode's Save and an Apply ask (editor.ts). */
  const checkFile = (key: string, all: Record<string, PrefabFile>): string | null => checkPrefab(key, all, Assets.prefabChecks);
  /** Why `key`'s root cannot be edited now, or null. */
  const rootWhy = (key: string): string | null => rootRefusal({ key, writes: writes(), problem: livePrefabs.problemOf(key), open: ctx.prefabsOpen, held: ctx.overrides.holding() });
  /** The root's edit thrown away -- refused, or the compile moved on: the next draw makes it again from the compile. */
  function dropRoot(key: string): void {
    if (rootEdit?.key === key) rootEdit = null;
    inspector.refresh();
  }
  // ---------------------------------------------------------------- a material file, edited in the inspector (material-block.ts)

  /** Each material's last write by the block: what the block reads until the page's file says the same. */
  const drafts = materialDrafts(materialFile);
  const materialHost: MaterialBlockHost = {
    read: (key) => drafts.read(key),
    unparsed: (key) => liveMaterials.problemOf(key),
    problems: (key) => materialProblems(key),
    writes,
    write(key, file, label) {
      const text = materialText(materialDiff(file));
      const edit = materialWriteEdit(api, materialPathOf(key), text, label, (now) => {
        drafts.written(key, now);
        if (visible) inspector.refresh();
      });
      void runEdit(edit).then((ok) => ok && say(`${label} · Z undoes`));
    },
    live: (key, file) => showMaterial(key, materialDiff(file)),
    textures: () => Assets.keysOf('Texture'),
    thumb: (texture) => keyThumb('textures', texture),
    wearers: (key) => wearersOf(key, prefabFiles()),
    reveal,
    prefabPath: prefabPathOf,
    // A texture dropped on a map: this tool's step, so the keys -- and Z -- its.
    focus: () => ctx.focus(),
  };

  /** Each physics material's last write by its block: what the block reads until the page's file says the same. */
  const physmatDrafts = new Map<string, PhysicsMaterialFile>();
  const physmatHost: PhysmatBlockHost = {
    writes,
    draft(key) {
      const draft = physmatDrafts.get(key);
      if (draft === undefined) return null;
      const file = parsePhysicsMaterial(dataIfPresent('physicsmaterials', key) ?? {});
      if (typeof file !== 'string' && physmatText(file) === physmatText(draft)) {
        physmatDrafts.delete(key);
        return null;
      }
      return draft;
    },
    write(path, file, label) {
      void runEdit(physmatEdit(api, path, file, label)).then((ok) => ok && say(`${label} · Z undoes`));
    },
  };

  /**
   * The Physics material block's writer, and `physmat_set`'s: `file` as the file's whole text, one step of this panel
   * (Z writes the text before back), its draft kept for the block until the page's data says the same.
   */
  function physmatEdit(via: PrefabsApi, path: string, file: PhysicsMaterialFile, label: string): Edit {
    const key = physmatKeyOf(path) ?? path;
    return materialWriteEdit(via, path, physmatText(file), label, (now) => {
      const read = now === null ? null : parsePhysicsMaterial(JSON.parse(now));
      if (read === null || typeof read === 'string') physmatDrafts.delete(key);
      else physmatDrafts.set(key, read);
      if (visible) inspector.refresh();
    });
  }

  const rootHost: RootBlockHost = {
    edit(key) {
      // The file the compile was made from: what the instance is, and the layout a write keeps.
      const made = livePrefabs.compiled?.get(key) ?? JSON.stringify(prefabFiles()[key] ?? null);
      if (rootEdit?.key === key && rootEdit.made === made) return rootEdit.edit;
      const file = JSON.parse(made) as PrefabFile | null;
      const edit = file ? createRootEdit(key, file, prefabFiles()) : null;
      rootEdit = edit ? { key, made, edit } : null;
      if (rootRefused?.key !== key) rootRefused = null;
      return edit;
    },
    refusal: rootWhy,
    commit: (key, edit, label) => void commitRoot(key, edit, label),
    refused: (key) => (rootRefused?.key === key ? rootRefused : null),
    menu: (at, items, title) => menu.show(at, items, { title }),
    tags: tagsState(root),
    labels: labelsState(root),
    adder: adderState(root),
    focus: () => ctx.focus(),
  };

  /**
   * An edit of `key`'s root: refused and said -- the block drawn again from the compile -- or the file it makes written,
   * one step of this tool's history (Z writes the text back). A file changed on disk since it was read is refused once:
   * the block offers to write over it, and its edit stays.
   */
  async function commitRoot(key: string, edit: RootEdit, label: string): Promise<void> {
    const named = `${key} root: ${label}`;
    const refuse = (line: string, overwrite = false): void => {
      rootRefused = { key, line, overwrite: overwrite ? () => void commitRoot(key, edit, label) : null };
      say(`Not written -- ${line}`, true);
      if (overwrite) inspector.refresh();
      else dropRoot(key);
    };
    const why = rootWhy(key);
    if (why) return refuse(why);
    let planned: ReturnType<RootEdit['plan']>;
    try {
      planned = edit.plan(prefabFiles(), checkFile);
    } catch (err) {
      const line = reasonOf(err);
      return refuse(line, /changed on disk since it was read/.test(line));
    }
    rootRefused = null;
    if (!planned) {
      inspector.refresh();
      return say(`${named}: the file says that already`);
    }
    const path = prefabPathOf(key);
    if (await runEdit(writePrefabsEdit(api, named, [{ path, text: planned.text }]))) {
      edit.wrote(planned.file, planned.text, prefabFiles());
      say(`${named} · Z undoes`);
    } else dropRoot(key);
  }

  /** The field put away, however it ended: the name it hid back, the lines taken away. */
  function endRename(): void {
    const was = renaming;
    if (!was) return;
    renaming = null;
    // Done first, so a blur as it leaves the page commits nothing.
    was.field.cancel();
    if (was.where === 'files') files.endEdit();
    else if (was.where === 'folders') folders.endEdit();
    else if (was.where === 'head') inspector.endEdit();
    else files.newFolder(null);
    files.note(null);
    inspector.note(null);
    held = null;
    nudge();
  }

  /**
   * Shift+N, the menus' New folder (§8): a folder in the open one, named in
   * place at the top of the files card, `validName` as it is typed; Enter asks
   * `GET names?…&folder=1`, then `POST mkdir`. Under Packs, a pack: its
   * sources' folder under `AssetsSource/packs/` with it.
   */
  function newFolder(): void {
    if (!writes()) return;
    const parent = folder;
    const takes = folderTakes(parent, naming.title(parent));
    if (!takes.newFolder) return say(under(parent, TRASH) ? 'The trash takes no new folder' : `${naming.title(parent)} takes no new folder`, true);
    const pack = takes.newFolder === 'pack' || parent === ROOTS.packs.source;
    endRename();
    // The field is at the top of the folder's own list: no search, no Issues over it.
    files.showAll();
    const taken = new Set(index.childrenOf(parent).folders.map((f) => baseName(f)));
    const first = pack ? 'new-pack' : 'new-folder';
    let name = first;
    for (let n = 2; taken.has(name); n++) name = `${first}-${n}`;
    const where = (typed: string): string => (pack ? `a pack: packs/${typed}/, with AssetsSource/packs/${typed}/ for its sources` : `a new folder in ${naming.say(parent)}`);
    const field = renameField({
      name,
      folder: true,
      fresh: true,
      placeholder: 'folder-name',
      typed(typed, refused) {
        const text = refused ? `${refused.refused}${refused.suggested ? ` -- ${refused.suggested} would do` : ''}` : `${where(typed)} · Enter makes it`;
        files.note(text, refused !== null);
        held = text;
        nudge();
      },
      commit: (typed) => commitNewFolder(parent, typed, pack),
      done: () => endRename(),
    });
    files.newFolder(field.form);
    renaming = { field, path: joinPath(parent, name), folder: true, where: 'new', typed: name };
    files.note(`${where(name)} · Enter makes it, Esc leaves it`);
    held = `New folder: ${where(name)}`;
    nudge();
  }

  async function commitNewFolder(parent: string, name: string, pack: boolean): Promise<Refused | null> {
    const dirs = pack ? [joinPath(ROOTS.packs.dir, name), joinPath(ROOTS.packs.source, name)] : [joinPath(parent, name)];
    try {
      const [answer] = await api.names(pack ? ROOTS.packs.dir : parent, [name], { folder: true });
      // Taken in the twin alone -- `src/assets/models/characters` for a new `AssetsSource/models/characters` -- is the twin
      // it will have, not a clash: `POST mkdir` refuses one there already, in its words.
      const twinOnly = answer !== undefined && 'refused' in answer && answer.exists === true && !hasFolder(dirs[0]!);
      if (answer && 'refused' in answer && !twinOnly) {
        say(`No folder made: ${answer.refused}`, true);
        return { refused: answer.refused, ...(answer.suggested !== undefined ? { suggested: answer.suggested } : {}) };
      }
    } catch (err) {
      say(`No folder made: ${reasonOf(err)}`, true);
      return { refused: reasonOf(err) };
    }
    // The twin the pipeline makes as it exports into the new folder: taken away with it, where empty by then.
    const twins = dirs.length === 1 ? [twin(dirs[0]!)].filter((d): d is string => d !== undefined && !hasFolder(d)) : [];
    void runEdit(newFolderEdit(api, editHost, dirs, `New ${pack ? 'pack' : 'folder'} ${name}`, twins)).then((ok) => {
      if (!ok) return;
      say(`New ${pack ? 'pack' : 'folder'} ${name} · Z undoes`);
      if (folder === parent) select(chosen([joinPath(parent, name)]));
    });
    return null;
  }

  /**
   * A file or a folder moved -- a rename, its undo, a drag: what is chosen and
   * the open folder follow it, its twin's too, and a folder kept empty goes
   * with it. Told as the move's answer comes, before the next frame prunes
   * what is gone.
   */
  function follow(from: string, to: string): void {
    const pairs: Array<[string, string]> = [[from, to]];
    const a = twin(from);
    const b = twin(to);
    if (a !== undefined && b !== undefined) pairs.push([a, b]);
    const map = (p: string): string => {
      for (const [x, y] of pairs) if (p === x || p.startsWith(`${x}/`)) return y + p.slice(x.length);
      return p;
    };
    if (selection.paths.some((p) => map(p) !== p)) selection = chosen(selection.paths.map(map), selection.latest !== null ? map(selection.latest) : null);
    // The locked inspector's files go with them too.
    if (pinned?.kind === 'many') pinned = { kind: 'many', paths: pinned.paths.map(map), at: map(pinned.at) };
    else if (pinned !== null && pinned.kind !== 'gone') pinned = { kind: pinned.kind, path: map(pinned.path) };
    const there = map(folder);
    if (there !== folder) {
      folder = there;
      keep({ folder });
    }
    const open = prefs.open.map(map);
    if (open.some((p, i) => p !== prefs.open[i])) keep({ open });
    // A folder's move: one kept empty (New folder) goes with it.
    if (extOf(to) === '') {
      index.forgetFolder(from);
      if (!hasFolder(to)) index.keepFolder(to);
    }
    soon();
  }

  // ---------------------------------------------------------------- import

  /** The read-mode banner's sentence, or bundle view's: what a write refused there says (§7). */
  function readOnlyLine(): string {
    return online === false
      ? 'What the build bundled: start npm run dev to change it'
      : `Read-only: only the machine running the dev server can change the project -- if this is that machine, open ${writableUrl()} instead`;
  }

  /** Files for a folder -- dropped, picked, pasted: the sheet, or the one open, which they join for its folder (§5). */
  function importInto(to: string, drop: ReadDrop, scripts = false): void {
    if (!writes()) return say(readOnlyLine(), true);
    const target = sheet.open ? sheet.folder! : to;
    const no = importRefused(target, naming);
    if (no) return say(no, true);
    // What comes in is to be seen, needing a hand or not.
    files.showAll();
    sheet.add(target, drop, scripts);
  }

  /** A picker opened from the click or the key that asked -- a user activation, so the browser allows it. */
  function pick(input: HTMLInputElement): void {
    if (!writes()) return say(readOnlyLine(), true);
    const no = importRefused(sheet.open ? sheet.folder! : (pickInto ?? folder), naming);
    if (no) return say(no, true);
    input.click();
  }

  /** Import ▾'s Paste image: `navigator.clipboard.read()`, which the browser may ask to allow first. */
  async function pasteImage(): Promise<void> {
    if (!writes()) return say(readOnlyLine(), true);
    say(`Reading the clipboard… the browser may ask to allow it first (${keyLabel('Mod+KeyV')}, a paste, never asks)`);
    try {
      const items = await navigator.clipboard.read();
      const at = new Date();
      const found: Array<{ rel: string; file: File }> = [];
      for (const item of items) {
        const type = item.types.find((t) => t.startsWith('image/'));
        if (!type) continue;
        const blob = await item.getType(type);
        const name = pastedName({ name: '', type }, at);
        found.push({ rel: name, file: new File([blob], name, { type }) });
      }
      if (found.length === 0) return say('No image on the clipboard', true);
      importInto(folder, { files: found, skipped: [] });
    } catch (err) {
      say(`The clipboard could not be read: ${reasonOf(err)}`, true);
    }
  }

  /** The page's paste, while the tab is up and not into a field (§5, "Paste is the browser's"): an image, or files the browser gives. */
  const onPaste = (event: ClipboardEvent): void => {
    if (!visible || isTyping(event.target)) return;
    const at = new Date();
    const found = Array.from(event.clipboardData?.items ?? [])
      .filter((item) => item.kind === 'file')
      .map((item) => item.getAsFile())
      .filter((f): f is File => f !== null)
      .map((f) => {
        const name = pastedName(f, at);
        return { rel: name, file: name === f.name ? f : new File([f], name, { type: f.type, lastModified: f.lastModified }) };
      });
    if (found.length === 0) return;
    event.preventDefault();
    importInto(folder, { files: found, skipped: [] });
  };

  /**
   * Where a drop lands (§3, §5): a folder's row or tile, the panel's open
   * folder -- its files, its title row -- the inspector's folder while it shows
   * a file; the sheet's while it is open. Not the tree, nor the scene: the
   * Scene tool's, which place a prefab dropped there.
   */
  function targetAt(node: Element | null): { folder: string; el: HTMLElement } | null {
    if (!node || !visible) return null;
    const inFolders = folders.card.contains(node);
    const inFiles = !inFolders && panel.contains(node);
    const inInspector = inspecting && inspector.panel.contains(node);
    if (!inFolders && !inFiles && !inInspector) return null;
    if (sheet.open) return { folder: sheet.folder!, el: sheet.root };
    if (inFolders) {
      // A folder's row, or a tab: its root.
      const row = node.closest<HTMLElement>('.ed-as-folder, .ed-as-tab');
      return row?.dataset.path !== undefined ? { folder: row.dataset.path, el: row } : null;
    }
    if (inFiles) {
      const item = node.closest<HTMLElement>('.ed-as-tile, .ed-as-row');
      const path = item?.dataset.path;
      if (item && path !== undefined && isFolderPath(index, path)) return { folder: path, el: item };
      return { folder, el: files.body };
    }
    const what = showing();
    // Locked on what was removed: no folder to drop into there.
    if (what.kind === 'gone') return null;
    const at = what.kind === 'folder' ? what.path : folderOf(what.kind === 'file' ? what.path : what.paths[0]!);
    return { folder: at, el: inspector.panel };
  }

  /** Sort by…: a second menu where the first was. */
  function sortMenu(at: { x: number; y: number }, byKey: boolean): void {
    const now = prefs.sort;
    const names: Record<AssetsPrefs['sort']['by'], string> = { name: 'Name', status: 'Status (what needs a hand first)', size: 'Size', modified: 'Modified', kind: 'Kind' };
    const items: MenuItem[] = (Object.keys(names) as AssetsPrefs['sort']['by'][]).map((by) => ({
      mcp: 'ui',
      label: `${now.by === by ? '✓ ' : ''}${names[by]}${now.by === by ? (now.down ? ' ↓' : ' ↑') : ''}`,
      title: now.by === by ? 'Again: the other way' : `Sort by ${names[by].toLowerCase()}, folders first`,
      run: () => {
        keep({ sort: { by, down: now.by === by ? !now.down : false } });
        files.refresh();
      },
    }));
    showMenu(at, [], items, 'Sort by', byKey);
  }

  // ---------------------------------------------------------------- the focus, the keys

  function setFocus(card: Card): void {
    // The preview is the right panel's: given the keys, it shows the file (the entity inspector, if it was up, goes).
    if (card === 'preview') ctx.inspect();
    if (focus === card) return;
    focus = card;
    lightFocus();
    nudge();
  }

  /** The focused card's title row lit -- only while the panel's side has the Scene tab's keys: else none of its cards has them. */
  function lightFocus(): void {
    const lit = ctx.focused;
    folders.head.classList.toggle('ed-as-focus', lit && focus === 'folders');
    files.head.classList.toggle('ed-as-focus', lit && focus === 'files');
    inspector.head.classList.toggle('ed-as-focus', lit && focus === 'preview');
  }

  /** A side card folded away: if it had the focus, the next card seen has it, so the keys never walk a card out of sight. */
  function foldedAway(card: Card, away: boolean): void {
    if (away && focus === card) cycle(1);
  }

  /** The tool's cards in the Scene tab: the panel, and the right panel while it shows a file. A press in one gives the panel's side the keys. */
  const cards = (): HTMLElement[] => [panel, inspector.panel];
  const cardOf = (node: Node | null): Card | null =>
    node === null ? null : folders.card.contains(node) ? 'folders' : panel.contains(node) ? 'files' : inspector.panel.contains(node) ? 'preview' : null;

  /**
   * A press or a focus in a card gives it the focus: heard capturing, as a
   * menu hears a press outside it -- but a press on a button that keeps the
   * focus where it is (the inspector's Use crate-2, a rename field's) leaves
   * the keys with the card that has them.
   */
  const pressed = (event: Event): void => {
    if ((event.target as Element | null)?.closest?.('[data-keeps-focus]')) return;
    const card = cardOf(event.target as Node | null);
    if (card) setFocus(card);
  };
  /** The tool's controls let go of the focus once a pointer has used them: a button after its click, a tick or a list after its change. */
  let pointered: Element | null = null;
  const down = (event: PointerEvent): void => {
    pointered = event.target as Element;
  };
  const clicked = (event: MouseEvent): void => {
    const b = (event.target as Element | null)?.closest?.('button');
    if (b && event.detail > 0 && cardOf(b) !== null) queueMicrotask(() => document.activeElement === b && b.blur());
  };
  const changed = (event: Event): void => {
    const target = event.target as HTMLElement;
    const control = target instanceof HTMLSelectElement || (target instanceof HTMLInputElement && (target.type === 'checkbox' || target.type === 'radio' || target.type === 'range'));
    if (control && pointered && (pointered === target || target.contains(pointered) || (target as HTMLInputElement).labels?.[0]?.contains(pointered))) target.blur();
  };
  /** The browser's menu, from the menu key on Windows, never over the tool's own. */
  const contextmenu = (event: MouseEvent): void => {
    if (!menu.open) return;
    event.preventDefault();
    event.stopPropagation();
  };

  /**
   * A button, a tick or a list of the editor's has the focus: Enter and Space
   * are the browser's on it, so the card keys stand still. Only one reached by
   * keyboard keeps it: every button a pointer used lets it go -- the tool's
   * (above) and the host's (`letGo`: the tab's own button, the bar's Keys,
   * Save) -- since Chrome makes a pointer-focused button `:focus-visible` at
   * the first key pressed, which is no test of how it was reached.
   */
  const controlFocused = (): boolean => {
    const at = document.activeElement;
    const control = at instanceof HTMLButtonElement || at instanceof HTMLInputElement || at instanceof HTMLSelectElement;
    return control && root.contains(at);
  };
  /** The import sheet over the files card: the card keys are its fields' and its buttons'. */
  const sheetOpen = (): boolean => sheet.open;
  const free = (): boolean => !menu.open && !sheetOpen() && !controlFocused();
  /** The preview showing something that plays or frames: Space and F are live. */
  const previewPlays = (): boolean => preview.plays;
  const scoped: Record<Scope, () => boolean> = {
    free,
    folders: () => free() && focus === 'folders',
    files: () => free() && focus === 'files',
    grid: () => free() && focus === 'files' && prefs.view === 'grid',
    preview: () => free() && previewPlays(),
    // ← → through several chosen, with the preview focused: Files' and Folders' arrows are theirs.
    several: () => free() && focus === 'preview' && selection.paths.length > 1,
    // The menu's arrows walk the folder picker too, a drop-down of the same kind.
    menu: () => menu.open || picker !== null,
    cards: () => !menu.open && !sheetOpen(),
    mod: () => !menu.open,
    search: () => !menu.open && !sheetOpen(),
    // Enter on the sheet with no control of it focused -- a click let go of one -- is Import; in a name field it is the form's own.
    sheet: () => sheetOpen() && !menu.open && !controlFocused(),
  };
  const nothingSelected = (): boolean => document.getSelection()?.isCollapsed ?? true;
  const when = (row: { scope?: Scope; writes?: boolean; copy?: boolean }) => (): boolean =>
    scoped[row.scope ?? 'free']() && (!row.copy || nothingSelected()) && (!row.writes || online === 'write');

  /** F6, Alt+→: the next card -- past an empty preview, or a card folded away -- letting go of any control of the editor's, a host button reached by Tab too. */
  function cycle(by: 1 | -1): void {
    const at = document.activeElement;
    if (at instanceof HTMLElement && root.contains(at)) at.blur();
    let i = CARDS.indexOf(focus);
    for (let n = 0; n < CARDS.length; n++) {
      i = (i + by + CARDS.length) % CARDS.length;
      const card = CARDS[i]!;
      // The preview only while the right panel is this tool's: an entity chosen since, it is the entity inspector.
      if (card === 'preview' && (selection.paths.length === 0 || inspector.side.folded || !inspecting)) continue;
      if (card === 'folders' && folders.side.folded) continue;
      setFocus(card);
      return;
    }
  }

  /** Files' arrows: `by` on -- a row of tiles at a time -- `extend` the range from the primary. */
  function walk(by: number, extend: boolean): void {
    select(stepOn(selection, by, files.shown(), extend));
  }

  function page(by: 1 | -1): void {
    if (focus === 'folders') return folders.walk(by * folders.page);
    walk(by * files.page * files.perRow, false);
  }

  function last(): void {
    if (focus === 'folders') return folders.last();
    const shown = files.shown();
    if (shown.length > 0) select(chosen([shown[shown.length - 1]!]));
  }

  /** Enter: a folder in Folders, the focus to the files; in the files, a folder opened, a file to the preview. */
  function enter(): void {
    if (focus === 'folders') return setFocus('files');
    if (focus !== 'files') return;
    const at = selection.latest ?? selection.primary;
    if (at === null) return say('Nothing chosen: the arrows choose a file, Enter shows it');
    if (isFolderPath(index, at)) return openFolder(at);
    setFocus('preview');
  }

  /** ] and [ in Folders: the next tab, or the one before, round -- as its press does. */
  function stepTab(by: 1 | -1): void {
    const tabs = tabRoots();
    if (tabs.length === 0) return;
    const at = tabs.indexOf(tabNow());
    const next = tabs[(Math.max(0, at) + by + tabs.length) % tabs.length]!;
    const last = lastIn.get(next);
    openFolder(last !== undefined && hasFolder(last) ? last : next);
  }

  /** Mod+↑: the folder the open one is in -- from a root, its tab's top, nowhere. */
  function folderUp(): void {
    const up = naming.parent(folder);
    if (up === null) return say(`${naming.title(folder)} is the top of its tab: there is no folder up from it`);
    openFolder(up, folder);
  }

  function selectAll(): void {
    select(choosePaths(selection, files.shown().filter((p) => !isFolderPath(index, p)), 'replace'));
  }

  /** The menu key: the focused card's menu, at its chosen element's lower left, its first item focused. */
  function menuKey(): void {
    const below = (node: Element | undefined | null): { x: number; y: number } | null => {
      if (!node) return null;
      const r = node.getBoundingClientRect();
      return { x: r.left + 8, y: r.bottom };
    };
    if (focus === 'folders') {
      const at = below(folders.row()) ?? below(folders.head)!;
      return folderMenu(folder, at, true, true);
    }
    if (focus === 'preview') {
      const one = selection.primary;
      const at = below(inspector.head)!;
      if (one === null) return folderMenu(folder, at, true, true);
      return filesMenu({ kind: 'row', path: one }, at, true);
    }
    const latest = selection.latest ?? selection.primary;
    if (latest === null) return filesMenu({ kind: 'space' }, below(files.head)!, true);
    files.reveal(latest);
    return filesMenu({ kind: 'row', path: latest }, below(files.element(latest)) ?? below(files.head)!, true);
  }

  function copyKey(): void {
    const one = focus === 'folders' ? undefined : selection.primary;
    const row = one === null || one === undefined ? undefined : shownAt(index, one);
    const key = row ? keyOfRow(row, index.entries) : undefined;
    if (key === undefined) return say(row ? `${baseName(row.path)} has no key: ${keyLabel('Mod+Shift+KeyC')} copies its path` : `Nothing chosen has a key: ${keyLabel('Mod+Shift+KeyC')} copies a path`, true);
    copy(key, 'the key');
  }

  function copyPath(): void {
    const path = focus === 'folders' ? folder : selection.primary ?? folder;
    if (path === PROJECT) return say('The project has no path of its own: it is the repository\'s root -- choose a root, a folder or a file', true);
    copy(path, 'the path');
  }

  const runs: Record<AssetsKeyName, () => void> = {
    'files menu item above': () => (menu.open ? menu.step(-1) : stepPicker(-1)),
    'files menu item below': () => (menu.open ? menu.step(1) : stepPicker(1)),
    'folders up': () => folders.walk(-1),
    'folders down': () => folders.walk(1),
    'folders fold': () => folders.fold(false),
    'folders unfold': () => folders.fold(true),
    'folders next tab': () => stepTab(1),
    'folders previous tab': () => stepTab(-1),
    'files up': () => walk(-files.perRow, false),
    'files down': () => walk(files.perRow, false),
    'files tile before': () => walk(-1, false),
    'files tile after': () => walk(1, false),
    'files extend up': () => walk(-files.perRow, true),
    'files extend down': () => walk(files.perRow, true),
    'files extend before': () => walk(-1, true),
    'files extend after': () => walk(1, true),
    'assets page up': () => page(-1),
    'assets page down': () => page(1),
    'assets last': last,
    'assets open': enter,
    'assets import': () => sheet.submit(),
    'assets next card': () => cycle(1),
    'assets previous card': () => cycle(-1),
    'assets menu': menuKey,
    // The preview's: live while it shows something that plays or frames (`previewPlays`).
    'assets play': () => preview.play(),
    'assets frame': () => preview.frame(),
    'assets preview before': () => stepPreview(-1),
    'assets preview after': () => stepPreview(1),
    'assets grid or list': () => files.setView(prefs.view === 'grid' ? 'list' : 'grid'),
    'assets smaller thumbs': () => files.resize(-1),
    'assets larger thumbs': () => files.resize(1),
    'assets export': () => exportKey(false),
    'assets export again': () => exportKey(true),
    'assets folder up': folderUp,
    'assets select all': selectAll,
    'assets select none': () => select(NO_PATHS),
    'assets copy key': copyKey,
    'assets copy path': copyPath,
    'assets search': () => files.focusSearch(),
    'assets rename': () => rename(),
    'assets trash': trash,
    'assets trash (backspace)': trash,
    'assets duplicate': () => duplicate(),
    // From the key itself: a MrDebug run is inside the keydown, a user activation, so the picker may open.
    'assets import files': () => pick(filesInput),
    'assets new folder': newFolder,
    'assets fold': () => setFolded(!prefs.folded),
    'assets issues': () => files.setIssues(!prefs.issues),
    'assets build': () => toggleBuild(),
  };
  const offs: (() => void)[] = [];
  // A prefab compiled again, or a file of one found broken: what the inspector says of it read again.
  offs.push(livePrefabs.onChange(() => {
    if (visible) inspector.refresh();
  }));
  // A material file changed, or found broken: the Material block and the preview drawn again -- and a write
  // the block made, once the file the page holds says the same, no longer stands in for it.
  offs.push(onMaterialFiles((change) => {
    drafts.heard([...change.changed, ...change.added, ...change.removed]);
    if (visible) inspector.refresh();
  }));
  offs.push(liveMaterials.onChange(() => {
    if (visible) inspector.refresh();
  }));
  for (const row of ASSETS_KEYS) offs.push(ctx.keys.add({ name: row.name, key: row.key, help: row.help, mcp: row.mcp, ...('anySide' in row && row.anySide ? { anySide: true } : {}), when: when(row), run: runs[row.name] }));
  // A game's (§12), after the tool's own: told where the tool is as it runs.
  const at = (): AssetsKeyAt => ({ folder, paths: selection.paths, card: focus, say });
  for (const key of options.keys ?? []) {
    offs.push(ctx.keys.add({ name: key.name, ...(key.key !== undefined ? { key: key.key } : {}), help: key.help, mcp: key.mcp, when: when(key), run: () => key.run(at()) }));
  }

  // ---------------------------------------------------------------- the index, the jobs, the tools

  let frame = 0;
  /** The cards drawn again from the index, the next frame -- what a change took away let go of first. */
  function soon(): void {
    if (frame !== 0) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      prune();
      if (!visible) return;
      files.refresh();
      folders.refresh();
      inspector.refresh();
      drawTools();
      nudge();
    });
  }

  const has = (path: string): boolean => index.entries.has(path) || hasFolder(path) || shownAt(index, path) !== undefined;

  /**
   * What a change took away, let go of: a path chosen, dropped; the open
   * folder gone from disk, its nearest folder that is -- never one the index
   * lacks. The frame after the change, so a move's answer first says where
   * they went (`follow`).
   */
  function prune(): void {
    const kept = stillThere(selection, has);
    if (kept !== selection) selection = kept;
    if (!hasFolder(folder)) {
      const gone = folder;
      folder = settle(folder);
      keep({ folder });
      // A trash slot emptied -- its last file restored -- goes as it should: no news. Emptied by a step of
      // this tool's (its last file moved away), it is still on disk, with nothing in it the index lists.
      if (dirName(gone) !== TRASH) say(steps.busy() ? `${naming.say(gone)} has nothing left in it: ${naming.say(folder)} instead` : `${naming.say(gone)} is gone from disk: ${naming.say(folder)} instead`);
    }
    if (renaming && renaming.where !== 'new' && !has(renaming.path)) endRename();
  }

  offs.push(
    live.on('changed', (diff) => {
      wanted = null;
      if ('tree' in diff) {
        countAll(counts, index.entries);
        sizeAll(sizes, index.entries);
        if (online !== false) api.jobs().then((list) => strip.seed(list), () => {});
        // A failure of a file deleted leaves the strip: a click on it would reveal nothing.
        strip.forget((source) => !index.entries.has(source));
      } else {
        const changed = [...diff.removed, ...diff.added.map((e) => e.path), ...diff.updated.map((e) => e.path)];
        countChanged(counts, changed, index.entries);
        sizeChanged(sizes, changed, index.entries);
        const removed = new Set(diff.removed);
        if (removed.size > 0) strip.forget((source) => removed.has(source));
      }
      soon();
    }),
    live.on('job', (job) => {
      const was = strip.running(job.source);
      // The strip draws itself; nothing else is drawn again for a step's progress.
      strip.take(job);
      const ended = jobEnded(job.state);
      if (ended) inspector.forget(job.source);
      // Its family's marks, a spinner on or off -- the one tile or row each, where they are drawn.
      if (ended || was !== strip.running(job.source)) {
        files.patch(job.source);
        if (inspector.showsFamily(job.source)) inspector.refresh();
      }
      nudge();
    }),
    live.on('tools', (looks) => {
      tools = looks;
      wanted = null;
      soon();
      // The Tools page too, which may be up with the panel not.
      toolsBlock.refresh();
      // Blender found or lost: a .glb beside a .blend is a hand export only without it.
      sheet.refresh();
    }),
    // This tab took a conversion, or finished one: "converting in this tab" where it was "waiting for a game tab".
    onConverting(() => {
      strip.redraw();
      sheet.refresh();
    }),
    live.on('offline', () => {
      offline = true;
      drawBanners();
    }),
  );

  function drawBanners(): void {
    banners.set({ online, offline, unanswered });
  }

  /** The Tools page's block -- patched, what changed alone -- and the folded Folders tab's ⚠ while sources are unmade for want of a tool. */
  function drawTools(): void {
    toolsBlock.refresh();
    const lacking = naming.roots.some((r) => toolsWanted(r).length > 0);
    folders.side.mark(lacking ? '⚠' : '', lacking ? 'sources are unmade for want of a tool: set its path in Config ▸ Tools' : '');
  }

  /** The first time the tab comes up: may this page write, the index, the tools, the jobs. */
  async function start(): Promise<void> {
    if (started) return;
    started = true;
    online = await api.online();
    drawBanners();
    // Every kind, the project's own too: their folders placed and titled by their key types before the first tree is drawn.
    try {
      index.useKinds((await api.kinds()).kinds);
    } catch {
      // A server that does not say (one older than the route): the table's kinds alone.
    }
    try {
      await live.start();
    } catch (err) {
      unanswered = true;
      drawBanners();
      say(`The index did not come: ${(err as Error).message}`, true);
    }
    countAll(counts, index.entries);
    sizeAll(sizes, index.entries);
    // The folder kept last time, or the nearest one up that the index still has.
    const there = settle(folder);
    if (there !== folder) {
      folder = there;
      keep({ folder });
    }
    if (online !== false) {
      api.tools().then((answer) => {
        tools = answer.tools;
        wanted = null;
        soon();
        sheet.refresh();
      }, () => {});
    }
    soon();
    files.refresh();
    folders.refresh();
    folders.reveal(true);
    inspector.refresh();
    ready = true;
    if (revealing !== null) {
      const path = revealing;
      revealing = null;
      reveal(path);
    }
  }

  // ---------------------------------------------------------------- the hint, the mouse

  /** What Space and F do to the preview just now, for the hint: "Space plays · F frames · ", or ''. */
  function previewKeys(): string {
    const space = preview.spaceWord;
    return `${space ? `${space} · ` : ''}${preview.frames ? 'F frames · ' : ''}`;
  }

  function hint(): string {
    const next = keyLabel(isMac() ? 'Alt+ArrowRight' : 'F6');
    const parts: string[] = [];
    if (sheet.open) parts.push(sheet.line);
    else if (focus === 'folders') parts.push(`Folders · ${naming.say(folder)} · ↑↓ walk · ←→ fold · Enter to the files · ${next} next card`);
    else if (focus === 'preview') {
      const several = selection.paths.length > 1;
      const one = several ? previewedOf(selection, stepped) : selection.primary;
      const of = several && one !== null ? ` (${selection.paths.indexOf(one) + 1} of ${selection.paths.length}) · ←→ step` : '';
      parts.push(`Preview · ${one ? baseName(one) : naming.title(folder)}${of} · ${previewKeys()}Esc back to the files · ${next} next card`);
    } else {
      const n = selection.paths.length;
      const one = n === 1 ? selection.primary! : null;
      const bytes = selection.paths.reduce((sum, p) => sum + (shownAt(index, p)?.size ?? 0), 0);
      const open = writes() ? 'double-click opens' : 'double-click previews';
      // Space and F are the preview's from here too (its scope wants no focus of its own): said where they work.
      const keys = previewKeys();
      if (n === 0) parts.push(`Files · ${files.counted} · ↑↓ choose · ${next} next card`);
      else if (one !== null && isFolderPath(index, one)) parts.push(`Files · ${naming.title(one)} · Enter opens · double-click opens`);
      else if (one !== null) parts.push(`Files · ${baseName(one)} · ${sayBytes(bytes)} · Enter previews · ${keys}${open}`);
      else parts.push(`Files · ${n} selected · ${sayBytes(bytes)} · Enter previews · ${keys}${open}`);
    }
    // Issues: the files card lists only what needs a hand -- said, with the way back to every file.
    if (prefs.issues && !sheet.open) parts.push(`Issues: only what needs a hand under ${naming.say(files.query?.everywhere ? PROJECT : folder)} · ${keyLabel('Shift+KeyI')} every file`);
    if (exporting) parts.push(`Exporting ${exporting.total} · ${exporting.ended} done`);
    else if (steps.pending) parts.push(steps.pending);
    else if (strip.busy > 0) parts.push(`${strip.busy} ${strip.busy === 1 ? 'job' : 'jobs'} running`);
    if (online === 'read') parts.push('read-only here');
    else if (online === false) parts.push('what the build bundled, read-only');
    // What a drag over here would do, or a rename's line: while it lasts, it wins over what was just said
    // (§3) -- a refusal on Enter in a rename field is its line already, never said twice.
    if (held) parts.push(held);
    else if (message && message.until > Date.now()) parts.push(message.text);
    return parts.join(' · ');
  }

  /** The keys card's line of what the mouse does on this tab: its tiles and rows, not the scene's. */
  function mouse(): string {
    const mod = modName();
    return `Mouse: click chooses · ${mod}-click adds or takes out · Shift-click chooses from the first chosen to it · `
      + `double-click ${writes() ? 'opens: a folder here, a file in its application' : 'opens a folder, previews a file'} · `
      + `right-click for a menu · a column's head sorts${writes() ? ' · drag a tile onto a folder to move it · drop files from the desktop on a folder, the files or the inspector to import · the inspector\'s name, clicked, renames' : ''} · `
      + 'a press on the grid\'s empty space draws a box: Shift adds, ' + `${mod} turns each over · `
      + 'the preview: drag orbits a model and pans a texture, the wheel zooms, Shift-drag pans; ◂ ▸ step through several chosen · '
      + 'drag a prefab\'s or a model\'s tile onto the scene to place it, or onto a tree row to place it under that entity; a material\'s onto an entity to wear it; drag tree rows onto a folder under prefabs/ to save them as a prefab · '
      + `the panel's top edge drags it taller (a double-click: 240), its fold button (${keyLabel('Shift+Space')}) folds it to a tab on the bottom edge · `
      + 'the folders\' right edge drags them wider; a side card\'s inner edge drags it wider, its fold button puts it away · '
      + 'a press in the tree, the scene or the entity inspector gives the keys and Z to the scene\'s side; one here, back to the files\'';
  }

  // ---------------------------------------------------------------- Claude's edits (Docs/mcp.md D2, M3)

  /**
   * The studio's asset tools, run as the panel's own steps: each flow below is its menu's, its drag's or its block's --
   * the same refusals, the same `Edit`, on the same queue -- with no question asked (the permission gate asks the person
   * where a tool is destructive) and each step labelled `Claude: …`, so Z here undoes Claude's change as the person's.
   */
  const agent = createAgentRunner(steps, api);
  /** The index in, and this page able to write: else the tool is refused in words. */
  const agentReady = async (): Promise<void> => {
    await start();
    if (!writes()) throw new Error(readOnlyLine());
  };
  /** The trashed paths of a slot -- those it had, or all -- as the Trash lists them. */
  const slotFiles = (slot: string, paths: readonly string[] | null): string[] => {
    const all = index.childrenOf(`${TRASH}/${slot}`).files.map((f) => f.path);
    if (all.length === 0) throw new Error(`There is no trash slot ${slot}: asset_list with trash: true lists them`);
    if (paths === null) return all;
    const out = all.filter((p) => paths.includes(fromTrash(p)?.path ?? ''));
    if (out.length === 0) throw new Error(`None of ${paths.join(', ')} is in the slot ${slot}`);
    return out;
  };
  /** Each source's job an answer queued. */
  const jobsOf = (answers: readonly unknown[]): Array<{ id: string; source: string }> =>
    answers.flatMap((a) => ((a as { jobs?: unknown })?.jobs && Array.isArray((a as { jobs: unknown[] }).jobs) ? ((a as { jobs: Array<{ id: string; source: string }> }).jobs) : []));
  /** The value a root field takes from what the tool was given: a number, a yes or no, a colour, a key. */
  const rootValue = (c: Component, field: string, given: unknown): number => {
    if (typeof given === 'number' && !Number.isFinite(given)) throw new Error(`${c.name}.${field}: ${given} is no number`);
    // An enum's name, flags' names, a colour's text, a key -- each through the one reader a file goes through.
    const why = fieldProblem(c, field, given);
    if (why !== null) throw new Error(why);
    const value = given === undefined ? null : fieldValue(c, field, given);
    if (value === null) throw new Error(`${c.name}.${field}: ${JSON.stringify(given)} is no value it takes -- a number, true or false, "#rrggbb", a name of an enum's, or a key`);
    return value;
  };

  const agentAssets: AgentAssets = {
    async move(paths, to, name) {
      await agentReady();
      if (name !== null) {
        if (paths.length !== 1) throw new Error('name renames one path: give one');
        const path = paths[0]!;
        const isDir = !index.entries.has(path) && hasFolder(path);
        if (!isDir && !index.entries.has(path)) throw new Error(`${path} is not here: asset_list shows what is`);
        const ext = isDir || /\.[^.]+$/.test(name) ? '' : (/\.[^./]+$/.exec(baseName(path))?.[0] ?? '');
        const target = joinPath(dirName(path), `${name}${ext}`);
        const caseOnly = caseKey(target) === caseKey(path);
        const why = caseOnly ? null : await codeNaming(keysOf(path, isDir));
        if (why !== null) throw new Error(`Not renamed: ${why}`);
        return agent.run(renameEdit(agent.api, editHost, path, target));
      }
      if (to === null) throw new Error('to (a folder) or name (a new name for one path)');
      const no = moveRefused(paths, to, index, naming);
      if (no) throw new Error(no);
      const named = await codeNaming(paths.flatMap((p) => keysOf(p, isFolderPath(index, p))));
      if (named !== null) throw new Error(`Not moved: ${named}`);
      const heads = familyHeads(paths, index.entries);
      const label = (n: number): string => `Move ${n === 1 ? stemOf(baseName(heads[0]!)) : n} to ${naming.title(to)}`;
      return agent.run(moveEdit(agent.api, editHost, heads.map((p) => [p, joinPath(to, baseName(p))] as const), label));
    },
    async copy(paths, to) {
      await agentReady();
      const into = to;
      if (into !== null) {
        const no = moveRefused(paths, into, index, naming, true);
        if (no) throw new Error(no);
      }
      const alone = partAlone(paths, index.entries);
      if (alone) throw new Error(`Can't copy: ${baseName(alone.part)} is part of ${alone.owners.map(baseName).join(', ')} -- copy its model, and it comes too`);
      const heads = familyHeads(paths, index.entries);
      const label = (n: number): string => (into === null ? (n === 1 ? `Duplicate ${stemOf(baseName(heads[0]!))}` : `Duplicate ${n}`) : `Copy ${n === 1 ? stemOf(baseName(heads[0]!)) : n} to ${naming.title(into)}`);
      return agent.run(copyEdit(agent.api, editHost, heads.map((p) => [p, into ?? dirName(p)] as const), label));
    },
    async remove(paths) {
      await agentReady();
      if (paths.some((p) => under(p, TRASH))) throw new Error('That is in the trash already: asset_restore brings it back, asset_empty_trash removes everything there for good');
      const dirs = paths.filter((p) => !index.entries.has(p) && hasFolder(p));
      for (const d of dirs) {
        const takes = folderTakes(d, naming.title(d));
        if (!takes.delete) throw new Error(takes.why ?? `${naming.title(d)} is not deleted`);
      }
      const missing = paths.filter((p) => !index.entries.has(p) && !hasFolder(p));
      if (missing.length > 0) throw new Error(`Not here: ${missing.join(', ')} -- asset_list shows what is`);
      const chosenFiles = paths.filter((p) => index.entries.has(p));
      const everything = [...new Set([...chosenFiles, ...[...index.entries.keys()].filter((p) => dirs.some((d) => under(p, d) || (twin(d) !== undefined && under(p, twin(d)!))))])];
      // What a data file still names is refused, naming it (Docs/asset-ids.md §4): the panel's own check.
      if (everything.length > 0) {
        const { referrers } = await api.referrers(everything);
        if (referrers.length > 0) {
          const names = [...new Set(referrers.flatMap((r) => r.names))].sort();
          const who = referrers.map((r) => referrerName(r.path));
          throw new Error(`Not deleted: ${who.join(', ')} ${who.length === 1 ? 'names' : 'name'} ${names.join(', ')} -- take ${names.length === 1 ? 'it' : 'them'} out of ${who.length === 1 ? 'that one' : 'those'} first`);
        }
      }
      const going = new Set(everything.map(prefabKeyOf).filter((k): k is string => k !== undefined));
      const open = ctx.prefabsUnsaved.filter((k) => going.has(k));
      if (open.length > 0) throw new Error(`${openWords(open)}: deleted, ${open.length === 1 ? 'its' : 'their'} edits could only be dropped -- ask the person to save or drop them first`);
      const removed = (done: { answers: unknown[] }): string[] => done.answers.flatMap((a) => (a as { removed?: string[] })?.removed ?? []);
      if (dirs.length === 0) {
        const done = await agent.run(trashEdit(agent.api, chosenFiles, chosenFiles.length === 1 ? `Delete ${baseName(chosenFiles[0]!)}` : `Delete ${chosenFiles.length}`));
        return { ...done, removed: removed(done) };
      }
      const sides = dirs.flatMap((d) => {
        const other = twin(d);
        return other !== undefined && hasFolder(other) ? [d, other] : [d];
      });
      const below = (path: string): string[] => [path, ...foldersIn(path).flatMap(below)];
      const folderList = [...new Set(sides.flatMap(below))];
      const inside = [...index.entries.keys()].filter((p) => sides.some((d) => under(p, d)));
      const label = dirs.length === 1 && chosenFiles.length === 0 ? `Delete ${baseName(dirs[0]!)}/` : `Delete ${paths.length}`;
      const done = await agent.run(deleteFolderEdit(agent.api, editHost, label, [...new Set([...chosenFiles, ...inside])], folderList));
      return { ...done, removed: removed(done) };
    },
    async restore(slot, paths, to) {
      await agentReady();
      const trashed = slotFiles(slot, paths);
      const back = restoring(trashed, (p) => index.entries.has(p));
      const done = await agent.run(restoreEdit(agent.api, editHost, bySlot(trashed), restoreLabel(back, to !== null), to ?? undefined));
      // Where each is now: moved into `to`, else where it came back.
      const moves = done.answers.flatMap((a) => (a as { moved?: Array<[string, string]> })?.moved ?? []);
      const restored = moves.length > 0 ? moves.map(([, b]) => b) : done.answers.flatMap((a) => (a as { restored?: string[] })?.restored ?? []);
      return { ...done, restored };
    },
    async make(kind, folderIn, name, of) {
      await agentReady();
      const dir = folderIn ?? (kind === 'model' ? `${ROOTS.source.dir}/${KINDS.models.dir}` : kind === 'material' ? MATERIALS_DIR : kind === 'physicsmaterial' ? PHYSMATS_DIR : kind === 'scene' ? SCENES_DIR : kind === 'prefab' || kind === 'variant' ? PREFABS_DIR : ROOTS.boot.dir);
      const madeAt = async (edit: Edit, path: string, key: string | null): Promise<AgentDone & { path: string; key: string | null; jobs: Array<{ id: string; source: string }> }> => {
        const done = await agent.run(edit);
        return { ...done, path, key, jobs: jobsOf(done.answers) };
      };
      if (kind === 'folder' || kind === 'pack') {
        if (name === null || name === '' || /[/\\]/.test(name)) throw new Error(`name is the new ${kind}'s name, no folder in it`);
        const pack = kind === 'pack';
        const parent = pack ? ROOTS.packs.dir : dir;
        const dirs = pack ? [joinPath(ROOTS.packs.dir, name), joinPath(ROOTS.packs.source, name)] : [joinPath(parent, name)];
        const [answer] = await api.names(parent, [name], { folder: true });
        const twinOnly = answer !== undefined && 'refused' in answer && answer.exists === true && !hasFolder(dirs[0]!);
        if (answer && 'refused' in answer && !twinOnly) throw new Error(`No folder made: ${answer.refused}`);
        const twins = dirs.length === 1 ? [twin(dirs[0]!)].filter((d): d is string => d !== undefined && !hasFolder(d)) : [];
        return madeAt(newFolderEdit(agent.api, editHost, dirs, `New ${pack ? 'pack' : 'folder'} ${name}`, twins), dirs[0]!, null);
      }
      if (kind === 'material') {
        if (!inMaterials(dir)) throw new Error(`${dir} is not under ${MATERIALS_DIR}: a material lives there`);
        const stem = name !== null ? name.replace(/\.material$/i, '') : freeKey(NEW_MATERIAL, (s) => takenIn(dir, `${s}${MATERIAL_SUFFIX}`));
        const path = joinPath(dir, `${stem}${MATERIAL_SUFFIX}`);
        return madeAt(materialWriteEdit(agent.api, path, materialText(newMaterial()), `New material ${stem}`, () => undefined, true), path, materialKeyOf(path) ?? null);
      }
      if (kind === 'physicsmaterial') {
        if (!inPhysmats(dir)) throw new Error(`${dir} is not under ${PHYSMATS_DIR}: a physics material lives there`);
        const stem = name !== null ? name.replace(/\.physmat$/i, '') : freeKey(NEW_PHYSMAT, (s) => takenIn(dir, `${s}${PHYSMAT_SUFFIX}`));
        const path = joinPath(dir, `${stem}${PHYSMAT_SUFFIX}`);
        return madeAt(materialWriteEdit(agent.api, path, physmatText(PHYSICS_MATERIAL_DEFAULTS), `New physics material ${stem}`, () => undefined, true), path, physmatKeyOf(path) ?? null);
      }
      if (kind === 'prefab') {
        if (!inPrefabs(dir)) throw new Error(`${dir} is not under ${PREFABS_DIR}: a prefab lives there`);
        const entity = name ?? nameFromFolder(dir);
        const file = name !== null ? `${name.replace(/\.prefab$/i, '')}${PREFAB_SUFFIX}` : freeName(entity, (n) => takenIn(dir, n));
        const path = joinPath(dir, file);
        return madeAt(writePrefabsEdit(agent.api, `New prefab ${stemOf(file)}`, [{ path, text: prefabText(newPrefab(stemOf(file))), create: true }]), path, prefabKeyOf(path) ?? null);
      }
      if (kind === 'variant') {
        if (of === null) throw new Error('of is the base prefab\'s key: crates/big');
        const base = caseKey(of);
        if (!Object.hasOwn(prefabFiles(), base)) throw new Error(`There is no prefab ${of}: asset_list src/assets/prefabs lists them`);
        const at = folderIn ?? dirName(prefabPathOf(base));
        const file = name !== null ? `${name.replace(/\.prefab$/i, '')}${PREFAB_SUFFIX}` : freeName(`${stemOf(baseName(prefabPathOf(base)))}-variant`, (n) => takenIn(at, n));
        const path = joinPath(at, file);
        return madeAt(writePrefabsEdit(agent.api, `Make variant of ${base}`, [{ path, text: prefabText(variantOf(base)), create: true }]), path, prefabKeyOf(path) ?? null);
      }
      if (kind === 'scene') {
        if (!inScenes(dir)) throw new Error(`${dir} is not under ${SCENES_DIR}: a scene lives there`);
        const stem = name !== null ? name.replace(/\.scene$/i, '') : freeKey(NEW_SCENE, (s) => takenIn(dir, `${s}${SCENE_SUFFIX}`));
        const path = joinPath(dir, `${stem}${SCENE_SUFFIX}`);
        return madeAt(writePrefabsEdit(agent.api, `New scene ${stem}`, [{ path, text: sceneText(newSceneSave(), false), create: true }]), path, sceneKeyOf(path) ?? null);
      }
      if (kind === 'model') {
        if (!inModels(dir)) throw new Error(`${dir} is no models folder under ${ROOTS.source.dir}: a model script goes there`);
        if (name === null || name === '') throw new Error('name is the new model\'s name: Test Thing');
        const stem = name.replace(/\.lua$/i, '');
        const [answer] = await api.names(dir, [`${stem}.lua`], { source: true });
        if (answer && 'refused' in answer) throw new Error(answer.refused);
        let path = joinPath(dir, `${stem}.lua`);
        const done = await agent.run(newModelEdit({ ...modelHost, api: agent.api }, dir, stem, (made) => void (path = made.path)));
        return { ...done, path, key: null, jobs: jobsOf(done.answers) };
      }
      throw new Error(`kind is folder, pack, prefab, variant, material, scene or model -- not ${kind}`);
    },
    async options(path, set, reset, include) {
      await agentReady();
      const isDir = !index.entries.has(path) && hasFolder(path);
      if (!isDir && index.entries.get(path)?.role !== 'source') throw new Error(`${path} is not a source: its options are its source's`);
      const record = isDir ? folderRecordPath(path) : recordPath(path);
      const answers: unknown[] = [];
      let step: string | null = null;
      if (set !== null || reset) {
        const label = (n: number): string => (reset && set === null ? `Reset the options of ${stemOf(baseName(path))}` : `Options of ${stemOf(baseName(path))}${n > 1 ? ` × ${n}` : ''}`);
        const done = await agent.run(optionsEdit(agent.api, (file) => records.fresh(file), [{ path, file: record, change: (own) => ({ ...(reset ? {} : own), ...((set ?? {}) as Options) }) }], label));
        answers.push(...done.answers);
        step = done.step;
      }
      if (include !== null) {
        const row = shownAt(index, path);
        const tick = row ? tickOf(row, index.entries) : null;
        if (tick === null) throw new Error(`${path} has no tick: a reference, a record or a file in the trash ships under no name it can have`);
        const { flips, stuck } = flipsTo([tick], include);
        if (stuck !== undefined) throw new Error(`Not now: ${stuck} -- rename it, or delete it, first`);
        if (flips.length > 0) {
          const name = baseName(path).replace(/^_/, '');
          const done = await agent.run(includeEdit(agent.api, editHost, flips, include, () => (include ? `Put ${name} in the build` : `Leave ${name} out of the build`)));
          answers.push(...done.answers);
          step = done.step ?? step;
        }
      }
      return { step, answers, record, jobs: jobsOf(answers) };
    },
    async exportAs(path, as) {
      await agentReady();
      if (index.entries.get(path)?.role !== 'source') throw new Error(`${path} is no source: only a source's export is named`);
      const value = exportAsValue(path, as);
      const done = await agent.run(exportAsEdit(agent.api, editHost, path, value, exportAsLabel(path, as ?? splitName(baseName(path)).stem)));
      const answer = done.answers.find((a): a is ExportAsAnswer => typeof (a as ExportAsAnswer | null)?.record === 'string');
      return { ...done, record: answer?.record ?? recordPath(path), as: value, moved: answer?.moved ?? [], jobs: jobsOf(done.answers) };
    },
    async adopt(path) {
      await agentReady();
      if (!adoptable(path)) throw new Error(`${path} is no .glb delivered as it is under models, with an AssetsSource twin folder: Make a script is for a model with no source`);
      let made: Adopted | undefined;
      const done = await agent.run(adoptEdit({ ...modelHost, api: agent.api }, path, (a) => void (made = a)));
      const adopted = made as Adopted | undefined;
      const state = adopted?.job?.state;
      return { ...done, script: adopted?.answer.path ?? joinPath(twin(dirName(path))!, `${splitName(baseName(path)).stem}.lua`), copied: adopted?.answer.copy ?? null, decoded: adopted?.answer.decoded ?? [], built: state === 'done' ? 'done' : state === 'failed' ? 'failed' : null, jobs: jobsOf(done.answers) };
    },
    async material(key, set) {
      await agentReady();
      const path = materialPathOf(key);
      if (!index.entries.has(path)) throw new Error(`There is no material ${key}: asset_list ${MATERIALS_DIR} lists them`);
      const text = await (await api.file(path)).text();
      let json: unknown;
      try {
        json = JSON.parse(text);
      } catch (err) {
        throw new Error(`${path} would not parse (${(err as Error).message}): fix it by hand first`);
      }
      const next = materialSet(json, set);
      if ('problems' in next) throw new Error(`Not written: ${next.problems.join('; ')}`);
      if (next.text === text) return { step: null, answers: [], path };
      const label = `${key}: ${Object.keys(set).join(', ')}`;
      const done = await agent.run(materialWriteEdit(agent.api, path, next.text, label, (now) => {
        drafts.written(key, now);
        if (visible) inspector.refresh();
      }));
      return { ...done, path };
    },
    async physmat(key, set) {
      await agentReady();
      const own = caseKey(key);
      const path = [...index.entries.keys()].find((p) => physmatKeyOf(p) === own);
      if (path === undefined) throw new Error(`There is no physics material ${key}: asset_list ${PHYSMATS_DIR} lists them; asset_new kind physicsmaterial makes one`);
      const text = await (await api.file(path)).text();
      let json: unknown;
      try {
        json = JSON.parse(text);
      } catch (err) {
        throw new Error(`${path} would not parse (${(err as Error).message}): fix it by hand first`);
      }
      const now = parsePhysicsMaterial(json);
      if (typeof now === 'string') throw new Error(`${path}: ${now} -- fix it by hand first`);
      const next = physmatSet(physmatDrafts.get(own) ?? now, set);
      if (typeof next === 'string') throw new Error(`Not written: ${next}`);
      if (physmatText(next) === physmatText(now)) return { step: null, answers: [], path, values: next };
      const done = await agent.run(physmatEdit(agent.api, path, next, `${own}: ${Object.keys(set).join(', ')}`));
      return { ...done, path, values: next };
    },
    async prefab(key, change) {
      await agentReady();
      const path = prefabPathOf(key);
      if (!Object.hasOwn(prefabFiles(), key)) throw new Error(`There is no prefab ${key}: asset_list ${PREFABS_DIR} lists them`);
      const changed: string[] = [];
      // The root first, on its edit world -- every name, field and value checked before it is touched (`changeRoot`),
      // and anything thrown after dropping the edit, so the next draw makes it again from the compile -- then the pool
      // on the same text: one file written, one step (the description's "one step").
      let planned: ReturnType<RootEdit['plan']> = null;
      let edit: RootEdit | null = null;
      if ((change.add?.length ?? 0) + (change.remove?.length ?? 0) + Object.keys(change.set ?? {}).length > 0) {
        const why = rootWhy(key);
        if (why) throw new Error(why);
        edit = rootHost.edit(key);
        if (!edit) throw new Error(`${key} is not compiled: it has no root to edit`);
        const rootChanged = changeRoot(edit, change, rootValue);
        try {
          planned = edit.plan(prefabFiles(), checkFile);
        } catch (err) {
          dropRoot(key);
          throw new Error(`Not written -- ${reasonOf(err)}`);
        }
        if (planned) changed.push(...rootChanged);
      }
      const text = await (await api.file(path)).text();
      const write = withPoolPlanned(text, planned, change.pool);
      if (!write) return { step: null, answers: [], path, changed: [] };
      const pooled = change.pool !== undefined && withPool(planned?.text ?? text, change.pool) !== (planned?.text ?? text);
      if (pooled) changed.push(change.pool ? `pool warm ${change.pool.warm}, max ${change.pool.max}` : 'no pool');
      const rootWords = changed.filter((c) => !c.startsWith('pool') && c !== 'no pool');
      const label = rootWords.length > 0
        ? `${key} root: ${[...rootWords, ...(pooled ? [change.pool ? `pool ${change.pool.warm}/${change.pool.max}` : 'no pool'] : [])].join(', ')}`
        : change.pool ? `Pool of ${key}: warm ${change.pool.warm}, max ${change.pool.max}` : `No pool for ${key}`;
      let done: AgentDone;
      try {
        done = await agent.run(writePrefabsEdit(agent.api, label, [{ path, text: write.text }]));
      } catch (err) {
        if (edit) dropRoot(key);
        throw err;
      }
      if (edit && write.file) edit.wrote(write.file, write.text, prefabFiles());
      return { step: done.step, answers: done.answers, path, changed };
    },
    async exportSources(what, force) {
      await agentReady();
      // As E: the panel's export step, its label Claude's -- answered as soon as its jobs are queued, the step landing once they end.
      let queued: (jobs: Array<{ id: string; source: string }>) => void = () => {};
      let failed: (err: Error) => void = () => {};
      const answered = new Promise<Array<{ id: string; source: string }>>((resolve, reject) => {
        queued = resolve;
        failed = reject;
      });
      const label = 'paths' in what ? `Export ${what.paths.length === 1 ? baseName(what.paths[0]!) : what.paths.length}` : `Export all stale under ${naming.title(what.under)}`;
      const exportNow = createExportStep({
        api: { ...agent.api, exportSources: (w, f) => agent.api.exportSources(w, f).then((answer) => (queued(answer.jobs), answer), (err: unknown) => (failed(err as Error), Promise.reject(err))) },
        jobs: (fn) => live.on('job', fn),
        entries: () => index.entries,
        steps: { run: (l, first, then, saying) => steps.run(`${CLAUDE}${l}`, first, then, saying) },
        progress(at) {
          exporting = at;
          nudge();
        },
        partial: (text) => say(text, true),
      });
      void exportNow(label, what, force).then((ok) => {
        if (!ok) failed(new Error('nothing was exported'));
      });
      const jobs = await answered.catch((err: unknown) => {
        throw new Error(reasonOf(err));
      });
      // None queued: nothing needed it, and no step comes.
      return { jobs, step: jobs.length > 0 ? `${CLAUDE}${label}` : null };
    },
  };
  useAgentAssets(agentAssets);

  // ---------------------------------------------------------------- up and away

  function listen(on: boolean): void {
    const method = on ? 'addEventListener' : 'removeEventListener';
    for (const card of cards()) {
      card[method]('pointerdown', pressed, true);
      card[method]('focusin', pressed);
      card[method]('pointerdown', down as EventListener, true);
      // mcp: ui -- a clicked button lets the focus go
      card[method]('click', clicked as EventListener);
      card[method]('change', changed);
    }
    window[method]('contextmenu', contextmenu as EventListener, true);
    // A paste is the page's, heard while the tab is up (§5); a drag carrying files or tiles, guarded on the window.
    document[method]('paste', onPaste as EventListener);
    dnd.listen(on);
  }

  return {
    setVisible(show) {
      if (show === visible) return;
      visible = show;
      if (!show) {
        listen(false);
        menu.close();
        files.shut();
        shutPicker();
        endRename();
        inspector.ask.close();
        panel.hidden = true;
        folders.setVisible(false);
        files.setVisible(false);
        inspector.setVisible(false);
        // Nothing made while the tab is away: what is under way finishes; the holds go with what held.
        thumbs.want([]);
        clearTimeout(scrolling);
        scrolling = undefined;
        thumbs.holdMaking(false);
        holds.clear();
        thumbs.pause(false);
        return;
      }
      // Files has the focus whenever the panel comes up.
      focus = 'files';
      prefs = loadPrefs().assets;
      panel.hidden = false;
      showFolded();
      folders.setVisible(true);
      files.setVisible(true);
      inspector.setVisible(inspecting);
      lightFocus();
      listen(true);
      drawBanners();
      drawTools();
      void start();
      if (started && online !== false) api.jobs().then((list) => strip.seed(list), () => {});
      nudge();
    },
    // The right panel this tool's inspector, or the entity inspector: shown, or put away -- its preview let go -- while up.
    setInspector(shown) {
      if (shown === inspecting) return;
      inspecting = shown;
      if (!visible) return;
      if (!shown) {
        inspector.ask.close();
        if (focus === 'preview') focus = 'files';
        lightFocus();
      }
      inspector.setVisible(shown);
      nudge();
    },
    // Locked: what the inspector shows now pinned; unlocked, it follows what is chosen again. Its lock drawn either way.
    setLocked(on) {
      pinned = on ? liveShowing() : null;
      inspector.refresh();
      nudge();
    },
    // An entity chosen: the files chosen let go, drawn so -- the right panel not asked for (no `select`).
    letGo() {
      if (selection.paths.length === 0) return;
      selection = NO_PATHS;
      stepped = null;
      files.redraw();
      inspector.refresh();
      nudge();
    },
    cards,
    // The Scene tab's keys here, or on the world's side: the focused card's title row lit only while here.
    setFocused() {
      lightFocus();
      nudge();
    },
    // `4`: the panel unfolded, the files with the keys.
    summon() {
      setFolded(false);
      setFocus('files');
    },
    folded: () => prefs.folded,
    setFolded: (on) => setFolded(on),
    // A menu, a drop-down, a sheet, a question are Esc's wherever the keys are; the preview's playing and its focus only while here.
    holdsEscape: () => visible && (menu.open || files.dropped || picker !== null || sheet.open || inspector.ask.open || (ctx.focused && (preview.playing || focus === 'preview'))),
    // One thing at a time, the one on top first: the rename field puts itself away (the browser's close request).
    cancel() {
      if (menu.open) menu.close();
      else if (files.dropped) files.shut();
      else if (picker) shutPicker();
      else if (sheet.open) sheet.close();
      else if (inspector.ask.open) inspector.ask.close();
      else if (preview.playing) preview.stop();
      else if (focus === 'preview') setFocus('files');
    },
    // A quick prompt (Mod+K, Docs/ai-panel.md §4) about the file chosen: over its row or tile, the box above it.
    quickTarget: () => {
      const path = selection.paths[0];
      if (!visible || path === undefined) return null;
      const item = panel.querySelector<HTMLElement>(`[data-path="${CSS.escape(path)}"]`);
      if (!item || item.offsetWidth === 0) return null;
      const at = item.getBoundingClientRect();
      return { target: { kind: 'asset', path, key: keyedFile(path, index.kinds)?.key ?? null }, anchor: { x: at.left + at.width / 2, y: at.top }, room: { left: 0, top: 0, right: innerWidth, bottom: at.top } };
    },
    hint: () => (visible ? hint() : null),
    mouse: () => (visible ? mouse() : null),
    // For the agent's turn: the folder open and the files chosen in it -- a path outside it, as a path -- once the tab has been up.
    context: () => {
      if (!started) return null;
      const facts: ToolFact[] = [{ name: 'folder', value: folder === PROJECT ? 'the project, above the roots' : folder }];
      const inFolder = (path: string): string => (folder !== PROJECT && dirName(path) === folder ? baseName(path) : path);
      if (selection.paths.length > 0) facts.push({ name: 'chosen', value: selection.paths.slice(0, CHOSEN_SAID).map(inFolder).concat(selection.paths.length > CHOSEN_SAID ? [`and ${selection.paths.length - CHOSEN_SAID} more`] : []) });
      return facts;
    },
    history,
    busy: () => steps.busy(),
    // The Model tab's New model, Import model… and Make a script (Docs/modeler.md M38, M39): the files are this panel's.
    newModel: (dir) => newModelIn(modelTarget(dir)),
    importModels: (dir) => {
      // Unfolded for the sheet; folded again as the import lands or the sheet closes, if it was (review round 2).
      if (!sheet.open) refoldAfterSheet = prefs.folded;
      setFolded(false);
      const at = modelTarget(dir);
      if (ready && at !== folder) openFolder(at);
      // Synchronous from the click that asked: the browser opens a picker only within a press.
      pickInto = at;
      pick(filesInput);
    },
    adoptModel: (path) => void adoptModel(path),
    // The Model tab's All options…: the script chosen and its Options block lit -- the panel left folded as it is.
    modelOptions: (path) => {
      if (!ready) return void (revealing = path);
      openFolder(folderOf(path), path);
      ctx.inspect();
      inspector.flashOptions(path);
    },
    modelThumb,
    // Brought up by the host first: the file chosen in the folder that lists it, in view (a prefab's link in the inspector).
    revealAsset: (path) => {
      setFolded(false);
      if (ready) return reveal(path);
      // Up for the first time: the index is still coming, and `start` opens the folder kept last time -- after it, this.
      revealing = path;
    },
    dispose() {
      useAgentAssets(null);
      cancelAnimationFrame(frame);
      cancelAnimationFrame(nudged);
      cancelAnimationFrame(wanting);
      clearTimeout(quiet);
      clearTimeout(scrolling);
      listen(false);
      shutPicker();
      endRename();
      for (const off of offs) off();
      offToolsPage();
      sheet.dispose();
      dnd.dispose();
      filesInput.remove();
      folderInput.remove();
      live.dispose();
      menu.dispose();
      folders.dispose();
      files.dispose();
      inspector.dispose();
      scratch.close();
      sound.stop();
      thumbs.dispose();
      // The context given back: Chrome drops the oldest past sixteen, and that is the game's.
      renderer?.dispose();
      panel.remove();
      dropSheet();
    },
  };
}
