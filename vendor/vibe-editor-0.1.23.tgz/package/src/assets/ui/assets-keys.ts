/**
 * The Assets tool's keys as data (Docs/assets-tool.md §8): each a name, its
 * keys, a line of help, a `scope` -- one word, which card or state it is live
 * in -- and two flags read the same way for every row: `writes`, off in read
 * mode and bundle view (its control is absent there too), and `copy`, waiting
 * for no text selected on the page, which is the browser's to copy. The tool
 * makes every key's `when` from these and adds its `run` (`assets-tool.ts`),
 * through `ctx.keys.add`, so each is a MrDebug action named `editor: <name>`,
 * listed on the keys card under "Assets".
 *
 * - **Names begin with their card or with `assets`**: a name is global to
 *   MrDebug, and none may repeat the host's or the Entities tool's
 *   (`assets-keys.test.ts` holds it).
 * - **Tab is the browser's**: the cards are F6 and Alt+→ (the chord for a Mac
 *   keyboard, whose F6 is the system's), and rename F2 or Shift+Enter.
 * - **Enter is two keys, never live together**: `assets open` with nothing up,
 *   `assets import` with the import sheet up and no control of it focused --
 *   in a name field Enter is the form's own, and MrDebug drops a typed key.
 * - **Several chosen step through the preview** with ← and → while it has the
 *   focus (`several`), as its ◂ ▸ do: the arrows are Files' and Folders' in
 *   theirs, so never two live at once.
 * - **Z, Y, Mod+S, H, T, Home, `?`, Esc and the tools' digits are the host's** and
 *   win; P is boot's.
 *
 * Pure: node tests it.
 */
import type { Mcp } from '../../mcp/declare.ts';
import { keyed } from '../../editor-keys.ts';

/** Where a key is live, one word each; the tool holds one `scoped: Record<Scope, () => boolean>`. */
export const SCOPES = ['free', 'folders', 'files', 'grid', 'preview', 'several', 'menu', 'cards', 'mod', 'search', 'sheet'] as const;
export type Scope = (typeof SCOPES)[number];

/** One key of the tool's, as data: the tool adds its `run`. */
export interface AssetsKey {
  /** Global to MrDebug: `editor: <name>`. */
  readonly name: string;
  readonly key: string | readonly string[];
  readonly help: string;
  /** The MCP tool that does the same, `'ui'`, or why none does (`Mcp`, `../../mcp/declare.ts`). */
  readonly mcp: Mcp;
  readonly scope: Scope;
  /** It changes the project: off in read mode and bundle view. */
  readonly writes?: boolean;
  /** Live whichever side of the Scene tab has the keys (`ToolKey.anySide`): the panel's own, not its choice's -- its fold. */
  readonly anySide?: boolean;
  /** It copies: off while text on the page is selected, which the browser copies. */
  readonly copy?: boolean;
}

export const ASSETS_KEYS = [
  { ...keyed('files menu item above'), help: 'The item above in the menu that is open', mcp: 'ui', scope: 'menu' },
  { ...keyed('files menu item below'), help: 'The item below in the menu that is open', mcp: 'ui', scope: 'menu' },
  { ...keyed('folders up'), help: 'Folders: the folder above', mcp: 'ui', scope: 'folders' },
  { ...keyed('folders down'), help: 'Folders: the folder below', mcp: 'ui', scope: 'folders' },
  { ...keyed('folders fold'), help: 'Folders: fold the folder; folded already, to its parent', mcp: 'ui', scope: 'folders' },
  { ...keyed('folders unfold'), help: 'Folders: unfold the folder; unfolded already, into its first folder', mcp: 'ui', scope: 'folders' },
  { ...keyed('folders next tab'), help: 'Folders: the next tab -- Assets, Source, Trash, round', mcp: 'ui', scope: 'folders' },
  { ...keyed('folders previous tab'), help: 'Folders: the tab before', mcp: 'ui', scope: 'folders' },
  { ...keyed('files up'), help: 'Files: the file above -- a row of tiles up, in the grid', mcp: 'ui', scope: 'files' },
  { ...keyed('files down'), help: 'Files: the file below -- a row of tiles down, in the grid', mcp: 'ui', scope: 'files' },
  { ...keyed('files tile before'), help: 'Files: the tile before', mcp: 'ui', scope: 'grid' },
  { ...keyed('files tile after'), help: 'Files: the tile after', mcp: 'ui', scope: 'grid' },
  { ...keyed('files extend up'), help: 'Files: the selection from the first chosen to the file above', mcp: 'ui', scope: 'files' },
  { ...keyed('files extend down'), help: 'Files: the selection from the first chosen to the file below', mcp: 'ui', scope: 'files' },
  { ...keyed('files extend before'), help: 'Files: the selection from the first chosen to the tile before', mcp: 'ui', scope: 'grid' },
  { ...keyed('files extend after'), help: 'Files: the selection from the first chosen to the tile after', mcp: 'ui', scope: 'grid' },
  { ...keyed('assets page up'), help: 'A page up the focused list, Folders\' or Files\'', mcp: 'ui', scope: 'free' },
  { ...keyed('assets page down'), help: 'A page down the focused list, Folders\' or Files\'', mcp: 'ui', scope: 'free' },
  { ...keyed('assets last'), help: 'The focused list\'s last item', mcp: 'ui', scope: 'free' },
  { ...keyed('assets open'), help: 'Open the folder, the focus to the files; on a file, the focus to the preview', mcp: 'ui', scope: 'free' },
  { ...keyed('assets import'), help: 'The import sheet up: Import -- also after a click on ×, a fix or Options let go of the focus', mcp: 'asset_import', scope: 'sheet' },
  { ...keyed('assets next card'), help: 'The next card: Folders, Files, the preview, round', mcp: 'ui', scope: 'cards' },
  { ...keyed('assets previous card'), help: 'The card before', mcp: 'ui', scope: 'cards' },
  { ...keyed('assets menu'), help: 'The focused card\'s menu, its first item focused: the arrows walk it, Enter chooses, Esc closes', mcp: 'ui', scope: 'free' },
  { ...keyed('assets play'), help: 'Play or pause the sound or the clip shown', mcp: 'ui', scope: 'preview' },
  { ...keyed('assets frame'), help: 'Frame the model shown; fit the texture', mcp: 'ui', scope: 'preview' },
  { ...keyed('assets preview before'), help: 'Several chosen, the preview focused: the one before previewed (◂) -- the keys walk on from it', mcp: 'ui', scope: 'several' },
  { ...keyed('assets preview after'), help: 'Several chosen, the preview focused: the next one previewed (▸) -- the keys walk on from it', mcp: 'ui', scope: 'several' },
  { ...keyed('assets grid or list'), help: 'The files as a grid of tiles, or a list', mcp: 'ui', scope: 'free' },
  { ...keyed('assets smaller thumbs'), help: 'Smaller tiles: 256, 128, 64', mcp: 'ui', scope: 'grid' },
  { ...keyed('assets larger thumbs'), help: 'Larger tiles: 64, 128, 256', mcp: 'ui', scope: 'grid' },
  { ...keyed('assets export'), help: 'Export what needs it: the selection\'s stale, missing and failed (in Folders, all under it)', mcp: 'asset_export', scope: 'free', writes: true },
  { ...keyed('assets export again'), help: 'Export the selection again, current or not', mcp: 'asset_export', scope: 'free', writes: true },
  { ...keyed('assets rename'), help: 'Rename where the name is: the tile, the row, the folder, the inspector\'s head', mcp: 'asset_move', scope: 'free', writes: true },
  { ...keyed('assets trash'), help: 'To the trash: Z undoes', mcp: 'asset_delete', scope: 'free', writes: true },
  { ...keyed('assets trash (backspace)'), help: 'To the trash: Z undoes', mcp: 'asset_delete', scope: 'free', writes: true },
  { ...keyed('assets duplicate'), help: 'A copy of each in its own folder', mcp: 'asset_copy', scope: 'mod', writes: true },
  { ...keyed('assets import files'), help: 'Import files into the open folder: the file picker', mcp: 'asset_import', scope: 'free', writes: true },
  { ...keyed('assets new folder'), help: 'A new folder in the open one, named in place', mcp: 'asset_new', scope: 'free', writes: true },
  { ...keyed('assets fold'), help: 'The Assets panel folded to a tab on the bottom edge, the scene the room -- or unfolded again; whichever side has the keys', mcp: 'ui', scope: 'free', anySide: true },
  { ...keyed('assets issues'), help: 'Issues: only what needs a hand under the open folder, flat; again, every file', mcp: 'ui', scope: 'free' },
  { ...keyed('assets build'), help: 'In the build or out of it: the files chosen, one tick for all -- a source never exported, a loose file named _', mcp: ['asset_options', 'asset_move'], scope: 'free', writes: true },
  { ...keyed('assets folder up'), help: 'The folder the open one is in', mcp: 'ui', scope: 'mod' },
  { ...keyed('assets select all'), help: 'Select every file shown', mcp: 'ui', scope: 'mod' },
  { ...keyed('assets select none'), help: 'Select no file', mcp: 'ui', scope: 'mod' },
  { ...keyed('assets copy key'), help: 'Copy the key: what the game loads it by', mcp: 'ui', scope: 'mod', copy: true },
  { ...keyed('assets copy path'), help: 'Copy the path, from the project\'s root', mcp: 'ui', scope: 'mod', copy: true },
  { ...keyed('assets search'), help: 'The search field: words, status: kind: role: ext:, and #key in every folder', mcp: 'ui', scope: 'search' },
] as const satisfies readonly AssetsKey[];

/** A key's name: what the tool's `run`s are keyed by. */
export type AssetsKeyName = (typeof ASSETS_KEYS)[number]['name'];
