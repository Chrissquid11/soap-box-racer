/**
 * The Assets tool's one status vocabulary (Docs/assets-tool.md §4): a glyph
 * and a colour for every status a file can be in -- never the colour alone --
 * shared by the tree's counts, the tiles, the rows and the inspector; and the
 * folders' counts of what needs a hand under them, kept up the changed paths
 * only (§9).
 *
 * - **A colour is a class** (`ed-as-green`, `ed-as-amber`, `ed-as-red`,
 *   `ed-as-grey`), its value a token in `assets.css`: a game's palette changes
 *   in one place, and this module stays pure.
 * - **Status is a source's** (Docs/assets.md §2), and an export carries its
 *   source's: the family is one thing. A loose file, a part, an intermediate
 *   or an extra has none, and shows only a pointer's mark.
 * - **What needs a hand** is a source `stale`, `missing`, `unmade`, `failed`
 *   or `conflict`, an export of one -- its tile says so, and so does its
 *   folder under Assets -- any file that is a Git LFS pointer, and a stray
 *   prefab file (`misnamed`: a `.json` under prefabs/, a `.prefab` elsewhere). Counted
 *   where each file lies, a family once in a folder: two exports of one source
 *   side by side are one thing to do (`familyOf`). Up to the project (`''`),
 *   where a source and its export, in two roots, are one family too.
 * - **What needs a hand, listed** (`issuesOf`, the files card's Issues): one
 *   file a family and a need, as the counts have them, so the list under a
 *   folder is as long as its mark says.
 * - **In the build** (`tickOf`, Docs/assets-tool.md §4, §6): every row's tick
 *   -- on or off, what flipping it does, why it cannot just now -- or none. A
 *   source's is its record's `"include": false` (or, beside a source of its
 *   stem, which shares that record, its name's `_`); an export's, a record's
 *   and an intermediate's their source's; a part's its owners'; a loose
 *   file's, and an `_` file's that would ship without it, its name's `_`.
 *   Off, a row is `excluded` -- its own mark, grey, never a need: counted
 *   apart (`Tally`), said on a folder's hover, left out of Issues.
 * - **A job's state**: `jobEnded`, the one place the five that end one --
 *   `done`, `failed`, `unmade`, `dropped`, `skipped` -- are written.
 *
 * Pure: node tests it (`marks.test.ts`).
 */
import type { Entry, JobState, Status } from '@vibe/pipeline/assets-types';
import { baseName, dirName, globbed, joinPath, locate, splitName, strayFile, under } from '@vibe/pipeline/paths';
import { isFound, recipeFor } from '@vibe/pipeline/recipes';
import { PROJECT, type Shown } from '../model.ts';

/** The four colours a mark comes in. */
export type Colour = 'green' | 'amber' | 'red' | 'grey';

/** Each colour's class: its value is a token in `assets.css`, never a literal here. */
export const COLOUR_CLASS: Readonly<Record<Colour, string>> = {
  green: 'ed-as-green',
  amber: 'ed-as-amber',
  red: 'ed-as-red',
  grey: 'ed-as-grey',
};

/** A status as the tool shows it: its glyph, its word, its colour, and what it means on hover. */
export interface Mark {
  glyph: string;
  word: string;
  colour: Colour;
  means: string;
  /** Drawn struck through (`ed-as-struck`): out of the build's key, a key no build has. */
  struck?: boolean;
}

/** Every status's mark: a glyph of its own each. */
export const STATUS_MARKS: Readonly<Record<Status, Mark>> = {
  current: { glyph: '✓', word: 'current', colour: 'green', means: 'its export is what it makes today' },
  stale: { glyph: '↻', word: 'stale', colour: 'amber', means: 'something it is made from changed: it can be exported again here' },
  missing: { glyph: '∅', word: 'missing', colour: 'amber', means: 'not exported yet: it can be made here' },
  unmade: { glyph: '⚙', word: 'unmade', colour: 'grey', means: 'nothing on this machine can make it: a tool, a game tab or a hand is wanted' },
  failed: { glyph: '✕', word: 'failed', colour: 'red', means: 'the last export failed, or it cannot succeed' },
  conflict: { glyph: '≠', word: 'conflict', colour: 'red', means: 'its export would share a path or a key with another file\'s' },
  excluded: { glyph: '⚿', word: 'excluded', colour: 'grey', means: 'out of the build: its tick is off, so it is never exported', struck: true },
  checking: { glyph: '○', word: 'checking', colour: 'grey', means: 'not hashed yet' },
  reference: { glyph: '◇', word: 'reference', colour: 'grey', means: 'under reference/: no export expected' },
};

/** A Git LFS pointer: the file not fetched. Its colour is its status's -- red on an export, which the game cannot load. */
export const POINTER: Mark = { glyph: '⤓', word: 'pointer', colour: 'red', means: 'a Git LFS pointer, not the file: git lfs install && git lfs pull' };

/** A prefab file that is none -- a `.json` under prefabs/, a `.prefab` elsewhere (`strayPrefab`): never compiled, so it needs a hand. */
export const MISNAMED: Mark = { glyph: '!', word: 'not a prefab', colour: 'red', means: 'a prefab file ends in .prefab and lies under prefabs/: rename or move it' };

/** What needs a hand, the worst first: what a folder's count is of, and whose glyph it shows. */
export const NEEDS = ['failed', 'conflict', 'pointer', 'misnamed', 'missing', 'stale', 'unmade'] as const;
export type Need = (typeof NEEDS)[number];

/** The mark of a need. */
export const needMark = (need: Need): Mark => (need === 'pointer' ? POINTER : need === 'misnamed' ? MISNAMED : STATUS_MARKS[need]);

/** Is this row an entry of the index, rather than a file in a trash slot? */
export const isEntry = (row: Shown): row is Entry => 'role' in row;

/** Has a job in this state ended -- done, failed, unmade, dropped, skipped (nothing to do) -- rather than queued, running or parked? */
export const jobEnded = (state: JobState): boolean => state === 'done' || state === 'failed' || state === 'unmade' || state === 'dropped' || state === 'skipped';

/**
 * The source of a row's family, as an entry: a source itself; an export's, an
 * intermediate's or a record's source (`entries`, the client index) -- what
 * Export, the inspector's Status and a job's mark go by. Undefined for any
 * other row, and for a file in the trash, which has no family.
 */
export function sourceOf(row: Shown, entries: ReadonlyMap<string, Entry>): Entry | undefined {
  if (!isEntry(row)) return undefined;
  if (row.role === 'source') return row;
  if ((row.role === 'export' || row.role === 'intermediate' || row.role === 'record') && row.source !== undefined) return entries.get(row.source);
  return undefined;
}

/**
 * The status a row says (§4): a source's own; an export's its source's
 * (`entries`, the client index) -- the family is one thing; `reference` under
 * `reference/`; none for a record, an intermediate, a loose file, a part, an
 * extra, or a file in the trash.
 */
export function statusOf(row: Shown, entries: ReadonlyMap<string, Entry>): Status | undefined {
  if (!isEntry(row)) return undefined;
  if (row.role === 'source' || row.role === 'reference') return row.status ?? (row.role === 'reference' ? 'reference' : undefined);
  if (row.role === 'export' && row.source !== undefined) return entries.get(row.source)?.status;
  return undefined;
}

/** A mark as drawn: its glyph, the class its colour is, and its hover -- the status and its reason. */
export interface Shows {
  glyph: string;
  colour: Colour;
  title: string;
  /** Struck through: out of the build. */
  struck?: boolean;
}

/** A mark's classes: `ed-as-mark`, its colour's, and struck through where it is out of the build. */
export const markClass = (mark: { colour: Colour; struck?: boolean }): string => `ed-as-mark ${COLOUR_CLASS[mark.colour]}${mark.struck ? ' ed-as-struck' : ''}`;

// ---------------------------------------------------------------- in the build: the tick

/** What flipping a tick does to one file: a source's record (`PUT sidecar { include }`), or a name's `_` put on or taken off (`POST move`). */
export type TickFlip = { record: string } | { from: string; to: string };

/** A row's "in the build" tick: on or off, what flipping it does, and its hover -- or, `stuck`, why it cannot flip just now. */
export interface Tick {
  on: boolean;
  flips: TickFlip[];
  title: string;
  stuck?: string;
}

/** The name with an `_` before it, or without: the twin of a tick's flip by name. */
const underscoreOf = (path: string): string => joinPath(dirName(path), `_${baseName(path)}`);
const withoutUnderscore = (path: string): string => joinPath(dirName(path), baseName(path).slice(1));

/** The other sources of `source`'s stem in its folder -- one record between them -- looked for only in a conflict, which they always are while both are in. */
function stemSharers(source: Entry, entries: ReadonlyMap<string, Entry>): string[] {
  if (source.status !== 'conflict') return [];
  const dir = dirName(source.path);
  const stem = splitName(baseName(source.path)).stem;
  const out: string[] = [];
  for (const e of entries.values()) if (e.role === 'source' && e.path !== source.path && dirName(e.path) === dir && splitName(baseName(e.path)).stem === stem) out.push(e.path);
  return out;
}

/** A source's own tick: its record's flag -- or, going out beside a source of its stem, its name's `_`. */
function sourceTick(source: Entry, entries: ReadonlyMap<string, Entry>): Tick {
  const name = baseName(source.path);
  if (!source.included) return { on: false, flips: [{ record: source.path }], title: `Out of the build: ${name} is never exported -- tick to put it back in, and it is exported again` };
  const sharing = stemSharers(source, entries);
  if (sharing.length > 0) {
    const to = underscoreOf(source.path);
    const stuck = entries.has(to) ? `${baseName(to)} is taken` : undefined;
    return { on: true, flips: [{ from: source.path, to }], title: `In the build -- untick to leave it out: renamed ${baseName(to)}, as it shares its record with ${sharing.map(baseName).join(', ')}`, ...(stuck ? { stuck } : {}) };
  }
  return { on: true, flips: [{ record: source.path }], title: `In the build: ${name} is exported -- untick to leave it out: its record says so, and its export goes to the trash` };
}

/**
 * A row's tick (§4, the Build column; §6, the inspector's head), or null for
 * none: a file in the trash, a reference, a record of no source, an extra that
 * no name ships. `entries` is the client index.
 */
export function tickOf(row: Shown, entries: ReadonlyMap<string, Entry>): Tick | null {
  if (!isEntry(row)) return null;
  switch (row.role) {
    case 'source':
      return sourceTick(row, entries);
    case 'export':
    case 'intermediate':
    case 'record': {
      const source = row.source !== undefined ? entries.get(row.source) : undefined;
      if (!source || source.role !== 'source') return null;
      const own = sourceTick(source, entries);
      return { ...own, title: `Its source's, ${baseName(source.path)}: ${own.title}` };
    }
    case 'part': {
      const owners = (row.owners ?? []).map((o) => entries.get(o)).filter((e): e is Entry => e !== undefined && e.role === 'source');
      if (owners.length === 0) return null;
      // Toward the other way from where the part is: each owner that is not there yet.
      const ticks = owners.map((o) => sourceTick(o, entries)).filter((tick) => tick.on === row.included);
      const stuck = ticks.find((tick) => tick.stuck !== undefined)?.stuck;
      return { on: row.included, flips: ticks.flatMap((tick) => tick.flips), title: `Its model's, ${owners.map((o) => baseName(o.path)).join(', ')}: a part is in the build as its model is`, ...(stuck ? { stuck } : {}) };
    }
    case 'loose': {
      const to = underscoreOf(row.path);
      const stuck = entries.has(to) ? `${baseName(to)} is taken` : undefined;
      return { on: true, flips: [{ from: row.path, to }], title: `In the build, as delivered -- untick to leave it out: renamed ${baseName(to)}, which no build takes`, ...(stuck ? { stuck } : {}) };
    }
    case 'extra': {
      // An `_` that keeps it out: off, if the name without it would ship -- as delivered, or as a source.
      if (!baseName(row.path).startsWith('_')) return null;
      const to = withoutUnderscore(row.path);
      const where = locate(to);
      const ships = where?.root === 'source' ? !where.reference && !baseName(to).startsWith('_') && isFound(recipeFor(to)) : where !== undefined && globbed(to);
      if (!ships) return null;
      const stuck = entries.has(to) ? `${baseName(to)} is taken` : undefined;
      const as = where?.root === 'source' ? 'a source again, exported once asked' : 'delivered';
      return { on: false, flips: [{ from: row.path, to }], title: `Out of the build: its name starts with _ -- tick to rename it ${baseName(to)}, ${as}`, ...(stuck ? { stuck } : {}) };
    }
    default:
      return null;
  }
}

/** Is a row out of the build on its own account -- a source its tick took out, an `_` name its tick would take off -- not as a part or an export following one? */
export function excludedOf(row: Shown, entries: ReadonlyMap<string, Entry>): boolean {
  if (!isEntry(row) || row.included) return false;
  if (row.role === 'source') return true;
  return row.role === 'extra' && tickOf(row, entries) !== null;
}

/** The ticks of several rows as one (§6, several chosen): on, off, or `mixed` (`—`); null when none has one. */
export function ticksOf(rows: readonly Shown[], entries: ReadonlyMap<string, Entry>): { on: boolean | 'mixed'; ticks: Tick[] } | null {
  const ticks = rows.map((r) => tickOf(r, entries)).filter((tick): tick is Tick => tick !== null);
  if (ticks.length === 0) return null;
  const on = ticks.every((tick) => tick.on) ? true : ticks.every((tick) => !tick.on) ? false : 'mixed';
  return { on, ticks };
}

/**
 * What putting these ticks to `to` does: every flip of each one not there
 * already, each file once, the records first, then the names -- one step
 * (`file-steps.ts`' `includeEdit`). `stuck`, the first that cannot.
 */
export function flipsTo(ticks: readonly Tick[], to: boolean): { flips: TickFlip[]; stuck?: string } {
  const flips: TickFlip[] = [];
  const seen = new Set<string>();
  let stuck: string | undefined;
  for (const tick of ticks) {
    if (tick.on === to) continue;
    stuck ??= tick.stuck;
    for (const flip of tick.flips) {
      const key = 'record' in flip ? flip.record : flip.from;
      if (seen.has(key)) continue;
      seen.add(key);
      flips.push(flip);
    }
  }
  flips.sort((a, b) => Number('from' in a) - Number('from' in b));
  return stuck !== undefined ? { flips, stuck } : { flips };
}

/**
 * The mark a row shows, or null for none: a pointer's (`⤓`, in its status's
 * colour, red on an export or with no status), else its status's, its title
 * the word and the `reason` (the source's, for an export).
 */
export function markOf(row: Shown, entries: ReadonlyMap<string, Entry>): Shows | null {
  if (!isEntry(row)) return null;
  // Out of the build: its own mark, whatever else it is -- nothing of it ships, so nothing of it needs a hand.
  if (excludedOf(row, entries) || (row.role === 'export' && statusOf(row, entries) === 'excluded')) {
    const mark = STATUS_MARKS.excluded;
    const why = row.role === 'source' || row.role === 'export' ? mark.means : 'out of the build: its name starts with _, which no build takes';
    return { glyph: mark.glyph, colour: mark.colour, title: `excluded: ${why}`, struck: true };
  }
  const status = statusOf(row, entries);
  const owner = row.role === 'export' && row.source !== undefined ? entries.get(row.source) : row;
  const reason = owner?.reason;
  const said = status ? `${status}${reason ? `: ${reason}` : ''}` : '';
  if (row.pointer) {
    const colour: Colour = row.role === 'export' || !status ? 'red' : STATUS_MARKS[status].colour;
    return { glyph: POINTER.glyph, colour, title: `${POINTER.means}${said ? ` · ${said}` : ''}` };
  }
  // A prefab file that is none -- a `.json` under prefabs/, a `.prefab` elsewhere: red, its problem on hover.
  const stray = strayFile(row.path);
  if (stray) return { glyph: MISNAMED.glyph, colour: MISNAMED.colour, title: stray.problem };
  if (!status) return null;
  return { glyph: STATUS_MARKS[status].glyph, colour: STATUS_MARKS[status].colour, title: said || STATUS_MARKS[status].means };
}

/**
 * What a file needs a hand with, if anything -- what its mark says
 * (`markOf`): a pointer, any file; a stray prefab file (`misnamed`); a
 * source's status among `NEEDS`, and an export's its source's.
 */
export function needOf(entry: Entry, entries: ReadonlyMap<string, Entry>): Need | null {
  // Out of the build: never a need -- an LFS pointer there included, which no build reads.
  if (excludedOf(entry, entries)) return null;
  if (entry.pointer) return 'pointer';
  if (strayFile(entry.path)) return 'misnamed';
  const status = statusOf(entry, entries);
  return status !== undefined && (NEEDS as readonly string[]).includes(status) ? (status as Need) : null;
}

/** What a file is counted as in its folders: a need, or out of the build (`excluded`, said on hover, never a need), or nothing. */
export type Tally = Need | 'excluded';

/** A file's tally: its need, else whether it is out of the build on its own account. */
export function tallyOf(entry: Entry, entries: ReadonlyMap<string, Entry>): Tally | null {
  return needOf(entry, entries) ?? (excludedOf(entry, entries) ? 'excluded' : null);
}

/** The family a file is counted as: an export's source, any other file itself -- so a family's exports side by side count once. */
export const familyOf = (entry: Entry): string => (entry.role === 'export' && entry.source !== undefined ? entry.source : entry.path);

/** A folder's count of what needs a hand under it, by need, and of what is out of the build: families, not files. */
export type Counts = ReadonlyMap<Tally, number>;

/** Every folder's counts, kept as files change: each file's need counted in every folder it is under, a family once a folder. */
export interface FolderCounts {
  /** `path`'s tally now (null for none, or gone), as a file of `family` (itself by default): counted up its folders, what it counted before taken off first. */
  set(path: string, need: Tally | null, family?: string): void;
  /** What needs a hand under `folder`, by need; empty for nothing. */
  of(folder: string): Counts;
  /** The paths counted as files of `family` just now: a source's exports, to count again when it changes. */
  members(family: string): readonly string[];
  /** Every count forgotten: a whole tree comes next. */
  clear(): void;
}

const NONE: Counts = new Map();

export function createCounts(): FolderCounts {
  /** Each file counted, by path: what it needs, and as whose. */
  const counted = new Map<string, { need: Tally; family: string }>();
  /** Each family's files counted. */
  const kin = new Map<string, Set<string>>();
  /** Per folder, per need, how many of each family's files are under it. */
  const files = new Map<string, Map<Tally, Map<string, number>>>();
  /** Per folder, per need, how many families: what is shown. */
  const folders = new Map<string, Map<Tally, number>>();

  /** `by` more of `family`'s files with `need` in every folder `path` is under, the project last: the family counted as it comes and as its last goes. */
  const up = (path: string, need: Tally, family: string, by: 1 | -1): void => {
    for (let dir = dirName(path), last = false; !last; dir = dirName(dir)) {
      last = dir === PROJECT;
      let needs = files.get(dir);
      if (!needs) files.set(dir, (needs = new Map()));
      let byFamily = needs.get(need);
      if (!byFamily) needs.set(need, (byFamily = new Map()));
      const before = byFamily.get(family) ?? 0;
      const after = before + by;
      if (after > 0) byFamily.set(family, after);
      else byFamily.delete(family);
      if (byFamily.size === 0) needs.delete(need);
      if (needs.size === 0) files.delete(dir);
      const step = before === 0 && after > 0 ? 1 : before > 0 && after <= 0 ? -1 : 0;
      if (step === 0) continue;
      let counts = folders.get(dir);
      if (!counts) folders.set(dir, (counts = new Map()));
      const n = (counts.get(need) ?? 0) + step;
      if (n > 0) counts.set(need, n);
      else counts.delete(need);
      if (counts.size === 0) folders.delete(dir);
    }
  };

  return {
    set(path, need, family = path) {
      const was = counted.get(path);
      if (was?.need === need && was.family === family) return;
      if (was === undefined && need === null) return;
      if (was) {
        up(path, was.need, was.family, -1);
        counted.delete(path);
        const members = kin.get(was.family);
        members?.delete(path);
        if (members?.size === 0) kin.delete(was.family);
      }
      if (need === null) return;
      counted.set(path, { need, family });
      let members = kin.get(family);
      if (!members) kin.set(family, (members = new Set()));
      members.add(path);
      up(path, need, family, 1);
    },
    of: (folder) => folders.get(folder) ?? NONE,
    members: (family) => [...(kin.get(family) ?? [])],
    clear() {
      counted.clear();
      kin.clear();
      files.clear();
      folders.clear();
    },
  };
}

/** Every file's count, from the whole index: a whole tree came. */
export function countAll(counts: FolderCounts, entries: ReadonlyMap<string, Entry>): void {
  counts.clear();
  for (const e of entries.values()) counts.set(e.path, tallyOf(e, entries), familyOf(e));
}

/**
 * The counts after a diff (§9: up the changed paths only): each path it named
 * -- added, updated or removed -- counted again, and with a source every file
 * of its family, those counted as it before and its exports now: an export's
 * need is its source's, so a source that changed, came or went moves its
 * exports' counts too.
 */
export function countChanged(counts: FolderCounts, paths: Iterable<string>, entries: ReadonlyMap<string, Entry>): void {
  const again = new Set<string>();
  for (const path of paths) {
    again.add(path);
    for (const member of counts.members(path)) again.add(member);
    const e = entries.get(path);
    if (e?.role === 'source') for (const made of e.exports ?? []) again.add(made);
  }
  for (const path of again) {
    const e = entries.get(path);
    counts.set(path, e ? tallyOf(e, entries) : null, e ? familyOf(e) : path);
  }
}

/** How many need a hand, in all: what is out of the build never does. */
export const total = (counts: Counts): number => NEEDS.reduce((sum, need) => sum + (counts.get(need) ?? 0), 0);

/** What is out of the build under a folder, said for its hover -- "2 out of the build" -- or null for none. */
export const excludedText = (counts: Counts): string | null => {
  const n = counts.get('excluded') ?? 0;
  return n > 0 ? `${n} out of the build` : null;
};

/** The worst need counted, or null. */
export const worst = (counts: Counts): Need | null => NEEDS.find((need) => (counts.get(need) ?? 0) > 0) ?? null;

/** The counts in words, the worst first: `1 failed, 2 stale`. */
export const countsText = (counts: Counts): string =>
  NEEDS.filter((need) => counts.has(need)).map((need) => `${counts.get(need)} ${need === 'pointer' ? (counts.get(need) === 1 ? 'LFS pointer' : 'LFS pointers') : needMark(need).word}`).join(', ');

/**
 * What needs a hand under `folder` (§4, the files card's Issues): every file
 * `needOf` names, one a family and a need -- as `FolderCounts` counts them, so
 * the list is as long as the folder's mark says -- its source where that is
 * under the folder, else the family's file first by path. Under the project
 * (`PROJECT`), every root's; a file in the trash has no family and needs
 * nothing, so the Trash has none.
 */
export function issuesOf(entries: ReadonlyMap<string, Entry>, folder: string): Entry[] {
  const chosen = new Map<string, Entry>();
  for (const e of entries.values()) {
    if (folder !== PROJECT && !under(e.path, folder)) continue;
    const need = needOf(e, entries);
    if (need === null) continue;
    const family = familyOf(e);
    const key = `${family}\n${need}`;
    const had = chosen.get(key);
    // The source itself first -- what its exports are made from -- then the first by path, so the choice is the same each time.
    const own = e.path === family;
    if (had === undefined || (own !== (had.path === family) ? own : e.path < had.path)) chosen.set(key, e);
  }
  return [...chosen.values()];
}

/** A folder's mark: the worst one's glyph in its colour, and how many in all -- `↻ 2` -- its title the counts in words. Null for none. */
export function folderMark(counts: Counts): Shows | null {
  const bad = worst(counts);
  if (bad === null) return null;
  const mark = needMark(bad);
  const out = excludedText(counts);
  return { glyph: `${mark.glyph} ${total(counts)}`, colour: mark.colour, title: `Needs a hand under here: ${countsText(counts)}${out ? ` · ${out}` : ''}` };
}
