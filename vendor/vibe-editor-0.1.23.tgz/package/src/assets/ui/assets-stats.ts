/**
 * A file's numbers, the inspector's Stats (Docs/assets-tool.md §6.4, §9, §12):
 * a browser game's -- bytes on the wire, triangles, texture pixels, seconds of
 * audio -- from `GET stats`, asked lazily and kept for the session.
 *
 * - **Bytes first, from the index** (`bytesLines`): on disk, a source's
 *   export's and the share it is of it, or an export's source's -- no wait.
 * - **`STATS`, a row of lines a reader**: what `GET stats` read the file as --
 *   a `model` (meshes, primitives, vertices, triangles, materials, textures and
 *   their bytes, clips, skins and joints, extensions, bounds), an `image`
 *   (size, format, alpha, power of two, mips), an `audio` (duration, channels,
 *   rate). A game's row by an entry's kind (`stats: { models: … }`) wins over
 *   the reader's (`statsRowFor`).
 * - **Asked once a content** (`createStatsCache`, `statsKey`): "reading…"
 *   until it answers, then kept for the session by the content's hash -- or,
 *   where the index has none (it hashes sources), by the path with its size
 *   and mtime, so a re-export is read again.
 *
 * Of a source, the numbers are of what is shown of it (`previewPath`): its
 * export when current. Pure: node tests it (`assets-stats.test.ts`), with a
 * stand-in `GET stats`.
 */
import type { AudioStats, Entry, FileStats, ImageStats, ModelStats } from '@vibe/pipeline/assets-types';
import { baseName } from '@vibe/pipeline/paths';
import type { Api } from '../api.ts';
import type { Shown } from '../model.ts';
import { sayBytes } from './budget.ts';
import { contentStamp, kindOfRow } from './files-columns.ts';
import { isEntry } from './marks.ts';

/** One line of Stats: what, how much, and more on hover. */
export interface StatLine {
  label: string;
  value: string;
  title?: string;
}

/** A row of Stats: the lines for a file and what `GET stats` read of it. */
export interface StatsRow {
  lines(entry: Shown, stats: FileStats): StatLine[];
}

const n = (v: number): string => v.toLocaleString('en');
const plural = (v: number, one: string, many = `${one}s`): string => `${n(v)} ${v === 1 ? one : many}`;
const seconds = (s: number): string => `${s.toFixed(2)} s`;
const isPow2 = (v: number): boolean => v > 0 && (v & (v - 1)) === 0;

/** A model's lines (`stats/glb.ts`'s numbers). */
function modelLines(entry: Shown, s: ModelStats): StatLine[] {
  const lines: StatLine[] = [
    { label: 'Meshes', value: `${plural(s.meshes, 'mesh', 'meshes')} · ${plural(s.primitives, 'primitive')}`, title: 'A primitive is a draw call, before instancing' },
    { label: 'Vertices', value: n(s.vertices) },
    { label: 'Triangles', value: n(s.triangles) },
    { label: 'Materials', value: n(s.materials) },
  ];
  const known = s.images.filter((i) => i.bytes !== undefined);
  const imageBytes = known.reduce((sum, i) => sum + (i.bytes ?? 0), 0);
  const names = s.images.map((i) => i.name ?? i.uri ?? i.mimeType ?? 'an image').join(', ');
  lines.push({
    label: 'Textures',
    value: s.textures === 0 ? 'none' : `${n(s.textures)}${known.length > 0 ? ` · ${sayBytes(imageBytes)} of the ${sayBytes(entry.size)}` : ''}`,
    ...(names ? { title: names } : {}),
  });
  lines.push({
    label: 'Clips',
    value: s.animations.length === 0 ? 'none' : s.animations.map((a) => `${a.name || 'unnamed'} ${seconds(a.duration)}`).join(', '),
  });
  if (s.skins.length > 0) {
    const joints = s.skins.reduce((sum, k) => sum + k.joints, 0);
    lines.push({ label: 'Skins', value: `${plural(s.skins.length, 'skin')} · ${plural(joints, 'joint')}` });
  }
  lines.push({ label: 'Extensions', value: s.extensionsUsed.length === 0 ? 'none' : s.extensionsUsed.join(', ') });
  if (s.bounds) {
    const [x, y, z] = [0, 1, 2].map((i) => s.bounds!.max[i]! - s.bounds!.min[i]!);
    lines.push({ label: 'Bounds', value: `${x!.toFixed(2)} × ${y!.toFixed(2)} × ${z!.toFixed(2)}`, title: 'Width × height × depth, in the model\'s units (metres), its meshes as stored: node transforms not applied' });
  }
  return lines;
}

/** An image's lines (`stats/image.ts`'s numbers). */
function imageLines(s: ImageStats): StatLine[] {
  const lines: StatLine[] = [];
  if (s.width !== undefined && s.height !== undefined) {
    lines.push({ label: 'Size', value: `${s.width} × ${s.height}`, title: `${n(s.width * s.height)} pixels` });
    const pow2 = s.pow2 ?? (isPow2(s.width) && isPow2(s.height));
    const off = [s.width, s.height].filter((v) => !isPow2(v));
    lines.push({ label: 'Power of two', value: pow2 ? 'both sides' : `no: ${[...new Set(off)].join(' and ')}` });
  }
  lines.push({ label: 'Format', value: s.format });
  if (s.alpha !== undefined) lines.push({ label: 'Alpha', value: s.alpha ? 'yes' : 'no' });
  if (s.mips !== undefined) lines.push({ label: 'Mips', value: n(s.mips) });
  if (s.composite === false) lines.push({ label: 'Composite', value: 'none in the file', title: 'Saved without Maximize Compatibility: Photoshop\'s own flattened image is not in it' });
  return lines;
}

/** A sound's lines (`stats/audio.ts`'s numbers). */
function audioLines(s: AudioStats): StatLine[] {
  const lines: StatLine[] = [];
  if (s.duration !== undefined) lines.push({ label: 'Duration', value: seconds(s.duration) });
  if (s.channels !== undefined) lines.push({ label: 'Channels', value: s.channels === 1 ? '1 (mono)' : s.channels === 2 ? '2 (stereo)' : n(s.channels) });
  if (s.sampleRate !== undefined) lines.push({ label: 'Rate', value: `${n(s.sampleRate)} Hz` });
  lines.push({ label: 'Format', value: s.format });
  return lines;
}

/** The rows, by what `GET stats` read a file as. */
export const STATS: Readonly<Record<string, StatsRow>> = {
  model: { lines: (entry, stats) => (stats.stats ? modelLines(entry, stats.stats as ModelStats) : []) },
  image: { lines: (_entry, stats) => (stats.stats ? imageLines(stats.stats as ImageStats) : []) },
  audio: { lines: (_entry, stats) => (stats.stats ? audioLines(stats.stats as AudioStats) : []) },
};

/** The row for a file: a game's by its kind (`models`), else by what `GET stats` read it as (`model`); none for neither. */
export function statsRowFor(entry: Shown, stats: FileStats, table: Readonly<Record<string, StatsRow>> = STATS): StatsRow | undefined {
  const kind = kindOfRow(entry);
  return (kind !== undefined ? table[kind] : undefined) ?? table[stats.kind];
}

/** A share, as the line says it: "4%", "<1%". */
const share = (part: number, whole: number): string => {
  if (whole <= 0) return '';
  const p = (part / whole) * 100;
  return p > 0 && p < 1 ? '<1%' : `${Math.round(p)}%`;
};

/**
 * The bytes, from the index: a file's on disk; a source's export's beside it
 * and the share it is of the source; an export's source's. Nothing to wait for.
 */
export function bytesLines(entry: Shown, entries: ReadonlyMap<string, Entry>): StatLine[] {
  const disk: StatLine = { label: 'On disk', value: sayBytes(entry.size), title: `${n(entry.size)} bytes` };
  if (!isEntry(entry)) return [disk];
  if (entry.role === 'source') {
    const made = entry.exports?.[0] !== undefined ? entries.get(entry.exports[0]) : undefined;
    if (!made) return [disk];
    return [disk, { label: 'Export', value: `${sayBytes(made.size)}, ${share(made.size, entry.size)} of it`, title: `${baseName(made.path)}: ${n(made.size)} bytes -- what the game downloads` }];
  }
  if (entry.role === 'export' && entry.source !== undefined) {
    const from = entries.get(entry.source);
    if (from) return [disk, { label: 'Source', value: `${sayBytes(from.size)}: this is ${share(entry.size, from.size)} of it`, title: `${baseName(from.path)}: ${n(from.size)} bytes` }];
  }
  return [disk];
}

/**
 * What a file's stats are kept under: its content's hash where the index has
 * one (a source's), else its path with its size and mtime -- an export's, a
 * loose file's, a trashed one's -- so a file changed is read again.
 */
export const statsKey = (row: Shown): string => (isEntry(row) && row.hash !== undefined ? row.hash : `${row.path}@${contentStamp(row)}`);

/** What the cache has of a file: its stats, or still reading, or why none came. */
export type StatsState = FileStats | 'reading' | { failed: string };

export interface StatsCache {
  /**
   * `path`'s stats, kept under `key` -- its content hash, or for a trashed
   * file its path -- for the session: `'reading'` until `GET stats` answers,
   * `then` told once it has. A file not hashed yet (no `key`) is kept by its
   * path until the index brings its hash; one the server is still hashing
   * (`checking`) is kept as nothing and not told -- the index's next change
   * draws it again, and it is asked again then. A refusal is kept too: never a
   * loop of asking.
   */
  get(path: string, key: string | undefined, then: () => void): StatsState;
}

export function createStatsCache(api: Pick<Api, 'stats'>): StatsCache {
  const kept = new Map<string, FileStats | { failed: string }>();
  /** Asked and not answered, by path: each caller told when it is. */
  const asking = new Map<string, Array<() => void>>();
  return {
    get(path, key, then) {
      const slot = key ?? `at ${path}`;
      const had = kept.get(slot);
      if (had) return had;
      const waiting = asking.get(path);
      if (waiting) {
        waiting.push(then);
        return 'reading';
      }
      const told = [then];
      asking.set(path, told);
      api.stats(path).then(
        (answer) => {
          asking.delete(path);
          // Not hashed yet: nothing kept, nobody told -- asked again as the index's change draws it.
          if ('checking' in answer) return;
          kept.set(slot, answer);
          for (const fn of told) fn();
        },
        (err: unknown) => {
          asking.delete(path);
          kept.set(slot, { failed: err instanceof Error ? err.message : String(err) });
          for (const fn of told) fn();
        },
      );
      return 'reading';
    },
  };
}
