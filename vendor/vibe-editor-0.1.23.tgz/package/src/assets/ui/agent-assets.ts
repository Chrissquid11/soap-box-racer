/**
 * The Assets panel's edits run for Claude (Docs/mcp.md D2, M3): each asset write of the studio's tools, with a tab
 * open, is the panel's own step -- the same `Edit` its menu, its drag or its block makes (`file-steps.ts`,
 * `prefab-steps.ts`, `material-steps.ts`, `model-steps.ts`, `assets-options.ts`, `export-step.ts`), run on the same
 * queue onto the same history, so `Z` in the panel undoes Claude's change as it undoes the person's. Its label is the
 * person's with `Claude: ` before it.
 *
 * - **`createAgentRunner`**: runs an edit made against its `api` -- a recording of the panel's, every answer a first
 *   doing gets kept for the tool's facts -- and answers the step's label, or throws why not in the server's words
 *   (`reasonOf`). Nothing to do (`Unchanged`) is no step: `step: null`.
 * - **`AgentAssets`**: what the panel offers the page's asset tools (`mcp/assets.ts`), set by the panel as it is made
 *   (`useAgentAssets`), none until then -- the tools then answer `gone`, and the dev server runs them.
 *
 * Imports types alone but the steps' `Unchanged` and `reasonOf`: node tests it on a real history and steps with a
 * stand-in API (`agent-assets.test.ts`).
 */
import type { Api } from '../api.ts';
import { reasonOf, Unchanged, type Doing, type Steps } from '../steps.ts';
import type { PhysicsMaterialFile } from '@vibe/engine';
import type { Edit } from './file-steps.ts';

/** What an edit run for Claude came to: its step's label (null: nothing to do, no step), and every answer its first doing got. */
export interface AgentDone {
  step: string | null;
  answers: unknown[];
}

/** The prefix every step Claude makes is labelled with: the person's word for it after. */
export const CLAUDE = 'Claude: ';

export interface AgentRunner {
  /** The panel's API, recorded: the edits made for Claude are made against it. */
  readonly api: Api;
  /** `edit` as one step on the panel's queue, labelled `Claude: …`; throws why not. */
  run(edit: Edit): Promise<AgentDone>;
}

/**
 * A runner over the panel's `steps` and `api`. Each call of the recorded API made while an edit's first doing runs has
 * its answer kept for that run; its undo and redo, later, keep nothing.
 *
 * **Only the edit's own calls are kept**, with no tag on them, because of who calls the recorded API and when: it is
 * handed to nothing but the edits made for Claude (the panel's menu, drag and blocks call the panel's own `api`, never
 * this one), and those run only through `steps.run` -- one queue, one doing at a time, its undo and redo too -- so
 * while `current` is set the one caller of the recorded API is the first doing running now. A call it started and did
 * not wait for would be kept with it too; no edit does that (each awaits its API calls).
 */
export function createAgentRunner(steps: Pick<Steps, 'run'>, api: Api): AgentRunner {
  let current: unknown[] | null = null;
  const recorded = new Proxy(api, {
    get(target, name, receiver) {
      const value = Reflect.get(target, name, receiver) as unknown;
      if (typeof value !== 'function') return value;
      return (...args: unknown[]): unknown => {
        const out = (value as (...a: unknown[]) => unknown).apply(target, args);
        const keep = current;
        if (keep && out instanceof Promise) return out.then((answer: unknown) => (keep.push(answer), answer));
        return out;
      };
    },
  });
  return {
    api: recorded,
    async run(edit) {
      const answers: unknown[] = [];
      let reason: string | null = null;
      let unchanged = false;
      const first: Doing = async () => {
        current = answers;
        try {
          return await edit.first();
        } catch (err) {
          if (err instanceof Unchanged) unchanged = true;
          else reason = reasonOf(err);
          throw err;
        } finally {
          current = null;
        }
      };
      const label = `${CLAUDE}${edit.label}`;
      const named = edit.named ? (): string => `${CLAUDE}${edit.named!()}` : undefined;
      const pushed = await steps.run(label, first, { do: edit.redo, undo: edit.undo, ...(named ? { label: named } : {}) }, `${label} …`);
      if (pushed) return { step: named?.() ?? label, answers };
      if (unchanged) return { step: null, answers };
      throw new Error(reason ?? 'not done: an edit before it failed, or another model opened meanwhile');
    },
  };
}

/** A pipeline job an edit queued. */
export interface Queued {
  id: string;
  source: string;
}

/** What the Assets panel offers the studio's asset tools: each the panel's own flow, with no question asked. */
export interface AgentAssets {
  /** `paths` into the folder `to`, or one renamed to `name` -- refused as the panel refuses (code naming them, a wrong folder). */
  move(paths: readonly string[], to: string | null, name: string | null): Promise<AgentDone>;
  /** Copies into `to`, or beside each (a duplicate). */
  copy(paths: readonly string[], to: string | null): Promise<AgentDone>;
  /** To the trash: files, folders with all under them -- refused while a data file names any of it. */
  remove(paths: readonly string[]): Promise<AgentDone & { removed: string[] }>;
  /** A slot's files back, or some; into `to` if given. */
  restore(slot: string, paths: readonly string[] | null, to: string | null): Promise<AgentDone & { restored: string[] }>;
  /** Something new of `kind` in `folder` (null: the kind's own), named `name` (null: as the menu names it); `of` a variant's base. */
  make(kind: string, folder: string | null, name: string | null, of: string | null): Promise<AgentDone & { path: string; key: string | null; jobs: Queued[] }>;
  /** A source's options (`set` merged over its record's, `reset` first), a folder's defaults, a source in the build or out. */
  options(path: string, set: Readonly<Record<string, unknown>> | null, reset: boolean, include: boolean | null): Promise<AgentDone & { record: string; jobs: Queued[] }>;
  /** A source's export named `as` (null: its own stem) -- its record's `"as"`, as Rename the export… writes it. */
  exportAs(path: string, as: string | null): Promise<AgentDone & { record: string; as: string | null; moved: Array<[string, string]>; jobs: Queued[] }>;
  /** Make a script for it: a `.glb` delivered as it is made a Gladius script's export, its build waited for. */
  adopt(path: string): Promise<AgentDone & { script: string; copied: string | null; decoded: string[]; built: 'done' | 'failed' | null; jobs: Queued[] }>;
  /** A material's fields, as the Material block writes them. */
  material(key: string, set: Readonly<Record<string, unknown>>): Promise<AgentDone & { path: string }>;
  /** A physics material's fields, as the Physics material block writes them: its path and every field after. */
  physmat(key: string, set: Readonly<Record<string, unknown>>): Promise<AgentDone & { path: string; values: PhysicsMaterialFile }>;
  /** A prefab's pool and its root's components, as the Prefab block writes them. */
  prefab(key: string, edit: { pool?: { warm: number; max: number } | null; set?: Readonly<Record<string, Readonly<Record<string, unknown>>>>; add?: readonly string[]; remove?: readonly string[] }): Promise<AgentDone & { path: string; changed: string[] }>;
  /** An export, as E and Export all stale: answered as soon as its jobs are queued -- the step lands once they end. */
  exportSources(what: { paths: readonly string[] } | { under: string }, force: boolean): Promise<{ jobs: Queued[]; step: string | null }>;
}

let agentAssets: AgentAssets | null = null;

/** The panel, made: its edits for Claude (null as it goes). */
export function useAgentAssets(assets: AgentAssets | null): void {
  agentAssets = assets;
}

/** The panel's edits for Claude, or null: no Assets panel made in this tab -- the dev server runs the tool instead. */
export const assetsForAgent = (): AgentAssets | null => agentAssets;
