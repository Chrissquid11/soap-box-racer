/**
 * A sound's peaks drawn (Docs/assets-tool.md §6.2, §9): the inspector's
 * waveform with its cursor, and a tile's thumbnail -- the strip `thumbs.ts` is
 * handed, made from peaks at 256 columns (`STRIP_COLUMNS`) of the sound's
 * export, decoded offline (`preview/audio.ts`).
 *
 * - **Columns to peaks** (`columnPeaks`): a drawn column covers the peaks
 *   under it, its lowest and highest; a column narrower than a peak takes the
 *   peak under it, so a short sound still fills the strip.
 * - **A bar a column** (`barOf`), centred on the middle, at least a pixel
 *   tall: silence is a line, never nothing.
 * - **Where the cursor is** (`cursorX`), and the time a click lands on
 *   (`timeAt`): held to the strip's ends.
 * - **Colours handed in**: the editor's tokens (`--as-wave` in `assets.css`),
 *   read by the tool, never a literal here.
 *
 * The math is pure (`waveform.test.ts`); `drawWave` and `waveStrip` touch a
 * canvas only when called.
 */
import type { Peaks } from '../preview/audio.ts';

/**
 * `peaks` at `columns` across: column `i` takes the peaks from `i × n /
 * columns` up to the next column's start -- the lowest of their lows, the
 * highest of their highs -- and at least the one under it.
 */
export function columnPeaks(peaks: Peaks, columns: number): Peaks {
  const n = peaks.min.length;
  const count = Math.max(0, Math.floor(columns));
  const min = new Float32Array(count);
  const max = new Float32Array(count);
  if (n === 0) return { min, max };
  for (let i = 0; i < count; i++) {
    const from = Math.min(n - 1, Math.floor((i * n) / count));
    const to = Math.max(from + 1, Math.floor(((i + 1) * n) / count));
    let lo = Infinity;
    let hi = -Infinity;
    for (let p = from; p < to && p < n; p++) {
      if (peaks.min[p]! < lo) lo = peaks.min[p]!;
      if (peaks.max[p]! > hi) hi = peaks.max[p]!;
    }
    min[i] = lo;
    max[i] = hi;
  }
  return { min, max };
}

/** A column's bar in a strip `height` tall, its middle at `height / 2`: -1..1 to pixels, top down, at least one pixel. */
export function barOf(min: number, max: number, height: number): { top: number; bottom: number } {
  const half = height / 2;
  const clamp = (v: number): number => Math.max(-1, Math.min(1, Number.isFinite(v) ? v : 0));
  let top = half - clamp(max) * half;
  let bottom = half - clamp(min) * half;
  if (bottom - top < 1) {
    const middle = (top + bottom) / 2;
    top = middle - 0.5;
    bottom = middle + 0.5;
  }
  return { top, bottom };
}

/** Where the cursor is drawn for `at` seconds of a sound `duration` long, across `width` pixels: held to the ends. */
export function cursorX(at: number, duration: number, width: number): number {
  if (!(duration > 0) || !(width > 0)) return 0;
  return Math.max(0, Math.min(width, (at / duration) * width));
}

/** The second a press at `x` pixels across a strip `width` wide stands for: held to the sound. */
export function timeAt(x: number, width: number, duration: number): number {
  if (!(duration > 0) || !(width > 0)) return 0;
  return Math.max(0, Math.min(duration, (x / width) * duration));
}

/** What `drawWave` draws with. */
export interface WaveContext {
  fillStyle: string | CanvasGradient | CanvasPattern;
  clearRect(x: number, y: number, w: number, h: number): void;
  fillRect(x: number, y: number, w: number, h: number): void;
}

/** `peaks` drawn across `width` × `height` pixels of `ctx` (its own pixels, not CSS's), a bar a column, in `colour`. */
export function drawWave(ctx: WaveContext, peaks: Peaks, width: number, height: number, colour: string): void {
  ctx.clearRect(0, 0, width, height);
  const columns = columnPeaks(peaks, width);
  ctx.fillStyle = colour;
  for (let x = 0; x < columns.min.length; x++) {
    const { top, bottom } = barOf(columns.min[x]!, columns.max[x]!, height);
    ctx.fillRect(x, top, 1, bottom - top);
  }
}

/** A thumbnail's band: this share of the square, across its middle. */
export const STRIP_BAND = 0.56;

/**
 * A sound's tile (`thumbs.ts`'s `strip`): `peaks` across a square `size` on a
 * side, in a band through its middle, the rest clear -- a WebP (a PNG where
 * the browser cannot write one: `thumbs.ts` then keeps it unposted).
 */
export async function waveStrip(peaks: Peaks, size: number, colour: string): Promise<Blob> {
  const band = Math.max(2, Math.round(size * STRIP_BAND));
  const draw = (ctx: OffscreenCanvasRenderingContext2D | CanvasRenderingContext2D): void => {
    ctx.clearRect(0, 0, size, size);
    ctx.save();
    ctx.translate(0, Math.round((size - band) / 2));
    drawWave(ctx, peaks, size, band, colour);
    ctx.restore();
  };
  if (typeof OffscreenCanvas !== 'undefined') {
    const canvas = new OffscreenCanvas(size, size);
    draw(canvas.getContext('2d')!);
    return canvas.convertToBlob({ type: 'image/webp', quality: 0.9 });
  }
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  draw(canvas.getContext('2d')!);
  return new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('the strip could not be encoded'))), 'image/webp', 0.9));
}
