/**
 * The files card's banners (Docs/assets-tool.md §7): one sentence each, and
 * what to do -- at the top of the card, above everything it lists.
 *
 * - **Read mode**: another machine, or this one at Vite's Network URL. Every
 *   write control is absent, not disabled, and the keys that write are off;
 *   the address of the writable page is a button that opens it in a new tab --
 *   an `ed-button`, as an `<a>` would hold the focus where the keys' guard
 *   does not look.
 * - **Bundle view**: no dev server; only what the build bundled, read-only.
 * - **The server gone**: `live.ts`'s `offline`; Vite's client reloads the page
 *   when it is back.
 * - **A call that failed** for want of an answer, after `online` was decided.
 */
import type { Online } from '../api.ts';
import { button, el } from '../../shell.ts';

export interface Banners {
  readonly root: HTMLElement;
  /** What is so just now: may this page write, has the server gone, did a call go unanswered. */
  set(state: { online: Online | null; offline: boolean; unanswered: boolean }): void;
}

/** The page as this machine's own, where it may write: `localhost`, the same port and path. */
export function writableUrl(): string {
  return `${location.protocol}//localhost:${location.port}${location.pathname}`;
}

export function createBanners(): Banners {
  const root = el('div', 'ed-as-banners');
  let drawn = '';
  return {
    root,
    set({ online, offline, unanswered }) {
      const key = JSON.stringify([online, offline, unanswered]);
      if (key === drawn) return;
      drawn = key;
      root.replaceChildren();
      if (offline) {
        root.append(el('div', 'ed-as-banner ed-as-bad',
          'The dev server stopped answering: the page reloads when it is back -- an unsaved scene asks first, as on any reload: Save (Mod+S) now if it matters.'));
      } else if (unanswered) {
        root.append(el('div', 'ed-as-banner ed-as-bad', 'The dev server did not answer: is npm run dev still running?'));
      }
      if (online === 'read') {
        const line = el('div', 'ed-as-banner');
        const url = writableUrl();
        line.append(
          'Read-only: only the machine running the dev server can change the project -- if this is that machine, open ',
          button('ui', url, 'Open the writable page in a new tab', () => void window.open(url, '_blank', 'noopener'), 'ed-small ed-as-link'),
          ' instead.',
        );
        root.append(line);
      } else if (online === false) {
        root.append(el('div', 'ed-as-banner', 'What the build bundled: start npm run dev to change it.'));
      }
      root.hidden = root.childElementCount === 0;
    },
  };
}
