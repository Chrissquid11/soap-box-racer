/**
 * The Assets panel's files, its right-hand column (Docs/assets-tool.md §4):
 * the open folder's folders, then its files -- every entry but a record, which
 * is shown as options, never as a file -- as a list with columns or a grid of
 * tiles (`G`, or the control on the title row), kept with the preferences.
 * Both are `virtual.ts`'s `mount`, keeping elements by path.
 *
 * - **The title row** (`head`, placed by the tool across the panel's top): the
 *   folder as a breadcrumb from the project, each part a button that opens
 *   it; grid or list; **Issues** (`Shift+I`), lit while on, with how many; the
 *   tiles' size (`[`, `]`) or the list's columns; the sort; the search
 *   (`Mod+F`); **Import ▾** (Files…, Folder…, Paste image), where this page
 *   may write.
 * - **The panel's height** (`frame`, the panel the column is in): its grip
 *   (`ed-as-grip`, placed by the tool on the panel's top edge), dragged with
 *   pointer capture as a side card's grip is, held between a row of tiles
 *   (160 px in the list) and half the window (`stripHeightFor`), a
 *   double-click back to 240, kept as `stripHeight`; the tiles drawn at the
 *   largest size a row of fits (`stripTile`).
 * - **A tile or a row is dragged** (`draggable`, where this page may write):
 *   the tool's `dnd.ts` carries it to a folder. A folder's tile and row, and
 *   the card itself, are where a drop lands.
 * - **A name made a field where it is** (`editName`): the tile's name, the
 *   row's -- the rename field (`rename-field.ts`) beside the name it hides; a
 *   new folder's at the top of the card (`newFolder`).
 * - **A row or a tile** says its name and its mark (`marks.ts`) -- a spinner
 *   while a job runs on it, the struck key while it is out of the build -- and,
 *   in the list, the columns ticked (`FILE_COLUMNS`, one grid for the header
 *   and every row, `fileGrid`): Build's a tick a click flips (`flipBuild`), that
 *   row alone, where this page may write. A
 *   folder's says what it holds after its name, "audio · 1.2 MB" -- on the
 *   Source side "models · 12 files" (`sizeSaid`) -- and in the list's Size.
 * - **Made once, patched after**: a tile's or a row's parts are made as it
 *   first comes into view, and an update writes only what changed -- its
 *   name, its size, its mark, its selection -- so a tile's thumbnail element
 *   outlives a click and a job's message. A job patches its family's marks
 *   alone (`patch`, §9): nothing else in the card is touched.
 * - **A click only selects** (`clickHow`, through `files-selection.ts`); a
 *   double-click -- read off the second click's `detail`, as the tree reads its
 *   own -- opens: a folder here, a file in the application the machine opens
 *   it with (in read mode, the preview, as Enter does).
 * - **The search** (`file-filter.ts`) makes the card one flat list of the
 *   open folder and everything under it -- from the project, every root and
 *   the Trash; every folder, with `#` -- with a Folder column whose cell opens
 *   the folder that lists the file (`folderOf`: a trashed one's slot) with it
 *   chosen. **Issues** makes it one too, of what needs a hand under the open
 *   folder (`issuesOf`, the folder's count listed), a search typed narrowing
 *   it: both must hold. Kept with the preferences.
 * - **The project** (`''`): its roots and the Trash as folder tiles, in the
 *   tree's order, the roots in the tree's two groups -- a label over each
 *   group's tiles, Not shipped and Shipped (`groupLabels`); a drop on it is
 *   refused, said where it would go.
 * - **The status line**, the card's last: the folder's count at rest; while a
 *   drag passes or a name is a field, what a drop would do or the uses line
 *   (`note`); what was just done, or refused, for a few seconds; the jobs
 *   strip above it.
 * - **An empty folder says what to do**: "Drop files here, or" Files… and
 *   Folder….
 * - **A tile's thumbnail** (`thumbs.ts`, §9): the format's icon until it is
 *   made, then its picture, drawn as `onReady` tells of it -- that tile alone.
 *   What is made first is the card's to say (`thumbOrder`): what is chosen,
 *   then the tiles in view, then the rest of the folder; the tool asks the
 *   queue again on a scroll, a choice, a new folder, once a frame.
 * - **A box over the grid** (the marquee): a press on the grid's empty space
 *   draws one, `ed-marquee`'s look, an element in the list so it scrolls with
 *   the tiles -- the list scrolling while the pointer is near its top or
 *   bottom -- and let go, every tile under it, those not drawn included
 *   (`tilesIn`, from the geometry), goes into the selection as `boxHow` says.
 *   A press on a tile is a drag instead.
 */
import { keyLabel } from '@vibe/engine/debug';
import type { Entry } from '@vibe/pipeline/assets-types';
import { TRASH } from '@vibe/pipeline/kinds';
import { baseName, extOf, under } from '@vibe/pipeline/paths';
import { STRIP_HEIGHT, STRIP_MIN, stripHeightFor, THUMBS, type AssetsPrefs } from '../../prefs.ts';
import { boxHow, clickHow, type Combine } from '../../selection.ts';
import { button, control, el, icon, iconButton } from '../../shell.ts';
import { dropUnder } from '../../drop.ts';
import { itemsOf, mount, range, type Mounted } from '../../virtual.ts';
import { PROJECT, trashFiles, type ClientIndex, type Shown } from '../model.ts';
import type { Thumbs, ThumbWant } from '../preview/thumbs.ts';
import type { Banners } from './banners.ts';
import { sayBytes, sizeSaid, type FolderSizes } from './budget.ts';
import { factsOf, passes, readQuery, searched, type Query } from './file-filter.ts';
import { columnsOf, fileGrid, flipColumn, gridLayout, groupLabels, isFolder, NOTHING, sortEntries, stripMin, stripTile, thumbSize, TILE_BAND, tileAt, tilesIn, wantOrder, type FileColumn, type GridLayout, type GroupLabel, type Listed } from './files-columns.ts';
import { clickOnPath, folderOf, folderTakes, isFolderPath, NO_PATHS, type PathSelection } from './files-selection.ts';
import { COLOUR_CLASS, excludedText, folderMark, isEntry, issuesOf, markOf, total, type FolderCounts, type Shows } from './marks.ts';
import { filesText, type Naming } from './naming.ts';

/** A list row's height, in CSS pixels. */
const ROW = 26;
/** A press moved this far, in CSS pixels, before it is a box: less is a click. */
const BOX_SLOP = 4;
/** The marquee scrolls the list while the pointer is this near its top or bottom, in CSS pixels; at most this fast, pixels a frame. */
const BOX_EDGE = 32;
const BOX_SPEED = 18;
/** How long a line of what was done stays on the status line, in milliseconds. */
const SAID = 6000;
/** Typing in the search waits this long for the next key, in milliseconds. */
const DEBOUNCE = 100;

const SORT_NAMES: Record<AssetsPrefs['sort']['by'], string> = { name: 'Name', status: 'Status', size: 'Size', modified: 'Modified', kind: 'Kind' };

/** The menus the files card asks for. */
/** A file's icon on its tile and its row: a scene's own (its file is a world), any other the page's. */
const fileIcon = (path: string): 'scenes' | 'file' => (extOf(path) === 'scene' ? 'scenes' : 'file');

export type FilesMenu = { kind: 'row'; path: string } | { kind: 'space' } | { kind: 'sort' };

/** A mark as a tile or a row shows it: a status's, or a spinner while a job runs on its family. */
type RowMark = Shows | { spin: true; title: string };

/**
 * `slot` -- a mark's own span, made once -- showing `mark`, or hidden for none:
 * written only where it differs, so a job's message that leaves a mark as it
 * was touches nothing.
 */
function putMark(slot: HTMLElement, mark: RowMark | null, base: string): void {
  const cls = mark === null ? base : 'spin' in mark ? `${base} ed-as-spin` : `${base} ${COLOUR_CLASS[mark.colour]}${mark.struck ? ' ed-as-struck' : ''}`;
  const text = mark === null || 'spin' in mark ? '' : mark.glyph;
  const title = mark?.title ?? '';
  if (slot.className !== cls) slot.className = cls;
  if (slot.textContent !== text) slot.textContent = text;
  if (slot.title !== title) slot.title = title;
  if (slot.hidden !== (mark === null)) slot.hidden = mark === null;
}

/** `node` says `text`, with `title`: written only where it differs. */
function put(node: HTMLElement, text: string, title?: string): void {
  if (node.textContent !== text) node.textContent = text;
  if (title !== undefined && node.title !== title) node.title = title;
}

/** What the files card asks of the tool. */
export interface FilesHost {
  readonly index: ClientIndex;
  readonly naming: Naming;
  readonly counts: FolderCounts;
  /** Every folder's size, kept as files change: what a folder's tile and row say it holds. */
  readonly sizes: FolderSizes;
  /** Every column there is: `FILE_COLUMNS`, and a game's. */
  readonly columns: readonly FileColumn[];
  readonly banners: Banners;
  /** The jobs strip's element, above the status line. */
  readonly strip: HTMLElement;
  prefs(): AssetsPrefs;
  keep(change: Partial<AssetsPrefs>): void;
  /** The folder open. */
  folder(): string;
  selection(): PathSelection;
  select(selection: PathSelection): void;
  /** A folder opened -- a breadcrumb, a folder row, a Folder cell -- `then` chosen in it. */
  open(folder: string, then?: string): void;
  /** A file double-clicked: opened on the machine, or previewed in read mode. */
  openFile(path: string): void;
  /** A file shown chosen in the folder that lists it, its tab up: a link cell's (the Twin's), as the inspector's twin link. */
  reveal(path: string): void;
  /** A menu at a point: a row's (the selection's), the empty space's, the sort's. */
  menu(what: FilesMenu, at: { x: number; y: number }, byKey: boolean): void;
  /** May this page write: the write controls are absent where not. */
  writes(): boolean;
  /** Is a job queued or running on this source? */
  running(source: string): boolean;
  /** The search changed: the hint reads again. */
  changed(): void;
  /** Import ▾ pressed: its menu under it. */
  importMenu(at: HTMLElement): void;
  /** The panel the column is in: its height is the grip's (`--ed-strip`, `stripHeight`), measured round the list. */
  readonly frame: HTMLElement;
  /** Is the panel folded to a tab: its height then is not the grip's, and nothing is measured. */
  folded(): boolean;
  /** The pickers: files, a folder -- for the open folder. */
  importFiles(): void;
  importFolder(): void;
  /** A tile's or a row's drag begins. */
  dragStart(event: DragEvent, path: string): void;
  /** A row's Build tick clicked: `paths` put in the build (`on`) or left out, one step. */
  flipBuild(paths: readonly string[], on: boolean): void;
  /** The thumbnails: a tile reads `known` and `url`, and is drawn again as its own is ready. */
  readonly thumbs: Pick<Thumbs, 'url' | 'known' | 'onReady'>;
  /** What a path's tile wants made at a size, or null for none to be had: a folder, a `.lua` not exported. */
  thumbOf(path: string, size: number): ThumbWant | null;
  /** The order changed -- the folder, a choice, the tiles' size -- the queue asked again, once a frame. */
  wantThumbs(): void;
  /** The grid scrolled -- `moved` onto other rows: what is made held while it scrolls, the queue asked again as the rows in view change. */
  scrolled(moved: boolean): void;
  /** A box let go over the grid: the paths under it, as `boxHow` says. */
  boxed(paths: readonly string[], how: Combine): void;
}

export interface Files {
  readonly card: HTMLElement;
  /** The title row: lit while the card has the focus. */
  readonly head: HTMLElement;
  /** The rows read again -- the folder, the index, the sort, the search -- and drawn the next frame. */
  refresh(): void;
  /** Drawn again as they are: the selection, or several marks (`GET jobs`). Each item patched, what changed alone. */
  redraw(): void;
  /** A job's message: the marks of `source`'s family -- itself and its exports -- patched where they are drawn, nothing else. Answers how many were. */
  patch(source: string): number;
  /** What is listed, in order: folders, then files. */
  shown(): readonly string[];
  /** Is a search up, and what it found? */
  readonly query: Query | null;
  /** Issues on, or off: kept, the card drawn again flat or as the folder is. */
  setIssues(on: boolean): void;
  /** The search cleared and Issues off: what was just made or imported is to be seen. */
  showAll(): void;
  readonly found: number;
  /** The folder's count, or the search's: the status line at rest. */
  readonly counted: string;
  /** Rows a page holds; tiles a row. */
  readonly page: number;
  readonly perRow: number;
  /** An item's element, if it is drawn: where the menu key puts the menu. */
  element(path: string): HTMLElement | undefined;
  /** `path` in view: only just, or in the middle. */
  reveal(path: string, middle?: boolean): void;
  /** The search field focused, its words selected. */
  focusSearch(): void;
  clearSearch(): void;
  /** Grid or list. */
  setView(view: AssetsPrefs['view']): void;
  /** The tiles a size larger (1) or smaller (-1). */
  resize(by: 1 | -1): void;
  /** A line on the status line for a few seconds: what was done, or why not. */
  say(text: string, bad?: boolean): void;
  /** Is a drop-down of its own down -- the columns? Esc puts it up (`shut`). */
  readonly dropped: boolean;
  shut(): void;
  /** A line held on the status line -- a drag's, a rename's uses -- until null; what was just done still shows over it. */
  note(text: string | null, bad?: boolean): void;
  /** `field` in place of `path`'s name, its tile or row brought into view; false if it is not listed. Taken away by `endEdit`. */
  editName(path: string, field: HTMLElement): boolean;
  endEdit(): void;
  /** A new folder's field at the top of the card -- or none. */
  newFolder(field: HTMLElement | null): void;
  /** The body the import sheet and the drops are over. */
  readonly body: HTMLElement;
  /** The thumbnails to make, in order: `first` (the preview's own), what is chosen, the tiles in view, the rest of the folder -- none in the list but `first`. */
  thumbOrder(first?: readonly ThumbWant[]): ThumbWant[];
  /** The thumbnail size the tiles draw now, by their size and the screen's pixels. */
  readonly thumbSize: number;
  /** The panel's top edge, to drag: the tool places it. */
  readonly grip: HTMLElement;
  /** The panel as tall as kept, held to this window and a row of tiles: after it unfolds, or the view changes. */
  place(): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}

export function createFiles(parent: HTMLElement, host: FilesHost): Files {
  const { index, naming, frame } = host;
  const card = el('div', 'ed-as-files');

  // ---------------------------------------------------------------- the title row

  const head = el('div', 'ed-as-files-head ed-as-head');
  const crumbs = el('div', 'ed-as-crumbs');
  const viewSegments = el('span', 'ed-segments ed-as-view');
  const gridButton = control('ui', 'ed-segment');
  gridButton.append(icon('grid'));
  gridButton.title = `The files as tiles (${keyLabel('KeyG')})`;
  gridButton.addEventListener('click', () => setView('grid'));
  const listButton = control('ui', 'ed-segment');
  listButton.append(icon('list'));
  listButton.title = `The files as a list with columns (${keyLabel('KeyG')})`;
  listButton.addEventListener('click', () => setView('list'));
  viewSegments.append(gridButton, listButton);
  // Issues: only what needs a hand under the open folder, flat -- lit while on, its label how many.
  const issuesButton = control('ui', 'ed-button ed-small ed-as-issues');
  issuesButton.addEventListener('click', () => setIssues(!host.prefs().issues));
  const sizes = el('span', 'ed-segments ed-as-sizes');
  const sizeButtons = THUMBS.map((size) => {
    const b = control('ui', 'ed-segment', String(size));
    b.title = `Tiles ${size} pixels square (${keyLabel('BracketLeft')} smaller, ${keyLabel('BracketRight')} larger)`;
    b.addEventListener('click', () => {
      host.keep({ thumb: size });
      remount();
    });
    sizes.append(b);
    return { size, b };
  });
  const sortButton = control('ui', 'ed-button ed-small ed-as-sort');
  sortButton.setAttribute('aria-haspopup', 'menu');
  sortButton.addEventListener('click', () => {
    const r = sortButton.getBoundingClientRect();
    host.menu({ kind: 'sort' }, { x: r.left, y: r.bottom + 4 }, false);
  });
  const chooser = iconButton('ui', 'columns', 'Columns: which the list shows, past the name', () => (chooserDown ? shut() : showChooser()));
  chooser.setAttribute('aria-haspopup', 'true');
  const search = el('input', 'ed-input ed-as-search');
  search.type = 'search';
  search.placeholder = 'Search this folder and below; #key everywhere';
  search.title = `${keyLabel('Mod+KeyF')}. Words search this folder and every folder under it: a name, a key or a twin's name must hold each; status:stale, kind:models, role:source, ext:png. #crate is a key holding crate, in every folder`;
  search.spellcheck = false;
  const importButton = control('ui', 'ed-button ed-small ed-as-import', 'Import ▾');
  importButton.title = `Import files into this folder: Files… (${keyLabel('KeyI')}), Folder…, Paste image -- or drop them on it`;
  importButton.setAttribute('aria-haspopup', 'menu');
  importButton.addEventListener('click', () => host.importMenu(importButton));
  const tools = el('span', 'ed-as-files-tools');
  tools.append(viewSegments, issuesButton, sizes, sortButton, chooser, search, importButton);
  head.append(crumbs, tools);

  // ---------------------------------------------------------------- the list

  const heads = el('div', 'ed-rows-head ed-as-heads');
  const list = el('div', 'ed-rows ed-as-list');
  const empty = el('div', 'ed-as-empty');
  empty.hidden = true;
  const status = el('div', 'ed-status ed-as-status');
  const body = el('div', 'ed-as-body');
  /** A new folder's field, at the top: named in place. */
  const fresh = el('div', 'ed-as-new-folder');
  fresh.hidden = true;
  body.append(fresh, heads, list, empty);
  /** The panel's top edge, to drag: the tool places it there. */
  const grip = el('div', 'ed-as-grip');
  grip.title = 'Drag to make the Assets panel taller or shorter; double-click for 240 px';
  card.append(host.banners.root, body, host.strip, status);
  parent.append(card);

  let listed: Listed[] = [];
  let paths: string[] = [];
  /** The project's tiles' groups, as the tree's sections have them -- a root's section, the Trash's none; empty in any other folder. */
  let groups: (string | null)[] = [];
  /** The label over each tile, by its index, for the grid as it is laid out now: worked out as the rows or the width change. */
  let labels: (GroupLabel | null)[] = [];
  let query: Query | null = null;
  let layout: GridLayout = gridLayout(600, 128, 0);
  let columns: FileColumn[] = [];
  let mounted: Mounted | null = null;
  /** What the status line says just now, and until when. */
  let said = '';
  let saidBad = false;
  /** A line held -- a drag's, a rename's -- under what was just done. */
  let noted: { text: string; bad: boolean } | null = null;
  /** The name made a field: whose, and the name element it hides. */
  let editing: { path: string; field: HTMLElement; hidden: HTMLElement | null } | null = null;
  let quiet: ReturnType<typeof setTimeout> | undefined;
  let typing: ReturnType<typeof setTimeout> | undefined;

  const entries = (): ReadonlyMap<string, Entry> => index.entries;
  const pathOf = (row: Listed): string => (isFolder(row) ? row.folder : row.path);
  /** Issues on: what needs a hand alone, flat. */
  const issuesOn = (): boolean => host.prefs().issues;
  /** One flat list -- a search's, the Issues' -- with a Folder column, rather than the open folder's own. */
  const flat = (): boolean => query !== null || issuesOn();
  /** Where Issues look: under the open folder -- everywhere with `#`, which opens none. */
  const issuesScope = (): string => (query?.everywhere ? PROJECT : host.folder());

  /** The rows, from the index: the open folder's -- or, flat, the search's and the Issues', both holding where both are up. */
  function read(): void {
    const prefs = host.prefs();
    const folder = host.folder();
    columns = columnsOf(prefs.columns, host.columns);
    let rows: Listed[];
    if (flat()) {
      const q = query;
      const pool: Shown[] = issuesOn()
        ? issuesOf(index.entries, issuesScope())
        : searched(index.entries.values(), index.trash.flatMap(trashFiles), folder, q?.everywhere ?? false);
      rows = q ? pool.filter((row) => passes(q, factsOf(row, entries()))) : pool;
    } else {
      const children = index.childrenOf(folder);
      // The project's folders, the roots and the Trash, in the tree's order: never sorted by name.
      if (folder === PROJECT) rows = naming.roots.filter((r) => children.folders.includes(r)).map((f) => ({ folder: f }));
      else rows = [...children.folders.map((f) => ({ folder: f })), ...children.files.filter((f) => !isEntry(f) || f.role !== 'record')];
    }
    listed = folder === PROJECT && !flat() ? rows : sortEntries(rows, prefs.sort.by, prefs.sort.down, entries());
    paths = listed.map(pathOf);
    groups = folder === PROJECT && !flat() ? paths.map((path) => naming.sectionOf(path)?.title ?? null) : [];
  }

  /** The room over each row of tiles for the groups' labels: the project's, in the grid. */
  const bandNow = (): number => (groups.length > 0 ? TILE_BAND : 0);

  // ---------------------------------------------------------------- the title row, drawn

  /** How many a flat list holds, said: "12 found", or with Issues alone "12 need a hand". */
  const foundText = (): string => (query ? `${listed.length} found` : `${listed.length} ${listed.length === 1 ? 'needs' : 'need'} a hand`);

  function drawHead(): void {
    const prefs = host.prefs();
    const folder = host.folder();
    crumbs.replaceChildren();
    if (query?.everywhere) {
      crumbs.append(el('span', 'ed-as-crumb-now', `${search.value.trim()} · ${foundText()}`));
    } else {
      const parts = naming.crumbs(folder);
      parts.forEach((part, i) => {
        if (i > 0) crumbs.append(el('span', 'ed-as-crumb-sep', '›'));
        const last = i === parts.length - 1;
        const b = control('ui', last && !flat() ? 'ed-as-crumb ed-as-crumb-now' : 'ed-as-crumb', part.text);
        b.title = last ? naming.say(part.path) : `Open ${naming.say(part.path)}${i === parts.length - 2 ? ` (${keyLabel('Mod+ArrowUp')})` : ''}`;
        b.addEventListener('click', () => {
          if (query) clearSearch();
          host.open(part.path);
        });
        crumbs.append(b);
      });
      if (flat()) crumbs.append(el('span', 'ed-as-crumb-now', ` · ${foundText()}`));
    }
    // Issues: lit while on; how many under the open folder -- the folder's own count (`marks.ts`), which the list is as long as.
    const issues = total(host.counts.of(issuesScope()));
    put(issuesButton, issues > 0 ? `Issues · ${issues}` : 'Issues', issuesOn()
      ? `Only what needs a hand under ${naming.say(issuesScope())}, a search typed narrowing it -- ${keyLabel('Shift+KeyI')}: every file again`
      : `Only what needs a hand under ${naming.say(issuesScope())}: stale, missing, failed, unmade, a conflict, an LFS pointer -- never what is out of the build -- flat, with each one's folder (${keyLabel('Shift+KeyI')})`);
    issuesButton.setAttribute('aria-pressed', String(issuesOn()));
    // The project's search is the whole project's.
    const placeholder = folder === PROJECT ? 'Search the whole project; #key' : 'Search this folder and below; #key everywhere';
    if (search.placeholder !== placeholder) search.placeholder = placeholder;
    gridButton.setAttribute('aria-pressed', String(prefs.view === 'grid'));
    listButton.setAttribute('aria-pressed', String(prefs.view === 'list'));
    for (const { size, b } of sizeButtons) b.setAttribute('aria-pressed', String(size === prefs.thumb));
    sizes.hidden = prefs.view !== 'grid';
    sortButton.hidden = prefs.view !== 'grid';
    sortButton.textContent = `${SORT_NAMES[prefs.sort.by]} ${prefs.sort.down ? '↓' : '↑'}`;
    sortButton.title = `Sorted by ${SORT_NAMES[prefs.sort.by].toLowerCase()}${prefs.sort.down ? ', the other way' : ''}: click for another, folders always first`;
    chooser.hidden = prefs.view !== 'list';
    heads.hidden = prefs.view !== 'list';
    // Where this page may write, and a folder takes imports -- not the Trash, not Packs or its sources' home: no control that does nothing.
    importButton.hidden = !host.writes() || !folderTakes(folder).import;
    if (prefs.view === 'list') drawHeads();
  }

  /** The list's header: the column names, a click on one sorts by it (again, the other way). */
  function drawHeads(): void {
    const prefs = host.prefs();
    const sortable = (name: string): AssetsPrefs['sort']['by'] | null =>
      name === 'name' || name === 'status' || name === 'size' || name === 'modified' || name === 'kind' ? name : null;
    const cell = (text: string, title: string, sorts: AssetsPrefs['sort']['by'] | null, numeric = false): HTMLElement => {
      const c = el('span', numeric ? 'ed-as-num' : undefined, text);
      c.title = title;
      if (sorts) {
        c.classList.add('ed-as-sortable');
        if (prefs.sort.by === sorts) c.textContent = `${text} ${prefs.sort.down ? '↓' : '↑'}`;
        // mcp: ui -- the list sorted by a column
        c.addEventListener('click', () => {
          const now = host.prefs().sort;
          host.keep({ sort: { by: sorts, down: now.by === sorts ? !now.down : false } });
          refresh();
        });
      }
      return c;
    };
    card.style.setProperty('--ed-columns', fileGrid(columns, flat()));
    heads.replaceChildren(
      cell('Name', 'Its name: folders first, always', 'name'),
      ...(flat() ? [cell('Folder', 'Where it is: a click opens that folder with it chosen', null)] : []),
      ...columns.map((c) => {
        const head = cell(c.title, c.help, sortable(c.name), c.numeric);
        if (c.tick) head.classList.add('ed-as-tick-cell');
        return head;
      }),
    );
  }

  // ---------------------------------------------------------------- rows and tiles

  /** A tile's parts, made once: what `update` patches. */
  interface TileParts {
    mark: HTMLElement;
    /** The name's line: what a rename field stands in for. */
    name: HTMLElement;
    /** A folder's: its name, and what it holds after it (" · 1.2 MB"). */
    label: HTMLElement | null;
    held: HTMLElement | null;
    size: HTMLElement | null;
    /** The format's icon and extension, until the picture is there. */
    glyph: HTMLElement | null;
    /** Its picture, made once the first is ready. */
    image: HTMLImageElement | null;
    /** The label over it and the tiles of its group beside it, in the project: made as it first has one. */
    group: HTMLElement | null;
  }
  /** A row's parts, made for one set of columns (`shape`): made again only when the columns change. */
  interface RowParts {
    shape: string;
    name: HTMLElement;
    nameMark: HTMLElement;
    where: HTMLButtonElement | null;
    cells: { cell: HTMLElement; mark: HTMLElement; text: HTMLElement; box: HTMLInputElement | null; link: HTMLButtonElement | null }[];
  }
  const tileParts = new WeakMap<HTMLElement, TileParts>();
  const rowParts = new WeakMap<HTMLElement, RowParts>();
  /** When a link cell was last followed (`event.timeStamp`), and how long the clicks of its double-click are its own. */
  let linkedAt = -Infinity;
  const LINK_SETTLE = 600;
  /** The list's columns as they are now, and whether a flat list's Folder column is among them: what a row's parts are made for. */
  const shapeNow = (): string => `${flat() ? 'found|' : ''}${columns.map((c) => c.name).join(',')}`;

  /** A row or a tile, its handlers reading its path off the element; its parts made for what it shows. */
  function make(i: number): HTMLElement {
    const grid = host.prefs().view === 'grid';
    const row = listed[i]!;
    const item = el('div', grid ? 'ed-as-tile' : 'ed-row ed-as-row');
    item.dataset.path = pathOf(row);
    // mcp: ui -- the Assets panel's selection; opening is the double-click's, each kind its own tab
    item.addEventListener('click', (event) => {
      // A click in the rename field is the field's.
      if (editing && editing.field.contains(event.target as Node)) return;
      // A double-click's second click on the row a link just brought under the pointer: the link's, not a choice or an open.
      if (event.detail > 1 && event.timeStamp - linkedAt < LINK_SETTLE) return;
      const path = item.dataset.path!;
      const how = clickHow(event, true);
      host.select(clickOnPath(host.selection(), path, how, paths));
      if (event.detail === 2 && how === 'one') {
        if (isFolderPath(index, path)) host.open(path);
        else host.openFile(path);
      }
    });
    item.addEventListener('contextmenu', (event) => {
      if (editing && editing.field.contains(event.target as Node)) return;
      event.preventDefault();
      event.stopPropagation();
      const path = item.dataset.path!;
      if (!host.selection().paths.includes(path)) host.select(clickOnPath(host.selection(), path, 'one', paths));
      host.menu({ kind: 'row', path }, { x: event.clientX, y: event.clientY }, false);
    });
    // A press on a tile is a drag (§4): of the selection if it is in it, else of it alone.
    item.addEventListener('dragstart', (event) => {
      // Not the rename field's text being dragged.
      if (editing && item.contains(editing.field) && editing.field.contains(event.target as Node)) return;
      host.dragStart(event, item.dataset.path!);
    });
    if (grid) makeTile(item, row);
    return item;
  }

  function makeTile(item: HTMLElement, row: Listed): void {
    const folder = isFolder(row);
    item.style.setProperty('--ed-thumb', `${side}px`);
    const thumb = el('div', 'ed-as-thumb');
    // The format's icon until its thumbnail is made: the picture goes in beside it, and the icon hides.
    let glyph: HTMLElement | null = null;
    if (folder) thumb.append(icon('folder'));
    else {
      glyph = el('span', 'ed-as-glyph');
      glyph.append(icon(fileIcon(pathOf(row))), el('span', 'ed-as-ext', extOf(pathOf(row)).toUpperCase() || '?'));
      thumb.append(glyph);
    }
    const mark = el('span', 'ed-as-mark ed-as-corner');
    mark.hidden = true;
    thumb.append(mark);
    const name = el('div', folder ? 'ed-as-tile-name ed-as-tile-folder' : 'ed-as-tile-name');
    // A folder's name and, after it, what it holds: the name cut short first.
    let label: HTMLElement | null = null;
    let held: HTMLElement | null = null;
    if (folder) name.append((label = el('span', 'ed-as-tile-label')), (held = el('span', 'ed-as-tile-held')));
    item.append(thumb, name);
    let size: HTMLElement | null = null;
    if (side >= 128 && !folder) item.append((size = el('div', 'ed-as-tile-size')));
    tileParts.set(item, { mark, name, label, held, size, glyph, image: null, group: null });
  }

  /** The cells of a row, for the columns as they are now. */
  function makeRow(item: HTMLElement, row: Listed): RowParts {
    const folder = isFolder(row);
    const name = el('span', 'ed-as-name');
    const label = el('span', folder ? 'ed-name ed-as-folder-name' : 'ed-name');
    const nameMark = el('span', 'ed-as-mark');
    nameMark.hidden = true;
    name.append(icon(folder ? 'folder' : fileIcon(pathOf(row))), label, nameMark);
    const cells: HTMLElement[] = [name];
    let where: HTMLButtonElement | null = null;
    if (flat()) {
      where = control('ui', 'ed-as-link');
      // mcp: ui -- a search hit's folder shown
      where.addEventListener('click', (event) => {
        event.stopPropagation();
        const at = item.dataset.path!;
        clearSearch();
        host.open(folderOf(at), at);
      });
      cells.push(where);
    }
    const parts: RowParts = { shape: shapeNow(), name: label, nameMark, where, cells: [] };
    for (const column of columns) {
      const cell = el('span', column.numeric ? 'ed-as-num' : column.tick ? 'ed-as-cell ed-as-tick-cell' : 'ed-as-cell');
      const mark = el('span', 'ed-as-mark');
      mark.hidden = true;
      const text = el('span');
      // A tick's column: a tick a click flips -- that row alone, never the selection the click would make.
      let box: HTMLInputElement | null = null;
      if (column.tick) {
        box = el('input', 'ed-as-tick');
        box.type = 'checkbox';
        box.hidden = true;
        // mcp: ui -- the build box's click kept from the row (its change is asset_options's)
        box.addEventListener('click', (event) => event.stopPropagation());
        // mcp: ui -- the same, for a double-click
        box.addEventListener('dblclick', (event) => event.stopPropagation());
        const flip = box;
        flip.addEventListener('change', () => {
          const on = flip.checked;
          // Drawn as the index has it until the step's answer moves it: a refusal leaves it as it was.
          flip.checked = !on;
          host.flipBuild([item.dataset.path!], on);
        });
      }
      // A link's column: its text a link where the row has one (`Cell.link`) -- its click shows that file, never the
      // row's: no choosing, no opening, no double-click. Out of the tab order: the list's keys stay the list's.
      let link: HTMLButtonElement | null = null;
      if (column.link) {
        const go = (link = control('ui', 'ed-as-link'));
        go.tabIndex = -1;
        go.hidden = true;
        go.addEventListener('click', (event) => {
          event.stopPropagation();
          if (event.detail > 1 || !go.dataset.path) return;
          linkedAt = event.timeStamp;
          host.reveal(go.dataset.path);
        });
        go.addEventListener('dblclick', (event) => event.stopPropagation());
      }
      cell.append(mark, ...(box ? [box] : []), text, ...(link ? [link] : []));
      cells.push(cell);
      parts.cells.push({ cell, mark, text, box, link });
    }
    item.replaceChildren(...cells);
    rowParts.set(item, parts);
    return parts;
  }

  /** What a folder holds, said (§3): under Assets or a pack its bytes, on the Source side its files; none for the project, the Trash and its slots. */
  function heldBy(folder: string): { text: string; title: string } | null {
    const shipping = folder === PROJECT ? undefined : naming.shipsAt(folder);
    return shipping === undefined ? null : sizeSaid(host.sizes.of(folder), shipping);
  }

  /** The mark a row or a tile shows: a spinner while a job runs on its family, else its own; a folder's, what needs a hand under it. */
  function markFor(row: Listed): RowMark | null {
    if (isFolder(row)) return folderMark(host.counts.of(row.folder));
    const source = isEntry(row) ? (row.role === 'source' ? row.path : row.role === 'export' ? row.source : undefined) : undefined;
    if (source !== undefined && host.running(source)) return { spin: true, title: `A job is running on ${baseName(source)}` };
    return markOf(row, entries());
  }

  function update(item: HTMLElement, i: number): void {
    const row = listed[i]!;
    const path = pathOf(row);
    if (item.dataset.path !== path) item.dataset.path = path;
    const selection = host.selection();
    const at = selection.paths.indexOf(path);
    const selected = String(at >= 0);
    if (item.getAttribute('aria-selected') !== selected) item.setAttribute('aria-selected', selected);
    const draggable = host.writes() && !(editing !== null && editing.path === path);
    if (item.draggable !== draggable) item.draggable = draggable;
    item.classList.toggle('ed-also', at >= 0 && path !== selection.primary);
    // A tile lit under a box and pooled meanwhile: unlit, the box gone.
    if (box === null && item.classList.contains('ed-as-boxed')) item.classList.remove('ed-as-boxed');
    if (host.prefs().view === 'grid') updateTile(item, row, i);
    else updateRow(item, row);
  }

  function updateRow(item: HTMLElement, row: Listed): void {
    const folder = isFolder(row);
    const path = pathOf(row);
    let parts = rowParts.get(item);
    if (!parts || parts.shape !== shapeNow()) parts = makeRow(item, row);
    put(parts.name, folder ? naming.title(path) : baseName(path));
    const out = folder ? excludedText(host.counts.of(path)) : null;
    const said = `${naming.say(path)}${out ? `\n${out}` : ''}`;
    const name = parts.name.parentElement!;
    if (name.title !== said) name.title = said;
    if (parts.where) {
      const there = folderOf(path);
      put(parts.where, naming.say(there), `Open ${naming.say(there)} with ${baseName(path)} chosen`);
    }
    // A folder's mark beside its name when no Status column is ticked to carry it.
    putMark(parts.nameMark, folder && columns.every((c) => c.name !== 'status') ? markFor(row) : null, 'ed-as-mark');
    columns.forEach((column, n) => {
      const { cell, mark, text, box, link } = parts!.cells[n]!;
      // The link where the row has one, the plain text where not: a pooled row shows either.
      const linked = (to: string | undefined): void => {
        if (!link) return;
        if (to !== undefined && link.dataset.path !== to) link.dataset.path = to;
        if (link.hidden !== (to === undefined)) link.hidden = to === undefined;
        if (text.hidden !== (to !== undefined)) text.hidden = to !== undefined;
      };
      if (folder) {
        // A folder has no tick of its own: its files have theirs.
        if (box && !box.hidden) box.hidden = true;
        linked(undefined);
        // A folder's: what needs a hand under it, where the status is; what it holds, where the size is; nothing else to say.
        const shown = column.name === 'status' ? markFor(row) : null;
        const holds = column.name === 'size' ? heldBy(path) : null;
        putMark(mark, shown, 'ed-as-mark');
        put(text, shown ? '' : holds ? holds.text : NOTHING);
        text.classList.toggle('ed-dim', !shown && !holds);
        const title = holds?.title ?? '';
        if (cell.title !== title) cell.title = title;
        return;
      }
      const cellSaid = column.cell(row, entries());
      // A tick's box shows only on a file with a tick: a tickless row's cell says `—`.
      if (box && !cellSaid.tick && !box.hidden) box.hidden = true;
      if (box && cellSaid.tick) {
        if (box.hidden) box.hidden = false;
        if (box.checked !== cellSaid.tick.on) box.checked = cellSaid.tick.on;
        const disabled = !host.writes() || cellSaid.tick.stuck !== undefined;
        if (box.disabled !== disabled) box.disabled = disabled;
        const label = cellSaid.tick.on ? 'In the build' : 'Out of the build';
        if (box.getAttribute('aria-label') !== label) box.setAttribute('aria-label', label);
      }
      putMark(mark, column.name === 'status' ? markFor(row) : (cellSaid.mark ?? null), 'ed-as-mark');
      linked(cellSaid.link);
      if (link && cellSaid.link !== undefined) put(link, cellSaid.text);
      put(text, cellSaid.text);
      text.classList.toggle('ed-dim', cellSaid.text === NOTHING);
      const title = cellSaid.title ?? cellSaid.text;
      if (cell.title !== title) cell.title = title;
    });
  }

  function updateTile(item: HTMLElement, row: Listed, i: number): void {
    const parts = tileParts.get(item);
    if (!parts) return;
    const folder = isFolder(row);
    const path = pathOf(row);
    const { x } = tileAt(i, layout);
    const left = `${x}px`;
    if (item.style.left !== left) item.style.left = left;
    const width = `${layout.tileWidth}px`;
    if (item.style.width !== width) item.style.width = width;
    const height = `${layout.tileHeight}px`;
    if (item.style.height !== height) item.style.height = height;
    // Under its row's band, where the tiles are in groups -- the mount places the row, the band is the tile's own.
    const band = layout.band > 0 ? `${layout.band}px` : '';
    if (item.style.marginTop !== band) item.style.marginTop = band;
    drawGroup(item, parts, labels[i] ?? null);
    const holds = folder ? heldBy(path) : null;
    // A folder's hover what it is -- a root's with what it is for -- and what it holds.
    const out = folder ? excludedText(host.counts.of(path)) : null;
    const said = folder ? `${naming.about(path)}${holds ? `\n${holds.title}` : ''}${out ? `\n${out}` : ''}` : naming.say(path);
    if (item.title !== said) item.title = said;
    if (parts.label && parts.held) {
      put(parts.label, naming.title(path));
      put(parts.held, holds ? ` · ${holds.text}` : '');
    } else put(parts.name, baseName(path));
    if (parts.size) put(parts.size, sayBytes((row as Shown).size));
    putMark(parts.mark, markFor(row), 'ed-as-mark ed-as-corner');
    if (!folder) drawThumb(parts, row as Shown);
  }

  /** The label over a tile and the rest of its group in its row (§4, the project's), or none: over the band, not to be pressed. */
  function drawGroup(item: HTMLElement, parts: TileParts, label: GroupLabel | null): void {
    if (!label) {
      if (parts.group) parts.group.hidden = true;
      return;
    }
    if (!parts.group) {
      parts.group = el('span', 'ed-as-group');
      item.append(parts.group);
    }
    const group = parts.group;
    if (group.hidden) group.hidden = false;
    put(group, label.group);
    const width = `${label.span * (layout.tileWidth + layout.gap) - layout.gap}px`;
    if (group.style.width !== width) group.style.width = width;
    const top = `${-layout.band}px`;
    if (group.style.top !== top) group.style.top = top;
  }

  /** The tile's picture, if the queue has it -- kept under its hash, or the one learned for it -- else the format's icon; written only where it changed. */
  function drawThumb(parts: TileParts, row: Shown): void {
    const size = tileThumb();
    const want = host.thumbOf(row.path, size);
    const hash = want ? host.thumbs.known(want) : undefined;
    const url = hash !== undefined ? host.thumbs.url(hash, size) : undefined;
    if (url && !parts.image) {
      const image = el('img', 'ed-as-thumb-img');
      image.alt = '';
      image.draggable = false;
      image.decoding = 'async';
      parts.glyph?.after(image);
      parts.image = image;
    }
    if (parts.image) {
      if (url && parts.image.src !== url) parts.image.src = url;
      if (parts.image.hidden !== !url) parts.image.hidden = !url;
    }
    if (parts.glyph && parts.glyph.hidden !== !!url) parts.glyph.hidden = !!url;
  }

  /** The size of thumbnail the tiles draw: theirs, sharp on a screen of two pixels a point. */
  const tileThumb = (): number => thumbSize(side, globalThis.devicePixelRatio ?? 1);

  /** The panel is laid out at the grip's height: shown, and not folded to a tab. */
  const laidOut = (): boolean => !frame.hidden && !host.folded() && list.clientHeight > 0;
  /**
   * The tiles' side as drawn: the size chosen -- or, in a panel too short for a
   * row of them with their names, the largest that fits (`stripTile`, §2).
   */
  const sideNow = (): number => (host.prefs().view === 'grid' && laidOut() ? stripTile(host.prefs().thumb, list.clientHeight) : host.prefs().thumb);
  let side: number = host.prefs().thumb;
  let residing = 0;
  /** The list's height changed -- the strip's grip, the window: drawn again at the side that fits now, the next frame. */
  function sideChanged(): void {
    if (residing !== 0) return;
    residing = requestAnimationFrame(() => {
      residing = 0;
      if (sideNow() !== side) remount();
    });
  }

  /** The mount for the view: made again when the view or the tiles' size changes, as its elements are the view's. */
  function remount(): void {
    mounted?.dispose();
    const grid = host.prefs().view === 'grid';
    side = sideNow();
    list.classList.toggle('ed-as-grid', grid);
    mounted = mount({
      list,
      rowHeight: () => (grid ? layout.rowHeight : ROW),
      perRow: (width) => {
        if (!grid) return 1;
        // Heard on the list's every resize, its height too: a panel made shorter or taller may want another side.
        sideChanged();
        layout = gridLayout(width, side, listed.length, bandNow());
        labels = groupLabels(groups, layout.perRow);
        return layout.perRow;
      },
      count: () => listed.length,
      key: (i) => pathOf(listed[i]!),
      make,
      update,
    });
    drawHead();
    drawEmpty();
    host.wantThumbs();
  }

  function drawEmpty(): void {
    const folder = host.folder();
    empty.hidden = listed.length > 0;
    if (listed.length > 0) return;
    empty.replaceChildren();
    if (issuesOn() && (query === null || total(host.counts.of(issuesScope())) === 0)) {
      // Nothing to do here: said, and the way back to every file.
      empty.append('Nothing under here needs a hand · ');
      empty.append(button('ui', 'Show every file', `Issues off: every file of ${naming.say(folder)} again (${keyLabel('Shift+KeyI')})`, () => setIssues(false), 'ed-small'));
    } else if (query) {
      empty.append(`Nothing matches ${search.value.trim()} ${query.everywhere ? 'in any folder' : 'here'} · `);
      const clear = control('ui', 'ed-button ed-small', 'Clear');
      clear.addEventListener('click', () => clearSearch());
      empty.append(clear);
    } else if (folder === TRASH) empty.append('Nothing in the trash');
    else if (under(folder, TRASH)) empty.append('Nothing in this slot');
    else if (!host.writes()) empty.append('Nothing here');
    else if (!folderTakes(folder).import) empty.append('No pack yet: New folder makes one, and files go into it');
    else {
      empty.append('Drop files here, or ');
      empty.append(
        button('asset_import', 'Files…', `Choose files to import into this folder (${keyLabel('KeyI')})`, () => host.importFiles(), 'ed-small'),
        ' ',
        button('asset_import', 'Folder…', 'Choose a folder to import into this one, its folders kept', () => host.importFolder(), 'ed-small'),
      );
    }
  }

  /** The folder's count, or the search's, or the Issues': "1 folder, 4 files". */
  function counted(): string {
    const folders = listed.filter(isFolder).length;
    const files = listed.length - folders;
    const n = `${folders > 0 ? `${folders} ${folders === 1 ? 'folder' : 'folders'}, ` : ''}${filesText(files)}`;
    if (query) return `${n} found${issuesOn() ? ' needing a hand' : ''}`;
    if (issuesOn()) return `${n} needing a hand`;
    if (host.folder() === TRASH && index.pruned) {
      return `${n} · ${index.pruned.count} ${index.pruned.count === 1 ? 'item' : 'items'} older than 30 days ${index.pruned.count === 1 ? 'was' : 'were'} removed at startup`;
    }
    return n;
  }

  function drawStatus(): void {
    const text = said || noted?.text || counted();
    status.textContent = text;
    status.title = text;
    status.classList.toggle('ed-bad', said !== '' ? saidBad : noted?.bad === true);
  }

  function refresh(): void {
    read();
    if (layout.count !== listed.length) layout = { ...layout, count: listed.length };
    // Into the project or out of it: the band over each row comes or goes, the labels with it -- the mount reads both again.
    if (layout.band !== bandNow()) layout = { ...layout, band: bandNow(), rowHeight: layout.tileHeight + layout.gap + bandNow() };
    labels = groupLabels(groups, layout.perRow);
    drawHead();
    drawEmpty();
    drawStatus();
    mounted?.invalidate();
    host.wantThumbs();
  }

  /** The thumbnails to make, in order (§9): `first`, what is chosen, the tiles in view, then the rest -- each path and size once. */
  function thumbOrder(first: readonly ThumbWant[] = []): ThumbWant[] {
    if (host.prefs().view !== 'grid') return [...first];
    const size = tileThumb();
    const per = Math.max(1, mounted?.perRow ?? layout.perRow);
    const view = itemsOf(range(list.scrollTop, list.clientHeight, layout.rowHeight, Math.ceil(listed.length / per), 0), per, listed.length);
    return wantOrder(paths, view, host.selection().paths, (path) => host.thumbOf(path, size), first);
  }

  // A thumbnail ready: its tile alone drawn again, where it is drawn.
  const offReady = host.thumbs.onReady((_hash, size, path) => {
    if (host.prefs().view === 'grid' && size === tileThumb()) mounted?.redraw([path]);
  });
  /** The first row in view, as last scrolled: the queue is asked again only as it changes. */
  let topRow = -1;
  list.addEventListener('scroll', () => {
    const row = Math.floor(list.scrollTop / Math.max(1, host.prefs().view === 'grid' ? layout.rowHeight : ROW));
    host.scrolled(row !== topRow);
    topRow = row;
  }, { passive: true });

  // ---------------------------------------------------------------- the columns, the sort

  const chooserList = el('div', 'ed-card ed-menu ed-ticks');
  let chooserDown: (() => void) | null = null;

  function showChooser(): void {
    chooserList.replaceChildren(el('div', 'ed-menu-title', 'Columns'));
    for (const column of host.columns) {
      const tick = el('label', 'ed-menu-item ed-tick');
      tick.title = column.help;
      const box = el('input');
      box.type = 'checkbox';
      box.checked = host.prefs().columns.includes(column.name);
      box.addEventListener('change', () => {
        host.keep({ columns: flipColumn(host.prefs().columns, column.name, host.columns) });
        refresh();
      });
      tick.append(box, el('span', 'ed-tick-name', column.label ?? column.title));
      chooserList.append(tick);
    }
    // Into the editor's root, which the panel is in: a drop-down over everything, never cut by the panel.
    chooserDown = dropUnder(frame.parentElement ?? document.body, chooser, chooserList, shut);
  }

  function shut(): void {
    chooserDown?.();
    chooserDown = null;
  }

  // ---------------------------------------------------------------- the search

  search.addEventListener('input', () => {
    clearTimeout(typing);
    typing = setTimeout(() => {
      const was = query !== null;
      query = readQuery(search.value);
      if (was || query) host.select(NO_PATHS);
      refresh();
      remountIfNeeded();
      host.changed();
    }, DEBOUNCE);
  });

  /** A flat list starting or ending -- a search, the Issues -- changes the list's columns: drawn again whole. */
  let wasFlat = false;
  function remountIfNeeded(): void {
    if (flat() === wasFlat) return;
    wasFlat = flat();
    remount();
  }

  /** Issues on or off (§4): kept, nothing chosen -- what was chosen may not be listed -- and the card drawn again. */
  function setIssues(on: boolean): void {
    if (issuesOn() === on) return;
    host.keep({ issues: on });
    host.select(NO_PATHS);
    refresh();
    remountIfNeeded();
    host.changed();
  }

  function clearSearch(): void {
    clearTimeout(typing);
    if (search.value === '' && query === null) return;
    search.value = '';
    query = null;
    refresh();
    remountIfNeeded();
    host.changed();
  }

  // ---------------------------------------------------------------- the marquee

  /** A box being drawn: where it began and is, in the list's own coordinates (it scrolls with them), how it combines. */
  let box: { id: number; x0: number; y0: number; x: number; y: number; how: Combine; el: HTMLElement | null; scrolling: number } | null = null;
  /** A box was let go: the click that ends it chooses nothing more. */
  let boxedNow = false;

  /** A point on the page in the list's own coordinates: what tiles are placed in. */
  function inList(x: number, y: number): { x: number; y: number } {
    const r = list.getBoundingClientRect();
    return { x: x - r.left - list.clientLeft + list.scrollLeft, y: y - r.top - list.clientTop + list.scrollTop };
  }

  /** The box drawn to where the pointer is now -- after a scroll too, the pointer still -- and the tiles it passes over lit as it goes. */
  function drawBox(): void {
    if (!box?.el) return;
    const at = inList(box.x, box.y);
    box.el.style.left = `${Math.min(box.x0, at.x)}px`;
    box.el.style.top = `${Math.min(box.y0, at.y)}px`;
    box.el.style.width = `${Math.abs(at.x - box.x0)}px`;
    box.el.style.height = `${Math.abs(at.y - box.y0)}px`;
    // Lit as the box passes, as the Finder's are: the drawn tiles it touches -- the geometry says which, cheaply.
    const under = new Set(tilesIn({ x0: box.x0, y0: box.y0, x1: at.x, y1: at.y }, { ...layout, count: listed.length }).map((i) => paths[i]!));
    for (const item of list.children) {
      const path = (item as HTMLElement).dataset.path;
      if (path !== undefined) item.classList.toggle('ed-as-boxed', under.has(path));
    }
  }

  /** The tiles lit under a box, unlit: it was let go, or taken away. */
  function unlight(): void {
    for (const item of list.querySelectorAll('.ed-as-boxed')) item.classList.remove('ed-as-boxed');
  }

  /** While the pointer is near the list's top or bottom edge, the list scrolls, a frame at a time: only while a box is drawn. */
  function edgeScroll(): void {
    if (!box?.el || box.scrolling !== 0) return;
    const step = (): void => {
      if (!box?.el) return;
      const r = list.getBoundingClientRect();
      const near = box.y - r.top < BOX_EDGE ? -(BOX_EDGE - (box.y - r.top)) : r.bottom - box.y < BOX_EDGE ? BOX_EDGE - (r.bottom - box.y) : 0;
      if (near === 0) {
        box.scrolling = 0;
        return;
      }
      list.scrollTop += Math.sign(near) * Math.min(BOX_SPEED, Math.ceil((Math.abs(near) / BOX_EDGE) * BOX_SPEED));
      drawBox();
      box.scrolling = requestAnimationFrame(step);
    };
    box.scrolling = requestAnimationFrame(step);
  }

  function endBox(take: boolean): void {
    const was = box;
    box = null;
    if (!was) return;
    if (was.scrolling !== 0) cancelAnimationFrame(was.scrolling);
    if (!was.el) return;
    const at = inList(was.x, was.y);
    was.el.remove();
    unlight();
    boxedNow = true;
    if (!take) return;
    const tiles = tilesIn({ x0: was.x0, y0: was.y0, x1: at.x, y1: at.y }, { ...layout, count: listed.length });
    host.boxed(tiles.map((i) => paths[i]!), was.how);
  }

  list.addEventListener('pointerdown', (event) => {
    // The grid's own space only: a tile's press is a drag, the scrollbar's the browser's.
    if (event.target !== list || event.button !== 0 || host.prefs().view !== 'grid' || editing) return;
    const r = list.getBoundingClientRect();
    if (event.clientX - r.left - list.clientLeft >= list.clientWidth) return;
    const at = inList(event.clientX, event.clientY);
    boxedNow = false;
    box = { id: event.pointerId, x0: at.x, y0: at.y, x: event.clientX, y: event.clientY, how: boxHow(event), el: null, scrolling: 0 };
    list.setPointerCapture(event.pointerId);
  });
  list.addEventListener('pointermove', (event) => {
    if (!box || event.pointerId !== box.id) return;
    box.x = event.clientX;
    box.y = event.clientY;
    if (!box.el) {
      const at = inList(box.x, box.y);
      if (Math.hypot(at.x - box.x0, at.y - box.y0) < BOX_SLOP) return;
      box.el = el('div', 'ed-marquee ed-as-marquee');
      list.append(box.el);
    }
    drawBox();
    edgeScroll();
  });
  list.addEventListener('pointerup', (event) => {
    if (box && event.pointerId === box.id) endBox(true);
  });
  list.addEventListener('pointercancel', (event) => {
    if (box && event.pointerId === box.id) endBox(false);
  });

  // A press on the list's empty space: nothing chosen, or its menu.
  // mcp: ui -- nothing selected
  list.addEventListener('click', (event) => {
    // The click a box ends with: the box chose already.
    if (boxedNow) {
      boxedNow = false;
      return;
    }
    if (event.target !== list || clickHow(event, true) !== 'one') return;
    host.select(NO_PATHS);
  });
  list.addEventListener('contextmenu', (event) => {
    if (event.target !== list && event.target !== empty) return;
    event.preventDefault();
    host.menu({ kind: 'space' }, { x: event.clientX, y: event.clientY }, false);
  });

  function setView(view: AssetsPrefs['view']): void {
    if (host.prefs().view === view) return;
    host.keep({ view });
    read();
    remount();
    // The panel's least height is the view's -- a row of tiles in the grid, 160 in the list -- measured as it is drawn now.
    placeStrip(host.prefs().stripHeight);
    const latest = host.selection().latest;
    if (latest !== null) reveal(latest);
    host.changed();
  }

  function reveal(path: string, middle = false): void {
    const i = paths.indexOf(path);
    if (i >= 0) mounted?.reveal(i, middle);
  }

  /** The rename field taken away, the name it hid back. */
  function endEdit(): void {
    if (!editing) return;
    editing.field.remove();
    if (editing.hidden) editing.hidden.hidden = false;
    editing = null;
  }

  // ---------------------------------------------------------------- the panel's height and its grip

  /** The panel's own height round the list -- its title row, the jobs, the status line, padding -- as last measured laid out. */
  let chrome = 0;
  /** The panel's least height now: a row of 64s with their names in the grid, `STRIP_MIN` in the list (§2). */
  const leastStrip = (): number => {
    if (laidOut()) chrome = Math.max(0, frame.getBoundingClientRect().height - list.clientHeight);
    return host.prefs().view === 'grid' && chrome > 0 ? stripMin(chrome) : STRIP_MIN;
  };
  /** The panel's height on screen: as kept, held to what this window allows and to a row of tiles. */
  const placeStrip = (height: number): void => {
    const px = `${stripHeightFor(height, innerHeight, leastStrip())}px`;
    if (frame.style.getPropertyValue('--ed-strip') !== px) frame.style.setProperty('--ed-strip', px);
    sideChanged();
  };
  let pull: { id: number; y: number; from: number; now: number } | null = null;
  grip.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || host.folded()) return;
    event.preventDefault();
    pull = { id: event.pointerId, y: event.clientY, from: frame.getBoundingClientRect().height, now: host.prefs().stripHeight };
    grip.setPointerCapture(event.pointerId);
    grip.classList.add('ed-dragging');
  });
  grip.addEventListener('pointermove', (event) => {
    if (!pull || pull.id !== event.pointerId) return;
    // Up is taller: the panel grows toward the scene.
    pull.now = stripHeightFor(pull.from - (event.clientY - pull.y), innerHeight, leastStrip());
    placeStrip(pull.now);
  });
  const letGoGrip = (event: PointerEvent): void => {
    if (!pull || pull.id !== event.pointerId) return;
    const kept = pull.now;
    pull = null;
    grip.classList.remove('ed-dragging');
    if (grip.hasPointerCapture(event.pointerId)) grip.releasePointerCapture(event.pointerId);
    host.keep({ stripHeight: kept });
  };
  grip.addEventListener('pointerup', letGoGrip);
  grip.addEventListener('pointercancel', letGoGrip);
  // mcp: ui -- the strip's height put back
  grip.addEventListener('dblclick', () => {
    host.keep({ stripHeight: STRIP_HEIGHT });
    placeStrip(STRIP_HEIGHT);
  });
  // A window made smaller holds the panel to its half: heard while the tab is up (`setVisible`), not for the tool's life.
  const resized = (): void => placeStrip(host.prefs().stripHeight);

  read();
  // Issues kept on: the card starts flat.
  wasFlat = flat();
  remount();

  return {
    card,
    head,
    refresh,
    redraw() {
      mounted?.flush();
      drawStatus();
      host.wantThumbs();
    },
    patch(source) {
      return mounted?.redraw([source, ...(index.entries.get(source)?.exports ?? [])]) ?? 0;
    },
    shown: () => paths,
    get query() {
      return query;
    },
    setIssues,
    showAll() {
      clearSearch();
      setIssues(false);
    },
    get found() {
      return listed.length;
    },
    get counted() {
      return counted();
    },
    get page() {
      const rows = Math.max(1, Math.floor(list.clientHeight / (host.prefs().view === 'grid' ? layout.rowHeight : ROW)) - 1);
      return rows;
    },
    get perRow() {
      return host.prefs().view === 'grid' ? (mounted?.perRow ?? 1) : 1;
    },
    element: (path) => mounted?.shown(path),
    reveal,
    focusSearch() {
      search.focus();
      search.select();
    },
    clearSearch,
    setView,
    resize(by) {
      const now = THUMBS.indexOf(host.prefs().thumb);
      const next = THUMBS[Math.max(0, Math.min(THUMBS.length - 1, now + by))]!;
      if (next === host.prefs().thumb) return;
      host.keep({ thumb: next });
      remount();
      const latest = host.selection().latest;
      if (latest !== null) reveal(latest);
    },
    say(text, bad = false) {
      said = text;
      saidBad = bad;
      clearTimeout(quiet);
      quiet = setTimeout(() => {
        said = '';
        drawStatus();
      }, SAID);
      drawStatus();
    },
    get dropped() {
      return chooserDown !== null;
    },
    shut,
    note(text, bad = false) {
      noted = text === null ? null : { text, bad };
      // A drag or a field begun says what it is now, over what was just done.
      if (text !== null && said !== '') {
        said = '';
        clearTimeout(quiet);
      }
      drawStatus();
    },
    editName(path, field) {
      endEdit();
      const i = paths.indexOf(path);
      if (i < 0) return false;
      mounted?.reveal(i);
      const item = mounted?.shown(path);
      if (!item) return false;
      // The name it stands for hidden, the field beside it: the tile's or row's own parts left as they are.
      const name = tileParts.get(item)?.name ?? rowParts.get(item)?.name ?? null;
      if (name) {
        name.hidden = true;
        name.after(field);
      } else item.append(field);
      editing = { path, field, hidden: name };
      item.draggable = false;
      return true;
    },
    endEdit,
    newFolder(field) {
      fresh.replaceChildren();
      fresh.hidden = field === null;
      if (field) fresh.append(icon('folder'), field);
    },
    body,
    thumbOrder,
    get thumbSize() {
      return tileThumb();
    },
    grip,
    place: resized,
    // The panel it is in comes and goes with the tool.
    setVisible(visible) {
      if (!visible) {
        removeEventListener('resize', resized);
        shut();
      } else {
        addEventListener('resize', resized);
        // Made while hidden, the panel measured nothing: its least height and its tiles' side, now it is laid out.
        placeStrip(host.prefs().stripHeight);
        refresh();
      }
    },
    dispose() {
      removeEventListener('resize', resized);
      cancelAnimationFrame(residing);
      shut();
      endBox(false);
      offReady();
      clearTimeout(quiet);
      clearTimeout(typing);
      mounted?.dispose();
      card.remove();
    },
  };
}
