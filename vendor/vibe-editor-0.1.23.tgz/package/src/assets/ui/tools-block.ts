/**
 * The Tools block, Config ▸ Assets ▸ Tools' content (Docs/assets-tool.md §7;
 * the page is `config/tools.ts`, added by the Assets tool, whose state it
 * shows): every tool the export steps need, from `GET tools` -- found, missing
 * or lacking; its version, or what to do about it; the line it read (ffmpeg's
 * encoder line), and a path set that did not run and was passed over for
 * another (`passedOver`) -- with its path to set (`PUT tools?name=`) and **Check
 * again** (`POST tools/check`). "Looking for tools…" while the first look
 * runs. Where every `unmade` story ends: a folder's `⚠` in the Assets panel
 * and the inspector's **Set its path in Tools** open the page, the path
 * focused (`show`).
 *
 * - **Patched in place, never made again**: each tool's block is made once, by
 *   its name, and `refresh` writes only the words that changed -- so a path
 *   being typed while auto-exports and tool messages flow, the very moment the
 *   `⚠` story brings a designer here, is never lost. A field with the focus is
 *   not written to at all; a refresh that changes nothing touches nothing.
 *
 * In read mode and bundle view the paths and Check again are absent: they
 * change the server's machine.
 *
 * A row of someone else's can sit under a tool's entry (`under`): the Tools
 * page's ffmpeg Download row (`config/tools.ts`), kept there as the block is
 * patched.
 */
import type { ToolLook } from '@vibe/pipeline/assets-types';
import { sayPassedOver } from '@vibe/pipeline/look-words';
import { textField } from '../../fields.ts';
import { button, el } from '../../shell.ts';
import { COLOUR_CLASS, type Colour } from './marks.ts';

/** What the Tools block asks of the tool. */
export interface ToolsHost {
  /** The tools as last looked for; null while the first look runs. */
  tools(): readonly ToolLook[] | null;
  /** May this page change the server's machine? */
  writes(): boolean;
  /** A tool's path set -- `''` forgets it -- and the tools looked for again. */
  setPath(tool: string, path: string): Promise<void>;
  /** Every tool looked for again. */
  checkAgain(): Promise<void>;
}

export interface ToolsBlock {
  readonly root: HTMLElement;
  /** Patched to the tools as they are: what changed alone, a focused field never. */
  refresh(): void;
  /** `tool`'s path field focused -- the first one's for none -- and in view: the page is shown first. */
  show(tool?: string): void;
  /** Tools missing or lacking: what the block's first line says. */
  readonly wanting: number;
  /** What a path set or Check again came to, under the list until the next. */
  say(text: string, bad?: boolean): void;
  /** `row` put under `tool`'s entry, its last part -- now, or as the tool is first drawn. */
  under(tool: string, row: HTMLElement): void;
  /** Every tool looked for again (the host's Check again): its path field then shows what was found. */
  checkAgain(): Promise<void>;
}

const STATE: Record<ToolLook['state'], { glyph: string; colour: Colour; word: string }> = {
  found: { glyph: '✓', colour: 'green', word: 'found' },
  missing: { glyph: '✕', colour: 'red', word: 'missing' },
  lacking: { glyph: '⚠', colour: 'amber', word: 'lacking' },
};

/** One tool's block, made once: its parts, each written only when its words change. */
interface Drawn {
  block: HTMLElement;
  said: HTMLElement;
  version: HTMLElement;
  line: HTMLElement;
  hint: HTMLElement;
  why: HTMLElement;
  /** The path set for it, passed over because it did not run: said, with what is used instead. */
  over: HTMLElement;
  input: HTMLInputElement | null;
}

/** `node` says `text` (hidden for none), with `title`: written only where it differs. */
function put(node: HTMLElement, text: string, title = text): void {
  if (node.textContent !== text) node.textContent = text;
  if (node.title !== title) node.title = title;
  const hidden = text === '';
  if (node.hidden !== hidden) node.hidden = hidden;
}

export function createToolsBlock(host: ToolsHost): ToolsBlock {
  const root = el('div', 'ed-as-tools');
  // What the exports want, in a line: every tool found, or how many are missing or lacking.
  const head = el('div', 'ed-as-tools-head');
  const want = el('span', `ed-as-mark ${COLOUR_CLASS.amber}`);
  const sum = el('span', 'ed-dim');
  head.append(want, sum);
  const body = el('div', 'ed-as-tools-body');
  const looking = el('div', 'ed-dim', 'Looking for tools…');
  const list = el('div', 'ed-as-tools-list');
  const again = button('tools_check', 'Check again', 'Look for every tool again: what can now be made is queued', () => void host.checkAgain(), 'ed-small');
  const readOnly = el('div', 'ed-dim', 'Read only: the tools are set on the machine running the dev server.');
  const said = el('div', 'ed-status');
  said.hidden = true;
  body.append(looking, list, again, said, readOnly);
  root.append(head, body);
  /** Each tool's block, by its name, in the order first drawn. */
  const drawn = new Map<string, Drawn>();
  /** What was last drawn from: a refresh that would draw the same touches nothing. */
  let last = '';
  /** A field to focus once drawn. */
  let focusing: string | null = null;
  /** Rows put under a tool's entry (`under`), by its name. */
  const extra = new Map<string, HTMLElement>();

  const wanting = (): number => (host.tools() ?? []).filter((t) => t.state !== 'found').length;

  function make(look: ToolLook): Drawn {
    const block = el('div', 'ed-as-tool');
    const top = el('div', 'ed-line');
    const said = el('span', 'ed-as-mark');
    top.append(el('b', undefined, look.tool), said);
    const version = el('div', 'ed-dim');
    const line = el('div', 'ed-dim ed-as-tool-line');
    const hint = el('div', 'ed-as-tool-hint');
    const why = el('div', 'ed-dim');
    const over = el('div', `ed-as-tool-hint ${COLOUR_CLASS.amber}`);
    block.append(top, version, line, hint, why, over);
    let input: HTMLInputElement | null = null;
    if (host.writes()) {
      const field = textField(look.path ?? '', (text) => void host.setPath(look.tool, text.trim()));
      input = field.querySelector('input')!;
      input.placeholder = `Path to ${look.tool}, or empty to look on the PATH`;
      input.title = `Where ${look.tool} is on this machine: Enter sets it, and the tools are looked for again`;
      input.dataset.tool = look.tool;
      block.append(field);
    }
    const row = extra.get(look.tool);
    if (row) block.append(row);
    return { block, said, version, line, hint, why, over, input };
  }

  function patch(look: ToolLook, d: Drawn): void {
    const state = STATE[look.state];
    const cls = `ed-as-mark ${COLOUR_CLASS[state.colour]}`;
    if (d.said.className !== cls) d.said.className = cls;
    put(d.said, `${state.glyph} ${state.word}`, look.why ?? (look.path ? `Run as ${look.path}` : state.word));
    put(d.version, look.version ? `version ${look.version}` : '');
    put(d.line, look.line ?? '');
    put(d.hint, look.state !== 'found' && look.hint ? look.hint : '');
    put(d.why, look.why && look.state !== 'found' ? look.why : '');
    const passed = sayPassedOver(look);
    put(d.over, passed ? `⚠ ${passed[0]!.toUpperCase()}${passed.slice(1)}: fix it here, or empty it to use the PATH's` : '');
    // The path as the server has it -- the one set, if it was passed over, so it can be fixed -- but never under a person typing one.
    const path = look.passedOver?.path ?? look.path ?? '';
    if (d.input && document.activeElement !== d.input && d.input.value !== path) d.input.value = path;
  }

  function refresh(): void {
    const tools = host.tools();
    const writes = host.writes();
    const now = JSON.stringify([tools, writes]);
    if (now !== last) {
      last = now;
      const n = wanting();
      put(want, n > 0 ? `⚠ ${n}` : '', '');
      put(sum, tools === null ? '' : n > 0 ? `${n} of the tools the exports need ${n === 1 ? 'is' : 'are'} missing or lacking${writes ? ': set a path below, or install it and Check again' : ''}` : 'Every tool the exports need was found');
      looking.hidden = tools !== null;
      again.hidden = !writes || tools === null;
      readOnly.hidden = writes || tools === null;
      const seen = new Set<string>();
      for (const look of tools ?? []) {
        seen.add(look.tool);
        let d = drawn.get(look.tool);
        if (!d) {
          d = make(look);
          drawn.set(look.tool, d);
          list.append(d.block);
        }
        patch(look, d);
      }
      for (const [tool, d] of drawn) {
        if (seen.has(tool)) continue;
        d.block.remove();
        drawn.delete(tool);
      }
    }
    if (focusing !== null) {
      const field = drawn.get(focusing)?.input ?? [...drawn.values()].find((d) => d.input)?.input ?? null;
      focusing = null;
      field?.focus();
      field?.select();
    }
  }

  return {
    root,
    refresh,
    show(tool) {
      focusing = tool ?? '';
      refresh();
      root.scrollIntoView({ block: 'nearest' });
    },
    get wanting() {
      return wanting();
    },
    say(text, bad = false) {
      said.hidden = false;
      said.textContent = text;
      said.classList.toggle('ed-bad', bad);
    },
    under(tool, row) {
      extra.set(tool, row);
      drawn.get(tool)?.block.append(row);
    },
    checkAgain: () => host.checkAgain(),
  };
}
