/**
 * A name made a field where it is (Docs/assets-tool.md §6.1, "Rename is one
 * mechanism"): the tile's name in the grid, the row's in the list, a folder's
 * row in Folders, the inspector's head -- the same field each time, put there
 * by the card that has the name.
 *
 * - **The stem alone is edited**: the extension after it is grey and fixed --
 *   a family has several, and `validName` wants one dot (`renameParts`). A
 *   folder's name is all stem.
 * - **Checked as it is typed** with `validName` (a new folder's, `{ folder:
 *   true }`): red, its refusal on hover and told (`typed`), so the uses line
 *   can follow too ("the key becomes characters/hero").
 * - **Enter commits** (the form's own submit): the name as it was is no
 *   rename; a refusal from `GET names` keeps the field open, red, its words
 *   said, and its suggestion one click away (`use`). **Leaving it commits**
 *   too -- a refusal then is said, and the field goes. **Esc cancels**, the
 *   browser's close request (§8, "Esc in a field").
 *
 * The field listens for no key: MrDebug drops a key typed into it, and Enter
 * and Esc are the browser's.
 */
import { validName } from '@vibe/pipeline/paths';
import { onCloseRequest, textInput } from '../../fields.ts';
import { el } from '../../shell.ts';
import { renamedName, renameParts } from './naming.ts';

/** A refusal: the field's red, and its way on. */
export interface Refused {
  refused: string;
  suggested?: string;
}

export interface RenameFieldOptions {
  /** The name as it is: `robot.glb`, a folder's `characters`; a new folder's first suggestion. */
  name: string;
  folder: boolean;
  /** The field's placeholder. */
  placeholder?: string;
  /** A new name, not a rename: the name as it was commits too. */
  fresh?: boolean;
  /** As it is typed: the whole name, and the refusal `validName` gives, or null. */
  typed?(name: string, refused: Refused | null): void;
  /** Enter, or leaving it changed: null once taken -- the field goes -- or a refusal, the field kept open with it (Enter) or said (left). */
  commit(name: string): Promise<Refused | null>;
  /** The field is done with, however it ended: its card takes it away. */
  done(): void;
}

export interface RenameField {
  readonly form: HTMLFormElement;
  readonly input: HTMLInputElement;
  /** The suggestion taken: the field says it, checked. */
  use(name: string): void;
  /** Taken away from outside -- the item it names gone -- as Esc would. */
  cancel(): void;
}

export function renameField(options: RenameFieldOptions): RenameField {
  const { stem, ext } = renameParts(options.name, options.folder);
  const form = el('form', 'ed-rename ed-as-rename');
  const input = textInput(stem, options.placeholder);
  const tail = el('span', 'ed-as-rename-ext', ext);
  tail.hidden = ext === '';
  form.append(input, tail);
  let over = false;
  let sending = false;

  const nameNow = (): string => renamedName(input.value, ext);
  /** The name as it is typed, checked: red with the refusal, or clear. */
  const check = (): Refused | null => {
    const name = nameNow();
    const valid = validName(name, { folder: options.folder });
    const refused = 'refused' in valid ? { refused: valid.refused, ...(valid.suggested !== undefined ? { suggested: valid.suggested } : {}) } : null;
    show(refused);
    options.typed?.(name, refused);
    return refused;
  };
  const show = (refused: Refused | null): void => {
    input.classList.toggle('ed-bad', refused !== null);
    input.title = refused ? `${refused.refused}${refused.suggested ? ` -- ${refused.suggested} would do` : ''}` : 'Enter renames, Esc leaves it as it was';
  };
  const finish = (): void => {
    if (over) return;
    over = true;
    unwatch();
    options.done();
  };
  const unwatch = onCloseRequest(finish);

  const unchanged = (): boolean => !options.fresh && nameNow() === options.name;
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (sending || over) return;
    if (unchanged()) return finish();
    if (check()) return;
    sending = true;
    input.readOnly = true;
    void options.commit(nameNow()).then((refused) => {
      sending = false;
      input.readOnly = false;
      if (!refused) return finish();
      // Refused: kept open, red, its words said -- and the field still the one typed in.
      show(refused);
      options.typed?.(nameNow(), refused);
      input.focus();
    });
  });
  input.addEventListener('input', () => void check());
  input.addEventListener('blur', () => {
    if (sending || over) return;
    // Left: committed as it is -- unless unchanged, or refused here already, which is said and let be.
    if (unchanged() || check()) return finish();
    sending = true;
    void options.commit(nameNow()).finally(finish);
  });
  queueMicrotask(() => {
    input.focus();
    input.select();
  });
  return {
    form,
    input,
    use(name) {
      input.value = renameParts(name, options.folder).stem;
      check();
      input.focus();
    },
    cancel: finish,
  };
}
