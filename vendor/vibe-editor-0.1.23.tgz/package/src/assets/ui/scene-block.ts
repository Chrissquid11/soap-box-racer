/**
 * The Assets tool's Scene block (Docs/assets-tool.md §6): what the inspector
 * says of a scene file (`src/assets/scenes/**\/*.scene`, Docs/ecs.md §19) under
 * its preview -- its key, how many entities it holds, its size and when it was
 * last written, whether the game opens it on start, and Open: the scene in
 * place of the world, as a double-click on its tile does (the open scene's
 * changes asked about first). Dragged onto the scene, a scene file does
 * nothing: a scene is opened, not placed.
 */
import type { SceneFile } from '@vibe/engine';
import { button, el } from '../../shell.ts';
import { ago, dateOf } from '../../when.ts';

/** What the block asks of the tool. */
export interface SceneBlockHost {
  /** The scene file as the page holds it; undefined until the dev server's update has brought it. */
  file(key: string): SceneFile | undefined;
  /** Its size in bytes and when it was written, as the index has them. */
  readonly size: number;
  readonly mtime: number;
  /** The scene the game opens on start, or null for its own world. */
  readonly start: string | null;
  /** The scene opened in place of the world, as the Scenes page's Open does. */
  open(key: string): void;
}

const sayBytes = (n: number): string => (n < 1024 ? `${n} B` : n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`);

/** The Scene block for `key`. */
export function sceneBlock(key: string, host: SceneBlockHost): HTMLElement {
  const s = el('div', 'ed-component ed-as-block');
  s.append(el('div', 'ed-component-head', 'Scene'));
  const file = host.file(key);
  const grid = el('div', 'ed-as-stats');
  const line = (label: string, value: string, title?: string): void => {
    const v = el('span', 'ed-as-stat', value);
    if (title) v.title = title;
    grid.append(el('span', 'ed-dim', label), v);
  };
  line('Name', key, `game.load(scene('${key}'))`);
  const count = file && Array.isArray(file.entities) ? file.entities.length : null;
  line('Entities', count === null ? '…' : String(count));
  line('Size', sayBytes(host.size));
  if (host.mtime > 0) line('Modified', ago(host.mtime, Date.now()), dateOf(host.mtime));
  line('On start', host.start === key ? 'yes: the game opens it' : 'no', 'Config ▸ Game ▸ Scenes picks the scene the game opens on start');
  s.append(grid);
  const buttons = el('div', 'ed-buttons');
  const open = button('scene_open', 'Open', file ? `${key} in place of the world (a double-click on it does too)` : `${key} is not in the page yet: a moment`, () => host.open(key), 'ed-small ed-accent');
  open.disabled = !file;
  buttons.append(open);
  s.append(buttons);
  return s;
}
