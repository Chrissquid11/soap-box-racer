/**
 * The boot set's bytes (Docs/assets-tool.md §3): what the game downloads
 * before its first frame -- every file under the boot root that ships, an
 * export or a loose file, `levels/` included (the game loads them first too),
 * in the build (`Entry.included`: a source unticked ships no export) -- against
 * the tool's budget, and bytes as the tool says them. The only
 * total of it: the Assets row in Folders, the import sheet's, the inspector's.
 *
 * And every folder's size (§3), as its row in Folders and its tile say it:
 * under a root that ships, the bytes that ship from it (`bytesUnder`: its
 * exports and loose files); on the Source side, how many files, their bytes on
 * hover -- so the two sides read apart at a glance (`sizeSaid`). Kept up the
 * changed paths only, as the marks' counts are (`createSizes`, `sizeChanged`):
 * never summed again from the whole index for a message.
 *
 * Pure: node tests it (`budget.test.ts`).
 */
import type { Entry } from '@vibe/pipeline/assets-types';
import { dirName, under } from '@vibe/pipeline/paths';
import { PROJECT } from '../model.ts';

/** What the boot set may weigh before its row goes amber, unless a game's `createAssetsTool({ budget })` says otherwise: 8 MB. */
export const BUDGET = 8 << 20;

/** Does this file download before the first frame: under the boot root, and shipped -- an export or a loose file, in the build. */
export const inBootSet = (entry: Entry): boolean => entry.root === 'boot' && shipsFile(entry);

/** Does this file ship, wherever it is: an export or a loose file -- the boot set's, a pack's -- in the build: an unticked source's export counts for nothing. */
export const shipsFile = (entry: Entry): boolean => (entry.role === 'export' || entry.role === 'loose') && entry.included;

/** The boot set's bytes, over the client index. */
export function bootBytes(entries: Iterable<Entry>): number {
  let bytes = 0;
  for (const entry of entries) if (inBootSet(entry)) bytes += entry.size;
  return bytes;
}

/** Bytes as the tool says them: `512 B`, `412 KB`, `1.1 MB`, `2.0 GB`. */
export function sayBytes(bytes: number): string {
  if (bytes < 1024) return `${Math.max(0, Math.round(bytes))} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

/** `n` files, said. */
export const filesText = (n: number): string => `${n} ${n === 1 ? 'file' : 'files'}`;

// ---------------------------------------------------------------- a folder's size

/** What a folder holds, everything under it: its files -- records left out, which are shown as options -- their bytes on disk, and the bytes of those that ship. */
export interface FolderSize {
  readonly files: number;
  readonly bytes: number;
  readonly ships: number;
}

const NOTHING: FolderSize = { files: 0, bytes: 0, ships: 0 };

/** What one file adds to every folder it is under: nothing for a record. */
const sizeOf = (entry: Entry): FolderSize => (entry.role === 'record' ? NOTHING : { files: 1, bytes: entry.size, ships: shipsFile(entry) ? entry.size : 0 });

/** Is a path under a folder -- under the project (`''`), every path is. */
const inside = (path: string, folder: string): boolean => folder === PROJECT || under(path, folder);

/** What `folder` holds, from the whole index: the definition the kept sizes (`createSizes`) are held to. */
export function sizeUnder(entries: Iterable<Entry>, folder: string): FolderSize {
  let files = 0;
  let bytes = 0;
  let ships = 0;
  for (const entry of entries) {
    if (!inside(entry.path, folder)) continue;
    const own = sizeOf(entry);
    files += own.files;
    bytes += own.bytes;
    ships += own.ships;
  }
  return { files, bytes, ships };
}

/** The bytes that ship from under `folder`: the sum of its exports and loose files -- what a folder under Assets or a pack says. */
export function bytesUnder(entries: Iterable<Entry>, folder: string): number {
  return sizeUnder(entries, folder).ships;
}

/** Every folder's size, kept as files change: each file's counted in every folder it is under, up to the project. */
export interface FolderSizes {
  /** The file at `path` is `entry` now, or gone (undefined): what it counted before taken off up its folders, what it counts now put on. */
  set(path: string, entry: Entry | undefined): void;
  /** What `folder` holds; nothing for a folder with no file under it. */
  of(folder: string): FolderSize;
  /** Every size forgotten: a whole tree comes next. */
  clear(): void;
}

export function createSizes(): FolderSizes {
  /** What each file counted, by path. */
  const counted = new Map<string, FolderSize>();
  /** Each folder's sum, the project's among them. */
  const folders = new Map<string, { files: number; bytes: number; ships: number }>();

  /** `own` added to (`by` 1) or taken from (-1) every folder `path` is under, the project last. */
  const up = (path: string, own: FolderSize, by: 1 | -1): void => {
    for (let dir = dirName(path), last = false; !last; dir = dirName(dir)) {
      last = dir === PROJECT;
      let sum = folders.get(dir);
      if (!sum) folders.set(dir, (sum = { files: 0, bytes: 0, ships: 0 }));
      sum.files += by * own.files;
      sum.bytes += by * own.bytes;
      sum.ships += by * own.ships;
      if (sum.files <= 0) folders.delete(dir);
    }
  };

  return {
    set(path, entry) {
      const was = counted.get(path);
      const now = entry ? sizeOf(entry) : NOTHING;
      if (was && was.files === now.files && was.bytes === now.bytes && was.ships === now.ships) return;
      if (was) {
        up(path, was, -1);
        counted.delete(path);
      }
      if (now.files === 0) return;
      counted.set(path, now);
      up(path, now, 1);
    },
    of: (folder) => folders.get(folder) ?? NOTHING,
    clear() {
      counted.clear();
      folders.clear();
    },
  };
}

/** Every folder's size, from the whole index: a whole tree came. */
export function sizeAll(sizes: FolderSizes, entries: ReadonlyMap<string, Entry>): void {
  sizes.clear();
  for (const entry of entries.values()) sizes.set(entry.path, entry);
}

/** The sizes after a diff (§9: up the changed paths only): each path it named -- added, updated or removed -- counted again. */
export function sizeChanged(sizes: FolderSizes, paths: Iterable<string>, entries: ReadonlyMap<string, Entry>): void {
  for (const path of paths) sizes.set(path, entries.get(path));
}

/**
 * A folder's size as its row and its tile say it (§3): under a root that
 * ships (`shipping`), the bytes that ship from it; on the Source side, how many
 * files, their bytes on disk on hover -- never bytes, so the sides read apart.
 */
export function sizeSaid(size: FolderSize, shipping: boolean): { text: string; title: string } {
  if (shipping) {
    return { text: sayBytes(size.ships), title: `${sayBytes(size.ships)} ships from here: ${size.ships.toLocaleString('en')} bytes, its exports and loose files` };
  }
  return { text: filesText(size.files), title: `${filesText(size.files)} · ${sayBytes(size.bytes)} on disk` };
}
