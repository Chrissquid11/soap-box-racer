/**
 * The Model tab's files as steps of the Assets panel's stack (Docs/modeler.md
 * M38, M39; Docs/assets-tool.md §8, "Undo"), as New scene and an import are:
 *
 * | Step | Calls | Undo | Redo |
 * | --- | --- | --- | --- |
 * | New model Test Thing | `POST model` | the script's family -- its record, the export made since -- to the trash | that slot restored |
 * | Make a script for rock.glb | `POST adopt`, then its export waited for | the script, its copy and its record to the trash, alone; then the `.glb` it replaced restored from the export's slot | the built `.glb` back from where the undo put it, then the script's files |
 *
 * - **New model does not wait for its build**: the Model tab opens at once and
 *   says "Building…"; an undo while the export runs drops its job (`POST
 *   delete`), so nothing is left behind.
 * - **Make a script waits for its export**: the `.glb` it replaces is in the
 *   slot its `done` names, and its undo puts that file back -- the key the game
 *   loads never without a file. An export that failed replaced nothing: its undo
 *   takes the script's files away and the `.glb` is as it was.
 * - Each call takes the slot the one before it answered, so Z and Y go round as
 *   often as asked.
 *
 * Imports types alone: node tests it with a stand-in API (`model-steps.test.ts`).
 */
import type { Entry, JobMessage, ModelMadeAnswer } from '@vibe/pipeline/assets-types';
import type { Api } from '../api.ts';
import type { Answered, Doing } from '../steps.ts';
import type { Edit } from './file-steps.ts';
import { jobEnded } from './marks.ts';

export interface ModelStepHost {
  api: Pick<Api, 'newModel' | 'adopt' | 'remove' | 'restore'>;
  /** Hear the `job` messages (`live.on('job', …)`). Returns the undo. */
  jobs(listener: (job: JobMessage) => void): () => void;
  /** The client index's entries: whether the script's record is there to take away. */
  entries(): ReadonlyMap<string, Entry>;
}

/** The record of a script: `crate.lua` -> `crate.export.json`. */
const recordOf = (script: string): string => script.replace(/\.lua$/i, '.export.json');

/** New model `name` in `dir`: the script written, its export queued; `made` told the script's path as the first doing answers. */
export function newModelEdit(host: ModelStepHost, dir: string, name: string, made: (answer: ModelMadeAnswer) => void): Edit {
  let path = '';
  let slot: string | undefined;
  return {
    label: `New model ${name}`,
    async first() {
      const answer = await host.api.newModel(dir, name);
      path = answer.path;
      made(answer);
      return answer;
    },
    async undo() {
      // The whole family: the record and the export made since go with it, a job still running is dropped.
      const gone = await host.api.remove([path]);
      slot = gone.slot;
      return gone;
    },
    async redo() {
      if (slot === undefined) throw new Error('the new model is not in the trash to bring back');
      return host.api.restore(slot, { replace: true });
    },
  };
}

/** What Make a script made: the script, its copy, and the `.glb` its export replaced, in a slot (none if the export failed). */
export interface Adopted {
  answer: ModelMadeAnswer;
  /** How its export ended: `done`, or why not. */
  job: JobMessage | undefined;
}

/** Make a script for the `.glb` at `path`; `made` told once its export has ended. */
export function adoptEdit(host: ModelStepHost, path: string, made: (adopted: Adopted) => void): Edit {
  let files: string[] = [];
  /** The `.glb` the export replaced: in this slot while the script stands; null once the undo put it back. */
  let original: string | undefined;
  /** The undo's: the script's files, and the built `.glb` the original displaced. */
  let scriptSlot: string | undefined;
  let builtSlot: string | undefined;
  const first: Doing = async () => {
    const ended = new Map<string, JobMessage>();
    let wanted: string | undefined;
    let resolve: () => void = () => {};
    const finished = new Promise<void>((r) => (resolve = r));
    // Heard from before the call: the job may end before its answer comes.
    const off = host.jobs((job) => {
      if (!jobEnded(job.state)) return;
      ended.set(job.id, job);
      if (job.id === wanted) resolve();
    });
    try {
      const answer = await host.api.adopt(path);
      files = [answer.path, ...(answer.copy !== undefined ? [answer.copy] : [])];
      wanted = answer.jobs[0]?.id;
      if (wanted !== undefined && !ended.has(wanted)) await finished;
      const job = wanted !== undefined ? ended.get(wanted) : undefined;
      original = job?.state === 'done' ? job.slot : undefined;
      made({ answer, job });
      return answer;
    } finally {
      off();
    }
  };
  const undo: Doing = async () => {
    const script = files[0]!;
    const own = [...files, ...(host.entries().has(recordOf(script)) ? [recordOf(script)] : [])];
    const gone = await host.api.remove(own, true);
    scriptSlot = gone.slot;
    let last: Answered = gone;
    if (original !== undefined) {
      const back = await host.api.restore(original, { replace: true });
      builtSlot = back.slot;
      last = back;
    }
    return last;
  };
  const redo: Doing = async () => {
    let last: Answered | undefined;
    // The built `.glb` first, then the script that made it: the record never reads against the file it did not make.
    if (builtSlot !== undefined) {
      const back = await host.api.restore(builtSlot, { replace: true });
      original = back.slot;
      last = back;
    }
    if (scriptSlot === undefined) throw new Error('the script is not in the trash to bring back');
    last = await host.api.restore(scriptSlot, { replace: true });
    return last;
  };
  return { label: `Make a script for ${path.slice(path.lastIndexOf('/') + 1)}`, first, redo, undo };
}
