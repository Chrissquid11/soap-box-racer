/**
 * The files card's search (Docs/assets-tool.md §4): words, each of which a
 * file's name, its key or its twin's name must hold; `status:stale`,
 * `kind:models`, `role:source`, `ext:png`; and `#crate`, a key holding `crate`
 * in any folder. Case does not matter; a prefix it does not know is read as a
 * word (`foo:bar`). Several of one prefix are any of them; words and prefixes
 * are all of them.
 *
 * - **Where it looks** (`searched`): the open folder and everything under it,
 *   as one flat list -- from the project (`''`), every root and the Trash's
 *   files; every folder's entries, with `#` (`everywhere`).
 *
 * Pure: node tests it (`file-filter.test.ts`).
 */
import type { Entry, TrashFile } from '@vibe/pipeline/assets-types';
import { TRASH } from '@vibe/pipeline/kinds';
import { baseName, extOf, under } from '@vibe/pipeline/paths';
import { PROJECT, type Shown } from '../model.ts';
import { keyOfRow, kindOfRow, twinOfRow } from './files-columns.ts';
import { isEntry, statusOf } from './marks.ts';

/** The prefixes a word may have. */
export const PREFIXES = ['status', 'kind', 'role', 'ext'] as const;
export type Prefix = (typeof PREFIXES)[number];

/** A search, read: the plain words, what each prefix must be (any of), the keys `#` asks for, and whether it looks everywhere. */
export interface Query {
  words: string[];
  is: Record<Prefix, string[]>;
  /** `#crate`: a key holding each; `#` alone, any key. */
  keys: string[];
  anyKey: boolean;
  /** A `#` in it: every folder, not only the open one. */
  everywhere: boolean;
}

/** What a row is searched by. */
export interface Facts {
  name: string;
  key?: string;
  twin?: string;
  status?: string;
  kind?: string;
  role?: string;
  ext: string;
}

/** The text in the field, read; null when there is nothing to search for. */
export function readQuery(text: string): Query | null {
  const query: Query = { words: [], is: { status: [], kind: [], role: [], ext: [] }, keys: [], anyKey: false, everywhere: false };
  let any = false;
  for (const raw of text.toLowerCase().split(/\s+/)) {
    if (raw === '') continue;
    any = true;
    if (raw.startsWith('#')) {
      query.everywhere = true;
      const key = raw.slice(1);
      if (key === '') query.anyKey = true;
      else query.keys.push(key);
      continue;
    }
    const colon = raw.indexOf(':');
    const prefix = colon > 0 ? raw.slice(0, colon) : '';
    const value = colon > 0 ? raw.slice(colon + 1) : '';
    if ((PREFIXES as readonly string[]).includes(prefix) && value !== '') {
      query.is[prefix as Prefix].push(prefix === 'ext' ? value.replace(/^\./, '') : value);
    } else query.words.push(raw);
  }
  return any ? query : null;
}

/** Does a row with these facts pass? */
export function passes(query: Query, facts: Facts): boolean {
  const name = facts.name.toLowerCase();
  const key = facts.key?.toLowerCase();
  const twin = facts.twin?.toLowerCase();
  for (const word of query.words) {
    if (!name.includes(word) && !key?.includes(word) && !twin?.includes(word)) return false;
  }
  for (const prefix of PREFIXES) {
    const wanted = query.is[prefix];
    if (wanted.length === 0) continue;
    const has = facts[prefix]?.toLowerCase();
    if (has === undefined || !wanted.includes(has)) return false;
  }
  if (query.anyKey && key === undefined) return false;
  for (const part of query.keys) if (key === undefined || !key.includes(part)) return false;
  return true;
}

/**
 * A row's facts, from the client index: an export's key, a source's its
 * export's; the twin the other side of the family; the status a source has
 * and its export carries. A file in the trash has its name, kind and
 * extension only, its kind from the path it had.
 */
export function factsOf(row: Shown, entries: ReadonlyMap<string, Entry>): Facts {
  const kind = kindOfRow(row);
  const key = keyOfRow(row, entries);
  const twin = twinOfRow(row, entries);
  const status = statusOf(row, entries);
  return {
    name: baseName(row.path),
    ext: extOf(row.path),
    ...(isEntry(row) ? { role: row.role } : {}),
    ...(kind !== undefined ? { kind } : {}),
    ...(key !== undefined ? { key } : {}),
    ...(twin !== undefined ? { twin: baseName(twin) } : {}),
    ...(status !== undefined ? { status } : {}),
  };
}

/**
 * What a search looks through, before its words: every entry under `folder`
 * -- under the project (`PROJECT`), every one -- but a record, which is shown
 * as options, never as a file; and the Trash's files (`trashed`, every slot's)
 * under it, from the project or the Trash. `everywhere` (`#`): every entry,
 * the Trash's files left out -- they have no key to be found by.
 */
export function searched(entries: Iterable<Entry>, trashed: Iterable<TrashFile>, folder: string, everywhere: boolean): Shown[] {
  const within = (path: string): boolean => everywhere || folder === PROJECT || under(path, folder);
  const rows: Shown[] = [];
  for (const e of entries) if (e.role !== 'record' && within(e.path)) rows.push(e);
  if (!everywhere && (folder === PROJECT || under(folder, TRASH))) for (const f of trashed) if (within(f.path)) rows.push(f);
  return rows;
}
