/**
 * The import sheet (Docs/assets-tool.md §5): a card over the files card,
 * never a dialog, for the folder it opened for -- a drop, a picker, a paste --
 * built from the pure plan (`import-plan.ts`), so what it shows is what part
 * one's own code decides.
 *
 * - **It opens at once**, and reads each owner after (`parts-browser.ts`):
 *   "reading robot.fbx for its parts · 40 %", then **part of robot.fbx**; a
 *   `.glb` by its head alone. Each row's name is a field, checked by `GET
 *   names` as it is typed, a refusal red with the server's words and its
 *   suggestion a click away; its role, a switch where it may be either, the
 *   fixes of a refused one, the tick of what it replaces, its tick in the
 *   build -- a source's sent `include=false`, one as delivered named `_` in its
 *   field -- with "Same for all" where the others differ, ×, and its recipe's
 *   options folded -- drawn by the Options block's own rows (`optionRow`),
 *   planned over the destination's folders' `export.json` (`planFields`), so
 *   a folder's default is grey with where it comes from, a value set to what
 *   is inherited is no override, and a value `PUT sidecar` would refuse is
 *   said under its field and holds Import. Totals, and the boot set against
 *   the budget.
 * - **One `<form>`**, whose submit is Import: Enter in a name field or on the
 *   button sends it, the browser's own, and does nothing while a row is
 *   refused (the button disabled). An option's field is a `<form>` of its own
 *   nested in it (`fields.ts`, made by script), so Enter there commits the
 *   option, never imports: the sheet acts only on its own submit. It opens
 *   with the focus on Import, moved to the first refused name if one comes.
 *   A click on ×, a fix, a flip or Options lets go of the focus (the tool's
 *   rule for a button a pointer used), so Enter is then the tool's key
 *   `assets import` (`submit`, `requestSubmit`): the hint's "Enter imports"
 *   holds wherever the focus went, and says what holds Import while a row does.
 * - **Import is one step** (`file-steps.ts`'s `importEdit`): `PUT import` a
 *   row each, owners first, the bytes going up on each row (`XMLHttpRequest`),
 *   then each export's steps from its `job` messages -- by the drop's own jobs,
 *   which its last file's answer names (`jobs`), and "converting in this tab"
 *   where this tab holds one's browser step; a failure keeps its row, its
 *   error and **Retry**, which sends the name typed in its field since. The
 *   folders it makes are read first (`newFolders`): its undo takes them away.
 * - **It closes** once every row's file is in the index and every job it
 *   queued has ended (`arrival`) -- the index having the last word: a source
 *   current is in, whatever a job said; a row failed or unmade keeps it up,
 *   with its line, until **Close**. Close is there at any time: before every row is in
 *   it stops the upload under way and trashes what was written, as one `POST
 *   delete` -- nothing half-imported; after, the jobs go on in the strip. Esc
 *   is Close (the tool's `cancel`), from a name field only where the browser
 *   has a close request; the card takes the focus on a press on its own space,
 *   so Esc is the host's again.
 * - **A drop while it is open joins it**, for its folder, whatever the files
 *   card shows meanwhile.
 */
import type { ImportAnswer, JobMessage, NameAnswer, ToolLook } from '@vibe/pipeline/assets-types';
import { joinPath, splitName } from '@vibe/pipeline/paths';
import { onCloseRequest, textInput } from '../../fields.ts';
import { button, control, el } from '../../shell.ts';
import type { Api } from '../api.ts';
import { PROJECT, type ClientIndex } from '../model.ts';
import { reasonOf, type Steps } from '../steps.ts';
import { sayBytes } from './budget.ts';
import type { ReadDrop } from './dnd.ts';
import { importEdit, type EditHost } from './file-steps.ts';
import { isMove, optionRow, planFields, targetOf, withOption, type Records, type RowSpec } from './assets-options.ts';
import { arrival, importQuery, nameQueries, newFolders, planImport, tickedName, type Arrival, type Choice, type Plan, type PlanRow, type Scan } from './import-plan.ts';
import { jobEnded } from './marks.ts';
import type { Naming } from './naming.ts';
import { readGlbHead, scanFile } from './parts-browser.ts';

/** How long typing in a name waits for the next key before `GET names` is asked. */
const ASK_MS = 150;
/** A name being checked: it holds Import no longer than that. */
const CHECKING = 'its name is being checked';

export interface SheetHost {
  readonly index: ClientIndex;
  readonly naming: Naming;
  readonly api: Api;
  readonly steps: Pick<Steps, 'run'>;
  readonly budget: number;
  /** The files card: the sheet goes in it, over everything it shows. */
  readonly card: HTMLElement;
  /** The records and folders' `export.json`, read through `GET file`: a row's options are planned over its destination's. */
  readonly records: Records;
  /** What an edit tells the tool and asks of the index. */
  readonly edits: EditHost;
  tools(): readonly ToolLook[] | null;
  /** The `job` messages, and the index moving: a sent row followed. Each returns its undo. */
  onJob(fn: (job: JobMessage) => void): () => void;
  onChanged(fn: () => void): () => void;
  /** Is a job queued or running for this source? */
  running(source: string): boolean;
  /** Is this job's browser step being done in this tab (`convert.ts`)? Its row says "converting in this tab". */
  converting(job: string): boolean;
  /** Up or down: the tool's keys and hint read again. */
  changed(): void;
  say(text: string, bad?: boolean): void;
  /**
   * The files written, owners first, once the step is on the stack: the files card shows where they landed; `scripts`,
   * those written as a Gladius script importing the file (Docs/modeler.md M39), the first opened in the Model tab.
   */
  landed(paths: readonly string[], scripts: readonly string[]): void;
  /** The folders the sheet may be moved to before Import -- its kind's, as the head's Into list offers them. */
  folders?(folder: string): readonly string[];
}

export interface ImportSheet {
  readonly open: boolean;
  /** The folder it is for, while it is open. */
  readonly folder: string | null;
  /** The hint's line for it: what Enter and Esc do just now. */
  readonly line: string;
  /** The card: lit as the files card's would be, a drop target over it. */
  readonly root: HTMLElement;
  /** Files for `folder` -- or, open already, for its own folder: they join it. */
  /**
   * `scripts`: the files picked from the Model tab (Import model…, Docs/modeler.md M39) -- a `.glb` or `.fbx` among
   * them a Gladius script by default; anywhere else a file is its own source by default, the row's switch there.
   */
  add(folder: string, read: ReadDrop, scripts?: boolean): void;
  /** Close: before Import, nothing sent; while sending, the upload stopped and what was written trashed; after, the jobs go on. */
  close(): void;
  /**
   * Enter with the focus on no control of the sheet's -- after a click on ×,
   * a fix or Options, which let go of it: Import, as the form's own Enter
   * would (`assets import`, a MrDebug key live while the sheet is up).
   */
  submit(): void;
  /** Drawn again: the tools answered (a `.glb` beside a `.blend` is a hand export only without Blender), a conversion taken here. */
  refresh(): void;
  dispose(): void;
}

/** A row once Import was pressed: waiting its turn, its bytes going up, in, or refused. */
type Sent = { state: 'waiting' } | { state: 'uploading'; sent: number; total: number } | { state: 'in'; path: string } | { state: 'failed'; error: string };

/** A row's elements, made once and patched. */
interface RowView {
  root: HTMLElement;
  skip: HTMLButtonElement;
  input: HTMLInputElement;
  was: HTMLElement;
  refusal: HTMLElement;
  refusalText: HTMLElement;
  use: HTMLButtonElement;
  role: HTMLElement;
  flip: HTMLButtonElement;
  /** A `.glb` or `.fbx` under models: as a Gladius script, or the file as it is. */
  scriptFlip: HTMLButtonElement;
  replace: HTMLLabelElement;
  tick: HTMLInputElement;
  replaceText: HTMLElement;
  /** In the build: its tick, and the others put the same. */
  build: HTMLLabelElement;
  buildTick: HTMLInputElement;
  same: HTMLButtonElement;
  line: HTMLElement;
  fixes: HTMLElement;
  fixesFor: string;
  fold: HTMLButtonElement;
  options: HTMLElement;
  /** What its options were last drawn from: the recipe, the destination, the overrides, what the folders said. */
  optionsFor: string | null;
  progress: HTMLElement;
  bar: HTMLElement;
  words: HTMLElement;
  retry: HTMLButtonElement;
}

interface Session {
  folder: string;
  /** The step's label as sent: what the line says once it is all in. */
  label: string;
  files: Array<{ rel: string; file: File }>;
  skipped: string[];
  choices: Map<number, Choice>;
  scans: Map<number, Scan>;
  names: Map<number, NameAnswer>;
  plan: Plan;
  /** Planning; Import pressed and on its way; every file sent. */
  phase: 'plan' | 'sending' | 'after';
  /** The rows as they were sent: the plan stops being worked out once Import is pressed. */
  frozen: Plan | null;
  sent: Map<number, Sent>;
  /** The scripts its rows were written as (`ImportAnswer.script`): opened in the Model tab as it lands. */
  scripts: Set<string>;
  /** The last `job` message by source, and by job: a row goes by its drop's own job once the import's answer names it (`ids`). */
  jobs: Map<string, JobMessage>;
  byId: Map<string, JobMessage>;
  ids: Map<string, string>;
  reading: AbortController;
  upload: AbortController | null;
  started: Set<string>;
  open: Set<number>;
  asked: number;
  asking: ReturnType<typeof setTimeout> | undefined;
  /** Enter pressed while a name was being checked: sent once the answer allows it. */
  waiting: boolean;
  /** An option's value refused under its field, by row and option: Import held, saying it, until it is fixed or the row skipped. */
  refused: Map<number, Map<string, string>>;
  /** The head's filter: only the rows that hold Import back are shown. Let go by itself once none is left. */
  problemsOnly: boolean;
  /** Was anything ever a problem this session: the "no problems left" line is said only after one was. */
  sawProblems: boolean;
  offs: Array<() => void>;
}

export function createImportSheet(host: SheetHost): ImportSheet {
  const { index, naming, api } = host;
  const root = el('div', 'ed-card ed-as-sheet');
  root.tabIndex = -1;
  root.hidden = true;
  const form = el('form', 'ed-as-sheet-form');
  form.noValidate = true;
  const head = el('div', 'ed-as-sheet-head');
  const title = el('div', 'ed-side-title ed-as-title');
  const closeButton = button('ui', 'Close', 'Close the sheet (Esc): before Import nothing is sent; while it sends, the upload stops and what was written goes to the trash; after, the jobs go on in the strip', () => close(), 'ed-small');
  // The rows that hold Import back, alone; and every suggested name taken at once.
  const problemsButton = button('ui', '', '', () => {
    if (!s) return;
    s.problemsOnly = !s.problemsOnly;
    draw();
  }, 'ed-small ed-quiet ed-as-sheet-problems');
  problemsButton.setAttribute('aria-pressed', 'false');
  const fixAllButton = button('ui', '', '', () => fixAll(), 'ed-small ed-as-sheet-fix-all');
  const headTools = el('div', 'ed-buttons ed-as-sheet-head-tools');
  headTools.append(problemsButton, fixAllButton, closeButton);
  // Where it all goes, changed before Import: every folder of the destination's kind (a models folder's: the models').
  const intoPick = el('select', 'ed-input ed-small ed-as-sheet-into');
  intoPick.setAttribute('aria-label', 'The folder the files are imported into');
  intoPick.title = 'Import into another folder: the rows planned again there';
  intoPick.addEventListener('change', () => {
    if (!s || s.phase !== 'plan' || intoPick.value === s.folder) return;
    s.folder = intoPick.value;
    host.say(`The import goes into ${naming.say(s.folder)} now`);
    replan();
    draw();
    ask();
    host.changed();
  });
  let intoFor = '';
  const headLeft = el('div', 'ed-as-sheet-head-left');
  headLeft.append(title, intoPick);
  head.append(headLeft, headTools);
  const rows = el('div', 'ed-as-sheet-rows');
  const noProblems = el('div', 'ed-dim ed-as-sheet-none', 'No problems left: every row can go as it is');
  noProblems.hidden = true;
  rows.append(noProblems);
  const foot = el('div', 'ed-as-sheet-foot');
  const skippedLine = el('div', 'ed-dim');
  const totals = el('div', 'ed-as-sheet-totals');
  const bootLine = el('div', 'ed-dim');
  const go = control('asset_import', 'ed-button ed-accent ed-as-sheet-go');
  go.type = 'submit';
  const footLine = el('div', 'ed-as-sheet-foot-line');
  footLine.append(totals, go);
  foot.append(skippedLine, bootLine, footLine);
  form.append(head, rows, foot);
  root.append(form);
  host.card.append(root);

  let s: Session | null = null;
  const views = new Map<number, RowView>();

  // ---------------------------------------------------------------- the plan, worked out again

  function replan(): void {
    if (!s) return;
    const blender = (host.tools() ?? []).some((t) => t.tool === 'blender' && t.state === 'found');
    const gladius = (host.tools() ?? []).some((t) => t.tool === 'gladius' && t.state === 'found');
    s.plan = planImport(
      { dest: s.folder, files: s.files.map((f) => ({ rel: f.rel, size: f.file.size })), skipped: s.skipped, entries: index.entries, blender, gladius, budget: host.budget, say: naming.say },
      s.choices,
      s.scans,
      s.names,
    );
  }

  let frame = 0;
  /** Drawing in a frame of its own, not inside a change: where a row's options may be drawn again (`drawRow`). */
  let inFrame = false;
  /** Drawn the next frame: a scan's progress, an answer. */
  function soon(): void {
    if (frame !== 0) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      if (!s) return;
      if (s.phase === 'plan') replan();
      inFrame = true;
      try {
        draw();
      } finally {
        inFrame = false;
      }
      read();
    });
  }

  const choice = (id: number): Choice => {
    const had = s!.choices.get(id);
    if (had) return had;
    const made: Choice = {};
    s!.choices.set(id, made);
    return made;
  };
  /** Is this row what holds Import back: a refused name or kind, a replace not ticked, an option refused? Never one being checked, nor one skipped. */
  const problem = (row: PlanRow): boolean =>
    !row.skip && ((row.blocked !== null && row.blocked !== CHECKING) || s!.refused.has(row.id));

  /** Every refused name's suggestion taken at once: one replan, one ask. */
  function fixAll(): void {
    if (!s || s.phase !== 'plan') return;
    let n = 0;
    for (const row of s.plan.rows) {
      if (row.skip || row.checked.state !== 'refused' || row.checked.suggested === undefined) continue;
      choice(row.id).name = row.checked.suggested;
      const input = views.get(row.id)?.input;
      if (input) input.value = row.checked.suggested;
      n++;
    }
    if (n === 0) return;
    replan();
    draw();
    read();
    askSoon();
    host.changed();
  }

  /** A change of the person's: the plan again, drawn now, the names asked again. */
  function chose(id: number, change: Partial<Choice>, ask = false): void {
    if (!s || s.phase !== 'plan') return;
    Object.assign(choice(id), change);
    replan();
    draw();
    read();
    if (ask) askSoon();
    host.changed();
  }

  // ---------------------------------------------------------------- reading owners, asking names

  /** Each row the plan wants read and not yet read: an owner for its parts, a `.glb` for its head. */
  function read(): void {
    const session = s;
    if (!session || session.phase !== 'plan') return;
    for (const want of session.plan.reads) {
      const key = `${want.id}:${want.what}`;
      if (session.started.has(key)) continue;
      session.started.add(key);
      const file = session.files[want.id]!.file;
      const done = (scan: Scan): void => {
        if (s !== session) return;
        session.scans.set(want.id, scan);
        soon();
      };
      if (want.what === 'head') {
        readGlbHead(file).then((head) => done({ state: 'done', read: file.size, head }), (err) => done({ state: 'failed', read: 0, error: reasonOf(err) }));
        continue;
      }
      if (!want.deps) continue;
      session.scans.set(want.id, { state: 'reading', read: 0 });
      scanFile(file, want.deps(want.path), {
        signal: session.reading.signal,
        progress: (n) => {
          if (s !== session) return;
          session.scans.set(want.id, { state: 'reading', read: n });
          soon();
        },
      }).then((names) => done({ state: 'done', read: file.size, names }), (err) => {
        if (!session.reading.signal.aborted) done({ state: 'failed', read: 0, error: reasonOf(err) });
      });
    }
  }

  function askSoon(): void {
    if (!s) return;
    clearTimeout(s.asking);
    s.asking = setTimeout(ask, ASK_MS);
  }

  /** `GET names` for every row that goes, a call a destination; an answer to an older ask dropped. */
  function ask(): void {
    const session = s;
    if (!session || session.phase !== 'plan') return;
    const asked = ++session.asked;
    for (const query of nameQueries(session.plan)) {
      api.names(query.dest, query.names).then((answers) => {
        if (s !== session || session.asked !== asked) return;
        answers.forEach((answer, i) => session.names.set(query.ids[i]!, answer));
        answered();
      }, (err) => {
        if (s !== session || session.asked !== asked) return;
        // Unchecked here: Import may go, and the server checks each name again as it writes.
        query.names.forEach((name, i) => session.names.set(query.ids[i]!, { name, ok: true }));
        host.say(`The names were not checked: ${reasonOf(err)} -- the import checks each again`, true);
        answered();
      });
    }
  }

  /** Names answered: drawn; the focus to the first refused name if it is still on Import; a waiting Enter sent. */
  function answered(): void {
    if (!s) return;
    replan();
    draw();
    const refused = s.plan.rows.find((r) => !r.skip && r.checked.state === 'refused');
    if (refused && (document.activeElement === go || s.waiting)) {
      const input = views.get(refused.id)?.input;
      input?.focus();
      input?.select();
      s.waiting = false;
    }
    if (s.waiting && !s.plan.blocked) send(s.plan.sends);
    host.changed();
  }

  /**
   * Where a sent row's file is (`arrival`): judged by its drop's own job once
   * the import's answer named it -- not by another job for the same source,
   * an auto-export's -- else by the last message heard for it.
   */
  function came(session: Session, path: string): Arrival {
    const id = session.ids.get(path);
    const job = id !== undefined ? (session.byId.get(id) ?? { id, source: path, step: 0, of: 0, state: 'queued' }) : session.jobs.get(path);
    const running = host.running(path) || (id !== undefined && job !== undefined && !jobEnded(job.state));
    return arrival(path, index.entries, job, running, job !== undefined && host.converting(job.id));
  }

  // ---------------------------------------------------------------- the rows, drawn

  const put = (node: HTMLElement, text: string): void => {
    if (node.textContent !== text) node.textContent = text;
  };
  const show = (node: HTMLElement, on: boolean): void => {
    if (node.hidden === on) node.hidden = !on;
  };

  function viewOf(row: PlanRow): RowView {
    const had = views.get(row.id);
    if (had) return had;
    const id = row.id;
    const r = el('div', 'ed-as-sheet-row');
    const skip = button('ui', '×', '', () => chose(id, { skip: !choice(id).skip }), 'ed-small ed-quiet ed-as-sheet-skip');
    const name = el('div', 'ed-as-sheet-name');
    const field = el('div', 'ed-as-sheet-field');
    const input = textInput(row.name, 'name.ext');
    input.addEventListener('input', () => {
      if (s?.phase === 'plan') chose(id, { name: input.value }, true);
      // A failed row's new name, kept for its Retry: a redraw in between does not put the sent one back.
      else if (s?.sent.get(id)?.state === 'failed') choice(id).name = input.value;
    });
    field.append(input);
    const was = el('div', 'ed-dim ed-as-sheet-was');
    const refusal = el('div', 'ed-as-sheet-refusal');
    const refusalText = el('span', 'ed-as-red');
    const use = button('ui', '', '', () => {
      const plan = s?.plan.rows.find((p) => p.id === id);
      if (plan?.checked.state !== 'refused' || plan.checked.suggested === undefined) return;
      input.value = plan.checked.suggested;
      chose(id, { name: plan.checked.suggested }, true);
      input.focus();
    }, 'ed-small');
    refusal.append(refusalText, use);
    name.append(field, was, refusal);
    const what = el('div', 'ed-as-sheet-what');
    const role = el('span', 'ed-badge ed-as-sheet-role');
    const flip = button('ui', '', '', () => {
      const plan = s?.plan.rows.find((p) => p.id === id);
      if (plan) chose(id, { source: plan.role !== 'source' }, true);
    }, 'ed-small ed-quiet');
    const scriptFlip = button('ui', '', '', () => {
      const plan = s?.plan.rows.find((p) => p.id === id);
      if (plan) chose(id, plan.role === 'script' ? { script: false } : { script: true, source: true }, true);
    }, 'ed-small ed-quiet');
    const replace = el('label', 'ed-tick ed-as-sheet-replace');
    const tick = el('input');
    tick.type = 'checkbox';
    tick.addEventListener('change', () => chose(id, { replace: tick.checked }));
    const replaceText = el('span');
    replace.append(tick, replaceText);
    // In the build: a source's own tick, sent include=false; one as delivered, its name's `_` -- the field shows it.
    const build = el('label', 'ed-tick ed-as-sheet-build');
    const buildTick = el('input');
    buildTick.type = 'checkbox';
    buildTick.addEventListener('change', () => {
      const plan = s?.plan.rows.find((p) => p.id === id);
      if (!plan) return;
      if (plan.role === 'delivered') {
        const name = tickedName(plan.name, buildTick.checked);
        input.value = name;
        chose(id, { name }, true);
      } else chose(id, { include: buildTick.checked });
    });
    build.append(buildTick, el('span', undefined, 'in the build'));
    const same = button('ui', '', '', () => {
      const plan = s?.plan.rows.find((p) => p.id === id);
      if (!plan || !s) return;
      for (const other of s.plan.rows) {
        if (other.id === id || other.skip || !other.tick || other.include === plan.include) continue;
        if (other.role === 'delivered') choice(other.id).name = tickedName(other.name, plan.include);
        else choice(other.id).include = plan.include;
      }
      replan();
      draw();
      read();
      askSoon();
      host.changed();
    }, 'ed-small ed-quiet ed-as-sheet-same');
    what.append(role, flip, scriptFlip, build, same, replace);
    const line = el('div', 'ed-dim ed-as-sheet-line');
    const fixes = el('div', 'ed-buttons ed-as-sheet-fixes');
    const fold = button('ui', 'Options ▸', 'Its recipe\'s options: a default is grey', () => {
      if (!s) return;
      if (s.open.has(id)) s.open.delete(id);
      else s.open.add(id);
      draw();
    }, 'ed-small ed-quiet ed-as-sheet-fold');
    const options = el('div', 'ed-as-sheet-options');
    // A field typed in is never drawn again under it: as the focus leaves it, the options are, the next frame.
    options.addEventListener('focusout', () => queueMicrotask(() => soon()));
    const progress = el('div', 'ed-as-sheet-progress');
    const bar = el('div', 'ed-as-bar');
    bar.append(el('i'));
    const words = el('span', 'ed-as-sheet-words');
    const retry = button('asset_import', 'Retry', 'Send it again, with the name in its field: its own step', () => {
      const plan = s?.frozen?.rows.find((p) => p.id === id);
      if (plan) send([{ ...plan, name: (s!.choices.get(id)?.name ?? plan.name).trim() || plan.name }]);
    }, 'ed-small');
    progress.append(bar, words, retry);
    r.append(skip, name, what, line, fixes, fold, options, progress);
    const view: RowView = { root: r, skip, input, was, refusal, refusalText, use, role, flip, scriptFlip, replace, tick, replaceText, build, buildTick, same, line, fixes, fixesFor: '', fold, options, optionsFor: null, progress, bar, words, retry };
    views.set(id, view);
    rows.append(r);
    return view;
  }

  function drawRow(row: PlanRow, sent: Sent | undefined, arrived: Arrival | undefined): void {
    const v = viewOf(row);
    const planning = s!.phase === 'plan';
    const failed = sent?.state === 'failed';
    v.root.classList.toggle('ed-as-skipped', row.skip);
    v.root.classList.toggle('ed-as-blocked', planning && row.blocked !== null && row.blocked !== CHECKING);
    show(v.root, planning || !row.skip);
    show(v.skip, planning);
    put(v.skip, row.skip ? '↺' : '×');
    v.skip.title = row.skip ? 'Put it back in the import' : 'Leave it out of the import';
    // A failed row's field keeps what was typed for its Retry; every other its plan's name.
    const shownName = failed ? (s!.choices.get(row.id)?.name ?? row.name) : row.name;
    if (document.activeElement !== v.input && v.input.value !== shownName) v.input.value = shownName;
    v.input.readOnly = !planning && !failed;
    v.input.classList.toggle('ed-bad', planning && row.checked.state === 'refused');
    v.input.title = row.checked.state === 'refused' ? row.checked.refused : row.checked.state === 'ok' && row.checked.note ? row.checked.note : 'Its name as it will be written: Enter imports';
    const sub = row.folder !== s!.folder && row.folder.startsWith(`${s!.folder}/`) ? `in ${row.folder.slice(s!.folder.length + 1)}/` : row.folder !== s!.folder ? `into ${naming.say(row.folder)}` : '';
    const wasText = [sub, row.original !== row.name ? `was ${row.original}` : ''].filter(Boolean).join(' · ');
    put(v.was, wasText);
    show(v.was, wasText !== '');
    const refused = planning && row.checked.state === 'refused' ? row.checked : null;
    show(v.refusal, refused !== null);
    if (refused) {
      put(v.refusalText, refused.refused);
      show(v.use, refused.suggested !== undefined);
      if (refused.suggested !== undefined) {
        put(v.use, `Use ${refused.suggested}`);
        v.use.title = `Name it ${refused.suggested}`;
      }
    }
    put(v.role, row.says);
    v.role.classList.toggle('ed-as-red', row.role === 'refused');
    v.role.title = row.refused ?? row.says;
    show(v.flip, planning && row.switchable);
    if (row.switchable) {
      put(v.flip, row.role === 'source' ? 'import as delivered' : 'import as a source');
      v.flip.title = row.role === 'source'
        ? 'As delivered: shipped as it is, no export made -- a source identical to its export doubles the LFS bill'
        : 'As a source: kept on the Source side, its export made by the pipeline';
    }
    show(v.scriptFlip, planning && row.scriptable);
    if (row.scriptable) {
      put(v.scriptFlip, row.role === 'script' ? 'import the file as it is' : 'import as a script');
      v.scriptFlip.title = row.role === 'script'
        ? 'The file its own source (or as delivered), no script: what it is, the model shown -- no parameters, nothing Claude can change'
        : `A Gladius script that imports it, the file copied beside it: opened in the Model tab, edited there and by Claude (${splitName(row.name).stem}.lua)`;
    }
    // In the build: a tick on a source and on one as delivered; after Import, said only where it is off.
    show(v.build, row.tick && !row.skip && (planning || !row.include));
    if (row.tick) {
      v.buildTick.checked = row.include;
      v.buildTick.disabled = !planning;
      v.build.title = row.role === 'delivered'
        ? row.include ? `In the build -- unticked, it is named _${row.name}, which no build takes` : `Out of the build: named ${row.name} -- ticked, the _ comes off`
        : row.include ? 'In the build: exported once it is in -- unticked, its record says it is out, and nothing is exported' : 'Out of the build: its record will say so, and nothing is exported -- tick it, in the tool, any time';
    }
    // The others put as this one is, where any differs: "Same for all" covers the tick.
    const differ = planning && row.tick && !row.skip ? s!.plan.rows.filter((r) => r.id !== row.id && !r.skip && r.tick && r.include !== row.include).length : 0;
    show(v.same, differ > 0);
    if (differ > 0) {
      put(v.same, `Same for all ${differ + 1}`);
      v.same.title = row.include ? 'Every file here in the build, as this one is' : 'Every file here out of the build, as this one is: sources not exported, files as delivered named _';
    }
    show(v.replace, row.replaces.length > 0 && (planning || row.replace));
    if (row.replaces.length > 0) {
      v.tick.checked = row.replace;
      v.tick.disabled = !planning;
      put(v.replaceText, `replaces ${row.replaces.map((p) => p.slice(p.lastIndexOf('/') + 1)).join(', ')}`);
      v.replace.title = 'Ticked: what is there goes to the trash first, in the same step -- one stem, one source';
    }
    const line = planning ? (row.refused ?? row.line ?? '') : '';
    put(v.line, line);
    v.line.classList.toggle('ed-as-red', planning && row.role === 'refused');
    show(v.line, line !== '');
    const fixesFor = planning ? row.fixes.map((f) => `${f.label}>${f.folder}`).join('|') : '';
    if (fixesFor !== v.fixesFor) {
      v.fixesFor = fixesFor;
      v.fixes.replaceChildren(...(planning ? row.fixes : []).map((f) => button('ui', f.label, `Move this row to ${naming.say(f.folder)}, ${f.source ? 'as a source' : 'as delivered'}`, () => chose(row.id, { folder: f.folder, source: f.source }, true), 'ed-small')));
    }
    show(v.fixes, fixesFor !== '');
    const hasOptions = planning && row.schemas !== undefined && !row.skip;
    show(v.fold, hasOptions);
    const unfolded = hasOptions && s!.open.has(row.id);
    put(v.fold, unfolded ? 'Options ▾' : `Options ▸${Object.keys(row.options).length > 0 ? ` (${Object.keys(row.options).length} set)` : ''}`);
    show(v.options, unfolded);
    if (unfolded) {
      const key = optionsKey(row);
      const active = document.activeElement;
      const typing = active instanceof HTMLInputElement && active.type !== 'checkbox' && v.options.contains(active);
      // Never inside the change that asked: Chrome fires a field's `change` as Tab takes the focus from it, before the
      // next control has it -- drawn then, that control would be gone, and the focus with it. The next frame, the focus
      // has landed, and goes back to its control once drawn.
      if (v.optionsFor !== key && !typing) {
        if (inFrame) drawOptions(v, row, key);
        else soon();
      }
    }
    // After Import: the bytes going up, then its export's steps, or why not.
    show(v.progress, !planning && !row.skip);
    if (!planning && !row.skip) {
      const bar = v.bar.firstElementChild as HTMLElement;
      let width = 0;
      let words = 'waiting its turn';
      if (sent?.state === 'uploading') {
        width = sent.total > 0 ? sent.sent / sent.total : 0;
        words = `uploading · ${Math.floor(width * 100)} % · ${sayBytes(sent.sent)} of ${sayBytes(sent.total)}`;
      } else if (sent?.state === 'in') {
        width = 1;
        words = arrived?.words ?? 'in';
      } else if (sent?.state === 'failed') words = sent.error;
      const pct = `${Math.round(width * 100)}%`;
      if (bar.style.width !== pct) bar.style.width = pct;
      put(v.words, words);
      v.words.title = words;
      v.words.classList.toggle('ed-as-red', failed || arrived?.state === 'bad');
      v.progress.classList.toggle('ed-as-done', arrived?.state === 'done');
      show(v.retry, failed && s!.phase === 'after');
    }
  }

  /** A row's destination, as its source will be: what its options are planned over. */
  const destOf = (row: PlanRow): string => joinPath(row.folder, row.name);

  /** What a row's options are drawn from: its recipe and destination, its overrides, and the folders' `export.json` as read. */
  function optionsKey(row: PlanRow): string {
    const target = targetOf(destOf(row), false);
    const layers = (target?.layers ?? []).map((path) => JSON.stringify(host.records.read(path, () => soon())));
    return `${row.recipe ?? ''}\n${destOf(row)}\n${JSON.stringify(row.options)}\n${layers.join('\n')}`;
  }

  /**
   * A row's options, as the Options block draws a source's (`optionRow`):
   * planned over the destination's folders' `export.json` (`planFields`) --
   * a folder's default grey and said, a value set to what is inherited taken
   * off, as `PUT sidecar` would -- a value refused said under its field and
   * holding Import. "Same for all" where others share its recipe. The focus
   * goes back to the control it was on.
   */
  function drawOptions(v: RowView, row: PlanRow, key: string): void {
    const active = document.activeElement;
    const focused = active instanceof HTMLElement && v.options.contains(active) ? active.dataset.focus : undefined;
    v.optionsFor = key;
    v.options.replaceChildren();
    // Drawn anew: no field says a refusal now.
    s!.refused.delete(row.id);
    const target = targetOf(destOf(row), false);
    if (!target) return;
    const layers = target.layers.map((path) => {
      const read = host.records.read(path, () => soon());
      return { path, options: read !== 'reading' && 'options' in read ? read.options : undefined };
    });
    const fields = planFields(target.schemas, layers, row.options, target.defaults);
    const spec: RowSpec = {
      writes: true,
      change(field, to) {
        if (isMove(to)) return;
        chose(row.id, { options: withOption(choice(row.id).options ?? {}, field.name, to, field.inherited, false) });
      },
      refused(field, why) {
        if (!s) return;
        const mine = s.refused.get(row.id) ?? new Map<string, string>();
        if (why === null) mine.delete(field.name);
        else mine.set(field.name, why);
        if (mine.size > 0) s.refused.set(row.id, mine);
        else s.refused.delete(row.id);
        draw();
        host.changed();
      },
    };
    const grid = el('div', 'ed-as-opts ed-as-sheet-opts');
    for (const field of fields) grid.append(...optionRow(field, spec, fields));
    v.options.append(grid);
    const sharing = s!.plan.rows.filter((r) => r.id !== row.id && !r.skip && r.recipe === row.recipe);
    if (sharing.length > 0) {
      const same = button('ui', `Same for all ${sharing.length + 1}`, `These options for every ${row.recipe?.split('.')[1] ?? ''} here: ${[row, ...sharing].map((r) => r.name).join(', ')}`, () => {
        for (const other of sharing) {
          choice(other.id).options = { ...(choice(row.id).options ?? {}) };
          // The tick too: one recipe's sources, in the build or out of it, as this one is.
          choice(other.id).include = choice(row.id).include !== false;
        }
        replan();
        draw();
      }, 'ed-small');
      same.dataset.focus = 'opt::same';
      v.options.append(same);
    }
    if (focused !== undefined) v.options.querySelector<HTMLElement>(`[data-focus="${CSS.escape(focused)}"]`)?.focus({ preventScroll: true });
  }

  /** The first option refused under its field, of a row that goes: what holds Import, and its words. */
  function heldByOption(): { name: string; why: string; id: number } | null {
    if (!s) return null;
    for (const row of s.plan.rows) {
      const refused = s.refused.get(row.id);
      if (row.skip || !refused) continue;
      const [first] = refused.values();
      if (first !== undefined) return { name: row.name, why: first, id: row.id };
    }
    return null;
  }

  function draw(): void {
    if (!s) return;
    const plan = s.frozen ?? s.plan;
    const planning = s.phase === 'plan';
    // From its root: every import is into the project, so the project's crumb says nothing.
    const into = planning ? (host.folders?.(s.folder) ?? []) : [];
    // The folder named in the title, or -- where it may change -- in the Into list beside it.
    put(title, into.length > 1 ? 'Import into' : `Import into ${naming.crumbs(s.folder).filter((c) => c.path !== PROJECT).map((c) => c.text).join(' › ')}`);
    title.title = naming.say(s.folder);
    const intoKey = `${s.folder}|${into.join('|')}`;
    if (intoKey !== intoFor) {
      intoFor = intoKey;
      intoPick.replaceChildren(...[...new Set([s.folder, ...into])].sort().map((f) => {
        const o = el('option', undefined, naming.crumbs(f).filter((c) => c.path !== PROJECT).map((c) => c.text).join(' › '));
        o.value = f;
        return o;
      }));
      intoPick.value = s.folder;
    }
    show(intoPick, into.length > 1);
    // What holds Import back, and what a suggestion would mend: counted before the rows are drawn, for the head.
    const problems = planning ? plan.rows.filter(problem) : [];
    const suggested = planning ? plan.rows.filter((r) => !r.skip && r.checked.state === 'refused' && r.checked.suggested !== undefined).length : 0;
    // The filter lets go by itself once nothing is left to show.
    if (s.problemsOnly && problems.length === 0) s.problemsOnly = false;
    for (const row of plan.rows) {
      const sent = s.sent.get(row.id);
      drawRow(row, sent, sent?.state === 'in' ? came(s, sent.path) : undefined);
      if (s.problemsOnly) show(views.get(row.id)!.root, problem(row));
    }
    show(noProblems, planning && problems.length === 0 && plan.rows.length > 0 && suggested === 0 && s.sawProblems);
    if (problems.length > 0) s.sawProblems = true;
    show(problemsButton, planning && (problems.length > 0 || s.problemsOnly));
    put(problemsButton, s.problemsOnly ? `Problems only · ${problems.length}` : `Problems · ${problems.length}`);
    problemsButton.setAttribute('aria-pressed', String(s.problemsOnly));
    problemsButton.title = s.problemsOnly ? 'Show every row again' : `Show only the ${problems.length === 1 ? 'row that holds' : `${problems.length} rows that hold`} Import back`;
    show(fixAllButton, planning && suggested > 0);
    put(fixAllButton, `Fix all · ${suggested}`);
    fixAllButton.title = `Take every suggested name: ${suggested === 1 ? 'one row' : `${suggested} rows`} renamed, as their Use buttons would`;
    put(skippedLine, plan.skipped ?? '');
    show(skippedLine, plan.skipped !== null);
    put(totals, `${plan.sends.length} ${plan.sends.length === 1 ? 'file' : 'files'} · ${sayBytes(plan.bytes)} to upload`);
    const boot = plan.boot;
    show(bootLine, boot !== null);
    if (boot) {
      const over = boot.after > boot.budget;
      put(bootLine, `The boot set: ${sayBytes(boot.now)}${boot.adds > 0 ? ` → ${sayBytes(boot.after)} with what lands as delivered` : ''}, of ${sayBytes(boot.budget)}${over ? ' -- over the budget: it downloads before the first frame' : ''} · sources add their exports once made`);
      bootLine.classList.toggle('ed-as-amber', over);
    }
    show(go, planning);
    const blocked = plan.blocked;
    const held = blocked !== null && blocked.blocked !== CHECKING;
    const option = heldByOption();
    go.disabled = held || option !== null || plan.sends.length === 0;
    put(go, s.waiting ? 'Checking the names…' : plan.label);
    go.title = held ? `Waiting for ${blocked!.name}: ${blocked!.blocked} -- or skip it (×)`
      : option ? `Waiting for ${option.name}'s options: ${option.why} -- fix it, or ↺`
      : plan.sends.length === 0 ? 'Nothing to import: every row is skipped' : `${plan.label} (Enter): one step, Z undoes it`;
    put(closeButton, planning ? 'Close' : s.phase === 'sending' ? 'Stop' : 'Close');
  }

  // ---------------------------------------------------------------- Import

  form.addEventListener('submit', (event) => {
    // An option's own form, nested in this one, submits itself: never an import.
    if (event.target !== form) return;
    event.preventDefault();
    if (!s || s.phase !== 'plan') return;
    const blocked = s.plan.blocked;
    if (blocked && blocked.blocked !== CHECKING) {
      const input = views.get(blocked.id)?.input;
      input?.focus();
      return;
    }
    // An option refused under its field: not imported with a value other than the one typed.
    if (heldByOption() !== null) return;
    if (blocked) {
      // A name still being checked: sent once it is answered, if it may be.
      s.waiting = true;
      clearTimeout(s.asking);
      ask();
      draw();
      return;
    }
    send(s.plan.sends);
  });

  /** These rows sent, owners first, as one step. */
  function send(list: readonly PlanRow[]): void {
    const session = s;
    if (!session || list.length === 0) return;
    session.waiting = false;
    session.frozen ??= session.plan;
    session.phase = 'sending';
    session.reading.abort();
    const upload = new AbortController();
    session.upload = upload;
    for (const row of list) session.sent.set(row.id, { state: 'waiting' });
    const drop = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
    const files = list.map((row, i) => ({
      name: row.name,
      send: (signal: AbortSignal): Promise<ImportAnswer> => {
        session.sent.set(row.id, { state: 'uploading', sent: 0, total: row.size });
        soon();
        return api.importFile(session.files[row.id]!.file, importQuery(row, drop, list.length - 1 - i), (sent, total) => {
          session.sent.set(row.id, { state: 'uploading', sent, total });
          soon();
        }, signal);
      },
    }));
    const label = list === session.plan.sends ? session.plan.label : list.length === 1 ? `Import ${list[0]!.name}` : `Import ${list.length} files`;
    const edit = importEdit(api, host.edits, files, {
      label,
      // The folders it makes, read before a byte is sent: its undo takes them away again.
      made: newFolders(list, (dir) => index.tree().has(dir)),
      signal: upload.signal,
      sent(i, result) {
        const row = list[i]!;
        session.sent.set(row.id, 'answer' in result ? { state: 'in', path: result.answer.path } : { state: 'failed', error: reasonOf(result.error) });
        // The drop's last file names its exports' jobs: each row goes by its own from now on.
        if ('answer' in result) for (const job of result.answer.jobs ?? []) session.ids.set(job.source, job.id);
        if ('answer' in result && result.answer.script) session.scripts.add(result.answer.path);
        soon();
      },
    });
    draw();
    host.changed();
    // The closing line names the import as first sent, not a Retry of one of its rows.
    if (session.label === '') session.label = label;
    void host.steps.run(edit.label, edit.first, { do: edit.redo, undo: edit.undo, ...(edit.named ? { label: edit.named } : {}) }, `${label} …`).then(() => {
      if (s !== session) return;
      session.phase = 'after';
      session.upload = null;
      const written = list.map((row) => session.sent.get(row.id)).flatMap((sent) => (sent?.state === 'in' ? [sent.path] : []));
      if (written.length > 0) host.landed(written, written.filter((p) => session.scripts.has(p)));
      // Rows never answered (the queue failed before them): failed, with Retry.
      for (const row of list) if (session.sent.get(row.id)?.state !== 'in' && session.sent.get(row.id)?.state !== 'failed') session.sent.set(row.id, { state: 'failed', error: 'not sent' });
      settle();
      host.changed();
    });
  }

  /** Every row in and every job ended: closed. A row failed or unmade keeps it up, with its line. */
  function settle(): void {
    const session = s;
    if (!session || session.phase !== 'after') return;
    draw();
    let done = true;
    for (const sent of session.sent.values()) {
      if (sent.state !== 'in') {
        done = false;
        continue;
      }
      if (came(session, sent.path).state !== 'done') done = false;
    }
    if (!done) return;
    const label = session.label;
    // Undone while its export ran: the export stopped, and nothing of it left.
    const stopped = [...session.sent.values()].some((sent) => {
      if (sent.state !== 'in') return false;
      const id = session.ids.get(sent.path);
      return (id !== undefined ? session.byId.get(id) : session.jobs.get(sent.path))?.state === 'dropped';
    });
    close();
    host.say(stopped ? `${label}: undone while its export ran -- the export stopped, nothing of it left` : `${label}: in, and exported where it is made -- Z undoes`);
  }

  // ---------------------------------------------------------------- open, close

  function add(folder: string, drop: ReadDrop, scripts = false): void {
    if (s && s.phase !== 'plan') {
      host.say(s.phase === 'sending' ? 'An import is under way: Close stops it, or wait -- then drop again' : 'The last import\'s sheet is still up, a row of it failed: Close it, then drop again', true);
      return;
    }
    if (drop.files.length === 0) {
      host.say(drop.skipped.length > 0 ? `Nothing to import: ${drop.skipped.length} of the OS's or an art tool's leavings skipped` : 'Nothing to import', true);
      return;
    }
    if (!s) {
      s = {
        folder,
        label: '',
        files: [],
        skipped: [],
        choices: new Map(),
        scans: new Map(),
        names: new Map(),
        plan: undefined as unknown as Plan,
        phase: 'plan',
        frozen: null,
        sent: new Map(),
        scripts: new Set(),
        jobs: new Map(),
        byId: new Map(),
        ids: new Map(),
        reading: new AbortController(),
        upload: null,
        problemsOnly: false,
        sawProblems: false,
        started: new Set(),
        open: new Set(),
        asked: 0,
        asking: undefined,
        waiting: false,
        refused: new Map(),
        offs: [],
      };
      const session = s;
      session.offs.push(
        host.onJob((job) => {
          if (s !== session) return;
          session.jobs.set(job.source, job);
          session.byId.set(job.id, job);
          if (session.phase !== 'plan') (session.phase === 'after' ? settle : soon)();
        }),
        host.onChanged(() => {
          if (s !== session) return;
          if (session.phase === 'after') settle();
          else soon();
        }),
      );
      // Esc in a name field, where the browser has a close request; elsewhere it is the tool's cancel.
      session.offs.push(onCloseRequest(() => close()));
      views.clear();
      rows.replaceChildren(noProblems);
      root.hidden = false;
    } else host.say(`${drop.files.length} more joined the import into ${naming.say(s.folder)}`);
    if (scripts) for (let i = 0; i < drop.files.length; i++) choice(s.files.length + i).script = true;
    s.files.push(...drop.files);
    s.skipped.push(...drop.skipped);
    replan();
    draw();
    read();
    ask();
    host.changed();
    // The focus on Import -- on the first refused name, if a row is.
    queueMicrotask(() => {
      if (!s) return;
      const refused = s.plan.rows.find((r) => !r.skip && r.checked.state === 'refused');
      const input = refused ? views.get(refused.id)?.input : undefined;
      if (input) {
        input.focus();
        input.select();
      } else if (!go.disabled) go.focus();
      else root.focus();
    });
  }

  function close(): void {
    const session = s;
    if (!session) return;
    // While it sends: the upload under way stopped, nothing more sent, what was written trashed (`importEdit`).
    session.upload?.abort();
    session.reading.abort();
    clearTimeout(session.asking);
    for (const off of session.offs) off();
    s = null;
    cancelAnimationFrame(frame);
    frame = 0;
    root.hidden = true;
    views.clear();
    rows.replaceChildren(noProblems);
    // The focus off the card it was in, back where the editor's keys are heard.
    if (root.contains(document.activeElement)) (document.activeElement as HTMLElement).blur();
    host.changed();
  }

  return {
    get open() {
      return s !== null;
    },
    get folder() {
      return s?.folder ?? null;
    },
    get line() {
      if (!s) return '';
      const into = naming.say(s.folder);
      if (s.phase === 'plan') {
        const blocked = s.plan.blocked;
        if (blocked && blocked.blocked !== CHECKING) return `Import into ${into} · ${blocked.name}: ${blocked.blocked} -- fix it or skip it (×), then Enter imports · Esc closes`;
        const option = heldByOption();
        if (option) return `Import into ${into} · ${option.name}: ${option.why} -- fix it or ↺, then Enter imports · Esc closes`;
        if (s.plan.sends.length === 0) return `Import into ${into} · every row skipped: nothing to import · Esc closes`;
        return `Import into ${into} · Enter imports · Esc closes`;
      }
      if (s.phase === 'sending') return `Importing into ${into} · Esc stops it: what was written goes to the trash`;
      return `Imported into ${into} · its exports on their way · Esc closes, they go on in the strip`;
    },
    root,
    add,
    close,
    submit() {
      if (s?.phase === 'plan') form.requestSubmit();
    },
    refresh() {
      if (s) soon();
    },
    dispose() {
      close();
      root.remove();
    },
  };
}
