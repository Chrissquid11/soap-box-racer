/**
 * The Assets tool's right-hand panel (Docs/assets-tool.md §6): the chosen
 * file, the several chosen, or -- with nothing chosen in the files card -- the
 * open folder. Its blocks fold as the entity inspector's do (`foldable`, with
 * the prefix `assets:`, so neither folds the other's).
 *
 * - **The Scene tab's one inspector, shared**: shown on the right while a
 *   file or a folder of the Assets panel was chosen last, the entity
 *   inspector while an entity was (`ctx.inspect`) -- choosing one clears the
 *   other (`ctx.chose`); one width, one fold -- the `right` preference --
 *   and one lock, whichever is shown.
 * - **Locked** (its lock, `Alt+L`; `inspector-lock.ts`): it shows what it
 *   showed as it was locked -- the files, or the open folder -- whatever is
 *   chosen since, a file renamed or moved followed to where it went; all of
 *   it deleted, "Nothing selected (locked: it was removed)". Not in the Model
 *   tab, which has no lock: the button is hidden there.
 *
 * - **Its header**: `Inspector`, the lock and the fold, as the entity inspector's.
 * - **The head**: the name; the role, as part one says it; the key with a copy
 *   button -- an export's or a loose file's own, a source's its export's ("ships
 *   as `characters/robot`") -- and the tick beside it, in the build; out of it,
 *   the key line reads "excluded from the build", the tick beside that; and the
 *   twin, a button that opens its folder with it chosen ("from
 *   Source/models/characters/robot.fbx", as the tool says a path) -- an
 *   `ed-button`, not an `<a>`, which would hold the focus where the keys' guard
 *   does not look.
 * - **The preview** (`assets-preview.ts`): the chosen file as the game will
 *   see it -- one block, kept across this panel's redraws, so a model is not
 *   decoded again for every change of the index; another file, or none,
 *   disposes it.
 * - **Status**: the mark, the word and its reason, `Entry.note` -- out of the
 *   build, "excluded: not exported" with the tick, and no Export now; for `unmade`
 *   what each tool it wants says to do, and **Set its path in Tools**; for
 *   `failed` the first line and **Show output** -- the last run's, from `GET
 *   run`, or this session's job's if that is later; **Export now**; the
 *   record's `built`, grey, and how long, from `GET run`.
 * - **Stats** (`assets-stats.ts`): the bytes from the index at once, then what
 *   `GET stats` read -- "reading…" until it answers, asked once a content
 *   hash -- by `STATS` and a game's rows; then each `WARNINGS` row that
 *   applies, a marked line of one sentence and the number (`warnings.ts`).
 * - **Options** (`assets-options.ts`): a source's recipe options as fields,
 *   the default grey, where a folder sets it said; a change one step through
 *   `PUT sidecar`, which re-exports; Reset per field and all. An export shows
 *   its source's.
 * - **A prefab** (`prefab-block.ts`): its problems, its root's components
 *   (edited here: `prefab-root-block.ts`), its entities, its pool (edited
 *   here) and who nests it, before Status.
 * - **Uses** (an export, a loose file, a source's export): `GET uses`' lines,
 *   each with a copy -- asked once a key for the session -- else "no literal
 *   uses found", and that a key built at runtime is not seen.
 * - **Several**: how many and their bytes; the first previewed, ◂ ▸ stepping
 *   through them (the one stepped to `latest`); their statuses counted, one
 *   tick for all (`—` when they differ), Export now for all, Options over the
 *   recipe they share. **A folder**: its files and bytes, how many of them are
 *   in the build, what needs a hand under it, Export all stale under it, and
 *   its `export.json` as Options. **The project**: the whole project's totals --
 *   every root's files and bytes, the Trash's, the boot set against its
 *   budget -- what needs a hand, Export all stale; no options of its own.
 * - **No Actions block**: what can be done to what is shown is the menu's --
 *   a right-click, or the menu key -- and the keys'; the panel carries only
 *   what the menu does not: Export now, the options, the uses.
 * - **Rename where the name is**: a click on the head's name makes it the
 *   rename field (`editName`), as the entity inspector's title does; while
 *   any rename is open, its uses line under the head (`note`).
 * - **A question** (`ask.ts`) goes in a place under the head that its redraws
 *   leave alone.
 * - **Not built again under a field**: while an option -- or a field of a
 *   prefab's Root block -- is typed in or scrubbed (`Holding`) a redraw waits, and comes as it lets go. Any
 *   other control keeps the focus across a redraw -- a tick, a list, a ↺, a
 *   button -- found again by its `data-focus`, or its block and its words.
 * - **Stats keep their height** while a re-export's numbers are read: the last
 *   lines, dimmed, until the new ones come, so nothing moves under the pointer.
 */
import type { Entry, OptionValue, Run, ToolLook, Use } from '@vibe/pipeline/assets-types';
import { ROOTS, TRASH } from '@vibe/pipeline/kinds';
import { aboveKinds } from '@vibe/pipeline/recipes';
import { baseName, fromTrash, recordPath, strayFile, twin, under } from '@vibe/pipeline/paths';
import { createAsk, type Ask } from '../../ask.ts';
import { foldable } from '../../inspector-blocks.ts';
import { tally } from '../../multi.ts';
import { button, el, iconButton, lockButton, sidePanel, type SidePanel } from '../../shell.ts';
import { REMOVED, type LockHost } from '../../inspector-lock.ts';
import type { Api, Online } from '../api.ts';
import { PROJECT, type ClientIndex, type Shown } from '../model.ts';
import { fieldsFor, flashWant, FLASH_HOLD_MS, fromSourceRoot, optionsBlock, type Holding, sharedTargets, targetOf, type Field, type OptionsBlock, type Records, type Target } from './assets-options.ts';
import { shownOf, type PreviewBlock } from './assets-preview.ts';
import { bytesLines, statsKey, statsRowFor, type StatLine, type StatsCache, type StatsRow } from './assets-stats.ts';
import { bootBytes, sayBytes } from './budget.ts';
import { jobError } from './export-step.ts';
import { keyOfRow, kindOfRow, sayDate, twinOfRow } from './files-columns.ts';
import { shownAt, type Showing } from './files-selection.ts';
import { countsText, excludedOf, isEntry, markClass, markOf, sourceOf, statusOf, STATUS_MARKS, tickOf, ticksOf, total, type FolderCounts, type Tick } from './marks.ts';
import { filesText, type Naming } from './naming.ts';
import { warningsOf, type Warning } from './warnings.ts';

/** What the panel shows (`files-selection.ts`, where the lock's rules over it are). */
export type { Showing };

/** What the inspector asks of the tool. */
export interface InspectorHost {
  readonly index: ClientIndex;
  readonly naming: Naming;
  readonly counts: FolderCounts;
  readonly api: Api;
  /** What to show just now: locked, what it pinned. */
  showing(): Showing;
  /** The right panel's lock (`EditorContext.lock`): its button in the header, beside the fold. */
  readonly lock: LockHost;
  /** May this page write: Export now is absent where not. */
  writes(): boolean;
  /** The tools as last looked for. */
  tools(): readonly ToolLook[] | null;
  /** This session's failure of a job for this source, if any. */
  failure(source: string): string | undefined;
  /** Is a job queued or running on this source? */
  running(source: string): boolean;
  /** A path's folder opened with it chosen: the twin's link. */
  reveal(path: string): void;
  /** Config ▸ Assets ▸ Tools brought up, that tool's path field focused. */
  openTools(tool?: string): void;
  /** For a Gladius script, or its export: the way to open it in the Model tab (Docs/modeler.md M19); null for any other file. */
  openModel(path: string): (() => void) | null;
  /**
   * For a `.glb` delivered as it is under models, with no source (Docs/modeler.md M39; Vibe3D D49): the way to make a
   * Gladius script for it -- the file copied in, a script importing it, opened in the Model tab; null for any other.
   */
  makeScript(path: string): (() => void) | null;
  /** Is the Model tab the tab up: a script's Open in Model tab reads "Back to the model" there (its card in this panel's place). */
  modelUp?(): boolean;
  /** Export these sources -- `force`, current or not -- as one step. */
  exportNow(sources: readonly string[], force: boolean): void;
  /** Export every stale source under a folder, as one step. */
  exportUnder(folder: string): void;
  /** `text` on the clipboard; `what` says what it was, on the hint. */
  copy(text: string, what: string): void;
  /** The boot set's budget, in bytes: what a root's figure is said against. */
  readonly budget: number;
  /** The panel folded away, or back: a focus on it moves to a card that is seen. */
  folded(folded: boolean): void;
  /** The head's name clicked: renamed where it is, if it may be. */
  rename(): void;
  /** May what it shows be renamed: the head's name a button then. */
  renames(showing: Showing): boolean;
  /** The preview block: placed under the head, kept across redraws, one file at a time. */
  readonly preview: PreviewBlock;
  /** `GET stats`, asked once a content hash. */
  readonly stats: StatsCache;
  /** `STATS` and a game's rows over it; `WARNINGS` and a game's. */
  readonly statsRows: Readonly<Record<string, StatsRow>>;
  readonly warnings: Readonly<Record<string, Warning>>;
  /** What this page may do: with no dev server, no stats are asked. */
  online(): Online | null;
  /** The records and `export.json`s, read through `GET file`, kept by path and mtime. */
  readonly records: Records;
  /**
   * An option changed on these targets -- set, moved by `by` (a number of
   * several that differ), or taken off (undefined): one step. `each` is each
   * target's own fields, as drawn.
   */
  changeOption(targets: readonly Target[], each: readonly (readonly Field[])[], field: Field, to: OptionValue | { by: number } | undefined): void;
  /** Reset all: every option set on these targets taken off, one step. */
  resetOptions(targets: readonly Target[], each: readonly (readonly Field[])[]): void;
  /** `GET uses` of these keys, asked once a key for the session: null while any is asked, `then` told. */
  uses(keys: readonly string[], then: () => void): Use[] | null;
  /** Several chosen: ◂ ▸, the one previewed stepped. */
  step(by: 1 | -1): void;
  /** A tick of the panel's clicked: these files put in the build (`on`) or left out, one step. */
  build(paths: readonly string[], on: boolean): void;
  /**
   * A prefab file's blocks (`prefab-block.ts`): its problems, its root to edit, entities, pool and who nests it; none
   * for any other file. A block the panel must not be built again under while it is typed in is handed to `hold`.
   */
  prefabBlocks(path: string, hold: (block: Holding) => void): HTMLElement[];
}

export interface AssetsInspector {
  readonly panel: HTMLElement;
  /** The title row: lit while the preview has the focus. */
  readonly head: HTMLElement;
  readonly side: SidePanel;
  /** Questions in the panel, under its head: "Export 112 files again?" */
  readonly ask: Ask;
  /** Built again from what it shows. */
  refresh(): void;
  /** `path`'s Options block, as it is next drawn for it, scrolled into view and lit for a moment (the Model tab's All options…). */
  flashOptions(path: string): void;
  /** A source's job ended: its last run asked again, as the block is drawn next. */
  forget(source: string): void;
  /** Does it show `source`'s family just now -- the source, an export of it, among several? A job of it redraws it then. */
  showsFamily(source: string): boolean;
  /** The output of the shown file's last failure open: the jobs strip's Show. */
  showOutput(): void;
  /** `field` in place of the head's name; false if there is no name to put it in. Taken away by `endEdit`. */
  editName(field: HTMLElement): boolean;
  endEdit(): void;
  /** A line under the head -- a rename's uses, what the key becomes -- with a button (a suggestion taken); null takes it away. */
  note(text: string | null, bad?: boolean, use?: { label: string; run(): void }): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}

/** A role as part one says it, in full, and what it means on hover. */
const ROLES: Record<Entry['role'], string> = {
  source: 'what an export is made from',
  part: 'read with its source, never exported on its own',
  intermediate: 'made from its source on the way to its export',
  record: 'a source\'s options',
  export: 'made from its source: what the game loads',
  loose: 'ships as delivered: no source',
  reference: 'nothing is made from it',
  extra: 'kept, not converted',
};

export function createAssetsInspector(root: HTMLElement, host: InspectorHost): AssetsInspector {
  const { index, naming, api } = host;
  const panel = el('div', 'ed-card ed-side ed-right ed-as-inspector');
  panel.hidden = true;
  root.append(panel);
  // The Scene tab's one right panel: its width and fold the entity inspector's own preference, `right`.
  const side = sidePanel(root, panel, 'right', { name: 'Inspector', changed: (folded) => host.folded(folded) });
  // Its header, as the entity inspector's: `Inspector`, the lock and the fold -- then the head, the file's name its title.
  const bar = el('div', 'ed-panel-head ed-panel-bar');
  const lock = lockButton(host.lock);
  bar.append(el('div', 'ed-side-title', 'Inspector'), lock.button, side.fold);
  const top = el('div', 'ed-as-inspector-head');
  // A rename's uses line: under the head, its redraws leave it be.
  const noted = el('div', 'ed-as-note');
  noted.hidden = true;
  panel.append(bar, top, noted);
  const ask = createAsk(panel);
  // The preview under the head and the question: its own element, which this panel's redraws leave in place.
  const preview = host.preview;
  preview.root.hidden = true;
  const body = el('div', 'ed-as-inspector-body');
  panel.append(preview.root, body);
  /** The title row, as last built: lit while the preview has the focus. */
  const head = el('div', 'ed-panel-head ed-as-head');

  /** Each source's last run, once asked this session: undefined for none, a promise while it is asked. */
  const runs = new Map<string, Run | null | 'asking'>();
  /** The Options block as last drawn: while a field of it is typed in or scrubbed, the panel is not drawn again under it. */
  let options: OptionsBlock | null = null;
  /** The source whose Options block is to be lit as it is next drawn for it (`flashOptions`). */
  const flashing = flashWant();
  /** Any other block held so -- a prefab's Root, while a field of it is typed in or scrubbed -- as last drawn. */
  let held: Holding[] = [];
  /** A redraw asked for while the Options block held: made as it lets go. */
  let waiting = false;
  /** The output shown, for this path. */
  let output: string | null = null;
  let visible = false;
  /** The head's name made a field: the panel is not built again under it. */
  let editing: HTMLElement | null = null;
  /** What Stats last drew, and for which file: kept, dimmed, while its family exports and its new numbers are read. */
  let statsLast: { path: string; lines: readonly StatLine[]; warnings: readonly string[] } | null = null;

  /** What a control of the panel is known by across a redraw: its `data-focus`, else its block, its tag and its words. */
  function focusKeyOf(node: Element | null): string | null {
    if (!(node instanceof HTMLElement) || !(top.contains(node) || body.contains(node))) return null;
    if (node.dataset.focus) return `key:${node.dataset.focus}`;
    const block = node.closest('.ed-component')?.querySelector('.ed-component-head')?.textContent ?? (top.contains(node) ? 'head' : '');
    return `at:${block}|${node.tagName}|${node.textContent?.trim() || node.title}`;
  }

  /** A control the focus was on and a redraw did not draw again just then (its block reading): looked for at the next, while nothing else has the focus. */
  let lost: string | null = null;
  const focusedElsewhere = (): void => void (lost = null);
  document.addEventListener('focusin', focusedElsewhere);

  /** The focus back on the control it was on before the redraw, if it is drawn again. */
  function refocus(key: string | null): void {
    const want = key ?? (document.activeElement === document.body ? lost : null);
    if (want === null || document.activeElement instanceof HTMLElement && (top.contains(document.activeElement) || body.contains(document.activeElement))) return;
    for (const node of [...top.querySelectorAll<HTMLElement>('button, input, select'), ...body.querySelectorAll<HTMLElement>('button, input, select')]) {
      if (focusKeyOf(node) !== want) continue;
      node.focus({ preventScroll: true });
      return;
    }
    lost = want;
  }

  const entries = (): ReadonlyMap<string, Entry> => index.entries;

  /** A line with a copy button: the key, the path. */
  function copyLine(label: string, text: string, what: string): HTMLElement {
    const line = el('div', 'ed-line ed-as-copy-line');
    const words = el('span', 'ed-as-copy-text');
    words.append(el('span', 'ed-dim', `${label} `), el('code', undefined, text));
    words.title = text;
    line.append(words, iconButton('ui', 'copy', `Copy ${what}: ${text}`, () => host.copy(text, what)));
    return line;
  }

  /** A link to another file: its folder opened with it chosen. */
  function link(words: string, path: string): HTMLButtonElement {
    return button('ui', words, `Open ${naming.say(path)}'s folder with it chosen`, () => host.reveal(path), 'ed-small ed-quiet ed-as-link');
  }

  function block(title: string): HTMLElement {
    const section = el('div', 'ed-component ed-as-block');
    section.append(el('div', 'ed-component-head', title));
    return section;
  }

  /**
   * A tick, in the build or not -- `mixed`, of several that differ, `—` --
   * whose click puts `paths` in (off or mixed) or out (on): one step. Where
   * this page may not write, or it cannot flip just now, it only says.
   */
  function buildTick(paths: readonly string[], on: boolean | 'mixed', title: string, stuck?: string, words = 'in the build'): HTMLElement {
    const label = el('label', 'ed-tick ed-as-build');
    const box = el('input');
    box.type = 'checkbox';
    box.checked = on === true;
    box.indeterminate = on === 'mixed';
    box.disabled = !host.writes() || stuck !== undefined;
    box.dataset.focus = 'build';
    box.addEventListener('change', () => host.build(paths, on !== true));
    label.append(box, ...(words ? [el('span', undefined, words)] : []));
    label.title = stuck !== undefined ? `${title} -- not now: ${stuck}` : title;
    return label;
  }

  /** One file's tick, from its `Tick`. */
  const fileTick = (path: string, tick: Tick, words?: string): HTMLElement => buildTick([path], tick.on, tick.title, tick.stuck, words);

  // ---------------------------------------------------------------- one file

  /** The head's title: a name a click renames, where it may be. */
  function titled(text: string, said: string): HTMLElement {
    const name = el('div', 'ed-side-title ed-as-title', text);
    name.title = said;
    if (host.renames(host.showing())) {
      name.classList.add('ed-name-edit');
      name.title = `${said} · click to rename (${'F2'})`;
      // mcp: asset_move -- the name made the field to rename the file
      name.addEventListener('click', () => host.rename());
    }
    return name;
  }

  function fileHead(row: Shown): void {
    const name = titled(baseName(row.path), naming.say(row.path));
    head.replaceChildren(name);
    top.replaceChildren(head);
    if (!isEntry(row)) {
      const at = fromTrash(row.path)!;
      const role = el('div', 'ed-as-role');
      role.append(el('span', 'ed-badge', 'in the trash'), ` ${naming.title(`${TRASH}/${at.slot}`)}`);
      top.append(role, copyLine('was', naming.say(at.path), 'the path it had'));
      return;
    }
    const role = el('div', 'ed-as-role');
    const badge = el('span', 'ed-badge', row.role);
    badge.title = ROLES[row.role];
    role.append(badge);
    if (row.kind) role.append(el('span', 'ed-dim', ` ${row.kind}`));
    top.append(role);
    const key = keyOfRow(row, entries());
    const tick = tickOf(row, entries());
    if (tick && !tick.on) {
      // Out of the build: no key it ships as -- said so, the tick beside it to put it back.
      const line = el('div', 'ed-line ed-as-copy-line ed-as-key-line');
      line.append(el('span', 'ed-dim ed-as-out', 'excluded from the build'), fileTick(row.path, tick));
      top.append(line);
    } else if (key !== undefined) {
      const line = copyLine(row.role === 'source' ? 'ships as' : 'key', key, 'the key');
      line.classList.add('ed-as-key-line');
      if (tick) line.append(fileTick(row.path, tick));
      top.append(line);
    } else if (tick) {
      const line = el('div', 'ed-line ed-as-key-line');
      line.append(el('span', 'ed-dim', 'no key yet'), fileTick(row.path, tick));
      top.append(line);
    }
    const twin = twinOfRow(row, entries());
    if (twin !== undefined) {
      const line = el('div', 'ed-line ed-as-twin-line');
      line.append(link(row.role === 'source' ? `ships as ${naming.say(twin)}` : `from ${naming.say(twin)}`, twin));
      top.append(line);
    } else if (row.role === 'source' && key === undefined) {
      top.append(el('div', 'ed-dim', 'not exported yet'));
    }
    if (row.role === 'part' && row.owners && row.owners.length > 0) {
      const line = el('div', 'ed-line ed-as-twin-line');
      for (const owner of row.owners) line.append(link(`part of ${baseName(owner)}`, owner));
      top.append(line);
    }
    if (row.role === 'loose') {
      top.append(el('div', 'ed-dim', 'ships as delivered'));
      const make = host.makeScript(row.path);
      if (make) {
        top.append(button(
          'model_adopt', 'Make a script for it',
          `A Gladius script that imports it -- ${baseName(row.path)} copied into AssetsSource/ beside it -- built here as its export, the key unchanged, and opened in the Model tab: then a parameter, a canvas, Claude can change it. The model shipped becomes Gladius's rebuild of the file: welded, its quads recovered, normals sampled, its materials named <name>:<material>. Z undoes`,
          make,
          'ed-small ed-accent',
        ));
      }
    }
    // A stray prefab file's reason is its Problems block's, in red with its Rename, below.
    if (row.role === 'extra' && row.reason && !strayFile(row.path)) top.append(el('div', 'ed-dim', row.reason));
  }

  function statusBlock(row: Shown): HTMLElement | null {
    if (!isEntry(row)) {
      const section = block('File');
      section.append(facts(row));
      return section;
    }
    const source = sourceOf(row, entries());
    const status = statusOf(row, entries());
    // A stray prefab file's problem is its Problems block's, with its Rename: not said again here.
    const mark = strayFile(row.path) ? null : markOf(row, entries());
    const section = block('Status');
    const out = status === 'excluded' || excludedOf(row, entries());
    if (mark || status) {
      const line = el('div', 'ed-line ed-as-status-line');
      const word = el('span', 'ed-as-status-word');
      if (mark) word.append(el('span', markClass(mark), mark.glyph), ' ');
      // Out of the build: never exported -- its tick, here too, puts it back.
      const said = out ? 'excluded' : row.pointer ? 'LFS pointer' : (status ?? '');
      word.append(el('b', undefined, said));
      // A source is not exported; a file as delivered, under its `_`, not shipped.
      if (out) word.lastElementChild!.append(el('span', 'ed-dim', source ? ': not exported' : ': not shipped'));
      if (source && host.running(source.path)) word.append(el('span', 'ed-dim', ' · exporting…'));
      word.title = mark?.title ?? '';
      line.append(word);
      const tick = out ? tickOf(source ?? row, entries()) : null;
      if (tick) line.append(fileTick((source ?? row).path, tick));
      section.append(line);
      if (source && source !== row) section.append(el('div', 'ed-dim', `its source's, ${baseName(source.path)}: the family is one thing`));
      const reason = source?.reason ?? row.reason;
      if (reason && status !== 'current') section.append(el('div', 'ed-as-reason', reason));
      if (status) section.title = STATUS_MARKS[status].means;
    }
    // A pointer's line and its command are the preview's (§6.2), right above; its reason says it here.
    if (source?.note) section.append(el('div', 'ed-dim', source.note));
    if (source && status === 'unmade') {
      const looks = (host.tools() ?? []).filter((t) => t.state !== 'found' && (source.reason ?? '').includes(t.tool));
      // A tool's hint the reason says already, word for word, is not said again under it.
      for (const look of looks) if (look.hint && !(source.reason ?? '').includes(look.hint)) section.append(el('div', 'ed-as-tool-hint', look.hint));
      if (looks.length > 0 || /needs /.test(source.reason ?? '')) {
        section.append(button('ui', 'Set its path in Tools', 'Config ▸ Assets ▸ Tools, this tool\'s path field focused', () => host.openTools(looks[0]?.tool), 'ed-small'));
      }
    }
    if (source) {
      const run = lastRun(source.path);
      const failure = host.failure(source.path);
      if (status === 'failed' || failure) {
        const told = failure ?? (run && run !== 'asking' ? run.error : undefined);
        const first = told === undefined ? undefined : jobError(told);
        // The reason says it already, as often as not: the first line once.
        if (first && !(source.reason ?? '').includes(first)) section.append(el('div', 'ed-as-reason ed-as-red', first));
        if (run && run !== 'asking' && run.output) {
          const show = button('ui', output === source.path ? 'Hide output' : 'Show output', 'The last run\'s whole output', () => {
            output = output === source.path ? null : source.path;
            refresh();
          }, 'ed-small ed-quiet');
          section.append(show);
          if (output === source.path) section.append(el('pre', 'ed-object ed-as-output', run.output));
        }
      }
      const model = host.openModel(row.path);
      if (model && host.modelUp?.()) section.append(button('ui', 'Back to the model', `${baseName(source.path)}'s card in this panel's place: its build, its parameters, its export row`, model, 'ed-small ed-accent'));
      else if (model) section.append(button('model_open', 'Open in Model tab', `${baseName(source.path)} built and shown in the Model tab: its views, its parts, rebuilt as it is saved (or double-click it)`, model, 'ed-small ed-accent'));
      if (host.writes() && !out) {
        section.append(button(
          'asset_export', 'Export now',
          `Export ${baseName(source.path)} again now, current or not: one step, Z undoes it`,
          () => host.exportNow([source.path], true),
          'ed-small ed-accent',
        ));
      }
      // What the last build did worth reading: hidden surfaces removed, parts gone whole, samples dropped, a merge not made.
      if (run && run !== 'asking' && run.current === true && run.notes && run.notes.length > 0) {
        const notes = el('div', 'ed-as-notes');
        for (const note of run.notes) notes.append(el('div', 'ed-dim', note));
        section.append(notes);
      }
      const built = builtOf(source);
      const took = run && run !== 'asking' ? ` · took ${(run.ms / 1000).toFixed(1)} s` : '';
      if (built?.built) {
        const tools = Object.entries(built.built.tools).map(([name, version]) => `${name} ${version}`).join(', ');
        const line = el('div', 'ed-dim ed-as-built', `built ${sayDate(Date.parse(built.built.at))}${took}${tools ? ` · ${tools}` : ''}`);
        line.title = `Recorded in ${baseName(recordPath(source.path))}: ${built.built.at}`;
        section.append(line);
      } else if (took) section.append(el('div', 'ed-dim', `last tried ${run && run !== 'asking' ? sayDate(Date.parse(run.at)) : ''}${took}`));
    }
    section.append(facts(row));
    return section;
  }

  /**
   * Stats (§6.4): the bytes from the index, then what `GET stats` read of what
   * is shown -- a current source's export -- by its row, then the warnings.
   */
  function statsBlock(row: Shown): HTMLElement {
    const section = block('Stats');
    const grid = el('div', 'ed-as-stats');
    const put = (lines: readonly StatLine[]): void => {
      for (const l of lines) {
        const value = el('span', 'ed-as-stat', l.value);
        if (l.title) value.title = l.title;
        grid.append(el('span', 'ed-dim', l.label), value);
      }
    };
    put(bytesLines(row, entries()));
    section.append(grid);
    if (host.online() === false) {
      section.append(el('div', 'ed-dim', 'its numbers need the dev server: npm run dev'));
      return section;
    }
    const { path } = shownOf(row);
    const subject = entries().get(path) ?? row;
    const answer = host.stats.get(path, statsKey(subject), () => {
      if (visible) refresh();
    });
    const warnings = (said: readonly string[], stale: boolean): void => {
      for (const words of said) {
        const warn = el('div', stale ? 'ed-as-warn ed-dim' : 'ed-as-warn');
        warn.append(el('span', 'ed-as-mark ed-as-amber', '⚠'), ' ', el('span', undefined, words));
        section.append(warn);
      }
    };
    // Its family being exported again -- the source stale meanwhile, so what is shown is the source, not the export --
    // or the new export's numbers being read: the last ones, dimmed, where they were, until the new ones come. The
    // panel keeps its height, and the Options block under it does not move.
    const family = isEntry(row) ? sourceOf(row, entries()) : undefined;
    const exporting = family !== undefined && host.running(family.path);
    const settling = family !== undefined && (exporting || family.status !== 'current');
    if ((answer === 'reading' || settling) && statsLast?.path === row.path) {
      grid.classList.add('ed-dim');
      put(statsLast.lines);
      warnings(statsLast.warnings, true);
      section.querySelector('.ed-component-head')?.append(el('span', 'ed-dim ed-as-small', exporting ? ' · exporting…' : answer === 'reading' ? ' · reading…' : ' · its last export\'s'));
    } else if (answer === 'reading') section.append(el('div', 'ed-dim', 'reading…'));
    else if ('failed' in answer) section.append(el('div', 'ed-dim', `no numbers: ${answer.failed}`));
    else {
      const lines = statsRowFor(subject, answer, host.statsRows)?.lines(subject, answer) ?? [];
      put(lines);
      const said = warningsOf(subject, answer, host.warnings);
      warnings(said, false);
      if (!settling) statsLast = { path: row.path, lines, warnings: said };
    }
    return section;
  }

  /** A file's facts, small: its kind, its bytes, when it changed. */
  function facts(row: Shown): HTMLElement {
    const kind = kindOfRow(row);
    const line = el('div', 'ed-dim ed-as-facts', `${kind ? `${kind} · ` : ''}${sayBytes(row.size)} · ${sayDate(row.mtime)}`);
    line.title = `${row.size.toLocaleString('en')} bytes; changed ${sayDate(row.mtime)}`;
    const wrap = el('div');
    wrap.append(line, copyLine('path', row.path, 'the path'));
    return wrap;
  }

  /** A source's last run on this machine: asked once, again after its job ends. */
  function lastRun(source: string): Run | null | 'asking' | undefined {
    const had = runs.get(source);
    if (had !== undefined) return had;
    runs.set(source, 'asking');
    api.run(source).then((run) => {
      runs.set(source, run ?? null);
      if (visible) refresh();
    }, () => runs.set(source, null));
    return 'asking';
  }

  /** A source's record, by its path and mtime: what it was built with -- read as the Options block reads it. */
  function builtOf(source: Entry): ReturnType<Records['record']> {
    return host.records.record(recordPath(source.path), () => {
      if (visible) refresh();
    });
  }

  // ---------------------------------------------------------------- options, uses

  /**
   * The Options block (§6.5) for these targets -- one source, several of one
   * recipe's options, a folder's `export.json` -- the records read through the
   * cache, the panel drawn again as they come.
   */
  function optionsSection(targets: readonly Target[], about?: string, none?: string): HTMLElement {
    const again = (): void => {
      if (visible) refresh();
    };
    const planned = none !== undefined ? null : fieldsFor(targets, (path) => host.records.read(path, again));
    const block = optionsBlock({
      fields: planned?.shared ?? null,
      ...(about !== undefined ? { about } : {}),
      ...(none !== undefined ? { none } : {}),
      ...(planned && planned.problems.length > 0 ? { problems: planned.problems } : {}),
      ...(targets.length > 0 && targets[0]!.byFormat ? { byFormat: targets[0]!.byFormat } : {}),
      writes: host.writes(),
      change: (field, to) => host.changeOption(targets, planned?.each ?? [], field, to),
      resetAll: () => host.resetOptions(targets, planned?.each ?? []),
    });
    block.onLetGo(() => {
      if (waiting) refresh();
    });
    options = block;
    // Lit once its fields are read: a block still "reading…" is drawn again as the records come.
    const lit = targets.length === 1 ? flashing.draw(targets[0]!.path, (planned?.shared ?? null) !== null, performance.now()) : null;
    if (lit) {
      const root = block.root;
      root.classList.add('ed-as-flash');
      requestAnimationFrame(() => root.scrollIntoView({ block: 'start', behavior: lit === 'first' ? 'smooth' : 'auto' }));
      setTimeout(() => root.classList.remove('ed-as-flash'), FLASH_HOLD_MS);
    }
    return block.root;
  }

  /** The Options block of a file: a source's own, an export's its source's; none for what has no options. */
  function fileOptions(row: Shown): HTMLElement | null {
    if (!isEntry(row)) return null;
    const source = sourceOf(row, entries());
    if (!source) return null;
    const target = targetOf(source.path, false);
    if (!target) return null;
    return optionsSection([target], source === row ? undefined : `its source's, ${baseName(source.path)}: the family is one thing`);
  }

  /**
   * Uses (§6.6), for an export, a loose file, a source's export: `GET uses`'
   * lines, each with a copy, or "no literal uses found" -- never "unused", as a
   * key built at runtime is not seen.
   */
  function usesBlock(row: Shown): HTMLElement | null {
    if (!isEntry(row) || !(row.role === 'export' || row.role === 'loose' || row.role === 'source')) return null;
    const key = keyOfRow(row, entries());
    if (key === undefined) return null;
    const section = block('Uses');
    if (host.online() === false) {
      section.append(el('div', 'ed-dim', 'its uses need the dev server: npm run dev'));
      return section;
    }
    const found = host.uses([key], () => {
      if (visible) refresh();
    });
    if (found === null) section.append(el('div', 'ed-dim', 'looking for uses in src/…'));
    else if (found.length === 0) {
      section.append(el('div', undefined, 'no literal uses found'));
      section.append(el('div', 'ed-dim', `GET uses finds '${key}' written as it is in src/: a key built at runtime -- Assets.parts('props'), a level naming a model through modelIfPresent -- is not seen, so none found is not unused`));
    } else {
      for (const use of found) {
        const at = `${use.file}:${use.line}`;
        const line = el('div', 'ed-line ed-as-copy-line ed-as-use');
        const words = el('span', 'ed-as-copy-text');
        words.append(el('code', undefined, at), ' ', el('span', 'ed-dim', use.text));
        words.title = `${at}\n${use.text}`;
        line.append(words, iconButton('ui', 'copy', `Copy ${at}`, () => host.copy(at, 'where it is used')));
        section.append(line);
      }
    }
    return section;
  }

  // ---------------------------------------------------------------- several

  function many(paths: readonly string[], at: string): void {
    const rows = paths.map((p) => shownAt(index, p)).filter((r): r is Shown => r !== undefined);
    const bytes = rows.reduce((sum, r) => sum + r.size, 0);
    const title = el('div', 'ed-side-title ed-as-title', `${filesText(paths.length)} · ${sayBytes(bytes)}`);
    head.replaceChildren(title);
    // ◂ ▸: the one previewed, stepped through them -- ← → too, with the preview focused.
    const n = Math.max(0, paths.indexOf(at));
    const stepper = el('div', 'ed-line ed-as-stepper');
    const before = button('ui', '◂', 'The one before, previewed (← with the preview focused): the keys walk on from it', () => host.step(-1), 'ed-small ed-as-step');
    const after = button('ui', '▸', 'The next, previewed (→ with the preview focused): the keys walk on from it', () => host.step(1), 'ed-small ed-as-step');
    before.dataset.focus = 'step:before';
    after.dataset.focus = 'step:after';
    stepper.append(before, el('span', 'ed-as-stepper-at', `${n + 1} of ${paths.length} · ${baseName(fromTrash(at)?.path ?? at)}`), after);
    stepper.title = naming.say(at);
    top.replaceChildren(head, stepper);
    const section = block('Status');
    const words = rows.map((r) => (excludedOf(r, entries()) ? 'excluded' : isEntry(r) && r.pointer ? 'LFS pointer' : statusOf(r, entries()) ?? (isEntry(r) ? r.role : 'in the trash')));
    section.append(el('div', 'ed-as-tally', tally(words)));
    // One tick for all: on, off, or `—` where they differ; a click puts every one in, or -- all in -- out.
    const built = ticksOf(rows, entries());
    if (built) {
      const inside = built.ticks.filter((tick) => tick.on).length;
      const line = el('div', 'ed-line ed-as-build-line');
      const title = built.on === 'mixed' ? `${inside} of ${built.ticks.length} in the build -- a click puts every one in` : built.on ? 'Every one in the build -- a click leaves them all out' : 'None in the build -- a click puts them all in';
      const stuck = built.ticks.find((tick) => tick.on === (built.on === true) && tick.stuck !== undefined)?.stuck;
      line.append(buildTick(paths, built.on, title, stuck), el('span', 'ed-dim', ` · ${inside} of ${built.ticks.length}`));
      section.append(line);
    }
    const sources = [...new Set(rows.map((r) => sourceOf(r, entries())?.path).filter((p): p is string => p !== undefined))];
    if (host.writes() && sources.length > 0) {
      section.append(button(
        'asset_export', sources.length > 1 ? `Export ${sources.length} now` : 'Export now',
        `Export ${sources.length > 1 ? `all ${sources.length} sources` : 'its source'} again now, current or not: one step, Z undoes it`,
        () => host.exportNow(sources, true),
        'ed-small ed-accent',
      ));
    }
    body.append(section);
    // Options for the recipe they share: one recipe's options, or none (`sharedTargets`).
    if (sources.length === 0) return;
    const shared = sharedTargets(sources);
    const about = sources.length === 1 ? `their source's, ${baseName(sources[0]!)}` : `${sources.length} sources, one recipe: a change is every one's`;
    if (shared === 'differ') body.append(optionsSection([], undefined, 'Their recipes differ: options are set for one recipe at a time -- choose sources of one format, in one kind'));
    else if (shared !== null) body.append(optionsSection(shared, about));
  }

  // ---------------------------------------------------------------- a folder

  function folder(path: string): void {
    const project = path === PROJECT;
    // A root says what it is -- its section, and the line its row's hover has; any other folder where it is.
    const explained = naming.explain(path);
    const inSection = naming.sectionOf(path);
    const title = titled(naming.title(path), project || explained !== undefined ? naming.about(path) : naming.say(path));
    head.replaceChildren(title);
    const line = project ? 'the whole project: every root and the trash' : explained !== undefined ? `${inSection ? `${inSection.title} · ` : ''}${explained}` : naming.say(path);
    top.replaceChildren(head, el('div', 'ed-dim', line));
    let files = 0;
    let bytes = 0;
    /** Its files with a tick, and of those in the build: "12 of 14 in the build". */
    let ticked = 0;
    let built = 0;
    const count = (e: Entry): void => {
      const tick = tickOf(e, entries());
      if (!tick) return;
      ticked++;
      if (tick.on) built++;
    };
    /** The project's: what the trash holds, said apart -- on disk too, but no file of the game's. */
    let trashed = 0;
    let trashedBytes = 0;
    if (project) {
      for (const e of entries().values()) {
        if (e.role === 'record') continue;
        files++;
        bytes += e.size;
        count(e);
      }
      for (const slot of index.trash) {
        for (const f of slot.files) {
          trashed++;
          trashedBytes += f.size;
        }
      }
    } else if (under(path, TRASH)) {
      for (const slot of index.trash) {
        for (const f of index.childrenOf(`${TRASH}/${slot.slot}`).files) {
          if (!under(f.path, path)) continue;
          files++;
          bytes += f.size;
        }
      }
    } else {
      for (const e of entries().values()) {
        if (e.role === 'record' || !under(e.path, path)) continue;
        files++;
        bytes += e.size;
        count(e);
      }
    }
    const section = block('Status');
    // On disk: every file under it. The boot set -- what the game downloads first, the Assets row's figure -- is said apart.
    const disk = el('div', undefined, `${filesText(files)} · ${sayBytes(bytes)} on disk`);
    disk.title = project ? 'Every file under every root, the records left out' : `Every file under ${naming.say(path)}, its records left out`;
    section.append(disk);
    if (ticked > 0) {
      const line = el('div', built < ticked ? undefined : 'ed-dim', `${built} of ${ticked} in the build`);
      line.title = `Of the files under it with a tick -- sources, exports, parts, loose files -- ${built} in the build; ${ticked - built} out of it: a source never exported, a loose file named _ (Shift+B on the files chosen)`;
      section.append(line);
    }
    if (project && trashed > 0) {
      const line = el('div', 'ed-dim', `and in the trash: ${filesText(trashed)} · ${sayBytes(trashedBytes)}`);
      line.title = 'What Delete sent to the trash, every slot: on disk until it is emptied or the 30-day prune takes it';
      section.append(line);
    }
    if (path === ROOTS.boot.dir || project) {
      const boot = bootBytes(entries().values());
      const line = el('div', boot > host.budget ? 'ed-as-reason ed-as-amber' : 'ed-dim', `the boot set: ${sayBytes(boot)} of a budget of ${sayBytes(host.budget)}`);
      line.title = 'Every export and loose file under Assets, levels/ too: what downloads before the first frame -- the figure on the Assets row';
      section.append(line);
    }
    const counts = host.counts.of(path);
    if (total(counts) > 0) section.append(el('div', 'ed-as-reason', `Needs a hand: ${countsText(counts)}`));
    else if (!under(path, TRASH)) section.append(el('div', 'ed-dim', 'Nothing under here needs a hand'));
    const stale = (counts.get('stale') ?? 0) + (counts.get('missing') ?? 0);
    if (host.writes() && !under(path, TRASH) && stale > 0) {
      section.append(button('asset_export', 'Export all stale', `Export every stale or missing source under ${naming.say(path)}: one step, Z undoes it`, () => host.exportUnder(path), 'ed-small ed-accent'));
    }
    body.append(section);
    // The project: no export.json of its own -- where defaults are set instead, as the Source root says it.
    if (project) {
      const where = aboveKinds(ROOTS.source.dir).replace(/^above the kinds' folders: /, '').replace('a kind\'s folder', `a kind's folder under ${naming.title(ROOTS.source.dir)}`);
      body.append(optionsSection([], undefined, `The whole project: ${where}`));
      return;
    }
    // Its export.json as Options (§6): every option a row of its kind has. A folder under Assets or Packs, its Source twin's.
    const sourceSide = under(path, ROOTS.source.dir) ? path : twin(path);
    const target = sourceSide !== undefined && index.tree().has(sourceSide) ? targetOf(sourceSide, true) : undefined;
    // Above the kinds' folders: no export.json the tool writes, and where defaults are set instead -- PUT sidecar's words.
    if (target && 'refused' in target) body.append(optionsSection([], undefined, `${target.refused[0]!.toUpperCase()}${target.refused.slice(1)}`));
    else if (target) {
      const file = fromSourceRoot(target.file);
      body.append(optionsSection([target], sourceSide === path
        ? `${file}: the defaults for every source under it, a source's own record over them`
        : `${file}, its twin's: the defaults for every source under ${naming.say(sourceSide!)}`));
    }
  }

  function refresh(): void {
    // Not under a rename field: it would go with the head. Nor under an option being typed or scrubbed: once it lets go.
    if (!visible || editing) return;
    if (options?.holding() || held.some((h) => h.holding())) {
      waiting = true;
      return;
    }
    waiting = false;
    options = null;
    held = [];
    // The control with the focus, found again once the panel is drawn: a tick, a ↺, a button keep it across a redraw.
    const focused = focusKeyOf(document.activeElement);
    const showing = host.showing();
    // The lock as it is: locked or not, and shown only in a tab that has one.
    lock.show();
    body.replaceChildren();
    // One file previewed; of several, the one stepped to (the first, until ◂ ▸); a folder, none.
    const one = showing.kind === 'file' ? shownAt(index, showing.path) : showing.kind === 'many' ? shownAt(index, showing.at) : undefined;
    preview.show(one ?? null);
    preview.root.hidden = one === undefined;
    if (showing.kind === 'gone') {
      head.replaceChildren();
      top.replaceChildren(el('div', 'ed-dim ed-nothing', `Nothing selected ${REMOVED}`));
    } else if (showing.kind === 'many') many(showing.paths, showing.at);
    else if (showing.kind === 'folder') folder(showing.path);
    else {
      const row = shownAt(index, showing.path);
      if (!row) folder(showing.path);
      else {
        if (output !== null && output !== sourceOf(row, entries())?.path) output = null;
        fileHead(row);
        if (isEntry(row)) {
          body.append(...host.prefabBlocks(row.path, (block) => {
            held.push(block);
            block.onLetGo(() => {
              if (waiting) refresh();
            });
          }));
        }
        const status = statusBlock(row);
        if (status) body.append(status);
        body.append(statsBlock(row));
        const opts = fileOptions(row);
        if (opts) body.append(opts);
        const uses = usesBlock(row);
        if (uses) body.append(uses);
      }
    }
    // The preview's block too, once: a block with its caret already is left as it is.
    foldable(panel, 'assets:');
    refocus(focused);
  }

  return {
    panel,
    head,
    side,
    ask,
    flashOptions(path) {
      flashing.want(path, performance.now());
      refresh();
    },
    refresh,
    forget(source) {
      runs.delete(source);
    },
    showsFamily(source) {
      const showing = host.showing();
      const paths = showing.kind === 'many' ? showing.paths : showing.kind === 'file' ? [showing.path] : [];
      return paths.some((p) => p === source || entries().get(p)?.source === source);
    },
    editName(field) {
      const name = head.querySelector<HTMLElement>('.ed-as-title');
      if (!name || !panel.contains(name)) return false;
      name.replaceWith(field);
      editing = field;
      return true;
    },
    endEdit() {
      if (!editing) return;
      editing = null;
      refresh();
    },
    note(text, bad = false, use) {
      noted.replaceChildren();
      noted.hidden = text === null;
      if (text === null) return;
      const words = el('span', bad ? 'ed-as-red' : undefined, text);
      noted.append(words);
      if (use) {
        const b = button('ui', use.label, use.label, use.run, 'ed-small');
        // Pressed, it keeps the rename field focused: the field takes the suggestion, and Enter is still its --
        // and the card the field is in keeps the keys (`keepsFocus`: the tool's press on the panel lets it be).
        b.dataset.keepsFocus = '';
        b.addEventListener('pointerdown', (event) => event.preventDefault());
        noted.append(' ', b);
      }
    },
    showOutput() {
      const showing = host.showing();
      if (showing.kind !== 'file') return;
      const row = entries().get(showing.path);
      const source = row ? sourceOf(row, entries()) : undefined;
      if (!source) return;
      output = source.path;
      runs.delete(source.path);
      refresh();
    },
    setVisible(show) {
      visible = show;
      panel.hidden = !show;
      if (!show) {
        ask.close();
        // Leaving: the preview's decode let go, its sound stopped, the canvas out of the page.
        preview.show(null);
        return;
      }
      side.refresh();
      refresh();
    },
    dispose() {
      document.removeEventListener('focusin', focusedElsewhere);
      ask.close();
      preview.dispose();
      side.dispose();
      panel.remove();
    },
  };
}
