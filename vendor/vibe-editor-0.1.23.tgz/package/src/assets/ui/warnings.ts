/**
 * The warnings under a file's Stats (Docs/assets-tool.md §6.4, §12): each a
 * marked line of one sentence and the number, for what a browser game pays
 * for -- a texture past what phones' GPUs take, a side that is no power of two,
 * a KTX2 of one mip level, a model past a triangle budget, a long sound
 * effect, a file Git LFS never fetched. Each threshold a named constant; a game adds or replaces a row
 * through `createAssetsTool({ warnings })`, merged over these by name.
 *
 * A row reads the file (an `Entry`, or under the Trash root a `TrashFile`) and
 * what `GET stats` read of what is shown of it -- a current source's export.
 * Pure: node tests it (`assets-stats.test.ts`).
 */
import type { AudioStats, FileStats, ImageStats, ModelStats } from '@vibe/pipeline/assets-types';
import type { KindName } from '@vibe/pipeline/kinds';
import type { Shown } from '../model.ts';
import { kindOfRow } from './files-columns.ts';

/** A texture's longer side past this is over what many phones' GPUs take, and four times the memory of the side below. */
export const TEXTURE_MAX = 2048;
/** A model past this many triangles is more than a browser game draws many of. */
export const TRIANGLES_MAX = 50_000;
/** A sound effect longer than this, in seconds, is likely music, or a master left untrimmed. */
export const SFX_SECONDS = 10;
/**
 * A KTX2 with fewer mip levels than this, bigger than a texel, is drawn with
 * no chain: smaller than its size it shimmers -- or, its mipmaps left to the
 * runtime, which three makes for none handed in by level, it comes out empty.
 */
export const KTX2_MIPS_MIN = 2;

/** One warning: when it applies, and what it says -- one sentence and the number. */
export interface Warning {
  when(entry: Shown, stats: FileStats): boolean;
  say(entry: Shown, stats: FileStats): string;
}

const image = (stats: FileStats): ImageStats | undefined => (stats.kind === 'image' ? (stats.stats as ImageStats | undefined) : undefined);
const model = (stats: FileStats): ModelStats | undefined => (stats.kind === 'model' ? (stats.stats as ModelStats | undefined) : undefined);
const audio = (stats: FileStats): AudioStats | undefined => (stats.kind === 'audio' ? (stats.stats as AudioStats | undefined) : undefined);

/** Kinds whose images are drawn on a material, mipmapped: where a side's power of two matters. */
const MIPMAPPED: readonly (KindName | undefined)[] = ['textures', 'models'];
/** Kinds whose images go to the GPU as they are: where a texture's size matters. */
const ON_GPU: readonly (KindName | undefined)[] = ['textures', 'models', 'atlases'];

const isPow2 = (n: number): boolean => n > 0 && (n & (n - 1)) === 0;
const count = (n: number): string => n.toLocaleString('en');

export const WARNINGS: Readonly<Record<string, Warning>> = {
  'texture size': {
    when(entry, stats) {
      const s = image(stats);
      return s !== undefined && ON_GPU.includes(kindOfRow(entry) as KindName | undefined) && Math.max(s.width ?? 0, s.height ?? 0) > TEXTURE_MAX;
    },
    say(_entry, stats) {
      const s = image(stats)!;
      return `Over ${TEXTURE_MAX} on a side, which many phones' GPUs cannot take: ${s.width} × ${s.height}`;
    },
  },
  'power of two': {
    when(entry, stats) {
      const s = image(stats);
      if (!s || !MIPMAPPED.includes(kindOfRow(entry) as KindName | undefined) || s.width === undefined || s.height === undefined) return false;
      return s.pow2 === false || !isPow2(s.width) || !isPow2(s.height);
    },
    say(_entry, stats) {
      const s = image(stats)!;
      const sides = [s.width!, s.height!].filter((n) => !isPow2(n));
      return `A side that is no power of two, which older GPUs cannot mipmap or repeat and PVRTC cannot compress: ${[...new Set(sides)].join(' and ')} in ${s.width} × ${s.height}`;
    },
  },
  mips: {
    when(entry, stats) {
      const s = image(stats);
      if (!s || s.format !== 'ktx2' || !MIPMAPPED.includes(kindOfRow(entry) as KindName | undefined)) return false;
      return (s.mips ?? 1) < KTX2_MIPS_MIN && Math.max(s.width ?? 0, s.height ?? 0) > 1;
    },
    say(_entry, stats) {
      const s = image(stats)!;
      const chain = Math.floor(Math.log2(Math.max(s.width ?? 1, s.height ?? 1))) + 1;
      return `One mip level: smaller than its size it shimmers, or with its mipmaps left to the runtime comes out empty -- make it with them (toktx --genmipmap): ${s.mips ?? 1} of ${chain}`;
    },
  },
  triangles: {
    when: (_entry, stats) => (model(stats)?.triangles ?? 0) > TRIANGLES_MAX,
    say: (_entry, stats) => `More triangles than a browser game draws many of (over ${count(TRIANGLES_MAX)}): ${count(model(stats)!.triangles)}`,
  },
  'sfx length': {
    when: (entry, stats) => kindOfRow(entry) === 'sfx' && (audio(stats)?.duration ?? 0) > SFX_SECONDS,
    say: (_entry, stats) => `Long for a sound effect (over ${SFX_SECONDS} s) -- music goes under audio/music: ${audio(stats)!.duration!.toFixed(1)} s`,
  },
  pointer: {
    when: (entry, stats) => stats.pointer === true || ('pointer' in entry && entry.pointer === true),
    say: (entry) => `A Git LFS pointer, not the file -- git lfs pull brings it, and its numbers: ${count(entry.size)} bytes on disk`,
  },
};

/** What applies of `table` to `entry` and its stats, in the table's order: each a sentence. */
export function warningsOf(entry: Shown, stats: FileStats, table: Readonly<Record<string, Warning>> = WARNINGS): string[] {
  const out: string[] = [];
  for (const row of Object.values(table)) if (row.when(entry, stats)) out.push(row.say(entry, stats));
  return out;
}
