/**
 * A dropped model read for its parts in the browser, before anything is
 * uploaded (Docs/assets-tool.md §5, "Parts are read after the sheet opens"),
 * with part one's own scanners (`parts.ts`): the sheet and the server cannot
 * disagree about what a model names.
 *
 * - **A file streamed through its scanner**, `feed` then `done`, chunk by chunk
 *   as the server's hashing pass reads it (§A.3), its progress told as it goes
 *   ("reading robot.fbx for its parts · 40 %"): an `.fbx`, a `.lua`, a
 *   `.gltf`, an `.obj`, a `.dae`, and an `.obj`'s `.mtl` in turn (`PART_DEPS`).
 * - **A `.glb` by its head alone** (`readGlbHead`): its first 20 bytes say how
 *   long its header and JSON chunk are (`glbHeadLength`), and only that much is
 *   read -- a 300 MB `.glb` costs a few kilobytes -- at most `GLB_HEAD_MAX`
 *   (16 MB; past it the head is not read, and the server finds the parts). Its
 *   JSON gives its parts (`gltfUris`, what its scanner would give) and its
 *   `extensionsUsed`: a Draco, meshopt or KTX2 one imports as delivered.
 * - **Stoppable**: a sheet closed stops its reads (`signal`).
 *
 * Pure but for `Blob`, which node has: `parts-browser.test.ts` reads
 * `packages/pipeline/src/assets/fixtures/` as `File`s, in small chunks, and gets the names
 * `parts.test.ts` asserts.
 */
import { glbHeadLength, glbJson, gltfUris, type Scanner } from '@vibe/pipeline/parts';

/** A `.glb` whose header and JSON chunk are longer than this is not read here: 16 MB. */
export const GLB_HEAD_MAX = 16 << 20;

/** The extensions that make a `.glb` compressed already: through `finish` and `draco` again it would be lossy twice (§A.5). */
export const COMPRESSED: readonly string[] = ['KHR_draco_mesh_compression', 'EXT_meshopt_compression', 'KHR_meshopt_compression', 'KHR_texture_basisu'];

/** What a `.glb`'s head said: its parts and extensions; or that it was too long to read here; or that it is no GLB. */
export type GlbHead = { uris: string[]; extensions: string[]; compressed: boolean } | { tooBig: number } | { notGlb: true };

/** The chunk a read hands its scanner at most: the browser's stream's own, cut to this. */
const CHUNK = 1 << 20;

export interface ReadOptions {
  /** Each chunk at most this many bytes: the stream's own otherwise, cut to 1 MB. A test feeds 1, 3, 7. */
  chunk?: number;
  /** Bytes read so far. */
  progress?(read: number): void;
  signal?: AbortSignal;
}

/** `file`'s bytes, in order, in chunks of at most `size`. */
async function* chunksOf(file: Blob, size: number, signal?: AbortSignal): AsyncGenerator<Uint8Array> {
  const reader = file.stream().getReader();
  try {
    for (;;) {
      if (signal?.aborted) throw new Error('stopped');
      const { done, value } = await reader.read();
      if (done) return;
      for (let i = 0; i < value.length; i += size) yield value.subarray(i, i + size);
    }
  } finally {
    reader.releaseLock();
  }
}

/** `file` fed to `scanner` chunk by chunk, then `done`: the names it holds. Rejects on a file the scanner cannot read, or when stopped. */
export async function scanFile(file: Blob, scanner: Scanner, options: ReadOptions = {}): Promise<string[]> {
  let read = 0;
  for await (const chunk of chunksOf(file, options.chunk ?? CHUNK, options.signal)) {
    scanner.feed(chunk);
    read += chunk.length;
    options.progress?.(read);
  }
  return scanner.done();
}

/** A `.glb`'s head: its first 20 bytes, then its header and JSON chunk -- never the rest, and nothing past `max`. */
export async function readGlbHead(file: Blob, max = GLB_HEAD_MAX): Promise<GlbHead> {
  const first = new Uint8Array(await file.slice(0, 20).arrayBuffer());
  const length = glbHeadLength(first);
  if (length === undefined) return { notGlb: true };
  if (length > max) return { tooBig: length };
  const json = glbJson(new Uint8Array(await file.slice(0, length).arrayBuffer()));
  const extensions = [...(json.extensionsUsed ?? [])];
  return { uris: gltfUris(json), extensions, compressed: extensions.some((e) => COMPRESSED.includes(e)) };
}
