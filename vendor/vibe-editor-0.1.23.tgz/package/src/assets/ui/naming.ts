/**
 * How the Assets tool names things (Docs/assets-tool.md §3, §7): the project
 * above the roots (`''`) by a game's `titles.project`, else "Project"; the
 * roots by their titles -- `ROOT_TITLES`, the defaults for the three part one has
 * (`kinds.ts`'s `ROOT_NAMES` are their keys), then a root's own `title`, or
 * its folder's last part capitalised, and a game's `titles` over all of them
 * -- the Trash's slots by when ("2026-10-04 09:00 · 3 files"; the automatic
 * one "Previous export (automatic) · 2 files"), and any path as the tool says
 * it, `AssetsSource/models/props/crate.lua`, a slot by its title and never its raw id;
 * a breadcrumb from its root, `Source › models` -- the root is the tab the
 * Folders column has up; and the folder a folder is in (`parent`), a root's
 * none.
 *
 * And the tree's two sections under the project (§3): **Not shipped**, the
 * roots that never ship (Source), and **Shipped**, those that do (Assets,
 * Packs) -- labels, not folders -- with what each root is in one line
 * (`ROOT_ABOUT`), said on its row's hover, its section's and the inspector.
 *
 * And a kind's folder by its kind (`kindOf`): every kind's -- the table's and a project's own, as the
 * dev server lists them (`GET kinds`) -- titled by its key type, `Tilemap`, beside its name.
 *
 * And a name in a rename field: the stem to edit, the extension grey and
 * fixed (`renameParts`); the key it makes; the uses line said while it is open.
 *
 * One owner: the tree, the breadcrumb, the hint and the inspector all name
 * through it. Pure: node tests it (`naming.test.ts`).
 */
import type { TrashSlot } from '@vibe/pipeline/assets-types';
import { ROOTS, TRASH, kindRows, type KindRow, type Root } from '@vibe/pipeline/kinds';
import { AUTO_SLOT, baseName, dirName, fromTrash, slotTime, under } from '@vibe/pipeline/paths';
import { PROJECT } from '../model.ts';
import { filesText } from './budget.ts';
import { sayDate } from './files-columns.ts';

/** What the tool calls the three roots part one has, by their key in `ROOTS`: the defaults, under a game's `titles`. */
export const ROOT_TITLES: Readonly<Record<string, string>> = { source: 'Source', boot: 'Assets', packs: 'Packs' };
/**
 * What each of the three roots is, in one line, by its key in `ROOTS`: its
 * row's hover, the inspector with it chosen. Another root says whether it
 * ships (`ROOT_SHIPS`, `ROOT_STAYS`).
 */
export const ROOT_ABOUT: Readonly<Record<string, string>> = {
  source: 'originals: never in a build, converted into Assets or a pack',
  boot: 'the boot set: in the build, downloaded before the first frame',
  packs: 'shipped zipped, downloaded when a pack is mounted',
};
const ROOT_SHIPS = 'in the build';
const ROOT_STAYS = 'never in a build';

/** The tree's two sections, by whether their roots ship: the title and what it means, one line. */
export const SECTIONS = {
  unshipped: { title: 'Not shipped', about: 'what the shipped files are made from: never in a build' },
  shipped: { title: 'Shipped', about: 'what the game downloads: the boot set before the first frame, a pack when it is mounted' },
} as const;
export type SectionId = keyof typeof SECTIONS;

/** A section of the tree, under the project: a label over its roots, never a folder -- no path, no selection, no drop. */
export interface Section {
  id: SectionId;
  title: string;
  /** What it means, on its label's hover. */
  about: string;
  /** Its roots' folders, in the tree's order. */
  roots: readonly string[];
}

/** The Trash root's title. */
export const TRASH_TITLE = 'Trash';
/** The project's title, above the roots, unless a game's `titles.project` names it. */
export const PROJECT_TITLE = 'Project';
/** The automatic slot's name (§7): it holds the export before the last of each file an automatic export replaced. */
export const AUTO_TITLE = 'Previous export (automatic)';

/** `n` files, said: `budget.ts`'s, which a folder's size says too. */
export { filesText };

/**
 * A name as its rename field shows it (§6.1): the stem to edit, and the
 * extension after it, grey and fixed -- a family has several, and `validName`
 * wants one dot. A folder's name is all stem.
 */
export function renameParts(name: string, folder = false): { stem: string; ext: string } {
  const dot = name.lastIndexOf('.');
  if (folder || dot <= 0) return { stem: name, ext: '' };
  return { stem: name.slice(0, dot), ext: name.slice(dot) };
}

/** The name a rename field makes: the stem typed, trimmed, and the extension it kept. */
export const renamedName = (stem: string, ext: string): string => `${stem.trim()}${ext}`;

/** A key under a new stem: `characters/robot` is `characters/hero`; a pack's keeps its name, `reef:props/box`. */
export function keyWithStem(key: string, stem: string): string {
  const at = Math.max(key.lastIndexOf('/'), key.lastIndexOf(':'));
  return `${key.slice(0, at + 1)}${stem}`;
}

/**
 * What `GET uses` found, as a rename's line says it (§6.1): "named in
 * src/game/index.ts:38: the build fails until it is changed", or "no literal
 * uses in src/" -- and, as the stem is typed, what the key becomes. `uses`
 * null while it is asked.
 */
export function usesLine(uses: ReadonlyArray<{ file: string; line: number }> | null, becomes?: string): string {
  const said = uses === null
    ? 'looking for uses in src/…'
    : uses.length === 0
      ? 'no literal uses in src/'
      : `named in ${uses[0]!.file}:${uses[0]!.line}${uses.length > 1 ? ` and ${uses.length - 1} more` : ''}: the build fails until it is changed`;
  return becomes !== undefined ? `${said}: the key becomes ${becomes}` : said;
}

/** How the tool names roots, slots and paths. */
export interface Naming {
  /** The roots' folders in the tree's order, under the project: those not shipped (Source, any other), those shipped (Assets, Packs, any other), then the Trash. */
  readonly roots: readonly string[];
  /** The two sections, Not shipped then Shipped, each with its roots -- one with none left out. */
  readonly sections: readonly Section[];
  /** The section a root is in; undefined for the Trash, the project, any other folder. */
  sectionOf(root: string): Section | undefined;
  /** What a root is, in one line (`ROOT_ABOUT`); undefined for any other folder. */
  explain(path: string): string | undefined;
  /** Is a path under a root that ships (true), one that does not (false), or neither -- the Trash, the project (undefined)? */
  shipsAt(path: string): boolean | undefined;
  /** The project's, a root's or a slot's title -- a slot's with how many files it holds; any other folder's own name. */
  title(path: string): string;
  /** The root folder a path is under, the Trash's too; undefined outside them -- and for the project, which is no root. */
  rootOf(path: string): string | undefined;
  /** A path as the tool says it: `AssetsSource/models/characters/robot.fbx`; a slot `Trash/2026-10-04 09:00`; a trashed file by the path it had, `Trash/AssetsSource/…`; the project by its title. */
  say(path: string): string;
  /** What a folder is, on hover over its row: the project's roots, its root's folder, a slot's meaning, else `say`. */
  about(path: string): string;
  /** A folder's breadcrumb: its root -- the tab it is under -- then each folder down to it, with what it is called; the project alone for the project. */
  crumbs(folder: string): { path: string; text: string }[];
  /** The folder `folder` is in: a root's none (null) -- it is its tab's top -- and the project's none. */
  parent(folder: string): string | null;
  /** The kind whose folder `path` is -- under Assets, or under Source for a kind with sources -- or undefined. */
  kindOf(path: string): KindRow | undefined;
}

const capital = (word: string): string => word.charAt(0).toUpperCase() + word.slice(1);

/**
 * The tool's names: `titles`, a game's, over `ROOT_TITLES` by a root's key --
 * `trash` the Trash's, `project` the project's; `slots` the Trash's, read each
 * time, for how many files a slot holds.
 */
export function createNaming(titles: Readonly<Record<string, string>>, slots: () => readonly TrashSlot[], kinds: () => readonly KindRow[] = () => kindRows()): Naming {
  const rows = Object.entries(ROOTS as Readonly<Record<string, Root>>);
  // Those not shipped first, then those shipped; in each, part one's three before a game's.
  const order = (key: string, root: Root): number => (root.ships ? 10 : 0) + (key === 'source' ? 0 : key === 'boot' ? 1 : key === 'packs' ? 2 : 3);
  const sorted = [...rows].sort((a, b) => order(a[0], a[1]) - order(b[0], b[1]));
  const byDir = new Map(sorted.map(([key, root]) => [root.dir, titles[key] ?? ROOT_TITLES[key] ?? root.title ?? capital(baseName(root.dir))]));
  const explained = new Map(sorted.map(([key, root]) => [root.dir, ROOT_ABOUT[key] ?? (root.ships ? ROOT_SHIPS : ROOT_STAYS)]));
  const shipping = new Map(sorted.map(([, root]) => [root.dir, root.ships]));
  const roots = [...sorted.map(([, root]) => root.dir), TRASH];
  const sections: Section[] = (['unshipped', 'shipped'] as const)
    .map((id) => ({ id, title: SECTIONS[id].title, about: SECTIONS[id].about, roots: sorted.filter(([, root]) => root.ships === (id === 'shipped')).map(([, root]) => root.dir) }))
    .filter((section) => section.roots.length > 0);
  const trashTitle = titles.trash ?? TRASH_TITLE;
  const projectTitle = titles.project ?? PROJECT_TITLE;

  const rootOf = (path: string): string | undefined => {
    let best: string | undefined;
    for (const dir of roots) if (under(path, dir) && (best === undefined || dir.length > best.length)) best = dir;
    return best;
  };
  /** A slot as said, without its count: when it was made, or the automatic one's name. */
  const when = (slot: string): string => {
    if (slot === AUTO_SLOT) return AUTO_TITLE;
    const at = slotTime(slot);
    return at ? sayDate(at.getTime()) : slot;
  };
  const isSlot = (path: string): boolean => dirName(path) === TRASH && path !== TRASH;
  const kindOf = (path: string): KindRow | undefined =>
    kinds().find((kind) => path === `${ROOTS.boot.dir}/${kind.dir}` || (kind.source && path === `${ROOTS.source.dir}/${kind.dir}`));
  const title = (path: string): string => {
    if (path === PROJECT) return projectTitle;
    if (path === TRASH) return trashTitle;
    const own = byDir.get(path);
    if (own !== undefined) return own;
    if (isSlot(path)) {
      const slot = baseName(path);
      return `${when(slot)} · ${filesText(slots().find((s) => s.slot === slot)?.files.length ?? 0)}`;
    }
    return baseName(path);
  };
  const say = (path: string): string => {
    if (path === PROJECT) return projectTitle;
    if (isSlot(path)) return `${trashTitle}/${when(baseName(path))}`;
    const trashed = fromTrash(path);
    if (trashed) return `${trashTitle}/${say(trashed.path)}`;
    const root = rootOf(path);
    if (root === undefined) return path;
    return path === root ? title(root) : `${title(root)}/${path.slice(root.length + 1)}`;
  };
  return {
    roots,
    sections,
    sectionOf: (root) => sections.find((section) => section.roots.includes(root)),
    explain: (path) => explained.get(path),
    shipsAt(path) {
      const root = rootOf(path);
      return root === undefined ? undefined : shipping.get(root);
    },
    title,
    rootOf,
    say,
    about(path) {
      if (path === PROJECT) return `${projectTitle}: the whole project -- ${roots.filter((r) => r !== TRASH).map(title).join(', ')} and the ${trashTitle}`;
      if (path === TRASH) return `${trashTitle}: what the tool deleted, by when`;
      if (byDir.has(path)) return `${title(path)} (${path}/) -- ${explained.get(path)}`;
      if (isSlot(path)) {
        return baseName(path) === AUTO_SLOT
          ? `${say(path)}: the export before the last, kept by automatic exports -- one a file`
          : `${say(path)}: what was moved to the trash then`;
      }
      const kind = kindOf(path);
      if (kind) return `${say(path)} -- ${kind.type}: ${kind.project ? "the project's own kind" : 'the kind'} '${kind.name}', ${kind.ext.map((e) => `.${e}`).join(' ')}${kind.project ? ` (Assets.data('${kind.name}', key))` : ''}`;
      return say(path);
    },
    crumbs(folder) {
      if (folder === PROJECT) return [{ path: PROJECT, text: projectTitle }];
      const root = rootOf(folder);
      if (root === undefined) return [{ path: folder, text: folder }];
      // From the root: its tab is the top (Docs/assets-tool.md §3), the project above it never said.
      const out = [{ path: root, text: title(root) }];
      if (folder === root) return out;
      let at = root;
      for (const part of folder.slice(root.length + 1).split('/')) {
        at = `${at}/${part}`;
        out.push({ path: at, text: title(at) });
      }
      return out;
    },
    kindOf,
    parent(folder) {
      if (folder === PROJECT) return null;
      const root = rootOf(folder);
      if (root === folder) return null;
      return root === undefined ? PROJECT : dirName(folder);
    },
  };
}
