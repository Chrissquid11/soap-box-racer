/**
 * The Assets tool's Prefab block (Docs/prefabs.md §7, Docs/assets-tool.md
 * §6): what the inspector says of a prefab file under its preview.
 *
 * - **Problems** first, in red: its file not parsing (the dev server's
 *   `problem`, with the line), or the last live compile's error naming it --
 *   the last good compile is what the game runs meanwhile.
 * - **Root**: its root's components, edited here without opening it
 *   (`prefab-root-block.ts`), each edit one step written to its file.
 * - **Entities**: its nodes as compiled -- nesting and overrides worked out --
 *   as a small tree, each with its name (or id) and what it is made of; an
 *   entity of a nested prefab says which.
 * - **Pool**: `warm` and `max`, edited here and written to its file (one step,
 *   Z undoes); and live, how many are parked and out in the world now. None
 *   set: the fields empty, a value in either sets one.
 * - **Used by**: the prefabs that nest it, each a link to its file; the
 *   levels and the scene files holding an instance of it, each a link too
 *   (Docs/prefabs.md §6).
 *
 * A file that is no prefab (`strayBlock`) -- a `.json` under `prefabs/`, a
 * `.prefab` outside it -- has its problem in red instead, and for the first
 * a one-click Rename to `.prefab` (Docs/prefabs.md §2).
 *
 * Its live numbers are read again twice a second while it is on the page;
 * nothing else is held.
 */
import type { StrayPrefab } from '@vibe/pipeline/paths';
import { compiledPrefab, untypedPrefab as prefab, type CompiledPrefab, type PrefabFile, type World } from '@vibe/engine';
import { button, el } from '../../shell.ts';
import type { Holding } from './assets-options.ts';
import { rootBlock, type RootBlockHost } from './prefab-root-block.ts';
import { nestersOf, prefabPathOf } from './prefab-steps.ts';

/** What the block asks of the tool. */
export interface PrefabBlockHost {
  readonly world: World;
  /** Every prefab file as the page holds it, by key. */
  files(): Readonly<Record<string, PrefabFile>>;
  /** Its problem now: a parse error with its line, or the compile's error naming it; null for none. */
  problem(key: string): string | null;
  /** May this page write files. */
  writes(): boolean;
  /** Its pool's numbers written to its file, one step; null takes the pool out. */
  setPool(key: string, pool: { warm: number; max: number } | null): void;
  /** A file's folder opened with it chosen. */
  reveal(path: string): void;
  /** The levels holding an instance of `key`, by key. */
  levels(key: string): string[];
  /** The scene files holding one, by key. */
  scenes(key: string): string[];
  /** A level's file, by key: what Used by reveals. */
  levelPath(key: string): string;
  /** A scene's file, by key: the same. */
  scenePath(key: string): string;
  /** The prefab opened to edit, the scene put aside (Docs/prefabs.md §7). */
  open(key: string): void;
  /** The Root block's: its root edited here (`prefab-root-block.ts`). */
  readonly root: RootBlockHost;
}

const section = (title: string): HTMLElement => {
  const s = el('div', 'ed-component ed-as-block');
  s.append(el('div', 'ed-component-head', title));
  return s;
};

/** The node's line in the tree: its name or id, then what it is made of. */
function nodeLine(p: CompiledPrefab, n: number): HTMLElement {
  let depth = 0;
  for (let up = p.parents[n]!; up >= 0; up = p.parents[up]!) depth++;
  const line = el('div', 'ed-line ed-as-pf-node');
  line.style.setProperty('--as-depth', String(depth));
  const id = p.paths[n] || '(root)';
  const name = p.names[n] ?? id;
  const said = el('span', 'ed-as-pf-name', name);
  said.title = `id path ${id}${p.views[n] ? ` · draws ${p.views[n]}` : ''}`;
  const made = el('span', 'ed-dim ed-as-pf-made', p.kinds[n]!.components.map((c) => c.name).join(', '));
  line.append(said, made);
  return line;
}

/** A number field of the pool's: whole, from `min`. */
function numberField(value: number | null, min: number, title: string, disabled: boolean, changed: (v: number | null) => void): HTMLInputElement {
  const input = el('input', 'ed-input ed-as-pf-number');
  input.type = 'number';
  input.min = String(min);
  input.step = '1';
  input.value = value === null ? '' : String(value);
  input.placeholder = '–';
  input.title = title;
  input.disabled = disabled;
  input.addEventListener('change', () => {
    const raw = input.value.trim();
    changed(raw === '' ? null : Math.max(min, Math.round(Number(raw))));
  });
  return input;
}

/** A stray prefab file's Problems block: what it is, and the Rename that fixes it where this page writes. */
export function strayBlock(stray: StrayPrefab, writes: boolean, rename: (name: string) => void): HTMLElement {
  const s = section('Problems');
  s.append(el('div', 'ed-as-red ed-as-pf-problem', stray.problem));
  if (stray.renameTo !== undefined) {
    const to = stray.renameTo;
    const line = el('div', 'ed-buttons');
    const go = button('asset_move', `Rename to ${to}`, `Made a prefab: compiled, a key, in Spawn -- Z undoes`, () => rename(to), 'ed-small ed-accent');
    go.disabled = !writes;
    line.append(go);
    s.append(line);
  }
  return s;
}

/** The Prefab block for `key`, or null for a key that is no prefab file. */
export function prefabBlock(key: string, host: PrefabBlockHost, hold: (block: Holding) => void): HTMLElement[] {
  const out: HTMLElement[] = [];
  const files = host.files();
  const file = files[key];
  const p = compiledPrefab(key);
  const problem = host.problem(key);
  if (problem) {
    const s = section('Problems');
    s.append(el('div', 'ed-as-red ed-as-pf-problem', problem));
    s.append(el('div', 'ed-dim', p ? 'The game runs the last good compile of it until the file is fixed: no reload needed' : 'Not compiled yet: fix the file, and it compiles as it is saved'));
    out.push(s);
  }

  if (file) {
    const s = section('Edit');
    const line = el('div', 'ed-buttons');
    line.append(button('scene_open_prefab', 'Open', p ? `Edit ${key} alone in the scene, the scene put aside until Back${problem ? ' -- read-only while it has a problem' : ''} (a double-click on it does too)` : `${key} is not compiled: fix the file first`, () => host.open(key), 'ed-small ed-accent'));
    if (!p) line.querySelector('button')!.disabled = true;
    s.append(line);
    out.push(s);
  }

  // Its root's components, edited here: what the compile made of it, the file written from them.
  const root = file && p ? rootBlock(key, host.root) : null;
  if (root) {
    hold(root.hold);
    out.push(root.root);
  }

  if (p) {
    const s = section('Entities');
    for (let n = 0; n < p.count; n++) s.append(nodeLine(p, n));
    s.append(el('div', 'ed-dim', 'A change to the file reaches every instance at once -- new, parked, and out in the world where it holds no override of its own (one step, Z undoes)'));
    out.push(s);
  }

  if (file || p) {
    const s = section('Pool');
    const size = p?.pool ?? file?.pool ?? null;
    const line = el('div', 'ed-line ed-as-pf-pool');
    let warm = size?.warm ?? null;
    let max = size?.max ?? null;
    const commit = (): void => {
      if (warm === null && max === null) return host.setPool(key, null);
      const m = Math.max(1, max ?? warm ?? 1);
      host.setPool(key, { warm: Math.min(warm ?? 0, m), max: m });
    };
    const off = !host.writes() || !file;
    line.append(
      el('span', 'ed-dim', 'warm'),
      numberField(warm, 0, 'How many are made and parked once the world exists', off, (v) => ((warm = v), commit())),
      el('span', 'ed-dim', 'max'),
      numberField(max, 1, 'How many it holds at most, parked and out together: past it, instantiate gives NONE and warns', off, (v) => ((max = v), commit())),
    );
    s.append(line);
    const live = el('div', 'ed-as-pf-live');
    const read = (): void => {
      if (!p?.pool) {
        live.textContent = size ? 'pooled from the next compile' : 'no pool: every instance is made new, and destroyed for real';
        return;
      }
      const pool = host.world.pool(prefab(key));
      const said = `${pool.parked} parked · ${pool.out} out${pool.resting > 0 ? ` · ${pool.resting} given back` : ''} in the world now`;
      if (live.textContent !== said) live.textContent = said;
    };
    read();
    s.append(live);
    if (p?.pool) {
      const timer = setInterval(() => {
        if (!live.isConnected) return clearInterval(timer);
        read();
      }, 500);
    }
    out.push(s);
  }

  const s = section('Used by');
  const nesters = nestersOf(key, files);
  if (nesters.length === 0) s.append(el('div', undefined, 'no other prefab nests it'));
  for (const k of nesters) {
    const line = el('div', 'ed-line');
    line.append(button('ui', k, `Open ${k}'s folder with it chosen: it nests ${key}`, () => host.reveal(prefabPathOf(k)), 'ed-small ed-quiet ed-as-link'));
    s.append(line);
  }
  // Levels and scenes hold instances by reference: a rename or a move follows by uid -- the server rewrites their keys in its
  // step (Docs/asset-ids.md §4) -- and a delete is refused while one holds one.
  const levels = host.levels(key);
  for (const k of levels) {
    const line = el('div', 'ed-line');
    line.append(button('ui', `level ${k}`, `Open the levels folder with ${k} chosen: it holds an instance of ${key}`, () => host.reveal(host.levelPath(k)), 'ed-small ed-quiet ed-as-link'));
    s.append(line);
  }
  const scenes = host.scenes(key);
  for (const k of scenes) {
    const line = el('div', 'ed-line');
    line.append(button('ui', `scene ${k}`, `Open the scenes folder with ${k} chosen: it holds an instance of ${key}`, () => host.reveal(host.scenePath(k)), 'ed-small ed-quiet ed-as-link'));
    s.append(line);
  }
  if (levels.length === 0 && scenes.length === 0) s.append(el('div', 'ed-dim', 'no level or scene holds an instance of it'));
  else s.append(el('div', 'ed-dim', 'a Rename or a Move follows in each by its uid, in its step; a Delete is refused while one holds it'));
  out.push(s);
  return out;
}
