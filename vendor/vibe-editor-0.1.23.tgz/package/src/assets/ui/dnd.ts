/**
 * Drag and drop in the Assets tool (Docs/assets-tool.md §3, §4, §5.1): files
 * from the desktop import, tiles dragged inside the tool move.
 *
 * - **A desktop drop is read** (`readEntries`): `webkitGetAsEntry()` walks a
 *   dropped folder, its relative paths kept (`robot/textures/skin.png`), a
 *   folder's reader asked again until it answers nothing (Chrome gives a
 *   hundred at a time); the OS's and the art tools' leavings (`IGNORED`) are
 *   skipped, a folder of them not walked, and counted. A browser that gives no
 *   entry gives the file (`getAsFile`). A picker's list (`<input
 *   webkitdirectory>`) is read the same way (`readList`).
 * - **One guard on `window`** while the tab is up: a drag carrying files or
 *   tiles is refused anywhere but a target -- `preventDefault`, `dropEffect
 *   = 'none'` -- so a drop a few pixels off a card never opens the file in
 *   the tab and takes the game with it.
 * - **Targets lit, and refusals said**: a folder row, a folder tile, the files
 *   card (its open folder) and the inspector (the folder it shows) -- lit
 *   (`ed-as-drop`), or struck through (`ed-as-drop-no`); what a drop there
 *   would do, or why it cannot, is said on each `dragover` that changes the
 *   target, in the hint and the files card's status line (no browser shows a
 *   `title` during a drag). **A refusal outlives the release**: the browser
 *   fires no `drop` where `dropEffect` is `none`, only a `dragleave` (and a
 *   tile's `dragend`), so a drag that ends over a refused target -- the
 *   pointer still in the page -- has its refusal said for a few seconds after
 *   (`refused`), as what was just done is.
 * - **A tile's drag** (`startDrag`): of the selection if the pressed tile is in
 *   it, else of that tile alone -- not chosen for it: a drag changes neither
 *   what is chosen nor what the inspector shows (`draggedPaths`); the drag
 *   image says the count ("3 files"); dropped on a folder, a move -- or, for a
 *   trashed file, a restore there. **A drag of prefab files** carries
 *   `PREFAB_DRAG` as well: over the scene it places one where it is dropped
 *   (`sceneAt`, `placed`), and held over the Entities tool's button it reaches
 *   the tree, where a row takes it as a child (`prefab-drop.ts`). **A drag of
 *   model files** carries `MODEL_DRAG` the same way, and places an entity drawn
 *   as the model; **of material files**, `MATERIAL_DRAG`, worn by the entity
 *   it is dropped on, in the scene or the tree. **Every tile drag carries its
 *   files' kinds** too, a type each (`application/x-vibebase-kind-model`), and
 *   their keys (`asset-drag.ts`): a key field of that kind in the inspector
 *   takes one dropped on it. **The tree's
 *   rows dragged here** (`ENTITIES_DRAG`) onto a folder under `prefabs/` are
 *   saved as a prefab there (`entitiesDropped`, `save-prefab.ts`).
 *
 * `readEntries` and `readList` touch no DOM: node tests them with stand-in
 * entries (`dnd.test.ts`). The rest reaches `window` only when called -- the
 * test hands it a stand-in to judge a drag over the scene.
 */
import { caseKey } from '@vibe/engine/case-key';
import { kindDef, ROOTS, type KindRow } from '@vibe/pipeline/kinds';
import { ignored, keyOf, locate } from '@vibe/pipeline/paths';
import { dragCarries, KEYS_DRAG } from '../../asset-drag.ts';
import { endDrag, startDrag } from '../../drag-record.ts';
import { carriesMaterial, carriesPlaceable, ENTITIES_DRAG, MATERIAL_DRAG, MODEL_DRAG, PREFAB_DRAG } from '../../prefab-drop.ts';

/** What `webkitGetAsEntry()` gives, as this reads it: a file, or a folder whose reader lists it in batches. */
export interface DropEntry {
  readonly isFile: boolean;
  readonly isDirectory: boolean;
  readonly name: string;
  file?(ok: (file: File) => void, fail?: (err: unknown) => void): void;
  createReader?(): { readEntries(ok: (entries: DropEntry[]) => void, fail?: (err: unknown) => void): void };
}

/** A drop read: each file with its path in what was dropped, and the names skipped as the OS's leavings. */
export interface ReadDrop {
  files: Array<{ rel: string; file: File }>;
  skipped: string[];
}

/**
 * A file's key and its kind's key type, as a key field reads a drag of it (`asset-drag.ts`), or null for a file that
 * is no key: the pipeline's own `keyOf` -- the kind's folder stripped, the extension dropped, lowercased -- with
 * `kindDef(...).type`: `src/assets/models/props/parrot.glb` is a `Model`, `props/parrot` -- and a project's own data
 * kind's by `kinds` (the dev server's rows).
 */
export function keyedFile(path: string, kinds: readonly KindRow[] = []): { kind: string; key: string } | null {
  const key = keyOf(path);
  const kind = locate(path)?.kind;
  if (key !== undefined && kind !== undefined) return { kind: kindDef(kind).type, key };
  // A project's own data kind (`vibe({ kinds })`, which the pipeline's table has not): its folder under src/assets,
  // one of its extensions -- `src/assets/tilemaps/demo.tilemap` is a `Tilemap`, `demo`.
  for (const own of kinds) {
    if (!own.project) continue;
    const dir = `${ROOTS.boot.dir}/${own.dir}/`;
    if (!path.startsWith(dir) || ignored(path)) continue;
    const under = path.slice(dir.length);
    const dot = under.lastIndexOf('.');
    if (dot <= 0 || !own.ext.includes(under.slice(dot + 1).toLowerCase()) || under.split('/').some((p) => p.startsWith('_'))) continue;
    return { kind: own.type, key: caseKey(under.slice(0, dot)) };
  }
  return null;
}

/** The type a tile's drag carries: the paths dragged, as JSON. */
export const DRAG_TYPE = 'application/x-vibebase-assets';

/** A file entry made of a `File`: what a browser that gives no entry gives. */
export const fileEntry = (file: File): DropEntry => ({ isFile: true, isDirectory: false, name: file.name, file: (ok) => ok(file) });

/** Every entry of a folder: its reader asked again until it answers nothing. */
function listed(entry: DropEntry): Promise<DropEntry[]> {
  const reader = entry.createReader?.();
  if (!reader) return Promise.resolve([]);
  return new Promise((resolve, reject) => {
    const all: DropEntry[] = [];
    const more = (): void =>
      reader.readEntries((batch) => {
        if (batch.length === 0) return resolve(all);
        all.push(...batch);
        more();
      }, reject);
    more();
  });
}

/** A dropped folder's or file's files, walked: relative paths kept, the leavings skipped and counted. */
export async function readEntries(entries: ReadonlyArray<DropEntry | null>): Promise<ReadDrop> {
  const out: ReadDrop = { files: [], skipped: [] };
  const walk = async (entry: DropEntry, at: string): Promise<void> => {
    const rel = at === '' ? entry.name : `${at}/${entry.name}`;
    if (ignored(entry.name)) {
      out.skipped.push(entry.name);
      return;
    }
    if (entry.isDirectory) {
      for (const kid of await listed(entry)) await walk(kid, rel);
      return;
    }
    if (!entry.isFile || !entry.file) return;
    const file = await new Promise<File>((ok, fail) => entry.file!(ok, fail));
    out.files.push({ rel, file });
  };
  for (const entry of entries) if (entry) await walk(entry, '');
  return out;
}

/** A picker's files: a folder picked keeps its paths (`webkitRelativePath`); the leavings skipped and counted. */
export function readList(list: ArrayLike<File>): ReadDrop {
  const out: ReadDrop = { files: [], skipped: [] };
  for (const file of Array.from(list)) {
    const rel = (file as File & { webkitRelativePath?: string }).webkitRelativePath || file.name;
    const leaving = rel.split('/').find((part) => part !== '' && ignored(part));
    if (leaving !== undefined) out.skipped.push(leaving);
    else out.files.push({ rel, file });
  }
  return out;
}

// ---------------------------------------------------------------- the DOM part

/** A target under the pointer: the folder a drop there is for, and the element lit. */
export interface DropTarget {
  folder: string;
  el: HTMLElement;
}

/** A drag over the scene: what is said, and whether a drop there is taken -- lit, `copy`, the drop let through. */
export interface SceneDrop {
  say: string;
  takes: boolean;
}

export interface DndHost {
  /** The target under this node, or null. */
  targetAt(node: Element | null): DropTarget | null;
  /** Why files from the desktop cannot be imported into `folder`, or null. */
  importRefusal(folder: string): string | null;
  /** Why these paths cannot move into `folder`, or null. */
  moveRefusal(paths: readonly string[], folder: string): string | null;
  /** What a drop there would do: "Import into Source › models", "Move 3 to props". */
  saying(what: 'files' | 'tiles' | 'entities', folder: string, paths: readonly string[]): string;
  /** Why the tree's entities cannot be saved as a prefab in `folder`, or null. */
  entitiesRefusal?(folder: string): string | null;
  /** The tree's entities dropped on `folder`: saved as a prefab there. */
  entitiesDropped?(entities: readonly number[], folder: string): void;
  /** Said while a drag is over a target -- null when it has left: the hint and the status line. */
  say(text: string | null, bad: boolean): void;
  /** A drop refused where it landed -- released over a refused target, or judged refused on `drop` -- said for a while after, as what was just done is. */
  refused(text: string): void;
  /** Files dropped on `folder`: read, then the sheet. */
  dropped(folder: string, read: Promise<ReadDrop>): void;
  /** Tiles dropped on `folder`: a move, or a restore there. */
  moved(paths: readonly string[], folder: string): void;
  /** Are these paths every one a prefab file: a drag of them carries `PREFAB_DRAG` too, which the scene and the tree take. */
  prefabs?(paths: readonly string[]): string[] | null;
  /** Are these paths every one a model file: their keys, carried as `MODEL_DRAG` too -- placed by the scene and the tree as an entity drawn as it. */
  models?(paths: readonly string[]): string[] | null;
  /** Are these paths every one a material file: their keys, carried as `MATERIAL_DRAG` too -- worn by the entity dropped on. */
  materials?(paths: readonly string[]): string[] | null;
  /** The project's kinds as the dev server lists them: a project's own data kind's file is keyed by them (`keyedFile`). */
  kinds?(): readonly KindRow[];
  /**
   * A prefab, model or material drag over no folder: what a drop here does -- "Place crates/big here" -- and whether
   * the scene takes it (a material over no entity: said, but not taken); null where it is not over the scene.
   */
  sceneAt?(event: DragEvent): SceneDrop | null;
  /** Dropped where `sceneAt` said it would place it. */
  placed?(event: DragEvent): void;
  /** The paths a drag of this tile takes: the selection if it is in it, else it alone -- not chosen for it (`draggedPaths`). */
  dragging(path: string): readonly string[];
}

export interface Dnd {
  /** The window's listeners on (the tab up) or off. */
  listen(on: boolean): void;
  /** A tile's `dragstart`: what it carries, and the drag image. */
  start(event: DragEvent, path: string): void;
  dispose(): void;
}

/** What a drag carries, by its types -- readable during `dragover`, unlike its data. */
const carried = (event: DragEvent): 'files' | 'tiles' | 'entities' | null => {
  const types = event.dataTransfer?.types ?? [];
  if (types.includes(DRAG_TYPE)) return 'tiles';
  if (types.includes(ENTITIES_DRAG)) return 'entities';
  if (types.includes('Files')) return 'files';
  return null;
};

export function createDnd(host: DndHost): Dnd {
  /** The tiles this page's drag carries: `dragover` cannot read a drag's data. */
  let tiles: readonly string[] | null = null;
  let lit: HTMLElement | null = null;
  let said: string | null = null;
  /** Why the target last judged refuses the drag, or null: said after a release there, which fires no `drop`. */
  let refusing: string | null = null;

  const light = (target: DropTarget | null, refused: boolean): void => {
    if (lit && lit !== target?.el) lit.classList.remove('ed-as-drop', 'ed-as-drop-no');
    lit = target?.el ?? null;
    if (!lit) return;
    lit.classList.toggle('ed-as-drop', !refused);
    lit.classList.toggle('ed-as-drop-no', refused);
  };
  const clear = (): void => {
    light(null, false);
    if (said !== null) host.say(null, false);
    said = null;
  };
  /** What a drag over here would do, or why not: lit, the drop effect set, said when it changes. */
  const judge = (event: DragEvent): { what: 'files' | 'tiles' | 'entities'; target: DropTarget | null; refusal: string | null } | null => {
    const what = carried(event);
    if (!what) return null;
    if (what === 'entities' && !host.entitiesDropped) return null;
    const target = host.targetAt(event.target instanceof Element ? event.target : null);
    const refusal = !target ? null
      : what === 'files' ? host.importRefusal(target.folder)
      : what === 'entities' ? (host.entitiesRefusal?.(target.folder) ?? null)
      : tiles ? host.moveRefusal(tiles, target.folder) : null;
    return { what, target, refusal };
  };

  const over = (event: DragEvent): void => {
    const judged = judge(event);
    if (!judged) return;
    const { what, target, refusal } = judged;
    // A prefab or a model over the scene: placed there on the drop; a material, worn by the entity under it. One the
    // scene does not take -- a material over no entity -- is said, but neither let through nor `copy`: the browser
    // fires no drop there, as the scene's own listener (`overScene`) says too, and the release says why.
    const scene = !target && (carriesPlaceable(event) || carriesMaterial(event)) ? (host.sceneAt?.(event) ?? null) : null;
    if (scene !== null) {
      if (scene.takes) event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = scene.takes ? 'copy' : 'none';
      light(null, false);
      refusing = scene.takes ? null : scene.say;
      if (scene.say !== said) {
        said = scene.say;
        host.say(scene.say, !scene.takes);
      }
      return;
    }
    // Anywhere else: no file opened in the tab, no tile dropped as text.
    event.preventDefault();
    const ok = target !== null && refusal === null;
    if (event.dataTransfer) event.dataTransfer.dropEffect = ok ? (what === 'tiles' ? 'move' : 'copy') : 'none';
    light(target, !ok);
    refusing = target ? refusal : null;
    const text = !target ? null : refusal ?? host.saying(what, target.folder, tiles ?? []);
    if (text !== said) {
      said = text;
      host.say(text, refusal !== null);
    }
  };

  const drop = (event: DragEvent): void => {
    const judged = judge(event);
    if (!judged) return;
    event.preventDefault();
    const { what, target, refusal } = judged;
    refusing = null;
    clear();
    if (!target && (carriesPlaceable(event) || carriesMaterial(event)) && host.sceneAt?.(event)?.takes) return host.placed?.(event);
    if (!target) return;
    if (refusal !== null) return host.refused(refusal);
    if (what === 'entities') {
      let entities: unknown;
      try {
        entities = JSON.parse(event.dataTransfer?.getData(ENTITIES_DRAG) || '[]');
      } catch {
        entities = [];
      }
      if (Array.isArray(entities) && entities.every((e) => typeof e === 'number') && entities.length > 0) host.entitiesDropped?.(entities as number[], target.folder);
      return;
    }
    if (what === 'tiles') {
      let paths: readonly string[] = tiles ?? [];
      if (paths.length === 0) {
        try {
          paths = JSON.parse(event.dataTransfer?.getData(DRAG_TYPE) || '[]') as string[];
        } catch {
          paths = [];
        }
        // From another tab: judged now, its paths readable at last.
        const no = host.moveRefusal(paths, target.folder);
        if (no !== null) return host.refused(no);
      }
      if (paths.length > 0) host.moved(paths, target.folder);
      return;
    }
    // The entries now, inside the event: the items are gone once it returns.
    const items = Array.from(event.dataTransfer?.items ?? []).filter((item) => item.kind === 'file');
    const entries = items.map((item) => {
      const entry = (item as DataTransferItem & { webkitGetAsEntry?(): DropEntry | null }).webkitGetAsEntry?.() ?? null;
      if (entry) return entry;
      const file = item.getAsFile();
      return file ? fileEntry(file) : null;
    });
    host.dropped(target.folder, readEntries(entries));
  };

  /** The drag ended over a refused target, the pointer still in the page: why, said for a while after -- once. */
  const sayRefused = (event: DragEvent): void => {
    const why = refusing;
    refusing = null;
    clear();
    const inside = event.clientX > 0 && event.clientY > 0 && event.clientX < innerWidth && event.clientY < innerHeight;
    if (why !== null && inside) host.refused(why);
  };
  const leave = (event: DragEvent): void => {
    // Into nothing: out of the window, or released where the drop is refused -- the browser's one word for it.
    if (event.relatedTarget === null && carried(event)) sayRefused(event);
  };
  const ended = (event: DragEvent): void => {
    tiles = null;
    endDrag();
    sayRefused(event);
  };

  let on = false;
  const listen = (next: boolean): void => {
    if (next === on) return;
    on = next;
    const method = on ? 'addEventListener' : 'removeEventListener';
    window[method]('dragover', over as EventListener, true);
    window[method]('drop', drop as EventListener, true);
    window[method]('dragleave', leave as EventListener, true);
    window[method]('dragend', ended as EventListener, true);
    if (!on) {
      tiles = null;
      refusing = null;
      clear();
    }
  };
  return {
    listen,
    start(event, path) {
      const paths = host.dragging(path);
      tiles = paths;
      const data = event.dataTransfer;
      if (!data) return;
      const prefabs = host.prefabs?.(paths) ?? null;
      const models = prefabs ? null : (host.models?.(paths) ?? null);
      const materials = prefabs || models ? null : (host.materials?.(paths) ?? null);
      // Their kinds and keys: what a key field in the inspector takes (`asset-drag.ts`).
      const kinds = host.kinds?.() ?? [];
      const files = paths.map((p) => keyedFile(p, kinds));
      // A prefab or a model may be placed, a material worn, an asset of any kind set on a key field (a copy), as well as
      // moved: a drop whose effect is not allowed never fires.
      data.effectAllowed = prefabs || models || materials || files.some((f) => f !== null) ? 'copyMove' : 'move';
      data.setData(DRAG_TYPE, JSON.stringify(paths));
      if (prefabs) data.setData(PREFAB_DRAG, JSON.stringify(prefabs));
      if (models) data.setData(MODEL_DRAG, JSON.stringify(models));
      if (materials) data.setData(MATERIAL_DRAG, JSON.stringify(materials));
      // Their kinds, a type each, and their keys, as data.
      const keyed = dragCarries(files);
      // Known while the drag is under way, in the page: what every key and ref field lights or dims for (`drag-record.ts`).
      startDrag({ what: 'assets', files });
      for (const type of keyed.types) data.setData(type, '1');
      data.setData(KEYS_DRAG, JSON.stringify(keyed.keys));
      data.setData('text/plain', paths.join('\n'));
      // The count, as the drag image: "3 files".
      const image = document.createElement('div');
      image.className = 'ed-as-drag';
      image.textContent = paths.length === 1 ? (paths[0]!.split('/').pop() ?? '') : `${paths.length} files`;
      document.body.append(image);
      data.setDragImage(image, -12, -12);
      requestAnimationFrame(() => image.remove());
    },
    dispose: () => listen(false),
  };
}
