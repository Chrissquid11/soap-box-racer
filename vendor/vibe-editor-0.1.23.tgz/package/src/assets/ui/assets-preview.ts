/**
 * The inspector's preview (Docs/assets-tool.md §6.2, §9, §12): what the game
 * will see of the chosen file, by `PREVIEWS` -- the row for the extension of
 * what is shown, else its kind's, else the fallback (`previewFor`).
 *
 * - **What is shown** is part one's rule (`previewPath`): a source's export
 *   when the source is `current`, else the file itself; a file in the trash by
 *   the path it had. An LFS pointer is never read: its row says what it is.
 * - **A model** (`.glb`, `.gltf`, a source three loads): the one preview
 *   renderer's canvas placed in the block, the scene decoded through the
 *   scratch store -- the game's loaders on the shipping side, a format's
 *   previewer on the Source side. Orbit by drag, zoom by the wheel (the
 *   renderer's own); Frame (`F`); Wireframe, Skeleton and Backfaces, kept with
 *   the preferences; the clips as segments up to four, a list past that;
 *   play and pause (Space), a scrubber, the time, ×0.5 · 1 · 2, loop; the
 *   triangles and draw calls in a corner. Its 256 thumbnail is made from this
 *   decode, once a hash (`wants`).
 * - **A texture**: an image the browser decodes as a DOM image on a
 *   checkerboard; a KTX2 through the scratch store on the renderer's quad, with
 *   its GPU format and mips. Zoom by the wheel (`preventDefault`ed: the panel
 *   does not scroll), pan by drag; 1:1 and Fit (`F`); the channels R, G, B, A;
 *   the size, and which side is no power of two.
 * - **An atlas**: its sheet with every frame outlined, its frames' names --
 *   each lit on hover, cropped to on a click.
 * - **A sound** (`waveform.ts`): its peaks, decoded offline; play and stop
 *   (Space), the cursor read from the player's `at` each frame while it plays;
 *   loop; a volume for the preview alone; duration, channels, rate; and why it
 *   is not heard -- muted in the game's settings, or before the tab's first
 *   click. Through `Audio.preview`, so the game's mute decides.
 * - **A font**: a `FontFace` from a blob URL, in `document.fonts` while shown:
 *   an editable line at three sizes. **An icon, an SVG**: at 24, 48 and 96, on
 *   light and on dark. **Text, a level, JSON**: read-only, with its size.
 * - **A prefab** (by its kind: a `.prefab` under `prefabs/`): its views as its file places
 *   them, turning, on the model's stage (`prefabPreview`).
 * - **A material** (a `.material` under `materials/`): a sphere wearing the game's own
 *   shared material, turning, on the same stage (`materialPreview`) -- a live change
 *   to the file shows on it at once; one remade for a new type is shown anew.
 * - **A source no browser previews** (`.lua`, `.blend`, `.psd`): its export when
 *   current; else the server's thumbnail at 256; else the format's icon and the
 *   line. **Anything else**: an image the browser decodes as a texture; else the
 *   icon and the line.
 * - **One at a time**: the block shows one file; another, or none, disposes
 *   the last -- its decode, its sound stopped, its font taken out, the canvas
 *   out of the page. The same file unchanged is left as it is, however often
 *   the inspector is drawn again.
 * - **The thumbnail queue holds still** while a clip or a sound plays, or the
 *   view is dragged (`hold`): the GPU and the frame are the preview's then.
 *
 * Nothing here holds a three.js object of its own: the renderer, the scratch
 * store and the sound player are the tool's, handed in. `previewFor` and the
 * small sums (`channelMatrix`, `atlasFrames`, `powerLine`) are pure, and the
 * file touches the DOM only when a row is made, so node imports it
 * (`assets-preview.test.ts`).
 */
import * as THREE from 'three';
import type { Entry, FileStats, AudioStats } from '@vibe/pipeline/assets-types';
import { SOUND_MASTERS, KINDS, type KindName } from '@vibe/pipeline/kinds';
import { baseName, dirName, extOf, fromTrash, joinPath, locate, splitName } from '@vibe/pipeline/paths';
import { button, control, el, icon, iconButton } from '../../dom.ts';
import { keepPref, loadPrefs, PREVIEW_HEIGHT, PREVIEW_MAX, PREVIEW_MIN, type AssetsPrefs, type WheelMode } from '../../prefs.ts';
import { GESTURE, wheelDevice, wheelDrag, type WheelLast } from '../../wheel.ts';
import type { Api } from '../api.ts';
import type { Shown } from '../model.ts';
import { decodeSound, NOTE_WORDS, peaks, type Peaks, type SoundPlayer } from '../preview/audio.ts';
import { fitScale, type PreviewRenderer } from '../preview/renderer.ts';
import { pinchZoom as zoomScale } from '../../view/navigation.ts';
import { previewPath, type ScratchStore } from '../preview/scratch.ts';
import { thumbWantOf, type Thumbs, type ThumbWant } from '../preview/thumbs.ts';
import { sayBytes } from './budget.ts';
import { isEntry } from './marks.ts';
import { parseMarkdown, renderMarkdown, SAFE_LINKS } from '../../markdown.ts';
import { cursorX, drawWave, timeAt } from './waveform.ts';
import { compiledPrefab, materialIfPresent, materialsStamp } from '@vibe/engine';
import { materialKeyOf } from './material-steps.ts';
import { prefabLook } from '../../prefab-views.ts';
import { prefabKeyOf } from './prefab-steps.ts';
import { livePrefabs } from '../../prefabs-live.ts';

// ---------------------------------------------------------------- the table

/** What a row is handed: the file, what is shown of it, and the tool's one renderer, decode, player and queue. */
export interface PreviewContext {
  /** The file chosen: an index entry, or under the Trash root a trashed file. */
  readonly entry: Shown;
  /** What is shown of it: a current source's export, else itself (`previewPath`). */
  readonly path: string;
  /** What is shown's extension and kind, by the path it had if it is in the trash. */
  readonly ext: string;
  readonly kind: KindName | undefined;
  /** Its bytes, as the index has them. */
  readonly size: number;
  readonly api: Pick<Api, 'file' | 'fileUrl'>;
  /** The one preview renderer: made the first time a row asks for it. */
  renderer(): PreviewRenderer;
  /** The one decode open at a time: the one before disposed as the next lands. */
  readonly scratch: ScratchStore;
  /** Sounds through the game's mixer, one at a time. */
  readonly sound: SoundPlayer;
  /** The thumbnails, for a picture the server made (a `.psd`'s). */
  readonly thumbs: Pick<Thumbs, 'url' | 'known' | 'onReady'>;
  /** The index's entry at a path: an atlas's `.json` beside its sheet, a hash. */
  entryAt(path: string): Entry | undefined;
  /** What `GET stats` read of what is shown, once it has: a sound's rate. Told at most once. */
  stats(then: (stats: FileStats) => void): void;
  /** The preview's preferences: wireframe, skeleton, backfaces, loop, volume. */
  prefs(): AssetsPrefs['preview'];
  keep(change: Partial<AssetsPrefs['preview']>): void;
  /** The thumbnail queue held while something plays or the view is dragged. */
  hold(why: 'play' | 'drag', on: boolean): void;
  /** What plays or frames, or whether it plays, changed: the keys and the hint read again. */
  changed(): void;
  /** Text on the clipboard, said on the hint. */
  copy(text: string, what: string): void;
  /** One of the editor's colour tokens (`--as-wave`): what a canvas is drawn in. */
  colour(token: string): string;
}

/** What a row made: its element, and what Space, F and Esc do with it. */
export interface PreviewShown {
  readonly root: HTMLElement;
  /** Space: play or pause -- a sound, stop -- what plays. Absent on a still. */
  play?(): void;
  /** Is there something to play just now -- a clip, a decoded sound: the hint says Space. Always, if absent and `play` is there. */
  plays?(): boolean;
  /** F: frame the model, fit the texture. */
  frame?(): void;
  /** Is it playing: Esc stops it first. */
  playing?(): boolean;
  /** Space pauses it where it is (a clip), rather than stopping it (a sound): what the hint says. */
  pauses?: boolean;
  /** Stop what plays: Esc. */
  stop?(): void;
  /** Thumbnails to make before the folder's: the model shown, at 256, from this decode. */
  wants?(): ThumbWant[];
  /** Everything it holds let go: its decode, its sound, its font, its listeners. */
  dispose(): void;
}

/** A row of `PREVIEWS`: how a file is previewed. A game adds one by extension or kind (§12). */
export interface PreviewRow {
  make(entry: Shown, ctx: PreviewContext): PreviewShown;
}

/** Images the browser decodes itself: shown as they are. */
const BROWSER_IMAGES: readonly string[] = ['png', 'jpg', 'jpeg', 'webp', 'avif', 'gif', 'bmp'];

/** What a file's picture is of, and by what name: the shown path, its extension and kind by the path it had. */
export function shownOf(entry: Shown): { path: string; ext: string; kind: KindName | undefined } {
  const path = isEntry(entry) ? previewPath(entry) : entry.path;
  const had = fromTrash(path)?.path ?? path;
  return { path, ext: extOf(had), kind: locate(had)?.kind };
}

/**
 * The row that previews `entry` (§6.2): an LFS pointer's, never read; else the
 * row for the extension of what is shown (a current source's export: a `.lua`
 * its `.glb`'s), else its kind's (a `.png` under `sprites/` an atlas, under
 * `icons/` an icon), else the fallback (`*`).
 */
export function previewFor(entry: Shown, table: Readonly<Record<string, PreviewRow>> = PREVIEWS): PreviewRow {
  if (isEntry(entry) && entry.pointer && table.pointer) return table.pointer;
  const { ext, kind } = shownOf(entry);
  // A prefab, found by its extension (`.prefab`, JSON inside): its views, turning. A stray `.json` under prefabs/ is plain JSON.
  if (kind === 'prefabs' && ext === KINDS.prefabs.ext[0] && table.prefabs) return table.prefabs;
  // A material the same: a sphere wearing it. A stray `.json` under materials/ is plain JSON.
  if (kind === 'materials' && ext === KINDS.materials.ext[0] && table.materials) return table.materials;
  return table[ext] ?? (kind !== undefined ? table[kind] : undefined) ?? table['*'] ?? PREVIEW_ROWS.other;
}

// ---------------------------------------------------------------- small sums, pure

/**
 * The colour matrix (`feColorMatrix`'s twenty numbers) that shows `on`'s
 * channels: all four, null -- the image as it is; one alone, that channel as
 * grey, opaque; else the channels off black, and with alpha off, opaque.
 */
export function channelMatrix(on: { r: boolean; g: boolean; b: boolean; a: boolean }): number[] | null {
  const { r, g, b, a } = on;
  if (r && g && b && a) return null;
  const lit = [r, g, b, a].filter(Boolean).length;
  if (lit === 1) {
    const c = [r, g, b, a].indexOf(true);
    const row = [0, 0, 0, 0, 0];
    row[c] = 1;
    return [...row, ...row, ...row, 0, 0, 0, 0, 1];
  }
  return [
    r ? 1 : 0, 0, 0, 0, 0,
    0, g ? 1 : 0, 0, 0, 0,
    0, 0, b ? 1 : 0, 0, 0,
    0, 0, 0, a ? 1 : 0, a ? 0 : 1,
  ];
}

/** One frame of an atlas, in the sheet's pixels from its top left. */
export interface AtlasFrame {
  name: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

/**
 * The frames a packer's `.json` names -- TexturePacker's hash or array, as the
 * game's `Atlas` reads them: the name without the extension the packer kept --
 * and the sheet's size if it says.
 */
export function atlasFrames(json: unknown): { frames: AtlasFrame[]; size?: { w: number; h: number } } {
  const raw = (json ?? {}) as { frames?: unknown; meta?: { size?: { w?: unknown; h?: unknown } } };
  const list: Array<[string, unknown]> = Array.isArray(raw.frames)
    ? raw.frames.map((f) => [String((f as { filename?: unknown })?.filename ?? ''), f])
    : Object.entries((raw.frames ?? {}) as Record<string, unknown>);
  const frames: AtlasFrame[] = [];
  for (const [name, item] of list) {
    const f = (item as { frame?: { x?: unknown; y?: unknown; w?: unknown; h?: unknown } } | null)?.frame;
    if (!f || typeof f.x !== 'number' || typeof f.y !== 'number' || typeof f.w !== 'number' || typeof f.h !== 'number') continue;
    frames.push({ name: name.replace(/\.[^.]+$/, ''), x: f.x, y: f.y, w: f.w, h: f.h });
  }
  const w = raw.meta?.size?.w;
  const h = raw.meta?.size?.h;
  return typeof w === 'number' && typeof h === 'number' ? { frames, size: { w, h } } : { frames };
}

const isPow2 = (v: number): boolean => v > 0 && (v & (v - 1)) === 0;

/** A texture's size, and which side is no power of two: "1024 × 512 · both sides powers of two". */
export function powerLine(width: number, height: number): string {
  const off = [...new Set([width, height].filter((v) => !isPow2(v)))];
  return `${width} × ${height} px · ${off.length === 0 ? 'both sides powers of two' : `${off.join(' and ')} ${off.length === 1 ? 'is' : 'are'} no power of two`}`;
}

/** Seconds as the preview says them: `0.42`. */
const secs = (t: number): string => t.toFixed(2);

// ---------------------------------------------------------------- parts the rows share

/** A toggle: a small button, pressed or not. */
function toggle(text: string, title: string, on: boolean, flip: (on: boolean) => void): HTMLButtonElement {
  const b = button('ui', text, title, () => {
    const now = b.getAttribute('aria-pressed') !== 'true';
    b.setAttribute('aria-pressed', String(now));
    flip(now);
  }, 'ed-small ed-as-toggle');
  b.setAttribute('aria-pressed', String(on));
  return b;
}

/** Segments, one pressed: `ed-segments`, as the files card's sizes. */
function segments<T extends string | number>(values: readonly T[], label: (v: T) => string, title: (v: T) => string, now: T, choose: (v: T) => void): { root: HTMLElement; set(v: T): void } {
  const root = el('span', 'ed-segments');
  const buttons = values.map((v) => {
    const b = control('ui', 'ed-segment', label(v));
    b.title = title(v);
    b.addEventListener('click', () => {
      set(v);
      choose(v);
    });
    root.append(b);
    return { v, b };
  });
  const set = (v: T): void => {
    for (const { v: w, b } of buttons) b.setAttribute('aria-pressed', String(w === v));
  };
  set(now);
  return { root, set };
}

/** A line of the preview's: dim, or red for what went wrong. */
const line = (text: string, cls = 'ed-dim'): HTMLElement => el('div', `ed-as-pv-line ${cls}`, text);

/** The format's icon and its extension, large: what a file shows with nothing better. */
function formatIcon(ext: string, pointer = false): HTMLElement {
  const box = el('div', 'ed-as-pv-icon');
  box.append(icon('file'), el('span', 'ed-as-ext', ext.toUpperCase() || '?'));
  if (pointer) box.append(el('span', 'ed-as-mark ed-as-corner ed-as-red', '⤓'));
  return box;
}

/** A thumbnail of `entry` wanted at `size`, as its tile wants it (`thumbWantOf`): a current source's by its export's stamp. */
const wantOf = (entry: Shown, size: number, ctx: Pick<PreviewContext, 'entryAt'>): ThumbWant[] => {
  const want = thumbWantOf(entry, size, isEntry(entry) ? previewPath(entry) : entry.path, (p) => ctx.entryAt(p));
  return want ? [want] : [];
};

/** Why a read failed, in a line. */
const why = (err: unknown): string => (err instanceof Error ? err.message : String(err));

/** The preview's own frame clock: a callback each animation frame until it answers false. */
function everyFrame(fn: () => boolean): () => void {
  let raf = 0;
  const go = (): void => {
    raf = fn() ? requestAnimationFrame(go) : 0;
  };
  raf = requestAnimationFrame(go);
  return () => {
    if (raf !== 0) cancelAnimationFrame(raf);
    raf = 0;
  };
}

/** The stage: where the renderer's canvas is placed, with what is said over it in a corner. */
function stage(ctx: PreviewContext, checker = false): { root: HTMLElement; info: HTMLElement; note: HTMLElement; holdOnDrag(): () => void } {
  // A texture's alpha shows against a checkerboard; a model stands on its grid.
  const root = el('div', checker ? 'ed-as-stage ed-as-checker' : 'ed-as-stage');
  const info = el('div', 'ed-as-pv-info');
  const note = el('div', 'ed-as-pv-note', 'decoding…');
  root.append(info, note, stageGrip(root));
  root.style.height = `${loadPrefs().assets.preview.height}px`;
  return {
    root,
    info,
    note,
    // The thumbnail queue held while the view is dragged: the canvas captures the pointer, so its release comes here too.
    holdOnDrag() {
      const down = (): void => ctx.hold('drag', true);
      const up = (): void => ctx.hold('drag', false);
      root.addEventListener('pointerdown', down);
      root.addEventListener('pointerup', up);
      root.addEventListener('pointercancel', up);
      root.addEventListener('lostpointercapture', up);
      return () => {
        root.removeEventListener('pointerdown', down);
        root.removeEventListener('pointerup', up);
        root.removeEventListener('pointercancel', up);
        root.removeEventListener('lostpointercapture', up);
        up();
      };
    },
  };
}

/** A height for the stage, held to its bounds. */
const stageHeight = (h: number): number => Math.round(Math.max(PREVIEW_MIN, Math.min(PREVIEW_MAX, h)));

/**
 * The stage's bottom edge, to drag: taller or shorter, kept with the
 * preferences (`preview.height`), a double-click back to its usual height.
 * The renderer follows the canvas through its own `ResizeObserver`; a picture
 * fits itself again. Pointer capture, as the strip's grip.
 */
function stageGrip(stage: HTMLElement): HTMLElement {
  const grip = el('div', 'ed-as-stage-grip');
  grip.title = `Drag to make the preview taller or shorter; double-click for ${PREVIEW_HEIGHT} px`;
  let pull: { id: number; y: number; from: number; now: number } | null = null;
  const keep = (height: number): void => {
    const assets = loadPrefs().assets;
    keepPref('assets', { ...assets, preview: { ...assets.preview, height } });
  };
  grip.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    pull = { id: event.pointerId, y: event.clientY, from: stage.getBoundingClientRect().height, now: stage.getBoundingClientRect().height };
    grip.setPointerCapture(event.pointerId);
    grip.classList.add('ed-dragging');
  });
  grip.addEventListener('pointermove', (event) => {
    if (!pull || pull.id !== event.pointerId) return;
    pull.now = stageHeight(pull.from + (event.clientY - pull.y));
    stage.style.height = `${pull.now}px`;
  });
  const letGo = (event: PointerEvent): void => {
    if (!pull || pull.id !== event.pointerId) return;
    const kept = pull.now;
    pull = null;
    grip.classList.remove('ed-dragging');
    if (grip.hasPointerCapture(event.pointerId)) grip.releasePointerCapture(event.pointerId);
    keep(kept);
  };
  grip.addEventListener('pointerup', letGo);
  grip.addEventListener('pointercancel', letGo);
  // mcp: ui -- the preview's height put back
  grip.addEventListener('dblclick', (event) => {
    event.stopPropagation();
    stage.style.height = `${PREVIEW_HEIGHT}px`;
    keep(PREVIEW_HEIGHT);
  });
  return grip;
}

/** The channel toggles, R G B A: told the matrix to show. */
/** The channels shown: red, green, blue, alpha. */
export type Channels = { r: boolean; g: boolean; b: boolean; a: boolean };

/**
 * The channels after a click on `c`, as Photoshop's and Substance's: alone (a
 * click on the one alone, all four again); with Shift, on or off beside the
 * rest -- never none, the last one on staying.
 */
export function channelsAfter(on: Readonly<Channels>, c: keyof Channels, add: boolean): Channels {
  const all = { r: true, g: true, b: true, a: true };
  if (!add) {
    const alone = on[c] && Object.values(on).filter(Boolean).length === 1;
    return alone ? all : { r: c === 'r', g: c === 'g', b: c === 'b', a: c === 'a' };
  }
  const next = { ...on, [c]: !on[c] };
  return next.r || next.g || next.b || next.a ? next : { ...on };
}

function channelToggles(show: (matrix: number[] | null) => void): HTMLElement {
  let on: Channels = { r: true, g: true, b: true, a: true };
  const root = el('span', 'ed-segments ed-as-channels');
  root.title = 'Channels: a click shows one alone, as grey -- again, all four; Shift+click adds or takes one away';
  const buttons = new Map<keyof Channels, HTMLButtonElement>();
  for (const c of ['r', 'g', 'b', 'a'] as const) {
    const b = control('ui', 'ed-segment', c.toUpperCase());
    b.title = `The ${({ r: 'red', g: 'green', b: 'blue', a: 'alpha' })[c]} channel alone (again: all four); Shift+click, on or off beside the rest`;
    b.setAttribute('aria-pressed', 'true');
    b.addEventListener('click', (event) => {
      on = channelsAfter(on, c, event.shiftKey);
      for (const [k, button] of buttons) button.setAttribute('aria-pressed', String(on[k]));
      show(channelMatrix(on));
    });
    buttons.set(c, b);
    root.append(b);
  }
  return root;
}

/**
 * Zoom and pan of a DOM picture in `view` -- `layer` moved by a transform,
 * its natural size `size`d -- as the renderer's quad: the wheel through
 * `wheel.ts` (a pinch zooms round the pointer, two fingers or Shift pan, a
 * mouse wheel zooms), `preventDefault`ed; a drag pans; fitted again on a
 * resize until someone moves it.
 */
interface PanZoom {
  size(width: number, height: number): void;
  fit(): void;
  actual(): void;
  /** A rectangle of the picture fitted: an atlas's frame. */
  to(rect: { x: number; y: number; w: number; h: number }): void;
  readonly scale: number;
  dispose(): void;
}

function panZoom(ctx: PreviewContext, view: HTMLElement, layer: HTMLElement, moved: () => void): PanZoom {
  let w = 0;
  let h = 0;
  let s = 1;
  let x = 0;
  let y = 0;
  let untouched = true;
  let wheelLast: WheelLast | null = null;
  let mode: WheelMode = loadPrefs().wheel;
  const place = (): void => {
    layer.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
    // What draws over the picture -- an atlas's outlines -- keeps its lines a pixel wide at any zoom.
    layer.style.setProperty('--as-zoom', String(s));
    layer.classList.toggle('ed-as-pixels', s >= 2);
    moved();
  };
  const fitTo = (rx: number, ry: number, rw: number, rh: number): void => {
    const vw = view.clientWidth;
    const vh = view.clientHeight;
    if (vw === 0 || vh === 0 || rw <= 0 || rh <= 0) return;
    s = fitScale(rw, rh, vw, vh);
    x = vw / 2 - (rx + rw / 2) * s;
    y = vh / 2 - (ry + rh / 2) * s;
    place();
  };
  const onWheel = (e: WheelEvent): void => {
    e.preventDefault();
    if (w === 0) return;
    if (!wheelLast || e.timeStamp - wheelLast.at > GESTURE) mode = loadPrefs().wheel;
    const device = wheelDevice(e, mode, wheelLast);
    wheelLast = { device, at: e.timeStamp };
    untouched = false;
    // A flat picture, not a 3D view: a pinch or Ctrl zooms, as a mouse's wheel does; two fingers or Shift pan.
    if (e.ctrlKey || (!e.shiftKey && device === 'mouse')) {
      const box = view.getBoundingClientRect();
      const px = e.clientX - box.left;
      const py = e.clientY - box.top;
      const next = THREE.MathUtils.clamp(s / zoomScale(e), 1 / 64, 64);
      // The texel under the pointer stays under it.
      x = px - ((px - x) * next) / s;
      y = py - ((py - y) * next) / s;
      s = next;
    } else {
      const { dx, dy } = wheelDrag(e);
      x += dx;
      y += dy;
    }
    place();
  };
  let pointer: { id: number; x: number; y: number } | null = null;
  const onDown = (e: PointerEvent): void => {
    if (e.button !== 0 || w === 0) return;
    e.preventDefault();
    view.setPointerCapture(e.pointerId);
    pointer = { id: e.pointerId, x: e.clientX, y: e.clientY };
    ctx.hold('drag', true);
  };
  const onMove = (e: PointerEvent): void => {
    if (!pointer || e.pointerId !== pointer.id) return;
    untouched = false;
    x += e.clientX - pointer.x;
    y += e.clientY - pointer.y;
    pointer.x = e.clientX;
    pointer.y = e.clientY;
    place();
  };
  const onUp = (e: PointerEvent): void => {
    if (!pointer || e.pointerId !== pointer.id) return;
    pointer = null;
    ctx.hold('drag', false);
  };
  view.addEventListener('wheel', onWheel, { passive: false });
  view.addEventListener('pointerdown', onDown);
  view.addEventListener('pointermove', onMove);
  view.addEventListener('pointerup', onUp);
  view.addEventListener('pointercancel', onUp);
  const resized = new ResizeObserver(() => {
    if (untouched) fitTo(0, 0, w, h);
  });
  resized.observe(view);
  return {
    size(width, height) {
      w = width;
      h = height;
      layer.style.width = `${w}px`;
      layer.style.height = `${h}px`;
      untouched = true;
      fitTo(0, 0, w, h);
    },
    fit() {
      untouched = true;
      fitTo(0, 0, w, h);
    },
    actual() {
      untouched = false;
      s = 1;
      x = (view.clientWidth - w) / 2;
      y = (view.clientHeight - h) / 2;
      place();
    },
    to(rect) {
      untouched = false;
      fitTo(rect.x, rect.y, rect.w, rect.h);
    },
    get scale() {
      return s;
    },
    dispose() {
      resized.disconnect();
      view.removeEventListener('wheel', onWheel);
      view.removeEventListener('pointerdown', onDown);
      view.removeEventListener('pointermove', onMove);
      view.removeEventListener('pointerup', onUp);
      view.removeEventListener('pointercancel', onUp);
      if (pointer) ctx.hold('drag', false);
    },
  };
}

let filters = 0;

/** An SVG colour-matrix filter for a DOM picture's channels: in the block, never seen itself. */
function channelFilter(): { svg: SVGSVGElement; apply(target: HTMLElement, matrix: number[] | null): void } {
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'ed-as-filter');
  svg.setAttribute('width', '0');
  svg.setAttribute('height', '0');
  const filter = document.createElementNS(NS, 'filter');
  const id = `ed-as-channels-${++filters}`;
  filter.setAttribute('id', id);
  // In the image's own sRGB, not linear light: one channel alone is the grey its values are.
  filter.setAttribute('color-interpolation-filters', 'sRGB');
  const matrix = document.createElementNS(NS, 'feColorMatrix');
  matrix.setAttribute('type', 'matrix');
  filter.append(matrix);
  svg.append(filter);
  return {
    svg,
    apply(target, m) {
      if (m) matrix.setAttribute('values', m.join(' '));
      target.style.filter = m ? `url(#${id})` : '';
    },
  };
}

// ---------------------------------------------------------------- the rows

/** A model: the renderer's canvas in the block, the controls over its interface. */
function modelPreview(entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-model');
  const view = stage(ctx);
  const tools = el('div', 'ed-as-pv-tools');
  const clipsRow = el('div', 'ed-as-pv-tools ed-as-pv-clips');
  clipsRow.hidden = true;
  root.append(view.root, tools, clipsRow);
  const renderer = ctx.renderer();
  renderer.mount(view.root);
  const unhold = view.holdOnDrag();
  let disposed = false;
  let ready = false;
  let clip: string | null = null;
  let speed = 1;
  const prefs = ctx.prefs();
  renderer.setWireframe(prefs.wireframe);
  renderer.setSkeleton(prefs.skeleton);
  renderer.setBackfaces(prefs.backfaces);

  tools.append(
    button('ui', 'Frame', 'The model framed again (F)', () => renderer.frame(), 'ed-small'),
    toggle('Wireframe', 'Its triangles as lines -- counted the same', prefs.wireframe, (on) => {
      renderer.setWireframe(on);
      ctx.keep({ wireframe: on });
    }),
    toggle('Skeleton', 'Its bones drawn over it, if it has any', prefs.skeleton, (on) => {
      renderer.setSkeleton(on);
      ctx.keep({ skeleton: on });
    }),
    toggle('Backfaces', 'Both sides of every face drawn: a face the wrong way round shows', prefs.backfaces, (on) => {
      renderer.setBackfaces(on);
      ctx.keep({ backfaces: on });
    }),
  );

  // The clips: play and pause, which, where, how fast, round and round.
  const playButton = iconButton('ui', 'play', 'Play the clip (Space)', () => play());
  const scrub = el('input', 'ed-as-scrub');
  scrub.type = 'range';
  scrub.min = '0';
  scrub.step = 'any';
  scrub.title = 'Where in the clip: drag to scrub';
  // Let go once a pointer used it -- the tool's rule for every control (§8) -- and kept by the keys, which step it.
  scrub.addEventListener('input', () => renderer.seek(Number(scrub.value)));
  const time = el('span', 'ed-as-pv-time', '0.00 / 0.00 s');
  const speeds = segments([0.5, 1, 2] as const, (v) => `×${v}`, (v) => `Played at ×${v}`, 1, (v) => {
    speed = v;
    if (renderer.playing) renderer.play(clip, { speed, loop: ctx.prefs().loop });
  });
  const loop = toggle('Loop', 'Round and round; off, once and held at its end', prefs.loop, (on) => {
    ctx.keep({ loop: on });
    if (renderer.playing) renderer.play(clip, { speed, loop: on });
  });
  const which = el('span', 'ed-as-pv-which');

  const choose = (name: string): void => {
    const was = renderer.playing;
    clip = name;
    if (was) renderer.play(name, { speed, loop: ctx.prefs().loop });
    else {
      // The clip made the one shown, paused at its start.
      renderer.play(name, { speed, loop: ctx.prefs().loop });
      renderer.play(null);
      renderer.seek(0);
    }
    drawTime();
  };

  function drawClips(names: readonly string[]): void {
    which.replaceChildren();
    if (names.length === 0) return;
    clip = names[0]!;
    if (names.length <= 4) {
      which.append(segments(names, (n) => n || 'unnamed', (n) => `The clip ${n || 'unnamed'}`, clip, choose).root);
    } else {
      const list = el('select', 'ed-input ed-as-pv-select');
      list.title = `${names.length} clips: choose one`;
      for (const n of names) {
        const option = el('option', undefined, n || 'unnamed');
        option.value = n;
        list.append(option);
      }
      list.addEventListener('change', () => choose(list.value));
      which.append(list);
    }
    clipsRow.append(playButton, which, scrub, time, speeds.root, loop);
    clipsRow.hidden = false;
  }

  function drawTime(): void {
    const d = renderer.duration;
    scrub.max = String(d || 1);
    if (document.activeElement !== scrub) scrub.value = String(renderer.time);
    const said = `${secs(renderer.time)} / ${secs(d)} s`;
    if (time.textContent !== said) time.textContent = said;
  }

  let wasPlaying = false;
  const off = renderer.on('frame', () => {
    if (disposed) return;
    const info = renderer.info();
    const said = `${info.triangles.toLocaleString('en')} triangles · ${info.calls} ${info.calls === 1 ? 'draw call' : 'draw calls'}`;
    if (view.info.textContent !== said) view.info.textContent = said;
    if (clip !== null) drawTime();
    const playing = renderer.playing;
    if (playing !== wasPlaying) {
      // Play or pause on the button, the queue held or let go, the hint read again: as it starts or stops, not each frame.
      wasPlaying = playing;
      playButton.replaceChildren(icon(playing ? 'pause' : 'play'));
      playButton.title = playing ? 'Pause the clip (Space)' : 'Play the clip (Space)';
      ctx.hold('play', playing);
      ctx.changed();
    }
  });

  void ctx.scratch.open(ctx.path).then(
    (scratch) => {
      if (disposed || !scratch) return;
      if (!scratch.scene) throw new Error(`${baseName(ctx.path)} decoded to no scene`);
      renderer.show(scratch.scene, scratch.animations);
      view.note.hidden = true;
      ready = true;
      drawClips(renderer.clips());
      ctx.changed();
    },
  ).catch((err: unknown) => {
    if (disposed) return;
    view.note.textContent = `Not previewed: ${why(err)}`;
    view.note.classList.add('ed-as-red');
  });

  function play(): void {
    if (!ready || clip === null) return;
    if (renderer.playing) renderer.play(null);
    else renderer.play(clip, { speed, loop: ctx.prefs().loop });
  }

  return {
    root,
    play,
    plays: () => ready && clip !== null,
    pauses: true,
    frame: () => renderer.frame(),
    playing: () => ready && renderer.playing,
    stop: () => renderer.play(null),
    wants: () => (ready ? wantOf(entry, 256, ctx) : []),
    dispose() {
      disposed = true;
      off();
      unhold();
      ctx.hold('play', false);
      renderer.clear();
      renderer.unmount();
      ctx.scratch.close();
    },
  };
}

/** Seconds a prefab's preview takes to turn once. */
const TURN = 12;

/**
 * A prefab (Docs/prefabs.md §7): its views as its file places them --
 * `prefabLook` -- on the model previewer's stage, turning
 * (a clip of its own, so the renderer draws every frame; Space pauses it).
 * Its models are the asset store's, shared with the game: no wireframe or
 * backfaces here, which would write their materials. A prefab not compiled
 * (its file broken) or drawing nothing says so.
 */
function prefabPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-model');
  const key = prefabKeyOf(ctx.path);
  const compiled = key === undefined ? undefined : compiledPrefab(key);
  const look = compiled ? prefabLook(compiled) : null;
  if (!look) {
    root.append(formatIcon('json'), line(compiled ? `${key} draws nothing: none of its entities has a view · ${sayBytes(ctx.size)}` : `${key ?? 'this'} is not compiled yet: just made, or its problem is below · ${sayBytes(ctx.size)}`));
    return { root, dispose: () => {} };
  }
  const view = stage(ctx);
  const tools = el('div', 'ed-as-pv-tools');
  root.append(view.root, tools);
  const renderer = ctx.renderer();
  renderer.mount(view.root);
  const unhold = view.holdOnDrag();
  // The game's own materials are shown: nothing here may write them.
  renderer.setWireframe(false);
  renderer.setBackfaces(false);
  renderer.setSkeleton(false);
  const turning = new THREE.Group();
  turning.add(look);
  const q = (turns: number): number[] => new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), turns * Math.PI * 2).toArray();
  const clip = new THREE.AnimationClip('turn', TURN, [new THREE.QuaternionKeyframeTrack('.quaternion', [0, TURN / 4, TURN / 2, (3 * TURN) / 4, TURN], [...q(0), ...q(0.25), ...q(0.5), ...q(0.75), ...q(1)])]);
  renderer.show(turning, [clip]);
  renderer.play('turn', { speed: 1, loop: true });
  view.note.hidden = true;
  const playButton = iconButton('ui', 'pause', 'Stop it turning (Space)', () => play());
  tools.append(button('ui', 'Frame', 'Framed again (F)', () => renderer.frame(), 'ed-small'), playButton);
  let wasPlaying = true;
  let disposed = false;
  const off = renderer.on('frame', () => {
    if (disposed) return;
    const info = renderer.info();
    const said = `${compiled!.count} ${compiled!.count === 1 ? 'entity' : 'entities'} · ${info.triangles.toLocaleString('en')} triangles · ${info.calls} ${info.calls === 1 ? 'draw call' : 'draw calls'}`;
    if (view.info.textContent !== said) view.info.textContent = said;
    if (renderer.playing !== wasPlaying) {
      wasPlaying = renderer.playing;
      playButton.replaceChildren(icon(wasPlaying ? 'pause' : 'play'));
      playButton.title = wasPlaying ? 'Stop it turning (Space)' : 'Turn it (Space)';
      ctx.changed();
    }
  });
  function play(): void {
    if (renderer.playing) renderer.play(null);
    else renderer.play('turn', { speed: 1, loop: true });
  }
  return {
    root,
    play,
    plays: () => true,
    pauses: true,
    frame: () => renderer.frame(),
    playing: () => renderer.playing,
    stop: () => renderer.play(null),
    dispose() {
      disposed = true;
      off();
      unhold();
      renderer.clear();
      renderer.unmount();
    },
  };
}

/**
 * A material (Docs/render.md §4): a sphere wearing it -- the game's own shared
 * material (`materialIfPresent`), so nothing here writes it and a file saved
 * shows on it as on every view wearing it -- turning on the model's stage
 * (Space pauses it). One not compiled (just made, or broken) says so.
 */
function materialPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-model');
  const key = materialKeyOf(ctx.path);
  const material = key === undefined ? null : materialIfPresent(key);
  if (!material) {
    root.append(formatIcon('json'), line(`${key ?? 'this'} is not compiled yet: just made, or its problem is below · ${sayBytes(ctx.size)}`));
    return { root, dispose: () => {} };
  }
  const view = stage(ctx);
  const tools = el('div', 'ed-as-pv-tools');
  root.append(view.root, tools);
  const renderer = ctx.renderer();
  renderer.mount(view.root);
  const unhold = view.holdOnDrag();
  // The game's own material is shown: nothing here may write it.
  renderer.setWireframe(false);
  renderer.setBackfaces(false);
  renderer.setSkeleton(false);
  const sphere = new THREE.SphereGeometry(0.5, 64, 32);
  const turning = new THREE.Group();
  turning.add(new THREE.Mesh(sphere, material));
  const q = (turns: number): number[] => new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), turns * Math.PI * 2).toArray();
  const clip = new THREE.AnimationClip('turn', TURN, [new THREE.QuaternionKeyframeTrack('.quaternion', [0, TURN / 4, TURN / 2, (3 * TURN) / 4, TURN], [...q(0), ...q(0.25), ...q(0.5), ...q(0.75), ...q(1)])]);
  renderer.show(turning, [clip]);
  renderer.play('turn', { speed: 1, loop: true });
  view.note.hidden = true;
  view.info.textContent = `${material.type} · ${key}`;
  const playButton = iconButton('ui', 'pause', 'Stop it turning (Space)', () => play());
  tools.append(button('ui', 'Frame', 'Framed again (F)', () => renderer.frame(), 'ed-small'), playButton);
  let wasPlaying = true;
  let disposed = false;
  const off = renderer.on('frame', () => {
    if (disposed || renderer.playing === wasPlaying) return;
    wasPlaying = renderer.playing;
    playButton.replaceChildren(icon(wasPlaying ? 'pause' : 'play'));
    playButton.title = wasPlaying ? 'Stop it turning (Space)' : 'Turn it (Space)';
    ctx.changed();
  });
  function play(): void {
    if (renderer.playing) renderer.play(null);
    else renderer.play('turn', { speed: 1, loop: true });
  }
  return {
    root,
    play,
    plays: () => true,
    pauses: true,
    frame: () => renderer.frame(),
    playing: () => renderer.playing,
    stop: () => renderer.play(null),
    dispose() {
      disposed = true;
      off();
      unhold();
      renderer.clear();
      renderer.unmount();
      sphere.dispose();
    },
  };
}

/** The GPU format three names a texture's: `RGBA_ASTC_4x4_Format`, read off three's own constants. */
/** The GPU formats the game's KTX2 loader hands back, by three's value: what a KTX2's line names (`KTX2Loader`'s own list). */
const KTX2_FORMATS: ReadonlyMap<number, string> = new Map<number, string>([
  [THREE.RGBAFormat, 'RGBAFormat'],
  [THREE.RGBFormat, 'RGBFormat'],
  [THREE.RGFormat, 'RGFormat'],
  [THREE.RedFormat, 'RedFormat'],
  [THREE.RGBA_ASTC_4x4_Format, 'RGBA_ASTC_4x4_Format'],
  [THREE.RGBA_ASTC_6x6_Format, 'RGBA_ASTC_6x6_Format'],
  [THREE.RGBA_BPTC_Format, 'RGBA_BPTC_Format'],
  [THREE.RGB_BPTC_UNSIGNED_Format, 'RGB_BPTC_UNSIGNED_Format'],
  [THREE.RGBA_ETC2_EAC_Format, 'RGBA_ETC2_EAC_Format'],
  [THREE.RGB_ETC2_Format, 'RGB_ETC2_Format'],
  [THREE.RGB_ETC1_Format, 'RGB_ETC1_Format'],
  [THREE.RGBA_S3TC_DXT5_Format, 'RGBA_S3TC_DXT5_Format'],
  [THREE.RGBA_S3TC_DXT1_Format, 'RGBA_S3TC_DXT1_Format'],
  [THREE.RGB_S3TC_DXT1_Format, 'RGB_S3TC_DXT1_Format'],
  [THREE.RGBA_PVRTC_4BPPV1_Format, 'RGBA_PVRTC_4BPPV1_Format'],
  [THREE.RGBA_PVRTC_2BPPV1_Format, 'RGBA_PVRTC_2BPPV1_Format'],
  [THREE.RGB_PVRTC_4BPPV1_Format, 'RGB_PVRTC_4BPPV1_Format'],
  [THREE.R11_EAC_Format, 'R11_EAC_Format'],
  [THREE.SIGNED_R11_EAC_Format, 'SIGNED_R11_EAC_Format'],
  [THREE.RG11_EAC_Format, 'RG11_EAC_Format'],
  [THREE.SIGNED_RG11_EAC_Format, 'SIGNED_RG11_EAC_Format'],
  [THREE.RED_RGTC1_Format, 'RED_RGTC1_Format'],
  [THREE.SIGNED_RED_RGTC1_Format, 'SIGNED_RED_RGTC1_Format'],
  [THREE.RED_GREEN_RGTC2_Format, 'RED_GREEN_RGTC2_Format'],
  [THREE.SIGNED_RED_GREEN_RGTC2_Format, 'SIGNED_RED_GREEN_RGTC2_Format'],
]);

function formatName(format: number): string {
  return KTX2_FORMATS.get(format) ?? String(format);
}

/** A KTX2: decoded by the game's loader, on the renderer's quad. */
function ktx2Preview(entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-texture');
  const view = stage(ctx, true);
  const tools = el('div', 'ed-as-pv-tools');
  const facts = line('');
  root.append(view.root, tools, facts);
  const renderer = ctx.renderer();
  renderer.mount(view.root);
  const unhold = view.holdOnDrag();
  let disposed = false;
  let ready = false;
  tools.append(
    button('ui', '1:1', 'One texel a pixel', () => renderer.actual(), 'ed-small'),
    button('ui', 'Fit', 'The whole texture in view (F)', () => renderer.frame(), 'ed-small'),
    channelToggles((m) => renderer.setChannels(m)),
  );
  const off = renderer.on('frame', () => {
    if (!disposed && ready) view.info.textContent = `${Math.round(renderer.zoom * 100)}%`;
  });
  void ctx.scratch.open(ctx.path).then((scratch) => {
    if (disposed || !scratch) return;
    const texture = scratch.texture;
    if (!texture) throw new Error(`${baseName(ctx.path)} decoded to no texture`);
    renderer.show(texture);
    ready = true;
    view.note.hidden = true;
    const image = texture.image as { width?: number; height?: number } | undefined;
    const mips = texture.mipmaps?.length ?? 0;
    const size = image?.width !== undefined && image?.height !== undefined ? powerLine(image.width, image.height) : '';
    facts.textContent = [size, `KTX2 · ${formatName(texture.format)}`, `${mips} ${mips === 1 ? 'mip' : 'mips'}`].filter(Boolean).join(' · ');
    ctx.changed();
  }).catch((err: unknown) => {
    if (disposed) return;
    view.note.textContent = `Not previewed: ${why(err)}`;
    view.note.classList.add('ed-as-red');
  });
  return {
    root,
    frame: () => renderer.frame(),
    wants: () => (ready ? wantOf(entry, 256, ctx) : []),
    dispose() {
      disposed = true;
      off();
      unhold();
      renderer.setChannels(null);
      renderer.clear();
      renderer.unmount();
      ctx.scratch.close();
    },
  };
}

/** A picture the browser decodes, in a view that zooms and pans: a texture's, an atlas's sheet. */
function pictureView(ctx: PreviewContext, extra?: (layer: HTMLElement) => void): {
  root: HTMLElement;
  view: HTMLElement;
  zoom: HTMLElement;
  pz: PanZoom;
  image: HTMLImageElement;
  filter: ReturnType<typeof channelFilter>;
  loaded: Promise<{ width: number; height: number }>;
  dispose(): void;
} {
  const view = el('div', 'ed-as-viewport ed-as-checker');
  const layer = el('div', 'ed-as-layer');
  const image = el('img', 'ed-as-picture');
  image.alt = '';
  image.draggable = false;
  image.decoding = 'async';
  layer.append(image);
  extra?.(layer);
  const zoom = el('div', 'ed-as-pv-info');
  const filter = channelFilter();
  view.append(layer, zoom, filter.svg);
  const pz = panZoom(ctx, view, layer, () => {
    zoom.textContent = `${Math.round(pz.scale * 100)}%`;
  });
  const loaded = new Promise<{ width: number; height: number }>((resolve, reject) => {
    image.addEventListener('load', () => {
      pz.size(image.naturalWidth, image.naturalHeight);
      resolve({ width: image.naturalWidth, height: image.naturalHeight });
    }, { once: true });
    image.addEventListener('error', () => reject(new Error(`the browser could not decode ${baseName(ctx.path)}`)), { once: true });
  });
  image.src = ctx.api.fileUrl(ctx.path);
  return { root: view, view, zoom, pz, image, filter, loaded, dispose: () => pz.dispose() };
}

/** An image the browser decodes: on a checkerboard, zoomed and panned, its channels. */
function texturePreview(entry: Shown, ctx: PreviewContext): PreviewShown {
  if (ctx.ext === 'ktx2') return ktx2Preview(entry, ctx);
  const root = el('div', 'ed-as-pv ed-as-pv-texture');
  const picture = pictureView(ctx);
  const tools = el('div', 'ed-as-pv-tools');
  const facts = line('reading…');
  tools.append(
    button('ui', '1:1', 'One texel a pixel', () => picture.pz.actual(), 'ed-small'),
    button('ui', 'Fit', 'The whole texture in view (F)', () => picture.pz.fit(), 'ed-small'),
    channelToggles((m) => picture.filter.apply(picture.image, m)),
  );
  root.append(picture.root, tools, facts);
  picture.loaded.then(
    ({ width, height }) => void (facts.textContent = `${powerLine(width, height)} · ${ctx.ext.toUpperCase()} · ${sayBytes(ctx.size)}`),
    (err: unknown) => {
      facts.textContent = `Not previewed: ${why(err)}`;
      facts.className = 'ed-as-pv-line ed-as-red';
    },
  );
  return { root, frame: () => picture.pz.fit(), dispose: () => picture.dispose() };
}

/** An atlas: the sheet with its frames outlined, their names lit on hover and cropped to on a click. */
function atlasPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-atlas');
  const NS = 'http://www.w3.org/2000/svg';
  const outline = document.createElementNS(NS, 'svg');
  outline.setAttribute('class', 'ed-as-frames-outline');
  const picture = pictureView(ctx, (layer) => layer.append(outline));
  const tools = el('div', 'ed-as-pv-tools');
  const facts = line('reading…');
  const names = el('div', 'ed-as-frame-names');
  tools.append(
    button('ui', 'Fit', 'The whole sheet in view (F)', () => fit(), 'ed-small'),
    button('ui', '1:1', 'One texel a pixel', () => picture.pz.actual(), 'ed-small'),
  );
  root.append(picture.root, tools, facts, names);
  let disposed = false;
  let chosen: { name: HTMLElement; rect: SVGRectElement } | null = null;
  const fit = (): void => {
    if (chosen) {
      chosen.name.classList.remove('ed-as-chosen');
      chosen.rect.classList.remove('ed-as-chosen');
      chosen = null;
    }
    picture.pz.fit();
  };
  // Its .json beside it: the same stem, in the same folder (a trashed sheet's, in the same slot).
  const json = joinPath(dirName(ctx.path), `${splitName(baseName(ctx.path)).stem}.json`);
  const frames = (ctx.entryAt(json) || fromTrash(ctx.path) ? ctx.api.file(json).then((r) => r.json() as Promise<unknown>) : Promise.reject(new Error('no .json beside it')))
    .then((raw) => atlasFrames(raw));
  void Promise.all([picture.loaded, frames]).then(([size, read]) => {
    if (disposed) return;
    const w = read.size?.w ?? size.width;
    const h = read.size?.h ?? size.height;
    outline.setAttribute('viewBox', `0 0 ${w} ${h}`);
    outline.setAttribute('width', String(size.width));
    outline.setAttribute('height', String(size.height));
    facts.textContent = `${read.frames.length} ${read.frames.length === 1 ? 'frame' : 'frames'} · ${powerLine(size.width, size.height)}`;
    for (const f of read.frames) {
      const rect = document.createElementNS(NS, 'rect');
      rect.setAttribute('x', String(f.x));
      rect.setAttribute('y', String(f.y));
      rect.setAttribute('width', String(f.w));
      rect.setAttribute('height', String(f.h));
      outline.append(rect);
      const name = control('ui', 'ed-as-frame-name', f.name);
      name.title = `${f.name}: ${f.w} × ${f.h} at ${f.x}, ${f.y} -- a click crops to it`;
      name.addEventListener('pointerenter', () => rect.classList.add('ed-as-lit'));
      name.addEventListener('pointerleave', () => rect.classList.remove('ed-as-lit'));
      name.addEventListener('click', () => {
        if (chosen?.rect === rect) return fit();
        if (chosen) {
          chosen.name.classList.remove('ed-as-chosen');
          chosen.rect.classList.remove('ed-as-chosen');
        }
        chosen = { name, rect };
        name.classList.add('ed-as-chosen');
        rect.classList.add('ed-as-chosen');
        picture.pz.to(f);
      });
      names.append(name);
    }
  }, (err: unknown) => {
    if (disposed) return;
    // The sheet alone, still: a texture with no frames to outline.
    picture.loaded.then(({ width, height }) => void (facts.textContent = `${powerLine(width, height)} · no frames read: ${why(err)}`), () => {
      facts.textContent = `Not previewed: ${why(err)}`;
      facts.className = 'ed-as-pv-line ed-as-red';
    });
  });
  return {
    root,
    frame: fit,
    dispose() {
      disposed = true;
      picture.dispose();
    },
  };
}

/** A sound: its waveform with a cursor, played through the game's mixer. */
function soundPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-sound');
  const wave = el('div', 'ed-as-wave');
  const canvas = el('canvas', 'ed-as-wave-canvas');
  const cursor = el('div', 'ed-as-cursor');
  cursor.hidden = true;
  const said = el('div', 'ed-as-pv-note', 'decoding…');
  wave.append(canvas, cursor, said);
  wave.title = 'A click plays from there';
  const tools = el('div', 'ed-as-pv-tools');
  const playButton = iconButton('ui', 'play', 'Play (Space)', () => play());
  const prefs = ctx.prefs();
  const loop = toggle('Loop', 'Round and round until stopped', prefs.loop, (on) => {
    ctx.keep({ loop: on });
    if (ctx.sound.playing) start(ctx.sound.at);
  });
  const volume = el('input', 'ed-as-volume');
  volume.type = 'range';
  volume.min = '0';
  volume.max = '1';
  volume.step = '0.05';
  volume.value = String(prefs.volume);
  volume.title = 'The preview\'s own volume, under the game\'s ui volume: the game does not hear it';
  // Heard as it is dragged -- the playing sound's own level, eased, never started again -- and kept as it is let go.
  volume.addEventListener('input', () => ctx.sound.setGain(Number(volume.value)));
  volume.addEventListener('change', () => ctx.keep({ volume: Number(volume.value) }));
  tools.append(playButton, loop, el('span', 'ed-dim ed-as-small', 'volume'), volume);
  const facts = line('');
  const note = line('', 'ed-as-amber');
  note.hidden = true;
  root.append(wave, tools, facts, note);

  let buffer: AudioBuffer | null = null;
  let waved: Peaks | null = null;
  let disposed = false;
  let from = 0;
  let stopClock: (() => void) | null = null;
  let rate: number | undefined;

  const drawNote = (): void => {
    const now = ctx.sound.note;
    note.hidden = now === null;
    note.textContent = now === null ? '' : NOTE_WORDS[now];
  };
  const drawFacts = (): void => {
    if (!buffer) return;
    const channels = buffer.numberOfChannels;
    facts.textContent = `${secs(buffer.duration)} s · ${channels === 1 ? 'mono' : channels === 2 ? 'stereo' : `${channels} channels`}${rate !== undefined ? ` · ${rate.toLocaleString('en')} Hz` : ''} · ${sayBytes(ctx.size)}`;
  };
  const drawWaveNow = (): void => {
    if (!waved) return;
    const ratio = Math.min(2, devicePixelRatio || 1);
    const width = Math.max(1, Math.round(wave.clientWidth * ratio));
    const height = Math.max(1, Math.round(wave.clientHeight * ratio));
    if (canvas.width !== width) canvas.width = width;
    if (canvas.height !== height) canvas.height = height;
    drawWave(canvas.getContext('2d')!, waved, width, height, ctx.colour('--as-wave'));
  };
  const resized = new ResizeObserver(() => drawWaveNow());
  resized.observe(wave);
  const placeCursor = (at: number): void => {
    if (!buffer) return;
    cursor.hidden = false;
    cursor.style.transform = `translateX(${cursorX(at, buffer.duration, wave.clientWidth)}px)`;
  };

  ctx.stats((stats) => {
    if (stats.kind === 'audio') rate = (stats.stats as AudioStats | undefined)?.sampleRate;
    drawFacts();
  });
  void ctx.api.file(ctx.path)
    .then((res) => res.arrayBuffer())
    .then((bytes) => decodeSound(bytes))
    .then((decoded) => {
      if (disposed) return;
      buffer = decoded;
      waved = peaks(decoded, 2048);
      said.hidden = true;
      drawFacts();
      drawNote();
      drawWaveNow();
      ctx.changed();
    }, (err: unknown) => {
      if (disposed) return;
      said.textContent = `Not decoded: ${why(err)}`;
      said.classList.add('ed-as-red');
    });

  /** Played from `at` seconds, with the loop and the volume as they are now; the cursor follows it each frame. */
  function start(at: number): void {
    if (!buffer) return;
    const now = ctx.prefs();
    ctx.sound.play(buffer, { from: at, loop: now.loop, gain: now.volume });
    playButton.replaceChildren(icon('pause'));
    playButton.title = 'Stop (Space)';
    ctx.hold('play', true);
    drawNote();
    if (!stopClock) {
      stopClock = everyFrame(() => {
        if (disposed) return false;
        drawNote();
        if (!ctx.sound.playing) {
          ended();
          return false;
        }
        placeCursor(ctx.sound.at);
        return true;
      });
    }
    ctx.changed();
  }
  function ended(): void {
    stopClock = null;
    playButton.replaceChildren(icon('play'));
    playButton.title = 'Play (Space)';
    placeCursor(from);
    ctx.hold('play', false);
    ctx.changed();
  }
  function stop(): void {
    ctx.sound.stop();
    stopClock?.();
    if (stopClock) ended();
  }
  function play(): void {
    if (!buffer) return;
    if (ctx.sound.playing) stop();
    else start(from);
    drawNote();
  }
  // mcp: ui -- a sound previewed from where the wave is clicked
  wave.addEventListener('click', (event) => {
    if (!buffer) return;
    const box = wave.getBoundingClientRect();
    from = timeAt(event.clientX - box.left, box.width, buffer.duration);
    placeCursor(from);
    start(from);
  });

  return {
    root,
    play,
    plays: () => buffer !== null,
    playing: () => ctx.sound.playing && stopClock !== null,
    stop,
    dispose() {
      disposed = true;
      resized.disconnect();
      if (stopClock) stop();
      ctx.hold('play', false);
    },
  };
}

let faces = 0;

/** A font: a `FontFace` from a blob URL, in `document.fonts` while shown, a line in it at three sizes. */
function fontPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-font');
  const sample = el('input', 'ed-input ed-as-sample');
  sample.type = 'text';
  sample.value = 'Sphinx of black quartz, judge my vow 0123456789';
  sample.title = 'A line in the font: type your own';
  sample.spellcheck = false;
  const lines = [14, 24, 40].map((px) => {
    const l = el('div', 'ed-as-font-line', sample.value);
    l.style.fontSize = `${px}px`;
    l.title = `${px} px`;
    return l;
  });
  sample.addEventListener('input', () => {
    for (const l of lines) l.textContent = sample.value;
  });
  const facts = line('loading…');
  root.append(sample, ...lines, facts);
  const family = `ed-as-font-${++faces}`;
  let url: string | null = null;
  let face: FontFace | null = null;
  let disposed = false;
  void ctx.api.file(ctx.path).then((res) => res.blob()).then(async (blob) => {
    if (disposed) return;
    url = URL.createObjectURL(blob);
    const made = new FontFace(family, `url("${url}")`);
    await made.load();
    if (disposed) return;
    face = made;
    document.fonts.add(made);
    for (const l of lines) l.style.fontFamily = `"${family}", ui-monospace, monospace`;
    // A face made without descriptors is always `normal`: its weight is the file's, and not said.
    facts.textContent = `${ctx.ext.toUpperCase()} · ${sayBytes(ctx.size)}`;
  }).catch((err: unknown) => {
    if (disposed) return;
    facts.textContent = `Not loaded: ${why(err)}`;
    facts.className = 'ed-as-pv-line ed-as-red';
  });
  return {
    root,
    dispose() {
      disposed = true;
      if (face) document.fonts.delete(face);
      if (url) URL.revokeObjectURL(url);
    },
  };
}

/** An icon: at 24, 48 and 96, on light and on dark. */
function iconPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-icons');
  const src = ctx.api.fileUrl(ctx.path);
  for (const shade of ['light', 'dark'] as const) {
    const row = el('div', `ed-as-icon-row ed-as-${shade}`);
    row.title = `On ${shade}`;
    for (const px of [24, 48, 96]) {
      const image = el('img');
      image.alt = '';
      image.draggable = false;
      image.width = image.height = px;
      image.title = `${px} px`;
      image.src = src;
      row.append(image);
    }
    root.append(row);
  }
  root.append(line(`${ctx.ext.toUpperCase()} · ${sayBytes(ctx.size)}`));
  return { root, dispose: () => {} };
}

/** At most this much of a text is read: a 40 MB level is not drawn into a panel. */
export const TEXT_MAX = 256 * 1024;

/** Text, a level, JSON: read-only, with its size. */
function textPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-text');
  const text = el('pre', 'ed-object ed-as-text', 'reading…');
  const cut = ctx.size > TEXT_MAX;
  root.append(text, line(`${sayBytes(ctx.size)}${cut ? ` · the first ${sayBytes(TEXT_MAX)} shown` : ''}`));
  let disposed = false;
  void ctx.api.file(ctx.path, cut ? { headers: { Range: `bytes=0-${TEXT_MAX - 1}` } } : undefined)
    .then((res) => res.text())
    .then((body) => {
      if (!disposed) text.textContent = body;
    }, (err: unknown) => {
      if (disposed) return;
      text.textContent = `Not read: ${why(err)}`;
      text.classList.add('ed-as-red');
    });
  return {
    root,
    dispose: () => void (disposed = true),
  };
}

/**
 * Markdown as a page (`markdown.ts`): a README beside the art, a designer's
 * notes. Built as elements, never markup, so a file can bring no script with
 * it. A relative link opens the file beside it through `GET file`; a relative
 * image is fetched the same way; a web address opens in a new tab.
 */
function markdownPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-text');
  const page = el('div', 'ed-object ed-as-text ed-as-md', 'reading…');
  const cut = ctx.size > TEXT_MAX;
  root.append(page, line(`Markdown · ${sayBytes(ctx.size)}${cut ? ` · the first ${sayBytes(TEXT_MAX)} shown` : ''}`));
  // A relative address is beside the document: served by the dev server, nothing in bundle view.
  const beside = (ref: string): string | null => {
    try {
      // Empty in bundle view for a file the build did not carry: shown as its text then.
      return ctx.api.fileUrl(joinPath(dirName(ctx.path), ref.replace(/^\.\//, ''))) || null;
    } catch {
      return null;
    }
  };
  const links = {
    href: (href: string): string | null => {
      const safe = SAFE_LINKS.href(href);
      if (safe === null) return null;
      return /^(https?:|mailto:)/i.test(safe) || safe.startsWith('#') ? safe : beside(safe);
    },
    image: (src: string): string | null => (/^https?:/i.test(src) ? src : beside(src)),
  };
  let disposed = false;
  void ctx.api.file(ctx.path, cut ? { headers: { Range: `bytes=0-${TEXT_MAX - 1}` } } : undefined)
    .then((res) => res.text())
    .then((body) => {
      if (disposed) return;
      page.replaceChildren(renderMarkdown(parseMarkdown(body), links));
    }, (err: unknown) => {
      if (disposed) return;
      page.textContent = `Not read: ${why(err)}`;
      page.classList.add('ed-as-red');
    });
  return {
    root,
    dispose: () => void (disposed = true),
  };
}

/**
 * A source no browser previews (`.lua`, `.blend`, `.psd`): its export when
 * current -- `previewFor` sent that to its own row -- else the server's
 * thumbnail at 256, else the format's icon and the line.
 */
function sourcePreview(entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-source');
  const want = wantOf(entry, 256, ctx)[0];
  const made = want !== undefined;
  const picture = el('div', 'ed-as-pv-thumb ed-as-checker');
  const words = isEntry(entry) && entry.role === 'source'
    ? 'previewed from its export once it is made'
    : `no preview of .${ctx.ext} here${made ? ': the server\'s thumbnail when it has one' : ''}`;
  const said = line(words);
  root.append(picture, said);
  const draw = (): boolean => {
    const known = want ? ctx.thumbs.known(want) : undefined;
    const url = known !== undefined ? ctx.thumbs.url(known, 256) : undefined;
    if (!url) return false;
    const image = el('img');
    image.alt = '';
    image.draggable = false;
    image.src = url;
    picture.replaceChildren(image);
    said.textContent = `the server's thumbnail${isEntry(entry) && entry.role === 'source' ? ': previewed from its export once it is made' : ''}`;
    return true;
  };
  if (!draw()) picture.replaceChildren(formatIcon(ctx.ext));
  const off = ctx.thumbs.onReady((_hash, size, path) => {
    if (size === 256 && path === entry.path) draw();
  });
  return {
    root,
    wants: () => (want ? [want] : []),
    dispose: off,
  };
}

/** An LFS pointer: the icon, what it is, and the command, copied with a click. */
function pointerPreview(_entry: Shown, ctx: PreviewContext): PreviewShown {
  const root = el('div', 'ed-as-pv ed-as-pv-pointer');
  const command = 'git lfs install && git lfs pull';
  const copyLine = el('div', 'ed-line ed-as-copy-line');
  const words = el('span', 'ed-as-copy-text');
  words.append(el('span', 'ed-dim', 'run '), el('code', undefined, command));
  copyLine.append(words, iconButton('ui', 'copy', `Copy the command: ${command}`, () => ctx.copy(command, 'the command: run it in a terminal; the tile changes as the files arrive')));
  root.append(formatIcon(ctx.ext, true), line('A Git LFS pointer, not the file', 'ed-as-red'), copyLine);
  return { root, dispose: () => {} };
}

/** Anything else: an image the browser decodes, as a texture; else the format's icon and the line. */
function otherPreview(entry: Shown, ctx: PreviewContext): PreviewShown {
  if (BROWSER_IMAGES.includes(ctx.ext)) return texturePreview(entry, ctx);
  const root = el('div', 'ed-as-pv ed-as-pv-other');
  root.append(formatIcon(ctx.ext), line(`no preview of .${ctx.ext || 'this'} here · ${sayBytes(ctx.size)}`));
  return { root, dispose: () => {} };
}

/** Every row of the table, by what it is: what `PREVIEWS` maps extensions and kinds to. */
export const PREVIEW_ROWS = {
  model: { make: modelPreview },
  prefab: { make: prefabPreview },
  material: { make: materialPreview },
  texture: { make: texturePreview },
  atlas: { make: atlasPreview },
  sound: { make: soundPreview },
  font: { make: fontPreview },
  icon: { make: iconPreview },
  text: { make: textPreview },
  markdown: { make: markdownPreview },
  source: { make: sourcePreview },
  pointer: { make: pointerPreview },
  other: { make: otherPreview },
} as const satisfies Record<string, PreviewRow>;

const rows = <K extends string>(keys: readonly K[], row: PreviewRow): Record<K, PreviewRow> => Object.fromEntries(keys.map((k) => [k, row])) as Record<K, PreviewRow>;

/**
 * The table (§6.2, §12): by extension -- the models three loads, a KTX2, an
 * SVG, the fonts, the sounds, text, and the sources only their export or the
 * server previews -- then by kind -- a sheet under `sprites/`, an icon, a
 * texture -- then `*`; `pointer` for an LFS pointer, whatever it is.
 */
export const PREVIEWS: Readonly<Record<string, PreviewRow>> = {
  ...rows(['glb', 'gltf', 'fbx', 'obj', 'dae', 'stl'], PREVIEW_ROWS.model),
  ktx2: PREVIEW_ROWS.texture,
  svg: PREVIEW_ROWS.icon,
  ...rows(['woff2', 'woff', 'ttf', 'otf'], PREVIEW_ROWS.font),
  ...rows([...KINDS.sfx.ext, ...SOUND_MASTERS], PREVIEW_ROWS.sound),
  ...rows(['json', 'prefab', 'scene', 'material', 'txt', 'log', 'csv', 'mtl'], PREVIEW_ROWS.text),
  md: PREVIEW_ROWS.markdown,
  ...rows(['lua', 'blend', 'aseprite', 'ase', 'psd', 'psb', 'xcf', 'kra', 'tif', 'tiff'], PREVIEW_ROWS.source),
  atlases: PREVIEW_ROWS.atlas,
  prefabs: PREVIEW_ROWS.prefab,
  materials: PREVIEW_ROWS.material,
  icons: PREVIEW_ROWS.icon,
  textures: PREVIEW_ROWS.texture,
  pointer: PREVIEW_ROWS.pointer,
  '*': PREVIEW_ROWS.other,
};

// ---------------------------------------------------------------- the block

/** What the block is handed: the tool's renderer, decode, player and queue, and the table. */
export type PreviewHost = Omit<PreviewContext, 'entry' | 'path' | 'ext' | 'kind' | 'size' | 'stats'> & {
  /** `PREVIEWS`, and a game's rows over it. */
  readonly table: Readonly<Record<string, PreviewRow>>;
  /** What `GET stats` read of a path, once it has (the Stats block's cache). */
  stats(path: string, then: (stats: FileStats) => void): void;
};

export interface PreviewBlock {
  /** The block, an `ed-component` "Preview": placed under the inspector's head, kept across its redraws. */
  readonly root: HTMLElement;
  /** `row` previewed -- or nothing. The same file, unchanged, is left as it is. */
  show(row: Shown | null): void;
  /** Does what is shown play or frame: Space and F are live. */
  readonly plays: boolean;
  /** Is there something to play, and something to frame: what the hint names. */
  readonly playable: boolean;
  readonly frames: boolean;
  /** Is something playing: Esc stops it. */
  readonly playing: boolean;
  /** What Space does to it now, for the hint: "Space plays", "Space pauses" (a clip), "Space stops" (a sound); '' for nothing to play. */
  readonly spaceWord: string;
  play(): void;
  frame(): void;
  stop(): void;
  /** The thumbnails the preview wants made first. */
  wants(): ThumbWant[];
  dispose(): void;
}

/**
 * `then`, told once and only while `current()` holds: the stats an answer
 * brings for what is shown -- whether it comes later or at once, inside the
 * call that asked, before the preview is recorded as shown (a cached answer).
 */
export function toldOnce<T>(current: () => boolean, then: (value: T) => void): (value: T) => void {
  let told = false;
  return (value) => {
    if (told || !current()) return;
    told = true;
    then(value);
  };
}

export function createPreview(host: PreviewHost): PreviewBlock {
  const root = el('div', 'ed-component ed-as-block ed-as-preview');
  const head = el('div', 'ed-component-head', 'Preview');
  const content = el('div', 'ed-as-pv-host');
  root.append(head, content);
  let shown: { key: string; made: PreviewShown } | null = null;
  /** The showing under way: taken before its preview is made, so an answer that comes inside the making counts. */
  let showing: object | null = null;

  /** What makes a preview another: the file, what is shown of it, and that content's hash. */
  const keyOf = (row: Shown): string => {
    const { path } = shownOf(row);
    const at = host.entryAt(path);
    return `${row.path}\n${path}\n${at?.hash ?? at?.mtime ?? row.mtime}\n${isEntry(row) && row.pointer ? 'pointer' : ''}`;
  };

  function close(): void {
    showing = null;
    if (!shown) return;
    const was = shown;
    shown = null;
    was.made.dispose();
    content.replaceChildren();
    host.changed();
  }

  return {
    root,
    show(row) {
      if (!row) return close();
      // A prefab is drawn from its compile, which a recompile replaces though its file is the same.
      // A material the same: its object may be another (a type changed), or the file compiled at last.
      const of = shownOf(row).kind;
      const key = of === 'prefabs' ? `${keyOf(row)}#${livePrefabs.compiles}` : of === 'materials' ? `${keyOf(row)}#${materialsStamp()}` : keyOf(row);
      if (shown?.key === key) return;
      close();
      const { path, ext, kind } = shownOf(row);
      const size = host.entryAt(path)?.size ?? row.size;
      // This showing's token, before its preview is made: a cached answer told inside `make` is its own.
      const mine = {};
      showing = mine;
      const ctx: PreviewContext = {
        ...host,
        entry: row,
        path,
        ext,
        kind,
        size,
        stats: (then) => host.stats(path, toldOnce(() => showing === mine, then)),
      };
      const made = previewFor(row, host.table).make(row, ctx);
      shown = { key, made };
      content.append(made.root);
      // What it is to its family -- a part's model, an intermediate's source -- is the head's to say, once.
      host.changed();
    },
    get plays() {
      return shown !== null && (shown.made.play !== undefined || shown.made.frame !== undefined);
    },
    get playable() {
      return shown?.made.play !== undefined && (shown.made.plays?.() ?? true);
    },
    get frames() {
      return shown?.made.frame !== undefined;
    },
    get playing() {
      return shown?.made.playing?.() ?? false;
    },
    get spaceWord() {
      if (!shown || shown.made.play === undefined || !(shown.made.plays?.() ?? true)) return '';
      if (!(shown.made.playing?.() ?? false)) return 'Space plays';
      return shown.made.pauses ? 'Space pauses' : 'Space stops';
    },
    play: () => shown?.made.play?.(),
    frame: () => shown?.made.frame?.(),
    stop: () => shown?.made.stop?.(),
    wants: () => shown?.made.wants?.() ?? [],
    dispose: close,
  };
}
