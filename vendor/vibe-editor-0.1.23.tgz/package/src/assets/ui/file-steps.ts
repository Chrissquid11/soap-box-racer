/**
 * The Assets tool's edits of files as steps (Docs/assets-tool.md §8, "Undo";
 * Docs/assets.md §6): each its calls, its undo and its redo, run on the
 * tool's own queue (`steps.ts`) -- `steps.run(edit.label, edit.first, { do:
 * edit.redo, undo: edit.undo, label: edit.named })`.
 *
 * | Edit | Calls | Undo |
 * | --- | --- | --- |
 * | Import 3 files | `PUT import`, a file each | every family it wrote to the trash, one slot; then what it replaced, restored, the last first; then the folders it made, the deepest first |
 * | Move 3 to props | `POST move`, a family each -- the files naming them rewritten by the server's repair pass in the call (`rewritten`) | moved back, the last first, each with its rewritten files' texts before (`restore`) |
 * | Rename robot → hero | `POST move` (a folder with its twin), the same | moved back, the same |
 * | Delete 3 | one `POST delete` of every path | `restore(slot)` |
 * | Delete characters/ | every family under it, both sides, then each folder, the deepest first -- a `.gitkeep` in one to a slot of its own | `mkdir` each, the shallowest first (one there again is fine); then `restore(slot)`, and each folder's slot |
 * | New folder rigs | `POST mkdir` (a pack: its twin too) | the folder deleted, empty |
 * | Duplicate crate · Copy crate to reef | `POST copy`, a family each | the copies to the trash; redo restores them |
 * | Keep crate.lua | `POST delete` of the other, alone | `restore(slot)` |
 * | crate.glb is crate.blend's hand export | `POST move` to `_crate.glb` | moved back |
 * | Rename the export of crate.blend → crate-hi | `PUT export-as { as }`: its record's `"as"`, its exports moved, what names it rewritten | `PUT export-as { restore }`: the record, the exports and those files as they were |
 * | Leave crate.lua out of the build | `PUT sidecar { include: false }`: the record says so, its exports to a slot | that slot restored, then `{ include: true }` -- the export back as it was, nothing exported |
 * | Put crate.lua in the build | `PUT sidecar { include: true }`, which exports it -- after its last time out's slot, restored | `{ include: false }`, the export to a slot |
 * | Leave rock.glb out of the build | `POST move` to `_rock.glb`, the file alone | moved back |
 * | Restore crate.lua (here) | `POST restore`; to another folder, then `POST move` | what came back, to the trash, its slot kept for redo |
 *
 * - **A step's undo and redo use the paths and slots of the last answer**,
 *   never the ones it was made with: each call takes the slot the one before
 *   answered, so Z and Y go round as often as asked (§A.6).
 * - **Several calls in order**: one refused stops the rest. None done is no
 *   step -- the refusal, naming its file, thrown; some done is a step of
 *   those, the rest said (`partial`), and named by what was done (`named`).
 * - **An import stopped** (`signal`, the sheet's Close before every file is
 *   in): the upload under way aborted, nothing more sent, the families
 *   already written trashed as one `POST delete` and what they replaced put
 *   back -- nothing half-imported, and no step.
 * - **What moved is told** (`moved(from, to)`), as each call answers, undo and
 *   redo too: the tool's selection and open folder follow a rename.
 *
 * Imports types alone: node tests it with a stand-in API (`file-steps.test.ts`).
 */
import type { ExportAsAnswer, ImportAnswer, MoveAnswer, WriteAnswer } from '@vibe/pipeline/assets-types';
import type { Api, RestoreText } from '../api.ts';
import type { Answered, Doing } from '../steps.ts';
import type { TickFlip } from './marks.ts';

/** What the edits call. */
export type FilesApi = Pick<Api, 'move' | 'remove' | 'restore' | 'mkdir' | 'copy' | 'setInclude'> & Partial<Pick<Api, 'names'>>;

/** What an edit tells the tool, and asks of the index. */
export interface EditHost {
  /** A file or a folder moved, from and to -- a rename, undone or redone too. */
  moved?(from: string, to: string): void;
  /** A folder made, or made again by an undo: the index shows it though empty (`keepFolder`). */
  made?(folder: string): void;
  /** One deleted or moved away (`forgetFolder`). */
  gone?(folder: string): void;
  /** Is this path in the index now? */
  has?(path: string): boolean;
  /** Some of several done, the rest refused -- or an undo's files left as edited since: said, once. */
  partial?(text: string): void;
}

/** A step, as `steps.run` takes it. */
export interface Edit {
  label: string;
  first: Doing;
  redo: Doing;
  undo: Doing;
  /** Its label as the first doing left it: "Import 2 files" of three. */
  named?: () => string;
}

/** A path's last part. */
const base = (path: string): string => path.slice(path.lastIndexOf('/') + 1);
/** A name's stem: `robot.fbx` is `robot`; a folder's name is its own. */
export const stemOf = (name: string): string => (name.lastIndexOf('.') > 0 ? name.slice(0, name.lastIndexOf('.')) : name);
/** "1 file", "3 files". */
const files = (n: number): string => `${n} ${n === 1 ? 'file' : 'files'}`;
/** A refusal's words, or an error's message. */
const why = (err: unknown): string => {
  const refused = (err as { body?: { refused?: unknown } } | null)?.body?.refused;
  return typeof refused === 'string' ? refused : err instanceof Error ? err.message : String(err);
};
/** A refusal that says the thing is there already (`exists: true`, a `409`). */
const exists = (err: unknown): boolean => (err as { body?: { exists?: unknown } } | null)?.body?.exists === true;
/** The server's refusal in words -- not there, not empty -- rather than no answer at all. */
const refusal = (err: unknown): boolean => typeof (err as { body?: { refused?: unknown } } | null)?.body?.refused === 'string';
/** An error that names its file: "box.glb: box.glb exists in …". */
const named = (path: string, err: unknown): Error => new Error(why(err).includes(base(path)) ? why(err) : `${base(path)}: ${why(err)}`);

/**
 * `items` called in order: those answered kept, and the last answer. One
 * refused stops the rest: none done throws it, naming its file; some done
 * says how many (`partial`) and keeps them.
 */
async function inOrder<T, A extends WriteAnswer>(items: readonly T[], call: (item: T) => Promise<A>, pathOf: (item: T) => string, host: EditHost, what: string): Promise<{ done: Array<[T, A]>; last: Answered | undefined }> {
  const done: Array<[T, A]> = [];
  let last: Answered | undefined;
  for (const item of items) {
    try {
      const answer = await call(item);
      done.push([item, answer]);
      last = answer;
    } catch (err) {
      if (done.length === 0) throw named(pathOf(item), err);
      host.partial?.(`${what}: ${done.length} of ${items.length} done; ${named(pathOf(item), err).message} -- the rest left as they were`);
      break;
    }
  }
  return { done, last };
}

// ---------------------------------------------------------------- moves

/** A doing's rewritten files as its undo's `restore`: each text before, and what the doing left there. */
const restoreTexts = (rewritten: ReadonlyArray<{ path: string; before: string; after: string }> | undefined): RestoreText[] =>
  (rewritten ?? []).map((r) => ({ path: r.path, text: r.before, after: r.after }));

/** An undo's answer: the files it left as they are, edited since the doing, said. */
function leftAsEdited<T extends { kept?: string[] }>(host: EditHost, answer: T): T {
  if (answer.kept !== undefined && answer.kept.length > 0) host.partial?.(`left as you edited it since: ${answer.kept.map(base).join(', ')}`);
  return answer;
}

/**
 * One move each, `[from, to]`: a family, or a folder with its twin. Undone the
 * last first. `say(n)` names it for how many moved: "Move 3 to props".
 *
 * **References follow in the same step** (Docs/asset-ids.md §4): the server's
 * move runs the repair pass at once, and answers the data files it rewrote with
 * their texts before (`rewritten`); the step keeps them, and its undo hands them
 * to the move back (`restore`), so the move and every rewritten file go back
 * together. A redo keeps what its own move answered. A move whose pass threw
 * midway (`partial`) is a step all the same -- what was done, Z undoing it --
 * and said.
 */
export function moveEdit(api: FilesApi, host: EditHost, pairs: ReadonlyArray<readonly [string, string]>, say: (n: number) => string): Edit {
  const label = say(pairs.length);
  let done: Array<readonly [string, string]> = [];
  /** Each move's rewritten files, by the pair: what its undo puts back. */
  const texts = new Map<readonly [string, string], RestoreText[]>();
  const kept = (pair: readonly [string, string], answer: MoveAnswer): MoveAnswer => {
    texts.set(pair, restoreTexts(answer.rewritten));
    if (answer.partial !== undefined) host.partial?.(`${base(pair[0])} moved, but ${answer.partial} -- Z puts it all back`);
    return answer;
  };
  const go = async (list: ReadonlyArray<readonly [string, string]>, back: boolean): Promise<Answered | undefined> => {
    let last: Answered | undefined;
    for (const pair of back ? [...list].reverse() : list) {
      const [from, to] = pair;
      const [a, b] = back ? [to, from] : [from, to];
      try {
        last = back ? leftAsEdited(host, await api.move(a, b, texts.get(pair) ?? [])) : kept(pair, await api.move(a, b));
      } catch (err) {
        throw named(a, err);
      }
      host.moved?.(a, b);
    }
    return last;
  };
  return {
    label,
    async first() {
      const run = await inOrder(pairs, (p) => api.move(p[0], p[1]).then((answer) => (host.moved?.(p[0], p[1]), kept(p, answer))), (p) => p[0], host, label);
      done = run.done.map(([p]) => p);
      return run.last;
    },
    redo: () => go(done, false),
    undo: () => go(done, true),
    named: () => say(done.length),
  };
}

/** A file or a folder renamed where it is: `Rename robot → hero`; the names whole when only the extension changes (`Rename rvd.json → rvd.prefab`). */
export function renameEdit(api: FilesApi, host: EditHost, from: string, to: string): Edit {
  const [a, b] = [stemOf(base(from)), stemOf(base(to))];
  return moveEdit(api, host, [[from, to]], () => (a === b ? `Rename ${base(from)} → ${base(to)}` : `Rename ${a} → ${b}`));
}

/** A `.glb` beside a `.blend` that cannot be made here, made its export by hand: `crate.glb` → `_crate.glb` (§A.3). */
export function handExportEdit(api: FilesApi, host: EditHost, glb: string, blend: string): Edit {
  const to = `${glb.slice(0, glb.lastIndexOf('/') + 1)}_${base(glb)}`;
  return moveEdit(api, host, [[glb, to]], () => `${base(glb)} is ${base(blend)}'s hand export`);
}

/**
 * A source's export named (Docs/asset-ids.md rule 8): `PUT export-as { as }` -- its record's `"as"` (a record of its
 * own made where another source shares its stem's), its exports moved, what names its key rewritten by uid -- one step;
 * undone by `{ restore }` with what the last doing answered: the record as it was, the exports back, the files as they were.
 */
export function exportAsEdit(api: Pick<Api, 'exportAs'>, host: EditHost, source: string, as: string | null, label: string): Edit {
  let last: ExportAsAnswer | undefined;
  const told = (pairs: ReadonlyArray<readonly [string, string]>, back: boolean): void => {
    for (const [a, b] of pairs) if (back) host.moved?.(b, a);
    else host.moved?.(a, b);
  };
  const go = async (): Promise<Answered> => {
    try {
      last = await api.exportAs(source, { as });
    } catch (err) {
      throw named(source, err);
    }
    told(last.moved, false);
    return last;
  };
  const undo = async (): Promise<Answered> => {
    const was = last!;
    const answer = await api.exportAs(source, { restore: { record: was.record, text: was.before, moved: was.moved, ...(was.made !== undefined ? { made: was.made } : {}), texts: restoreTexts(was.rewritten) } });
    told(was.moved, true);
    return leftAsEdited(host, answer);
  };
  return { label, first: go, redo: go, undo };
}

// ---------------------------------------------------------------- in the build

/**
 * Files put in the build or left out of it (§8; `marks.ts`' `flipsTo`), one
 * step, each flip in order -- the records first, then the names:
 *
 * - **A source's record.** Out: `PUT sidecar { include: false }` -- the
 *   record says so, and its exports go to a slot of their own in the same
 *   call. In: the slot of its last time out restored first, its exports back
 *   as they were, then `{ include: true }`, the flag off -- current again,
 *   nothing exported; with no slot (in for the first time, or out with no
 *   export), the flag alone, and the server exports it.
 * - **A name's `_`**: `POST move`, the file alone (`planMove`'s rule), told
 *   as a move so the selection follows.
 *
 * Undone the last first, each the other way; redone as first done. Refused
 * midway: a step of what was done, the rest said (`partial`), as every edit.
 * `say(n)` names it for how many: "Leave crate.lua out of the build".
 */
export function includeEdit(api: FilesApi, host: EditHost, flips: readonly TickFlip[], to: boolean, say: (n: number) => string): Edit {
  const label = say(flips.length);
  /** Each source's slot from its last time out of the build: what putting it back in restores. */
  const slots = new Map<string, string>();
  let done: TickFlip[] = [];
  /** One flip, toward `to` (`ahead`) or back. */
  const one = async (flip: TickFlip, ahead: boolean): Promise<WriteAnswer> => {
    if ('record' in flip) {
      const include = ahead ? to : !to;
      if (!include) {
        const answer = await api.setInclude(flip.record, false);
        if (answer.slot !== undefined) slots.set(flip.record, answer.slot);
        else slots.delete(flip.record);
        return answer;
      }
      const slot = slots.get(flip.record);
      if (slot !== undefined) {
        // Its exports back first, while it is still out: then in, it is current, and nothing is made again.
        await api.restore(slot, { replace: true });
        slots.delete(flip.record);
      }
      return api.setInclude(flip.record, true);
    }
    const [from, onto] = ahead ? [flip.from, flip.to] : [flip.to, flip.from];
    const answer = await api.move(from, onto);
    host.moved?.(from, onto);
    return answer;
  };
  const pathOf = (flip: TickFlip): string => ('record' in flip ? flip.record : flip.from);
  const go = async (list: readonly TickFlip[], ahead: boolean): Promise<Answered | undefined> => {
    let last: Answered | undefined;
    for (const flip of ahead ? list : [...list].reverse()) {
      try {
        last = await one(flip, ahead);
      } catch (err) {
        throw named(pathOf(flip), err);
      }
    }
    return last;
  };
  return {
    label,
    async first() {
      const run = await inOrder(flips, (flip) => one(flip, true), pathOf, host, label);
      done = run.done.map(([flip]) => flip);
      return run.last;
    },
    redo: () => go(done, true),
    undo: () => go(done, false),
    named: () => say(done.length),
  };
}

// ---------------------------------------------------------------- the trash

/** Families to the trash, one slot: undone by restoring it; redone by trashing what came back. `only`: those files alone. */
export function trashEdit(api: FilesApi, paths: readonly string[], label: string, only = false): Edit {
  let slot: string | undefined;
  let restored: string[] = [];
  const out = async (list: readonly string[], alone: boolean): Promise<Answered> => {
    const answer = await api.remove(list, alone);
    slot = answer.slot;
    restored = [];
    return answer;
  };
  return {
    label,
    first: () => out(paths, only),
    // What came back, exactly: the families went whole, and came back whole.
    redo: () => out(restored, true),
    async undo() {
      if (slot === undefined) throw new Error('nothing went to the trash to bring back');
      const answer = await api.restore(slot);
      restored = answer.restored;
      return answer;
    },
  };
}

/** The other of a conflict to the trash, alone -- its record and export are the stem's, the one kept's too: `Keep crate.lua`. */
export function keepEdit(api: FilesApi, keep: string, others: readonly string[]): Edit {
  return trashEdit(api, others, `Keep ${base(keep)}`, true);
}

/**
 * A folder deleted (§8): every family under it, on both sides, to one slot;
 * then each folder left, the deepest first, its twin with it -- a folder with
 * anything in it is refused, so the families go first; one holding only what
 * the index never lists (a tracked `.gitkeep`, a `.DS_Store`) has those put in
 * a slot of its own, never destroyed. Undone by making the folders again, the
 * shallowest first -- those that held no file a restore would not make; one
 * there again already (another tab made it) is fine -- then restoring the
 * slot, and each folder's.
 */
export function deleteFolderEdit(api: FilesApi, host: EditHost, label: string, paths: readonly string[], folders: readonly string[]): Edit {
  // How deep each is under the folder deleted, or under its twin: each side's top is the shortest of the list it is under.
  const depth = (f: string): number => {
    const top = folders.filter((o) => f === o || f.startsWith(o + '/')).sort((a, b) => a.length - b.length)[0] ?? f;
    return f.split('/').length - top.split('/').length;
  };
  const deepestFirst = [...folders].sort((a, b) => depth(b) - depth(a) || (a < b ? 1 : -1));
  let slot: string | undefined;
  /** The slots a folder's unlisted files went to: its `.gitkeep`, kept. */
  let kept: string[] = [];
  let restored: readonly string[] = paths;
  const down = async (list: readonly string[], alone: boolean): Promise<Answered | undefined> => {
    let last: Answered | undefined;
    slot = undefined;
    kept = [];
    if (list.length > 0) {
      const answer = await api.remove(list, alone);
      slot = answer.slot;
      last = answer;
    }
    for (const dir of deepestFirst) {
      try {
        const answer = await api.remove([dir]);
        if (answer.slot !== undefined) kept.push(answer.slot);
        last = answer;
      } catch (err) {
        throw named(dir, err);
      }
      host.gone?.(dir);
    }
    return last;
  };
  return {
    label,
    first: () => down(paths, false),
    redo: () => down(restored, true),
    async undo() {
      let last: Answered | undefined;
      for (const dir of [...deepestFirst].reverse()) {
        try {
          last = await api.mkdir(dir);
        } catch (err) {
          // There again -- another tab made it, or a restore did: as good as made.
          if (!exists(err)) throw named(dir, err);
        }
        host.made?.(dir);
      }
      if (slot !== undefined) {
        const answer = await api.restore(slot);
        restored = answer.restored;
        last = answer;
      }
      for (const k of kept) last = await api.restore(k);
      kept = [];
      return last;
    },
  };
}

// ---------------------------------------------------------------- folders, copies

/**
 * A new folder -- a pack, its twin under `AssetsSource/packs/` with it: `New
 * folder rigs`. Undone by deleting it, empty. One there already on disk and
 * empty -- the index lists files, so it was nowhere to be seen -- is shown, not
 * made, and its undo leaves it on disk. `twins`: the folders the pipeline makes
 * as it exports into one -- `src/assets/models/rigs` for a new
 * `AssetsSource/models/rigs` -- taken away with it where they are empty by then
 * (an import into it undone first), never where anything is in them.
 */
export function newFolderEdit(api: FilesApi, host: EditHost, folders: readonly string[], label = `New folder ${base(folders[0]!)}`, twins: readonly string[] = []): Edit {
  const there = new Set<string>();
  const make = async (): Promise<Answered | undefined> => {
    let last: Answered | undefined;
    for (const dir of folders) {
      try {
        last = await api.mkdir(dir);
      } catch (err) {
        if (!exists(err)) throw named(dir, err);
        there.add(dir);
      }
      host.made?.(dir);
    }
    return last;
  };
  return {
    label,
    first: make,
    redo: make,
    async undo() {
      let last: Answered | undefined;
      for (const dir of [...folders].reverse()) {
        if (!there.has(dir)) {
          try {
            last = await api.remove([dir]);
          } catch (err) {
            throw named(dir, err);
          }
        }
        host.gone?.(dir);
      }
      for (const twin of twins) {
        try {
          // Asked first (`GET names`: a folder there is a name taken), so one never made is no 404 of a delete.
          const cut = twin.lastIndexOf('/');
          const [there] = api.names ? await api.names(twin.slice(0, cut), [twin.slice(cut + 1)], { folder: true }) : [undefined];
          if (api.names && !(there && 'refused' in there && there.exists === true)) continue;
          last = await api.remove([twin]);
          host.gone?.(twin);
        } catch {
          // Something is in it: left as it is.
        }
      }
      return last;
    },
  };
}

/**
 * Each `[from, folder]` copied -- its family, both sides, a taken name made
 * `-2` -- into a folder: its own for a duplicate. Undone by trashing the
 * copies, one slot; redone by restoring it. `say(n)`: "Duplicate 3".
 */
export function copyEdit(api: FilesApi, host: EditHost, pairs: ReadonlyArray<readonly [string, string]>, say: (n: number) => string): Edit {
  const label = say(pairs.length);
  let made: string[] = [];
  let slot: string | undefined;
  let all = pairs.length;
  return {
    label,
    async first() {
      const run = await inOrder(pairs, (p) => api.copy(p[0], p[1]), (p) => p[0], host, label);
      made = run.done.flatMap(([, answer]) => answer.paths);
      all = run.done.length;
      return run.last;
    },
    async redo() {
      if (slot === undefined) throw new Error('the copies are not in the trash to bring back');
      const answer = await api.restore(slot, { replace: true });
      made = answer.restored;
      return answer;
    },
    async undo() {
      // Every path, gone or not: none there is the server's refusal, in its words ("none of these is there").
      const answer = await api.remove(made, true);
      slot = answer.slot;
      return answer;
    },
    named: () => say(all),
  };
}

// ---------------------------------------------------------------- restoring

/**
 * Trashed files back where they were -- of each slot its `paths`, or all of
 * it -- or, with `here`, then each moved into that folder: one step. Undone by
 * sending what came back to the trash, exactly those files, its slot kept:
 * redone by restoring that, which puts them where they were last.
 */
export function restoreEdit(api: FilesApi, host: EditHost, slots: ReadonlyArray<{ slot: string; paths?: readonly string[] }>, label: string, here?: string): Edit {
  let now: string[] = [];
  let again: string | undefined;
  return {
    label,
    async first() {
      let answer: Answered | undefined;
      for (const { slot, paths } of slots) {
        const back = await api.restore(slot, paths ? { paths } : {});
        now.push(...back.restored);
        answer = back;
      }
      if (here === undefined) return answer;
      // Each file asked for, as it came back (`-2` if its name was taken), into the folder.
      const run = await inOrder(now.filter((p) => !p.startsWith(`${here}/`)), (p) => api.move(p, `${here}/${base(p)}`).then((a) => (host.moved?.(p, `${here}/${base(p)}`), a)), (p) => p, host, label);
      const moved = new Map(run.done.map(([p]) => [p, `${here}/${base(p)}`]));
      now = now.map((p) => moved.get(p) ?? p);
      return run.last ?? answer;
    },
    async undo() {
      const answer = await api.remove(now, true);
      again = answer.slot;
      return answer;
    },
    async redo() {
      if (again === undefined) throw new Error('nothing to restore again');
      const answer = await api.restore(again);
      now = answer.restored;
      return answer;
    },
  };
}

// ---------------------------------------------------------------- an import

/** One file of an import, as the sheet sends it: its `PUT import`, its upload stoppable. */
export interface ImportSend {
  name: string;
  send(signal: AbortSignal): Promise<ImportAnswer>;
}

export interface ImportOptions {
  /** "Import 3 files", "Import robot.fbx": the plan's. */
  label: string;
  /** The folders it makes -- in no index before it, both sides -- the deepest first: its undo takes them away again (`newFolders`). */
  made?: readonly string[];
  /** The sheet's Close before every file is in. */
  signal: AbortSignal;
  /** Each file's end: its answer, or why not. */
  sent?(index: number, result: { answer: ImportAnswer } | { error: unknown }): void;
}

/**
 * A drop as one step (§5.7, §A.6): `PUT import` a file each, in order, a
 * refused one kept for Retry and the rest sent on; the step is of what was
 * written. Undone by trashing every family it wrote, one slot, then putting
 * back what each replaced, the last first, then removing the folders it made
 * (`made`), the deepest first -- each only if empty, one not there or not
 * empty left as it is -- so no empty folder is left on disk where the index
 * shows none; redone by restoring that slot, which makes them again -- no
 * upload, no export -- and trashing again what it had replaced.
 */
export function importEdit(api: FilesApi, host: EditHost, sends: readonly ImportSend[], options: ImportOptions): Edit {
  /** What each file wrote: its path, and the slot of what it replaced. */
  let written: Array<{ name: string; path: string; slot?: string }> = [];
  /** The paths in the index the step's undo takes off: what was written, or what a redo brought back. */
  let paths: string[] = [];
  /** The slots what it replaced is in, and the paths that came back from them on the last undo. */
  let replaced: string[] = [];
  let displaced: string[] = [];
  let slot: string | undefined;
  const stopped = (): Error => new Error('closed before every file was in: nothing was imported');
  return {
    label: options.label,
    async first() {
      let last: Answered | undefined;
      let failure: unknown;
      for (const [i, file] of sends.entries()) {
        if (options.signal.aborted) break;
        try {
          const answer = await file.send(options.signal);
          written.push({ name: file.name, path: answer.path, ...(answer.slot !== undefined ? { slot: answer.slot } : {}) });
          last = answer;
          options.sent?.(i, { answer });
        } catch (err) {
          if (options.signal.aborted) break;
          failure ??= named(file.name, err);
          options.sent?.(i, { error: err });
        }
      }
      if (options.signal.aborted) {
        // Nothing half-imported: what was written to the trash, what it replaced back.
        if (written.length > 0) await api.remove(written.map((w) => w.path));
        for (const w of [...written].reverse()) if (w.slot !== undefined) await api.restore(w.slot, { replace: true });
        written = [];
        throw stopped();
      }
      if (written.length === 0) throw failure ?? new Error('nothing was imported');
      paths = written.map((w) => w.path);
      replaced = written.flatMap((w) => (w.slot !== undefined ? [w.slot] : [])).reverse();
      if (written.length < sends.length) host.partial?.(`${options.label}: ${written.length} of ${sends.length} in; the rest keep their rows, with Retry`);
      return last;
    },
    async undo() {
      // The folders it made leave by this undo, not from disk: told first, so the open one gives way quietly.
      for (const dir of options.made ?? []) host.gone?.(dir);
      // Whole families: a source's record, intermediate and the export made since go with it -- a job still running is dropped.
      const gone = await api.remove(paths);
      slot = gone.slot;
      let last: Answered = gone;
      displaced = [];
      for (const s of replaced) {
        const answer = await api.restore(s, { replace: true });
        displaced.push(...answer.restored);
        last = answer;
      }
      for (const dir of options.made ?? []) {
        try {
          last = await api.remove([dir]);
        } catch (err) {
          // Not there (its side never had a file), or something else is in it now: left as it is.
          if (!refusal(err)) throw named(dir, err);
        }
      }
      return last;
    },
    async redo() {
      if (slot === undefined) throw new Error('the import is not in the trash to bring back');
      const back = await api.restore(slot, { replace: true });
      paths = back.restored;
      let last: Answered = back;
      // What it had replaced and the restore displaced is in that answer's slot; one at another path (a key's) is trashed again.
      const slots = back.slot !== undefined ? [back.slot] : [];
      const left = displaced.filter((p) => (host.has?.(p) ?? false) && !paths.includes(p));
      if (left.length > 0) {
        const again = await api.remove(left, true);
        if (again.slot !== undefined) slots.push(again.slot);
        last = again;
      }
      replaced = slots;
      return last;
    },
    named: () => (written.length === sends.length ? options.label : written.length === 1 ? `Import ${written[0]!.name}` : `Import ${files(written.length)}`),
  };
}
