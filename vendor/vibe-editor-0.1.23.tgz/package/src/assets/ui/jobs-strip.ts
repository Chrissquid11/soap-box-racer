/**
 * The files card's jobs strip (Docs/assets-tool.md §4): above the status line
 * while anything runs or has failed -- "exporting drone.fbx · draco · 2 of 3",
 * each job's progress on hover. A click on one opens its file's folder,
 * wherever that is, and selects the file. A failure stays, with **Show** (its
 * output, in the inspector) and ×, until dismissed; a `dropped` job leaves at
 * once, and so does a `skipped` one (its source current when its turn came:
 * nothing to do); a failure whose source is deleted leaves with it
 * (`forget`). A job parked for a game tab that this tab has claimed says
 * "converting in this tab", not "waiting for a game tab" (`converting`). Fed
 * by the `job` messages and by `GET jobs` (§9), which says what was running
 * before the tab came up -- an auto-export, another tab's import.
 *
 * A `job` message redraws the strip alone (`take`): the tool patches the one
 * tile's or row's mark itself (§9), and nothing else is drawn again.
 */
import type { JobInfo, JobMessage } from '@vibe/pipeline/assets-types';
import { baseName } from '@vibe/pipeline/paths';
import { isFound, recipeFor } from '@vibe/pipeline/recipes';
import { button, control, el } from '../../shell.ts';
import { jobEnded } from './marks.ts';

/** What the strip asks of the tool. */
export interface JobsHost {
  /** A job clicked: its file's folder opened, the file selected. */
  reveal(source: string): void;
  /** A failure's Show: the file selected, its output open in the inspector. */
  show(source: string): void;
  /** Something about several jobs changed -- a dismissal, `GET jobs` -- not one `job` message: the marks and the hint read again. */
  changed(): void;
  /** Is this job's browser step being done in this tab (`convert.ts` claimed it)? */
  converting(job: string): boolean;
}

export interface JobsStrip {
  readonly root: HTMLElement;
  /** A `job` message: the strip drawn again, nothing else told. */
  take(job: JobMessage): void;
  /** Sources `gone` says are gone from the index: their failures leave the strip, and the session's record of them. True if any did. */
  forget(gone: (source: string) => boolean): boolean;
  /** `GET jobs`: what is queued, running or parked now, in place of what was thought to be. */
  seed(jobs: readonly JobInfo[]): void;
  /** Is a job queued, running or parked for this source? Its mark is a spinner meanwhile. */
  running(source: string): boolean;
  /** The error a job for this source last failed with, this session. */
  failure(source: string): string | undefined;
  /** How many are queued, running or parked. */
  readonly busy: number;
  /** Drawn again: this tab took a conversion, or finished one. */
  redraw(): void;
}

interface Job {
  id: string;
  source: string;
  state: JobMessage['state'];
  step: number;
  of: number;
  error?: string;
  ms?: number;
}

/** Shown at most, then how many more. */
const SHOWN = 6;

/** A step's name, from the source's recipe: what the strip says it is at. */
function stepName(source: string, step: number): string | undefined {
  const recipe = recipeFor(source);
  return isFound(recipe) ? recipe.row.steps[step - 1] : undefined;
}

export function createJobsStrip(host: JobsHost): JobsStrip {
  const root = el('div', 'ed-as-jobs');
  root.hidden = true;
  const jobs = new Map<string, Job>();
  /** This session's failures, by source: kept for the inspector after the strip's line is dismissed. */
  const failures = new Map<string, string>();
  const live = (job: Job): boolean => !jobEnded(job.state);

  function said(job: Job): { text: string; title: string } {
    const name = baseName(job.source);
    switch (job.state) {
      case 'queued':
        return { text: `${name} · queued`, title: `${job.source}: waiting its turn` };
      case 'parked':
        return host.converting(job.id)
          ? { text: `${name} · converting in this tab`, title: `${job.source}: this tab is reading it with three's loader, then sends the .glb` }
          : { text: `${name} · waiting for a game tab`, title: `${job.source}: a step of it runs in a game tab, and none has taken it yet` };
      case 'failed':
        return { text: `✕ ${name} failed${job.error ? `: ${job.error}` : ''}`, title: `${job.source} failed${job.error ? `: ${job.error}` : ''}` };
      default: {
        const step = stepName(job.source, job.step);
        const at = job.of > 0 ? ` · ${step ? `${step} · ` : ''}${job.step} of ${job.of}` : '';
        return { text: `exporting ${name}${at}`, title: `${job.source}: step ${job.step} of ${job.of}${step ? `, ${step}` : ''}` };
      }
    }
  }

  function draw(): void {
    root.replaceChildren();
    const all = [...jobs.values()];
    root.hidden = all.length === 0;
    if (all.length === 0) return;
    root.append(el('span', 'ed-as-jobs-label', 'Jobs'));
    for (const job of all.slice(0, SHOWN)) {
      const { text, title } = said(job);
      const chip = el('span', job.state === 'failed' ? 'ed-as-job ed-as-red' : 'ed-as-job');
      const go = control('ui', 'ed-as-job-go', text);
      go.title = `${title} · click to show it`;
      go.addEventListener('click', () => host.reveal(job.source));
      chip.append(go);
      if (job.state === 'failed') {
        chip.append(
          button('ui', 'Show', 'Its output, in the inspector', () => host.show(job.source), 'ed-small ed-quiet'),
          button('ui', '×', 'Dismiss: its mark stays red until it is exported again', () => {
            jobs.delete(job.id);
            draw();
            host.changed();
          }, 'ed-small ed-quiet'),
        );
      }
      root.append(chip);
    }
    if (all.length > SHOWN) root.append(el('span', 'ed-dim', `+${all.length - SHOWN} more`));
  }

  return {
    root,
    take(message) {
      const job: Job = { id: message.id, source: message.source, state: message.state, step: message.step, of: message.of, ...(message.error ? { error: message.error } : {}), ...(message.ms !== undefined ? { ms: message.ms } : {}) };
      if (message.state === 'done' || message.state === 'dropped' || message.state === 'unmade' || message.state === 'skipped') {
        jobs.delete(message.id);
        if (message.state === 'done') failures.delete(message.source);
      } else {
        // A new job for a source drops its old failure: it is being tried again.
        for (const [id, old] of jobs) if (old.source === message.source && old.state === 'failed' && id !== message.id) jobs.delete(id);
        jobs.set(message.id, job);
        if (message.state === 'failed') failures.set(message.source, message.error ?? 'failed');
      }
      draw();
    },
    forget(gone) {
      let any = false;
      for (const source of [...failures.keys()]) {
        if (!gone(source)) continue;
        failures.delete(source);
        any = true;
      }
      for (const [id, job] of jobs) {
        if (live(job) || !gone(job.source)) continue;
        jobs.delete(id);
        any = true;
      }
      if (any) draw();
      return any;
    },
    seed(list) {
      for (const [id, job] of jobs) if (live(job)) jobs.delete(id);
      for (const info of list) {
        const had = jobs.get(info.id);
        jobs.set(info.id, { id: info.id, source: info.source, state: info.state, step: had?.step ?? 0, of: had?.of ?? 0 });
      }
      draw();
      host.changed();
    },
    running: (source) => [...jobs.values()].some((job) => job.source === source && live(job)),
    failure: (source) => failures.get(source),
    get busy() {
      return [...jobs.values()].filter(live).length;
    },
    redraw: draw,
  };
}
