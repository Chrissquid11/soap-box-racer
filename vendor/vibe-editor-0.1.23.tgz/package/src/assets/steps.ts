/**
 * The Assets tool's steps (Docs/assets.md §6, "Asynchronous steps"): every
 * one a call to the dev server, which can fail -- a file moved in the Finder,
 * the server stopped, a disk full -- on the tool's own `History`, whose
 * `undo()` and `redo()` are synchronous and move the step at once.
 *
 * - **One serial queue per tool instance.** The tool's own actions run through
 *   it (`run`), and a step's `undo()` and `redo()` queue their call and return
 *   at once, which is all `history.ts` asks. A call is **confirmed** when the
 *   client index has reached the `seq` of its response (`reached`): `live.ts`
 *   applies a response's diff the moment it comes, so the next call waits for
 *   the disk, not for the push channel's debounce.
 * - **A doing may make several calls** in order -- a drop of three files, a
 *   folder's delete -- and resolves with the last response; the step is
 *   confirmed when that one's `seq` is reached. A failure midway stops there,
 *   and its error names the file. A step's `do` and `undo` close over what
 *   the last response said -- its paths, its slot -- never what the step was
 *   made with: each call takes the slot the one before it answered.
 * - **The first doing is not on the stack.** While it runs `busy()` is true and
 *   `pending` is what the bar says ("Renaming crate → box …"); once confirmed,
 *   `asyncStep(label, do, undo)` is pushed, whose `do` is what Redo runs (for
 *   an import, a restore from the trash: no second upload). A first doing that
 *   fails leaves the stack as it was.
 * - **An undo or a redo is on the stack already**, so its label reads "Rename
 *   crate → box …" from the moment its call is queued until it is confirmed.
 * - **Busy means no Undo**: the host's Undo, Redo and a History travel do
 *   nothing while `busy()` (`active-history.ts`); a travel made while idle
 *   queues one call per step it crosses. The queue calls `history.touch()` as
 *   it goes from idle to busy and back, and as a pending label changes.
 * - **A first doing that finds nothing to change** throws `Unchanged`: no step
 *   is pushed, nothing is said, nothing is read again, and what is queued
 *   behind it goes on -- an option set to what it is already, the fourth of
 *   four arrow presses at the top of a range.
 * - **On a failure** the tool is told why ("Undo stopped at 'Rename crate →
 *   box': box.glb exists"); the calls queued behind are dropped unsent; the
 *   failed step and theirs are moved back in reverse queue order --
 *   `history.redo()` for a failed undo, `history.undo()` for a failed redo --
 *   under `restoring`, so their `undo()`/`redo()` make no call; and the index is
 *   read again (`reread`: `GET tree?since=`). No automatic retries. A step has
 *   no `size`: nothing of it is in memory.
 *
 * Imports `history.ts`'s types alone: a node test holds it (`steps.test.ts`).
 */
import type { History, Step } from '../history.ts';

/** What a doing resolves with: its last response, whose `seq` the index must reach -- or nothing to wait for. */
export interface Answered {
  seq: number;
}

/** One call or several, in order; throws on a refusal, saying the file. */
export type Doing = () => Promise<Answered | void>;

export interface StepsOptions {
  /** The tool's own stack: its `ToolInstance.history`. */
  history: History;
  /** Resolves once the client index has reached `seq` (`live.until`). */
  reached(seq: number): Promise<void>;
  /** After a failure: the index read again from the server (`live.refresh`). */
  reread(): Promise<void>;
  /** Why it stopped, said by the tool: "Undo stopped at 'Rename crate → box': box.glb exists". */
  failed?(message: string): void;
  /**
   * The stack's era, compared by identity: moved on when `history` becomes another's -- the Model tab opening
   * another model (`script-steps.ts`). A call queued under an older era moves `history` no more: a first doing not
   * yet started is dropped unsent (`false`); one that lands is handed to `stray` instead of pushed; a failed undo
   * or redo's put-back is `stray(era, null)` -- that era's stack no longer says what is on disk. None: one era.
   */
  era?(): unknown;
  /** A call of an older era ended: its step to keep with that era's stack, or null for one that stopped. */
  stray?(era: unknown, step: Step | null): void;
}

export interface Steps {
  /** Something is queued or under way: `ToolInstance.busy`. */
  busy(): boolean;
  /** What is under way, as the bar says it -- "Renaming crate → box …", "Undo Rename crate → box …" -- or null. */
  readonly pending: string | null;
  /** The stack is being put back after a failure: a step's `undo()` and `redo()` make no call. */
  readonly restoring: boolean;
  /**
   * A step's first doing, queued behind whatever is: once confirmed, `then` is
   * pushed as `asyncStep(label, then.do, then.undo)` -- named by `then.label()`
   * if it has one, read then: an import of three that wrote two is "Import 2
   * files". True once pushed; false, the stack as it was, if it failed or was
   * dropped behind a failure. `saying` is the bar's while it runs: `label …`
   * unless given.
   */
  run(label: string, first: Doing, then: { do: Doing; undo: Doing; label?: () => string }, saying?: string): Promise<boolean>;
  /** A step for the stack whose `undo()` and `redo()` queue their call: pushed by `run`, or by the tool itself. */
  asyncStep(label: string, redo: Doing, undo: Doing): Step;
}

/** A step of this queue's, and how many of its calls are queued or under way. */
interface Queued extends Step {
  calls: number;
}

/** One call in the queue: a first doing, or a step's undo or redo. */
interface Call {
  kind: 'first' | 'undo' | 'redo';
  label: string;
  saying: string;
  doing: Doing;
  step?: Queued;
  /** A first doing's: what to push, once confirmed. */
  then?: { do: Doing; undo: Doing; label?: () => string };
  /** A first doing's: told how it ended. */
  ended?: (pushed: boolean) => void;
  /** The stack's era as it was queued (`StepsOptions.era`). */
  era: unknown;
}

/** A first doing's word that there was nothing to do: no step, and no failure. */
export class Unchanged extends Error {}

/** A refusal's words, or an error's message: what follows the colon in the tool's line. */
export function reasonOf(err: unknown): string {
  const refused = (err as { body?: { refused?: unknown } } | null)?.body?.refused;
  if (typeof refused === 'string') return refused;
  return err instanceof Error ? err.message : String(err);
}

export function createSteps({ history, reached, reread, failed, era = () => null, stray }: StepsOptions): Steps {
  const queue: Call[] = [];
  let working = false;
  let restoring = false;

  /** The next call, and the one after, until none is left; a failure ends the run. */
  async function work(): Promise<void> {
    working = true;
    try {
      while (queue.length > 0) {
        const call = queue[0]!;
        if (call.kind === 'first' && call.era !== era()) {
          // Another model's now: its first doing is not sent -- it would write a file nobody is looking at.
          queue.shift();
          call.ended?.(false);
          continue;
        }
        try {
          const answer = await call.doing();
          if (answer) await reached(answer.seq);
        } catch (err) {
          if (err instanceof Unchanged && call.kind === 'first') {
            // Nothing to do: no step, and the rest go on.
            queue.shift();
            call.ended?.(false);
            continue;
          }
          // What was queued is gone; anything queued while the index was read again runs next.
          await fail(err);
          continue;
        }
        queue.shift();
        if (call.step) call.step.calls--;
        if (call.kind === 'first') {
          const step = steps.asyncStep(call.then!.label?.() ?? call.label, call.then!.do, call.then!.undo);
          // Landed after another model opened: the step is its own stack's, never the one in use now.
          if (call.era !== era()) {
            stray?.(call.era, step);
            call.ended?.(false);
          } else {
            history.push(step);
            call.ended?.(true);
          }
        }
        // A label back from pending: read again now if more is queued; the last call's is the `finally`'s touch.
        if (queue.length > 0) history.touch();
      }
    } finally {
      working = false;
      // Idle again, however it ended.
      history.touch();
    }
  }

  /** The failed call and every one behind it: said, dropped unsent, the stack put back; then the index read again. */
  async function fail(err: unknown): Promise<void> {
    const dropped = queue.splice(0);
    const head = dropped[0]!;
    const reason = reasonOf(err);
    const message = head.kind === 'first' ? `${head.label} failed: ${reason}` : `${head.kind === 'undo' ? 'Undo' : 'Redo'} stopped at '${head.label}': ${reason}`;
    for (const call of dropped) if (call.step) call.step.calls--;
    restoring = true;
    try {
      // The last queued first: each history move here takes back the latest one made.
      const now = era();
      for (let i = dropped.length - 1; i >= 0; i--) {
        const call = dropped[i]!;
        if (call.kind !== 'first' && call.era !== now) {
          // Its stack is put aside, or gone: this one's is not to move.
          stray?.(call.era, null);
          continue;
        }
        if (call.kind === 'undo') history.redo();
        else if (call.kind === 'redo') history.undo();
        else call.ended?.(false);
      }
    } finally {
      restoring = false;
    }
    failed?.(message);
    try {
      await reread();
    } catch {
      // The server gone too: `live.ts` says so on its own (`offline`).
    }
  }

  function enqueue(call: Call): void {
    const idle = !steps.busy();
    queue.push(call);
    if (call.step) call.step.calls++;
    // Idle to busy, or a label now pending: read again.
    if (idle || call.step) history.touch();
    if (!working) void work();
  }

  const steps: Steps = {
    busy: () => queue.length > 0 || working,
    get pending() {
      return queue[0]?.saying ?? null;
    },
    get restoring() {
      return restoring;
    },
    run(label, first, then, saying = `${label} …`) {
      return new Promise<boolean>((ended) => enqueue({ kind: 'first', label, saying, doing: first, then, ended, era: era() }));
    },
    asyncStep(label, redo, undo) {
      // Its name may be said better while it is on the stack (the Model tab's outside edit found a Claude turn's): set
      // `label`, then the history's `touch`.
      let name = label;
      const step: Queued = {
        calls: 0,
        get label() {
          return step.calls > 0 ? `${name} …` : name;
        },
        set label(next: string) {
          name = next;
        },
        undo() {
          if (restoring) return;
          enqueue({ kind: 'undo', label: name, saying: `Undo ${name} …`, doing: undo, step, era: era() });
        },
        redo() {
          if (restoring) return;
          enqueue({ kind: 'redo', label: name, saying: `Redo ${name} …`, doing: redo, step, era: era() });
        },
      };
      return step;
    },
  };
  return steps;
}
