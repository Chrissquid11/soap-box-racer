/**
 * The thumbnail queue and cache (Docs/assets.md §7, §8; part two §9): what a
 * tile and the inspector's 256 draw, made in the order the tool wants them,
 * and kept as object URLs for the session.
 *
 * - **`want(items)`**, in the order to make them -- the tool puts the selected
 *   file first (its preview's decode is used, not made again: `shown`), then
 *   the tiles in view, then the rest of the folder -- and a new order replaces
 *   the last: what was wanted and is not now is not made. What is under way
 *   finishes. `pause(on)` holds the queue while the preview plays a clip or is
 *   dragged; `holdMaking(on)` holds only what is made here -- a render, a
 *   decode -- while the grid scrolls: what is made already keeps coming, in
 *   view order, and what must be made waits for the hold to let go.
 * - **What a picture is of** (`from`, `scratch.ts`'s `previewPath` through the
 *   index): a `current` source's export -- a `.lua`, a `.blend`, an
 *   `.aseprite` has its export's thumbnail, made once for both -- else the file
 *   itself. `GET thumb` is asked for that; what comes back is kept under the
 *   item's own hash, or the hash learned for it, and a thumbnail made here is
 *   posted under the hash the server named for what it shows. A current
 *   source's item has no hash of its own: it is the export's picture, learned
 *   under the export's stamp (`thumbWantOf`), so a re-export -- which moves no
 *   source hash -- is asked again.
 * - **A master is never decoded for a strip** (part two §9): a sound on the
 *   Source side is drawn from its export when it is current, else it is its
 *   format's icon (`isMaster`); a 200 MB `.wav` is no tile's.
 * - **A hash the index has not** -- it hashes sources; an export's, a loose
 *   file's and a trashed file's are read when first asked -- is learned from
 *   `GET thumb`'s answer (the miss's `hash`, a hit's `ETag`) and told with
 *   `onReady`, kept by path with the item's `stamp` (its size and mtime): a
 *   file changed since is a new stamp, and asked again.
 * - **`GET thumb` first**: an image, a `.psd`, an `.xcf` or a `.kra` is made by
 *   the server, any thumbnail already made by anyone is a hit, and a model, a
 *   KTX2 or a sound is a miss, `{ make: 'browser', hash }` (asked for as a
 *   `200`, `THUMB_MISS_HEADER`, so the console stays quiet). Then it is made
 *   here, **one an animation frame, and none while paused** -- a model or a
 *   texture rendered (`renderer.ts`'s `capture`, to a render target), a sound's
 *   waveform strip from peaks at 256 columns (drawn by part two's
 *   `waveform.ts`, handed in as `strip`; the last peaks kept by hash, so its
 *   three sizes decode it once), each after a frame and the pause alike --
 *   and posted with `PUT thumb?hash=&size=` **only where `online` is
 *   `'write'`**, and only a WebP; elsewhere what is made stays in the LRU, and
 *   the cache on disk waits for a tab that may write.
 * - **The preview's own decode is borrowed, never kept across a wait**: taken
 *   after the frame is waited for, and if the preview has moved on and
 *   disposed it by then, the file is decoded again for the thumbnail -- a
 *   disposed scene drawn would upload GPU memory nothing frees.
 * - **Not again this session**: `{ none }` and a make that failed, by the
 *   content's hash -- a file fixed and saved again has a new one and is tried
 *   again. A rejection that is no `Error` (three's read-back, on a lost
 *   context) is no failure of the file's: it goes to the end of the order, at
 *   most twice more. `{ checking: true }` (not hashed yet) is asked again at
 *   the next `want`.
 * - **One LRU of object URLs**, 2000 or 64 MB, whichever first: `url(hash,
 *   size)` is a use, and the least recently used is revoked past that. The
 *   tool makes one `Thumbs` a session (as `assetApi()` is one), so a tile
 *   scrolled away and back, or the tab closed and opened, is drawn at once.
 *   After `dispose()` nothing is kept, posted or made an object URL of, a
 *   make under way included.
 * - **`ask(items)`: wanted beside the order** -- a key picker's model rows in
 *   the inspector (`thumbWhenReady`): made ahead of it, and kept across the
 *   tool's next `want` until each has been tried once.
 * - **A hidden tab stalls it**, by design: its frames are animation frames,
 *   which a hidden page does not have; it goes on when the tab is seen.
 *
 * Everything it touches is handed in -- the API, the renderer's `capture`, the
 * scratch decode, the frame clock, the object URLs -- so a node test drives it
 * with stand-ins (`thumbs.test.ts`).
 */
import type * as THREE from 'three';
import type { Entry } from '@vibe/pipeline/assets-types';
import { KINDS, SOUND_MASTERS, thumbMaker } from '@vibe/pipeline/kinds';
import { extOf, fromTrash, locate } from '@vibe/pipeline/paths';
import type { Api } from '../api.ts';
import type { Shown } from '../model.ts';
import { decodeSound, peaks, type Peaks, type Samples } from './audio.ts';
import type { Scratch } from './scratch.ts';

/**
 * A thumbnail wanted: a file at a size. `hash` the index's, when it has one
 * (a source's); else the server's answer says it -- an export's, a loose
 * file's, a trashed file's -- and it is learned for the file as `stamp` has it
 * (its size and mtime: `thumbStamp`), so a file changed since is asked again.
 */
export interface ThumbWant {
  hash?: string;
  path: string;
  size: number;
  stamp?: string;
}

/** How many columns a sound's strip is drawn from, whatever its size. */
export const STRIP_COLUMNS = 256;

/** Sounds the browser decodes: every audio kind's, and the masters `GET thumb` sends here -- the server's one list (`kinds.ts`). */
const SOUNDS: readonly string[] = [...KINDS.sfx.ext, ...SOUND_MASTERS];

/** What tells a file's content changed when the index has no hash of it: its size and mtime. */
export const contentStamp = (row: { size: number; mtime: number }): string => `${row.size}:${row.mtime}`;

/** A sound on the Source side -- a trashed one by the path it had: a master, never decoded for a tile's strip. */
export function isMaster(path: string): boolean {
  const had = fromTrash(path)?.path ?? path;
  return SOUNDS.includes(extOf(had)) && locate(had)?.root === 'source';
}

/**
 * The thumbnail a file's tile -- and its preview's 256 -- wants at `size`
 * (part two §9), `from` being what its picture is of (`previewPath`: a
 * current source's export, else itself); null for none to be had: a pointer,
 * a record, a format nobody draws, a master. A source whose picture is its
 * export's is asked for by its own path, with no hash -- the export's is
 * learned from the answer, under the export's stamp -- so a re-export, which
 * moves no source's hash, is asked again and its tile drawn new.
 */
export function thumbWantOf(row: Shown, size: number, from: string, at: (path: string) => Pick<Entry, 'size' | 'mtime'> | undefined): ThumbWant | null {
  if ('role' in row && (row.pointer === true || row.role === 'record')) return null;
  if (thumbMaker(extOf(fromTrash(from)?.path ?? from)) === 'none' || isMaster(from)) return null;
  if (from !== row.path) {
    const made = at(from);
    if (made) return { path: row.path, size, stamp: `${from} ${contentStamp(made)}` };
  }
  return 'hash' in row && row.hash !== undefined ? { hash: row.hash, path: row.path, size } : { path: row.path, size, stamp: contentStamp(row) };
}

/** A make whose capture was rejected by no fault of the file's -- a lost context -- is tried this many times more. */
const AGAIN = 2;

export interface ThumbsOptions {
  api: Pick<Api, 'online' | 'thumb' | 'putThumb' | 'file'>;
  /** A model or a texture as a WebP `size` on its longer side: the preview renderer's `capture`. */
  capture(size: number, what: THREE.Object3D | THREE.Texture): Promise<Blob>;
  /** A file decoded for its picture, registering nothing: `scratch.ts`'s `decodeScratch`. */
  decode(path: string): Promise<Scratch>;
  /** The preview's open decode, if any: a thumbnail of what it shows is made from it, and it is not disposed. */
  shown?(): Scratch | null;
  /** What a file's thumbnail is of -- `scratch.ts`'s `previewPath` through the index: a `current` source's export. Itself by default. */
  from?(path: string): string;
  /** A sound's strip as a WebP `size` across: part two's `waveform.ts`. Without it, a sound's thumbnail is not made here. */
  strip?(peaks: Peaks, size: number): Promise<Blob>;
  /** A sound's bytes decoded: `audio.ts`'s `decodeSound`, on an `OfflineAudioContext`. */
  decodeSound?(bytes: ArrayBuffer): Promise<Samples>;
  /** Resolves at the next animation frame: no more than one made a frame. */
  frame?(): Promise<void>;
  /** The LRU's bounds: 2000 thumbnails or 64 MB. */
  limits?: { count: number; bytes: number };
  /** Object URLs: `URL`'s. */
  urls?: { create(blob: Blob): string; revoke(url: string): void };
}

export interface Thumbs {
  /** The order to make them in, replacing the last order. */
  want(items: readonly ThumbWant[]): void;
  /** Wanted beside the order, ahead of it: kept across a `want` until each has been tried once (a key picker's rows). */
  ask(items: readonly ThumbWant[]): void;
  /** Hold the queue (a clip playing, the preview dragged), or let it go on. */
  pause(on: boolean): void;
  /** Hold what is made here -- a render, a decode -- while fetches of what is made already go on (the grid scrolling); let go, it is made. */
  holdMaking(on: boolean): void;
  /** The thumbnail's object URL, once made: a use, for the LRU. */
  url(hash: string, size: number): string | undefined;
  /** The hash an item's thumbnail is kept under: its own, or the one learned for it under its stamp; undefined until the server has said. */
  known(item: ThumbWant): string | undefined;
  /** Told each thumbnail made or fetched: the hash it is kept under and its size, and the path it was wanted for. Returns the undo. */
  onReady(fn: (hash: string, size: number, path: string) => void): () => void;
  /** Resolves when nothing is queued or under way. */
  idle(): Promise<void>;
  /** Every object URL revoked, the queue emptied: the session's end. Nothing is kept after it. */
  dispose(): void;
}

const LIMITS = { count: 2000, bytes: 64 * 1024 * 1024 };

/** The next animation frame: none while the tab is hidden, so the queue waits for it to be seen. */
const nextFrame = (): Promise<void> => new Promise((resolve) => requestAnimationFrame(() => resolve()));

/** Not a thumbnail now, nor later this session: the server has none, or making it failed. */
class NoThumb extends Error {}

/** To be made once the making hold lets go: put by, the queue going on with what is made already. */
class Later extends Error {}

/** How many sounds' peaks are kept by hash: their three sizes decoded once. */
const PEAKS_KEPT = 32;

export function createThumbs(options: ThumbsOptions): Thumbs {
  const { api } = options;
  const limits = options.limits ?? LIMITS;
  const urls = options.urls ?? { create: (blob: Blob) => URL.createObjectURL(blob), revoke: (url: string) => URL.revokeObjectURL(url) };
  const frame = options.frame ?? nextFrame;
  const decodeBytes = options.decodeSound ?? decodeSound;

  /** hash-size → its object URL, its bytes and the blob (another hash may want the same picture), least recently used first. */
  const kept = new Map<string, { url: string; bytes: number; blob: Blob }>();
  let bytes = 0;
  /** A file's hash the index has not, learned from the server's answer, with the stamp it was learned under: a new stamp, a new content. */
  const learned = new Map<string, { hash: string; stamp: string | undefined }>();
  const learn = (item: ThumbWant, hash: string): void => void learned.set(item.path, { hash, stamp: item.stamp });
  /** Of what has none, or failed: by content hash (or a trashed file's path) and size -- not asked again this session. */
  const none = new Set<string>();
  /** Each item's tries after a rejection that was no fault of its own. */
  const tries = new Map<string, number>();
  const ready = new Set<(hash: string, size: number, path: string) => void>();

  let order: ThumbWant[] = [];
  /** Asked beside the order (`ask`): first in every order until tried. */
  let asked: ThumbWant[] = [];
  /** Put by while making was held: back at the front of the order as it lets go. */
  let later: ThumbWant[] = [];
  /** A sound's peaks by the hash of what was decoded, the last few: its three sizes decode it once. */
  const peaksBy = new Map<string, Peaks>();
  let working = false;
  let paused = false;
  let making = true;
  let unpause: (() => void) | null = null;
  let idlers: Array<() => void> = [];
  let disposed = false;

  const id = (hash: string, size: number): string => `${hash}-${size}`;
  const hashOf = (item: ThumbWant): string | undefined => {
    if (item.hash !== undefined) return item.hash;
    const known = learned.get(item.path);
    return known && known.stamp === item.stamp ? known.hash : undefined;
  };
  /** What `none` and the tries know an item by: its content, so a file saved again is a new one. */
  const noneKey = (item: ThumbWant): string => `${hashOf(item) ?? item.path}\n${item.size}`;
  const have = (item: ThumbWant): boolean => {
    const hash = hashOf(item);
    return (hash !== undefined && kept.has(id(hash, item.size))) || none.has(noneKey(item));
  };

  /** Every listener told: a thumbnail is ready for `path`, kept under `hash`. */
  const tell = (hash: string, size: number, path: string): void => {
    for (const fn of ready) fn(hash, size, path);
  };

  function keep(hash: string, size: number, blob: Blob, path: string): void {
    // The session over: nothing made an object URL of, nothing told.
    if (disposed) return;
    const key = id(hash, size);
    const old = kept.get(key);
    if (old) {
      urls.revoke(old.url);
      bytes -= old.bytes;
      kept.delete(key);
    }
    kept.set(key, { url: urls.create(blob), bytes: blob.size, blob });
    bytes += blob.size;
    // The least recently used out, past either bound: the one just made stays.
    for (const [k, v] of kept) {
      if (kept.size <= limits.count && bytes <= limits.bytes) break;
      if (k === key) continue;
      urls.revoke(v.url);
      bytes -= v.bytes;
      kept.delete(k);
    }
    tell(hash, size, path);
  }

  /** Held while paused. */
  async function going(): Promise<void> {
    while (paused && !disposed) await new Promise<void>((resolve) => (unpause = resolve));
  }

  /** The thumbnail of `from` -- what `item`'s picture is of, `hash` its content -- made here: a model or a texture rendered, a sound's strip drawn. */
  async function make(from: string, size: number, hash: string): Promise<Blob> {
    // One a frame, a sound's as a model's, and none while the preview has the GPU's attention.
    await going();
    await frame();
    await going();
    if (disposed) throw new NoThumb('the queue was disposed');
    // The grid scrolling: nothing decoded or rendered now -- put by, made as it stops.
    if (!making) throw new Later();
    if (SOUNDS.includes(extOf(from))) {
      if (!options.strip) throw new NoThumb(`no waveform drawer handed in for ${from}`);
      if (isMaster(from)) throw new NoThumb(`${from} is a master: its strip is its export's`);
      let strip = peaksBy.get(hash);
      if (!strip) {
        const samples = await decodeBytes(await (await api.file(from)).arrayBuffer());
        strip = peaks(samples, STRIP_COLUMNS);
        peaksBy.set(hash, strip);
        for (const key of peaksBy.keys()) {
          if (peaksBy.size <= PEAKS_KEPT) break;
          peaksBy.delete(key);
        }
      }
      return options.strip(strip, size);
    }
    // The preview's decode, if it shows this file -- taken now, after the waits: it may have moved on and disposed it meanwhile.
    const open = options.shown?.() ?? null;
    const borrowed = open !== null && open.path === from && !open.disposed ? open : null;
    const scratch = borrowed ?? (await options.decode(from));
    try {
      // Our own decode took time: the preview may want the GPU again by now.
      if (!borrowed) await going();
      const what = scratch.scene ?? scratch.texture;
      if (!what) throw new NoThumb(`${from} decoded to nothing to draw`);
      // Rendered as `capture` is called, before its first wait: the borrowed decode is drawn while it is the preview's.
      return await options.capture(size, what);
    } finally {
      if (scratch !== borrowed) scratch.dispose();
    }
  }

  async function post(hash: string, size: number, blob: Blob): Promise<void> {
    if (disposed || blob.type !== 'image/webp' || (await api.online()) !== 'write') return;
    try {
      await api.putThumb(hash, size, blob);
    } catch (err) {
      console.warn(`[assets] a thumbnail made here was not kept on the server (${hash}-${size}):`, err);
    }
  }

  async function one(item: ThumbWant): Promise<void> {
    const from = options.from?.(item.path) ?? item.path;
    const answer = await api.thumb(from, item.size);
    if (disposed) return;
    if ('blob' in answer) {
      // Kept under the item's own hash, or -- none, a source shown by its export -- the one the answer says it shows.
      const hash = item.hash ?? answer.hash ?? hashOf(item);
      if (hash === undefined) return;
      if (item.hash === undefined) learn(item, hash);
      keep(hash, item.size, answer.blob, item.path);
      return;
    }
    const miss = answer.miss;
    // Not hashed yet: the index's next `changed` brings the hash, and the tool wants it again.
    if ('checking' in miss) return;
    if ('none' in miss) throw new NoThumb(miss.none);
    if (item.hash === undefined) learn(item, miss.hash);
    const mine = item.hash ?? miss.hash;
    // Made already, for itself or for another file it is the picture of (a source and its export).
    const made = kept.get(id(miss.hash, item.size));
    if (made) {
      if (mine !== miss.hash) keep(mine, item.size, made.blob, item.path);
      else tell(mine, item.size, item.path);
      return;
    }
    const blob = await make(from, item.size, miss.hash);
    keep(mine, item.size, blob, item.path);
    // Posted under the hash of what it shows: the next ask of either file is a hit.
    await post(miss.hash, item.size, blob);
  }

  async function work(): Promise<void> {
    working = true;
    try {
      while (order.length > 0 && !disposed) {
        await going();
        const item = order.shift();
        if (!item || have(item)) continue;
        try {
          await one(item);
          asked = asked.filter((a) => a !== item);
        } catch (err) {
          if (disposed) break;
          // Made later: the hold lets go, and it is first again.
          if (err instanceof Later) {
            later.push(item);
            continue;
          }
          asked = asked.filter((a) => a !== item);
          const key = noneKey(item);
          // No `Error` at all: three's read-back on a lost context. The file is not at fault: later, a few times.
          if (!(err instanceof Error) && (tries.get(key) ?? 0) < AGAIN) {
            tries.set(key, (tries.get(key) ?? 0) + 1);
            order.push(item);
            continue;
          }
          none.add(key);
          if (!(err instanceof NoThumb)) console.warn(`[assets] no thumbnail of ${item.path}:`, err);
        }
      }
    } finally {
      working = false;
      const waiting = idlers;
      idlers = [];
      for (const fn of waiting) fn();
    }
  }

  const thumbs: Thumbs = {
    want(items) {
      if (disposed) return;
      // A new order says what is wanted now, what was put by among it.
      later = [];
      asked = asked.filter((item) => !have(item));
      order = [...asked, ...items].filter((item) => !have(item));
      if (!working && order.length > 0) void work();
    },
    ask(items) {
      if (disposed) return;
      const fresh = items.filter((item) => !have(item) && !asked.some((a) => a.path === item.path && a.size === item.size && a.stamp === item.stamp && a.hash === item.hash));
      if (fresh.length === 0) return;
      asked.push(...fresh);
      order = [...fresh, ...order];
      if (!working) void work();
    },
    pause(on) {
      paused = on;
      if (!on) {
        const go = unpause;
        unpause = null;
        go?.();
      }
    },
    holdMaking(on) {
      making = !on;
      if (on || disposed) return;
      // Let go: what was put by first, as it was wanted, then the rest of the order.
      order = [...later.filter((item) => !have(item)), ...order];
      later = [];
      if (!working && order.length > 0) void work();
    },
    url(hash, size) {
      const key = id(hash, size);
      const hit = kept.get(key);
      if (!hit) return undefined;
      // A use: the most recent now.
      kept.delete(key);
      kept.set(key, hit);
      return hit.url;
    },
    known: (item) => hashOf(item),
    onReady(fn) {
      ready.add(fn);
      return () => void ready.delete(fn);
    },
    idle() {
      if (!working) return Promise.resolve();
      return new Promise((resolve) => idlers.push(resolve));
    },
    dispose() {
      disposed = true;
      order = [];
      later = [];
      asked = [];
      peaksBy.clear();
      for (const { url } of kept.values()) urls.revoke(url);
      kept.clear();
      bytes = 0;
      ready.clear();
      thumbs.pause(false);
    },
  };
  return thumbs;
}

/**
 * `item`'s thumbnail as an object URL from `thumbs` -- at once when it is kept,
 * else asked for (`ask`) and told when it is ready (`onReady`), or null once the
 * queue is idle without it: none to be had, or not now. A key picker's row
 * (`key-field.ts`), through the Assets tool's one queue -- so a model the panel
 * never drew is made, and a re-export, a new stamp, is asked again.
 */
export function thumbWhenReady(thumbs: Thumbs, item: ThumbWant): Promise<string | null> {
  const now = (): string | undefined => {
    const hash = thumbs.known(item);
    return hash === undefined ? undefined : thumbs.url(hash, item.size);
  };
  const hit = now();
  if (hit !== undefined) return Promise.resolve(hit);
  return new Promise((resolve) => {
    let done = false;
    const end = (url: string | null): void => {
      if (done) return;
      done = true;
      off();
      resolve(url);
    };
    const off = thumbs.onReady((hash, size, path) => {
      if (path === item.path && size === item.size) end(thumbs.url(hash, size) ?? null);
    });
    thumbs.ask([item]);
    void thumbs.idle().then(() => end(now() ?? null));
  });
}
