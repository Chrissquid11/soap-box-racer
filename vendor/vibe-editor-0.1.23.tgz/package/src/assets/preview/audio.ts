/**
 * A sound's preview (Docs/assets.md §7, §8): its waveform, and playing it.
 *
 * - **Decoded on an `OfflineAudioContext`** (`decodeSound`): no sound made, so
 *   never a gesture needed -- a tile's strip and the inspector's waveform come
 *   from it before the tab has been clicked. From the export when the source
 *   is `current` (`scratch.ts`'s `previewPath`): a 200 MB master decoded for a
 *   picture is a stall.
 * - **Peaks** (`peaks`, pure): each column's lowest and highest sample over
 *   every channel, what a waveform is drawn from; drawing it is part two's
 *   (`waveform.ts`), a tile's thumbnail included (`thumbs.ts`).
 * - **Played through the game's mixer** (`Audio.preview`, handed in as
 *   `Mixer`), on the ui bus, one at a time -- so `updateMute()` in `boot`
 *   still decides whether anything is heard. `at` is read each frame, for the
 *   cursor; nothing else is kept of where it is.
 * - **Two notes** the tool reads (`soundNote`): muted -- "muted in the game's
 *   settings" -- and, before the tab's first gesture (`Audio.running` false),
 *   "click once to enable sound".
 *
 * Imports the engine's `audio.ts`'s types alone (it reads `DEBUG_BUILD` as it loads): the
 * mixer is handed in, so a node test holds this file (`audio.test.ts`).
 */
import type { AudioPreview, PreviewOptions } from '@vibe/engine/assets';

/** What `peaks` reads of an `AudioBuffer`. */
export interface Samples {
  readonly numberOfChannels: number;
  readonly length: number;
  getChannelData(channel: number): Float32Array;
}

/** Each column's lowest and highest sample, -1..1, over every channel. */
export interface Peaks {
  readonly min: Float32Array;
  readonly max: Float32Array;
}

/**
 * The waveform at `columns` across: column `i` covers the samples from `i ×
 * length / columns` up to the next one's start, every channel together. A
 * sound shorter than `columns` samples gives each column the sample under it,
 * so a click still draws; silence, and no sound at all, are zero.
 */
export function peaks(buffer: Samples, columns: number): Peaks {
  const n = Math.max(0, Math.floor(columns));
  const min = new Float32Array(n);
  const max = new Float32Array(n);
  const { length, numberOfChannels } = buffer;
  if (length === 0 || numberOfChannels === 0) return { min, max };
  for (let c = 0; c < numberOfChannels; c++) {
    const data = buffer.getChannelData(c);
    for (let i = 0; i < n; i++) {
      const from = Math.floor((i * length) / n);
      const to = Math.max(from + 1, Math.floor(((i + 1) * length) / n));
      let lo = c === 0 ? Infinity : min[i]!;
      let hi = c === 0 ? -Infinity : max[i]!;
      for (let s = from; s < to && s < length; s++) {
        const v = data[s]!;
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
      min[i] = lo;
      max[i] = hi;
    }
  }
  return { min, max };
}

/** The rate a sound is decoded at for its waveform: most hardware's, so `Audio.preview` plays it unresampled there. */
export const SAMPLE_RATE = 48000;

/** A sound file's bytes decoded, with no sound made and no gesture needed. */
export async function decodeSound(bytes: ArrayBuffer): Promise<AudioBuffer> {
  return new OfflineAudioContext(1, 1, SAMPLE_RATE).decodeAudioData(bytes);
}

/** What the tool says over a sound's play button, or null for nothing. */
export type SoundNote = 'muted' | 'locked' | null;

/** The notes' words. */
export const NOTE_WORDS: Readonly<Record<Exclude<SoundNote, null>, string>> = {
  muted: "muted in the game's settings",
  locked: 'click once to enable sound',
};

/** What playing a sound needs of the game's mixer: `Audio`. */
export interface Mixer {
  preview(buffer: AudioBuffer, options?: PreviewOptions): AudioPreview;
  readonly isMuted: boolean;
  readonly running: boolean;
}

/** Why a sound played now would not be heard: muted, or the tab not yet clicked; null if it would be. */
export function soundNote(mixer: Pick<Mixer, 'isMuted' | 'running'>): SoundNote {
  if (mixer.isMuted) return 'muted';
  if (!mixer.running) return 'locked';
  return null;
}

/** A sound played for the preview: one at a time. */
export interface SoundPlayer {
  /** From `from` seconds (0), round and round with `loop`, at `gain` over the ui bus; the one playing stopped first. */
  play(buffer: AudioBuffer, options?: PreviewOptions): void;
  /** The one playing's level, set as it plays: the volume slider dragged, heard as it moves. */
  setGain(gain: number): void;
  stop(): void;
  /** Seconds into the sound: where the cursor is drawn, read each frame. */
  readonly at: number;
  /**
   * Still sounding: a loop until stopped, else until its end. Before the tab's
   * first gesture the context is suspended, so `at` stays at `from` and this
   * stays true until a click starts it: a play button reads `note` first
   * ('locked': "click once to enable sound") and says so rather than playing.
   */
  readonly playing: boolean;
  /** What to say over it now. */
  readonly note: SoundNote;
}

export function createSoundPlayer(mixer: Mixer): SoundPlayer {
  let handle: AudioPreview | null = null;
  let playing: { buffer: AudioBuffer; loop: boolean } | null = null;
  /** Where it stopped, so the cursor stays there. */
  let left = 0;
  return {
    play(buffer, options = {}) {
      handle?.stop();
      handle = mixer.preview(buffer, options);
      playing = { buffer, loop: options.loop ?? false };
    },
    setGain(gain) {
      if (handle) handle.gain = gain;
    },
    stop() {
      if (handle) left = handle.at;
      handle?.stop();
      handle = null;
      playing = null;
    },
    get at() {
      return handle ? handle.at : left;
    },
    get playing() {
      return handle !== null && playing !== null && (playing.loop || handle.at < playing.buffer.duration);
    },
    get note() {
      return soundNote(mixer);
    },
  };
}
