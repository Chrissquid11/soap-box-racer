/**
 * The one preview renderer (Docs/assets.md §7, §8): a `THREE.WebGLRenderer` of
 * its own, which shows one thing at a time -- a model, or a texture (a KTX2)
 * on a quad -- with the controls the Assets tool draws buttons over, and which
 * renders thumbnails for `thumbs.ts` to a render target.
 *
 * - **The interface is the tool's** (part two §6): `show(scene, clips?)` or
 *   `show(texture)`; `frame()`; `setWireframe`, `setSkeleton`, `setBackfaces`;
 *   `clips()`, `play(name | null, { speed, loop })`, `seek(t)`, `time`,
 *   `duration`; a texture's `actual()` (1:1), `zoom` and `setChannels` (a
 *   colour matrix on the quad, never on a thumbnail); `info()` -- the
 *   triangles counted from the geometry, so a wireframe says the same, the
 *   draw calls from `renderer.info` less the grid's and the skeleton's;
 *   `on('frame', fn)`, told each frame drawn, so a scrubber follows a clip;
 *   `capture(size, what?)`, a WebP
 *   of a model or a texture to a `WebGLRenderTarget`, read back -- the canvas
 *   never touched, what is shown never moved. The tool holds no three.js
 *   object of its own.
 * - **Its canvas is placed by the caller** (`mount(parent)`, `unmount()`): in
 *   the inspector's preview block while a model or a KTX2 is shown, out of the
 *   page otherwise. It fills its parent, kept to its size by a
 *   `ResizeObserver`.
 * - **Blender's navigation**, as every 3D view of the editor has it
 *   (`view/navigation.ts`, Docs/navigation.md): the middle button -- and here,
 *   with nothing to select, the left one too -- orbits a model, Shift pans,
 *   Ctrl zooms; a right drag does nothing; any drag pans a texture. The wheel is
 *   `preventDefault`ed -- the panel does not scroll -- and read as the scene's
 *   is: a pinch zooms, two fingers orbit (pan a texture), Shift pans, a mouse
 *   wheel zooms, Ctrl and Shift with it pan. Its own orbit, not a `ViewCamera`:
 *   a texture is shown here too, and every thumbnail framed the same way.
 * - **A ground grid and a neutral light rig**: a hemisphere and a key light
 *   (an OBJ's or an FBX's Phong materials see no environment), and three's
 *   `RoomEnvironment` for the standard ones. Its background is transparent:
 *   the panel's own shows through, a checkerboard under a texture.
 * - **On demand**: a frame is drawn when something changes -- a drag draws as
 *   the pointer moves, not while it is held still -- and every frame only
 *   while a clip plays.
 * - **Never `Assets.useRenderer`**, which would make this the context the KTX2
 *   loader asks: same GPU, same answer, and the game's is there first.
 * - **Remade on its own `webglcontextlost`**: a second context of a browser's
 *   sixteen or so may be the one taken. A new canvas and renderer where the
 *   old ones were, the same thing shown; three uploads it all again. One that
 *   cannot be made (the GPU gone for good) is said in the console, not
 *   thrown, and tried again at the next `mount`.
 * - **`dispose()` gives the context back** (`forceContextLoss`): three's own
 *   `dispose` frees its objects, not the context, and Chrome counts a context
 *   until it is collected -- past sixteen it drops the oldest, which is the
 *   game's.
 * - **A texture's thumbnail is never enlarged**: drawn at most its own size in
 *   the middle of the square, as the server's never scale up.
 *
 * The orbit, the framing and the wheel's zoom are pure functions at the top
 * (`renderer.test.ts`); nothing touches the DOM until `createPreviewRenderer`.
 */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { sizeOf } from '@vibe/engine';
import { loadPrefs, type WheelMode } from '../../prefs.ts';
import { GESTURE, wheelDevice, type WheelLast } from '../../wheel.ts';
import { dragZoom, macPlatform, navigates, pressAction, wheelAction, wheelZoom, type PressAction } from '../../view/navigation.ts';

// ---------------------------------------------------------------- the orbit, pure

/** Where the camera is: round `target`, `radius` off, `theta` round the up axis from +Z, `phi` down from straight above. */
export interface Orbit {
  target: THREE.Vector3;
  radius: number;
  theta: number;
  phi: number;
}

/** A three-quarter view from above: where a framing looks from, and every thumbnail. */
export const VIEW = { theta: Math.PI / 4, phi: 1.05 } as const;
/** Framing leaves this much room round what it frames. */
export const MARGIN = 1.15;
/** A zoom goes no nearer than this share of the framed distance, and no further than this many times it. */
const ZOOM_IN = 0.05;
const ZOOM_OUT = 20;

/** The view's up for `orbit`: Y, or -Y past a pole (`sin(phi)` under 0) -- so the image goes on smoothly over the top. */
export function upOf(orbit: Orbit, out = new THREE.Vector3()): THREE.Vector3 {
  return out.set(0, Math.sin(orbit.phi) < 0 ? -1 : 1, 0);
}

/** The camera's place for `orbit`, into `out`. */
export function eye(orbit: Orbit, out = new THREE.Vector3()): THREE.Vector3 {
  const s = Math.sin(orbit.phi);
  return out.set(s * Math.sin(orbit.theta), Math.cos(orbit.phi), s * Math.cos(orbit.theta)).multiplyScalar(orbit.radius).add(orbit.target);
}

/**
 * The orbit that frames `bounds` from `view`: round its middle, near enough that
 * its bounding sphere fills the narrower of the two fields of view, with
 * `margin` round it. An empty box frames a unit one at the origin.
 */
export function framed(bounds: THREE.Box3, fov: number, aspect: number, view: { theta: number; phi: number } = VIEW, margin = MARGIN): Orbit {
  const box = bounds.isEmpty() ? new THREE.Box3(new THREE.Vector3(-0.5, -0.5, -0.5), new THREE.Vector3(0.5, 0.5, 0.5)) : bounds;
  const sphere = box.getBoundingSphere(new THREE.Sphere());
  const r = Math.max(sphere.radius, 1e-3);
  const v = THREE.MathUtils.degToRad(fov);
  const h = 2 * Math.atan(Math.tan(v / 2) * aspect);
  return { target: sphere.center.clone(), radius: (r * margin) / Math.sin(Math.min(v, h) / 2), theta: view.theta, phi: view.phi };
}

/**
 * Round the target, as a drag of (`dx`, `dy`) pixels on a view `height` tall turns it (OrbitControls' measure) -- with
 * no limit, as every 3D view of the editor (Docs/navigation.md §6): over the top `phi` goes past 0 or π and the view is
 * upside down (`upOf`), never flipping at a pole.
 */
export function turn(orbit: Orbit, dx: number, dy: number, height: number, reverse = upOf(orbit).y): void {
  const h = Math.max(height, 1);
  // Upside down as the gesture began (`reverse` -1), across the other way: the model still follows the pointer (Blender's).
  orbit.theta -= (2 * Math.PI * dx * reverse) / h;
  orbit.phi -= (2 * Math.PI * dy) / h;
}

/** Nearer (`scale` < 1) or further, kept within what the framing allows (`framedRadius`). */
export function zoom(orbit: Orbit, scale: number, framedRadius: number): void {
  orbit.radius = THREE.MathUtils.clamp(orbit.radius * scale, framedRadius * ZOOM_IN, framedRadius * ZOOM_OUT);
}

const right = new THREE.Vector3();
const up = new THREE.Vector3();
const forward = new THREE.Vector3();

/** The target moved with the pointer, as a drag of (`dx`, `dy`) pixels on a view `height` tall at `fov` degrees moves what is under it. */
export function pan(orbit: Orbit, dx: number, dy: number, height: number, fov: number): void {
  const perPixel = (2 * orbit.radius * Math.tan(THREE.MathUtils.degToRad(fov) / 2)) / Math.max(height, 1);
  eye(orbit, forward).sub(orbit.target).normalize().negate();
  right.crossVectors(forward, upOf(orbit, up)).normalize();
  up.crossVectors(right, forward).normalize();
  orbit.target.addScaledVector(right, -dx * perPixel).addScaledVector(up, dy * perPixel);
}

/**
 * The triangles `object` draws: each visible mesh's, by its index (or its
 * vertices) within its draw range, times its instances. Counted from the
 * geometry, so a wireframe -- which three counts as lines -- says the same.
 */
export function trianglesOf(object: THREE.Object3D): number {
  let n = 0;
  object.traverseVisible((o) => {
    const mesh = o as THREE.Mesh & Partial<THREE.InstancedMesh>;
    if (!mesh.isMesh || !mesh.geometry) return;
    const g = mesh.geometry;
    const all = g.index ? g.index.count : (g.getAttribute('position')?.count ?? 0);
    const from = Math.min(Math.max(g.drawRange.start, 0), all);
    const drawn = Math.min(all - from, g.drawRange.count);
    n += Math.floor(drawn / 3) * (mesh.isInstancedMesh ? (mesh.count ?? 1) : 1);
  });
  return n;
}

/** A texture's scale -- screen pixels a texel -- that fits `tw`×`th` into a view `vw`×`vh`, with `margin` round it. */
export function fitScale(tw: number, th: number, vw: number, vh: number, margin = MARGIN): number {
  if (tw <= 0 || th <= 0 || vw <= 0 || vh <= 0) return 1;
  return Math.min(vw / tw, vh / th) / margin;
}

/** The grid's span under a model `radius` across: a power of ten at least four times it, in tenths. */
export function gridSpan(radius: number): number {
  return Math.pow(10, Math.ceil(Math.log10(Math.max(radius * 4, 1e-3))));
}

/**
 * A texture of one level under a mipmap filter, drawn as the file's picture:
 * from that level (`LinearFilter`). Such a KTX2 -- uncompressed, its mipmaps
 * left to the runtime, which three does not make for one handed in by level --
 * is stored with a chain whose levels below the first are never filled, so a
 * draw smaller than its size samples nothing: an empty thumbnail, a preview
 * gone below 100%. The preview's and the thumbnail's own decode only, never the
 * game's; what the game will draw is the `mips` warning's to say (`warnings.ts`).
 * True if it changed it.
 */
export function wholeLevel(texture: THREE.Texture): boolean {
  const mipmapped = texture.minFilter !== THREE.NearestFilter && texture.minFilter !== THREE.LinearFilter;
  if (!mipmapped || (texture.mipmaps?.length ?? 0) !== 1) return false;
  texture.minFilter = THREE.LinearFilter;
  texture.generateMipmaps = false;
  texture.needsUpdate = true;
  return true;
}

/**
 * A texture `width`×`height` on a thumbnail `size` square, as a share of the
 * square each way: fitted inside it by its longer side, and never enlarged --
 * a small one drawn at its own size in the middle, as the server's are.
 */
export function thumbScale(width: number, height: number, size: number): { x: number; y: number } {
  const w = Math.max(1, width);
  const h = Math.max(1, height);
  const k = Math.min(1, size / Math.max(w, h));
  return { x: (w * k) / size, y: (h * k) / size };
}

/**
 * A render target's RGBA rows, bottom up and with their colour scaled by
 * coverage, as an image's: top down, straight alpha. The colour divided out is
 * sRGB-encoded (the target stores sRGB), so a soft edge's comes out a little
 * off from a linear division -- fine for a thumbnail.
 */
export function asImage(pixels: Uint8Array, size: number): Uint8ClampedArray<ArrayBuffer> {
  const out = new Uint8ClampedArray(size * size * 4);
  const row = size * 4;
  for (let y = 0; y < size; y++) {
    const from = (size - 1 - y) * row;
    for (let x = 0; x < row; x += 4) {
      const a = pixels[from + x + 3]!;
      const k = a > 0 && a < 255 ? 255 / a : 1;
      out[y * row + x] = pixels[from + x]! * k;
      out[y * row + x + 1] = pixels[from + x + 1]! * k;
      out[y * row + x + 2] = pixels[from + x + 2]! * k;
      out[y * row + x + 3] = a;
    }
  }
  return out;
}

// ---------------------------------------------------------------- the renderer

export interface ClipOptions {
  /** 1 is as authored. */
  speed?: number;
  /** Round and round; else once, held at its end. Default true. */
  loop?: boolean;
}

export interface PreviewInfo {
  triangles: number;
  calls: number;
}

export interface PreviewRenderer {
  /** Its canvas now (a new one after a lost context). */
  readonly canvas: HTMLCanvasElement;
  /** The canvas into `parent`, filling it. */
  mount(parent: HTMLElement): void;
  /** The canvas out of the page; what is shown kept. */
  unmount(): void;
  /** A model: its scene (the preview's own -- shown, never disposed here) and its clips. */
  show(scene: THREE.Object3D, clips?: readonly THREE.AnimationClip[]): void;
  /** A texture on a quad: a KTX2, or any. */
  show(texture: THREE.Texture): void;
  /** Nothing shown. */
  clear(): void;
  /** The view put back where it frames what is shown. */
  frame(): void;
  /** A texture at one texel a CSS pixel, round its middle; a model framed. */
  actual(): void;
  /** A texture's zoom: CSS pixels a texel (1 for a model). */
  readonly zoom: number;
  /**
   * A texture's channels through a colour matrix -- `feColorMatrix`'s twenty
   * numbers, four rows of four and an offset -- on the quad alone, never on a
   * thumbnail; null for the texture as it is.
   */
  setChannels(matrix: readonly number[] | null): void;
  setWireframe(on: boolean): void;
  setSkeleton(on: boolean): void;
  setBackfaces(on: boolean): void;
  /** The shown model's clips, by name. */
  clips(): string[];
  /** A clip played from where it is (from the start if it ended), or, with null, paused where it is. */
  play(name: string | null, options?: ClipOptions): void;
  /** The clip playing, or paused, or the first, at `t` seconds. */
  seek(t: number): void;
  readonly time: number;
  readonly duration: number;
  readonly playing: boolean;
  /** What is shown: its triangles, and the last frame's draw calls of it. */
  info(): PreviewInfo;
  /** Told after each frame drawn. Returns the undo. */
  on(event: 'frame', fn: () => void): () => void;
  /**
   * `what` -- what is shown, by default -- as a WebP `size` on a side, from the
   * view every thumbnail has, rendered to a render target and read back.
   */
  capture(size: number, what?: THREE.Object3D | THREE.Texture): Promise<Blob>;
  /** The context and everything of its own let go. */
  dispose(): void;
}

/** The two lights every model is seen by: from above and the sky, and a key light from the front and side. */
function lightRig(): THREE.Object3D[] {
  // A white face under all three comes to about 1: lit, never clipped, its sides told apart.
  const sky = new THREE.HemisphereLight('#ffffff', '#6a6a6a', 0.8);
  const key = new THREE.DirectionalLight('#ffffff', 1.5);
  key.position.set(3, 5, 4);
  return [sky, key];
}

/** A shown model's materials as they were: what wireframe and backfaces go back to. */
type Looks = Map<THREE.Material, { wireframe: boolean; side: THREE.Side }>;

function looksOf(object: THREE.Object3D): Looks {
  const looks: Looks = new Map();
  object.traverse((o) => {
    const material = (o as Partial<THREE.Mesh>).material;
    if (!material) return;
    for (const m of Array.isArray(material) ? material : [material]) {
      if (!looks.has(m)) looks.set(m, { wireframe: (m as THREE.MeshBasicMaterial).wireframe === true, side: m.side });
    }
  });
  return looks;
}

/** Each material wireframe or not, double-sided or as it was. */
function wear(looks: Looks, wireframe: boolean, backfaces: boolean): void {
  for (const [m, was] of looks) {
    const side = backfaces ? THREE.DoubleSide : was.side;
    if ('wireframe' in m) (m as THREE.MeshBasicMaterial).wireframe = wireframe || was.wireframe;
    if (m.side !== side) {
      m.side = side;
      m.needsUpdate = true;
    }
  }
}

/** Is it drawn upside down on a plane: a KTX2 (compressed, or raw data) keeps its rows top down and is never flipped on upload. */
function rowsDown(texture: THREE.Texture): boolean {
  const image = texture.image as unknown;
  const bitmap = typeof ImageBitmap !== 'undefined' && image instanceof ImageBitmap;
  return !texture.flipY && !bitmap;
}

/** A texture's size as `store.ts` reads it, held to at least a texel each way: what a quad is scaled by. */
function texels(texture: THREE.Texture): { width: number; height: number } {
  const { width, height } = sizeOf(texture);
  return { width: Math.max(1, width), height: Math.max(1, height) };
}

/** RGBA pixels as a WebP (a PNG where the browser cannot write WebP: `thumbs.ts` then keeps it unposted). */
async function encode(pixels: Uint8ClampedArray<ArrayBuffer>, size: number): Promise<Blob> {
  const image = new ImageData(pixels, size, size);
  if (typeof OffscreenCanvas !== 'undefined') {
    const canvas = new OffscreenCanvas(size, size);
    canvas.getContext('2d')!.putImageData(image, 0, 0);
    return canvas.convertToBlob({ type: 'image/webp', quality: 0.9 });
  }
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  canvas.getContext('2d')!.putImageData(image, 0, 0);
  return new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('the thumbnail could not be encoded'))), 'image/webp', 0.9));
}

export function createPreviewRenderer(): PreviewRenderer {
  const FOV = 40;
  let gl: THREE.WebGLRenderer;
  let environment: THREE.Texture | null = null;

  // What is shown: a model in `stage` (under `holder`), or a texture on `quad` in `flat`.
  const stage = new THREE.Scene();
  stage.environmentIntensity = 0.35;
  stage.add(...lightRig());
  const holder = new THREE.Group();
  stage.add(holder);
  const grid = new THREE.GridHelper(1, 10, '#8a8a8a', '#5c5c5c');
  (grid.material as THREE.Material).transparent = true;
  (grid.material as THREE.Material).opacity = 0.5;
  stage.add(grid);
  const camera = new THREE.PerspectiveCamera(FOV, 1, 0.01, 1000);

  const flat = new THREE.Scene();
  // Both sides -- a KTX2's rows are flipped by a negative scale -- in one pass: three draws a transparent double-sided material twice otherwise.
  const quad = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ transparent: true, side: THREE.DoubleSide, forceSinglePass: true, toneMapped: false }));
  // The channels shown (`setChannels`): the sampled colour through a matrix, the identity by default.
  const channels = { value: new THREE.Matrix4() };
  const channelOffset = { value: new THREE.Vector4() };
  // Alpha is data, not colour: shown as grey it is decoded first, so the output's sRGB encoding gives back its own value.
  const fromAlpha = { value: 0 };
  quad.material.onBeforeCompile = (shader) => {
    shader.uniforms.uChannels = channels;
    shader.uniforms.uChannelOffset = channelOffset;
    shader.uniforms.uFromAlpha = fromAlpha;
    shader.fragmentShader = `uniform mat4 uChannels;\nuniform vec4 uChannelOffset;\nuniform float uFromAlpha;\n${shader.fragmentShader.replace(
      '#include <map_fragment>',
      '#include <map_fragment>\n\tdiffuseColor = uChannels * diffuseColor + uChannelOffset;\n\tif (uFromAlpha > 0.5) diffuseColor.rgb = sRGBTransferEOTF(vec4(diffuseColor.rgb, 1.0)).rgb;',
    )}`;
  };
  flat.add(quad);
  const flatCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, -10, 10);

  // Thumbnails: their own scene and lights, the thing borrowed into it for the render.
  const shoot = new THREE.Scene();
  shoot.environmentIntensity = stage.environmentIntensity;
  shoot.add(...lightRig());
  const shootCamera = new THREE.PerspectiveCamera(FOV, 1, 0.01, 1000);
  const shootQuad = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ transparent: true, side: THREE.DoubleSide, forceSinglePass: true, toneMapped: false }));
  const shootFlatScene = new THREE.Scene();
  shootFlatScene.add(shootQuad);
  const shootFlat = new THREE.OrthographicCamera(-0.5, 0.5, 0.5, -0.5, -10, 10);
  const targets = new Map<number, THREE.WebGLRenderTarget>();

  type Shown =
    | { kind: 'model'; object: THREE.Object3D; clips: readonly THREE.AnimationClip[]; bounds: THREE.Box3; radius: number; triangles: number; looks: Looks; mixer: THREE.AnimationMixer | null }
    | { kind: 'texture'; texture: THREE.Texture; width: number; height: number };
  let shown: Shown | null = null;
  let action: THREE.AnimationAction | null = null;
  let orbit: Orbit = framed(new THREE.Box3(), FOV, 1);
  let framedRadius = orbit.radius;
  /** A texture's view: screen pixels a texel, and the texel under the middle. */
  const flatView = { scale: 1, x: 0, y: 0 };
  /** Nobody has moved the view since it was framed: a resize frames it again. */
  let untouched = true;
  let wireframe = false;
  let backfaces = false;
  let skeleton: THREE.SkeletonHelper | null = null;
  let skeletonOn = false;
  let lastInfo: PreviewInfo = { triangles: 0, calls: 0 };
  const listeners = new Set<() => void>();
  let width = 0;
  let height = 0;

  // ---- drawing, on demand
  let raf = 0;
  let last = 0;
  /** The context could not be made again after a loss: tried once more at the next `mount`. */
  let broken = false;
  const playing = (): boolean => action !== null && !action.paused && action.enabled && action.isRunning();

  const invalidate = (): void => {
    if (raf === 0 && typeof requestAnimationFrame !== 'undefined') raf = requestAnimationFrame(tick);
  };

  function tick(now: number): void {
    raf = 0;
    // Out of the page: nothing drawn, the clock stopped; `mount` asks for a frame again.
    if (!gl.domElement.isConnected) {
      last = 0;
      return;
    }
    const dt = last === 0 ? 0 : Math.min((now - last) / 1000, 0.1);
    last = now;
    if (shown?.kind === 'model' && shown.mixer && playing()) shown.mixer.update(dt);
    draw();
    // A clip playing draws every frame; a drag draws as the pointer moves (`move`), never while it is held still.
    if (playing()) invalidate();
    else last = 0;
  }

  function draw(): void {
    if (!gl.domElement.isConnected || width === 0 || height === 0 || !shown) return;
    if (shown.kind === 'model') {
      eye(orbit, camera.position);
      upOf(orbit, camera.up);
      camera.lookAt(orbit.target);
      camera.near = Math.max(orbit.radius / 100, 1e-4);
      camera.far = orbit.radius + gridSpan(shown.radius);
      camera.updateProjectionMatrix();
      gl.render(stage, camera);
    } else {
      flatCamera.left = -width / 2;
      flatCamera.right = width / 2;
      flatCamera.top = height / 2;
      flatCamera.bottom = -height / 2;
      flatCamera.zoom = flatView.scale;
      flatCamera.position.set(flatView.x, flatView.y, 5);
      flatCamera.updateProjectionMatrix();
      gl.render(flat, flatCamera);
    }
    // The draws of what is shown: the grid's and the skeleton's are the preview's own.
    const helpers = shown.kind === 'model' ? 1 + (skeleton ? 1 : 0) : 0;
    lastInfo = { triangles: shown.kind === 'model' ? shown.triangles : 2, calls: Math.max(0, gl.info.render.calls - helpers) };
    for (const fn of listeners) fn();
  }

  // ---- the canvas: made, sized, listened to, remade
  const resize = new ResizeObserver((records) => {
    const box = records[records.length - 1]!.contentRect;
    width = Math.round(box.width);
    height = Math.round(box.height);
    if (width === 0 || height === 0) return;
    gl.setSize(width, height, false);
    camera.aspect = width / height;
    if (untouched) frameNow();
    invalidate();
  });

  let pointer: { id: number; x: number; y: number; does: PressAction } | null = null;
  let wheelLast: WheelLast | null = null;
  let wheelMode: WheelMode = loadPrefs().wheel;

  const onDown = (e: PointerEvent): void => {
    if (!shown || pointer) return;
    e.preventDefault();
    // The rule's, with nothing to select: a right press is no drag; a texture pans whatever the button.
    const does = pressAction(e, loadPrefs().nav, { mac: macPlatform(), selects: false });
    if (!navigates(does)) return;
    gl.domElement.setPointerCapture(e.pointerId);
    pointer = { id: e.pointerId, x: e.clientX, y: e.clientY, does: shown.kind === 'texture' ? 'pan' : does };
    // The orbit's way for the whole drag, from the up as it began.
    turnWay = upOf(orbit).y;
    wheelMode = loadPrefs().wheel;
  };
  const onMove = (e: PointerEvent): void => {
    if (!pointer || e.pointerId !== pointer.id) return;
    const dx = e.clientX - pointer.x;
    const dy = e.clientY - pointer.y;
    pointer.x = e.clientX;
    pointer.y = e.clientY;
    if (pointer.does === 'zoom' && shown?.kind === 'model') {
      untouched = false;
      zoom(orbit, dragZoom(dy), framedRadius);
      invalidate();
      return;
    }
    move(pointer.does === 'pan' ? 'pan' : 'orbit', dx, dy);
  };
  const onUp = (e: PointerEvent): void => {
    if (!pointer || e.pointerId !== pointer.id) return;
    pointer = null;
  };
  const onWheel = (e: WheelEvent): void => {
    e.preventDefault();
    if (!shown) return;
    // The preference read again as a gesture starts: the keys card may have changed it.
    if (!wheelLast || e.timeStamp - wheelLast.at > GESTURE) {
      wheelMode = loadPrefs().wheel;
      turnWay = upOf(orbit).y;
    }
    const device = wheelDevice(e, wheelMode, wheelLast);
    wheelLast = { device, at: e.timeStamp };
    const does = wheelAction(e, device);
    if (does.kind === 'zoom') {
      untouched = false;
      const scale = wheelZoom(e, device);
      if (shown.kind === 'model') zoom(orbit, scale, framedRadius);
      else flatView.scale = THREE.MathUtils.clamp(flatView.scale / scale, 1 / 64, 64);
      invalidate();
      return;
    }
    move(does.kind === 'orbit' && shown.kind === 'model' ? 'orbit' : 'pan', does.dx, does.dy);
  };
  const onMenu = (e: Event): void => e.preventDefault();
  // Not `preventDefault`ed: that asks the browser to restore this context, which is abandoned for a new one.
  const onLost = (): void => void setTimeout(remake, 0);

  /** The horizontal orbit's way for the gesture under way: -1 begun upside down. */
  let turnWay = 1;
  function move(how: 'orbit' | 'pan', dx: number, dy: number): void {
    if (!shown) return;
    untouched = false;
    if (shown.kind === 'texture') {
      flatView.x -= dx / flatView.scale;
      flatView.y += dy / flatView.scale;
    } else if (how === 'orbit') turn(orbit, dx, dy, height, turnWay);
    else pan(orbit, dx, dy, height, FOV);
    invalidate();
  }

  function listen(canvas: HTMLCanvasElement, on: boolean): void {
    if (on) {
      canvas.addEventListener('pointerdown', onDown);
      canvas.addEventListener('pointermove', onMove);
      canvas.addEventListener('pointerup', onUp);
      canvas.addEventListener('pointercancel', onUp);
      canvas.addEventListener('contextmenu', onMenu);
      canvas.addEventListener('webglcontextlost', onLost);
      canvas.addEventListener('wheel', onWheel, { passive: false });
    } else {
      canvas.removeEventListener('pointerdown', onDown);
      canvas.removeEventListener('pointermove', onMove);
      canvas.removeEventListener('pointerup', onUp);
      canvas.removeEventListener('pointercancel', onUp);
      canvas.removeEventListener('contextmenu', onMenu);
      canvas.removeEventListener('webglcontextlost', onLost);
      canvas.removeEventListener('wheel', onWheel);
    }
  }

  function make(): THREE.WebGLRenderer {
    const made = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    made.setPixelRatio(Math.min(devicePixelRatio, 2));
    made.setClearColor(0x000000, 0);
    const canvas = made.domElement;
    canvas.style.display = 'block';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.touchAction = 'none';
    listen(canvas, true);
    // The room's light, for standard materials: made on this context, again on the next.
    const pmrem = new THREE.PMREMGenerator(made);
    const room = new RoomEnvironment();
    environment = pmrem.fromScene(room, 0.04).texture;
    room.dispose();
    pmrem.dispose();
    stage.environment = shoot.environment = environment;
    if (width > 0 && height > 0) made.setSize(width, height, false);
    return made;
  }

  function remake(): void {
    const old = gl;
    const oldEnvironment = environment;
    listen(old.domElement, false);
    resize.unobserve(old.domElement);
    // A target's GL storage was the old context's: made again on the new one when next asked for.
    for (const target of targets.values()) target.dispose();
    targets.clear();
    try {
      gl = make();
    } catch (err) {
      // The GPU gone for good, for now: said, not thrown from a timer -- and tried again at the next mount.
      broken = true;
      console.warn('[assets] the preview\'s WebGL context was lost and could not be made again: it is tried again as a preview is next shown', err);
      return;
    }
    broken = false;
    if (old.domElement.parentElement) {
      old.domElement.replaceWith(gl.domElement);
      resize.observe(gl.domElement);
    }
    oldEnvironment?.dispose();
    old.dispose();
    console.info('[assets] the preview\'s WebGL context was lost: made again');
    invalidate();
  }

  gl = make();

  // ---- what is shown
  function frameNow(): void {
    if (!shown) return;
    untouched = true;
    if (shown.kind === 'model') {
      orbit = framed(shown.bounds, FOV, width > 0 && height > 0 ? width / height : 1);
      framedRadius = orbit.radius;
    } else {
      flatView.scale = fitScale(shown.width, shown.height, width, height);
      flatView.x = flatView.y = 0;
    }
  }

  function dropSkeleton(): void {
    if (!skeleton) return;
    skeleton.removeFromParent();
    skeleton.dispose();
    skeleton = null;
  }

  function placeSkeleton(): void {
    dropSkeleton();
    if (!skeletonOn || shown?.kind !== 'model') return;
    let bones = false;
    shown.object.traverse((o) => void (bones ||= (o as THREE.Bone).isBone === true));
    if (!bones) return;
    skeleton = new THREE.SkeletonHelper(shown.object);
    stage.add(skeleton);
  }

  function clear(): void {
    if (shown?.kind === 'model') {
      shown.mixer?.stopAllAction();
      shown.mixer?.uncacheRoot(shown.object);
      wear(shown.looks, false, false);
      holder.remove(shown.object);
    } else if (shown?.kind === 'texture') {
      quad.material.map = null;
      quad.material.needsUpdate = true;
    }
    dropSkeleton();
    action = null;
    shown = null;
    lastInfo = { triangles: 0, calls: 0 };
    if (gl.domElement.isConnected) {
      gl.clear();
      for (const fn of listeners) fn();
    }
  }

  function clipAction(name?: string): THREE.AnimationAction | null {
    if (shown?.kind !== 'model' || !shown.mixer) return null;
    const clip = name === undefined ? shown.clips[0] : shown.clips.find((c) => c.name === name);
    return clip ? shown.mixer.clipAction(clip) : null;
  }

  async function capture(size: number, what?: THREE.Object3D | THREE.Texture): Promise<Blob> {
    const thing = what ?? (shown?.kind === 'model' ? shown.object : shown?.texture);
    if (!thing) throw new Error('nothing to capture');
    let target = targets.get(size);
    if (!target) {
      // sRGB storage: the GPU encodes what the shaders write (linear) as it stores it, so the bytes read back are an image's.
      target = new THREE.WebGLRenderTarget(size, size, { colorSpace: THREE.SRGBColorSpace, samples: 4 });
      targets.set(size, target);
    }
    gl.setRenderTarget(target);
    gl.setClearColor(0x000000, 0);
    gl.clear();
    if ((thing as THREE.Texture).isTexture) {
      const texture = thing as THREE.Texture;
      // A picture of the file: a one-level texture from its level, not an empty minified draw.
      wholeLevel(texture);
      const { width: w, height: h } = texels(texture);
      // Fitted by its longer side, never enlarged: a 64×32 at 256 is 64×32 in the middle of the square.
      const scale = thumbScale(w, h, size);
      shootQuad.material.map = texture;
      shootQuad.material.needsUpdate = true;
      shootQuad.scale.set(scale.x, scale.y * (rowsDown(texture) ? -1 : 1), 1);
      gl.render(shootFlatScene, shootFlat);
      shootQuad.material.map = null;
    } else {
      const object = thing as THREE.Object3D;
      const home = object.parent;
      // What is shown, as it was made: no wireframe, its own sides.
      const looks = shown?.kind === 'model' && shown.object === object ? shown.looks : null;
      if (looks) wear(looks, false, false);
      shoot.add(object);
      object.updateMatrixWorld(true);
      const view = framed(new THREE.Box3().setFromObject(object), FOV, 1);
      eye(view, shootCamera.position);
      shootCamera.lookAt(view.target);
      shootCamera.near = Math.max(view.radius / 1000, 1e-4);
      shootCamera.far = view.radius * 10;
      shootCamera.updateProjectionMatrix();
      gl.render(shoot, shootCamera);
      // Back where it was, before anything else can draw it.
      if (home) home.add(object);
      else shoot.remove(object);
      if (looks) wear(looks, wireframe, backfaces);
    }
    gl.setRenderTarget(null);
    const pixels = new Uint8Array(size * size * 4);
    await gl.readRenderTargetPixelsAsync(target, 0, 0, size, size, pixels);
    return encode(asImage(pixels, size), size);
  }

  const preview: PreviewRenderer = {
    get canvas() {
      return gl.domElement;
    },
    mount(parent) {
      // Lost and not made again last time: once more, now that a preview is wanted.
      if (broken) remake();
      parent.append(gl.domElement);
      resize.observe(gl.domElement);
      invalidate();
    },
    unmount() {
      resize.unobserve(gl.domElement);
      gl.domElement.remove();
      pointer = null;
    },
    show(what: THREE.Object3D | THREE.Texture, clips: readonly THREE.AnimationClip[] = []) {
      clear();
      if ((what as THREE.Texture).isTexture) {
        const texture = what as THREE.Texture;
        // Below 100% too: drawn from its one level, as its thumbnail is.
        wholeLevel(texture);
        const { width: w, height: h } = texels(texture);
        quad.material.map = texture;
        quad.material.needsUpdate = true;
        quad.scale.set(w, rowsDown(texture) ? -h : h, 1);
        shown = { kind: 'texture', texture, width: w, height: h };
      } else {
        const object = what as THREE.Object3D;
        holder.add(object);
        object.updateMatrixWorld(true);
        const bounds = new THREE.Box3().setFromObject(object);
        const looks = looksOf(object);
        const radius = bounds.isEmpty() ? 1 : bounds.getBoundingSphere(new THREE.Sphere()).radius;
        shown = { kind: 'model', object, clips, bounds, radius, triangles: trianglesOf(object), looks, mixer: clips.length > 0 ? new THREE.AnimationMixer(object) : null };
        wear(looks, wireframe, backfaces);
        grid.scale.setScalar(gridSpan(radius));
        grid.position.set(bounds.isEmpty() ? 0 : (bounds.min.x + bounds.max.x) / 2, bounds.isEmpty() ? 0 : bounds.min.y, bounds.isEmpty() ? 0 : (bounds.min.z + bounds.max.z) / 2);
        placeSkeleton();
      }
      frameNow();
      invalidate();
    },
    clear,
    frame() {
      frameNow();
      invalidate();
    },
    actual() {
      if (shown?.kind !== 'texture') return preview.frame();
      untouched = false;
      flatView.scale = 1;
      flatView.x = flatView.y = 0;
      invalidate();
    },
    get zoom() {
      return shown?.kind === 'texture' ? flatView.scale : 1;
    },
    setChannels(m) {
      if (!m) {
        channels.value.identity();
        channelOffset.value.set(0, 0, 0, 0);
        fromAlpha.value = 0;
      } else {
        const at = (i: number): number => m[i] ?? 0;
        channels.value.set(at(0), at(1), at(2), at(3), at(5), at(6), at(7), at(8), at(10), at(11), at(12), at(13), at(15), at(16), at(17), at(18));
        channelOffset.value.set(at(4), at(9), at(14), at(19));
        // The colour read from alpha alone.
        fromAlpha.value = at(3) !== 0 && at(0) === 0 && at(1) === 0 && at(2) === 0 ? 1 : 0;
      }
      invalidate();
    },
    setWireframe(on) {
      wireframe = on;
      if (shown?.kind === 'model') wear(shown.looks, wireframe, backfaces);
      invalidate();
    },
    setSkeleton(on) {
      skeletonOn = on;
      placeSkeleton();
      invalidate();
    },
    setBackfaces(on) {
      backfaces = on;
      if (shown?.kind === 'model') wear(shown.looks, wireframe, backfaces);
      invalidate();
    },
    clips() {
      return shown?.kind === 'model' ? shown.clips.map((c) => c.name) : [];
    },
    play(name, { speed = 1, loop = true } = {}) {
      if (name === null) {
        if (action) action.paused = true;
        invalidate();
        return;
      }
      const next = clipAction(name);
      if (!next) return;
      if (action && action !== next) action.stop();
      action = next;
      const ended = !loop && action.time >= action.getClip().duration;
      if (ended || !action.enabled) action.reset();
      action.setLoop(loop ? THREE.LoopRepeat : THREE.LoopOnce, Infinity);
      action.clampWhenFinished = true;
      action.timeScale = speed;
      action.paused = false;
      action.play();
      last = 0;
      invalidate();
    },
    seek(t) {
      action ??= clipAction();
      if (!action || shown?.kind !== 'model' || !shown.mixer) return;
      if (!action.isScheduled()) {
        action.paused = true;
        action.play();
      }
      action.enabled = true;
      action.time = THREE.MathUtils.clamp(t, 0, action.getClip().duration);
      shown.mixer.update(0);
      invalidate();
    },
    get time() {
      return action?.time ?? 0;
    },
    get duration() {
      return action?.getClip().duration ?? (shown?.kind === 'model' ? (shown.clips[0]?.duration ?? 0) : 0);
    },
    get playing() {
      return playing();
    },
    info() {
      return { ...lastInfo };
    },
    on(_event, fn) {
      listeners.add(fn);
      return () => void listeners.delete(fn);
    },
    capture,
    dispose() {
      if (raf !== 0) cancelAnimationFrame(raf);
      raf = 0;
      clear();
      preview.unmount();
      resize.disconnect();
      // Unheard first, so the loss below is not taken for one to remake from.
      listen(gl.domElement, false);
      for (const target of targets.values()) target.dispose();
      targets.clear();
      environment?.dispose();
      grid.dispose();
      quad.geometry.dispose();
      quad.material.dispose();
      shootQuad.geometry.dispose();
      shootQuad.material.dispose();
      // The context given back now, not when it is collected: Chrome drops the oldest past sixteen, and that is the game's.
      gl.forceContextLoss();
      gl.dispose();
      listeners.clear();
    },
  };
  return preview;
}
