/**
 * Three's loader for each model format a source may be in (Docs/assets.md §7):
 * one table, `PREVIEWERS`, for the preview and for the browser's conversion
 * (`convert.ts`, §8) alike. Each row imports its loader when first asked, so
 * none of them is in a build -- and inside `packages/editor/src/`, none is in a
 * release at all.
 *
 * A previewer loads one URL into `{ scene, animations }`. Its own files -- an
 * FBX's textures, an OBJ's `.mtl` and its images -- are asked for through the
 * `LoadingManager` it is given, whose URL modifier sends each to `GET file`.
 * A format three has a loader for is one row here (§11): `usdz` with
 * `USDZLoader`, say.
 */
import * as THREE from 'three';

/** A model loaded: its scene, and its clips. */
export interface Loaded {
  scene: THREE.Object3D;
  animations: THREE.AnimationClip[];
}

export interface Previewer {
  load(url: string, manager?: THREE.LoadingManager): Promise<Loaded>;
}

/** A three loader of anything: made with a manager, asked for one URL. */
type LoaderClass<T> = new (manager?: THREE.LoadingManager) => { loadAsync(url: string): Promise<T> };

/** What a loader gives, as a scene and its clips: a glTF or a Collada's `{ scene, animations }`, an FBX's `Group` with its own. */
function asLoaded(result: unknown): Loaded {
  const r = result as THREE.Object3D & { scene?: THREE.Object3D };
  if (r.scene) return { scene: r.scene, animations: (r as { animations?: THREE.AnimationClip[] }).animations ?? [] };
  return { scene: r, animations: r.animations ?? [] };
}

/** A loader that gives a model. */
export function model(Loader: LoaderClass<unknown>): Previewer {
  return { load: async (url, manager) => asLoaded(await new Loader(manager).loadAsync(url)) };
}

/** A loader that gives a bare geometry (STL): a mesh of it, in its own colours if it has any. */
export function geometry(Loader: LoaderClass<THREE.BufferGeometry>): Previewer {
  return {
    async load(url, manager) {
      const shape = await new Loader(manager).loadAsync(url);
      if (!shape.hasAttribute('normal')) shape.computeVertexNormals();
      const scene = new THREE.Group();
      scene.add(new THREE.Mesh(shape, new THREE.MeshStandardMaterial({ vertexColors: shape.hasAttribute('color') })));
      return { scene, animations: [] };
    },
  };
}

/** Each model source format's previewer, by its lowercase extension. */
export const PREVIEWERS: Record<string, () => Promise<Previewer>> = {
  fbx: () => import('three/addons/loaders/FBXLoader.js').then(({ FBXLoader }) => model(FBXLoader)),
  obj: () => import('./obj.ts').then((m) => m.objWithMtl),
  dae: () => import('three/addons/loaders/ColladaLoader.js').then(({ ColladaLoader }) => model(ColladaLoader)),
  stl: () => import('three/addons/loaders/STLLoader.js').then(({ STLLoader }) => geometry(STLLoader)),
  gltf: () => import('three/addons/loaders/GLTFLoader.js').then(({ GLTFLoader }) => model(GLTFLoader)),
  glb: () => import('three/addons/loaders/GLTFLoader.js').then(({ GLTFLoader }) => model(GLTFLoader)),
};
