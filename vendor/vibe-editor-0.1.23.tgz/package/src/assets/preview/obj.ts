/**
 * An OBJ with its materials (Docs/assets.md §7, `PREVIEWERS`' `obj` row):
 * three's `OBJLoader` alone draws every face grey, so the file is read first
 * for its `mtllib`, the `.mtl` loaded with `MTLLoader` -- its images through the
 * same manager, so `GET file` serves them -- and the OBJ parsed with those
 * materials. A `.mtl` that is not there, or does not load, leaves it grey: a
 * preview, not a failure.
 */
import * as THREE from 'three';
import type { Loaded, Previewer } from './previewers.ts';

export const objWithMtl: Previewer = {
  async load(url: string, manager?: THREE.LoadingManager): Promise<Loaded> {
    const [{ OBJLoader }, { MTLLoader }] = await Promise.all([import('three/addons/loaders/OBJLoader.js'), import('three/addons/loaders/MTLLoader.js')]);
    const text = (await new THREE.FileLoader(manager).loadAsync(url)) as string;
    const loader = new OBJLoader(manager);
    const library = /^\s*mtllib\s+(.+?)\s*$/m.exec(text)?.[1];
    if (library !== undefined) {
      try {
        const materials = await new MTLLoader(manager).loadAsync(library);
        materials.preload();
        loader.setMaterials(materials);
      } catch (err) {
        console.warn(`[assets] ${library} did not load: the model is drawn without its materials`, err);
      }
    }
    return { scene: loader.parse(text), animations: [] };
  },
};
