/**
 * A preview's own decode (Docs/assets.md §7): a file read into three.js
 * objects that belong to the preview alone -- never the store's, which the game
 * is drawing, and which a preview's `dispose()` would blank -- and disposed
 * when the preview moves on.
 *
 * - **What is decoded** (`previewPath`): a source's export when the source is
 *   `current` -- what the game will draw, and small -- the source itself only
 *   otherwise; any other file, itself.
 * - **An export goes through the game's own loaders** (`store.ts`'s
 *   `decodeModel` and `decodeTexture`, registering nothing): the Draco, KTX2
 *   and meshopt shims, the colour space and filtering, what the game will
 *   see. A model's images found as at boot (`resolveBeside`), by name beside it
 *   or in its root's `textures/`, among the index's files and through `GET
 *   file`. A KTX2 from its bytes, by a name that says so.
 * - **A source goes through its format's previewer** (`PREVIEWERS`), its parts
 *   fetched through `GET file` by the `LoadingManager`'s URL modifier, and it
 *   resolves once the textures that load after the model are in -- an OBJ's
 *   MTL images, an FBX's -- one that never does taken off (`convert.ts`'s
 *   `loadWhole`, the browser conversion's own way): its thumbnail is captured
 *   the moment it resolves, and must not be a black model.
 * - **One preview at a time** (`createScratchStore`): `open` decodes the next,
 *   and the one before is disposed as it lands -- or fails; a decode a later
 *   `open` overtook is disposed the moment it arrives, never shown, and one
 *   that fails answers null as well. `close` disposes what is open. A
 *   `Scratch` is disposed once, however often asked; a skinned model's
 *   skeleton with it (`store.ts`'s `disposeModel`).
 *
 * The decoders are handed in for a node test (`scratch.test.ts`); by default
 * they are `store.ts`'s and `PREVIEWERS`. No DOM at module level.
 */
import * as THREE from 'three';
import type { GLTF } from 'three/addons/loaders/GLTFLoader.js';
import type { Entry } from '@vibe/pipeline/assets-types';
import { KINDS, ROOTS, type KindName } from '@vibe/pipeline/kinds';
import { extOf, fromTrash, locate } from '@vibe/pipeline/paths';
import { decodeModel, decodeTexture, disposeModel, extrasOntoClips, type Lookup, type Resolve, resolveBeside, type Source, type TextureUse } from '@vibe/engine';
import type { Api } from '../api.ts';
import { loadWhole } from '../convert.ts';
import { PREVIEWERS, type Loaded, type Previewer } from './previewers.ts';

/** How long a source's own textures are waited for before it is shown without the ones still out: a preview, not an export. */
const WHOLE_MS = 15000;

/** What a preview of `entry` is made from: a `current` source's export (its keyed one), else the file itself. */
export function previewPath(entry: Pick<Entry, 'path' | 'role' | 'status' | 'exports'>): string {
  const keyed = entry.exports?.[0];
  return entry.role === 'source' && entry.status === 'current' && keyed !== undefined ? keyed : entry.path;
}

/** Model formats the game ships: decoded as the game decodes them on the shipping side. */
const GAME_MODELS: readonly string[] = KINDS.models.ext;
/** Images the game decodes (and a KTX2): one texture, on either side. */
const IMAGES: readonly string[] = KINDS.textures.ext;

/** How a file is decoded here: a model or a texture, through the game's loaders or its source format's previewer. */
export interface Decoding {
  as: 'model' | 'texture';
  through: 'game' | 'previewer';
}

/**
 * How `path` is decoded, or null for nothing this decodes (a `.lua`, a
 * sound, a `.psd`: an export, the server's thumbnail, or the format's icon). A
 * file in the trash goes by the path it had.
 */
export function decodingOf(path: string): Decoding | null {
  const had = fromTrash(path)?.path ?? path;
  const ext = extOf(had);
  if (IMAGES.includes(ext)) return { as: 'texture', through: 'game' };
  const ships = locate(had)?.root !== 'source';
  if (ships && GAME_MODELS.includes(ext)) return { as: 'model', through: 'game' };
  if (PREVIEWERS[ext] !== undefined) return { as: 'model', through: 'previewer' };
  return null;
}

/** A file decoded for a preview: a model's scene and clips, or a texture -- the preview's own. */
export interface Scratch {
  readonly path: string;
  readonly through: 'game' | 'previewer';
  readonly scene: THREE.Object3D | null;
  readonly animations: readonly THREE.AnimationClip[];
  readonly texture: THREE.Texture | null;
  readonly disposed: boolean;
  /** Its geometry, materials and textures freed: once, however often called. */
  dispose(): void;
}

/** What decodes: `store.ts`'s and `PREVIEWERS` by default. */
export interface ScratchDecoders {
  model(source: Source, resolve?: Resolve): Promise<Pick<GLTF, 'scene' | 'animations'>>;
  texture(source: Source, use: TextureUse): Promise<THREE.Texture>;
  previewer(ext: string): Promise<Previewer> | undefined;
  /** Every geometry, material and texture under `scene`, freed. */
  disposeScene(scene: THREE.Object3D): void;
}

export const GAME_DECODERS: ScratchDecoders = {
  model: decodeModel,
  texture: decodeTexture,
  previewer: (ext) => PREVIEWERS[ext]?.(),
  // `disposeModel` reads the scene alone: a previewer's loads are walked the same way.
  disposeScene: (scene) => disposeModel({ scene } as GLTF),
};

export interface ScratchOptions {
  api: Pick<Api, 'fileUrl' | 'file'>;
  /** The client index's entry at a path: where a model's images are looked for, and a source's parts. */
  entryAt(path: string): Entry | undefined;
  decoders?: ScratchDecoders;
}

/**
 * How an export's image URIs resolve, as at boot (`beside.ts`): by name beside
 * it, then in its root's `textures/` -- among the files the index has, each
 * through `GET file`. Undefined for a file not under a shipping root's
 * `models/` (a trashed one: nothing beside it is indexed).
 */
function besideOf(path: string, { api, entryAt }: ScratchOptions): Resolve | undefined {
  const where = locate(path);
  if (!where || where.root === 'source' || where.kind !== 'models' || where.under === undefined) return undefined;
  const base = where.root === 'boot' ? ROOTS.boot.dir : `${ROOTS.packs.dir}/${where.pack}`;
  const lookup: Lookup = (kind, under) => {
    const file = `${base}/${KINDS[kind].dir}/${under}`;
    return entryAt(file) ? api.fileUrl(file) : undefined;
  };
  const key = where.under.replace(/\.[^.]+$/, '');
  return (uri) => resolveBeside(key, uri, lookup);
}

/** What a texture is for: an atlas's sheet is finished nearest, as the game finishes it. */
function useOf(path: string): TextureUse {
  const kind: KindName | undefined = locate(fromTrash(path)?.path ?? path)?.kind;
  return kind === 'atlases' ? 'atlas' : 'texture';
}

function made(path: string, through: 'game' | 'previewer', parts: { scene?: THREE.Object3D; animations?: THREE.AnimationClip[]; texture?: THREE.Texture }, free: () => void): Scratch {
  let disposed = false;
  return {
    path,
    through,
    scene: parts.scene ?? null,
    animations: parts.animations ?? [],
    texture: parts.texture ?? null,
    get disposed() {
      return disposed;
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      free();
    },
  };
}

/** `path` decoded for a preview, registering nothing. Rejects for a file this does not decode (`decodingOf`). */
export async function decodeScratch(path: string, options: ScratchOptions): Promise<Scratch> {
  const { api, entryAt } = options;
  const decoders = options.decoders ?? GAME_DECODERS;
  const how = decodingOf(path);
  if (!how) throw new Error(`no preview of .${extOf(path)} here: its export, or the server's thumbnail`);

  if (how.as === 'texture') {
    let texture: THREE.Texture;
    if (extOf(path) === 'ktx2') {
      // From its bytes, by its name: `store.ts` tells a KTX2 by its extension, and `GET file`'s URL ends in a query.
      const bytes = new Uint8Array(await (await api.file(path)).arrayBuffer());
      texture = await decoders.texture({ bytes, name: path }, useOf(path));
    } else texture = await decoders.texture({ url: api.fileUrl(path) }, useOf(path));
    return made(path, 'game', { texture }, () => texture.dispose());
  }

  if (how.through === 'game') {
    const gltf = await decoders.model({ url: api.fileUrl(path) }, besideOf(path, options));
    extrasOntoClips(gltf);
    return made(path, 'game', { scene: gltf.scene, animations: gltf.animations }, () => decoders.disposeScene(gltf.scene));
  }

  const previewer = decoders.previewer(extOf(path));
  if (!previewer) throw new Error(`no previewer for .${extOf(path)}`);
  // Resolved once its textures are in, as the browser's conversion waits for them: a thumbnail captured at once is no black model.
  const loaded: Loaded = await loadWhole(await previewer, api, path, entryAt(path)?.parts ?? [], 'is previewed', WHOLE_MS);
  return made(path, 'previewer', loaded, () => decoders.disposeScene(loaded.scene));
}

/** The one preview open at a time. */
export interface ScratchStore {
  /** What is open now. */
  readonly current: Scratch | null;
  /**
   * `path` decoded and open, the one before disposed: resolves with it, or with
   * null if a later `open` or a `close` came first (and then it is disposed as
   * it arrives -- or, failing, is null all the same: the tool reports no error
   * for a file no longer chosen). A decode that fails, still the latest,
   * rejects and leaves nothing open.
   */
  open(path: string): Promise<Scratch | null>;
  /** The preview closed: what is open disposed, a decode under way disposed when it lands. */
  close(): void;
}

export function createScratchStore(options: ScratchOptions): ScratchStore {
  let current: Scratch | null = null;
  /** Each `open` and `close` takes the next: a decode whose turn has passed is not shown. */
  let turn = 0;
  const drop = (): void => {
    current?.dispose();
    current = null;
  };
  return {
    get current() {
      return current;
    },
    async open(path) {
      const mine = ++turn;
      let scratch: Scratch;
      try {
        scratch = await decodeScratch(path, options);
      } catch (err) {
        // Overtaken, its failure is no one's business: the file is not chosen any more.
        if (mine !== turn) return null;
        drop();
        throw err;
      }
      if (mine !== turn) {
        scratch.dispose();
        return null;
      }
      drop();
      current = scratch;
      return scratch;
    },
    close() {
      turn++;
      drop();
    },
  };
}
