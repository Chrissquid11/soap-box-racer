/**
 * The asset pipeline's way into the running game (Docs/assets.md §8),
 * installed at boot -- before the editor is ever opened -- so a re-export
 * reaches the game whether or not anyone looks: `boot` loads the editor's
 * module at boot behind `DEBUG` (to open the start scene), and calls
 * `watchAssets(game)`, which `editor.ts` re-exports from here -- still its one
 * import.
 *
 * - **`reload`** messages are carried out one at a time (`reload.ts`): the new
 *   export swapped into what is drawn, and its line logged and told
 *   (`onReloaded`) -- the one line a reload logs (`index.ts` hears no
 *   `reload`). One still queued for the same file takes a second in: the
 *   watcher may tell one write twice, and an atlas's two files are one key,
 *   so the later is carried out once, after the one under way. The editor,
 *   once made, hands in its `draw` (`useDraw`), so a swap under it redraws
 *   outlines and gizmo; otherwise a stopped game draws one frame, and a
 *   running one shows it next frame.
 * - **`convert`** messages go to the browser's conversion (`convert.ts`); and
 *   once subscribed, any job already waiting for a tab is claimed. Which jobs
 *   this tab is converting the Assets tool reads (`convertingHere`,
 *   `onConverting`).
 * - **The session's one `Api`** (`assetApi`), so `online` is probed once: with
 *   no dev server, its bundle view is the registry's files. Every move and
 *   delete it makes is told (`onFilesWent`), whichever tool asked.
 * - **Prefab files** added, changed or removed are compiled again into the
 *   game (`prefabs-live.ts`, Docs/prefabs.md §7): once a burst, settled
 *   (`SETTLE_MS`) after the engine's `prefabs.ts` holds them, outside any tick; the line logged, an error
 *   kept and shown, never thrown. `problem` messages -- a prefab or material file the
 *   server found broken and kept from the page -- are kept for the Assets tool
 *   (`livePrefabs.unparsed`, `liveMaterials.unparsed`).
 *
 * Nothing without `import.meta.hot`: a build, served from anywhere, has no dev
 * server to hear.
 */
import type { PushMessage, ReloadMessage } from '@vibe/pipeline/assets-types';
import { KIND_NAMES, PUSH_EVENT, isDataKind, type Kind } from '@vibe/pipeline/kinds';
import { Assets, entries, files } from '@vibe/engine/assets';
import type { Game } from '@vibe/engine/boot';
import { applyUpdates, type Entity, markGameTokens, materialName, onPrefabFiles, prefabFiles, prefabName, sceneName, View, ViewState } from '@vibe/engine';
import { usePrefabNames } from './ui/prefab-steps.ts';
import { useMaterialNames } from './ui/material-steps.ts';
import { liveMaterials } from './materials-live.ts';
import { livePrefabs, recompile, snapshot } from '../prefabs-live.ts';
import { createApi, type Api } from './api.ts';
import type { BundleFile } from './bundle.ts';
import { useSceneNames, type FilesWent } from './scene-files.ts';
import { createConverter, type Converter } from './convert.ts';
import { reload, type Reloaded } from './reload.ts';

/** What the build bundled, from the registry: each kind's files, its keys marked. */
// A key is its file's path lowercased: each leads back to its file as it is on disk (`prefabPathOf`, `scenePathOf`).
usePrefabNames(prefabName);
useMaterialNames(materialName);
useSceneNames(sceneName);

export function shippedFiles(): BundleFile[] {
  const out: BundleFile[] = [];
  for (const kind of KIND_NAMES.filter((k): k is Kind => !isDataKind(k))) {
    const keys = new Map(entries(kind).map(([key, url]) => [url, key]));
    for (const [path, url] of files(kind)) {
      const key = keys.get(url);
      out.push({ kind, path, url, ...(key !== undefined ? { key } : {}) });
    }
  }
  return out;
}

let api: Api | null = null;

const wentHeard = new Set<(went: FilesWent) => void>();

/** The session's API: one `online`, one probe; every move and delete it makes told (`onFilesWent`). */
export function assetApi(): Api {
  return (api ??= createApi({ bundle: shippedFiles, went: (went) => { for (const listener of wentHeard) listener(went); } }));
}

/**
 * Told each move and delete the dev server carried out for this page, as it
 * answers -- from the Assets panel, the Scenes page, an undo or a redo: the
 * open scene follows its file (`sceneKeyAfter`). Returns the undo.
 */
export function onFilesWent(listener: (went: FilesWent) => void): () => void {
  wentHeard.add(listener);
  return () => void wentHeard.delete(listener);
}

/** The editor's redraw while it is up: true if it drew. */
let redraw: (() => boolean) | null = null;

/** The editor hands in how it draws (and takes it back, null, as it goes): a swap under it redraws the outlines and the gizmo. */
export function useDraw(draw: (() => boolean) | null): void {
  redraw = draw;
}

const heard = new Set<(reloaded: Reloaded) => void>();

/** Told each reload carried out, with its line: the Assets tool shows it. Returns the undo. */
export function onReloaded(listener: (reloaded: Reloaded) => void): () => void {
  heard.add(listener);
  return () => void heard.delete(listener);
}

/**
 * Milliseconds the prefab files are let settle before a recompile: one step of the Assets tool can be several
 * hot updates -- a rename, then the prefabs nesting it rewritten -- and between them the files do not compile.
 */
const SETTLE_MS = 250;

let watching = false;
let converter: Converter | null = null;

/** Is this job's browser step being done in this tab (`convert.ts`)? False before `watchAssets`, and without a dev server. */
export function convertingHere(job: string): boolean {
  return converter?.holds(job) ?? false;
}

const converts = new Set<() => void>();

/** Told as this tab takes a conversion and as it is done with one -- heard before `watchAssets` too. Returns the undo. */
export function onConverting(listener: () => void): () => void {
  converts.add(listener);
  return () => void converts.delete(listener);
}

/** Re-exports swapped into `game` as they come, and conversions done for the dev server: once, at boot. */
export function watchAssets(game: Game): void {
  const hot = import.meta.hot;
  if (!hot || watching) return;
  watching = true;
  converter = createConverter(assetApi());
  const converting = converter;
  converting.onHolding(() => {
    for (const fn of converts) fn();
  });
  /** One reload at a time: the old model of one is disposed before the next decodes. */
  let queue = Promise.resolve();
  /** The reloads queued and not yet begun, by file: a second for one of them is that one. */
  const waiting = new Map<string, ReloadMessage>();
  const draw = (): void => {
    if (redraw?.()) return;
    if (!game.isRunning) game.renderOnce();
  };
  const carryOut = async (message: ReloadMessage): Promise<void> => {
    try {
      const done = await reload(game, message, draw);
      if (!done) return;
      console.info(`[assets] ${done.line}`);
      for (const fn of heard) fn(done);
    } catch (err) {
      console.error(`[assets] the new ${message.kind} '${message.key}' could not be swapped in:`, err);
    }
  };
  hot.on(PUSH_EVENT, (data: PushMessage) => {
    if (data.type === 'reload') {
      const { kind, key, beside = '' } = data.reload;
      const file = `${kind}\n${key}\n${beside}`;
      const queued = waiting.has(file);
      waiting.set(file, data.reload);
      if (queued) return;
      queue = queue.then(() => {
        const message = waiting.get(file)!;
        waiting.delete(file);
        return carryOut(message);
      });
    } else if (data.type === 'convert') void converting.heard(data.convert);
    else if (data.type === 'problem' && data.problem.kind === 'materials') {
      const { key, message, line } = data.problem;
      if (message === null) {
        if (!liveMaterials.unparsed.delete(key)) return;
      } else {
        liveMaterials.unparsed.set(key, line !== undefined ? { key, message, line } : { key, message });
        console.error(`[materials] src/assets/materials/${key}.material does not parse${line !== undefined ? ` (line ${line})` : ''}: ${message} -- the last good file stays compiled`);
      }
      liveMaterials.tell();
    } else if (data.type === 'problem' && data.problem.kind === 'prefabs') {
      const { key, message, line } = data.problem;
      if (message === null) {
        if (!livePrefabs.unparsed.delete(key)) return;
      } else {
        livePrefabs.unparsed.set(key, line !== undefined ? { key, message, line } : { key, message });
        console.error(`[prefabs] src/assets/prefabs/${key}.prefab does not parse${line !== undefined ? ` (line ${line})` : ''}: ${message} -- the last good file stays compiled`);
      }
      livePrefabs.tell();
    }
  });
  // Prefab files, compiled again as they change: the files as the boot compiled them are the first snapshot, and
  // the tokens now are game code's -- the editor's, made later, may lose their file.
  markGameTokens();
  const compiled = snapshot(prefabFiles());
  livePrefabs.compiled = compiled;
  let soon: ReturnType<typeof setTimeout> | undefined;
  onPrefabFiles(() => {
    if (soon !== undefined) clearTimeout(soon);
    soon = setTimeout(() => {
      soon = undefined;
      // Inside the editor's steps while it is up: the pools drained and warmed are no edit.
      const done = livePrefabs.around(() => recompile(game.world, prefabFiles(), compiled, Assets.prefabChecks));
      livePrefabs.last = done;
      livePrefabs.compiles++;
      if (done.error) console.error(`[prefabs] ${done.line}`);
      else console.info(`[prefabs] ${done.line}`);
      // Every instance out brought up where it holds no override of its own: one step in the editor, in place outside it.
      if (done.pending.length > 0) {
        const keys = [...new Set(done.pending.map((p) => p.old.key))];
        const hold = livePrefabs.hold;
        const update = (run: () => void): void => {
          if (!hold || hold(run, keys) === false) livePrefabs.update(`${keys.join(', ')} updated`, run);
        };
        update(() => {
          const world = game.world;
          // A node that draws another model now: its view let go of, so the prefab's hooks draw the new one.
          const view = (e: Entity): void => {
            if (world.has(e, View)) world.remove(e, View);
            if (world.has(e, ViewState)) world.remove(e, ViewState);
          };
          const { updated, lines } = applyUpdates(world, done.pending, { view });
          if (updated > 0) console.info(`[prefabs] ${updated} ${updated === 1 ? 'instance' : 'instances'} of ${keys.join(', ')} updated${lines.length > 0 ? `: ${lines.join('; ')}` : ''}`);
        });
      }
      livePrefabs.tell();
      draw();
    }, SETTLE_MS);
  });
  void converting.claimWaiting();
}
