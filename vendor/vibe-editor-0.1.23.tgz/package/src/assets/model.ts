/**
 * The client index (Docs/assets.md §8): what the dev server's index is, as this
 * page knows it -- every entry by path, the Trash's slots, and `seq`, the
 * server's count of changes it has caught up to. `live.ts` keeps it current;
 * the Assets tool reads it.
 *
 * - **It only moves forward from its `seq`.** A diff ending at or before it is
 *   a no-op (a push that a response already brought, a response a push
 *   overtook); one whose `from` is past it is a gap, which `live.ts` fills with
 *   `GET tree?since=`. A diff that starts before `seq` and ends after it is
 *   applied whole: the server composes every change over (`from`, `seq`], so a
 *   path it names is as it is at the end, whichever came between. A response
 *   to a `since` older than the server keeps is the whole tree, put in place
 *   of what is.
 * - **The Trash comes whole** (§6): `trash` on the tree, and on a diff within
 *   which the server re-read `.trash/` -- replacing the copy, never merged.
 * - **The folders are made from it** (`folderTree`): the project at the top
 *   (`PROJECT`, `''`, its folders the roots and then the Trash, no file of its
 *   own -- the one place every root is under), the roots, every folder a
 *   file is under, each kind's own folder under Source and Assets where the index
 *   has files under that root (`KIND_DIRS`: where art of that kind goes, there
 *   before its first file -- and no Source at all in bundle view, which has
 *   none), and the Trash root with its slots as folders, a slot's
 *   files as `TrashFile`s -- `{ path, size, mtime, slot }`, `path` where the
 *   file is now (`.trash/<slot>/<the path it had>`), what `GET file`, `GET
 *   thumb` and `GET stats` take -- so a slot is drawn as any folder is. No
 *   sort, filter or totals: those are the tool's (part two §10).
 * - **And the folders this page made** (`keepFolder`): the index lists files,
 *   so a folder made empty -- New folder, a pack -- would be nowhere to drop
 *   into; kept here, shown though empty, until this page deletes or moves it
 *   (`forgetFolder`). One removed outside the tool stays for the session.
 *
 * Pure: it imports the pipeline's pure modules alone, so a node test holds it
 * (`model.test.ts`).
 */
import type { Diff, Entry, TrashFile, TrashSlot, TreeAnswer } from '@vibe/pipeline/assets-types';
import { KINDS, ROOTS, TRASH, kindRows, type KindRow } from '@vibe/pipeline/kinds';
import { dirName, trashPath } from '@vibe/pipeline/paths';

/** What a folder lists: an entry of the index, or a file in a trash slot. */
export type Shown = Entry | TrashFile;

/** What is in a folder, not under it: its folders' paths, then its files. */
export interface Children {
  folders: string[];
  files: Shown[];
}

/** What became of a diff: applied, a no-op (at or before `seq`), or past a gap (`GET tree?since=` fills it). */
export type Applied = 'applied' | 'ignored' | 'gap';

/**
 * The project: the folder above the roots, `''`, the tree's top -- its folders
 * the roots, in `ROOTS`' order, then the Trash; no file of its own. What a
 * search or a count of the whole project is over.
 */
export const PROJECT = '';

/** The folders of the index: the project, the roots, every folder a file is under, the Trash and its slots. */
export interface FolderTree {
  /** The tree's top: the project (`PROJECT`), whose folders are `roots`. */
  readonly top: string;
  /** The roots' folders, in `ROOTS`' order, then the Trash's: the project's folders. */
  readonly roots: readonly string[];
  /** Is it a folder here: the project, a root, a folder some file is under, the Trash or one of its slots? */
  has(folder: string): boolean;
  /** Its folders, then its files. The project's, the roots and the Trash; under the Trash root, the slots; in a slot, its files. Empty for no such folder. */
  childrenOf(folder: string): Children;
}

/** A folder being made: its folders as they were found, and its files. */
interface Made {
  folders: Set<string>;
  files: Shown[];
}

const ROOT_DIRS: readonly string[] = Object.values(ROOTS).map((root) => root.dir);

/**
 * Each kind's folder, where art of that kind goes: under Assets every kind's
 * (`src/assets/audio/sfx`, `src/assets/levels`), under Source those a source
 * comes from. Folders of the tree with no file in them yet -- an empty
 * `textures/` holds a `.gitkeep`, which the index lists not -- so a designer
 * sees where a file goes before the first one is there; placed for a root the
 * index has a file under, so bundle view, which has the boot set alone, shows
 * no Source. A pack's are its own, made as its files come.
 */
const KIND_HOMES: ReadonlyArray<{ root: string; dir: string }> = [
  ...Object.values(KINDS).map((kind) => ({ root: ROOTS.boot.dir, dir: `${ROOTS.boot.dir}/${kind.dir}` })),
  ...Object.values(KINDS).filter((kind) => kind.source).map((kind) => ({ root: ROOTS.source.dir, dir: `${ROOTS.source.dir}/${kind.dir}` })),
];
export const KIND_DIRS: readonly string[] = KIND_HOMES.map((home) => home.dir);

/** A project's own kinds' folders (`vibe({ kinds })`, from `GET kinds`), under Assets: placed as the table's are. */
const ownHomes = (kinds: readonly KindRow[]): Array<{ root: string; dir: string }> =>
  kinds.filter((kind) => kind.project).map((kind) => ({ root: ROOTS.boot.dir, dir: `${ROOTS.boot.dir}/${kind.dir}` }));

/** The folder whose files are `.trash/<slot>/...`: `childrenOf` of it lists them. */
export function slotFolder(slot: string): string {
  return `${TRASH}/${slot}`;
}

/** A trash slot's files as the tool lists them: where each is now, and its slot. */
export function trashFiles(slot: TrashSlot): TrashFile[] {
  return slot.files.map((f) => ({ path: trashPath(slot.slot, f.path), size: f.size, mtime: f.mtime, slot: slot.slot }));
}

/**
 * The folder tree of `entries` and the Trash's `trash`, the project at its
 * top. A folder is there if it is the project, a
 * root is, a kind's is under a root with files (`KIND_DIRS`), a file is under
 * it, or it is one of `kept` (the folders this page made, under a root): the
 * index lists files, not folders, so any other empty folder is not in it.
 */
export function folderTree(entries: Iterable<Entry>, trash: readonly TrashSlot[], kept: Iterable<string> = [], kinds: readonly KindRow[] = []): FolderTree {
  const made = new Map<string, Made>();
  const folder = (path: string): Made => {
    let f = made.get(path);
    if (!f) made.set(path, (f = { folders: new Set(), files: [] }));
    return f;
  };
  /** `dir` a folder, and up to its root each folder its parent's: stopped where one is known already. */
  const place = (dir: string): void => {
    folder(dir);
    while (!ROOT_DIRS.includes(dir) && dir !== '') {
      const parent = dirName(dir);
      const up = folder(parent);
      if (up.folders.has(dir)) break;
      up.folders.add(dir);
      dir = parent;
    }
  };
  // The project first: the roots and the Trash its folders, no file of its own -- nothing is placed in it but them.
  made.set(PROJECT, { folders: new Set([...ROOT_DIRS, TRASH]), files: [] });
  for (const dir of ROOT_DIRS) folder(dir);
  const all = [...entries];
  /** The roots some file is under: where the kinds' folders go, first, in `KINDS`' order. */
  const used = new Set(ROOT_DIRS.filter((root) => all.some((entry) => entry.path.startsWith(root + '/'))));
  for (const { root, dir } of [...KIND_HOMES, ...ownHomes(kinds)]) if (used.has(root)) place(dir);
  for (const entry of all) {
    const dir = dirName(entry.path);
    // A file under no root -- none the server sends -- is no file of the project's.
    if (dir === PROJECT) continue;
    place(dir);
    folder(dir).files.push(entry);
  }
  for (const dir of kept) if (ROOT_DIRS.some((root) => dir.startsWith(root + '/'))) place(dir);
  const top = folder(TRASH);
  for (const slot of trash) {
    const path = slotFolder(slot.slot);
    top.folders.add(path);
    folder(path).files.push(...trashFiles(slot));
  }
  return {
    top: PROJECT,
    roots: [...ROOT_DIRS, TRASH],
    has: (path) => made.has(path),
    childrenOf(path) {
      const f = made.get(path);
      return f ? { folders: [...f.folders], files: [...f.files] } : { folders: [], files: [] };
    },
  };
}

/** The client index: the entries, the Trash, and how far it has come. */
export interface ClientIndex {
  /** The server's `seq` of the last change this index has; -1 before the first tree. */
  readonly seq: number;
  /** Has the first tree come? */
  readonly loaded: boolean;
  /** Every entry, by path. */
  readonly entries: ReadonlyMap<string, Entry>;
  /** The Trash's slots, as the server last sent them. */
  readonly trash: readonly TrashSlot[];
  /** What the server's 30-day prune removed at its start, from the last whole tree: the Trash root's line. */
  readonly pruned: { count: number; at: string } | undefined;
  /** The whole index (`GET tree`) in place of what is -- unless it is older than what is. */
  load(answer: TreeAnswer): Applied;
  /** A diff -- a response's or a `changed` message's -- or a whole tree, by `seq` (above). */
  apply(diff: Diff | TreeAnswer): Applied;
  /** The folders, made again only when the index has moved since the last ask. */
  tree(): FolderTree;
  /** `tree().childrenOf(folder)`. */
  childrenOf(folder: string): Children;
  /** A folder this page made, shown though no file is in it yet. */
  keepFolder(folder: string): void;
  /** One this page deleted or moved -- and every one kept under it. */
  forgetFolder(folder: string): void;
  /** Every kind, the project's own too (`GET kinds`): the table's alone until the server says. */
  readonly kinds: readonly KindRow[];
  /** The server's kinds in: a project kind's folder placed as the table's are. */
  useKinds(kinds: readonly KindRow[]): void;
}

export function createIndex(): ClientIndex {
  let seq = -1;
  let entries = new Map<string, Entry>();
  let trash: readonly TrashSlot[] = [];
  let pruned: { count: number; at: string } | undefined;
  let made: FolderTree | null = null;
  const kept = new Set<string>();
  let kinds: readonly KindRow[] = kindRows();

  const load = (answer: TreeAnswer): Applied => {
    if (answer.seq < seq) return 'ignored';
    seq = answer.seq;
    entries = new Map(answer.tree.map((e) => [e.path, e]));
    trash = answer.trash;
    pruned = answer.pruned;
    made = null;
    return 'applied';
  };

  const index: ClientIndex = {
    get seq() {
      return seq;
    },
    get loaded() {
      return seq >= 0;
    },
    get entries() {
      return entries;
    },
    get trash() {
      return trash;
    },
    get pruned() {
      return pruned;
    },
    load,
    apply(diff) {
      if ('tree' in diff) return load(diff);
      // Nothing to add a diff to yet: the whole tree is what is wanted.
      if (seq < 0 || diff.from > seq) return 'gap';
      if (diff.seq <= seq) return 'ignored';
      for (const path of diff.removed) entries.delete(path);
      for (const e of diff.added) entries.set(e.path, e);
      for (const e of diff.updated) entries.set(e.path, e);
      if (diff.trash) trash = diff.trash;
      seq = diff.seq;
      made = null;
      return 'applied';
    },
    tree() {
      return (made ??= folderTree(entries.values(), trash, kept, kinds));
    },
    childrenOf(folder) {
      return index.tree().childrenOf(folder);
    },
    keepFolder(folder) {
      if (kept.has(folder)) return;
      kept.add(folder);
      made = null;
    },
    forgetFolder(folder) {
      for (const dir of [...kept]) if (dir === folder || dir.startsWith(folder + '/')) kept.delete(dir);
      made = null;
    },
    get kinds() {
      return kinds;
    },
    useKinds(next) {
      kinds = next;
      made = null;
    },
  };
  return index;
}
