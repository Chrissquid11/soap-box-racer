/**
 * Bundle view's index (Docs/assets.md §5, "Without a dev server"; part two
 * §7): with no dev server -- `npm run build:debug` on a static host -- the
 * Assets tool lists what the registry globbed, read-only, its previews from
 * the hashed URLs. The same `TreeAnswer` the server gives, so the tool draws
 * it as it draws the live index, and each file's URL beside it.
 *
 * Only the boot set: no Source side, no packs, no Trash; no roles to speak of
 * (every file is `loose`: nothing here knows its source), no sizes (a `HEAD`
 * on the URL, when the inspector asks), `seq` 0.
 *
 * The registry's files are handed in (`boot.ts` reads them): `registry.ts`
 * runs on `import.meta.glob`, so this stays pure and a node test holds it
 * (`bundle.test.ts`).
 */
import type { Entry, TreeAnswer } from '@vibe/pipeline/assets-types';
import { KINDS, ROOTS, type Kind } from '@vibe/pipeline/kinds';
import { joinPath } from '@vibe/pipeline/paths';

/** One file the build bundled: its kind, its path under the kind's folder, its URL, and its key if it is one. */
export interface BundleFile {
  kind: Kind;
  path: string;
  url: string;
  key?: string;
}

export interface BundleIndex {
  /** The index, as `GET tree` would answer it. */
  answer: TreeAnswer;
  /** Each file's URL, by its path: what the tool previews from. */
  urls: Map<string, string>;
}

export function bundleIndex(files: readonly BundleFile[]): BundleIndex {
  const tree: Entry[] = [];
  const urls = new Map<string, string>();
  for (const { kind, path, url, key } of files) {
    const full = joinPath(ROOTS.boot.dir, KINDS[kind].dir, path);
    tree.push({ path: full, root: 'boot', role: 'loose', kind, ...(key !== undefined ? { key } : {}), size: 0, mtime: 0, included: true });
    urls.set(full, url);
  }
  return { answer: { seq: 0, tree, trash: [] }, urls };
}
