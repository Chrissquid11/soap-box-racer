/**
 * The dev server's API (Docs/assets.md §5, under `/__assets/`), as typed
 * calls: one per row of §5's table, each answering the shape `api-types.ts`
 * names -- the same file the server is written against.
 *
 * - **`online`, decided once a session** from `GET tools`'s `write` (§5,
 *   "Without a dev server"): `'write'`, `'read'` (another machine: previews,
 *   no writes) or `false` -- no answer in 2 s, or no dev server at all
 *   (`import.meta.hot` is undefined in a build), and then no `/__assets/` call
 *   is ever made: the index is the bundle's (`bundle.ts`, from the registry's
 *   files, handed in), a file's URL its hashed one, and every other call
 *   refused here. Never per call, so the tool does not flicker between modes.
 * - **The path rule, mirrored**: a path is checked before it is sent with the
 *   server's own `checkedPath` (`paths.ts`), against the same folders the
 *   route allows, and refused in the server's words -- `ApiRefused`, as a
 *   refusal from the server is.
 * - **Every mutating call carries the client index's `seq`** (`since=`) and
 *   hands its answer to the index (`connect`: `live.ts`) the moment it comes,
 *   so applying the diff brings the index to the answer's `seq` (§6).
 * - **`PUT import` goes by `XMLHttpRequest`**, for its upload progress: `fetch`
 *   has none for a request body.
 * - **The studio's routes** (`/__studio/`, Docs/squidwright-implementation.md
 *   2.2) are `studio`'s calls (`StudioCalls`): the same `online` and the same
 *   refusals, no index -- nothing there moves it.
 *
 * No `import.meta.glob`, no DOM at module level: a node test makes one with a
 * stand-in `fetch` (`api.test.ts`).
 */
import type {
  CopyAnswer,
  DeleteAnswer,
  Diff,
  ExportAnswer,
  FileStats,
  ImportAnswer,
  JobInfo,
  HeldAnswer,
  KindsAnswer,
  ModelAnswer,
  ModelMadeAnswer,
  ParamsAnswer,
  PreviewFailure,
  ScriptAnswer,
  TraceAnswer,
  TraceFaces,
  MoveAnswer,
  ExportAsAnswer,
  ReferrersAnswer,
  NameAnswer,
  PrefabAnswer,
  Options,
  Refusal,
  RestoreAnswer,
  Run,
  SidecarAnswer,
  ThumbMiss,
  ToolsAnswer,
  ToolsCheckAnswer,
  TreeAnswer,
  Use,
  WriteAnswer,
} from '@vibe/pipeline/assets-types';
import type {
  BrokenAnswer,
  CheckRow,
  DebugBreakpoint,
  DebugState,
  DistAnswer,
  DownloadState,
  FileAnswer,
  FilesAnswer,
  GitAsk,
  GitBranches,
  GitCommitted,
  GitDiff,
  GitLog,
  GitRan,
  GitRepo,
  GitStatus,
  LogAnswer,
  MappedStack,
  Problem,
  SearchAnswer,
  TasksAnswer,
  FileMade,
  FilesCopied,
  FilesDeleted,
  FilesMoved,
} from '@vibe/pipeline/studio-types';
import { ENGINE_DATA_KINDS, KINDS, ROOTS, THUMB_MISS_HEADER, kindRows } from '@vibe/pipeline/kinds';
import { READ_DIRS, WRITE_DIRS, checkedPath } from '@vibe/pipeline/paths';
import { bundleIndex, type BundleFile, type BundleIndex } from './bundle.ts';
import type { FilesWent } from './scene-files.ts';

/** Where the API is mounted on the dev server. */
export const API_BASE = '/__assets/';
/** Where a project's own routes are (`vibe({ routes })`): `/__tools/<name>/`. */
export const TOOLS_BASE = '/__tools/';

/** Where the studio's routes are (`@vibe/pipeline/studio-types`' `STUDIO_PREFIX`). */
export const STUDIO_BASE = '/__studio/';

/**
 * The studio's routes (`/__studio/`), for the Studio tab's cards and the Tools page's Download row: each the
 * shape `@vibe/pipeline/studio-types` names, a refusal `ApiRefused` as any call here (a 501 `{ why }` too, its
 * status what says it). With no dev server, refused before anything is sent.
 */
export interface StudioCalls {
  /** `GET log?stream=&since=`: the stream's lines after `since`, and its last seq. */
  log(stream: string, since?: number): Promise<LogAnswer>;
  /** `GET tasks`: the scripts a run may name, what runs, what ran last. */
  tasks(): Promise<TasksAnswer>;
  /** `POST run { script, args? }`: `args` is `test`'s one file. 400 not allowed, 409 one runs. */
  run(script: string, args?: readonly string[]): Promise<{ name: string; from: number }>;
  /** `POST cancel`: the running task signalled; 409 when none runs. */
  cancel(): Promise<{ cancelled: string | null }>;
  /** `GET problems`: tsc's errors over both programs, and the modules Vite cannot serve (the program `vite`). */
  problems(): Promise<Problem[]>;
  /** `GET broken`: the modules Vite cannot serve now, and the page reloads held for them (Docs/studio.md §1, "Mid-session"). */
  broken(): Promise<BrokenAnswer>;
  /** `POST stack { stack }`: a runtime error's stack at the TypeScript's places, and its first frame under `src/`. */
  stack(stack: string): Promise<MappedStack>;
  /** `POST probe { id, ack: true }`: this tab makes the probe page the dev server asked for (`studio:probe`). */
  probeAck(id: string): Promise<{ ok: true }>;
  /** `POST unhold`: "Reload anyway" -- the modules held for a throw let go, the held reload sent if nothing else is broken. */
  unhold(): Promise<BrokenAnswer>;
  /** `GET checks`: what the machine has -- node, claude, gladius, ffmpeg, git lfs. */
  checks(): Promise<CheckRow[]>;
  /** `GET dist`: `dist/` measured; null when there is none (the route's 404). */
  dist(): Promise<DistAnswer | null>;
  /** `GET preview`: the running preview's url, or null. */
  preview(): Promise<string | null>;
  /** `POST preview`: a preview started (or the running one): its url. */
  startPreview(): Promise<string>;
  /** `POST reveal { path }`: shown in the Finder or the Explorer by the shell; 501 in a browser. */
  reveal(path: string): Promise<void>;
  /** `GET download?tool=`: a download's state. */
  downloadState(tool: string): Promise<DownloadState>;
  /** `POST download { tool }`: fetched, checked and unpacked -- answered as it starts (`downloading`); `studio:download` and `downloadState` carry the rest. */
  download(tool: string): Promise<DownloadState>;
  /** `GET tree`: every file the Code card may open. */
  tree(): Promise<FilesAnswer>;
  /** `GET file?path=&at=`: the text on disk and its mtime -- or, with `at` (a turn, `HEAD`), as it was then. 404 none, 413 over `FILE_LIMIT`. */
  file(path: string, at?: string): Promise<FileAnswer>;
  /**
   * `PUT file { path, text, ifMtime }`: written, if the file is still at `ifMtime` (null: a file not there yet, or
   * written anew) -- its new mtime answered. 412 a `FileConflict` (the refusal's body carries `text` and `mtime`), 423
   * a `FileLocked` (`conversation`).
   */
  save(path: string, text: string, ifMtime: number | null): Promise<{ mtime: number }>;
  /** `GET search?q=&glob=`: the hits, `truncated` past `SEARCH_LIMIT`. */
  search(q: string, glob?: string): Promise<SearchAnswer>;
  /** The Code card tree's file operations (`/__studio/files/`): a 409 `FileClash`'s body carries `clash`. */
  files: FileOpCalls;
  /** The Git card's calls (`/__studio/git/`): what each answers, `@vibe/pipeline/studio-types` names. */
  git: GitCalls;
  /** The dev server's debugger (`/__studio/debug/`): the Code card's breakpoints under VS Code's F5. */
  debug: DebugCalls;
}

/** The Code card tree's file operations: made, moved, copied, deleted -- each checked by the dev server. */
export interface FileOpCalls {
  /** `POST files/new { path, folder }`: an empty file, or a folder. */
  make(path: string, folder: boolean): Promise<FileMade>;
  /** `POST files/move { from, to, replace }`: a script's imports updated by TypeScript, an asset the Assets panel's way. */
  move(from: string, to: string, replace?: boolean): Promise<FilesMoved>;
  /** `POST files/copy { from, to, replace }`. */
  copy(from: string, to: string, replace?: boolean): Promise<FilesCopied>;
  /** `POST files/delete { paths, check }`: for good (an asset to `.trash/`) -- or, `check`, checked alone. */
  remove(paths: readonly string[], check?: boolean): Promise<FilesDeleted>;
}

/** The dev server's debugger: attached or not, the breakpoints read and toggled, the Debugger tab opened. */
export interface DebugCalls {
  /** `GET debug/state`: attached to a studio tab in a Chrome with a debugging port, or not. */
  state(): Promise<DebugState>;
  /** `GET debug/breakpoints`: each with whether the game has it set. */
  breakpoints(): Promise<DebugBreakpoint[]>;
  /** `POST debug/breakpoints { file, line }`: toggled; the list after, once tried. */
  toggle(file: string, line: number): Promise<DebugBreakpoint[]>;
  /** `POST debug/open`: the Debugger tab made or brought forward; 409 while not attached. */
  open(): Promise<void>;
}

/** The Git card's routes: status, log, branches, a diff to read; commit, checkout, push and pull to act -- the last three answering `GitAsk` until `confirm`. */
export interface GitCalls {
  /** `GET git/status`. */
  status(): Promise<GitStatus>;
  /** `GET git/log?count=`. */
  log(count?: number): Promise<GitLog[]>;
  /** `GET git/branches`. */
  branches(): Promise<GitBranches[]>;
  /** `GET git/diff?paths=`: the paths' unified diff against `HEAD`, cut at `GIT_DIFF_LIMIT`. */
  diff(paths: readonly string[]): Promise<GitDiff>;
  /** `POST git/commit { message, paths, repo }`. 409 git's refusal (`why`). */
  commit(repo: GitRepo, message: string, paths: readonly string[]): Promise<GitCommitted>;
  /** `POST git/checkout { branch, repo, create?, confirm? }`. */
  checkout(repo: GitRepo, branch: string, options?: { create?: boolean; confirm?: boolean }): Promise<GitAsk | GitRan>;
  /** `POST git/push { repo, confirm? }`: the ask, then with `confirm` the push. */
  push(repo: GitRepo, confirm?: boolean): Promise<GitAsk | GitRan>;
  /** `POST git/pull { repo, confirm? }`: the ask, then with `confirm` the pull, fast-forward only. */
  pull(repo: GitRepo, confirm?: boolean): Promise<GitAsk | GitRan>;
}

/** An undo's text put back: a data file's text before the doing, and what the doing left there (`after`). */
export interface RestoreText {
  path: string;
  text: string;
  after?: string;
}

/** What this page may do: write (this machine), read (another one), or nothing -- no dev server, bundle view. */
export type Online = 'write' | 'read' | false;

/** A call refused -- by the server (its status and body), or here before it was sent (the same words). */
export class ApiRefused extends Error {
  /** The HTTP status; 0 for no answer at all. */
  readonly status: number;
  readonly body: Refusal & Record<string, unknown>;
  constructor(status: number, body: Refusal & Record<string, unknown>) {
    super(body.refused);
    this.name = 'ApiRefused';
    this.status = status;
    this.body = body;
  }
}

/** Where a mutating call's answer goes: the client index (`live.ts`), and the `seq` it sends as `since=`. */
export interface AnswerSink {
  /** The index's `seq`; -1 before its first tree (then no `since=` is sent). */
  readonly seq: number;
  take(answer: WriteAnswer): void;
}

/** `PUT import`'s question (§5, Importing): one file into `dest`. */
export interface ImportQuery {
  dest: string;
  name: string;
  /** Imported as a source (its twin on the Source side), or as delivered. */
  source: boolean;
  /** Its family to the trash first, and this in its place. */
  replace?: boolean;
  /** Its record's options. */
  options?: Options;
  /** False: a source out of the build from the start -- its record says so, and nothing is exported. */
  include?: boolean;
  /** The drop it is one of, and how many of the drop's files come after it: the exports go with the last. */
  drop?: string;
  left?: number;
  /** A `.glb` or `.fbx` as a Gladius script that imports it, the file copied in beside it (Docs/modeler.md M39). */
  script?: boolean;
}

/** `GET thumb`: the thumbnail -- with the hash it shows, from its `ETag` -- or why there is none yet. */
export type ThumbAnswer = { blob: Blob; hash?: string } | { miss: ThumbMiss };

export interface ApiOptions {
  /** Is there a dev server to ask? `import.meta.hot` by default: undefined in a build. */
  hot?: boolean;
  /** The page's `fetch` by default. */
  fetch?: typeof fetch;
  /** What the build bundled, for bundle view: the registry's files (`boot.ts` hands them in). */
  bundle?: () => readonly BundleFile[];
  /** How long `GET tools` has to answer before this page counts as having no dev server: 2 s. */
  probeMs?: number;
  /**
   * Told each move and delete the server carried out, as it answers -- whoever
   * asked: the Assets panel, the Scenes page, an undo or a redo of either.
   * The one place a file renamed or gone is heard (`boot.ts`' `onFilesWent`).
   */
  went?: (went: FilesWent) => void;
}

export interface Api {
  /** `'write'`, `'read'` or `false`, decided once (above). */
  online(): Promise<Online>;
  /** Answers to the index from now on (`live.ts`); null to stop. */
  connect(sink: AnswerSink | null): void;
  /** The studio's routes (`/__studio/`): the Studio tab's cards', the Tools page's Download row's. */
  readonly studio: StudioCalls;

  // -------------------------------------------------- tools
  /** `GET tools`: may this page write, and the tools found (`null` while the first look runs). */
  tools(): Promise<ToolsAnswer>;
  /** `POST tools/check`: look again; what can now be made, queued. */
  checkTools(): Promise<ToolsCheckAnswer>;
  /** `PUT tools?name=`: a tool's path, from the Tools card -- `''` forgets it -- then a look again. */
  setTool(name: string, path: string): Promise<ToolsCheckAnswer>;

  // -------------------------------------------------- reading
  /** `GET tree`, or `GET tree?since=`: a diff, or the whole tree when `since` is older than the server keeps. Offline, the bundle's. */
  tree(since?: number): Promise<TreeAnswer | Diff>;
  /** `GET stats?path=`; `{ checking: true }` until the file is hashed. */
  stats(path: string): Promise<FileStats | { checking: true }>;
  /** `GET file?path=`'s URL -- for an `<img>`, an `<audio>`, a download. Offline, the file's hashed URL ('' for none). */
  fileUrl(path: string): string;
  /** `GET file?path=`: the bytes (`Range`, `ETag` and `If-None-Match` as `init` gives them). */
  file(path: string, init?: RequestInit): Promise<Response>;
  /** `GET thumb?path=&size=`. */
  thumb(path: string, size: number): Promise<ThumbAnswer>;
  /** `PUT thumb?hash=&size=`: a thumbnail made here, filed under the hash of what it shows. */
  putThumb(hash: string, size: number, webp: Blob): Promise<WriteAnswer>;
  /** `GET uses?key=`: where the key is written in `src/`. */
  uses(key: string): Promise<Use[]>;
  /** `GET names`: each name fine or refused with a way on, in the order asked. */
  names(dest: string, names: readonly string[], options?: { folder?: boolean; source?: boolean }): Promise<NameAnswer[]>;
  /** `GET jobs`: what is queued, running, and parked waiting for a tab. */
  jobs(): Promise<JobInfo[]>;
  /** `GET run?path=`: a source's last attempt on this machine; undefined for none. */
  run(path: string): Promise<Run | undefined>;
  /** `GET model?path=`: a Gladius script as the kernel builds it -- its polygons, its counts, a failed build's lines (Docs/modeler.md §3). */
  model(path: string): Promise<ModelAnswer>;
  /** `GET held`: the Gladius scripts whose export waits for a Claude turn's end (Docs/modeler.md M21). */
  held(): Promise<HeldAnswer>;
  /**
   * A project route's caller (`vibe({ routes })`, mounted at `/__tools/<name>/`): `call(path)` a GET,
   * `call(path, body)` a POST of `body` as JSON -- answering the route's JSON, or refused (`ApiRefused`)
   * as any call here is. With no dev server, refused before anything is sent.
   */
  tool(name: string): { call(path: string, body?: unknown): Promise<unknown> };
  /** `GET kinds`: every kind, the project's own too (`vibe({ kinds })`), as the Assets panel titles their folders; with no dev server, the table's alone. */
  kinds(): Promise<KindsAnswer>;
  /** `GET params?path=`: what a Gladius script's params{} declares, by `gladius params` -- no build -- at the export's parameters. */
  params(path: string): Promise<ParamsAnswer>;
  /**
   * `POST preview?path=` with `{ params }`: a build that is not the export, at
   * these parameters over the source's (Docs/modeler.md M22) -- its bytes and
   * how long it took, or why not (`PreviewFailure`: Gladius's lines, or
   * `superseded` by a later ask). `signal` lets go of it.
   */
  preview(path: string, params: Readonly<Record<string, string>>, signal?: AbortSignal): Promise<{ ok: true; bytes: Uint8Array; ms: number } | PreviewFailure>;
  /** `POST trace?path=`: the script replayed op by op -- its steps, their cost, the version to fetch (Docs/modeler.md M34). */
  trace(path: string, signal?: AbortSignal): Promise<TraceAnswer>;
  /** `GET trace?path=&v=`: the trace's GLB, every step a node. */
  traceBytes(path: string, version: string, signal?: AbortSignal): Promise<Uint8Array>;
  /** `GET trace?path=&v=&faces=1`: each step's polygons (a second Gladius pass). */
  traceFaces(path: string, version: string): Promise<TraceFaces>;

  // -------------------------------------------------- writing
  /**
   * `PUT import`: one file, its upload's progress told as it goes. `signal`
   * stops it (`xhr.abort()`): the server writes nothing of an upload that ends
   * early, and the call rejects with status 0, `aborted`.
   */
  importFile(file: Blob, query: ImportQuery, progress?: (sent: number, total: number) => void, signal?: AbortSignal): Promise<ImportAnswer>;
  /** `POST model`: New model -- a starter script `<name>.lua` in `dir` (a models folder, either side), its export queued (Docs/modeler.md M38). */
  newModel(dir: string, name: string): Promise<ModelMadeAnswer>;
  /** `POST adopt`: Make a script for a `.glb` delivered as it is -- its copy and a script importing it, the export queued (M39). */
  adopt(path: string): Promise<ModelMadeAnswer>;
  /** `POST export`: `{ paths }` or `{ under }`, `force` to make even what is current. */
  exportSources(what: { paths: readonly string[] } | { under: string }, force?: boolean): Promise<ExportAnswer>;
  /** `POST convert/claim?job=`: this tab does the browser step -- true -- or another took it first (`409`): false. */
  claim(job: string): Promise<boolean>;
  /** `PUT intermediate?job=&three=`: the browser step's `.glb`. */
  putIntermediate(job: string, glb: ArrayBuffer | Blob, three: string): Promise<WriteAnswer>;
  /**
   * `POST move`: a family, or a folder with its twin -- the references to what moved rewritten by the server's repair
   * pass in the same call (Docs/asset-ids.md §4), answered as `rewritten` with their texts before and after. `restore`,
   * an undo's: those texts, written back after the move back where the file still holds its `after` -- one edited since
   * answered as `kept`, left as it is.
   */
  move(from: string, to: string, restore?: ReadonlyArray<RestoreText>): Promise<MoveAnswer>;
  /**
   * `PUT export-as?path=`: a source's export named (`{ as }`, null to take it out) -- or, an undo's, `{ restore }`: the
   * record, the exports and the rewritten files put back as the doing answered them, the exports it set making stopped
   * and trashed (`made`).
   */
  exportAs(path: string, body: { as: string | null } | { restore: { record: string; text: string | null; moved: ReadonlyArray<readonly [string, string]>; made?: readonly string[]; texts: ReadonlyArray<RestoreText> } }): Promise<ExportAsAnswer>;
  /** `POST referrers`: the data files naming any of these files' assets, by uid or by key -- what a Delete is refused by. */
  referrers(paths: readonly string[]): Promise<ReferrersAnswer>;
  /** `POST delete`: whole families to a new slot, or with `only` those files alone; an empty folder removed. */
  remove(paths: readonly string[], only?: boolean): Promise<DeleteAnswer>;
  /** `POST restore`: a slot, or some of its paths, back where they were; `replace` trashes what is there first. */
  restore(slot: string, options?: { paths?: readonly string[]; replace?: boolean }): Promise<RestoreAnswer>;
  /** `POST empty-trash`: for good. */
  emptyTrash(): Promise<WriteAnswer>;
  /** `POST mkdir`. */
  mkdir(path: string): Promise<WriteAnswer>;
  /** `POST copy`: a family into a folder -- its own, for a duplicate. */
  copy(from: string, to: string): Promise<CopyAnswer>;
  /** `POST reveal`: shown in the Finder or the Explorer; with `open`, opened in its application. */
  reveal(path: string, open?: boolean): Promise<WriteAnswer>;
  /** `PUT sidecar?path=`: a source's options, or a folder's defaults. */
  putSidecar(path: string, options: Options): Promise<SidecarAnswer>;
  /**
   * `PUT prefab?path=` with `{ text, create? }`: a prefab file written whole, its text before answered (Docs/prefabs.md §7);
   * a scene the same way (a `.scene` under `scenes/`, the editor's Save), or a level rewritten by a prefab's rename;
   * a material file (a `.material` under `materials/`: New material, the Material block's edits).
   */
  putPrefab(path: string, text: string, create?: boolean): Promise<PrefabAnswer>;
  /** `PUT sidecar?path=` with `{ include }`: a source in the build, or out of it -- its exports to a slot, answered as `slot`. */
  setInclude(path: string, include: boolean): Promise<SidecarAnswer>;
  /** `PUT script?path=` with `{ text, expect }`: a Gladius script written whole, if it is still `expect` on disk (else `409`, `changed`); its export queued. */
  putScript(path: string, text: string, expect: string): Promise<ScriptAnswer>;
  /** A Gladius script's record written back whole -- `text` null takes it away -- if the disk still has `expect` (null: none); else 409. */
  putRecord(path: string, text: string | null, expect: string | null): Promise<ScriptAnswer>;
}

/** A query value: a list is one parameter each. */
type Param = string | number | boolean | undefined | readonly string[];

/** The path argument checked as the server will check it, or refused here in its words. */
function checked(raw: unknown, dirs: readonly string[], folder = false): string {
  const answer = checkedPath(raw, dirs, { folder });
  if ('refused' in answer) throw new ApiRefused(answer.status, { refused: answer.refused });
  return answer.path;
}

/** What a failed answer's body says, as a refusal. */
function refusalOf(status: number, statusText: string, body: unknown): Refusal & Record<string, unknown> {
  if (typeof body === 'object' && body !== null && typeof (body as Refusal).refused === 'string') return body as Refusal & Record<string, unknown>;
  return { refused: status === 0 ? 'the dev server did not answer' : `the dev server answered ${status}${statusText ? ` ${statusText}` : ''}` };
}

function parse(text: string): unknown {
  try {
    return text === '' ? {} : JSON.parse(text);
  } catch {
    return undefined;
  }
}

export function createApi(options: ApiOptions = {}): Api {
  const hot = options.hot ?? import.meta.hot !== undefined;
  const probeMs = options.probeMs ?? 2000;
  const doFetch = (input: string, init?: RequestInit): Promise<Response> => (options.fetch ?? fetch)(input, init);
  let probe: Promise<Online> | null = null;
  /** `online`, once known: what the synchronous `fileUrl` goes by. */
  let known: Online | undefined = hot ? undefined : false;
  let sink: AnswerSink | null = null;
  let bundled: BundleIndex | null = null;
  const bundle = (): BundleIndex => (bundled ??= bundleIndex(options.bundle?.() ?? []));

  const online = (): Promise<Online> =>
    (probe ??= (async (): Promise<Online> => {
      if (!hot) return false;
      try {
        const res = await doFetch(`${API_BASE}tools`, { signal: AbortSignal.timeout(probeMs) });
        if (!res.ok) return false;
        return ((await res.json()) as ToolsAnswer).write ? 'write' : 'read';
      } catch {
        return false;
      }
    })().then((o) => (known = o)));

  /** No dev server: refused here, and nothing sent. */
  const ensure = async (): Promise<void> => {
    if ((await online()) === false) throw new ApiRefused(0, { refused: 'no dev server: this is what the build bundled, read-only (npm run dev to change it)' });
  };

  const url = (route: string, params: Record<string, Param> = {}): string => {
    const q = new URLSearchParams();
    for (const [name, value] of Object.entries(params)) {
      if (value === undefined) continue;
      if (Array.isArray(value)) for (const v of value as readonly string[]) q.append(name, v);
      else q.append(name, String(value));
    }
    const query = q.toString();
    return `${API_BASE}${route}${query ? `?${query}` : ''}`;
  };

  /** A call's answer: its JSON, or the refusal it carries, thrown. */
  async function answered<T>(res: Response): Promise<T> {
    const body = parse(await res.text());
    if (res.ok) return body as T;
    throw new ApiRefused(res.status, refusalOf(res.status, res.statusText, body));
  }

  async function read<T>(route: string, params?: Record<string, Param>): Promise<T> {
    await ensure();
    return answered<T>(await doFetch(url(route, params)));
  }

  /** A mutating call: `since=` the index's `seq`, and its answer handed to the index before anyone else sees it. */
  async function write<T extends WriteAnswer>(method: 'POST' | 'PUT', route: string, params: Record<string, Param>, body: unknown): Promise<T> {
    await ensure();
    const since = sink !== null && sink.seq >= 0 ? sink.seq : undefined;
    const init: RequestInit =
      method === 'POST' || !(body instanceof Blob || body instanceof ArrayBuffer)
        ? { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body ?? {}) }
        : { method, body };
    const answer = await answered<T>(await doFetch(url(route, { ...params, since }), init));
    sink?.take(answer);
    return answer;
  }

  /** A studio route's answer: GET with `query`, or a POST (a PUT, with `method`) of `body` as JSON. */
  async function studioCall<T>(route: string, query?: Record<string, Param>, body?: unknown, method: 'POST' | 'PUT' = 'POST'): Promise<T> {
    await ensure();
    const q = new URLSearchParams();
    for (const [name, value] of Object.entries(query ?? {})) {
      if (value === undefined) continue;
      // A list is the name repeated: `git/diff?paths=a&paths=b`.
      if (Array.isArray(value)) for (const v of value as readonly string[]) q.append(name, v);
      else q.append(name, String(value));
    }
    const search = q.toString();
    const target = `${STUDIO_BASE}${route}${search ? `?${search}` : ''}`;
    const init: RequestInit | undefined = body === undefined ? undefined : { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
    const res = await doFetch(target, init);
    const said = parse(await res.text());
    if (res.ok) return said as T;
    // Reveal's 501 says `{ why }` alone, a save's 412 and 423 `{ why, ... }`: its words, as a refusal's, the rest kept.
    const why = typeof said === 'object' && said !== null && !('refused' in said) && typeof (said as { why?: unknown }).why === 'string' ? (said as { why: string }).why : undefined;
    throw new ApiRefused(res.status, why !== undefined ? { ...(said as Record<string, unknown>), refused: why, why } : refusalOf(res.status, res.statusText, said));
  }

  const studio: StudioCalls = {
    log: (stream, since = 0) => studioCall<LogAnswer>('log', { stream, since }),
    tasks: () => studioCall<TasksAnswer>('tasks'),
    run: (script, args) => studioCall<{ name: string; from: number }>('run', undefined, args === undefined ? { script } : { script, args }),
    cancel: () => studioCall<{ cancelled: string | null }>('cancel', undefined, {}),
    problems: () => studioCall<Problem[]>('problems'),
    broken: () => studioCall<BrokenAnswer>('broken'),
    stack: (stack) => studioCall<MappedStack>('stack', undefined, { stack }),
    probeAck: (id) => studioCall<{ ok: true }>('probe', undefined, { id, ack: true }),
    unhold: () => studioCall<BrokenAnswer>('unhold', undefined, {}),
    checks: () => studioCall<CheckRow[]>('checks'),
    async dist() {
      try {
        return await studioCall<DistAnswer>('dist');
      } catch (err) {
        if (err instanceof ApiRefused && err.status === 404) return null;
        throw err;
      }
    },
    preview: async () => (await studioCall<{ url: string | null }>('preview')).url,
    startPreview: async () => (await studioCall<{ url: string }>('preview', undefined, {})).url,
    reveal: async (path) => void (await studioCall<{ ok: true }>('reveal', undefined, { path })),
    downloadState: (tool) => studioCall<DownloadState>('download', { tool }),
    download: (tool) => studioCall<DownloadState>('download', undefined, { tool }),
    tree: () => studioCall<FilesAnswer>('tree'),
    file: (path, at) => studioCall<FileAnswer>('file', { path, at }),
    save: (path, text, ifMtime) => studioCall<{ mtime: number }>('file', undefined, { path, text, ifMtime }, 'PUT'),
    search: (q, glob) => studioCall<SearchAnswer>('search', { q, glob: glob || undefined }),
    files: {
      make: (path, folder) => studioCall<FileMade>('files/new', undefined, { path, folder }),
      move: (from, to, replace = false) => studioCall<FilesMoved>('files/move', undefined, { from, to, replace }),
      copy: (from, to, replace = false) => studioCall<FilesCopied>('files/copy', undefined, { from, to, replace }),
      remove: (paths, check = false) => studioCall<FilesDeleted>('files/delete', undefined, { paths, check }),
    },
    git: {
      status: () => studioCall<GitStatus>('git/status'),
      log: (count) => studioCall<GitLog[]>('git/log', { count }),
      branches: () => studioCall<GitBranches[]>('git/branches'),
      diff: (paths) => studioCall<GitDiff>('git/diff', { paths }),
      commit: (repo, message, paths) => studioCall<GitCommitted>('git/commit', undefined, { repo, message, paths }),
      checkout: (repo, branch, options = {}) => studioCall<GitAsk | GitRan>('git/checkout', undefined, { repo, branch, ...options }),
      push: (repo, confirm = false) => studioCall<GitAsk | GitRan>('git/push', undefined, { repo, confirm }),
      pull: (repo, confirm = false) => studioCall<GitAsk | GitRan>('git/pull', undefined, { repo, confirm }),
    },
    debug: {
      state: () => studioCall<DebugState>('debug/state'),
      breakpoints: () => studioCall<DebugBreakpoint[]>('debug/breakpoints'),
      toggle: (file, line) => studioCall<DebugBreakpoint[]>('debug/breakpoints', undefined, { file, line }),
      open: async () => void (await studioCall<{ ok: true }>('debug/open', undefined, {})),
    },
  };

  return {
    online,
    connect(next) {
      sink = next;
    },
    studio,

    tools: () => read<ToolsAnswer>('tools'),
    checkTools: () => write<ToolsCheckAnswer>('POST', 'tools/check', {}, {}),
    setTool: (name, path) => write<ToolsCheckAnswer>('PUT', 'tools', { name }, { path }),

    async tree(since) {
      if ((await online()) === false) return bundle().answer;
      return read<TreeAnswer | Diff>('tree', { since });
    },
    async stats(path) {
      const p = checked(path, READ_DIRS);
      await ensure();
      // Not hashed yet is expected while a source is checked again: asked as a 200 (`THUMB_MISS_HEADER`), no red line.
      const res = await doFetch(url('stats', { path: p }), { headers: { [THUMB_MISS_HEADER]: '200' } });
      // Read once: the miss, the stats, or a refusal's words.
      const body = parse(await res.text());
      if ((res.ok || res.status === 404) && (body as { checking?: unknown } | undefined)?.checking === true) return { checking: true };
      if (res.ok) return body as FileStats;
      throw new ApiRefused(res.status, refusalOf(res.status, res.statusText, body));
    },
    fileUrl(path) {
      if (known === false) return bundle().urls.get(path) ?? '';
      return url('file', { path: checked(path, READ_DIRS) });
    },
    async file(path, init) {
      const p = checked(path, READ_DIRS);
      if ((await online()) === false) {
        const hashed = bundle().urls.get(p);
        if (hashed === undefined) throw new ApiRefused(404, { refused: `${p} is not in what the build bundled` });
        return doFetch(hashed, init);
      }
      const res = await doFetch(url('file', { path: p }), init);
      if (!res.ok && res.status !== 304) await answered(res);
      return res;
    },
    async thumb(path, size) {
      const p = checked(path, READ_DIRS);
      await ensure();
      // Misses asked for as 200s (`THUMB_MISS_HEADER`): every first one is expected, and a 404 is a red line in the console.
      const res = await doFetch(url('thumb', { path: p, size }), { headers: { [THUMB_MISS_HEADER]: '200' } });
      if (res.ok && (res.headers.get('content-type') ?? '').startsWith('application/json')) {
        const body = parse(await res.text());
        if (typeof body === 'object' && body !== null) return { miss: body as ThumbMiss };
        throw new ApiRefused(502, refusalOf(502, 'not a thumbnail nor a miss', body));
      }
      if (res.ok) {
        // `"<sha1>-<size>-v<rule>"`: the content's hash, the one place a trashed file's is said with its picture.
        const hash = /^"([0-9a-f]{40})-\d+(?:-v\d+)?"$/.exec(res.headers.get('etag') ?? '')?.[1];
        return { blob: await res.blob(), ...(hash !== undefined ? { hash } : {}) };
      }
      if (res.status === 404) {
        const body = parse(await res.text());
        if (typeof body === 'object' && body !== null && !('refused' in body)) return { miss: body as ThumbMiss };
        throw new ApiRefused(404, refusalOf(404, res.statusText, body));
      }
      return answered<never>(res);
    },
    putThumb: (hash, size, webp) => write<WriteAnswer>('PUT', 'thumb', { hash, size }, webp),
    uses: (key) => read<Use[]>('uses', { key }),
    names: async (dest, names, { folder, source } = {}) => read<NameAnswer[]>('names', { dest: checked(dest, WRITE_DIRS, true), name: names, folder: folder ? '1' : undefined, source }),
    jobs: () => read<JobInfo[]>('jobs'),
    async run(path) {
      const p = checked(path, WRITE_DIRS);
      await ensure();
      // None is expected, every source not yet exported here: asked as a 200 (`THUMB_MISS_HEADER`), no red line in the console.
      const res = await doFetch(url('run', { path: p }), { headers: { [THUMB_MISS_HEADER]: '200' } });
      // The route's one 404 is "no export of it tried here" -- the path rule refuses with 403 or 422 -- so any 404 is none.
      if (res.status === 404) return undefined;
      const run = await answered<Run | { none: true }>(res);
      return 'none' in run ? undefined : run;
    },

    model: async (path) => read<ModelAnswer>('model', { path: checked(path, [ROOTS.source.dir]) }),
    held: () => read<HeldAnswer>('held'),
    tool(name) {
      return {
        async call(path, body) {
          await ensure();
          const target = `${TOOLS_BASE}${encodeURIComponent(name)}/${path.replace(/^\/+/, '')}`;
          const init: RequestInit | undefined = body === undefined ? undefined : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
          return answered<unknown>(await doFetch(target, init));
        },
      };
    },
    async kinds() {
      if ((await online()) === false) return { kinds: kindRows() };
      return read<KindsAnswer>('kinds');
    },
    params: async (path) => read<ParamsAnswer>('params', { path: checked(path, [ROOTS.source.dir]) }),
    async preview(path, params, signal) {
      const p = checked(path, [ROOTS.source.dir]);
      await ensure();
      const res = await doFetch(url('preview', { path: p }), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ params }), ...(signal ? { signal } : {}) });
      if (res.ok && (res.headers.get('content-type') ?? '').startsWith('model/gltf-binary')) {
        return { ok: true, bytes: new Uint8Array(await res.arrayBuffer()), ms: Number(res.headers.get('x-preview-ms') ?? 0) };
      }
      return answered<PreviewFailure>(res);
    },

    async trace(path, signal) {
      const p = checked(path, [ROOTS.source.dir]);
      await ensure();
      return answered<TraceAnswer>(await doFetch(url('trace', { path: p }), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}', ...(signal ? { signal } : {}) }));
    },
    async traceBytes(path, version, signal) {
      const p = checked(path, [ROOTS.source.dir]);
      await ensure();
      const res = await doFetch(url('trace', { path: p, v: version }), signal ? { signal } : {});
      if (res.ok && (res.headers.get('content-type') ?? '').startsWith('model/gltf-binary')) return new Uint8Array(await res.arrayBuffer());
      return answered<never>(res);
    },
    traceFaces: async (path, version) => read<TraceFaces>('trace', { path: checked(path, [ROOTS.source.dir]), v: version, faces: '1' }),

    async importFile(file, query, progress, signal) {
      const dest = checked(query.dest, WRITE_DIRS, true);
      await ensure();
      const stopped = (): ApiRefused => new ApiRefused(0, { refused: `the upload of ${query.name} was stopped: nothing of it was written`, aborted: true });
      if (signal?.aborted) throw stopped();
      const options = query.options !== undefined ? JSON.stringify(query.options) : undefined;
      const since = sink !== null && sink.seq >= 0 ? sink.seq : undefined;
      const target = url('import', { dest, name: query.name, source: query.source, replace: query.replace ?? false, options, include: query.include === false ? false : undefined, drop: query.drop, left: query.left, script: query.script ? true : undefined, since });
      const answer = await new Promise<ImportAnswer>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('PUT', target);
        xhr.upload.onprogress = (e) => progress?.(e.loaded, e.lengthComputable ? e.total : file.size);
        xhr.onload = () => {
          const body = parse(xhr.responseText);
          if (xhr.status >= 200 && xhr.status < 300) resolve(body as ImportAnswer);
          else reject(new ApiRefused(xhr.status, refusalOf(xhr.status, xhr.statusText, body)));
        };
        xhr.onerror = () => reject(new ApiRefused(0, refusalOf(0, '', undefined)));
        xhr.onabort = () => reject(stopped());
        const stop = (): void => xhr.abort();
        signal?.addEventListener('abort', stop, { once: true });
        xhr.onloadend = () => signal?.removeEventListener('abort', stop);
        xhr.send(file);
      });
      sink?.take(answer);
      return answer;
    },
    newModel: async (dir, name) => write<ModelMadeAnswer>('POST', 'model', {}, { dir: checked(dir, WRITE_DIRS, true), name }),
    adopt: async (path) => write<ModelMadeAnswer>('POST', 'adopt', {}, { path: checked(path, WRITE_DIRS) }),
    async exportSources(what, force) {
      const body = 'under' in what ? { under: checked(what.under, WRITE_DIRS, true) } : { paths: what.paths.map((p) => checked(p, WRITE_DIRS)) };
      return write<ExportAnswer>('POST', 'export', {}, force ? { ...body, force: true } : body);
    },
    async claim(job) {
      try {
        await write<WriteAnswer>('POST', 'convert/claim', { job }, {});
        return true;
      } catch (err) {
        if (err instanceof ApiRefused && err.status === 409) return false;
        throw err;
      }
    },
    putIntermediate: (job, glb, three) => write<WriteAnswer>('PUT', 'intermediate', { job, three }, glb instanceof Blob ? glb : new Blob([glb], { type: 'model/gltf-binary' })),
    // `async`, so a path refused by `checked` is a rejection like the server's, never a throw.
    async move(from, to, restore) {
      const answer = await write<MoveAnswer>('POST', 'move', {}, { from: checked(from, WRITE_DIRS, true), to: checked(to, WRITE_DIRS, true), ...(restore && restore.length > 0 ? { restore } : {}) });
      options.went?.({ moved: answer.moved, removed: [] });
      return answer;
    },
    exportAs: async (path, body) => write<ExportAsAnswer>('PUT', 'export-as', { path: checked(path, [ROOTS.source.dir]) }, body),
    // A POST that reads: no `since`, nothing for the index.
    async referrers(paths) {
      const body = JSON.stringify({ paths: paths.map((p) => checked(p, WRITE_DIRS, true)) });
      await ensure();
      return answered<ReferrersAnswer>(await doFetch(url('referrers'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body }));
    },
    async remove(paths, only) {
      const answer = await write<DeleteAnswer>('POST', 'delete', {}, { paths: paths.map((p) => checked(p, WRITE_DIRS, true)), ...(only ? { only: true } : {}) });
      options.went?.({ moved: [], removed: answer.removed });
      return answer;
    },
    restore: async (slot, { paths, replace } = {}) =>
      write<RestoreAnswer>('POST', 'restore', {}, { slot, ...(paths ? { paths: paths.map((p) => checked(p, WRITE_DIRS)) } : {}), ...(replace ? { replace: true } : {}) }),
    emptyTrash: () => write<WriteAnswer>('POST', 'empty-trash', {}, {}),
    mkdir: async (path) => write<WriteAnswer>('POST', 'mkdir', {}, { path: checked(path, WRITE_DIRS, true) }),
    copy: async (from, to) => write<CopyAnswer>('POST', 'copy', {}, { from: checked(from, WRITE_DIRS), to: checked(to, WRITE_DIRS, true) }),
    reveal: async (path, open) => write<WriteAnswer>('POST', 'reveal', {}, { path: checked(path, READ_DIRS, true), ...(open ? { open: true } : {}) }),
    putSidecar: async (path, options) => write<SidecarAnswer>('PUT', 'sidecar', { path: checked(path, [ROOTS.source.dir], true) }, { options }),
    putScript: async (path, text, expect) => write<ScriptAnswer>('PUT', 'script', { path: checked(path, [ROOTS.source.dir]) }, { text, expect }),
    putRecord: async (path, text, expect) => write<ScriptAnswer>('PUT', 'record', { path: checked(path, [ROOTS.source.dir]) }, { text, expect }),
    putPrefab: async (path, text, create) =>
      write<PrefabAnswer>('PUT', 'prefab', { path: checked(path, [KINDS.prefabs.dir, KINDS.levels.dir, KINDS.scenes.dir, KINDS.materials.dir, ENGINE_DATA_KINDS.physicsmaterials!.dir].map((dir) => `${ROOTS.boot.dir}/${dir}`)) }, { text, ...(create ? { create: true } : {}) }),
    setInclude: async (path, include) => write<SidecarAnswer>('PUT', 'sidecar', { path: checked(path, [ROOTS.source.dir], true) }, { include }),
  };
}
