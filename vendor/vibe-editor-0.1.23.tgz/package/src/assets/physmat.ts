/**
 * A physics material file in the Assets panel (Docs/physics.md §4.3, §7): `src/assets/physics-materials/<key>.physmat`,
 * made by New physics material and edited in the inspector as a material is -- its place, its key from its path, and
 * its text: only what differs from the defaults, the uid the pipeline stamped kept by the server.
 *
 * Pure: node tests it (the editor's `physics/physics-pure.test.ts`).
 */
import { ENGINE_DATA_KINDS, ROOTS } from '@vibe/pipeline/kinds';
import { caseKey, type Combine, COMBINES, PHYSICS_MATERIAL_DEFAULTS, type PhysicsMaterialFile } from '@vibe/engine';

/** Its extension, with the dot. */
export const PHYSMAT_SUFFIX = '.physmat';
/** Where they are: `src/assets/physics-materials`. */
export const PHYSMATS_DIR = `${ROOTS.boot.dir}/${ENGINE_DATA_KINDS.physicsmaterials!.dir}`;
/** What New physics material names a file before it is named in place. */
export const NEW_PHYSMAT = 'new-physics-material';

/** A folder physics materials live in. */
export const inPhysmats = (path: string): boolean => path === PHYSMATS_DIR || path.startsWith(`${PHYSMATS_DIR}/`);

/** A physics material's key from its path -- `…/physics-materials/Ice.physmat` is `ice` -- or undefined for any other file. */
export function physmatKeyOf(path: string): string | undefined {
  if (!path.startsWith(`${PHYSMATS_DIR}/`) || !path.toLowerCase().endsWith(PHYSMAT_SUFFIX)) return undefined;
  const key = path.slice(PHYSMATS_DIR.length + 1, -PHYSMAT_SUFFIX.length);
  return key.split('/').some((s) => s.startsWith('_')) ? undefined : caseKey(key);
}

/** The file's text: each field that differs from the defaults, in the fields' order, two spaces, a newline at the end. */
export function physmatText(file: PhysicsMaterialFile): string {
  const out: Record<string, unknown> = {};
  for (const k of ['friction', 'rollingFriction', 'restitution', 'frictionCombine', 'restitutionCombine'] as const) {
    if (file[k] !== PHYSICS_MATERIAL_DEFAULTS[k]) out[k] = file[k];
  }
  return `${JSON.stringify(out, null, 2)}\n`;
}

/** The fields `physmat_set` and the block set, each checked. */
export interface PhysmatChange {
  friction?: unknown;
  rollingFriction?: unknown;
  restitution?: unknown;
  frictionCombine?: unknown;
  restitutionCombine?: unknown;
}

/** `file` with `change` laid over it: the material, or what is wrong with the change -- nothing half applied. */
export function physmatSet(file: PhysicsMaterialFile, change: Readonly<Record<string, unknown>>): PhysicsMaterialFile | string {
  const out = { ...file };
  for (const [k, v] of Object.entries(change)) {
    if (k === 'friction' || k === 'rollingFriction' || k === 'restitution') {
      if (typeof v !== 'number' || !Number.isFinite(v) || v < 0) return `${k}: a number, 0 or more`;
      out[k] = v;
    } else if (k === 'frictionCombine' || k === 'restitutionCombine') {
      if (!(COMBINES as readonly unknown[]).includes(v)) return `${k}: one of ${COMBINES.join(', ')}`;
      out[k] = v as Combine;
    } else return `${k} is no field of a physics material: friction, rollingFriction, restitution, frictionCombine, restitutionCombine`;
  }
  return out;
}
