---
skill: studio
title: The assets
when: Before listing, making, importing, exporting, moving, renaming, deleting or restoring an asset file, or editing a material or a prefab file without opening it
covers:
  tools:
    - asset_list
    - asset_info
    - asset_uses
    - asset_thumb
    - asset_new
    - asset_import
    - asset_copy
    - asset_move
    - asset_delete
    - asset_restore
    - asset_empty_trash
    - asset_options
    - asset_export
    - material_get
    - material_set
    - prefab_info
    - prefab_file
    - prefab_edit
order: 30
---
# The assets

The Assets panel runs along the bottom of the Scene and Model tabs (`4` brings it up): the project's files as the
game sees them, with an inspector for the one chosen. The `asset_*`, `material_*` and `prefab_*` tools do what its
menus, drags, ticks and blocks do, with the same checks. Use them, not file tools, for anything that moves,
renames, deletes or exports an asset: they keep the uids, the keys and the files that name them together.

## Where things are

- **`src/assets/<kind>/`** -- what ships, in folders by kind: `models/`, `textures/`, `sprites/`, `icons/`,
  `fonts/`, `audio/sfx/`, `audio/ui/`, `audio/music/`, `materials/`, `prefabs/`, `scenes/`, `levels/` (and the
  project's own data kinds). Most files here are **exports**, made by the pipeline; a file that ships exactly as
  it was delivered (a `.woff2`, an icon `.svg`) may sit here as a **loose** file.
- **`AssetsSource/`** -- the originals (`.blend`, `.lua` Gladius scripts, `.png`, `.psd`, `.wav` …), in the same
  folders: `AssetsSource/models/props/crate.blend` exports `src/assets/models/props/crate.glb`. Never put an
  original under `src/`.
- **`packs/<name>/`** -- content mounted later (its originals in `AssetsSource/packs/<name>/`); a pack's key
  carries its name: `reef:props/crate`.
- **Data files** -- materials (`.material`), prefabs (`.prefab`), scenes (`.scene`) -- are JSON written in
  `src/assets/` itself; they are their own source.

**A key** is the path under its kind's folder, no extension, lowercased: `models/props/Big Crate.glb` is
`props/big crate`. Code names an asset by its key (`Assets.instance('props/crate')`, `prefab('crates/big')`).
**A uid** (`uid://k7f3q2m9x4b6t`) is the pipeline's, stamped once and never changed: a data file's `"uid"`, a
source's record's, a loose file's `<file>.uid` beside it. A file names another by both, `{ "uid", "key" }`: write
the key, and the pipeline adds the uid. Never make a uid up.

## Read first

- **`asset_list`** -- a folder's files (left out: the top folders), `recursive` for all under it, `kind` to keep
  one kind; paged (`limit`, then `cursor` from `next`). Each file: its role (`source`, `export`, `loose`,
  `record`, `part` …), kind, key, uid, status and whether it is in the build. `trash: true` lists the trash.
- **`asset_info`** -- one file whole: its family (a source's exports, an export's source), its record's options,
  why its status is what it is, **where code names its key** (file and line) and **which data files name it**
  (what would refuse its delete). Read it before moving, renaming or deleting.
- **`asset_uses`** -- just where code names a key (`key`, or a file's `path`).
- **`asset_thumb`** -- a file's thumbnail as an image (64, 128 or 256): a texture, a model's render, a sound's
  waveform. A model's is drawn by the studio tab: with none drawn yet, it says to open its folder in the panel.
- **`prefab_info`** -- the prefabs as compiled now: each key, its entities and node names, what it nests, its pool,
  its instances, and why a file does not compile; with `key`, one prefab whole. **`prefab_file`** -- a prefab's
  JSON as it is on disk. **`material_get`** -- a material's every field (the default where the file says none).

**A source's status**: `current` (its exports match it), `stale` (changed since), `missing` (never exported),
`failed` (the last export failed: `asset_info` says why), `conflict` (two sources want one export),
`excluded` (out of the build), `checking` (not read yet: ask again in a moment).

## The jobs

**Make something** -- `asset_new` with `kind`: `folder` or `pack` (`name` needed), `material` (a white standard),
`physicsmaterial` (a `.physmat` with the defaults, [physics](physics.md)), `prefab` (one entity with a Transform), `variant` (`of` a prefab key: its root an instance of it), `scene` (a
world empty but for its Main Camera), `model` (a Gladius script under `AssetsSource/models/`, `name` needed, its export queued -- then
[the Model tab](model.md)). `in` is the folder (left out, the kind's own), `name` its name. A prefab, a variant
and a scene are written by the editor, so they need the studio open.

**Bring a file in** -- `asset_import`: `from` an absolute path on this machine, `to` a folder. An original goes
under `AssetsSource/` (exported by its recipe; `options` and `include: false` as the import sheet sets them); a
file that ships as it is goes under `src/assets/`. `name` renames it; `replace: true` sends what has that name to
the trash first. It reads only a file inside the person's home folder or the project, nothing hidden (no part of
the path starting with `.`), at most 1 GB -- and one outside the project asks the person first, at every level.
A file already among the project's assets is refused: copy or move it instead.

**Import a model to change in the Model tab** -- `asset_import` with `script: true`, a `.glb` or `.fbx` into a
folder under `AssetsSource/models/`: as Import model…, a Gladius script `<stem>.lua` that imports the file, copied in
beside it as `<stem>.source.glb` (its parts, colours, skin and clips kept), built as the model's export. `model_open`
then opens the script in the Model tab, where the `gladius` skill changes it.

**Export** -- `asset_export` with `paths` (sources, or their exports) or `under` a folder (every stale or
missing source there); `force` exports current ones too. It answers when done within 20 s, else with a job:
`job_wait` it. A source changed on disk exports itself once it is quiet (but a `.blend`, whose Blender step is
slow: it stays `stale` until asked), and so does one whose options changed; `asset_export` is for one left `stale`
or `missing`, or failed, or wanted now.

**Set export options** -- `asset_options` on a source (or a folder, for its defaults): `set` options by name
(`{ "max": 1024 }` for a texture, `{ "textureMax": 1024 }` for a model; `asset_info` shows what the record
sets), `reset: true` to take every one off, and it queues an export of what it changed: its answer's `jobs`,
each one's `id` for `job_wait` -- wait for it before looking at the result. The options are kept in the
source's record, `<stem>.export.json` beside it; a folder's defaults in its `export.json`.

**Name an export** -- `asset_options` with `as` alone (no `set`, `reset` or `include`): the name the source's
export ships as, no extension -- its key's last part, its record's `"as"`, as the menu's Rename the export… --
`null` (or the source's own stem) for none. Its exports move to the new name and every data file naming them
follows by uid; two sources of one stem (a `crate.blend` and a `crate.lua`, a conflict) ship apart once one is
named. A name another export has is refused. Game code naming the old key changes too: read `asset_uses` first.

**In or out of the build** -- a source: `asset_options` with `include: false` (never exported, `excluded`) or
`true`. A loose file: rename it with a leading `_` (`asset_move` with `name: '_crate.png'`), which the build skips;
take the `_` off to put it back.

**Copy** -- `asset_copy`: `paths` into `to`, or beside themselves (`-2`) with no `to`. A copy is a new asset with
its own uid.

**Move or rename** -- `asset_move`: `paths` into the folder `to`, or one path given a new `name` in its folder
(the extension kept when the name has none). Each goes with its family: a source with its exports and record. Every
data file naming what moved -- a prefab nesting it, a scene, a material's map -- is rewritten by uid in the same
move. **Refused while game code names its key**: the code changes first. Read `asset_uses`, change the code to
the new key with Edit (the typecheck fails on it until the move), then move. A change of case alone is never
refused.

**Delete and restore** -- `asset_delete` sends files or folders, each with its family, to the project's trash,
as one slot. **Refused while a data file names any of it** (`asset_info`'s data files): take it out of those first.
Destructive: under Auto it asks the person. `asset_restore` with the `slot` brings it back (all of it, or `paths`
of it; where it was, or into `to`); `asset_list` with `trash: true` lists the slots. `asset_empty_trash` removes
every slot **for good** -- nothing brings it back, not `Z`, not Undo this turn -- so only when the person asks.

**A material** -- `material_set` by `key` (`props/rust`, the file `src/assets/materials/props/rust.material`):
`set` fields -- `type` (standard, physical, basic, toon), `color` `"#rrggbb"`, `roughness`, `metalness`,
`emissive`, `emissiveIntensity`, `map` / `normalMap` / … as a texture key (or null), `opacity`, `transparent`,
`alphaTest`, `side` (front, back, double), `flatShading`, `wireframe`, `depthWrite`. A field the type does not
draw with, or a bad value, refuses the whole call. An entity wears it through `Render.material` (`scene_set`
with the key: [the scene](scene.md)).

**A prefab's root or pool, without opening it** -- `prefab_edit` with `key`: `pool` (`{ warm, max }`, or null),
the root's fields as `set` (`{ "Spin": { "speed": 2 } }`), `add` and `remove` components by name. Checked by the
compile first: one that would not compile is refused, nothing written. Needs the studio open. For anything more
than the root -- its children, their components -- open it: `scene_open_prefab` ([the scene](scene.md)). Every
instance follows the file once it compiles.

## Two paths: the panel's step, or the server's

With a studio tab open, each write (`asset_new`, `asset_move`, `asset_copy`, `asset_delete`, `asset_restore`,
`asset_options`, `material_set`, `asset_export`, `prefab_edit`) is **one step in the Assets panel's history**,
`Claude: …`: the person's `Z` in the panel undoes it, the files it rewrote with it. With no tab open, the dev
server does the same work itself (but `prefab_edit`, and a new prefab, variant or scene, which need the editor);
the answer says so ("No studio tab: the dev server did it"), and only Undo this turn takes it back.
`asset_import` and `asset_empty_trash` are always the server's: no panel step. Every answer says which path it
took. The asset tools work during a playtest too.

## Refusals, and what they mean

| The answer says | What to do |
|---|---|
| Not moved: game code names it: change it there first -- … | change each named file and line to the new key (Edit), then move |
| Not deleted: … names … -- take it out of those first | take it out of the prefabs, scenes and materials `asset_info` lists, or ask the person |
| … is not in the index: asset_list shows what is | a typo, or a file starting with `_` or `.` (no asset); list the folder |
| … is a folder: asset_list lists what is in it | `asset_info` takes a file |
| … is no folder: asset_new kind folder makes one | make the folder first |
| A new prefab is written by the editor … it needs the studio open | ask the person to open the studio |
| … would not parse … fix it by hand first | the file is broken JSON: read `prefab_file` / `material_get`, fix it with the person |
| Not written: … (prefab_edit) | the compile refused it; its words say which field or component |
| … is outside your home folder and the project / is hidden | an import reads neither: ask the person to put the file somewhere it may be read |
| … is one of the project's assets already | `asset_copy` or `asset_move` it |
| …'s thumbnail is made by a studio tab as its tile is drawn | ask the person to open its folder in the panel, then ask again |
| The assets server is not running here | the dev server is not up: ask the person to start it (`npm run dev`) |

## A job, end to end

"Make a rusty material for the big crate, a bit rougher, and use it."

1. `asset_list` with `folder: 'src/assets/materials'` -- no `props/rust` yet, and a `props` folder among its
   folders. `asset_list` on `src/assets/textures/props` -- `props/rust-albedo` is there.
2. `asset_new` with `kind: 'material'`, `in: 'src/assets/materials/props'`, `name: 'rust'` -- made, key
   `props/rust`; one step in the panel. Had the listing no `props` folder, `asset_new` with `kind: 'folder'`,
   `in: 'src/assets/materials'`, `name: 'props'` first.
3. `material_set` with `key: 'props/rust'`, `set: { "color": "#b5652b", "roughness": 0.85, "map": "props/rust-albedo" }`.
4. `scene_query` for the big crate (`prefab: 'crates/big'`, then `scene_entity` to find which entity of it has
   the `Render`), and `scene_set` `Render.material` = `"props/rust"` on that one. For every crate at once, change
   the prefab instead: `prefab_edit` when the root has the `Render`, else `scene_open_prefab`.
5. `view_shot` to look, and say what was made: `Z` in the Assets panel takes back the material, `Z` in the scene
   the crate's change.

## Rules that bite

- Code names keys, files name uids: a move that changes a key code uses is refused until the code changes.
- Never write a uid by hand, and never edit an export under `src/assets/` -- change its source and export it.
- Never a file tool for a move, rename or delete of an asset: the family, the uid and the files naming it would
  be left behind.
- `asset_empty_trash` is for good: only on the person's word.
- Two names that differ only by case are one key: never make the second.
