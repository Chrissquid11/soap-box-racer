/**
 * The editor's preferences, kept in this browser under a key of their own
 * (`vibebase.editor`), apart from the scenes: the gizmo's snapping and its
 * steps, the History card open or shut, the inspector's position in the world
 * or its parent's space, each side panel's width and fold -- by side, or by a
 * name of its own (`panels['assets-folders']`) -- whether the wheel is a
 * trackpad's or a mouse's (`wheel.ts`), the 3D views' navigation (`nav`,
 * Blender's preferences: Docs/navigation.md D1), which columns the entity tree shows (`columns`), the blocks folded
 * shut in either inspector (`folds`), the Assets tool's own (`assets`,
 * Docs/assets-tool.md §8), Claude's column hidden out of the page
 * (`agentMinimized`, Docs/ai-panel.md D2; the AI button and Mod+I bring it back) and its width (`panels.ai`) -- nothing
 * else of it (an `agent` block kept before the column, its fold and height, is read past): its
 * model, effort, review and Auto are the dev server's -- the Config tab's
 * page chosen and its groups folded (`config`, `config/pages.ts`), and the
 * Model tab's model open, layout, shading, grid and stats (`model`,
 * Docs/modeler.md M18), and what Stop does with what was changed while a
 * playtest was paused (`afterPlaytest`, Docs/studio.md §1), and the game
 * view's presets and the one chosen (`gameView`, the project's: Docs/game-view.md §4).
 *
 * - **The person's and the project's, kept apart** (Docs/studio.md, "What the
 *   editor remembers"): `localStorage` is the origin's, and two projects on one
 *   port share it. The fields in `PROJECT_PREFS` -- what is open, where: the
 *   Model tab's script, the Assets panel's folder, its unfolded folders and its
 *   tab, the Config tab's page -- are kept under the project's own key
 *   (`projectKey`, `vibebase.editor@<id>`); the rest, how the person likes the
 *   editor, under `vibebase.editor`, the same in every project. An entry kept
 *   before the split is the person's half alone: its project fields unread.
 * - **Read checked**: anything missing or odd is the default, so an old or
 *   garbled entry never breaks the editor.
 * - **Pure but for `localStorage`**, reached through `globalThis` and forgiven
 *   when it is missing or refuses (node, a blocked page), or a stand-in handed
 *   in: node tests the rest.
 */
import { projectId, projectKey } from '@vibe/engine/project-key';
import { FREE, presetNamed, readPresets, type GamePreset } from './game-view.ts';
import { DEFAULT_KEYMAP, KEYMAPS, type Keymap } from './editor-keys.ts';

/** Where they are kept: the person's here, the project's at `projectKey(KEY)`. Rename per game, as the scenes' key. */
const KEY = 'vibebase.editor';

/**
 * The fields that are the project's, as `<block>.<field>`: they name a file or a folder of it, or what of it is
 * open. Kept under the project's key; every other field is the person's.
 */
export const PROJECT_PREFS = ['model.source', 'assets.folder', 'assets.open', 'assets.tab', 'config.page', 'gameView.preset', 'gameView.presets'] as const;

/** The steps a click on each cycles through: metres, degrees, a share of the size. */
export const STEPS = {
  move: [0.1, 0.25, 0.5, 1],
  turn: [5, 15, 45, 90],
  scale: [0.1, 0.25, 0.5],
} as const satisfies Record<string, readonly number[]>;

export type SnapStep = keyof typeof STEPS;

/** The gizmo's snapping: on or off, and a step for each of its modes. */
export interface Snap {
  on: boolean;
  /** Metres. */
  move: number;
  /** Degrees. */
  turn: number;
  /** A share of the size. */
  scale: number;
}

/** Off, as the gizmo always was without Ctrl or Cmd held; the steps it snapped to then. */
export const SNAP: Readonly<Snap> = { on: false, move: 0.25, turn: 15, scale: 0.1 };

/**
 * How scrolling moves the camera: `auto` tells a trackpad -- two fingers orbit,
 * a pinch zooms, Shift pans -- from a mouse wheel, which zooms, by the events
 * (`wheel.ts`); `trackpad` and `mouse` say which it is.
 */
export type WheelMode = 'auto' | 'trackpad' | 'mouse';
export const WHEEL_MODES: readonly WheelMode[] = ['auto', 'trackpad', 'mouse'];

/**
 * How the 3D views are moved round (Docs/navigation.md D1): Blender's own
 * preferences, each with Blender's default. `emulate3`: Alt with the left
 * button is the middle one (Shift+Alt pans, Ctrl+Alt zooms). `emulateNumpad`:
 * the digit row, `-` and `=` are the numpad while the pointer is over a 3D
 * view. `zoomToMouse`: the wheel zooms toward the pointer, not the view's
 * middle. `orbitSelection`: the orbit turns round the selection's middle.
 * `autoPerspective`: an axis view goes orthographic, and orbiting off it back.
 * `keymap`: Blender's Industry Compatible (the default, D8) or Blender's own (Docs/navigation.md §8).
 */
export interface NavPrefs {
  keymap: Keymap;
  emulate3: boolean;
  emulateNumpad: boolean;
  zoomToMouse: boolean;
  orbitSelection: boolean;
  autoPerspective: boolean;
}
export const NAV: Readonly<NavPrefs> = { keymap: DEFAULT_KEYMAP, emulate3: false, emulateNumpad: false, zoomToMouse: false, orbitSelection: false, autoPerspective: true };

/** The side panels' width as they first open, and the narrowest they go, in CSS pixels. The widest is half the window less `PANEL_ROOM`. */
export const PANEL = 320;
export const PANEL_MIN = 240;
/** What each side panel leaves the scene of its half of the window: `shell.css`' `--ed-left-w` cap, `max(240px, 50vw - 200px)`. */
export const PANEL_ROOM = 200;

/**
 * A side panel's width, `to` held to what the stylesheet shows in a window
 * `window` wide (`--ed-left-w`, `--ed-right-w`): so the width a grip keeps is
 * the one that was seen -- never more than the panel can be.
 */
export const panelWidthFor = (to: number, window: number): number => Math.round(Math.max(PANEL_MIN, Math.min(to, window / 2 - PANEL_ROOM)));

/**
 * The entity tree's columns after the name, in the order a row shows them
 * (`columns.ts`): its id, its prefab, its labels, its components, its layer,
 * its tags. The filter reads all of them whichever are shown.
 */
export const COLUMNS = ['id', 'prefab', 'labels', 'components', 'layer', 'tags'] as const;
export type Column = (typeof COLUMNS)[number];
/** Shown until a person chooses: the id, the layer and the tags. */
export const COLUMNS_ON: readonly Column[] = ['id', 'layer', 'tags'];

/** The side panels kept by a name of their own besides `left` and `right`: at most this many. */
export const PANELS_MAX = 16;

/** What a side panel kept by a name of its own is called: the tool's prefix, `assets-folders`. */
const PANEL_NAME = /^[a-z][a-z0-9-]{0,63}$/;

/** What the Assets tool's sort goes by (Docs/assets-tool.md §4). */
export const ASSET_SORTS = ['name', 'status', 'size', 'modified', 'kind'] as const;
export type AssetSort = (typeof ASSET_SORTS)[number];
/** The Assets tool's thumbnail sizes, in CSS pixels. */
export const THUMBS = [64, 128, 256] as const;
export type Thumb = (typeof THUMBS)[number];
/** The most list columns kept by name, and the most folders kept unfolded: past it, the oldest go. */
export const ASSET_COLUMNS_MAX = 64;
export const OPEN_MAX = 2000;
/** The Assets panel's height, in CSS pixels: what is kept is held to these -- `STRIP_MIN` the list's least; the grid's is a row of tiles (`stripMin`). */
export const STRIP_MIN = 160;
export const STRIP_MAX = 4000;
/** The inspector's preview stage, in CSS pixels: its height as dragged, held to these. */
export const PREVIEW_HEIGHT = 240;
export const PREVIEW_MIN = 120;
export const PREVIEW_MAX = 1200;
/** The Assets panel's height as a double-click on its grip puts it back. */
export const STRIP_HEIGHT = 240;

/**
 * The Assets panel's height as it is drawn and kept: its grip held it between `min`
 * -- `STRIP_MIN` in the list, a row of the smallest tiles with their names in
 * the grid (`files-columns.ts`' `stripMin`) -- and half the window
 * (Docs/assets-tool.md §2), whole pixels; a window made smaller holds a kept
 * height to its half too, a row of tiles before all.
 */
export function stripHeightFor(height: number, windowHeight: number, min = STRIP_MIN): number {
  const least = Math.max(STRIP_MIN, Math.ceil(min));
  const most = Math.max(least, Math.floor(windowHeight / 2));
  return Math.round(Math.max(least, Math.min(Number.isFinite(height) ? height : STRIP_HEIGHT, most)));
}

/** The Assets tool's preferences (Docs/assets-tool.md §8), kept whole: `keepPref('assets', { ...loadPrefs().assets, view })`. */
export interface AssetsPrefs {
  view: 'grid' | 'list';
  thumb: Thumb;
  /** The list's columns past the name, by name: `FILE_COLUMNS` decides (prefs.ts imports no tool). */
  columns: string[];
  sort: { by: AssetSort; down: boolean };
  /** The folder last open ('' for none yet: the tab's root), and the folders unfolded, the latest last. */
  folder: string;
  open: string[];
  /**
   * The Folders column's tab: the root it shows -- `src/assets`, `AssetsSource`, `.trash` -- '' for
   * the first, Assets. Kept as its folder, so prefs.ts knows no root; one kept before the tabs (with
   * `project`, now unread) is the tab of the folder kept.
   */
  tab: string;
  /** The Assets panel folded to a tab on the bottom edge (the Scene tab's room the scene's), and how tall it is unfolded: its grip's. */
  folded: boolean;
  stripHeight: number;
  preview: { wireframe: boolean; skeleton: boolean; backfaces: boolean; loop: boolean; volume: number; height: number };
  /** The files card's Issues: only what needs a hand under the open folder, flat. */
  issues: boolean;
}

export const ASSETS: Readonly<AssetsPrefs> = {
  view: 'grid', thumb: 128, columns: ['build', 'status', 'size', 'key'], sort: { by: 'name', down: false },
  folder: '', open: [], tab: '', folded: false, stripHeight: STRIP_HEIGHT,
  preview: { wireframe: false, skeleton: false, backfaces: false, loop: true, volume: 0.8, height: PREVIEW_HEIGHT },
  issues: false,
};

/** `open` with `folder` unfolded, the latest last, and the oldest gone past `OPEN_MAX`; or with it folded (`on` false). */
export function withOpen(open: readonly string[], folder: string, on = true): string[] {
  const rest = open.filter((f) => f !== folder);
  return on ? [...rest, folder].slice(-OPEN_MAX) : rest;
}

/** The Model tab's shading modes (Docs/modeler.md M10): surfaces, surfaces with their wires, wires alone. */
export const SHADINGS = ['shaded', 'shaded-wireframe', 'wireframe'] as const;
export type Shading = (typeof SHADINGS)[number];
/** The Model tab's layouts: one view, two, four. */
export const MODEL_LAYOUTS = [1, 2, 4] as const;

/**
 * The Model tab's (Docs/modeler.md M18): the script open ('' for none), how many views, the shading, the grid and the
 * stats on or off; and `panel`, the Assets panel unfolded there by a person after the tab folded it for room -- not
 * folded for them again.
 */
export interface ModelPrefs {
  source: string;
  panel: boolean;
  /** The Assets panel is folded because the tab folded it for room: unfolded again as the tab goes -- or after a reload, as it comes back. */
  roomFold: boolean;
  layout: (typeof MODEL_LAYOUTS)[number];
  shading: Shading;
  grid: boolean;
  stats: boolean;
  /** The bones overlay drawn (Docs/modeler.md M32). */
  bones: boolean;
  /** Auto key: a bone let go is written as a key at once (M33, Vibe3D D122) -- kept, so a session later still records. */
  autoKey: boolean;
  /** The clips' playback speed, one of `MODEL_SPEEDS` (M31). */
  speed: (typeof MODEL_SPEEDS)[number];
  /** The build trace's playback speed, 0.1 to 32 (Docs/modeler.md M36, Vibe3D D66): kept between sessions. */
  traceSpeed: number;
  /** The build trace's Total or Last (D66). */
  traceView: 'total' | 'last';
  /**
   * The right panel's blocks folded (true) or unfolded (false) by a person, by
   * key: `params`, `materials`, and `m:<name>` a material's (Docs/modeler.md
   * M24) -- one never chosen takes its default. At most `MODEL_FOLDS_MAX`.
   */
  folds: Record<string, boolean>;
}

/** The clips' speeds (Docs/modeler.md M31): four fixed steps. */
export const MODEL_SPEEDS = [0.25, 0.5, 1, 2] as const;

/** The most fold choices kept: the newest win. */
export const MODEL_FOLDS_MAX = 64;

export const MODEL: Readonly<ModelPrefs> = { source: '', panel: false, roomFold: false, layout: 1, shading: 'shaded', grid: true, stats: true, bones: false, autoKey: false, speed: 1, traceSpeed: 1, traceView: 'total', folds: {} };

/** The side panels, by side -- the tree on the left, the inspector on the right -- and by a name of their own. */
export interface Panels {
  left: Panel;
  right: Panel;
  [pref: string]: Panel | undefined;
}

export interface Prefs {
  snap: Snap;
  /** The History card unfolded: shut until opened once. */
  history: boolean;
  /** The inspector's Position row in the world's space, not its parent's. */
  worldPosition: boolean;
  /**
   * The side panels: `left` and `right` always there, with their defaults; one
   * kept by a name of its own (`sidePanel`'s `pref`) a checked `Panel`, or none
   * -- a new card starts as wide as its side's.
   */
  panels: Panels;
  /** What the wheel is: a trackpad's, a mouse's, or told by its events. */
  wheel: WheelMode;
  /** The 3D views' navigation: Blender's preferences (Docs/navigation.md D1). */
  nav: NavPrefs;
  /** The tree's columns shown, in `COLUMNS`' order; none at all is a choice too. */
  columns: Column[];
  /** Either inspector's blocks folded shut, by name -- the Assets tool's with its prefix, `assets:Stats` -- only those that are. */
  folds: Record<string, true>;
  /** The Assets tool's. */
  assets: AssetsPrefs;
  /**
   * Claude's column hidden: gone from the page, its room given back, until the AI button or Mod+I brings it back.
   * What a new page starts with -- every page of the browser shares it; a page reloaded comes back as its own card
   * was, from its resume record (`ResumeRecord.agentMinimized`), since another page may have written this since.
   */
  agentMinimized: boolean;
  /** The Config tab: the page chosen, and its tree's groups folded. */
  config: ConfigPrefs;
  /** The Model tab: the script open, its views, shading, grid and stats. */
  model: ModelPrefs;
  /** What Stop does with what was changed while the playtest was paused: ask, keep it all, or drop it all. */
  afterPlaytest: AfterPlaytest;
  /**
   * Maximize on Play (Docs/game-view.md §3, D3): a playtest plays over the whole window with every card hidden, as it
   * did before the game view; off (the default), it plays docked, in the scene's room with the cards where they are.
   */
  maximizeOnPlay: boolean;
  /** The selected camera's picture in picture in the Scene view (`camera-view.ts`): shown unless hidden with its ×. */
  cameraPreview: boolean;
  /** The game view (Docs/game-view.md §4): the project's own presets and the one chosen -- both the project's. */
  gameView: GameViewPrefs;
}

/** The game view's block: the preset chosen by its name (`FREE`, Free Aspect, for none) and the project's own presets. */
export interface GameViewPrefs {
  preset: string;
  presets: GamePreset[];
}

/** Free Aspect, and no presets of the project's own. */
export const GAME_VIEW: Readonly<GameViewPrefs> = { preset: FREE, presets: [] };

/** What Stop does with a playtest's paused edits (`playtest-edits.ts`' `keepDecision`): ask each time -- until chosen -- keep all, drop all. */
export type AfterPlaytest = 'ask' | 'keep' | 'drop';
export const AFTER_PLAYTEST: readonly AfterPlaytest[] = ['ask', 'keep', 'drop'];

/** The Config tab's (`config/config.ts`): the page chosen by its id ('' for the first), and the groups folded shut, by name. */
export interface ConfigPrefs {
  page: string;
  folded: string[];
}

/** The first page, every group open. */
export const CONFIG: Readonly<ConfigPrefs> = { page: '', folded: [] };
/** The most groups kept folded: a game's own are a handful. */
export const CONFIG_FOLDED_MAX = 64;

/** A side panel: its width, and whether it is folded away to a tab at the screen's edge. */
export interface Panel {
  width: number;
  folded: boolean;
}

/** The step after `now` in `which`'s list, round to the first again; `back` for the one before. One not in the list goes to the first. */
export function cycle(which: SnapStep, now: number, back = false): number {
  const list: readonly number[] = STEPS[which];
  const at = list.indexOf(now);
  if (at < 0) return list[0]!;
  return list[(at + (back ? list.length - 1 : 1)) % list.length]!;
}

/** One step as the bar says it: `0.25 m`, `15°`, `0.1`. */
export function stepText(which: SnapStep, value: number): string {
  return which === 'move' ? `${value} m` : which === 'turn' ? `${value}°` : String(value);
}

/** Does a drag snap now: the toggle, turned over while Ctrl or Cmd is held. */
export const snapping = (on: boolean, held: boolean): boolean => on !== held;

/** Text as JSON, or null where it is none or garbled: the defaults then, and the next save writes it whole again. */
function parsed(text: string | null): unknown {
  try {
    return JSON.parse(text ?? 'null');
  } catch {
    return null;
  }
}

/** The entry as kept, read: anything missing or odd -- a step not offered any more -- is the default. */
export function readPrefs(text: string | null): Prefs {
  return prefsOf(parsed(text));
}

/** A value as an object to read fields of, or none. */
const record = (value: unknown): Record<string, unknown> | null => (typeof value === 'object' && value !== null && !Array.isArray(value) ? (value as Record<string, unknown>) : null);

/**
 * The two entries as kept, read as one: the person's, with each of `PROJECT_PREFS` taken from the project's -- and
 * from there alone: one in the person's entry (kept before the split, or by another project's page) is not read.
 */
export function joinPrefs(person: string | null, project: string | null): Prefs {
  const all: Record<string, unknown> = { ...(record(parsed(person)) ?? {}) };
  const own = record(parsed(project));
  for (const path of PROJECT_PREFS) {
    const [block, field] = path.split('.') as [string, string];
    const into: Record<string, unknown> = { ...(record(all[block]) ?? {}) };
    const from = record(own?.[block]);
    if (from && field in from) into[field] = from[field];
    else delete into[field];
    all[block] = into;
  }
  return prefsOf(all);
}

/** The preferences as two entries: the person's, every field but `PROJECT_PREFS`, and the project's, those alone. */
export function splitPrefs(prefs: Prefs): { person: Record<string, unknown>; project: Record<string, unknown> } {
  const person: Record<string, unknown> = { ...prefs };
  const project: Record<string, unknown> = {};
  for (const path of PROJECT_PREFS) {
    const [block, field] = path.split('.') as [string, string];
    const { [field]: value, ...rest } = record(person[block]) ?? {};
    person[block] = rest;
    project[block] = { ...(record(project[block]) ?? {}), [field]: value };
  }
  return { person, project };
}

/** The preferences from an entry's data: each field checked, anything missing or odd its default. */
function prefsOf(data: unknown): Prefs {
  const all = data as {
    snap?: Partial<Record<keyof Snap, unknown>>;
    history?: unknown;
    worldPosition?: unknown;
    panels?: Record<string, { width?: unknown; folded?: unknown } | undefined>;
    wheel?: unknown;
    nav?: unknown;
    columns?: unknown;
    folds?: unknown;
    assets?: unknown;
    agentMinimized?: unknown;
    config?: unknown;
    model?: unknown;
    afterPlaytest?: unknown;
    maximizeOnPlay?: unknown;
    cameraPreview?: unknown;
    gameView?: unknown;
  } | null;
  const kept = all?.snap ?? {};
  const step = (which: SnapStep): number => {
    const value = kept[which];
    return typeof value === 'number' && (STEPS[which] as readonly number[]).includes(value) ? value : SNAP[which];
  };
  // A width a screen could have, or null. Half the window is the page's to hold it to, as it is resized.
  const checked = (value: unknown): number | null =>
    typeof value === 'number' && Number.isFinite(value) && value >= PANEL_MIN && value <= 10_000 ? Math.round(value) : null;
  // By side: anything else is the default.
  const width = (value: unknown): number => checked(value) ?? PANEL;
  const panel = (side: 'left' | 'right'): Panel => ({ width: width(all?.panels?.[side]?.width), folded: all?.panels?.[side]?.folded === true });
  const panels: Panels = { left: panel('left'), right: panel('right') };
  // Those kept by a name of their own: each a panel whose width a screen could have, or dropped; a few at most.
  let named = 0;
  for (const [name, entry] of Object.entries((all?.panels as Record<string, unknown> | undefined) ?? {})) {
    if (named >= PANELS_MAX) break;
    if (name === 'left' || name === 'right' || !PANEL_NAME.test(name) || typeof entry !== 'object' || entry === null) continue;
    const w = checked((entry as { width?: unknown }).width);
    if (w === null) continue;
    panels[name] = { width: w, folded: (entry as { folded?: unknown }).folded === true };
    named++;
  }
  const columns = all?.columns;
  return {
    snap: { on: kept.on === true, move: step('move'), turn: step('turn'), scale: step('scale') },
    history: all?.history === true,
    worldPosition: all?.worldPosition === true,
    panels,
    wheel: WHEEL_MODES.find((mode) => mode === all?.wheel) ?? 'auto',
    // A `drag` kept before the navigation was Blender's is not read: a plain left-drag is always a box now.
    nav: readNav(all?.nav),
    // A list: those it names that there are, in their order, each once. Anything else, the defaults. `kind` is `prefab`'s name before prefabs.
    columns: Array.isArray(columns) ? COLUMNS.filter((c) => columns.includes(c) || (c === 'prefab' && columns.includes('kind'))) : [...COLUMNS_ON],
    folds: Object.fromEntries(Object.entries((all?.folds as Record<string, unknown> | undefined) ?? {}).filter(([, v]) => v === true).map(([k]) => [k, true as const])),
    assets: readAssets(all?.assets),
    agentMinimized: all?.agentMinimized === true,
    config: readConfig(all?.config),
    model: readModel(all?.model),
    afterPlaytest: AFTER_PLAYTEST.find((a) => a === all?.afterPlaytest) ?? 'ask',
    maximizeOnPlay: all?.maximizeOnPlay === true,
    cameraPreview: all?.cameraPreview !== false,
    gameView: readGameView(all?.gameView),
  };
}

/** The game view's block as kept, read: the presets checked (`readPresets`), a choice no preset has Free Aspect. */
function readGameView(value: unknown): GameViewPrefs {
  const g = record(value) ?? {};
  const presets = readPresets(g.presets);
  const chosen = typeof g.preset === 'string' ? presetNamed(presets, g.preset) : null;
  return { preset: chosen?.name ?? FREE, presets };
}

/** The navigation's on-or-off preferences: every one of `NavPrefs` but the keymap. */
export type NavSwitch = Exclude<keyof NavPrefs, 'keymap'>;

/** The navigation's block as kept, read: each a boolean, anything else Blender's default -- the keymap one of the two, else Industry Compatible (D8: one never chosen too). */
function readNav(value: unknown): NavPrefs {
  const n = record(value) ?? {};
  const bool = (key: NavSwitch): boolean => (typeof n[key] === 'boolean' ? (n[key] as boolean) : NAV[key]);
  return { keymap: KEYMAPS.find((k) => k === n.keymap) ?? DEFAULT_KEYMAP, emulate3: bool('emulate3'), emulateNumpad: bool('emulateNumpad'), zoomToMouse: bool('zoomToMouse'), orbitSelection: bool('orbitSelection'), autoPerspective: bool('autoPerspective') };
}

/** The Model tab's block as kept, read: each field checked on its own, anything odd its default. */
function readModel(value: unknown): ModelPrefs {
  const m = (typeof value === 'object' && value !== null ? value : {}) as Record<string, unknown>;
  return {
    source: typeof m.source === 'string' && m.source.endsWith('.lua') ? m.source : MODEL.source,
    panel: m.panel === true,
    roomFold: m.roomFold === true,
    layout: MODEL_LAYOUTS.find((l) => l === m.layout) ?? MODEL.layout,
    shading: SHADINGS.find((s) => s === m.shading) ?? MODEL.shading,
    grid: typeof m.grid === 'boolean' ? m.grid : MODEL.grid,
    stats: typeof m.stats === 'boolean' ? m.stats : MODEL.stats,
    bones: m.bones === true,
    autoKey: m.autoKey === true,
    speed: MODEL_SPEEDS.find((v) => v === m.speed) ?? MODEL.speed,
    traceSpeed: typeof m.traceSpeed === 'number' && Number.isFinite(m.traceSpeed) && m.traceSpeed >= 0.1 && m.traceSpeed <= 32 ? m.traceSpeed : MODEL.traceSpeed,
    traceView: m.traceView === 'last' ? 'last' : 'total',
    folds: readFolds(m.folds),
  };
}

/** The fold choices as kept: booleans by a key of at most 200 characters, the last `MODEL_FOLDS_MAX`. */
function readFolds(value: unknown): Record<string, boolean> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return {};
  const pairs = Object.entries(value as Record<string, unknown>).filter((p): p is [string, boolean] => typeof p[1] === 'boolean' && p[0].length <= 200);
  return Object.fromEntries(pairs.slice(-MODEL_FOLDS_MAX));
}

/** The Config tab's block as kept, read: a page's id as a string, the groups folded as strings, each once. */
function readConfig(value: unknown): ConfigPrefs {
  const c = (typeof value === 'object' && value !== null ? value : {}) as { page?: unknown; folded?: unknown };
  return {
    page: typeof c.page === 'string' ? c.page : CONFIG.page,
    folded: strings(c.folded, CONFIG_FOLDED_MAX) ?? [],
  };
}

/** Strings each once, in their order, at most `max` -- the last `max`, the latest being last. Anything but a list: null. */
function strings(value: unknown, max: number): string[] | null {
  if (!Array.isArray(value)) return null;
  const out = [...new Set(value.filter((v): v is string => typeof v === 'string'))];
  return out.slice(-max);
}

/** The Assets tool's block as kept, read: each field checked on its own, anything odd its default. */
function readAssets(value: unknown): AssetsPrefs {
  const a = (typeof value === 'object' && value !== null ? value : {}) as Record<string, unknown>;
  const bool = (v: unknown, fallback: boolean): boolean => (typeof v === 'boolean' ? v : fallback);
  const sort = (typeof a.sort === 'object' && a.sort !== null ? a.sort : {}) as { by?: unknown; down?: unknown };
  const preview = (typeof a.preview === 'object' && a.preview !== null ? a.preview : {}) as Record<string, unknown>;
  const height = a.stripHeight;
  const volume = preview.volume;
  return {
    view: a.view === 'list' || a.view === 'grid' ? a.view : ASSETS.view,
    thumb: THUMBS.find((size) => size === a.thumb) ?? ASSETS.thumb,
    columns: strings(a.columns, ASSET_COLUMNS_MAX) ?? [...ASSETS.columns],
    sort: { by: ASSET_SORTS.find((by) => by === sort.by) ?? ASSETS.sort.by, down: sort.down === true },
    folder: typeof a.folder === 'string' ? a.folder : ASSETS.folder,
    open: strings(a.open, OPEN_MAX) ?? [],
    tab: typeof a.tab === 'string' ? a.tab : ASSETS.tab,
    folded: a.folded === true,
    stripHeight: typeof height === 'number' && Number.isFinite(height) && height >= STRIP_MIN && height <= STRIP_MAX ? Math.round(height) : ASSETS.stripHeight,
    preview: {
      wireframe: preview.wireframe === true,
      skeleton: preview.skeleton === true,
      backfaces: preview.backfaces === true,
      loop: bool(preview.loop, ASSETS.preview.loop),
      volume: typeof volume === 'number' && Number.isFinite(volume) && volume >= 0 && volume <= 1 ? volume : ASSETS.preview.volume,
      height: typeof preview.height === 'number' && Number.isFinite(preview.height) && preview.height >= PREVIEW_MIN && preview.height <= PREVIEW_MAX ? Math.round(preview.height) : ASSETS.preview.height,
    },
    issues: a.issues === true,
  };
}

/** What the preferences need of `localStorage`: a test's stand-in has this shape. */
export type PrefsStore = Pick<Storage, 'getItem' | 'setItem'>;

/** This page's `localStorage`, or none where it is missing or blocked: reaching it can throw. */
function pageStore(): PrefsStore | null {
  try {
    return globalThis.localStorage ?? null;
  } catch {
    return null;
  }
}

/** The two entries as kept, as text: the person's and the project's -- one entry where there is no project id (node, a release). */
function storedTexts(store: PrefsStore | null, id: string): { person: string | null; project: string | null } {
  const person = store?.getItem(KEY) ?? null;
  return { person, project: id === '' ? person : (store?.getItem(projectKey(KEY, id)) ?? null) };
}

/** What this browser keeps for this project and this person, or the defaults. `store` and `id` are a test's. */
export function loadPrefs(store: PrefsStore | null = pageStore(), id: string = projectId()): Prefs {
  try {
    const { person, project } = storedTexts(store, id);
    return joinPrefs(person, project);
  } catch {
    return readPrefs(null);
  }
}

/**
 * What the keymap's coming means to this person (Docs/navigation.md §8): `tell` -- preferences kept before it, with no
 * keymap among them, so their 3D views' keys change under them: told once, the keymap then kept; `mark` -- nothing kept
 * at all, a person new to the editor: the keymap kept, nothing said (so a later page never takes them for the first
 * kind); `none` -- a keymap kept already, or a storage that refuses.
 */
export function keymapNews(store: PrefsStore | null = pageStore(), id: string = projectId()): 'tell' | 'mark' | 'none' {
  try {
    const { person, project } = storedTexts(store, id);
    if (person === null && project === null) return store === null ? 'none' : 'mark';
    return typeof record(record(parsed(person))?.nav)?.keymap === 'string' ? 'none' : 'tell';
  } catch {
    return 'none';
  }
}

/** The preferences as kept, or null where nothing is kept or the storage refuses: a page's own copy then stands. */
export function storedPrefs(store: PrefsStore | null = pageStore(), id: string = projectId()): Prefs | null {
  try {
    const { person, project } = storedTexts(store, id);
    return person === null && project === null ? null : joinPrefs(person, project);
  } catch {
    return null;
  }
}

/**
 * One preference changed and kept: read again first, so whatever else is kept
 * there -- from another tab, say -- stays, with this over it; then written as
 * its two entries, the person's and the project's (`splitPrefs`). A storage that
 * refuses only means it is not kept.
 */
export function keepPref<K extends keyof Prefs>(key: K, value: Prefs[K], store: PrefsStore | null = pageStore(), id: string = projectId()): void {
  const kept = loadPrefs(store, id);
  kept[key] = value;
  try {
    if (id === '') {
      store?.setItem(KEY, JSON.stringify(kept));
      return;
    }
    const { person, project } = splitPrefs(kept);
    store?.setItem(KEY, JSON.stringify(person));
    store?.setItem(projectKey(KEY, id), JSON.stringify(project));
  } catch {
    // Blocked or full: this session keeps them, the next starts from the defaults.
  }
}
