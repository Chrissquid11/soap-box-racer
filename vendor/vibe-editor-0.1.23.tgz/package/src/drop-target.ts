/**
 * The page's drop targets lit while a drag is under way (Docs/properties.md D7, Docs/ecs.md §13): each field
 * that would take what is dragged (`drag-record.ts`' record) lit, each that would not dimmed with its reason --
 * over it as the drag passes, and in its hover text -- and a drop that does not fit doing nothing but say why,
 * a notice (`dropNotice`, the Scene tab's line).
 *
 * - **`dropTarget(el, test, take?)`**: `el` lights by `test` for every drag in the page from now on -- one that
 *   is under way as it is made too, so a field the inspector builds again mid-drag is lit at once. With `take`,
 *   it takes the drop itself: `take(fit)` on a fit. Without, it only lights (a key field takes its drops by the
 *   drag's MIME types, which a drag from outside the page carries too).
 * - **`dragSource(el, record)`**: a drag begun on `el` carries `record()` -- set at its start, cleared at its end.
 *
 * DOM only where called: a node test imports nothing of it.
 */
import { dragging, endDrag, onDrag, startDrag, type DragRecord, type Fit } from './drag-record.ts';

const tests = new WeakMap<Element, (record: DragRecord) => Fit>();
/** The reason of the refusing target the pointer was over last: said if the drag ends there. */
let refused: string | null = null;
let say: ((why: string) => void) | null = null;
/**
 * The target the drag is over, by its field (`data-field`): the inspector builds its fields again as the world ticks,
 * and the one under the pointer is lit as over it -- its reason said -- before the next dragover reaches it.
 */
let over: string | null = null;
let listening = false;

/** Where a refused drop's reason is said: the Scene tab's notice. */
export function dropNotice(notice: (why: string) => void): void {
  say = notice;
}

function light(el: HTMLElement, record: DragRecord): void {
  const test = tests.get(el);
  if (!test) return;
  const fit = test(record);
  el.classList.toggle('ed-drop-ok', fit.ok);
  el.classList.toggle('ed-drop-no', !fit.ok);
  if (fit.ok) delete el.dataset.dropWhy;
  else el.dataset.dropWhy = fit.why;
  const under = over !== null && el.dataset.field === over;
  el.classList.toggle('ed-drop-over', under && fit.ok);
  el.classList.toggle('ed-drop-said', under && !fit.ok);
}

function unlight(el: HTMLElement): void {
  el.classList.remove('ed-drop-ok', 'ed-drop-no', 'ed-drop-over', 'ed-drop-said');
  delete el.dataset.dropWhy;
}

/** Every target in the page lit for `record`, or unlit for none; a refusal the drag ended on said. */
function lightAll(record: DragRecord | null): void {
  for (const el of typeof document === 'undefined' ? [] : document.querySelectorAll<HTMLElement>('[data-drop-target]')) {
    if (record) light(el, record);
    else unlight(el);
  }
  if (record === null && refused !== null) {
    const why = refused;
    refused = null;
    say?.(`Not dropped: ${why}`);
  }
  if (record !== null) refused = null;
  else over = null;
}

/** Once, at the first target: the lighting told of every drag, and a drag ended anywhere ends the record. */
function listen(): void {
  if (listening) return;
  listening = true;
  onDrag(lightAll);
  // A stand-in page (node's tests): the fields light, no window to hear the drags end.
  if (typeof window === 'undefined') return;
  // A source taken out of the page mid-drag (a row drawn again) still hears its own dragend; these are the rest.
  // After the drop's own handlers, which read the record: a task later, not a microtask (those run between listeners).
  window.addEventListener('drop', () => void setTimeout(endDrag, 0), true);
  window.addEventListener('dragend', () => endDrag(), true);
  // A press means any drag is over, however it ended (Firefox and WebKit send a mouse move after dragstart: not that).
  window.addEventListener('pointerdown', () => dragging() !== null && endDrag(), true);
  window.addEventListener('mousedown', () => dragging() !== null && endDrag(), true);
}

/**
 * Why the field under the pointer refuses the drag, or null for one that takes it (or none under it): said if the drag
 * is let go there -- for a field that takes its drop itself (a key field, by the drag's types) as a `take`'s is.
 */
export function refusing(why: string | null): void {
  refused = why;
}

/** A drop taken, then refused by what it would set (the pick's own refusal): said as any refused drop. */
export function dropRefused(why: string): void {
  say?.(`Not dropped: ${why}`);
}

/** `el` lit by `test` for every drag in the page; with `take`, a drop that fits taken, one that does not said. */
export function dropTarget(el: HTMLElement, test: (record: DragRecord) => Fit, take?: (fit: Fit) => void): void {
  listen();
  tests.set(el, test);
  el.dataset.dropTarget = '';
  const now = dragging();
  // Now, and once its maker has named its field (`data-field`, set after it returns): lit as over it if it is.
  if (now) {
    light(el, now);
    queueMicrotask(() => dragging() === now && light(el, now));
  }
  if (!take) return;
  const hover = (event: DragEvent): void => {
    const record = dragging();
    if (!record) return;
    const fit = test(record);
    event.stopPropagation();
    over = el.dataset.field ?? null;
    if (fit.ok) {
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
      refused = null;
      el.classList.add('ed-drop-over');
      el.classList.remove('ed-drop-said');
      return;
    }
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'none';
    refused = fit.why;
    el.classList.add('ed-drop-said');
  };
  // Entered, and every moment over it: a browser sends dragover only as the pointer moves, some of them.
  el.addEventListener('dragenter', hover);
  el.addEventListener('dragover', hover);
  el.addEventListener('dragleave', (event) => {
    const into = event.relatedTarget;
    if (into instanceof Node && el.contains(into)) return;
    // Taken out of the page under the pointer (the inspector built again): the one in its place carries on.
    if (!el.isConnected) return;
    el.classList.remove('ed-drop-over', 'ed-drop-said');
    if (into !== null && over === (el.dataset.field ?? null)) over = null;
    // Into nothing: let go here -- the browser's word for a drop it refused. Anywhere else: not this one's to say.
    if (into !== null) refused = null;
  });
  el.addEventListener('drop', (event) => {
    const record = dragging();
    el.classList.remove('ed-drop-over', 'ed-drop-said');
    if (!record) return;
    const fit = test(record);
    event.preventDefault();
    event.stopPropagation();
    refused = null;
    endDrag();
    if (fit.ok) take(fit);
    else say?.(`Not dropped: ${fit.why}`);
  });
}

/** A drag begun on `el` carries `record()`: set as it starts, cleared as it ends. */
export function dragSource(el: HTMLElement, record: () => DragRecord | null): void {
  el.addEventListener('dragstart', () => {
    const r = record();
    if (r) startDrag(r);
  });
  el.addEventListener('dragend', () => endDrag());
}
