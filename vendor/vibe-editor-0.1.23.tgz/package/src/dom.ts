/**
 * The parts every card is made of -- `el`, `icon`, `button`, `iconButton`,
 * `withKey`, `tip`, and whose a right-click is (`keepsBrowserMenu`) -- with no
 * stylesheet of their own: `shell.ts` re-exports them with
 * its `?inline` sheet, which node cannot load. A module node imports for a test
 * (the Assets tool's preview table, `assets-preview.ts`) makes its elements
 * through here, and touches the DOM only when they are called.
 */
import { ICON, type IconName } from './icons.ts';
import type { Mcp } from './mcp/declare.ts';

export const el = <K extends keyof HTMLElementTagNameMap>(tag: K, className?: string, text?: string): HTMLElementTagNameMap[K] => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
};

export const icon = (name: IconName): SVGElement => {
  const span = el('span');
  span.innerHTML = ICON[name];
  return span.firstElementChild as SVGElement;
};

/** An action's declaration as the element carries it, `data-mcp`: the tool names, `ui`, or `none`. */
export const mcpText = (mcp: Mcp): string => (typeof mcp === 'string' ? mcp : 'none' in mcp ? 'none' : mcp.join(' '));

/**
 * A card's button: the MCP tool that does the same (`Mcp`, `mcp/declare.ts`: a tool's name, `'ui'`, or `{ none: why }`),
 * its text, its title on hover, what a click does; `extra` classes beside `ed-button`: `ed-quiet`, `ed-danger`,
 * `ed-accent`, `ed-small`.
 */
export const button = (mcp: Mcp, text: string, title: string, run: () => void, extra = ''): HTMLButtonElement => {
  const b = el('button', `ed-button ${extra}`, text);
  b.type = 'button';
  b.title = title;
  b.dataset.mcp = mcpText(mcp);
  b.addEventListener('click', run);
  return b;
};

/**
 * A bare button: `mcp` as `button`'s, its class and its text if any, `type="button"` -- what it looks like inside and
 * what a click does are the caller's. For a control the two helpers above do not fit (a tab, a row, a segment, a
 * menu's item); never a raw `el('button')`, which the `mcp` check refuses undeclared.
 */
export const control = (mcp: Mcp, className?: string, text?: string): HTMLButtonElement => {
  const b = el('button', className, text);
  b.type = 'button';
  b.dataset.mcp = mcpText(mcp);
  return b;
};

/** A bare glyph of a button, quiet until the pointer is on it: its name is its title. `mcp` as `button`'s. */
export const iconButton = (mcp: Mcp, glyph: IconName, title: string, run: () => void, className = 'ed-icon-button'): HTMLButtonElement => {
  const b = el('button', className);
  b.type = 'button';
  b.title = title;
  b.dataset.mcp = mcpText(mcp);
  b.append(icon(glyph));
  b.addEventListener('click', run);
  return b;
};

/** The kinds of `<input>` typed into: a right-click there is the browser's, for its copy and paste. */
const TYPED = new Set(['', 'text', 'search', 'number', 'url', 'email', 'password', 'tel']);

/**
 * Does a right-click on `target` keep the browser's own menu? Only in a field
 * of text -- an input typed into, a textarea, an editable block: the filter,
 * the prompt box, a name being typed -- where its Copy and Paste are wanted.
 * Anywhere else in the editor, a right-click the editor has no menu for does
 * nothing (`editor.ts`). Read structurally, so node can test it.
 */
export function keepsBrowserMenu(target: { tagName?: string; type?: string; isContentEditable?: boolean } | null): boolean {
  if (!target) return false;
  if (target.isContentEditable) return true;
  const tag = target.tagName?.toUpperCase();
  return tag === 'TEXTAREA' || (tag === 'INPUT' && TYPED.has((target.type ?? '').toLowerCase()));
}

/** A title with the key that does the same, as a person reads it: `Undo Move (⌘Z)`. */
export const withKey = (text: string, key?: string): string => (key ? `${text} (${key})` : text);

/**
 * An icon of the top bar or the tool strip named: what it does and its key,
 * `Move · W`, as its tooltip (`data-tip`, drawn by shell.css under the bar or
 * beside the strip as the pointer or the focus is on it) and its accessible
 * name. Not `title`: the browser's own would come up over it a second later.
 * Touched only when it changes, as the bar reads it every frame.
 */
export const tip = (b: HTMLElement, text: string, key?: string): void => {
  const said = key ? `${text} · ${key}` : text;
  if (b.dataset.tip === said) return;
  b.dataset.tip = said;
  b.setAttribute('aria-label', said);
};
