/**
 * The entity tool's tree, on the left: the ECS's own hierarchy, read through
 * `src/ecs/inspect.ts`, a row an entity, filtered by name, component, `#label`,
 * `layer:` or `prefab:` (`filter.ts`), walked by the arrow keys.
 *
 * - **A row is columns**: its name (else its prefab) -- the one that takes what
 *   is left, cut short -- then those chosen on the list under the title row's
 *   columns button (`columns.ts`, kept with the preferences): its id, prefab,
 *   labels, components, layer and tags -- the id, the layer and the tags until
 *   chosen otherwise. One grid for the header and every row, so they line up.
 *   The filter reads every one, shown or not.
 * - **Its layer and its tags are controls**: a list of the layers, as the
 *   inspector's, and the tags' drop-down of ticks (`tags-drop.ts`). Either is
 *   that entity's -- the whole selection's, if the row is in it -- one step.
 *
 * - **Each row has its switches** at its end, under an eye, a pointer and a
 *   power sign in the header -- drawn, picked in the scene, on -- each shown
 *   on hover and while set: a click hides, makes unpickable or switches off that entity -- the whole
 *   selection, if the row is in it -- as one step. A row hidden or switched off,
 *   itself or by an ancestor, is dimmed or struck through, and its title says
 *   why and by whom (`switches.ts`).
 *
 * - **A click selects as its modifiers say** (`clickHow`): alone, the row;
 *   Mod -- Cmd on a Mac -- puts it in or takes it out; Shift, every row shown
 *   from the first selected to it, in the order shown, the first still first;
 *   Mod and Shift, those added to what is there.
 * - **Only the rows in view exist**: placed by hand in a spacer as tall as the
 *   whole list, and drawn again as it scrolls, so ten thousand entities scroll
 *   -- which rows, `virtual.ts`'s `range()`.
 * - **A row dragged** onto the middle of another goes under it, the row
 *   outlined; onto its upper or lower quarter in front of or after it, an
 *   insertion line between the rows -- at every level, the roots too, which
 *   the ECS keeps in order (Docs/ecs.md §8); onto the empty list, last of the
 *   roots, the line under the last row. A row of the selection carries the
 *   whole selection, in the tree's order. A folded row held under a drag
 *   unfolds after `SPRING_MS` (1.5 s), so a drop can reach what it holds. The tree only says where
 *   (`drop-zone.ts`), and refuses what cannot be -- under itself, or where it
 *   is already; the edit is the tool's (`reparent`, `reorder`). A prefab
 *   or a model dragged from the Assets panel is shown the same way,
 *   by the same line: made under the row, or a sibling at the line's place
 *   (`placePrefab`). A material dragged onto a row outlines it alone, and is
 *   worn by that entity (`wearMaterial`).
 * - **Its head is the scene's** (`head`): the tree's tools -- fold, unfold,
 *   the columns, Copy, Paste -- at the end of that row, the filter right under
 *   it; how many entities there are is in the filter's placeholder. What was
 *   done (`say`) shows for a few seconds at the card's foot, over the rows,
 *   never moving them.
 * - **A right-click** on a row is its menu (`menu`), on the empty list below
 *   the rows the tool's menu of what can be made there (`blankMenu`).
 * - **Instances are marked** (Docs/prefabs.md §7): an instance's root by its
 *   name, bold in the accent, its prefab's key on hover, the entities inside one tinted, and an entity put
 *   under one that is none of it marked as added (+). `overridden` in the
 *   filter lists the roots of instances that change their prefab.
 */
import { canWear, carriesMaterial, carriesPlaceable, ENTITIES_DRAG } from './prefab-drop.ts';
import { endDrag as endRecord, startDrag } from './drag-record.ts';
import { dropPlace, zoneAt, type Zone } from './drop-zone.ts';
import { movers } from './gesture.ts';
import { createAsk, type Ask } from './ask.ts';
import { keyLabel } from '@vibe/engine/debug';
import {
  childrenOf, componentsOn, Disabled, Hidden, Hierarchy, inTreeOrder, label, Labels, layerOf, madeFromText, Name, NONE, rootsOf, type Entity, type World,
} from '@vibe/engine';
import { COLUMN, flip, grid, inOrder } from './columns.ts';
import { passes, readFilter } from './filter.ts';
import { internal } from './inspector-blocks.ts';
import { itemsOf } from './overrides-edit.ts';
import { layerSelect } from './inspector-state.ts';
import { flipAll } from './multi.ts';
import { COLUMNS, keepPref, loadPrefs, type Column } from './prefs.ts';
import { clickHow, clickOn, type Selection } from './selection.ts';
import { el, icon, iconButton, sidePanel, type PanelHead } from './shell.ts';
import { isOut, SWITCHES, why, type Switch } from './switches.ts';
import { dropUnder } from './drop.ts';
import { shutTags, tagsDrop, tagsState, type TagsHost } from './tags-drop.ts';
import type { Viewport } from './viewport.ts';
import { range } from './virtual.ts';

/** A row's height, in CSS pixels: rows are placed by it. */
const ROW = 24;
/** How long a drag held over a folded row waits before unfolding it. */
const SPRING_MS = 1500;
/** A row's room before its name's cell, as the stylesheet has it, and how far in each level of depth puts the name: CSS pixels. */
const PAD = 6;
const INDENT = 14;
/** Up to this many entities, the tree opens fully unfolded. */
const EXPAND_ALL = 200;
/** How long a line of what was done stays, in milliseconds. */
const SAID = 6000;

interface Row {
  e: Entity;
  depth: number;
  children: number;
}

/** Where a row dragged over another would go: in front of it, after it -- a sibling either way -- or under it. */
type Drop = { e: Entity; how: Zone };

/** Is `e` `ancestor` itself, or anywhere under it: what `ancestor` cannot be put under without a cycle. */
export function within(world: World, e: Entity, ancestor: Entity): boolean {
  const links = world.store(Hierarchy);
  for (let a = e; a !== NONE; a = links.parent[a]! as Entity) if (a === ancestor) return true;
  return false;
}

export interface TreeHost {
  /** A row clicked while an entity is being picked: the pick's. True if it took it -- else it is a click that selects. */
  pick(e: Entity): boolean;
  /** Is an entity being picked: the second click of a double-click is then the pick's, not the camera's. */
  picking(): boolean;
  /** While a typed ref is picked: why `e` would not do, or null -- its row dimmed or lit; undefined, neither. */
  pickMisfit?(e: Entity): string | null | undefined;
  /** A row right-clicked: its menu, at that point on the page. */
  menu(e: Entity, x: number, y: number): void;
  /** The empty list below the rows right-clicked: what can be made there, at that point on the page. */
  blankMenu?(x: number, y: number): void;
  /** A row's eye or power sign clicked: that entity hidden or switched off, or shown or on again -- the selection's, if it is in it. */
  toggle(which: Switch, e: Entity): void;
  /** A row's layer or tags changed, on its entity or the selection: everything read again, one step called `label`. */
  changed(label: string): void;
  /** Rows dropped under another, or onto the empty list (NONE: last of the roots). The rows dragged, in the tree's order. */
  reparent(children: readonly Entity[], parent: Entity): void;
  /** Rows dropped beside another: among `parent`'s children -- the roots, for NONE -- in front of `before`, NONE for last. */
  reorder(children: readonly Entity[], parent: Entity, before: Entity): void;
  /**
   * A prefab dragged from the Assets tool dropped (`prefab-drop.ts`): on a
   * row's middle, as its child; on the line between rows, under `parent` in
   * front of `before` (NONE, last); on the empty list, with `parent` NONE and
   * no `before`: placed as a drop on the scene is.
   */
  placePrefab?(event: DragEvent, parent: Entity, before?: Entity): void;
  /** A material dragged from the Assets tool dropped on `e`'s row (`prefab-drop.ts`): worn by it, its `Render.material`. */
  wearMaterial?(event: DragEvent, e: Entity): void;
  /** Is the instance of `root` marked as one? Not the opened prefab's own, whose entities are the file's. Every one, left out. */
  instanceShown?(root: Entity): boolean;
  /** Did Claude's last turn change `e` (Docs/ai-panel.md D8): a sparkle at its row's end, until the next turn or a look. */
  touched?(e: Entity): boolean;
}

export interface TreeOptions {
  root: HTMLElement;
  world: World;
  selection: Selection;
  viewport: Viewport;
  host: TreeHost;
  /** The tool's buttons on the head's row, after fold, unfold and the columns: Copy, Paste. */
  tools: readonly HTMLElement[];
  /** The scene's header (`EditorContext.head`): at the card's top, the tools and the fold at its row's end. None: a row of their own. */
  head?: PanelHead;
}

export interface Tree {
  /** Its card: a press in it gives the Scene tab's keys to the entities' side. */
  readonly card: HTMLElement;
  /** Rows read again from the world and drawn -- the first time, or the first after another world, unfolded if there are few. */
  refresh(): void;
  /** The selection changed: the row chosen last unfolded to and in view -- in the middle, or, walked to by key, only just. */
  showSelected(): void;
  /** These rows unfolded, at the next refresh: a parent given a child, what a paste made. */
  unfold(entities: Iterable<Entity>): void;
  /** Another world: every row folded, and unfolded again at the next refresh if there are few. */
  reset(): void;
  /** The row `by` below the one the keys go from selected -- with none, the first or the last. */
  walk(by: 1 | -1): void;
  /** That row unfolded (`open`) or folded; unfolded already, → goes to its first child; folded, ← to its parent. */
  fold(open: boolean): void;
  /** Every entity in the tree's order: what the filter shows, while there is one. */
  all(): Entity[];
  /** The filter as typed, trimmed: '' for none. */
  readonly filter: string;
  /** A line of what was done, at the card's foot over the rows, for a few seconds: no row moves. */
  say(text: string, bad?: boolean): void;
  /** A question under the title: Save as prefab's key (`ask.ts`). */
  readonly ask: Ask;
  /** Is one of its drop-downs down -- the columns, a row's tags? Esc puts it up (`shut`), as the tool's `cancel`. */
  readonly dropped: boolean;
  shut(): void;
  /** The card unfolded, if it was folded away: its header -- and a question under it -- seen. */
  showCard(): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}

export function createTree({ root, world, selection, viewport, host, tools, head: sceneHead }: TreeOptions): Tree {
  let rows: Row[] = [];
  const expanded = new Set<number>();
  /** The tree not read yet, or another world in: unfolded fully at the next refresh, if it is small enough. */
  let fresh = true;
  /** The selection moved by the arrow keys: the row scrolled only as far as it needs, not into the middle. */
  let walking = false;
  /** The rows being dragged -- the one pressed, or the selection it is in, in the tree's order -- and where they would go if let go now. */
  let dragged: Entity[] = [];
  /** A folded row held under a drag: unfolded once it has been for `SPRING_MS`, so a drop can reach what it holds. */
  let springAt: Entity = NONE;
  let springTimer: ReturnType<typeof setTimeout> | null = null;
  let dropping: Drop | null = null;

  const card = el('div', 'ed-card ed-side ed-left ed-tree');
  const foldAll = iconButton('ui', 'collapse', 'Fold every row', () => {
    expanded.clear();
    refresh();
    reveal(false);
  });
  const openAll = iconButton('ui', 'expand', 'Unfold every row', () => {
    for (let e = 1; e < world.extent; e++) if (world.alive(e as Entity)) expanded.add(e);
    refresh();
    reveal(false);
  });
  // Which columns the rows show: a list of ticks under the button, down until a press elsewhere.
  const chooser = iconButton('ui', 'columns', 'Columns: which the rows show, past the name', () => (chooserDown ? shutChooser() : showChooser()));
  chooser.setAttribute('aria-haspopup', 'true');
  // On the scene's header row, before the fold: no row of their own, so the filter comes right under the header.
  const headTools = el('span', 'ed-tree-tools');
  headTools.append(foldAll, openAll, chooser, ...tools);
  const head = el('div', 'ed-line');
  if (!sceneHead) head.append(headTools);
  // What was done, for a few seconds, over the foot of the rows: no room kept for it.
  const status = el('div', 'ed-status ed-tree-status');
  status.hidden = true;
  const filter = el('input', 'ed-input');
  filter.type = 'search';
  filter.title = 'Words match a name, a component or a label; #spawn a label with spawn in it; layer:Enemies or layer:2 a layer; prefab:crates/big an instance of it, every entity of it';
  // The columns' names, on the grid the rows have.
  const heads = el('div', 'ed-rows-head');
  const list = el('div', 'ed-rows');
  const spacer = el('div', 'ed-rows-space');
  // Where a dragged row would go, between two rows: in the list, so it scrolls with them.
  const dropLine = el('div', 'ed-drop-line');
  dropLine.hidden = true;
  list.append(spacer, dropLine);
  // A question -- Save as prefab's key -- under the status line, above the rows.
  const askBox = el('div', 'ed-tree-ask');
  const ask = createAsk(askBox);
  card.append(sceneHead ? sceneHead.root : head, askBox, filter, heads, list, status);
  root.append(card);
  // Its right edge drags it wider, and it folds away to the left: both kept for next time. Back, its rows are drawn again.
  const side = sidePanel(root, card, 'left', {
    name: 'Entities',
    changed: (folded) => {
      if (folded) shut();
      else reveal(false);
      drawRows();
    },
  });
  if (sceneHead) sceneHead.end.append(headTools, side.fold);
  else headTools.append(side.fold);

  let quiet: ReturnType<typeof setTimeout> | undefined;

  // ---------------------------------------------------------------- columns

  /** The columns shown past the name, in a row's order: as kept, until ticked otherwise. */
  let columns: Column[] = inOrder(loadPrefs().columns);
  /** Which row's tags are down: kept as the rows are drawn again, as they are after every tick and every scroll. */
  const tags = tagsState(root);
  const chooserList = el('div', 'ed-card ed-menu ed-ticks');
  /** Takes the chooser's list away; null while it is not down. */
  let chooserDown: (() => void) | null = null;

  /** The header's names, for the columns shown; the grid itself is set as the rows are read (`readRows`). */
  function showHeads(): void {
    const name = (text: string, title = '', control = false): HTMLElement => {
      // Over a control, in by its edge, as its words are.
      const cell = el('span', control ? 'ed-over-control' : undefined, text);
      cell.title = title;
      return cell;
    };
    // Over the switches at the end, an eye, a pointer and a power sign: whether each row is drawn, picked in the scene, on.
    const sight = el('span', 'ed-head-sight');
    // Each in a box as wide as a row's switch, so it sits over its own.
    for (const glyph of ['eye', 'pick', 'power'] as const) {
      const box = el('span', 'ed-head-glyph');
      box.append(icon(glyph));
      sight.append(box);
    }
    // Its keys as the keymap has them when the pointer comes onto it (Docs/navigation.md §8: Hide is Ctrl+H or Shift+H).
    const sightTitle = (): string => `The eye: drawn or hidden (${keyLabel(SWITCHES.hidden.key)}). The pointer: picked in the scene, or only selected here (${keyLabel(SWITCHES.unpickable.key)}). `
      + `The power sign: on or switched off (${keyLabel(SWITCHES.disabled.key)}). Each shows on a row on hover and while set; `
      + 'a click on a row\'s is that row\'s, or the selection\'s if the row is in it';
    sight.title = sightTitle();
    sight.addEventListener('pointerenter', () => (sight.title = sightTitle()));
    heads.replaceChildren(name('Name'), ...columns.map((c) => name(COLUMN[c].name, COLUMN[c].title, c === 'layer' || c === 'tags')), sight);
  }

  function showChooser(): void {
    chooserList.replaceChildren(el('div', 'ed-menu-title', 'Columns'));
    for (const column of COLUMNS) {
      const tick = el('label', 'ed-menu-item ed-tick');
      tick.title = COLUMN[column].title;
      const box = el('input');
      box.type = 'checkbox';
      box.checked = columns.includes(column);
      box.addEventListener('change', () => {
        columns = flip(columns, column);
        keepPref('columns', columns);
        showHeads();
        refresh();
      });
      tick.append(box, el('span', 'ed-tick-name', COLUMN[column].name));
      chooserList.append(tick);
    }
    chooserDown = dropUnder(root, chooser, chooserList, shutChooser);
  }

  function shutChooser(): void {
    chooserDown?.();
    chooserDown = null;
  }

  /** Every drop-down of the tree's put up: the columns, a row's tags. */
  function shut(): void {
    shutChooser();
    shutTags(tags);
  }

  showHeads();

  // ---------------------------------------------------------------- rows

  /** `e`'s labels, none if it has no `Labels`. */
  const labelsOf = (e: Entity): readonly string[] => (world.has(e, Labels) ? (world.rawStore(Labels) as { value: string[][] }).value[e]! : []);

  /** Is `root`'s instance marked as one (`instanceShown`)? */
  const shownInstance = (root: Entity): boolean => root !== NONE && (host.instanceShown?.(root) ?? true);

  function readRows(): void {
    const wanted = readFilter(filter.value);
    rows = [];
    if (wanted) {
      // Filtered: a flat list of what matches -- by name, component, label, layer or prefab -- in the tree's order.
      const matched: Entity[] = [];
      for (let i = 1; i < world.extent; i++) {
        const e = i as Entity;
        if (!world.alive(e)) continue;
        const { layer, name } = layerOf(world, e);
        const facts = {
          name: label(world, e), components: componentsOn(world, e).map((t) => t.name), labels: labelsOf(e), layer, layerName: name, prefab: world.prefabOf(e)?.key ?? '',
          overridden: () => world.instanceRoot(e) === e && shownInstance(e) && (itemsOf(world, e)?.items.length ?? 0) > 0,
        };
        if (passes(wanted, facts)) matched.push(e);
      }
      for (const e of inTreeOrder(world, matched)) rows.push({ e, depth: 0, children: 0 });
    } else {
      const walk = (e: Entity, depth: number): void => {
        const children = childrenOf(world, e);
        rows.push({ e, depth, children: children.length });
        if (expanded.has(e)) for (const child of children) walk(child, depth + 1);
      };
      for (const e of rootsOf(world)) walk(e, 0);
    }
    // A pooled prefab's parked instances are not the scene's (Docs/prefabs.md §5): not listed, not counted.
    // How many, where it costs no room: the filter's placeholder.
    const count = world.stats.entities - world.stats.parked;
    const placeholder = `Filter ${count} ${count === 1 ? 'entity' : 'entities'}: name, component, #label, layer:2, prefab:crates`;
    if (filter.placeholder !== placeholder) filter.placeholder = placeholder;
    spacer.style.height = `${rows.length * ROW}px`;
    // The id's column as wide as the highest index needs, so it is read again with the rows.
    card.style.setProperty('--ed-columns', grid(columns, world.extent));
  }

  function drawRows(): void {
    for (const old of list.querySelectorAll('.ed-row')) old.remove();
    const { first, last } = range(list.scrollTop, list.clientHeight, ROW, rows.length);
    const chosen = selection.list;
    const names = world.rawStore(Name) as { value: unknown[] };
    const edit: TagsHost = { world, changed: (label) => host.changed(label) };
    /** The row whose tags are down was drawn, and its list shown again under it. */
    let dropped = false;
    for (let i = first; i < last; i++) {
      const { e, depth, children } = rows[i]!;
      const row = el('div', 'ed-row');
      row.dataset.e = String(e);
      row.style.top = `${i * ROW}px`;
      row.draggable = true;
      const at = chosen.indexOf(e);
      if (at >= 0) row.setAttribute('aria-selected', 'true');
      // The rest of a selection of several, fainter than the one shown.
      if (at > 0) row.classList.add('ed-also');
      // Drawn again mid-drag, as the list scrolls: as it was.
      if (dragged.includes(e)) row.classList.add('ed-dragged');
      if (dropping?.e === e && dropping.how === 'into') row.classList.add('ed-drop-into');
      const caret = el('span', 'ed-caret', children === 0 ? '' : expanded.has(e) ? '▾' : '▸');
      // mcp: ui -- an entity's children unfolded
      caret.addEventListener('click', (event) => {
        event.stopPropagation();
        if (expanded.has(e)) expanded.delete(e);
        else expanded.add(e);
        refresh();
      });
      // Its name; with none, its prefab (`crates/big · rider`, else `entity`), dimmed -- the id is its own column. In by its depth, its caret first.
      const named = world.has(e, Name) && !!names.value[e];
      const cell = el('span', 'ed-cell-name');
      cell.style.paddingLeft = `${depth * INDENT}px`;
      const name = el('span', named ? 'ed-name' : 'ed-name ed-unnamed', named ? label(world, e) : madeFromText(world, e));
      cell.append(caret, name);
      // An instance's root: its name bold in the accent, its prefab's key on hover (the Prefab column shows it); inside one, tinted; put under one and none of it, added.
      const root = world.instanceRoot(e);
      const up = world.instanceRoot(world.store(Hierarchy).parent[e]! as Entity);
      if (root === e && shownInstance(root)) {
        name.classList.add('ed-name-instance');
        name.title = `An instance of ${world.prefabOf(e)!.key}: its overrides are marked in the inspector`;
      } else if (root !== NONE && shownInstance(root)) row.classList.add('ed-row-inner');
      if (up !== NONE && up !== root && shownInstance(up)) {
        const added = el('span', 'ed-added-mark', '+');
        added.title = `Added to ${label(world, up)}'s instance: no entity of ${world.prefabOf(up)!.key} -- Apply it, or Revert it, from the inspector`;
        caret.after(added);
      }
      row.append(cell);
      // What its layer and its tags change: the selection, if the row is in it, as its switches do.
      const group = at >= 0 ? chosen : [e];
      for (const column of columns) {
        const it = columnCell(column, e, group, edit);
        // Not a press on the row: no selecting, no drag from here.
        if (it instanceof HTMLSelectElement || it instanceof HTMLButtonElement) {
          // mcp: ui -- a column's control keeps its click from the row
          it.addEventListener('click', (event) => event.stopPropagation());
          it.draggable = false;
        }
        if (column === 'tags' && tags.open === e) dropped = true;
        row.append(it);
      }
      const switches = el('span', 'ed-row-switches');
      // Claude's last turn changed it (D8): the sparkle in a slot of its own before the switches -- there on every row, so
      // the switches never move -- until the next turn or until it is selected.
      if (host.touched) {
        const mark = el('span', 'ed-row-claude');
        if (host.touched(e)) {
          mark.title = 'Claude\'s last turn changed it -- the mark goes as you select it, or at the next turn';
          mark.append(icon('sparkle'));
        }
        switches.append(mark);
      }
      switches.append(switchButton(e, 'hidden', chosen), switchButton(e, 'unpickable', chosen), switchButton(e, 'disabled', chosen));
      // Out of sight, out of play: dimmed, struck through, and said why on hover.
      const unseen = isOut(world, e, 'hidden');
      const off = isOut(world, e, 'disabled');
      row.classList.toggle('ed-unseen', unseen);
      row.classList.toggle('ed-out', off);
      if (unseen || off) row.title = why(world, e);
      // While an entity is picked for a ref: lit if it fits, dimmed and why if not (Docs/properties.md §3).
      const misfit = host.picking() ? host.pickMisfit?.(e) : undefined;
      row.classList.toggle('ed-pick-fits', misfit === null);
      row.classList.toggle('ed-pick-misfit', typeof misfit === 'string');
      if (typeof misfit === 'string') row.title = `Not this one: ${misfit}`;
      row.append(switches);
      // mcp: scene_select, view_focus -- the scene's selection, a double-click the camera onto it
      row.addEventListener('click', (event) => {
        // A pick takes the first click; the second of a double-click is the camera's.
        const pick = host.picking();
        if (!host.pick(e)) clickOn(selection, e, clickHow(event, true), rows.map((r) => r.e));
        if (event.detail === 2 && !pick) focusOn(e);
      });
      row.addEventListener('contextmenu', (event) => {
        event.preventDefault();
        host.menu(e, event.clientX, event.clientY);
      });
      row.addEventListener('dragstart', (event) => {
        // The selection, if this row is in it -- each not under another of it, in the tree's order -- else this row alone.
        const links = world.store(Hierarchy);
        const ofSelection = selection.list.includes(e);
        const carried = ofSelection ? [...selection.list] : [e];
        dragged = ofSelection ? inTreeOrder(world, movers(carried, (x) => links.parent[x]! as Entity)) : [e];
        event.dataTransfer?.setData('text/plain', String(e));
        // The selection -- if this row is in it, else this row alone -- onto a folder of the Assets tool: saved as a prefab there.
        event.dataTransfer?.setData(ENTITIES_DRAG, JSON.stringify(carried));
        // The same, known while the drag is under way: what a ref field in the inspector lights for (`drag-record.ts`).
        startDrag({ what: 'entities', entities: carried });
        if (event.dataTransfer) event.dataTransfer.effectAllowed = 'copyMove';
        for (const x of dragged) list.querySelector(`.ed-row[data-e="${x}"]`)?.classList.add('ed-dragged');
      });
      row.addEventListener('dragend', endDrag);
      // Over a row: where it would go, if anywhere -- not on itself, nor under itself -- and the list does not hear it.
      row.addEventListener('dragover', (event) => {
        event.stopPropagation();
        // Held over a folded row with children: it unfolds after a while, as a folder in a file browser does.
        springOver(e, children > 0 && !expanded.has(e));
        // A material from the Assets tool: worn by this one -- the row outlined, never a line between. A row with no
        // `Render` cannot wear one: not outlined, not let through, `none`.
        if (host.wearMaterial && carriesMaterial(event)) {
          if (!canWear(world, e)) {
            if (event.dataTransfer) event.dataTransfer.dropEffect = 'none';
            showDrop(null, 0, 0);
            return;
          }
          event.preventDefault();
          if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
          showDrop({ e, how: 'into' }, i, depth);
          return;
        }
        // A prefab or a model from the Assets tool: under this one, or beside it at the line.
        if (host.placePrefab && carriesPlaceable(event)) {
          event.preventDefault();
          if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
          showDrop({ e, how: zoneOf(row, event) }, i, depth);
          return;
        }
        const where = dropOn(e, row, event);
        showDrop(where, i, depth);
        if (!where) return;
        event.preventDefault();
        // Said, not left to the browser: a drag it starts with no effect chosen drops nowhere.
        if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
      });
      row.addEventListener('drop', (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (host.wearMaterial && carriesMaterial(event)) {
          showDrop(null, 0, 0);
          springOver(NONE, false);
          return host.wearMaterial(event, e);
        }
        if (host.placePrefab && carriesPlaceable(event)) {
          showDrop(null, 0, 0);
          springOver(NONE, false);
          const { parent, before } = dropPlace(world.store(Hierarchy), e, zoneOf(row, event), world.firstRoot);
          return host.placePrefab(event, parent, before);
        }
        const where = dropOn(e, row, event);
        const children = dragged;
        endDrag();
        if (where && children.length > 0) dropAt(children, where);
      });
      list.append(row);
    }
    // Its row scrolled away, or its column gone: its list goes too.
    if (tags.open !== null && !dropped) shutTags(tags);
  }

  /**
   * One cell of `e`'s row: text, or its layer's list and its tags' drop-down,
   * which change `group`. Built with the row, each time it is drawn, and only
   * for the columns shown: the list and the drop-down make their choices only
   * once pressed.
   */
  function columnCell(column: Column, e: Entity, group: readonly Entity[], edit: TagsHost): HTMLElement {
    switch (column) {
      case 'id':
        return el('span', 'ed-id', `#${e}`);
      case 'prefab':
        return text('ed-row-prefab', madeFromText(world, e));
      case 'labels':
        return text('ed-row-labels', labelsOf(e).map((l) => `#${l}`).join(' '));
      case 'components':
        // Its switches and labels are shown their own way, not as component names.
        return text('ed-components', componentsOn(world, e).filter((t) => t !== Name && t !== Labels && t !== Hidden && t !== Disabled && !internal(t)).map((t) => t.name).join(' '));
      case 'layer': {
        const pick = layerSelect(world, group, edit.changed, { shows: [e], lazy: true });
        pick.className = world.layerOfEntity(e) === 0 ? 'ed-row-layer ed-none' : 'ed-row-layer';
        return pick;
      }
      case 'tags':
        // It says the row's own; its ticks are the group's.
        return tagsDrop(edit, group, tags, { at: e, shows: [e] })?.button ?? el('span');
    }
  }

  /** A cell of text, cut short, the whole of it on hover. */
  function text(className: string, words: string): HTMLElement {
    const cell = el('span', className, words);
    cell.title = words;
    return cell;
  }

  /**
   * A row's switch: an eye, a pointer or a power sign, shown on hover and while set --
   * faint while only an ancestor's is. A click is the host's, not the row's.
   */
  function switchButton(e: Entity, which: Switch, chosen: readonly Entity[]): HTMLButtonElement {
    const { tag, key, set, unset, means } = SWITCHES[which];
    const own = world.has(e, tag);
    const out = own || isOut(world, e, which);
    const glyph = which === 'disabled' ? 'power' : which === 'hidden' ? (out ? 'eyeOff' : 'eye') : out ? 'pickOff' : 'pick';
    const b = iconButton('scene_flags', glyph, '', () => host.toggle(which, e), 'ed-icon-button ed-row-switch');
    b.setAttribute('aria-pressed', String(own));
    b.classList.toggle('ed-inherited', !own && isOut(world, e, which));
    // What a click does: the selection's, if the row is in it, one way for all.
    const group = chosen.includes(e) ? chosen : [e];
    const on = flipAll(group.map((x) => world.has(x, tag)));
    const who = group.length > 1 ? ` all ${group.length} selected` : ' it';
    b.title = on ? `${set}${who}: ${means} (${keyLabel(key)})` : `${unset}${who} again (${keyLabel(key)})`;
    // Not a press on the row: no selecting, no drag from here.
    b.addEventListener('click', (event) => event.stopPropagation());
    b.draggable = false;
    return b;
  }

  function refresh(): void {
    // Fully open the first time, if small enough; after that, folded as it was left -- Fold all stays folded.
    if (fresh) {
      fresh = false;
      if (world.stats.entities - world.stats.parked <= EXPAND_ALL) for (let e = 1; e < world.extent; e++) expanded.add(e);
    }
    readRows();
    drawRows();
  }

  /**
   * A row double-clicked: the camera onto it. Read off the second click's count,
   * not a `dblclick`: the first click draws the rows again, and the browser sends
   * none for two clicks on two elements.
   */
  function focusOn(e: Entity): void {
    if (!world.alive(e)) return;
    if (!selection.list.includes(e)) selection.choose(e);
    viewport.focus();
  }

  // ---------------------------------------------------------------- dragging rows

  /** Which zone of `row` the pointer is in (`drop-zone.ts`): its upper quarter, its lower, or its middle. */
  function zoneOf(row: HTMLElement, event: DragEvent): Zone {
    const box = row.getBoundingClientRect();
    return zoneAt((event.clientY - box.top) / box.height);
  }

  /**
   * Where the rows being dragged, over `e`'s row, would go: the upper quarter in
   * front of it, the lower quarter after it, the middle under it -- beside a
   * root, among the roots. Null where they cannot, or where they are already:
   * on one of them, under one of them, or nowhere new.
   */
  function dropOn(e: Entity, row: HTMLElement, event: DragEvent): Drop | null {
    const children = dragged;
    if (children.length === 0 || !world.alive(e) || !children.every((c) => world.alive(c))) return null;
    // On one of them, or under one -- which would be a cycle.
    if (children.some((c) => within(world, e, c))) return null;
    const links = world.store(Hierarchy);
    const how = zoneOf(row, event);
    const parent = how === 'into' ? e : (links.parent[e]! as Entity);
    const same = children.every((c) => links.parent[c] === parent);
    if (how === 'into' && same) return null;
    if (children.length > 1) return { e, how };
    const child = children[0]!;
    if (how === 'before' && same && links.nextSibling[child] === e) return null;
    if (how === 'after' && same && links.nextSibling[e] === child) return null;
    return { e, how };
  }

  /** Can the rows dragged go last of the roots -- the empty list, the line under the last row? Not where they are the last roots already, in order. */
  function dropLast(): boolean {
    const children = dragged;
    if (children.length === 0) return false;
    const links = world.store(Hierarchy);
    // Already the last roots, in order: nothing new.
    let r = world.lastRoot as number;
    for (let i = children.length - 1; i >= 0; i--, r = links.prevSibling[r]!) if (children[i] !== r || links.parent[r] !== NONE) return true;
    return false;
  }

  /** The drop shown: a line between rows for before and after, the row outlined for under it; nothing for null. */
  function showDrop(where: Drop | null, at: number, depth: number): void {
    const into = where?.how === 'into' ? where.e : NONE;
    if ((dropping?.how === 'into' ? dropping.e : NONE) !== into) {
      for (const row of list.querySelectorAll('.ed-drop-into')) row.classList.remove('ed-drop-into');
      if (into !== NONE) list.querySelector(`.ed-row[data-e="${into}"]`)?.classList.add('ed-drop-into');
    }
    dropping = where;
    dropLine.hidden = !where || where.how === 'into';
    if (!where || where.how === 'into') return;
    // At the row's own depth, past its caret: a sibling of it.
    dropLine.style.top = `${(where.how === 'before' ? at : at + 1) * ROW}px`;
    dropLine.style.left = `${PAD + depth * INDENT + 14}px`;
  }

  /**
   * The row under a drag now: one folded with children starts the wait to unfold
   * it (`SPRING_MS`); any other row, or none, stops a wait under way. Called on
   * every `dragover`, so only a change of row starts the clock again.
   */
  function springOver(e: Entity, folded: boolean): void {
    if (folded && springAt === e) return;
    if (springTimer !== null) clearTimeout(springTimer);
    springTimer = null;
    springAt = folded ? e : NONE;
    if (!folded) return;
    springTimer = setTimeout(() => {
      springTimer = null;
      springAt = NONE;
      if (!world.alive(e) || expanded.has(e)) return;
      expanded.add(e);
      refresh();
    }, SPRING_MS);
  }

  /** The drag over, however it ended: nothing shown, nothing faint. */
  function endDrag(): void {
    endRecord();
    springOver(NONE, false);
    if (dragged.length === 0 && !dropping && dropLine.hidden) return;
    dragged = [];
    showDrop(null, 0, 0);
    for (const row of list.querySelectorAll('.ed-dragged')) row.classList.remove('ed-dragged');
  }

  /** Rows let go of over another: under it, or siblings in front of it or after it. */
  function dropAt(children: readonly Entity[], { e, how }: Drop): void {
    if (how === 'into') return host.reparent(children, e);
    const { parent, before } = dropPlace(world.store(Hierarchy), e, how, world.firstRoot);
    host.reorder(children, parent, before);
  }

  list.addEventListener('scroll', drawRows);
  filter.addEventListener('input', refresh);
  // Dropped on the list itself, not on a row: no parent.
  list.addEventListener('dragover', (event) => {
    springOver(NONE, false);
    if (host.placePrefab && carriesPlaceable(event)) {
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
      showDrop(null, 0, 0);
      return;
    }
    if (dragged.length === 0) return;
    showDrop(null, 0, 0);
    if (!dropLast()) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
    // Under the last row, at a root's depth.
    dropLine.hidden = false;
    dropLine.style.top = `${rows.length * ROW}px`;
    dropLine.style.left = `${PAD + 14}px`;
  });
  // Right-clicked below the rows: what can be made there. A row's own menu is the row's.
  list.addEventListener('contextmenu', (event) => {
    if (!host.blankMenu || (event.target as Element).closest('.ed-row')) return;
    event.preventDefault();
    host.blankMenu(event.clientX, event.clientY);
  });
  list.addEventListener('dragleave', (event) => {
    if (list.contains(event.relatedTarget as Node | null)) return;
    showDrop(null, 0, 0);
    springOver(NONE, false);
  });
  list.addEventListener('drop', (event) => {
    event.preventDefault();
    springOver(NONE, false);
    if (host.placePrefab && carriesPlaceable(event)) return host.placePrefab(event, NONE);
    const children = dragged;
    const last = dropLast();
    endDrag();
    if (last) host.reparent(children, NONE);
  });
  // A row drawn again as the list scrolled mid-drag may not hear its drag end: the first move after it does.
  list.addEventListener('pointermove', () => endDrag());

  // ---------------------------------------------------------------- by key

  /** The row the keys go from: the one chosen last while it is still selected, else the first selected; -1 for none. */
  function focused(): number {
    const e = selection.list.includes(selection.latest) ? selection.latest : selection.primary;
    return e === NONE ? -1 : rows.findIndex((row) => row.e === e);
  }

  /** The focused row scrolled into view: into the middle, or only just. */
  function reveal(middle: boolean): void {
    const at = focused();
    if (at < 0) return;
    const top = at * ROW;
    const bottom = top + ROW;
    if (top >= list.scrollTop && bottom <= list.scrollTop + list.clientHeight) return;
    list.scrollTop = middle ? top - list.clientHeight / 2 : top < list.scrollTop ? top : bottom - list.clientHeight;
  }

  /** `e` selected by key: its row is then kept in view only as far as it must be. */
  function walkTo(e: Entity): void {
    walking = true;
    try {
      selection.choose(e);
    } finally {
      walking = false;
    }
  }

  function walk(by: 1 | -1): void {
    if (rows.length === 0) return;
    const at = focused();
    const next = at < 0 ? (by > 0 ? 0 : rows.length - 1) : Math.min(rows.length - 1, Math.max(0, at + by));
    if (next !== at) walkTo(rows[next]!.e);
  }

  return {
    card,
    refresh,
    get filter() {
      return filter.value.trim();
    },
    showSelected() {
      const e = selection.latest;
      // Its ancestors unfolded, so its row is there to see.
      const links = world.store(Hierarchy);
      for (let a = e !== NONE ? links.parent[e]! : NONE; a !== NONE; a = links.parent[a]!) expanded.add(a);
      if (card.hidden) return;
      refresh();
      // Picked in the scene, the row comes to the middle; walked to by key, only as far as it must.
      reveal(!walking);
    },
    unfold(entities) {
      for (const e of entities) if (e !== NONE) expanded.add(e);
    },
    reset() {
      expanded.clear();
      fresh = true;
    },
    walk,
    fold(open) {
      const at = focused();
      // The filtered list is flat: nothing to fold.
      if (at < 0 || filter.value.trim()) return;
      const { e, children } = rows[at]!;
      if (children > 0 && expanded.has(e) !== open) {
        if (open) expanded.add(e);
        else expanded.delete(e);
        refresh();
        reveal(false);
      } else if (open) {
        if (children > 0) walk(1);
      } else {
        const parent = world.store(Hierarchy).parent[e]! as Entity;
        if (parent !== NONE) walkTo(parent);
      }
    },
    all() {
      if (filter.value.trim()) return rows.map((row) => row.e);
      const all: Entity[] = [];
      const walk = (e: Entity): void => {
        all.push(e);
        for (const child of childrenOf(world, e)) walk(child);
      };
      for (const e of rootsOf(world)) walk(e);
      return all;
    },
    ask,
    say(text, bad = false) {
      // The whole of it on hover, where one line cuts it short.
      status.textContent = status.title = text;
      status.classList.toggle('ed-bad', bad);
      status.hidden = false;
      clearTimeout(quiet);
      quiet = setTimeout(() => {
        status.textContent = status.title = '';
        status.hidden = true;
      }, SAID);
    },
    get dropped() {
      return chooserDown !== null || tags.open !== null;
    },
    shut,
    showCard: () => side.setFolded(false),
    setVisible(visible) {
      card.hidden = !visible;
      if (!visible) return shut();
      // Its width and fold on screen again: another tool's card on the left may have had the side.
      side.refresh();
      // The columns as kept: Config ▸ Editor ▸ Preferences may have ticked them meanwhile. The rows follow as the tool reads the world.
      const kept = inOrder(loadPrefs().columns);
      if (kept.join() !== columns.join()) {
        columns = kept;
        showHeads();
      }
    },
    dispose() {
      shut();
      clearTimeout(quiet);
      side.dispose();
      card.remove();
    },
  };
}
