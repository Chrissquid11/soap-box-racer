/**
 * What a drag of the Assets panel's files says of their kinds, for a key field
 * to take one (Docs/ecs.md §13, Docs/assets-tool.md §6): one generic way, so
 * every `key(kind)` field anywhere -- `Render.model`, `Render.material`, a
 * project's own `key('Model')`, the Material block's texture maps -- reads it.
 *
 * - **Kinds by type**: a drag's types are readable in `dragover`, its data only
 *   on `drop`, so each kind among the files dragged is a type of its own --
 *   `application/x-vibebase-kind-model` (`KIND_DRAG` + the key type
 *   lowercased: a browser lowercases a drag's types) -- `UNKEYED_DRAG` when
 *   any file is no key (a model's own image, a folder's README), and
 *   `MANY_DRAG` when there are several. Beside the panel's `DRAG_TYPE` and the
 *   scene's and tree's `PREFAB_DRAG`, `MODEL_DRAG` and `MATERIAL_DRAG`, which
 *   stay for them.
 * - **The keys as data** (`KEYS_DRAG`): each file's key, in the drag's order,
 *   read on the drop.
 * - **A field takes it** (`dragTakes`) only when every file is of its kind:
 *   one -- `'one'`, the drop sets it as a pick would -- or several -- `'many'`,
 *   refused and said: one key a field.
 * - **A path's key** is the Assets tool's to say (`dnd.ts`' `keyedFile`, over
 *   the pipeline's own `keyOf`), handed in to `dragCarries`: only the editor's
 *   `assets/` imports the pipeline.
 *
 * Pure: node tests it (`asset-drag.test.ts`).
 */

/** A drag's type for each kind among its files: this, then the key type lowercased (`…-kind-model`). */
export const KIND_DRAG = 'application/x-vibebase-kind-';

/** A drag with a file that is no key among its files: no key field takes it. */
export const UNKEYED_DRAG = 'application/x-vibebase-unkeyed';

/** A drag of several files: a key field refuses it, saying one. */
export const MANY_DRAG = 'application/x-vibebase-many';

/** The keys a drag carries, as JSON: each file's, in order (`''` for one that is no key). */
export const KEYS_DRAG = 'application/x-vibebase-keys';

/** What a drag of `files` (`dnd.ts`' `keyedFile` each: a key and its kind's key type, or null) carries for key fields: its types, and the keys as `KEYS_DRAG`'s data. */
export function dragCarries(files: readonly ({ kind: string; key: string } | null)[]): { types: string[]; keys: string[] } {
  const types: string[] = [];
  for (const f of files) {
    const type = f === null ? UNKEYED_DRAG : KIND_DRAG + f.kind.toLowerCase();
    if (!types.includes(type)) types.push(type);
  }
  if (files.length > 1) types.push(MANY_DRAG);
  return { types, keys: files.map((f) => f?.key ?? '') };
}

/**
 * Does a drag of these `types` suit a key field of `kind`: `'one'` -- a file of that kind, taken -- `'many'` --
 * several, every one of that kind, refused and said -- or null: none of it, or not all (the cursor says no).
 */
export function dragTakes(types: readonly string[], kind: string): 'one' | 'many' | null {
  const kinds = types.filter((t) => t.startsWith(KIND_DRAG) || t === UNKEYED_DRAG);
  if (kinds.length !== 1 || kinds[0] !== KIND_DRAG + kind.toLowerCase()) return null;
  return types.includes(MANY_DRAG) ? 'many' : 'one';
}

/** The first key a drop carries (`KEYS_DRAG`), or null. Only on `drop`. */
export function droppedKey(data: { getData(type: string): string } | null): string | null {
  let keys: unknown;
  try {
    keys = JSON.parse(data?.getData(KEYS_DRAG) || '[]');
  } catch {
    return null;
  }
  return Array.isArray(keys) && typeof keys[0] === 'string' && keys[0] !== '' ? keys[0] : null;
}
