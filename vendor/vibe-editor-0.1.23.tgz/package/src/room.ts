/**
 * The scene's room, as numbers (Docs/game-view.md §3, Docs/ai-panel.md §3): what the docked cards leave of the canvas
 * -- right of the tool strip and the left panel, left of the right panel and Claude's column docked, under the top bar,
 * above a card along the bottom and the dock -- and whether Claude's column docks or lies over the scene (D5).
 * `editor.ts` measures the cards (`roomPastCards`) and hands their boxes here; node tests it (`room.test.ts`).
 */

/** A box on the page, in CSS pixels. */
export interface Box {
  readonly left: number;
  readonly top: number;
  readonly right: number;
  readonly bottom: number;
}

/**
 * A card as the room sees it: `left` the strip or a left panel (the room starts at its right), `right` a right panel or
 * Claude's column docked (it ends at its left), `bottom` a card along the bottom shown whole (the Assets panel; folded
 * to its tab it sits over the game, and is `over`), `dock` the History card's column (the room ends at its top), `over`
 * anything that lies over the scene and takes nothing from it -- Claude's column overlaid among them.
 */
export type CardSide = 'left' | 'right' | 'bottom' | 'dock' | 'over';

export interface CardBox extends Box {
  readonly side: CardSide;
}

/** The least room Claude's column leaves the scene docked, in CSS pixels: less, and it lies over the scene (D5). */
export const AI_ROOM_MIN = 400;

/** The width Claude's column starts at, in CSS pixels (`panels.ai`, D1). */
export const AI_WIDTH = 360;

/**
 * The room between `cards` on `canvas`, its top no higher than `under` (the top bar's end and a gap). A card with no
 * size is not there. However little is left: the caller says what is too little.
 */
export function roomBetween(canvas: Box, under: number, cards: readonly CardBox[]): Box {
  let { left, right, bottom } = canvas;
  const top = Math.max(canvas.top, under);
  for (const card of cards) {
    if (card.right - card.left <= 0 || card.bottom - card.top <= 0) continue;
    if (card.side === 'left') left = Math.max(left, card.right);
    else if (card.side === 'right') right = Math.min(right, card.left);
    else if (card.side === 'bottom' || card.side === 'dock') bottom = Math.min(bottom, card.top);
  }
  return { left, top, right, bottom };
}

/**
 * Does Claude's column dock (true) or lie over the scene (false)? Decided on the room as if it were hidden, so the
 * answer never flips back and forth with itself: measured with the column docked, the room is its width narrower.
 * It docks while what it leaves is `AI_ROOM_MIN` or more -- not a media query: the side panels, folded or not, a tab
 * with none (Studio), the window's width, all count.
 */
export function aiDocks(roomWidth: number, aiWidth: number, docked: boolean): boolean {
  const hidden = roomWidth + (docked ? aiWidth : 0);
  return hidden - aiWidth >= AI_ROOM_MIN;
}

/**
 * `room` kept clear of what lies over it (Claude's column overlaid, D5): its right end at the left of any box that
 * reaches into it from the right -- where the view cube and a camera's preview, placed at the room's right, go. Never
 * narrower than nothing.
 */
export function clearOf(room: Box, over: readonly Box[]): Box {
  let right = room.right;
  for (const b of over) {
    if (b.right - b.left <= 0 || b.bottom - b.top <= 0 || b.right <= room.left || b.left >= right) continue;
    right = Math.max(room.left, b.left);
  }
  return { ...room, right };
}
