/**
 * The editor's glyphs, as inline SVG, CrabParty's style: `icon(name)` in
 * `shell.ts` makes one, and a tool names one for its button (`IconName`).
 *
 * Drawn rather than generated: a toolbar icon has to be legible at 22 px and
 * take its colour from the CSS around it, so the chosen tool can be amber
 * without a second file. Each is a 24x24 view box in `currentColor`.
 */

const wrap = (body: string): string =>
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
  + `${body}</svg>`;

export const ICON = {
  /** The editor's mark: a crate seen in three-quarter. */
  props: wrap('<path d="M12 2.6 21 7.4v9.2L12 21.4 3 16.6V7.4Z"/><path d="M3 7.4 12 12l9-4.6M12 12v9.4" stroke-opacity=".55"/>'),
  /** Entities: a tree, a parent and two children. */
  tree: wrap(
    '<rect x="3.5" y="3.5" width="7" height="5" rx="1.2"/><rect x="13.5" y="9.5" width="7" height="5" rx="1.2"/>'
    + '<rect x="13.5" y="16" width="7" height="5" rx="1.2"/><path d="M7 8.5V18.5h6.5M7 12h6.5" stroke-opacity=".55"/>',
  ),
  /** Systems: bars, the members slot by slot. */
  systems: wrap('<path d="M4 20V11M9 20V5M14 20v-7M19 20V8"/><path d="M3 20.5h18" stroke-opacity=".55"/>'),
  /** The Studio tab: a terminal, its prompt and cursor. */
  terminal: wrap('<rect x="3" y="4.5" width="18" height="15" rx="2"/><path d="m7 9.5 3 2.5-3 2.5"/><path d="M12.5 15h4.5" stroke-opacity=".55"/>'),
  /** Scenes: worlds kept, one on another. */
  scenes: wrap('<path d="M12 3.5 20.5 8 12 12.5 3.5 8Z"/><path d="m3.5 12 8.5 4.5 8.5-4.5M3.5 16l8.5 4.5 8.5-4.5" stroke-opacity=".55"/>'),
  /** The Config tab: three sliders, each at its own setting. */
  config: wrap('<path d="M4 6.5h9M17 6.5h3M4 12h3M11 12h9M4 17.5h11M19 17.5h1" stroke-opacity=".55"/><circle cx="15" cy="6.5" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="17.5" r="2"/>'),
  /** Select: the arrow, because nothing else reads as "pick". */
  select: wrap('<path d="M5 3.2 18.6 11l-5.9 1.4L10.2 18Z" fill="currentColor" fill-opacity=".2"/>'),

  /** The gizmo's three modes: arrows four ways, an arrow round, a corner pulled out. */
  move: wrap('<path d="M12 3.5v17M3.5 12h17" stroke-opacity=".55"/><path d="m9 6.5 3-3 3 3M9 17.5l3 3 3-3M6.5 9l-3 3 3 3M17.5 9l3 3-3 3"/>'),
  rotate: wrap('<path d="M19.5 12a7.5 7.5 0 1 1-2.4-5.5"/><path d="M19.6 3.6v4.6H15"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/>'),
  scale: wrap('<rect x="3.5" y="10.5" width="10" height="10" rx="1.2" stroke-opacity=".55"/><path d="M10.5 13.5 20 4M14 4h6v6"/>'),
  /** The gizmo's axes: the world's, a globe; the entity's own, a crate with its three. */
  world: wrap(
    '<circle cx="12" cy="12" r="8.5"/>'
    + '<path d="M3.5 12h17M12 3.5c2.4 2.3 3.6 5.1 3.6 8.5s-1.2 6.2-3.6 8.5c-2.4-2.3-3.6-5.1-3.6-8.5s1.2-6.2 3.6-8.5Z" stroke-opacity=".55"/>',
  ),
  local: wrap('<path d="M12 2.6 21 7.4v9.2L12 21.4 3 16.6V7.4Z" stroke-opacity=".55"/><path d="M12 12V5.5M12 12l5.6 3M12 12l-5.6 3"/>'),

  /** Snapping: a horseshoe magnet, its poles at the bottom. */
  magnet: wrap('<path d="M6 4.5v7a6 6 0 0 0 12 0v-7"/><path d="M6 4.5h3.5v7a2.5 2.5 0 0 0 5 0v-7H18" stroke-opacity=".55"/><path d="M6 8h3.5M14.5 8H18"/>'),
  /** Everything framed: four corners round the view. */
  /** The collider overlay: a wire box drawn dashed, its centre marked. */
  colliders: wrap('<path d="M12 2.6 21 7.4v9.2L12 21.4 3 16.6V7.4Z" stroke-dasharray="2.4 1.9"/><circle cx="12" cy="12" r="2"/>'),
  frame: wrap('<path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"/><rect x="8.5" y="8.5" width="7" height="7" rx="1.2" stroke-opacity=".55"/>'),
  /** The tree's columns, which to show: a table, its columns ruled. */
  columns: wrap('<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M9.5 4.5v15M14.5 4.5v15" stroke-opacity=".55"/>'),
  /** The tree folded up -- chevrons in to a line -- or opened out, chevrons away from it. */
  collapse: wrap('<path d="m8 5 4 4 4-4M8 19l4-4 4 4" stroke-opacity=".55"/><path d="M5 12h14"/>'),
  expand: wrap('<path d="m8 9 4-4 4 4M8 15l4 4 4-4" stroke-opacity=".55"/><path d="M5 12h14"/>'),
  /** A side panel folded away to the left, or the right: its edge, and a chevron toward it. */
  foldLeft: wrap('<path d="M4.5 4v16" stroke-opacity=".55"/><path d="m14 7-5 5 5 5M19.5 12H9"/>'),
  foldRight: wrap('<path d="M19.5 4v16" stroke-opacity=".55"/><path d="m10 7 5 5-5 5M4.5 12H15"/>'),
  /** A card along the bottom folded down to its title row, or back up: the foot, and a chevron toward it or away. */
  foldDown: wrap('<path d="M4 19.5h16" stroke-opacity=".55"/><path d="m7 10 5 5 5-5M12 4.5V15"/>'),
  foldUp: wrap('<path d="M4 19.5h16" stroke-opacity=".55"/><path d="m7 9 5-5 5 5M12 15V4"/>'),
  /** Something to know before an edit: a triangle with a mark. */
  warn: wrap('<path d="M12 3.8 21.2 19.5H2.8Z"/><path d="M12 10v4.2M12 17.2v.1"/>'),

  /** Scale's lock: shut, the three axes go together; open, each by itself. */
  lock: wrap('<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3"/>'),
  unlock: wrap('<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V7.5a4 4 0 0 1 7.6-1.7" stroke-opacity=".55"/>'),

  /** Copy: one sheet over another. Paste: a clipboard. */
  copy: wrap(
    '<rect x="8.5" y="8.5" width="11" height="11" rx="1.8"/>'
    + '<path d="M15.5 8.5V6.3a1.8 1.8 0 0 0-1.8-1.8H6.3a1.8 1.8 0 0 0-1.8 1.8v7.4a1.8 1.8 0 0 0 1.8 1.8h2.2" stroke-opacity=".55"/>',
  ),
  paste: wrap(
    '<path d="M9 5H7a1.8 1.8 0 0 0-1.8 1.8v12.4A1.8 1.8 0 0 0 7 21h10a1.8 1.8 0 0 0 1.8-1.8V6.8A1.8 1.8 0 0 0 17 5h-2"/>'
    + '<rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4" stroke-opacity=".55"/>',
  ),
  /** Shown or hidden (`Hidden`): an eye open, and the same eye struck through. */
  eye: wrap('<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/>'),
  eyeOff: wrap(
    '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z" stroke-opacity=".55"/>'
    + '<circle cx="12" cy="12" r="2.8" stroke-opacity=".55"/><path d="M4.5 19.5 19.5 4.5"/>',
  ),
  /** Picked in the scene or not (`Unpickable`): the pointer, and the same pointer struck through. */
  pick: wrap('<path d="M6 3.5 18 11l-5.2 1.3L10.4 17.5Z" fill="currentColor" fill-opacity=".2"/>'),
  pickOff: wrap('<path d="M6 3.5 18 11l-5.2 1.3L10.4 17.5Z" stroke-opacity=".55"/><path d="M4.5 19.5 19.5 4.5"/>'),
  /** In play or switched off (`Disabled`): the power sign. */
  power: wrap('<path d="M12 3.5V11.5"/><path d="M7.4 6.4a7.5 7.5 0 1 0 9.2 0" stroke-opacity=".55"/>'),
  /** A tag: a hash, the mark of a tag() component. */
  tag: wrap('<path d="M9.5 4 7.5 20M16.5 4l-2 16M4.5 9.5h16M3.5 15h16"/>'),
  /** Labels: a tag on its string. */
  label: wrap('<path d="M3.5 12.4V4.5a1 1 0 0 1 1-1h7.9l8.1 8.1a1.4 1.4 0 0 1 0 2l-6.9 6.9a1.4 1.4 0 0 1-2 0Z"/><circle cx="8.2" cy="8.2" r="1.4" stroke-opacity=".55"/>'),
  /** History: a clock wound back. */
  history: wrap('<path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3"/><path d="M4.3 3.8v3.6h3.6"/><path d="M12 8v4.3l2.8 1.7" stroke-opacity=".55"/>'),

  /** The keys card: a keyboard, its keys as dots and a space bar. */
  keys: wrap(
    '<rect x="2.5" y="6" width="19" height="12" rx="2.2"/>'
    + '<path d="M6.5 10h.01M10 10h.01M13.5 10h.01M17 10h.01M8 14h8" stroke-width="2" stroke-opacity=".7"/>',
  ),

  undo: wrap('<path d="M4 8h9.5a5.5 5.5 0 1 1 0 11H8"/><path d="M4 8l4-4M4 8l4 4"/>'),
  redo: wrap('<path d="M20 8h-9.5a5.5 5.5 0 1 0 0 11H16"/><path d="m20 8-4-4m4 4-4 4"/>'),
  /** Minimize the agent's card: a line along the foot, as a window's. */
  minimize: wrap('<path d="M5.5 17.5h13"/>'),
  /** Maximize on Play: a screen, its four corners pushed out. */
  maximize: wrap('<rect x="7.5" y="8.5" width="9" height="7" rx="1" stroke-opacity=".55"/><path d="M3.5 8V4.5H7M17 4.5h3.5V8M20.5 16v3.5H17M7 19.5H3.5V16"/>'),
  /** AI: Claude's card shown or hidden -- a four-point star, a small one beside it. */
  sparkle: wrap('<path d="M10.5 3.5c.6 4.2 2.3 5.9 6.5 6.5-4.2.6-5.9 2.3-6.5 6.5-.6-4.2-2.3-5.9-6.5-6.5 4.2-.6 5.9-2.3 6.5-6.5Z" fill="currentColor" fill-opacity=".2"/><path d="M17.5 14.5c.3 2 1 2.7 3 3-2 .3-2.7 1-3 3-.3-2-1-2.7-3-3 2-.3 2.7-1 3-3Z" stroke-opacity=".55"/>'),
  save: wrap('<path d="M4.5 4.5h11L20 9v10.5h-15Z"/><path d="M8.5 4.5v5h7M8 19.5v-5h8v5" stroke-opacity=".55"/>'),
  play: wrap('<path d="M7 4.5 19.5 12 7 19.5Z" fill="currentColor" fill-opacity=".2"/>'),
  close: wrap('<path d="M6 6l12 12M18 6 6 18"/>'),
  /** The play strip's (`play` and `pause` its other two): a playtest stopped, a square; one tick on, a triangle to a bar. */
  stop: wrap('<rect x="5.5" y="5.5" width="13" height="13" rx="1.5" fill="currentColor" fill-opacity=".2"/>'),
  step: wrap('<path d="M5.5 5 15 12l-9.5 7Z" fill="currentColor" fill-opacity=".2"/><path d="M18.5 5v14"/>'),

  /** The Assets tool: a folder, a file with its corner turned, a box of art -- its tab -- and a grid of tiles or a list's lines. */
  folder: wrap('<path d="M3.5 6.5a1.5 1.5 0 0 1 1.5-1.5h4.2l2 2.2H19a1.5 1.5 0 0 1 1.5 1.5v9.3A1.5 1.5 0 0 1 19 19.5H5A1.5 1.5 0 0 1 3.5 18Z"/><path d="M3.5 10h17" stroke-opacity=".55"/>'),
  file: wrap('<path d="M6 3.5h8l4 4v13H6Z"/><path d="M14 3.5v4h4" stroke-opacity=".55"/>'),
  assets: wrap('<rect x="3.5" y="3.5" width="17" height="17" rx="2.5"/><path d="m3.5 16 5-5 4 4 2.5-2.5 5.5 5.5" stroke-opacity=".55"/><circle cx="15.5" cy="8.5" r="1.6"/>'),
  grid: wrap('<rect x="4" y="4" width="6.5" height="6.5" rx="1.2"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.2"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.2"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.2"/>'),
  list: wrap('<path d="M8.5 6.5h11M8.5 12h11M8.5 17.5h11"/><path d="M4.5 6.5h.01M4.5 12h.01M4.5 17.5h.01" stroke-width="2.4"/>'),
  search: wrap('<circle cx="10.5" cy="10.5" r="6"/><path d="m15 15 5 5"/>'),
  /** The preview's: a clip or a sound paused. */
  pause: wrap('<rect x="6.5" y="5" width="3.5" height="14" rx="1" fill="currentColor" fill-opacity=".2"/><rect x="14" y="5" width="3.5" height="14" rx="1" fill="currentColor" fill-opacity=".2"/>'),

  /** The Model tab (Docs/modeler.md): a box in wire, its corners the vertices a script places. */
  model: wrap('<path d="M12 2.8 20.5 7.4v9.2L12 21.2 3.5 16.6V7.4Z" stroke-opacity=".55"/><path d="M3.5 7.4 12 12l8.5-4.6M12 12v9.2" stroke-opacity=".55"/><circle cx="12" cy="2.8" r="1.4" fill="currentColor"/><circle cx="3.5" cy="7.4" r="1.4" fill="currentColor"/><circle cx="20.5" cy="7.4" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/>'),
  /** Its layouts: one view, two side by side, four. */
  layout1: wrap('<rect x="3.5" y="4.5" width="17" height="15" rx="2"/>'),
  layout2: wrap('<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M12 4.5v15"/>'),
  layout4: wrap('<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M12 4.5v15M3.5 12h17"/>'),
  /** Its shading: a sphere lit; lit with its wires, the left half wire and the right solid (Vibe3D D10); wires alone. */
  shaded: wrap('<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16" fill="currentColor" fill-opacity=".45" stroke="none"/><circle cx="12" cy="12" r="8" fill="currentColor" fill-opacity=".25" stroke="none"/>'),
  shadedWire: wrap('<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 1 0 16Z" fill="currentColor" fill-opacity=".45" stroke="none"/><path d="M12 4v16M4.6 9h7.4M4.6 15h7.4M8 4.9C6.8 7 6.4 9.5 6.4 12s.4 5 1.6 7.1" stroke-opacity=".7" stroke-width="1.2"/>'),
  wireframe: wrap('<circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4v16M5.2 8h13.6M5.2 16h13.6M12 4c-2.6 2.2-3.8 5-3.8 8s1.2 5.8 3.8 8M12 4c2.6 2.2 3.8 5 3.8 8s-1.2 5.8-3.8 8" stroke-opacity=".7" stroke-width="1.2"/>'),
  /** The ground in metres: a plane in perspective, its lines. */
  ground: wrap('<path d="M2.5 17.5 7 7.5h10l4.5 10Z"/><path d="M12 7.5v10M9.3 7.5 7.5 17.5M14.7 7.5l1.8 10M4.6 12.8h14.8" stroke-opacity=".55"/>'),
  /** The stats overlay: a column of figures. */
  stats: wrap('<path d="M4.5 6h6M4.5 10h6M4.5 14h6M4.5 18h6" stroke-opacity=".55"/><path d="M14 6h5.5M15.5 10h4M13 14h6.5M16 18h3.5"/>'),
  /** Build the script now. */
  build: wrap('<path d="M14.5 4.5a4.5 4.5 0 0 0-5.7 5.7L3.6 15.4a1.6 1.6 0 0 0 2.3 2.3l5.2-5.2a4.5 4.5 0 0 0 5.7-5.7l-2.6 2.6-2.3-.4-.4-2.3Z"/>'),
  /** The outliner's rows, in Blender's shapes (Vibe3D D91): a mesh, one bones move, a bone, an empty. */
  mesh: wrap('<path d="M12 3 20 7.5v9L12 21l-8-4.5v-9Z"/><path d="M4 7.5 12 12l8-4.5M12 12v9" stroke-opacity=".55"/>'),
  skinned: wrap('<path d="M12 3 20 7.5v9L12 21l-8-4.5v-9Z"/><path d="M4 7.5 12 12l8-4.5M12 12v9" stroke-opacity=".55"/><circle cx="12" cy="12" r="2.4" fill="currentColor"/>'),
  bone: wrap('<path d="M12 2.5 15.8 7.8 12 21.5 8.2 7.8Z"/><path d="M8.2 7.8h7.6" stroke-opacity=".55"/>'),
  /** The Model tab's transport (Docs/modeler.md M31): to the clip's start, a frame back, a frame on, to its end. */
  toStart: wrap('<path d="M6 5v14"/><path d="M18 5 9 12l9 7Z" fill="currentColor" fill-opacity=".2"/>'),
  stepBack: wrap('<path d="M16.5 5 7.5 12l9 7Z" fill="currentColor" fill-opacity=".2"/>'),
  stepOn: wrap('<path d="M7.5 5 16.5 12l-9 7Z" fill="currentColor" fill-opacity=".2"/>'),
  toEnd: wrap('<path d="M18 5v14"/><path d="M6 5 15 12l-9 7Z" fill="currentColor" fill-opacity=".2"/>'),
  /** The build trace (Docs/modeler.md M34): the script's steps climbing to the model, the last one whole. */
  trace: wrap('<path d="M3.5 20.5h4v-4h4v-4h4v-4h5" stroke-opacity=".55"/><rect x="15.5" y="3.5" width="5" height="5" rx="1" fill="currentColor" fill-opacity=".25"/>'),
  /** A key of a clip: a pose written into the script's action{} (M33). */
  keyframe: wrap('<path d="M12 3.5 20.5 12 12 20.5 3.5 12Z" fill="currentColor" fill-opacity=".25"/>'),
  empty: wrap('<path d="M12 3.5v17M3.5 12h17M6 6l12 12" stroke-opacity=".8"/>'),
  /** The Model tab's canvases and their painter (Vibe3D D27, D63: the tab is a brush -- it changes what the left button does). */
  brush: wrap('<g transform="scale(1.5)" stroke-width="1.15"><path d="M11.5 2.5 6 8l2 2 5.5-5.5a1.4 1.4 0 0 0-2-2Z"/><path d="M6 8c-1.6.4-2.4 1.4-2.6 3.4-.9.2-1.2.6-1.4 1.1 1.9.9 4.4.6 5.2-1.1.4-.9.1-1.9-1.2-3.4Z"/></g>'),
  eraser: wrap('<g transform="scale(1.5)" stroke-width="1.15"><path d="M6.5 13H13"/><path d="m9.2 3.3 3.5 3.5a1 1 0 0 1 0 1.4l-4.3 4.3a1 1 0 0 1-1.4 0L3.5 9a1 1 0 0 1 0-1.4l4.3-4.3a1 1 0 0 1 1.4 0Z"/></g>'),
  marqueeRect: wrap('<rect x="3.75" y="5.25" width="16.5" height="13.5" stroke-dasharray="3.9 3"/>'),
  marqueeEllipse: wrap('<ellipse cx="12" cy="12" rx="8.25" ry="6.75" stroke-dasharray="3.9 3"/>'),
  lasso: wrap('<g transform="scale(1.5)" stroke-width="1.15"><path d="M8 3.2c3 0 5 1.7 5 3.6S11 10.4 8 10.4 3 8.7 3 6.8 5 3.2 8 3.2Z" stroke-dasharray="2.6 2"/><path d="M5.6 10.1c-.4 1.3-.2 2.3.6 2.7"/></g>'),
  cut: wrap('<g transform="scale(1.5)" stroke-width="1.15"><circle cx="4.4" cy="12" r="1.7"/><circle cx="11.6" cy="12" r="1.7"/><path d="M5.6 10.8 12 2.5M10.4 10.8 4 2.5"/></g>'),
  trash: wrap('<g transform="scale(1.5)" stroke-width="1.15"><path d="M3.5 4.5h9M6.5 4.5V3h3v1.5M5 4.5l.6 8h4.8l.6-8"/></g>'),
} as const;

export type IconName = keyof typeof ICON;
