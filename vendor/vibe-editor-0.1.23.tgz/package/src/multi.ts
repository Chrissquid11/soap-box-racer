/**
 * Values across the selection: what the inspector shows and writes when several
 * entities are selected at once (Docs/ecs.md §13). Pure, so node tests it.
 *
 * - **A field of several shows one value or none**: the value when every one
 *   has it (`agreed`), else the mixed marker, with the values on hover
 *   (`spread`).
 * - **Typed, a value is everyone's; moved, each moves from its own**: a scrub or
 *   a step offsets each by the same amount (`offsetEach`), so a mixed field
 *   stays mixed and they all move.
 * - **Names typed for several are numbered** (`numbered`): `wall`, `wall 2`,
 *   `wall 3` -- or on from a number the name ends in.
 * - **A step of several says so**: `Set Spin.speed × 3` (`times`).
 * - **A switch of several goes one way** (`flipAll`): on for every one unless
 *   all are on already -- Hide 3 hides the two that were not -- and then off.
 * - **Labels of several are counted** (`labelCounts`): each once, with how many
 *   have it, so a chip some have says "2 of 3"; typed, they end at a comma or
 *   at Enter (`typedLabels`).
 */

/** What a field of several shows when they differ. */
export const MIXED = '—';

/** The hover of a field whose values differ: what each has. */
export const eachOwn = (values: readonly string[]): string => `Each its own: ${spread(values)}`;

/** The value every one of `values` has, or null when they differ (or there are none). `same` says what equal is: `===` by default. */
export function agreed<T>(values: readonly T[], same: (a: T, b: T) => boolean = (a, b) => a === b): T | null {
  if (values.length === 0) return null;
  const first = values[0]!;
  for (let i = 1; i < values.length; i++) if (!same(values[i]!, first)) return null;
  return first;
}

/**
 * The values of a mixed field as its hover says them: each once, in the order
 * first met, with how many have it when more than one does -- `0.5 ×2, 1.25`.
 * At most `max` of them, then how many more.
 */
export function spread(values: readonly string[], max = 8): string {
  const counts = new Map<string, number>();
  for (const v of values) counts.set(v, (counts.get(v) ?? 0) + 1);
  const listed = [...counts].slice(0, max).map(([v, n]) => (n > 1 ? `${v} ×${n}` : v));
  const more = counts.size - max;
  return more > 0 ? `${listed.join(', ')} and ${more} more` : listed.join(', ');
}

/** Each of `starts` moved by `by`, then held by `clamp` -- an integer's rounding, a type's range -- each its own. */
export function offsetEach(starts: readonly number[], by: number, clamp: (value: number) => number = (v) => v): number[] {
  return starts.map((v) => clamp(v + by));
}

/**
 * `count` names from one typed: the first as typed, the rest numbered from 2
 * -- `wall`, `wall 2`, `wall 3`. A name that ends in a number counts on from
 * it, its width kept: `crate 08`, `crate 09`, `crate 10`.
 */
export function numbered(name: string, count: number): string[] {
  const out: string[] = [];
  const ends = /^(.*?)(\d+)$/.exec(name);
  for (let i = 0; i < count; i++) {
    if (i === 0) out.push(name);
    else if (ends) out.push(`${ends[1]}${String(Number(ends[2]) + i).padStart(ends[2]!.length, '0')}`);
    else out.push(`${name} ${i + 1}`);
  }
  return out;
}

/** A step's label for `n` at once: `Set Spin.speed × 3`; for one, the label alone. */
export const times = (label: string, n: number): string => (n > 1 ? `${label} × ${n}` : label);

/** How many have it, of how many: `on 2 of 3`. */
export const onOf = (n: number, of: number): string => `on ${n} of ${of}`;

/** `n` of a thing, said: `1 entity`, `3 entities`. */
export const entities = (n: number): string => `${n} ${n === 1 ? 'entity' : 'entities'}`;

/** Names counted, the most first, then in the order first met: `2 LittleCrate, 1 Rider`. */
export function tally(names: readonly string[]): string {
  const counts = new Map<string, number>();
  for (const name of names) counts.set(name, (counts.get(name) ?? 0) + 1);
  return [...counts].sort((a, b) => b[1] - a[1]).map(([name, n]) => `${n} ${name}`).join(', ');
}

/** What a switch of several does: on for every one unless all are on already; then off for all. */
export const flipAll = (states: readonly boolean[]): boolean => !states.every(Boolean);

/** The labels of several, each once in the order first met, with how many of them have it. */
export function labelCounts(lists: readonly (readonly string[])[]): { label: string; count: number }[] {
  const counts = new Map<string, number>();
  for (const list of lists) for (const label of new Set(list)) counts.set(label, (counts.get(label) ?? 0) + 1);
  return [...counts].map(([label, count]) => ({ label, count }));
}

/**
 * Labels as typed into the field: those ended by a comma -- all of it at
 * Enter (`whole`) -- trimmed, empty ones dropped, each once; and what is left
 * to go on typing.
 */
export function typedLabels(text: string, whole: boolean): { labels: string[]; rest: string } {
  const parts = text.split(',');
  const rest = whole ? '' : parts.pop()!;
  const labels = [...new Set(parts.map((part) => part.trim()).filter(Boolean))];
  return { labels, rest: rest.trimStart() };
}
