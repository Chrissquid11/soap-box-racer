/**
 * The editor's entity tool, the Scene tab (`entitiesTool`, key `1`, Docs/ecs.md
 * §13): the tree on the left (`tree.ts`), the selected entity's components on
 * the right (`inspector.ts`), its links drawn in the scene (`link-lines.ts`),
 * and the scene's own keys -- the gizmo's G R S X V, F, the arrows (flying over the view), Delete, the
 * Mod chords, and Shift+H and Shift+E that hide or switch off the selection
 * (`switches.ts`). This file is the wiring; what an edit does is `edits.ts`.
 *
 * - **The world's side of the tab**: the Assets panel is shown along its
 *   bottom (`within`), and the keys are this tool's while the tree, the scene
 *   or its inspector was pressed in last (`ctx.focused`). The right panel is
 *   its inspector while an entity was chosen last (`ctx.inspect` on a
 *   selection), the Assets inspector while a file was -- and an entity
 *   chosen clears the files chosen, a file the entities (`ctx.chose`,
 *   `letGo`). Locked (`Alt+L`, the inspector's lock), it keeps the entities
 *   it showed, by ref, whatever is chosen after (`inspector-lock.ts`).
 *
 * - **An entity is picked the way one is selected**: after "Link to…" -- a
 *   link's target -- or a ref's "Pick…", the next click in the scene or the
 *   tree is that entity instead (the scene's click is the tool's first,
 *   `onPick`), for every entity selected as it began: one step, `Link Likes
 *   × 3`. Esc, or a click on nothing, stops. One thing at a time: a pick or a
 *   menu -- and no box in the scene meanwhile (`setBoxAway`).
 * - **Create** (the tree's right-click menu, on a row or on the empty list
 *   below the rows): Empty, Camera (`edits.createCamera`: in front of the
 *   editor's view, looking along it, main if the scene has none), then the prefabs by folder, a submenu each
 *   (`prefab-groups.ts`) -- made where the camera looks, as the row's child or
 *   a root (`edits.create`), one step `Spawn crates/big`. The arrows walk the
 *   menu, → opens a submenu and ← closes it.
 * - **Save as prefab…** (the menu, `Shift+S`): the selection written as a new
 *   prefab and replaced by an instance of it, one step (`save-prefab.ts`); the
 *   key is asked for under the tree's title. **Open prefab** on an instance
 *   opens its prefab to edit -- and each prefab it nests, inward -- through
 *   the host (`ctx.openPrefab`, `opened.ts`).
 * - **An instance's overrides** (Docs/prefabs.md §7): marked in the tree and
 *   the inspector, each with its menu -- Revert, Apply to each prefab that
 *   could hold it -- the Overrides list on its root, and Unpack (the menu
 *   too); each through `ctx.overrides`, a step Z undoes. Not the opened
 *   prefab's own instance: its entities are the file's, and its Save writes
 *   them. Apply is the scene's: in an opened prefab, Save writes the file.
 * - **Esc is never a key of its own**: what the tool has under way is its
 *   `holdsEscape` and `cancel`, the menu first, then a drop-down -- the tree's
 *   columns, a list of tags -- then a pick.
 * - **What is not drawn is not clicked**: a hidden or switched-off entity is
 *   no target in the scene -- a click goes through to what is behind it -- and
 *   is selected in the tree; selected, it keeps its outline and the gizmo, and
 *   its row, dimmed or struck through, says why on hover.
 */
import { keyLabel, MrDebug } from '@vibe/engine/debug';
import { Camera, compiledPrefab, compiledPrefabs, type Component, type Entity, type EntityRef, fileFieldOf, Hierarchy, label, NONE, prefabFiles, type Relation, Transform, untypedPrefab as prefab } from '@vibe/engine';
import { factsOf, fits } from './drag-record.ts';
import { dropNotice } from './drop-target.ts';
import { createEdits, PASTE } from './edits.ts';
import { GIZMO_MODES } from './gizmo.ts';
import { createInspector } from './inspector.ts';
import { lockHost, shownOf, type Shown } from './inspector-lock.ts';
import { keyPickKeys } from './key-field.ts';
import { addComponentKeys } from './add-component.ts';
import type { OverridesHost } from './inspector-overrides.ts';
import { itemsOf } from './overrides-edit.ts';
import { createLinkLines } from './link-lines.ts';
import { createMenu, type MenuItem } from './menu.ts';
import { flipAll, times } from './multi.ts';
import { iconButton, withKey } from './shell.ts';
import { EMPTY } from './spawn.ts';
import { leafOf, prefabGroups, type PrefabGroup } from './prefab-groups.ts';
import { emulatedKeys, viewKeys } from './view/nav-keys.ts';
import { pointerOverView } from './view/over-view.ts';
import { alignCamerasWithView } from './inspector-camera.ts';
import { loadPrefs } from './prefs.ts';
import { SWITCHES, switchStep, type Switch } from './switches.ts';
import type { EditorContext, EditorTab, ToolFact, ToolInstance, ToolKey } from './tool.ts';
import { tabId } from './tab-pages.ts';
import { createTree } from './tree.ts';
import { nestedKeys, prefabsOf } from './opened.ts';
import { PREFABS_DIR, prefabPathOf } from './assets/ui/prefab-steps.ts';
import { keyProblem, rootsOfChoice, saveAsPrefab, suggestKey } from './save-prefab.ts';
import type { Mcp } from './mcp/declare.ts';
import { NOT_FOR_CLAUDE } from './mcp/gaps.ts';
import { entitiesTarget } from './agent/context.ts';
import { editorKey, keyed, tabKey } from './editor-keys.ts';

/**
 * The Scene tab: its id stays `entities` -- what a reload's record, a game's
 * tool list and `ctx.tool` call it -- and the Assets panel is shown within it.
 */
export const entitiesTool: EditorTab = {
  id: tabId('entities'),
  name: 'Scene',
  icon: 'tree',
  key: tabKey('entities'),
  lock: true,
  help: 'The editor\'s Scene tab: the entity tree, the scene, the inspector -- and the Assets panel along the bottom -- the keys to the entities\' side',
  create: (ctx) => createEntities(ctx),
};

/** What an entity is being picked for: the target of a new link of a relation, or whom a `ref()` field points at. */
type Pick = { what: 'link'; relation: Relation<any> } | { what: 'ref'; component: Component; field: string };

/** What the inspector calls a pick: a relation's name, or a ref's `Component.field`. */
const pickKey = (p: Pick): string => (p.what === 'link' ? p.relation.name : `${p.component.name}.${p.field}`);

/** Paste, the button and the key: entities copied (from this scene, another, or as JSON on the clipboard) made here -- `scene_paste`, given `scene_copy`'s handle. */
const PASTE_MCP: Mcp = 'scene_paste';
/** A pick's own refusal of the entity it began from, alone: not said on a click, said on a drop. */
const ITSELF = 'itself';
/** Delete's line and Backspace's: the same, so the keys card shows them as one. */
const DESTROY = 'Destroy the selection and everything under it';

function createEntities(ctx: EditorContext): ToolInstance {
  const { game, world, root, selection, viewport, worldSteps } = ctx;
  const canvas = game.renderer.domElement;
  const current = (): Entity => selection.primary;
  // The selection's links, in the scene: built again whenever an edit is drawn, and not otherwise.
  const lines = createLinkLines(world, viewport, current);
  const redraw = (): void => {
    lines.stale();
    ctx.draw();
  };
  let visible = true;
  /** The right panel is this tool's inspector: an entity was chosen last, not a file of the Assets panel (`ctx.inspect`). */
  let inspecting = true;
  /** The right panel locked (`ctx.lock`): the entities the inspector showed as it was, kept as refs. Null unlocked. */
  let pinned: EntityRef[] | null = null;
  /** What the inspector shows: the selection, or -- locked -- those pinned still alive (`shownOf`). */
  const shown = (): Shown<Entity> => shownOf(selection.list, ctx.locked ? pinned : null, (r) => {
    const e = world.deref(r);
    return e !== NONE && world.alive(e) ? e : null;
  });
  /** An entity being picked -- a link's target, a ref's -- for those selected when it began, the first first. */
  let picking: (Pick & { from: EntityRef[] }) | null = null;
  /**
   * A crosshair over the world while an entity is picked there -- the canvas
   * UI sets its own cursor only over its widgets, hidden now -- and the
   * scene's clicks the tool's meanwhile: no box.
   */
  const aim = (): void => {
    const taken = picking !== null;
    canvas.style.cursor = taken ? 'crosshair' : '';
    viewport.setBoxAway(taken);
  };

  const menu = createMenu(root, canvas);
  const copyButton = iconButton(
    'scene_copy',
    'copy',
    withKey('Copy the selection, each with everything under it: onto the clipboard, as JSON, and for Paste here', keyLabel(tabKey('copy'))),
    () => edits.copy(),
  );
  const pasteButton = iconButton(
    PASTE_MCP,
    'paste',
    withKey(
      'Paste what was copied, round where the last one was placed or the middle of the view -- from another scene, or before a reload, through the clipboard',
      keyLabel(PASTE),
    ),
    () => void edits.paste(),
  );
  /**
   * The Create item of the tree's menus: a submenu of Empty and every prefab
   * there is, by folder -- each made where the camera looks, as `on`'s child,
   * or a root for NONE (`edits.create`, the opened prefab's rule in it).
   */
  function createItem(on: Entity): MenuItem {
    // The prefabs compiled now: one whose file went (a live recompile) keeps its row for instances still out, not its key.
    // In an opened prefab, not it nor one that nests it: saved, it would be inside itself.
    const open = ctx.prefab;
    const files = open ? prefabFiles() : {};
    const keys = compiledPrefabs().flatMap((p) => (p && compiledPrefab(p.key) === p && !(open && nestedKeys(p.key, files).includes(open)) ? [p.key] : []));
    const where = on === NONE ? (open ? `under ${open}'s root` : 'a root') : `under ${label(world, on)}`;
    const one = (key: string): MenuItem => {
      const pooled = compiledPrefab(key)?.pool != null;
      return {
        mcp: 'scene_create',
        // A pooled one says so: nested in the prefab open it is a plain part of it, not pooled (Docs/prefabs.md §5).
        label: pooled ? `${leafOf(key)} · pooled` : leafOf(key),
        title: (compiledPrefab(key)?.kinds[0]?.components.includes(Transform)
          ? `A ${key}, whole, where the camera looks, ${where}`
          : `A ${key}, ${where}: its root has no Transform, so it is nowhere in particular`)
          + (pooled && open ? ` -- pooled, but nested in ${open} it is a plain part of each ${open}, made and destroyed with it, not taken from its pool` : pooled ? ' -- pooled: the game takes its instances from a pool' : ''),
        run: () => edits.create(prefab(key), on),
      };
    };
    // A folder a submenu, `path` the folders above it; then the prefabs directly in it.
    const folder = (group: PrefabGroup, path: string): MenuItem[] => [
      ...group.folders.map((f): MenuItem => ({ mcp: 'ui', label: f.name, title: `prefabs/${path}${f.name}`, items: folder(f, `${path}${f.name}/`) })),
      ...group.keys.map(one),
    ];
    const items: MenuItem[] = [
      { mcp: 'scene_create', label: EMPTY, title: `An Empty where the camera looks, ${where}: an entity with only a Transform and a name, for code to fill in`, run: () => edits.create(EMPTY, on) },
      {
        mcp: 'scene_create',
        label: 'Camera',
        title: `A camera in front of the editor's view, looking along it, ${where}: a Transform and a Camera -- the main one if the scene has none`,
        run: () => edits.createCamera(on),
      },
      ...folder(prefabGroups(keys), '').map((item, i) => (i === 0 ? { ...item, rule: true } : item)),
    ];
    return { mcp: 'ui', label: 'Create', title: `Make an Empty, a camera or an instance of a prefab, ${where}`, items };
  }

  /** The empty list below the tree's rows right-clicked: the Create menu, a root -- or, in an opened prefab, under its root. */
  function openBlankMenu(x: number, y: number): void {
    stopPick(false);
    menu.show({ x, y }, [createItem(NONE)], { title: ctx.prefab ?? 'Scene' });
  }

  /** The opened prefab's own instance (Docs/prefabs.md §7): its entities are the file's -- no overrides of it shown. */
  const ownInstance = (root: Entity): boolean => ctx.prefab !== null && world.prefabOf(root)?.key === ctx.prefab && world.store(Hierarchy).parent[root] === NONE;
  /** After a Revert, an Unpack or an Apply: everything read again, the other tools told. */
  const settled = (said: string, bad = false): void => {
    refresh();
    ctx.emit('changed');
    tree.say(said, bad);
  };
  const overrides: OverridesHost = {
    of: (e) => {
      const root = world.instanceRoot(e);
      return root === NONE || ownInstance(root) ? null : itemsOf(world, root);
    },
    revert: (root, items) => {
      try {
        settled(`${ctx.overrides.revert(root, items)} · Z undoes`);
      } catch (err) {
        settled(`Not reverted: ${err instanceof Error ? err.message : String(err)}`, true);
      }
    },
    apply: (root, items, target) => {
      tree.say(`Applying to ${target}…`);
      ctx.overrides.apply(root, items, target).then((said) => settled(said), (err: Error) => settled(`Not applied: ${err.message}`, true));
    },
    unpack: (root, completely) => {
      try {
        settled(ctx.overrides.unpack(root, completely));
      } catch (err) {
        settled(`Not unpacked: ${err instanceof Error ? err.message : String(err)}`, true);
      }
    },
    select: (e) => selection.choose(e),
    menu: (at, items, title) => menu.show(at, items, { title }),
    applyBlocked: () => (ctx.prefab !== null ? `Apply is the scene's: in the opened prefab ${ctx.prefab}, its Save writes the file` : null),
    showPrefab: (key) => {
      if (!ctx.revealAsset(prefabPathOf(key))) tree.say(`${key}: no tool here lists files`, true);
    },
  };

  const tree = createTree({
    root,
    world,
    selection,
    viewport,
    host: {
      pick: picked,
      picking: () => picking !== null,
      pickMisfit,
      menu: openMenu,
      blankMenu: openBlankMenu,
      toggle: (which, e) => edits.toggle(which, selection.list.includes(e) ? selection.list : [e]),
      changed,
      reparent: (children, parent) => edits.reparent(children, parent),
      reorder: (children, parent, before) => edits.reorder(children, parent, before),
      placePrefab: (event, parent, before) => edits.placeDropped(event, parent, before),
      wearMaterial: (event, e) => edits.wearDropped(event, e),
      instanceShown: (root) => !ownInstance(root),
      touched: (e) => ctx.touched(e),
    },
    tools: [copyButton, pasteButton],
    // The scene's header -- Scene or Prefab, Save and Back -- at the top of the tree's card.
    head: ctx.head,
  });
  const inspector = createInspector(root, game, {
    blocks: ctx.blocks,
    primary: () => shown().subject[0] ?? NONE,
    selected: () => shown().subject,
    removed: () => shown().removed,
    lock: lockHost(ctx),
    select: (e) => selection.choose(e),
    changed,
    redraw,
    commit,
    reparent: (child, parent) => edits.reparent([child], parent),
    duplicate: () => edits.duplicate(),
    destroy: () => edits.destroy(),
    toggle: (which, es) => edits.toggle(which, es),
    // From what the inspector shows: locked, its pinned entities, not the selection.
    link: (relation) => startPick({ what: 'link', relation }, shown().subject),
    pickRef: (component, field) => startPick({ what: 'ref', component, field }, shown().subject),
    dropRef: (component, field, e) => dropped({ what: 'ref', component, field }, [e]),
    dropLink: (relation, targets) => dropped({ what: 'link', relation }, targets),
    opened: () => ctx.prefab !== null,
    thumb: (key, type) => ctx.modelThumb(key, type),
    // An asset file dropped on a key field: the world's step, so the keys -- and Z -- the entities' side's.
    focus: () => ctx.focus(),
    overrides,
    // The Camera block's Align buttons: the editor's view, and looking through a camera.
    camera: { view: () => viewport.view(), lookThrough: (e) => viewport.lookThrough(e) },
    get picking() {
      return picking ? pickKey(picking) : null;
    },
  });
  const edits = createEdits(ctx, tree, { changed, commit, stopPick: () => stopPick(false), visible: () => visible });
  // A drop on a field that does not take it: why, on the Scene tab's line (`drop-target.ts`).
  dropNotice((why) => tree.say(why, true));

  /** An edit is done: one world step called `label`, and the other tools told. */
  function commit(label: string): void {
    if (worldSteps.commit(label)) ctx.emit('changed');
  }

  /** After an edit to what exists: the world settled, everything read again, one step of history. */
  function changed(label: string): void {
    redraw();
    tree.refresh();
    inspector.refresh();
    commit(label);
  }

  // ---------------------------------------------------------------- picking an entity

  /**
   * A click on `e`, in the scene or the tree, while an entity is being picked:
   * the pick's, for every entity it began from -- each linked to `e`, or its
   * ref pointed at it -- as one step. True if a pick took the click.
   */
  function picked(e: Entity): boolean {
    if (!picking) return false;
    const from = picking.from.map((r) => world.deref(r)).filter((x) => x !== NONE && world.alive(x));
    // Nothing clicked, or what it began from gone: the pick is off.
    if (e === NONE || from.length === 0) {
      stopPick();
      return true;
    }
    const pick = picking;
    const why = pointWhy(pick, from, e);
    // Itself, alone: not what is picked, and the pick goes on quietly. One a typed ref cannot hold: said, and it goes on.
    if (why !== null) {
      if (why !== ITSELF) tree.say(`Not picked: ${why}`, true);
      return true;
    }
    stopPick(false);
    pointAt(pick, from, [e]);
    return true;
  }

  /** Why `from` cannot point at, or link to, `e` by `pick`: itself alone (`ITSELF`), or one a typed ref cannot hold; null if it can. */
  function pointWhy(pick: Pick, from: readonly Entity[], e: Entity): string | null {
    if (!from.some((x) => x !== e)) return ITSELF;
    if (pick.what !== 'ref') return null;
    const fit = fits({ kind: 'ref', needs: fileFieldOf(pick.component, pick.field)?.field.needs ?? [] }, { what: 'entities', entities: [e] }, factsOf(world));
    return fit.ok ? null : fit.why;
  }

  /**
   * The pick's write, a click's or a drop's: each of `from` (but `e` itself) linked to each of `targets`, or its ref
   * pointed at the one target -- one step. Checked first (`pointWhy`).
   */
  function pointAt(pick: Pick, from: readonly Entity[], targets: readonly Entity[]): void {
    if (pick.what === 'link') {
      let made = 0;
      for (const e of targets) for (const source of from) if (source !== e && world.relate(source, pick.relation, e) !== 0) made++;
      changed(times(`Link ${pick.relation.name}`, made));
      return;
    }
    const e = targets[0]!;
    const column = (world.rawStore(pick.component) as Record<string, { [i: number]: number }>)[pick.field]!;
    const holders = from.filter((x) => x !== e && world.has(x, pick.component));
    for (const holder of holders) column[holder] = world.ref(e);
    changed(times(`Set ${pickKey(pick)}`, holders.length));
  }

  /** A drop of `targets` as a pick of them by every entity the inspector shows: null if done, else why not. */
  function dropped(pick: Pick, targets: readonly Entity[]): string | null {
    const from = shown().subject.filter((x) => world.alive(x));
    const fitting = targets.filter((e) => pointWhy(pick, from, e) === null);
    if (fitting.length === 0) {
      const why = targets.length > 0 ? pointWhy(pick, from, targets[0]!) : 'nothing dropped';
      return why === ITSELF ? `${label(world, targets[0]!)} is the entity it would be set on` : why;
    }
    pointAt(pick, from, fitting);
    return null;
  }

  /**
   * While a typed ref is picked: why `e` would not do -- it lacks what the ref needs, or it is the one being set --
   * or null; undefined while no typed ref is picked (a link, a plain ref: no row lit or dimmed).
   */
  function pickMisfit(e: Entity): string | null | undefined {
    if (picking?.what !== 'ref' || (fileFieldOf(picking.component, picking.field)?.field.needs ?? []).length === 0) return undefined;
    const from = picking.from.map((r) => world.deref(r));
    if (from.includes(e)) return 'it is the one being set';
    return pointWhy(picking, from, e);
  }

  /** Begin picking for the selection -- or `all`, the locked inspector's -- a link's target, or whom a ref points at. The same pick again stops it. */
  function startPick(pick: Pick, all: readonly Entity[] = selection.list): void {
    if ((picking && pickKey(picking) === pickKey(pick)) || all.length === 0) return stopPick();
    menu.close();
    picking = { ...pick, from: all.map((e) => world.ref(e)) };
    aim();
    redraw();
    tree.refresh();
    inspector.refresh();
  }

  /** The pick over; `show`, and the frame and the inspector say so. */
  function stopPick(show = true): void {
    if (!picking) return;
    picking = null;
    aim();
    tree.refresh();
    if (!show) return;
    redraw();
    inspector.refresh();
  }

  // ---------------------------------------------------------------- the menu

  /**
   * The right-click menu for `e`, at a point on the page: `e` selected first,
   * unless it is among the selection already. Create first: what it makes is
   * `e`'s child.
   */
  function openMenu(e: Entity, x: number, y: number): void {
    if (!world.alive(e)) return;
    stopPick(false);
    if (!selection.list.includes(e)) selection.choose(e);
    // What acts on one entity acts on this one: shown first.
    const alone = (): void => {
      if (current() !== e) selection.choose(e);
    };
    const all = selection.list.length;
    const parent = world.store(Hierarchy).parent[e]! as Entity;
    const items: MenuItem[] = [
      createItem(e),
      { mcp: 'view_focus', label: 'Focus', key: 'F', title: 'The camera onto the selection', rule: true, run: () => viewport.focus() },
      // Ask Claude about it (Docs/ai-panel.md §5, A3, D7): the quick prompt at the menu's point, its target the selection
      // (or the entity right-clicked) -- never sent. Only where a dev server hosts Claude.
      ...(ctx.canAsk
        ? [{
          mcp: NOT_FOR_CLAUDE.askClaude,
          label: 'Ask Claude about this…',
          title: all > 1 ? `Ask Claude about all ${all} selected: a box here, they go with the prompt as its target` : 'Ask Claude about it: a box here, it goes with the prompt as its target',
          run: () => void ctx.ask({ target: entitiesTarget(world, selection.list.includes(e) ? selection.list : [e]), at: { x, y } }),
        } satisfies MenuItem]
        : []),
      {
        mcp: 'scene_duplicate',
        rule: ctx.canAsk,
        label: 'Duplicate', key: keyLabel(editorKey('duplicate').at(-1)!), title: 'A copy of it, where it is',
        run: () => {
          alone();
          edits.duplicate();
        },
      },
    ];
    if (parent !== NONE) items.push({ mcp: 'scene_reparent', label: 'Unparent', title: `Take it out from under ${label(world, parent)}`, run: () => edits.reparent([e], NONE) });
    // The switches, for all selected: one way for all, as their keys.
    const chosen = selection.list;
    const flip = (which: Switch, rule = false): MenuItem => {
      const { tag, key, means } = SWITCHES[which];
      const on = flipAll(chosen.map((x) => world.has(x, tag)));
      return {
        mcp: 'scene_flags',
        label: switchStep(which, on, all), key: keyLabel(key), rule,
        title: on
          ? `${all > 1 ? `All ${all}` : 'It'} ${which === 'hidden' ? 'hidden' : which === 'disabled' ? 'switched off' : 'locked'}: ${means}`
          : `${all > 1 ? `All ${all}` : 'It'} back ${which === 'hidden' ? 'in sight' : which === 'disabled' ? 'in play' : 'within the scene\'s reach'}`,
        run: () => edits.toggle(which, chosen),
      };
    };
    // A prefab: the selection saved as one; an instance's prefab opened, and each it nests inward.
    items.push({
      mcp: 'scene_save_prefab',
      label: 'Save as prefab…', key: keyLabel(tabKey('save as prefab')), rule: true,
      title: all > 1 ? `All ${all} as one new prefab, under an empty root: they become its instance` : 'It and everything under it as a new prefab: it becomes its instance',
      run: () => askSaveAs(),
    });
    for (const key of prefabsOf(world, prefabFiles(), e)) {
      if (key === ctx.prefab) continue;
      items.push({ mcp: 'scene_open_prefab', label: `Open prefab ${key}`, title: `Edit ${key} alone: the scene put aside until Back`, run: () => ctx.openPrefab(key) });
    }
    // An instance's root: its link to the prefab broken, one level or all through.
    const made = world.prefabOf(e);
    if (made && world.instanceRoot(e) === e && !ownInstance(e)) {
      items.push({ mcp: 'scene_override', label: 'Unpack', title: `Plain entities, no longer linked to ${made.key}; what it nests stays an instance of its own prefab`, run: () => overrides.unpack(e, false) });
      if (made.owners.some((o) => o.length > 1)) items.push({ mcp: 'scene_override', label: 'Unpack completely', title: 'Plain entities all through: every prefab it nests unlinked too', run: () => overrides.unpack(e, true) });
    }
    items.push(flip('hidden', true), flip('disabled'), flip('unpickable'), {
      mcp: 'scene_flags',
      label: 'Add label…', title: all > 1 ? `A label for all ${all}, typed in the inspector` : 'A label for it, typed in the inspector',
      run: () => inspector.addLabel(),
    });
    items.push(
      // Several are renamed together, numbered; the inspector's title is the field either way.
      {
        mcp: 'scene_rename',
        rule: true,
        label: all > 1 ? `Rename ${all}` : 'Rename', title: all > 1 ? `A name for all ${all}, numbered, in the inspector` : 'Its name, in the inspector',
        run: () => inspector.rename(),
      },
      {
        mcp: 'scene_destroy',
        label: all > 1 ? `Destroy ${all}` : 'Destroy', key: 'Del', danger: true,
        title: all > 1 ? `Destroy all ${all} selected and everything under them` : 'Destroy it and everything under it',
        run: () => edits.destroy(),
      },
    );
    world.allComponents.forEach((relation) => {
      if (relation.kind !== 'relation') return;
      items.push({
        mcp: 'scene_relate',
        label: `Link to…  ${relation.name}`,
        rule: !items.some((item) => item.label.startsWith('Link')),
        title: all > 1 ? `A new ${relation.name} link from each of the ${all} selected: then click its target` : `A new ${relation.name} link from it: then click its target`,
        run: () => startPick({ what: 'link', relation }),
      });
    });
    menu.show({ x, y }, items, { title: label(world, e) });
  }

  /** Read the world again: on open, after an undo, and after anything else changed it. */
  function refresh(): void {
    // A pick from entities an undo took away is over.
    if (picking && !picking.from.some((r) => world.alive(world.deref(r)))) stopPick(false);
    // What the menu was for may be gone.
    menu.close();
    redraw();
    tree.refresh();
    if (visible && inspecting) inspector.refresh();
  }

  // ---------------------------------------------------------------- save as prefab

  /** Save as prefab…: the key asked for under the tree's title, then the selection saved as it. */
  function askSaveAs(): void {
    const chosen = selection.list;
    const roots = rootsOfChoice(ctx, chosen);
    if (roots.length === 0) return tree.say('Select what to save as a prefab first', true);
    menu.close();
    stopPick(false);
    // Where it came from, if it is an instance; else the folder of the prefabs there are.
    const from = world.prefabOf(roots[0]!)?.key;
    // Its folder as it is on disk (a key is the path lowercased): the new file goes beside it.
    const there = from === undefined ? '' : prefabPathOf(from).slice(PREFABS_DIR.length + 1);
    const folder = there.includes('/') ? there.slice(0, there.lastIndexOf('/')) : 'props';
    const several = roots.length > 1 ? ` -- ${roots.length} roots: one prefab, an empty root above them` : '';
    tree.ask.askName(`Save as prefab: a name in a folder under prefabs/ (its key is it lowercased)${several}`, suggestKey(ctx, folder, roots, prefabFiles()), (key) => {
      const problem = keyProblem(key, prefabFiles());
      if (problem) return tree.say(`Not saved: ${problem}`, true);
      saveAs(key, chosen);
    }, 'Save');
  }

  /** `chosen` saved as the prefab `key`, said on the tree's line either way. */
  function saveAs(key: string, chosen: readonly Entity[]): void {
    // Its question answered while an Apply lands: the file and the instance it makes would be loaded over.
    if (ctx.refuses('Save as prefab')) return;
    tree.say(`Saving ${key}…`);
    saveAsPrefab(ctx, key, chosen, () => {
      refresh();
      ctx.emit('changed');
    }).then(
      (said) => {
        refresh();
        ctx.emit('changed');
        tree.say(said);
      },
      (err: Error) => tree.say(`Not saved as a prefab: ${err.message}`, true),
    );
  }

  // ---------------------------------------------------------------- the editor's

  /** Not while a pick is under way, which a click ends, nor while a menu is open, whose items the arrows walk. */
  const treeKeys = (): boolean => !picking && !menu.open;
  /** The selected entities with a `Camera`: what Ctrl+Alt+Numpad0 moves. */
  const selectedCameras = (): Entity[] => selection.list.filter((e) => world.alive(e) && world.has(e, Camera));
  /** Numpad0: through the camera selected, else the scene's main one -- else nothing to look through. */
  function lookThroughCamera(): void {
    const e = selectedCameras()[0] ?? ctx.game.gameView.entity;
    if (e !== NONE && world.alive(e)) viewport.lookThrough(e);
  }
  const navKeys: ToolKey[] = viewKeys({ prefix: 'view', mcp: 'view_set', who: 'The editor\'s camera', when: () => true }, {
    look: (preset) => viewport.look(preset),
    flip: () => viewport.flip(),
    projection: () => viewport.setProjection(viewport.projection === 'perspective' ? 'orthographic' : 'perspective'),
    orbit: (dx, dy) => viewport.orbitBy(dx, dy),
    pan: (dx, dy) => viewport.panBy(dx, dy),
    zoom: (scale) => viewport.zoomBy(scale),
  });
  const keys: ToolKey[] = [
    // `view`: they only look, so they stay live while an Apply lands (`hold.ts`); the rest are refused then, said.
    ...GIZMO_MODES.map((m): ToolKey => ({ name: m.name.toLowerCase(), mcp: 'ui', key: m.key, view: true, help: m.help, run: () => viewport.setMode(m.mode) })),
    { ...keyed('world or local'), mcp: 'ui', view: true, help: 'The gizmo along the world\'s axes, or the selection\'s own', run: () => viewport.toggleSpace() },
    {
      ...keyed('snap'), mcp: 'ui', view: true, help: 'Snapping on or off: the gizmo to the steps beside its icon on the top bar (Ctrl or Cmd held turns it over)',
      run: () => viewport.setSnap({ on: !viewport.snap.on }),
    },
    { ...keyed('focus'), mcp: 'view_focus', view: true, help: 'The editor\'s camera onto the selection; with nothing selected, onto everything', run: () => viewport.focus() },
    // Blender's numpad, the Model tab's too (`view/nav-keys.ts`, Docs/navigation.md §3): its keys are that tab's alone, these this one's.
    ...navKeys,
    {
      // Blender's walk (Docs/navigation.md §4): Shift and the key left of 1, which alone puts the cards away.
      ...keyed('walk'), mcp: 'view_set', view: true, when: () => pointerOverView(),
      help: 'Walk: the mouse looks, W A S D move, E Q rise and fall, Shift faster, Alt slower, the wheel the speed -- a click, Enter or Space keeps it, a right click or Esc puts the view back',
      run: () => viewport.walk((code) => MrDebug.held(code)),
    },
    {
      ...keyed('view camera'), mcp: 'view_set', view: true,
      help: 'The editor\'s camera looking through the scene\'s main camera -- or the camera selected -- as Align view with camera',
      run: () => lookThroughCamera(),
    },
    {
      ...keyed('camera to view'), mcp: 'scene_set',
      help: 'The cameras selected moved to the editor\'s view, turned and seeing as it does -- the Camera block\'s Align with view',
      when: () => selectedCameras().length > 0, run: () => alignCamerasWithView(world, selectedCameras(), viewport.view(), changed),
    },
    // The arrows fly over the Scene view (Docs/navigation.md §7): ↑ ↓ along the look, ← → across, Shift faster -- the pointer
    // over the view, no menu open; elsewhere the tree's rows and the menus have them, as ever.
    {
      // Whichever side has the keys (the Assets panel's too): the pointer over the view is what says the arrows fly.
      ...keyed('fly arrows'), mcp: 'ui', view: true, anySide: true, hold: true, when: () => pointerOverView() && !menu.open,
      help: 'Fly the editor\'s camera while held, the pointer over the view: ↑ ↓ along the look, ← → across, Shift faster',
      run: () => viewport.arrowFly((code) => MrDebug.held(code)),
    },
    // A menu's items by key: the arrows walk them, Enter chooses (the browser's own, on a button).
    { ...keyed('menu item above'), mcp: 'ui', view: true, help: 'The item above in the menu that is open', when: () => menu.open, run: () => menu.step(-1) },
    { ...keyed('menu item below'), mcp: 'ui', view: true, help: 'The item below in the menu that is open', when: () => menu.open, run: () => menu.step(1) },
    { ...keyed('submenu open'), mcp: 'ui', view: true, help: 'Open the submenu of the item focused -- Create, a folder of prefabs', when: () => menu.open, run: () => menu.enter() },
    { ...keyed('submenu close'), mcp: 'ui', view: true, help: 'Close the submenu, back to its item', when: () => menu.open, run: () => menu.back() },
    { ...keyed('row above'), mcp: 'scene_select', view: true, help: 'Select the row above in the tree', when: treeKeys, run: () => tree.walk(-1) },
    { ...keyed('row below'), mcp: 'scene_select', view: true, help: 'Select the row below in the tree', when: treeKeys, run: () => tree.walk(1) },
    { ...keyed('fold row'), mcp: 'ui', view: true, help: 'Fold the selected row; folded already, select its parent', when: treeKeys, run: () => tree.fold(false) },
    { ...keyed('unfold row'), mcp: 'ui', view: true, help: 'Unfold the selected row; unfolded already, select its first child', when: treeKeys,
      run: () => tree.fold(true) },
    { ...keyed('duplicate'), mcp: 'scene_duplicate', help: 'A copy of the selection, where it is, selected', run: () => edits.duplicate() },
    // Text selected on the page -- a status line, a number -- is the browser's to copy.
    {
      ...keyed('copy'), mcp: 'scene_copy', view: true, help: 'Copy the selection, each with everything under it, for Paste here or in another scene',
      when: () => document.getSelection()?.isCollapsed ?? true, run: () => edits.copy(),
    },
    // With nothing copied here, the browser's paste instead, heard as such (`edits.ts`): it needs no permission to read the clipboard.
    {
      ...keyed('paste'), mcp: PASTE_MCP, help: 'Paste what was copied, round where the last one was placed or the middle of the view',
      when: () => edits.copied, run: () => void edits.paste(),
    },
    {
      ...keyed('select all'), mcp: 'scene_select', view: true, help: 'Select every entity -- what the filter shows, while there is one',
      run: () => {
        stopPick(false);
        selection.chooseAll(tree.all());
      },
    },
    { ...keyed('select none'), mcp: 'scene_select', view: true, help: 'Select nothing', run: () => selection.clear() },
    // H is the History card's and E the gizmo's turn: Shift with them.
    {
      ...keyed('hide'), mcp: 'scene_flags', help: 'Hide the selection, or show it again: not drawn, still running -- and not clicked in the scene',
      run: () => edits.toggle('hidden', selection.list),
    },
    {
      ...keyed('lock picking'), mcp: 'scene_flags',
      help: 'Lock the selection against picking in the scene, or unlock it: still drawn and running, selected only in the tree',
      run: () => edits.toggle('unpickable', selection.list),
    },
    {
      ...keyed('switch off'), mcp: 'scene_flags', help: 'Switch the selection off, or on again: in no system and not drawn, everything under it too',
      run: () => edits.toggle('disabled', selection.list),
    },
    {
      ...keyed('lock inspector'), mcp: 'ui', view: true, anySide: true,
      help: 'Lock the inspector to what it shows -- the entities or the files -- whatever is chosen after, or unlock it',
      run: () => ctx.lock(!ctx.locked),
    },
    { ...keyed('save as prefab'), mcp: 'scene_save_prefab', help: 'Save the selection as a new prefab, asking its key: it becomes an instance of it, one step', run: () => askSaveAs() },
    { ...keyed('delete'), mcp: 'scene_destroy', help: DESTROY, run: () => edits.destroy() },
    // A Mac keyboard's delete key is Backspace.
    { ...keyed('delete (backspace)'), mcp: 'scene_destroy', help: DESTROY, run: () => edits.destroy() },
    // A key field's picker in the inspector (`key-field.ts`): its ↑ ↓ Enter and Esc, typed into it alone.
    ...keyPickKeys(),
    ...addComponentKeys(),
  ];
  const offs = [
    // The selection changed (the editor has drawn it): its row in view, the first one in the inspector.
    // An entity chosen -- in the tree, the scene, a box, by the agent, a prefab dropped -- is what the right panel shows
    // now (not while it is locked), and the Assets panel lets go of its files: one selection across the tab. Nothing
    // chosen -- a click on nothing, the other side's choice clearing this one -- moves neither.
    ctx.on('selection', () => {
      tree.showSelected();
      if (selection.list.length > 0) {
        ctx.inspect();
        ctx.chose();
      }
      if (visible && inspecting) inspector.refresh();
    }),
    // Another world: the pick is off, and indices of it mean nothing here -- what was open is closed. Then `refresh`.
    ctx.on('loaded', () => {
      stopPick(false);
      edits.reset();
      tree.reset();
    }),
    // The scene's click is the tool's while an entity is being picked.
    viewport.onPick((e) => picked(e)),
    // A right-click on an entity is its menu.
    viewport.onContext((e, pointer) => {
      if (e === NONE) return false;
      openMenu(e, pointer.clientX, pointer.clientY);
      return true;
    }),
    // A step committed -- a value typed or scrubbed, a gizmo drag let go, by this tool or another: the marks kept current.
    // After the event that committed it (an Enter's submit) is done with the field, so the panel is built again after it.
    ctx.on('changed', () => {
      if (visible && inspecting) setTimeout(() => inspector.checkMarks(), 0);
    }),
    // The numbers keep up with the gizmo, in place; the links' lines with the entities.
    viewport.on('moved', () => {
      lines.stale();
      inspector.showValues();
    }),
    ...keys.map((key) => ctx.keys.add(key)),
    // Emulate Numpad (Docs/navigation.md D5): the digit row, - and = as the numpad, only with the pointer over the Scene view.
    ...emulatedKeys(keys, () => loadPrefs().nav.emulateNumpad && pointerOverView()).map((key) => ctx.keys.add(key)),
  ];

  return {
    setVisible(show) {
      // The scene first: showing the tool draws, and the gizmo and the lines have to know by then.
      lines.setVisible(show);
      viewport.setActive(show);
      visible = show;
      tree.setVisible(show);
      if (!show) {
        stopPick(false);
        menu.close();
      }
      inspector.setVisible(show && inspecting);
      if (show) refresh();
    },
    setInspector(on) {
      if (on === inspecting) return;
      inspecting = on;
      if (!visible) return;
      if (!on) inspector.shut();
      inspector.setVisible(on);
      if (on) inspector.refresh();
    },
    // Locked: what the inspector shows now pinned, by ref; unlocked, the selection again. The header's lock drawn either way.
    setLocked(on) {
      pinned = on ? selection.list.map((e) => world.ref(e)) : null;
      if (visible && inspecting) inspector.refresh();
    },
    // A file chosen in the Assets panel: the entities let go (its 'selection', empty, moves no panel).
    letGo() {
      if (selection.list.length > 0) selection.clear();
    },
    cards: () => [tree.card, inspector.panel],
    // Another world, an edit by another tool, an undo or a redo (the host's `refreshTools`): the tree and the inspector read again.
    refresh,
    showHead: () => tree.showCard(),
    holdsEscape: () => menu.open || tree.ask.open || tree.dropped || inspector.dropped || picking !== null,
    // One thing at a time, the one on top first: the menu, then a drop-down, then a pick.
    cancel: () => {
      if (menu.open) menu.close();
      else if (tree.ask.open) tree.ask.close();
      else if (tree.dropped || inspector.dropped) {
        tree.shut();
        inspector.shut();
      } else stopPick();
    },
    // What the tool shows, for the agent's turn: the tree's filter, a pick under way. Not whom the inspector
    // is on: always the first selected, which the host's selection line names first.
    context: () => {
      const facts: ToolFact[] = [];
      if (tree.filter !== '') facts.push({ name: 'tree filtered by', value: `"${tree.filter}"` });
      if (picking) facts.push({ name: 'picking', value: pickKey(picking) });
      return facts;
    },
    // While an entity is picked, what to click: the one line the tool has for the top bar.
    hint: () =>
      picking?.what === 'link' ? `Click the entity to link ${picking.from.length > 1 ? `all ${picking.from.length} ` : ''}to, in the scene or the tree · Esc stops`
      : picking ? `Click whom ${pickKey(picking)} should point at${picking.from.length > 1 ? ` for all ${picking.from.length}` : ''}, in the scene or the tree · Esc stops`
      : null,
    dispose() {
      stopPick(false);
      edits.dispose();
      menu.dispose();
      for (const off of offs) off();
      lines.dispose();
      tree.dispose();
      inspector.dispose();
    },
  };
}
