/**
 * The prefabs renamed while the editor is up, in order (Docs/prefabs.md §6),
 * and a world save followed through them as it is put back.
 *
 * - **A save is of an era**: the number of renames made when it was taken
 *   (`era`). An undo puts back a world step's save with its era
 *   (`world-steps.ts`), an Apply's undo or redo its own (`overrides-steps.ts`'
 *   `era`): only the renames made since are replayed on it (`follow`), so its
 *   instances of the key as it was come back as instances of the key now.
 * - **An Apply's files follow too** (`followFiles`): its undo or redo writes
 *   the prefab files of its era under the key each has now -- never
 *   `crate.prefab` made again beside the `box.prefab` it was renamed to. The
 *   prefabs a file nests are named by uid, and `PUT prefab` runs the repair
 *   pass over the file it writes: each lands named as it is called now.
 * - **Never onto a newer save**: after `crate` renamed `box`, a new prefab may
 *   be called `crate` again; a world saved then holds instances of that one,
 *   and replaying the old rename on it would make them `box` -- two `box`
 *   rows in `instances.keys`, the table corrupt.
 *
 * Pure: node tests it (`renames.test.ts`).
 */
import type { WorldSave } from '@vibe/engine';
import { caseKey } from '@vibe/engine';
import { renameInSave } from './level-keys.ts';

export interface Renames {
  /** How many renames there have been: the era a save taken now is of. */
  readonly era: number;
  /** Prefab `from` renamed `to`. */
  push(from: string, to: string): void;
  /** `save`, taken in era `since`, with every rename made after it applied, in order, in place. */
  follow(save: WorldSave, since: number): WorldSave;
  /** Prefab files by key, written in era `since`: each under its key now, in order (what it nests the server's pass names). */
  followFiles(files: ReadonlyMap<string, string>, since: number): Map<string, string>;
}

export function createRenames(): Renames {
  const list: [string, string][] = [];
  return {
    get era() {
      return list.length;
    },
    push(from, to) {
      list.push([from, to]);
    },
    follow(save, since) {
      for (let i = Math.max(0, since); i < list.length; i++) renameInSave(save, list[i]![0], list[i]![1]);
      return save;
    },
    followFiles(files, since) {
      const out = new Map<string, string>();
      for (const [key, text] of files) {
        let at = key;
        for (let i = Math.max(0, since); i < list.length; i++) {
          const [from, to] = list[i]!;
          if (caseKey(at) === caseKey(from)) at = to;
        }
        out.set(at, text);
      }
      return out;
    },
  };
}

