/**
 * The scene without a main camera, said (Docs/camera.md §3, 8.3): one notice
 * on the editor's strip (`notices.ts`, kind `camera`) while the scene open has
 * no `Camera` with `main` on -- the game draws through the built-in one then.
 *
 * - **No camera at all**: "This scene has no main camera…" with **Add a main
 *   camera** -- a camera entity where the built-in camera is now, `main` on,
 *   selected, one step (the editor's `add`).
 * - **Cameras, none main**: said so, with **Make <name> main** -- the first by
 *   entity -- one step.
 * - **Gone when one is main**, and never for a prefab opened to edit (it is no
 *   scene). Looked at as each frame of the editor's scene is drawn (the
 *   viewport's `update`): a load, an undo, a camera made or its tick changed
 *   all show there -- walking the cameras alone (`mainCameraCode`, a standing
 *   query), and building nothing while the rule and the first camera's name
 *   are as they were. The rule is `camera-entity.ts`' (tested).
 * - **Dismissed, it stays away** until what it would say changes.
 */
import { Camera, type Entity, label, Name, type World } from '@vibe/engine';
import { cameraQuery, MAIN_SAID, mainCameraCode, mainRuleFrom, mainRuleText } from './camera-entity.ts';
import type { NoticeAction, Notices } from './notices.ts';

export interface CameraNoticeOptions {
  world: World;
  notices: Notices;
  /** A prefab is opened to edit: no scene, nothing said. */
  prefabOpen(): boolean;
  /** Add a main camera: made where the built-in camera is, selected, one step. */
  add(): void;
  /** `e`'s `main` ticked: one step. */
  makeMain(e: Entity): void;
}

export interface CameraNotice {
  /** The rule looked at again: the notice up, changed, or taken down. */
  check(): void;
  dispose(): void;
}

export function createCameraNotice({ world, notices, prefabOpen, add, makeMain }: CameraNoticeOptions): CameraNotice {
  // Made now, outside any tick: each frame only walks it.
  cameraQuery(world);
  /** What it said last -- up, or dismissed -- and its id; null for nothing to say. */
  let said: { text: string; id: number } | null = null;
  /** What it last looked at: the rule's code and the first camera's own name -- unchanged, nothing is built. */
  let lastCode = NaN;
  let lastName: string | null | undefined;
  const down = (): void => {
    if (said) notices.dismiss(said.id);
    said = null;
  };
  return {
    check() {
      const code = prefabOpen() ? MAIN_SAID : mainCameraCode(world);
      const own = code > 0 && world.has(code as Entity, Name) ? world.store(Name).value[code] : null;
      if (code === lastCode && own === lastName) return;
      lastCode = code;
      lastName = own;
      const rule = mainRuleFrom(code);
      if (rule === null) return down();
      const first = rule.kind === 'none-main' ? rule.first : 0;
      const name = first ? label(world, first as Entity) : '';
      const text = mainRuleText(rule, name);
      // The same words: as it is, up or dismissed.
      if (said?.text === text) return;
      down();
      const actions: NoticeAction[] = rule.kind === 'none'
        ? [{ mcp: 'scene_create', label: 'Add a main camera', title: 'A camera entity where the built-in camera is now, main: the game draws through it', run: add }]
        : [{
          mcp: 'scene_main_camera',
          label: `Make ${name} main`,
          title: `${name}'s main ticked: the game draws through it`,
          run: () => {
            if (world.alive(first as Entity) && world.has(first as Entity, Camera)) makeMain(first as Entity);
          },
        }];
      said = { text, id: notices.add('camera', text, undefined, actions).id };
    },
    dispose() {
      down();
      lastCode = NaN;
    },
  };
}
