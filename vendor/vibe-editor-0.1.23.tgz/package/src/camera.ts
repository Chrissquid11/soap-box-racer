/**
 * The editor's own camera while it is open (Docs/camera.md §1 rule 6, §3): a
 * perspective and an orthographic camera of the editor's (`ViewCamera`, the
 * Model tab's, `view/view-camera.ts`), never the game's. While the editor is up
 * the game draws the whole canvas through the active one (`Game.viewOverride`);
 * closed -- a playtest -- the game draws through its own cameras again, and a
 * pause brings this one back where it was. The editor's one driver moves it
 * (`view/navigator.ts`, Blender's navigation: Docs/navigation.md) -- the middle
 * button orbits, Shift pans, Ctrl zooms; the wheel zooms, or on a trackpad two
 * fingers orbit, a pinch zooms, Shift pans (`view/navigation.ts`) -- in either
 * projection: zoom in orthographic narrows the frustum.
 *
 * - **The left button is the selection's** (`picking.ts`): a box from
 *   anywhere, a click picks -- never the orbit, but with Emulate 3 Button
 *   Mouse and Alt held. The right is the menu. A press on a handle of the gizmo
 *   holds the camera still (`hold`); one on the view cube orbits from there
 *   (`grab`).
 * - **Perspective or orthographic** (`setProjection`, the view cube's centre,
 *   Numpad5): the swap keeps what is seen at the target the same size (D20).
 *   Framing (`F`) and the wheel's pan work through the orthographic frustum's
 *   height there, not a field of view.
 * - **No limits**, as Blender's turntable (Docs/navigation.md §6): the orbit
 *   goes on over the top and upside down, the view's up carried with it
 *   (`ViewCamera.orbit`); the camera and what it turns round go under the
 *   ground as freely as over it. An axis view (a key, a cone) is upright again.
 * - **Where it was left**: each open goes on from the last close; the first
 *   looks from where the game's main camera is, turning round what it looked
 *   at. Across a reload too: the pose, its projection, its orthographic
 *   height and its up, is kept with the editor's resume record (`pose`, `setPose`).
 * - **Every layer seen**, as an editor's view of the scene has them: its
 *   cameras are its own, so nothing of the game's is touched.
 * - **The game frame's shape** (`Game.frame`, Docs/game-view.md §3: the
 *   scene's room between the cards): both cameras' aspect from it as it opens,
 *   whenever the canvas is resized (a `ResizeObserver`) and whenever the editor
 *   moves the frame (`reshape`), the orthographic frustum's width with it; the
 *   pointer mapped into it.
 */
import * as THREE from 'three';
import type { Game } from '@vibe/engine/boot';
import { keepPref, loadPrefs, type WheelMode } from './prefs.ts';
import { ViewCamera } from './view/view-camera.ts';
import type { Projection, Vec3 } from './view/views.ts';
import type { EditorView } from './camera-entity.ts';
import { createNavigator, noAutoscroll, type NavView } from './view/navigator.ts';
import { overView } from './view/over-view.ts';
import { armFly, arrowFly, beginWalk, type WalkTarget } from './view/walker.ts';

/** Framing leaves this much room round what it frames. */
const MARGIN = 1.15;
/** The ground is found under a pointer only this far off, in metres: further, and the view is all but level with it. */
const GROUND = 120;
/** The perspective camera's vertical field of view, in degrees: the game's built-in camera's, as the Scene tab always had it. */
export const SCENE_FOV = 50;
/** Nearest and furthest a perspective dolly goes; the orthographic zoom's limits. */
const MIN_DISTANCE = 0.3;
const MAX_DISTANCE = 150;
const MIN_ZOOM = 0.01;
const MAX_ZOOM = 1000;
/** What the clip planes are measured against (`ViewCamera.rescale`): a scene's things, and its ground's reach. */
const RADIUS = 10;
const REACH = 150;

/** A part of the view, in its own measure: -1 at its left and bottom edges, 1 at its right and top. */
export interface ViewRect {
  x0: number;
  x1: number;
  y0: number;
  y1: number;
}

/** Where the editor's camera is and what it turns round, in the world, and how it sees: kept across a reload. */
export interface CameraPose {
  position: [number, number, number];
  target: [number, number, number];
  /** Perspective unless said: a pose kept before there was a choice. */
  projection?: Projection;
  /** The world's height seen at the target in orthographic, in metres. */
  height?: number;
  /** The view's own up: upside down after an orbit over the top. Y when left out -- a pose kept before there was one. */
  up?: [number, number, number];
  /**
   * The perspective camera's vertical field of view, in degrees: `SCENE_FOV`
   * unless said -- Align view with camera's, a camera's own, kept until the
   * projection is swapped.
   */
  fov?: number;
}

export interface EditorCamera {
  /**
   * The camera the editor's -- as it was left, or looking from where the game's
   * main camera is -- drawn through (`Game.viewOverride`) and listening on the
   * canvas: after the gizmo, which hears a press first, so a drag on a handle is
   * never the camera's.
   */
  open(): void;
  /** The game drawn through its own cameras again, the editor's view kept for the next open. */
  close(): void;
  /** Still while a handle of the gizmo is dragged, and free again. */
  hold(held: boolean): void;
  /** A press the cube took: the orbit, dragged from it -- or, let go where it went down, `click` (Docs/navigation.md §2). */
  grab(event: PointerEvent, click: () => void): void;
  /** The camera drawn through now: the perspective or the orthographic one. */
  readonly object: THREE.PerspectiveCamera | THREE.OrthographicCamera;
  readonly projection: Projection;
  /** The other projection, what is seen at the target the same size; drawn through at once while open. */
  setProjection(projection: Projection): void;
  /** Looking along `direction` (from what it turns round toward the camera) at the distance it has, upright: `view_set`'s pose. */
  lookFrom(direction: Vec3): void;
  /** The same from an axis -- a cone of the cube, the numpad, `view_set`'s numpad: orthographic too with Auto Perspective (Docs/navigation.md §3). */
  snapTo(direction: Vec3): void;
  /** An orbit step, in turns: `dx` as a drag right, `dy` as a drag down (the numpad's 15°). */
  orbitBy(dx: number, dy: number): void;
  /** A pan step: the view moved `dx` right, `dy` up, in shares of the height it sees at the pivot. */
  panBy(dx: number, dy: number): void;
  /** A zoom step toward the middle: under 1 nearer. */
  zoomBy(scale: number): void;
  /** Blender's walk in this view (Docs/navigation.md §4, `view/walker.ts`), `held` the keys down now. */
  walk(held: (code: string) => boolean): void;
  /** The arrow keys' flight (Docs/navigation.md §7): ↑ ↓ along the look, ← → across, while any is held (`held`). */
  arrowFly(held: (code: string) => boolean): void;
  /** What the walk asks of this view: `walk`'s, and a test's to drive its pieces. */
  walkTarget(): WalkTarget;
  /** From what it turns round toward the camera, unit length, into `out`. */
  direction(out: THREE.Vector3): THREE.Vector3;
  /**
   * Onto `bounds`, from the side it looks from now, near enough that they fill
   * the view -- or `part` of it, the room the editor's cards leave (`ViewRect`):
   * filled and centred there, never under a card. In either projection.
   */
  frame(bounds: THREE.Box3, part?: ViewRect | null): void;
  /** The ray from the camera through (`x`, `y`) on the page. */
  aim(x: number, y: number): THREE.Raycaster;
  /** The game's frame moved (`Game.setFrame`): both cameras shaped as it is now, and drawn again -- nothing if it has not since the last shaping. */
  reshape(): void;
  /** Where the middle of the view meets the ground, or the point the camera turns round if it never does. */
  lookAt(): THREE.Vector3;
  /** Where a pointer at (`x`, `y`) on the page meets the ground, into `out`; null if it looks above the horizon, or too far off. */
  groundAt(x: number, y: number, out: THREE.Vector3): THREE.Vector3 | null;
  /** Is this point of the world in front of the camera and inside the view? */
  sees(point: THREE.Vector3): boolean;
  /** What the wheel is -- a trackpad's, a mouse's, or told by its events -- kept with the preferences. */
  readonly wheel: WheelMode;
  setWheel(mode: WheelMode): void;
  /** Does scrolling orbit just now: a trackpad, by the preference or, in `auto`, by the last wheel read. */
  readonly trackpad: boolean;
  /** Where it is now, open, or was left; null before it has ever opened. */
  readonly pose: CameraPose | null;
  /** The view now as numbers -- where, turned how, round what, how it sees: what Align with view and Create ▸ Camera take. */
  view(): EditorView;
  /** Where it goes from now: at once while open, else at the next open. */
  setPose(pose: CameraPose): void;
  dispose(): void;
}

/** The editor's two cameras, as the Scene tab has them: its field of view, its clip planes measured for a scene. */
export function sceneView(): ViewCamera {
  const view = new ViewCamera('perspective');
  view.perspective.fov = SCENE_FOV;
  view.perspective.updateProjectionMatrix();
  view.rescale(RADIUS, REACH);
  return view;
}

const forward = new THREE.Vector3();
const centre = new THREE.Vector3();
const right = new THREE.Vector3();
const upward = new THREE.Vector3();
const corner = new THREE.Vector3();

/**
 * `view` onto `bounds` (or `part` of the view, `ViewRect`): from what it turns
 * round to the middle of `bounds`, and back -- or the orthographic frustum
 * opened -- just far enough that each of their eight corners is inside the
 * view, with a margin. Tighter than a sphere round them, which a flat spread of
 * things on the ground is mostly not. In `part` of the view, its halves are
 * what there is room in, and the camera slides across so the middle of `bounds`
 * is the middle of that part. In orthographic the camera stands where the
 * perspective one would, so a swap back sees the same. Pure three: node-tested.
 */
export function frameView(view: ViewCamera, aspect: number, bounds: THREE.Box3, part?: ViewRect | null): void {
  const camera = view.camera;
  bounds.getCenter(centre);
  const across = part ? Math.max(0.05, (part.x1 - part.x0) / 2) : 1;
  const high = part ? Math.max(0.05, (part.y1 - part.y0) / 2) : 1;
  // From what it turns round towards the camera, and the view's own right and up for it.
  forward.copy(camera.position).sub(view.target);
  if (forward.lengthSq() < 1e-8) forward.set(0, 0.5, 1);
  forward.normalize();
  right.crossVectors(camera.up, forward);
  if (right.lengthSq() < 1e-8) right.set(1, 0, 0);
  right.normalize();
  upward.crossVectors(forward, right);
  const slope = Math.tan(THREE.MathUtils.degToRad(view.perspective.fov) / 2);
  view.target.copy(centre);
  if (view.projection === 'orthographic') {
    // Half the frustum's height that holds every corner, across and up, in the part.
    let half = 0;
    for (let i = 0; i < 8; i++) {
      corner.set(i & 1 ? bounds.max.x : bounds.min.x, i & 2 ? bounds.max.y : bounds.min.y, i & 4 ? bounds.max.z : bounds.min.z).sub(centre);
      half = Math.max(half, Math.abs(corner.dot(right)) / (aspect * across), Math.abs(corner.dot(upward)) / high);
    }
    half = Math.max(half * MARGIN, 0.05);
    view.fitHeight(2 * half);
    if (part) view.target.addScaledVector(right, -((part.x0 + part.x1) / 2) * half * aspect).addScaledVector(upward, -((part.y0 + part.y1) / 2) * half);
    camera.position.copy(view.target).addScaledVector(forward, THREE.MathUtils.clamp(half / slope, MIN_DISTANCE, MAX_DISTANCE));
  } else {
    const tall = slope * high;
    const wide = slope * aspect * across;
    let distance = 0;
    for (let i = 0; i < 8; i++) {
      corner.set(i & 1 ? bounds.max.x : bounds.min.x, i & 2 ? bounds.max.y : bounds.min.y, i & 4 ? bounds.max.z : bounds.min.z).sub(centre);
      // Nearer the camera by its share along the view, and it needs room across it either way.
      const near = corner.dot(forward);
      distance = Math.max(distance, near + Math.abs(corner.dot(right)) / wide, near + Math.abs(corner.dot(upward)) / tall);
    }
    distance = THREE.MathUtils.clamp(distance * MARGIN, MIN_DISTANCE + 0.5, MAX_DISTANCE);
    if (part) {
      // The middle of the part, at that distance, is this far off the view's own: what it turns round goes the other way.
      const full = slope * distance;
      view.target.addScaledVector(right, -((part.x0 + part.x1) / 2) * full * aspect).addScaledVector(upward, -((part.y0 + part.y1) / 2) * full);
    }
    camera.position.copy(view.target).addScaledVector(forward, distance);
  }
  camera.lookAt(view.target);
  view.clip();
}

/** `view`'s pose as values: where, round what, the projection, and what the orthographic frustum sees at the target. */
export function poseOf(view: ViewCamera): CameraPose {
  const o = view.orthographic;
  return {
    position: view.camera.position.toArray(),
    target: view.target.toArray(),
    projection: view.projection,
    height: (o.top - o.bottom) / o.zoom,
    fov: view.perspective.fov,
    up: view.camera.up.toArray(),
  };
}

/**
 * `pose` moved to look from `position` at `target` (`view_set`'s pose): its projection, height and field of view kept,
 * upright -- the up it had lies anywhere against the new look, and would roll the view or leave it degenerate.
 */
export function poseLookingAt(pose: CameraPose | null, position: [number, number, number], target: [number, number, number]): CameraPose {
  const { up: _up, ...kept } = pose ?? { position, target };
  return { ...kept, position, target };
}

/** A field of view a pose may hold: a number of degrees a perspective camera can have; anything else is `SCENE_FOV`. */
const fovOf = (fov: number | undefined): number => (fov !== undefined && Number.isFinite(fov) && fov > 0 && fov < 180 ? fov : SCENE_FOV);

/** `view` put where `pose` says: its projection, its place, the orthographic frustum's height (zoom 1), the perspective field of view. */
export function putPose(view: ViewCamera, pose: CameraPose): void {
  const fov = fovOf(pose.fov);
  if (view.perspective.fov !== fov) {
    view.perspective.fov = fov;
    view.perspective.updateProjectionMatrix();
  }
  view.setProjection(pose.projection ?? 'perspective');
  view.target.fromArray(pose.target);
  view.camera.position.fromArray(pose.position);
  if (view.projection === 'orthographic' && pose.height !== undefined && pose.height > 0 && Number.isFinite(pose.height)) view.fitHeight(pose.height);
  // Upside down as it was left (over the top), or upright: a pose kept before there was an up.
  const up = pose.up;
  if (up && up.every(Number.isFinite) && Math.hypot(...up) > 1e-6) view.camera.up.fromArray(up).normalize();
  else view.camera.up.set(0, 1, 0);
  view.camera.lookAt(view.target);
  view.clip();
}

/** What the editor's camera asks of the editor besides the game: Orbit Around Selection's pivot, and word of the wheel's device. */
export interface CameraHooks {
  /** The selection's middle, or null: what the orbit turns round with Orbit Around Selection. */
  pivot?(): THREE.Vector3 | null;
  /** The wheel is read as another device now (`auto`): the top bar's status line says what scrolling does. */
  scrolled?(trackpad: boolean): void;
  /** The keys down now (MrDebug's `held`): what the right button's flight and the arrows read. None: no flight. */
  held?(code: string): boolean;
}

/**
 * `moved`: the camera moved, by the driver or by framing -- the frame to be
 * drawn again. Whoever needs the camera drawn through reads `object` as it
 * needs it.
 */
export function createCamera(game: Game, moved: () => void, hooks: CameraHooks = {}): EditorCamera {
  const canvas = game.renderer.domElement;
  const view = sceneView();
  view.minDistance = MIN_DISTANCE;
  view.maxDistance = MAX_DISTANCE;
  view.minZoom = MIN_ZOOM;
  view.maxZoom = MAX_ZOOM;
  /** Has it opened once: before, the first open looks from where the game's main camera is. */
  let placed = false;
  /** Open: drawn through just now. */
  let opened = false;
  /** Still while a handle of the gizmo is dragged (`hold`). */
  let held = false;

  let wheelMode = loadPrefs().wheel;

  /** After every move: the clip planes, the frame drawn again. */
  function settle(): void {
    view.clip();
    moved();
  }

  /** The game's frame on the page, client pixels: what the camera is drawn into, and the pointer measured against. */
  const box = (): { left: number; top: number; width: number; height: number } => {
    const r = canvas.getBoundingClientRect?.();
    const f = game.frame;
    return { left: (r?.left ?? 0) + f.x, top: (r?.top ?? 0) + f.y, width: f.width, height: f.height };
  };
  /**
   * Auto Perspective (Docs/navigation.md §3): orthographic because an axis view made it so -- a key, a cone, an Alt
   * snap -- and so back to perspective once orbited off the axis. Never after a projection the person chose (Numpad5).
   */
  let autoOrtho = false;
  /** An orbit away from the axis an axis view made orthographic: perspective again, as Numpad5 swaps it. */
  function autoBack(): void {
    if (!autoOrtho || view.preset !== 'free') return;
    autoOrtho = false;
    project('perspective');
  }
  /**
   * Looking along an axis, upright -- or not (`axis` false: an Alt+middle drag between snaps, `up` its own turned up);
   * orthographic with Auto Perspective.
   */
  function snapTo(direction: Vec3, axis = true, up?: Vec3): void {
    view.lookFrom(direction, axis ? undefined : up);
    if (axis && view.projection === 'perspective' && loadPrefs().nav.autoPerspective) {
      project('orthographic');
      autoOrtho = true;
    } else {
      if (!axis) autoBack();
      settle();
    }
  }
  /** Where an Alt+middle click centres: the nearest thing drawn under the pointer, else the ground there. */
  const hitPoint = new THREE.Vector3();
  function pointAt(x: number, y: number): THREE.Vector3 | null {
    const ray = aim(x, y);
    const hit = ray.intersectObjects(game.scene.children.filter((c) => c.visible && c.userData.entity !== undefined), true)[0];
    if (hit) return hitPoint.copy(hit.point);
    return camera.groundAt(x, y, hitPoint);
  }
  /** The one view the driver moves here: the whole canvas. */
  const navView: NavView = {
    cam: view,
    box,
    moved: () => {
      autoBack();
      moved();
    },
    pivot: () => hooks.pivot?.() ?? null,
    look: (direction, axis, up) => snapTo(direction, axis, up),
    pointAt,
  };
  /** The camera in `projection`: a camera's own field of view given back to the editor's, drawn through, settled. */
  function project(projection: Projection): void {
    // A camera's own field of view (Align view with camera) is kept until the swap: the editor's own again, either way --
    // before it, back to perspective, so the swap places the camera for it; after it, to orthographic, which sized itself from the one seen.
    if (projection === 'perspective') ownFov();
    view.setProjection(projection);
    if (projection === 'orthographic') ownFov();
    drawThrough();
    settle();
  }
  const nav = createNavigator({
    wheelMode: () => wheelMode,
    device: (device) => {
      moved();
      hooks.scrolled?.(device === 'trackpad');
    },
  });

  /** A press on the canvas, after the gizmo's (which holds the camera still for one on a handle): the driver's if it navigates. */
  const down = (event: PointerEvent): void => {
    if (held || nav.dragging) return;
    // A gizmo's handle under a left press is the gizmo's; the rest of the left button is picking's box or click.
    // A right press may yet be a flight (Docs/navigation.md §7): moved, or a fly key pressed, it flies; let go, picking's menu.
    if (nav.press(event, navView) === 'menu' && hooks.held) armFly(camera.walkTarget(), hooks.held, event);
    if (nav.dragging) canvas.setPointerCapture?.(event.pointerId);
  };
  const drag = (event: PointerEvent): void => {
    nav.move(event);
  };
  const up = (event: PointerEvent): void => {
    if (nav.up(event) && canvas.hasPointerCapture?.(event.pointerId)) canvas.releasePointerCapture(event.pointerId);
  };
  const cancel = (): void => nav.cancel();
  /** The pointer over the Scene view, or off it (onto a card too): Emulate Numpad's digit row is the numpad only over it. */
  const over = (): void => overView('scene', true);
  const away = (): void => overView('scene', false);
  /** Every wheel on the canvas: the driver's, but while a handle of the gizmo is dragged. */
  const wheel = (event: WheelEvent): void => {
    if (held) {
      event.preventDefault();
      return;
    }
    nav.wheel(event, navView);
  };

  const projected = new THREE.Vector3();
  const ray = new THREE.Raycaster();
  // Picks on any layer, as the editor's cameras see them all.
  ray.layers.enableAll();
  const point = new THREE.Vector2();

  /** Where the middle of the view meets the ground, or the point the camera turns round if it never does. */
  function groundAhead(out: THREE.Vector3, camera: THREE.Camera = view.camera): THREE.Vector3 {
    camera.getWorldDirection(forward);
    camera.getWorldPosition(centre);
    const t = forward.y < -1e-3 ? -centre.y / forward.y : -1;
    if (t > 0 && t < 60) return out.copy(centre).addScaledVector(forward, t);
    return out.set(view.target.x, 0, view.target.z);
  }

  function aim(x: number, y: number): THREE.Raycaster {
    const rect = box();
    point.set(((x - rect.left) / rect.width) * 2 - 1, -((y - rect.top) / rect.height) * 2 + 1);
    view.camera.updateMatrixWorld();
    ray.setFromCamera(point, view.camera);
    return ray;
  }

  /** Both cameras shaped as the game's frame is. */
  /** The frame the camera was last shaped by: `reshape` does nothing while the game's frame is still that. */
  const shaped = { x: NaN, y: NaN, width: NaN, height: NaN };
  const shape = (): void => {
    const f = game.frame;
    shaped.x = f.x;
    shaped.y = f.y;
    shaped.width = f.width;
    shaped.height = f.height;
    if (f.width > 0 && f.height > 0) view.setAspect(f.width / f.height);
  };
  const resized = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(() => {
    if (!opened) return;
    shape();
    moved();
  });

  /** The first open: looking from where the game's main camera is, turning round where it looked at the ground. */
  function fromGame(): void {
    const theirs = game.mainCamera;
    theirs.updateMatrixWorld();
    const camera = view.camera;
    theirs.matrixWorld.decompose(camera.position, camera.quaternion, corner);
    camera.updateMatrixWorld();
    groundAhead(view.target, camera);
    camera.up.set(0, 1, 0);
    camera.lookAt(view.target);
    view.clip();
  }

  /** The perspective camera at the editor's own field of view. */
  function ownFov(): void {
    if (view.perspective.fov === SCENE_FOV) return;
    view.perspective.fov = SCENE_FOV;
    view.perspective.updateProjectionMatrix();
  }

  /** The camera drawn through is `view.camera` now: the game told. */
  function drawThrough(): void {
    if (opened) game.viewOverride = view.camera;
  }

  const camera: EditorCamera = {
    open() {
      if (opened) return;
      shape();
      if (!placed) {
        placed = true;
        fromGame();
      }
      opened = true;
      drawThrough();
      canvas.addEventListener('wheel', wheel, { capture: true, passive: false });
      // After the gizmo's, before picking's: a press a handle took holds the camera still.
      canvas.addEventListener('pointerdown', down);
      canvas.addEventListener('pointermove', drag);
      canvas.addEventListener('pointerup', up);
      canvas.addEventListener('pointercancel', cancel);
      canvas.addEventListener('mousedown', noAutoscroll);
      canvas.addEventListener('pointermove', over);
      canvas.addEventListener('pointerleave', away);
      settle();
      resized?.observe(canvas);
    },
    close() {
      if (!opened) return;
      opened = false;
      canvas.removeEventListener('wheel', wheel, { capture: true });
      canvas.removeEventListener('pointerdown', down);
      canvas.removeEventListener('pointermove', drag);
      canvas.removeEventListener('pointerup', up);
      canvas.removeEventListener('pointercancel', cancel);
      canvas.removeEventListener('mousedown', noAutoscroll);
      canvas.removeEventListener('pointermove', over);
      canvas.removeEventListener('pointerleave', away);
      overView('scene', false);
      nav.cancel();
      held = false;
      resized?.unobserve(canvas);
      // The game's own cameras again: its main one, or the fallback.
      if (game.viewOverride === view.perspective || game.viewOverride === view.orthographic) game.viewOverride = null;
    },
    reshape() {
      if (!opened) return;
      // Every measure of the room comes here: only a frame that moved reshapes and redraws.
      const f = game.frame;
      if (f.x === shaped.x && f.y === shaped.y && f.width === shaped.width && f.height === shaped.height) return;
      shape();
      moved();
    },
    hold(on) {
      held = on;
      if (on) nav.cancel();
    },
    grab(event, click) {
      if (held || !opened) return;
      nav.grab(event, navView, 'orbit', click);
      canvas.setPointerCapture?.(event.pointerId);
    },
    get object() {
      return view.camera;
    },
    get projection() {
      return view.projection;
    },
    setProjection(projection) {
      // Chosen: Auto Perspective leaves it be from now.
      autoOrtho = false;
      if (projection === view.projection) return;
      project(projection);
    },
    snapTo: (direction) => snapTo(direction),
    orbitBy(dx, dy) {
      view.orbit(dx, dy, 1, loadPrefs().nav.orbitSelection ? hooks.pivot?.() ?? null : null);
      autoBack();
      settle();
    },
    panBy(dx, dy) {
      view.pan(-dx, dy, 1);
      settle();
    },
    zoomBy(scale) {
      view.zoom(scale);
      settle();
    },
    walk(held) {
      if (opened) beginWalk(camera.walkTarget(), held);
    },
    arrowFly(held) {
      if (opened) arrowFly({ cam: view, moved: () => moved() }, held);
    },
    walkTarget: () => ({
      cam: view,
      element: canvas,
      cancel: () => nav.cancel(),
      perspective: () => {
        if (view.projection === 'orthographic') project('perspective');
      },
      // Put back on Esc: the pose and Auto Perspective's flag with it, so an orbit off the axis still swaps back.
      saved: () => {
        const pose = poseOf(view);
        const auto = autoOrtho;
        return () => {
          camera.setPose(pose);
          autoOrtho = auto;
        };
      },
      moved,
      ended: (kept) => {
        if (!kept) return;
        // Walked in perspective: what it keeps is no axis view's any more.
        autoOrtho = false;
        camera.setPose(poseOf(view));
      },
    }),
    lookFrom(direction) {
      view.lookFrom(direction);
      settle();
    },
    direction: (out) => view.direction(out),
    frame(bounds, part) {
      frameView(view, view.perspective.aspect, bounds, part);
      settle();
    },
    aim,
    lookAt() {
      return groundAhead(new THREE.Vector3());
    },
    groundAt(x, y, out) {
      const { origin, direction } = aim(x, y).ray;
      // Down to the ground, and not so far off that a step of the pointer is metres.
      if (direction.y > -1e-3) return null;
      const t = -origin.y / direction.y;
      if (!(t > 0 && t < GROUND)) return null;
      // On the ground: y is 0 to the bit, not the -2.2e-16 the ray's sum leaves -- written, that would be a value of its own.
      out.copy(origin).addScaledVector(direction, t);
      out.y = 0;
      return out;
    },
    sees(at) {
      view.camera.updateMatrixWorld();
      projected.copy(at).project(view.camera);
      return projected.z < 1 && Math.abs(projected.x) <= 1 && Math.abs(projected.y) <= 1;
    },
    get wheel() {
      return wheelMode;
    },
    setWheel(mode) {
      wheelMode = mode;
      keepPref('wheel', mode);
    },
    get trackpad() {
      return wheelMode === 'trackpad' || (wheelMode === 'auto' && nav.device === 'trackpad');
    },
    get pose() {
      return placed ? poseOf(view) : null;
    },
    view() {
      const c = view.camera;
      c.updateMatrixWorld();
      return {
        position: c.position.toArray(),
        quaternion: [c.quaternion.x, c.quaternion.y, c.quaternion.z, c.quaternion.w],
        target: view.target.toArray(),
        projection: view.projection,
        fov: view.perspective.fov,
        height: view.frustumHeight(),
      };
    },
    setPose(next) {
      placed = true;
      const was = view.camera;
      putPose(view, next);
      if (view.camera !== was) drawThrough();
      if (opened) settle();
    },
    dispose() {
      camera.close();
      resized?.disconnect();
    },
  };
  return camera;
}
