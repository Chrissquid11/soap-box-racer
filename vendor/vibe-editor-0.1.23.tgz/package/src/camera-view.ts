/**
 * Camera entities seen in the Scene view (Docs/camera.md §3, 8.3): an icon
 * and a camera shape where each is, the selected one's frustum, and a picture
 * in picture of what it sees.
 *
 * - **The icon** is a small camera glyph, a sprite facing the editor's view at
 *   one size on screen whatever the distance or the projection (scaled each
 *   frame from the editor's camera), drawn over the world. It is the editor's
 *   own, in its own group among the editor's objects -- never inside the
 *   engine's three camera, which a projection change hands to a project's
 *   `release` (`ViewOptions.release`) -- put where the camera's view is each
 *   frame (from its `matrixWorld`), hidden with it. Its `userData.entity` is
 *   the camera's, so a click picks the camera and the box takes it
 *   (`picking.ts`, `marquee.ts`: the viewport's `standIns`). In the scene only
 *   while the editor is open -- out as it closes and for a playtest -- and
 *   hidden for the preview with the rest of the editor's things: never in a
 *   draw through a game camera.
 * - **The camera shape**, Blender's: a pyramid from where each camera is to
 *   its image plane `DISPLAY_DEPTH` (1 m) in front, the rectangle at its
 *   viewport's aspect and its fov -- orthographic, the rectangle its size and
 *   the sides parallel -- and a triangle over the top edge for up, filled on
 *   the main camera and outlined on the rest (`camera-shape.ts`, the numbers).
 *   Fat lines (`pick-lines.ts`, `LINE_PX` wide: a one-pixel line is lost
 *   against the sand), in the editor's quiet colour over a wider light halo --
 *   read on sand, sky, a dark clear colour and from under the ground -- the
 *   accent for one selected; drawn over the world, under the gizmo (whose
 *   handles three orders last). One geometry a camera, built again only when
 *   its lens changes -- each frame only its matrix is the camera's. A stand-in
 *   as the icon is: a click within `LINE_PICK_PX` of a line, or on the main
 *   camera's filled triangle, picks the camera (an outlined triangle's fill
 *   takes no click); the box takes it when the shape's middle is inside. Only
 *   on the Scene page. Out for a `view_shot` through it (`hideThrough`).
 * - **The frustum** of the selected camera, near to far, in the accent but
 *   faint (`FRUSTUM_OPACITY`, thinner): a far of 200 m reaches across the view,
 *   and the shape is what says where the camera looks. Built again as its lens,
 *   near or far change. Never picked.
 * - **The preview**: while a camera is the one selected, what it sees, drawn
 *   through it into the bottom right of the scene's room -- above the Assets
 *   panel and the dock, never under the right card -- a quarter of the room's
 *   width at its viewport's aspect (`previewRect`), through `Game.onDrawWorld`
 *   after the cube, so the stopped frame keeps it. The editor's own things --
 *   the grid, the gizmo, the boxes, the icons, the frustum -- are not in it. A
 *   thin frame with its name over it, and × to hide it -- kept in the
 *   preferences (`cameraPreview`) -- and "Camera preview" to bring it back.
 *   Not on any page but the Scene tab's, nor in a playtest (the editor's
 *   scene is closed then).
 */
import * as THREE from 'three';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';
import { Camera, type Entity, label, NONE, View } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import type { EditorCamera } from './camera.ts';
import { cameraQuery, previewRect } from './camera-entity.ts';
import { button, el } from './dom.ts';
import { DISPLAY_DEPTH, frustumLines, type ShapeLens, pyramidLines, rectAt, sameLens, upTriangle } from './camera-shape.ts';
import { ACCENT, HALO, QUIET } from './overlays.ts';
import { pickLines, type PickLines } from './pick-lines.ts';
import { keepPref, loadPrefs } from './prefs.ts';
import type { Selection } from './selection.ts';
import { drawInto, drawWhole } from './view/draw-into.ts';
import type { PageBox, Rect } from './view/views.ts';

/** The icon's height on screen, in CSS pixels. */
const ICON_PX = 30;
/** The camera shape's lines, in CSS pixels; the frustum's, thinner. */
const LINE_PX = 1.75;
const FRUSTUM_PX = 1.25;
/** A camera not selected: its shape drawn in the quiet colour, a little see-through. */
const QUIET_OPACITY = 0.85;
/** Under every shape's lines, a light line this wide: the dark lines read over a dark sky or clear colour, or from under the ground. */
const HALO_PX = 4.5;
const HALO_OPACITY = 0.5;
/** The selected camera's whole frustum: faint, so a far plane far off does not swamp the view. */
const FRUSTUM_OPACITY = 0.35;

export interface CameraViewOptions {
  game: Game;
  /** The editor's own camera: what the icons face and are sized for. */
  camera: EditorCamera;
  selection: Selection;
  /** The editor's root: the preview's frame goes in it, placed in page pixels. */
  root: HTMLElement;
  /** The scene's room on the page, past the cards; null for none -- the whole canvas, or no room left (`roomless`). */
  room(): PageBox | null;
  /** Is `room` null for want of room, the cards up: then no preview, rather than one under a card. */
  roomless(): boolean;
  /** The editor's own things in the scene hidden while the preview is drawn, and back. */
  hideOurs(hidden: boolean): void;
  /** Something of it changed on screen: a frame to be drawn soon. */
  changed(): void;
}

export interface CameraView {
  /** In the scene while the editor is open: the selected camera's frustum, the icons' group, the camera shapes' group. */
  readonly objects: readonly THREE.Object3D[];
  /** The icons and the camera shapes, each with its camera's entity as `userData.entity`: what picking and the box take as the camera. */
  readonly standIns: readonly THREE.Object3D[];
  open(): void;
  close(): void;
  /** The Scene page is up: the preview and its frame shown, or neither. */
  setShown(shown: boolean): void;
  /** Before each frame: the icons onto every camera and sized, the frustum on the selected one. */
  update(): void;
  /**
   * The shape, the icon and the frustum of the camera looked through hidden for a moment, and back: a `view_shot`
   * through a camera entity, `e` (Blender hides the camera you look through); null, every camera's -- a shot through
   * the game's own cameras. The preview hides all of the editor's things itself.
   */
  hideThrough(e: Entity | null, hidden: boolean): void;
  /** Over the world, after the cube: the selected camera's preview. */
  draw(renderer: THREE.WebGLRenderer): void;
  /** The room may have moved: the frame with it. */
  relayout(): void;
  dispose(): void;
}

/** The camera glyph: a body and a lens, light with a dark edge, so it reads over sky and ground alike. */
function glyph(): THREE.CanvasTexture {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const g = canvas.getContext('2d')!;
  const shape = (): void => {
    g.beginPath();
    g.roundRect(8, 20, 34, 26, 5);
    g.moveTo(42, 29);
    g.lineTo(56, 21);
    g.lineTo(56, 45);
    g.lineTo(42, 37);
    g.closePath();
    g.moveTo(25 + 7, 14);
    g.arc(25, 14, 7, 0, Math.PI * 2);
  };
  g.lineJoin = 'round';
  g.lineWidth = 6;
  g.strokeStyle = 'rgba(0, 0, 0, 0.7)';
  shape();
  g.stroke();
  g.fillStyle = '#f2f2f4';
  shape();
  g.fill();
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

const isCamera = (o: THREE.Object3D | null | undefined): o is THREE.PerspectiveCamera | THREE.OrthographicCamera =>
  !!o && ((o as THREE.PerspectiveCamera).isPerspectiveCamera === true || (o as THREE.OrthographicCamera).isOrthographicCamera === true);

/** A three camera's aspect: its viewport's, as the engine set it. */
function aspectOf(o: THREE.PerspectiveCamera | THREE.OrthographicCamera): number {
  if ((o as THREE.PerspectiveCamera).isPerspectiveCamera) return (o as THREE.PerspectiveCamera).aspect;
  const c = o as THREE.OrthographicCamera;
  return (c.right - c.left) / Math.max(1e-9, c.top - c.bottom);
}

/** A camera's shape: its lines and its up triangle under one object that stands for it, and the lens they were built for. */
interface Shape {
  group: THREE.Group;
  lines: PickLines;
  /** A light line under the lines, wider: what shows the quiet colour against a dark sky or clear colour. */
  halo: PickLines;
  fill: THREE.Mesh;
  lens: ShapeLens;
}

/** The lens a three camera draws with, into `out`: its fov, or its half height through its zoom, and its viewport's aspect. */
function lensOf(o: THREE.PerspectiveCamera | THREE.OrthographicCamera, out: ShapeLens): ShapeLens {
  out.orthographic = (o as THREE.OrthographicCamera).isOrthographicCamera === true;
  out.fov = out.orthographic ? 0 : (o as THREE.PerspectiveCamera).fov;
  out.size = out.orthographic ? ((o as THREE.OrthographicCamera).top - (o as THREE.OrthographicCamera).bottom) / 2 / Math.max(1e-9, (o as THREE.OrthographicCamera).zoom) : 0;
  out.aspect = aspectOf(o);
  return out;
}

/** The up triangle's fill, picked only where it is drawn (the main camera's): an outlined one is the lines'. */
function fillRaycast(this: THREE.Mesh, raycaster: THREE.Raycaster, intersects: THREE.Intersection[]): void {
  if (this.visible) THREE.Mesh.prototype.raycast.call(this, raycaster, intersects);
}

/** `list[i]` out, the last swapped into its place: the order of the icons, the shapes and the stand-ins does not matter. */
function swapOut<T>(list: T[], i: number): void {
  list[i] = list[list.length - 1]!;
  list.pop();
}

/** `item` out of `list`, if it is in it. */
function drop<T>(list: T[], item: T): void {
  const i = list.indexOf(item);
  if (i >= 0) swapOut(list, i);
}

const lens = { orthographic: false, fov: 0, size: 0, aspect: 0 } satisfies ShapeLens;
const halves = [0, 0];
const at = new THREE.Vector3();
const eye = new THREE.Vector3();
const size = new THREE.Vector2();
const clearWas = new THREE.Color();

export function createCameraView({ game, camera, selection, root, room, roomless, hideOurs, changed }: CameraViewOptions): CameraView {
  const { world, scene } = game;
  const canvas = game.renderer.domElement;
  const texture = glyph();
  const plain = new THREE.SpriteMaterial({ map: texture, depthTest: false, depthWrite: false, transparent: true });
  const chosen = new THREE.SpriteMaterial({ map: texture, depthTest: false, depthWrite: false, transparent: true, color: new THREE.Color(ACCENT) });
  /** Each camera's icon, by entity, and the entities that have one, walked without an iterator. */
  const icons = new Map<Entity, THREE.Sprite>();
  const hung: Entity[] = [];
  /** Each `hang`'s number: an icon not marked with it has lost its camera. */
  let stamp = 0;
  /** Where the preview's frame was put, in page pixels: written again only where it moved. */
  const placed = { left: NaN, top: NaN, width: NaN, height: NaN };
  // Made now, outside any tick: each frame only walks it.
  cameraQuery(world);
  /** The selected camera's frustum: one set of lines, put on whichever camera is selected, built again as its numbers change. */
  const frustumMaterial = new LineMaterial({ color: ACCENT, linewidth: FRUSTUM_PX, transparent: true, opacity: FRUSTUM_OPACITY, depthTest: false, depthWrite: false });
  const frustumSet = pickLines(frustumMaterial, 994);
  frustumSet.pickable = false;
  frustumSet.name = 'editor: the selected camera\'s frustum';
  frustumSet.matrixAutoUpdate = false;
  frustumSet.visible = false;
  /** Its holder: what hiding the editor's things (the preview, `U`) hides, the frustum's own `visible` being the selection's. */
  const holder = new THREE.Group();
  holder.name = 'editor: the frustum\'s holder';
  holder.add(frustumSet);
  /** What the frustum was last built for: its lens, near and far. */
  const built = { lens: { orthographic: false, fov: NaN, size: NaN, aspect: NaN } as ShapeLens, near: NaN, far: NaN };
  /** The icons: the editor's own group, never a child of the engine's cameras. */
  const iconGroup = new THREE.Group();
  iconGroup.name = 'editor: camera icons';
  /** The camera shapes: the editor's own group too, each shape put where its camera is each frame. */
  const shapeGroup = new THREE.Group();
  shapeGroup.name = 'editor: camera shapes';
  const quietLine = new LineMaterial({ color: QUIET, linewidth: LINE_PX, transparent: true, opacity: QUIET_OPACITY, depthTest: false, depthWrite: false });
  // Every one see-through, the opaque ones too: all sort among the editor's other lines alike, by their order.
  const chosenLine = new LineMaterial({ color: ACCENT, linewidth: LINE_PX, transparent: true, depthTest: false, depthWrite: false });
  const haloLine = new LineMaterial({ color: HALO, linewidth: HALO_PX, transparent: true, opacity: HALO_OPACITY, depthTest: false, depthWrite: false });
  const quietFill = new THREE.MeshBasicMaterial({ color: QUIET, transparent: true, opacity: QUIET_OPACITY, side: THREE.DoubleSide, depthTest: false, depthWrite: false });
  const chosenFill = new THREE.MeshBasicMaterial({ color: ACCENT, transparent: true, side: THREE.DoubleSide, depthTest: false, depthWrite: false });
  /** What `hideThrough` hid, to show again. */
  const hiddenNow: THREE.Object3D[] = [];
  /** Each camera's shape, by entity. */
  const shapes = new Map<Entity, Shape>();
  /** The icons and the shapes, one array: what picking and the box are handed. */
  const standIns: THREE.Object3D[] = [];
  let opened = false;
  let shown = false;
  let previewOn = loadPrefs().cameraPreview;

  const frame = el('div', 'ed-cam-preview');
  frame.hidden = true;
  const name = el('span', 'ed-cam-preview-name');
  const hide = button('ui', '×', 'Hide the camera preview (kept hidden until shown again)', () => setPreview(false), 'ed-quiet ed-cam-preview-hide');
  frame.append(name, hide);
  const show = button('ui', 'Camera preview', 'Show what the selected camera sees, in the corner of the scene', () => setPreview(true), 'ed-small ed-cam-preview-show');
  show.hidden = true;
  root.append(frame, show);

  function setPreview(on: boolean): void {
    previewOn = on;
    keepPref('cameraPreview', on);
    place();
    changed();
  }

  /** The selected camera's entity and its three camera, or null: the first selected, if it is a camera with one. */
  function selected(): { e: Entity; object: THREE.PerspectiveCamera | THREE.OrthographicCamera } | null {
    const e = selection.primary;
    if (e === NONE || !world.alive(e) || !world.has(e, Camera) || !world.has(e, View)) return null;
    const object = world.store(View).value[e];
    return isCamera(object) ? { e, object } : null;
  }

  /** Where the preview goes, canvas-local -- and the canvas on the page -- or null for nowhere. */
  function rectFor(object: THREE.PerspectiveCamera | THREE.OrthographicCamera): { rect: Rect; page: DOMRect } | null {
    const page = canvas.getBoundingClientRect();
    const r = room();
    if (!r && roomless()) return null;
    const box: Rect = r ? { x: r.left - page.left, y: r.top - page.top, width: r.right - r.left, height: r.bottom - r.top } : { x: 0, y: 0, width: page.width, height: page.height };
    const rect = previewRect(box, aspectOf(object));
    return rect ? { rect, page } : null;
  }

  /** The frame and the show button where the preview is, or away. */
  function place(): void {
    const s = opened && shown ? selected() : null;
    const where = s ? rectFor(s.object) : null;
    frame.hidden = !(where && previewOn);
    show.hidden = !(where && !previewOn);
    if (!s || !where) return;
    const { rect, page } = where;
    if (previewOn) {
      const words = label(world, s.e);
      if (name.textContent !== words) name.textContent = words;
      // Written only where it moved: the numbers compared, no string made for a frame where nothing did.
      const left = page.left + rect.x;
      const top = page.top + rect.y;
      if (left !== placed.left) frame.style.left = `${(placed.left = left)}px`;
      if (top !== placed.top) frame.style.top = `${(placed.top = top)}px`;
      if (rect.width !== placed.width) frame.style.width = `${(placed.width = rect.width)}px`;
      if (rect.height !== placed.height) frame.style.height = `${(placed.height = rect.height)}px`;
    } else {
      const right = `${Math.max(0, window.innerWidth - (page.left + rect.x + rect.width))}px`;
      const bottom = `${Math.max(0, window.innerHeight - (page.top + rect.y + rect.height))}px`;
      if (show.style.right !== right) show.style.right = right;
      if (show.style.bottom !== bottom) show.style.bottom = bottom;
    }
  }

  /** Every camera's icon and shape hung on its view; one whose camera went, let go. Allocates nothing but a new camera's icon and shape, and a shape's lines built again. */
  function hang(): void {
    stamp++;
    const views = world.store(View).value;
    const eyeCam = camera.object;
    eyeCam.getWorldPosition(eye);
    // The view's height on the page: the game's frame's, which the editor's camera is drawn into.
    const height = Math.max(1, game.frame.height);
    const main = world.store(Camera).main;
    const q = cameraQuery(world);
    for (let n = 0; n < q.count; n++) {
      const e = q.members[n]! as Entity;
      if (!world.alive(e)) continue;
      const object = views[e];
      if (!isCamera(object)) continue;
      let icon = icons.get(e);
      if (!icon) {
        icon = new THREE.Sprite(plain);
        icon.name = 'editor: camera icon';
        icon.renderOrder = 996;
        icon.userData.entity = e;
        icons.set(e, icon);
        hung.push(e);
        iconGroup.add(icon);
        standIns.push(icon);
      }
      icon.userData.stamp = stamp;
      // Where the camera's view is, as `present` placed it; hidden with it.
      object.updateWorldMatrix(true, false);
      icon.position.setFromMatrixPosition(object.matrixWorld);
      icon.visible = object.visible;
      icon.material = selection.list.includes(e) ? chosen : plain;
      // One size on screen: as tall as ICON_PX of the canvas, at its distance in perspective, through the frustum in orthographic.
      at.copy(icon.position);
      const seen = (eyeCam as THREE.PerspectiveCamera).isPerspectiveCamera
        ? 2 * Math.max(0.01, at.distanceTo(eye)) * Math.tan(THREE.MathUtils.degToRad((eyeCam as THREE.PerspectiveCamera).fov) / 2)
        : ((eyeCam as THREE.OrthographicCamera).top - (eyeCam as THREE.OrthographicCamera).bottom) / (eyeCam as THREE.OrthographicCamera).zoom;
      icon.scale.setScalar((ICON_PX / height) * seen);
      shapeOn(e, object, icon.material === chosen, main[e] === 1);
    }
    // One whose camera went (or whose view is no camera now): let go, swapped out of the list.
    for (let i = hung.length - 1; i >= 0; i--) {
      const e = hung[i]!;
      const icon = icons.get(e)!;
      if (icon.userData.stamp === stamp) continue;
      letGo(e, icon);
      swapOut(hung, i);
    }
  }

  /** `e`'s shape made if it has none, built again if its lens changed, put where its camera is, in its colour. */
  function shapeOn(e: Entity, object: THREE.PerspectiveCamera | THREE.OrthographicCamera, isChosen: boolean, isMain: boolean): void {
    let shape = shapes.get(e);
    if (!shape) {
      const group = new THREE.Group();
      group.name = 'editor: camera shape';
      group.userData.entity = e;
      group.matrixAutoUpdate = false;
      const lines = pickLines(quietLine, 995);
      const halo = pickLines(haloLine, 993, lines.geometry);
      halo.pickable = false;
      const fill = new THREE.Mesh(new THREE.BufferGeometry(), quietFill);
      fill.renderOrder = 995;
      fill.frustumCulled = false;
      fill.raycast = fillRaycast;
      fill.geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(9), 3));
      group.add(halo, lines, fill);
      shape = { group, lines, halo, fill, lens: { orthographic: false, fov: NaN, size: NaN, aspect: NaN } };
      shapes.set(e, shape);
      shapeGroup.add(group);
      standIns.push(group);
    }
    lensOf(object, lens);
    if (!sameLens(lens, shape.lens)) {
      Object.assign(shape.lens, lens);
      // A new geometry for the new numbers: a lens changes seldom, and this hands the old buffers back.
      shape.lines.geometry.dispose();
      shape.lines.geometry = new LineSegmentsGeometry().setPositions(pyramidLines(lens));
      shape.halo.geometry = shape.lines.geometry;
      const [w, h] = rectAt(lens, DISPLAY_DEPTH, halves) as [number, number];
      const position = shape.fill.geometry.getAttribute('position') as THREE.BufferAttribute;
      (position.array as Float32Array).set(upTriangle(w, h, -DISPLAY_DEPTH));
      position.needsUpdate = true;
      shape.fill.geometry.computeBoundingSphere();
      shape.fill.geometry.computeBoundingBox();
    }
    shape.group.matrix.copy(object.matrixWorld);
    shape.group.matrixWorldNeedsUpdate = true;
    // Hidden with its camera; only on the Scene page.
    shape.group.visible = object.visible && shown;
    shape.lines.material = isChosen ? chosenLine : quietLine;
    shape.fill.material = isChosen ? chosenFill : quietFill;
    // The main camera's triangle filled, the rest's only outlined (the lines draw the outline).
    shape.fill.visible = isMain;
  }

  /** `e`'s icon and shape out of the scene and the stand-ins. */
  function letGo(e: Entity, icon: THREE.Sprite): void {
    icon.removeFromParent();
    icons.delete(e);
    drop(standIns, icon);
    const shape = shapes.get(e);
    if (shape) {
      shape.group.removeFromParent();
      shape.lines.geometry.dispose();
      shape.fill.geometry.dispose();
      shapes.delete(e);
      drop(standIns, shape.group);
    }
  }

  /** The selected camera's whole frustum on it, near to far: built again only as its numbers change. */
  function frustum(): void {
    const s = opened && shown ? selected() : null;
    frustumSet.visible = s !== null && s.object.visible;
    if (!s) return;
    const o = s.object;
    lensOf(o, lens);
    if (!sameLens(lens, built.lens) || built.near !== o.near || built.far !== o.far) {
      Object.assign(built.lens, lens);
      built.near = o.near;
      built.far = o.far;
      frustumSet.geometry.dispose();
      frustumSet.geometry = new LineSegmentsGeometry().setPositions(frustumLines(lens, o.near, o.far));
    }
    o.updateWorldMatrix(true, false);
    frustumSet.matrix.copy(o.matrixWorld);
    frustumSet.matrixWorldNeedsUpdate = true;
  }

  /** Every icon let go: the editor closed, a playtest. */
  function unhang(): void {
    for (let i = hung.length - 1; i >= 0; i--) letGo(hung[i]!, icons.get(hung[i]!)!);
    hung.length = 0;
  }

  return {
    objects: [holder, shapeGroup, iconGroup],
    standIns,
    open() {
      opened = true;
      changed();
    },
    close() {
      opened = false;
      unhang();
      frustum();
      place();
    },
    setShown(on) {
      if (on === shown) return;
      shown = on;
      frustum();
      place();
      changed();
    },
    update() {
      if (!opened) return;
      hang();
      frustum();
      place();
    },
    draw(renderer) {
      if (!opened || !shown || !previewOn) return;
      const s = selected();
      const where = s ? rectFor(s.object) : null;
      if (!s || !where) return;
      renderer.getSize(size);
      if (size.y <= 0) return;
      const background = scene.background;
      const autoClear = renderer.autoClear;
      renderer.getClearColor(clearWas);
      const alpha = renderer.getClearAlpha();
      const shadows = renderer.shadowMap.autoUpdate;
      const c = world.store(Camera);
      drawInto(renderer, where.rect, size.y);
      // Its own colour, or the scene's sky: as the game would clear its rect (a camera that clears nothing shows the sky here).
      if (c.clear[s.e] === 1) {
        scene.background = null;
        renderer.setClearColor(c.clearColor[s.e]!, 1);
      }
      renderer.autoClear = true;
      // The shadow maps are this frame's already.
      renderer.shadowMap.autoUpdate = false;
      hideOurs(true);
      try {
        renderer.render(scene, s.object);
      } finally {
        hideOurs(false);
        renderer.shadowMap.autoUpdate = shadows;
        renderer.autoClear = autoClear;
        renderer.setClearColor(clearWas, alpha);
        scene.background = background;
        drawWhole(renderer, size.x, size.y);
      }
    },
    hideThrough(e, hidden) {
      if (!hidden) {
        for (let i = 0; i < hiddenNow.length; i++) hiddenNow[i]!.visible = true;
        hiddenNow.length = 0;
        return;
      }
      const out = (o: THREE.Object3D | undefined): void => {
        if (!o?.visible) return;
        o.visible = false;
        hiddenNow.push(o);
      };
      for (let i = 0; i < hung.length; i++) {
        const c = hung[i]!;
        if (e !== null && c !== e) continue;
        out(icons.get(c));
        out(shapes.get(c)?.group);
      }
      if (e === null || selected()?.e === e) out(frustumSet);
    },
    relayout: () => place(),
    dispose() {
      unhang();
      frustumSet.geometry.dispose();
      frustumMaterial.dispose();
      quietLine.dispose();
      chosenLine.dispose();
      haloLine.dispose();
      quietFill.dispose();
      chosenFill.dispose();
      plain.dispose();
      chosen.dispose();
      texture.dispose();
      frame.remove();
      show.remove();
    },
  };
}
