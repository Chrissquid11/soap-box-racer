/**
 * Play shows the game (Docs/game-view.md §7): a playtest started or run on from a tab that covers the scene's room --
 * a page (`ToolInstance.page`: the Config tab, the Studio tab and every card of it, a project tool's page) or a scene
 * of its own (`ownScene`: the Model tab) -- goes to the Scene tab first, so the game is seen, docked or maximized as the
 * preference says; Claude's `play_start` as the person's F5. Stop goes back to the tab Play was pressed on, unless the
 * tab was changed at all during the playtest (a round trip too): then Stop leaves them where they are. Pause and Step
 * move nothing. The cards slid away (the key left of `1`) stay away: the game has the whole canvas, and the tab is
 * still changed under them, so they come back onto the scene.
 *
 * Pure: `editor.ts` hands over the tool's declared flags and runs what these say. Node tests them (`play-scene.test.ts`).
 */

/** The tab up as Play is pressed: its id, and whether it hides the scene's room. */
export interface PlayTab {
  /** The tab's id: a tool on the bar. */
  readonly tab: string;
  /** Its tool declares itself a page (`ToolInstance.page`): a card over the room -- Config, Studio and every card of it, a project tool's page. */
  readonly page: boolean;
  /** Its tool draws a scene of its own over the canvas (`ToolInstance.ownScene`): the Model tab's views. */
  readonly ownScene: boolean;
}

/** What `playTab` reads of a tool's instance: the two flags it declares (`tool.ts`). */
export interface TabFlags {
  readonly page?: boolean;
  readonly ownScene?: boolean;
}

/**
 * The tab `id` as Play sees it, from what its instance declares -- never from the page's elements: a tool opts in on
 * purpose. A Home of its own (`frameAll`) is no scene of its own: a tool framing its layer over the shared scene stays.
 */
export const playTab = (id: string, instance: TabFlags | undefined): PlayTab => ({
  tab: id, page: instance?.page === true, ownScene: instance?.ownScene === true,
});

/** Where Stop takes the person: back `from`, if the tab is still `to` -- the one Play went to. */
export interface PlayReturn {
  readonly from: string;
  readonly to: string;
}

/** Does the tab up hide the game: not the Scene tab, and a page or views of its own. A side card (Tiles) does not. */
export const coversScene = (at: PlayTab, scene: string): boolean => at.tab !== scene && (at.page || at.ownScene);

/** Play pressed with no playtest: the tab to go to first (null: stay), and where Stop comes back to. */
export function onStart(at: PlayTab, scene: string): { go: string | null; back: PlayReturn | null } {
  if (!coversScene(at, scene)) return { go: null, back: null };
  return { go: scene, back: { from: at.tab, to: scene } };
}

/**
 * Play pressed on a paused playtest: to the scene again if the tab up covers it. The way back kept only while the
 * person is still where Play put them: a tab changed during the pause is a move of their own, and Stop leaves it be.
 */
export function onResume(back: PlayReturn | null, at: PlayTab, scene: string): { go: string | null; back: PlayReturn | null } {
  const kept = back !== null && at.tab === back.to ? back : null;
  return { go: coversScene(at, scene) ? scene : null, back: kept };
}

/**
 * A tab changed by the person while a playtest runs or is paused: their own move, so Stop leaves them where they end
 * up -- even back on the scene after a round trip (Config, then Scene again). Play's own move to the scene is made
 * before the playtest begins, Stop's after it ends: neither comes here. Resume's does, while paused, and is undone at
 * once: the way back Resume decided (`onResume`) is set after its move.
 */
export const onTabChange = (back: PlayReturn | null, playing: boolean): PlayReturn | null => (playing ? null : back);

/** Stop: the tab to go back to, or null -- none kept, or the person moved since Play. */
export const onStop = (back: PlayReturn | null, tab: string): string | null => (back !== null && tab === back.to && back.from !== tab ? back.from : null);
