/**
 * The inspector's Add Component menu as data (Docs/ecs.md §3, "Where the menu lists it"): what may be added to the
 * entities shown, grouped by each component's `menu` path, and searched. Pure -- the engine's pure side and no DOM:
 * `component-menu.test.ts` tests it in node; `add-component.ts` draws it.
 *
 * - **What is offered** (`offered`): every component of the world but a relation (Link with…), a tag (the state line's),
 *   the world's own (`internal`), `View` (the engine's, from `Render`), the switches and labels (`STATE`), and one
 *   every one of the entities has already. Of several, one only some have is offered, to add to the rest.
 * - **Where each is** (`menuPath`): its `menu` split at `/` -- `Physics/Colliders` two levels -- or, with none,
 *   `Game` (`GAME`): a game's own. A project tool's components say `menu: 'Tools'` themselves; the token cannot tell.
 * - **The tree** (`menuTree`): a category a node, its sub-categories first, then its components, each by name.
 *   `Game` comes first at the top -- a game's own are what is added most -- then the rest by name.
 * - **A search** (`searchMenu`): the components whose name holds what is typed, any case, as one flat list --
 *   an exact name first, then a name it begins, then a word of the name it begins (`Collider` in `BoxCollider`),
 *   then anywhere; by name within each. Spaces in what is typed are ignored: `box coll` finds `BoxCollider`.
 */
import { type AnyComponent, type Entity, View, type World } from '@vibe/engine';
import { internal, STATE } from './blocks.ts';

/** Where a component that says no `menu` is listed: a game's own. */
export const GAME = 'Game';

/** A component as the menu lists it. */
export interface MenuEntry {
  readonly component: AnyComponent;
  readonly name: string;
  /** Its categories, outermost first: `['Physics', 'Colliders']`. */
  readonly path: readonly string[];
  /** Its row's hover: the component's `help`, or ''. */
  readonly help: string;
}

/** A category: its sub-categories, then its own components; `path` from the top (`[]` for the top itself). */
export interface MenuNode {
  readonly name: string;
  readonly path: readonly string[];
  readonly children: MenuNode[];
  readonly entries: MenuEntry[];
  /** Every component in it and under it: the count its row shows. */
  count: number;
}

/** `component`'s categories: its `menu` -- trimmed and its empty parts dropped by the engine (`menuOf`) -- split at `/`, or `[GAME]`. */
export function menuPath(component: AnyComponent): string[] {
  return component.menu ? component.menu.split('/') : [GAME];
}

/** May the adder offer `component` at all: no relation, tag, the world's own, View, switch or labels. */
export function addable(component: AnyComponent): boolean {
  return !(component.bit < 0 || component.kind === 'relation' || component.kind === 'tag' || internal(component) || component === View || STATE.includes(component));
}

/** What the adder offers `es`: every addable component of the world that not every one of them has, as entries. */
export function offered(world: World, es: readonly Entity[]): MenuEntry[] {
  const out: MenuEntry[] = [];
  for (const component of world.allComponents) {
    if (!addable(component)) continue;
    if (es.length > 0 && es.every((e) => world.has(e, component))) continue;
    out.push(entryOf(component));
  }
  return out;
}

/** One component as the menu lists it. */
export function entryOf(component: AnyComponent): MenuEntry {
  return { component, name: component.name, path: menuPath(component), help: component.help ?? '' };
}

const byName = (a: { name: string }, b: { name: string }): number => a.name.localeCompare(b.name);

/** The entries as a tree of categories (the module's header): the top node, `path` `[]`. */
export function menuTree(entries: readonly MenuEntry[]): MenuNode {
  const top: MenuNode = { name: '', path: [], children: [], entries: [], count: 0 };
  for (const entry of entries) {
    let at = top;
    at.count++;
    for (const part of entry.path) {
      let next = at.children.find((c) => c.name === part);
      if (!next) {
        next = { name: part, path: [...at.path, part], children: [], entries: [], count: 0 };
        at.children.push(next);
      }
      at = next;
      at.count++;
    }
    at.entries.push(entry);
  }
  const sort = (node: MenuNode, isTop: boolean): void => {
    node.children.sort((a, b) => (isTop && a.name === GAME ? -1 : isTop && b.name === GAME ? 1 : byName(a, b)));
    node.entries.sort(byName);
    for (const child of node.children) sort(child, false);
  };
  sort(top, true);
  return top;
}

/** The node at `path` under `top`, or null if there is none now (its last component added, say). */
export function nodeAt(top: MenuNode, path: readonly string[]): MenuNode | null {
  let at: MenuNode | undefined = top;
  for (const part of path) {
    at = at.children.find((c) => c.name === part);
    if (!at) return null;
  }
  return at;
}

/** How well `name` matches `typed` (lowercased, no spaces): 0 exact, 1 its start, 2 a word's start, 3 anywhere; -1 none. */
export function matchRank(name: string, typed: string): number {
  if (typed === '') return 3;
  const lower = name.toLowerCase();
  if (lower === typed) return 0;
  if (lower.startsWith(typed)) return 1;
  // A word of the name begins with it: after a capital (BoxCollider's Collider), a digit run, or `_`, `-`, space.
  for (let i = 1; i < name.length; i++) {
    const c = name[i]!;
    const prev = name[i - 1]!;
    const starts = (c >= 'A' && c <= 'Z' && !(prev >= 'A' && prev <= 'Z')) || /[_\- ]/.test(prev);
    if (starts && lower.startsWith(typed, i)) return 2;
  }
  return lower.includes(typed) ? 3 : -1;
}

/** What is typed as it is matched: lowercased, its spaces gone. */
export const searchText = (typed: string): string => typed.toLowerCase().replace(/\s+/g, '');

/** The entries whose name matches `typed`, best first (the module's header); every one for nothing typed, by name. */
export function searchMenu(entries: readonly MenuEntry[], typed: string): MenuEntry[] {
  const q = searchText(typed);
  const ranked: { entry: MenuEntry; rank: number }[] = [];
  for (const entry of entries) {
    const rank = matchRank(entry.name, q);
    if (rank >= 0) ranked.push({ entry, rank });
  }
  ranked.sort((a, b) => a.rank - b.rank || byName(a.entry, b.entry));
  return ranked.map((r) => r.entry);
}

/** A row the card shows: a category to open, or a component to add (its path shown beside it in a search). */
export type MenuRow =
  | { readonly kind: 'category'; readonly node: MenuNode }
  | { readonly kind: 'component'; readonly entry: MenuEntry };

/**
 * The rows the card shows: with something typed, the search's flat list; else the categories and components of the
 * node at `path` -- or of the top, if that node is gone.
 */
export function menuRows(top: MenuNode, path: readonly string[], typed: string, entries: readonly MenuEntry[]): MenuRow[] {
  if (searchText(typed) !== '') return searchMenu(entries, typed).map((entry) => ({ kind: 'component', entry }));
  const node = nodeAt(top, path) ?? top;
  return [...node.children.map((n) => ({ kind: 'category' as const, node: n })), ...node.entries.map((entry) => ({ kind: 'component' as const, entry }))];
}
