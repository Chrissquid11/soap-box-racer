/**
 * The game view's presets kept (Docs/game-view.md §4): the project's own and the one chosen, over the editor's
 * preferences (`prefs.ts`' `gameView`), as the play strip's dropdown, Config ▸ Editor ▸ Game view and the
 * `game_view_*` tools change them. Apart from `game-view.ts`, which `prefs.ts` reads its presets with.
 *
 * Pure but for the preferences' `localStorage`, forgiven where there is none: node tests it (`game-view.test.ts`).
 */
import { allPresets, FREE, presetFrom, presetNamed, PRESETS_MAX, type GamePreset, type PresetAsk } from './game-view.ts';
import { keepPref, loadPrefs } from './prefs.ts';

/** The project's presets and the one chosen, as the dropdown, Config ▸ Game view and the `game_view_*` tools change them. */
export interface GameViews {
  /** The preset chosen, or null: Free Aspect. */
  readonly preset: GamePreset | null;
  /** Its name: `FREE` for none. */
  readonly chosen: string;
  /** The project's own, in order. */
  readonly own: readonly GamePreset[];
  /** The preset of that name chosen (`FREE` for none): null, or why not -- no preset is called that. */
  choose(name: string): string | null;
  /**
   * A preset of the project's added -- or, `replacing` one of them by its name, changed in place: the preset, or why
   * not. A change of the one chosen keeps it chosen, under its new name.
   */
  put(ask: PresetAsk, replacing?: string | null): GamePreset | string;
  /** One of the project's taken out (chosen, Free Aspect then): null, or why not. */
  remove(name: string): string | null;
  /** One of the project's moved `by` places in the list, held at the ends. */
  move(name: string, by: number): void;
}

/**
 * The game view's presets over the editor's preferences (`gameView`, the project's): each change kept at once, then
 * `changed` told -- the editor shapes the frame anew and the dropdown says so.
 */
export function createGameViews(changed: () => void): GameViews {
  let { preset: chosen, presets: own } = loadPrefs().gameView;
  const keep = (): void => {
    keepPref('gameView', { preset: chosen, presets: own });
    changed();
  };
  const ownNamed = (name: string): number => own.findIndex((p) => p.name.toLowerCase() === name.trim().toLowerCase());
  return {
    get preset() {
      return presetNamed(own, chosen);
    },
    get chosen() {
      return chosen;
    },
    get own() {
      return own;
    },
    choose(name) {
      const low = name.trim().toLowerCase();
      if (low === FREE.toLowerCase()) chosen = FREE;
      else {
        const p = presetNamed(own, name);
        if (!p) return `no preset is called ${name}: ${[FREE, ...allPresets(own).map((x) => x.name)].join(', ')}`;
        chosen = p.name;
      }
      keep();
      return null;
    },
    put(ask, replacing = null) {
      const at = replacing === null ? -1 : ownNamed(replacing);
      if (replacing !== null && at < 0) return `no preset of the project's is called ${replacing}`;
      if (at < 0 && own.length >= PRESETS_MAX) return `a project keeps at most ${PRESETS_MAX} presets`;
      const was = at >= 0 ? own[at]!.name : null;
      const made = presetFrom(ask, own, was);
      if (typeof made === 'string') return made;
      own = at >= 0 ? own.map((p, i) => (i === at ? made : p)) : [...own, made];
      if (was !== null && chosen === was) chosen = made.name;
      keep();
      return made;
    },
    remove(name) {
      const at = ownNamed(name);
      if (at < 0) return `no preset of the project's is called ${name}`;
      if (own[at]!.name === chosen) chosen = FREE;
      own = own.filter((_, i) => i !== at);
      keep();
      return null;
    },
    move(name, by) {
      const at = ownNamed(name);
      if (at < 0) return;
      const to = Math.max(0, Math.min(own.length - 1, at + by));
      if (to === at) return;
      const next = [...own];
      const [one] = next.splice(at, 1);
      next.splice(to, 0, one!);
      own = next;
      keep();
    },
  };
}
