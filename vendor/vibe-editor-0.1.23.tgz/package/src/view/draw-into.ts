/**
 * Drawing into a part of the canvas over the world, through `Game.onDrawWorld`
 * (Docs/camera.md §3): the Scene view's cube (`scene-cube.ts`) and the selected
 * camera's preview (`camera-view.ts`). The viewport and the scissor are set for
 * a rect into whatever is bound -- the screen, or the kept frame's target,
 * whose own viewport three takes each time it binds it -- and put back whole.
 */
import type * as THREE from 'three';
import type { Rect } from './views.ts';

/** What is drawn next goes into `rect` (canvas-local CSS pixels, the canvas `height` tall), scissored -- into the target bound, if one is. */
export function drawInto(renderer: THREE.WebGLRenderer, rect: Rect, height: number): void {
  const target = renderer.getRenderTarget();
  const y = height - (rect.y + rect.height);
  if (target === null) {
    renderer.setViewport(rect.x, y, rect.width, rect.height);
    renderer.setScissor(rect.x, y, rect.width, rect.height);
    renderer.setScissorTest(true);
    return;
  }
  const ratio = renderer.getPixelRatio();
  target.viewport.set(Math.round(rect.x * ratio), Math.round(y * ratio), Math.round(rect.width * ratio), Math.round(rect.height * ratio));
  target.scissor.copy(target.viewport);
  target.scissorTest = true;
  renderer.setRenderTarget(target);
}

/** The whole canvas again (`width` × `height` CSS pixels), no scissor: as the game left it. */
export function drawWhole(renderer: THREE.WebGLRenderer, width: number, height: number): void {
  const target = renderer.getRenderTarget();
  if (target === null) {
    renderer.setViewport(0, 0, width, height);
    renderer.setScissor(0, 0, width, height);
    renderer.setScissorTest(false);
    return;
  }
  target.viewport.set(0, 0, target.width, target.height);
  target.scissor.copy(target.viewport);
  target.scissorTest = false;
  renderer.setRenderTarget(target);
}
