/**
 * Blender's walk, its numbers (Docs/navigation.md §4): where the camera looks
 * as a yaw round the world's up and a pitch above or below level, turned by
 * the mouse; a step from the keys held -- W and S along the look, A and D
 * across it, E and Q the world's up and down -- Shift four times as fast, Alt
 * a quarter; the wheel's speed; and the pivot put back in front at the end.
 * Pure: `walk.test.ts`. The driver, pointer lock and all, is `walker.ts`.
 */
import * as THREE from 'three';
import { pastSlop } from './navigation.ts';

/** Where the camera looks: `yaw` round the world's up (0 along +Z), `pitch` above level (radians). */
export interface Look {
  yaw: number;
  pitch: number;
}

/** Radians a pixel of the mouse turns the look. */
export const LOOK_SPEED = 0.003;
/** The pitch stops this short of straight up or down. */
const PITCH_MAX = Math.PI / 2 - 0.01;
/** Shift and Alt held: this many times faster, slower. */
export const FAST = 4;
export const SLOW = 0.25;
/** A notch of the wheel: the speed this many times up or down, held within `SPEED_MIN`..`SPEED_MAX` of where it began. */
export const SPEED_STEP = 1.25;
const SPEED_MIN = 1 / 64;
const SPEED_MAX = 64;

/** The look along `forward` (unit or not). */
export function lookOf(forward: THREE.Vector3): Look {
  const f = forward.clone().normalize();
  return { yaw: Math.atan2(f.x, f.z), pitch: THREE.MathUtils.clamp(Math.asin(THREE.MathUtils.clamp(f.y, -1, 1)), -PITCH_MAX, PITCH_MAX) };
}

/** The unit direction `look` looks along, into `out`. */
export function forwardOf(look: Look, out = new THREE.Vector3()): THREE.Vector3 {
  const c = Math.cos(look.pitch);
  return out.set(c * Math.sin(look.yaw), Math.sin(look.pitch), c * Math.cos(look.yaw));
}

/** The look turned by a mouse move of (`dx`, `dy`) pixels: right turns right, up looks up; never over the poles. */
export function turned(look: Look, dx: number, dy: number): Look {
  return { yaw: look.yaw - dx * LOOK_SPEED, pitch: THREE.MathUtils.clamp(look.pitch - dy * LOOK_SPEED, -PITCH_MAX, PITCH_MAX) };
}

/** The keys held, each way. */
export interface WalkKeys {
  forward: boolean;
  back: boolean;
  left: boolean;
  right: boolean;
  up: boolean;
  down: boolean;
  fast: boolean;
  slow: boolean;
}

const right = new THREE.Vector3();
const ahead = new THREE.Vector3();
const UP = new THREE.Vector3(0, 1, 0);

/**
 * The step for `dt` seconds at `speed` metres a second with `keys` held, into
 * `out`: along the look (pitch and all), across it, the world's up -- a
 * diagonal no faster than straight on; Shift `FAST`, Alt `SLOW`.
 */
export function stepOf(look: Look, keys: WalkKeys, speed: number, dt: number, out = new THREE.Vector3()): THREE.Vector3 {
  forwardOf(look, ahead);
  right.crossVectors(ahead, UP);
  if (right.lengthSq() < 1e-12) right.set(1, 0, 0);
  right.normalize();
  out.set(0, 0, 0)
    .addScaledVector(ahead, (keys.forward ? 1 : 0) - (keys.back ? 1 : 0))
    .addScaledVector(right, (keys.right ? 1 : 0) - (keys.left ? 1 : 0))
    .addScaledVector(UP, (keys.up ? 1 : 0) - (keys.down ? 1 : 0));
  if (out.lengthSq() === 0) return out;
  const boost = keys.fast ? FAST : keys.slow ? SLOW : 1;
  return out.normalize().multiplyScalar(speed * boost * dt);
}

/**
 * The right button held over a view (Docs/navigation.md §7, Unity's and Unreal's): `menu` while it may still be a
 * click -- let go there, the context menu as ever -- and `fly` once the pointer has moved past the editor's one click
 * slop from where it went down (`pastSlop`, as picking's and the stage's clicks; a fly key pressed flies too,
 * `walker.ts`' `flyKey`). Pure.
 */
export function rightPress(from: { x: number; y: number }, at: { x: number; y: number }): 'menu' | 'fly' {
  return pastSlop(at.x - from.x, at.y - from.y) ? 'fly' : 'menu';
}

/** A flight goes on only while its right button is down (`PointerEvent.buttons`' bit 2): found up, it ends where it is. */
export const flightHeld = (buttons: number): boolean => (buttons & 2) !== 0;

/**
 * Is a press's event swallowed by the walker: everything while a walk or a flight is under way; after it, only the
 * events of the button whose press ended it (`trailing`: its release, its click, a contextmenu) -- never a new press of
 * another, nor any after an end by a key (`trailing` null).
 */
export const swallowed = (underWay: boolean, trailing: number | null, button: number): boolean => underWay || (trailing !== null && button === trailing);

/** The wheel's speed: a notch up (`deltaY` under 0) faster by `SPEED_STEP`, down slower; `factor` the share of the speed it began at. */
export function speedAfter(factor: number, deltaY: number): number {
  if (deltaY === 0) return factor;
  return THREE.MathUtils.clamp(deltaY < 0 ? factor * SPEED_STEP : factor / SPEED_STEP, SPEED_MIN, SPEED_MAX);
}

/** A walk's speed to begin with, in metres a second: half the distance it looked from, so a step is the same share of what it saw. */
export const walkSpeed = (distance: number): number => Math.max(0.05, distance) * 0.5;

/**
 * The editor's keys of a walk (`editor.ts`), by name: the only editor keys live while it walks, while it flies with the
 * right button held, and while that button is held over a view and may yet fly.
 */
export const WALK_KEYS: ReadonlySet<string> = new Set(['walk forward', 'walk back', 'walk left', 'walk right', 'walk up', 'walk down', 'walk keep', 'walk put back']);

/** Is the editor key `name` live as far as a walk or a flight goes: always, but while one is under way (`walking`) only its own (`WALK_KEYS`). */
export const walkGate = (name: string, walking: boolean): boolean => !walking || WALK_KEYS.has(name);

/** Quiet this long after a walk ends, in milliseconds: the Esc the browser used to let go of the pointer may still come. */
export const QUIET = 400;

/** Whether a walk is under way -- or ended less than `QUIET` ago, which counts as one for the editor's keys. */
export class WalkClock {
  private on = false;
  private until = 0;
  begin(): void {
    this.on = true;
  }
  /**
   * Ended at `now` (`performance.now()`'s): quiet `QUIET` after -- but for a flight let go by its own button
   * (`quiet` false), where no Esc can follow and G R S, a second right-drag, are wanted at once.
   */
  end(now: number, quiet = true): void {
    this.on = false;
    this.until = quiet ? now + QUIET : 0;
  }
  /** Under way, or ended less than `QUIET` before `now`. */
  walking(now: number): boolean {
    return this.on || now < this.until;
  }
  /** Under way itself, the quiet after not counted. */
  get active(): boolean {
    return this.on;
  }
}
