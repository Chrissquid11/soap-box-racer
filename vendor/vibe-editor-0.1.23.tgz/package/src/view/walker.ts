/**
 * Blender's walk, the driver (Docs/navigation.md §4): one at a time, over the
 * Scene view's camera or a Model view's. Shift+` (or Shift+IntlBackslash)
 * begins it (`beginWalk`): the pointer locked on the view's canvas, the
 * mouse turning the look, W A S D E Q held moving (MrDebug's held keys, the
 * editor's walk actions), Shift faster, Alt slower, the wheel changing the
 * speed; a left click, Enter or Space keeps where it ended, a right click or
 * Esc puts the view back where it began -- and so does the pointer lock let go
 * by the browser (its own Esc). While it walks every other editor key rests
 * (`walking`, read by the editor's keys) and the views' own pointer and wheel
 * listeners hear nothing: this one's are on the window, capturing.
 *
 * The numbers are `walk.ts`'s. Perspective while it walks: an orthographic
 * view is swapped to perspective and back if put back.
 */
import * as THREE from 'three';
import { flightHeld, forwardOf, swallowed, lookOf, QUIET, rightPress, speedAfter, stepOf, turned, WalkClock, walkSpeed, type Look, type WalkKeys } from './walk.ts';
import type { ViewCamera } from './view-camera.ts';

/** What a walk asks of the view it walks in: its host's. */
export interface WalkTarget {
  cam: ViewCamera;
  /** The canvas the pointer is locked to. */
  element: HTMLElement;
  /** A drag under way in the view dropped first: the walk's window listeners take its release, which would never reach it. */
  cancel?(): void;
  /** The view in perspective (the host's own swap: the Scene tab draws through the other camera then). */
  perspective(): void;
  /** Where the view was as it began, to put back on Esc: the host's own record and putting back. */
  saved(): () => void;
  /** After each frame of it: the clip planes, a frame drawn. */
  moved(): void;
  /** It ended, kept or put back: the host's view settled (the Scene tab's floor for the new pose). */
  ended?(kept: boolean): void;
}

/** What the walk reads of the keys held: MrDebug's `held`. */
export type Held = (code: string) => boolean;

interface Walk {
  target: WalkTarget;
  look: Look;
  distance: number;
  speed: number;
  factor: number;
  restore: () => void;
  frame: number;
  at: number;
  held: Held;
  /** `walk` (Shift+`: a click or Enter keeps, Esc puts back) or `fly` (the right button held: let go, it ends where it is). */
  mode: 'walk' | 'fly';
  /** A flight's: the right button's pointer, captured on the view's canvas while it flies -- no pointer lock. */
  pointerId: number | null;
}

/** A right press over a view that may yet be a flight (`armFly`): where it went down, its view, the keys. */
interface Armed {
  target: WalkTarget;
  held: Held;
  x: number;
  y: number;
  pointerId: number;
}

let walk: Walk | null = null;
let armed: Armed | null = null;
/** Under way, and quiet a moment after it ends: the Esc the browser used to let go of the pointer may still come, and must reach nothing. */
const clock = new WalkClock();
/** How long the presses after a keeping click are swallowed: its pointerup, its click. */
const AFTER = QUIET;
const step = new THREE.Vector3();
const ahead = new THREE.Vector3();

/** Is a walk under way: every editor key but the walk's own rests. */
export const walking = (): boolean => clock.walking(performance.now());

const keysOf = (held: Held): WalkKeys => ({
  forward: held('KeyW'),
  back: held('KeyS'),
  left: held('KeyA'),
  right: held('KeyD'),
  up: held('KeyE'),
  down: held('KeyQ'),
  fast: held('ShiftLeft') || held('ShiftRight'),
  slow: held('AltLeft') || held('AltRight'),
});

/** `cam` placed for `look` -- upright, as Blender's walk, from an upside-down view too -- the pivot `distance` ahead. */
export function placeWalk(cam: ViewCamera, look: Look, distance: number): void {
  const camera = cam.camera;
  forwardOf(look, ahead);
  cam.target.copy(camera.position).addScaledVector(ahead, distance);
  camera.up.set(0, 1, 0);
  camera.lookAt(cam.target);
  cam.clip();
}

/** The camera placed for the look, the pivot a little ahead while it walks. */
function place(w: Walk): void {
  placeWalk(w.target.cam, w.look, w.distance);
  w.target.moved();
}

function frame(now: number): void {
  const w = walk;
  if (!w) return;
  const dt = Math.min(0.1, Math.max(0, (now - w.at) / 1000));
  w.at = now;
  stepOf(w.look, keysOf(w.held), w.speed * w.factor, dt, step);
  if (step.lengthSq() > 0) {
    w.target.cam.camera.position.add(step);
    place(w);
  }
  w.frame = requestAnimationFrame(frame);
}

/** The look, from the pointer's own moves (`pointermove`: a press whose default a host prevented sends no mouse events). */
const onMove = (event: PointerEvent): void => {
  if (!walk) return;
  // A flight whose right button is found up -- let go outside the window, its release lost: over where it is, this move
  // the page's own again.
  if (walk.mode === 'fly' && !flightHeld(event.buttons)) return endWalk(true, false);
  event.stopPropagation();
  walk.look = turned(walk.look, event.movementX, event.movementY);
  place(walk);
};
const onDown = (event: PointerEvent): void => {
  if (!walk) return;
  // Flying with its right button found up (its release lost outside the window): the flight over where it is, and this
  // press -- a tab, a row -- the person's own, not swallowed.
  if (walk.mode === 'fly' && !flightHeld(event.buttons)) return endWalk(true, false);
  event.preventDefault();
  event.stopPropagation();
  // Flying, the right button is still down: no other press ends it.
  if (walk.mode === 'fly') return;
  if (event.button === 0) endWalk(true, true, 0);
  else if (event.button === 2) endWalk(false, true, 2);
};
/** Flying: the right button let go, the flight over where it is. */
const onUp = (event: PointerEvent): void => {
  if (walk?.mode === 'fly' && event.button === 2) endWalk(true, false, 2);
};
/** The window left while flying: the flight over where it is (its button's release will not come here). */
const onBlur = (): void => {
  if (walk?.mode === 'fly') endWalk(true, false);
};
/** The canvas's capture of the flight's pointer lost (the browser or a host let it go) while the button is held: over where it is, as a blur. */
const onLostCapture = (event: PointerEvent): void => {
  if (walk?.mode === 'fly' && event.pointerId === walk.pointerId) endWalk(true, false);
};

/**
 * A flight ended before its right button came up (Esc, Enter, Space, the pointer lock lost): that button's release,
 * whenever it comes, is the flight's -- swallowed, so picking or the stage never takes it for a click and opens the
 * menu (on a Mac the contextmenu came with the press, which the editor refuses; elsewhere with the release, refused
 * as ever).
 */
let rightGuard = false;
const guardUp = (event: PointerEvent): void => {
  if (event.button !== 2) return;
  event.preventDefault();
  event.stopPropagation();
  rightGuard = false;
  window.removeEventListener('pointerup', guardUp, true);
};
function guardRight(): void {
  if (rightGuard) return;
  rightGuard = true;
  window.addEventListener('pointerup', guardUp, true);
}
/**
 * The button whose press ended the walk -- a keeping left click, a putting-back right click, a flight's right button let
 * go -- or null for a key: after the end only that button's trailing events (its release, its click, a contextmenu)
 * are swallowed, never a new press of another (a click on a tab just after a flight).
 */
let trailing: number | null = null;
/** The clicks and the menu that follow a press: none of them anyone else's while it walks -- after, only the ending button's. */
const swallow = (event: Event): void => {
  if (!swallowed(walk !== null, trailing, (event as MouseEvent).button)) return;
  event.preventDefault();
  event.stopPropagation();
};
const onWheel = (event: WheelEvent): void => {
  if (!walk) return;
  event.preventDefault();
  event.stopPropagation();
  walk.factor = speedAfter(walk.factor, event.deltaY);
};
/** The browser let go of the pointer (its own Esc, the window left): put back, as Esc -- a flight ends where it is. */
const onLock = (): void => {
  if (walk && document.pointerLockElement !== walk.target.element) endWalk(false);
};

// ---------------------------------------------------------------- the right button's flight (Docs/navigation.md §7)

/** Is a right press over a view held that may yet fly: the fly keys are its, every other editor key rests. */
export const flyArmed = (): boolean => armed !== null;

/**
 * A right press over `target`'s view (what the rule calls the menu): armed -- the pointer moved past `FLY_SLOP`, or a
 * fly key pressed while it is held, and it flies (`rightPress`); let go first, nothing here, the host's menu as ever.
 */
export function armFly(target: WalkTarget, held: Held, event: { clientX: number; clientY: number; pointerId: number }): void {
  // Not while one is under way; the quiet after one is no reason to refuse (a second right-drag at once).
  if (clock.active) return;
  disarm();
  armed = { target, held, x: event.clientX, y: event.clientY, pointerId: event.pointerId };
  window.addEventListener('pointermove', armedMove, true);
  window.addEventListener('pointerup', armedUp, true);
  window.addEventListener('blur', disarm);
}

/** A fly key went down: a right press armed over a view flies now. */
export function flyKey(): void {
  if (armed) beginWalk(armed.target, armed.held, 'fly', armed.pointerId);
}

const armedMove = (event: PointerEvent): void => {
  if (!armed) return;
  if (!flightHeld(event.buttons)) return disarm();
  if (rightPress(armed, { x: event.clientX, y: event.clientY }) === 'fly') beginWalk(armed.target, armed.held, 'fly', armed.pointerId);
};
/** Let go before it flew: a click -- the host's menu hears it as ever. */
const armedUp = (event: PointerEvent): void => {
  if (event.button === 2) disarm();
};

function disarm(): void {
  if (!armed) return;
  armed = null;
  window.removeEventListener('pointermove', armedMove, true);
  window.removeEventListener('pointerup', armedUp, true);
  window.removeEventListener('blur', disarm);
}

// ---------------------------------------------------------------- the arrow keys' flight

/** What the arrows fly: a view's camera, and what follows a step. */
export interface ArrowTarget {
  cam: ViewCamera;
  moved(): void;
}

let arrowing: { target: ArrowTarget; held: Held; frame: number; at: number } | null = null;

/** -1, 0 or 1: `plus` held less `minus` held. */
const way = (held: Held, plus: string, minus: string): number => (held(plus) ? 1 : 0) - (held(minus) ? 1 : 0);

function arrowFrame(now: number): void {
  const a = arrowing;
  if (!a) return;
  const ahead = way(a.held, 'ArrowUp', 'ArrowDown');
  const side = way(a.held, 'ArrowRight', 'ArrowLeft');
  if (ahead === 0 && side === 0) {
    arrowing = null;
    return;
  }
  const dt = Math.min(0.1, Math.max(0, (now - a.at) / 1000));
  a.at = now;
  // The view's own flight, the Model tab's held W A S D's (`ViewCamera.fly`): its speed, its own right upside down too,
  // the pivot with it, and in orthographic ↑ ↓ zoom -- Shift four times as fast.
  const cam = a.target.cam;
  cam.fly(ahead, side, 0, dt, a.held('ShiftLeft') || a.held('ShiftRight') ? 4 : 1);
  cam.clip();
  a.target.moved();
  a.frame = requestAnimationFrame(arrowFrame);
}

/** An arrow key went down over a view: it flies while any arrow is held (`held`, MrDebug's), ↑ ↓ along the look, ← → across. */
export function arrowFly(target: ArrowTarget, held: Held): void {
  if (arrowing) {
    arrowing.target = target;
    return;
  }
  arrowing = { target, held, frame: 0, at: performance.now() };
  arrowing.frame = requestAnimationFrame(arrowFrame);
}

/** A walk begun in `target`'s view, `held` the keys down now -- or, `fly`, a flight with the right button held. One at a time: a second is nothing. */
export function beginWalk(target: WalkTarget, held: Held, mode: 'walk' | 'fly' = 'walk', pointerId: number | null = null): void {
  if (clock.active) return;
  disarm();
  target.cancel?.();
  const restore = target.saved();
  target.perspective();
  const cam = target.cam;
  const forward = cam.direction(new THREE.Vector3()).negate();
  const distance = Math.max(cam.distance, 1e-3);
  clock.begin();
  walk = { target, look: lookOf(forward), distance, speed: walkSpeed(distance), factor: 1, restore, frame: 0, at: performance.now(), held, mode, pointerId: mode === 'fly' ? pointerId : null };
  place(walk);
  window.addEventListener('pointermove', onMove, true);
  window.addEventListener('pointerdown', onDown, true);
  window.addEventListener('pointerup', onUp, true);
  for (const type of ['pointerup', 'mousedown', 'mouseup', 'click', 'auxclick', 'contextmenu'] as const) window.addEventListener(type, swallow, true);
  window.addEventListener('wheel', onWheel, { capture: true, passive: false });
  window.addEventListener('blur', onBlur);
  if (mode === 'fly') {
    // A flight never locks the pointer (Docs/navigation.md §7, at the user's ask): no browser bubble "press Esc to show
    // your cursor". The right button's pointer is captured on the canvas instead, so the look goes on past its edge and
    // outside the window while the button is held, and the cursor -- left visible -- is where it is when it is let go.
    if (pointerId !== null) {
      try {
        target.element.setPointerCapture?.(pointerId);
        target.element.addEventListener('lostpointercapture', onLostCapture as EventListener);
      } catch {
        // Not a live pointer (a test's): the window's own listeners still read the moves over the page.
      }
    }
  } else {
    // Walk keeps Blender's lock: no button is held to capture with, and the cursor would run into the screen's edges.
    document.addEventListener('pointerlockchange', onLock);
    // Asked for in the key's own task, a user's gesture; refused (a test's browser, a frame), the walk goes on unlocked.
    try {
      const asked = target.element.requestPointerLock?.() as unknown;
      if (asked instanceof Promise) asked.catch(() => {});
    } catch {
      // Unlocked: the mouse still turns the look while it moves over the page.
    }
  }
  walk.frame = requestAnimationFrame(frame);
}

/**
 * The walk ended: `keep`, where it is, the pivot in front at the distance it had; else the view put back where it
 * began. A flight is always kept. `quiet` false: no quiet after -- a flight let go by its own button (or found up, the
 * window left), where no Esc can follow. `by`: the button whose press ended it (`trailing`), null for a key.
 */
export function endWalk(keep: boolean, quiet = true, by: number | null = null): void {
  const w = walk;
  if (!w) return;
  trailing = by;
  if (w.mode === 'fly') {
    keep = true;
    // Ended with its button still down (Esc, Enter, Space, the lock lost): that button's release is the flight's.
    if (quiet) guardRight();
  }
  walk = null;
  clock.end(performance.now(), quiet);
  cancelAnimationFrame(w.frame);
  window.removeEventListener('pointermove', onMove, true);
  window.removeEventListener('pointerdown', onDown, true);
  window.removeEventListener('pointerup', onUp, true);
  for (const type of ['pointerup', 'mousedown', 'mouseup', 'click', 'auxclick', 'contextmenu'] as const) {
    // The release and the click that follow an ending press still come: swallowed a moment longer.
    setTimeout(() => {
      // A walk begun meanwhile swallows them still.
      if (!walk) window.removeEventListener(type, swallow, true);
    }, AFTER);
  }
  window.removeEventListener('wheel', onWheel, true);
  window.removeEventListener('blur', onBlur);
  document.removeEventListener('pointerlockchange', onLock);
  if (document.pointerLockElement === w.target.element) document.exitPointerLock?.();
  w.target.element.removeEventListener('lostpointercapture', onLostCapture as EventListener);
  if (w.pointerId !== null && w.target.element.hasPointerCapture?.(w.pointerId)) w.target.element.releasePointerCapture(w.pointerId);
  if (keep) place(w);
  else w.restore();
  w.target.ended?.(keep);
}
