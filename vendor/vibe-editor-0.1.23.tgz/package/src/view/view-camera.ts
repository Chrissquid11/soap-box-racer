/**
 * One view's camera -- each of the Model tab's views', and the Scene tab's
 * (Docs/modeler.md M7, M9, M15; Docs/camera.md §3): both
 * projections at once (Vibe3D D20), a turntable round a target, pan, zoom to
 * a point, framing and the clip planes -- three.js maths, no DOM, so a node
 * test drives it (`view-camera.test.ts`).
 *
 * - **Two cameras, one viewpoint**: a perspective and an orthographic camera
 *   kept side by side; a swap copies where it is and sizes the incoming
 *   frustum so what is seen stays the same size -- never a teleport.
 * - **The target is the pivot**: orbit swings the camera round it as Blender's
 *   turntable does -- about the world's Y by the horizontal, about the view's
 *   own right by the vertical, with no limit: over the top and upside down, the
 *   camera's up carried with the turn (`camera.up` is always the view's own up,
 *   so a `lookAt` never flips it). Pan moves both along the view's own right and up; zoom
 *   scales both toward a point -- the one under the pointer -- so that point
 *   stays put (in orthographic the frustum narrows instead).
 * - **Framing keeps the direction** (D23's fix): re-centre and re-zoom, never
 *   re-aim; a camera never placed looks from three-quarter above.
 * - **The clip planes from what there is**: far past the model and the grid's
 *   corners from where the camera is (D78, D102's lesson), near a share of it.
 */
import * as THREE from 'three';
import { DIRECTIONS, presetOf, type Preset, type Projection, type Vec3 } from './views.ts';

/** The perspective camera's vertical field of view, in degrees. */
export const FOV = 45;
/** Framing leaves this much room round what it frames. */
export const MARGIN = 1.15;
/** How near and how far a zoom goes, as shares of the model's radius. */
const NEAREST = 0.01;
const FARTHEST = 200;

const offset = new THREE.Vector3();
const WORLD_UP = new THREE.Vector3(0, 1, 0);
const yaw = new THREE.Quaternion();
const pitch = new THREE.Quaternion();
const right = new THREE.Vector3();
const up = new THREE.Vector3();
const forward = new THREE.Vector3();
const scratch = new THREE.Vector3();
const move = new THREE.Vector3();
const rotation = new THREE.Quaternion();

/** The horizontal turn's way for a view whose up is `up` as a gesture begins: -1 upside down, Blender's `reverse`. */
export const reverseOf = (up: THREE.Vector3): 1 | -1 => (up.y < 0 ? -1 : 1);

/**
 * The turn a drag of (`dx`, `dy`) pixels on a view `height` tall makes, Blender's turntable: a whole turn about the
 * world's up for a drag the view's height across, and about the view's own right (`viewRight`, unit) for one up or
 * down -- no limit, so a vertical drag goes on over the top. `reverse` -1 for a view upside down as the gesture began
 * (`reverseOf`): the horizontal turn the other way, so the scene still follows the pointer. Into `out`. Pure three:
 * node-tested.
 */
export function turnOf(dx: number, dy: number, height: number, viewRight: THREE.Vector3, out = new THREE.Quaternion(), reverse = 1): THREE.Quaternion {
  const h = Math.max(height, 1);
  // Upside down (`reverse` -1), the turn about the world's up goes the other way, so the scene still follows the pointer (Blender's).
  yaw.setFromAxisAngle(WORLD_UP, (-2 * Math.PI * dx * reverse) / h);
  pitch.setFromAxisAngle(viewRight, (-2 * Math.PI * dy) / h);
  return out.multiplyQuaternions(yaw, pitch);
}

/** A view's camera as plain values, kept across a reload (the resume record, Docs/modeler.md M18). */
export interface ViewPose {
  position: [number, number, number];
  target: [number, number, number];
  projection: Projection;
  /** The orthographic camera's zoom, and its frustum's height before it. */
  zoom: number;
  height: number;
  /** The view's own up -- upside down after an orbit over the top; Y when left out (a pose kept before). */
  up?: [number, number, number];
}

const triple = (v: unknown): v is [number, number, number] => Array.isArray(v) && v.length === 3 && v.every((n) => typeof n === 'number' && Number.isFinite(n));
const positive = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v) && v > 0;

/** Poses as kept, read: each checked, null for anything odd -- a view then framed as if new. */
export function readPoses(value: unknown): (ViewPose | null)[] {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 4).map((v) => {
    const p = (typeof v === 'object' && v !== null ? v : {}) as Record<string, unknown>;
    if (!triple(p.position) || !triple(p.target) || (p.projection !== 'perspective' && p.projection !== 'orthographic') || !positive(p.zoom) || !positive(p.height)) return null;
    const pose: ViewPose = { position: p.position, target: p.target, projection: p.projection, zoom: p.zoom, height: p.height };
    if (triple(p.up) && Math.hypot(...p.up) > 1e-6) pose.up = p.up;
    return pose;
  });
}

export class ViewCamera {
  readonly perspective = new THREE.PerspectiveCamera(FOV, 1, 0.01, 1000);
  readonly orthographic = new THREE.OrthographicCamera(-1, 1, 1, -1, -1000, 1000);
  /** What it turns round: the middle of what it looks at. */
  readonly target = new THREE.Vector3();
  /** The model's radius, from the last framing or rescale: what the zoom's limits and the clip planes are measured against. */
  radius = 1;
  /** How far the grid reaches, centre to corner: the far plane clears it too. */
  reach = 1;
  /** The model's middle: the far plane is measured to it from wherever the camera is (flying, D102). */
  readonly centre = new THREE.Vector3();
  private mode: Projection = 'perspective';
  private aspect = 1;
  /** Has it ever been placed: framing keeps the direction of one that has. */
  placed = false;
  /** Bounds of its own on a zoom, besides the model's radius: the Scene tab's metres, the orthographic zoom's reach. */
  minDistance = 0;
  maxDistance = Infinity;
  minZoom = 1e-3;
  maxZoom = 1e5;

  constructor(projection: Projection = 'perspective') {
    this.perspective.position.set(...DIRECTIONS.free).normalize().multiplyScalar(4);
    this.perspective.lookAt(this.target);
    this.orthographic.position.copy(this.perspective.position);
    this.orthographic.lookAt(this.target);
    if (projection === 'orthographic') this.setProjection('orthographic');
  }

  /** The camera drawn with just now. */
  get camera(): THREE.PerspectiveCamera | THREE.OrthographicCamera {
    return this.mode === 'perspective' ? this.perspective : this.orthographic;
  }

  get projection(): Projection {
    return this.mode;
  }

  /** From the target toward the camera, unit length. */
  direction(out = new THREE.Vector3()): THREE.Vector3 {
    out.copy(this.camera.position).sub(this.target);
    return out.lengthSq() < 1e-18 ? out.set(0, 0, 1) : out.normalize();
  }

  /** Where it looks from, as a name: `front` within ~2.5° of the axis, else `free` (D22). */
  get preset(): Preset {
    const d = this.direction(scratch);
    return presetOf([d.x, d.y, d.z]);
  }

  get distance(): number {
    return this.camera.position.distanceTo(this.target);
  }

  /** The world's height seen at the target: what a pixel of pan is worth, and what a projection swap keeps. */
  frustumHeight(distance = this.distance): number {
    if (this.mode === 'orthographic') return (this.orthographic.top - this.orthographic.bottom) / this.orthographic.zoom;
    return 2 * distance * Math.tan(THREE.MathUtils.degToRad(this.perspective.fov) / 2);
  }

  /** The view's shape, width over height: both cameras follow it. */
  setAspect(aspect: number): void {
    this.aspect = Number.isFinite(aspect) && aspect > 0 ? aspect : 1;
    this.perspective.aspect = this.aspect;
    this.perspective.updateProjectionMatrix();
    const half = (this.orthographic.top - this.orthographic.bottom) / 2;
    this.orthographic.left = -half * this.aspect;
    this.orthographic.right = half * this.aspect;
    this.orthographic.updateProjectionMatrix();
  }

  /** The other projection, seeing what this one sees at the target the same size (D20). */
  setProjection(mode: Projection): void {
    if (mode === this.mode) return;
    const height = this.frustumHeight();
    const from = this.camera;
    const dir = this.direction(new THREE.Vector3());
    this.mode = mode;
    if (mode === 'orthographic') {
      this.orthographic.position.copy(from.position);
      this.sizeOrthographic(height);
    } else {
      // As far back as a perspective frustum shows that height at the target.
      const d = height / 2 / Math.tan(THREE.MathUtils.degToRad(this.perspective.fov) / 2);
      this.perspective.position.copy(this.target).addScaledVector(dir, d);
    }
    // Turned as the one it takes over from, upside down or not.
    this.camera.quaternion.copy(from.quaternion);
    this.camera.up.copy(from.up);
    this.clip();
  }

  toggleProjection(): void {
    this.setProjection(this.mode === 'perspective' ? 'orthographic' : 'perspective');
  }

  /** The orthographic frustum `height` world units tall, its zoom 1: framing done by hand (the Scene tab's). */
  fitHeight(height: number): void {
    this.sizeOrthographic(height);
  }

  /** The orthographic frustum `height` world units tall. */
  private sizeOrthographic(height: number): void {
    const half = Math.max(height, 1e-6) / 2;
    this.orthographic.top = half;
    this.orthographic.bottom = -half;
    this.orthographic.left = -half * this.aspect;
    this.orthographic.right = half * this.aspect;
    this.orthographic.zoom = 1;
    this.orthographic.updateProjectionMatrix();
  }

  /**
   * Round the target, as a drag of (`dx`, `dy`) pixels on a view `height` tall
   * turns it (`turnOf`): about the world's up and the view's own right, with
   * no limit -- over the top the view goes upside down, its up turned with it,
   * nothing flipping at a pole. With `pivot` (Orbit Around Selection), round
   * that point instead: the camera and the target turned round it together.
   * `reverse`: the horizontal turn's way, taken as the gesture began
   * (`reverseOf` its up then) -- per call unless a drag hands its own in.
   */
  orbit(dx: number, dy: number, height: number, pivot?: THREE.Vector3 | null, reverse: 1 | -1 = reverseOf(this.camera.up)): void {
    const camera = this.camera;
    turnOf(dx, dy, height, right.set(1, 0, 0).applyQuaternion(camera.quaternion).normalize(), rotation, reverse);
    const about = pivot ?? this.target;
    camera.position.sub(about).applyQuaternion(rotation).add(about);
    if (pivot) this.target.sub(pivot).applyQuaternion(rotation).add(pivot);
    // Kept unit: a turn a step, thousands of them, never drift the distance or skew the view.
    camera.quaternion.premultiply(rotation).normalize();
    camera.up.copy(WORLD_UP).applyQuaternion(camera.quaternion);
    this.placed = true;
  }

  /** The view's own right and up, for a pan -- upside down too. */
  private axes(): void {
    this.direction(forward).negate();
    right.set(1, 0, 0).applyQuaternion(this.camera.quaternion);
    up.set(0, 1, 0).applyQuaternion(this.camera.quaternion);
  }

  /** Across the view, as a drag of (`dx`, `dy`) pixels on a view `height` tall moves what is under the pointer. */
  pan(dx: number, dy: number, height: number): void {
    const perPixel = this.frustumHeight() / Math.max(height, 1);
    this.axes();
    scratch.copy(right).multiplyScalar(-dx * perPixel).addScaledVector(up, dy * perPixel);
    this.target.add(scratch);
    this.camera.position.add(scratch);
    this.placed = true;
  }

  /**
   * Nearer (`scale` < 1) or further, toward the point under the pointer -- at
   * (`ndcX`, `ndcY`), -1 to 1 across the view -- on the plane through the
   * target: that point stays where it is on screen. Held within what the
   * model's radius allows.
   */
  zoom(scale: number, ndcX = 0, ndcY = 0): void {
    if (!(scale > 0) || !Number.isFinite(scale)) return;
    const camera = this.camera;
    let s = scale;
    if (this.mode === 'perspective') {
      const d = this.distance;
      const next = THREE.MathUtils.clamp(d * s, Math.max(this.radius * NEAREST, this.minDistance), Math.min((this.radius + this.reach) * FARTHEST, this.maxDistance));
      s = d > 0 ? next / d : 1;
    } else {
      const zoom = THREE.MathUtils.clamp(this.orthographic.zoom / s, this.minZoom, this.maxZoom);
      s = this.orthographic.zoom / zoom;
    }
    if (s === 1) return;
    // The point under the pointer on the plane through the target, square to the view.
    const half = this.frustumHeight() / 2;
    this.axes();
    const point = scratch.copy(this.target).addScaledVector(right, ndcX * half * this.aspect).addScaledVector(up, ndcY * half);
    const shift = offset.copy(this.target).sub(point).multiplyScalar(s).add(point).sub(this.target);
    if (this.mode === 'perspective') {
      camera.position.sub(point).multiplyScalar(s).add(point);
      this.target.add(shift);
    } else {
      this.target.add(shift);
      camera.position.add(shift);
      this.orthographic.zoom /= s;
      this.orthographic.updateProjectionMatrix();
    }
    camera.lookAt(this.target);
    this.placed = true;
  }

  /** The target moved to `point`, the camera with it: the same look, the same distance, centred there (Alt+middle click). */
  centreOn(point: THREE.Vector3): void {
    scratch.copy(point).sub(this.target);
    this.target.add(scratch);
    this.camera.position.add(scratch);
    this.camera.lookAt(this.target);
    this.placed = true;
  }

  /** Look along `direction` (from the target toward the camera), at the distance it has: upright -- or `up` up, an Alt+middle drag's own turn. */
  lookFrom(direction: Vec3, up?: Vec3): void {
    const d = Math.max(this.distance, 1e-3);
    const camera = this.camera;
    camera.position.copy(this.target).addScaledVector(scratch.set(...direction).normalize(), d);
    if (up) camera.up.set(...up);
    else camera.up.copy(WORLD_UP);
    camera.lookAt(this.target);
    this.placed = true;
  }

  /**
   * Onto `bounds`: centred on its middle, near enough that its bounding sphere
   * fills the narrower side of the view with `MARGIN` round it, from the
   * direction it looks from now -- or from three-quarter above if never placed.
   * `radius` is the whole model's, for the limits and the clip planes.
   */
  frame(bounds: THREE.Box3, radius = this.radius): void {
    const sphere = bounds.isEmpty() ? new THREE.Sphere(new THREE.Vector3(), 0.5) : bounds.getBoundingSphere(new THREE.Sphere());
    this.radius = Math.max(radius, sphere.radius, 1e-3);
    // A point -- a bone, an empty -- framed with a little of the model round it.
    const r = Math.max(sphere.radius, this.radius * 0.05, 1e-3);
    const dir = this.placed ? this.direction(new THREE.Vector3()) : new THREE.Vector3(...DIRECTIONS.free).normalize();
    this.target.copy(sphere.center);
    const v = THREE.MathUtils.degToRad(this.perspective.fov);
    const h = 2 * Math.atan(Math.tan(v / 2) * this.aspect);
    const distance = (r * MARGIN) / Math.sin(Math.min(v, h) / 2);
    this.perspective.position.copy(this.target).addScaledVector(dir, distance);
    this.orthographic.position.copy(this.perspective.position);
    // The orthographic frustum fitted to the sphere on the narrower side.
    this.sizeOrthographic((2 * r * MARGIN) / Math.min(1, this.aspect));
    // Turned as it is now, upside down or not -- upright if never placed.
    const was = this.placed ? offset.copy(this.camera.up) : offset.copy(WORLD_UP);
    for (const c of [this.perspective, this.orthographic]) {
      c.up.copy(was);
      c.lookAt(this.target);
    }
    this.placed = true;
    this.clip();
  }

  /** The model's size, middle and the ground's reach taken, nothing moved (D46): the limits and the clip planes follow. */
  rescale(radius: number, reach: number, centre?: THREE.Vector3): void {
    this.radius = Math.max(radius, 1e-3);
    this.reach = Math.max(reach, 0);
    if (centre) this.centre.copy(centre);
    this.clip();
  }

  /**
   * Flown for `dt` seconds (Vibe3D D102): `ahead` forward (-1 back), `side`
   * right, `rise` up -- forward the camera's own, pitch and all; up the world's.
   * The target goes with the camera, so the orbit then turns round where it
   * flew to. 1.5 model radii a second, `boost` times that. In orthographic
   * there is no forward to fly: ahead and back zoom instead, as the wheel does.
   */
  fly(ahead: number, side: number, rise: number, dt: number, boost = 1): void {
    const step = 1.5 * this.radius * boost * dt;
    if (this.mode === 'orthographic' && ahead !== 0) this.zoom(Math.exp(-ahead * 1.5 * boost * dt));
    const along = this.mode === 'perspective' ? ahead : 0;
    if (along === 0 && side === 0 && rise === 0) return;
    this.axes();
    move.set(0, 0, 0).addScaledVector(forward, along).addScaledVector(right, side).addScaledVector(WORLD_UP, rise);
    if (move.lengthSq() === 0) return;
    // Diagonals no faster than straight on.
    move.normalize().multiplyScalar(step);
    this.target.add(move);
    this.camera.position.add(move);
    this.placed = true;
  }

  /**
   * Near and far from where the camera is: far past the model's far side and
   * the grid's corners, near a share of the distance -- never so near against
   * far that the depth buffer shreds the model's own surfaces.
   */
  clip(): void {
    const camera = this.camera;
    // From the camera to the model's middle and the ground's, wherever it has flown or panned to (D102's lesson).
    const toModel = camera.position.distanceTo(this.centre);
    const toGround = camera.position.length();
    const far = (Math.max(toModel + this.radius * 2, toGround + this.reach) + this.distance) * 1.5 + 1;
    const near = Math.max(far * 2e-5, Math.min(this.distance * 0.01, this.radius * 0.05));
    this.perspective.near = near;
    this.perspective.far = far;
    this.perspective.updateProjectionMatrix();
    this.orthographic.near = -far;
    this.orthographic.far = far;
    this.orthographic.updateProjectionMatrix();
  }

  /** Where it is, as values. */
  pose(): ViewPose {
    return {
      position: this.camera.position.toArray(),
      target: this.target.toArray(),
      projection: this.mode,
      zoom: this.orthographic.zoom,
      height: this.orthographic.top - this.orthographic.bottom,
      up: this.camera.up.toArray(),
    };
  }

  /** Put where a pose says: its projection, its place, its orthographic frustum. */
  setPose(pose: ViewPose): void {
    this.setProjection(pose.projection);
    this.target.fromArray(pose.target);
    this.camera.position.fromArray(pose.position);
    if (pose.projection === 'orthographic') {
      this.sizeOrthographic(pose.height);
      this.orthographic.zoom = pose.zoom;
      this.orthographic.updateProjectionMatrix();
    }
    if (pose.up) this.camera.up.fromArray(pose.up).normalize();
    else this.camera.up.copy(WORLD_UP);
    this.camera.lookAt(this.target);
    this.placed = true;
    this.clip();
  }

  /** Both cameras' matrices brought up to where they are: before a frame, or a ray. */
  update(): void {
    this.camera.updateMatrixWorld();
  }
}
