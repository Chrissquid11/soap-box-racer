/**
 * The one driver of the editor's 3D views (Docs/navigation.md D2): a press
 * and a wheel event, read by the rule (`navigation.ts`), turned into an orbit,
 * a pan or a zoom of a `ViewCamera` -- the Scene view's (`camera.ts`) and each
 * Model view's (`model/stage.ts`). Its host listens on its canvas, in the order
 * it needs (the cube, a gizmo, picking), and hands each event on: `press` (or
 * `grab`, a drag the host has decided -- the cube's), `move`, `up`, `cancel`
 * and `wheel`. Several views on one canvas are each a `NavView`: the one a
 * press or a wheel event is over is the host's to say.
 *
 * - **A drag starts after 4 pixels** (`navigation.ts`' `SLOP`, `pastSlop`): a press let go before is a
 *   click -- the cube's cone, the centre's pivot (Alt+middle) -- `up` says.
 * - **It follows the pointer**, as Blender's: an orbit a whole turn for a drag
 *   the view's height, a pan keeping what is under the pointer under it, a
 *   Ctrl+middle zoom up or right nearer.
 * - **The wheel's device** (`wheel.ts`) is kept from one event to the next of
 *   a gesture, and its host told when it changes: the top bar's status line
 *   says what scrolling does then (`scrollLine`).
 * - **The preferences are read as each gesture starts** (`loadPrefs`), so a
 *   change on Config ▸ Preferences holds at once.
 */
import * as THREE from 'three';
import { loadPrefs, type NavPrefs, type WheelMode } from '../prefs.ts';
import { GESTURE, wheelDevice, type WheelDevice, type WheelLast } from '../wheel.ts';
import { dragZoom, macPlatform, navigates, pastSlop, pressAction, wheelAction, wheelZoom, type PressAction, type PressWhere } from './navigation.ts';
import { reverseOf, turnOf, type ViewCamera } from './view-camera.ts';
import { DIRECTIONS, type Vec3 } from './views.ts';

/** The six axis views an Alt+middle drag snaps to, unit length. */
const AXES = (['front', 'back', 'left', 'right', 'top', 'bottom'] as const).map((p) => new THREE.Vector3(...DIRECTIONS[p]).normalize());
const snapped = new THREE.Vector3();
const snappedUp = new THREE.Vector3();
const freeRight = new THREE.Vector3();
const freeTurn = new THREE.Quaternion();

/** The axis view nearest `direction`: the one it is most along. */
export function nearestAxis(direction: THREE.Vector3): THREE.Vector3 {
  let best = AXES[0]!;
  for (const axis of AXES) if (axis.dot(direction) > best.dot(direction)) best = axis;
  return best;
}

/** The wheel still this long, in milliseconds: the view at rest. */
const REST = 160;

/** One view a driver moves: its camera, where it is on the page, and what follows a step. */
export interface NavView {
  readonly cam: ViewCamera;
  /** The view's box on the page, in client pixels. */
  box(): { left: number; top: number; width: number; height: number };
  /** After each step: the clip planes, any floor, a frame asked for. */
  moved(): void;
  /** A gesture over -- a drag let go, the wheel still a moment: the view at rest. */
  rested?(): void;
  /** Orbit Around Selection's pivot: the selection's middle, or null for the view's own. */
  pivot?(): THREE.Vector3 | null;
  /**
   * Looking from `direction` (from the pivot toward the camera): an Alt+middle drag's, on an axis view while Alt is held
   * (`axis`, Auto Perspective's to answer) or between them. The host's, for its floor and its projection; else `lookFrom`.
   */
  look?(direction: Vec3, axis: boolean, up?: Vec3): void;
  /** The point of the scene under (`x`, `y`) on the page, or null: where an Alt+middle click centres the view. */
  pointAt?(x: number, y: number): THREE.Vector3 | null;
}

/** A drag the driver has under way: which pointer, what it does, where it was, and the click it is if let go unmoved. */
interface Drag {
  id: number;
  view: NavView;
  does: 'orbit' | 'pan' | 'zoom' | 'snap';
  x: number;
  y: number;
  lastX: number;
  lastY: number;
  moved: boolean;
  pivot: THREE.Vector3 | null;
  click: (() => void) | null;
  /** An Alt+middle drag's own turn of the view, as an orbit turns it -- upside down too: what is snapped to the nearest axis while Alt is held. */
  free: THREE.Quaternion | null;
  /** The button that began it, as `PointerEvent.buttons` has it: 1 left, 4 middle, 2 right. */
  mask: number;
  /** The horizontal orbit's way for the whole drag, from the view's up as it began: -1 upside down (Blender's). */
  reverse: 1 | -1;
}

/** A button (`PointerEvent.button`) as its bit in `PointerEvent.buttons`. */
export const buttonMask = (button: number): number => (button === 1 ? 4 : button === 2 ? 2 : button === 0 ? 1 : 1 << button);

/** A middle press never starts the browser's autoscroll (Windows): the mouse event's default, not the pointer's. Each host's canvas. */
export const noAutoscroll = (event: MouseEvent): void => {
  if (event.button === 1) event.preventDefault();
};

export interface NavigatorOptions {
  /** The preferences, as each gesture starts: `loadPrefs().nav` by default. */
  prefs?(): NavPrefs;
  /** The wheel's device preference: `loadPrefs().wheel` by default. */
  wheelMode?(): WheelMode;
  /** The device the wheel is read as changed (in `auto`, by its events). */
  device?(device: WheelDevice): void;
}

export interface Navigator {
  /**
   * A press over `view`: what the rule says it is, and -- a drag of the view --
   * begun (the host captures the pointer). A box, a menu or nothing is the
   * host's.
   */
  press(event: PointerEvent, view: NavView, where?: Omit<PressWhere, 'mac'>): PressAction;
  /** A drag the host decided (a press on the cube orbits), and the click it is if let go unmoved. */
  grab(event: PointerEvent, view: NavView, does: 'orbit' | 'pan' | 'zoom', click?: () => void): void;
  /** The pointer moved: true if it was the drag's -- false too once its button is found up (the drag then over). */
  move(event: PointerEvent): boolean;
  /** Let go: null if it was not the drag's; else whether it moved, and the action it was (a click of it if not). */
  up(event: PointerEvent): { does: Drag['does']; moved: boolean } | null;
  /** The drag dropped where it is (a cancel, the view gone). */
  cancel(): void;
  /** A wheel event over `view`: orbit, pan or zoom (`wheelAction`). Its default prevented. */
  wheel(event: WheelEvent, view: NavView): void;
  /** A drag under way. */
  readonly dragging: boolean;
  /** The device the last wheel event was read as, or null before one. */
  readonly device: WheelDevice | null;
}

export function createNavigator(options: NavigatorOptions = {}): Navigator {
  const prefs = (): NavPrefs => options.prefs?.() ?? loadPrefs().nav;
  const wheelMode = (): WheelMode => options.wheelMode?.() ?? loadPrefs().wheel;
  let drag: Drag | null = null;
  let last: WheelLast | null = null;
  let mode: WheelMode = 'auto';
  let wheelReverse: 1 | -1 = 1;
  let rest: ReturnType<typeof setTimeout> | undefined;
  let restView: NavView | null = null;

  /** The pivot for an orbit starting now: the selection's middle, with Orbit Around Selection. */
  const pivotOf = (view: NavView): THREE.Vector3 | null => (prefs().orbitSelection ? view.pivot?.() ?? null : null);

  function begin(event: PointerEvent, view: NavView, does: Drag['does'], click: (() => void) | null): void {
    event.preventDefault();
    const free = does === 'snap' ? view.cam.camera.quaternion.clone() : null;
    drag = { id: event.pointerId, view, does, x: event.clientX, y: event.clientY, lastX: event.clientX, lastY: event.clientY, moved: false, pivot: does === 'orbit' ? pivotOf(view) : null, click, free, mask: buttonMask(event.button), reverse: reverseOf(view.cam.camera.up) };
    // An Alt+middle click (let go unmoved): the view centred on the point under the pointer.
    if (does === 'snap') drag.click = () => centre(view, event.clientX, event.clientY);
  }

  /** The view's pivot moved to the point under (`x`, `y`), the camera with it: what it sees turned no way. */
  function centre(view: NavView, x: number, y: number): void {
    const point = view.pointAt?.(x, y);
    if (!point) return;
    view.cam.centreOn(point);
    view.cam.clip();
    view.moved();
  }

  /** One step of a drag: (`dx`, `dy`) pixels, on a view `height` tall. `alt`: Alt held now -- an Alt+middle drag snaps while it is. */
  function step(d: Drag, dx: number, dy: number, alt: boolean): void {
    const cam = d.view.cam;
    const height = d.view.box().height;
    if (d.free) {
      // Its own turn of the view, turned as an orbit would turn it (no limit), then looked from -- the nearest axis,
      // upright, while Alt is held.
      d.free.premultiply(turnOf(dx, dy, height, freeRight.set(1, 0, 0).applyQuaternion(d.free).normalize(), freeTurn, d.reverse)).normalize();
      snapped.set(0, 0, 1).applyQuaternion(d.free);
      snappedUp.set(0, 1, 0).applyQuaternion(d.free);
      const along = alt ? nearestAxis(snapped) : snapped;
      const direction: Vec3 = [along.x, along.y, along.z];
      const up: Vec3 | undefined = alt ? undefined : [snappedUp.x, snappedUp.y, snappedUp.z];
      if (d.view.look) d.view.look(direction, alt, up);
      else cam.lookFrom(direction, up);
    } else if (d.does === 'orbit') cam.orbit(dx, dy, height, d.pivot, d.reverse);
    else if (d.does === 'pan') cam.pan(dx, dy, height);
    else cam.zoom(dragZoom(dy));
    cam.clip();
    d.view.moved();
  }

  return {
    press(event, view, where = {}) {
      const action = pressAction(event, prefs(), { mac: macPlatform(), ...where });
      if (navigates(action)) begin(event, view, action, null);
      return action;
    },
    grab(event, view, does, click) {
      begin(event, view, does, click ?? null);
    },
    move(event) {
      const d = drag;
      if (!d || event.pointerId !== d.id) return false;
      // Its button no longer down -- its release went to someone else (a walk begun, the window left): over, unmoved or not, no click.
      if (typeof event.buttons === 'number' && (event.buttons & d.mask) === 0) {
        drag = null;
        if (d.moved) d.view.rested?.();
        return false;
      }
      if (!d.moved && !pastSlop(event.clientX - d.x, event.clientY - d.y)) return true;
      d.moved = true;
      const dx = event.clientX - d.lastX;
      const dy = event.clientY - d.lastY;
      d.lastX = event.clientX;
      d.lastY = event.clientY;
      if (dx !== 0 || dy !== 0) step(d, dx, dy, event.altKey);
      return true;
    },
    up(event) {
      const d = drag;
      if (!d || event.pointerId !== d.id) return null;
      drag = null;
      if (d.moved) d.view.rested?.();
      else d.click?.();
      return { does: d.does, moved: d.moved };
    },
    cancel() {
      drag = null;
    },
    wheel(event, view) {
      event.preventDefault();
      // The preference read again as a gesture starts: Config ▸ Preferences may have changed it.
      // The orbit's way too, from the view's up as the gesture starts (Blender's reverse upside down): one way the whole gesture.
      if (!last || event.timeStamp - last.at > GESTURE) {
        mode = wheelMode();
        wheelReverse = reverseOf(view.cam.camera.up);
      }
      const device = wheelDevice(event, mode, last);
      const told = last?.device ?? null;
      last = { device, at: event.timeStamp };
      if (device !== told) options.device?.(device);
      const does = wheelAction(event, device);
      const cam = view.cam;
      const box = view.box();
      if (does.kind === 'zoom') {
        // To the view's middle -- or, with Zoom to Mouse Position, to the point under the pointer.
        const toMouse = prefs().zoomToMouse;
        const nx = toMouse ? ((event.clientX - box.left) / Math.max(box.width, 1)) * 2 - 1 : 0;
        const ny = toMouse ? -((event.clientY - box.top) / Math.max(box.height, 1)) * 2 + 1 : 0;
        cam.zoom(wheelZoom(event, device), nx, ny);
      } else if (does.kind === 'orbit') {
        cam.orbit(does.dx, does.dy, box.height, pivotOf(view), wheelReverse);
      } else {
        cam.pan(does.dx, does.dy, box.height);
      }
      cam.clip();
      view.moved();
      // The wheel at rest a moment: the view at rest.
      clearTimeout(rest);
      restView = view;
      rest = setTimeout(() => restView?.rested?.(), REST);
    },
    get dragging() {
      return drag !== null;
    },
    get device() {
      return last?.device ?? null;
    },
  };
}
