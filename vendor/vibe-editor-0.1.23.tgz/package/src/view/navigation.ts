/**
 * Blender's navigation, as a rule (Docs/navigation.md D2, §2): what a press of
 * a button, or a wheel event, does in a 3D view of the editor -- the Scene
 * view, each Model view, the Assets preview -- from the button, the modifiers
 * held, whether this is a Mac, the preferences (`NavPrefs`, D1) and whether
 * something else takes the press (a gizmo's handle, a tool's click, the view
 * cube). Pure: `navigation.test.ts` holds every case, with the shapes Mac and
 * Windows browsers give each event. The driver that moves a `ViewCamera` by it
 * is `navigator.ts`.
 *
 * - **The left button selects** (D3): a box from anywhere, a click picks --
 *   never the orbit, but with Emulate 3 Button Mouse and Alt held, where it is
 *   the middle button. Where a gizmo handle or a tool takes the press, nothing
 *   here.
 * - **The middle button navigates**: alone it orbits, Shift pans, Ctrl zooms,
 *   Alt orbits snapping to the axis views (and a click of it moves the pivot to
 *   the point under the pointer: `snap`, decided as the press is let go).
 * - **The right button is the menu**, let go where it went down; a right drag
 *   does nothing.
 * - **Ctrl is Ctrl** (D4): on a Mac Cmd stands for it too, as the numpad's
 *   keys take it.
 * - **Industry Compatible** (Docs/navigation.md §8, the default keymap):
 *   Alt+left orbits, Alt+middle pans, Alt+right zooms; the middle alone does
 *   nothing; the left button's box and the right's menu as above; Emulate 3
 *   Button Mouse is not read.
 * - **The wheel** (`wheelAction`): a trackpad's two fingers orbit, Shift pans,
 *   Ctrl -- a pinch is a wheel event with Ctrl -- zooms; a mouse's wheel zooms,
 *   Ctrl pans across, Shift pans up and down (a Mac's Shift turns the wheel
 *   sideways: either delta). Which device it is, `wheel.ts`.
 */
import type { NavPrefs } from '../prefs.ts';
import { wheelDrag, type WheelDevice, type WheelInput } from '../wheel.ts';

/** A press that moves this far, in CSS pixels, or further, is a drag: the editor's one click slop (picking, the stage, the driver, the right button's flight). */
export const SLOP = 4;
/** Has a press moved (`dx`, `dy`) past the slop: a drag, no click. */
export const pastSlop = (dx: number, dy: number): boolean => Math.hypot(dx, dy) >= SLOP;

/** What a press does: a drag of the view, the selection's box (a click if let go unmoved), the menu, or nothing of the view's. */
export type PressAction = 'orbit' | 'pan' | 'zoom' | 'snap' | 'box' | 'menu' | 'none';

/** What of a pointer event the rule reads. */
export interface PressInput {
  /** 0 left, 1 middle, 2 right. */
  button: number;
  shiftKey: boolean;
  ctrlKey: boolean;
  altKey: boolean;
  metaKey: boolean;
  /** `PointerEvent.pointerType`: a finger has no box and no menu -- it orbits. */
  pointerType?: string;
}

/** Where the press is: a Mac or not, and whether a gizmo handle, a tool or the cube takes it. */
export interface PressWhere {
  mac: boolean;
  /** A gizmo's handle, a tool's clicks, the view cube: the press is theirs. */
  taken?: boolean;
  /** Does the view select at all: the Assets preview has nothing to pick, so its left button is the middle one there. */
  selects?: boolean;
}

/** Is this a Mac: MrDebug's own test (`isMac`), here so that a node test can import the driver without MrDebug. */
export const macPlatform = (): boolean => /Mac|iPhone|iPad/.test(globalThis.navigator?.platform ?? '');

/** Ctrl, or Cmd on a Mac (D4). */
export const ctrlOf = (press: { ctrlKey: boolean; metaKey: boolean }, mac: boolean): boolean => press.ctrlKey || (mac && press.metaKey);

/** Is this action a drag of the view, the driver's. */
export const navigates = (action: PressAction): action is 'orbit' | 'pan' | 'zoom' | 'snap' => action === 'orbit' || action === 'pan' || action === 'zoom' || action === 'snap';

/** The middle button's drag, by what is held: Shift pans, Ctrl zooms, Alt snaps, alone it orbits. */
function middle(press: PressInput, mac: boolean): PressAction {
  if (press.shiftKey) return 'pan';
  if (ctrlOf(press, mac)) return 'zoom';
  if (press.altKey) return 'snap';
  return 'orbit';
}

/**
 * Industry Compatible's mouse (Docs/navigation.md §8): Alt alone with the left button orbits -- before what takes the
 * press, as Blender's does over a gizmo -- with the middle pans, with the right zooms; the middle alone does nothing.
 * Null where Industry says nothing different: the left button's box, the right's menu, a finger.
 */
function industry(press: PressInput, mac: boolean): PressAction | null {
  if (press.altKey && !press.shiftKey && !ctrlOf(press, mac) && press.pointerType !== 'touch') {
    if (press.button === 0) return 'orbit';
    if (press.button === 1) return 'pan';
    if (press.button === 2) return 'zoom';
  }
  return null;
}

/** What `press` does here (§2; under Industry Compatible, §8). */
export function pressAction(press: PressInput, prefs: Pick<NavPrefs, 'emulate3' | 'keymap'>, where: PressWhere): PressAction {
  const { mac } = where;
  if (prefs.keymap === 'industry') {
    const alt = industry(press, mac);
    if (alt !== null) return alt;
    // The middle button alone, or with Shift or Ctrl: Industry binds nothing to it in the 3D view.
    if (press.button === 1) return 'none';
  }
  if (press.button === 1) return middle(press, mac);
  if (press.button === 2) return press.pointerType === 'touch' ? 'none' : 'menu';
  if (press.button !== 0) return 'none';
  // Emulate 3 Button Mouse: Alt with the left button is the middle one -- Shift+Alt pans, Ctrl+Alt zooms (a Mac's Ctrl+click, its
  // secondary click, a zoom here and never a menu). Before what takes the press: Alt-dragging never grabs a handle in Blender either.
  // Under Industry Compatible meaningless (D12): Alt with the mouse is its navigation already.
  if (prefs.keymap !== 'industry' && prefs.emulate3 && press.altKey) {
    if (press.shiftKey) return 'pan';
    if (ctrlOf(press, mac)) return 'zoom';
    return 'orbit';
  }
  if (where.taken) return 'none';
  // Nothing to select (the Assets preview): the left button is the middle one. A finger orbits.
  if (where.selects === false) return middle(press, mac);
  if (press.pointerType === 'touch') return 'orbit';
  return 'box';
}

/** What a wheel event does, from its device: a drag's worth of pixels for an orbit or a pan, or a zoom. */
export type WheelAction = { kind: 'orbit' | 'pan'; dx: number; dy: number } | { kind: 'zoom' };

/** What `event` does (§2), `device` told by `wheel.ts`. Ctrl is Ctrl alone here: Cmd with a wheel is the browser's on a Mac. */
export function wheelAction(event: WheelInput, device: WheelDevice): WheelAction {
  const { dx, dy } = wheelDrag(event);
  if (device === 'trackpad') {
    if (event.ctrlKey) return { kind: 'zoom' };
    if (event.shiftKey) return { kind: 'pan', dx, dy };
    return { kind: 'orbit', dx, dy };
  }
  // A mouse: Ctrl pans across, Shift up and down -- a Mac turns a Shift-wheel sideways, so either delta is the wheel's.
  if (event.ctrlKey) return { kind: 'pan', dx: dy !== 0 ? dy : dx, dy: 0 };
  if (event.shiftKey) return { kind: 'pan', dx: 0, dy: dy !== 0 ? dy : dx };
  return { kind: 'zoom' };
}

/** A zoom step: this many times nearer or further -- a mouse wheel's notch, Numpad+ and Numpad- (Blender's). */
export const ZOOM_STEP = 1.2;

/**
 * How much a wheel event zooms in proportion to its delta (under 1 nearer, over
 * 1 further): fingers pinched together, or the wheel down -- deltaY over 0 --
 * further. A 100-pixel step five percent; a pinch's small steps ten times
 * theirs; lines and pages made pixels as `wheel.ts` makes them. A trackpad's
 * pinch, and a flat picture's wheel (the Assets preview's).
 */
export function pinchZoom(event: WheelInput): number {
  const pixels = -wheelDrag(event).dy * (event.ctrlKey ? 10 : 1);
  return Math.pow(0.95, -pixels * 0.01);
}

/** A 3D view's wheel zoom: a mouse's notch one `ZOOM_STEP` whatever its delta, as Blender's; a trackpad's pinch in proportion (`pinchZoom`). */
export function wheelZoom(event: WheelInput, device: WheelDevice): number {
  if (device === 'trackpad') return pinchZoom(event);
  return event.deltaY > 0 ? ZOOM_STEP : event.deltaY < 0 ? 1 / ZOOM_STEP : 1;
}

/** How much nearer a Ctrl+middle drag of `dy` pixels goes: up nearer, down further -- vertical only, Blender's default Zoom Axis. */
export function dragZoom(dy: number): number {
  return Math.pow(0.95, -dy * 0.2);
}

/** What scrolling does just now, for the top bar's status line: a trackpad's or a mouse's. */
export function scrollLine(trackpad: boolean): string {
  return trackpad
    ? 'Scrolling as a trackpad: two fingers orbit · Shift pans · a pinch or Ctrl zooms'
    : 'Scrolling as a mouse wheel: the wheel zooms · Ctrl pans across · Shift pans up and down';
}
