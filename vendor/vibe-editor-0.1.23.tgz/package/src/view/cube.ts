/**
 * A view's orientation cube (Docs/modeler.md M9; Vibe3D D21), the Model tab's
 * views' and the Scene tab's (Docs/camera.md §3): Unity's scene
 * gizmo -- a centre cube with a cone on each axis, +X +Y +Z coloured and
 * lettered, the negatives grey -- drawn in a box at the view's top right.
 * A cone clicked looks down that axis; the centre swaps the projection.
 *
 * - **Cones, not a lettered cube**: from straight in front every face of a
 *   cube but one is edge-on and cannot be hit; cones stand out of the
 *   silhouette from any angle (D21's reason).
 * - **Drawn in the view's own projection**, so it shows which one the view is
 *   in; both framed to the same size, so it does not jump on a swap.
 * - **Over the view, not in it**: its own scene, drawn after the view into
 *   its box with only the depth cleared -- clearing the colour would punch a
 *   hole in the picture.
 * - **One for every view**: its scene and materials shared; only where it
 *   looks from, and which part is under the pointer, are the view's.
 */
import * as THREE from 'three';
import type { Rect, Vec3 } from './views.ts';
import { keymapNow } from '../editor-keys.ts';

const X = 0xd6483b;
const Y = 0x7cbf3f;
const Z = 0x3f7fd6;
const NEGATIVE = 0x8d929c;
const CENTRE = 0xb8bcc4;
/** Both projections frame this half-height round the cube. */
const HALF = 1.85;
const FOV = 52;

/** What the cube does, on its hover: the numpad's views, for a keyboard with none. Both tabs'. */
export const cubeTip = (): string => `Drag to orbit (Numpad2 4 6 8 by 15°); a cone looks down that axis -- as ${keymapNow() === 'industry' ? 'F1 or Numpad1 front, F2 or Numpad3 right, F3 or Numpad7 top' : 'Numpad1 front, Numpad3 right, Numpad7 top'}, Ctrl+ them the opposite, Numpad9 the other side; the centre swaps perspective and orthographic, as Numpad5`;

/** What a click on the cube hit: its centre, or a cone and the direction it looks from. */
export type CubeHit = { kind: 'centre' } | { kind: 'axis'; direction: Vec3 };

interface Handle {
  mesh: THREE.Mesh;
  material: THREE.MeshLambertMaterial;
  base: THREE.Color;
  direction: Vec3;
}

const AXES: { direction: Vec3; colour: number; label?: string }[] = [
  { direction: [1, 0, 0], colour: X, label: 'x' },
  { direction: [0, 1, 1e-3], colour: Y, label: 'y' },
  { direction: [0, 0, 1], colour: Z, label: 'z' },
  { direction: [-1, 0, 0], colour: NEGATIVE },
  { direction: [0, -1, 1e-3], colour: NEGATIVE },
  { direction: [0, 0, -1], colour: NEGATIVE },
];

const white = new THREE.Color(0xffffff);
const towards = new THREE.Vector3();
const ndc = new THREE.Vector2();

export class Cube {
  private readonly scene = new THREE.Scene();
  private readonly ortho = new THREE.OrthographicCamera(-HALF, HALF, HALF, -HALF, 0.1, 40);
  private readonly persp = new THREE.PerspectiveCamera(FOV, 1, 0.1, 40);
  private readonly ray = new THREE.Raycaster();
  private readonly handles: Handle[] = [];
  private readonly centre: THREE.Mesh;
  private readonly centreMaterial = new THREE.MeshLambertMaterial({ color: CENTRE });
  private readonly pickable: THREE.Object3D[] = [];
  private readonly cone = new THREE.ConeGeometry(0.19, 0.42, 20);
  private readonly box = new THREE.BoxGeometry(0.52, 0.52, 0.52);
  private readonly labels: THREE.Sprite[] = [];
  private lit: THREE.Object3D | null = null;

  constructor() {
    // A fixed key light in the cube's own space: the cones read as solids and do not swim as the view turns.
    this.scene.add(new THREE.AmbientLight(0xffffff, 1.6));
    const key = new THREE.DirectionalLight(0xffffff, 1.5);
    key.position.set(1, 1.4, 1.6);
    this.scene.add(key);
    this.centre = new THREE.Mesh(this.box, this.centreMaterial);
    this.scene.add(this.centre);
    this.pickable.push(this.centre);
    const up = new THREE.Vector3(0, 1, 0);
    for (const axis of AXES) {
      const material = new THREE.MeshLambertMaterial({ color: axis.colour });
      const mesh = new THREE.Mesh(this.cone, material);
      const d = new THREE.Vector3(...axis.direction).normalize();
      mesh.position.copy(d).multiplyScalar(0.98);
      mesh.quaternion.setFromUnitVectors(up, d);
      this.scene.add(mesh);
      this.pickable.push(mesh);
      this.handles.push({ mesh, material, base: new THREE.Color(axis.colour), direction: axis.direction });
      if (axis.label) {
        // Over the cube always: a letter hidden behind it has stopped doing its job.
        const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: letter(axis.label), depthTest: false, depthWrite: false, transparent: true }));
        sprite.position.copy(d).multiplyScalar(1.5);
        sprite.scale.setScalar(0.62);
        sprite.renderOrder = 10;
        this.scene.add(sprite);
        this.labels.push(sprite);
      }
    }
  }

  private cameraFor(orthographic: boolean): THREE.OrthographicCamera | THREE.PerspectiveCamera {
    return orthographic ? this.ortho : this.persp;
  }

  /** The cube's cameras looking from where the view does. */
  private aim(direction: THREE.Vector3, up: THREE.Vector3, orthographic: boolean): THREE.Camera {
    const camera = this.cameraFor(orthographic);
    const distance = orthographic ? 12 : HALF / Math.tan(THREE.MathUtils.degToRad(FOV / 2));
    camera.position.copy(direction).normalize().multiplyScalar(distance);
    camera.up.copy(up);
    camera.lookAt(0, 0, 0);
    camera.updateMatrixWorld();
    return camera;
  }

  /** What is under a point of the box (box-local CSS pixels), the view looking from `direction`. */
  pick(box: Rect, x: number, y: number, direction: THREE.Vector3, up: THREE.Vector3, orthographic: boolean): CubeHit | null {
    const mesh = this.meshAt(box, x, y, direction, up, orthographic);
    if (!mesh) return null;
    if (mesh === this.centre) return { kind: 'centre' };
    const handle = this.handles.find((h) => h.mesh === mesh);
    return handle ? { kind: 'axis', direction: handle.direction } : null;
  }

  private meshAt(box: Rect, x: number, y: number, direction: THREE.Vector3, up: THREE.Vector3, orthographic: boolean): THREE.Object3D | null {
    const camera = this.aim(direction, up, orthographic);
    ndc.set((x / box.width) * 2 - 1, -((y / box.height) * 2 - 1));
    this.ray.setFromCamera(ndc, camera);
    return this.ray.intersectObjects(this.pickable, false)[0]?.object ?? null;
  }

  /** The part under the pointer lit (null for none): true if that changed, and the view wants drawing again. */
  hover(hit: { box: Rect; x: number; y: number; direction: THREE.Vector3; up: THREE.Vector3; orthographic: boolean } | null): boolean {
    const mesh = hit ? this.meshAt(hit.box, hit.x, hit.y, hit.direction, hit.up, hit.orthographic) : null;
    if (mesh === this.lit) return false;
    this.lit = mesh;
    return true;
  }

  /** Into `box` of a canvas `canvasHeight` CSS pixels tall, looking from `direction`; the part lit only in the view it is lit in. */
  render(renderer: THREE.WebGLRenderer, canvasHeight: number, box: Rect, direction: THREE.Vector3, up: THREE.Vector3, orthographic: boolean, lit: boolean): void {
    const flipped = canvasHeight - (box.y + box.height);
    renderer.setViewport(box.x, flipped, box.width, box.height);
    renderer.setScissor(box.x, flipped, box.width, box.height);
    this.draw(renderer, direction, up, orthographic, lit);
  }

  /**
   * Into the viewport and scissor the renderer has now -- the caller's to set (the Scene tab's into a
   * kept frame's target, `scene-cube.ts`) -- looking from `direction`: only the depth cleared.
   */
  draw(renderer: THREE.WebGLRenderer, direction: THREE.Vector3, up: THREE.Vector3, orthographic: boolean, lit: boolean): void {
    this.centreMaterial.color.set(CENTRE);
    for (const h of this.handles) h.material.color.copy(h.base);
    if (lit && this.lit === this.centre) this.centreMaterial.color.lerp(white, 0.45);
    else if (lit && this.lit) this.handles.find((h) => h.mesh === this.lit)?.material.color.lerp(white, 0.45);
    const camera = this.aim(towards.copy(direction), up, orthographic);
    const autoClear = renderer.autoClear;
    renderer.autoClear = false;
    renderer.clearDepth();
    renderer.render(this.scene, camera);
    renderer.autoClear = autoClear;
  }

  dispose(): void {
    this.cone.dispose();
    this.box.dispose();
    this.centreMaterial.dispose();
    for (const h of this.handles) h.material.dispose();
    for (const s of this.labels) {
      s.material.map?.dispose();
      s.material.dispose();
    }
  }
}

/** A letter, outlined so it reads over a light cone and the dark stage alike. */
function letter(text: string): THREE.CanvasTexture {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  ctx.font = '600 44px ui-sans-serif, system-ui, -apple-system, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 6;
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.75)';
  ctx.strokeText(text, size / 2, size / 2);
  ctx.fillStyle = '#f2f2f4';
  ctx.fillText(text, size / 2, size / 2);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
