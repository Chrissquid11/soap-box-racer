/**
 * Blender's numpad, one table for both tabs' 3D views (Docs/navigation.md §3):
 * the axis views and their opposites, the other side, the projection, the
 * 15° orbit steps, the pan steps, the zoom steps, framing the selection --
 * each a `ToolKey` the tab adds, with `when` its own and `view: true`, its MCP
 * tool as the tab declares it (`view_set` and `view_focus` on the Scene tab,
 * `'ui'` on the Model tab). And Emulate Numpad's twins (D5): the same actions
 * on the digit row, `-` and `=`, live only with the preference on and the
 * pointer over a 3D view (`over-view.ts`), so `1`-`6` stay the tabs anywhere
 * else. Pure: `nav-keys.test.ts` reads the table.
 *
 * - **Ctrl for the opposite and the pans** (D4): `Mod` (Cmd on a Mac, Ctrl
 *   elsewhere) and `Ctrl` (the Ctrl key itself on a Mac, MrDebug's chord) --
 *   one key on a PC, both on a Mac.
 * - **Steps**: an orbit 15° (`ORBIT_STEP`); a pan a tenth of the height the
 *   view sees at its pivot (`PAN_STEP`), so a step looks the same near or far;
 *   a zoom 1.2 times nearer or further (`ZOOM_STEP`), toward the view's middle.
 */
import type { Mcp } from '../mcp/declare.ts';
import type { ToolKey } from '../tool.ts';
import type { Preset } from './views.ts';
import { ZOOM_STEP } from './navigation.ts';
import { editorKeyOf, hasEditorKey } from '../editor-keys.ts';

export { ZOOM_STEP };

/** An orbit step, in radians: 15°. */
export const ORBIT_STEP = Math.PI / 12;
/** A pan step: this share of the height the view sees at its pivot. */
export const PAN_STEP = 0.1;

/**
 * Each numpad view, Blender's: 1 front, 3 right, 7 top -- with Ctrl (Cmd on a Mac too), the side opposite. Their keys,
 * as every key of this page's, are `editor-keys.ts`' (`<prefix> <name>`: `view front` Numpad1).
 */
export const NUMPAD_VIEWS: readonly Exclude<Preset, 'free'>[] = ['front', 'back', 'right', 'left', 'top', 'bottom'];

/** What the keys do to the view they act on: the tab's own doings. */
export interface ViewKeyDoings {
  look(preset: Exclude<Preset, 'free'>): void;
  /** From the other side of where it looks (Numpad9). */
  flip(): void;
  /** The other projection (Numpad5). */
  projection(): void;
  /** An orbit step, as a drag that way: `dx` -1 left, 1 right; `dy` -1 up, 1 down -- the scene turning with it. In turns. */
  orbit(dx: number, dy: number): void;
  /** A pan step: the view moved `dx` right, `dy` up, in shares of the height it sees. */
  pan(dx: number, dy: number): void;
  /** A zoom step: under 1 nearer. */
  zoom(scale: number): void;
}

/** What a tab says of its keys: its names' prefix, its MCP tools, whose view it is, when they are live. */
export interface ViewKeyOptions {
  /** `view` (the Scene tab's names, `view front`) or `model` (`model front`). */
  prefix: string;
  /** The tool that does what a look, a step and the projection do: `view_set`, or `'ui'`. */
  mcp: Mcp;
  /** Whose view, for the help: `The editor's camera`, `The view under the pointer`. */
  who: string;
  when(): boolean;
}

/** The numpad's keys for a tab (§3). */
export function viewKeys({ prefix, mcp, who, when }: ViewKeyOptions, act: ViewKeyDoings): ToolKey[] {
  const turn = ORBIT_STEP / (2 * Math.PI);
  // Each one's keys from the editor's table, by its name there (`view front`, `model front`): a name not there throws.
  const key = (name: string, help: string, run: () => void): ToolKey => ({ name: `${prefix} ${name}`, mcp, key: editorKeyOf(`${prefix} ${name}`), view: true, when, help: `${who} ${help}`, run });
  return [
    ...NUMPAD_VIEWS.map((preset) => key(preset, `from the ${preset}, at the distance it has -- as the cube's cone`, () => act.look(preset))),
    key('flip', 'from the other side: half a turn round, its height kept -- from an axis view, the opposite one', () => act.flip()),
    key('projection', 'in the other projection, perspective or orthographic -- as the cube\'s centre', () => act.projection()),
    key('orbit down', 'orbited down by 15°', () => act.orbit(0, turn)),
    key('orbit up', 'orbited up by 15°', () => act.orbit(0, -turn)),
    key('orbit left', 'orbited left by 15°', () => act.orbit(-turn, 0)),
    key('orbit right', 'orbited right by 15°', () => act.orbit(turn, 0)),
    key('pan down', 'panned down by a tenth of what it sees', () => act.pan(0, -PAN_STEP)),
    key('pan up', 'panned up by a tenth of what it sees', () => act.pan(0, PAN_STEP)),
    key('pan left', 'panned left by a tenth of what it sees', () => act.pan(-PAN_STEP, 0)),
    key('pan right', 'panned right by a tenth of what it sees', () => act.pan(PAN_STEP, 0)),
    key('zoom in', 'zoomed in a step', () => act.zoom(1 / ZOOM_STEP)),
    key('zoom out', 'zoomed out a step', () => act.zoom(ZOOM_STEP)),
  ];
}

/** The digit row and `-` `=` for the numpad's keys (D5): `Numpad1` is `Digit1`, `NumpadAdd` is `Equal`; others none. */
export function emulatedKey(key: string): string | null {
  const parts = key.split('+');
  const code = parts.pop()!;
  const digit = /^Numpad(\d)$/.exec(code);
  const as = digit ? `Digit${digit[1]}` : code === 'NumpadSubtract' ? 'Minus' : code === 'NumpadAdd' ? 'Equal' : null;
  return as === null ? null : [...parts, as].join('+');
}

/**
 * Emulate Numpad's twins of `keys` (D5): each numpad key's action again on the digit row, `-` and `=`, its help the
 * same -- so the keys card lists both on one line -- live only while `emulating` says so and its own `when` does.
 */
export function emulatedKeys(keys: readonly ToolKey[], emulating: () => boolean): ToolKey[] {
  const out: ToolKey[] = [];
  for (const k of keys) {
    // Its twin's keys from the editor's table (`<name> (numpad emulated)`), there for each numpad key's action and
    // `emulatedKey`'s of its keys (`editor-keys.test.ts` holds the two together).
    const name = `${k.name} (numpad emulated)`;
    if (!hasEditorKey(name)) continue;
    const when = k.when;
    out.push({ ...k, name, key: editorKeyOf(name), when: () => emulating() && (when?.() ?? true) });
  }
  return out;
}
