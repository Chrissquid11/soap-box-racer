/**
 * Industry Compatible's Alt+left, and Emulate 3 Button Mouse's under Blender's,
 * over a gizmo's handle (Docs/navigation.md §2, §8): Blender's way is the orbit, so a three `TransformControls` -- the Scene
 * tab's gizmo, the Model tab's pose gizmo -- stands aside for that press. A
 * capturing `pointerdown` on its element, heard before the controls' own,
 * switches them off for the one press and back on as it is let go
 * (`altThrough`). The rule itself is `navigation.ts`' `pressAction`, which the
 * view's driver then reads: the orbit.
 */
import { loadPrefs, type NavPrefs } from '../prefs.ts';

/** What of a `TransformControls` this needs. */
export interface Switchable {
  enabled: boolean;
  readonly dragging: boolean;
}

/** Does this press go through the gizmo to the orbit: the left button with Alt -- Industry Compatible's orbit, or Emulate 3 Button Mouse on under Blender's -- no handle dragged already. */
export const altGoesThrough = (event: { button: number; altKey: boolean }, prefs: Pick<NavPrefs, 'emulate3' | 'keymap'>, controls: Switchable): boolean =>
  event.button === 0 && event.altKey && (prefs.keymap === 'industry' || prefs.emulate3) && controls.enabled && !controls.dragging;

/** `controls` off for an Alt+left press on `element` under Emulate 3 Button Mouse, on again as it is let go. Returns the undo. */
export function altThrough(element: HTMLElement, controls: Switchable): () => void {
  let off = false;
  const back = (): void => {
    if (!off) return;
    off = false;
    controls.enabled = true;
    window.removeEventListener('pointerup', back, true);
    window.removeEventListener('pointercancel', back, true);
  };
  const down = (event: PointerEvent): void => {
    if (!altGoesThrough(event, loadPrefs().nav, controls)) return;
    off = true;
    controls.enabled = false;
    window.addEventListener('pointerup', back, true);
    window.addEventListener('pointercancel', back, true);
  };
  element.addEventListener('pointerdown', down, true);
  return () => {
    element.removeEventListener('pointerdown', down, true);
    back();
  };
}
