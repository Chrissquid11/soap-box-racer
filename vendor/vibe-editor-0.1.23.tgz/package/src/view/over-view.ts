/**
 * Is the pointer over a 3D view of the editor just now -- the Scene view, a
 * Model view: what Emulate Numpad asks before the digit row is the numpad's
 * (Docs/navigation.md D5), and why the tabs' `1`-`6` yield there. Each view's
 * host says when the pointer comes onto it and leaves (`overView`), by a name
 * of its own, so one view's leave never clears another's enter.
 */
const over = new Set<string>();

/** The pointer onto (`on`) or off the view named `who`. */
export function overView(who: string, on: boolean): void {
  if (on) over.add(who);
  else over.delete(who);
}

/** Is the pointer over any 3D view. */
export const pointerOverView = (): boolean => over.size > 0;
