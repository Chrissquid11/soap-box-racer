/**
 * A view of a scene as numbers, shared by the Model tab's views and the Scene
 * tab's (Docs/modeler.md M9, Docs/camera.md §3): where a camera looks from and
 * its name, its projection's, a rect and a point in it, and the cube's box --
 * pure, no three.js and no DOM, so a node test holds every rule
 * (`views.test.ts`). The numpad's keys are `nav-keys.ts`'.
 *
 * - **Named for where the camera is** (D22): a view is `Front` while its
 *   camera looks along that axis within ~2.5° (`AXIS_DOT`), `Free` otherwise.
 */

export type Preset = 'free' | 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom';
export type Projection = 'perspective' | 'orthographic';

export type Vec3 = readonly [number, number, number];

/** From what a view turns round toward its camera. Straight down the pole a turntable cannot hold, so top and bottom come in a hair off it. */
export const DIRECTIONS: Readonly<Record<Preset, Vec3>> = {
  free: [0.7, 0.5, 1],
  front: [0, 0, 1],
  back: [0, 0, -1],
  left: [-1, 0, 0],
  right: [1, 0, 0],
  top: [0, 1, 0.001],
  bottom: [0, -1, 0.001],
};

export const PRESET_NAMES: Readonly<Record<Preset, string>> = {
  free: 'Free',
  front: 'Front',
  back: 'Back',
  left: 'Left',
  right: 'Right',
  top: 'Top',
  bottom: 'Bottom',
};

/** How nearly a camera must look along an axis to be named for it: ~2.5° (D22). */
export const AXIS_DOT = 0.999;

const unit = (v: Vec3): Vec3 => {
  const length = Math.hypot(v[0], v[1], v[2]);
  return length === 0 ? [0, 0, 0] : [v[0] / length, v[1] / length, v[2] / length];
};

/** The axis a direction (from the target toward the camera) looks along, or `free` between them. */
export function presetOf(direction: Vec3): Preset {
  const d = unit(direction);
  for (const preset of ['front', 'back', 'left', 'right', 'top', 'bottom'] as const) {
    const a = unit(DIRECTIONS[preset]);
    if (d[0] * a[0] + d[1] * a[1] + d[2] * a[2] > AXIS_DOT) return preset;
  }
  return 'free';
}

/** A view's label: where it looks from, and its projection, as Unity has them (`Front · Iso`). */
export function viewLabel(preset: Preset, projection: Projection): string {
  return `${PRESET_NAMES[preset]} · ${projection === 'perspective' ? 'Persp' : 'Iso'}`;
}

/** A part of a canvas, in CSS pixels from its top left: a view, the cube's box. */
export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

/** Is the point inside the rect? */
export const inside = (r: Rect, x: number, y: number): boolean => x >= r.x && x < r.x + r.width && y >= r.y && y < r.y + r.height;

/** The cube's box in a view: its top right, a third of the view's shorter side, 52 to 96 pixels (D21). */
export function cubeRect(view: Rect): Rect {
  const size = Math.round(Math.max(52, Math.min(96, Math.min(view.width, view.height) * 0.32)));
  const margin = 6;
  return { x: view.x + view.width - size - margin, y: view.y + margin, width: size, height: size };
}

/** A part of the page, in client pixels: the Scene tab's room past the editor's cards. */
export interface PageBox {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

/**
 * The Scene tab's cube: top right of the scene's room (`room`, past the
 * editor's cards, so never under the right one), or of the whole canvas for
 * none -- in canvas-local CSS pixels, as `cubeRect` sizes it in a view. Sized
 * by the room's width and its height down to the canvas's foot: what cuts the
 * room short from below (the Assets panel, the dock floating over the middle)
 * is nowhere near its top right. `canvas` is the canvas's place on the page.
 */
export function roomCubeRect(room: PageBox | null, canvas: { left: number; top: number; width: number; height: number }): Rect {
  const view = room
    ? { x: room.left - canvas.left, y: room.top - canvas.top, width: room.right - room.left, height: canvas.top + canvas.height - room.top }
    : { x: 0, y: 0, width: canvas.width, height: canvas.height };
  return cubeRect(view);
}
