/**
 * What is selected in the editor: one list for every tool, the scene's picking
 * and the tree alike.
 *
 * Kept as `EntityRef`s, so an entity destroyed under it is simply no longer
 * selected -- and is again if an undo brings it back, under the same ref. The
 * first is the one shown, moved by the gizmo and duplicated; the rest go with
 * it where a tool acts on them all.
 *
 * Every change is told (the editor's 'selection' event), even one that changed
 * nothing: a click on what is selected still brings its row into view.
 *
 * **What a click asks** (`clickHow`, pure, tested) is read off the modifiers
 * held, through MrDebug's own `pressed` -- so `Mod` is Cmd on a Mac and Ctrl
 * elsewhere, as on every key: alone, one; Mod, in or out (`toggle`); Shift, in
 * the scene added, in the tree the rows from the first selected to this one
 * (`range`), with Mod too added to what is there. A box in the scene
 * (`boxHow`): alone it is the selection, Shift adds it, Mod turns each over.
 */
import { type Entity, type EntityRef, NONE, pressed, type World } from '@vibe/engine';

export interface Selection {
  /** The entity shown and moved: the first selected that is alive, or NONE. */
  readonly primary: Entity;
  /** Every selected entity alive, the first first. */
  readonly list: readonly Entity[];
  /** As kept, the first first: refs, dead ones too, as an undo may bring them back. */
  readonly refs: readonly EntityRef[];
  /** What the last `choose` was for, if it was alive: what a list scrolls to. NONE after `clear`. */
  readonly latest: Entity;
  /** `e` alone selected (NONE for nothing); with `add`, put in, or taken out if it is there. */
  choose(e: Entity, add?: boolean): void;
  /**
   * These, and only these, selected, the first shown: what a paste made, a box,
   * a range of rows. `latest`, if given and among them, is what a list scrolls
   * to; else the first. Told once.
   */
  chooseAll(list: readonly Entity[], latest?: Entity): void;
  clear(): void;
}

/** The editor's own handle: `drop` empties it without telling anyone, for another world coming in. */
export interface HeldSelection extends Selection {
  drop(): void;
}

export function createSelection(world: World, changed: () => void): HeldSelection {
  let refs: EntityRef[] = [];
  let latest: Entity = NONE;

  /** The selection as entities: those alive, in order. */
  const living = (): Entity[] => {
    const out: Entity[] = [];
    for (const r of refs) {
      const e = world.deref(r);
      // A ref whose entity an undo took back out of the world has its generation still, and no life.
      if (e !== NONE && world.alive(e)) out.push(e);
    }
    return out;
  };

  return {
    get primary() {
      return living()[0] ?? NONE;
    },
    get list() {
      return living();
    },
    get refs() {
      return refs;
    },
    get latest() {
      return latest;
    },
    choose(e, add = false) {
      const ok = e !== NONE && world.alive(e);
      if (!add) refs = ok ? [world.ref(e)] : [];
      else if (ok) {
        const kept = living().map((x) => world.ref(x));
        const ref = world.ref(e);
        refs = kept.includes(ref) ? kept.filter((r) => r !== ref) : [...kept, ref];
      }
      latest = ok ? e : NONE;
      changed();
    },
    chooseAll(list, last) {
      const ok = list.filter((e) => e !== NONE && world.alive(e));
      refs = [...new Set(ok.map((e) => world.ref(e)))];
      latest = last !== undefined && ok.includes(last) ? last : ok[0] ?? NONE;
      changed();
    },
    clear() {
      refs = [];
      latest = NONE;
      changed();
    },
    drop() {
      refs = [];
      latest = NONE;
    },
  };
}

// ---------------------------------------------------------------- what a click asks

/**
 * What a click asks of the selection: `one` alone, `add` it in, `toggle` it in
 * or out, `range` the rows from the first selected to it, `add-range` those
 * added to what is there.
 */
export type ClickHow = 'one' | 'add' | 'toggle' | 'range' | 'add-range';

/** How a box -- or any several at once -- goes into the selection: in its place, added, or each turned over. */
export type Combine = 'replace' | 'add' | 'toggle';

/** The modifiers of a pointer event, as `pressed` reads them. */
type Held = Pick<MouseEvent, 'ctrlKey' | 'metaKey' | 'shiftKey'>;

/**
 * The modifiers held, as a chord of MrDebug's (`pressed`): Alt left out -- it
 * is the camera's, an Alt-drag orbits -- and null for Ctrl on a Mac or the
 * Windows key elsewhere, which are no `Mod`.
 */
const chordOf = (event: Held, mac?: boolean): string | null =>
  pressed({ code: 'Click', ctrl: event.ctrlKey, meta: event.metaKey, shift: event.shiftKey, alt: false }, mac);

/** What a click with these modifiers asks, in the tree (`inTree`) or in the scene. */
export function clickHow(event: Held, inTree: boolean, mac?: boolean): ClickHow {
  switch (chordOf(event, mac)) {
    case 'Mod+Click':
      return 'toggle';
    case 'Shift+Click':
      return inTree ? 'range' : 'add';
    case 'Mod+Shift+Click':
      return inTree ? 'add-range' : 'toggle';
    // Nothing held -- or Ctrl on a Mac, its right-click, which is no Mod.
    default:
      return 'one';
  }
}

/** How a box drawn with these modifiers goes in: Shift adds, Mod turns each over, nothing replaces. */
export function boxHow(event: Held, mac?: boolean): Combine {
  const chord = chordOf(event, mac);
  return chord === 'Shift+Click' ? 'add' : chord?.startsWith('Mod+') ? 'toggle' : 'replace';
}

/**
 * `these` put into `now` by `how`, in an order whose first is the one shown:
 * replacing, `these` as they come; adding, `now` and then those not in it;
 * turning over, `now` less those in `these`, then the rest of `these`.
 */
export function combined<E>(now: readonly E[], these: readonly E[], how: Combine): E[] {
  if (how === 'replace') return [...new Set(these)];
  const was = new Set(now);
  const fresh = [...new Set(these)].filter((e) => !was.has(e));
  if (how === 'add') return [...now, ...fresh];
  const out = new Set(these);
  return [...now.filter((e) => !out.has(e)), ...fresh];
}

/**
 * The rows from `from` to `to`, `from` first and the rest in the rows' order
 * -- so the one shown stays the one it was. Null if either is not a row.
 */
export function rangeOf<E>(rows: readonly E[], from: E, to: E): E[] | null {
  const a = rows.indexOf(from);
  const b = rows.indexOf(to);
  if (a < 0 || b < 0) return null;
  const span = rows.slice(Math.min(a, b), Math.max(a, b) + 1);
  return [from, ...span.filter((e) => e !== from)];
}

/**
 * A click on `e` that no tool took, as `how` asks: `rows`, the tree's in
 * order, for a range. A range with nothing selected, or from a row not shown,
 * is `e` alone; in the scene a Shift-click on nothing changes nothing.
 */
export function clickOn(selection: Selection, e: Entity, how: ClickHow, rows: readonly Entity[] = []): void {
  const now = selection.list;
  if (how === 'range' || how === 'add-range') {
    const range = e === NONE ? null : rangeOf(rows, selection.primary, e);
    if (!range) return selection.choose(e);
    return selection.chooseAll(how === 'range' ? range : combined(now, range, 'add'), e);
  }
  if (how === 'toggle') return selection.choose(e, true);
  if (how === 'add') return e === NONE ? selection.chooseAll(now, selection.latest) : selection.chooseAll(combined(now, [e], 'add'), e);
  selection.choose(e);
}
