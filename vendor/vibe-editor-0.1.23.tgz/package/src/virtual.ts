/**
 * Long lists drawn only where they are scrolled to (Docs/assets-tool.md §9,
 * §10): the rows in view worked out (`range`), the items a run of rows holds
 * (`itemsOf`, a grid's rows holding several), how many tiles a width takes
 * (`perRowOf`), and where to scroll to bring a row into view (`revealTop`) --
 * pure, so node tests them -- and `mount`, which keeps a list's elements by
 * key: those in view placed, those scrolled out waiting in a small pool, so an
 * element that comes back is the same one, its image decoded once.
 *
 * - **The entity tree takes `range()` alone** (`tree.ts`): its rows carry drop
 *   lines and drop-downs drawn with them. The Assets tool's Folders and Files
 *   are `mount`s.
 * - **Nothing of the editor's is imported**, and `mount` touches the DOM,
 *   `ResizeObserver` and `requestAnimationFrame` only when it is called: node
 *   imports this file for `virtual.test.ts`.
 * - **`mount` makes no item itself** (`make(i)` does); its one element of its
 *   own is the spacer that gives the list its scrolling height.
 */

/** Rows `first` up to, not including, `last`. */
export interface Span {
  first: number;
  last: number;
}

/**
 * The rows to draw of `rows` rows each `rowHeight` tall, scrolled to
 * `scrollTop` in a view `height` tall: those in view, and `overscan` more
 * before and after, held to the list's ends. With `overscan` 2 it is the
 * entity tree's own formula: `max(0, floor(scrollTop / ROW) - 2)` to
 * `min(rows, first + ceil(height / ROW) + 4)`.
 */
export function range(scrollTop: number, height: number, rowHeight: number, rows: number, overscan = 2): Span {
  if (rows <= 0 || rowHeight <= 0) return { first: 0, last: 0 };
  const first = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
  const last = Math.min(rows, first + Math.ceil(Math.max(0, height) / rowHeight) + 2 * overscan);
  return { first: Math.min(first, last), last };
}

/** The items rows `rows` hold, `perRow` a row, of `count` items: the last row part full, and nothing past `count`. */
export function itemsOf(rows: Span, perRow: number, count: number): Span {
  const per = Math.max(1, Math.floor(perRow));
  const last = Math.max(0, Math.min(count, rows.last * per));
  return { first: Math.min(rows.first * per, last), last };
}

/** How many tiles `tile` wide, `gap` apart, fit across `width`: at least one. The last needs no gap after it. */
export function perRowOf(width: number, tile: number, gap: number): number {
  if (tile <= 0) return 1;
  return Math.max(1, Math.floor((width + gap) / (tile + gap)));
}

/**
 * Where to scroll so row `at` is in view: where it is if it is in view
 * already; else with its top in the middle (`middle`), or only just -- its top
 * at the top coming from below, its bottom at the bottom coming from above.
 */
export function revealTop(at: number, rowHeight: number, scrollTop: number, height: number, middle = false): number {
  const top = at * rowHeight;
  const bottom = top + rowHeight;
  if (top >= scrollTop && bottom <= scrollTop + height) return scrollTop;
  if (middle) return Math.max(0, top - height / 2);
  return top < scrollTop ? top : bottom - height;
}

export interface MountOptions {
  /** The scrolling element: `position: relative`, its items placed in it by `top`. */
  list: HTMLElement;
  /**
   * A row's height in pixels, read again on `invalidate()` -- always after
   * `perRow`, so a height that comes of the layout `perRow` works out (a grid's
   * tiles at a new size) is the new one, never the last.
   */
  rowHeight(): number;
  /** Items a row for a list this wide: 1 for a plain list. Called first, at the mount, on a resize and on `invalidate()`. */
  perRow(width: number): number;
  /** Items there are, read again on `invalidate()`. */
  count(): number;
  /** Item `i`'s key: what its element is kept by. */
  key(i: number): string;
  /** A new element for item `i`. */
  make(i: number): HTMLElement;
  /** `el` made to show item `i`: as it comes into view, and for every one in view on `invalidate()`. */
  update(el: HTMLElement, i: number): void;
}

export interface Mounted {
  /** Read `rowHeight()`, `count()` and the items again, and draw what is in view: once, the next frame. */
  invalidate(): void;
  /** Item `i`'s row in view: in the middle, or only just. Drawn now. */
  reveal(i: number, middle?: boolean): void;
  /** Items a row, as last worked out. */
  readonly perRow: number;
  /** The element shown for the item with this key, if it is in view. */
  shown(key: string): HTMLElement | undefined;
  /**
   * The items with these keys made to show themselves again (`update`), now,
   * those in view alone: one mark changed -- a job's -- and nothing else is
   * touched, the list's own elements neither added, moved nor taken out.
   * Answers how many were.
   */
  redraw(keys: Iterable<string>): number;
  /** Drawn now, rather than at the next frame: what `invalidate` will do. */
  flush(): void;
  dispose(): void;
}

/** The pool keeps this many screens' worth of elements scrolled out. */
const POOL_SCREENS = 2;

/**
 * `list` drawn as a virtual list: the items in view in it, each kept by its
 * key; those scrolled out in a detached pool of twice a screen's worth, the
 * least recently shown dropped past that, and any whose key is gone dropped at
 * the next `invalidate()`. Its own `ResizeObserver` works `perRow` out again on
 * a resize; a scroll draws at once what comes into view.
 */
export function mount({ list, rowHeight, perRow, count, key, make, update }: MountOptions): Mounted {
  const spacer = list.ownerDocument.createElement('div');
  spacer.className = 'ed-rows-space';
  list.append(spacer);
  /** In view, by key. */
  let live = new Map<string, HTMLElement>();
  /** Where each in view is, by key: `update` takes the index. */
  let at = new Map<string, number>();
  /** Scrolled out and waiting, by key, the least recently shown first. */
  const pool = new Map<string, HTMLElement>();
  // The layout first, then the height that comes of it.
  let per = Math.max(1, perRow(list.clientWidth));
  let height = Math.max(1, rowHeight());
  let total = 0;
  let frame = 0;
  let disposed = false;

  /**
   * What is in view placed; `all`: every one in view made to show its item
   * again, not only those coming in. The count is read every time: the items
   * may have changed since the last `invalidate()` -- a scroll or a resize
   * before its frame must not ask for an item past the end.
   */
  function draw(all: boolean): void {
    if (disposed) return;
    total = count();
    const rows = Math.ceil(total / per);
    spacer.style.height = `${rows * height}px`;
    const span = itemsOf(range(list.scrollTop, list.clientHeight, height, rows), per, total);
    const next = new Map<string, HTMLElement>();
    const where = new Map<string, number>();
    for (let i = span.first; i < span.last; i++) {
      const k = key(i);
      let el = live.get(k);
      const fresh = !el;
      if (!el) {
        el = pool.get(k);
        if (el) pool.delete(k);
        else el = make(i);
      }
      const row = Math.floor(i / per);
      el.style.top = `${row * height}px`;
      if (fresh || all) update(el, i);
      if (!el.isConnected || el.parentElement !== list) list.append(el);
      next.set(k, el);
      where.set(k, i);
    }
    // What went out of view waits in the pool, detached; the oldest go past two screens' worth.
    for (const [k, el] of live) {
      if (next.has(k)) continue;
      el.remove();
      pool.delete(k);
      pool.set(k, el);
    }
    live = next;
    at = where;
    const keep = Math.max(16, POOL_SCREENS * Math.max(1, span.last - span.first));
    while (pool.size > keep) pool.delete(pool.keys().next().value!);
  }

  /** Every key there is, and the pool rid of those gone: the next `invalidate()`'s. */
  function prune(): void {
    if (pool.size === 0) return;
    const keys = new Set<string>();
    for (let i = 0; i < total; i++) keys.add(key(i));
    for (const k of [...pool.keys()]) if (!keys.has(k)) pool.delete(k);
  }

  function now(): void {
    cancelAnimationFrame(frame);
    frame = 0;
    per = Math.max(1, perRow(list.clientWidth));
    height = Math.max(1, rowHeight());
    total = count();
    prune();
    draw(true);
  }

  const onScroll = (): void => draw(false);
  list.addEventListener('scroll', onScroll, { passive: true });
  let width = list.clientWidth;
  const resized = new ResizeObserver(() => {
    if (list.clientWidth === width) return draw(false);
    width = list.clientWidth;
    const was = per;
    per = Math.max(1, perRow(width));
    height = Math.max(1, rowHeight());
    if (per !== was) invalidate();
    else draw(false);
  });
  resized.observe(list);

  function invalidate(): void {
    if (frame !== 0 || disposed) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      now();
    });
  }

  draw(true);

  return {
    invalidate,
    flush: now,
    get perRow() {
      return per;
    },
    shown: (k) => live.get(k),
    redraw(keys) {
      let n = 0;
      for (const k of keys) {
        const el = live.get(k);
        const i = at.get(k);
        // Still that item: the list may have changed since it was drawn, before its frame.
        if (!el || i === undefined || i >= count() || key(i) !== k) continue;
        update(el, i);
        n++;
      }
      return n;
    },
    reveal(i, middle = false) {
      if (frame !== 0) now();
      const row = Math.floor(i / per);
      const top = revealTop(row, height, list.scrollTop, list.clientHeight, middle);
      if (top !== list.scrollTop) list.scrollTop = top;
      draw(false);
    },
    dispose() {
      disposed = true;
      cancelAnimationFrame(frame);
      resized.disconnect();
      list.removeEventListener('scroll', onScroll);
      for (const el of live.values()) el.remove();
      live.clear();
      at.clear();
      pool.clear();
      spacer.remove();
    },
  };
}
