/**
 * The editor's notices (Docs/studio.md §1, "Recovery"): what went wrong that the person should see, kept here
 * and drawn as a strip under the top bar (`notices-strip.ts`, `.ed-notices` in `shell.css`) -- each its words
 * and a Dismiss, the strip hidden with none. In studio mode the editor must come up and stay up whatever fails,
 * and point the failures out instead of blocking:
 *
 * - **`boot`**: the game could not load -- a prefab that will not compile, a game module with a syntax error, the
 *   preload -- and the page is in recovery over a stand-in game (`@vibe/engine/boot`). While one is up the strip
 *   has Reload, and the page reloads itself when the fix lands (`recovery.ts`).
 * - **`tools`**: a project's tool module, its components or one of its tools failed: the editor goes on without it.
 * - **`frame`**: a system threw: the game paused (a playtest paused, the editor over it), where it threw in the
 *   TypeScript once its stack is mapped (`code-notices.ts`), with Open; gone with the next good swap.
 * - **`swap`**: a changed game module threw as it was evaluated: not swapped, the game on the last good code (Docs/studio.md
 *   §1, "Mid-session"); placed and opened as `frame`; gone with the next good swap.
 * - **`code`**: a module of the project's Vite cannot serve now -- a syntax error, an import of no file -- said by the
 *   editor from the dev server's list (`code-notices.ts`), with Open; gone when it serves again. A page reload the
 *   server holds meanwhile is said on it.
 * - **`scene`**: the start scene was not opened: the game's own world instead.
 * - **`camera`**: the scene has no main camera -- the game draws through the built-in one -- said by the editor
 *   itself (`camera-notice.ts`), with a button that mends it (`actions`): Add a main camera, Make <name> main.
 * - **`keys`**: a debug key of the game's (a `MrDebug.add` with no `when`) holds a key of the editor's, so the
 *   editor's action goes without it (`editor-keys.ts`' `giveWay`): every one in one notice, by name and key.
 *
 * Boot says them through `EditorHandle.notice` (its contract, written in the engine's `boot.ts`); one boot had
 * before the editor was made comes with `createEditor({ notices })`. No DOM: a node test runs this.
 */
import { NOT_FETCHED } from '@vibe/engine';
import type { Mcp } from './mcp/declare.ts';

/** What a notice is about (boot's `NoticeKind`, the same words). */
export type NoticeKind = 'boot' | 'tools' | 'frame' | 'scene' | 'swap' | 'physics' | 'camera' | 'code' | 'keys';
/** What boot says (its `NoticeKind`, the same words): all but the editor's own. */
export type BootNoticeKind = Exclude<NoticeKind, 'camera' | 'code' | 'keys'>;

/** A button on a notice's row that does something about it. */
export interface NoticeAction {
  label: string;
  /** The MCP tool that does what it does, `'ui'`, or why none does (`Mcp`, `mcp/declare.ts`). */
  mcp: Mcp;
  title: string;
  run(): void;
}

export interface Notice {
  /** Its own, for Dismiss. */
  readonly id: number;
  readonly kind: NoticeKind;
  readonly text: string;
  /** When it was said, in milliseconds. */
  readonly at: number;
  /** What was thrown, for the console and a row's hover. */
  readonly error?: unknown;
  /** Buttons on its row before Dismiss. */
  readonly actions?: readonly NoticeAction[];
  /** The error's stack at the TypeScript's places (`code-notices.ts`): the row's hover, in place of the error's own. */
  readonly stack?: string;
}

export interface Notices {
  /** Those up, oldest first. */
  readonly list: readonly Notice[];
  /** Said: up from now, unless the same words of the same kind are up already (a frame that throws on every tick). Answers the one up. */
  add(kind: NoticeKind, text: string, error?: unknown, actions?: readonly NoticeAction[], stack?: string): Notice;
  /** One said again in place -- its words, buttons and stack -- keeping its id, its place and when it was said. False: not up. */
  update(id: number, text: string, actions?: readonly NoticeAction[], stack?: string): boolean;
  /** One put away. */
  dismiss(id: number): void;
  /** Every one put away but a `boot` one: the game could not load, and Reload is its way out, never Dismiss. */
  dismissAll(): void;
  /** Every one of `kind` put away: what they said is over (a good swap, a module that serves again). */
  clear(kind: NoticeKind): void;
  /** Is one of `kind` up? */
  has(kind: NoticeKind): boolean;
  /** Told each time the list changes. Returns the undo. */
  on(fn: () => void): () => void;
}

export function createNotices(now: () => number = () => Date.now()): Notices {
  let list: Notice[] = [];
  let next = 1;
  const heard = new Set<() => void>();
  const told = (): void => {
    for (const fn of heard) fn();
  };
  return {
    get list() {
      return list;
    },
    add(kind, text, error, actions, stack) {
      const same = list.find((n) => n.kind === kind && n.text === text);
      if (same) return same;
      const notice: Notice = { id: next++, kind, text, at: now(), ...(error !== undefined ? { error } : {}), ...(actions ? { actions } : {}), ...(stack !== undefined ? { stack } : {}) };
      list = [...list, notice];
      told();
      return notice;
    },
    update(id, text, actions, stack) {
      const at = list.findIndex((n) => n.id === id);
      if (at < 0) return false;
      const was = list[at]!;
      const { actions: _a, stack: _s, ...rest } = was;
      const notice: Notice = { ...rest, text, ...(actions ? { actions } : {}), ...(stack !== undefined ? { stack } : {}) };
      list = list.map((n, i) => (i === at ? notice : n));
      told();
      return true;
    },
    dismiss(id) {
      const kept = list.filter((n) => n.id !== id);
      if (kept.length === list.length) return;
      list = kept;
      told();
    },
    dismissAll() {
      const kept = list.filter((n) => n.kind === 'boot');
      if (kept.length === list.length) return;
      list = kept;
      told();
    },
    clear(kind) {
      const kept = list.filter((n) => n.kind !== kind);
      if (kept.length === list.length) return;
      list = kept;
      told();
    },
    has: (kind) => list.some((n) => n.kind === kind),
    on(fn) {
      heard.add(fn);
      return () => void heard.delete(fn);
    },
  };
}

/** An error's words: its message -- which names the prefab and the key, or the file and line, as boot's error does -- or the thing itself. */
export function errorText(error: unknown): string {
  if (error instanceof Error) return error.message.trim() || error.name;
  if (typeof error === 'string') return error;
  try {
    return JSON.stringify(error) ?? String(error);
  } catch {
    return String(error);
  }
}

/** The boot notice's words: what failed, and what to do. */
export function bootText(error: unknown): string {
  return `The game could not load -- ${errorText(error)} · Fix it here (Code, Claude), then Reload · reloads by itself when the fix lands`;
}

/** Vite's error for a module it could not serve (its `vite:error` payload's `err`, the overlay's): the words that name the file. */
export interface ViteError {
  message: string;
  id?: string;
  loc?: { file?: string; line: number; column: number };
}

/**
 * A boot notice in the browser's words (a module that did not load: the engine's `NOT_FETCHED`, no file) said in Vite's
 * instead, once: the first `vite:error` heard -- or its overlay read -- names the file. A later one (another
 * file's syntax error, fixed or not) leaves it as it is: a notice already in Vite's words is not the browser's.
 * True if it changed. `root`, as `viteErrorText`'s.
 */
export function namedByVite(notices: Notices, err: ViteError, root = ''): boolean {
  const vague = notices.list.find((n) => n.kind === 'boot' && NOT_FETCHED.test(errorText(n.error)) && n.text === bootText(n.error));
  if (!vague) return false;
  notices.dismiss(vague.id);
  notices.add('boot', bootText(viteErrorText(err, root)), vague.error);
  return true;
}

/**
 * Vite's error as a boot notice's error words: where -- its `loc`, else a `file:line:col` its message names (the
 * bundler's code frame), else its file -- then the message's first line that says something (not "Transform failed
 * with 1 error:"). `root`, the project's with its `/`, taken off the front of a path.
 */
export function viteErrorText(err: ViteError, root = ''): string {
  const lines = err.message.split('\n').map((l) => l.trim()).filter((l) => l !== '');
  const headline = lines.find((l) => !/^Transform failed with \d+ errors?:?$/i.test(l)) ?? lines[0] ?? '';
  const named = /([\w./@-]+\.\w+):(\d+):(\d+)/.exec(err.message);
  const file = (err.loc?.file ?? err.id ?? '').split('?')[0]!;
  const short = root && file.startsWith(root) ? file.slice(root.length) : file;
  const where = err.loc ? `${short}:${err.loc.line}:${err.loc.column}` : named ? named[0] : short;
  // A headline that starts with the file again says it once.
  const said = where && headline.startsWith(file) ? headline.slice(file.length).replace(/^[:\s]+/, '') : headline;
  return where ? `${where}: ${said}` : said;
}
