/**
 * The view cube in the Scene view (Docs/camera.md §3): the Model tab's cube
 * (`view/cube.ts`) drawn over the world at the top right of the scene's room
 * -- past the editor's cards, so never under the right one -- with "Persp" or
 * "Iso" under it, a button of the page's as the Model tab's `.ed-mo-proj`.
 *
 * - **Drawn through the game's hook** (`Game.onDrawWorld`, the viewport's,
 *   which draws the camera preview after it), right after the world: running or stopped -- into the kept frame then, so the Pixi layer's
 *   copy of it keeps the cube. The viewport and the scissor are set for its box
 *   into whatever is bound -- the screen, or the kept frame's target, whose own
 *   viewport three takes each time it binds it -- and put back whole.
 * - **A press on it is its alone**: a capturing `pointerdown`, added before the
 *   gizmo's, the camera's and picking's, stops a left press in its box. A drag
 *   from there orbits (`EditorCamera.grab`); let go where it went down, a cone
 *   looks down that axis (`EditorCamera.snapTo`, orthographic with Auto Perspective), the centre swaps the
 *   projection, as the button does.
 * - **Only on the Scene page** (`setShown`, the viewport's `setActive`): under
 *   the Model, Studio or Config page the cube is not drawn and its button is
 *   hidden and inert -- never reached by Tab, so Enter never swaps the scene
 *   camera's projection unseen -- and a press or a hover where it would be is
 *   not its.
 * - **Hover** lights the part under the pointer and says what the cube does on
 *   the canvas's tooltip (`cubeTip`), as the Model tab's.
 * - **Where the room is** comes from the editor (`room`), read as each frame is
 *   drawn, and between frames -- the editor's cards come and go, are dragged
 *   wider, and the dock above the Assets panel moves without the scene being
 *   drawn: the editor says so (`relayout`) wherever it measures its cards --
 *   a tab changed, the cards away or back, a card or the dock resized (its
 *   `ResizeObserver`) -- and a frame is asked for only when the cube's box
 *   moved. Nothing polls.
 */
import * as THREE from 'three';
import type { Game } from '@vibe/engine/boot';
import type { EditorCamera } from './camera.ts';
import { control, tip } from './dom.ts';
import { Cube, cubeTip } from './view/cube.ts';
import { drawInto, drawWhole } from './view/draw-into.ts';
import { inside, roomCubeRect, type PageBox, type Rect } from './view/views.ts';

export interface SceneCubeOptions {
  game: Game;
  camera: EditorCamera;
  /** The editor's root: the button goes in it, placed in page pixels. */
  root: HTMLElement;
  /** The scene's room on the page, past the editor's cards; null for the whole canvas. */
  room(): PageBox | null;
  /** Something of the cube's changed on screen -- lit, moved: a frame to be drawn soon. */
  changed(): void;
}

export interface SceneCube {
  /** Drawn and listening: the editor's scene is up. */
  open(): void;
  close(): void;
  /** Over the world, into the corner, as the viewport's `Game.onDrawWorld` calls it while open: nothing off the Scene page. */
  draw(renderer: THREE.WebGLRenderer): void;
  /** The Scene tab is the page up: the cube drawn and its button shown, or neither. */
  setShown(shown: boolean): void;
  /** The room may have moved (a card resized, folded or slid away): a frame asked for if the cube's box moved. */
  relayout(): void;
  dispose(): void;
}

const direction = new THREE.Vector3();
/** A pointer over the cube, as `Cube.hover` takes it: filled in place on each move, nothing made per event. */
const over = { box: { x: 0, y: 0, width: 0, height: 0 } as Rect, x: 0, y: 0, direction, up: new THREE.Vector3(), orthographic: false };

export function createSceneCube({ game, camera, root, room, changed }: SceneCubeOptions): SceneCube {
  const canvas = game.renderer.domElement;
  const cube = new Cube();
  const button = control('view_set', 'ed-view-proj') as HTMLButtonElement;
  button.hidden = true;
  button.inert = true;
  root.append(button);
  let opened = false;
  /** The Scene tab is the page up (`setShown`). */
  let shown = false;
  /** The button there to see and to reach, or neither: open, on the Scene page. */
  const showButton = (): void => {
    const on = opened && shown;
    button.hidden = !on;
    button.inert = !on;
  };
  /** Is the pointer over a part of the cube: lit. */
  let lit = false;
  /** The box drawn last, canvas-local: what a press and a hover are measured against. */
  let box: Rect = { x: 0, y: 0, width: 0, height: 0 };

  /** The cube's box now, canvas-local CSS pixels, and the canvas's place on the page. */
  const place = (): { rect: Rect; page: DOMRect } => {
    const page = canvas.getBoundingClientRect();
    return { rect: roomCubeRect(room(), page), page };
  };
  const same = (a: Rect, b: Rect): boolean => a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;

  /** The button under the cube, and its words: the projection now. */
  function label(rect: Rect, page: DOMRect): void {
    const iso = camera.projection === 'orthographic';
    const words = iso ? 'Iso' : 'Persp';
    if (button.textContent !== words) {
      button.textContent = words;
      tip(button, iso ? 'Orthographic: click for perspective (or the cube\'s centre)' : 'Perspective: click for orthographic (or the cube\'s centre)', 'Numpad5');
    }
    const left = `${page.left + rect.x + rect.width / 2}px`;
    const top = `${page.top + rect.y + rect.height + 2}px`;
    if (button.style.left !== left) button.style.left = left;
    if (button.style.top !== top) button.style.top = top;
  }

  const size = new THREE.Vector2();
  /** Over the world, before the UI: the viewport's part of `Game.onDrawWorld`. */
  const draw = (renderer: THREE.WebGLRenderer): void => {
    if (!shown) return;
    const { rect, page } = place();
    box = rect;
    label(rect, page);
    renderer.getSize(size);
    if (rect.width <= 0 || rect.height <= 0 || size.y <= 0) return;
    drawInto(renderer, rect, size.y);
    const seen = camera.object;
    cube.draw(renderer, camera.direction(direction), seen.up, camera.projection === 'orthographic', lit);
    drawWhole(renderer, size.x, size.y);
  };

  /** Is a point of the page in the cube's box: if so, `over` holds it box-local, with the box and the camera's look. */
  const local = (event: { clientX: number; clientY: number }): boolean => {
    if (!shown) return false;
    const page = canvas.getBoundingClientRect();
    const x = event.clientX - page.left;
    const y = event.clientY - page.top;
    if (!inside(box, x, y)) return false;
    over.box = box;
    over.x = x - box.x;
    over.y = y - box.y;
    camera.direction(direction);
    over.up.copy(camera.object.up);
    over.orthographic = camera.projection === 'orthographic';
    return true;
  };

  /**
   * Before the gizmo, the camera and picking hear it (capturing, added first): a left press in the cube's box is its own --
   * a drag from it orbits (Blender's gizmo, Docs/navigation.md §2); let go where it went down, a cone looks down that axis,
   * the centre swaps the projection.
   */
  const down = (event: PointerEvent): void => {
    if (event.button !== 0) return;
    if (!local(event)) return;
    const hit = cube.pick(box, over.x, over.y, direction, over.up, over.orthographic);
    event.preventDefault();
    event.stopImmediatePropagation();
    camera.grab(event, () => {
      if (!hit) return;
      if (hit.kind === 'centre') camera.setProjection(camera.projection === 'perspective' ? 'orthographic' : 'perspective');
      else camera.snapTo(hit.direction);
    });
  };

  const hover = (event: PointerEvent): void => {
    const at = event.buttons === 0 && local(event);
    const was = lit;
    lit = at;
    // The cube says what it does as the pointer comes onto it: on a laptop it is the numpad's views.
    if (lit !== was) canvas.title = lit ? cubeTip() : '';
    if (cube.hover(at ? over : null) || lit !== was) changed();
  };
  const leave = (): void => {
    if (!lit && !cube.hover(null)) return;
    lit = false;
    canvas.title = '';
    changed();
  };

  button.addEventListener('click', (event) => {
    event.stopPropagation();
    camera.setProjection(camera.projection === 'perspective' ? 'orthographic' : 'perspective');
  });

  const sceneCube: SceneCube = {
    draw: (renderer) => {
      if (opened) draw(renderer);
    },
    open() {
      if (opened) return;
      opened = true;
      canvas.addEventListener('pointerdown', down, { capture: true });
      canvas.addEventListener('pointermove', hover);
      canvas.addEventListener('pointerleave', leave);
      showButton();
      changed();
    },
    close() {
      if (!opened) return;
      opened = false;
      canvas.removeEventListener('pointerdown', down, { capture: true });
      canvas.removeEventListener('pointermove', hover);
      canvas.removeEventListener('pointerleave', leave);
      if (lit) canvas.title = '';
      lit = false;
      cube.hover(null);
      showButton();
    },
    setShown(on) {
      if (on === shown) return;
      shown = on;
      showButton();
      if (!on) leave();
      if (opened) changed();
    },
    relayout() {
      if (!opened || !shown) return;
      const { rect, page } = place();
      label(rect, page);
      if (!same(rect, box)) changed();
    },
    dispose() {
      sceneCube.close();
      cube.dispose();
      button.remove();
    },
  };
  return sceneCube;
}
