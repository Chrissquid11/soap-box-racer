/**
 * Undo and redo for the editor: a stack of steps, each knowing how to undo and
 * redo itself.
 *
 * **It knows nothing of worlds.** A step is anything with `undo` and `redo`: a
 * world edit (`world-steps.ts`, which keeps the whole world before and after),
 * a spline's point moved, a tile painted, a level's setting changed -- any tool
 * pushes its own, and they all share the one stack, the one pair of keys and the
 * bar's buttons.
 *
 * - **A step is pushed once it is done**: the tool has applied it, and the
 *   history only keeps it. Its `label` -- 'Move', 'Rename', 'Destroy 3' -- is on
 *   the Undo and Redo buttons and the top bar's status line.
 * - **A group is one step**: everything pushed inside `group` becomes one, undone
 *   last first. Groups inside a group are the same group. Its steps are its
 *   `parts`, for whoever pushed one to find it inside (a playtest's paused
 *   edits, `editor.ts`).
 * - **A step may absorb the next** (`merge`): a slider dragged twice in a row is
 *   one step, if the step says so. Never across the save point, or after an undo.
 * - **Bounded**: a hundred steps, or 64 MB over the steps that say how big they
 *   are (`size`), the oldest going first.
 * - **It knows where the last save is**: a step's place in the list, so undoing
 *   back to the save is clean again, and an edit after an undo past it, which
 *   drops the steps ahead, leaves no way back to it. The editor's subtitle
 *   shows a dot while `saved` is false.
 * - **A step that lands later may be put back** (`place`): an Apply's undo
 *   or redo writes files and waits for their compile; one that cannot land --
 *   the dev server gone -- moves the step back where it was without running
 *   it, and one that lands late moves it on then.
 * - **What it is kept for is the editor's to decide**: another world loaded, or
 *   the game run since, is `reset` -- the steps were of something else.
 * - **It can be read as a list** (`labels`, `done`): the editor's History card,
 *   where a click on a step undoes or redoes to it, one step at a time; and as
 *   the steps themselves (`steps`), for whoever pushed one to find it again --
 *   the agent's edits, whose Undo is that step's (Docs/agent.md §8).
 * - **A step's label may change** while it is on the stack -- an asset step
 *   whose call is under way reads "Rename crate → box …" until the disk says
 *   so (Docs/assets.md §6): `touch()` tells the listeners `'label'`, the one
 *   way to say "read me again", on which the host redraws its bars.
 */

export interface Step {
  /** What it did, as the buttons say it: 'Move', 'Rename', 'Destroy 3'. */
  label: string;
  undo(): void;
  redo(): void;
  /** Absorb `next` into this step (a slider dragged twice in a row): true if absorbed. Optional. */
  merge?(next: Step): boolean;
  /** What keeping it costs, in characters (a save's JSON): counted against the history's bound. Optional. */
  size?: number;
  /**
   * What went wrong with it last, whole -- an Apply's undo that could not land,
   * and the ways back: its row in the History card says it on hover, marked.
   * Cleared once it lands. Optional.
   */
  note?: string;
  /**
   * The agent's turn it was made in (Docs/ai-panel.md D8; set by the page tools as they commit it): the History card
   * groups a turn's steps under one row. None for the person's, an outside client's, or one from before a reload.
   */
  turn?: string | null;
  /**
   * The step let go of for good -- fallen off the stack's end, dropped from
   * redo by a new step, the stack reset or replaced: what it alone kept is
   * freed (a canvas deleted, its texture). Optional.
   */
  drop?(): void;
  /** A group's steps, in order, as they were pushed inside it (`group`). Read only. */
  readonly parts?: readonly Step[];
}

/** What changed: a step pushed (or merged), undone, redone; the steps all gone; the save point moved; a label, or whether it can be used (`touch`); the steps put aside or taken back. */
export type HistoryEvent = 'push' | 'undo' | 'redo' | 'reset' | 'saved' | 'label' | 'aside';

/** A history's steps put aside (`setAside`): only `takeBack` reads it. */
export interface SetAside {
  readonly back: readonly Step[];
  readonly ahead: readonly Step[];
  readonly kept: number;
  readonly savedAt: number | null;
}

/** Was the history saved where it stood when `kept` was put aside? What `saved` said then, read after. */
export function keptSaved(kept: SetAside): boolean {
  return kept.savedAt === kept.back.length;
}

export interface History {
  readonly canUndo: boolean;
  readonly canRedo: boolean;
  /** The step Undo would take back, by its label; null if none. */
  readonly undoLabel: string | null;
  readonly redoLabel: string | null;
  /**
   * Every step kept, oldest first, by label: the done ones, then those undone,
   * the one Redo would do next first. What a list of the history shows.
   */
  readonly labels: readonly string[];
  /** The steps `labels` names, in the same order: a step pushed is the same object here until it goes. Read only. */
  readonly steps: readonly Step[];
  /** How many of `labels` are done: Undo takes back `labels[done - 1]`, Redo does `labels[done]`. */
  readonly done: number;
  /** Is everything as it was last saved or loaded: no step since, or every one undone again? */
  readonly saved: boolean;
  /** A step the tool has already applied: kept, to undo. The steps undone before it go. */
  push(step: Step): void;
  /** `run`, and every step it pushes one step called `label`. Nested groups flatten into the outer one. */
  group<T>(label: string, run: () => T): T;
  /** The last step undone. False if there is none. */
  undo(): boolean;
  /** The step undone last, done again. False if there is none. */
  redo(): boolean;
  /**
   * `step` moved across without being run -- to the done side (`done`: the
   * one Redo would do next becomes the one Undo takes back) or the undone
   * side -- for a step whose undo or redo could not land, or landed late.
   * Told as the move: `'redo'` or `'undo'`. False, nothing moved, if `step`
   * is not the one next to it on the other side.
   */
  place(step: Step, done: boolean): boolean;
  /** Things as they are now are what was just saved. */
  markSaved(): void;
  /** No save holds things as they are any more (the one they were saved as is gone): unsaved until saved again. */
  forgetSaved(): void;
  /** Something else entirely now -- another world loaded, an empty one: no steps either way, and as saved. */
  reset(): void;
  /** Nothing moved, but read it again: a step's label changed, or whether Undo may be used (`'label'`). */
  touch(): void;
  /** How many times its steps are put aside just now: 0 while they are its own (`setAside`, `takeBack`). */
  readonly aside: number;
  /** Every step put aside, and the save's place: the stack empty and as saved, until `takeBack`. Told as `'aside'`. */
  setAside(): SetAside;
  /** What `setAside` kept, back as it was -- the steps since dropped. Told as `'aside'`. */
  takeBack(kept: SetAside): void;
  /** Told after every change above. Returns the undo. */
  on(listener: (event: HistoryEvent) => void): () => void;
}

export interface HistoryOptions {
  /** Steps kept at most. */
  steps?: number;
  /** Characters kept at most, over the steps that give a `size`. */
  size?: number;
}

export function createHistory({ steps = 100, size = 64 << 20 }: HistoryOptions = {}): History {
  const back: Step[] = [];
  const ahead: Step[] = [];
  /** `size` over `back` and `ahead` together. */
  let kept = 0;
  /**
   * Where the last save is, as `back.length` was when things were as saved --
   * the steps behind it -- or null when no step is. Undo and redo move along the
   * same count, so it is clean again exactly when they come back to it.
   */
  let savedAt: number | null = null;
  /** The steps of the group being run, if one is. */
  let grouped: Step[] | null = null;
  const listeners = new Set<(event: HistoryEvent) => void>();
  /** Stacks put aside, not yet taken back. */
  let aside = 0;

  const tell = (event: HistoryEvent): void => {
    for (const listener of listeners) listener(event);
  };

  /** Every step kept, oldest first: the done ones, then those undone, the one Redo would do next first. */
  function all(): Step[] {
    const out = [...back];
    for (let i = ahead.length - 1; i >= 0; i--) out.push(ahead[i]!);
    return out;
  }

  function trim(): void {
    while (back.length > steps || (kept > size && back.length > 0)) {
      const gone = back.shift()!;
      kept -= gone.size ?? 0;
      gone.drop?.();
      // Every place is one fewer now; the save's went with the step if it was the oldest.
      if (savedAt !== null) savedAt = savedAt > 0 ? savedAt - 1 : null;
    }
  }

  /** `next` into the last of `list`, if that one takes it. */
  function merged(list: Step[], next: Step): boolean {
    const last = list[list.length - 1];
    if (!last?.merge) return false;
    const was = last.size ?? 0;
    if (!last.merge(next)) return false;
    if (list === back) kept += (last.size ?? 0) - was;
    return true;
  }

  function push(step: Step): void {
    if (grouped) {
      if (!merged(grouped, step)) grouped.push(step);
      return;
    }
    // Into the step before only straight after it: not over an undo, and not past the save, which would then be wrong.
    if (ahead.length === 0 && savedAt !== back.length && merged(back, step)) {
      trim();
      tell('push');
      return;
    }
    for (const s of ahead) {
      kept -= s.size ?? 0;
      s.drop?.();
    }
    ahead.length = 0;
    back.push(step);
    kept += step.size ?? 0;
    // The save was among the steps ahead, which went: there is no undoing back to it now.
    if (savedAt !== null && savedAt >= back.length) savedAt = null;
    trim();
    tell('push');
  }

  return {
    get canUndo() {
      return back.length > 0;
    },
    get canRedo() {
      return ahead.length > 0;
    },
    get undoLabel() {
      return back[back.length - 1]?.label ?? null;
    },
    get redoLabel() {
      return ahead[ahead.length - 1]?.label ?? null;
    },
    get labels() {
      return all().map((s) => s.label);
    },
    get steps() {
      return all();
    },
    get done() {
      return back.length;
    },
    get saved() {
      return savedAt === back.length;
    },
    push,
    group(label, run) {
      if (grouped) return run();
      const inner: Step[] = (grouped = []);
      try {
        return run();
      } finally {
        grouped = null;
        // Pushed even if `run` threw: what it did before is done, and undoable.
        if (inner.length > 0) push(composite(label, inner));
      }
    },
    undo() {
      const step = back[back.length - 1];
      if (!step) return false;
      step.undo();
      ahead.push(back.pop()!);
      tell('undo');
      return true;
    },
    redo() {
      const step = ahead[ahead.length - 1];
      if (!step) return false;
      step.redo();
      back.push(ahead.pop()!);
      tell('redo');
      return true;
    },
    place(step, done) {
      const [from, to] = done ? [ahead, back] : [back, ahead];
      if (from[from.length - 1] !== step) return false;
      to.push(from.pop()!);
      tell(done ? 'redo' : 'undo');
      return true;
    },
    markSaved() {
      savedAt = back.length;
      tell('saved');
    },
    forgetSaved() {
      savedAt = null;
      tell('saved');
    },
    reset() {
      for (const s of [...back, ...ahead]) s.drop?.();
      back.length = 0;
      ahead.length = 0;
      kept = 0;
      savedAt = 0;
      tell('reset');
    },
    touch() {
      tell('label');
    },
    get aside() {
      return aside;
    },
    setAside() {
      aside++;
      const out: SetAside = { back: [...back], ahead: [...ahead], kept, savedAt };
      back.length = 0;
      ahead.length = 0;
      kept = 0;
      savedAt = 0;
      tell('aside');
      return out;
    },
    takeBack(from) {
      // The steps made while those were aside go: what they alone kept is freed.
      const keep = new Set([...from.back, ...from.ahead]);
      for (const s of [...back, ...ahead]) if (!keep.has(s)) s.drop?.();
      back.splice(0, back.length, ...from.back);
      ahead.splice(0, ahead.length, ...from.ahead);
      kept = from.kept;
      savedAt = from.savedAt;
      aside = Math.max(0, aside - 1);
      tell('aside');
    },
    on(listener) {
      listeners.add(listener);
      return () => void listeners.delete(listener);
    },
  };
}

/** One row of a list of the history -- the History card's -- as it is drawn. */
export interface HistoryRow {
  /** Steps done when it is the last: 0 is the start. */
  n: number;
  label: string;
  /** Done, the last done (Undo takes it back), or undone (Redo would do it again). */
  state: 'done' | 'current' | 'undone';
  /** What a click on it does. */
  tip: string;
}

/**
 * The rows a list of `labels`, `done` of them done, draws (the History card):
 * the start, then every step, newest last -- read from the history whenever it
 * says it changed, so a push after undos draws the steps that went gone and
 * the new one in their place.
 */
export function historyRows(labels: readonly string[], done: number): HistoryRow[] {
  const steps = (n: number): string => `${n} ${n === 1 ? 'step' : 'steps'}`;
  const state = (n: number): HistoryRow['state'] => (n === done ? 'current' : n < done ? 'done' : 'undone');
  return [
    { n: 0, label: 'Start', state: state(0), tip: done === 0 ? 'As history began: every step undone' : 'Undo every step, back to where history began' },
    ...labels.map((label, i): HistoryRow => {
      const n = i + 1;
      return {
        n,
        label,
        state: state(n),
        tip: n === done ? 'The last step done: Undo takes it back' : n < done ? `Undo back to here: ${steps(done - n)}` : `Redo up to here: ${steps(n - done)}`,
      };
    }),
  ];
}

/** Several steps as one: done first to last, undone last to first. */
function composite(label: string, steps: readonly Step[]): Step {
  return {
    label,
    parts: steps,
    size: steps.reduce((sum, s) => sum + (s.size ?? 0), 0),
    undo() {
      for (let i = steps.length - 1; i >= 0; i--) steps[i]!.undo();
    },
    redo() {
      for (const s of steps) s.redo();
    },
    drop() {
      for (const s of steps) s.drop?.();
    },
  };
}
