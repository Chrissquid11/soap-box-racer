/**
 * The labels of one entity or several, as a control (Docs/ecs.md §13), shaped
 * as the tags' (`tags-drop.ts`): a button that says which they have -- "None",
 * "spawn", "spawn +2" (`dropText`) -- and drops down every label in use in the world with
 * a tick each, on all, on some (half), on none, and at the bottom a field that
 * adds a new one. A tick or an add is one step for every one; the list stays
 * down until a press elsewhere or Esc.
 *
 * - **Labels are free text** (`Labels`, an object component): the list is what
 *   the world's entities carry now, so a label taken off the last entity that
 *   had it leaves the list. `Labels` is put on with an entity's first label and
 *   taken off with its last: no entity needs the component to have none.
 * - **Typed**, a label ends at Enter or at a comma, and goes on every one; the
 *   list is built again with it ticked and the field keeps the focus, so labels
 *   can be typed one after another.
 * - **It outlives its button** as the tags' does: the same state, kept by the
 *   place (`TagsState`), with whether the field had the focus.
 */
import { type Entity, type World } from '@vibe/engine';
import { onCloseRequest, textInput } from './fields.ts';
import { addLabels, labelsOf, removeLabel } from './labels.ts';
import { times, typedLabels } from './multi.ts';
import { el } from './shell.ts';
import { dropUnder } from './drop.ts';
import { dropButton, dropText, shutTags, type TagsHost, type TagsState } from './tags-drop.ts';

/** A place's labels drop-down: which is down, and whether its field is being typed in, kept as the button is built again. */
export interface LabelsState extends TagsState {
  /** The field had the focus: it gets it back when the list is shown again. */
  typing: boolean;
}

export const labelsState = (root: HTMLElement): LabelsState => ({ root, open: null, shown: null, typing: false });

/** Up again, none down. */
export function shutLabels(state: LabelsState): void {
  state.typing = false;
  shutTags(state);
}

/** Every label some living entity carries, in the order first met, then those of `es`. */
function allLabels(world: World, es: readonly Entity[]): string[] {
  const seen = new Set<string>();
  for (const e of es) for (const label of labelsOf(world, e)) seen.add(label);
  for (let i = 1; i < world.extent; i++) {
    const e = i as Entity;
    if (world.alive(e)) for (const label of labelsOf(world, e)) seen.add(label);
  }
  return [...seen].sort((a, b) => a.localeCompare(b));
}

/**
 * The control for `es`: its button, and the list it drops down under itself.
 * `at` tells this place's buttons apart, as the tags' does.
 */
export function labelsDrop(host: TagsHost, es: readonly Entity[], state: LabelsState, at = 0): HTMLButtonElement {
  const { world } = host;
  const many = es.length;

  // What it says: the labels every one has, then those only some have.
  const counts = new Map<string, number>();
  for (const e of es) for (const label of new Set(labelsOf(world, e))) counts.set(label, (counts.get(label) ?? 0) + 1);
  const on = [...counts].filter(([, n]) => n === many).map(([l]) => l);
  const some = [...counts].filter(([, n]) => n < many).map(([l]) => l);
  const said = dropText(on, some);
  const button = dropButton(said, `${said.all || 'No labels'} · every label in use, a tick each, and a field at the bottom to add one${many > 1 ? ` to all ${many} selected` : ''}`);

  /** `labels` onto every one that has not got each (`labels.ts`, the tools' path too): one step. */
  const add = (labels: readonly string[]): void => {
    const n = addLabels(world, es, labels).length;
    host.changed(times(labels.length === 1 ? `Add label ${labels[0]}` : `Add ${labels.length} labels`, n));
  };
  /** `label` off every one that has it; an entity's last gone, `Labels` with it. */
  const remove = (label: string): void => host.changed(times(`Remove label ${label}`, removeLabel(world, es, label).length));

  const list = el('div', 'ed-card ed-menu ed-ticks ed-labels-list');
  /** The ticks as the world is now, and the field under them. */
  const fill = (): void => {
    list.replaceChildren(el('div', 'ed-menu-title', many > 1 ? `Labels · all ${many}` : 'Labels'));
    for (const label of allLabels(world, es)) {
      const count = counts.get(label) ?? 0;
      const row = el('label', 'ed-menu-item ed-tick');
      const box = el('input');
      box.type = 'checkbox';
      box.checked = count === many;
      box.indeterminate = count > 0 && count < many;
      box.title = count === many ? (many > 1 ? `On all ${many}` : 'On') : count > 0 ? `On ${count} of ${many}: a tick puts it on all` : many > 1 ? `A tick puts it on all ${many}` : 'A tick puts it on';
      box.addEventListener('change', () => {
        state.typing = false;
        if (box.checked) add([label]);
        else remove(label);
      });
      row.append(box, el('span', 'ed-tick-name', label));
      if (count > 0 && count < many) row.append(el('span', 'ed-dim ed-count', `${count} of ${many}`));
      list.append(row);
    }
    if (list.childElementCount === 1) list.append(el('div', 'ed-menu-note', 'No labels in this world yet'));

    // A new one, at the bottom: Enter or a comma adds it, ticked, and the field keeps the focus for the next.
    const form = el('form', 'ed-labels-add');
    const field = textInput('', many > 1 ? `Add a label to all ${many}…` : 'Add a label…');
    form.append(field);
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const { labels } = typedLabels(field.value, true);
      if (labels.length === 0) return;
      state.typing = true;
      add(labels);
    });
    field.addEventListener('input', () => {
      if (!field.value.includes(',')) return;
      const { labels, rest } = typedLabels(field.value, false);
      field.value = rest;
      if (labels.length === 0) return;
      state.typing = true;
      add(labels);
    });
    // Esc, as the browser's close request, takes the list up: the editor's keys are not heard while typing.
    let unwatch = (): void => {};
    field.addEventListener('focus', () => {
      unwatch();
      unwatch = onCloseRequest(() => shutLabels(state));
    });
    field.addEventListener('blur', () => unwatch());
    list.append(form);
    if (state.typing) queueMicrotask(() => field.isConnected && field.focus());
  };
  const show = (): void => {
    fill();
    state.shown = dropUnder(state.root, button, list, () => shutLabels(state));
  };

  // mcp: ui -- the labels list opened
  button.addEventListener('click', () => {
    const was = state.open === at;
    shutLabels(state);
    if (was) return;
    state.open = at;
    show();
  });
  // Down already, from the button this one replaces: that one's list goes now, and this one's comes once the button is in place.
  if (state.open === at) {
    state.shown?.();
    state.shown = null;
    queueMicrotask(() => {
      if (state.open === at && !state.shown && button.isConnected) show();
    });
  }
  return button;
}

/** Down, with the field to type in: "Add label…" from the menu. The place builds its button again, which shows it. */
export function openLabels(state: LabelsState, at = 0): void {
  state.open = at;
  state.typing = true;
}
