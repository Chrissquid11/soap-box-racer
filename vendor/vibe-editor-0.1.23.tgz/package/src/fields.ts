/**
 * The editor's inputs: a number that can be typed, stepped or scrubbed
 * (`numberField`), a line of text kept as it is left (`textField`), and a line
 * of text edited in place of what it names (`textEdit`).
 *
 * - **A number** is a label and an input. Drag across the label to scrub the
 *   value -- Shift for fine, Ctrl or Cmd for coarse -- each pixel written live;
 *   click it to type. The arrow keys step it (the browser's own, on a number
 *   input). Typing writes as it goes; Enter, a step, leaving the field or the
 *   end of a scrub is `commit` -- one step of history however many writes.
 * - **A field of several** -- the same value of every entity selected -- shows
 *   it when they agree and `—` when they do not, the values on hover. Typed,
 *   every one is set to it; scrubbed or stepped by the arrow keys, each moves
 *   by as much from its own (`move`), so a mixed field stays mixed. A step is
 *   told from typing by its event: the browser's own step is a plain `Event`,
 *   typing an `InputEvent`.
 * - **Enter is a form's submit**, and Esc the browser's close request (a
 *   `CloseWatcher`), not keys listened for: the editor's keys are MrDebug's,
 *   and a field never listens for a key of its own (CLAUDE.md). Enter also lets
 *   go of the field, so the editor's keys work again. Each form is `noValidate`:
 *   a number past its `max` is clamped by the field, never refused by the
 *   browser's bubble over the editor.
 */
import { el } from './dom.ts';
import { MIXED } from './multi.ts';

export interface NumberOptions {
  /** The label: what is dragged to scrub. */
  label: string;
  /** Its class beside `ed-scrub`, to colour an axis. */
  labelClass?: string;
  /**
   * The value shown; null for several that differ -- the field shows `—`, and
   * `note` on hover; undefined for none set -- the field empty, `placeholder`
   * grey in it (an asset option's default), and `fallback` what a scrub or a
   * step goes on from.
   */
  value: number | null | undefined;
  /** While the values differ: what they are, on hover. */
  note?: string;
  /** One press of an arrow key; a scrub moves this much every ten pixels. */
  step: number;
  /** Whole numbers only: an integer field. */
  integer?: boolean;
  min?: number;
  max?: number;
  /** Decimal places shown. Default 5. */
  digits?: number;
  /** The title on the label and the input. */
  title?: string;
  /**
   * Grey in the empty field while the values agree: a default not set (an
   * asset option's). The mixed marker takes its place while they differ, and
   * it comes back when they agree again.
   */
  placeholder?: string;
  /**
   * What the empty field stands for -- the default not set: a scrub begins
   * from it, and focused the field holds it, selected, so typing replaces it
   * and an arrow key steps from it; left unchanged, the field is empty again.
   */
  fallback?: number;
  /** Read only: shown, not editable or scrubbable. */
  fixed?: boolean;
  /** Each change as it happens: a key typed, a pixel scrubbed, a step. */
  set(value: number): void;
  /**
   * A field of several whose values differ, scrubbed or stepped: each moved by
   * `by` from its own -- since the scrub began -- so they stay apart and all
   * move. Typing still sets every one (`set`). Left out, such a scrub sets them
   * all, from 0.
   */
  move?(by: number): void;
  /** The change is done: one step of history. */
  commit(): void;
}

export interface NumberField {
  /** The label and the input, side by side in a grid or a line. */
  readonly label: HTMLElement;
  readonly input: HTMLInputElement;
  /** The value as it is now -- null for several that differ, `note` on hover; undefined for none set -- unless the field is being typed in or scrubbed. */
  show(value: number | null | undefined, note?: string): void;
}

/** A value as a person reads it: whole numbers whole, fractions to `digits` places. */
export const shown = (value: number, digits = 5): string => (Number.isInteger(value) ? String(value) : String(Number(value.toFixed(digits))));

/** Pixels a press has to travel along the label before it is a scrub and not a click. */
const SCRUB = 3;

/** The one field being scrubbed, if any: what `show` leaves alone. */
let scrubbing: HTMLInputElement | null = null;

export function numberField(options: NumberOptions): NumberField {
  const { step, integer = false, min = -Infinity, max = Infinity, digits = 5 } = options;
  const label = el('span', options.labelClass ? `ed-scrub ${options.labelClass}` : 'ed-scrub', options.label);
  // A form of its own, so Enter is its submit -- never the browser's validation bubble over the editor: a
  // value past `max` is clamped (`clamp`), not refused with "Value must be less than or equal to 180".
  const form = el('form', 'ed-field');
  form.noValidate = true;
  const input = el('input', 'ed-input');
  input.type = 'number';
  input.step = String(step);
  if (Number.isFinite(min)) input.min = String(min);
  if (Number.isFinite(max)) input.max = String(max);
  input.value = options.value === null || options.value === undefined ? '' : shown(options.value, digits);
  if (options.title) label.title = input.title = options.title;
  form.append(input);
  const clamp = (value: number): number => Math.min(max, Math.max(min, integer ? Math.round(value) : value));

  /** The values it stands for differ: no number, the marker, and what they are on hover. Touched only as that changes. */
  let mixed = false;
  let noted: string | undefined;
  // Its grey default, until the values differ.
  if (options.placeholder) input.placeholder = options.placeholder;
  const mark = (value: number | null | undefined, note?: string): void => {
    const now = value === null;
    if (now === mixed && (!now || note === noted)) return;
    mixed = now;
    noted = now ? note : undefined;
    input.classList.toggle('ed-mixed', now);
    input.placeholder = now ? MIXED : options.placeholder ?? '';
    const title = now && note ? (options.title ? `${options.title}\n${note}` : note) : options.title ?? '';
    label.title = input.title = title;
  };
  mark(options.value, options.note);

  if (options.fixed) {
    input.disabled = true;
    label.classList.add('ed-fixed');
    const show = (value: number | null | undefined, note?: string): void => {
      mark(value, note);
      input.value = value === null || value === undefined ? '' : shown(value, digits);
    };
    return { label: withField(label, form), input, show };
  }

  input.addEventListener('input', (event) => {
    const value = Number(input.value);
    if (input.value === '' || Number.isNaN(value)) return;
    // The arrow keys on values that differ: each a step from its own. Stepped from empty, the browser goes from 0 -- up past it, down to it or under.
    if (mixed && options.move && !(event instanceof InputEvent)) {
      options.move(value > 0 ? step : -step);
      input.value = '';
      return;
    }
    // Typed: every one is this now.
    mark(value);
    options.set(clamp(value));
  });
  // A step of the arrow keys, or the field left with a new value -- shown as it was taken, past `max` clamped.
  input.addEventListener('change', () => {
    const value = Number(input.value);
    if (input.value !== '' && !Number.isNaN(value) && clamp(value) !== value) input.value = shown(clamp(value), digits);
    options.commit();
  });
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    input.blur();
  });
  // None set: focused, the field holds what it stands for, selected -- typed over, or stepped from by an arrow
  // key -- and left as it was, it is empty again, its grey default back; no `change`, so no commit.
  // Selected however it came: by Tab at once; by a click after the press has put its caret, which it does
  // after the focus (so a turn later), and its release kept from undoing it where a browser would.
  const { fallback } = options;
  if (fallback !== undefined) {
    let filled = false;
    let clicked = false;
    input.addEventListener('focus', () => {
      if (input.value !== '' || mixed) return;
      filled = true;
      input.value = shown(fallback, digits);
      input.select();
      setTimeout(() => {
        if (filled && document.activeElement === input && input.value === shown(fallback, digits)) input.select();
      }, 0);
    });
    input.addEventListener('mousedown', () => void (clicked = document.activeElement !== input));
    input.addEventListener('mouseup', (event) => {
      if (!clicked) return;
      clicked = false;
      // The click that focused it: its release does not put a caret in the default just selected.
      if (filled && input.value === shown(fallback, digits)) {
        event.preventDefault();
        input.select();
      }
    });
    input.addEventListener('blur', () => {
      if (filled && input.value === shown(fallback, digits)) input.value = '';
      filled = false;
    });
  }

  // ---------------------------------------------------------------- scrubbing

  let press: { id: number; x: number; value: number; from: number; moving: boolean } | null = null;
  label.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    // An empty field: from what it stands for, none set -- or, for values that differ, from nothing moved.
    const value = input.value === '' ? (mixed ? 0 : options.fallback ?? 0) : Number(input.value);
    const from = Number.isNaN(value) ? 0 : value;
    press = { id: event.pointerId, x: event.clientX, value: from, from, moving: false };
    label.setPointerCapture(event.pointerId);
  });
  label.addEventListener('pointermove', (event) => {
    if (!press || press.id !== event.pointerId) return;
    const dx = event.clientX - press.x;
    if (!press.moving) {
      if (Math.abs(dx) < SCRUB) return;
      press.moving = true;
      scrubbing = input;
      // Typing elsewhere ends here: that field commits as it lets go.
      (document.activeElement as HTMLElement | null)?.blur?.();
    }
    press.x = event.clientX;
    // Read every move, so letting go of Shift halfway goes on from where it got to.
    const rate = event.shiftKey ? 0.1 : event.ctrlKey || event.metaKey ? 10 : 1;
    press.value += (dx * step * rate) / 10;
    // Values that differ: each moved by as much, and the field says by how much.
    if (mixed && options.move) {
      const by = press.value - press.from;
      input.placeholder = `${by < 0 ? '−' : '+'}${shown(Math.abs(by), digits)}`;
      options.move(by);
      return;
    }
    const value = clamp(press.value);
    input.value = shown(value, digits);
    options.set(value);
  });
  const release = (event: PointerEvent): void => {
    if (!press || press.id !== event.pointerId) return;
    const moved = press.moving;
    press = null;
    scrubbing = null;
    if (label.hasPointerCapture(event.pointerId)) label.releasePointerCapture(event.pointerId);
    input.placeholder = mixed ? MIXED : options.placeholder ?? '';
    if (moved) options.commit();
    else if (event.type === 'pointerup') {
      // A click: the field, to type in.
      input.focus();
      input.select();
    }
  };
  label.addEventListener('pointerup', release);
  label.addEventListener('pointercancel', release);

  return {
    label: withField(label, form),
    input,
    show(value, note) {
      // Typed in or scrubbed: the text is the person's, but what the values are now is still said on hover.
      if (input === document.activeElement || input === scrubbing) {
        if (mixed && value === null) mark(value, note);
        return;
      }
      mark(value, note);
      const text = value === null || value === undefined ? '' : shown(value, digits);
      if (input.value !== text) input.value = text;
    },
  };
}

/** The label with its form after it, as one fragment to append: grid cells stay label, field, label, field. */
function withField(label: HTMLElement, form: HTMLElement): HTMLElement {
  const both = el('span', 'ed-pair');
  both.append(label, form);
  return both;
}

/** What a browser that has one gives for a close request: Esc on a desktop. Not in TypeScript's DOM types yet. */
interface CloseWatcherLike {
  onclose: (() => void) | null;
  destroy(): void;
}
declare const CloseWatcher: { new (): CloseWatcherLike } | undefined;

/**
 * Esc as the browser's close request, where there is one (Chrome, Edge): `run`
 * on the first, then nothing. Made in the click that opened what it closes.
 * Returns the undo, for when that is done some other way.
 */
export function onCloseRequest(run: () => void): () => void {
  const watcher = typeof CloseWatcher === 'function' ? new CloseWatcher() : null;
  if (!watcher) return () => {};
  watcher.onclose = run;
  return () => watcher.destroy();
}

/** A text input as every one of the editor's is: no spellchecking, a placeholder if given. */
export function textInput(value: string, placeholder?: string): HTMLInputElement {
  const input = el('input', 'ed-input');
  input.type = 'text';
  input.value = value;
  input.spellcheck = false;
  if (placeholder) input.placeholder = placeholder;
  return input;
}

/**
 * A line of text, saved when Enter is pressed or the field is left with it
 * changed. `mixed`, for several that differ: empty, `—` in its place, and the
 * note on hover.
 */
export function textField(value: string, save: (text: string) => void, mixed?: { note: string }): HTMLFormElement {
  const form = el('form', 'ed-line');
  form.noValidate = true;
  const input = textInput(value, mixed ? MIXED : undefined);
  if (mixed) {
    input.classList.add('ed-mixed');
    input.title = mixed.note;
  }
  form.append(input);
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    input.blur();
  });
  input.addEventListener('change', () => save(input.value));
  return form;
}

export interface TextOptions {
  value: string;
  placeholder?: string;
  /** Enter, or leaving the field: the text as typed. */
  commit(text: string): void;
  /** Esc: nothing changes. */
  cancel(): void;
}

/**
 * A line of text being edited in place, focused and selected: Enter or leaving
 * it commits, Esc cancels. Either way it is done -- the caller takes it away.
 */
export function textEdit({ value, placeholder, commit, cancel }: TextOptions): HTMLFormElement {
  const form = el('form', 'ed-rename');
  const input = textInput(value, placeholder);
  form.append(input);
  let done = false;
  const finish = (keep: boolean): void => {
    if (done) return;
    done = true;
    unwatch();
    if (keep) commit(input.value);
    else cancel();
  };
  const unwatch = onCloseRequest(() => finish(false));
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    finish(true);
  });
  input.addEventListener('blur', () => finish(true));
  queueMicrotask(() => {
    input.focus();
    input.select();
  });
  return form;
}
