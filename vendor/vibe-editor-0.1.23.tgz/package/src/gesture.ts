/**
 * A gizmo gesture on several entities at once: the maths, apart from three and
 * the world, so node tests it (Docs/ecs.md §13).
 *
 * The gizmo drags a stand-in at the first selected entity's world transform
 * (`gizmo.ts`). Every other entity the gesture moves follows what the
 * stand-in did, from where it was itself when the gesture began:
 *
 * - **Move**: by the same world delta.
 * - **Rotate**: about the stand-in's pivot -- its position orbits it, and its
 *   rotation turns by as much.
 * - **Scale**: about the pivot along the stand-in's own axes -- its position
 *   spread out or drawn in by as much -- and its own scale times the same
 *   factors. Exact for a uniform scale; for any other, the factors go along
 *   each entity's own axes, the nearest the ECS can hold: it has no skew.
 *
 * Each entity once: one under another that is also selected goes with it
 * (`movers`), or it would move twice.
 *
 * Poses are world transforms as plain numbers -- position, quaternion (x y z w),
 * scale -- composed as Docs/ecs.md §8 composes them. `toLocal` takes one back
 * into a parent's space, as a whole.
 *
 * **A gesture lands in the parent's space, never through the world**
 * (`gestureLocal`): going to the world and back moves what the gesture never
 * touched by a bit or two -- more the further out the parent is, as
 * `WorldTransform` is 32 bits (0.9 → 0.8999966 150 m out) -- and an instance
 * compares its values with its prefab's exactly, so each such bit would be an
 * override, and a line in a file once applied. So a move is the local
 * position as it began plus the drag's delta mapped into the parent's frame
 * (turned back, divided by its scale: never through its position); a turn the
 * local rotation as it began times the drag's turn seen from the parent; a
 * scale the local scale as it began times the drag's factor. A channel the
 * gesture does not move is not written at all, an axis it does not move gets
 * an exact 0 or ×1, and what it moves carries no noise from how far out it
 * is. The inspector's World fields write the same way (`vectorToLocal`,
 * `turnToLocal`).
 *
 * **In the frame it is made in** (`GestureFrame`): a drag along the world's
 * axes is taken as a world delta; one along the entity's own (Local, `X`) as
 * a delta in its own axes -- the stand-in's turned back out of it -- carried
 * into the parent's space by the entity's own local rotation, never through
 * its world one, whose 32 bits do not turn back exactly (a Local X drag 3 m
 * out would leave `pz 0 → -8e-9`). A turn the same: Local, the stand-in's
 * turn in its own axes, after the local rotation. In that frame each part of
 * the drag that is only noise next to the gesture's own size -- the drag's
 * length, the snap grid's distance from the origin while it snaps, 1 for a
 * quaternion -- is an exact 0 (`cleaned`), and each value written is settled
 * against where it began by the same size (`settled`). So what the gesture
 * leaves alone in its frame is left alone: World, every world axis it does
 * not move; Local, every own axis -- and so every local one under a child
 * not turned, or turned about that axis alone. An axis the frame's move
 * really reaches (a world X drag under a turned parent: `px` and `pz`) moves.
 *
 * **A rotation is compared as one**: `q` and `-q` are the same, so a turn
 * back to where it began -- a full turn, a sign flipped -- writes the
 * rotation it began with, to the bit (`sameRotation`).
 */

export type Vec3 = [number, number, number];
export type Quat = [number, number, number, number];

export interface Pose {
  p: Vec3;
  q: Quat;
  s: Vec3;
}

/** The gizmo's modes, as three's TransformControls names them: what a gesture does. */
export type GizmoMode = 'translate' | 'rotate' | 'scale';

/** A `Transform`'s ten numbers, in the order a pose's are kept and put back. */
export const POSE_FIELDS = ['px', 'py', 'pz', 'qx', 'qy', 'qz', 'qw', 'sx', 'sy', 'sz'] as const;

/**
 * Which of a pose's channels a gesture writes: the one dragged (`first`) its
 * mode's alone; another following it, its position too, as it orbits or is
 * spread about the pivot (`follow`).
 */
export function written(mode: GizmoMode, first: boolean): { p: boolean; q: boolean; s: boolean } {
  if (mode === 'translate') return { p: true, q: false, s: false };
  return { p: !first, q: mode === 'rotate', s: mode === 'scale' };
}

/** The axes a gizmo drags along: the world's, or the selection's own. */
export type GizmoSpace = 'world' | 'local';

/**
 * The frame a drag is made in, as TransformControls makes it: its axes
 * (`space` -- a scale is always the entity's own, a free turn or move the
 * world's) and whether it snaps -- a snapped position is rounded in that
 * frame, its noise as large as the grid's distance from the origin.
 */
export interface GestureFrame {
  space: GizmoSpace;
  snapped: boolean;
  /**
   * The handle dragged, as TransformControls names it (`'X'`, `'XY'`,
   * `'XYZ'`…): a move along the frame's axes it has is the gesture itself,
   * however small -- never cleaned as noise, snapped or not, near or far.
   * Left out: every axis cleaned against the drag's size.
   */
  axis?: string;
}

const WORLD: GestureFrame = { space: 'world', snapped: false };

/** Four of 32 bits' steps, relative: two values this close to each other are the same value, stored. */
const STEP = 4 * 2 ** -23;

/** Each of `v` that is only noise next to `size` (within a few 32-bit steps of it) an exact 0 -- but those `kept` (a drag's own axes). */
export const cleaned = <T extends number[]>(v: T, size: number, kept?: readonly boolean[]): T => v.map((x, i) => (kept?.[i] !== true && Math.abs(x) <= STEP * size ? 0 : x)) as T;

/** The axes of its frame a drag of `frame`'s handle is along: X, Y and Z, each kept or not. */
const alongOf = (frame: GestureFrame): boolean[] | undefined => (frame.axis === undefined ? undefined : [...'XYZ'].map((a) => frame.axis!.includes(a)));

/** Are `a` and `b` one rotation, to a few 32-bit steps -- `q` and `-q` alike? */
export function sameRotation(a: readonly number[], b: readonly number[]): boolean {
  const s = a[0]! * b[0]! + a[1]! * b[1]! + a[2]! * b[2]! + a[3]! * b[3]! < 0 ? -1 : 1;
  for (let i = 0; i < 4; i++) if (Math.abs(a[i]! - s * b[i]!) > STEP) return false;
  return true;
}

/**
 * The rotation `q` to write over `was`: `was` itself, to the bit, if they are
 * one rotation; else `q` on `was`'s side (`q` and `-q` are one rotation: the
 * numbers nearer it), each of its four only noise from `was`'s put back.
 */
export function settledRotation(q: Quat, was: Quat): Quat {
  if (sameRotation(q, was)) return [was[0], was[1], was[2], was[3]];
  const s = q[0] * was[0] + q[1] * was[1] + q[2] * was[2] + q[3] * was[3] < 0 ? -1 : 1;
  return [settled(s * q[0], was[0], 1), settled(s * q[1], was[1], 1), settled(s * q[2], was[2], 1), settled(s * q[3], was[3], 1)];
}

const length = (v: readonly number[]): number => Math.hypot(...v);

/**
 * `value`, or `was` if `value` is only float noise away from it -- within a
 * few 32-bit steps of `was`, or of `around` where the numbers it came from were
 * larger (a difference of two). Relative, never an absolute floor: a deliberate
 * 1e-6 nudge, or a scale on an entity a millionth of a metre big, is kept.
 */
export const settled = (value: number, was: number, around = 0): number => (Math.abs(value - was) <= STEP * Math.max(Math.abs(was), Math.abs(around)) ? was : value);

/**
 * A delta of the world -- a direction and a length, not a point -- in the
 * space of a parent at `parent`: turned back and divided by its scale, never
 * through its position, so how far out the parent is brings no noise in, and
 * an axis the delta leaves at 0 under a parent turned about it stays 0.
 * Unchanged with no parent; null under one scaled to nothing on an axis.
 */
export function vectorToLocal(parent: Pose | null, d: Vec3): Vec3 | null {
  if (!parent) return d;
  return scaledDown(rotate(invert(normalize(parent.q)), d), parent.s);
}

/** `v` divided by a parent's scale `s`, axis by axis: null if it is nothing on one. */
function scaledDown(v: Vec3, s: Vec3): Vec3 | null {
  if (s[0] === 0 || s[1] === 0 || s[2] === 0) return null;
  return [v[0] / s[0], v[1] / s[1], v[2] / s[2]];
}

/** A turn of the world (one applied after, `turn · q`) as the same turn seen from a parent at `parent`: P⁻¹ · turn · P. */
export function turnToLocal(parent: Pose | null, turn: Quat): Quat {
  if (!parent) return turn;
  const p = normalize(parent.q);
  return multiply(invert(p), multiply(turn, p));
}

/**
 * The ten numbers (`POSE_FIELDS`) to write into the `Transform` of an
 * entity a gesture moves -- the stand-in gone from `from` to `to` -- that was
 * `startLocal` locally and `startWorld` in the world as it began, under a
 * parent at `parent` (its world pose; null for none). `first` is the entity
 * the stand-in is on; any other follows it (`follow`). `frame` is the drag's
 * (the world's axes, unsnapped, if not given). Worked out in the parent's
 * space, from `startLocal`: what the gesture does not move in its frame is
 * `startLocal`'s, to the bit. Null under a parent scaled to nothing.
 */
export function gestureLocal(
  mode: GizmoMode, from: Pose, to: Pose, startWorld: Pose, startLocal: readonly number[], parent: Pose | null, first: boolean, frame: GestureFrame = WORLD,
): number[] | null {
  const out = [...startLocal];
  const channels = written(mode, first);
  /** The entity's own axes are the drag's: the stand-in's, which is on it. */
  const own = first && frame.space === 'local';
  const startQ: Quat = [startLocal[3]!, startLocal[4]!, startLocal[5]!, startLocal[6]!];
  if (channels.p) {
    // Snapped, the stand-in's position is rounded in the drag's frame: noise the size of its distance from the origin.
    const grid = frame.snapped ? length(from.p) : 0;
    let d: Vec3 | null;
    // The drag's own axes are never noise: only the others are cleaned (a snapped step far out is under the grid's noise floor).
    const along = mode === 'translate' ? alongOf(frame) : undefined;
    if (own && mode === 'translate') {
      // The drag in the stand-in's own axes, then into the parent's by the local rotation: P⁻¹·(P·L)·v is L·v, with no 32-bit turn undone.
      const delta = rotate(invert(normalize(from.q)), sub(to.p, from.p));
      const v = rotate(normalize(startQ), cleaned(delta, Math.max(length(delta), grid), along));
      d = parent ? scaledDown(v, parent.s) : v;
    } else {
      const delta = followDelta(mode, from, to, startWorld);
      // In the world's axes: the handle's are those only in World space.
      d = vectorToLocal(parent, cleaned(delta, Math.max(length(delta), grid), frame.space === 'world' ? along : undefined));
    }
    if (!d) return null;
    // Settled by the drag's own size where its axes are known -- the snapped grid's noise is cleaned off the others
    // already -- else by the grid's too.
    const size = along ? length(d) : Math.max(length(d), parent ? grid / Math.min(...parent.s.map(Math.abs)) : grid);
    for (let i = 0; i < 3; i++) out[i] = settled(startLocal[i]! + d[i]!, startLocal[i]!, size);
  }
  if (channels.q) {
    // Local: the stand-in's turn in its own axes, after the local rotation (P⁻¹·(P·L)·t is L·t). World: the world's turn seen from the parent.
    const q = own
      ? normalize(multiply(startQ, cleaned(multiply(invert(normalize(from.q)), normalize(to.q)), 1)))
      : normalize(multiply(turnToLocal(parent, cleaned(multiply(normalize(to.q), invert(normalize(from.q))), 1)), startQ));
    const settledQ = settledRotation(q, startQ);
    for (let i = 0; i < 4; i++) out[3 + i] = settledQ[i]!;
  }
  if (channels.s) {
    // The world's scale is the parent's times the local, axis by axis (§8: no skew): the drag's factor is the local's.
    const k = ratio(to.s, from.s);
    for (let i = 0; i < 3; i++) out[7 + i] = settled(startLocal[7 + i]! * k[i]!, startLocal[7 + i]!);
  }
  return out;
}

/**
 * The inspector's World mode, one axis of the world position typed: the local
 * position `local` moved by that axis's change alone (`value` less `at`, the
 * world position now), seen from the parent -- a local axis the change does
 * not reach is `local`'s, to the bit. Null under a parent scaled to nothing.
 */
export function worldAxisLocal(parent: Pose | null, local: Vec3, at: Vec3, i: number, value: number): Vec3 | null {
  const d: Vec3 = [0, 0, 0];
  d[i] = value - at[i]!;
  const v = vectorToLocal(parent, d);
  if (!v) return null;
  // Settled by the change's own size, as a gizmo drag is: an axis it reaches by noise alone stays as it was.
  const size = length(v);
  return [settled(local[0] + v[0], local[0], size), settled(local[1] + v[1], local[1], size), settled(local[2] + v[2], local[2], size)];
}

/**
 * The inspector's World mode, a world angle typed: the local rotation `local`
 * turned by the turn that takes the world rotation from `was` to `to`, seen
 * from the parent; each of its four only noise from `local`'s put back, and
 * `local` itself if it is the same rotation (`settledRotation`).
 */
export function worldTurnLocal(parent: Pose | null, local: Quat, was: Quat, to: Quat): Quat {
  const turn = turnToLocal(parent, cleaned(multiply(normalize(to), invert(normalize(was))), 1));
  return settledRotation(normalize(multiply(turn, local)), local);
}

/**
 * The inspector's World mode, a world scale typed: the local scale `local`
 * times the factor that takes the world's from `was` to `to`, axis by axis --
 * the world's is the parent's times the local (§8) -- an axis not changed
 * left as it was. From nothing no factor gets anywhere: the local scale the
 * parent's gives it.
 */
export function worldScaleLocal(parent: Pose | null, local: Vec3, was: Vec3, to: Vec3): Vec3 {
  const one = (i: number): number => {
    if (to[i] === was[i]) return local[i]!;
    if (was[i] === 0) return parent && parent.s[i] !== 0 ? to[i]! / parent.s[i]! : to[i]!;
    return settled((local[i]! * to[i]!) / was[i]!, local[i]!);
  };
  return [one(0), one(1), one(2)];
}

/**
 * How far an entity that was at `start` moves in the world, the stand-in gone
 * from `from` to `to`: `follow`'s position less `start`'s, worked out as a
 * difference from the first -- an axis the gesture leaves alone gets an exact
 * 0, not a large number less itself.
 */
function followDelta(mode: GizmoMode, from: Pose, to: Pose, start: Pose): Vec3 {
  const moved = sub(to.p, from.p);
  if (mode === 'translate') return moved;
  const r = sub(start.p, from.p);
  const was = normalize(from.q);
  const local = rotate(invert(was), r);
  const now = normalize(to.q);
  const there = mode === 'rotate' ? rotate(now, local) : rotate(now, scaled(local, ratio(to.s, from.s)));
  return add(moved, sub(there, r));
}

/**
 * The entities of `selected` with no selected ancestor -- what a gesture moves
 * itself -- in the selection's order. The others are under one of these, and
 * go with it. `parentOf` gives 0 for none.
 */
export function movers<E extends number>(selected: readonly E[], parentOf: (e: E) => E): E[] {
  const chosen = new Set<number>(selected);
  return selected.filter((e) => {
    // Bounded by the selection's size: a cycle, which the world never makes, cannot hang it.
    let a = parentOf(e);
    for (let n = 0; a !== 0 && n <= selected.length + 64; n++, a = parentOf(a)) if (chosen.has(a)) return false;
    return true;
  });
}

/**
 * Where an entity that was at `start` is now, the stand-in having gone from
 * `from` to `to` under `gesture`.
 */
export function follow(gesture: GizmoMode, from: Pose, to: Pose, start: Pose): Pose {
  if (gesture === 'translate') {
    // Only the position: rotation and scale as they were, to the bit.
    return { p: add(start.p, sub(to.p, from.p)), q: [...start.q], s: [...start.s] };
  }
  // Where it was from the pivot, in the stand-in's own axes as the gesture began.
  const was = normalize(from.q);
  const local = rotate(invert(was), sub(start.p, from.p));
  const now = normalize(to.q);
  if (gesture === 'rotate') {
    const turn = multiply(now, invert(was));
    return { p: add(to.p, rotate(now, local)), q: normalize(multiply(turn, start.q)), s: [...start.s] };
  }
  const k = ratio(to.s, from.s);
  return { p: add(to.p, rotate(now, scaled(local, k))), q: [...start.q], s: scaled(start.s, k) };
}

/**
 * A world pose as the local one of an entity hanging from a parent at `parent`
 * (its world pose): undone the way Docs/ecs.md §8 composes it -- position,
 * rotation and scale one at a time, not as matrices -- so exact, where
 * inverting the parent's matrix would bring in a skew the ECS never makes.
 * Null if the parent is scaled to nothing on an axis: no local pose gives that.
 */
export function toLocal(parent: Pose, world: Pose): Pose | null {
  const p = pointToLocal(parent, world.p);
  if (!p) return null;
  return { p, q: multiply(invert(normalize(parent.q)), world.q), s: [world.s[0] / parent.s[0], world.s[1] / parent.s[1], world.s[2] / parent.s[2]] };
}

/** A point of the world in the space of a parent at `parent`: what a child there needs as its local position to be at it. Null as `toLocal`. */
export function pointToLocal(parent: Pose, p: Vec3): Vec3 | null {
  const [sx, sy, sz] = parent.s;
  if (sx === 0 || sy === 0 || sz === 0) return null;
  const local = rotate(invert(normalize(parent.q)), sub(p, parent.p));
  return [local[0] / sx, local[1] / sy, local[2] / sz];
}

/** A local pose under a parent at `parent`, in the world: §8's composition, which `toLocal` undoes. */
export function toWorld(parent: Pose, local: Pose): Pose {
  const q = normalize(parent.q);
  return { p: add(parent.p, rotate(q, scaled(local.p, parent.s))), q: multiply(q, local.q), s: scaled(local.s, parent.s) };
}

// ---------------------------------------------------------------- vectors and quaternions

const add = (a: Vec3, b: Vec3): Vec3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sub = (a: Vec3, b: Vec3): Vec3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const scaled = (a: Vec3, k: Vec3): Vec3 => [a[0] * k[0], a[1] * k[1], a[2] * k[2]];

/** `to` over `from`, axis by axis; an axis scaled to nothing leaves the others' factor alone. */
const ratio = (to: Vec3, from: Vec3): Vec3 => [from[0] === 0 ? 1 : to[0] / from[0], from[1] === 0 ? 1 : to[1] / from[1], from[2] === 0 ? 1 : to[2] / from[2]];

/** `a * b`: a turn by `b`, then by `a`. */
export function multiply(a: Quat, b: Quat): Quat {
  const [ax, ay, az, aw] = a;
  const [bx, by, bz, bw] = b;
  return [
    ax * bw + aw * bx + ay * bz - az * by,
    ay * bw + aw * by + az * bx - ax * bz,
    az * bw + aw * bz + ax * by - ay * bx,
    aw * bw - ax * bx - ay * by - az * bz,
  ];
}

/** A rotation as the inspector shows it: Euler angles in degrees, XYZ, as three's `Euler.setFromQuaternion` works them out. */
export function eulerDegrees(q: Quat): Vec3 {
  const [x, y, z, w] = normalize(q);
  const m11 = 1 - 2 * (y * y + z * z);
  const m12 = 2 * (x * y - z * w);
  const m13 = 2 * (x * z + y * w);
  const m22 = 1 - 2 * (x * x + z * z);
  const m23 = 2 * (y * z - x * w);
  const m32 = 2 * (y * z + x * w);
  const m33 = 1 - 2 * (x * x + y * y);
  const deg = 180 / Math.PI;
  const ey = Math.asin(Math.max(-1, Math.min(1, m13)));
  if (Math.abs(m13) < 0.9999999) return [Math.atan2(-m23, m33) * deg, ey * deg, Math.atan2(-m12, m11) * deg];
  return [Math.atan2(m32, m22) * deg, ey * deg, 0];
}

/**
 * `eulerDegrees` of `q`, as the three angles nearest `near`: every rotation
 * has two sets of XYZ angles (x and z half a turn over, y the other side of
 * 90°) -- 92.6° about y is also x -180, y 87.4, z -180 -- and the one a
 * person turned to is the one nearer where it began.
 */
export function eulerNear(q: Quat, near: Vec3): Vec3 {
  const a = eulerDegrees(q);
  const wrap = (v: number): number => ((((v + 180) % 360) + 360) % 360) - 180 || 0;
  const b: Vec3 = [wrap(a[0] + 180), wrap(180 - a[1]), wrap(a[2] + 180)];
  const off = (v: Vec3): number => v.reduce((sum, x, i) => sum + Math.abs(wrap(x - near[i]!)), 0);
  return off(b) < off(a) ? b : a;
}

export function normalize(q: Quat): Quat {
  const n = Math.hypot(q[0], q[1], q[2], q[3]);
  return n === 0 ? [0, 0, 0, 1] : [q[0] / n, q[1] / n, q[2] / n, q[3] / n];
}

/** The turn back, for a unit quaternion. */
const invert = (q: Quat): Quat => [-q[0], -q[1], -q[2], q[3]];

/** `v` turned by the unit quaternion `q`. */
export function rotate(q: Quat, v: Vec3): Vec3 {
  const [x, y, z, w] = q;
  // t = 2 (q.xyz × v); v + w t + q.xyz × t
  const tx = 2 * (y * v[2] - z * v[1]);
  const ty = 2 * (z * v[0] - x * v[2]);
  const tz = 2 * (x * v[1] - y * v[0]);
  return [v[0] + w * tx + (y * tz - z * ty), v[1] + w * ty + (z * tx - x * tz), v[2] + w * tz + (x * ty - y * tx)];
}
