/**
 * Which tools a tab shows, which of them has the keys, and whose card the
 * right panel is (Docs/ecs.md §13): the host's rules, pure, so a node test
 * holds them.
 *
 * - **A tab is a tool on the bar**, and a tool may be shown `within` another's
 *   tab instead of having one of its own -- the Assets panel inside Scene,
 *   along the bottom -- or within several (`within: ['entities', 'model']`:
 *   the same panel in Scene and in Model, Docs/modeler.md M6). Its key brings
 *   up the tab it is in: the one up, if it is one of them, else its first --
 *   the keys with it.
 * - **One side has the keys**: in a tab of several, the tool last pressed in
 *   (its cards, the scene for the tab's own) -- its keys live, the others'
 *   resting, so one physical key (Delete, Mod+C, the arrows) never acts on
 *   both. Undo, Redo, the bars and the History card follow it too
 *   (`active-history.ts`, asked of the focused tool). A key marked `anySide`
 *   is live whichever side has them: the Assets panel's fold.
 * - **The right panel is whoever chose last**: an entity chosen shows the
 *   entity inspector, a file the Assets inspector.
 * - **One selection across the sides** (`chose`): something chosen on one
 *   side -- an entity, a file -- and every other side up lets go of its own
 *   choice, so the tab never has an entity and a file chosen at once. Only
 *   in a tab whose tools say how to let go (`ToolInstance.letGo`): the
 *   Model tab's parts and the Assets panel's files keep each their own.
 * - **The lock** (`lock`), in a tab whose tool has one (`lock: true`, the
 *   Scene tab): the right panel stays whose it is -- a choice on either side
 *   still chooses, but never takes the panel -- until it is unlocked. The
 *   tab left and come back to, it is still locked, and still that side's.
 *   Unlocked, the panel is the side's that chose last while it was shut --
 *   a real choice (`chose`), not a folder opened or chosen, nor a click on nothing --
 *   where it would have gone unlocked (`afterUnlock`); none, it stays.
 *   Another world loaded lets it go (`release`, `inspector-lock.ts`' `letsGo`)
 *   -- not the same one loaded again, and never a lock on a side whose
 *   inspector pins paths (`pins: 'paths'`, the Assets panel's files).
 * - **A new tab starts with its own**: the keys and the right panel its own
 *   tool's, whatever was focused when it was left.
 */

import { afterUnlock, letsGo, type Load } from './inspector-lock.ts';

/** What these rules read of a tool: its id, and the tab or tabs it is shown in, if not its own. */
export interface Placed {
  readonly id: string;
  /**
   * The id of the tool whose tab it is shown in -- the Assets panel's `entities` -- or the ids of several, the first
   * its home (`['entities', 'model']`): no button of its own.
   */
  readonly within?: string | readonly string[];
  /** Its tab's right panel can be locked to what it shows (`Sides.lock`): the Scene tab's. */
  readonly lock?: boolean;
  /** What its inspector's lock pins is paths, of no world (the Assets panel's files): no world loaded lets it go. */
  readonly pins?: 'paths';
}

/** The tabs a tool is shown within, its home first; none for a tool with a tab of its own. */
export function withinOf(tool: Placed): readonly string[] {
  const { within } = tool;
  return within === undefined ? [] : typeof within === 'string' ? [within] : within;
}

export interface Sides {
  /** The tab up: a tool on the bar. */
  readonly tab: string;
  /** Every tool shown with it: the tab's own first, then those within it, in order. */
  readonly up: readonly string[];
  /** Is more than one tool shown: then the focused side is lit, and said. */
  readonly split: boolean;
  /** The tool with the keys and the bars' history: one of `up`. */
  readonly focused: string;
  /** Whose card the right panel shows: one of `up`. */
  readonly inspecting: string;
  /** Another tab up: the keys and the right panel its own tool's. False if it was up already (nothing changes). */
  enter(tab: string): boolean;
  /** The keys to `id`, if it is up. True if they moved. */
  focus(id: string): boolean;
  /** The right panel `id`'s, if it is up and the panel is not locked (locked, refused and forgotten: `chose` is what the unlock reads). True if it changed hands. */
  inspect(id: string): boolean;
  /** Can the right panel be locked in the tab up: its tool has a lock (`lock: true`, the Scene tab). */
  readonly lockable: boolean;
  /** Is the right panel locked in the tab up: whose it is kept, whatever is chosen. */
  readonly locked: boolean;
  /**
   * The right panel locked (`on`) to the side it is -- or unlocked, the panel then the side chosen in last while it
   * was shut (`afterUnlock`) -- in the tab up, if its tool has a lock; kept for that tab as others come and go. True
   * if it changed.
   */
  lock(on: boolean): boolean;
  /**
   * A world loaded (`load`): whatever tab it is locked in unlocked, if that lets it go (`letsGo`) -- another world, and
   * a lock on a side pinning entities, of the world before. That tab, or null if none was let go.
   */
  release(load: Load): string | null;
  /**
   * Something chosen in `id` -- an entity, a file: a real choice, never a folder opened or a click on nothing: the
   * other tools up in the tab, which let go of their own choice -- one selection across the sides. None if `id` is
   * not up. Locked, it changes nothing of this, but is remembered -- the panel `id`'s as the lock opens
   * (`afterUnlock`). With `remember` false -- folders chosen, browsing, no subject -- nothing: no other side lets
   * go (a folder is a way through the files, not an object), and the lock remembers nothing.
   */
  chose(id: string, remember?: boolean): readonly string[];
  /** Is `id` shown just now? */
  isUp(id: string): boolean;
  /** Is a key of `id`'s live, as far as the sides go: it is up, and has the keys -- or the key is one of either side's (`anySide`). */
  keyLive(id: string, anySide?: boolean): boolean;
}

/**
 * The tab `id` is shown in: its own; or the one it is within -- of several, `up` (the tab up) if it is among them,
 * else its first.
 */
export function tabOf(tools: readonly Placed[], id: string, up?: string): string {
  const tool = tools.find((t) => t.id === id);
  const tabs = tool ? withinOf(tool) : [];
  if (tabs.length === 0) return id;
  return up !== undefined && tabs.includes(up) ? up : tabs[0]!;
}

/** The tools on the bar: those with a tab of their own. */
export function tabsOf<T extends Placed>(tools: readonly T[]): T[] {
  return tools.filter((t) => t.within === undefined);
}

/** Every tool a tab shows: its own, then each within it, in the tools' order. */
export function upIn(tools: readonly Placed[], tab: string): string[] {
  return [tab, ...tools.filter((t) => withinOf(t).includes(tab)).map((t) => t.id)];
}

export function createSides(tools: readonly Placed[], first: string): Sides {
  for (const t of tools) {
    for (const tab of withinOf(t)) {
      const host = tools.find((h) => h.id === tab);
      if (!host || host.within !== undefined) throw new Error(`[editor] ${t.id} is within ${tab}, which is no tool with a tab of its own`);
    }
  }
  let tab = first;
  let up = upIn(tools, tab);
  let focused = tab;
  let inspecting = tab;
  /**
   * The tab whose right panel is locked, whose side it is locked to, and the side something was last chosen in
   * meanwhile (`chose`: null for none) -- the panel its as the lock opens. Null for no lock.
   */
  let locked: { tab: string; side: string; chose: string | null } | null = null;
  const hasLock = (id: string): boolean => tools.find((t) => t.id === id)?.lock === true;
  return {
    get tab() {
      return tab;
    },
    get up() {
      return up;
    },
    get split() {
      return up.length > 1;
    },
    get focused() {
      return focused;
    },
    get inspecting() {
      return inspecting;
    },
    enter(next) {
      if (next === tab) return false;
      tab = next;
      up = upIn(tools, tab);
      focused = tab;
      // Back to the tab it was locked in: the panel the side it was locked to.
      inspecting = locked?.tab === tab ? locked.side : tab;
      return true;
    },
    focus(id) {
      if (!up.includes(id) || focused === id) return false;
      focused = id;
      return true;
    },
    inspect(id) {
      if (!up.includes(id)) return false;
      // Locked: refused, and not remembered -- a folder opened or a click on nothing asks for the panel too, and is no
      // choice; the side chosen in last is `chose`'s.
      if (locked?.tab === tab) return false;
      if (inspecting === id) return false;
      inspecting = id;
      return true;
    },
    get lockable() {
      return hasLock(tab);
    },
    get locked() {
      return locked?.tab === tab;
    },
    lock(on) {
      if (!hasLock(tab) || on === (locked?.tab === tab)) return false;
      if (!on && locked !== null) inspecting = afterUnlock(locked.side, locked.chose);
      locked = on ? { tab, side: inspecting, chose: null } : null;
      return true;
    },
    release(load) {
      if (locked === null) return null;
      const { side } = locked;
      if (!letsGo(load, tools.find((t) => t.id === side)?.pins === 'paths')) return null;
      const was = locked.tab;
      // Up just now: the panel the side chosen in last, as an unlock gives it (a tab not up starts with its own anyway).
      if (was === tab) inspecting = afterUnlock(side, locked.chose);
      locked = null;
      return was;
    },
    chose(id, remember = true) {
      if (!up.includes(id)) return [];
      // A real choice, in the tab it is locked in: remembered -- the panel this side's as the lock opens.
      // Folders chosen, browsing: no subject -- nothing let go, nothing remembered.
      if (!remember) return [];
      if (locked?.tab === tab) locked.chose = id;
      return up.filter((other) => other !== id);
    },
    isUp: (id) => up.includes(id),
    keyLive: (id, anySide = false) => up.includes(id) && (anySide || focused === id),
  };
}
