/**
 * The selected entity's relation links, drawn in the scene while the entity
 * tool is up (Docs/ecs.md §13): a line to each entity it links to, in one
 * colour, and from each that links to it, in another, fainter.
 *
 * - **Lines with a width**: three's fat lines (`LineSegments2`), a few pixels
 *   wide whatever the screen -- a one-pixel line is lost against the sand on a
 *   dense display. One set out, one set in, each of one colour: a fat line's
 *   colours carry no alpha, so the fainter one is a material of its own. Their
 *   `resolution` -- what a pixel of width is measured against -- is the
 *   viewport in effect, the game's frame (`fitResolution`), read as each is
 *   drawn (`onBeforeRender`): in step with a resize or the frame moved from
 *   its first frame, the game's own redraw included.
 * - **Built again only when what they show may have changed**: another entity
 *   selected, or the tool saying the world changed (`stale`). Each buffer is
 *   sized to its links -- grown by doubling, never shrunk -- and written in
 *   place. A frame that changed neither costs one comparison; the camera
 *   moving needs nothing, the lines being in the world.
 * - **The editor's**: in the scene through `viewport.add`, so out of it while
 *   a playtest runs; drawn over everything, as the
 *   outline is; and never picked -- picking tests views only.
 * - **Each end at the middle of its view**, or where the entity is if it has
 *   none; a link to an entity that is nowhere is left out.
 */
import * as THREE from 'three';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';
import { type Entity, linksOf, NONE, Transform, View, type World, WorldTransform } from '@vibe/engine';
import { fitResolution } from './pick-lines.ts';
import type { Viewport } from './viewport.ts';

/**
 * Out to what it links to: a deep magenta, solid. In from what links to it: a
 * violet, fainter. Deep rather than light, to show against the sand and the
 * sky alike.
 */
const OUT = { color: '#e3127f', opacity: 1 };
const IN = { color: '#4b2fd6', opacity: 0.6 };
/** CSS pixels. */
const WIDTH = 2.5;

export interface LinkLines {
  /** The world may have changed under them: built again before the next frame is drawn. */
  stale(): void;
  /** Shown while the tool is up; away, they go with the next frame. */
  setVisible(visible: boolean): void;
  dispose(): void;
}

/** One colour of line: a buffer of segments written in place, and how many of them to draw. */
interface LineSet {
  readonly lines: LineSegments2;
  /** Write `n` segments from `ends` -- six numbers each, from and to. */
  write(ends: readonly number[], n: number): void;
  dispose(): void;
}

function lineSet(name: string, { color, opacity }: { color: string; opacity: number }): LineSet {
  const geometry = new LineSegmentsGeometry();
  const material = new LineMaterial({ color, linewidth: WIDTH, transparent: opacity < 1, opacity, depthTest: false, depthWrite: false });
  const lines = new LineSegments2(geometry, material);
  lines.name = name;
  // Under the selection's boxes, over the world.
  lines.renderOrder = 996;
  // The buffer changes under it: a bounding sphere worked out once would cull it wrong.
  lines.frustumCulled = false;
  lines.visible = false;
  // A pixel of width as the viewport in effect has it -- the game's frame, not the canvas -- whatever drew this frame, and into whatever target.
  lines.onBeforeRender = (renderer) => fitResolution(material, renderer);
  /** Segments the buffer has room for, and the buffer. */
  let room = 0;
  let positions = new Float32Array(0);
  return {
    lines,
    write(ends, n) {
      if (n > room) {
        room = Math.max(8, 2 ** Math.ceil(Math.log2(n)));
        positions = new Float32Array(room * 6);
        // Hands the array to the geometry as it is: written in place from here on.
        geometry.setPositions(positions);
      }
      for (let i = 0; i < n * 6; i++) positions[i] = ends[i]!;
      if (n > 0) (geometry.getAttribute('instanceStart') as THREE.InterleavedBufferAttribute).data.needsUpdate = true;
      // The draw range of an instanced line: one instance a segment.
      geometry.instanceCount = n;
      lines.visible = n > 0;
    },
    dispose() {
      geometry.dispose();
      material.dispose();
    },
  };
}

export function createLinkLines(world: World, viewport: Viewport, selected: () => Entity): LinkLines {
  const out = lineSet('editor: relation links out', OUT);
  const into = lineSet('editor: relation links in', IN);
  let shown = false;
  let dirty = true;
  /** What the lines were last built for: another entity selected is a rebuild too. */
  let builtFor: Entity = NONE;
  /** Each set's segments as this build finds them, kept to be written. */
  const outEnds: number[] = [];
  const inEnds: number[] = [];

  const box = new THREE.Box3();
  const a = new THREE.Vector3();
  const b = new THREE.Vector3();

  /** Where a line to `e` ends: the middle of its view, else its world position. False if it is nowhere. */
  function endOf(e: Entity, at: THREE.Vector3): boolean {
    if (!world.alive(e)) return false;
    const view = world.has(e, View) ? world.store(View).value[e] : null;
    if (view) {
      view.updateMatrixWorld(true);
      box.setFromObject(view);
      if (!box.isEmpty()) {
        box.getCenter(at);
        return true;
      }
    }
    if (!world.has(e, Transform)) return false;
    const w = world.store(WorldTransform);
    at.set(w.px[e]!, w.py[e]!, w.pz[e]!);
    return true;
  }

  function build(): void {
    dirty = false;
    const e = shown ? selected() : NONE;
    builtFor = e;
    outEnds.length = 0;
    inEnds.length = 0;
    if (e !== NONE && endOf(e, a)) {
      for (const relation of world.allComponents) {
        if (relation.kind !== 'relation') continue;
        const links = linksOf(world, e, relation);
        // From the source to the target, whichever end this entity is.
        for (const link of links.out) if (link.other !== e && endOf(link.other, b)) outEnds.push(a.x, a.y, a.z, b.x, b.y, b.z);
        for (const link of links.into) if (link.other !== e && endOf(link.other, b)) inEnds.push(b.x, b.y, b.z, a.x, a.y, a.z);
      }
    }
    out.write(outEnds, outEnds.length / 6);
    into.write(inEnds, inEnds.length / 6);
  }

  const offs = [
    viewport.add(out.lines, into.lines),
    // Before every frame drawn, the views placed: built again only if something it shows may have moved.
    viewport.on('update', () => {
      if (dirty || builtFor !== (shown ? selected() : NONE)) build();
    }),
  ];

  return {
    stale() {
      dirty = true;
    },
    setVisible(visible) {
      shown = visible;
      dirty = true;
    },
    dispose() {
      for (const off of offs) off();
      out.dispose();
      into.dispose();
    },
  };
}
