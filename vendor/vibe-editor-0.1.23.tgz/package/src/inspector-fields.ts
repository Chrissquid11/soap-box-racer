/**
 * The inspector's widget for each kind of numeric field (Docs/properties.md §2, P1), as a field's maker declares it
 * (`fileFields`, the engine's `ecs/fields.ts`): `fieldLine` picks one.
 *
 * - **A number**: a scrub field, labelled (`label`, or its name spaced), stepped by its `step`, clamped to its
 *   `min`/`max`; with `slider`, a line of its own: the number and a slider from `min` to `max`.
 * - **An enum** (`enumOf`): a drop-down of its names. **Flags** (`flagsOf`): a button saying the names set, which
 *   opens a list of ticks, one a name.
 * - **A vector** (`vec2/3/4`): one row, a scrub field an axis, each clamped as a number is.
 * - **A key, a colour (with alpha), a yes or no, a ref**: `key-field.ts`'s lines and `inspector-blocks.ts`' ref.
 * - **`help`** is every widget's title; **`readonly`** shows it, never edited (as a runtime field of an opened
 *   prefab); **`hidden`** leaves it out; **`group`** a sub-heading over it and every field after it naming the same.
 *
 * Every control's edit is `scene_set`'s (`data-mcp`); each a step of its own, `Set Brain.mood` (`× 3` for several),
 * one for a whole scrub or drag, as every field. `data-field` is `Component.field` -- a vector's one, its row --
 * which the overrides' marks find it by.
 */
import type { Component, Entity, Field, FileField } from '@vibe/engine';
import { flagNames, INT_RANGE, labelOf } from '@vibe/engine';
import { numberField, shown, type NumberField } from './fields.ts';
import type { Blocks, Columns } from './inspector-blocks.ts';
import { picker, titled, type LineOptions } from './key-field.ts';
import { agreed, eachOwn, MIXED, times } from './multi.ts';
import { control, el } from './dom.ts';

/** One value of several -- or of one -- as a number field: how each is read and written, and the step it makes. */
export interface ValuesOptions {
  label: string;
  labelClass?: string;
  title?: string;
  step: number;
  digits?: number;
  integer?: boolean;
  min?: number;
  max?: number;
  /** The step a change makes, `× 3` added for several: `Set Spin.speed`, `Move`. */
  did: string;
  /** Shown, never edited: a runtime field of an opened prefab, which no Save keeps. */
  fixed?: boolean;
  /** Each one's value now, in one order. */
  read(): number[];
  /** The `i`th one's value written, in place: drawn once all are written. */
  write(i: number, value: number): void;
}

/**
 * A number field on one value of each of several: shown when they agree, `—`
 * when they do not; typed, every one is set; scrubbed or stepped, each moved
 * from its own; one step for all of it. With one, a field as any other.
 */
export function valuesField(blocks: Blocks, o: ValuesOptions): NumberField {
  const first = o.read();
  const count = first.length;
  const clamp = (v: number): number => Math.min(o.max ?? Infinity, Math.max(o.min ?? -Infinity, o.integer ? Math.round(v) : v));
  const note = (values: readonly number[]): string | undefined => (count > 1 ? eachOwn(values.map((v) => shown(v, o.digits))) : undefined);
  /** Where each was as a scrub or a step began: what it moves from. */
  let starts: number[] | null = null;
  const field = numberField({
    label: o.label,
    labelClass: o.labelClass,
    title: o.title,
    value: agreed(first),
    note: note(first),
    step: o.step,
    digits: o.digits,
    integer: o.integer,
    min: o.min,
    max: o.max,
    fixed: o.fixed,
    set(value) {
      for (let i = 0; i < count; i++) o.write(i, value);
      blocks.wrote();
    },
    move: count > 1
      ? (by) => {
        starts ??= o.read();
        starts.forEach((v, i) => o.write(i, clamp(v + by)));
        blocks.wrote();
      }
      : undefined,
    commit() {
      starts = null;
      blocks.host.commit(times(o.did, count));
    },
  });
  blocks.live(() => {
    const values = o.read();
    field.show(agreed(values), note(values));
  });
  return field;
}

/** What a field's title says of what it is, after its help. */
function kindSaid(c: Component, f: FileField): string {
  const d = f.field;
  const at = `${c.name}.${f.name}`;
  if (d.enum) return `${at}: one of ${d.enum.join(', ')}`;
  if (d.flags) return `${at}: any of ${d.flags.join(', ')}`;
  const range = INT_RANGE[d.type];
  const bounds = d.min !== undefined || d.max !== undefined ? `, from ${d.min ?? range?.[0] ?? '-∞'} to ${d.max ?? range?.[1] ?? '∞'}` : range ? `, a whole number from ${range[0]} to ${range[1]}` : '';
  if (d.vec !== undefined) return `${at}: ${d.vec} numbers (${d.type})${bounds} -- drag an axis's letter to scrub it`;
  return `${at}: ${d.type}${bounds || ', a number'} -- drag the name to scrub`;
}

/** A field's bounds as the inspector holds what it writes to them: its own, within its type's. */
function bounds(d: Field): { min?: number; max?: number; integer: boolean } {
  const range = INT_RANGE[d.type];
  const min = d.min !== undefined ? Math.max(d.min, range?.[0] ?? -Infinity) : range?.[0];
  const max = d.max !== undefined ? Math.min(d.max, range?.[1] ?? Infinity) : range?.[1];
  return { min, max, integer: range !== undefined };
}

/** A line across the grid: its name (labelled, its help on hover) and what is picked with. */
function line(c: Component, f: FileField, options: LineOptions, extra = ''): { line: HTMLElement; name: HTMLElement; picks: HTMLElement } {
  const out = el('div', `ed-keyline ${extra}`.trim());
  out.dataset.field = `${c.name}.${f.name}`;
  const name = el('span', 'ed-keyline-name', options.label ?? labelOf(f));
  name.title = titled(options, kindSaid(c, f));
  const picks = el('div', 'ed-keyline-picks');
  out.append(name, picks);
  return { line: out, name, picks };
}

/** A number field of one column, with its options: clamped, stepped, labelled -- and with `slider`, a line with a slider. */
export function numberLine(blocks: Blocks, c: Component, f: FileField, es: readonly Entity[], options: LineOptions): HTMLElement {
  const d = f.field;
  const column = (): { [i: number]: number } => (blocks.world.rawStore(c) as Columns)[f.name]!;
  const { min, max, integer } = bounds(d);
  const field = valuesField(blocks, {
    fixed: options.fixed,
    label: options.label ?? labelOf(f),
    title: titled(options, kindSaid(c, f)),
    step: d.step ?? (integer ? 1 : 0.1),
    integer,
    min,
    max,
    did: `Set ${c.name}.${f.name}`,
    read: () => es.map((e) => column()[e]!),
    write: (i, value) => void (column()[es[i]!] = value),
  });
  field.input.dataset.mcp = 'scene_set';
  if (!d.slider || d.min === undefined || d.max === undefined) return field.label;
  // A slider beside the number: a line of its own, the name the number's scrub as ever.
  const out = el('div', 'ed-keyline ed-sliderline');
  out.dataset.field = `${c.name}.${f.name}`;
  const slider = el('input', 'ed-slider');
  slider.type = 'range';
  slider.min = String(d.min);
  slider.max = String(d.max);
  slider.step = String(d.step ?? (integer ? 1 : (d.max - d.min) / 100));
  slider.disabled = options.fixed === true;
  slider.dataset.mcp = 'scene_set';
  slider.title = titled(options, kindSaid(c, f));
  const did = times(`Set ${c.name}.${f.name}`, es.length);
  let sliding = false;
  const show = (): void => {
    const values = es.map((e) => column()[e]!);
    const same = agreed(values);
    slider.value = String(same ?? values[0] ?? d.initial);
    slider.classList.toggle('ed-mixed', same === null);
  };
  show();
  slider.addEventListener('input', () => {
    sliding = true;
    const v = Math.min(d.max!, Math.max(d.min!, Number(slider.value)));
    for (const e of es) column()[e] = integer ? Math.round(v) : v;
    blocks.wrote();
  });
  slider.addEventListener('change', () => {
    sliding = false;
    blocks.host.commit(did);
  });
  blocks.live(() => {
    if (!sliding) show();
  });
  out.append(field.label, slider);
  return out;
}

/**
 * An `enumOf` field: a drop-down of its names (`picker`, as a key's: typed to filter, ↑ ↓ and Enter) -- several that
 * differ, `—` until one is picked for all; a value no name has (a number code wrote) said as it is. One step a pick.
 */
export function enumLine(blocks: Blocks, c: Component, f: FileField, es: readonly Entity[], options: LineOptions): HTMLElement {
  const names = f.field.enum!;
  const column = (): { [i: number]: number } => (blocks.world.rawStore(c) as Columns)[f.name]!;
  const { line: out, picks } = line(c, f, options);
  const nameOf = (v: number): string => names[v] ?? `${v} (no name)`;
  const now = (): { value: string | null; note?: string } => {
    const values = es.map((e) => column()[e]!);
    const same = agreed(values);
    return same === null ? { value: null, note: eachOwn(values.map(nameOf)) } : { value: nameOf(same) };
  };
  const pick = picker({
    title: `${c.name}.${f.name}`,
    ...now(),
    choices: () => names,
    fixed: options.fixed,
    pick: (text) => {
      const v = names.indexOf(text);
      if (v < 0) return;
      for (const e of es) column()[e] = v;
      blocks.wrote();
      blocks.host.commit(times(`Set ${c.name}.${f.name}`, es.length));
    },
  });
  pick.root.classList.add('ed-enum');
  pick.input.dataset.mcp = 'scene_set';
  blocks.live(() => {
    const n = now();
    pick.show(n.value, n.note);
  });
  picks.append(pick.root);
  return out;
}

/** The flags lists open, by `Component.field`: the inspector is built again after each tick, and the list stays open. */
const flagsOpen = new Set<string>();

/** The names a flags value has, as its button says them: `fire, ice`, or `none`. */
const flagsSaid = (names: readonly string[], value: number): string => flagNames(names, value).join(', ') || 'none';

/**
 * A `flagsOf` field: a button saying the names set (`fire, ice`; `—` for several that differ), which opens a list of
 * ticks under it, one a name -- a tick sets or clears that name's bit on every one, one step; neither ticked nor
 * clear while only some have it. Open, it stays open as the inspector is built again, until its button shuts it.
 */
export function flagsLine(blocks: Blocks, c: Component, f: FileField, es: readonly Entity[], options: LineOptions): HTMLElement {
  const names = f.field.flags!;
  const column = (): { [i: number]: number } => (blocks.world.rawStore(c) as Columns)[f.name]!;
  const { line: out, picks } = line(c, f, options, 'ed-flagsline');
  // Read only, it still opens: the ticks say which names are set, and stay disabled.
  const head = control('scene_set', 'ed-input ed-flags-head');
  const list = el('div', 'ed-flags-list');
  const at = `${c.name}.${f.name}`;
  list.hidden = !flagsOpen.has(at);
  head.setAttribute('aria-expanded', String(!list.hidden));
  const boxes = names.map((n, i) => {
    const row = el('label', 'ed-flags-row');
    const box = el('input', 'ed-check');
    box.type = 'checkbox';
    box.dataset.mcp = 'scene_set';
    box.disabled = options.fixed === true;
    const bit = 2 ** i;
    box.addEventListener('change', () => {
      for (const e of es) {
        const has = (Math.floor(column()[e]! / bit) & 1) === 1;
        if (has !== box.checked) column()[e] = box.checked ? column()[e]! + bit : column()[e]! - bit;
      }
      blocks.wrote();
      blocks.host.commit(times(`Set ${c.name}.${f.name}`, es.length));
      show();
    });
    row.append(box, el('span', undefined, n));
    list.append(row);
    return { box, bit };
  });
  const show = (): void => {
    const values = es.map((e) => column()[e]! >>> 0);
    const same = agreed(values);
    head.textContent = same === null ? MIXED : flagsSaid(names, same);
    head.title = same === null ? `${c.name}.${f.name}\n${eachOwn(values.map((v) => flagsSaid(names, v)))}` : titled(options, `${kindSaid(c, f)} -- a click lists them, a tick each`);
    for (const { box, bit } of boxes) {
      const on = values.filter((v) => (Math.floor(v / bit) & 1) === 1).length;
      box.checked = on === values.length && on > 0;
      box.indeterminate = on > 0 && on < values.length;
    }
  };
  show();
  head.addEventListener('click', () => {
    list.hidden = !list.hidden;
    head.setAttribute('aria-expanded', String(!list.hidden));
    if (list.hidden) flagsOpen.delete(at);
    else flagsOpen.add(at);
  });
  blocks.live(show);
  const drop = el('div', 'ed-flags');
  drop.append(head, list);
  picks.append(drop);
  return out;
}

/** A vector field: one row, an axis's scrub field each (`x y z w`), each clamped as a number, one step a change. */
export function vectorLine(blocks: Blocks, c: Component, f: FileField, es: readonly Entity[], options: LineOptions): HTMLElement {
  const d = f.field;
  const { min, max } = bounds(d);
  const { line: out, picks } = line(c, f, options, 'ed-vecline');
  const axes = ['x', 'y', 'z', 'w'];
  f.columns.forEach((spec, i) => {
    const column = (): { [i: number]: number } => (blocks.world.rawStore(c) as Columns)[spec.name]!;
    const field = valuesField(blocks, {
      fixed: options.fixed,
      label: axes[i]!,
      labelClass: `ed-axis-${axes[i]}`,
      title: titled(options, `${c.name}.${f.name}.${axes[i]} (${spec.name}): ${d.type}${min !== undefined || max !== undefined ? `, from ${min ?? '-∞'} to ${max ?? '∞'}` : ''} -- drag the letter to scrub`),
      step: d.step ?? 0.1,
      min,
      max,
      did: `Set ${c.name}.${f.name}`,
      read: () => es.map((e) => column()[e]!),
      write: (n, value) => void (column()[es[n]!] = value),
    });
    field.input.dataset.mcp = 'scene_set';
    picks.append(field.label);
  });
  return out;
}

/** A sub-heading over the fields of a `group`, across the grid. */
export function groupHead(name: string): HTMLElement {
  return el('div', 'ed-field-group', name);
}

/** The line that ends a group: the fields after it are under no heading. */
export function groupEnd(): HTMLElement {
  return el('div', 'ed-field-group-end');
}

/** What a block shows, in order: a field, a group's heading, or the end of a group. */
export type Laid = { field: FileField } | { group: string } | { end: true };

/**
 * A block's fields laid out by their `group`s, left out where `hidden`: each group's heading where its first field
 * is, then every field of that group, in their order -- one heading a group however its fields are spread -- and a
 * field of none after a group ends it (a line), so it is under no heading. Ungrouped fields keep their order.
 */
export function fieldLayout(fields: readonly FileField[]): Laid[] {
  const out: Laid[] = [];
  const shown = fields.filter((f) => !f.field.hidden);
  const done = new Set<string>();
  let inGroup = false;
  for (const f of shown) {
    const g = f.field.group;
    if (g === undefined) {
      if (inGroup) out.push({ end: true });
      inGroup = false;
      out.push({ field: f });
      continue;
    }
    if (done.has(g)) continue;
    done.add(g);
    out.push({ group: g });
    for (const x of shown) if (x.field.group === g) out.push({ field: x });
    inGroup = true;
  }
  return out;
}
