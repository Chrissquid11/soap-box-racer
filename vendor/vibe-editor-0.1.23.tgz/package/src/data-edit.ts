/**
 * What the inspector's list and dictionary do to a value, pure (Docs/properties.md §3, P4): node tests it
 * (`data-edit.test.ts`); `inspector-data.ts` draws the widgets over it.
 *
 * - **`renameKey`**: a dictionary's entry given another key, kept in its place -- a key it has already refused, said.
 * - **`moveTo`**: where an element dragged by its grip lands, dropped on a row (before it) or the foot (the end).
 * - **`room`**: how many more a list takes, by its `max`; **`canRemove`** whether its `min` lets one go.
 */
import type { ListElement } from '@vibe/engine';

/**
 * `map`'s entry `from` keyed `to` instead, in its place: the order written is kept. Why not, or null: done. A key the
 * map has is refused where it is typed (Docs/properties.md §3), the entry left as it was.
 */
export function renameKey<K, V>(map: Map<K, V>, from: K, to: K, said: (k: K) => string = (k) => JSON.stringify(k)): string | null {
  if (from === to) return null;
  if (!map.has(from)) return `no key ${said(from)}`;
  if (map.has(to)) return `${said(to)} is a key already: a key is in a dictionary once`;
  const entries = [...map];
  map.clear();
  for (const [k, v] of entries) map.set(k === from ? to : k, v);
  return null;
}

/** The index an element dragged from `from` lands at, dropped before row `before` (`length` for the foot); null where it stays. */
export function moveTo(from: number, before: number, length: number): number | null {
  const to = Math.max(0, Math.min(before, length));
  const at = to > from ? to - 1 : to;
  return at === from ? null : at;
}

/** How many more `list` takes, now holding `length`: its `max` less what it has, or as many as come. */
export const room = (list: ListElement, length: number): number => (list.max === undefined ? Infinity : Math.max(0, list.max - length));

/** Does `list`'s `min` let one go, now holding `length`? */
export const canRemove = (list: ListElement, length: number): boolean => length > (list.min ?? 0);
