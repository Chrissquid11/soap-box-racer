/**
 * Camera entities in the editor (Docs/camera.md §3, 8.3), as numbers: what the
 * Camera block's buttons write, where Create ▸ Camera and the notice's "Add a
 * main camera" put one, where the preview goes in the scene's room, when the
 * scene is said to have no main camera, and what `F` frames on one. Pure --
 * three's maths and the world, no DOM, no renderer -- so `camera-entity.test.ts`
 * holds every rule.
 *
 * - **Isometric** is a preset, not a mode (§1 rule 4): orthographic, and the
 *   entity turned 45° about Y, then 35.264° down -- `atan(1/√2)`, where the
 *   world's three axes come out the same length on screen.
 * - **A pose of the world lands in the `Transform`** in its parent's space
 *   (`placedTransform`, `gesture.ts`' `toLocal` and `pointToLocal`): position
 *   and rotation; its own scale kept.
 * - **A new scene is empty but for its main camera** (`newSceneWorld`): every
 *   root destroyed, then `Main Camera` -- `Camera { main: true }`, at
 *   `NEW_SCENE_CAMERA_AT` looking at the origin -- so the game draws through it.
 * - **One main camera, said**: a scene with no `Camera` at all, or cameras none
 *   of which is `main`, is told so -- the first by entity offered to be made
 *   main (`mainCameraRule`).
 */
import * as THREE from 'three';
import { Camera, type Entity, Hierarchy, Name, NONE, type Query, rootsOf, Transform, type World, WorldTransform } from '@vibe/engine';
import type { CameraPose } from './camera.ts';
import { freshName } from './clip.ts';
import { pointToLocal, toLocal, type Pose, type Quat, type Vec3 } from './gesture.ts';
import { EMPTY, spawnAt } from './spawn.ts';
import type { Projection, Rect } from './view/views.ts';

/** Isometric's turn about Y, and then down, in degrees: `atan(1/√2)` down, so the three axes are seen alike. */
export const ISO_YAW = 45;
export const ISO_PITCH = THREE.MathUtils.radToDeg(Math.atan(1 / Math.SQRT2));

/** The isometric rotation in the world: 45° about Y, then 35.264° down about the turned X. A camera looks down its -Z. */
export function isometricRotation(): Quat {
  const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(-ISO_PITCH), THREE.MathUtils.degToRad(ISO_YAW), 0, 'YXZ'));
  return [q.x, q.y, q.z, q.w];
}

/**
 * A pose of the world as an entity's `Transform` under a parent at `parent`
 * (its world pose; null for none): the position and rotation to write, its
 * scale left as it is. Null under a parent scaled to nothing on an axis.
 */
export function placedTransform(parent: Pose | null, position: Vec3, rotation: Quat): { p: Vec3; q: Quat } | null {
  if (!parent) return { p: [...position], q: [...rotation] };
  const p = pointToLocal(parent, position);
  const local = toLocal(parent, { p: position, q: rotation, s: parent.s });
  return p && local ? { p, q: local.q } : null;
}

/** The editor's view as numbers: where its camera is, turned how, what it turns round, how it sees. */
export interface EditorView {
  position: Vec3;
  quaternion: Quat;
  target: Vec3;
  projection: Projection;
  /** The perspective camera's vertical field of view, in degrees. */
  fov: number;
  /** The world's height seen at the target in orthographic, in metres. */
  height: number;
}

/** What a `Camera` takes of the editor's view, Align with view: its projection, and its field of view or its half height. */
export function alignedLens(view: EditorView): { projection: 0 | 1; fov: number; size: number } {
  return { projection: view.projection === 'orthographic' ? 1 : 0, fov: view.fov, size: view.height / 2 };
}

/** A camera's lens as Align view with camera takes it: its projection, its field of view, the world's height it sees in orthographic. */
export interface Lens {
  projection: Projection;
  /** Vertical, in degrees: a perspective camera's; for an orthographic one, what the editor's perspective camera goes back to. */
  fov: number;
  /** In metres: an orthographic camera's frustum height over its zoom. */
  height: number;
}

/** Align view with camera turns round a point no nearer than this, in metres: never centimetres off the camera. */
export const LOOK_REACH_MIN = 1;

/**
 * Align view with camera as a pose of the editor's camera: where the camera is
 * (`position`), turning round a point along its look (`along`, unit) as far as
 * the editor's view was from what it turned round -- not past the ground if it
 * looks down onto it from above, so what the editor turns round is never under
 * the ground (its floor would lift the view off the camera), and never nearer
 * than `LOOK_REACH_MIN`. Its projection, its height in orthographic (the
 * editor's own in perspective), and its field of view.
 */
export function lookThroughPose(position: Vec3, along: Vec3, view: EditorView, lens: Lens): CameraPose {
  const [x, y, z] = position;
  let reach = Math.max(LOOK_REACH_MIN, Math.hypot(view.target[0] - view.position[0], view.target[1] - view.position[1], view.target[2] - view.position[2]));
  if (along[1] < -1e-3 && y > 0) reach = Math.max(LOOK_REACH_MIN, Math.min(reach, -y / along[1]));
  const orthographic = lens.projection === 'orthographic';
  return {
    position: [x, y, z],
    target: [x + along[0] * reach, y + along[1] * reach, z + along[2] * reach],
    projection: lens.projection,
    height: orthographic ? lens.height : view.height,
    fov: lens.fov,
  };
}

/** Where a camera made from the editor's view goes: in front of it, along its look -- a third of the way to what it turns round, 1 to 6 m. */
export function inFront(view: EditorView): Vec3 {
  const [x, y, z] = view.position;
  const to = Math.hypot(view.target[0] - x, view.target[1] - y, view.target[2] - z);
  const d = Math.min(6, Math.max(1, to / 3));
  const look = new THREE.Vector3(0, 0, -1).applyQuaternion(new THREE.Quaternion(...view.quaternion));
  return [x + look.x * d, y + look.y * d, z + look.z * d];
}

/** A camera to make: where, turned how, main or not, and its lens if not the defaults. */
export interface CameraMaking {
  position: Vec3;
  rotation: Quat;
  main: boolean;
  /** Under this entity, in its space; NONE (or left out) a root. */
  parent?: Entity;
  lens?: { projection: 0 | 1; fov: number; size: number };
  /** Its `Name`, as given; left out, "Camera" numbered as the tree's names are. */
  name?: string;
}

/** An entity's world pose, as the world worked it out at its last boundary; null for none or one with no `Transform`. */
function worldPose(world: World, e: Entity): Pose | null {
  if (e === NONE || !world.alive(e) || !world.has(e, Transform)) return null;
  const w = world.store(WorldTransform);
  return { p: [w.px[e]!, w.py[e]!, w.pz[e]!], q: [w.qx[e]!, w.qy[e]!, w.qz[e]!, w.qw[e]!], s: [w.sx[e]!, w.sy[e]!, w.sz[e]!] };
}

/** The world pose `e`'s `Transform` is relative to: its parent's, or null for none. */
export const parentPose = (world: World, e: Entity): Pose | null => worldPose(world, world.store(Hierarchy).parent[e]! as Entity);

/**
 * A camera entity made: a `Transform` where `making` says, a `Camera` (`main`
 * as said, the lens if given), a `Name` -- `making.name`, else "Camera"
 * numbered as the tree's names are. Its view comes at the boundary (the engine's `cameras` system).
 * NONE if the world is full. The caller flushes and makes it one step.
 */
export function makeCamera(world: World, making: CameraMaking): Entity {
  const parent = making.parent ?? NONE;
  const placed = placedTransform(worldPose(world, parent), making.position, making.rotation);
  const at = placed?.p ?? making.position;
  const e = spawnAt(world, EMPTY, { x: at[0], y: at[1], z: at[2] });
  if (e === NONE) return NONE;
  const t = world.store(Transform);
  const q = placed?.q ?? making.rotation;
  t.qx[e] = q[0];
  t.qy[e] = q[1];
  t.qz[e] = q[2];
  t.qw[e] = q[3];
  world.store(Name).value[e] = making.name ?? freshName(world, 'Camera');
  const c = world.add(e, Camera);
  c.main[e] = making.main ? 1 : 0;
  if (making.lens) {
    c.projection[e] = making.lens.projection;
    c.fov[e] = making.lens.fov;
    c.size[e] = making.lens.size;
  }
  if (parent !== NONE && world.alive(parent)) world.setParent(e, parent);
  return e;
}

/** Where a new scene's camera stands: up and back from the origin, which it looks at. */
export const NEW_SCENE_CAMERA_AT: Vec3 = [0, 5, 10];

/** What a new scene's camera is called. */
export const NEW_SCENE_CAMERA_NAME = 'Main Camera';

/** The rotation that turns a camera (looking down its -Z, Y up) at `from` to look at `to`. */
export function lookingAt(from: Vec3, to: Vec3): Quat {
  const m = new THREE.Matrix4().lookAt(new THREE.Vector3(...from), new THREE.Vector3(...to), new THREE.Vector3(0, 1, 0));
  const q = new THREE.Quaternion().setFromRotationMatrix(m);
  return [q.x, q.y, q.z, q.w];
}

/**
 * A new scene, in `world`: every root destroyed (their children with them,
 * their views leaving the scene), then one camera made -- `Main Camera`, main,
 * at `NEW_SCENE_CAMERA_AT` looking at the origin -- and flushed. Config ▸
 * Scenes' New and `scene_new` both. The camera, or NONE if the world is full.
 */
export function newSceneWorld(world: World): Entity {
  for (const e of rootsOf(world)) world.destroy(e);
  world.flush();
  const e = makeCamera(world, { position: NEW_SCENE_CAMERA_AT, rotation: lookingAt(NEW_SCENE_CAMERA_AT, [0, 0, 0]), main: true, name: NEW_SCENE_CAMERA_NAME });
  world.flush();
  return e;
}

/** Each world's standing query of its cameras: made once, kept with the world. */
const cameraQueries = new WeakMap<World, Query>();

/**
 * The world's cameras, a standing query (`world.query`) made the first time
 * and kept: every entity with a `Camera`, switched off or not, as of the last
 * boundary. What is walked each frame instead of every slot of the world. Make
 * it outside a tick -- the editor makes it as it is made.
 */
export function cameraQuery(world: World): Query {
  let q = cameraQueries.get(world);
  if (!q) {
    q = world.query({ with: [Camera], includeDisabled: true });
    cameraQueries.set(world, q);
  }
  return q;
}

/** Every live entity with a `Camera`, into `out` (its length set): in no particular order. Allocates nothing once `out` is long enough. */
export function camerasOf(world: World, out: Entity[] = []): Entity[] {
  const q = cameraQuery(world);
  let n = 0;
  for (let i = 0; i < q.count; i++) {
    const e = q.members[i]! as Entity;
    if (world.alive(e)) out[n++] = e;
  }
  out.length = n;
  return out;
}

/**
 * Make `e` the main camera -- the notice's "Make <name> main" and the tools' `scene_main_camera`: its `main` on and
 * every other camera's off, so the game draws through the one. Selects nothing. The cameras it turned off, by entity.
 */
export function setMainCamera(world: World, e: Entity): Entity[] {
  const main = world.store(Camera).main;
  const off: Entity[] = [];
  // Every slot, not the query: a camera made since the last boundary (a batch's) is one too.
  for (let i = 1; i < world.extent; i++) {
    const x = i as Entity;
    if (x === e || !world.alive(x) || !world.has(x, Camera) || main[x] === 0) continue;
    main[x] = 0;
    off.push(x);
  }
  main[e] = 1;
  return off;
}

/**
 * The main camera's rule as one number, allocating nothing: `MAIN_SAID` (-1)
 * for a main camera -- nothing to say; 0 for no camera; else the first camera
 * by entity, none being main. What the notice looks at each frame.
 */
export function mainCameraCode(world: World): number {
  const q = cameraQuery(world);
  const main = world.store(Camera).main;
  let first = 0;
  for (let i = 0; i < q.count; i++) {
    const e = q.members[i]! as Entity;
    if (!world.alive(e)) continue;
    if (main[e] !== 0) return MAIN_SAID;
    if (first === 0 || e < first) first = e;
  }
  return first;
}

/** `mainCameraCode` for a scene with a main camera. */
export const MAIN_SAID = -1;

/** What the scene is told of its main camera: none at all, cameras none of which is main (the first offered), or nothing to say. */
export type MainRule = { kind: 'none' } | { kind: 'none-main'; first: Entity } | null;

/** The rule: no camera -- `none`; cameras, none main -- `none-main` with the first; one main (or more) -- null. */
export function mainCameraRule(cameras: readonly { e: Entity; main: boolean }[]): MainRule {
  if (cameras.length === 0) return { kind: 'none' };
  if (cameras.some((c) => c.main)) return null;
  return { kind: 'none-main', first: cameras[0]!.e };
}

/** A rule from its code (`mainCameraCode`). */
export function mainRuleFrom(code: number): MainRule {
  return code === MAIN_SAID ? null : code === 0 ? { kind: 'none' } : { kind: 'none-main', first: code as Entity };
}

/** The rule for `world` as it is: its cameras and their `main`. */
export const mainRuleOf = (world: World): MainRule => mainRuleFrom(mainCameraCode(world));

/** The notice's words for a rule; `name` the first camera's, for `none-main`. */
export function mainRuleText(rule: Exclude<MainRule, null>, name: string): string {
  return rule.kind === 'none'
    ? 'This scene has no main camera: the game draws through the built-in one'
    : `This scene has cameras, but none is main: the game draws through the built-in one -- ${name} could be`;
}

/** The preview's share of the room's width, its margin from the room's edges, and its most of the room's height. */
const PREVIEW_SHARE = 0.25;
const PREVIEW_MARGIN = 10;
const PREVIEW_TALL = 0.45;

/**
 * The preview of the selected camera in the scene's room (canvas-local CSS
 * pixels): its bottom right, a quarter of the room's width at the camera's
 * aspect -- no taller than nearly half the room, narrower then. Null for a
 * room too small to hold one (under 60 px either way).
 */
export function previewRect(room: Rect, aspect: number): Rect | null {
  if (!(aspect > 0) || !Number.isFinite(aspect)) return null;
  let width = room.width * PREVIEW_SHARE;
  let height = width / aspect;
  const most = room.height * PREVIEW_TALL;
  if (height > most) {
    height = most;
    width = height * aspect;
  }
  width = Math.round(width);
  height = Math.round(height);
  if (width < 60 || height < 60) return null;
  return { x: Math.round(room.x + room.width - width - PREVIEW_MARGIN), y: Math.round(room.y + room.height - height - PREVIEW_MARGIN), width, height };
}

/** Half the side of the box `F` frames round a camera: its bounds are empty, so a 2 m box round where it is. */
export const CAMERA_FOCUS_HALF = 1;

/** The box `F` frames on a camera at `position`: `CAMERA_FOCUS_HALF` each way. */
export function cameraFocusBox(position: Vec3, out = new THREE.Box3()): THREE.Box3 {
  const h = CAMERA_FOCUS_HALF;
  return out.set(new THREE.Vector3(position[0] - h, position[1] - h, position[2] - h), new THREE.Vector3(position[0] + h, position[1] + h, position[2] + h));
}

/**
 * Which of the Camera block's fields are shown for the cameras selected: `fov`
 * for a perspective one, `size` for an orthographic one -- both while they
 * differ -- and `clearColor` while any clears to its own colour.
 */
export function cameraFieldsShown(projections: readonly number[], clears: readonly number[]): { fov: boolean; size: boolean; clearColor: boolean } {
  return { fov: projections.some((p) => p === 0), size: projections.some((p) => p === 1), clearColor: clears.some((c) => c === 1) };
}

/** A column of numbers, by row: a store's, or a test's array. */
export type Column = { [row: number]: number };

/** `value` written into `column` at each of `rows` that differs: how many changed. The Camera block's drop-downs. */
export function writeRows(column: Column, rows: readonly number[], value: number): number {
  let changed = 0;
  for (const row of rows) {
    if (column[row] === value) continue;
    column[row] = value;
    changed++;
  }
  return changed;
}

/** `layer` ticked on or off in the mask of each of `rows`, every other bit -- named or not -- as it was: how many changed. */
export function tickLayer(masks: Column, rows: readonly number[], layer: number, on: boolean): number {
  let changed = 0;
  for (const row of rows) {
    const next = withLayer(masks[row]!, layer, on);
    if (next === masks[row]) continue;
    masks[row] = next;
    changed++;
  }
  return changed;
}

/** A layer mask with `layer` seen or not: the u32 `Camera.layers` keeps. */
export function withLayer(mask: number, layer: number, on: boolean): number {
  const bit = (1 << layer) >>> 0;
  return (on ? (mask | bit) : (mask & ~bit)) >>> 0;
}
