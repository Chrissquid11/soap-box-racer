/**
 * The inspector's relation blocks: each relation the entity is at either end
 * of, a line a link -- the other end, a button that selects it; the link's data
 * to edit; × to cut it (`unrelate`) -- and "Link with…" for one it has none of.
 *
 * "Link to…" makes a new one: the next entity clicked, in the scene or the
 * tree, is its target (the tool's pick, `host.link`); Esc, or a click on
 * nothing, stops. Rows of the tree dropped on it are targets too, one link
 * to each (`drop-target.ts`).
 *
 * **With several selected**, a relation is shown only if every one of them is
 * at an end of it; its links are listed under each entity's name, each edited
 * and cut as one link -- a link is one entity's. "Link to…" links every one
 * of them to the entity clicked, as one step.
 */
import { label, linksOf, type Entity, type Relation } from '@vibe/engine';
import { columnField, type Blocks, type Columns } from './inspector-blocks.ts';
import { factsOf, fits } from './drag-record.ts';
import { dropRefused, dropTarget } from './drop-target.ts';
import { button, el } from './shell.ts';

/** With several selected, the links of this many are listed; the rest are said in a line. */
const LISTED = 12;

/** Each relation every one of `es` is at either end of: the links out and in, editable, and the way to make another. */
export function relationBlocks(blocks: Blocks, es: readonly Entity[]): HTMLElement[] {
  const { world, host } = blocks;
  const many = es.length > 1;
  const out: HTMLElement[] = [];
  const unlinked: Relation<any>[] = [];
  for (const relation of world.allComponents) {
    if (relation.kind !== 'relation') continue;
    const each = es.map((e) => ({ e, links: linksOf(world, e, relation) }));
    const linked = each.filter(({ links }) => links.out.length > 0 || links.into.length > 0);
    const picking = host.picking === relation.name;
    if (linked.length < es.length && !picking) {
      unlinked.push(relation);
      continue;
    }
    const section = el('div', 'ed-component');
    const top = el('div', 'ed-component-head');
    const pick = button(
      'scene_relate', picking ? 'Click an entity…  Esc' : 'Link to…',
      picking
        ? 'Click the entity to link to, in the scene or the tree; Esc stops'
        : many ? `A new ${relation.name} link from each of the ${es.length} selected: then click its target` : `A new ${relation.name} link from this entity: then click its target`,
      () => host.link(relation),
      'ed-quiet ed-pick',
    );
    pick.setAttribute('aria-pressed', String(picking));
    // Rows of the tree (or a component's header: its entity) dropped on it: a link from each selected to each, one step.
    // Through the pick's own write (`host.dropLink`): a link from each shown to each dropped, one step, as a pick makes one.
    if (host.dropLink) dropTarget(pick, (record) => fits({ kind: 'link', relation: relation.name }, record, factsOf(world)), (fit) => {
      if (!('entities' in fit)) return;
      const why = host.dropLink!(relation, fit.entities);
      if (why !== null) dropRefused(why);
    });
    top.append(el('b', undefined, relation.name), pick);
    section.append(top);
    const rows = (): Columns => world.rawStore(relation) as Columns;
    for (const { e, links } of many ? linked.slice(0, LISTED) : each) {
      // Several: whose links these are, a button that selects that one alone.
      if (many) section.append(button('scene_select', label(world, e), `Select ${label(world, e)} alone`, () => host.select(e), 'ed-quiet ed-link-source'));
      for (const [arrow, list, outward] of [['→', links.out, true], ['←', links.into, false]] as const) {
        for (const link of list) {
          const line = el('div', 'ed-link');
          const end = button('scene_select', `${arrow} ${label(world, link.other)}`, 'Select the entity at the other end', () => host.select(link.other), 'ed-quiet ed-link-end');
          line.append(end);
          for (const field of relation.fields) {
            line.append(columnField(blocks, field.name, field.type, `Set ${relation.name}.${field.name}`, () => rows()[field.name]!, [link.row]).label);
          }
          line.append(
            button('scene_unrelate', '×', 'Cut this link', () => {
              if (outward) world.unrelate(e, relation, link.other);
              else world.unrelate(link.other, relation, e);
              host.changed(`Cut ${relation.name}`);
            }, 'ed-quiet'),
          );
          section.append(line);
        }
      }
    }
    if (many && linked.length > LISTED) section.append(el('div', 'ed-dim', `… and the links of ${linked.length - LISTED} more`));
    out.push(section);
  }
  if (unlinked.length > 0) {
    const adder = el('select', 'ed-input ed-link-add');
    adder.title = many
      ? `A new link from each of the ${es.length} selected: pick the relation, then click its target`
      : 'A new link from this entity: pick the relation, then click its target';
    adder.append(new Option('Link with…', ''));
    for (const relation of unlinked) adder.append(new Option(relation.name, String(relation.id)));
    adder.addEventListener('change', () => {
      const relation = unlinked.find((r) => String(r.id) === adder.value);
      adder.blur();
      if (relation) host.link(relation);
    });
    const line = el('div', 'ed-line');
    line.append(adder);
    out.push(line);
  }
  return out;
}
