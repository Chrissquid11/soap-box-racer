/**
 * The host's keys that have chords (`editor.ts`), here so a node test reads them: the plain key and what people press
 * for it everywhere else; the chord is the caption. Save is `Mod+S` alone since plain S is the gizmo's Scale
 * (Blender's G R S, Docs/navigation.md §7). Each from the editor's key table (`editor-keys.ts`), as every key of its is.
 */
import { editorKey, tabKey } from './editor-keys.ts';

export const UNDO = editorKey('undo');
export const REDO = editorKey('redo');
export const SAVE = tabKey('save');
