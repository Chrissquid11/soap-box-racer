/**
 * A prefab's root edited without opening it (Docs/prefabs.md §7, the Assets
 * tool's Root block -- Unity's inspector on a prefab asset): what the block
 * draws, and how an edit becomes the file's new text. Pure but for the world
 * it makes: node tests it (`root-edit.test.ts`); the block that draws it is
 * `assets/ui/prefab-root-block.ts`.
 *
 * **The shape, and why**: one fresh instance of the prefab in a small scratch
 * `World` of its own, as Apply makes one (`overrides-edit.ts`' `planApply`),
 * and the root's components drawn by the Entities inspector's own block code
 * (`inspector.ts`' `entityBlocks`) pointed at that world. An edit is then a
 * world edit like any other -- a column written, a component added, removed
 * or switched off, a tag, a ref, a name -- and the file is written from the
 * instance by the writer the opened mode's Save uses (`clipToPrefab` with
 * `unpack`, in the file's own layout, `unchanged` for no write). So every
 * field type the inspector edits is edited here with no code of its own, a
 * runtime field is dimmed as it is in the opened mode, and a field changed is
 * a line changed in git. A variant's root is the nested instance at its root,
 * and the writer writes its change as an override at `[]` of the variant's
 * file -- never into its base. Rejected: writing the file's JSON from the
 * fields directly, which would need a second writer, a second set of field
 * widgets and a second idea of defaults, runtime fields and overrides.
 *
 * **What refuses an edit** (`refusal`, then `plan`): the page cannot write (a
 * static `build:debug`); the file does not compile (its problem said); the
 * prefab is open in the opened mode -- two editors of one file would fight;
 * an Apply lands (`hold.ts`); the writer cannot keep it (`notes`); the file
 * would not compile, or would leave a prefab nesting it not compiling
 * (`wouldNotCompile`, Save's check); its file changed on disk since it was
 * read (`on-disk.ts`), refused once as Save is -- the same edit again, the
 * file still saying the same, writes over it.
 */
import { type AnyComponent, type Component, compiledPrefab, type Entity, Instance, Loop, Name, type PrefabFile, untypedPrefab as prefab, World } from '@vibe/engine';
import { prefabText, withPool } from './assets/ui/prefab-steps.ts';
import { copyOut } from './clip.ts';
import { diskChange, diskWords, knownOf, wroteOver, type Known } from './on-disk.ts';
import { wouldNotCompile } from './opened.ts';
import { clipToPrefab } from './prefab-write.ts';

/** The compile's checks of `key` as `files` say it: its error, or null (`checkPrefab`, the models known). */
export type Check = (key: string, files: Record<string, PrefabFile>) => string | null;

/** One entity of the scratch instance: what a ref of the root can point at. */
export interface Part {
  entity: Entity;
  /** Its node's id path (`''` the root). */
  path: string;
  /** Its name, else its id path. */
  label: string;
}

export interface RootEdit {
  readonly key: string;
  /** The scratch world the instance is in: the block's fields write here. */
  readonly world: World;
  /** The instance's root: the entity the block shows. */
  readonly root: Entity;
  /** Every entity of the instance, in node order: a ref's choices. */
  readonly parts: readonly Part[];
  /** The file the instance was made from -- or, since, last written: the layout a write keeps. */
  readonly file: PrefabFile;
  /**
   * The file as the instance says it now, checked: `null` if it says what
   * the file does (nothing to write); else its text and the file. Throws,
   * in words, what refuses it -- nothing written: what the writer cannot
   * keep, a compile it would break, the file changed on disk since it was
   * read (once: asked again, the file still saying the same, it goes).
   */
  plan(files: Readonly<Record<string, PrefabFile>>, check: Check): { file: PrefabFile; text: string } | null;
  /** `file` was written as `text`: what is on disk now, the next write's layout -- and no change of anyone else's. */
  wrote(file: PrefabFile, text: string, files: Readonly<Record<string, PrefabFile>>): void;
}

/** What stops any edit of `key`'s root before it is tried, or null: the reasons the block is read-only. */
export function refusal(o: { key: string; writes: boolean; problem: string | null; open: readonly string[]; held: string | null }): string | null {
  if (!o.writes) return 'this page cannot write files -- edit it in npm run dev';
  if (o.problem !== null) return `${o.key} does not compile: ${o.problem}`;
  if (o.open.includes(o.key)) return `${o.key} is open: edit it there`;
  if (o.held !== null) return o.held;
  return null;
}

/**
 * The root of `key` ready to edit: a fresh instance of it as compiled now in
 * a scratch world, made from `file` -- the file that compile was made from.
 * `files` is every prefab file as the page holds it. Null if `key` is not
 * compiled.
 */
export function createRootEdit(key: string, file: PrefabFile, files: Readonly<Record<string, PrefabFile>>): RootEdit | null {
  const compiled = compiledPrefab(key);
  if (!compiled) return null;
  // Room for the instance and what an edit adds to it (a component's rows are per entity): small, never shared.
  const world = new World({ loop: new Loop(), entities: Math.max(64, compiled.count * 2 + 16), shared: false });
  const root = world.instantiate(prefab(key));
  world.flush();
  const inst = world.rawStore(Instance) as Record<'node' | 'next', { [i: number]: number }>;
  const names = (world.rawStore(Name) as { value: (string | null)[] }).value;
  const parts: Part[] = [];
  for (let e = root as number; e !== 0; e = inst.next[e]!) {
    const path = compiled.paths[inst.node[e]!]!;
    const named = world.has(e as Entity, Name) ? names[e] : null;
    parts.push({ entity: e as Entity, path, label: named || path || '(root)' });
  }
  let base = file;
  let known: Known = knownOf(key, file, files);
  /** A change on disk said once already: the same again writes over it. */
  let overwrite: string | null = null;
  return {
    key,
    world,
    root,
    parts,
    get file() {
      return base;
    },
    plan(held, check) {
      world.flush();
      const written = clipToPrefab(copyOut(world, [root]), { compiled: (k) => compiledPrefab(k), unpack: { key, file: base } });
      if (written.notes.length > 0) throw new Error(`${key} cannot keep it, so nothing was written: ${written.notes.join('; ')}`);
      if (written.unchanged) return null;
      const problem = wouldNotCompile(key, { ...held, [key]: written.file }, check);
      if (problem !== null) throw new Error(problem);
      const change = diskChange(key, known, held);
      if (change?.how === 'gone') throw new Error(`${diskWords(key, change).replace(' since you opened it', ' since it was read')}: nothing written`);
      if (change && overwrite !== change.text) {
        overwrite = change.text;
        throw new Error(`${key} changed on disk since it was read: nothing written -- edit it again to write over that, or wait for it to compile and see it here`);
      }
      return { file: written.file, text: prefabText(written.file) };
    },
    wrote(file, text, held) {
      known = wroteOver(known, key, text, held);
      overwrite = null;
      base = file;
    },
  };
}

// ---------------------------------------------------------------- prefab_edit's change (Docs/mcp.md M3)

/** `prefab_edit`'s change of a root: components added and removed, a number component's fields set. */
export interface RootChange {
  add?: readonly string[];
  remove?: readonly string[];
  set?: Readonly<Record<string, Readonly<Record<string, unknown>>>>;
}

/**
 * `change` made on `edit`'s root, as the Root block makes each: every name, field and value checked **first**, so a
 * refusal throws with the edit's world untouched -- never a root half-edited -- then added, removed and set, in that
 * order. `value` reads a field's value from what was given (a number, a yes or no, a colour, a key), throwing why not.
 * Answers what changed, a few words each: `+ReGlow`, `-ReAim`, `ReTurn.speed`.
 */
export function changeRoot(edit: RootEdit, change: RootChange, value: (c: Component, field: string, given: unknown) => number): string[] {
  const { world: w, root: e } = edit;
  const named = (n: string): AnyComponent => {
    const c = w.allComponents.find((x) => x.name === n);
    if (!c) throw new Error(`There is no component called ${n}`);
    return c;
  };
  const adds = (change.add ?? []).map(named);
  const removes = (change.remove ?? []).map(named);
  const sets: Array<{ c: Component; field: string; to: number }> = [];
  for (const [n, fields] of Object.entries(change.set ?? {})) {
    const c = named(n);
    if (c.kind !== 'data') throw new Error(`${n} has no fields set here: a number component's are`);
    if (removes.includes(c) || (!w.has(e, c) && !adds.includes(c))) throw new Error(`The root has no ${n}: add it first`);
    for (const [field, given] of Object.entries(fields)) {
      if (!(c as Component).fields.some((f) => f.name === field)) throw new Error(`${n} has no field ${field}`);
      sets.push({ c: c as Component, field, to: value(c as Component, field, given) });
    }
  }
  const changed: string[] = [];
  for (const c of adds) {
    if (w.has(e, c)) continue;
    w.add(e, c);
    changed.push(`+${c.name}`);
  }
  for (const c of removes) {
    if (!w.has(e, c)) continue;
    w.remove(e, c);
    changed.push(`-${c.name}`);
  }
  for (const s of sets) {
    (w.rawStore(s.c) as Record<string, { [i: number]: number }>)[s.field]![e] = s.to;
    changed.push(`${s.c.name}.${s.field}`);
  }
  w.flush();
  return changed;
}

/**
 * A prefab's root change and its pool as **one** write (`prefab_edit`: one step): the root's planned file (or, with
 * none, the file's `text` as it is) with `pool` set (`null`: none; left out: as it is). Null when it comes to the file
 * as it is. The file beside the text keeps the pool too, so the root's next write (`wrote`, its layout) keeps it.
 */
export function withPoolPlanned(text: string, planned: { file: PrefabFile; text: string } | null, pool: { warm: number; max: number } | null | undefined): { file: PrefabFile | null; text: string } | null {
  const base = planned?.text ?? text;
  const next = pool === undefined ? base : withPool(base, pool);
  if (next === text) return null;
  if (!planned) return { file: null, text: next };
  const file: PrefabFile = { ...planned.file };
  if (pool) file.pool = pool;
  else if (pool === null) delete file.pool;
  return { file, text: next };
}
