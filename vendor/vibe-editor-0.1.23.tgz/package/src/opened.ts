/**
 * The opened-prefab mode (Docs/prefabs.md §7): a prefab opened to edit -- a
 * double-click in the Assets tool, Open on an instance, Open in the Prefab
 * block -- alone in the scene as one instance, edited by the Entities tool
 * and the inspector as any entities, Save writing its file, Back putting the
 * world back. The host (`editor.ts`) owns the top bar's line and the
 * question; this is what the mode does.
 *
 * The rules:
 *   - **The world is put aside as a playtest does**: `world.save()`, then
 *     back through the host's `load` (`Game.load`), so the scene's unsaved
 *     state -- and its own history -- are as they were. A playtest inside the
 *     mode puts the prefab's world back in turn.
 *   - **Its own history**: the world's steps are put aside (`setAside`) as the
 *     mode opens and taken back as it ends, so Z inside it is the mode's, and
 *     none of its steps is left on the world's stack. Its saved point is the
 *     file: as opened, and after each Save.
 *   - **A stack**: a nested instance opens the same way from inside, and Back
 *     returns to the prefab it was opened from, with its unsaved edits.
 *   - **Back with unsaved changes asks first**: `back()` says no, and the host
 *     asks (its dialog, `dialog.ts`, never `confirm`) before `back(true)`. **Nothing unsaved
 *     is dropped unasked at any level**: `unsavedAny` is any frame of the
 *     stack with edits not saved, and each level of Back asks of its own.
 *   - **Save writes what was opened**: the opened instance's root and what is
 *     under it (`clipToPrefab`'s `unpack`): the file's own ids kept, its
 *     nested instances instances still, in the file's own layout. An entity
 *     beside the root, not under it, is not in the prefab: the Save is
 *     refused, saying so, and the edits stay unsaved -- so Back still asks.
 *     What is made in the mode goes under the root, or the selected entity
 *     of it, in its space (`openedParent`, `localAt`), never beside it. A file
 *     that would say what it says already is not written: "nothing to save".
 *   - **Each frame keeps the compiled prefabs it was opened against**
 *     (`base`): its entities were made from them, so its overrides are worked
 *     out against them -- never against a compile that came since, which
 *     would make every value a nested Save changed an override pinning the
 *     old one. When a prefab it nests is compiled anew -- an inner one opened
 *     from it and saved, or its file changed beside it -- its entities of that
 *     prefab are brought up to the new compile where they hold no edit of
 *     their own (`bring-up.ts`, as the live update does), one step of
 *     its history (`<key> brought up`, which Z undoes, the base with it), and
 *     the base moves on. So a Save after neither reverts the nested edit nor
 *     bakes it in. **Every instance in it is followed**, not only those its
 *     file nests: one spawned, dragged or pasted in since it opened is its
 *     own instance, and keeps the compile it was made from (`made`, recorded
 *     as the world makes it: `onInstance`), so the writer works its overrides
 *     out against that, and it is brought up as the file's are. **One that
 *     gained or lost entities is followed** (`restructure`): the lost go from
 *     its world, and the gained are made where the new compile puts them --
 *     taken from a fresh instance (of the prefab open for the file's, of the
 *     instance's own prefab for one spawned), re-pointed at its entities and
 *     made its instance's -- the frame's own edits kept, in the same step.
 *     An entity of the frame's own under a lost one goes to the lost one's
 *     nearest surviving ancestor, said ("sticker moved to seat"). One that
 *     changed otherwise (a link's data, a ref) is shown as it was until
 *     opened again, and said; its overrides stay against its base, so a Save
 *     is still right. What truly cannot be followed -- the tree, refs or links
 *     changed as well as entities gained or lost, or a gained one the prefab
 *     open does not have as compiled -- makes the frame **stale**: said, its
 *     Save refused with the words to Back and open it again; worked out again
 *     at every catch-up, so it goes once what made it does.
 *   - **A restructure undone keeps what is edited since**: Z on a bring-up
 *     that took entities out shows them again, plain (the prefab has them no
 *     more), and says so; one edited after that is kept by the next Save as
 *     the frame's own entity, never dropped with its edit.
 *   - **Every Save is compiled before it is written** (`check`): a file that
 *     would not compile -- a prefab put inside itself, an override at what
 *     the nested prefab no longer has -- is refused, the error said, and
 *     nothing is written. So is one that would leave a prefab nesting it not
 *     compiling (an entity of its own under one this one takes away): the
 *     whole compile would fail, and every prefab with it.
 *   - **Its own file changed on disk is never written over unasked**
 *     (`on-disk.ts`): each frame keeps the text it last read or wrote; a
 *     recompile that brings a change is said at once, for every frame open
 *     (`refresh`); a Save is refused in words, and a second, the file still
 *     saying the same, writes over it. A file renamed or trashed while open
 *     is refused every time: never written back at the key it left.
 *   - **A prefab with a compile error opens read-only**, the error said: the
 *     last good compile is what is shown, and a Save would write that over
 *     the file being fixed.
 *
 * Free of the page: the world, the history and the file's writing are handed
 * in, so a node test drives it (`opened.test.ts`).
 */
import {
  checkPrefab, compiledPrefab, compiledPrefabs, Hierarchy, linksOf, Name, nestedKey, NO_REF, NONE, plainSave, untypedPrefab as prefab, refreshInstances, rootsOf, sameCompile, sceneSave, Transform, WorldTransform,
  type CompiledPrefab, type Component, type Entity, type EntityRef, type PrefabFile, type World, type WorldSave,
} from '@vibe/engine';
import { prefabPathOf, prefabText } from './assets/ui/prefab-steps.ts';
import { bringUp, structureOf, type Member, type Structure } from './bring-up.ts';
import { copyOut } from './clip.ts';
import type { History, SetAside } from './history.ts';
import { pointToLocal } from './gesture.ts';
import { diskChange, diskWords, knownOf, wroteOver, type DiskChange, type Known } from './on-disk.ts';
import { clipToPrefab, ownersOf, pathOf } from './prefab-write.ts';
import { PENDING, type WorldSteps } from './world-steps.ts';

export interface OpenedHost {
  world: World;
  /** The world's history: put aside while a prefab is open, the mode's own meanwhile. */
  history: History;
  worldSteps: WorldSteps;
  /** A world put back: `Game.load`, which dresses the views again. */
  load(save: WorldSave): void;
  /** Every prefab file as the page holds it, by key. */
  files(): Readonly<Record<string, PrefabFile>>;
  /** Its problem now -- a parse or compile error naming it -- or null. */
  problem(key: string): string | null;
  /** A prefab file written whole (`PUT prefab`). */
  write(path: string, text: string): Promise<unknown>;
  /** The selection, as refs: kept as a prefab opens, chosen again as it closes. */
  selection(): readonly EntityRef[];
  choose(refs: readonly EntityRef[]): void;
  /** Another world in the scene: a prefab opened or gone back from (the host emits `loaded`). */
  changed(): void;
  /** A line for the person: the status line. */
  say?(line: string): void;
  /** `key` as `files` say it, put through the compile's checks: its error, or null. Default: `checkPrefab`. */
  check?(key: string, files: Record<string, PrefabFile>): string | null;
}

/**
 * `key` written as `files` say it, put through the compile's checks (`check`)
 * before it is: why it would not compile -- itself, or a prefab nesting it,
 * which a path into it could break, and the whole compile with it -- in
 * words that say nothing was written; null if it compiles. The opened mode's
 * Save asks it, and the Assets tool's Root block (`root-edit.ts`).
 */
export function wouldNotCompile(key: string, files: Record<string, PrefabFile>, check: (key: string, files: Record<string, PrefabFile>) => string | null): string | null {
  const problem = check(key, files);
  if (problem !== null) return `${key} would not compile, so nothing was written: ${problem}`;
  for (const k of Object.keys(files)) {
    if (k === key || !nestedKeys(k, files).includes(key)) continue;
    const theirs = check(k, files);
    if (theirs !== null) return `${key} would leave ${k}, which nests it, not compiling, so nothing was written: ${theirs} -- put back what ${k} uses, or change ${k} first`;
  }
  return null;
}

/**
 * Where something made in the opened mode goes (Create on the empty list or
 * a row, a drop on the scene, the agent's `scene_create`): under the
 * first of `selected` that is the prefab's root or under it, else under the
 * root -- never beside it, where Save could not keep it. NONE with no root.
 */
export function openedParent(world: World, root: Entity, selected: readonly Entity[]): Entity {
  if (root === NONE || !world.alive(root)) return NONE;
  const parent = world.store(Hierarchy).parent;
  for (const e of selected) {
    for (let n = e, steps = 0; n !== NONE && steps < world.extent; n = parent[n]! as Entity, steps++) if (n === root) return e;
  }
  return root;
}

/**
 * `at`, a point of the world, as a child of `parent` needs it: in `parent`'s
 * space as the world worked it out at its last boundary. As it is for a
 * parent with no `Transform` (it passes nothing on), and the parent's origin
 * for one scaled to nothing, where no local point is it.
 */
export function localAt(world: World, parent: Entity, at: { x: number; y: number; z: number }): { x: number; y: number; z: number } {
  if (!world.has(parent, Transform)) return at;
  const w = world.store(WorldTransform);
  const local = pointToLocal({ p: [w.px[parent]!, w.py[parent]!, w.pz[parent]!], q: [w.qx[parent]!, w.qy[parent]!, w.qz[parent]!, w.qw[parent]!], s: [w.sx[parent]!, w.sy[parent]!, w.sz[parent]!] }, [at.x, at.y, at.z]);
  return local ? { x: local[0], y: local[1], z: local[2] } : { x: 0, y: 0, z: 0 };
}

/** An entity of a nested instance in a frame: the entity, its path in the prefab it nests, and that instance's id in the file. */
interface NestedMember extends Member {
  nested: string;
}

/** Every prefab as compiled now, by key. */
function compiledNow(): Map<string, CompiledPrefab> {
  const out = new Map<string, CompiledPrefab>();
  for (const p of compiledPrefabs()) if (p && compiledPrefab(p.key) === p) out.set(p.key, p);
  return out;
}

/** `key` and every prefab it nests, to any depth, by its file and theirs. */
export function nestedKeys(key: string, files: Readonly<Record<string, PrefabFile>>): string[] {
  const out = [key];
  for (let i = 0; i < out.length; i++) {
    for (const e of files[out[i]!]?.entities ?? []) {
      const nested = nestedKey(e);
      if (nested !== null && !out.includes(nested)) out.push(nested);
    }
  }
  return out;
}

/** One prefab open: what it is, and what to put back. */
interface Frame {
  key: string;
  /** Its file as opened: which entity of it each node is, for every Save of this opening. */
  file: PrefabFile;
  /** The world it was opened from, and that world's history and selection. */
  world: WorldSave;
  kept: SetAside;
  selection: EntityRef[];
  /** Its instance's root in the scene. */
  root: EntityRef;
  /** Why it cannot be saved: its compile error. */
  readOnly: string | null;
  /** The compiled prefabs its file's entities were made from (or brought up to), by key: what their overrides are worked out against. */
  base: Map<string, CompiledPrefab>;
  /**
   * Every other instance in it -- spawned, dragged, pasted in since it opened
   * -- by its root: the compile it was made from (or brought up to). What its
   * overrides are worked out against, and what it is followed from.
   */
  made: Map<EntityRef, CompiledPrefab>;
  /**
   * Every prefab as compiled at its last catch-up (or as it opened): what an
   * instance it never saw made -- one taken from a pool, which no hook tells
   * of -- was made from at the earliest. A guess that early is safe: followed
   * from there, an instance made later is left as it is.
   */
  seen: Map<string, CompiledPrefab>;
  /** What was said to be beyond bringing up, by what was not followed (`file:<key>`, `inst:<ref>`): the compile, said once each. */
  told: Map<string, CompiledPrefab>;
  /** Entities its Saves wrote as plain ones, and the id each was given: kept by the next Save, the file's now. */
  ids: Map<EntityRef, string>;
  /** Why it can no longer be saved, by what was not followed -- a nested prefab changed in a way it cannot follow. Worked out again at every catch-up. */
  stale: Map<string, string>;
  /**
   * Entities an undone restructure shows again plain, the prefab having them
   * no more, and each one as it was then: one that differs at the next
   * follow was edited since, and is kept as the frame's own.
   */
  letGo: Map<EntityRef, string>;
  /** Entities of a nested prefab's once, kept as the frame's own (`letGo`): never taken for the prefab's again. */
  own: Set<EntityRef>;
  /** Did a Save of this opening write its file? */
  wrote: boolean;
  /** Its file on disk as last read or written (`on-disk.ts`): what tells it changed beside the editor since. */
  disk: Known;
  /** The text on disk a Save refused to write over: a Save while the file still says it writes over it. */
  overwrite: string | null;
  /** What was said of its file changed on disk: said once each. */
  toldDisk: string | null;
}

/** What a catch-up follows: the file's nested instances of a prefab, or one instance spawned in. */
interface Task {
  id: string;
  key: string;
  old: CompiledPrefab;
  /** The instance's root, for one spawned in. */
  root?: Entity;
}

/** Where entities gained are made: the instance they join, the prefab a fresh instance of which has them, and a nested path as that prefab's. */
interface Into {
  root: Entity;
  key: string;
  at(nested: string, q: string): string;
}

export interface Opened {
  /** The prefab open, the innermost; null for none. */
  readonly key: string | null;
  /** Every prefab open, outermost first. */
  readonly stack: readonly string[];
  /** Why the one open cannot be saved; null if it can. */
  readonly readOnly: string | null;
  /** Why the one open can no longer be saved -- a nested prefab changed in a way it cannot follow: Back and open it again -- or null. */
  readonly stale: string | null;
  /** Why the one open's file can never be saved from here -- renamed or trashed since it was opened -- or null: Back's question then offers no Save. */
  readonly gone: string | null;
  /** The one open edited since it was opened or saved. */
  readonly unsaved: boolean;
  /** Any prefab open -- the one on top, or one further out it was opened from -- edited since it was opened or saved. */
  readonly unsavedAny: boolean;
  /** The keys of every prefab open with edits not saved, outermost first: what the Assets tool asks about before it renames or trashes one. */
  readonly unsavedKeys: readonly string[];
  /** The world under every prefab open -- the scene's -- which a reload keeps; null with none open. */
  readonly outer: WorldSave | null;
  /** That scene saved as its history was put aside (true with none open): its mark, which a reload keeps as it was. */
  readonly outerSaved: boolean;
  /** The opened instance's root, while it lives. */
  readonly root: Entity;
  /** `key` opened over what is in the scene: null, or why not. */
  open(key: string): string | null;
  /** The one open written to its file -- or not, the file saying it already: what was done, and what the file could not keep. */
  save(): Promise<{ line: string; notes: string[]; wrote: boolean }>;
  /**
   * The prefab open brought up to what it nests as compiled now (a recompile
   * came, a step undone): what to say, a line each. Save does it first too.
   */
  refresh(): string[];
  /** The world it was opened from back; false, and nothing done, while it has unsaved changes and `force` is not given. */
  back(force?: boolean): boolean;
  /** Every one closed, unsaved changes dropped: asked already, or a reload. */
  leaveAll(): void;
  /** The prefabs `e` is an entity of, the instance's own first and each it nests inward: what Open offers. */
  prefabsOf(e: Entity): string[];
}

export function createOpened(host: OpenedHost): Opened {
  const { world, history, worldSteps } = host;
  const stack: Frame[] = [];
  const top = (): Frame | undefined => stack[stack.length - 1];
  /** Keys a Save of this stack wrote: brought up, they were "saved"; any other, "recompiled". */
  const saved = new Set<string>();
  /** Instances made by the mode itself -- the prefab opened, a fresh one to take entities from -- are no frame's to follow. */
  let quiet = false;
  // Each instance made in a frame -- spawned, dragged, pasted -- and the compile it was made from. One a load brings
  // back keeps what it was known by (an undo, a redo: the same ref); one never known -- taken from a pool, which no
  // hook tells of -- is left to `seen`.
  // A root given back to its pool is told too (`World.park`, its views dressed again): parked, it was made earlier, and
  // its entry -- the compile it was made from, which a Z bringing it back needs -- stays. One warmed is of the compile
  // now, which is what a take hands out: kept.
  world.onInstance((e, p, loaded) => {
    const frame = top();
    if (!frame || quiet || loaded || world.parked(e)) return;
    const r = world.ref(e);
    if (r !== frame.root) frame.made.set(r, p);
  });
  const tree = (): { parent: { [i: number]: number }; firstChild: { [i: number]: number }; nextSibling: { [i: number]: number } } => world.store(Hierarchy);
  const children = (e: Entity): Entity[] => {
    const t = tree();
    const out: Entity[] = [];
    for (let c = t.firstChild[e]! as Entity; c !== NONE; c = t.nextSibling[c]! as Entity) out.push(c);
    return out;
  };
  const label = (frame: Frame, e: Entity): string => (world.has(e, Name) ? (world.rawStore(Name) as { value: (string | null)[] }).value[e] : null) ?? pathOf(world.kindOfEntity(e).name, frame.key) ?? `entity ${e}`;
  /** An entity as it is: what tells one edited since (`letGo`). */
  const print = (e: Entity): string => JSON.stringify([copyOut(world, [e]).entities[0], tree().parent[e]]);

  function open(key: string): string | null {
    const file = host.files()[key];
    if (!file) return `no prefab file ${key}`;
    if (!compiledPrefab(key)) return `${key} is not compiled${host.problem(key) ? `: ${host.problem(key)}` : ''}`;
    if (stack.some((f) => f.key === key)) return `${key} is open already, further out: Back to it`;
    // An edit under way is a step of the world it was made in.
    worldSteps.commit(PENDING);
    world.flush();
    // The scene with its instances' overrides (`sceneSave`): Back brings it up to what was saved here meanwhile.
    const outer = stack.length === 0 ? sceneSave(world) : world.save();
    const selection = [...host.selection()];
    const kept = history.setAside();
    for (const r of rootsOf(world)) world.destroy(r);
    world.flush();
    quiet = true;
    const root = world.instantiate(prefab(key));
    world.flush();
    quiet = false;
    if (root === NONE) {
      host.load(outer);
      history.takeBack(kept);
      worldSteps.sync();
      host.changed();
      return 'the world is full';
    }
    const ref = world.ref(root);
    const base = new Map<string, CompiledPrefab>();
    for (const k of nestedKeys(key, host.files())) {
      const p = compiledPrefab(k);
      if (p) base.set(k, p);
    }
    stack.push({
      key, file: structuredClone(file), world: outer, kept, selection, root: ref, readOnly: host.problem(key), base, made: new Map(), seen: compiledNow(),
      told: new Map(), ids: new Map(), stale: new Map(), letGo: new Map(), own: new Set(), wrote: false,
      disk: knownOf(key, file, host.files()), overwrite: null, toldDisk: null,
    });
    history.markSaved();
    worldSteps.sync();
    host.changed();
    host.choose([ref]);
    return null;
  }

  /**
   * What of `frame` follows the prefabs it holds, read from its world: its
   * own instance's nested entities by the prefab each is of (`nested`, found
   * by kind through the file's own entities, `ownersOf`, as the writer finds
   * them), and every other instance in it by its root (`instances`) with its
   * entities by path. With each, one a load let go of because the prefab no
   * longer has its node (put back after a recompile, or by an undone
   * restructure: plain since), so it is followed out as one still in its
   * instance is. The frame's `own` are its own, never a prefab's.
   */
  function gather(frame: Frame, root: Entity): { nested: Map<string, NestedMember[]>; instances: Map<Entity, { key: string; members: NestedMember[] }> } {
    const owner = ownersOf(frame.file);
    const nested = new Map<string, NestedMember[]>();
    const instances = new Map<Entity, { key: string; members: NestedMember[] }>();
    const instanceAt = (r: Entity): { key: string; members: NestedMember[] } | undefined => {
      let unit = instances.get(r);
      const p = unit ? null : world.prefabOf(r);
      if (p) instances.set(r, (unit = { key: p.key, members: [] }));
      return unit;
    };
    const walk = (e: Entity, inside: readonly Entity[]): void => {
      const at = world.instanceRoot(e);
      const kind = world.kindOfEntity(e).name;
      let within = inside;
      if (frame.own.has(world.ref(e))) {
        // The frame's own now: nobody's to follow.
      } else if (at !== NONE && at !== root) {
        const unit = instanceAt(at);
        if (at === e) within = [...inside, e];
        const path = unit ? pathOf(kind, unit.key) : null;
        if (unit && path !== null) unit.members.push({ e, path, nested: '' });
      } else {
        const path = pathOf(kind, frame.key);
        const o = path === null ? null : owner(path);
        if (o && 'nested' in o && (at === root || compiledPrefab(o.prefab)?.paths.includes(o.inner) === false)) {
          const list = nested.get(o.prefab) ?? [];
          list.push({ e, path: o.inner, nested: o.nested });
          nested.set(o.prefab, list);
        } else if (at === NONE) {
          // Let go of by an instance spawned in, around it: its prefab no longer has it.
          for (let i = inside.length - 1; i >= 0; i--) {
            const unit = instances.get(inside[i]!);
            const q = unit ? pathOf(kind, unit.key) : null;
            if (!unit || q === null) continue;
            if (compiledPrefab(unit.key)?.paths.includes(q) === false) unit.members.push({ e, path: q, nested: '' });
            break;
          }
        }
      }
      for (const c of children(e)) walk(c, within);
    };
    walk(root, []);
    return { nested, instances };
  }

  /**
   * `frame`, the one open, brought up to the prefabs it holds as compiled now:
   * its file's nested instances, and every instance spawned in since it
   * opened. One step if anything was. What to say.
   */
  function catchUp(frame: Frame): string[] {
    try {
      return follow(frame);
    } finally {
      frame.seen = compiledNow();
    }
  }

  function follow(frame: Frame): string[] {
    const root = world.deref(frame.root);
    if (frame.readOnly || root === NONE || !world.alive(root)) return [];
    // Worked out again: what made it stale may be gone, the designer's doing or the nested prefab's.
    frame.stale.clear();
    const said: string[] = [];
    const tasks: Task[] = [];
    for (const [k, p] of frame.base) {
      // Compiled anew and the same (every compile makes every prefab afresh): taken as seen, never named in the line.
      const now = compiledPrefab(k);
      if (k === frame.key || now === undefined || now === p) continue;
      if (sameCompile(now, p)) frame.base.set(k, now);
      else tasks.push({ id: `file:${k}`, key: k, old: p });
    }
    for (const [r, { key }] of gather(frame, root).instances) {
      const ref = world.ref(r);
      let was = frame.made.get(ref);
      const now = compiledPrefab(key);
      // Never seen made -- taken from a pool: as compiled at the last catch-up, the earliest it can be.
      if (!was || was.key !== key) {
        was = frame.seen.get(key) ?? now;
        if (was) frame.made.set(ref, was);
      }
      if (now && was && now !== was && sameCompile(now, was)) frame.made.set(ref, now);
      else if (now && was && now !== was) tasks.push({ id: `inst:${ref}`, key, old: was, root: r });
    }
    if (tasks.length === 0) return said;
    world.flush();
    const before = JSON.stringify(world.save());
    const wasBase = new Map(frame.base);
    const wasMade = new Map(frame.made);
    const wasOwn = new Set(frame.own);
    const brought: string[] = [];
    const lines: string[] = [];
    for (const task of tasks) {
      const { key: k, old } = task;
      const now = compiledPrefab(k)!;
      // Read again for each: following one's entities gained or lost changes what the next finds.
      const members = (): NestedMember[] => {
        const g = gather(frame, root);
        return task.root === undefined ? (g.nested.get(k) ?? []) : (g.instances.get(task.root)?.members ?? []);
      };
      const done = (): void => {
        if (task.root === undefined) frame.base.set(k, now);
        else frame.made.set(world.ref(task.root), now);
      };
      const list = members();
      if (list.length === 0) {
        done();
        continue;
      }
      const into: Into = task.root === undefined
        ? { root, key: frame.key, at: (nested, q) => (frame.file.entities[0]?.prefab !== undefined && frame.file.entities[0].id === nested ? q : q === '' ? nested : `${nested}/${q}`) }
        : { root: task.root, key: k, at: (_nested, q) => q };
      const change = structureOf(old, now);
      const moved = change !== null && (change.added.length > 0 || change.removed.length > 0);
      let why: string | null = null;
      if (change === null) {
        // Gained or lost entities as well: written against the base, a Save would name what the prefab has no more.
        if (old.paths.join() !== now.paths.join()) why = `${k} changed since ${frame.key} was opened in a way it cannot follow -- entities gained or lost, and its tree, refs or links changed`;
      } else if (moved) {
        const r = restructure(frame, into, k, list, now, change);
        why = r.why;
        lines.push(...r.lines);
      }
      if (change === null || why !== null) {
        if (why !== null) frame.stale.set(task.id, why);
        if (frame.told.get(task.id) === now) continue;
        frame.told.set(task.id, now);
        if (why === null) said.push(`${k} changed in what it is made of since ${frame.key} was opened: shown as it was until ${frame.key} is opened again -- a Save keeps it right`);
        else said.push(`${why}: Back, and open ${frame.key} again to save it`);
        continue;
      }
      bringUp(world, moved ? members() : list, old, now);
      done();
      if (!brought.includes(k)) brought.push(k);
    }
    if (brought.length === 0) return said;
    // What an undone restructure let go of is followed now: kept or gone, it is no longer waiting.
    frame.letGo.clear();
    world.flush();
    const after = JSON.stringify(world.save());
    // Compiled anew and the same for these entities (every compile makes every prefab afresh): nothing to show, no step.
    if (after === before) return said;
    const nowBase = new Map(frame.base);
    const nowMade = new Map(frame.made);
    const nowOwn = new Set(frame.own);
    const wasSaved = history.saved;
    history.push({
      label: `${brought.join(', ')} brought up`,
      size: before.length + after.length,
      undo: () => {
        host.load(JSON.parse(before) as WorldSave);
        frame.base = new Map(wasBase);
        frame.made = new Map(wasMade);
        frame.own = new Set(wasOwn);
        worldSteps.sync();
        // What the prefab has no more is back, plain: said, and an edit to one from now on keeps it.
        const back = letGoNow(frame);
        if (back.length > 0) host.say?.(`${back.join(', ')} ${back.length === 1 ? 'is' : 'are'} back as before, plain -- ${brought.join(', ')} ${brought.length === 1 ? 'has' : 'have'} ${back.length === 1 ? 'it' : 'them'} no more: the next Save takes ${back.length === 1 ? 'it' : 'them'} out again, but keeps one edited here as ${frame.key}'s own`);
      },
      redo: () => {
        host.load(JSON.parse(after) as WorldSave);
        frame.base = new Map(nowBase);
        frame.made = new Map(nowMade);
        frame.own = new Set(nowOwn);
        frame.letGo.clear();
        worldSteps.sync();
      },
    });
    // Not an edit of the file: what it says is as it was.
    if (wasSaved) history.markSaved();
    worldSteps.sync();
    const one = brought.length === 1;
    const how = (k: string): string => `${k} ${saved.has(k) ? 'saved' : 'recompiled'}`;
    said.push([
      `${brought.map(how).join(', ')}: ${frame.key} shows ${one ? 'it' : 'them'} as ${one ? 'it is' : 'they are'} now, its own edits kept -- Z shows ${one ? 'it' : 'them'} as before, until a Save brings ${one ? 'it' : 'them'} up again`,
      ...lines,
    ].join(' · '));
    return said;
  }

  /** What of `frame` an undone restructure let go of -- plain now, the prefab having it no more -- each kept as it is now: their names. */
  function letGoNow(frame: Frame): string[] {
    frame.letGo.clear();
    const root = world.deref(frame.root);
    if (root === NONE || !world.alive(root)) return [];
    const g = gather(frame, root);
    const names: string[] = [];
    for (const list of [...g.nested.values(), ...[...g.instances.values()].map((u) => u.members)]) {
      for (const { e } of list) {
        if (world.instanceRoot(e) !== NONE) continue;
        frame.letGo.set(world.ref(e), print(e));
        names.push(label(frame, e));
      }
    }
    return names;
  }

  /**
   * `frame`'s world following prefab `k`'s entities gained and lost (`change`,
   * from the compile its members were made from to `now`), in instance
   * `into.root`: the lost destroyed -- what of the frame's own is under one
   * moved to its nearest ancestor that stays, said, and one an undone
   * restructure let go of and was edited since kept as the frame's own -- and
   * the gained taken from one fresh instance of `into.key` (compiled with the
   * new `k`, so each is where it puts it, with what it gives it), put under
   * their parents, their refs and links re-pointed at the frame's entities,
   * and made `into.root`'s instance's (a save, its rows re-rooted, put back
   * through `load`, which finds each one's node again by its kind). One gained
   * already there is left. `why` is null when done; why not -- nothing changed
   * -- when it cannot be. One fresh instance a call, whatever it gains: the
   * whole prefab made and destroyed, O(prefab) per prefab changed, as Save
   * and Back are a person's pace.
   */
  function restructure(frame: Frame, into: Into, k: string, list: readonly NestedMember[], now: CompiledPrefab, change: Structure): { why: string | null; lines: string[] } {
    const t = tree();
    const lines: string[] = [];
    // Lost: each, with everything under it that is the prefab's too. One edited since an undo let it go: the frame's own.
    const removed = new Set(change.removed);
    const lost = list.filter((m) => removed.has(m.path));
    const keep = lost.filter((m) => {
      const was = frame.letGo.get(world.ref(m.e));
      return was !== undefined && was !== print(m.e);
    });
    const gone = new Set(lost.filter((m) => !keep.includes(m)).map((m) => m.e));
    /** What is under one gone and stays -- the frame's own, one kept -- and where it goes: the nearest ancestor that stays. */
    const moves: [Entity, Entity, Entity][] = [];
    for (const e of gone) {
      for (const c of children(e)) {
        if (gone.has(c)) continue;
        let up = t.parent[e]! as Entity;
        while (up !== NONE && gone.has(up)) up = t.parent[up]! as Entity;
        if (up === NONE) return { why: `${k} no longer has ${pathOf(world.kindOfEntity(e).name, into.key) ?? label(frame, e)}, and ${frame.key} has ${label(frame, c)} under it with nothing left above`, lines: [] };
        moves.push([c, up, e]);
      }
    }
    // Gained: in each nested instance of `k`, where its parent is in the frame (or gained with it), and it is not there already.
    const groups = new Map<string, Map<string, Entity | null>>();
    for (const m of list) {
      if (gone.has(m.e) || keep.includes(m)) continue;
      const g = groups.get(m.nested) ?? new Map<string, Entity | null>();
      g.set(m.path, m.e);
      groups.set(m.nested, g);
    }
    const outer = compiledPrefab(into.key);
    const plan: { at: string; parent: Entity | null }[] = [];
    for (const [nested, g] of groups) {
      for (const q of change.added) {
        const parentQ = now.paths[now.parents[now.paths.indexOf(q)]!]!;
        if (g.has(q) || !g.has(parentQ)) continue;
        const at = into.at(nested, q);
        if (!outer || !outer.paths.includes(at)) return { why: `${k} gained ${q}, and ${into.key} as compiled has no ${at}`, lines: [] };
        plan.push({ at, parent: g.get(parentQ)! });
        g.set(q, null);
      }
    }
    for (const m of keep) {
      frame.own.add(world.ref(m.e));
      lines.push(`${label(frame, m.e)} kept as ${frame.key}'s own: ${k} no longer has it, and it was edited here`);
    }
    for (const [c, up, from] of moves) {
      lines.push(`${label(frame, c)} moved to ${label(frame, up)}: ${k} no longer has ${label(frame, from)}`);
      world.setParent(c, up);
    }
    world.flush();
    for (const e of gone) if (!gone.has(t.parent[e]! as Entity)) world.destroy(e);
    world.flush();
    if (plan.length === 0) return { why: null, lines };
    // One fresh instance: what every gained entity is taken from.
    quiet = true;
    try {
      const fresh = world.instantiate(prefab(into.key));
      world.flush();
      if (fresh === NONE) return { why: `the world is full: what ${k} gained could not be made`, lines };
      /** The entities of instance `top`, by path in `into.key`. */
      const byPath = (top: Entity): Map<string, Entity> => {
        const out = new Map<string, Entity>();
        for (const stack = [top]; stack.length > 0; ) {
          const e = stack.pop()!;
          const path = world.instanceRoot(e) === top ? pathOf(world.kindOfEntity(e).name, into.key) : null;
          if (path !== null) out.set(path, e);
          stack.push(...children(e));
        }
        return out;
      };
      const theirs = byPath(fresh);
      const ours = byPath(into.root);
      const made = new Set<Entity>();
      for (const { at, parent } of plan) {
        const e = theirs.get(at)!;
        made.add(e);
        // Under one of the frame's; one gained under one gained is there already.
        if (parent !== null) world.setParent(e, parent);
      }
      world.flush();
      /** An entity of the fresh instance as the frame's: one taken over is itself, any other the frame's of its path. */
      const ourOf = (e: Entity): Entity | undefined => {
        if (made.has(e)) return e;
        const path = pathOf(world.kindOfEntity(e).name, into.key);
        return path === null ? undefined : ours.get(path);
      };
      for (const e of made) {
        for (const c of world.allComponents) {
          if (c.kind !== 'data' || !world.has(e, c)) continue;
          const columns = world.rawStore(c) as Record<string, { [i: number]: number }>;
          for (const f of c.fields) {
            if (!(c as Component).schema[f.name]?.ref) continue;
            const to = world.deref(columns[f.name]![e]! as EntityRef);
            if (to === NONE || made.has(to) || world.instanceRoot(to) !== fresh) continue;
            const mine = ourOf(to);
            columns[f.name]![e] = mine === undefined ? NO_REF : world.ref(mine);
          }
        }
        for (const r of world.allComponents) {
          if (r.kind !== 'relation') continue;
          for (const link of linksOf(world, e, r).out) {
            if (made.has(link.other) || world.instanceRoot(link.other) !== fresh) continue;
            const to = ourOf(link.other);
            if (to === undefined) continue;
            const p = world.relate(e, r, to);
            const columns = world.rawStore(r) as Record<string, { [i: number]: number }>;
            if (p !== 0) for (const f of r.fields) columns[f.name]![p] = link.data[f.name]!;
          }
        }
      }
      world.flush();
      // The instance's: their rows re-rooted in a save, each found again by its kind as it loads.
      const save = world.save();
      const inst = save.instances;
      if (inst) save.entities.forEach((e, i) => void (made.has(e as Entity) && (inst.root[i] = into.root)));
      host.load(save);
      world.destroy(fresh);
      world.flush();
      return { why: null, lines };
    } finally {
      quiet = false;
    }
  }

  async function save(): Promise<{ line: string; notes: string[]; wrote: boolean }> {
    const frame = top();
    if (!frame) throw new Error('no prefab is open');
    if (frame.readOnly) throw new Error(`${frame.key} opened read-only: ${frame.readOnly}`);
    const root = world.deref(frame.root);
    if (root === NONE || !world.alive(root)) throw new Error(`${frame.key}'s root is gone: undo, or Back without saving`);
    // Its file changed beside the editor since: never written over unasked, never brought back at a key it left.
    const held = { ...host.files() };
    const change = diskChange(frame.key, frame.disk, host.files());
    if (change?.how === 'gone') throw new Error(`${diskWords(frame.key, change)}: nothing written -- a Save would bring it back at ${frame.key}. Back without your edits${change.to !== null ? `, and open ${change.to} to edit it there` : ''}`);
    if (change && frame.overwrite !== change.text) {
      frame.overwrite = change.text;
      throw new Error(`${diskWords(frame.key, change)}: Save again to write over it, or Back without your edits and open it again -- nothing written`);
    }
    worldSteps.commit(PENDING);
    world.flush();
    const caught = catchUp(frame);
    const stale = [...frame.stale.values()][0];
    if (stale !== undefined) throw new Error(`${stale}: Back, and open ${frame.key} again to save it`);
    // Beside the root is outside the prefab: a Save that left them out would say all is saved, and Back would drop them unasked.
    const beside = rootsOf(world).filter((r) => r !== root).length;
    if (beside > 0) throw new Error(`${beside} ${beside === 1 ? 'entity' : 'entities'} beside the root ${beside === 1 ? 'is' : 'are'} not in the prefab: drag ${beside === 1 ? 'it' : 'them'} under it, or delete ${beside === 1 ? 'it' : 'them'} -- nothing written`);
    const order: Entity[] = [];
    const clip = copyOut(world, [root], order);
    const had = new Map(order.flatMap((e, i) => (frame.ids.has(world.ref(e)) ? [[i, frame.ids.get(world.ref(e))!] as const] : [])));
    // Each instance against what its entities were made from: the file's nested ones the frame's base, one spawned in its own.
    const compiled = (k: string, at?: number): CompiledPrefab | undefined => {
      if (at === undefined) return frame.base.get(k) ?? compiledPrefab(k);
      const made = frame.made.get(world.ref(order[at]!));
      return made?.key === k ? made : compiledPrefab(k);
    };
    const { file, notes, unchanged, ids } = clipToPrefab(clip, { compiled, unpack: { key: frame.key, file: frame.file, ids: had } });
    notes.unshift(...caught);
    // Written over when asked to be, though it says what was opened: the file on disk is what the person chose to replace.
    if (unchanged && !change) {
      if (top() === frame) history.markSaved();
      return { line: `${frame.key}: nothing to save -- its file says this already`, notes, wrote: false };
    }
    // Compiled first: a file that would not compile is never written -- the last good compile would stand, and the file lie.
    // And every prefab nesting it: one a file puts something under, by a path into it, would break -- and the whole compile with it.
    const problem = wouldNotCompile(frame.key, { ...host.files(), [frame.key]: file }, host.check ?? checkPrefab);
    if (problem !== null) throw new Error(problem);
    const text = prefabText(file);
    await host.write(prefabPathOf(frame.key), text);
    // What is on disk now: the next Save compares with it, keeps its layout, and its new entities' ids.
    frame.disk = wroteOver(frame.disk, frame.key, text, held);
    frame.overwrite = null;
    frame.toldDisk = null;
    frame.file = file;
    frame.wrote = true;
    saved.add(frame.key);
    for (const [i, id] of ids) frame.ids.set(world.ref(order[i]!), id);
    // The steps are the mode's; what is on disk now is this.
    if (top() === frame) history.markSaved();
    return { line: `Saved ${frame.key}`, notes, wrote: true };
  }

  /** Each frame's file changed on disk since it was read or written, said once each, the moment a recompile brings it: its line. */
  function onDisk(): string[] {
    const lines: string[] = [];
    for (const frame of stack) {
      const change = diskChange(frame.key, frame.disk, host.files());
      const told = change === null ? null : change.how === 'changed' ? `text:${change.text}` : `gone:${change.to}`;
      if (told === frame.toldDisk) continue;
      frame.toldDisk = told;
      if (change) lines.push(diskLine(frame.key, change));
    }
    return lines;
  }

  function back(force = false): boolean {
    const frame = top();
    if (!frame) return false;
    worldSteps.commit(PENDING);
    if (!force && !history.saved) return false;
    stack.pop();
    const below = top();
    host.load(below ? frame.world : plainSave(frame.world));
    history.takeBack(frame.kept);
    worldSteps.sync();
    // Back in the prefab it was opened from: what was saved inside it shown there, if compiled yet (else `refresh`, when it is).
    if (below) for (const line of catchUp(below)) host.say?.(line);
    else {
      // Back in the scene: every instance in it brought up to the prefabs as compiled now, one step Z undoes.
      const lines = refreshInstances(world, frame.world);
      world.flush();
      const keys = [...saved];
      saved.clear();
      if (worldSteps.commit(keys.length > 0 ? `${keys.join(', ')} updated` : 'Prefabs updated')) host.say?.([`the scene brought up to ${keys.length > 0 ? keys.join(', ') : 'the prefabs'} as saved: every instance takes the new data where it holds no override of its own · Z undoes`, ...lines].join(' · '));
    }
    host.changed();
    host.choose(frame.selection);
    return true;
  }

  return {
    get key() {
      return top()?.key ?? null;
    },
    get stack() {
      return stack.map((f) => f.key);
    },
    get readOnly() {
      return top()?.readOnly ?? null;
    },
    get stale() {
      const frame = top();
      return frame ? ([...frame.stale.values()][0] ?? null) : null;
    },
    get gone() {
      const frame = top();
      const change = frame ? diskChange(frame.key, frame.disk, host.files()) : null;
      return change?.how === 'gone' ? diskWords(frame!.key, change) : null;
    },
    get unsaved() {
      return stack.length > 0 && !history.saved;
    },
    get unsavedAny() {
      return this.unsavedKeys.length > 0;
    },
    get unsavedKeys() {
      // The one on top by the history now; each further out by the history put aside as the next was opened from it.
      return stack.filter((_f, i) => (i === stack.length - 1 ? !history.saved : stack[i + 1]!.kept.savedAt !== stack[i + 1]!.kept.back.length)).map((f) => f.key);
    },
    get outer() {
      return stack[0]?.world ?? null;
    },
    get outerSaved() {
      const kept = stack[0]?.kept;
      return kept ? kept.savedAt === kept.back.length : true;
    },
    get root() {
      const frame = top();
      return frame ? world.deref(frame.root) : NONE;
    },
    open,
    save,
    refresh() {
      const frame = top();
      return frame ? [...onDisk(), ...catchUp(frame)] : [];
    },
    back,
    leaveAll() {
      while (stack.length > 0) back(true);
    },
    prefabsOf: (e) => prefabsOf(world, host.files(), e),
  };
}

/** A frame's file changed on disk, said as it lands: what happened, and what a Save will do. */
function diskLine(key: string, change: DiskChange): string {
  if (change.how === 'changed') return `${diskWords(key, change)}: a Save would write over that -- it asks first; Back without your edits and open it again to see it`;
  return `${diskWords(key, change)}: a Save will not write it back${change.to !== null ? ` -- Back, and open ${change.to}` : ' -- Back without your edits, or undo the trash in the Assets tool'}`;
}

/**
 * The prefabs `e` is an entity of: its instance's, then each that one nests
 * at `e`, inward -- a big crate's rider is `crates/big`'s and `crates/rider`'s.
 * Found by its kind's name, the node's path, through each file's entities.
 */
export function prefabsOf(world: World, files: Readonly<Record<string, PrefabFile>>, e: Entity): string[] {
  const p = world.prefabOf(e);
  if (!p) return [];
  const out = [p.key];
  let key = p.key;
  let path = pathOf(world.kindOfEntity(e).name, key) ?? p.paths[world.nodeOf(e)] ?? '';
  for (let depth = 0; depth < 32; depth++) {
    const file = files[key];
    const owner = file ? ownersOf(file)(path) : null;
    if (!owner || 'plain' in owner) break;
    key = owner.prefab;
    path = owner.inner;
    out.push(key);
  }
  return out;
}
