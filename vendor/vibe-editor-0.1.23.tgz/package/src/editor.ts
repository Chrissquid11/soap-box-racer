/**
 * The editor's host (`createEditor`): studio mode's page (`?studio`, Docs/studio.md
 * §1), made by the engine's `boot` as it ends and open from then on -- nothing
 * closes it; the plain page is the game's, `P` its pause (Docs/squidwright-plan.md
 * D14). It holds the chrome -- the top bar and the tool strip (`shell.ts`, its middle
 * `top-bar.ts`), the History and keys cards -- and the services every tool is handed (`tool.ts`): one history,
 * the world steps, the selection, the scene. The tools are plugins; `index.ts`
 * is where a reader starts.
 *
 * - **The whole page, never closed**: it opens itself as it is made, P and Esc
 *   close nothing, and the top bar has no Close -- the play strip is its last.
 *   The keys of every debugger (`playtest-state.ts`): `F5` plays, or runs a
 *   paused playtest on; `F6` (and boot's `P`) pauses it with the editor over its
 *   world as it is now; `F10` steps one tick while paused (`Game.step`);
 *   `Shift+F5` stops. Edits while paused are steps on that world, Resume keeps
 *   them, Stop puts back the world the playtest found. The strip and the pill
 *   over the running game say which and for how long (`PLAYING · 12.3 s`).
 * - **Debug builds only.** A project's main.ts hands it to `boot` as a dynamic import
 *   of `@vibe/editor` (index.ts) behind `DEBUG`, a literal `false` in a release, so Rollup
 *   drops it and everything it pulls in. Never import it statically.
 * - **Every key is a MrDebug action with a `when`**, chords too -- never a key
 *   listener of the editor's own. The host's are registered before the tools',
 *   so they win; while a playtest runs only `T`, Esc, `F5`, `F6`, `Shift+F5` and
 *   the key left of `1` (`GUI_KEY`, the cards away and back) are the editor's.
 * - **What history is kept for is decided here**: as it opens, if the game ran
 *   since the steps knew the world, it starts again -- an undo would rewind the
 *   simulation with it. A playtest is no step and does not end it: the world is put back.
 *   Paused, its history is its own (the scene's put aside, taken back at Stop).
 * - **Tabs and sides** (`sides.ts`): a tool on the bar is a tab; one shown
 *   `within` another's -- the Assets panel along the bottom of Scene -- has
 *   none of its own, and its key brings that tab up with the keys in it. In a
 *   tab of several, one side has the keys: the one last pressed in (a tool's
 *   `cards`, the scene for the tab's own), lit with the focus ring. The right
 *   panel is the card of whichever chose last. The tool within (the Assets
 *   panel) has no icon on the strip: its key, or a press in it, is the way.
 * - **Whose history**: the focused tool's own, if it has one (the Assets
 *   tool's), else the world's -- Undo, Redo, the bars and the History card
 *   alike, and none of them while that tool is busy (`active-history.ts`). The
 *   unsaved dot is always the world's.
 * - **The top bar's middle** (`top-bar.ts`): the gizmo's icons only while the
 *   tool up works in the scene; the status line what the editor said a
 *   moment ago (`say`), else the tool's line (`hint`), else nothing.
 * - **Every card put away** by the key left of `1` (`GUI_KEY`), the scene
 *   alone, and back by it or by Esc -- which then closes nothing else: each
 *   block slides off its edge (`shell.setAway`, `.ed-away`). The editor stays
 *   open and the scene is worked in as before; a tool whose work is in its
 *   cards has its keys rest meanwhile. A key that asks for a card -- a tool's,
 *   `H`, `?`, the prompt box's -- and a card of the agent's that waits bring
 *   them back. Never kept: the editor opens with its cards.
 * - **Claude's column** (`agent/`, Docs/agent.md §4, Docs/ai-panel.md §3): the
 *   agent's card as a full-height column at the window's right edge, right of
 *   the inspector (`shell.ts`' `aiColumn`), where a dev server hosts Claude Code
 *   (`import.meta.hot`): the host's, on every tab, shown or hidden (`Mod+I`, the
 *   AI button); docked, or over the scene where the room left would be under
 *   `AI_ROOM_MIN` (`measure`, `room.ts`' `aiDocks`). `Mod+;` is the host's key
 *   for it, the box's own are MrDebug field actions registered here. A turn's
 *   context is gathered here (`agent/context.ts`): the scene, the tool up, each
 *   tool's `context()`, the selection. The agent's editor
 *   tools (§8) act through the handle given here (`mcp/page.ts`):
 *   the world and its own history, open or not, the selection, the scene, a
 *   world step as an inspector edit makes one, Undo on the world's stack, the
 *   Scenes tool's Save.
 * - **Its static imports of `assets/`** are two, both in this chunk, which
 *   `debugGuard` already checks: `boot.ts` (`watchAssets`, from boot) and the
 *   Assets tool (`assets/ui/assets-tool.ts`).
 * - **A reload it survives** (Docs/agent.md §4): `prepareReload` keeps the
 *   tool, the unsaved world, the selection, the camera and the scene's mark in
 *   this page's record in the tab's `sessionStorage` (`resume.ts`, by the
 *   page's id, so a frame or a copy of the tab never takes it) just before Vite reloads the
 *   page -- on `vite:beforeFullReload`, which Vite's client awaits, and on
 *   `vite:ws:disconnect`, after which it reloads with a bare
 *   `location.reload()` once the server is back -- and lets that one unload
 *   past the Scenes tool's guard (`resume.ts`' `createReloadPass`). While
 *   armed, `pagehide` writes it again; the pass lapses after `PASS_MS` with
 *   no reload -- the dev server away, after `AWAY_MS`, the record kept: a
 *   server stopped for good, and the tab then closed, must not take an
 *   unsaved scene with it unasked. Away, the page asks the server each second
 *   whether it is back (`HEAD /`), and arms again when it is -- before Vite's
 *   client, which awaits the disconnect's listeners, reloads. Closed, it
 *   writes nothing: the guard asks as ever. `resume`, from boot, brings it
 *   back.
 * - **A prefab opened to edit** (`opened.ts`, Docs/prefabs.md §7): the world
 *   put aside as a playtest does, the prefab alone in the scene with a
 *   history of its own, the left panel's header naming it -- `Prefab ·
 *   crates/big` -- beside its Save (Mod+S) and Back (Alt+↑ too), at any width;
 *   Back with unsaved changes asks in the editor's modal dialog
 *   (`dialog.ts`): Save, Don't save, Cancel. Never a silent drop, at any level: while
 *   any prefab open has unsaved changes Esc is Back, one level, and closing
 *   the editor (P, ×) goes Back through every level, asking at each that has
 *   them and going on once it is answered. Closing the
 *   editor, or a reload, goes back to the scene first: what the game runs, and
 *   what a reload keeps, is never a prefab's world.
 * - **The scene's room**: what the docked panels leave -- right of the strip
 *   and the left panel, left of the right panel and Claude's column docked,
 *   under the top bar, above a tool's card along the bottom (`ed-bottom-card`:
 *   the Assets panel, docked between the side panels) and the History card's
 *   dock (`room.ts`' `roomBetween`). Framing and the viewport measure it
 *   (`room`). The dock floats in it, on the bottom card (`--ed-panel-h`), its
 *   height bounded by the top bar as it measures (`--ed-top-h`).
 */
import { Assets } from '@vibe/engine/assets';
import { keyLabel, MrDebug, type DebugAction } from '@vibe/engine/debug';
import type { Mcp } from './mcp/declare.ts';
import { NOT_FOR_CLAUDE } from './mcp/gaps.ts';

import { checkPrefab, type Entity, type EntityRef, isWhole, NONE, physicsSettings, plainSave, type PrefabFile, prefabFiles, refreshInstances, sceneSave, type WorldSave } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import { createHistoryHost, elsewhere } from './active-history.ts';
import { createCameraNotice } from './camera-notice.ts';
import { addMainCamera, makeMainCamera, type StepHost } from './edits.ts';
import { AI_KEY, createAgentCard, TAB_FIELD, type AgentCard } from './agent/agent-card.ts';
import { typingInTerminal } from './agent/terminal-pane.ts';
import { aiDocks, clearOf, roomBetween, type CardBox } from './room.ts';
import { entitiesTarget, turnContext, type TurnContext, type TurnTarget } from './agent/context.ts';
import { createQuickPrompt, QUICK_FIELD } from './agent/quick-prompt.ts';
import { capTarget, type QuickAt } from './agent/quick.ts';
import { FIELD } from './agent/prompt-box.ts';
import { assetApi, useDraw } from './assets/boot.ts';
import { prefabStrays } from './assets/strays.ts';
import { assetsTool } from './assets/ui/assets-tool.ts';
import { createTopBar } from './top-bar.ts';
import { scrollLine } from './view/navigation.ts';
import { REDO, SAVE, UNDO } from './host-keys.ts';
import { pointerOverView } from './view/over-view.ts';
import { endWalk, flyArmed, flyKey, walking } from './view/walker.ts';
import { walkGate } from './view/walk.ts';
import { entitiesTool } from './entities.ts';
import { modelTool } from './model/model-tool.ts';
import { STUDIO_ID, studioTool, type StudioInstance } from './studio/studio-tool.ts';
import { CONSOLE_FIELD } from './studio/console-card.ts';
import { GIT_FIELD } from './studio/git-card.ts';
import { SEARCH_FIELD } from './studio/code/search-pane.ts';
import { KEY_FIELD } from './key-field.ts';
import { bootText, createNotices, errorText, namedByVite, type BootNoticeKind, type ViteError } from './notices.ts';
import { createCodeNotices } from './code-notices.ts';
import { createProbeFrames, probeDoneId, probeFrame } from './studio/probe-frames.ts';
import { createNoticesStrip } from './notices-strip.ts';
import { createRecoveryReload } from './recovery.ts';
import { clearTries, createRecoveryFix, tabTries } from './recovery-fix.ts';
import { createAgentApi } from './agent/api.ts';
import { createHistory, keptSaved, type History, type HistoryEvent, type SetAside, type Step } from './history.ts';
import { createHistoryCard } from './history-card.ts';
import { createKeysCard } from './keys-card.ts';
import { keepPref, keymapNews, loadPrefs } from './prefs.ts';
import { BUILT_IN, boxWords, FREE, presetRows, resolutionOf, SCALE_FILTERS, type ScaleFilter, type ScaleMode } from './game-view.ts';
import { createGameViews } from './game-view-store.ts';
import { GAME_VIEW_PAGE, gameViewPage } from './config/game-view.ts';
import { createMenu, type MenuItem } from './menu.ts';
import { createReloadPass, dropResume, pageId, passWrite, resumeWorld, takeResume, touchResume, writeResume } from './resume.ts';
import { keyProblem, saveAsPrefab } from './save-prefab.ts';
import { guardUnsaved, letReloadPass, loadKept, resumeScene, saveScene, sceneMark, scenesForAgent, scenesPage } from './config/scenes.ts';
import { claudePage } from './config/claude.ts';
import { claudeMdPage } from './config/claude-md.ts';
import { skillsPage } from './config/skills.ts';
import { configTool } from './config/config.ts';
import { keysPage } from './config/keys.ts';
import { createPages } from './config/pages.ts';
import { preferencesPage } from './config/preferences.ts';
import { systemsPage } from './config/systems.ts';
import { afterRebuild, beforeRebuild, type BeforeRebuild, type FollowHost } from './rebuild-follow.ts';
import { createSelection } from './selection.ts';
import { aiColumn, createShell, el, keepsBrowserMenu, type AiColumn } from './shell.ts';
import { skippedText } from './skipped.ts';
import type { ConfigPage, EditorContext, EditorEvent, EditorExtensions, EditorTab, EditorTool, ToolInstance } from './tool.ts';
import { blockList, type BlockItem } from './blocks.ts';
import { BUILT_IN_BLOCKS, clipsOf } from './inspector-blocks.ts';
import { createViewport, type Room } from './viewport.ts';
import { createSides, tabOf, tabsOf, upIn } from './sides.ts';
import type { Load } from './inspector-lock.ts';
import { useModels } from './prefab-views.ts';
import type { CameraPose } from './camera.ts';
import { createWorldSteps, openHistory, PENDING } from './world-steps.ts';
import { onResume as playResumes, onStart as playStarts, onStop as playStops, onTabChange as playTabChanged, playTab, type PlayReturn, type PlayTab } from './play-scene.ts';
import { next as playtestNext, notSavedPlaying, PAUSED_HINT, PLAY_KEYS, playtestBar, type PlaytestEvent, type PlaytestState } from './playtest-state.ts';
import { editorKey, giveWay, KEYMAP_NEWS, keyed, sayGivenWay, setKeymap, switchKeymap, tabKey, undoOnThrow, type Keymap, type KeyClash } from './editor-keys.ts';
import { askUnsaved, dialogKeys, dialogNote, dialogOpen, keepDialog, mountDialogs, showDialog } from './dialog.ts';
import { applyEdits, diffSaves, droppedLine, editId, editsOf, editWords, followRecorded as followSteps, KEPT, keptLabel, keptLine, mergeEdits, stopAnswer, type Applied, type Edit, type PausedStep, type Recorded } from './playtest-edits.ts';
import { agentStep, stepBy } from './mcp/play.ts';
import { createTouched, touchedBy } from './claude-steps.ts';
import type { KeepChoice, PagePlay } from './mcp/host.ts';
import { createViewHost } from './view-host.ts';
import { prefabPathOf } from './assets/ui/prefab-steps.ts';
import { createOpened } from './opened.ts';
import { anotherWorld } from './paste.ts';
import { livePrefabs, whenCompiled, whenLanded } from './prefabs-live.ts';
import { createOverrideSteps } from './overrides-steps.ts';
import { createHold, PRESSES } from './hold.ts';
import { renameInSave } from './level-keys.ts';
import { createRenames } from './renames.ts';
import { createColliderLines } from './physics/collider-lines.ts';
import { modelBounds } from './physics/model-bounds.ts';
import { physicsPage } from './physics/physics-page.ts';
import { readPhysics, writePhysics, type PhysicsGuard } from './physics/settings-client.ts';
import { physicsBlocks } from './physics/physics-blocks.ts';

/** A key of the editor's own: a MrDebug action that says its MCP tool (`Mcp`, Docs/skills.md §2 rule 7). */
type EditorKey = DebugAction & { mcp: Mcp };

// boot's steps, in a debug build: the scene marked "Open this scene on start", and the asset pipeline's
// re-exports swapped into the running game (Docs/assets.md §8) -- still the project's one import of the package, through boot.
export { openedOnStart } from './config/scenes.ts';
export { watchAssets } from './assets/boot.ts';

/** The editor as boot holds it: open from the moment it is made, and never closed (the page is the editor's). */
export interface Editor {
  /** Something the person should see, on the notices strip under the top bar (`notices.ts`): boot's. */
  notice(kind: BootNoticeKind, text: string, error?: unknown): void;
  /** Every notice of `kind` put away: boot's, on a good swap (a failed one's, a system's that threw). */
  clearNotice(kind: BootNoticeKind): void;
  /** No playtest, one running (the editor hidden under the game), or one paused with the editor over its world (`playtest-state.ts`). */
  readonly playtestState: PlaytestState;
  /** A playtest running, paused: the game stopped, the editor over its world as it is now (boot's `P`). In any other state, nothing (`playtest-state.ts`'s `'pause'`). */
  pausePlaytest(): void;
  /** A paused playtest run on from the world as it is, the edits made meanwhile in it (boot's `P` again). In any other state, nothing (`'resume'`). */
  resumePlaytest(): void;
  dispose(): void;
}

export interface EditorOptions {
  /** What is being edited, under the title, until a tool names it (a scene saved or loaded). */
  name(): string;
  /** The game being edited: its world, its scene. */
  game: Game;
  /**
   * A playtest begins, or ends: boot runs the game with its HUD up, or stops
   * it and puts the HUD away, the editor still open under it. Told after the editor has hidden itself, and
   * before it puts the world back. A pause is told as an end (`false`) and its
   * resume as a beginning (`true`): the game stopped, or running, the same way.
   */
  onPlaytest(playing: boolean): void;
  /** The tools, in order: those with a tab of their own on the bar, the rest `within` one. Default: Scene, Config, Model, Studio (the Assets panel within Scene and Model). */
  tools?: EditorTool[];
  /**
   * A game's own pages of the Config tab, after the editor's (Systems, Scenes,
   * Preferences, Keys, and the Assets tool's Tools): each under its group --
   * one of the editor's, or its own, after them (`config/pages.ts`).
   */
  pages?: ConfigPage[];
  /**
   * A game's own inspector blocks (`blocks.ts`' `BlockItem`): each drawn where its order puts it among the
   * editor's -- Transform 10, View 20, the components' fields 30 -- or in place of the one of its id.
   */
  blocks?: BlockItem[];
  /**
   * A project's own (`boot`'s `tools` module: `ProjectTools`, `@vibe/engine/boot`): its tools after the editor's
   * (or after `tools`) -- one with the id of one of them in its place -- its pages and blocks after any given here.
   */
  extensions?: EditorExtensions;
  /**
   * Studio mode's recovery (Docs/studio.md §1): the game could not load, and `game` is boot's stand-in -- an empty
   * world. The error the first notice, with Reload; the Studio tab up on its Console as the editor first opens; no
   * resume record written for the stand-in's world; the page reloaded when the fix lands (`recovery.ts`).
   */
  recovery?: { error: unknown };
  /** What boot had to say before the editor was made: the strip's first notices, after recovery's. */
  notices?: readonly { kind: BootNoticeKind; text: string; error?: unknown }[];
}

/**
 * The editor's own root is a keys field (`data-keys-field`): text typed into
 * any field in it -- unless one nearer has keys of its own (the prompt box, a
 * dialog's name) -- reaches only the actions of this field: Mod+S's save, Mod+I's AI card.
 */
const EDITOR_FIELD = 'editor';
/**
 * The fields Mod+I is taken typed into (`ai card typed`): the editor's own, the inspector's key pickers (a field
 * of their own, nearer than the editor's), and the Studio tab's plain text fields.
 */
const AI_TYPED_FIELDS = [EDITOR_FIELD, KEY_FIELD, GIT_FIELD, CONSOLE_FIELD, SEARCH_FIELD] as const;
/** The fields Mod+S saves from (`save typed`): the editor's own, and a key picker's -- its list shut by the blur. */
const SAVE_TYPED_FIELDS = [EDITOR_FIELD, KEY_FIELD] as const;
/** Back from an opened prefab, out to what it was opened from (as Mod+↑ is a folder up in Assets): its button's key, there at any width. */
const BACK = tabKey('prefab back');

/** The editor's own keys' group on the keys card: tools' keys go under their tool's name. */
const OWN_KEYS = 'Editor';
/** The agent's prompt box's own keys, typed into it: their group on the keys card. */
const PROMPT_KEYS = 'Prompt';
/** The dock's gap between its cards, as `shell.css` has it. */
const DOCK_GAP = 8;
/** The canvas outside the game's frame (Docs/game-view.md §3): the editor's own dark, `shell.css`' `--code-bg`. */
const OUTSIDE = 0x10141c;

/** How long a line the editor says itself stays on the top bar's status line, in milliseconds. */
const SAY_MS = 12_000;
/** How long one with more to it on hover stays: something went wrong, and the way on takes reading. */
const SAY_LONG_MS = 60_000;
/** How long a path being copied may take: a window not in front may never answer, and a click must say something. */
const COPY_MS = 1000;

/** A text file the Code card opens from a turn's result row: source and data, not art. */
const CODE_FILE = /\.(?:ts|js|json|lua|md|css|html|prefab|scene)$/i;

/** What the editor takes back from a reload as it is made: its tool, the selection, the camera, the unsaved mark, the agent's edits, and what to say. */
interface Resumed {
  tool: string;
  /** The side with the keys, if another than `tool` (the Assets panel within its tab). */
  focused: string | undefined;
  selection: EntityRef[];
  camera: CameraPose | null;
  unsaved: boolean;
  /** The agent's editor edits as values (the record's `agent`): its card's to read. */
  agent: unknown;
  /** The agent's card minimized, as the page before left it; undefined, the preferences say. */
  agentMinimized: boolean | undefined;
  /** Each tool's own, by its id (`ToolInstance.carry`). */
  tools: Record<string, unknown>;
  notes: string[];
}

/** What `resume` brought back, until `createEditor` takes it. */
let resumed: Resumed | null = null;

/** This page's id, once asked for: its resume record is its own, not another frame's or a copy's (`resume.ts`' `pageId`). */
let page: string | null = null;
const thisPage = (): string =>
  (page ??= pageId({
    state: () => window.history.state,
    replace: (state) => window.history.replaceState(state, ''),
    // A page on the LAN is no secure context: no randomUUID there.
    make: () => globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`,
  }));

/**
 * At boot, before anything else sees the world (`boot`'s `EditorModule`, `@vibe/engine/boot`):
 * the record of a reload the editor survived (`resume.ts`), read and deleted,
 * its world loaded in place of the game's -- a component this build lacks
 * skipped, and said; a world too big to keep, or one that will not load (the
 * world put back first, `resumeWorld`), the scene as last saved. True if there
 * was one: boot then skips the start scene -- false too when the world would
 * not load and no scene could stand in for it.
 */
export function resume(game: Game): boolean {
  const record = takeResume(thisPage(), Date.now());
  if (!record) return false;
  const notes: string[] = [];
  let scene = record.scene;
  let unsaved = record.unsaved;
  /** The record's own world is the one now: only then do its selection's refs and the agent's values name what they did. */
  let loaded = record.world !== null;
  if (record.world) {
    // One that will not load: the world put back, then the scene as last saved; neither, boot goes on as with no record.
    const name = scene?.current ?? null;
    const done = resumeWorld(game, record.world, () => {
      const kept = name === null ? null : loadKept(game, name);
      return kept !== null && !('error' in kept);
    });
    if (done.how === 'loaded') {
      if (done.skipped.length > 0) notes.push(`Back from the reload${skippedText(done.skipped)}`);
    } else if (done.how === 'kept') {
      notes.push(`The world kept across the reload did not load (${done.why}): ‘${record.title ?? name}’ is back as last saved`);
      scene = scene && { ...scene, edited: false };
      unsaved = false;
      loaded = false;
    } else {
      console.warn(`[editor] The world kept across the reload did not load: ${done.why} -- the game starts as it would with none`);
      return false;
    }
  } else {
    // Too big to keep: the scene as last saved, by its key, if its file is there.
    const name = scene?.current ?? null;
    const done = name === null ? null : loadKept(game, name);
    const called = record.title ?? name ?? 'The world';
    if (done && !('error' in done)) {
      notes.push(`‘${called}’ was too big to keep across the reload: it is back as last saved`);
      scene = scene && { ...scene, edited: false };
      unsaved = false;
    } else {
      notes.push(`‘${called}’ was too big to keep across the reload: this is the game's own world`);
      scene = null;
    }
  }
  // What the page before had to say after it: an Apply its stack held that the prefab files still do.
  for (const note of record.notes) notes.push(`Back from the reload: ${note}`);
  if (scene) resumeScene(scene);
  // The world as last saved, not as the agent left it: its edits' values, and the selection's refs, mean nothing there.
  resumed = { tool: record.tool, focused: record.focused, selection: loaded ? (record.selection as EntityRef[]) : [], camera: record.camera, unsaved, agent: loaded ? record.agent : null, agentMinimized: record.agentMinimized, tools: record.tools, notes };
  for (const note of notes) console.warn(`[editor] ${note}`);
  return true;
}

/**
 * The editor, made over the game. One that throws half made -- a tool's module mid-edit, anything `makeEditor` meets --
 * takes its keys back off MrDebug before the throw goes on (`undoOnThrow`), so boot's next try (studio mode's P)
 * registers them again rather than failing on names already there. Nothing else of it is undone: a reload is the
 * clean way.
 */
export function createEditor(options: EditorOptions): Editor {
  const keys: (() => void)[] = [];
  return undoOnThrow(keys, () => makeEditor(options, keys));
}

/** `createEditor`'s making: `keys` the undo of every key it registers, for its dispose and for a throw. */
function makeEditor(options: EditorOptions, keys: (() => void)[]): Editor {
  const { name, game, onPlaytest, extensions = {} } = options;
  // The keymap every key below is looked up in (Docs/navigation.md §8): the preference's, before a key is registered.
  setKeymap(loadPrefs().nav.keymap);
  /** Studio mode's recovery: over a stand-in game, the page reloaded when the fix lands. */
  const recovering = options.recovery !== undefined;
  /** What went wrong that the person should see (`notices.ts`): recovery's error first, then boot's earlier ones. */
  const notices = createNotices();
  if (options.recovery) notices.add('boot', bootText(options.recovery.error), options.recovery.error);
  for (const n of options.notices ?? []) notices.add(n.kind, n.text, n.error);
  // Someone with preferences kept from before the keymap: their keys changed under them -- told once, then kept. Someone
  // new: kept, nothing said.
  const news = keymapNews();
  if (news !== 'none') keepPref('nav', { ...loadPrefs().nav });
  if (news === 'tell') notices.add('keys', KEYMAP_NEWS);
  /** The notices drawn: Reload while the game could not load -- a reload the editor lets past its guard (`reloadNow`). */
  const noticesStrip = createNoticesStrip(notices, () => reloadNow());
  /** The tools: the editor's (or those given), then a project's own -- one with the id of one of those in its place (a game's own Assets tool, `assets`). */
  // The Studio tab after Model; Scene first, the tab a first open lands on (`sides`, below).
  // Each of the editor's own an `EditorTab`: its id one of `tab-pages.ts`', which names its skill page.
  const ownTabs: readonly EditorTab[] = [entitiesTool, configTool, modelTool, studioTool, assetsTool];
  const given = options.tools ?? ownTabs;
  const projects = new Map((extensions.tools ?? []).map((tool) => [tool.id, tool]));
  const tools: EditorTool[] = [...given.map((tool) => projects.get(tool.id) ?? tool), ...(extensions.tools ?? []).filter((tool) => !given.some((g) => g.id === tool.id))];
  const gamePages: ConfigPage[] = [...(options.pages ?? []), ...(extensions.pages ?? [])];
  /** The inspector's blocks: the editor's own, a project's among them (`blocks.ts`). */
  // The editor's own blocks, the physics items among them (Fit to model, a body's state: `physics/physics-blocks.ts`), then a project's.
  const blocks = blockList([...BUILT_IN_BLOCKS, ...physicsBlocks()], [...(options.blocks ?? []), ...(extensions.blocks ?? [])]);
  const ids = tools.map((t) => t.id);
  if (new Set(ids).size !== ids.length) throw new Error(`[editor] two tools share an id: ${ids.join(', ')}`);
  /** The tabs, what each shows, which side has the keys and whose card the right panel is (`sides.ts`). */
  const sides = createSides(tools, tabsOf(tools)[0]?.id ?? '');
  /** Back from a reload: taken once, its selection chosen as the editor first opens. */
  let back = resumed;
  resumed = null;
  /** A line of the editor's own on the status line -- what a reload could not keep -- its whole text on hover, and until when. */
  let notice: { text: string; full: string; until: number } | null = null;
  // The shell picks its first tool while it is being made, before the tools are.
  let ready = false;
  /** The world as the playtest found it, put back when it ends; null while there is none. */
  let playing: WorldSave | null = null;
  /** The playtest is paused, the editor over its world as it is now (`playtest-state.ts`). */
  let paused = false;
  /** The scene's history as the playtest found it, put aside at its first pause and taken back at Stop. */
  let pauseKept: SetAside | null = null;
  /**
   * What each step taken while the playtest was paused changed (`playtest-edits.ts`' `diffSaves`), in order, by the
   * step: each one followed as the history moves (`followRecorded`), so a step undone is no edit -- and one fallen off
   * the history's end (its bound: a hundred steps, 64 MB) is still one, done for good, its step let go of. Only the
   * steps': the game's own doings between pauses are in none.
   */
  let recorded: Recorded<Step>[] = [];
  /** How many times the history is put aside while the pause's own steps are its: a prefab opened over it puts them aside again. */
  let pauseAside = 0;
  /** Every pause's edits before this one, a list a step: what Stop offers to keep with this pause's. */
  let playEdits: PausedStep[] = [];
  /** A step that is no edit of the person's is being committed (every instance brought up to a prefab compiled anew): not recorded. */
  let unrecorded = false;
  /** The paused hint said once: what Stop and Resume do with the edits made now. */
  let pausedSaid = false;
  /** The loop's tick as the playtest began: the strip's and the pill's time is the ticks since. */
  let playFrom = 0;
  /** While one runs, the pill's time said again each second (`showPlay`). */
  let playClock: ReturnType<typeof setInterval> | null = null;
  /** What Stop did with what was changed while paused, for the studio's `play_stop`. */
  type Stopped = ReturnType<PagePlay['stop']>;
  /** The playtest's state: none, running under the hidden editor, or paused with the editor over it. */
  const playState = (): PlaytestState => (playing === null ? 'none' : paused ? 'paused' : 'running');
  /** A playtest running: the game the player's, the editor hidden under it. Paused, the editor is the editor. */
  const running = (): boolean => playing !== null && !paused;
  /** Every card put away, the scene alone (`GUI_KEY`; Esc brings them back). Never kept: the editor opens with its cards. */
  let away = false;
  /** The tab Play left for the Scene tab, for Stop to go back to (`play-scene.ts`); null when Play moved nothing. */
  let playBack: PlayReturn | null = null;
  /**
   * Maximize on Play (Docs/game-view.md §3, D3): a playtest over the whole window with every card hidden, as before the
   * game view; off, it plays docked in the scene's room. The preference, read once and kept as it is turned over.
   */
  let maximizeOn = loadPrefs().maximizeOnPlay;
  /**
   * The game view's presets (Docs/game-view.md §4): the project's own and the one chosen -- the play strip's dropdown,
   * Config ▸ Game view and the `game_view_*` tools -- and the frame shaped anew as one changes.
   */
  const gameViews = createGameViews(() => roomMoved());
  /**
   * The stopped scene's Game look (D4): the world through the game's own cameras, shaped by the preset, the editor's
   * camera and gizmo put away -- the dropdown's Game, `game_view_set`'s `look`. Off, the editor's camera fills the room.
   */
  let gameLook = false;
  /** What a tool has called the world -- a scene's name -- or null for the game's own; and its hover text. */
  let title: string | null = null;
  /** Why the world's history last started again, as it does: the agent's rows say so of an edit it let go of. */
  let resetWhy = 'another scene was loaded';
  let titleNote: (() => string) | null = null;
  /** Each tool, made, in the bar's order. */
  const made: { tool: EditorTool; instance: ToolInstance }[] = [];
  /** The first tool's context, made once with it: what the agent's Save as prefab hands `saveAsPrefab`. */
  let firstContext: EditorContext | null = null;
  const heard = new Map<EditorEvent, Set<() => void>>();

  const shell = createShell({
    // The scene's name, with a dot while it has changed since it was saved.
    name: () => (ready && opened.key ? openedTitle() : `${title ?? name()}${recovering ? ' · recovery' : ''}${playtestBar(playState()).title}`),
    unsaved: () => ready && !history.saved,
    nameNote: () => (ready && opened.key ? openedNote() : (titleNote?.() ?? '')),
    // Every tab on the strip, in order -- the Config tab pinned to its foot (`place`); one within a tab (the Assets
    // panel) has no icon of its own.
    tools: tools.map((t) => ({ id: t.id, name: t.name, icon: t.icon, key: t.key ? keyLabel(t.key) : undefined, within: t.within !== undefined, place: t.place })),
    onTool: (id) => {
      // Another tab: the keys and the right panel its own tool's -- before the editor is ready too (a reload's tab).
      // Changed during a playtest, the person's own move: Stop leaves them there (`play-scene.ts`).
      if (sides.enter(id)) playBack = playTabChanged(playBack, playing !== null);
      if (!ready) return;
      show(id);
      // Another tool may keep another stack: the bars and the History card read it again.
      refreshBars();
      emit('tool', null);
    },
    undo: () => undo(),
    redo: () => redo(),
    // Asked once while the shell is being made, before the history is. The tool up's stack, or the world's.
    canUndo: () => ready && host.canUndo,
    canRedo: () => ready && host.canRedo,
    undoLabel: () => (ready ? host.undoLabel : null),
    redoLabel: () => (ready ? host.redoLabel : null),
    undoKey: keyLabel(UNDO[1]!),
    redoKey: keyLabel(REDO[1]!),
    // The first tool's that saves (Scenes); its Copy and Export are in that tool.
    save: () => save(),
    saveKey: keyLabel(SAVE),
    play: (button) => playtest(button),
    playKeys: { F5: keyLabel(PLAY_KEYS.F5), F6: keyLabel(PLAY_KEYS.F6), stop: keyLabel(PLAY_KEYS.stop), step: keyLabel(PLAY_KEYS.step) },
    maximize: () => setMaximize(!maximizeOn),
    gameView: (button) => gameViewMenu(button),
    // Claude's card shown or minimized; the button hidden where there is no card (`setAi`).
    ai: () => toggleAi(),
    aiKey: keyLabel(AI_KEY),
    prefabSave: () => savePrefab(),
    prefabBack: () => backPrefab(),
    backKey: keyLabel(BACK),
  });
  shell.setHidden(true);
  shell.root.dataset.keysField = EDITOR_FIELD;
  /** The top bar, whose end the dock stays below (`measure`'s `--ed-top-h`). */
  const top = shell.top;

  /** The world as changed, on screen: commands applied, the views placed, the gizmo and boxes on them, the frame drawn. */
  const draw = (): void => {
    game.world.flush();
    game.loop.present();
    viewport.update();
    topBar.refresh();
    game.renderOnce();
  };
  const history = createHistory();
  /**
   * Each prefab renamed while the editor is up, in order (Docs/prefabs.md §6): an older step's world names
   * the key as it was, and is followed through the renames made since it was taken as it is put back -- so an
   * undo past a rename brings its instances back as instances of the key now, not plain; a newer one is left.
   */
  const renames = createRenames();
  /**
   * Claude's edits shown (Docs/ai-panel.md D8): the entities its last turn changed, marked in the tree until the next
   * turn or a look (`marks`), and each step's, outlined in the scene as it lands (`landing`, read by the agent's
   * `changed`, once the page tools have put its turn on the step).
   */
  const marks = createTouched();
  let landing: { step: Step; refs: number[] }[] = [];
  // An edit that gets past the hold while an Apply's undo or redo lands is put back as it is committed, and said (`world-steps.ts`).
  const worldSteps = createWorldSteps(history, game.world, (save, era) => void game.load(renames.follow(save, era)), {
    held: () => overrides.holding(),
    refused: (line) => {
      say(line);
      emit('changed', null);
      draw();
    },
  }, () => renames.era, (step, before, after) => {
    // A step of Claude's: what it changed (refs), for the tree's marks and the scene's outline as it lands. While a
    // playtest is paused, each step's diff is kept by the step too (Docs/studio.md §1). One diff for both, made only then.
    const claude = stepBy(step.label) === 'Claude';
    const recording = paused && playing !== null && !unrecorded && history.aside === pauseAside;
    if (!claude && !recording) return;
    const edits = diffSaves(JSON.parse(before) as WorldSave, JSON.parse(after) as WorldSave);
    if (claude) landing.push({ step, refs: touchedBy(edits) });
    if (recording && edits.length > 0) recorded.push({ step, edits, undone: false, claude: agentStep(step.label) });
  });
  // A marked entity selected is seen: its mark goes (D8).
  const selection = createSelection(game.world, () => {
    marks.seen(selection.list.map((e) => game.world.ref(e)));
    emit('selection', null);
  });
  /**
   * The host choosing again what was chosen -- a prefab's root as it opens, the scene's selection on Back, a swap's by
   * ref (`chooseAsHost`): no one's choice, so the other side keeps its own (`choseIn`) -- Back gives the file back.
   */
  let hostChoosing = false;
  const chooseAsHost = (es: Entity[]): void => {
    hostChoosing = true;
    try {
      selection.chooseAll(es);
    } finally {
      hostChoosing = false;
    }
  };
  /** The prefab opened to edit, a stack (Docs/prefabs.md §7): the world and its history put aside meanwhile. */
  /**
   * Where each prefab open was opened from, outermost first -- the camera, and the
   * tool that was up (the Assets tool, for one opened from its files) -- put back
   * on its Back, so Back returns to the page it left.
   */
  const openedFrom: { pose: CameraPose | null; tool: string; focused: string; inspecting: string }[] = [];
  const opened = createOpened({
    world: game.world,
    history,
    worldSteps,
    load: (save) => void game.load(save),
    files: prefabFiles,
    problem: (key) => livePrefabs.problemOf(key),
    write: (path, text) => assetApi().putPrefab(path, text),
    selection: () => selection.refs,
    choose: (refs) => {
      const alive = refs.map((r) => game.world.deref(r)).filter((e) => e !== NONE && game.world.alive(e));
      if (alive.length > 0) chooseAsHost(alive);
    },
    changed: () => {
      // Another world -- the prefab's, or the one put aside, back: a lock on entities let go.
      emit('loaded', null);
      showOpened();
      draw();
      // Back from a prefab: the camera where it was, and the tab it was opened from up again, the keys and the right panel as they were.
      while (openedFrom.length > opened.stack.length) {
        const from = openedFrom.pop()!;
        if (from.tool !== shell.tool && ids.includes(from.tool)) shell.select(from.tool);
        focusTool(from.focused);
        // After the selection it had is chosen again, which would claim the right panel for the entities.
        queueMicrotask(() => inspectTool(from.inspecting));
        if (from.pose) viewport.setPose(from.pose);
      }
    },
    say: (line) => say(line),
    // The compile's checks, models included, before a Save writes: a file that would not compile is never written.
    check: (key, files) => checkPrefab(key, files, Assets.prefabChecks),
  });
  /** An instance's overrides settled: Revert, Unpack, and Apply with the prefab's file in its step (Docs/prefabs.md §7). */
  const overrides = createOverrideSteps({
    world: game.world,
    history,
    worldSteps,
    load: (save, era) => void game.load(renames.follow(save, era)),
    era: () => renames.era,
    followFiles: (files, era) => renames.followFiles(files, era),
    files: prefabFiles,
    compiled: (key) => {
      const text = livePrefabs.compiled?.get(key);
      return text === undefined ? undefined : (JSON.parse(text) as PrefabFile);
    },
    put: (path, text) => assetApi().putPrefab(path, text),
    landed: (texts) => whenLanded(texts),
    hold: (hold) => void (livePrefabs.hold = hold),
    check: (key, files) => checkPrefab(key, files, Assets.prefabChecks),
    told: () => {
      emit('changed', null);
      refreshBars();
      draw();
    },
    say: (line, full) => say(line, full),
    landing: (line) => holdEdits(line),
    // A late landing puts its world back only into the editor's own: not over the running game, nor a playtest.
    live: () => live(),
    uses: (literal) => assetApi().uses(literal),
    selected: () => selection.list,
    choose: (es) => selection.chooseAll(es),
  });
  // The tab closed or reloaded by hand with prefab edits not saved: the browser asks, as for the scene's (a reload the editor survives passes).
  // The scene's own mark is the one put aside under a prefab open: the prefab's stack is as saved when it opens.
  guardUnsaved({ beside: () => opened.unsavedAny, sceneSaved: () => sceneSaved() });
  // A recompile drains and warms the pools of what changed: no edit, so no step -- inside the steps while the editor is
  // up (an edit under way committed first), by itself while the game runs or a playtest does.
  livePrefabs.around = <T>(run: () => T): T => (live() ? worldSteps.unedited(run) : run());
  // Every instance out brought up to a prefab compiled anew: one step Z undoes, while the editor is up; in place during a
  // playtest. A prefab open follows what it nests itself (`opened.refresh`), and the scene under it is brought up on Back.
  livePrefabs.update = (label: string, run: () => void): void => {
    if (opened.key) return;
    if (!live()) return run();
    worldSteps.commit(PENDING);
    run();
    // The prefab's doing, not the person's: no edit of a paused playtest's either -- Stop brings the found world up to it.
    unrecorded = true;
    let made = false;
    try {
      made = worldSteps.commit(label);
    } finally {
      unrecorded = false;
    }
    if (made) say(`${label}: every instance out takes the prefab's new data where it holds no override of its own · Z undoes`);
    // What each instance overrides is worked out against the new compile: the marks and the lists read again.
    emit('changed', null);
  };
  // The game's code swapped in place (`Game.rebuild`, `rebuild-follow.ts`): no step, as a recompile is none. Before, a
  // playtest ended and an edit under way committed -- or the swap refused for a prefab open unsaved; after, the world read again.
  const follow: FollowHost = {
    isOpen: () => isOpen(),   // wrapped: `isOpen` is declared below, after this object is built
    playing: () => playing !== null,
    // The playtest's own end, Stop's: the world put back, and the editor's view and tools back with it -- paused or running.
    stopPlaying: () => endPlaying(),
    openedUnsaved: () => opened.unsavedAny,
    openedKey: () => opened.key,
    worldSteps,
    selection: {
      refs: () => selection.refs,
      alive: (refs) => refs.map((r) => game.world.deref(r)).filter((e) => e !== NONE && game.world.alive(e)),
      chooseAll: (es) => chooseAsHost(es),
    },
    loaded: () => emit('loaded', null, 'again'),
    say: (line) => say(line),
    draw,
  };
  // What before found -- a playtest it ended -- said in after's one line.
  let before: BeforeRebuild = { swap: true, playtestEnded: false };
  game.onBeforeRebuild = () => {
    before = beforeRebuild(follow);
    return before.swap;
  };
  game.onRebuilt = (change) => afterRebuild(follow, change, before);
  // A prefab the one open holds compiled anew (an inner one saved, its file changed beside it): shown there, its own edits kept.
  const offPrefabs = livePrefabs.onChange(() => {
    if (!opened.key || playing) return;
    const lines = opened.refresh();
    if (lines.length === 0) return;
    say(lines.join(' · '));
    emit('loaded', null, 'again');
    showOpened();
    draw();
  });
  // The editor's modal dialog (`dialog.ts`) goes over everything of the editor's: Back's question, a scene's "lose what changed?".
  const unmountDialogs = mountDialogs(shell.root);
  const viewport = createViewport({
    game,
    selection,
    // A gizmo drag is the tool up's edit: it kept up through 'moved', the others are told.
    edited: (label) => {
      if (worldSteps.commit(label)) emit('changed', shell.tool);
    },
    draw,
    root: shell.root,
    held: () => overrides.busy(),
    room: () => sceneRoom(),
    cubeRoom: () => cubeRoom(),
    // A camera's preview at the room's right, clear of Claude's column over the scene.
    previewRoom: () => clearRoom(sceneRoom()),
    // The wheel read as another device, or chosen: the top bar's status line says what scrolling does now (Docs/navigation.md).
    scrolled: (trackpad) => say(scrollLine(trackpad)),
  });
  // No main camera in the scene, said on the strip with the way to mend it (`camera-notice.ts`); looked at as each frame is drawn.
  /** The notice's steps, as the entity tool's edits make theirs (`edits.ts`): the world's step, every tool reading the world again. */
  const cameraSteps: StepHost = {
    world: game.world,
    selection,
    commit(label) {
      if (worldSteps.commit(label)) emit('changed', null);
      draw();
    },
  };
  const cameraNotice = createCameraNotice({
    world: game.world,
    notices,
    prefabOpen: () => opened.key !== null,
    add: () => void addMainCamera(cameraSteps, game.camera),
    makeMain: (e) => makeMainCamera(cameraSteps, e),
  });
  viewport.on('update', () => cameraNotice.check());
  // The colliders drawn (Docs/physics.md §7): in the game's scene, so a playtest shows them too -- built again for each
  // frame the editor draws, and each frame while a playtest runs.
  const colliderLines = createColliderLines(() => game.world, () => selection.list);
  game.scene.add(colliderLines.object);
  // Built again only when something may have moved: an edit, the selection, a load, a playtest's turn, a gizmo step.
  viewport.on('update', () => colliderLines.update());
  viewport.on('moved', () => colliderLines.stale());
  for (const event of ['changed', 'selection', 'playtest'] as const) on(event, () => colliderLines.stale());
  // Another world: the shapes kept for the last let go.
  on('loaded', () => colliderLines.forget());
  let colliderFrame = 0;
  const followColliders = (): void => {
    colliderFrame = requestAnimationFrame(followColliders);
    if (playing !== null && !paused && colliderLines.shown !== 'none') colliderLines.update(true);
  };
  colliderFrame = requestAnimationFrame(followColliders);
  const setColliders = (shown: 'none' | 'selected' | 'all'): void => {
    colliderLines.setShown(shown);
    draw();
  };
  /** Config ▸ Physics' rule, and `physics_settings_set`'s: no change in a playtest, on or off only with the scene saved. */
  const physicsGuard: PhysicsGuard = { playing: () => playing !== null, unsaved: () => !sceneSaved() };

  /** What the line said as the hold began: taken down with it. */
  let heldLine: string | null = null;
  /**
   * Every way into the editor that changes the world or its history, held while an Apply or its undo or redo lands
   * (`hold.ts` lists them): every key the editor registers (`addKey`), every press on its cards but the free ones, and
   * each whole-world entry point asked first (`hold.refuses`).
   */
  const hold = createHold({ line: () => overrides.holding(), say: (line) => say(line), inside: (target) => target instanceof Node && shell.root.contains(target) });
  // Before any card's or menu's own: a press on a held card stops here, so nothing behind it -- the scene -- has it either.
  for (const type of PRESSES) shell.root.addEventListener(type, (event) => void hold.pointer(event), true);
  // While held, nothing typed into a card's field lands: the field keeps the focus, the text as it was -- whatever
  // the panel is built again into meanwhile (an undo reads every tool again), so it is the input itself that is refused.
  shell.root.addEventListener('beforeinput', (event) => {
    if (heldLine !== null && event.target instanceof Element && event.target.closest('.ed-side, .ed-card')) event.preventDefault();
  }, true);
  /**
   * World edits held while an Apply or its undo or redo lands
   * (`overrides.landing`), or let go (null): the cards -- the tree, the
   * inspector, a tool's files, the top bar's actions -- refuse a press, said
   * (`hold.pointer`), their fields keep the focus but take no typing, every
   * key but those that only look is refused, the gizmo comes off the
   * selection, and the line says why. The world that lands would be loaded
   * over an edit made meanwhile.
   */
  function holdEdits(line: string | null): void {
    shell.root.classList.toggle('ed-held', line !== null);
    if (line !== null) {
      heldLine = line;
      say(line);
    } else if (heldLine !== null) {
      // The held line, and every "not now" refusal of it: none outlives the hold, or it reads as held still.
      if (notice?.text.endsWith(heldLine)) notice = null;
      heldLine = null;
      if (isOpen()) show(shell.tool);
    }
    // Undo and Redo off while it lands and back after it, on every bar: a step pushed meanwhile (the Apply's own)
    // was drawn while the stack waited.
    refreshBars();
    if (isOpen()) draw();
  }

  const instanceOf = (id: string): ToolInstance | undefined => made.find((m) => m.tool.id === id)?.instance;
  /** The tool with the keys: the tab's own, or -- in a tab it shares -- the side last pressed in (`sides.ts`). */
  const active = (): ToolInstance | undefined => instanceOf(sides.focused);
  /**
   * Whose Undo: the focused tool's own stack, if it has one, else the world's
   * -- an edit under way committed first only on the world's -- and nothing
   * while that tool is busy (`active-history.ts`).
   */
  const host = createHistoryHost({ world: history, tool: active, commit: () => void worldSteps.commit(PENDING), worldBusy: () => overrides.busy() });
  /** The stack Undo, Redo, the bars and the History card work on just now. */
  const activeHistory = (): History => host.history;
  /** Whose history the card names: the tool up's, if it keeps its own, else the world's. */
  const whose = (): string => (host.isWorld ? 'World' : (made.find((m) => m.tool.id === sides.focused)?.tool.name ?? 'World'));
  /** The tool holding Esc just now, if any. */
  const holder = (): ToolInstance | undefined => made.find((m) => m.instance.holdsEscape?.())?.instance;
  const saver = (): ToolInstance | undefined => made.find((m) => m.instance.save)?.instance;

  const isOpen = (): boolean => shell.shown;
  /** Open, and no playtest running: the game's keys are the game's while one runs. A paused one's world is the editor's. */
  const live = (): boolean => isOpen() && !running();
  /**
   * The scene's steps at their save: with a prefab open, the mark put aside under it, never the prefab's stack; with a
   * playtest paused, the mark put aside at its first pause -- the scene as Stop puts it back, never the pause's steps.
   */
  const sceneSaved = (): boolean => (opened.key !== null ? opened.outerSaved : pauseKept !== null ? keptSaved(pauseKept) : history.saved);
  /** Live, and the keys card shut: what it lists stands still while it is read. */
  const editing = (): boolean => live() && !keysCard.open;

  // The History card, shut until opened -- and then as it was left, from one visit to the next.
  // A turn's number in its conversation, for its group's words and tint (D8): the agent's card's transcripts, once made.
  const historyCard = createHistoryCard(activeHistory, whose, (to) => travel(to), loadPrefs().history, (turn) => measured?.turnNumber(turn) ?? null);
  const topBar = createTopBar({
    into: shell.controls,
    viewport,
    said: () => (notice && notice.until > Date.now() ? notice.text : null) ?? active()?.hint?.() ?? null,
    saidFull: () => (notice && notice.until > Date.now() ? notice.full : null),
    historyOpen: () => historyCard.open,
    toggleHistory: () => toggleHistory(),
    keysOpen: () => keysCard.open,
    toggleKeys: () => {
      if (live()) keysCard.toggle();
    },
    // G R S X V are the entity tool's keys: with the Assets panel focused (G is grid or list there), its buttons name none.
    gizmoKeys: () => sides.focused === entitiesTool.id,
    keysKey: keyLabel(editorKey('keys')[0]!),
    colliders: () => colliderLines.shown,
    setColliders: (shown) => setColliders(shown),
    physicsOff: () => !physicsSettings().enabled,
  });

  /** Every tool but `except` reads the world again. */
  function refreshTools(except: string | null = null): void {
    for (const { tool, instance } of made) if (tool.id !== except) instance.refresh?.();
  }

  /** The agent's card once made: what `measure` reads, asked by the card while it is being made too. */
  let measured: AgentCard | null = null;
  /** Claude's column, once the card is placed (`aiColumn`): docked or over the scene, as `measure` finds the room. */
  let column: AiColumn | null = null;

  /** What the host shows of history: the top bar's Undo and Redo, its status line, the History card. */
  function refreshBars(): void {
    // An opened prefab's Save is on while there is something to save.
    if (opened.key) showOpened();
    else shell.refresh();
    topBar.refresh();
    historyCard.refresh();
    // The tab up may send something else with a turn now: the card's line over its box.
    measured?.refreshWith();
  }

  /**
   * An event to everyone listening; then, after an edit, every tool but the one
   * that said so reads the world again -- that one has. After another world,
   * every tool does, the one that loaded it too: the tree, the inspector, each
   * page are of the world before until they read this one -- whoever loaded it,
   * whichever tab is up (a tool not shown reads it again as it is shown).
   */
  function emit(event: EditorEvent, from: string | null, load: Load = 'another'): void {
    // The selection dropped (a load into the same world chooses it again by ref); another world lets go of a lock on its entities.
    if (event === 'loaded') {
      // Another world, or this one loaded again (a scene opened or new, a prefab opened or Back, a playtest put back):
      // Claude's marks were of the one before (D8).
      marks.clear();
      landing = [];
      selection.drop();
      unlockEverywhere(load);
      // A clip copied before is from the world before: its refs out mean nothing here (`paste.ts`).
      if (load === 'another') anotherWorld(game.world);
    }
    for (const fn of heard.get(event) ?? []) fn();
    if (event === 'loaded') refreshTools();
    else if (event === 'changed') refreshTools(from);
  }

  function on(event: EditorEvent, fn: () => void): () => void {
    let set = heard.get(event);
    if (!set) heard.set(event, (set = new Set()));
    set.add(fn);
    return () => void set.delete(fn);
  }

  // The selection on screen before any tool reads it: the gizmo on it, the outlines round it.
  on('selection', draw);
  /** Undoing or redoing to a step of the History card: the tools read the world again once, at the end, not at each step. */
  let travelling = false;
  history.on((event) => {
    // History begun again or put aside (a prefab open, a pause): the marks were of the steps before (D8).
    if (event === 'reset' || event === 'aside') marks.clear();
    followRecorded(event);
    if (!ready || travelling) return;
    refreshBars();
    // After an undo or a redo the world is another one: everything is read again.
    if (event === 'undo' || event === 'redo') refreshTools();
  });
  // The bar says what the gizmo now does; the gizmo redraws itself.
  viewport.on('gizmo', () => topBar.refresh());

  /** Each editor key's group on the keys card, by its MrDebug name. */
  const groupOf = new Map<string, string>();
  /** The editor's keys that gave way to a game's debug key with no `when` (`editor-keys.ts`): one notice says them all. */
  const givenWay: KeyClash[] = [];
  let givenWayNotice: number | null = null;
  /** An editor key added -- or, a game's always holding one of its keys, gone without and said (Docs/studio.md, "Keys"). */
  const addOwnKey = (action: DebugAction): (() => void) => {
    const before = givenWay.length;
    const off = giveWay(MrDebug, action, givenWay);
    if (givenWay.length === before) return off;
    for (const c of givenWay.slice(before)) console.warn(`[editor] '${c.other}' always takes ${c.key}: the editor's '${c.editor}' goes without it`);
    givenWayNotice = sayGivenWay(notices, givenWayNotice, givenWay);
    return off;
  };
  /** The keymap switched (Config ▸ Preferences, Docs/navigation.md §8): `editor-keys.ts`' `switchKeymap`. */
  const changeKeymap = (keymap: Keymap): void => {
    givenWayNotice = switchKeymap(keymap, {
      keep: (k) => keepPref('nav', { ...loadPrefs().nav, keymap: k }),
      router: MrDebug, given: givenWay, notices, notice: givenWayNotice, card: keysCard,
    });
  };
  /**
   * A key of the editor's: a MrDebug action named `editor: …`, listed on the keys card under `group` -- held while an
   * Apply lands, refused and said, unless it only looks (`free`: `hold.key`). The editor's own take their keys from
   * `editor-keys.ts`' table (`editorKey`); a project tool's are its own.
   */
  const addKey = (group: string, action: EditorKey, free = false): (() => void) => {
    // A dialog up (`dialog.ts`): every key of the editor's rests but its own.
    const when = action.when;
    // A walk under way (Docs/navigation.md §4): every key but its own rests -- Esc above all, which puts the view back.
    // A walk or a right-button flight under way, or the right button held over a view (it may yet fly): its keys alone.
    const gated: DebugAction = { ...action, when: () => !dialogOpen() && walkGate(action.name, walking() || flyArmed()) && (when?.() ?? true) };
    const named = hold.key({ ...gated, name: `editor: ${action.name}` }, free);
    const off = addOwnKey(named); // mcp: typed: addKey's action, an EditorKey, carries its mcp
    groupOf.set(named.name, group);
    keys.push(off);
    return off;
  };
  // The dialog's first of all, live only while it is up (and never held: its answers wait on an Apply themselves).
  for (const action of dialogKeys()) {
    const off = addOwnKey({ ...action, name: `editor: ${action.name}` }); // mcp: ui -- a dialog's own keys: its answers are the asking action's
    groupOf.set(`editor: ${action.name}`, OWN_KEYS);
    keys.push(off);
  }
  // Blender's walk's keys and the right button's flight's (Docs/navigation.md §4, §7), live only while one is under way
  // or the right button is held over a view: held W A S D E Q (polled by the walk; taken here so they go nowhere else --
  // S never scales then, D never duplicates; one pressed with the right button held begins the flight), a click's Enter
  // or Space keeping, Esc putting back (a flight ends where it is).
  for (const way of ['forward', 'back', 'left', 'right', 'up', 'down'] as const) {
    addKey(OWN_KEYS, {
      mcp: 'ui', ...keyed(`walk ${way}`), hold: true, when: () => walking() || flyArmed(),
      help: `Walking or flying (the right button held): ${way}, held -- Shift faster, Alt slower`, run: () => flyKey(),
    }, true);
  }
  addKey(OWN_KEYS, { mcp: 'ui', ...keyed('walk keep'), when: () => walking(), help: 'Walking: keep the view where it is', run: () => endWalk(true) }, true);
  addKey(OWN_KEYS, { mcp: 'ui', ...keyed('walk put back'), when: () => walking(), help: 'Walking: the view put back where the walk began -- flying with the right button held: the flight ended where it is', run: () => endWalk(false) }, true);
  // The host's own, before the tools': these win.
  for (const tool of tools) {
    if (!tool.key) continue;
    addKey(OWN_KEYS, {
      mcp: 'ui',
      // Emulate Numpad with the pointer over a 3D view: the digit row is the numpad's there (Docs/navigation.md D5), the tabs' elsewhere.
      name: tool.id, key: tool.key, when: () => editing() && !(loadPrefs().nav.emulateNumpad && pointerOverView()), help: tool.help ?? `The editor's ${tool.name} tool`,
      run: () => summon(tool),
    }, true);
  }
  /** A tool asked for by its key is asked to be seen: its tab up, the keys its own. */
  function summon(tool: EditorTool): void {
    setAway(false);
    // A tool within several tabs comes up in the one up, if it is among them (the Assets panel in Scene or Model).
    shell.select(tabOf(tools, tool.id, shell.tool));
    focusTool(tool.id);
    if (tool.within !== undefined) instanceOf(tool.id)?.summon?.();
    shell.refresh();
  }
  // The agent's card, where there is a dev server to host Claude Code (Docs/agent.md §4): the host's, on every tab.
  const agentCard: AgentCard | null = import.meta.hot
    ? createAgentCard({
      context: () => gather(),
      // What the tool up sends besides: the Model tab's model and canvases (Docs/modeler.md M26).
      attachments: () => made.find((m) => m.tool.id === shell.tool)?.instance.attachments?.() ?? null,
      draw: () => draw(),
      canvas: game.renderer.domElement,
      // Maximized, the column hidden with every card while one runs (the pill's badge); docked, it stays live, or is set aside (`playAside`).
      playing: () => running() && maximizeOn,
      badge: (text) => shell.setBadge(text),
      // A card nobody can see would wait for good.
      attention: () => setAway(false),
      reveal: (path, turn) => reveal(path, turn),
      resized: () => measure(),
      // The ⋯ menu's way to the settings the chip has not: Config ▸ Claude ▸ Settings.
      settingsPage: () => void pages.show('claude'),
      // The AI button lit while the card shows: minimized by its button, brought back by a card waiting too; minimized,
      // its amber dot while a card waits unseen -- in a conversation not shown, or one minimized again.
      aiButton: (shown, waiting, running) => shell.setAi(shown, waiting, running),
      minimized: back?.agentMinimized,
      tools: {
        world: game.world,
        // The project's own MCP tools (src/tools/ mcpTools, Docs/mcp.md M7): declared in the hello, run here.
        project: () => extensions.mcpTools ?? [],
        history,
        worldSteps,
        // A paused playtest's world is the editor's: a turn's edit lands on it, a step, as with none.
        state: () => (running() ? 'playtest' : 'open'),
        // What studio_state says is open: the playtest's state, and the editor's tab shown.
        playtest: () => playState(),
        tab: () => tools.find((t) => t.id === shell.tool)?.name ?? null,
        selection: () => selection.list,
        scene: () => sceneFacts(),
        // studio_context (Docs/terminal.md D8): a column turn's facts, whole -- no attachments go with a tool's answer.
        context: () => gather(true),
        // An edit the agent made: drawn, and every tool reads the world again -- the step is already on the stack. What its
        // steps changed is marked in the tree and outlined in the scene for a moment (D8).
        changed: () => {
          const landed = landing;
          landing = [];
          for (const { step, refs } of landed) marks.landed(step.turn ?? null, refs);
          const alive = landed.flatMap((l) => l.refs).map((r) => game.world.deref(r as EntityRef)).filter((e) => e !== NONE);
          if (alive.length > 0) viewport.flash(alive);
          draw();
          emit('changed', null);
        },
        undo: (n) => undoWorld(n),
        save: (name) => saveScene(name),
        choose: (e) => selection.choose(e),
        // M2's: the selection set, the view for a camera, the prefab opened and closed, the Scenes page's own buttons.
        select: (es) => selection.chooseAll(es),
        view: () => viewport.view(),
        openPrefab: (key) => {
          const why = openPrefab(key);
          return why === null ? { readOnly: opened.readOnly } : { error: why };
        },
        closePrefab: (save) => closePrefabFor(save),
        saveOpened: () => (playing ? Promise.resolve({ error: 'A playtest is on: stop it first' }) : saveOpened()),
        openScene: (key, discard) => scenesForAgent().open(key, discard),
        newScene: (discard) => scenesForAgent().fresh(discard),
        saveSceneAs: (name) => scenesForAgent().saveAs(name),
        importScene: (text, name, discard) => scenesForAgent().importSave(text, name, discard),
        setStart: (key) => scenesForAgent().start(key),
        resetWhy: () => resetWhy,
        overrides,
        opened: () => opened.key,
        openedRoot: () => opened.root,
        // The tree's own Save as prefab, its key checked as the tree's question checks it.
        savePrefab: (key, entities, options) => {
          const problem = keyProblem(key, prefabFiles());
          if (problem) return Promise.reject(new Error(problem));
          // The first tool's context, as it was made: Save as prefab reads the world, its history and the selection, which every tool shares.
          return saveAsPrefab(firstContext ?? contextFor(tools[0]!), key, entities, () => emit('changed', null), options);
        },
        prefabProblems: () => {
          const out = new Map<string, string>();
          for (const key of [...livePrefabs.unparsed.keys(), ...(livePrefabs.last?.errorKeys ?? [])]) {
            const why = livePrefabs.problemOf(key);
            if (why !== null) out.set(key, why);
          }
          return out;
        },
        prefabStrays: () => prefabStrays(assetApi()),
        // What a key field may be set to: the assets loaded now, as the inspector's pickers offer them.
        keysOf: (kind) => Assets.keysOf(kind),
        keyKinds: () => Assets.keyKinds(),
        partsOf: (model) => Assets.partsOf(model),
        clipsOf: (e) => clipsOf(game.world, e),
        // M4: the playtest's keys, the view's and Y -- the same functions the keys and buttons call.
        play: agentPlay(),
        views: createViewHost({ game, viewport, room: () => sceneRoom(), modelShot: () => made.map((m) => m.instance.shot?.() ?? null).find((c) => c !== null) ?? null }),
        // The game view (Docs/game-view.md D7): the frame the game is drawn in, and Maximize on Play.
        gameView: {
          get: () => {
            const canvas = game.renderer.domElement;
            const f = game.frame;
            const whole = isWhole(f, canvas.clientWidth, canvas.clientHeight);
            const preset = gameViews.preset;
            return {
              frame: { x: f.x, y: f.y, width: f.width, height: f.height },
              canvas: { width: canvas.clientWidth, height: canvas.clientHeight },
              fills: whole ? 'window' : 'room',
              maximizeOnPlay: maximizeOn,
              preset: gameViews.chosen,
              applies: gameDraws() && preset !== null,
              pixels: { width: game.pixels.width, height: game.pixels.height },
              scale: game.scale,
              look: gameLook ? 'game' : 'scene',
              presets: presetRows(gameViews.own),
            };
          },
          setMaximize: (on) => setMaximize(on),
          choose: (name) => gameViews.choose(name),
          setLook: (on) => setGameLook(on),
          put: (ask, replacing) => gameViews.put(ask, replacing),
          remove: (name) => gameViews.remove(name),
          move: (name, by) => gameViews.move(name, by),
        },
        redo: (n) => redoWorld(n),
        // Physics (Docs/physics.md §7): Config ▸ Physics' file, Fit to model's bounds, the view menu's Colliders.
        physics: {
          read: () => readPhysics(),
          write: (change) => writePhysics(change, physicsGuard),
          bounds: (e) => modelBounds(game.world, e),
          colliders: () => colliderLines.shown,
          setColliders: (shown) => setColliders(shown),
        },
        // The Model tab's own doings, for the model tools (Docs/mcp.md M6).
        model: () => made.map((m) => m.instance.model).find((x) => x !== undefined) ?? null,
      },
      carried: back?.agent ?? null,
    })
    : null;
  measured = agentCard;
  // The game view (Docs/game-view.md §3): the toggle as the preference is; the canvas outside the room the editor's own dark.
  shell.setMaximize(maximizeOn);
  game.outside.set(OUTSIDE);
  // The play strip's game view dropdown (Docs/game-view.md §4): a press anywhere else closes it.
  const gameMenu = createMenu(shell.root, game.renderer.domElement);
  // The AI button's one say on whether it is there at all: hidden with no card (a build without a dev server), else as
  // the card is -- which says so itself from then on (`aiButton`).
  shell.setAi(agentCard ? !agentCard.minimized : null);
  // The quick prompt (Mod+K, Docs/ai-panel.md §4): a one-line box where the person is working, sent to the conversation
  // shown in Claude's column -- the column left as it is; its pill opens it.
  const quick = agentCard
    ? createQuickPrompt({
      root: shell.root,
      quick: agentCard.quick,
      onTurns: (fn) => agentCard.onTurns(fn),
      openColumn: () => (setAway(false), agentCard.focusBox()),
    })
    : null;
  if (agentCard && quick) {
    const card = agentCard;
    // A turn starting (any conversation's, as the list says): the last turn's marks go (D8).
    let wasRunning = card.running();
    card.onTurns((running) => {
      if (running && !wasRunning && marks.ids.size > 0) {
        marks.clear();
        instanceOf(entitiesTool.id)?.refresh?.();
      }
      wasRunning = running;
    });
    // Anywhere, the Code card's editor too (Monaco has no Mod+K of its own taken here: its Ctrl+K chords are Windows').
    addKey(OWN_KEYS, { mcp: NOT_FOR_CLAUDE.askClaude, ...keyed('quick prompt'), anywhere: true, when: () => isOpen() && !typingInTerminal(), help: 'Ask Claude about what is selected here -- the entities, the Assets panel\'s file, the Model tab\'s parts, the Code card\'s line -- in a box where you are: Enter sends to the conversation shown, Esc closes', run: () => quick.toggle(quickAt()) }, true);
    addKey(PROMPT_KEYS, { mcp: NOT_FOR_CLAUDE.askClaude, name: 'quick send', key: 'Enter', field: QUICK_FIELD, when: () => quick.open, help: 'Send the quick prompt to the conversation shown, with its target', run: () => quick.keys.send() }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'quick close', key: 'Escape', field: QUICK_FIELD, when: () => quick.open, help: 'Close the quick prompt, nothing sent', run: () => quick.close() }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'quick earlier', key: 'ArrowUp', field: QUICK_FIELD, when: () => quick.open && quick.keys.canRecall(-1), help: 'An earlier prompt, in the quick prompt', run: () => quick.keys.recall(-1) }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'quick later', key: 'ArrowDown', field: QUICK_FIELD, when: () => quick.open && quick.keys.canRecall(1), help: 'A later prompt, or back to what was typed, in the quick prompt', run: () => quick.keys.recall(1) }, true);
    addKey(OWN_KEYS, { mcp: 'ui', ...keyed('claude'), when: editing, help: 'Claude Code\'s prompt box, to type in: Claude\'s column shown if hidden', run: () => (setAway(false), card.focusBox()) }, true);
    // Not `anywhere`: typed into the Code card, Cmd+I is Monaco's own (its suggestions, `suggestController`'s second key).
    // In a docked playtest too: a column set aside for it is brought back for the rest of that playtest.
    addKey(OWN_KEYS, { mcp: 'ui', ...keyed('ai card'), when: () => editing() || (running() && !maximizeOn), help: 'Show or hide Claude\'s column (the AI button): shown, the prompt box focused', run: () => toggleAi() }, true);
    // The box's own: keys typed into it alone (MrDebug's field scope). ↑ and ↓ only from its first and last line --
    // listed on the keys card all the same, which asks while the box is not focused.
    const recalls = (step: -1 | 1): boolean => document.activeElement?.closest?.(`[data-keys-field="${FIELD}"]`) == null || card.keys.canRecall(step);
    // The slash list's (`/` typed first, Docs/agent.md §4): registered before the box's own Enter and ↑ ↓, which it
    // takes while open -- MrDebug's first live action on a key wins.
    const slashOpen = (): boolean => live() && card.keys.slashOpen();
    addKey(PROMPT_KEYS, { mcp: NOT_FOR_CLAUDE.claudeControl, name: 'slash run', key: 'Enter', field: FIELD, when: slashOpen, help: 'The slash command picked, completed -- and done at once if it takes nothing (/usage, /clear, /agents)', run: () => card.keys.slash('enter') }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'slash complete', key: 'Tab', field: FIELD, when: slashOpen, help: 'The slash command picked, completed in the box', run: () => card.keys.slash('tab') }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'slash up', key: 'ArrowUp', field: FIELD, when: slashOpen, help: 'The slash command above', run: () => card.keys.slash('up') }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'slash down', key: 'ArrowDown', field: FIELD, when: slashOpen, help: 'The slash command below', run: () => card.keys.slash('down') }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'slash close', key: 'Escape', field: FIELD, when: slashOpen, help: 'The slash list shut, the words kept', run: () => card.keys.slash('escape') }, true);
    // Free while an Apply lands, as the card is: a turn's editor tools wait for it themselves (`mcp/page.ts`).
    // Mod+I from the box: the column it is in hidden, as Mod+I shows it with the box focused -- typed into it, a key is the box's alone.
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'prompt ai card', key: AI_KEY, field: FIELD, when: live, help: 'Claude\'s column hidden, from the box (Mod+I brings it back)', run: () => toggleAi() }, true);
    addKey(PROMPT_KEYS, { mcp: NOT_FOR_CLAUDE.claudeControl, name: 'prompt send', key: ['Enter', 'Mod+Enter'], field: FIELD, when: live, help: 'Send the prompt (Shift+Enter is a new line); while a turn runs, it says so and keeps the words', run: () => card.keys.send() }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'prompt earlier', key: 'ArrowUp', field: FIELD, when: () => live() && recalls(-1), help: 'An earlier prompt, on the box\'s first line', run: () => card.keys.recall(-1) }, true);
    addKey(PROMPT_KEYS, { mcp: 'ui', name: 'prompt later', key: 'ArrowDown', field: FIELD, when: () => live() && recalls(1), help: 'A later prompt, or back to the draft, on the box\'s last line', run: () => card.keys.recall(1) }, true);
    // The card's tabs, conversations at once (Docs/agent.md §4): Alt chords -- Cmd+T, W, Tab and 1-9 are the browser's. Anywhere in the
    // editor, and typed into the box too but for the digits (Option+5 and 6 type [ and ] on some Mac layouts).
    const tabKeys: { name: string; mcp: Mcp; key: readonly string[]; help: string; run: () => void; box: boolean }[] = [
      { ...keyed('claude new tab'), mcp: NOT_FOR_CLAUDE.claudeControl, help: 'A new conversation in Claude Code\'s card, with the shown one\'s settings', run: () => card.tabs.create(), box: true },
      { ...keyed('claude close tab'), mcp: NOT_FOR_CLAUDE.claudeControl, help: 'The conversation shown closed (asked first while it runs; the last one\'s is Clear)', run: () => card.tabs.close(), box: true },
      { ...keyed('claude next tab'), mcp: 'ui', help: 'The next conversation\'s tab', run: () => card.tabs.step(1), box: true },
      { ...keyed('claude previous tab'), mcp: 'ui', help: 'The conversation\'s tab before', run: () => card.tabs.step(-1), box: true },
      ...([1, 2, 3, 4, 5, 6] as const).map((n) => ({ ...keyed(`claude tab ${n}`), mcp: 'ui' as const, help: `Claude Code's conversation ${n}, shown`, run: () => card.tabs.show(n), box: false })),
    ];
    for (const k of tabKeys) {
      addKey(OWN_KEYS, { mcp: k.mcp, name: k.name, key: k.key, when: editing, help: k.help, run: () => (setAway(false), card.setMinimized(false), k.run()) }, true);
      if (k.box) addKey(PROMPT_KEYS, { mcp: k.mcp, name: `prompt ${k.name.replace(/^claude /, '')}`, key: k.key, field: FIELD, when: live, help: `${k.help}, from the box`, run: k.run }, true);
    }
    // A tab's title being typed: Enter keeps it, Esc lets it go.
    addKey(PROMPT_KEYS, { mcp: NOT_FOR_CLAUDE.claudeControl, name: 'tab title keep', key: 'Enter', field: TAB_FIELD, when: () => live() && card.tabs.renaming(), help: 'Keep the conversation\'s new title', run: () => card.tabs.commitRename() }, true);
    addKey(PROMPT_KEYS, { mcp: NOT_FOR_CLAUDE.claudeControl, name: 'tab title cancel', key: 'Escape', field: TAB_FIELD, when: () => live() && card.tabs.renaming(), help: 'Let the conversation\'s new title go', run: () => card.tabs.cancelRename() }, true);
  }

  /**
   * The AI button and Mod+I: Claude's column shown with the box focused -- or, showing, hidden (gone from the page, its
   * room given back). Nothing where there is no card.
   */
  function toggleAi(): void {
    if (!agentCard) return;
    if (!agentCard.hidden) {
      agentCard.setMinimized(true);
      return;
    }
    setAway(false);
    agentCard.focusBox();
  }

  /**
   * Where a quick prompt opens and what it is about (Docs/ai-panel.md §4): the focused side's tool's own, then the tab's
   * (the Assets panel's file, the Model tab's parts, the Code card's caret), then the scene's selection at its top in
   * the room clear of the cards and Claude's column, else the focused card's top with no target.
   */
  function quickAt(): QuickAt {
    const whole = { left: 0, top: top.getBoundingClientRect().bottom, right: innerWidth, bottom: innerHeight };
    for (const id of new Set([sides.focused, shell.tool])) {
      const at = instanceOf(id)?.quickTarget?.() ?? null;
      if (at) return at;
    }
    const room = clearRoom(sceneRoom()) ?? whole;
    const middle = { x: (room.left + room.right) / 2, y: room.top + 40 };
    if (shell.tool === entitiesTool.id && selection.list.length > 0) {
      return { target: entitiesTarget(game.world, selection.list), anchor: viewport.screenOf(selection.list) ?? middle, room };
    }
    const card = instanceOf(sides.focused)?.cards?.().find((c) => !c.hidden && c.offsetWidth > 0);
    const at = card?.getBoundingClientRect();
    if (at) return { target: null, anchor: { x: at.left + at.width / 2, y: at.top + 40 }, room: { left: at.left, top: at.top, right: at.right, bottom: at.bottom } };
    return { target: null, anchor: middle, room };
  }

  /**
   * Ask Claude about something (Docs/ai-panel.md §5, A3): the quick prompt opened with `target` and `text` -- at `at`
   * (an item's row, a menu's point) in the window, or, given none, where Mod+K would open for an entity target -- never
   * sent by itself. False with no Claude.
   */
  function askAbout({ target, text, at }: { target: TurnTarget; text?: string; at?: HTMLElement | { x: number; y: number } }): boolean {
    if (!quick) return false;
    setAway(false);
    const window = { left: 0, top: top.getBoundingClientRect().bottom, right: innerWidth, bottom: innerHeight };
    let place: QuickAt;
    if (at instanceof HTMLElement) {
      const box = at.getBoundingClientRect();
      place = { target, anchor: { x: box.left + box.width / 2, y: box.top }, room: window };
    } else if (at) place = { target, anchor: at, room: window };
    else {
      const room = clearRoom(sceneRoom()) ?? window;
      const point = target.kind === 'entities' ? viewport.screenOf(target.entities.map((e) => e.id as Entity)) : null;
      place = { target, anchor: point ?? { x: (room.left + room.right) / 2, y: room.top + 40 }, room };
    }
    // A problem's message or a console line held within the server's cap, head and tail kept, the cut marked.
    quick.ask({ ...place, target: capTarget(place.target!) }, text);
    return true;
  }

  /** Claude's column set aside by `playAside` for the playtest running now. */
  let asideSet = false;
  /** Shown during this playtest -- by Mod+I, the AI button or a card waiting -- after it was set aside: not again until Stop. */
  let shownInPlay = false;

  /**
   * A docked playtest and Claude's column over the scene (Docs/ai-panel.md D5): the column set aside while the game
   * runs, so it never covers the game, its HUD or the Assets panel -- hidden as if minimized, the preference untouched
   * -- unless the person shows it (Mod+I, the AI button) or a card waits, which keeps it shown for the rest of that
   * playtest. Paused or stopped, it is back as it was. A docked column, or a maximized playtest, is left as it is.
   * Called at each playtest change.
   */
  function playAside(): void {
    if (!agentCard) return;
    if (asideSet && !agentCard.aside) shownInPlay = true;
    if (playing === null) shownInPlay = false;
    const want = running() && !maximizeOn && !shownInPlay && (asideSet || (!agentCard.hidden && shell.root.classList.contains('ed-ai-over')));
    asideSet = want;
    agentCard.setAside(want);
  }

  /** The scene open -- its file's key (null: none yet), unsaved or not -- or null for the game's own world. */
  function sceneFacts(): { name: string | null; unsaved: boolean } | null {
    const mark = sceneMark();
    return mark && (mark.current !== null || mark.source !== null) ? { name: mark.current, unsaved: !history.saved } : null;
  }

  /**
   * What the editor shows, as the agent's turn's facts (`agent/context.ts`): the scene, the playtest, the tool up, each
   * tool's own, the selection. `whole`: for a sender with no attachments -- the terminal's prompts, `studio_context`
   * (Docs/terminal.md D9) -- each tool says what it would leave to them.
   */
  function gather(whole = false): TurnContext {
    const play = playState();
    return turnContext(
      {
        game: name(),
        playtest: running(),
        ...(play === 'none' ? {} : { play }),
        scene: sceneFacts(),
        tool: tools.find((t) => t.id === shell.tool)?.name ?? null,
      },
      made.map(({ tool, instance }) => ({ tool: tool.name, up: sides.isUp(tool.id), facts: instance.context?.(whole) ?? null })),
      game.world,
      selection.list,
    );
  }

  /**
   * A file of a turn's result, clicked: a text file (`CODE_FILE`)
   * opens in the Studio tab's Code card -- its diff from the turn's start when
   * the row has its turn, else the file -- and anything else is shown in the
   * Finder where the Assets tool's `POST reveal` may -- art under the roots --
   * else its path copied; which, the card says in its head.
   */
  async function reveal(path: string, turn?: string): Promise<string> {
    const coder = CODE_FILE.test(path) ? made.find((m) => m.instance.openFile) : undefined;
    if (coder) {
      setAway(false);
      try {
        if (turn !== undefined && coder.instance.openDiff) {
          await coder.instance.openDiff(path, turn);
          return `In the Code card: ${path} since the turn began`;
        }
        await coder.instance.openFile!(path);
        return `In the Code card: ${path}`;
      } catch (err) {
        return `Not opened in the Code card (${(err as Error).message}): ${path}`;
      }
    }
    try {
      await assetApi().reveal(path);
      return `Shown in the Finder: ${path}`;
    } catch {
      // Outside the asset folders: copied -- which a page without the focus is refused, or never answered: said either way.
      const copied = await Promise.race([
        navigator.clipboard.writeText(path).then(() => true, () => false),
        new Promise<false>((resolve) => setTimeout(() => resolve(false), COPY_MS)),
      ]);
      return copied ? `Path copied: ${path}` : `Not copied -- the page did not have the focus: ${path}`;
    }
  }

  /** The host's keys; `free` the ones that only look -- the cards, the camera, the keys card -- live while an Apply lands. */
  const own: (EditorKey & { free?: true })[] = [
    // Mod+S alone: plain S is the gizmo's Scale (Blender's G R S, Docs/navigation.md §7).
    { ...keyed('save'), mcp: 'scene_save', when: () => editing() && (saver() !== undefined || opened.key !== null), help: 'Save the current scene; with none yet, name it -- with a prefab open, the prefab', run: () => save() },
    // Typed into one of the editor's own fields (an inspector number, the tree's filter, a rename): the field committed
    // as its blur does, then saved -- never the browser's Save Page As. A key picker (its own field) the same: its blur
    // shuts the list first. A field with keys of its own (the prompt box) is apart.
    ...SAVE_TYPED_FIELDS.map((field): EditorKey => ({
      name: field === EDITOR_FIELD ? 'save typed' : `save typed ${field}`, mcp: 'scene_save', key: SAVE, field, when: () => editing() && (saver() !== undefined || opened.key !== null),
      help: 'Mod+S typed into a field of the editor\'s: what was typed committed, then saved',
      run: () => {
        const at = document.activeElement;
        if (at instanceof HTMLElement && shell.root.contains(at)) at.blur();
        save();
      },
    })),
    // Mod+I the same way, free as the AI button is: typed into the tree's filter, an inspector number, a rename (the
    // editor's own field), the Git message, the Console's filter, the Code card's search -- fields with keys of their
    // own, so each named. Not the Code card's Monaco (`code`), where Cmd+I stays Monaco's; the prompt box's is its own.
    ...AI_TYPED_FIELDS.map((field): EditorKey & { free: true } => ({
      name: field === EDITOR_FIELD ? 'ai card typed' : `ai card typed ${field}`, mcp: 'ui', key: AI_KEY, field, free: true,
      // No card, no key: Cmd+I stays the browser's.
      when: () => agentCard !== null && editing(),
      help: 'Mod+I typed into a field of the editor\'s: Claude\'s card shown with the box focused, or minimized',
      run: () => toggleAi(),
    })),
    { ...keyed('playtest'), mcp: ['play_start', 'play_stop'], when: isOpen, help: 'Play the game from the world as it is; T again puts the world back -- paused (P), T resumes it', run: () => playtest('T') },
    // The keys of every debugger. F5 and Shift+F5 taken whenever the editor is open, so the browser's reload never is;
    // F6 too (the browser's address bar) -- all three `anywhere`, typed into a field too; F10 only while paused, the one
    // state it does anything in.
    { ...keyed('play'), mcp: 'play_start', anywhere: true, when: isOpen, help: 'Play: a playtest from the world as it is, or a paused one run on (nothing while one runs)', run: () => playtest('F5') },
    { ...keyed('pause'), mcp: 'play_pause', anywhere: true, when: isOpen, help: 'Pause the playtest running: the editor over its world as it is now', run: () => playtest('F6') },
    { ...keyed('stop'), mcp: 'play_stop', anywhere: true, when: isOpen, help: 'Stop the playtest, running or paused: the world put back as it found it', run: () => playtest('stop') },
    { ...keyed('step'), mcp: 'play_step', when: () => live() && paused && playing !== null, help: 'Step: one tick of the paused playtest, then paused again', run: () => playtest('step') },
    { ...keyed('undo'), mcp: 'history_undo', when: editing, help: 'Undo the editor\'s last edit', run: () => undo() },
    { ...keyed('redo'), mcp: 'history_redo', when: editing, help: 'Redo the edit undone last', run: () => redo() },
    { ...keyed('history'), mcp: 'ui', free: true, when: editing, help: 'The History card: every step; a click on one undoes or redoes to it', run: () => toggleHistory() },
    // The camera works with every tool up, so this does too -- a tab with a scene of its own (Model) frames that.
    { ...keyed('frame all'), mcp: 'view_focus', free: true, when: editing, help: 'The editor\'s camera onto everything drawn -- on the Model tab, every view onto the model', run: () => frameAll() },
    // `?` opens the card and closes it again: live while it is open, as the others are not.
    { ...keyed('keys'), mcp: 'ui', free: true, when: live, help: 'This card: every editor key live just now, by tool', run: () => (setAway(false), keysCard.toggle()) },
    // The key left of 1: in a playtest too, where the one card left goes with the rest.
    { ...keyed('cards'), mcp: 'ui', free: true, when: isOpen, help: 'Every card of the editor out of the way, the scene alone -- and back (Esc brings them back too)', run: () => setAway(!away) },
    // Esc's order: the quick prompt first -- open, the focus gone from it, it is what the person is in the middle of --
    // then the cards back, before anything Esc would stop out of sight.
    { ...keyed('close quick prompt'), mcp: 'ui', free: true, when: () => quick?.open ?? false, help: 'Close the quick prompt, nothing sent', run: () => quick?.close() },
    { ...keyed('cards back'), mcp: 'ui', free: true, when: () => isOpen() && away, help: 'Bring the editor\'s cards back', run: () => setAway(false) },
    // Back from an opened prefab, with no card needed (a narrow window, the cards away): its question first while there are unsaved changes.
    { ...keyed('prefab back'), mcp: 'scene_close_prefab', when: () => editing() && opened.key !== null, help: 'Back from the prefab open to what it was opened from -- asking first while it has changes not saved', run: () => backPrefab() },
    { ...keyed('close keys'), mcp: 'ui', free: true, when: () => keysCard.open, help: 'Close the keys card', run: () => keysCard.close() },
    // The game view's dropdown, ahead of the playtest's Esc: open over a docked playtest, Esc shuts it and stops nothing.
    { ...keyed('close game view menu'), mcp: 'ui', free: true, when: () => gameMenu.open, help: 'Close the game view\'s dropdown', run: () => gameMenu.close() },
    { ...keyed('game view menu up'), mcp: 'ui', free: true, when: () => gameMenu.open, help: 'The item above in the game view\'s dropdown (Enter or Space chooses it)', run: () => gameMenu.step(-1) },
    { ...keyed('game view menu down'), mcp: 'ui', free: true, when: () => gameMenu.open, help: 'The item below in the game view\'s dropdown (Enter or Space chooses it)', run: () => gameMenu.step(1) },
    // Claude's ⋯ menu and its chip's popover (menu.ts' contract): Esc closes them, ahead of a docked playtest's Esc.
    { ...keyed('close claude menu'), mcp: 'ui', free: true, when: () => agentCard?.holdsEscape() ?? false, help: 'Close Claude\'s ⋯ menu, or its settings popover', run: () => agentCard?.cancel() },
    { ...keyed('claude menu up'), mcp: 'ui', free: true, when: () => agentCard?.menuOpen() ?? false, help: 'The item above in Claude\'s ⋯ menu (Enter or Space chooses it)', run: () => agentCard?.menuStep(-1) },
    { ...keyed('claude menu down'), mcp: 'ui', free: true, when: () => agentCard?.menuOpen() ?? false, help: 'The item below in Claude\'s ⋯ menu (Enter or Space chooses it)', run: () => agentCard?.menuStep(1) },
    {
      ...keyed('cancel'), mcp: 'ui', free: true, when: () => editing() && holder() !== undefined,
      help: 'Stop what the tool has under way -- a pick, a placing, a menu, a question -- and leave the editor open', run: () => holder()?.cancel?.(),
    },
    // The History card is a card over the rest, as the keys card is: Esc shuts it before it puts the editor away.
    { ...keyed('close history'), mcp: 'ui', free: true, when: () => editing() && historyCard.open && holder() === undefined, help: 'Close the History card', run: () => toggleHistory() },
    // A playtest, running or paused, after what Esc stops in a card (running, every card is hidden and none of those is
    // live): the playtest ended, the world it found put back, history as it was.
    { ...keyed('stop playtest'), mcp: 'play_stop', when: () => isOpen() && playing !== null, help: 'Stop the playtest, running or paused: the world put back as it found it, history as it was', run: () => playtest('Esc') },
    // With a prefab's edits not saved -- the one open's, or one's further out -- Esc is Back, one level, asking first if
    // that one has them. Never a silent drop.
    {
      ...keyed('prefab unsaved'), mcp: 'scene_close_prefab', when: () => editing() && opened.unsavedAny,
      help: 'With an opened prefab\'s changes not saved, at any level: Back one level, asking first if the one open has them', run: () => backPrefab(),
    },
  ];
  for (const { free, ...action } of own) addKey(OWN_KEYS, action, free === true);

  /**
   * The Config tab's pages (`config/pages.ts`): the editor's -- Game ▸ Systems and Scenes, Editor ▸
   * Preferences and Keys -- then a game's own; a tool adds its own as it is made (the Assets tool's Tools).
   * The Config tab makes each with its context.
   */
  const pages = createPages([
    systemsPage,
    scenesPage,
    preferencesPage({ setMaximize: (on) => setMaximize(on), setKeymap: (keymap) => changeKeymap(keymap) }),
    gameViewPage({ views: gameViews }),
    physicsPage(physicsGuard),
    keysPage({
      groupOf: (name) => groupOf.get(name) ?? OWN_KEYS,
      groups: () => [OWN_KEYS, PROMPT_KEYS, ...tools.map((t) => t.name)],
    }),
    // Claude ▸ Settings, Skills and CLAUDE.md, where the card is: the last two open their files in the Code card (reveal).
    ...(agentCard ? [claudePage(agentCard.settings), skillsPage({ open: (path) => reveal(path) }), claudeMdPage({ open: (path) => reveal(path) })] : []),
    ...gamePages,
  ]);

  const contextFor = (tool: EditorTool): EditorContext => ({
    game,
    world: game.world,
    root: shell.root,
    head: shell.head,
    history,
    worldSteps,
    selection,
    viewport,
    get tool() {
      return shell.tool;
    },
    get focused() {
      return sides.focused === tool.id;
    },
    focus: () => focusTool(tool.id),
    get inspecting() {
      return sides.inspecting === tool.id;
    },
    inspect: () => inspectTool(tool.id),
    chose: (browsing) => choseIn(tool.id, browsing === true),
    get lockable() {
      return sides.lockable;
    },
    get locked() {
      return sides.locked;
    },
    lock: (on) => lockInspector(on),
    get playing() {
      return running();
    },
    playtest: () => playState(),
    play: (button) => playtest(button),
    get title() {
      return title ?? name();
    },
    setTitle(named, note) {
      title = named;
      titleNote = note ?? null;
      shell.refresh();
    },
    showTool: (id) => {
      shell.select(tabOf(tools, id, shell.tool));
      focusTool(id);
    },
    get prefab() {
      return opened.key;
    },
    get prefabRoot() {
      return opened.root;
    },
    get prefabsUnsaved() {
      return opened.unsavedKeys;
    },
    get prefabsOpen() {
      return opened.stack;
    },
    openPrefab: (key) => openPrefab(key),
    modelFiles: {
      newModel: (dir) => {
        const lister = made.find((m) => m.instance.newModel);
        lister?.instance.newModel!(dir);
        return lister !== undefined;
      },
      importModels: (dir) => {
        const lister = made.find((m) => m.instance.importModels);
        if (!lister) return false;
        // Its panel up in the tab that is up (the Model tab's own), the sheet in view as the files come.
        setAway(false);
        shell.select(tabOf(tools, lister.tool.id, shell.tool));
        focusTool(lister.tool.id);
        lister.instance.importModels!(dir);
        return true;
      },
      adoptModel: (path) => {
        const lister = made.find((m) => m.instance.adoptModel);
        lister?.instance.adoptModel!(path);
        return lister !== undefined;
      },
      options: (path) => {
        const lister = made.find((m) => m.instance.modelOptions);
        lister?.instance.modelOptions!(path);
        return lister !== undefined;
      },
    },
    modelThumb: (key, type) => made.find((m) => m.instance.modelThumb)?.instance.modelThumb!(key, type) ?? Promise.resolve(null),
    revealAsset: (path) => {
      const lister = made.find((m) => m.instance.revealAsset);
      if (!lister) return false;
      // Its tab up -- Scene or Model, whichever is up, for the Assets panel -- the keys its own; the file it chooses shows in the right panel.
      setAway(false);
      shell.select(tabOf(tools, lister.tool.id, shell.tool));
      focusTool(lister.tool.id);
      lister.instance.revealAsset!(path);
      return true;
    },
    bottom: {
      folded: () => {
        const card = sides.up.map((id) => instanceOf(id)).find((i) => i?.setFolded && i !== instanceOf(sides.tab));
        return card?.folded?.() ?? null;
      },
      fold: (folded) => {
        const card = sides.up.map((id) => instanceOf(id)).find((i) => i?.setFolded && i !== instanceOf(sides.tab));
        card?.setFolded?.(folded);
      },
    },
    openModel: (path, how) => {
      const opener = made.find((m) => m.instance.openModel);
      if (!opener || running() || hold.refuses(`Open ${path}`)) return false;
      // Asked first, its tab brought up after: a path it does not open leaves the tab where it is.
      if (!opener.instance.openModel!(path, how)) return false;
      setAway(false);
      shell.select(tabOf(tools, opener.tool.id, shell.tool));
      focusTool(opener.tool.id);
      inspectTool(opener.tool.id);
      return true;
    },
    turnChanged: () => measured?.refreshWith(),
    askClaude: (text) => {
      if (!measured) return false;
      setAway(false);
      measured.prefill(text);
      return true;
    },
    ask: (request) => askAbout(request),
    canAsk: quick !== null,
    touched: (e) => marks.has(game.world.ref(e)),
    renamedPrefab: (from, to) => void renamePrefabInWorld(from, to),
    overrides,
    // The world as changed: the colliders built again too (`physics/collider-lines.ts`).
    draw: () => {
      colliderLines.stale();
      draw();
    },
    on,
    emit: (event) => emit(event, tool.id),
    keys: {
      // Live while its side has the keys (`sides.ts`) -- or either side, `anySide`. Its cards away, a tool's keys rest --
      // they would act on lists nobody sees -- but the tab's own where the scene is what it works in.
      add: ({ view, anySide, anyTab, ...key }) => addKey(tool.name, {
        ...key,
        when: () =>
          editing() &&
          (anyTab === true
            ? !away
            : sides.keyLive(tool.id, anySide === true) && (!away || ((viewport.active || instanceOf(tool.id)?.ownScene === true) && tool.within === undefined))) &&
          (key.when?.() ?? true),
      }, view === true),
    },
    refuses: (what) => hold.refuses(what),
    pages,
    blocks,
    control: (node, order) => placeControl(node, order),
  });

  /** The tools' controls in the top bar's middle, in their order (`EditorContext.control`). */
  const controlled: { node: HTMLElement; order: number }[] = [];
  function placeControl(node: HTMLElement, order: number): () => void {
    const entry = { node, order };
    // After every one of the same order or lower: ties keep the order added.
    const at = controlled.findIndex((c) => c.order > order);
    controlled.splice(at < 0 ? controlled.length : at, 0, entry);
    shell.middle.replaceChildren(...controlled.map((c) => c.node));
    return () => {
      const i = controlled.indexOf(entry);
      if (i < 0) return;
      controlled.splice(i, 1);
      node.remove();
    };
  }

  // Over everything of the editor's but a menu: the keys live as it opened, by group -- the editor's, then each tool's.
  const keysCard = createKeysCard(shell.root, game.renderer.domElement, {
    groupOf: (name) => groupOf.get(name) ?? OWN_KEYS,
    groups: () => [OWN_KEYS, PROMPT_KEYS, ...tools.map((t) => t.name)],
    changed: () => topBar.refresh(),
    wheel: () => viewport.wheel,
    setWheel: (mode) => viewport.setWheel(mode),
    mouse: () => active()?.mouse?.() ?? null,
  });

  for (const tool of tools) {
    const context = contextFor(tool);
    firstContext ??= context;
    try {
      made.push({ tool, instance: tool.create(context) });
    } catch (err) {
      // One tool that throws as it is made -- a project's, mid-edit -- is skipped, said: the editor comes up without it.
      console.error(`[editor] the tool '${tool.name}' did not start: the editor goes on without it`, err);
      notices.add('tools', `The tool '${tool.name}' did not start: the editor goes on without it -- ${errorText(err)}`, err);
      made.push({ tool, instance: { setVisible() {}, dispose() {} } });
    }
  }
  // Back from a reload: the tool it was on (said before `ready`, so nothing is shown yet) -- its tab, the keys its
  // own -- the camera where it was, and the unsaved mark as it was -- the history a fresh one.
  if (back) {
    if (ids.includes(back.tool)) {
      shell.select(tabOf(tools, back.tool));
      sides.focus(back.tool);
      // The side that had the keys -- the Assets panel, say -- has them again, and Z works its stack as before.
      if (back.focused !== undefined && back.focused !== back.tool && ids.includes(back.focused)) sides.focus(back.focused);
    }
    if (back.camera) viewport.setPose(back.camera);
    if (back.unsaved) history.forgetSaved();
    else history.markSaved();
    // Each tool's own -- the Model tab's cameras -- given back to it.
    for (const { tool, instance } of made) if (tool.id in back.tools) instance.takeBack?.(back.tools[tool.id]);
  }
  // A tool's own stack: its changes redraw the bars while it is up -- its undo and redo are its own business,
  // so no other tool reads the world again for them (only the world's do that, above).
  const stacks = new Set<History>();
  for (const { instance } of made) {
    const stack = instance.history;
    if (!stack || stack === history || stacks.has(stack)) continue;
    stacks.add(stack);
    stack.on(() => {
      if (ready && !travelling && activeHistory() === stack) refreshBars();
    });
  }
  // A plain copy of an instance's entity, and the ghost of a prefab being placed, drawn with the game's models.
  useModels((key, part) => Assets.instance(key, part));
  // A re-export swapped into the game while the editor is up redraws its frame: outlines, the gizmo.
  useDraw(() => {
    if (!live()) return false;
    draw();
    return true;
  });
  // After the tools' cards, on top of them where a narrow screen makes them meet: the History card, floating over the
  // scene on the bottom card; it grows upward.
  const dock = el('div', 'ed-dock');
  dock.append(historyCard.root);
  shell.root.append(dock);
  // Claude's column (Docs/ai-panel.md §3): the agent's card at the window's right edge, right of the inspector -- the
  // host's, on every tab; docked or over the scene as `measure` finds the room.
  column = agentCard ? aiColumn(shell.root, agentCard.root) : null;
  if (agentCard) shell.root.append(agentCard.root);
  // Docked until the room is measured (`placeColumn`).
  column?.place(true);
  /**
   * Recovery's reload (`recovery.ts`): a turn's end, a fix's file saved, an export landed -- a second after the last,
   * never while a turn runs, for as long as the page is in recovery (the boot notice has no Dismiss: Reload is its
   * way out). Heard through the Studio tab's hub: its `studio:file-changed`, and the export jobs on its `Live`.
   */
  const hub = import.meta.hot ? ((instanceOf(STUDIO_ID) as StudioInstance | undefined)?.hub ?? null) : null;
  const studioHub = recovering ? hub : null;
  /**
   * Mid-session (`code-notices.ts`, Docs/studio.md §1): the dev server's broken modules a notice each, a runtime error
   * placed at its TypeScript line -- each with Open, the Code card at the line. Over recovery's stand-in only counted.
   */
  const codeNotices = createCodeNotices({ notices, map: hub ? (stack) => hub.calls.stack(stack) : null, open: (file, line, col) => void hub?.openFile(file, line, col).catch((err: Error) => console.warn(`[editor] ${file} not opened: ${err.message}`)), show: !recovering, unhold: () => void hub?.calls.unhold().catch((err: Error) => console.warn(`[editor] the reload not let go: ${err.message}`)) });
  const offBroken = hub ? hub.hear('studio:broken', (m) => codeNotices.heard(m)) : () => {};
  // The dev server's evaluation probe, before it lets a page reload go (`probe-frames.ts`): a hidden frame of its page.
  const probes = hub ? createProbeFrames({ ack: (id) => hub.calls.probeAck(id), frame: probeFrame, later: (run, ms) => setTimeout(run, ms), cancel: (timer) => clearTimeout(timer as ReturnType<typeof setTimeout>) }) : null;
  const offProbe = hub && probes ? hub.hear('studio:probe', (m) => probes.asked(m)) : () => {};
  const probeDone = (event: MessageEvent): void => void (probes && probes.done(probeDoneId(event, location.origin) ?? ''));
  addEventListener('message', probeDone);
  void hub?.calls.broken().then((answer) => codeNotices.heard(answer), (err: Error) => console.warn(`[editor] the broken modules not fetched: ${err.message}`));
  /** The resume record of the reload before recovery, kept fresh for the real boot after the fix (`touchResume`). */
  const keepResume = (): void => void (recovering && touchResume(thisPage(), Date.now()));
  const recoveryReload = studioHub
    ? createRecoveryReload({
      running: () => agentCard?.running() ?? false,
      active: () => recovering,
      held: () => codeNotices.broken > 0,
      reload: () => reloadNow(),
      now: () => Date.now(),
      later: (run, ms) => setTimeout(run, ms),
      cancel: (timer) => clearTimeout(timer as ReturnType<typeof setTimeout>),
    })
    : null;
  /**
   * Claude tries first (`recovery-fix.ts`, Docs/studio.md §1): with `fixBoot` on, the host available and no turn
   * running, the boot error is sent in the Recovery conversation -- three tries across reloads at most, counted in
   * this tab's `sessionStorage`, which a good boot clears (a tab without one sends nothing: its count would start again
   * at every reload, no cap). The boot notice's line says what the try is doing; every turn's end but the try's own
   * goes to the reload rule.
   */
  const fixStore = tabTries();
  if (!recovering && fixStore) clearTries(fixStore);
  const recoveryFix = studioHub && recoveryReload && agentCard
    ? createRecoveryFix({
      api: createAgentApi(),
      store: fixStore,
      notices,
      fixLine: (line) => noticesStrip.fixLine(line),
      running: () => agentCard.running(),
      onTurns: (fn) => agentCard.onTurns(fn),
      settings: agentCard.settings,
      heard: (event) => recoveryReload.heard(event),
      later: (run, ms) => setTimeout(run, ms),
      cancel: (timer) => clearTimeout(timer as ReturnType<typeof setTimeout>),
    })
    : null;
  const offRecovery = studioHub && recoveryReload
    ? [
      studioHub.onFile((m) => recoveryReload.heard({ kind: 'file', path: m.path })),
      studioHub.onJob((job) => {
        if (job.state === 'done') recoveryReload.heard({ kind: 'export' });
      }),
    ]
    : [];
  /** Vite's overlay over the page: read, then closed -- the boot notice says it, and the editor is not to be covered. */
  const closeViteOverlay = (): void => {
    for (const overlay of document.querySelectorAll<HTMLElement & { close?: () => void }>('vite-error-overlay')) overlay.close?.();
  };
  /**
   * Vite's error, heard as `vite:error` whenever it comes (mid-session too: the notices and the Problems card say it, and
   * the editor is never covered) -- its overlay closed, which Vite's client makes once the listeners have run, so a beat
   * later (`shell.css` hides it meanwhile). In recovery, a game module that did not load: the browser's error names no
   * file, Vite's does -- or its overlay's, read if it came first; the boot notice says Vite's first words in place of
   * the browser's (`namedByVite`).
   */
  const viteHeard = (payload: unknown): void => {
    const err = (payload as { err?: ViteError } | null)?.err;
    if (err && typeof err.message === 'string') namedByVite(notices, err);
    setTimeout(closeViteOverlay, 0);
  };
  import.meta.hot?.on('vite:error', viteHeard);
  if (recovering && import.meta.hot) {
    const overlay = document.querySelector('vite-error-overlay')?.shadowRoot;
    const message = overlay?.querySelector('.message-body')?.textContent?.trim();
    const file = overlay?.querySelector('.file')?.textContent?.trim();
    if (message) namedByVite(notices, { message, ...(file ? { id: file } : {}) });
    closeViteOverlay();
  }
  /** Recovery's first open: the Studio tab up on its Console, where the server's log says what the fix did. */
  let consoleOwed = recovering;
  const barHeight = new ResizeObserver(() => measure());
  // Claude's column dragged wider, shown or hidden: the room past it changes, and whether it still docks.
  if (agentCard) barHeight.observe(agentCard.root);
  // A tool's card along the bottom -- the Assets panel -- under the dock: as it is dragged taller, folds or goes.
  for (const card of shell.root.querySelectorAll<HTMLElement>(':scope > .ed-bottom-card')) barHeight.observe(card);
  // The side cards as they are dragged wider, fold to their tab or come and go with a tab: the room past them changes.
  for (const card of shell.root.querySelectorAll<HTMLElement>(':scope > .ed-side')) barHeight.observe(card);
  // A slide of the cards back into place (`setAway`) ends where they stand: the cube's corner measured there, not mid-slide.
  shell.root.addEventListener('transitionend', (event) => {
    if (event.propertyName === 'translate' && event.target instanceof HTMLElement && event.target.parentElement === shell.root) roomMoved();
  });
  // A press or a focus in a tool's cards gives it the keys, in a tab it shares; the scene is the tab's own tool's.
  shell.root.addEventListener('pointerdown', pressedIn, true);
  shell.root.addEventListener('focusin', pressedIn);
  game.renderer.domElement.addEventListener('pointerdown', pressedIn, true);
  // The browser's own menu never over the editor or its scene: a right-click the editor has a menu for opens it
  // (the tree's, the scene's, the Assets panel's -- each prevents the browser's itself); one it has none for does
  // nothing. In a field of text -- the filter, the prompt box, a name typed -- the browser's stays, for its copy and
  // paste (`keepsBrowserMenu`). One capturing listener here, not one per card.
  shell.root.addEventListener('contextmenu', noBrowserMenu, true);
  game.renderer.domElement.addEventListener('contextmenu', noBrowserMenu, true);
  // The top bar as it lays out bounds the dock and the side panels from above.
  barHeight.observe(top);
  // The notices under the top bar: what the side panels start under, while any are up.
  shell.root.append(noticesStrip.root);
  barHeight.observe(noticesStrip.root);
  const offNotices = notices.on(() => measure());
  ready = true;
  historyCard.refresh();

  // ---------------------------------------------------------------- a reload it survives

  /**
   * The editor as it is, into this page's record in the tab's `sessionStorage` for the page that
   * comes back (`resume`): the tool, the world -- in a playtest, the one it
   * put aside -- unsaved or not, the selection, the camera, the scene's mark.
   * Not before the editor has opened, nor over recovery's stand-in. True if it was written.
   */
  function prepareReload(): boolean {
    if (!isOpen()) return false;
    // Over recovery's stand-in: its empty world is nothing to bring back -- the real boot after starts as ever.
    if (recovering) return false;
    if (!playing) worldSteps.commit(PENDING);
    // The prompt's draft, and Attach view: the box keeps them as typed, and once more now.
    agentCard?.keep();
    return writeResume({
      at: Date.now(),
      page: thisPage(),
      open: true,
      tool: shell.tool,
      focused: sides.focused,
      title: title ?? name(),
      // The scene's own mark: under a prefab open, as its history was put aside.
      unsaved: !sceneSaved(),
      // The scene, never a prefab's world: a prefab open is gone back from by the reload, its edits with it.
      // An Apply's undo or redo landing with its files written: the world it puts back, which the files after the reload hold.
      world: opened.outer ?? playing ?? overrides.landingTo() ?? game.world.save(),
      // Paused, what is chosen is of the playtest's world, and the record's is the one it found: none comes back.
      selection: opened.key || playing ? [] : [...selection.refs],
      camera: viewport.pose,
      scene: sceneMark(),
      // The agent's edits as values: the undo stack does not survive the reload, these do (Docs/agent.md §8).
      agent: agentCard?.carry() ?? null,
      // Minimized stays so across the reload.
      ...(agentCard ? { agentMinimized: agentCard.minimized } : {}),
      // Each tool's own, as values: the Model tab's cameras.
      tools: Object.fromEntries(made.flatMap(({ tool, instance }) => (instance.carry ? [[tool.id, instance.carry()]] : []))),
      // An Apply whose undo or redo could not land: the stack goes with the reload, the prefab files keep it -- said after.
      notes: overrides.notes(),
    });
  }

  /**
   * A reload is coming: the record written, and that one unload let past the
   * Scenes tool's guard -- for `PASS_MS`, or while the server is away, and
   * again when it is back (`resume.ts`).
   */
  const reloading = createReloadPass({
    // Recovery's stand-in passes with no record: nothing of it comes back, and a reload is its way out.
    write: passWrite(recovering, prepareReload),
    // In recovery the record is the real boot's, kept for it: a restart of the dev server meanwhile drops nothing.
    drop: () => {
      if (!recovering) dropResume(thisPage());
    },
    pass: letReloadPass,
    // Any answer is the server back; only a network error is not.
    ping: () => fetch('/', { method: 'HEAD', cache: 'no-store' }).then(() => true, () => false),
    now: () => Date.now(),
    later: (run, ms) => setTimeout(run, ms),
    cancel: (timer) => clearTimeout(timer as ReturnType<typeof setTimeout>),
  });
  const arm = (): void => reloading.arm();
  /**
   * A reload the editor asks for itself -- recovery's, when the fix lands, and the strip's Reload: armed first, as
   * Vite's are, so the Scenes tool's guard lets it by. A guard that asked would stop it -- silently in the app,
   * whose window has no "Leave site?" of a browser's but the one `will-prevent-unload` shows (Docs/studio.md §13).
   */
  function reloadNow(): void {
    keepResume();
    arm();
    location.reload();
  }
  // Vite's client awaits this before it pings and reloads: the promise settles once the pass is armed again.
  const disconnected = (): Promise<void> | undefined => reloading.away();
  const connected = (): void => reloading.back();
  /** The page going: armed, the record again, so an edit made while the server was away is kept. */
  const leaving = (): void => {
    // Recovery's page going, by any reload: the record kept for the real boot stamped fresh.
    keepResume();
    reloading.leaving();
  };
  addEventListener('pagehide', leaving);
  // Back from the back/forward cache: the page did not go after all.
  const shownAgain = (event: PageTransitionEvent): void => {
    if (event.persisted) reloading.shown();
  };
  addEventListener('pageshow', shownAgain);
  const hot = import.meta.hot;
  hot?.on('vite:beforeFullReload', arm);
  hot?.on('vite:ws:disconnect', disconnected);
  hot?.on('vite:ws:connect', connected);

  /**
   * `--ed-panel-h`: a tool's card along the bottom (`ed-bottom-card`, the
   * Assets panel) while it is shown, with the dock's gap above it -- the dock
   * sits on it, and the Model tab's views stay above it. `--ed-top-h`: where
   * the top bar ends, which the side panels, Claude's column, the strip and
   * the dock stay below. Then the room moved (`roomMoved`): Claude's column
   * placed first (`placeColumn`).
   */
  function measure(): void {
    const floor = bottomCard();
    const panel = floor ? floor.offsetHeight + DOCK_GAP : 0;
    shell.root.style.setProperty('--ed-panel-h', `${panel}px`);
    const end = Math.max(top.offsetTop + top.offsetHeight, noticesStrip.root.hidden ? 0 : noticesStrip.root.offsetTop + noticesStrip.root.offsetHeight);
    if (end > 0) shell.root.style.setProperty('--ed-top-h', `${end}px`);
    // The room past the cards may have moved with them: the game's frame, and the view cube to its corner (it draws only if its box moved).
    roomMoved();
  }

  /**
   * The game's frame (`Game.setFrame`, Docs/game-view.md §3): the scene's room between the cards -- the editor's camera,
   * a docked playtest's cameras, the pointer and the HUD all in it -- or the whole canvas with the cards away, the room
   * too small, or a playtest running maximized. Then the view cube, the camera preview and the editor's camera's shape.
   */
  function roomMoved(): void {
    // Claude's column first: docked or over the scene, the room is what is left of it.
    placeColumn();
    // The preset while the game's own cameras draw (D4), first: the frame then fits its box in the room at once.
    game.setResolution(gameDraws() ? resolutionOf(gameViews.preset) : null);
    game.setFrame(frameRoom());
    viewport.relayout();
    frameMarked();
  }

  /** Do the game's own cameras draw: a playtest running, or the Game look (paused or stopped). The preset applies then. */
  function gameDraws(): boolean {
    return running() || gameLook;
  }

  /**
   * The frame's box on the page for the paused edge (`--ed-frame-*`, `.ed-framed`), and the dropdown's words: the
   * preset's name, the box's size and scale in its tooltip.
   */
  function frameMarked(): void {
    const page = game.renderer.domElement.getBoundingClientRect();
    const f = game.frame;
    const style = shell.root.style;
    style.setProperty('--ed-frame-left', `${page.left + f.x}px`);
    style.setProperty('--ed-frame-top', `${page.top + f.y}px`);
    style.setProperty('--ed-frame-width', `${f.width}px`);
    style.setProperty('--ed-frame-height', `${f.height}px`);
    shell.root.classList.add('ed-framed');
    const preset = gameViews.preset;
    const where = gameDraws() ? `the game drawn ${boxWords(f, game.pixels, game.scale, preset)}` : 'shapes a playtest and the Game look; the editor\'s camera fills the room';
    shell.setGameView(gameViews.chosen, `Game view: ${gameViews.chosen} -- ${where}`);
  }

  /** The play strip's dropdown (Docs/game-view.md §4): Free Aspect, the built-ins, the project's own, Add…, Edit presets…, the Game look. */
  function gameViewMenu(at: HTMLElement): void {
    if (gameMenu.open) return gameMenu.close();
    const item = (name: string, words?: string): MenuItem => ({
      label: `${gameViews.chosen === name ? '✓ ' : '\u2003'}${name}`,
      mcp: 'game_view_set',
      title: words ?? `Shape the game view with ${name}`,
      run: () => void gameViews.choose(name),
    });
    const own = gameViews.own;
    const items: MenuItem[] = [
      item(FREE, 'The room as it is'),
      ...BUILT_IN.map((p) => item(p.name)),
      ...own.map((p, i) => ({ ...item(p.name), rule: i === 0 })),
      { label: 'Add…', mcp: 'game_view_preset', title: 'A preset of the project\'s own: a name, a size, a mode', rule: true, run: () => addPreset() },
      { label: 'Edit presets…', mcp: 'ui', title: 'Config ▸ Game view: the project\'s presets edited, reordered, removed', run: () => void pages.show(GAME_VIEW_PAGE) },
      {
        label: `${gameLook ? '✓ ' : '\u2003'}Game`,
        mcp: 'game_view_set',
        title: gameLook ? 'Back to the editor\'s camera: the scene to edit, filling the room' : 'The scene through the game\'s own cameras, shaped by the preset -- as a playtest draws it, nothing running',
        rule: true,
        run: () => setGameLook(!gameLook),
      },
    ];
    const f = game.frame;
    const foot = gameDraws() ? boxWords(f, game.pixels, game.scale, gameViews.preset) : `${f.width}×${f.height}, the editor's camera`;
    // Down to the room's foot at most -- the Assets panel and the History card below it -- scrolled past that.
    gameMenu.show(at, items, { foot, bottom: roomPastCards()?.bottom });
  }

  /** The dropdown's Add…: a name, a size and a mode asked for, the preset made and chosen -- or the dialog kept up, saying why not. */
  function addPreset(): void {
    const modes = ['fit', 'pixel', 'stretch:nearest', 'stretch:linear'];
    showDialog({
      title: 'Add a game view preset',
      text: 'A size is an aspect, 16:9 -- drawn Fit, at the screen\'s sharpness -- or pixels, 640x360, drawn Fit, Pixel (scaled by a whole number, nearest) or Stretch (scaled by any, nearest or linear).',
      field: { value: '', label: 'Name' },
      second: { value: '640x360', label: 'Size', title: 'An aspect, 16:9, or pixels, 640x360' },
      choice: { value: 'fit', label: 'Mode', options: [{ value: 'fit', text: 'Fit' }, { value: 'pixel', text: 'Pixel' }, { value: 'stretch:nearest', text: 'Stretch, nearest' }, { value: 'stretch:linear', text: 'Stretch, linear' }] },
      buttons: [{
        label: 'Add',
        kind: 'accent',
        run: (name, choice, _up, _ticks, size) => {
          const [mode, filter] = (modes.includes(choice ?? '') ? choice! : 'fit').split(':') as [ScaleMode, ScaleFilter | undefined];
          const made = gameViews.put({ name, size: size ?? '', mode, filter: filter && SCALE_FILTERS.includes(filter) ? filter : undefined });
          if (typeof made === 'string') {
            dialogNote(made);
            return false;
          }
          gameViews.choose(made.name);
          return true;
        },
      }],
    });
  }

  /**
   * The Game look on or off (D4): the scene through the game's own cameras and the preset, the editor's camera and
   * its gizmo put away -- or back. While a playtest runs the game's cameras draw anyway: it holds for the pause and the
   * stop after.
   */
  function setGameLook(on: boolean): void {
    if (gameLook === on) return;
    gameLook = on;
    if (!running()) {
      if (on) viewport.close();
      else viewport.open();
    }
    roomMoved();
    if (!running()) game.renderOnce();
  }

  /** The room as the game's frame, canvas-relative CSS pixels; null for the whole canvas. */
  function frameRoom(): { x: number; y: number; width: number; height: number } | null {
    if (running() && maximizeOn) return null;
    const room = sceneRoom();
    if (!room) return null;
    const canvas = game.renderer.domElement.getBoundingClientRect();
    return { x: room.left - canvas.left, y: room.top - canvas.top, width: room.right - room.left, height: room.bottom - room.top };
  }

  /**
   * Maximize on Play turned on or off (the play strip's toggle, `game_view_set`): kept as the preference, the toggle lit
   * as it is -- and a playtest running moved over at once, to the whole window or back into the room.
   */
  function setMaximize(on: boolean): void {
    maximizeOn = on;
    keepPref('maximizeOnPlay', on);
    shell.setMaximize(on);
    // Config ▸ Preferences' row, if it is up, as it is now.
    refreshTools();
    if (!running()) return;
    if (on) hideTools();
    else show(shell.tool);
    shell.setPlaying(true, on);
    roomMoved();
    playAside();
  }

  /**
   * `GUI_KEY`, and Esc back: every card slid off its edge, the scene alone, or
   * back where it was (`shell.setAway`). The editor stays open and the scene is
   * worked in as before; a card focused lets go, so no key lands on a button out
   * of sight, and the keys card shuts. Back, a card of the agent's that came
   * meanwhile is brought into view.
   */
  function setAway(on: boolean): void {
    if (away === on) return;
    away = on;
    shell.setAway(on);
    if (on) {
      keysCard.close();
      const focused = document.activeElement;
      if (focused instanceof HTMLElement && shell.root.contains(focused)) focused.blur();
    } else if (isOpen() && !running()) agentCard?.shown();
    topBar.refresh();
    // The room past the cards changed at once (`sceneRoom`): the game's frame, and the view cube to its corner.
    roomMoved();
  }

  /**
   * A line of the editor's own on the status line for a while: what a reload
   * could not keep. `full`, the whole of it, on hover -- and it stays longer.
   */
  /** `say`'s timer, cleared by the next line and by `dispose`. */
  let sayTimer: ReturnType<typeof setTimeout> | undefined;
  function say(text: string, full?: string, long = full !== undefined && full !== text): void {
    const ms = long ? SAY_LONG_MS : SAY_MS;
    notice = { text, full: full ?? text, until: Date.now() + ms };
    // Said while the editor is closed (a late landing, a rename's follow-up): kept for the next open, no tool shown under a hidden shell.
    if (isOpen()) show(shell.tool);
    clearTimeout(sayTimer);
    sayTimer = setTimeout(() => {
      sayTimer = undefined;
      if (notice && notice.until <= Date.now()) {
        notice = null;
        if (isOpen()) show(shell.tool);
      }
    }, ms + 50);
  }

  /**
   * Claude's column docked or over the scene (Docs/ai-panel.md D5): decided on the room as if it were hidden -- the room
   * measured, plus its width while it docks -- so it never flips with itself. Hidden, neither; the cards away or the
   * editor closed, as it was.
   */
  function placeColumn(): void {
    if (!column || !measured) return;
    if (measured.hidden) return column.place(column.docked);
    const room = roomPastCards();
    // Docked as the page has it now -- the class, not the last decision: hidden, the class went, and the room was
    // measured with the inspector at the window's edge.
    if (room) column.place(aiDocks(room.right - room.left, column.width(), aiDocked()));
    else column.place(column.docked);
  }

  /** Claude's column docked on the page now (its class on the root): only then does it take from the room. */
  function aiDocked(): boolean {
    return shell.root.classList.contains('ed-ai-docked');
  }

  /**
   * The room kept clear of Claude's column lying over it (D5, `room.ts`' `clearOf`): where the view cube and a camera's
   * preview go, so neither is drawn under the column.
   */
  function clearRoom(room: Room | null): Room | null {
    if (!room || !agentCard || agentCard.hidden || !shell.root.classList.contains('ed-ai-over')) return room;
    const at = agentCard.root.getBoundingClientRect();
    return clearOf(room, [{ left: at.left, top: at.top, right: at.right, bottom: at.bottom }]);
  }

  /** A tool's card along the bottom, shown: what the dock sits on. */
  function bottomCard(): HTMLElement | null {
    for (const card of shell.root.querySelectorAll<HTMLElement>(':scope > .ed-bottom-card')) if (!card.hidden && card.offsetHeight > 0) return card;
    return null;
  }

  /**
   * The scene's room on the page -- between the side cards (the tool strip
   * the leftmost), under the top bar, above a card along the bottom and the
   * dock -- what framing fills (`frameAll`, `focus`). Null for the whole
   * canvas: the cards away, or no room left.
   */
  function sceneRoom(): Room | null {
    const room = roomPastCards();
    return room && room.right - room.left > 80 && room.bottom - room.top > 80 ? room : null;
  }

  /**
   * The view cube's room: the scene's, but its foot the canvas's -- the cube
   * sizes from the top, so a tall Assets panel or the History card never
   * sends it to the canvas's corner under the right card. The whole canvas
   * (null) only with the cards away or the editor closed.
   */
  function cubeRoom(): Room | null {
    const room = clearRoom(roomPastCards());
    return room && { ...room, bottom: game.renderer.domElement.getBoundingClientRect().bottom };
  }

  /**
   * `sceneRoom` as measured, however little is left (`room.ts`' `roomBetween`): null only with the cards away or the
   * editor closed. Claude's column narrows it only while docked; over the scene it takes nothing.
   */
  function roomPastCards(): Room | null {
    if (away || !isOpen()) return null;
    const canvas = game.renderer.domElement.getBoundingClientRect();
    const cards: CardBox[] = [];
    for (const card of shell.root.children) {
      if (!(card instanceof HTMLElement) || card.hidden) continue;
      const at = card.getBoundingClientRect();
      if (card.classList.contains('ed-left') || card === shell.strip) cards.push({ side: 'left', left: at.left, top: at.top, right: at.right, bottom: at.bottom });
      else if (card.classList.contains('ed-right') || (card.classList.contains('ed-ai-column') && aiDocked())) cards.push({ side: 'right', left: at.left, top: at.top, right: at.right, bottom: at.bottom });
      // A bottom card folded to its tab (the Assets panel's `ed-as-folded`) sits over the game, as a side card's folded tab does.
      else if (card.classList.contains('ed-bottom-card') && !card.classList.contains('ed-as-folded')) cards.push({ side: 'bottom', left: at.left, top: at.top, right: at.right, bottom: at.bottom });
    }
    // Above the dock as it stands: the History card if open.
    const docked = dock.getBoundingClientRect();
    cards.push({ side: 'dock', left: docked.left, top: docked.top, right: docked.right, bottom: docked.bottom });
    return roomBetween(canvas, top.getBoundingClientRect().bottom + DOCK_GAP, cards);
  }

  /** Home: the tab up's own scene framed whole, if it has one (the Model tab's views), else the editor's camera onto the world. */
  function frameAll(): void {
    const own = instanceOf(sides.tab);
    if (own?.frameAll) own.frameAll();
    else viewport.frameAll();
  }

  /** The keys to `id`, in the tab it shares: the side lit, the bars reading its history. */
  function focusTool(id: string): void {
    if (!sides.focus(id)) return;
    lightSides();
    if (ready) refreshBars();
  }

  /** The right panel `id`'s card: each tool of the tab told whether it is its own. */
  function inspectTool(id: string): void {
    if (!sides.inspect(id) || !ready) return;
    for (const up of sides.up) instanceOf(up)?.setInspector?.(up === sides.inspecting);
  }

  /**
   * Something chosen in `id`: each other tool up in its tab lets go of its own choice -- one selection across the sides.
   * Not for the host's own choosing (`chooseAsHost`): a prefab opened from its file, Back gives the file back.
   */
  function choseIn(id: string, browsing = false): void {
    if (!ready || hostChoosing) return;
    for (const other of sides.chose(id, !browsing)) instanceOf(other)?.letGo?.();
  }

  /**
   * The right panel locked to what it shows, or unlocked, in the tab up: each tool of it told, to pin or let go --
   * unlocked, the panel the side chosen in last meanwhile (`afterUnlock`), each told whether it is its.
   */
  function lockInspector(on: boolean): void {
    if (!sides.lock(on) || !ready) return;
    for (const up of sides.up) instanceOf(up)?.setLocked?.(on);
    if (!on) for (const up of sides.up) instanceOf(up)?.setInspector?.(up === sides.inspecting);
  }

  /**
   * A world loaded: the lock let go if it is another world and the lock is on entities (`letsGo`), in whichever tab
   * it was, and that tab's tools told -- what they pinned was of the world before. The same world loaded again keeps it.
   */
  function unlockEverywhere(load: Load): void {
    const was = sides.release(load);
    if (was === null || !ready) return;
    for (const id of upIn(tools, was)) instanceOf(id)?.setLocked?.(false);
    if (was === sides.tab) for (const up of sides.up) instanceOf(up)?.setInspector?.(up === sides.inspecting);
  }

  /** The focused side lit with the editor's focus ring, and each tool told -- lit only in a tab of several. */
  function lightSides(): void {
    shell.root.classList.toggle('ed-split', sides.split);
    for (const { tool, instance } of made) {
      const on = sides.split && tool.id === sides.focused;
      for (const card of instance.cards?.() ?? []) card.classList.toggle('ed-focus-side', on);
      instance.setFocused?.(tool.id === sides.focused);
    }
  }

  /** A right-click in the editor or on its scene, while it is open: the browser's menu only in a field of text. */
  function noBrowserMenu(event: MouseEvent): void {
    if (isOpen() && !keepsBrowserMenu(event.target as Element | null)) event.preventDefault();
  }

  /**
   * A press or a focus in the editor or on the scene: in a tab of several, the side it is in has the keys. Not a drop:
   * a key field that takes one gives them itself (`PickerOptions.dropped`); any other leaves them where the drag began.
   */
  function pressedIn(event: Event): void {
    if (!sides.split || !isOpen() || running()) return;
    const target = event.target;
    if (!(target instanceof Node)) return;
    if (target === game.renderer.domElement) return focusTool(sides.tab);
    for (const id of sides.up) if (instanceOf(id)?.cards?.().some((card) => card.contains(target))) return focusTool(id);
  }

  /**
   * The tab `id` up -- its own tool and every one within it -- and every other
   * tool away: the others first, as showing a tool may draw and the scene has
   * to know by then whose it is. Each told whether the right panel is its
   * before it shows.
   */
  function show(id: string): void {
    sides.enter(id);
    for (const { tool, instance } of made) if (!sides.isUp(tool.id)) instance.setVisible(false);
    for (const up of sides.up) {
      const instance = instanceOf(up);
      instance?.setInspector?.(up === sides.inspecting);
      instance?.setVisible(true);
    }
    lightSides();
    // The gizmo's icons with the scene, the status line as the tool up has it, the strip's icons lit as the tabs are.
    topBar.refresh();
    shell.refresh();
    // Measured now too, not only as the observer reports: a page in a window not in front renders no frame to report from.
    measure();
  }

  /** Every tool away: the editor closing, or a playtest -- hidden, a pick under way stops. */
  function hideTools(): void {
    for (const { instance } of made) instance.setVisible(false);
  }

  /**
   * Z, and the bar's button: on the tool up's stack, or the world's -- where an
   * edit not committed yet is a step of its own first, so this undoes it and
   * not the one before. Nothing while the tool up is busy.
   */
  function undo(): void {
    if (hold.refuses('Undo')) return;
    // The focused side's stack empty, the world's not: said, rather than nothing happening.
    const line = elsewhere(host, history, whose(), 'undo');
    if (line !== null) return say(line);
    host.undo();
  }

  function redo(): void {
    if (hold.refuses('Redo')) return;
    const line = elsewhere(host, history, whose(), 'redo');
    if (line !== null) return say(line);
    host.redo();
  }

  /**
   * A step of the History card clicked: undone or redone to, until `to` steps
   * are done -- each step its own `undo` or `redo`, as Z and Y would take them --
   * and everything read again once at the end.
   */
  function travel(to: number): void {
    if (!editing() || hold.refuses('Undo or redo to a step') || host.busy) return;
    const world = host.isWorld;
    travelling = true;
    try {
      host.travel(to);
    } finally {
      travelling = false;
    }
    refreshBars();
    // The world another one: everything read again. A tool's own stack is its own business.
    if (world) refreshTools();
  }

  /**
   * `n` steps of the world's own history undone -- the agent's, from its row
   * or Undo this turn -- whichever tool is up: each its own `undo`, as the
   * History card takes them, everything read again once at the end.
   */
  function undoWorld(n: number): void {
    if (hold.refuses('Undo')) return;
    travelling = true;
    try {
      for (let i = 0; i < n; i++) if (!history.undo()) break;
    } finally {
      travelling = false;
    }
    refreshBars();
    refreshTools();
  }

  /** Redo `n` steps of the world's history, as Y does (`history_redo`). */
  function redoWorld(n: number): void {
    if (hold.refuses('Redo')) return;
    travelling = true;
    try {
      for (let i = 0; i < n; i++) if (!history.redo()) break;
    } finally {
      travelling = false;
    }
    refreshBars();
    refreshTools();
  }

  /** The playtest as the studio's play tools drive it (Docs/mcp.md M4): the functions F5, F6, F10 and Shift+F5 call. */
  function agentPlay(): PagePlay {
    return {
      state: () => playState(),
      ticks: () => ({ tick: game.loop.tick, ticks: playing === null ? 0 : playTicks() }),
      offered: () => {
        const found = playing;
        if (found === null) return [];
        return mergeEdits(editsOf(paused ? [...playEdits, ...pauseSteps()] : playEdits), found).map((e) => ({ id: editId(e), words: editWords(e, found) }));
      },
      press: (event) => playtest(event),
      stop: (keep, prefix) => (playtestNext(playState(), 'stop').action === 'stop' ? endPlaying(keep, prefix) : { how: 'none', kept: [], skipped: [], discarded: 0, step: null }),
    };
  }

  /** H, and the top bar's History: the History card opened or shut, and kept so. */
  function toggleHistory(): void {
    if (!editing()) return;
    setAway(false);
    historyCard.setOpen(!historyCard.open);
    keepPref('history', historyCard.open);
    topBar.refresh();
  }

  /** S, and the bar's button: the prefab open, if one is; else the first tool that saves does. */
  function save(): void {
    // The world a playtest has is the game's, not the scene's: Stop puts the scene's back, and then it is saved.
    if (playing) return say(`Not saved: ${notSavedPlaying(paused ? 'paused' : 'running')}`);
    if (hold.refuses('Save')) return;
    if (opened.key) return savePrefab();
    saver()?.save?.();
  }

  // ---------------------------------------------------------------- a prefab opened to edit

  /** The name in the header while a prefab is open, after `Prefab`: `crates/big`, and the one it was opened from. */
  function openedTitle(): string {
    const stack = opened.stack;
    const from = stack.length > 1 ? ` (in ${stack[stack.length - 2]})` : '';
    return `${opened.key}${from}${opened.readOnly ? ' · read-only' : ''}`;
  }

  /** The title's hover text while a prefab is open: where it is written, and the way out. */
  function openedNote(): string {
    const stack = opened.stack;
    const back = stack.length > 1 ? stack[stack.length - 2]! : 'the scene';
    return `${prefabPathOf(opened.key!)}: ${keyLabel(SAVE)} writes it, ${keyLabel(BACK)} goes back to ${back}`;
  }

  /** The scene's header as the mode is: `Prefab`, its Save and Back, or `Scene`. */
  function showOpened(): void {
    const stack = opened.stack;
    // Stale -- a nested prefab changed in a way it cannot follow -- it is read-only now, and says how to go on.
    const why = opened.readOnly ?? (opened.stale ? `${opened.stale} -- Back, and open it again` : null);
    shell.setOpened(opened.key ? { back: stack.length > 1 ? stack[stack.length - 2]! : 'the scene', readOnly: why, unsaved: opened.unsaved } : null);
    shell.refresh();
    measure();
  }

  /** `key` opened over what is in the scene, the Entities tool up; why not, said -- and returned -- if it cannot be (null: opened). */
  function openPrefab(key: string): string | null {
    if (playing) return 'a playtest is on: stop it first';
    if (hold.refuses(`Open ${key}`)) return 'an Apply is landing: try again in a moment';
    const pose = viewport.pose;
    // As they were before it opens: opening chooses its root, which claims the right panel for the entities.
    const { focused, inspecting } = sides;
    const why = opened.open(key);
    if (why) {
      say(`${key} not opened: ${why}`);
      return why;
    }
    openedFrom.push({ pose: pose === null ? null : { ...pose }, tool: shell.tool, focused, inspecting });
    shell.select(entitiesTool.id);
    // Its entities are what is edited now: the keys and the right panel theirs.
    focusTool(entitiesTool.id);
    inspectTool(entitiesTool.id);
    // The prefab framed, its views placed first (`draw`): it opens whole in view, wherever the scene's camera was.
    draw();
    viewport.frameAll();
    say(opened.readOnly ? `${key} opened read-only: ${opened.readOnly}` : `${key} opened: edit it as any entities -- ${keyLabel(SAVE)} saves it, ${keyLabel(BACK)} goes back`);
    return null;
  }

  /**
   * Back from the prefab open, as the agent's `scene_close_prefab` asks it (Docs/mcp.md M2): with changes not saved,
   * saved first (`save` true) or dropped (`false`) -- the dialog's Save and Don't save -- and refused with neither.
   */
  async function closePrefabFor(save: boolean | null): Promise<{ key: string; back: string; saved: boolean; dropped: boolean; said: string } | { error: string }> {
    const key = opened.key;
    if (!key) return { error: 'No prefab is open' };
    if (playing) return { error: 'A playtest is on: stop it first' };
    if (hold.refuses('Back')) return { error: 'An Apply is landing: try again in a moment' };
    const back = opened.stack.length > 1 ? opened.stack[opened.stack.length - 2]! : 'the scene';
    if (opened.back()) return { key, back, saved: false, dropped: false, said: `Back from ${key} to ${back}: it had no changes to save` };
    if (save === null) return { error: `${key} has changes not saved: give save: true to save them and go back, or save: false to drop them (ask the person: they cannot be had back)` };
    if (save) {
      if (opened.gone !== null) return { error: `${key} cannot be saved: ${opened.gone}` };
      const { line, notes, wrote } = await opened.save();
      if (!wrote || opened.unsaved) return { error: `Not saved, so not back: ${[line, ...notes].join(' · ')}` };
      opened.back(true);
      return { key, back, saved: true, dropped: false, said: `${[line, ...notes].join(' · ')} -- back to ${back}` };
    }
    opened.back(true);
    return { key, back, saved: false, dropped: true, said: `Back from ${key} to ${back}, its changes dropped` };
  }

  /**
   * Prefab `from` renamed `to`: once `to` is compiled, the world's instances of
   * it named anew -- the world saved with its overrides, renamed (`renameInSave`),
   * loaded again, no step -- so they stay instances, and a save of the scene names
   * the new key. With a prefab open, the scene put aside under it is renamed instead,
   * and during a playtest the world it puts back -- and, paused, the world it has too, which is the editor's. Every older step's world follows
   * the renames made since it was taken as it is put back (`renames.ts`).
   */
  async function renamePrefabInWorld(from: string, to: string): Promise<void> {
    if (!(await whenCompiled(to, true))) return;
    // An Apply landing loads its world, renamed as it is put back (`renames.follow`): this one waits for it.
    await overrides.idle();
    renames.push(from, to);
    const outer = opened.outer;
    if (outer) return void renameInSave(outer, from, to);
    // A playtest: the world it puts back is renamed. Running, the game's own is left -- it is put back at the end; paused,
    // it is the one the editor shows and Resume runs on, so it is renamed as with none.
    if (playing) renameInSave(playing, from, to);
    if (running()) return;
    const save = sceneSave(game.world);
    if (!renameInSave(save, from, to)) return;
    livePrefabs.around(() => game.load(save));
    emit('loaded', null, 'again');
    draw();
  }

  /** The prefab open written to its file. */
  function savePrefab(): void {
    if (!opened.key || playing || hold.refuses('Save')) return;
    void saveOpened().then((done) => say('error' in done ? done.error : done.said));
  }

  /** The prefab open written to its file, staying in it: the header's Save, Mod+S, and `scene_save` with a prefab open. */
  async function saveOpened(): Promise<{ key: string; file: string; wrote: boolean; said: string } | { error: string }> {
    const key = opened.key;
    if (!key) return { error: 'No prefab is open' };
    if (opened.gone !== null) return { error: `${key} cannot be saved: ${opened.gone}` };
    try {
      const { line, notes, wrote } = await opened.save();
      showOpened();
      return { key, file: prefabPathOf(key), wrote, said: [line, ...notes].join(' · ') };
    } catch (err) {
      return { error: `Not saved: ${(err as Error).message}` };
    }
  }

  /**
   * Back to what it was opened from: with unsaved changes, asked first in the
   * editor's dialog -- Save (then back), Don't save (back), Cancel.
   */
  function backPrefab(): void {
    const key = opened.key;
    if (!key || playing || hold.refuses('Back')) return;
    if (opened.back()) return;
    setAway(false);
    const go = (): void => void opened.back(true);
    // Its file renamed or trashed: a Save can only be refused, so it is not offered -- said why.
    const gone = opened.gone;
    askUnsaved({
      what: `'${key}'`,
      doing: `Go back to ${opened.stack.length > 1 ? opened.stack[opened.stack.length - 2] : 'the scene'}?`,
      go,
      ...(gone !== null ? { save: null, why: gone } : {
        save: () => opened.save().then(({ line, notes, wrote }) => {
          say([line, ...notes].join(' · '));
          // Refused (a compile error, a stale frame): nothing went, and the dialog stays for the person to choose again.
          if (!wrote && opened.unsaved) {
            showOpened();
            return false;
          }
          return true;
        }, (err: Error) => {
          say(`Not saved: ${err.message}`);
          return false;
        }),
      }),
    });
  }

  /**
   * T, the bar's Playtest, Resume and Stop, Esc, boot's P (`pausePlaytest`, `resumePlaytest`): what the playtest's
   * state machine (`playtest-state.ts`) says for this state and this event, done.
   */
  function playtest(event: PlaytestEvent): void {
    const { action } = playtestNext(playState(), event);
    if (action === 'start') startPlaying();
    else if (action === 'pause') pausePlaying();
    else if (action === 'resume') resumePlaying();
    else if (action === 'stop') endPlaying();
    else if (action === 'step') stepPlaying();
  }

  /** The playtest's ticks so far: the loop's since it began. */
  const playTicks = (): number => Math.max(0, game.loop.tick - playFrom);

  /** The play strip and the pill as the state is now, the time with them; each second while one runs. */
  function showPlay(): void {
    const state = playState();
    shell.setPlaytest(state, playTicks());
    if (state === 'running' && playClock === null) playClock = setInterval(showPlay, 1000);
    else if (state !== 'running' && playClock !== null) {
      clearInterval(playClock);
      playClock = null;
    }
  }

  /**
   * F10, the strip's Step: one tick of the paused playtest (`Game.step`), then paused again. The game ran: as a second
   * pause, this pause's edits are kept for Stop and its history starts again -- an undo would rewind the tick with it.
   * Refused while a card has the keys or a landing holds the world, as Resume is.
   */
  function stepPlaying(): void {
    if (!editing()) return;
    if (hold.refuses('Step')) return;
    worldSteps.commit(PENDING);
    playEdits.push(...pauseSteps());
    recorded = [];
    game.step();
    resetWhy = 'the playtest stepped since';
    try {
      history.reset();
    } finally {
      resetWhy = 'another scene was loaded';
    }
    pauseAside = history.aside;
    worldSteps.sync();
    showPlay();
    refreshTools();
    refreshBars();
    emit('changed', null);
    draw();
  }

  /** The tab up as Play sees it (`play-scene.ts`): a page, or a scene of its own, as its tool declares. */
  const tabUp = (): PlayTab => playTab(shell.tool, instanceOf(shell.tool));

  /** A playtest from the world as it is: the editor hidden, the game the player's. */
  function startPlaying(): void {
    if (!editing()) return;
    // Its end loads the world it began from, and brings that up as a step: begun under a landing, the Apply it undoes
    // or redoes would be loaded over, and dropped from redo.
    if (hold.refuses('Playtest')) return;
    // An edit under way is a step of its own first: the playtest is none.
    worldSteps.commit(PENDING);
    // From a page or the Model tab, to the Scene tab first: the game seen (Docs/game-view.md §7).
    const start = playStarts(tabUp(), entitiesTool.id);
    playBack = start.back;
    if (start.go !== null) shell.select(start.go);
    playing = sceneSave(game.world);
    paused = false;
    pauseKept = null;
    playEdits = [];
    playFrom = game.loop.tick;
    showPlay();
    // Docked (Docs/game-view.md §3), the cards stay where they are and the game plays in the room; maximized, they go.
    shell.setPlaying(true, maximizeOn);
    if (maximizeOn) hideTools();
    // Grid, gizmo and outlines out of the scene, and the camera the game's again.
    viewport.close();
    roomMoved();
    onPlaytest(true);
    agentCard?.playtest();
    playAside();
    emit('playtest', null);
  }

  /**
   * The playtest running, paused: the game stopped, and the editor over its world as it is now -- nothing put back --
   * its camera, its tools, the History card. The scene's history is put aside (taken back at Stop), so the edits made
   * now are steps of their own on this world, Z undoing them; a second pause starts them again -- the game ran since.
   */
  function pausePlaying(): void {
    paused = true;
    // The game paused, the HUD and the debug panel away, as an end does.
    onPlaytest(false);
    recorded = [];
    if (pauseKept === null) pauseKept = history.setAside();
    else {
      resetWhy = 'the playtest ran since';
      try {
        history.reset();
      } finally {
        resetWhy = 'another scene was loaded';
      }
    }
    pauseAside = history.aside;
    worldSteps.sync();
    showPlay();
    shell.setPlaying(false, maximizeOn);
    // The editor's camera and its gizmo back -- unless the Game look is on (D4); every tool reads the world the playtest
    // made. Docked, the frame stays put.
    if (!gameLook) viewport.open();
    show(shell.tool);
    roomMoved();
    refreshTools();
    refreshBars();
    agentCard?.playtest();
    playAside();
    emit('playtest', null);
    draw();
    if (!pausedSaid) {
      pausedSaid = true;
      say(PAUSED_HINT);
    }
  }

  /**
   * The paused playtest run on from the world as it is, the edits made meanwhile in it. As T's start: refused while a
   * card has the keys (`editing`) -- the keys card shut first, as before a playtest begins.
   */
  function resumePlaying(): void {
    if (!editing()) return;
    // A landing Apply loads its world: not under the running game.
    if (hold.refuses('Resume')) return;
    // An edit under way is in the world already: committed, so the next pause's history knows of it.
    worldSteps.commit(PENDING);
    // A page put up while paused: to the Scene tab again, as Play does (§7).
    const resume = playResumes(playBack, tabUp(), entitiesTool.id);
    if (resume.go !== null) shell.select(resume.go);
    // After the move: the tab change it made is no move of the person's, and what it dropped is decided here.
    playBack = resume.back;
    // This pause's edits kept for Stop: the next pause starts its history again.
    playEdits.push(...pauseSteps());
    recorded = [];
    paused = false;
    showPlay();
    shell.setPlaying(true, maximizeOn);
    if (maximizeOn) hideTools();
    viewport.close();
    roomMoved();
    onPlaytest(true);
    agentCard?.playtest();
    playAside();
    emit('playtest', null);
  }

  /**
   * Stop, Esc, T while running: the world put back, and the editor's view and tools back with it -- then what was
   * changed while paused offered to keep, as the preference says.
   */
  function endPlaying(keep?: KeepChoice, prefix = ''): Stopped {
    const steps = stopPlaying();
    // Back to the page Play was pressed on, if the person is still where Play put them (§7).
    const back = playStops(playBack, shell.tool);
    playBack = null;
    if (back !== null) shell.select(back);
    // The editor as it was: its camera -- or the Game look, if it is on -- its tool, the frame drawn from its view.
    if (!gameLook) viewport.open();
    show(shell.tool);
    return offerKept(steps, keep, prefix);
  }

  /** The edits of the steps this pause has done -- not those undone -- a list a step, in order: a group's own steps inside it. */
  function pauseSteps(): PausedStep[] {
    return recorded.filter((r) => !r.undone).map((r) => ({ edits: r.edits, claude: r.claude === true }));
  }

  /**
   * Each recorded step's place, as the history moved: done or undone while it is there; gone from it, kept as done
   * for good if it was done (off the bound's end) and let go of if undone (dropped from redo). Only while the pause's
   * own steps are the history's: a prefab opened over them puts them aside, and a reset is another world.
   */
  function followRecorded(event: HistoryEvent): void {
    if (recorded.length === 0 || !paused || history.aside !== pauseAside) return;
    if (event === 'reset') {
      recorded = [];
      return;
    }
    recorded = followSteps(recorded, history.steps, history.done);
  }

  /**
   * After Stop, the found world back: what was changed while paused asked about (`keepDialog`: Keep all, Keep none,
   * Keep ticked; Esc none), kept all, or dropped -- the preference's (Config ▸ Editor ▸ Preferences). Nothing with nothing.
   */
  function offerKept(steps: PausedStep[], keep?: KeepChoice, prefix = ''): Stopped {
    // Judged from the found world, put back, to now: what it has already is no edit, and a field's `was` is its value there.
    const found = game.world.save();
    const edits = mergeEdits(editsOf(steps), found);
    // Claude's `play_stop` answers the offer itself, with no dialog; else the preference: ask, keep or drop.
    const answer = stopAnswer(edits, found, keep, loadPrefs().afterPlaytest);
    if (answer.how === 'asked') showDialog(keepDialog(answer.rows, (ticked) => void keepEdits(edits, ticked, found)));
    const why = keep !== undefined ? ' (Claude: play_stop)' : answer.how === 'preference: keep' ? ' (Preferences: after a playtest, keep)' : '';
    // Claude's step only when every edit kept is Claude's own: else the person's, `history_undo` taking it back only with `any`.
    const label = keptLabel(steps, edits.filter((_, i) => answer.ticked[i] === true), prefix);
    const done = answer.ticked.some(Boolean) ? keepEdits(edits, answer.ticked, found, why, label) : null;
    if (!done && edits.length > 0 && answer.how !== 'asked') say(answer.how === 'preference: drop' ? droppedLine(edits.length) : `${edits.length} ${edits.length === 1 ? 'change' : 'changes'} from the playtest dropped${why}`);
    // What was kept, said for the studio's `play_stop` (Docs/mcp.md M4).
    return {
      how: answer.how,
      kept: done ? done.applied.map((e) => editWords(e, found)) : [],
      skipped: done ? done.skipped.map((x) => `${editWords(x.edit, found)}: ${x.why}`) : [],
      discarded: answer.discarded,
      step: done && done.applied.length > 0 ? label : null,
    };
  }

  /** The ticked ones of `edits` onto the world put back, one step Z undoes ("Kept from the playtest"); what the world lacks said. */
  function keepEdits(edits: readonly Edit[], ticked: readonly boolean[], found: WorldSave, why = '', label = KEPT): Applied | null {
    if (!ticked.some(Boolean) || playing !== null) return null;
    worldSteps.commit(PENDING);
    const { applied, skipped } = applyEdits(game.world, edits, ticked, (save) => void game.load(save));
    worldSteps.commit(label);
    refreshTools();
    refreshBars();
    emit('changed', null);
    draw();
    const line = keptLine(applied.length, skipped.map((s) => s.why));
    say(`${line}${why}`, skipped.length > 0 ? `${line} -- ${skipped.map((s) => `${editWords(s.edit, found)}: ${s.why}`).join('; ')}` : undefined);
    return { applied, skipped };
  }

  /**
   * The playtest over: the game stopped, then the world put back as it began; history as it was -- the steps made
   * while it was paused go with the world they were made on.
   */
  function stopPlaying(): PausedStep[] {
    // An edit under way -- a number typed, Esc pressed before it was left -- is a step first, as Resume makes it.
    if (paused) worldSteps.commit(PENDING);
    // What every pause changed, this one's read before its history goes: Stop offers it (`offerKept`), by the step.
    const steps = paused ? [...playEdits, ...pauseSteps()] : playEdits;
    playEdits = [];
    recorded = [];
    const save = playing!;
    const kept = pauseKept;
    playing = null;
    paused = false;
    pauseKept = null;
    onPlaytest(false);
    if (kept) history.takeBack(kept);
    game.load(plainSave(save));
    // Put back, not edited: every step still fits, and the next open finds nothing ran.
    worldSteps.sync();
    // A prefab compiled anew while it ran: the world put back is brought up to it, one step Z undoes.
    refreshInstances(game.world, save);
    game.world.flush();
    if (worldSteps.commit('Prefabs updated')) say('Prefabs changed while it ran: the scene brought up to them · Z undoes');
    showPlay();
    shell.setPlaying(false, maximizeOn);
    roomMoved();
    agentCard?.playtest();
    playAside();
    refreshBars();
    // Paused, the tools read the playtest's world, and an entity of it may be chosen: they read this one again.
    if (kept) emit('loaded', null, 'again');
    emit('playtest', null);
    return steps;
  }

  /**
   * The editor up, once, as it is made: the page is the editor's from then on (boot has paused the game and put its
   * HUD away first), and nothing closes it.
   */
  function openEditor(): void {
    // History goes on from where it was if the game has not run since. If it
    // has, an undo would rewind it, so it starts again -- unsaved: the world
    // has moved on from any save.
    // A step the agent's card carried across a reload (pushed as the card was made, before the unsaved mark) goes on with it:
    // `resume.test.ts` runs this order.
    openHistory(history, worldSteps, (why, reset) => {
      resetWhy = why;
      try {
        reset();
      } finally {
        resetWhy = 'another scene was loaded';
      }
    });
    // The camera first: the tool's first frame is drawn from the editor's view.
    viewport.open();
    shell.refresh();
    shell.setHidden(false);
    show(shell.tool);
    if (consoleOwed) {
      consoleOwed = false;
      const studioTab = made.find((m) => m.tool.id === STUDIO_ID)?.instance as StudioInstance | undefined;
      if (studioTab?.strip) {
        shell.select(tabOf(tools, STUDIO_ID, shell.tool));
        focusTool(STUDIO_ID);
        studioTab.strip.show('console');
      }
    }
    // Claude's column shown: a card that came while the editor was being made, in view.
    agentCard?.shown();
    // Back from a reload: the selection as it was -- refs, which the world kept across it -- and what could not be kept, said.
    if (back) {
      const { selection: refs, notes } = back;
      back = null;
      const alive = refs.map((r) => game.world.deref(r)).filter((e) => e !== NONE && game.world.alive(e));
      if (alive.length > 0) selection.chooseAll(alive);
      // Each short, to its first ` -- `, as the line fits it; whole on hover, for as long as a failure's line.
      if (notes.length > 0) say(notes.map((n) => n.split(' -- ')[0]!).join(' · '), notes.join(' · '), true);
    }
  }
  openEditor();

  return {
    notice(kind, text, error) {
      codeNotices.say(kind, text, error);
    },
    clearNotice(kind) {
      codeNotices.clear(kind);
    },
    get playtestState() {
      return playState();
    },
    pausePlaytest() {
      playtest('pause');
    },
    resumePlaytest() {
      playtest('resume');
    },
    dispose() {
      if (playing) stopPlaying();
      if (playClock !== null) clearInterval(playClock);
      reloading.dispose();
      for (const off of offRecovery) off();
      recoveryFix?.dispose();
      import.meta.hot?.off('vite:error', viteHeard);
      offBroken();
      offProbe();
      probes?.dispose();
      removeEventListener('message', probeDone);
      recoveryReload?.dispose();
      offNotices();
      cameraNotice.dispose();
      cancelAnimationFrame(colliderFrame);
      colliderLines.dispose();
      noticesStrip.dispose();
      removeEventListener('pagehide', leaving);
      removeEventListener('pageshow', shownAgain);
      hot?.off('vite:beforeFullReload', arm);
      hot?.off('vite:ws:disconnect', disconnected);
      hot?.off('vite:ws:connect', connected);
      barHeight.disconnect();
      game.renderer.domElement.removeEventListener('pointerdown', pressedIn, true);
      game.renderer.domElement.removeEventListener('contextmenu', noBrowserMenu, true);
      quick?.dispose();
      column?.dispose();
      agentCard?.dispose();
      for (const off of keys) off();
      keysCard.dispose();
      gameMenu.dispose();
      for (const { instance } of made) instance.dispose();
      useDraw(null);
      useModels(null);
      livePrefabs.around = <T>(run: () => T): T => run();
      // The game's rebuild hooks point into this editor's closures: a disposed editor answers no swap.
      game.onBeforeRebuild = null;
      game.onRebuilt = null;
      livePrefabs.update = (_label: string, run: () => void): void => run();
      livePrefabs.hold = null;
      offPrefabs();
      clearTimeout(sayTimer);
      guardUnsaved(null);
      viewport.dispose();
      // What the editor set on the game put back: no preview, the whole canvas, the outside black.
      game.setResolution(null);
      game.setFrame(null);
      game.outside.set(0x000000);
      unmountDialogs();
      shell.dispose();
    },
  };
}
