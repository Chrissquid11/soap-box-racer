/**
 * A prefab's key in a world save (Docs/prefabs.md §6, §9): a save names each
 * instance's prefab by reference (`instances.keys`, `{ uid, key }`) and each
 * entity's node by its kind's name, the key and the node's path
 * (`crates/big/rider`).
 *
 * - **Who holds it**: a save whose `instances.keys` names the key (the Prefab
 *   block's Used by).
 * - **The world's own, renamed** (`renameInSave`): the editor's open world and
 *   its undo history follow a prefab renamed or moved in the Assets panel --
 *   the key, each kind named for it (the root's, and every node's under it,
 *   `crates/big/...`), and the node tables a save keeps; nothing else. A kind
 *   of another prefab that only shares the start of the name
 *   (`crates/big-variant`) is left. The files -- levels, scenes, prefabs
 *   nesting it -- are not rewritten here: they name it by uid, and the
 *   server's move rewrites their keys in the same call (Docs/asset-ids.md §4).
 *
 * Pure: node tests it (`level-keys.test.ts`).
 */
import { caseKey, isKeyRef, refText, resolveRef, type WorldSave } from '@vibe/engine';

/** Does `save` hold an instance of `key`? */
export const holdsPrefab = (save: unknown, key: string): boolean => {
  const keys = (save as Partial<WorldSave> | null)?.instances?.keys;
  // A key, or a reference (`{ uid, key }`, Docs/asset-ids.md §3) by the key its uid has now -- a stale key read right.
  return Array.isArray(keys) && keys.some((k) => {
    const now = resolveRef('prefabs', k);
    return now !== null && caseKey(now) === caseKey(key);
  });
};

/** A kind's name with `from`'s key as `to`'s: `crates/big/rider` is `crates/huge/rider`; any other as it is. */
const renamedKind = (kind: string, from: string, to: string): string => (kind === from ? to : kind.startsWith(`${from}/`) ? `${to}${kind.slice(from.length)}` : kind);

/** `save` naming prefab `from` as `to`, in place: its key, its kinds and its node tables. False, and nothing changed, if it holds none of it. */
export function renameInSave(save: WorldSave, from: string, to: string): boolean {
  const inst = save.instances;
  const k = inst ? inst.keys.findIndex((x) => refText(x) !== '' && caseKey(refText(x)) === caseKey(from)) : -1;
  if (!inst || k < 0) return false;
  // A reference keeps its uid, its key the new one.
  const was = inst.keys[k];
  inst.keys[k] = isKeyRef(was) ? { uid: was.uid, key: to } : to;
  // Its kinds: its entities', and its nodes' as saved -- so a plain copy of one of its entities (a partial paste) is renamed too.
  const kinds = new Set<string>(inst.nodes?.[k] ?? []);
  save.entities.forEach((_e, i) => {
    if (inst.prefab[i] === k) kinds.add(save.kinds[i]!);
  });
  save.kinds = save.kinds.map((kind) => (kinds.has(kind) ? renamedKind(kind, from, to) : kind));
  if (inst.nodes?.[k]) inst.nodes[k] = inst.nodes[k]!.map((kind) => renamedKind(kind, from, to));
  return true;
}
