/**
 * Claude's edits shown (Docs/ai-panel.md §5, A4, D8), the pure parts: the History card's rows with a turn's steps
 * grouped under one (`groupHistory`), and the entities a step changed (`touchedBy`) -- what the tree marks and the
 * viewport outlines as the edit lands. `history-card.ts` and `editor.ts` draw them; node tests these
 * (`claude-steps.test.ts`).
 */
import type { HistoryRow } from './history.ts';
import { stepBy } from './mcp/play.ts';
import type { Edit } from './playtest-edits.ts';

/** A row of the History card: one step, or a turn of Claude's, its steps under it. */
export type HistoryEntry =
  /** `turn`: a Claude step's turn, for its tint; null for every other step. */
  | { kind: 'step'; row: HistoryRow; claude: boolean; turn: string | null; ordinal: number | null }
  | {
    kind: 'turn';
    /** The turn's id: the group's, kept open or shut by it. */
    turn: string;
    /** "Claude · 4 edits", or with the conversation's title while several are open. */
    label: string;
    /** Its steps' rows, oldest first. */
    rows: HistoryRow[];
    /** Its last step's place: a click on the group goes there. */
    n: number;
    /** The turn's number in its conversation ("turn 3"), where the transcript knows it; null where not. */
    ordinal: number | null;
    /** Done, the last done, undone, or some of it undone ("part"). */
    state: HistoryRow['state'] | 'part';
    /** The current step (Undo's) is one of its own: folded, the group carries the mark of where you are. */
    holdsCurrent: boolean;
  };

/** What each step is: its label, and the agent's turn it was made in (`Step.turn`; none for the person's). */
export interface StepFacts {
  label: string;
  turn: string | null;
}

/** The conversation a Claude label names, `Claude (Bugs): Move` -- null for a plain `Claude: Move`. */
const conversationOf = (label: string): string | null => /^Claude \(([^)]*)\): /.exec(label)?.[1] ?? null;

/**
 * `rows` (the start, then each step: `historyRows`) as the History card shows them: two steps or more of one turn of
 * Claude's, side by side, one row ("Claude · 3 edits") with them under it; every other step a row of its own, Claude's
 * marked. Z still undoes one step: a group is only how they are shown.
 */
export function groupHistory(rows: readonly HistoryRow[], steps: readonly StepFacts[], ordinalOf: (turn: string) => number | null = () => null): HistoryEntry[] {
  const out: HistoryEntry[] = [];
  let i = 0;
  while (i < rows.length) {
    const row = rows[i]!;
    const step = row.n > 0 ? steps[row.n - 1] : undefined;
    const claude = step !== undefined && stepBy(step.label) === 'Claude';
    if (!claude || !step!.turn) {
      out.push({ kind: 'step', row, claude, turn: null, ordinal: null });
      i++;
      continue;
    }
    const ordinal = ordinalOf(step!.turn);
    let j = i + 1;
    while (j < rows.length && steps[rows[j]!.n - 1]?.turn === step!.turn && stepBy(steps[rows[j]!.n - 1]!.label) === 'Claude') j++;
    if (j - i < 2) {
      out.push({ kind: 'step', row, claude, turn: step!.turn, ordinal });
      i++;
      continue;
    }
    const group = rows.slice(i, j);
    // The last step done its last: current; done or undone whole, as its steps; else part of it undone -- the current
    // step inside it -- 'part', the step's own row carrying the mark once unfolded.
    const last = group[group.length - 1]!.state;
    const state: HistoryRow['state'] | 'part' = last === 'current' ? 'current' : group.every((r) => r.state === last) ? last : 'part';
    const who = conversationOf(step!.label);
    out.push({ kind: 'turn', turn: step!.turn, label: `Claude${who ? ` (${who})` : ''}${ordinal !== null ? ` · turn ${ordinal}` : ''} · ${group.length} edits`, rows: group, n: group[group.length - 1]!.n, ordinal, state, holdsCurrent: group.some((r) => r.state === 'current') });
    i = j;
  }
  return out;
}

/**
 * A turn's tint (D8): a hue its steps share, so one turn's edits read as one -- stepped round the wheel by the turn's
 * number (neighbours far apart), or, unnumbered, from its id. Claude's violet (≈ 260°) is the first.
 */
export function turnHue(turn: string, ordinal: number | null): number {
  if (ordinal !== null) return (260 + (ordinal - 1) * 137) % 360;
  let h = 0;
  for (let i = 0; i < turn.length; i++) h = (h * 31 + turn.charCodeAt(i)) >>> 0;
  return h % 360;
}

/** An entity's ref from its index and generation, as `World.ref` makes one (18 bits of index): one destroyed since names nobody. */
export const refOf = (id: number, gen: number): number => ((gen & 0xfff) << 18) | id;

/**
 * The entities a step changed, from its diff (`diffSaves`), as refs (`refOf`) -- an index alone would mark whatever
 * takes it next: those edited and those it made; not those it destroyed.
 */
export function touchedBy(edits: readonly Edit[]): number[] {
  const out = new Set<number>();
  for (const e of edits) {
    if (e.kind === 'removed') continue;
    out.add(refOf(e.id, e.gen));
    if (e.kind === 'added') for (const s of e.entities) out.add(refOf(s.id, s.gen));
  }
  return [...out];
}

/**
 * The tree's marks (D8), by ref: the entities the last turn changed, until the next turn -- a step of another turn, or
 * a turn starting (`clear`) -- until another world (`clear`), or until the person selects one (it is seen). A step
 * with no turn (from before a reload) adds to them and starts nothing. Pure state, for the host.
 */
export function createTouched(): {
  /** A Claude step landed: its turn and what it changed (refs). True if the marks changed. */
  landed(turn: string | null, refs: readonly number[]): boolean;
  /** The person selected these (refs): their marks go. True if any went. */
  seen(refs: readonly number[]): boolean;
  /** Every mark gone: a turn starts, another world is loaded, history starts again. */
  clear(): void;
  has(ref: number): boolean;
  readonly ids: ReadonlySet<number>;
} {
  let turn: string | null = null;
  const ids = new Set<number>();
  return {
    landed(next, changed) {
      if (next !== null && next !== turn) {
        turn = next;
        ids.clear();
      }
      const had = ids.size;
      for (const id of changed) ids.add(id);
      return ids.size !== had || changed.length > 0;
    },
    seen(chosen) {
      let gone = false;
      for (const id of chosen) gone = ids.delete(id) || gone;
      return gone;
    },
    clear() {
      ids.clear();
      turn = null;
    },
    has: (id) => ids.has(id),
    ids,
  };
}
