/**
 * The prefabs by folder, for the tree's Create menu (`entities.ts`): a
 * submenu a folder under `prefabs/` -- `crates ▸ big, chip, little` -- and a
 * prefab at its root directly in the menu. Pure, so a node test holds it.
 */

/** A folder of prefabs: its name, the folders in it, and the keys of the prefabs directly in it -- each sorted. */
export interface PrefabGroup {
  readonly name: string;
  readonly folders: PrefabGroup[];
  readonly keys: string[];
}

/** The last part of a prefab's key: what its item in its folder's submenu says. */
export const leafOf = (key: string): string => key.slice(key.lastIndexOf('/') + 1);

/** `keys` -- `crates/big`, `barrel` -- as a tree of folders, the root's name `''`. */
export function prefabGroups(keys: readonly string[]): PrefabGroup {
  const root: PrefabGroup = { name: '', folders: [], keys: [] };
  for (const key of keys) {
    const parts = key.split('/');
    let at = root;
    for (const part of parts.slice(0, -1)) {
      let next = at.folders.find((f) => f.name === part);
      if (!next) at.folders.push((next = { name: part, folders: [], keys: [] }));
      at = next;
    }
    at.keys.push(key);
  }
  const sort = (group: PrefabGroup): void => {
    group.folders.sort((a, b) => a.name.localeCompare(b.name));
    group.keys.sort((a, b) => leafOf(a).localeCompare(leafOf(b)));
    group.folders.forEach(sort);
  };
  sort(root);
  return root;
}
