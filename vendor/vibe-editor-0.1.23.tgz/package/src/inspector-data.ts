/**
 * A data component's block in the inspector (Docs/properties.md §3, P4): its fields as its schema declares them, each
 * element its own widget, all the way down -- `inspector-blocks.ts`' `objectBlock` hands a data component here.
 *
 * - **A list**: its name and count, folded or open (kept as the inspector is built again); a row an element, its
 *   widget (any kind: a number, an enum, a key's picker, a ref's line, a record, another list), a grip to drag it up or
 *   down within the list (one step), × to remove it; + at its foot adds the element's default. `min`/`max` grey + and
 *   ×. A drop of what an element takes -- tree rows, a block's header, assets from the Assets panel, several at once --
 *   onto the list appends them, onto a row inserts them before it (`fitsMany`); one that does not fit dims with why. A
 *   long list (past `VIRTUAL` rows) scrolls in its block, only the rows in view drawn.
 * - **A dictionary**: a row an entry -- its key's widget (text, an enum's names, a number; an entity's shown), its
 *   value's -- a grip to reorder (kept in the file), ×; + adds the first free key (an enum's next name, `"key 2"`). A
 *   key typed that it has already is refused there, said under it (`renameKey`).
 * - **A record**: a group of its fields under its name, folded or open. **A string**: a text field, `multiline` a text
 *   area (marked `data-keys-field`: typing there is typing, the editor's keys never fire), `maxLength` held.
 * - **A number**: a scrub field held to `min`/`max`; with `slider` and both bounds a slider beside it, as a column's
 *   (`inspector-fields.ts`' `numberLine`): written live as it slides, one step when let go.
 * - **Several selected**: edited as one while they hold the same; else shown, never edited, saying so.
 * - **One step an edit**, `Set Patrol.waypoints[2]`, `Add to Patrol.waypoints`, `Move in Patrol.waypoints`: every
 *   control declares its tool -- `scene_set` (a value), `scene_list_insert` (+, a drop), `scene_list_remove` (×),
 *   `scene_list_move` (the grip). `data-field` on each top-level field's line (`Patrol.waypoints`), which an
 *   instance's override marks (D9).
 */
import {
  colourValue, type DataComponentOf, dataDefault, dataPlain, type DictElement, type Element, elementAt, entryStep, pathText, putAt, type Entity, type EntityRef, type Field, flagNames, freeKey, hex, hexA,
  internKey, keyText, label, soundKind, labelOf, type ListElement, moveEntry, moveItem, NO_REF, NONE, rawOut, type RecordElement, refMisfit, refTakes, type Step, type StringElement,
} from '@vibe/engine';
import { canRemove, moveTo, renameKey, room } from './data-edit.ts';
import { mount, type Mounted } from './virtual.ts';
import { factsOf, fits, fitsMany, type DropField, type Fit, type ManyFit } from './drag-record.ts';
import { dropTarget } from './drop-target.ts';
import { numberField } from './fields.ts';
import type { Blocks } from './inspector-blocks.ts';
import { picker, type KeySources } from './key-field.ts';
import { times } from './multi.ts';
import { button, control, el } from './dom.ts';

/** Past this many elements a list scrolls in its block, only the rows in view drawn. */
export const VIRTUAL = 60;

/** Lists, dictionaries and records folded, by `Component:path`: kept as the inspector is built again after each tick. */
const shut = new Set<string>();
/** Records open, by `Component:path` (a record nested in a list starts folded). */
const opened = new Set<string>();
/** A long list's scroll, by `Component:path`. */
const scrolled = new Map<string, number>();
/** The row being dragged by its grip: its list (`Component:path`) and index. */
let gripped: { list: string; from: number } | null = null;

/** What every widget of one block is built with. */
interface Ctx {
  readonly blocks: Blocks;
  readonly es: readonly Entity[];
  readonly c: DataComponentOf;
  /** Shown, never changed: the several selected hold different values, or a read-only field. */
  readonly fixed: boolean;
  readonly keys: KeySources;
}

const slotOf = (ctx: Ctx, e: Entity): Record<string, unknown> => (ctx.blocks.world.rawStore(ctx.c) as { value: Record<string, unknown>[] }).value[e]!;
/** The value at `steps` of the first one shown. */
const valueAt = (ctx: Ctx, steps: readonly Step[]): unknown => elementAt(ctx.c.data, slotOf(ctx, ctx.es[0]!), steps).value;

/** `steps`' value replaced on every one shown by what `next` makes of its own: written in place (`putAt`). */
function put(ctx: Ctx, steps: readonly Step[], next: (was: unknown) => unknown): void {
  for (const e of ctx.es) {
    const at = elementAt(ctx.c.data, slotOf(ctx, e), steps);
    putAt(at, next(at.value));
  }
}

/** A value edit done: drawn, one step. */
function commit(ctx: Ctx, steps: readonly Step[]): void {
  ctx.blocks.wrote();
  ctx.blocks.host.commit(times(`Set ${ctx.c.name}.${pathText(steps)}`, ctx.es.length));
}

/** A list's or a dictionary's own change on every one shown -- an element added, taken out, moved: one step, built again. */
function change(ctx: Ctx, steps: readonly Step[], verb: string, run: (value: unknown) => void): void {
  for (const e of ctx.es) run(elementAt(ctx.c.data, slotOf(ctx, e), steps).value);
  ctx.blocks.host.changed(times(`${verb} ${ctx.c.name}.${pathText(steps)}`, ctx.es.length));
}

/** A line of the block: its name (its help and what it is on hover) and what it is edited with. */
function line(name: string, title: string, extra = ''): { line: HTMLElement; picks: HTMLElement } {
  const out = el('div', `ed-keyline ed-dataline ${extra}`.trim());
  const picks = el('div', 'ed-keyline-picks');
  // A dictionary's value has its key beside it for a name.
  if (name !== '') {
    const n = el('span', 'ed-keyline-name', name);
    n.title = title;
    out.append(n);
  } else picks.title = title;
  out.append(picks);
  return { line: out, picks };
}

/** What a drop on an element of this kind is, if it takes one: a ref's entities, a key's assets. */
function dropFieldOf(el: Element): DropField | null {
  if ('shape' in el) return null;
  if (el.ref) return { kind: 'ref', needs: el.needs ?? [] };
  if (el.key !== undefined && el.key !== 'Clip') return { kind: 'key', keyKind: el.key };
  return null;
}

/** An element as a dropped entity or key is held: a ref to it, the key interned. */
const dropped = (ctx: Ctx, el: Element, item: Entity | string): unknown => (typeof item === 'string' ? internKey((el as Field).key!, item) : ctx.blocks.world.ref(item));

// ---------------------------------------------------------------- the block

/** A data component's block: its fields, a line each (`data-field`), as its schema lays them out. */
export function dataComponentBlock(blocks: Blocks, es: readonly Entity[], c: DataComponentOf, keys: KeySources, head: HTMLElement): HTMLElement {
  const section = el('div', 'ed-component ed-data');
  section.append(head);
  const same = es.every((e) => JSON.stringify(dataPlain({ shape: 'record', fields: c.data }, (blocks.world.rawStore(c) as { value: unknown[] }).value[e], rawOut)) === JSON.stringify(dataPlain({ shape: 'record', fields: c.data }, (blocks.world.rawStore(c) as { value: unknown[] }).value[es[0]!], rawOut)));
  const ctx: Ctx = { blocks, es, c, fixed: !same, keys };
  const grid = el('div', 'ed-fields');
  if (!same) grid.append(el('div', 'ed-dim ed-data-note', `The ${es.length} selected hold different ${c.name}: the first's shown -- select one to edit it`));
  let group: string | undefined;
  for (const [f, element] of Object.entries(c.data)) {
    if (element.hidden) continue;
    if (element.group !== group) {
      if (element.group !== undefined) grid.append(el('div', 'ed-field-group', element.group));
      else grid.append(el('div', 'ed-field-group-end'));
      group = element.group;
    }
    // A field systems fill as the game runs, on an opened prefab: shown, never written -- no Save keeps it.
    const runtime = c.runtime.includes(f) && blocks.host.opened?.() === true;
    const shown = widget({ ...ctx, fixed: ctx.fixed || element.readonly === true || runtime }, element, [{ name: f }], element.label ?? labelOf({ name: f, field: element as Field }), true);
    shown.dataset.field = `${c.name}.${f}`;
    if (element.readonly) shown.title = `${shown.title ? `${shown.title}\n` : ''}Read only: shown here, set by code`;
    if (runtime) {
      shown.classList.add('ed-runtime');
      shown.title = `${shown.title ? `${shown.title}\n` : ''}Runtime: systems set ${f} as the game runs, so the prefab never keeps it -- shown here, not edited`;
    }
    grid.append(shown);
  }
  section.append(grid);
  return section;
}

/** Is `steps` an element of a list (not a dictionary's entry by a number key)? */
function isListElement(ctx: Ctx, steps: readonly Step[]): boolean {
  const at = elementAt(ctx.c.data, slotOf(ctx, ctx.es[0]!), steps.slice(0, -1));
  return 'shape' in at.el && at.el.shape === 'list';
}

/** An element's widget, by its kind: `steps` where it is, `name` what its line is called. */
function widget(ctx: Ctx, element: Element, steps: readonly Step[], name: string, top = false): HTMLElement {
  const title = `${ctx.c.name}.${pathText(steps)}${element.help ? `\n${element.help}` : ''}`;
  if ('shape' in element) {
    if (element.shape === 'string') return stringLine(ctx, element, steps, name, title);
    if (element.shape === 'list') return listBlock(ctx, element, steps, name, title);
    if (element.shape === 'dict') return dictBlock(ctx, element, steps, name, title);
    return recordBlock(ctx, element, steps, name, title, top);
  }
  if (element.ref) return refLine(ctx, element, steps, name, title, steps.length > 0 && 'index' in steps[steps.length - 1]! && isListElement(ctx, steps));
  if (element.key !== undefined) return keyLine(ctx, element, steps, name, title);
  if (element.enum) return enumLine(ctx, element, steps, name, title);
  if (element.flags) return flagsLine(ctx, element, steps, name, title);
  if (element.color) return colourLine(ctx, element, steps, name, title);
  if (element.bool) return boolLine(ctx, steps, name, title);
  if (element.vec !== undefined) return vectorLine(ctx, element, steps, name, title);
  return numberLine(ctx, element, steps, name, title);
}

// ---------------------------------------------------------------- the leaves

function numberLine(ctx: Ctx, f: Field, steps: readonly Step[], name: string, title: string): HTMLElement {
  const integer = f.type !== 'f32' && f.type !== 'f64';
  const out = line(name, title, 'ed-datanumber');
  /** With `slider`, the slider beside it: following what is typed or scrubbed. */
  let slider: HTMLInputElement | null = null;
  const field = numberField({
    label: '', title, value: valueAt(ctx, steps) as number, step: f.step ?? (integer ? 1 : 0.1), integer, min: f.min, max: f.max, fixed: ctx.fixed,
    set: (v) => {
      put(ctx, steps, () => v);
      if (slider) slider.value = String(v);
      ctx.blocks.wrote();
    },
    commit: () => ctx.blocks.host.commit(times(`Set ${ctx.c.name}.${pathText(steps)}`, ctx.es.length)),
  });
  field.input.dataset.mcp = 'scene_set';
  out.picks.append(field.label);
  if (!f.slider || f.min === undefined || f.max === undefined) return out.line;
  // With `slider`, as a column's: the number and a slider from min to max beside it, a drag one step.
  const { min, max } = f;
  slider = el('input', 'ed-slider');
  slider.type = 'range';
  slider.min = String(min);
  slider.max = String(max);
  slider.step = String(f.step ?? (integer ? 1 : (max - min) / 100));
  slider.value = String(valueAt(ctx, steps));
  slider.disabled = ctx.fixed;
  slider.title = title;
  slider.dataset.mcp = 'scene_set';
  const range = slider;
  range.addEventListener('input', () => {
    const v = Math.min(max, Math.max(min, Number(range.value)));
    const now = integer ? Math.round(v) : v;
    put(ctx, steps, () => now);
    field.show(now);
    ctx.blocks.wrote();
  });
  range.addEventListener('change', () => commit(ctx, steps));
  out.line.classList.add('ed-sliderline');
  out.picks.append(range);
  return out.line;
}

function boolLine(ctx: Ctx, steps: readonly Step[], name: string, title: string): HTMLElement {
  const out = line(name, title, 'ed-tickline');
  const box = el('input', 'ed-check');
  box.type = 'checkbox';
  box.checked = valueAt(ctx, steps) === true;
  box.disabled = ctx.fixed;
  box.dataset.mcp = 'scene_set';
  box.addEventListener('change', () => {
    put(ctx, steps, () => box.checked);
    commit(ctx, steps);
  });
  out.picks.append(box);
  return out.line;
}

function enumLine(ctx: Ctx, f: Field, steps: readonly Step[], name: string, title: string): HTMLElement {
  const names = f.enum!;
  const out = line(name, title);
  const v = valueAt(ctx, steps) as number;
  const pick = picker({
    title: `${ctx.c.name}.${pathText(steps)}`, value: names[v] ?? String(v), choices: () => names, fixed: ctx.fixed,
    pick: (text) => {
      const at = names.indexOf(text);
      if (at < 0) return;
      put(ctx, steps, () => at);
      commit(ctx, steps);
    },
  });
  pick.root.classList.add('ed-enum');
  pick.input.dataset.mcp = 'scene_set';
  out.picks.append(pick.root);
  return out.line;
}

function flagsLine(ctx: Ctx, f: Field, steps: readonly Step[], name: string, title: string): HTMLElement {
  const out = line(name, `${title}\nAny of ${f.flags!.join(', ')}`);
  const v = valueAt(ctx, steps) as number;
  const set = new Set(flagNames(f.flags!, v));
  const ticks = el('div', 'ed-data-flags');
  f.flags!.forEach((n, i) => {
    const row = el('label', 'ed-flags-row');
    const box = el('input', 'ed-check');
    box.type = 'checkbox';
    box.checked = set.has(n);
    box.disabled = ctx.fixed;
    box.dataset.mcp = 'scene_set';
    box.addEventListener('change', () => {
      const bit = 2 ** i;
      put(ctx, steps, (was) => {
        const has = (Math.floor((was as number) / bit) & 1) === 1;
        return has === box.checked ? was : box.checked ? (was as number) + bit : (was as number) - bit;
      });
      commit(ctx, steps);
    });
    row.append(box, el('span', undefined, n));
    ticks.append(row);
  });
  out.picks.append(ticks);
  return out.line;
}

function colourLine(ctx: Ctx, f: Field, steps: readonly Step[], name: string, title: string): HTMLElement {
  const out = line(name, title);
  const v = valueAt(ctx, steps) as number;
  const swatch = el('input', 'ed-color');
  swatch.type = 'color';
  swatch.value = f.alpha ? hexA(v).slice(0, 7) : hex(v);
  swatch.disabled = ctx.fixed;
  swatch.dataset.mcp = 'scene_set';
  swatch.title = title;
  swatch.addEventListener('change', () => {
    const rgb = colourValue(swatch.value, false);
    if (rgb === null) return;
    // A colour with alpha keeps each one's own alpha: the swatch is the colour alone.
    put(ctx, steps, (was) => (f.alpha ? ((rgb * 256) + ((was as number) & 0xff)) >>> 0 : rgb));
    commit(ctx, steps);
  });
  out.picks.append(swatch);
  return out.line;
}

function vectorLine(ctx: Ctx, f: Field, steps: readonly Step[], name: string, title: string): HTMLElement {
  const out = line(name, title, 'ed-vecline');
  const axes = ['x', 'y', 'z', 'w'];
  const now = valueAt(ctx, steps) as number[];
  for (let i = 0; i < f.vec!; i++) {
    const field = numberField({
      label: axes[i]!, labelClass: `ed-axis-${axes[i]}`, title: `${title} ${axes[i]}`, value: now[i] ?? 0, step: f.step ?? 0.1, min: f.min, max: f.max, fixed: ctx.fixed,
      set: (v) => {
        put(ctx, steps, (was) => (was as number[]).map((x, k) => (k === i ? v : x)));
        ctx.blocks.wrote();
      },
      commit: () => ctx.blocks.host.commit(times(`Set ${ctx.c.name}.${pathText(steps)}`, ctx.es.length)),
    });
    field.input.dataset.mcp = 'scene_set';
    out.picks.append(field.label);
  }
  return out.line;
}

function keyLine(ctx: Ctx, f: Field, steps: readonly Step[], name: string, title: string): HTMLElement {
  const kind = f.key!;
  const out = line(name, `${title}\n${f.mesh ? 'a model and its part' : `a ${kind} key`}`);
  const text = keyText(kind, valueAt(ctx, steps) as number) ?? '';
  const pick = picker({
    title: `${ctx.c.name}.${pathText(steps)}`, value: text, none: 'none', fixed: ctx.fixed,
    choices: () => (f.mesh ? ctx.keys.keysOf('Model') : ctx.keys.keysOf(kind)),
    ...(ctx.keys.look && kind !== 'Clip' ? { look: (key: string) => ctx.keys.look!(kind, key) } : {}),
    ...(ctx.keys.play && soundKind(kind) !== undefined ? { play: (key: string, ended: () => void) => ctx.keys.play!(kind, key, ended) } : {}),
    ...(kind !== 'Clip' ? { drops: kind, dropped: () => ctx.blocks.host.focus?.() } : {}),
    pick: (t) => {
      put(ctx, steps, () => internKey(kind, t));
      commit(ctx, steps);
    },
  });
  pick.input.dataset.mcp = 'scene_set';
  out.picks.append(pick.root);
  return out.line;
}

/** Whom a ref holds, said: the entity's label, `nobody`, or `gone`. */
function whom(ctx: Ctx, held: EntityRef): { text: string; e: Entity; gone: boolean } {
  if (held === NO_REF) return { text: 'nobody', e: NONE, gone: false };
  const e = ctx.blocks.world.deref(held);
  return e !== NONE && ctx.blocks.world.alive(e) ? { text: label(ctx.blocks.world, e), e, gone: false } : { text: 'gone', e: NONE, gone: true };
}

function refLine(ctx: Ctx, f: Field, steps: readonly Step[], name: string, title: string, inList = false): HTMLElement {
  const { world, host } = ctx.blocks;
  const needs = f.needs ?? [];
  const out = el('div', 'ed-ref ed-dataline');
  const n = el('span', 'ed-dim', name);
  n.title = `${title}\na reference to ${refTakes({ needs })}: drop a row of the tree${needs.length > 0 ? ' or a component\'s header' : ''} on it`;
  out.append(n);
  const held = whom(ctx, valueAt(ctx, steps) as EntityRef);
  if (held.e !== NONE) {
    const misfit = refMisfit({ needs }, (cn) => factsOf(world).has(held.e, cn), held.text);
    const shown = needs.length === 1 ? `${needs[0]} on ${held.text}` : held.text;
    const end = button('scene_select', `→ ${shown}`, misfit ?? `Select ${held.text}`, () => host.select(held.e), 'ed-quiet ed-link-end');
    if (misfit) end.classList.add('ed-ref-misfit');
    out.append(end);
  } else out.append(el('span', held.gone ? 'ed-ref-none ed-ref-gone' : 'ed-dim ed-ref-none', held.text));
  if (ctx.fixed) return out;
  // A tree row, or a component's header, dropped on it: pointed there, one step -- but a list's element, whose row
  // takes a drop as an element inserted before it (Docs/properties.md §3): × and + replace one there.
  // mcp: scene_set -- a drop on a data component's ref is scene_set's value at its path
  if (!inList) dropTarget(out, (record) => {
    const fit: Fit = fits({ kind: 'ref', needs }, record, factsOf(world));
    return fit.ok && 'entity' in fit && ctx.es.every((e) => e === fit.entity) ? { ok: false, why: `${label(world, fit.entity)} is the entity it would be set on` } : fit;
  }, (fit) => {
    if (!('entity' in fit)) return;
    put(ctx, steps, () => world.ref(fit.entity));
    commit(ctx, steps);
  });
  // A list's element: its row's × takes it out; nobody is what + puts there.
  if (!inList && (held.e !== NONE || held.gone)) {
    out.append(button('scene_set', '×', `Point ${ctx.c.name}.${pathText(steps)} at nobody`, () => {
      put(ctx, steps, () => NO_REF);
      commit(ctx, steps);
    }, 'ed-quiet'));
  }
  return out;
}

function stringLine(ctx: Ctx, s: StringElement, steps: readonly Step[], name: string, title: string): HTMLElement {
  const out = line(name, `${title}${s.maxLength !== undefined ? `\nat most ${s.maxLength} characters` : ''}`, 'ed-datastring');
  const box = s.multiline ? el('textarea', 'ed-input ed-textarea') : el('input', 'ed-input');
  if (box instanceof HTMLInputElement) box.type = 'text';
  box.value = String(valueAt(ctx, steps) ?? '');
  if (s.maxLength !== undefined) box.maxLength = s.maxLength;
  box.disabled = ctx.fixed;
  box.dataset.mcp = 'scene_set';
  // Typing in it is typing: the editor's keys never fire (MrDebug's field rules); Enter in a text area is a new line.
  box.dataset.keysField = 'data-text';
  box.title = title;
  box.addEventListener('change', () => {
    const text = s.maxLength !== undefined ? box.value.slice(0, s.maxLength) : box.value;
    put(ctx, steps, () => text);
    commit(ctx, steps);
  });
  out.picks.append(box);
  return out.line;
}

// ---------------------------------------------------------------- the groups

/** A group's head: a caret and its name (a click folds it), and what follows. */
function groupHead(key: string, name: string, title: string, open: boolean, toggle: (open: boolean) => void): HTMLElement {
  const head = el('div', 'ed-data-head');
  const caret = control('ui', 'ed-quiet ed-data-caret', open ? '▾' : '▸');
  caret.title = open ? 'Fold it' : 'Open it';
  caret.setAttribute('aria-expanded', String(open));
  // mcp: ui -- a list, a dictionary or a record folded or opened
  caret.addEventListener('click', () => toggle(!open));
  const n = el('span', 'ed-data-name', name);
  n.title = title;
  head.append(caret, n);
  head.dataset.group = key;
  return head;
}

function recordBlock(ctx: Ctx, r: RecordElement, steps: readonly Step[], name: string, title: string, top: boolean): HTMLElement {
  const key = `${ctx.c.name}:${pathText(steps)}`;
  const open = top ? !shut.has(key) : opened.has(key);
  const box = el('div', 'ed-data-group ed-data-record');
  box.append(groupHead(key, name, title, open, (now) => {
    if (top) (now ? shut.delete(key) : shut.add(key));
    else (now ? opened.add(key) : opened.delete(key));
    box.replaceWith(recordBlock(ctx, r, steps, name, title, top));
  }));
  if (open) {
    const body = el('div', 'ed-data-body');
    for (const [f, sub] of Object.entries(r.fields)) if (!sub.hidden) body.append(widget(ctx, sub, [...steps, { name: f }], sub.label ?? labelOf({ name: f, field: sub as Field })));
    box.append(body);
  }
  return box;
}

/** A list's or a dictionary's foot: + (its tool), greyed with why where it takes no more. */
function adder(tool: 'scene_list_insert', why: string | null, title: string, run: () => void): HTMLElement {
  const plus = button(tool, '+', why ?? title, run, 'ed-quiet ed-small ed-data-add');
  plus.disabled = why !== null;
  return plus;
}

/** A row's grip: dragged up or down within its list, one step (the grip's tool). */
function grip(ctx: Ctx, list: string, from: number): HTMLElement {
  const g = el('span', 'ed-data-grip', '⠿');
  g.title = ctx.fixed ? 'Its place' : 'Drag up or down to move it';
  g.dataset.mcp = 'scene_list_move';
  if (ctx.fixed) return g;
  g.draggable = true;
  // mcp: scene_list_move -- a row dragged by its grip
  g.addEventListener('dragstart', (event) => {
    gripped = { list, from };
    event.dataTransfer?.setData('text/plain', `${list}[${from}]`);
    if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move';
  });
  g.addEventListener('dragend', () => void (gripped = null));
  return g;
}

/** A row takes a grip's drop from its own list: the element dragged lands before it (`before`), one step. */
function gripTarget(row: HTMLElement, list: string, before: number, length: number, move: (from: number, to: number) => void): void {
  row.addEventListener('dragover', (event) => {
    if (gripped?.list !== list) return;
    event.preventDefault();
    event.stopPropagation();
    row.classList.add('ed-data-before');
  });
  row.addEventListener('dragleave', () => row.classList.remove('ed-data-before'));
  row.addEventListener('drop', (event) => {
    if (gripped?.list !== list) return;
    event.preventDefault();
    event.stopPropagation();
    row.classList.remove('ed-data-before');
    const to = moveTo(gripped.from, before, length);
    const from = gripped.from;
    gripped = null;
    if (to !== null) move(from, to);
  });
}

/**
 * Drops of what an element takes onto `target` -- tree rows, a header, assets, several at once -- each inserted at
 * `at` (the end, for the list itself), one step; lit while a drag that fits is under way, dimmed with why if not.
 */
function elementDrops(ctx: Ctx, target: HTMLElement, list: ListElement, steps: readonly Step[], at: () => number): void {
  const field = dropFieldOf(list.of);
  if (field === null || ctx.fixed) return;
  let last: ManyFit = { ok: false, why: '' };
  // mcp: scene_list_insert -- a drop of entities or assets onto a list
  dropTarget(target, (record) => {
    const now = valueAt(ctx, steps) as unknown[];
    last = fitsMany(field, record, factsOf(ctx.blocks.world), room(list, now.length));
    return last.ok ? { ok: true, entities: [] } : { ok: false, why: last.why };
  }, () => {
    if (!last.ok) return;
    const items = last.items.map((x) => dropped(ctx, list.of, x));
    const where = at();
    // The keys to this side (the drag began on the Assets panel's, which had them): Z is this drop's.
    ctx.blocks.host.focus?.();
    change(ctx, steps, 'Add to', (value) => void (value as unknown[]).splice(Math.min(where, (value as unknown[]).length), 0, ...items));
  });
}

function listBlock(ctx: Ctx, list: ListElement, steps: readonly Step[], name: string, title: string): HTMLElement {
  const key = `${ctx.c.name}:${pathText(steps)}`;
  const items = valueAt(ctx, steps) as unknown[];
  const open = !shut.has(key);
  const box = el('div', 'ed-data-group ed-data-list');
  const head = groupHead(key, `${name} (${items.length})`, `${title}\n${list.min !== undefined || list.max !== undefined ? `${list.min ?? 0} to ${list.max ?? 'any number'} of ` : 'a list of '}${(list.of as Field).needs ? refTakes(list.of as Field) : 'its element'}`, open, (now) => {
    if (now) shut.delete(key);
    else shut.add(key);
    box.replaceWith(listBlock(ctx, list, steps, name, title));
  });
  box.append(head);
  elementDrops(ctx, box, list, steps, () => (valueAt(ctx, steps) as unknown[]).length);
  if (!open) return box;
  const rows = el('div', 'ed-data-rows');
  const drawRow = (i: number): HTMLElement => {
    const row = el('div', 'ed-data-row');
    row.dataset.field = `${ctx.c.name}.${pathText([...steps, { index: i }])}`;
    row.append(grip(ctx, key, i), widget(ctx, list.of, [...steps, { index: i }], String(i)));
    if (!ctx.fixed) {
      const can = canRemove(list, items.length);
      const x = button('scene_list_remove', '×', can ? `Remove ${i}` : `At its least, ${list.min}: none may go`, () => change(ctx, steps, 'Remove from', (value) => void (value as unknown[]).splice(i, 1)), 'ed-quiet ed-data-x');
      x.disabled = !can;
      row.append(x);
      gripTarget(row, key, i, items.length, (from, to) => change(ctx, steps, 'Move in', (value) => moveItem(value as unknown[], from, to)));
      elementDrops(ctx, row, list, steps, () => i);
    }
    return row;
  };
  // A long list of one-line elements is drawn as far as it is scrolled; one of records or lists, whose rows open, whole.
  if (items.length > VIRTUAL && !('shape' in list.of && list.of.shape !== 'string')) virtualRows(rows, key, items.length, drawRow);
  else for (let i = 0; i < items.length; i++) rows.append(drawRow(i));
  box.append(rows);
  if (!ctx.fixed) {
    const foot = el('div', 'ed-data-foot');
    // The foot takes a grip's drop too: to the end.
    gripTarget(foot, key, items.length, items.length, (from, to) => change(ctx, steps, 'Move in', (value) => moveItem(value as unknown[], from, to)));
    const r = room(list, items.length);
    foot.append(adder('scene_list_insert', r === 0 ? `At its most, ${list.max}: none may be added` : null, `Add one at its default -- or drop ${dropFieldOf(list.of) ? 'what it holds' : 'nothing'} here`, () => change(ctx, steps, 'Add to', (value) => void (value as unknown[]).push(dataDefault(list.of)))));
    box.append(foot);
  }
  return box;
}

/** Each long list's mount, by `Component:path`: let go of as the inspector draws the list again. */
const mounts = new Map<string, Mounted>();

/**
 * A long list's rows (`virtual.ts`' `mount`): a box that scrolls, only the rows in view in it, each kept by its index
 * -- scrolled, a row in view stays the same element, so a field focused in it keeps the focus -- its scroll kept as
 * the inspector is built again. Its rows' height is the first row's as drawn: only a list of one-line elements is
 * drawn so (a list of records or lists, whose rows open and grow, draws every row).
 */
function virtualRows(rows: HTMLElement, key: string, count: number, draw: (i: number) => HTMLElement): void {
  rows.classList.add('ed-data-scroll');
  mounts.get(key)?.dispose();
  let height = 0;
  const m = mount({
    list: rows,
    rowHeight: () => height || 30,
    perRow: () => 1,
    count: () => count,
    key: (i) => String(i),
    make: (i) => {
      const row = draw(i);
      row.classList.add('ed-data-vrow');
      return row;
    },
    update: () => {},
  });
  mounts.set(key, m);
  rows.addEventListener('scroll', () => void scrolled.set(key, rows.scrollTop), { passive: true });
  // Once it is in the page: its rows' height as drawn, and where it was scrolled to.
  queueMicrotask(() => {
    const first = rows.querySelector<HTMLElement>(':scope > .ed-data-vrow');
    height = first?.offsetHeight ?? 0;
    rows.scrollTop = scrolled.get(key) ?? 0;
    m.flush();
  });
}

/** A dictionary's key, as its row shows it: an editable text, an enum's name to pick, a number; an entity's line. */
function keyWidget(ctx: Ctx, d: DictElement, steps: readonly Step[], k: unknown, note: HTMLElement): HTMLElement {
  const kf = d.keyOf;
  const map = (): Map<unknown, unknown> => valueAt(ctx, steps) as Map<unknown, unknown>;
  const said = (x: unknown): string => JSON.stringify(!('shape' in kf) && kf.enum ? kf.enum[x as number] ?? x : x);
  /** Every one shown renamed, or the clash said where it was typed: nothing written. */
  const rename = (to: unknown): boolean => {
    for (const e of ctx.es) {
      const m = elementAt(ctx.c.data, slotOf(ctx, e), steps).value as Map<unknown, unknown>;
      if (to !== k && m.has(to)) {
        note.textContent = `${said(to)} is a key already: a key is in a dictionary once -- not renamed`;
        note.hidden = false;
        return false;
      }
    }
    // One step, `scene_list_move`'s rename.
    change(ctx, steps, 'Rename in', (value) => void renameKey(value as Map<unknown, unknown>, k, to));
    return true;
  };
  if ('shape' in kf) {
    const box = el('input', 'ed-input ed-data-key');
    box.type = 'text';
    box.value = String(k);
    box.disabled = ctx.fixed;
    box.dataset.mcp = 'scene_list_move';
    box.dataset.keysField = 'data-text';
    box.title = 'Its key: typed, and Enter or leaving the field renames it';
    box.addEventListener('input', () => {
      const clash = box.value !== k && map().has(box.value);
      box.classList.toggle('ed-invalid', clash);
      note.textContent = clash ? `${JSON.stringify(box.value)} is a key already` : '';
      note.hidden = !clash;
    });
    box.addEventListener('change', () => {
      if (box.value === k) return;
      if (!rename(box.value)) box.classList.add('ed-invalid');
    });
    return box;
  }
  if (kf.ref) {
    const held = whom(ctx, k as EntityRef);
    return el('span', 'ed-data-key ed-dim', `→ ${held.text}`);
  }
  if (kf.enum) {
    const names = kf.enum;
    const pick = picker({
      title: `${ctx.c.name}.${pathText(steps)}'s key`, value: names[k as number] ?? String(k), choices: () => names, fixed: ctx.fixed,
      pick: (text) => {
        const at = names.indexOf(text);
        if (at >= 0 && at !== k) rename(at);
      },
    });
    pick.root.classList.add('ed-enum', 'ed-data-key');
    pick.input.dataset.mcp = 'scene_list_move';
    return pick.root;
  }
  let typed = k as number;
  const field = numberField({
    label: '', value: k as number, step: kf.step ?? 1, integer: kf.type !== 'f32' && kf.type !== 'f64', fixed: ctx.fixed,
    set: (v) => void (typed = v),
    commit: () => void (typed !== k && rename(typed)),
  });
  field.input.dataset.mcp = 'scene_list_move';
  field.label.classList.add('ed-data-key');
  return field.label;
}

function dictBlock(ctx: Ctx, d: DictElement, steps: readonly Step[], name: string, title: string): HTMLElement {
  const key = `${ctx.c.name}:${pathText(steps)}`;
  const map = valueAt(ctx, steps) as Map<unknown, unknown>;
  const open = !shut.has(key);
  const box = el('div', 'ed-data-group ed-data-dict');
  box.append(groupHead(key, `${name} (${map.size})`, `${title}\na dictionary, its entries in the order written`, open, (now) => {
    if (now) shut.delete(key);
    else shut.add(key);
    box.replaceWith(dictBlock(ctx, d, steps, name, title));
  }));
  if (!open) return box;
  const rows = el('div', 'ed-data-rows');
  const entries = [...map.keys()];
  entries.forEach((k, i) => {
    const row = el('div', 'ed-data-row ed-data-entry');
    const at = [...steps, entryStep(d, k)];
    row.dataset.field = `${ctx.c.name}.${pathText(at)}`;
    const note = el('div', 'ed-data-clash');
    note.hidden = true;
    const value = widget(ctx, d.valueOf, at, '');
    row.append(grip(ctx, key, i), keyWidget(ctx, d, steps, k, note), value);
    if (!ctx.fixed) {
      row.append(button('scene_list_remove', '×', 'Remove this entry', () => change(ctx, steps, 'Remove from', (m) => void (m as Map<unknown, unknown>).delete(k)), 'ed-quiet ed-data-x'));
      gripTarget(row, key, i, entries.length, (from, to) => change(ctx, steps, 'Move in', (m) => moveEntry(m as Map<unknown, unknown>, from, to)));
    }
    rows.append(row, note);
  });
  box.append(rows);
  if (!ctx.fixed) {
    const free = freeKey(d, map);
    const foot = el('div', 'ed-data-foot');
    gripTarget(foot, key, entries.length, entries.length, (from, to) => change(ctx, steps, 'Move in', (m) => moveEntry(m as Map<unknown, unknown>, from, to)));
    const keyRef = !('shape' in d.keyOf) && d.keyOf.ref === true ? (d.keyOf as Field) : null;
    const why = free === null ? (keyRef ? `An entity's entry: drop a row of the tree here -- ${refTakes(keyRef)} -- its key` : 'Every key it can have, it has') : null;
    // A dictionary keyed by entities: a tree row (or a header) dropped on its foot is a new entry, that entity its key.
    // mcp: scene_list_insert -- an entity dropped on a ref-keyed dictionary's foot, its new entry's key
    if (keyRef) dropTarget(foot, (record) => {
      const fit = fits({ kind: 'ref', needs: keyRef.needs ?? [] }, record, factsOf(ctx.blocks.world));
      if (!fit.ok || !('entity' in fit)) return fit;
      const r = ctx.blocks.world.ref(fit.entity);
      return ctx.es.some((e) => (elementAt(ctx.c.data, slotOf(ctx, e), steps).value as Map<unknown, unknown>).has(r)) ? { ok: false, why: `${label(ctx.blocks.world, fit.entity)} has an entry already: a key is in a dictionary once` } : fit;
    }, (fit) => {
      if (!('entity' in fit)) return;
      const r = ctx.blocks.world.ref(fit.entity);
      change(ctx, steps, 'Add to', (m) => void (m as Map<unknown, unknown>).set(r, dataDefault(d.valueOf)));
    });
    foot.append(adder('scene_list_insert', why, `Add an entry: ${JSON.stringify(!('shape' in d.keyOf) && d.keyOf.enum ? d.keyOf.enum[free as number] : free)}, its value its default`, () => change(ctx, steps, 'Add to', (m) => void (m as Map<unknown, unknown>).set(free, dataDefault(d.valueOf)))));
    box.append(foot);
  }
  return box;
}
