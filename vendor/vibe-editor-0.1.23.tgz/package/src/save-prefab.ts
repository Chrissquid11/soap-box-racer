/**
 * "Save as prefab…" (Docs/prefabs.md §7): entities in the scene written as a
 * new prefab file, and replaced by an instance of it where they stood -- one
 * undo step that, undone, puts the entities back and the file in the trash.
 * From the tree's menu and its key (`entities.ts`), and from a drag of the
 * selection onto a folder of the Assets tool (`assets/ui/assets-tool.ts`).
 *
 * The rules:
 *   - **The name is a path under `prefabs/`, a name in a folder**, as typed
 *     -- `Test Case/Big Thing` is `Test Case/Big Thing.prefab` -- and its key
 *     the name lowercased (`caseKey`): each part a name `validName` takes, none
 *     starting with `_`, and one whose key a file has (in any case) is refused
 *     (`keyProblem`).
 *   - **The file is the selection's roots and everything under them**,
 *     written by `clipToPrefab`: several roots under one empty root, said in
 *     the question. Roots under one parent are written in its space and the
 *     instance goes under it; roots under different ones, in the world's.
 *   - **The instance comes once the prefab is compiled**: the file is written
 *     (`PUT prefab { create }`), the dev server's push recompiles it
 *     (`whenCompiled`), and only then are the entities destroyed and the
 *     instance made -- so a file that does not compile changes nothing in the
 *     scene, and goes to the trash again with its error said.
 *   - **One step**: the world before and after, as a world step keeps them,
 *     and the file. Undo puts the world before back at once and sends the
 *     file to the trash, as `prefab-steps.ts`' New prefab is undone; Redo
 *     writes it again and, once it is compiled, puts the world after back.
 *     Its file calls run one after another, never two at once.
 *   - **Edits made while it waits are kept** (the compile takes a moment):
 *     the selection is written as it was asked, and nothing in the world is
 *     touched until the compile is in. Then "before" is the world as it is
 *     then -- what was edited meanwhile in it, each its own step below this
 *     one -- so Undo takes back only what Save as prefab did. If the
 *     selection itself changed meanwhile (an entity of it edited, moved or
 *     gone), the file no longer says what it is: nothing is replaced, the
 *     file goes to the trash, and that is said. If the scene is not there to
 *     replace them in -- a playtest, a prefab opened, the editor closed -- the
 *     same. Chosen over locking the world: nothing has to know about a lock
 *     (the agent's edits, every tool's), and nothing can be lost.
 *   - **What systems set is carried over** (`takeRuntime`, `putRuntime`): the
 *     instance is made fresh, so each runtime field of the entities it
 *     replaces -- a follower's target, a spin's angle -- is put on its
 *     counterpart (by its path in the file, `clipToPrefab`'s `paths`), a ref
 *     into the selection re-pointed at the new entity. The scene goes on as
 *     it was.
 */
import { caseKey, compiledPrefab, type Entity, Hierarchy, inTreeOrder, Name, NONE, type PrefabFile, Transform, untypedPrefab as prefab, type WorldSave } from '@vibe/engine';
import { assetApi } from './assets/boot.ts';
import { prefabFileOf, prefabNameOf, prefabNameProblem, prefabText } from './assets/ui/prefab-steps.ts';
import { putRuntime, takeRuntime } from './bring-up.ts';
import { copyOut } from './clip.ts';
import type { Step } from './history.ts';
import { clipToPrefab, pathOf } from './prefab-write.ts';
import { livePrefabs, whenCompiled } from './prefabs-live.ts';
import { spawnAt } from './spawn.ts';
import type { EditorContext } from './tool.ts';
import { PENDING } from './world-steps.ts';

/** Why `name` (a path under `prefabs/`, as typed) cannot be a new prefab's, or null if it can: its key is it lowercased. */
export function keyProblem(name: string, files: Readonly<Record<string, PrefabFile>>): string | null {
  const problem = prefabNameProblem(name);
  if (problem !== null) return problem;
  const key = caseKey(name);
  if (Object.keys(files).some((k) => caseKey(k) === key) || compiledPrefab(key)) return `there is a prefab ${key} already (a key is the name lowercased)`;
  return null;
}

/** The selection's roots: each chosen entity not under another chosen, alive, in the tree's order -- the roots' among them (Docs/ecs.md §8), so a prefab of several keeps it. */
export function rootsOfChoice(ctx: EditorContext, chosen: readonly Entity[]): Entity[] {
  const { world } = ctx;
  const parent = world.store(Hierarchy).parent;
  const set = new Set(chosen);
  return inTreeOrder(world, chosen).filter((e) => {
    if (!world.alive(e)) return false;
    for (let a = parent[e]! as Entity; a !== NONE; a = parent[a]! as Entity) if (set.has(a)) return false;
    return true;
  });
}

/** A name for the selection in `folder` (its path under `prefabs/`, `crates`): its first root's name as it is -- a file's name made of it if need be -- free. */
export function suggestKey(ctx: EditorContext, folder: string, roots: readonly Entity[], files: Readonly<Record<string, PrefabFile>>): string {
  const names = ctx.world.rawStore(Name) as { value: (string | null)[] };
  const first = roots[0];
  const named = first !== undefined && ctx.world.has(first, Name) ? names.value[first] : null;
  const stem = `${folder}/${roots.length > 1 ? 'group' : prefabNameOf(named)}`;
  let key = stem;
  for (let n = 2; keyProblem(key, files) !== null; n++) key = `${stem}-${n}`;
  return key;
}

/** The agent's call (`scene_save_prefab`): its step's label prefixed (`Claude: `), and the step and the instance's root handed back. */
export interface SaveOptions {
  prefix?: string;
  made?(step: Step, root: Entity): void;
}

/** The file calls of every save step, one after another. */
let queue: Promise<unknown> = Promise.resolve();
const inTurn = (job: () => Promise<unknown>): void => {
  queue = queue.then(job).catch((err: unknown) => console.warn(`[editor] save as prefab: ${err instanceof Error ? err.message : String(err)}`));
};

/**
 * `chosen` written as the prefab `key` and replaced by an instance of it, one
 * step; `told` after the world changed under the tool (a redo, which lands
 * later). Resolves to what to say; rejects with why nothing was done.
 */
export async function saveAsPrefab(ctx: EditorContext, key: string, chosen: readonly Entity[], told: () => void, options: SaveOptions = {}): Promise<string> {
  const { world, worldSteps, history, game } = ctx;
  const roots = rootsOfChoice(ctx, chosen);
  if (roots.length === 0) throw new Error('nothing selected');
  worldSteps.commit(PENDING);
  world.flush();
  const tree = world.store(Hierarchy);
  const parent = tree.parent[roots[0]!]! as Entity;
  const shared = roots.every((r) => tree.parent[r] === parent);
  /** The selection as a clip: what the file says, and -- taken again once compiled -- whether it still does. */
  const take = (order: Entity[] = []) => {
    const clip = copyOut(world, roots, order);
    // Under one parent: its space, and the instance goes under it. A clip's roots are their pose in the world.
    if (shared && parent !== NONE) {
      const t = world.store(Transform);
      let at = 0;
      for (const entry of clip.entities) {
        if (entry.parent >= 0) continue;
        const r = roots[at++]!;
        const data = entry.data[Transform.name];
        if (!data) continue;
        for (const f of ['px', 'py', 'pz', 'qx', 'qy', 'qz', 'qw', 'sx', 'sy', 'sz'] as const) data[f] = t[f][r]!;
      }
    }
    return clip;
  };
  const clip = take();
  const asked = JSON.stringify(clip);
  const scene = { aside: history.aside, prefab: ctx.prefab };
  const { file, placed, notes, paths } = clipToPrefab(clip, { compiled: compiledPrefab, name: key.slice(key.lastIndexOf('/') + 1).replaceAll('-', ' ') });
  // Written as named; known from here on by its key, the name lowercased.
  const path = prefabFileOf(key);
  key = caseKey(key);
  const text = prefabText(file);
  const api = assetApi();
  await api.putPrefab(path, text, true);
  if (!(await whenCompiled(key, true))) {
    const why = livePrefabs.problemOf(key) ?? 'it was not compiled in time';
    await api.remove([path], true).catch(() => undefined);
    throw new Error(`${key} did not compile, so the file went to the trash again: ${why}`);
  }
  // The world as it is now, edits made meanwhile in it: what Undo puts back. The selection as asked, or nothing is replaced.
  worldSteps.commit(PENDING);
  world.flush();
  const away = ctx.playing ? 'a playtest began' : ctx.prefab !== scene.prefab || history.aside !== scene.aside ? 'another world came into the scene' : ctx.root.hidden ? 'the editor closed' : null;
  /** The selection's entities in the clip's order, as `paths` has them. */
  const order: Entity[] = [];
  const changed = away ?? (!roots.every((r) => world.alive(r)) ? 'an entity of the selection is gone' : JSON.stringify(take(order)) !== asked ? 'the selection was edited' : null);
  if (changed) {
    await api.remove([path], true).catch(() => undefined);
    throw new Error(`${changed} while ${key} was compiled, so the file went to the trash and nothing was replaced: Save as prefab again`);
  }
  const before = JSON.stringify(world.save());
  const runtime = takeRuntime(world, order);
  for (const r of roots) if (world.alive(r)) world.destroy(r);
  world.flush();
  const e = spawnAt(world, prefab(key), placed);
  if (e !== NONE && shared && parent !== NONE && world.alive(parent)) world.setParent(e, parent);
  world.flush();
  if (e !== NONE) {
    // Each replaced entity's counterpart in the instance, by its path: what systems set on it goes on as it was.
    const made = new Map<string, Entity>();
    const tree = world.store(Hierarchy);
    for (const stack = [e]; stack.length > 0; ) {
      const x = stack.pop()!;
      const at = world.instanceRoot(x) === e ? pathOf(world.kindOfEntity(x).name, key) : null;
      if (at !== null) made.set(at, x);
      for (let c = tree.firstChild[x]! as Entity; c !== NONE; c = tree.nextSibling[c]! as Entity) stack.push(c);
    }
    putRuntime(world, runtime, paths.map((at) => (at === null ? null : (made.get(at) ?? null))));
  }
  const after = JSON.stringify(world.save());
  const load = (json: string): void => void game.load(JSON.parse(json) as WorldSave);
  const step: Step = {
    label: `${options.prefix ?? ''}Save as prefab ${key}`,
    size: before.length + after.length,
    undo: () => {
      load(before);
      inTurn(async () => {
        await api.remove([path], true);
        await whenCompiled(key, false);
      });
    },
    redo: () => {
      inTurn(async () => {
        await api.putPrefab(path, text, true);
        if (!(await whenCompiled(key, true))) throw new Error(`${key} did not compile again: the entities stay as they were`);
        load(after);
        worldSteps.sync();
        told();
      });
    },
  };
  history.push(step);
  options.made?.(step, e);
  if (e !== NONE) ctx.selection.choose(e);
  const said = `Saved as prefab ${key}${roots.length > 1 ? ` (${roots.length} under one root)` : ''}: the selection is an instance of it`;
  return notes.length > 0 ? `${said} · ${notes.join(' · ')}` : said;
}
