/**
 * Studio mode's recovery, its rule for reloading (Docs/studio.md §1, "Recovery"): the game could not load, the
 * editor is up over a stand-in game with a `boot` notice (`notices.ts`), and the page reloads itself when the
 * fix lands -- boot then makes the game for real.
 *
 * - **A Claude turn ended** (`turn-ended`): the turn was the fix, or its try. (Its held code's replay may reload
 *   the page first; the next boot is a real one, and resumes as ever.)
 * - **A file changed under `src/` or `AssetsSource/`** (`file`: the dev server's `studio:file-changed`) -- a save
 *   in the Code card, the shell, the Finder -- or **an export landed** (`export`: the assets push's job `done`).
 * - **Never while a turn runs**: its half-made edits are not the fix; its end is.
 * - **Debounced**, `RECOVERY_DEBOUNCE_MS`: a burst of saves is one reload, a second after the last (`due`).
 * - **Never while a module is broken** (`held`: the dev server's list, Docs/studio.md §1 "Mid-session"): a save that
 *   leaves a syntax error is no fix, and a reload would only come back to this; the save that mends it reloads.
 *
 * `recoveryReload` is the rule, pure; `createRecoveryReload` keeps its clock, its effects handed in -- node
 * tests both.
 */

/** How long after the last event that calls for it the page reloads. */
export const RECOVERY_DEBOUNCE_MS = 1000;

/** What was heard: a turn's end, a file changed, an export landed -- or the debounce's timer come due. */
export type RecoveryEvent = { kind: 'turn-ended' } | { kind: 'file'; path: string } | { kind: 'export' } | { kind: 'due' };

export interface RecoveryState {
  /** Is a Claude turn running? */
  running: boolean;
  /** When the last event that called for a reload was heard, or null for none yet. */
  lastAt: number | null;
  now: number;
}

/** Is `path` (relative to the root) where a fix is written: the project's code and assets, or the sources? */
export function fixPath(path: string): boolean {
  const p = path.replace(/\\/g, '/').replace(/^\.\//, '');
  return (p.startsWith('src/') || p.startsWith('AssetsSource/')) && !p.split('/').includes('node_modules');
}

/**
 * Does `event` call for a reload? For a turn's end, a fix's file or an export: yes, unless a turn runs (the reload
 * then waits a debounce). For `due`: yes once no turn runs and the debounce has passed since the last.
 */
export function recoveryReload(event: RecoveryEvent, state: RecoveryState): boolean {
  if (state.running) return false;
  switch (event.kind) {
    case 'due':
      return state.lastAt !== null && state.now - state.lastAt >= RECOVERY_DEBOUNCE_MS;
    case 'file':
      return fixPath(event.path);
    case 'turn-ended':
    case 'export':
      return true;
  }
}

export interface RecoveryReloadHost {
  /** Is a Claude turn running now? */
  running(): boolean;
  /** Is the page still in recovery -- a `boot` notice up? A frame or scene notice reloads nothing. */
  active(): boolean;
  /** Is a module of the project's broken now (the dev server says)? Then the reload waits for the save that mends it. */
  held?(): boolean;
  /** The reload: `location.reload()`. */
  reload(): void;
  now(): number;
  later(run: () => void, ms: number): unknown;
  cancel(timer: unknown): void;
}

export interface RecoveryReload {
  /** An event heard: the reload armed for a debounce from now, if it calls for one. */
  heard(event: Exclude<RecoveryEvent, { kind: 'due' }>): void;
  dispose(): void;
}

/** The rule on a clock: each event that calls for it arms the reload a debounce away; due, it reloads -- unless a turn runs, then the next event does. */
export function createRecoveryReload(host: RecoveryReloadHost): RecoveryReload {
  let lastAt: number | null = null;
  let timer: unknown = null;
  const due = (): void => {
    timer = null;
    if (!host.active() || host.held?.()) return;
    if (recoveryReload({ kind: 'due' }, { running: host.running(), lastAt, now: host.now() })) host.reload();
  };
  return {
    heard(event) {
      if (!host.active()) return;
      if (!recoveryReload(event, { running: host.running(), lastAt, now: host.now() })) return;
      lastAt = host.now();
      if (timer !== null) host.cancel(timer);
      timer = host.later(due, RECOVERY_DEBOUNCE_MS);
    },
    dispose() {
      if (timer !== null) host.cancel(timer);
      timer = null;
    },
  };
}
