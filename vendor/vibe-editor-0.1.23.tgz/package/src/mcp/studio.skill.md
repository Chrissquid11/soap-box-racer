---
skill: studio
title: Working in the studio
when: First, before any studio tool -- how a call goes: read first, one step Z undoes, jobs, refusals and time-outs, what asks the person, images, finding a tool
covers:
  tools:
    - studio_state
    - studio_context
    - batch
    - history_list
    - history_undo
    - history_redo
    - job_status
    - job_wait
order: 10
---
# Working in the studio

This page is for Claude in a game project made on `@vibe/engine`, working beside a person who has the studio open.

The studio is the game's editor, in the person's browser tab (`?studio` on the dev server's address, or the
Squidwright app's window): a Scene tab (the entity tree, the scene, one inspector, the Assets panel along the
bottom), a Model tab (Gladius scripts), a Studio tab (Console, Problems, Tests, Build, Code, Git) and a Config tab.
Every action a person has there is an MCP tool here, `mcp__studio__<area>_<verb>`, run through the same code as
the person's button, with the same checks and the same refusals. Each other page of this skill is one editor:
read the one the job needs.

Never edit a file the editor has open (a `.scene`, a `.prefab` open to edit) with a file tool, and never `curl` the
dev server's routes: the editor would not know, and its next save writes over yours. Go through the tools. Game
code (`src/game/`, `src/ui/`) is yours to write with Edit and Write as always -- the [code page](code.md) says
how to check it.

## Two kinds of tool

- **Page tools** act on the editor's world in the open studio tab (the scene, the playtest, the view, the Model
  tab). With no tab open they answer "The studio is not open: ask the person to open …" and the address -- ask
  them, and wait.
- **Server tools** run in the dev server and need no tab: the asset reads, tests, builds, TypeScript, git, jobs.
  The asset writes are page tools that the dev server runs itself when no tab is open (the
  [assets page](assets.md) says what changes then).

## Read first, every time

Nothing is known until it is read, and the person keeps working between your calls.

- **`studio_state`** -- what is open: the tab shown, the scene (its name, saved or not), a prefab open to edit,
  the playtest (none, running, paused), the Problems card's count, the jobs running -- and every selected entity
  whole, with its overrides if it is an instance. "This", "the selected one", "it" mean what this says is
  selected now, not what was selected three calls ago.
- Then the reads of the editor at hand: `scene_query` and `scene_entity` ([the scene](scene.md)),
  `asset_list` and `asset_info` ([assets](assets.md)), `model_info` ([the Model tab](model.md)), `play_state`
  ([play and view](play.md)), `problems_list` ([code](code.md)).
- Read again before acting on anything read a while ago. Where the person may be editing the same field,
  `scene_set`'s `was` writes only if the field still holds what you read; if not, nothing is written and the
  answer gives the value now (`changed`) -- read it and decide again.

## One step, one `Z`

- **A world edit is one step** on the editor's undo stack, labelled `Claude: …` (`Claude (<conversation>): …`
  while several conversations are open). The person undoes it with `Z` as one of their own, and sees it in the
  History card -- with a sparkle, your turn's steps together under one row ("Claude · 3 edits"), each still its own
  step to `Z` -- and the entities you changed are marked in the tree and outlined in the scene as each edit lands. So
  change only what the job needs: every entity you touch is shown to the person as yours.
- **`batch`** runs several scene edits as ONE step: the [scene page](scene.md) has its rules (at most 64
  calls, `"$0"` for what call 0 made, all or nothing). Use it for edits that belong together, so one `Z` takes
  back the whole job.
- **An asset change** is a step in the Assets panel's own history (`Z` with the panel focused), a Model tab
  change one of the Model tab's. Neither is on the world's stack, and `history_undo` does not reach them.
- **Undo this turn**, under each of your turns in the person's transcript, takes back what the turn did: its
  file writes, and its world steps while every step above them is yours.
- A step you make after the person undid something drops their undone step from the redo side. The answer says
  so ("this step dropped it from the redo side") -- tell them.

**`history_list`** shows the world's steps: each label, whose it is (`by`: Claude, an outside client's `MCP: …`, or
the person), and where the person is in it. **`history_undo`** / **`history_redo`** take `n` steps (1 by default,
at most 100) from the latest. They are for your own steps: one of the person's among them refuses the whole call,
unless `any: true` -- which takes back the person's work, so only when they asked, and it asks them first. Neither
works while a playtest runs (paused, they do). To take back one edit of yours that is not on top, make the opposite edit instead.

## Long work is a job

An export, a build, a test run or a model's build answers within about 20 s if it is done by then; otherwise it
answers at once with a job id and keeps going.

- **`job_wait`** with that `id` waits for it to end -- up to `timeoutMs`, five minutes at most and by default --
  and answers it as it ended, or as it stands when the time ran out ("Still running after … s"): then wait
  again, or do other work meanwhile.
- **`job_status`** reads one job (`id`), or every job kept: the running ones, and the last 64 that ended. A job
  has a state (running, done, failed), progress, its result or its error. A job running past its lifetime (an
  hour) is failed as abandoned; a dev server restarted fails the jobs it was running.
- **`job_cancel`** stops a test run or a build (the task running, and its job) -- the [code page](code.md) says
  when.
- `studio_state` lists the running jobs too. The person sees the same jobs in the Assets panel's job strip and
  the Studio tab's cards.

## When a call is not done

Every tool that will not do something says why and changes nothing.

| The answer says | What it means, and what to do |
|---|---|
| The studio is not open: ask the person to open … | no studio tab: ask them to open that address; nothing was done |
| A playtest is running in the studio | while one runs (not paused) the editor's world is the game's: of the page tools only `studio_state`, `history_list`, the `play_*`, `view_*` and `game_view_*` tools, `physics_state`, `physics_raycast`, `physics_overlap` ([physics](physics.md): `physics_settings_set` refuses itself while one is on) and the asset writes (`asset_new`, `asset_move`, `asset_copy`, `asset_delete`, `asset_restore`, `asset_options`, `asset_export`, `material_set`, `prefab_edit`, `model_adopt`) answer, and every server tool (`asset_list`, `asset_info`, tests, code, git, jobs); the scene's reads and edits (`scene_query`, `scene_entity`, `scene_describe` …), `prefab_info`, the Model tab's other tools (`model_info` too), `history_undo` / `history_redo` and the project's own tools answer this. `play_pause` (then they work on the paused world) or `play_stop` ([play](play.md)) -- ask first if the person started it |
| The studio tab has no Assets panel made yet | ask the person to bring it up (`4`), then try again |
| did not answer … within … s: … It may yet be done | the editor may still be working (a compile): read `studio_state` (or `asset_list` for an asset tool) to see whether it landed before calling again -- never just repeat a write |
| The studio tab went away after … reached it: it may yet be done | the same: read first, then decide |
| The user declined this tool call | the person said no: do not try it another way; ask what they want |
| anything else | the tool's own refusal, in words: it names what to do (a field to set first, a name it does know) |

A call that waited past its deadline is never begun late: if the editor had not started it by then, it never
will. One that had started may still finish -- that is why you read before trying again.

## What asks the person

The person picks the permission level in the settings chip under the prompt box, at the foot of Claude's column at the
window's right edge; it is theirs alone, and no tool changes it
(`claude_settings` reads it: [Config](config.md)).

- **Reads never ask**, at any level.
- **Ask**: every write asks.
- **Auto**: writes go by; destructive calls ask -- `asset_delete`, `asset_empty_trash`, `history_undo` /
  `history_redo` with `any`, `scene_open` / `scene_new` / `model_open` with `discard`, `scene_close_prefab` with
  `save: false`, `git_commit` naming a file this turn did not write, `git_branch` with `confirm`, `git_push`,
  `git_pull`.
- **Unsafe auto**: those go by too. Still asks, at every level: `asset_import` of a file outside the project, and
  anything the person's own ask rules name.

A card that asks is the person's to answer. Destructive means the person's work can go: before such a call, say
what it will do, and prefer asking them in words first when they did not ask for it.

## A quick prompt's target

The person may ask from where they are working with `Mod+K` -- a one-line box over the scene, the Assets panel, the
Model tab or the Code card. Such a message's context says first what it is about: "This prompt is about entity 38
"big crate", prefab crates/big …", "… the asset src/assets/prefabs/crates/big.prefab (its key "crates/big")", "… the
part "lid" of the model AssetsSource/models/props/crate.lua", "… src/game/systems/hop.ts, line 42". That is what
"this", "it" and "here" mean: the entities by their ids (refs for `scene_entity` and `scene_set`), the asset by its path
and key (`asset_info`), the parts by their `emit{name=…}` names (`model_info`), the file and line (Read it). The
selection is said as well; when the two differ, the target is what the words are about. Read before acting, as ever.

The same first line comes from **Ask Claude about this…** in the entity menu (the entities), **Fix with Claude** on a Problems row
("… a problem (tsc TS2322) at src/game/systems/hop.ts:42:7: "…""; read the file there, fix it, and `problems_list` says
whether it is gone) and **Explain** on a Console line ("… this line of the server log: "…""; `console_read` has the
lines around it). Their words in the box -- "Fix this", "Explain this" -- are the person's to change; the target is
what they mean.

## What the editor shows: every message, and `studio_context`

Each message from the person begins with what the editor shows as they send it: "The editor shows: Sandbox, in a
playtest paused (the editor over its world), scene "camp" (unsaved, kept in the browser). Tool up: Studio." -- then
the selection's first eight, and each tab's own facts: the Code card's file with the caret's line and column and the
text selected there ("Studio tool: Code card file src/game/systems/spin.ts, line 12, column 5 (changes not saved);
selected there "pos.x[e] += dt"; problems (2) …"), the Problems' first five, the Assets panel's folder and files
chosen, the Model tab's model, build and parts selected. "This file", "this line", "the selected code" mean those.

**`studio_context`** answers the same words now -- the same facts, gathered whole -- and a line saying `view_shot` is
the picture. Read it again mid-turn when the person may have moved on, and before acting on "this" long after the
message came.

**Claude in a terminal.** The person may continue a conversation in the `claude` CLI -- in a terminal drawn in Claude's
column, or their own -- and come back to the column. Everything here holds there too: the same studio tools, each
message's head (added by the run's hook as context), the same permissions (the CLI asks where the column would ask; what asks
the person in the studio every time -- a program to run, a download, an import from outside the project -- is refused
there: ask them to do it in the column). There is no Undo this turn in the terminal: your world steps are still `Z`'s.
Back in the column, the terminal's turns are in the conversation. A conversation left in the column's terminal when the
dev server or the app restarted comes back in the terminal by itself as the person shows it: the same session resumed.
Your turn's end, its failure and a permission prompt there are told to the studio by the run's hooks, so the person's
tab says so as it does for the column; they print nothing and change nothing of yours.

**When a turn ends** where the person is not looking -- another conversation's tab shown, the column hidden, the window
in the background -- the conversation's tab gets a dot (the accent when done, the warning colour when a card or the
terminal waits on them, the danger colour when it failed) and the top bar's AI button the strongest of those. There is
nothing to call for it: end a turn with what the person needs to read first.

## What the person sees of you besides

The person's prompt box takes slash commands. Your own and the project's (`/compact`, a skill) come to you as the
prompt they are; four are the column's and never reach you: `/usage` (the plan's limits, this conversation's cost and
tokens, the context window -- theirs to watch), `/clear`, `/agents` (a strip listing your subagents and background
tasks: each `Agent` call's type and description, its calls and tokens, what it did last -- so give each a description
that says what it is for), and `/btw <question>`, a side question answered by a copy of this conversation with no
tools, one reply, while you work on. That copy is you without your tools: answer briefly from what you know, and say
so if the answer needs a look you cannot take there. Nothing of it is added to this conversation.

## Looking: images

`view_shot` draws a view as an image without moving the person's view ([play and view](play.md)): `target`
`'scene'` (the default, the editor's scene view), `'camera'` with `camera` (a camera entity's ref or path: what it
sees), `'main'` (the game's own view) or `'model'` (the Model tab). About 1024 pixels wide by default, at most 2048
on the long side; WebP unless `format: 'png'` is asked. It is refused while the WebGL context is lost (look again once it is
back). `asset_thumb` is a file's thumbnail, `model_preview` a model built at other values. Look when the look
matters -- a placement, a colour, a camera -- not after every edit. The game is drawn in the scene's room between the
cards, its frame: `game_view_state` reads it, Maximize on Play and the preview presets (16:9, 320×180 Pixel...),
`game_view_set` chooses a preset, the Game look and Maximize on Play, `game_view_preset` makes the project's own
([play and view](play.md)); `view_shot` crops to the frame, a preset's box when one applies.

## Finding a tool

A few tools are always loaded: `studio_state`, `studio_context`, `scene_query`, `scene_entity`, `scene_set`, `scene_create`,
`batch`, `asset_list`, `asset_info`, `asset_new`, `asset_move`, `play_state`, `view_shot`, `problems_list`,
`tests_run`, `model_info`. The rest are deferred: find them with the tool search -- by words (`asset trash`,
`git commit`) or by name (`select:mcp__studio__asset_delete`) -- and they load. Each page's covers are the tools
it is about. The project's own tools are `project_<name>` (the pages beside its tools, in this skill too).

## A job, end to end

"Make the crates in the camp scene a bit bigger and show me."

1. `studio_state` -- the Scene tab, `forest/camp` open and saved, no playtest, nothing selected.
2. `scene_query` with `prefab: 'crates/big'` -- three instances, refs 7, 9 and 12.
3. `scene_entity` on 7, 9 and 12 (`scene_query` gives no values) -- `Transform` `sx`, `sy`, `sz` 1 on 7 and 12,
   1.2 on 9: "a bit bigger" is each one's own scale × 1.25.
4. `batch` with three `scene_set` calls (`component: 'Transform'`, `field: 'sx'`, then `sy`, `sz`, each
   `entities: [7, 9, 12]`, `value: [1.25, 1.5, 1.25]` and `was: [1, 1.2, 1]`, what was read) -- one step,
   "Claude: 3 edits". Had the person changed one meanwhile, that call writes nothing and its result in the
   batch's says `changed` with the values now (the other calls still land): read again and decide.
5. `view_shot` -- look at it. Too big? `history_undo` (it is your step) and try again.
6. Say what changed, that one `Z` takes it back, and that the scene is not saved yet -- `scene_save` when they
   want it kept.

## Rules that bite

- Read before you act; read again after a refusal or a time-out, never repeat a write blind.
- The person's selection is theirs: tools name what they act on, and only `scene_select` moves it.
- No tool saves for you: a scene is written by `scene_save`, a prefab open to edit by `scene_save` too (staying in
  it) or `scene_close_prefab` with `save: true` (going back).
- Never the person's steps without their word (`any: true`); never a destructive call they did not ask for.
- What a tool cannot do, say so -- do not reach the same end around the editor's back.
