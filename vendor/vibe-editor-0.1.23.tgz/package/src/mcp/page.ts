/**
 * The studio's page tools, the editor's half (Docs/mcp.md §3; Docs/agent.md §8 for the eight's history): a call the
 * dev server relays to this tab -- the turn's, or the last studio tab to say hello -- run against the world by its
 * area's handler, and its answer, facts the server words. Pure over the host's handle (`PageHost`), so node tests it
 * against a world.
 *
 * - **Handlers by name, one module per area** (`HANDLERS`): `studio.ts` (`studio_state`), `scene.ts` (`scene_describe`,
 *   `scene_set`, `scene_create`, `scene_override`, `scene_save_prefab`, `scene_save`), `prefab.ts` (`prefab_info`);
 *   what they share is `facts.ts`', what they stand on `host.ts`'. A tool the page has no handler for is refused.
 * - **While a playtest runs** (not paused: a paused one's world is the editor's) only `IN_PLAYTEST` answers; any other
 *   is `away`, which the server words (`words.ts`' `PLAYTEST`). No tab at all is the server's own `gone`.
 * - **Held while an Apply lands** (`hold.ts`): each tool that changes the world waits for it (`WAITS`), then runs as
 *   a new step -- which drops what the person undid from redo, said in its answer (`dropped`); `holding` is what Undo
 *   this turn is refused whole with meanwhile. **Never begun late**: one whose relay stopped waiting (`expires`, the
 *   tool's deadline) before it could begin is refused, nothing changed -- the agent was told `timeout`. Every tool
 *   that waits has at least a minute (`COMPILE_MS`), over the page's own compile waits (a few seconds each).
 * - **Its edits are kept as values, by call and by turn** (`AgentEdit`: the field, and each entity's value before
 *   and after), for the transcript: a row's Undo is the editor's undo of that step while it is on top (`stepOf`,
 *   `undo`); the result's Undo this turn walks the world's history back to where the first step of the turn -- and
 *   of the turns after it, as rewinding files puts those back too -- went on, if every step above that point is the
 *   agent's, else it says why it cannot (`turnSteps`, `undoTurn`).
 * - **A reload keeps the values, not the steps** (`carry`, into the resume record; the undo stack starts afresh): an
 *   edit from before one has no Undo of its own, and Undo this turn puts its `was` back by value -- one new step,
 *   "Undo Claude's edits (turn …)", which `Z` undoes and `Y` does again -- wherever the field still holds the agent's
 *   value; one changed since is left as it is, and said. That step, on top as the page goes, is carried too.
 * - **Gone**: history let go of a step -- another scene loaded, the game ran, the oldest past what it keeps -- and
 *   its edit is gone, kept and said with why (`turnSteps`' `gone`): its values mean nothing in the world now.
 */
import { BATCHED_TOOLS, PROJECT_PREFIX, type EditorResult, type McpAnswerRequest, type McpCall, type PageToolName, type ProjectToolResult } from '@vibe/pipeline/agent-types';
import { type Component, type Entity, type EntityRef, fieldValue, Hierarchy, label, NONE, Transform, type World } from '@vibe/engine';
import type { Step } from '../history.ts';
import { PENDING } from '../world-steps.ts';
import { no, Refusal, stepPrefix } from './facts.ts';
import type { CarriedEdit, EditorCarry, KeptEdit, PageContext, PageHandler, PageHost } from './host.ts';
import { sceneComponent, sceneCopy, sceneDestroy, sceneDuplicate, sceneEntity, sceneFlags, sceneMainCamera, scenePaste, sceneQuery, sceneRelate, sceneRename, sceneReparent, sceneSelect, sceneUnrelate } from './entities.ts';
import { prefabInfo } from './prefab.ts';
import { sceneCreate, sceneDescribe, sceneOverride, sceneSave, sceneSavePrefab, sceneSet } from './scene.ts';
import { sceneClosePrefab, sceneImport, sceneNew, sceneOpen, sceneOpenPrefab, sceneSaveAs, sceneStart } from './scenes.ts';
import { studioContext, studioState } from './studio.ts';
import { assetCopy, assetDelete, assetExport, assetMove, assetNew, assetOptions, assetRestore, materialSetTool, modelAdopt, NoPanel, physmatSetTool, prefabEdit } from './assets.ts';
import { gameViewPreset, gameViewSet, gameViewState, historyList, historyRedo, historyUndo, playPause, playStart, playState, playStep, playStop, viewFocus, viewGet, viewSet, viewShot } from './play.ts';
import { sceneListInsert, sceneListMove, sceneListRemove } from './data.ts';
import { physicsFit, physicsOverlap, physicsRaycast, physicsSettingsSet, physicsState } from './physics.ts';
import { modelExport, modelInfo, modelMaterialsSet, modelOpen, modelParamsSet, modelPose, modelPreview } from './model.ts';

export type { AgentEdit, CarriedEdit, EditorCarry, PageHost } from './host.ts';
export { entityFacts, refOrKey, SELECTION_MAX, ROOTS_MAX, STEP_PREFIX, stepPrefix, summarise } from './facts.ts';

/** Each page tool's handler, by name: one module per area. */
const HANDLERS: Record<PageToolName, PageHandler> = {
  studio_state: studioState,
  studio_context: studioContext,
  scene_describe: sceneDescribe,
  prefab_info: prefabInfo,
  scene_set: sceneSet,
  scene_create: sceneCreate,
  scene_override: sceneOverride,
  scene_save_prefab: sceneSavePrefab,
  scene_save: sceneSave,
  scene_query: sceneQuery,
  scene_entity: sceneEntity,
  scene_destroy: sceneDestroy,
  scene_duplicate: sceneDuplicate,
  scene_reparent: sceneReparent,
  scene_rename: sceneRename,
  scene_component: sceneComponent,
  scene_flags: sceneFlags,
  scene_relate: sceneRelate,
  scene_unrelate: sceneUnrelate,
  scene_list_insert: sceneListInsert,
  scene_list_remove: sceneListRemove,
  scene_list_move: sceneListMove,
  scene_main_camera: sceneMainCamera,
  scene_select: sceneSelect,
  scene_copy: sceneCopy,
  scene_paste: scenePaste,
  // Its own, below: it runs the others.
  batch: () => no('batch runs in the dispatcher'),
  scene_open_prefab: sceneOpenPrefab,
  scene_close_prefab: sceneClosePrefab,
  scene_open: sceneOpen,
  scene_new: sceneNew,
  scene_save_as: sceneSaveAs,
  scene_start: sceneStart,
  scene_import: sceneImport,
  asset_new: assetNew,
  asset_move: assetMove,
  asset_copy: assetCopy,
  asset_delete: assetDelete,
  asset_restore: assetRestore,
  asset_options: assetOptions,
  material_set: materialSetTool,
  physmat_set: physmatSetTool,
  prefab_edit: prefabEdit,
  asset_export: assetExport,
  play_state: playState,
  play_start: playStart,
  play_pause: playPause,
  play_step: playStep,
  play_stop: playStop,
  view_shot: viewShot,
  view_get: viewGet,
  view_set: viewSet,
  view_focus: viewFocus,
  game_view_state: gameViewState,
  game_view_set: gameViewSet,
  game_view_preset: gameViewPreset,
  physics_state: physicsState,
  physics_settings_set: physicsSettingsSet,
  physics_raycast: physicsRaycast,
  physics_overlap: physicsOverlap,
  physics_fit: physicsFit,
  history_list: historyList,
  history_undo: historyUndo,
  history_redo: historyRedo,
  model_open: modelOpen,
  model_info: modelInfo,
  model_params_set: modelParamsSet,
  model_preview: modelPreview,
  model_export: modelExport,
  model_materials_set: modelMaterialsSet,
  model_pose: modelPose,
  model_adopt: modelAdopt,
};

/**
 * What a page tool may do with a playtest running: read what is open -- and change the project's files through the
 * Assets panel, whose history is its own, not the world's (Docs/mcp.md M3) -- and drive the playtest itself, look,
 * and move the view, which is no edit of the world (M4). Never undo or redo: the world is the game's then.
 */
const IN_PLAYTEST: ReadonlySet<string> = new Set([
  'studio_state', 'studio_context', 'asset_new', 'asset_move', 'asset_copy', 'asset_delete', 'asset_restore', 'asset_options', 'material_set', 'physmat_set', 'prefab_edit', 'asset_export', 'model_adopt',
  'play_state', 'play_start', 'play_pause', 'play_step', 'play_stop', 'view_shot', 'view_get', 'view_set', 'view_focus', 'game_view_state', 'game_view_set', 'game_view_preset', 'history_list',
  // Physics read as it runs, and its file -- whose writes refuse themselves while a playtest is on.
  'physics_state', 'physics_settings_set', 'physics_raycast', 'physics_overlap',
]);

/**
 * What a `batch` may run (Docs/mcp.md §4): the world's own edits, each done at once -- never one that waits on a
 * file or a compile (Save, Apply, Save as prefab), loads another world (a scene, a prefab opened) or is no edit.
 */
export const BATCHED: ReadonlySet<string> = new Set(BATCHED_TOOLS);

/** Calls in one batch, at most. */
export const BATCH_MAX = 64;

/** `"$0"`: entry 0's made entity (its ref), in a later entry's arguments where they name an entity. */
const MADE = /^\$(\d+)$/;

/** The arguments that name entities, where `"$n"` is read: never a name, a label or any other text. */
const NAMING: readonly string[] = ['entity', 'entities', 'parent', 'before', 'target'];

/**
 * The tools that change the world, or save it: while an Apply's undo or redo
 * lands (`OverrideSteps.holding`), each waits for it, then runs -- a new step,
 * which drops the undone Apply from redo, as any step made after an undo does:
 * said in its answer (`dropped`). Chosen over running it before the undo,
 * which by then is under way: the person's Z came first.
 */
const WAITS: ReadonlySet<string> = new Set([
  'scene_set', 'scene_create', 'scene_override', 'scene_save', 'scene_save_prefab', ...BATCHED, 'batch', 'scene_select', 'scene_paste',
  'scene_open_prefab', 'scene_close_prefab', 'scene_open', 'scene_new', 'scene_save_as', 'scene_start', 'scene_import',
  // M4: a playtest begun, stepped or stopped loads or runs the world; Z and Y move it.
  'play_start', 'play_step', 'play_stop', 'history_undo', 'history_redo',
  'physics_fit',
]);

/** Edits kept, and carried across a reload, at most: the newest. */
export const EDITS_MAX = 200;

/** A carry as the resume record kept it, read: null for none, or anything odd; an edit that is odd left out. */
export function readCarry(raw: unknown): EditorCarry | null {
  if (typeof raw !== 'object' || raw === null || !Array.isArray((raw as { edits?: unknown }).edits)) return null;
  const r = raw as { edits: unknown[]; top?: unknown };
  const num = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
  const text = (v: unknown): string | null => (typeof v === 'string' ? v : null);
  const edits: CarriedEdit[] = [];
  /** Each kept edit's place, by its place in the record: the top's indices follow. */
  const moved = new Map<number, number>();
  r.edits.forEach((value, i) => {
    const e = value as Partial<Record<keyof CarriedEdit, unknown>> | null;
    if (typeof e !== 'object' || e === null || typeof e.component !== 'string' || typeof e.field !== 'string' || !Array.isArray(e.written)) return;
    const written = (e.written as unknown[]).flatMap((w) => {
      const x = w as Record<string, unknown> | null;
      const value = (v: unknown): v is number | string => num(v) || typeof v === 'string';
      return x && num(x.id) && num(x.ref) && value(x.was) && value(x.now) ? [{ id: x.id, ref: x.ref, was: x.was, now: x.now }] : [];
    });
    if (written.length === 0) return;
    moved.set(i, edits.length);
    edits.push({ turn: text(e.turn), use: text(e.use), component: e.component, field: e.field, written, undone: e.undone === true, gone: text(e.gone) });
  });
  const t = r.top as { label?: unknown; edits?: unknown; done?: unknown } | null | undefined;
  const indices = t && Array.isArray(t.edits) ? t.edits.flatMap((i) => (num(i) && moved.has(i) ? [moved.get(i)!] : [])) : [];
  const top = t && typeof t.label === 'string' && indices.length > 0 ? { label: t.label, edits: indices, done: t.done === true } : null;
  return { edits, top };
}

/**
 * Where a row's step is now: on top (Undo takes it), under a later step,
 * undone, gone from history, from before the page reloaded (`before`: Undo
 * this turn puts it back) -- or none of this tab's.
 */
export type StepState = 'top' | 'under' | 'undone' | 'gone' | 'before' | null;

/**
 * What Undo this turn would do to the editor: this turn's edits and the
 * later turns', walked back on the undo stack (`count`) or put back by value
 * (`values`, from before a reload) -- or why it cannot.
 */
export interface TurnSteps {
  /** This turn's edits made in this tab. */
  own: number;
  /** The agent's steps the walk takes back on the editor's undo stack. */
  count: number;
  /** Edits from before a reload put back by value, as one new step. */
  values: number;
  /** Of `count` and `values`, the turns' after it. */
  later: number;
  /** Fields from before a reload changed since, which stay as they are: "Transform.sy on big crate". */
  left: string[];
  /** Of `own`, how many are gone from the undo stack -- all of them, or some: the rest are undone without them. */
  lost: number;
  /** Why the first of those went: "another scene was loaded"; null with none gone. */
  gone: string | null;
  /** Why the editor's part cannot be done, in words that agree with `own`; null if it can (or there is nothing but `gone`). */
  why: string | null;
}

export interface PageTools {
  /** A call relayed from the dev server, run now: the answer for `POST mcp/answer` -- later, for an Apply, once its file is compiled. */
  run(call: McpCall): McpAnswerRequest | Promise<McpAnswerRequest>;
  /** A row's step, by its call's `tool_use` id. */
  stepOf(use: string): StepState;
  /** The editor's undo of a row's step, if it is on top: null if done, else why not. */
  undo(use: string): string | null;
  /** What Undo this turn would do to the editor; null where this tab made no edit in it. */
  turnSteps(turn: string): TurnSteps | null;
  /**
   * The turn's edits undone, and the later turns': the steps walked back, then
   * those from before a reload put back by value as one step called `label`.
   * How many, and the fields left as changed since -- or why not.
   */
  undoTurn(turn: string, label?: string): { undone: number; left: string[] } | { error: string };
  /** Why nothing may be undone just now -- an Apply, its undo or its redo landing -- or null: Undo this turn is refused whole then, its files too. */
  holding(): string | null;
  /** The edits as values, and Undo this turn's step on top: for the resume record, a reload keeping no steps. */
  carry(): EditorCarry;
  /** History moved, or a step was made: a row's state may have changed. Returns the undo. */
  on(listener: () => void): () => void;
  dispose(): void;
}

/**
 * A field of an entity Undo this turn puts back by value: the agent's last value there, and the one before its first --
 * as the column holds them in this session (a key's text interned again: `valuesOf`), for `valueStep` and `plan`.
 */
interface Value {
  id: Entity;
  ref: EntityRef;
  component: Component;
  field: string;
  now: number;
  was: number;
  edits: KeptEdit[];
}

export function createPageTools(host: PageHost, carried: EditorCarry | null = null): PageTools {
  const { world, history, worldSteps } = host;
  /** The opened prefab's own instance, whose overrides are its file's edits: none said of it. */
  const opened = (w: World, e: Entity): boolean => {
    const key = host.opened?.() ?? null;
    const root = w.instanceRoot(e);
    return key !== null && w.prefabOf(root)?.key === key && (w.rawStore(Hierarchy) as { parent: ArrayLike<number> }).parent[root] === NONE;
  };
  /** Every edit, in the order made: the newest `EDITS_MAX`. */
  const edits: KeptEdit[] = [];
  /** Each by its call's `tool_use` id: the row's. */
  const byUse = new Map<string, KeptEdit>();
  /** Undo this turn's steps by value, and the edits each puts back. */
  const valueSteps = new Map<Step, KeptEdit[]>();
  const listeners = new Set<() => void>();
  const tell = (): void => {
    for (const listener of listeners) listener();
  };
  /** Making it again from a carry: the world is as it was left, nothing to draw. */
  let quiet = false;

  function keep(edit: KeptEdit): void {
    // Its turn on the step itself, wherever the step was made (a call's, a batch's, Save as prefab's, an override's,
    // a playtest's kept edits): the History card groups a turn's steps (Docs/ai-panel.md D8).
    if (edit.step && edit.turn !== null) edit.step.turn = edit.turn;
    edits.push(edit);
    if (edit.use !== null) byUse.set(edit.use, edit);
    while (edits.length > EDITS_MAX) {
      const old = edits.shift()!;
      if (old.use !== null && byUse.get(old.use) === old) byUse.delete(old.use);
    }
  }

  /** History moved: each edit's step read again; one it let go of is undone (its redo dropped) or gone (trimmed, or the stack begun again). */
  const off = history.on((event) => {
    // The opened-prefab mode's own history: the world's steps put aside, not gone -- read again once taken back.
    if (history.aside > 0) return;
    if (event === 'reset') {
      const why = host.resetWhy();
      for (const e of edits) {
        if (e.gone === null) e.gone = why;
        e.step = null;
      }
      valueSteps.clear();
    } else {
      const steps = history.steps;
      const done = history.done;
      for (const e of edits) {
        if (e.step === null) continue;
        const at = steps.indexOf(e.step);
        if (at >= 0) {
          e.done = at < done;
          continue;
        }
        // A world kept as a step is megabytes: let go of here too.
        if (e.done) e.gone = 'older than the steps the editor keeps';
        else e.undone = true;
        e.step = null;
      }
      for (const step of [...valueSteps.keys()]) if (!steps.includes(step)) valueSteps.delete(step);
    }
    tell();
  });

  /** Inside a `batch`: the steps its calls would make, put off to its one. */
  let batching = false;

  /** A call's edit done: flushed, one step -- or, inside a batch, none yet -- kept for the transcript. */
  function step(call: McpCall, label: string, values?: Pick<KeptEdit, 'component' | 'field' | 'written'>): string | null {
    world.flush();
    if (batching) return label;
    const full = `${stepPrefix(call)}${label}`;
    if (!worldSteps.commit(full)) return null;
    keep({ turn: call.turn, use: call.use, component: values?.component ?? '', field: values?.field ?? '', written: values?.written ?? [], step: history.steps[history.done - 1]!, done: true, undone: false, gone: null });
    return full;
  }

  /** What each area's handlers are given. */
  const ctx: PageContext = {
    host, world, history, worldSteps, keep, tell, opened, step,
    get batching() {
      return batching;
    },
  };

  /** Entry `i`'s arguments, each `"$n"` the entity entry `n` made (its ref). */
  function resolveMade(tool: string, args: Record<string, unknown>, made: readonly (number | null)[], i: number): Record<string, unknown> {
    const one = (value: unknown): unknown => {
      if (typeof value !== 'string') return value;
      const m = MADE.exec(value);
      if (!m) return value;
      const n = Number(m[1]);
      if (n >= i) return no(`entry ${i}: ${value} names entry ${n}, which is not before it`);
      if (made[n] == null) return no(`entry ${i}: ${value} names entry ${n}, which made no entity`);
      return made[n];
    };
    const each = (value: unknown): unknown => (Array.isArray(value) ? value.map(one) : one(value));
    const out = { ...args };
    for (const key of NAMING) if (key in out) out[key] = each(out[key]);
    // scene_set's value (and was) name an entity only on a ref() field: a Name, a key or a number is its own text.
    if (tool === 'scene_set') {
      const c = world.allComponents.find((x) => x.name === args.component);
      if (c?.kind === 'data' && (c.schema as Record<string, { ref?: true } | undefined>)[String(args.field)]?.ref) {
        for (const key of ['value', 'values', 'was']) if (key in out) out[key] = each(out[key]);
      }
    }
    return out;
  }

  /**
   * `batch`: its calls run in order as one step on the undo stack (`Claude: N edits`); a later call may name an entity
   * an earlier one made as `"$<n>"`. One that fails puts the world back as it was before the first -- no step, nothing
   * changed -- and the answer says which failed and why.
   */
  function batch(call: McpCall): EditorResult {
    const calls = call.args.calls;
    if (!Array.isArray(calls) || calls.length === 0) return no('calls is a list of { tool, args }: at least one');
    if (calls.length > BATCH_MAX) return no(`calls: at most ${BATCH_MAX} in one batch`);
    worldSteps.commit(PENDING);
    const results: EditorResult[] = [];
    const made: (number | null)[] = [];
    const labels: string[] = [];
    batching = true;
    try {
      calls.forEach((entry: unknown, i) => {
        const { tool, args } = (entry ?? {}) as { tool?: unknown; args?: unknown };
        if (typeof tool !== 'string' || !BATCHED.has(tool)) return no(`entry ${i}: ${String(tool)} is not one a batch runs -- it runs ${[...BATCHED].join(', ')}`);
        try {
          const given = args === undefined ? {} : args;
          if (typeof given !== 'object' || given === null || Array.isArray(given)) return no('args is an object');
          const inner: McpCall = { ...call, tool: tool as PageToolName, args: resolveMade(tool, given as Record<string, unknown>, made, i) };
          const done = HANDLERS[tool as PageToolName](ctx, inner);
          if (done instanceof Promise) return no('it would wait, which a batch does not');
          results.push(done);
          made.push('ref' in done && typeof done.ref === 'number' ? done.ref : 'copy' in done ? done.copy.ref : null);
          if ('step' in done && typeof done.step === 'string') labels.push(done.step);
        } catch (err) {
          throw new Refusal(`entry ${i} (${tool}) failed: ${err instanceof Error ? err.message : String(err)}`);
        }
      });
    } catch (err) {
      batching = false;
      // Every call before it undone: the world as it was, no step.
      worldSteps.revert();
      host.changed();
      tell();
      const done = results.length;
      throw new Refusal(`${err instanceof Error ? err.message : String(err)}. ${done === 0 ? 'Nothing was done' : `The ${done === 1 ? 'one' : done} before it ${done === 1 ? 'was' : 'were'} undone`}: the scene is as it was.`);
    }
    batching = false;
    const label = labels.length === 1 ? labels[0]! : `${calls.length} edits`;
    const committed = step(call, label);
    host.changed();
    tell();
    return { tool: 'batch', results, step: committed };
  }

  /**
   * A call that changes the world, run: an Apply's undo or redo landing would
   * load its world over an edit made now, so it waits for that first. A step
   * it makes after the person's undo drops what was undone from redo, as any
   * new step does: its answer says which (`dropped`).
   */
  function result(call: McpCall): EditorResult | Promise<EditorResult> {
    if (call.tool.startsWith(PROJECT_PREFIX)) return project(call);
    const handler = Object.hasOwn(HANDLERS, call.tool) ? HANDLERS[call.tool as PageToolName] : undefined;
    if (!handler) return no(`The studio has no page tool called ${String(call.tool)}`);
    if (!WAITS.has(call.tool)) return handler(ctx, call as McpCall & { tool: PageToolName });
    if (host.overrides?.holding()) return host.overrides.idle().then(() => result(call));
    // Its time ran out before it could begin -- the agent was told `timeout`, and may try again: never begun late.
    if (call.expires !== undefined && (host.now?.() ?? Date.now()) > call.expires) {
      return no(`Not done: ${call.tool} could not begin before its time ran out (the editor was busy -- an Apply landing), so Claude was told it timed out. Nothing was changed.`);
    }
    const redo = history.redoLabel;
    const mark = (r: EditorResult): EditorResult => (redo !== null && history.redoLabel !== redo && 'step' in r ? { ...r, dropped: redo } : r);
    const done = call.tool === 'batch' ? batch(call) : handler(ctx, call as McpCall & { tool: PageToolName });
    return done instanceof Promise ? done.then(mark) : mark(done);
  }

  /**
   * A project's own tool (`project_<name>`, Docs/mcp.md M7): its `run` over the world, its edits one step -- `Claude:
   * <its step>`, an outside client's `MCP: …` -- as a built-in's are; one that names no step but changed the world, a step
   * under its name; one declared `readOnly`, nothing kept. It waits for an Apply landing, never begins late,
   * and a throw puts the world back as it was: its message is the tool's error. Its answer is its own shape
   * (`ProjectToolResult`), which the server words.
   *
   * **A `run` awaited is not alone with the world**: the person may edit while it is. What they had under way is a
   * step of their own before it begins, and one they commit meanwhile is their own step too -- but world steps are the
   * whole world, so a change made while it was awaited cannot be told apart from the person's (a mark taken just
   * before the await says only that something changed). So nothing is put back that may be the person's: a throw or a
   * `readOnly` tool's writes are put back only when nothing changed while it was awaited and the person made no step
   * meanwhile; else what changed is kept, a step under the tool's name (Z takes it back), and its words say so.
   */
  async function project(call: McpCall): Promise<EditorResult> {
    const name = call.tool.slice(PROJECT_PREFIX.length);
    const tool = host.project?.().find((t) => t.name === name);
    if (!tool) return no(`The project declares no tool called ${name} in this tab (src/tools/ mcpTools) -- a page reloaded since may know it`);
    if (host.overrides?.holding()) await host.overrides.idle();
    if (call.expires !== undefined && (host.now?.() ?? Date.now()) > call.expires) {
      return no(`Not done: ${name} could not begin before its time ran out (the editor was busy -- an Apply landing). Nothing was changed.`);
    }
    // What the person typed and did not commit is a step of its own first, as before any built-in's edit.
    worldSteps.commit(PENDING);
    /** Something changed while `run` was awaited, or the person made, undid or redid a step meanwhile: not told apart. */
    let shared = false;
    let answer: Awaited<ReturnType<typeof tool.run>>;
    try {
      const ran = tool.run({ world, selection: host.selection() }, call.args);
      if (ran instanceof Promise) {
        const moved = worldSteps.mark();
        const off = history.on((event) => {
          if (event === 'push' || event === 'undo' || event === 'redo' || event === 'reset') shared = true;
        });
        try {
          answer = await ran;
        } finally {
          off();
          if (moved()) shared = true;
        }
      } else {
        answer = ran;
      }
    } catch (err) {
      const why = err instanceof Error ? err.message : String(err);
      world.flush();
      if (shared && worldSteps.drifted()) {
        const kept = step(call, name);
        host.changed();
        tell();
        throw new Refusal(`${name} refused: ${why} -- what changed while it ran cannot be told apart from edits made in the editor meanwhile, so it was kept as a step${kept === null ? '' : ` (${kept})`}, which Z takes back`);
      }
      worldSteps.revert();
      host.changed();
      throw new Refusal(`${name} refused: ${why} -- nothing was changed`);
    }
    // Its annotations are what the gate trusted (Docs/packages.md §10), so they are kept honest here. Read-only: let in
    // as a read, so whatever it changed is put back and its step ignored -- unless that may be the person's too. Else its
    // step -- or, changing the world with none named, its own name: never left pending, to fold into the person's next step.
    world.flush();
    let words = String(answer.words ?? '');
    let made: string | null = null;
    if (tool.annotations?.readOnly === true) {
      if (worldSteps.drifted()) {
        if (shared) {
          made = step(call, name);
          words += `${words === '' ? '' : ' '}(${name} is declared read-only, but the world changed while it ran and that cannot be told apart from edits made in the editor meanwhile: kept as a step${made === null ? '' : `, ${made}`}, which Z takes back)`;
        } else {
          worldSteps.revert();
          words += `${words === '' ? '' : ' '}(${name} is declared read-only: what it changed in the world was put back)`;
        }
      }
    } else {
      made = step(call, typeof answer.step === 'string' && answer.step !== '' ? answer.step : name);
    }
    host.changed();
    tell();
    const out: ProjectToolResult = { tool: 'project', name, words, json: answer.json ?? null, step: made };
    return out as unknown as EditorResult;
  }

  // ---------------------------------------------------------------- the steps, for the transcript

  function stepOf(use: string): StepState {
    const e = byUse.get(use);
    if (!e) return null;
    if (e.gone !== null) return 'gone';
    if (e.step === null) return e.undone ? 'undone' : 'before';
    const at = history.steps.indexOf(e.step);
    if (at < 0) return 'gone';
    return at >= history.done ? 'undone' : at === history.done - 1 ? 'top' : 'under';
  }

  /** An entity as a person reads it: its name, else its prefab and id. */
  const whom = (e: Entity): string => (world.alive(e) ? label(world, e) : `entity ${e}`);

  /**
   * Each field the edits wrote, as Undo this turn puts it back by value: the
   * agent's last value there and the value before its first -- newest first,
   * so a field written twice goes back to before both.
   */
  function valuesOf(list: readonly KeptEdit[]): Value[] {
    const out = new Map<string, Value>();
    for (let n = list.length - 1; n >= 0; n--) {
      const e = list[n]!;
      const found = world.allComponents.find((c) => c.name === e.component);
      if (found?.kind !== 'data') continue;
      const component = found as Component;
      /** As the column holds it now: a key's text interned in this session (`fieldValue`), a number as it is. */
      const held = (x: number | string): number => fieldValue(component, e.field, x) ?? NaN;
      for (const w of e.written) {
        const key = `${w.id}|${e.component}|${e.field}`;
        const v = out.get(key);
        if (v) {
          v.was = held(w.was);
          if (!v.edits.includes(e)) v.edits.push(e);
        } else out.set(key, { id: w.id as Entity, ref: w.ref as EntityRef, component, field: e.field, now: held(w.now), was: held(w.was), edits: [e] });
      }
    }
    return [...out.values()];
  }

  /** Is the entity the one written, alive, with the component. */
  const there = (v: Value): boolean => world.alive(v.id) && world.deref(v.ref) === v.id && world.has(v.id, v.component);
  const columnOf = (v: Value): { [i: number]: number } | undefined => (world.rawStore(v.component) as Record<string, { [i: number]: number }>)[v.field];

  /** Undo this turn's step for edits from before a reload: their `was` put back (redo), the agent's values again (undo). */
  function valueStep(label: string, values: readonly Value[]): Step {
    const covered = [...new Set(values.flatMap((v) => v.edits))];
    const write = (back: boolean): void => {
      for (const v of values) {
        const column = there(v) ? columnOf(v) : undefined;
        if (!column) continue;
        column[v.id] = back ? v.was : v.now;
        if (v.component === Transform) world.moved(v.id);
      }
      for (const e of covered) e.undone = back;
      if (!quiet) host.changed();
    };
    const step: Step = { label, size: 64 * values.length, undo: () => write(false), redo: () => write(true) };
    valueSteps.set(step, covered);
    return step;
  }

  /** What Undo this turn would do: the walk back, the values to put back, what stays, and why not. */
  function plan(turn: string): (TurnSteps & { walk: { count: number; edits: KeptEdit[] }; put: Value[] }) | null {
    // This turn's edits and the later turns' -- all made after its first, in order -- as rewinding files puts those back too.
    const first = edits.findIndex((e) => e.turn === turn);
    if (first < 0) return null;
    const all = edits.slice(first).filter((e) => e.turn !== null);
    const mine = all.filter((e) => e.turn === turn);
    const own = mine.length;
    const them = own === 1 ? 'it' : 'them';
    // Gone from the stack, all or some: said, with why; the rest are undone without them.
    const lost = mine.filter((e) => e.gone !== null).length;
    const gone = mine.find((e) => e.gone !== null)?.gone ?? null;
    let why: string | null = null;

    // The steps still on the stack: walked back, if every step above the first is the agent's.
    const live = all.filter((e) => e.step !== null && e.gone === null);
    const walk = { count: 0, edits: [] as KeptEdit[] };
    if (live.length > 0) {
      const steps = history.steps;
      const done = history.done;
      const at = live.map((e) => steps.indexOf(e.step!));
      if (at.some((i) => i >= done) && at.some((i) => i < done)) why = 'some of the agent\'s edits are undone already, some not: Z and Y in the editor';
      else if (at.some((i) => i < done)) {
        const from = Math.min(...at);
        const ours = new Set(edits.flatMap((e) => (e.step !== null ? [e.step] : [])));
        for (let i = from; i < done; i++) {
          if (ours.has(steps[i]!)) continue;
          why = `an edit of yours came after ${them} (${steps[i]!.label}): undo it first, or use the History card`;
          break;
        }
        if (why === null) {
          walk.count = done - from;
          walk.edits = live.filter((_, n) => at[n]! >= from);
        }
      }
    }

    // From before a reload: put back by value, where the field still holds the agent's value.
    const before = all.filter((e) => e.step === null && !e.undone && e.gone === null);
    const put: Value[] = [];
    const left: string[] = [];
    for (const v of valuesOf(before)) {
      const column = there(v) ? columnOf(v) : undefined;
      if (column !== undefined && Object.is(column[v.id], v.now)) put.push(v);
      else left.push(`${v.component.name}.${v.field} on ${whom(v.id)}`);
    }
    const values = new Set(put.flatMap((v) => v.edits)).size;
    const undone = [...walk.edits, ...new Set(put.flatMap((v) => v.edits))];
    if (why === null && walk.count + put.length === 0 && lost < own) {
      const rest = own - lost;
      why = left.length > 0 ? `${left.join(', ')} changed since` : `${rest === 1 ? 'it is' : 'they are'} undone already`;
    }
    return { own, count: walk.count, values, later: undone.filter((e) => e.turn !== turn).length, left, lost, gone, why, walk, put };
  }

  // Back from a reload: the edits as values, and Undo this turn's step on top -- on the fresh stack, so Z and Y still have it.
  if (carried) {
    quiet = true;
    for (const c of carried.edits) keep({ ...c, written: c.written.map((w) => ({ ...w })), step: null, done: false });
    const top = carried.top;
    const covered = top ? top.edits.flatMap((i) => (edits[i] ? [edits[i]!] : [])) : [];
    if (top && covered.length > 0) {
      const step = valueStep(top.label, valuesOf(covered));
      history.push(step);
      // Its edits as they were: the world is as the page left it, so undoing it writes what is there already.
      if (!top.done) history.undo();
      for (const e of covered) e.undone = top.done;
    }
    quiet = false;
  }

  return {
    run(call) {
      const id = call.id;
      const state = host.state();
      // A playtest running: the editor cannot act -- but what is open can still be read.
      if (state !== 'open' && !IN_PLAYTEST.has(call.tool)) return { id, away: state };
      // No Assets panel made here: `nopanel` -- refused before any step -- and the dev server runs the asset tool instead (D2).
      const failed = (err: unknown): McpAnswerRequest => (err instanceof NoPanel ? { id, away: 'nopanel' } : { id, error: err instanceof Refusal ? err.message : `The editor failed: ${err instanceof Error ? err.message : String(err)}` });
      try {
        const done = result(call);
        return done instanceof Promise ? done.then((r): McpAnswerRequest => ({ id, result: r }), failed) : { id, result: done };
      } catch (err) {
        return failed(err);
      }
    },
    stepOf,
    undo(use) {
      if (host.state() !== 'open') return 'The editor is not open -- a playtest runs: P pauses it, then Undo';
      // An Apply landing loads its world: a step undone under it would be loaded over (`hold.ts`).
      const held = host.overrides?.holding();
      if (held) return `Not now -- ${held}`;
      worldSteps.commit(PENDING);
      const state = stepOf(use);
      if (state !== 'top') {
        return state === 'undone' ? 'Undone already' : state === 'under' ? 'A later edit is on top: Z undoes that first' : state === 'before' ? 'From before the reload: Undo this turn puts it back' : 'No longer on the editor\'s undo stack';
      }
      host.undo(1);
      return null;
    },
    turnSteps(turn) {
      const p = plan(turn);
      return p && { own: p.own, count: p.count, values: p.values, later: p.later, left: p.left, lost: p.lost, gone: p.gone, why: p.why };
    },
    undoTurn(turn, label = 'Undo Claude\'s edits') {
      if (host.state() !== 'open') return { error: 'The editor is not open -- a playtest runs: P pauses it, then Undo this turn' };
      const held = host.overrides?.holding();
      if (held) return { error: `Not now -- ${held}` };
      worldSteps.commit(PENDING);
      const p = plan(turn);
      if (!p) return { undone: 0, left: [] };
      if (p.why !== null) return { error: p.why };
      if (p.walk.count > 0) host.undo(p.walk.count);
      if (p.put.length > 0) {
        // One step: Z puts the agent's values back, Y takes them away again.
        const step = valueStep(label, p.put);
        step.redo();
        history.push(step);
      }
      return { undone: p.walk.edits.length + p.values, left: p.left };
    },
    holding: () => host.overrides?.holding() ?? null,
    carry() {
      const steps = history.steps;
      const done = history.done;
      const out = edits.map((e): CarriedEdit => ({
        turn: e.turn,
        use: e.use,
        component: e.component,
        field: e.field,
        written: e.written.map((w) => ({ ...w })),
        // A step of this page's: undone while it is above the stack's top.
        undone: e.step !== null ? steps.indexOf(e.step) >= done : e.undone,
        gone: e.gone,
      }));
      let top: EditorCarry['top'] = null;
      for (const at of [done - 1, done]) {
        const covered = at >= 0 && at < steps.length ? valueSteps.get(steps[at]!) : undefined;
        if (!covered) continue;
        top = { label: steps[at]!.label, edits: covered.map((e) => edits.indexOf(e)).filter((i) => i >= 0).sort((a, b) => a - b), done: at === done - 1 };
        break;
      }
      return { edits: out, top };
    },
    on(listener) {
      listeners.add(listener);
      return () => void listeners.delete(listener);
    },
    dispose() {
      off();
      listeners.clear();
    },
  };
}
