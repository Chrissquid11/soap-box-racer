/**
 * What every action a person has in the editor says of Claude (Docs/skills.md §2 rule 7, §9 S2): the studio MCP tool
 * that does the same, or why there is none. A required argument or field at each place an action is made -- the
 * `button`, `iconButton` and `control` helpers (`dom.ts`, their first argument), a menu entry (`MenuItem.mcp`), a
 * tool's key (`ToolKey.mcp`, the Assets panel's `AssetsToolKey.mcp`), the editor's own keys (`editor.ts`' `addKey`),
 * a notice's action (`NoticeAction.mcp`) -- so the typecheck fails on one left out. A control made any other way (a
 * raw `el('button')`, a `MrDebug.add` in the editor or a tool folder) carries the same as a `// mcp: ...` comment,
 * which `vibe test`'s `mcp` check requires (`packages/pipeline/src/checks/mcp.ts`).
 *
 * - **A tool's name** (`'scene_save'`, `'play_start'`), typed against the catalogue's names -- or a project's own,
 *   `project_<name>` (its `mcpTools`, Docs/packages.md §10): Claude can do what the button does. Several, for a
 *   control that does one or another (a play button that also pauses).
 * - **`'ui'`**: the control changes only the editor's own view -- a fold, a sort, a filter, a tab or card switched, a
 *   menu or a dialog opened or closed, a preview's look, the Assets panel's selection, a copy to the clipboard, a file
 *   shown on the machine (Reveal, Download, Open in its application): nothing of the project, its files, its world or
 *   its history. A dialog's answer, and a sheet's choice before it sends (the import sheet's skip, folder, source or
 *   script tick, Same for all, a fix), is `'ui'`: the action that asked, or the one that sends, declares -- the sheet's
 *   Import and Retry are `asset_import`, whose inputs those choices are. Where a tool does even a view's work --
 *   the scene's selection (`scene_select`), the editor's camera (`view_set`, `view_focus`) -- the tool is named.
 * - **A none**: a person can do something here that no tool does. In the editor always an entry of `gaps.ts`, held
 *   so by the type -- `GAPS` (still to get a tool: none since S5) or `NOT_FOR_CLAUDE` (none by design: the person's own control of
 *   Claude, their drawing for it, the code Claude writes with its own Edit) -- each a line in Docs/skills.md §9: the
 *   entries are `as const`, so their texts are the only nones `Mcp` takes and an inline `{ none: '<why>' }` does not
 *   build. A project's own tool says its own why through `projectNone('<why>')` -- the one open none, branded so a bare
 *   literal is still refused -- which the `mcp` check refuses inside `@vibe/editor`.
 *
 * Node-safe: types, and `projectNone`.
 */
import type { ProjectToolName, ToolName } from '@vibe/pipeline/agent-types';
import type { GAPS, NOT_FOR_CLAUDE } from './gaps.ts';

/** A studio MCP tool by name: the catalogue's, or a project's own (`project_<name>`). */
export type McpTool = ToolName | ProjectToolName;

/** The editor's nones: an entry of `gaps.ts`, its text the literal there. */
export type Gap = (typeof GAPS)[keyof typeof GAPS] | (typeof NOT_FOR_CLAUDE)[keyof typeof NOT_FOR_CLAUDE];

declare const PROJECT_NONE: unique symbol;
/** A project tool's own none: its why in its words, made by `projectNone` alone. */
export interface ProjectNone {
  readonly none: string;
  readonly [PROJECT_NONE]: true;
}

/** A project's own tool's none (`examples/tools/tile-tool/`): what a person does there that no tool does, in words. Never in the editor (the `mcp` check). */
export const projectNone = (why: string): ProjectNone => ({ none: why }) as ProjectNone;

/** An editor action's declaration: the tool (or tools) that do the same, `'ui'`, or why none does. */
export type Mcp = McpTool | readonly McpTool[] | 'ui' | Gap | ProjectNone;
