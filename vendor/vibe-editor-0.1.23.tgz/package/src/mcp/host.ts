/**
 * What the studio's page tools stand on (Docs/mcp.md §3): the editor's handle (`PageHost`, which `editor.ts` hands
 * over), an edit as the tools keep it for the transcript (`AgentEdit`, carried across a reload as `EditorCarry`), and
 * what each area's handlers are given (`PageContext`). Types only.
 */
import type { Entity, World } from '@vibe/engine';
import type { McpCall, EditorResult, GameViewResult, ModelFacts, QueuedExport, TurnContext } from '@vibe/pipeline/agent-types';
import type { GamePreset, PresetAsk } from '../game-view.ts';
import type { EditorView } from '../camera-entity.ts';
import type { History, Step } from '../history.ts';
import type { OverrideSteps } from '../overrides-steps.ts';
import type { WorldSteps } from '../world-steps.ts';
import type { ProjectMcpTool } from '../tool.ts';
import type { PhysicsSettings } from '@vibe/engine';
import type { Bounds } from '../physics/fit.ts';
import type { PhysicsChange } from '../physics/settings-client.ts';

/** What the page tools need of the editor (`editor.ts` hands it over). */
export interface PageHost {
  readonly world: World;
  /** The project's own MCP tools (`ProjectMcpTool`, Docs/mcp.md M7): `project_<name>`'s calls run by these. None: none. */
  project?(): readonly ProjectMcpTool[];
  /** The world's undo stack -- never a tool's own. */
  readonly history: History;
  readonly worldSteps: WorldSteps;
  /** Open and editing, or a playtest running (the editor hidden under the game). Never closed: the page is the editor's. */
  state(): 'open' | 'playtest';
  /** The playtest as `studio_state` says it: none, running, or paused with the editor over its world. Left out, read from `state`. */
  playtest?(): 'none' | 'running' | 'paused';
  /** The editor's tab shown -- Scene, Config, Model, Studio … (a tool's name) -- or null. */
  tab?(): string | null;
  /** The selection, the first shown first. */
  selection(): readonly Entity[];
  /** The scene open -- its file's key (null: none yet), unsaved or not -- or null for the game's own world. */
  scene(): { name: string | null; unsaved: boolean } | null;
  /** What a column turn is told of the editor, whole (`agent/context.ts`, Docs/terminal.md D8): `studio_context`'s facts. None, and it is refused. */
  context?(): TurnContext;
  /** The time now, as `Date.now()` (a call's `expires` is read against it); left out, `Date.now`. A test's own. */
  now?(): number;
  /** The world was edited: drawn again, and every tool reads it again (`changed`). */
  changed(): void;
  /** Why the world's history last started again, asked as it does: "another scene was loaded", "the game ran since". */
  resetWhy(): string;
  /** Undo `n` steps of the world's history, as the History card does: read again once at the end. */
  undo(n: number): void;
  /** The Scenes page's Save: the scene's own file, or a new one named `name` -- written by the dev server, so answered later. */
  save(name: string | null): Promise<{ name: string; key: string } | { error: string }>;
  /** `e` selected, as a Spawn selects what it made. No tool calls it: a write never moves the selection (Docs/mcp.md §2 rule 5), and `scene_select` sets it through `select`. */
  choose?(e: Entity): void;
  /** An instance's overrides settled, as the inspector settles them; none, and `scene_override` is refused. */
  readonly overrides?: OverrideSteps;
  /** The prefab open to edit, or null for the scene: its own instance's overrides are its file's edits, and Apply is the scene's. */
  opened?(): string | null;
  /** That prefab's instance root (NONE while the scene is): what `scene_create` puts an instance under there, given no parent. */
  openedRoot?(): Entity;
  /**
   * Save as prefab, the tree's own (`save-prefab.ts`): `entities` written as
   * the prefab `key` and replaced by an instance of it, one step -- its label
   * prefixed, and handed to `made` with the instance's root. Resolves to the
   * line said; rejects with why nothing was done (the key taken, or not a
   * name in a folder; the file not compiling). None, and
   * `scene_save_prefab` is refused.
   */
  savePrefab?(key: string, entities: readonly Entity[], options: { prefix: string; made(step: Step, root: Entity): void }): Promise<string>;
  /** Prefab files the live compile could not take, by key, with why: a file that does not parse, or a compile error naming it. */
  prefabProblems?(): ReadonlyMap<string, string>;
  /** Prefab files that are none -- a `.json` under prefabs/ -- by path, with the fix (`packages/editor/src/assets/strays.ts`): listed in `broken`. */
  prefabStrays?(): Promise<readonly { key: string; problem: string }[]>;
  /** The keys of an asset kind loaded now (`Assets.keysOf`): what `scene_set` may put in a key field. None, and any key is taken. */
  keysOf?(kind: string): readonly string[];
  /** Every key type the project has (`Assets.keyKinds`: the pipeline's and its own), for saying a key is another kind's. Left out, the engine's (`keyKinds`, as the bundle handed them in). */
  keyKinds?(): readonly string[];
  /** A model's named parts (`Assets.partsOf`): what a `Model` key's `#part` may be. */
  partsOf?(model: string): readonly string[];
  /**
   * The clip names of the model an entity is drawn with, lowercased (the inspector's `clipsOf`): what a `Clip` key
   * may be on it. Left out, any clip is taken. An empty list -- a model with no clips -- refuses every clip but none;
   * `undefined` -- no model, or one not loaded (no `Render.model` nor a view's, or a key the store lacks) -- is not
   * known, and any clip is taken.
   */
  clipsOf?(e: Entity): readonly string[] | undefined;

  // ------------------------------------------------------------ M2: the scene and its entities

  /** The person's selection set to `es` (`scene_select`), as a click in the tree does; none, `scene_select` is refused. */
  select?(es: readonly Entity[]): void;
  /** The editor's view: where Create ▸ Camera puts a camera (in front of it, looking along it). None, at the origin. */
  view?(): EditorView;
  /** The tree's Open prefab: `key` opened over the scene, put aside as the editor does -- why it cannot be saved (null: it can), or why not opened. */
  openPrefab?(key: string): { readOnly: string | null } | { error: string };
  /**
   * Back from the prefab open: saved first (`save` true), its changes dropped (`false`), or -- `null` -- only if it
   * has none. Resolves to where it went back to, or why not.
   */
  closePrefab?(save: boolean | null): Promise<{ key: string; back: string; saved: boolean; dropped: boolean; said: string } | { error: string }>;
  /**
   * The prefab open saved to its file, staying in it: the header's Save and S with a prefab open (`editor.ts`'
   * `saveOpened`). `wrote` false: nothing to save, its file says this already.
   */
  saveOpened?(): Promise<{ key: string; file: string; wrote: boolean; said: string } | { error: string }>;
  /** The Scenes page's Open: `key` in place of the world -- refused while it has changes nobody saved, unless `discard`. */
  openScene?(key: string, discard: boolean): { skipped: string[]; discarded: boolean } | { error: string };
  /** The Scenes page's New scene: the world emptied -- refused while it has changes nobody saved, unless `discard`. */
  newScene?(discard: boolean): { discarded: boolean } | { error: string };
  /** The Scenes page's Save as…, never over another scene: written by the dev server. */
  saveSceneAs?(name: string): Promise<{ name: string; key: string } | { error: string }>;
  /** The Scenes page's Import…: a world save's text written as a new scene and opened -- refused over what nobody saved, unless `discard`. */
  importScene?(text: string, name: string, discard: boolean): Promise<{ key: string; file: string; skipped: string[]; discarded: boolean } | { error: string }>;
  /** The Scenes page's start pick: `key`'s file says `"start": true` (null: the game's own world). */
  setStart?(key: string | null): Promise<{ start: string | null } | { error: string }>;

  // ------------------------------------------------------------ M4: play and view

  /** The playtest, through the editor's own controls. None: the play tools are refused. */
  readonly play?: PagePlay;
  /** The editor's view, and images of views. None: the view tools are refused. */
  readonly views?: PageView;
  /** The game view: the frame the game is drawn in, and Maximize on Play (Docs/game-view.md D7). None: the game view tools are refused. */
  readonly gameView?: PageGameView;
  /** The Model tab's model, as the model tools work it (Docs/mcp.md M6). None, or null: no Model tab here. */
  model?(): PageModel | null;
  /** Redo `n` steps of the world's history, as Y does: read again once at the end. */
  redo?(n: number): void;
  /** Physics as the physics tools work it (Docs/physics.md §7): Config ▸ Physics' file, Fit's bounds, the overlay. None: refused. */
  readonly physics?: PagePhysics;
}

/** What the collider overlay draws: nothing, the selection's colliders, or every one. */
export type CollidersShown = 'none' | 'selected' | 'all';

/** Physics as the physics tools work it (`editor.ts`): the same functions as Config ▸ Physics, Fit to model and the view menu's Colliders. */
export interface PagePhysics {
  /** `physics.json` as the dev server has it (`live`), else the settings the page was served. */
  read(): Promise<{ settings: PhysicsSettings; live: boolean }>;
  /** A change written to `physics.json`, by Config ▸ Physics' rule (refused while a playtest is on; on or off only saved). */
  write(change: PhysicsChange): Promise<{ settings: PhysicsSettings; restart: boolean } | { error: string }>;
  /** The model `e` draws, its bounds in `e`'s own space before its scale; null for none drawn. */
  bounds(e: Entity): Bounds | null;
  /** The collider overlay's choice, and the way to set it (the view menu's Colliders). */
  colliders(): CollidersShown;
  setColliders(shown: CollidersShown): void;
}

/** What `play_stop`'s `keep` answers: the offer Stop makes, with no dialog. */
export type KeepChoice = 'all' | 'none' | readonly string[];

/** The playtest as the play tools work it (`editor.ts`): the same functions F5, F6, F10 and Shift+F5 call. */
export interface PagePlay {
  state(): 'none' | 'running' | 'paused';
  /** The loop's tick now, and the ticks since the playtest began (0 with none). */
  ticks(): { tick: number; ticks: number };
  /** What was changed while paused, as Stop would offer it now: each by its id (`editId`) and in words. */
  offered(): Array<{ id: string; words: string }>;
  /** A key's event, through the editor's own `playtest`: F5 plays or runs on, F6 pauses, F10 steps. */
  press(event: 'F5' | 'F6' | 'step'): void;
  /**
   * Stop, as Shift+F5: the world put back -- then what was changed while paused kept as `keep` says (no dialog), or,
   * with none, as the person's preference says (`asked`: the dialog shown to them). What was kept, skipped and dropped
   * (`discarded`). `prefix` labels the kept ones' step as the call's (`Claude: Kept from the playtest`).
   */
  stop(keep: KeepChoice | undefined, prefix: string): { how: 'all' | 'none' | 'listed' | 'preference: keep' | 'preference: drop' | 'asked'; kept: string[]; skipped: string[]; discarded: number; step: string | null };
}

/** A view to draw into an image: the editor's, a camera entity's, the game's main camera, the Model tab's. */
export interface ShotAsk {
  target: 'scene' | 'camera' | 'main' | 'model';
  /** `camera`: the camera entity. */
  camera: Entity | null;
  width: number | null;
  height: number | null;
  overlays: boolean;
  format: 'webp' | 'png';
}

/** An image drawn: its bytes as base64, its type and size, what to say beside it, and the camera entity looked through. */
export interface Shot {
  data: string;
  mimeType: string;
  width: number;
  height: number;
  notes: string[];
  camera: Entity | null;
}

/** The game view as `game_view_state`, `game_view_set` and `game_view_preset` work it (`editor.ts`, Docs/game-view.md §3-4). */
export interface PageGameView {
  /**
   * The game's frame (`Game.frame`: a preset's box when one applies), the canvas's CSS size, whether the frame is in
   * the room or the whole canvas, Maximize on Play, the preset chosen and whether it applies now, the game's pixels and
   * the box's scale, the look, and every preset.
   */
  get(): Omit<GameViewResult, 'tool'>;
  /** Maximize on Play set, as the play strip's toggle: kept as the preference, a playtest running moved at once. */
  setMaximize(on: boolean): void;
  /** The preset of that name chosen, as the dropdown (Free Aspect for none): null, or why not. */
  choose(name: string): string | null;
  /** The Game look on or off, as the dropdown's Game. */
  setLook(game: boolean): void;
  /** A preset of the project's added, or `replacing` one changed: the preset, or why not. */
  put(ask: PresetAsk, replacing?: string | null): GamePreset | string;
  /** One of the project's removed: null, or why not. */
  remove(name: string): string | null;
  /** One of the project's moved `by` places. */
  move(name: string, by: number): void;
}

/** The editor's view as the view tools work it (`editor.ts`, `viewport.ts`): the same camera F, the cube and Numpad move. */
export interface PageView {
  /** Where it is: its pose, the room past the cards (canvas CSS pixels; null: all of it), the canvas's size. */
  get(): {
    pose: { position: [number, number, number]; target: [number, number, number]; projection: 'perspective' | 'orthographic'; fov: number | null; height: number | null };
    room: { left: number; top: number; right: number; bottom: number } | null;
    canvas: { width: number; height: number };
  };
  /** The camera at `position`, turning round `target`, its projection kept. */
  setPose(position: [number, number, number], target: [number, number, number]): void;
  /** From a side, at the distance it has (the numpad's, the cube's cones). */
  look(preset: 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom'): void;
  setProjection(projection: 'perspective' | 'orthographic'): void;
  /** Onto these entities, as F frames the selection; false if none of them is anywhere. */
  frame(entities: readonly Entity[]): boolean;
  /** An image of a view, drawn as the screen draws it; the person's view unmoved. Throws why not, in words. */
  shot(ask: ShotAsk): Promise<Shot>;
}

/** One `scene_set` this tab ran that made a step, as values (Docs/agent.md §8): what a reload carries, the undo stack not surviving one. */
export interface AgentEdit {
  /** The turn it was made in, and its call's `tool_use` id: the transcript's row. */
  turn: string | null;
  use: string | null;
  component: string;
  field: string;
  /**
   * Each entity written: its id and its ref (a reload keeps both), its value before, and the agent's -- a key field's
   * as its text (`fieldPlain`), since ids are a session's (Docs/render.md §2), interned again on the way back.
   */
  written: { id: number; ref: number; was: number | string; now: number | string }[];
}

/** An edit as a reload carries it: its values, and where it stood. */
export interface CarriedEdit extends AgentEdit {
  /** The agent's values are not in the world -- undone, with `Z` or Undo this turn: nothing to put back. */
  undone: boolean;
  /** Gone from the undo stack, and why ("another scene was loaded"): its values mean nothing in the world now. */
  gone: string | null;
}

/** What a reload carries of the agent's edits in this tab: the resume record's `agent`. */
export interface EditorCarry {
  edits: CarriedEdit[];
  /** Undo this turn's step by value, the last done as the page went (`done`) or the next to redo: its label, and its edits by index. */
  top: { label: string; edits: number[]; done: boolean } | null;
}

/** An edit as kept here: its values, its step while this page has it, and where it stands. */
export interface KeptEdit extends CarriedEdit {
  /** Its step on the world's undo stack; null once from before a reload, or let go of. */
  step: Step | null;
  /** Its step was done when history last moved: one that goes from below was the oldest, trimmed; from above, its redo dropped. */
  done: boolean;
}

/** What each area's handlers are given: the editor, and the bookkeeping of what they did (`page.ts`). */
export interface PageContext {
  readonly host: PageHost;
  readonly world: World;
  readonly history: History;
  readonly worldSteps: WorldSteps;
  /** An edit a call made, kept for the transcript: its step, and -- a `scene_set`'s -- its values. */
  keep(edit: KeptEdit): void;
  /** A row's state may have changed: the transcript is told. */
  tell(): void;
  /** Is `e` of the opened prefab's own instance, whose overrides are its file's edits: none said of it. */
  opened(world: World, e: Entity): boolean;
  /**
   * A call's edit done: the world flushed, then one world step labelled `Claude: <label>` (the call's prefix), kept
   * for the transcript -- with `values`, a `scene_set`'s, by value too. Inside a `batch`, no step: the batch makes
   * one of them all. The step's label, or null if nothing changed.
   */
  step(call: McpCall, label: string, values?: Pick<AgentEdit, 'component' | 'field' | 'written'>): string | null;
  /** Inside a `batch`: the step is the batch's, nothing drawn until it ends. */
  readonly batching: boolean;
}

/** A page tool's handler: the call's facts, or a promise of them (an Apply, once its file is compiled). It throws a `Refusal` for input that will not do. */
export type PageHandler = (ctx: PageContext, call: McpCall) => EditorResult | Promise<EditorResult>;

/** A material field's new value, as the Materials block writes it: a number, a word or a path, a linear colour; null takes it out. */
export type ModelFieldValue = number | string | readonly [number, number, number] | null;

/** One joint's pose as `model_pose` takes it: Gladius's readable trio, in degrees from rest, and a move in metres. */
export interface ModelJoint {
  forward?: number;
  left?: number;
  twist?: number;
  translate?: [number, number, number];
}

/**
 * The Model tab as the studio's model tools work it (`model/model-agent.ts`, Docs/mcp.md M6): its own steps -- Open,
 * the Parameters block's drag and let go and Bake, the Materials block's let go, K, Build -- each write one step of the
 * tab's history. A problem is said in words, nothing done.
 */
export interface PageModel {
  /** The script open, or null. */
  path(): string | null;
  /** `path` opened, the tab brought up -- as the Assets panel's Open in Model tab; a preview not written put away only with `discard`. */
  open(path: string, discard: boolean): Promise<{ discarded: boolean } | { problem: string }>;
  /** The model open, as facts (its parameters read again); null with none. */
  facts(): Promise<ModelFacts | null>;
  /** Parameters set (the record), or baked into the script: one step. */
  setParams(values: Readonly<Record<string, string | null>>, bake: boolean): Promise<{ label: string; baked: string[]; skipped: string[]; files: string[] } | { problem: string }>;
  /** A preview built at these values and shown, nothing written: null once shown, else why not. */
  preview(values: Readonly<Record<string, string>>): Promise<string | null>;
  /** The export shown again after a preview. */
  unpreview(): void;
  /** Exported now, as Build: the jobs queued. */
  export(): Promise<{ jobs: QueuedExport[] } | { problem: string }>;
  /** A declared material's fields written: one step. */
  setMaterial(name: string, set: Readonly<Record<string, ModelFieldValue>>): Promise<{ label: string; files: string[] } | { problem: string }>;
  /** Joints keyed into the clip's action at `time` seconds (or `frame`): one step, as K. */
  pose(clip: string, at: { time?: number; frame?: number }, joints: Readonly<Record<string, ModelJoint>>): Promise<{ label: string; note: string; time: number; files: string[] } | { problem: string }>;
}
