/**
 * The scene area's page tools (Docs/mcp.md §4), each what the editor's own control does, through its own code:
 *
 * - **`scene_describe`**: `world.describe()`.
 * - **`scene_set`**: a numeric field, written as the inspector writes one -- the column, `world.moved` for a
 *   `Transform` -- on `entities`, or on the selection; `value` one for all, or one per entity. An edit under way is a
 *   step of its own first (`PENDING`); then ONE world step, `Claude: Transform.px` (`× 3` for several), so `Z` undoes
 *   it. A component that is no number's, an unknown field, a `ref()`, a value out of range, a dead entity or one
 *   without the component is refused, nothing written.
 * - **`scene_create`**: an instance of a prefab, an Empty or a camera, placed as the tree's Create menu places it
 *   (`spawnAt`), at `at` -- in the world, or relative to `parent` -- named afresh; in an opened prefab with no
 *   `parent`, under its root or the selected entity of it. Never selected: Claude's edits do not move the person's
 *   selection (Docs/mcp.md §2 rule 5). ONE world step.
 * - **`scene_override`**: Revert, Apply or Unpack, as the inspector's marks and Overrides list do; ONE step `Z`
 *   undoes, Apply's with the prefab's file in it, answered once the file is written and compiled.
 * - **`scene_save_prefab`**: the tree's Save as prefab, of `entities` or the selection, answered once the file is
 *   compiled and the entities replaced; ONE step that `Z` undoes -- the file to the trash.
 * - **`scene_save`**: the Scenes page's Save: the scene's own file, or a new one -- written by the dev server, so
 *   answered once it is on disk.
 */
import type { DescribeResult, InstantiateResult, McpCall, OverrideResult, SaveResult, SavePrefabResult, SetResult } from '@vibe/pipeline/agent-types';
import { type AnyComponent, caseKey, isData, keyKinds, clampTo, colourValue, compiledPrefab, compiledPrefabs, type Component, type Entity, type Field, fieldPlain, fieldProblem, fieldValue, fileFieldOf, fileFields, type FileField, Hierarchy, isKeyRef, keyKindOf, label, Labels, Name, NO_REF, NONE, type ObjectComponent, prefabFiles, refMisfit, splitModel, Transform, untypedPrefab as prefab, View } from '@vibe/engine';
import { prefabPathOf } from '../assets/ui/prefab-steps.ts';
import { dataSet } from './data.ts';
import { inFront, MAIN_SAID, mainCameraCode, makeCamera } from '../camera-entity.ts';
import type { Step } from '../history.ts';
import { colourOf, hexOf } from '../key-field.ts';
import { times } from '../multi.ts';
import { setName } from '../names.ts';
import { localAt, nestedKeys, openedParent } from '../opened.ts';
import { itemsAt, itemsOf, type Item } from '../overrides-edit.ts';
import { EMPTY, spawnAt } from '../spawn.ts';
import { PENDING } from '../world-steps.ts';
import { entitiesOf, entityOf, handleOf, no, pathOf, RANGE, refOrKey, Refusal, rowOf, stepPrefix, uidOfField } from './facts.ts';
import type { PageContext } from './host.ts';

/** `scene_describe`: `world.describe()`. */
export function sceneDescribe(ctx: PageContext): DescribeResult {
  return { tool: 'scene_describe', text: ctx.world.describe() };
}

/** The component `name` names, if it is one `scene_set` may write: a numeric one's field, or an object one's value. */
export function settable(ctx: PageContext, name: string): AnyComponent {
  const { world } = ctx;
  const component = world.allComponents.find((c) => c.name === name);
  if (!component) {
    const names = world.allComponents.filter((c) => (c.kind === 'data' && !c.transient) || (c.kind === 'object' && (c === Name || (c.save && c.load)))).map((c) => c.name);
    return no(`There is no component called ${name}: those scene_set writes are ${names.join(', ')}`);
  }
  if (component.kind === 'tag') return no(`${name} is a tag, with no fields to set: scene_flags puts it on or takes it off`);
  if (component.kind === 'relation') return no(`${name} is a relation: scene_relate makes a link, with its data`);
  if (component.kind === 'object') {
    if (component === View) return no('View is the engine\'s own, drawn from Render: set Render.model');
    if (component === Labels) return no('Labels are scene_flags\' (labels add, remove)');
    if (component !== Name && !(component.save && component.load)) return no(`${name} is an object component with no save shape (no save and load): nothing can be written into it`);
    return component;
  }
  if (component.transient) return no(`${name} is the world's own, worked out again from the rest${name === 'WorldTransform' ? ': set Transform' : ''}`);
  return component;
}

/** The component `name` names, if it is a numeric one: `scene_set`'s M1 refusals, kept for its callers. */
export function numeric(ctx: PageContext, name: string): Component {
  const component = settable(ctx, name);
  if (component.kind !== 'data') return no(`${name} is an object component, not numbers`);
  return component as Component;
}


/** A key type as a person says it: `Sfx` "a Sfx", `Atlas` "an Atlas". */
const aKindOf = (kind: string): string => `${/^[AEIOU]/.test(kind) ? 'an' : 'a'} ${kind}`;

/** Why `text` is no key of `kind` the project has (one of another kind said so; a `Model`'s `#part` none of its parts), or null: none, or the host cannot say. */
export function unknownKey(ctx: PageContext, kind: string, text: string): string | null {
  const { host } = ctx;
  if (text === '' || !host.keysOf) return null;
  /** The first ten and how many: `named` what they are, `none` said for none. */
  const listed = (all: readonly string[], named: string, none: string): string =>
    all.length === 0 ? none : `${named} are ${all.slice(0, 10).join(', ')}${all.length > 10 ? ` and ${all.length - 10} more (${all.length} in all)` : ''}`;
  const { model, part } = kind === 'Model' ? splitModel(text) : { model: text, part: null };
  const keys = host.keysOf(kind);
  const found = keys.find((k) => caseKey(k) === caseKey(model));
  if (found === undefined) {
    // An asset of another kind with that key: said by its kind ("hop is a Sfx, not a Model").
    // Among every kind the project has, its own data kinds too (the pipeline's, as the bundle handed them in).
    const kinds = host.keyKinds?.() ?? keyKinds();
    const other = kinds.find((k) => k !== kind && host.keysOf!(k).some((x) => caseKey(x) === caseKey(model)));
    const what = other === undefined ? `no ${kind} asset has the key ${model}` : `${model} is ${aKindOf(other)}, not ${aKindOf(kind)}`;
    return `${what} -- ${listed(keys, `the ${kind} keys`, `there are no ${kind} keys`)}`;
  }
  if (part === null || !host.partsOf) return null;
  const parts = host.partsOf(found);
  return parts.some((p) => caseKey(p) === caseKey(part)) ? null : `${found} has no part ${part} -- ${listed(parts, 'its parts', 'it has none')}`;
}

/**
 * A numeric field's value as the inspector shows it: a key's text, a colour `#rrggbb` (`#rrggbbaa` with alpha), an
 * enum's name, flags' names (`fire, ice`), a ref the ref it holds, a number.
 */
function shown(component: Component, field: string, value: number): number | string {
  const schema = (component.schema as Record<string, { color?: true; alpha?: true } | undefined>)[field];
  if (schema?.color && !schema.alpha) return hexOf(value);
  return fieldPlain(component, field, value);
}

/** A field's value now as an answer says it: `shown`, a vector its numbers. */
function shownField(component: Component, f: FileField, columns: readonly { [i: number]: number }[], e: Entity): number | string | number[] {
  return f.field.vec !== undefined ? columns.map((c) => c[e]!) : shown(component, f.name, columns[0]![e]!);
}

/**
 * The value given for a numeric field, as its column holds it -- through the inspector's own readers: a key's text
 * or `{ uid, key }` interned (`fieldValue`), a colour `#rrggbb` (`colourOf`), a yes or no, a ref by an entity's ref or
 * path (`world.ref`; null for none), a number in its type's range. Refused, with why, for anything else.
 */
function columnValue(ctx: PageContext, component: Component, field: string, given: unknown, e: Entity, clamped?: string[]): number {
  const { world, host } = ctx;
  const key = `${component.name}.${field}`;
  const schema = (component.schema as Record<string, Field | undefined>)[field];
  if (schema?.ref) {
    if (given === null || given === 0 || given === '') return NO_REF;
    const to = entityOf(world, given, key);
    // A typed ref (`ref(Health)`) holds only an entity with what it needs: refused with why, as a drop is.
    const misfit = refMisfit(schema, (name) => {
      const c = world.allComponents.find((x) => x.name === name);
      return c !== undefined && world.has(to, c);
    }, label(world, to));
    if (misfit !== null) return no(`${key}: ${misfit}`);
    return world.ref(to);
  }
  if (schema?.alpha) {
    const hex = typeof given === 'string' ? colourValue(given, true) : typeof given === 'number' && Number.isInteger(given) && given >= 0 && given <= 0xffffffff ? given : null;
    if (hex === null) return no(`${key} is a colour with alpha: "#rrggbbaa" ("#rrggbb" opaque), not ${JSON.stringify(given)}`);
    return hex;
  }
  if (schema?.color) {
    const hex = typeof given === 'string' ? colourOf(given) : typeof given === 'number' && Number.isInteger(given) && given >= 0 && given <= 0xffffff ? given : null;
    if (hex === null) return no(`${key} is a colour: "#rrggbb", not ${JSON.stringify(given)}`);
    return hex;
  }
  // An enum by its name (or its index), flags by a list of names: a name none of its names refused with the names there are.
  if (schema?.enum) {
    if (typeof given !== 'string' && typeof given !== 'number') return no(`${key} is one of ${schema.enum.join(', ')}: give the name, not ${JSON.stringify(given)}`);
    // An index past its names is code's to write, never Claude's: a name, or an index of one.
    if (typeof given === 'number' && !(Number.isInteger(given) && given >= 0 && given < schema.enum.length)) return no(`${key}: ${given} is no index of its names -- give a name: ${schema.enum.join(', ')}`);
    const why = fieldProblem(component, field, given);
    if (why !== null) return no(why);
    return fieldValue(component, field, given)!;
  }
  if (schema?.flags) {
    if (typeof given === 'number' && Number.isInteger(given) && given >= 0 && given < 2 ** schema.flags.length) return given;
    if (!Array.isArray(given) && typeof given !== 'string') return no(`${key} is a set of ${schema.flags.join(', ')}: give a list of names (["${schema.flags[0]}"]; [] for none), not ${JSON.stringify(given)}`);
    const why = fieldProblem(component, field, given);
    if (why !== null) return no(why);
    return fieldValue(component, field, given)!;
  }
  if (schema?.bool) {
    if (given === true || given === 1) return 1;
    if (given === false || given === 0) return 0;
    return no(`${key} is a yes or no: true or false, not ${JSON.stringify(given)}`);
  }
  const kind = keyKindOf(component, field);
  if (kind !== null) {
    let text: string;
    const mesh = schema?.mesh === true;
    /** A mesh's `{ key, part }` (or `{ uid, key, part }`): its part, `''` for the whole model. */
    const partOf = (g: unknown): string => {
      const part = (g as { part?: unknown }).part;
      return typeof part === 'string' ? part : '';
    };
    if (typeof given === 'string') text = given;
    else if (isKeyRef(given)) {
      const ref = refOrKey(kind, mesh ? { uid: given.uid, key: given.key } : given);
      if ('error' in ref) return no(`${key}: ${ref.error}`);
      text = (ref.key ?? '') + (mesh && ref.key !== null && partOf(given) !== '' && !ref.key.includes('#') ? `#${partOf(given)}` : '');
    } else if (mesh && given !== null && typeof given === 'object' && !Array.isArray(given) && typeof (given as { key?: unknown }).key === 'string') {
      // A mesh by `{ key, part }`: the model's key and one of its parts (none, the whole model).
      const model = (given as { key: string }).key;
      text = model === '' ? '' : partOf(given) === '' ? model : `${model}#${partOf(given)}`;
    } else {
      return no(mesh
        ? `${key} is a mesh, a model and one of its parts: give { key, part } ({ "key": "props/parrot", "part": "wing" }; no part for the whole model), "props/parrot#wing", or "" for none -- not ${JSON.stringify(given)}`
        : `${key} is a ${kind} key: give its text ("props/crate"; "" for none) or { uid, key }, not ${JSON.stringify(given)}`);
    }
    // A key no asset has: refused with the keys there are, as the pickers offer them -- never interned on trust.
    if (kind !== 'Clip') {
      const why = unknownKey(ctx, kind, text);
      if (why !== null) return no(`${key}: ${why}`);
    } else if (text !== '' && host.clipsOf) {
      // A clip is a name among the clips of the model the entity is drawn with: each entity's own.
      const clips = host.clipsOf(e);
      if (clips !== undefined && !clips.includes(caseKey(text))) {
        return no(`${key}: entity ${e} (${label(world, e)}) ${clips.length === 0 ? `has no clip ${text} -- its model has no clips` : `has no clip ${text} -- its model's clips are ${clips.join(', ')}`}`);
      }
    }
    return fieldValue(component, field, text)!;
  }
  if (typeof given !== 'number' || !Number.isFinite(given)) return no(`${key} is a number, not ${JSON.stringify(given)}`);
  const type = component.fields.find((f) => f.name === field)!.type;
  const range = RANGE[type];
  if (range && (!Number.isInteger(given) || given < range[0] || given > range[1])) return no(`${key} is a ${type}: a whole number from ${range[0]} to ${range[1]}, not ${given}`);
  // Its own bounds (`min`, `max`: a vector's on each axis): clamped, as the inspector clamps, and said.
  const bounded = fileFieldOf(component, field)?.field;
  const held = bounded ? clampTo(bounded, given) : given;
  if (held !== given) clamped?.push(`${key} ${given} clamped to ${held}, its ${held === bounded!.min ? 'min' : 'max'}`);
  return held;
}

/**
 * The value given for a field, as its columns hold it: `columnValue`'s, or a vector's `[x, y, z]` an axis each, each
 * held to its bounds. Refused, with why, for anything else.
 */
function fieldValues(ctx: PageContext, component: Component, f: FileField, given: unknown, e: Entity, clamped?: string[]): number[] {
  if (f.field.vec === undefined) return [columnValue(ctx, component, f.name, given, e, clamped)];
  const n = f.field.vec;
  if (!Array.isArray(given) || given.length !== n || given.some((x) => typeof x !== 'number' || !Number.isFinite(x))) {
    return no(`${component.name}.${f.name} is a vector, [${['x', 'y', 'z', 'w'].slice(0, n).join(', ')}]: ${n} numbers, not ${JSON.stringify(given)}`);
  }
  return f.columns.map((c, i) => columnValue(ctx, component, c.name, given[i], e, clamped));
}

/** An object component's value given, as it is held: `Name` its text (null or "" for none), any other through its `load`. */
function objectValue(component: ObjectComponent<unknown>, given: unknown, now: unknown): unknown {
  if (component === Name) {
    if (given === null || given === '') return null;
    if (typeof given !== 'string') return no(`Name is text, not ${JSON.stringify(given)}`);
    // As the title takes it: trimmed, and nothing but spaces is no name.
    return given.trim() || null;
  }
  try {
    return component.load!(given, now);
  } catch (err) {
    return no(`${component.name} would not take that: ${err instanceof Error ? err.message : String(err)} -- give it in its save shape, as scene_entity shows it`);
  }
}

/** An object component's value as an answer says it: `Name` its text, any other its save shape as JSON text. */
function objectShown(component: ObjectComponent<unknown>, value: unknown): string {
  if (component === Name) return typeof value === 'string' ? value : '';
  try {
    return JSON.stringify(value === undefined || value === null ? null : component.save!(value)) ?? 'null';
  } catch {
    return 'null';
  }
}

/**
 * `scene_set`: a field, as the inspector writes it -- a number, a key, a colour, a yes or no, a ref, or an object
 * component whole by its save shape (`Name` its text) -- on `entities` (refs or paths), or on the selection. `was`,
 * given: written only where every entity holds it still, else `changed` with what each holds now, nothing written.
 */
export function sceneSet(ctx: PageContext, call: McpCall): SetResult {
  const { world, host } = ctx;
  const args = call.args;
  const component = settable(ctx, String(args.component));
  // A data component: a path into it, or the whole -- its own reader, checked against its schema at every step.
  if (isData(component)) return dataSet(ctx, call, component);
  const object = component.kind === 'object';
  const name = object ? 'value' : String(args.field);
  const data = object ? null : (component as Component);
  // The field as a file names it: a vector's name (`dir`), or one column of it (`dirX`) on its own.
  const whole = data ? fileFieldOf(data, name) : undefined;
  if (data && !whole) return no(`${data.name} has no field ${name}: it has ${fileFields(data).map((f) => f.name).join(', ')}`);
  const ff: FileField | undefined = whole && whole.name !== name ? { ...whole, name, field: { type: whole.field.type, initial: 0, ...(whole.field.min !== undefined ? { min: whole.field.min } : {}), ...(whole.field.max !== undefined ? { max: whole.field.max } : {}) }, columns: whole.columns.filter((c) => c.name === name) } : whole;
  const key = object ? component.name : `${component.name}.${name}`;
  // A runtime field of the prefab open: systems set it, and no Save of the prefab keeps it -- the inspector shows it, never edits it.
  if (ff && host.opened?.() && ff.runtime) return no(`${key} is set by the game's systems as it runs: a prefab keeps none of it, so it is not written here`);
  // A read-only field (`readonly: true`): the game's code sets it -- the inspector shows it, never edits it.
  if (whole?.field.readonly) return no(`${key} is read only (readonly: true in its maker): the game's code sets it, and neither the inspector nor scene_set writes it`);

  const given = args.entities;
  const ids: Entity[] = given === undefined ? [...host.selection()].filter((e) => world.alive(e)) : entitiesOf(world, given);
  if (ids.length === 0) return no('Nothing is selected: name the entities by ref or path, or ask the person to select them');
  for (const e of ids) if (component !== Name && !world.has(e, component)) return no(`${pathOf(world, e)} has no ${component.name}: scene_component adds it`);
  const value = args.value;
  // A vector's value is a list, and so is flags': one for all is that list; one per entity a list of them.
  const listed = ff !== undefined && (ff.field.vec !== undefined || ff.field.flags !== undefined);
  const each = (v: unknown): unknown[] => (listed
    ? (Array.isArray(v) && v.length > 0 && v.every(Array.isArray) ? [...(v as unknown[])] : ids.map(() => v))
    : Array.isArray(v) && !(object && component !== Name) ? [...(v as unknown[])] : ids.map(() => v));
  // `values`: one an entity, in order, said outright (as a data component takes them).
  const asked = args.values !== undefined ? (Array.isArray(args.values) ? [...(args.values as unknown[])] : no('values is a list: one value an entity, in order')) : each(value);
  if (asked.length !== ids.length) return no(`value has ${asked.length} values for ${ids.length} ${ids.length === 1 ? 'entity' : 'entities'}: give one for all, or one per entity`);

  const names = (): (string | null)[] => (world.rawStore(Name) as { value: (string | null)[] }).value;
  const nameOf = (e: Entity): string | null => (world.has(e, Name) ? (names()[e] ?? null) : null);
  const slots = object ? (world.rawStore(component) as { value: unknown[] }).value : null;
  const columns = data ? ff!.columns.map((c) => (world.rawStore(data) as Record<string, { [i: number]: number }>)[c.name]!) : [];
  const column = data ? columns[0]! : null;
  /** What the field holds now, as an answer says it. */
  const now = (e: Entity): number | string | number[] => (object ? objectShown(component as ObjectComponent<unknown>, component === Name ? nameOf(e) : slots![e]) : shownField(data!, ff!, columns, e));

  // Optimistic: `was` given, and the field changed since -- the person's edit wins; nothing written.
  if (args.was !== undefined) {
    const wasAll = each(args.was);
    if (wasAll.length !== ids.length) return no(`was has ${wasAll.length} values for ${ids.length} entities: one for all, or one per entity`);
    const f32 = data !== null && ff!.field.type === 'f32';
    const schema = data ? (data.schema as Record<string, { ref?: true } | undefined>)[name] : undefined;
    const naming = schema?.ref === true || (data !== null && keyKindOf(data, name) !== null);
    const moved = ids.filter((e, i) => {
      const w = wasAll[i];
      if (object) return now(e) !== (component === Name ? (w ?? '') : JSON.stringify(w));
      let held: number[];
      try {
        held = fieldValues(ctx, data!, ff!, w, e);
      } catch (err) {
        // A ref or a key it held then, gone now: it holds something else -- changed, not a mistake in the call.
        if (naming && err instanceof Refusal) return true;
        throw err;
      }
      // As the column keeps it: an f32 holds 0.1 as 0.10000000149…, which is the 0.1 an answer said.
      return held.some((h, k) => columns[k]![e] !== (f32 ? Math.fround(h) : h));
    });
    if (moved.length > 0) {
      return { tool: 'scene_set', component: component.name, field: name, step: null, written: [], changed: moved.map((e) => ({ ref: world.ref(e), id: e, name: nameOf(e), now: now(e) })) };
    }
  }

  const clamped: string[] = [];
  const values = ids.map((e, i) => (object ? objectValue(component as ObjectComponent<unknown>, asked[i], component === Name ? nameOf(e) : slots![e]) : fieldValues(ctx, data!, ff!, asked[i], e, clamped)));
  // An edit under way -- a number typed, not committed -- is a step of its own first: Z then undoes this, not it too.
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
  const was = ids.map(now);
  ids.forEach((e, i) => {
    // The title's rename (`names.ts`): trimmed, "" taking it off.
    if (component === Name) setName(world, e, (values[i] as string | null) ?? '');
    else if (object) slots![e] = values[i];
    else {
      (values[i] as number[]).forEach((v, k) => void (columns[k]![e] = v));
      if (component === Transform) world.moved(e);
    }
  });
  world.flush();
  // A key field's as its text: a reload carries it, and a reload's ids are its own. An object's write keeps its step alone.
  const written = ids.map((e, i) => ({ id: e, ref: world.ref(e), was: was[i]!, now: now(e) }));
  // A vector's numbers, a ref, a colour: kept by the step alone, as an object's write.
  const plain = data !== null && ff!.field.vec === undefined && !(data.schema as Record<string, { ref?: true; color?: true } | undefined>)[name]?.ref && !(data.schema as Record<string, { color?: true } | undefined>)[name]?.color;
  const step = ctx.step(call, times(key, ids.length), plain ? { component: component.name, field: name, written: ids.map((e, i) => ({ id: e, ref: world.ref(e), was: fieldPlain(data!, name, typeof was[i] === 'number' ? (was[i] as number) : (fieldValue(data!, name, was[i]) ?? 0)), now: fieldPlain(data!, name, column![e]!) })) } : undefined);
  if (!ctx.batching) {
    host.changed();
    ctx.tell();
  }
  const kind = data ? keyKindOf(data, name) : null;
  return {
    tool: 'scene_set',
    component: component.name,
    field: name,
    step,
    ...(object ? { object: true } : {}),
    // As kept: an f32 holds 0.1 as 0.10000000149…
    // A key field's: the key as text, and the uid it has where it has one (Docs/asset-ids.md §3) -- what a file would write.
    written: written.map((w) => ({ ...w, name: nameOf(w.id as Entity), ...(data ? uidOfField(kind, column![w.id]!, data, name) : {}) })),
    ...(clamped.length > 0 ? { clamped: [...new Set(clamped)] } : {}),
  };
}

/** Where what is made goes, as the Create menu's rule has it: `parent` given, under it; in an opened prefab, under its root (or the selected entity of it). */
function madeUnder(ctx: PageContext, parent: unknown): { under: Entity; opened: boolean } {
  const { world, host } = ctx;
  if (parent !== undefined && parent !== null) return { under: entityOf(world, parent, 'parent'), opened: false };
  const inOpened = host.opened?.() ? openedParent(world, host.openedRoot?.() ?? NONE, host.selection()) : NONE;
  return { under: inOpened, opened: inOpened !== NONE };
}

/**
 * `scene_create`: as the Create menu makes it -- an instance of a prefab (the Spawn list's), an Empty, or a camera
 * (Create ▸ Camera: in front of the editor's view, looking along it, `main` when the scene has none) -- at `at` (in
 * the world, or relative to `parent`), under `parent` in front of `before`, named `name` if given. ONE step.
 */
export function sceneCreate(ctx: PageContext, call: McpCall): InstantiateResult {
  const { world, host } = ctx;
  const { kind = 'prefab', prefab: given, at, parent, before, name } = call.args as { kind?: unknown; prefab?: unknown; at?: unknown; parent?: unknown; before?: unknown; name?: unknown };
  if (kind !== 'prefab' && kind !== 'empty' && kind !== 'camera') return no(`kind is prefab, empty or camera, not ${String(kind)}`);
  let key: string | undefined;
  if (kind === 'prefab') {
    // A key, or a reference as a file writes it (`{ uid, key }`, Docs/asset-ids.md §3): by its uid, never one made up.
    const ref = refOrKey('prefabs', given);
    if ('error' in ref) return no(`prefab: ${ref.error}`);
    key = ref.key === null ? undefined : caseKey(ref.key);
    // The prefabs compiled now: one whose file went keeps its row for the instances still out, not its key.
    const keys = compiledPrefabs().flatMap((p) => (p && compiledPrefab(p.key) === p ? [p.key] : [])).sort();
    if (key === undefined || !keys.includes(key)) return no(`There is no prefab ${key ?? String(given)}: the prefabs are ${keys.join(', ') || 'none'}`);
    // In an opened prefab, never the prefab open, nor one nesting it: saved, it would be inside itself.
    const open = host.opened?.() ?? null;
    if (open !== null && nestedKeys(key, prefabFiles()).includes(open)) return no(`${key === open ? `${open} is the prefab open` : `${key} nests ${open}, the prefab open`} -- saved, it would be inside itself`);
  } else if (given !== undefined) return no(`prefab is for kind prefab: a${kind === 'empty' ? 'n Empty' : ' camera'} has none`);
  if (name !== undefined && (typeof name !== 'string' || name.length > 200)) return no('name is text');
  const num = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
  const point = at === undefined ? null : (at as Record<string, unknown> | null);
  if (point !== null && (!point || !num(point.x) || !num(point.y) || !num(point.z))) return no('at is { x, y, z }, three numbers in metres');
  const { under, opened: inOpened } = madeUnder(ctx, parent);
  const beforeE = before === undefined || before === null ? NONE : entityOf(world, before, 'before');
  if (beforeE !== NONE && (world.rawStore(Hierarchy) as { parent: ArrayLike<number> }).parent[beforeE] !== under) return no(`before: ${pathOf(world, beforeE)} is not ${under === NONE ? 'a root' : `a child of ${pathOf(world, under)}`}`);
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
  const xyz = point ? { x: point.x as number, y: point.y as number, z: point.z as number } : { x: 0, y: 0, z: 0 };
  let e: Entity;
  let main: boolean | undefined;
  if (kind === 'camera') {
    // As Create ▸ Camera: in front of the view, looking along it -- or at `at`; main when the scene has no main camera yet.
    main = mainCameraCode(world) !== MAIN_SAID;
    const view = host.view?.();
    const rotation: [number, number, number, number] = view ? view.quaternion : [0, 0, 0, 1];
    if (point && parent !== undefined && parent !== null) {
      e = makeCamera(world, { position: [xyz.x, xyz.y, xyz.z], rotation, main });
      if (e !== NONE) world.setParent(e, under);
    } else {
      const position: [number, number, number] = point ? [xyz.x, xyz.y, xyz.z] : view ? inFront(view) : [0, 0, 0];
      e = makeCamera(world, { position, rotation, main, parent: under });
    }
  } else {
    const what = kind === 'empty' ? EMPTY : prefab(key!);
    // In an opened prefab, `at` in the world put in its root's space; under a parent given, `at` is relative to it already.
    e = spawnAt(world, what, inOpened ? localAt(world, under, xyz) : xyz);
    if (e !== NONE && under !== NONE) world.setParent(e, under);
  }
  if (e === NONE) return no('The world is full: nothing was made');
  if (beforeE !== NONE) world.setParent(e, under, beforeE);
  if (typeof name === 'string' && name.trim() !== '') world.store(Name).value[e] = name.trim();
  const step = ctx.step(call, kind === 'camera' ? 'Create Camera' : `Spawn ${kind === 'empty' ? EMPTY : key}`) ?? 'none';
  // Not selected, as the Create menu would: the person's selection is theirs (Docs/mcp.md §2 rule 5).
  if (!ctx.batching) {
    host.changed();
    ctx.tell();
  }
  const row = rowOf(world, e);
  return {
    tool: 'scene_create', kind, prefab: key ?? null, id: e, ref: row.ref, path: row.path, name: row.name, entities: key ? compiledPrefab(key)!.count : 1,
    parent: under === NONE ? null : under, at: point ? xyz : { x: 0, y: 0, z: 0 }, step, ...(main !== undefined ? { main } : {}),
  };
}

/** `scene_save_prefab`: Save as prefab of `entities` -- else the selection -- as the tree's menu does it. */
export function sceneSavePrefab(ctx: PageContext, call: McpCall): Promise<SavePrefabResult> {
  const { world, host } = ctx;
  const { key, entities } = call.args as { key?: unknown; entities?: unknown };
  if (!host.savePrefab) return no('The editor here saves no prefab');
  if (typeof key !== 'string' || key === '') return no('key is the new prefab\'s key, a name in a folder: crates/pile');
  const ids: Entity[] = entities === undefined ? [...host.selection()].filter((e) => world.alive(e)) : entitiesOf(world, entities);
  if (ids.length === 0) return no('Nothing is selected: name the entities by ref or path, or ask the person to select them');
  let step: Step | null = null;
  let root: Entity = NONE;
  const options = { prefix: stepPrefix(call), made: (made: Step, at: Entity) => void ((step = made), (root = at)) };
  return host.savePrefab(key, ids, options).then(
    (said): SavePrefabResult => {
      const own = step as Step | null;
      if (own) ctx.keep({ turn: call.turn, use: call.use, component: '', field: '', written: [], step: own, done: true, undone: false, gone: null });
      host.changed();
      ctx.tell();
      const names = (world.rawStore(Name) as { value: (string | null)[] }).value;
      const alive = root !== NONE && world.alive(root);
      return {
        tool: 'scene_save_prefab', key, file: prefabPathOf(key), root, name: alive && world.has(root, Name) ? (names[root] ?? null) : null,
        entities: compiledPrefab(key)?.count ?? 0, step: own?.label ?? 'none', said,
      };
    },
    (err: Error) => no(`Not saved as a prefab: ${err.message}`),
  );
}

/** `scene_override`: its instance, the overrides it names, and what to do -- worked out before anything is done. */
export function overrideCall(ctx: PageContext, call: McpCall): { root: Entity; items: Item[]; verb: 'revert' | 'apply' | 'unpack'; to: string | null; completely: boolean } {
  const { world, host } = ctx;
  const { verb, entity, what, to, completely } = call.args as { verb?: unknown; entity?: unknown; what?: unknown; to?: unknown; completely?: unknown };
  if (!host.overrides) return no('The editor here settles no overrides');
  if (verb !== 'revert' && verb !== 'apply' && verb !== 'unpack') return no('verb is revert, apply or unpack');
  const e = entity === undefined ? (host.selection()[0] ?? NONE) : entityOf(world, entity);
  if (e === NONE || !world.alive(e)) return no('Nothing is selected: name the entity by ref or path, or ask the person to select it');
  const root = world.instanceRoot(e);
  if (root === NONE) return no(`Entity ${e} (${label(world, e)}) is no instance of a prefab: it has no overrides`);
  if (host.opened?.() && world.prefabOf(root)?.key === host.opened()) return no(`Entity ${e} is of the prefab open, ${host.opened()}: its edits are the file's, which its Save writes`);
  const all = itemsOf(world, root)!;
  if (verb === 'unpack') {
    if (e !== root) return no(`Unpack is an instance's root's: entity ${root} (${label(world, root)})`);
    return { root, items: [], verb, to: null, completely: completely === true };
  }
  // Its own by handle; on the root, any of the instance's as `<at>: <handle>` too -- the list studio_state shows there.
  const own = itemsAt(world, all, e);
  const mine = e === root ? all.items : own;
  const handle = handleOf;
  const named = (w: string) => (i: Item): boolean => (own.includes(i) && i.what === w) || handle(i) === w;
  let items = mine;
  if (what !== undefined) {
    if (!Array.isArray(what) || what.some((w) => typeof w !== 'string')) return no('what is a list of overrides by their handles, as studio_state lists them');
    const unknown = (what as string[]).filter((w) => !mine.some(named(w)));
    if (unknown.length > 0) return no(`${label(world, e)} has no override ${unknown.join(', ')}: it has ${mine.map(handle).join(', ') || 'none'}`);
    items = mine.filter((i) => (what as string[]).some((w) => named(w)(i)));
  }
  if (items.length === 0) return no(`${label(world, e)} changes nothing of ${all.prefab.key}: nothing to ${verb}`);
  if (verb === 'revert') return { root, items, verb, to: null, completely: false };
  if (host.opened?.()) return no(`Apply is the scene's: a prefab is open (${host.opened()}), whose Save writes its file`);
  // `to` a key, or a reference read by its uid.
  const toRef = to === undefined ? null : refOrKey('prefabs', to);
  if (toRef !== null && 'error' in toRef) return no(`to: ${toRef.error}`);
  const target = toRef !== null && toRef.key !== null ? caseKey(toRef.key) : all.prefab.key;
  if (!items.some((i) => i.owners.includes(target))) return no(`${target} cannot hold ${items.map((i) => i.what).join(', ')}: ${[...new Set(items.flatMap((i) => i.owners))].join(', ')} can`);
  return { root, items, verb, to: target, completely: false };
}

/** `scene_override` run: Revert and Unpack at once, Apply once its file is written and compiled. */
export function sceneOverride(ctx: PageContext, call: McpCall): OverrideResult | Promise<OverrideResult> {
  const { world, host } = ctx;
  const { root, items, verb, to, completely } = overrideCall(ctx, call);
  const prefabKey = world.prefabOf(root)!.key;
  /** Its own step, as the steps made it -- never whichever is on top by the time an Apply answers. */
  let step: Step | null = null;
  const options = { prefix: stepPrefix(call), made: (made: Step) => void (step = made) };
  const answer = (said: string): OverrideResult => {
    const own = step as Step | null;
    if (own) ctx.keep({ turn: call.turn, use: call.use, component: '', field: '', written: [], step: own, done: true, undone: false, gone: null });
    host.changed();
    ctx.tell();
    return { tool: 'scene_override', verb, root, prefab: prefabKey, done: items.map(handleOf), to, step: own?.label ?? 'none: nothing changed', said };
  };
  if (verb === 'unpack') return answer(host.overrides!.unpack(root, completely, options));
  if (verb === 'revert') return answer(host.overrides!.revert(root, items, options));
  return host.overrides!.apply(root, items, to!, options).then(answer, (err: Error) => no(`Not applied: ${err.message}`));
}

/** `scene_save`: the Scenes page's Save -- the scene's own file, or `name` for a new one -- answered once it is on disk. */
export function sceneSave(ctx: PageContext, call: McpCall): Promise<SaveResult> {
  const name = call.args.name;
  if (name !== undefined && typeof name !== 'string') return no('name is not text');
  // A prefab open to edit: S and the header's Save write it and stay in it -- the same here.
  const open = ctx.host.opened?.() ?? null;
  if (open !== null) {
    if (typeof name === 'string') return no(`${open} is open to edit: scene_save saves it to its own file, with no name -- scene_close_prefab first to save the scene as a new one`);
    if (!ctx.host.saveOpened) return no('The editor here saves no prefab open');
    return ctx.host.saveOpened().then((done) => {
      if ('error' in done) return no(done.error);
      ctx.tell();
      return { tool: 'scene_save', name: done.key, key: done.key, saved: true, prefab: { file: done.file, wrote: done.wrote, said: done.said } };
    });
  }
  return ctx.host.save(typeof name === 'string' ? name : null).then((saved) => ('error' in saved ? no(saved.error) : { tool: 'scene_save', name: saved.name, key: saved.key, saved: true }));
}
