/**
 * What the studio's page tools share (Docs/mcp.md §3): an entity whole as `studio_state` says it (`entityFacts`),
 * an object component summarised, a tool's asset argument read (`refOrKey`), a step's label prefix, and the
 * refusal a handler throws for input that will not do (`no`), said to the agent as the tool's error.
 */
import type { EntityFacts, EntityRow, McpCall, OverrideFacts } from '@vibe/pipeline/agent-types';
import { type AnyComponent, componentsOn, type Entity, type EntityRef, fieldPlain, fileFields, flagNames, Hierarchy, isKeyRef, keyKindOf, keyOfUid, keyRef, Labels, ofKind, linksOf, madeFrom, Name, NO_REF, NONE, resolveRef, rootsOf, View, type World } from '@vibe/engine';
import { modelKeysOf } from '../agent/context.ts';
import { itemsAt, itemsOf, type Item } from '../overrides-edit.ts';

/** Entities `studio_state` answers whole, at most: the rest are counted. */
export const SELECTION_MAX = 32;

/** A prefab's instances `prefab_info` names by id, at most. */
export const ROOTS_MAX = 32;

/** What a prefab's entity is made of, as `prefab_info` says it: the world's own -- every entity's, or worked out -- left out. */
export const OWN = new Set(['Instance', 'Hierarchy', 'WorldTransform']);

/** The prefix of the agent's steps' labels on the editor's undo stack. */
export const STEP_PREFIX = 'Claude: ';

/**
 * A tool's asset argument (Docs/asset-ids.md §3): a key's text, or a reference as a file writes it -- `{ uid, key }`,
 * read by its uid (a stale key read right). A uid the index does not know is refused: Claude never makes one up, it
 * writes the key and the pipeline adds the uid. `key` null for none (`''`).
 */
export function refOrKey(kind: string, given: unknown): { key: string | null } | { error: string } {
  if (typeof given === 'string') return { key: given === '' ? null : given };
  if (!isKeyRef(given)) return { error: `give a key's text ("props/crate") or { uid, key }, not ${JSON.stringify(given) ?? String(given)}` };
  const row = keyOfUid(given.uid);
  if (row === undefined) return { error: `no asset has the uid ${given.uid} -- never make one up: give the key alone ("${given.key}"), and the pipeline adds its uid` };
  // A uid of another kind's asset: what it is said (a Sfx's uid on a Model field), never read as this kind's key.
  if (!ofKind(row, kind)) return { error: `the uid ${given.uid} is ${row.key}, ${row.type ?? row.kind} -- not a ${kind}` };
  return { key: resolveRef(kind, given) };
}

/** A key field's value's uid, `{ uid }`, where its asset has one; `{}` for none, or a field that is no key's. */
export function uidOfField(kind: string | null, value: number, component: { readonly schema: object }, field: string): { uid?: string } {
  if (kind === null) return {};
  const text = fieldPlain(component, field, value);
  if (typeof text !== 'string' || text === '') return {};
  const ref = keyRef(kind, text);
  return isKeyRef(ref) ? { uid: ref.uid } : {};
}

/** The prefix of an outside client's steps (`/__mcp`, Docs/mcp.md M7): no conversation's, so not Claude's in the panel. */
export const OUTSIDE_PREFIX = 'MCP: ';

/** A call's steps' prefix: `Claude: `, or -- several conversations open -- whose, `Claude (Crate work): `; an outside client's `MCP: `. */
export const stepPrefix = (call: Pick<McpCall, 'title' | 'outside'>): string => (call.outside ? OUTSIDE_PREFIX : call.title ? `Claude (${call.title}): ` : STEP_PREFIX);

/** A call's input that will not do: said to the agent, as the tool's error. */
export class Refusal extends Error {}

export const no = (why: string): never => {
  throw new Refusal(why);
};

/** Each integer type's range: a value outside it would wrap. */
export const RANGE: Partial<Record<string, [number, number]>> = {
  i8: [-128, 127], u8: [0, 255], i16: [-32768, 32767], u16: [0, 65535],
  i32: [-2147483648, 2147483647], u32: [0, 4294967295],
};

/** An object component's value in a few words: itself where it is short, else what it is. */
export function summarise(value: unknown): string {
  if (value === null || value === undefined) return 'empty';
  if (typeof value === 'string') return value.length > 200 ? `${value.slice(0, 199)}…` : value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (Array.isArray(value)) return `a list of ${value.length}`;
  const object = value as { isObject3D?: unknown; type?: unknown; name?: unknown; children?: unknown };
  if (object.isObject3D === true) {
    const n = Array.isArray(object.children) ? object.children.length : 0;
    return `${String(object.type)}${typeof object.name === 'string' && object.name ? ` "${object.name}"` : ''}, ${n} ${n === 1 ? 'child' : 'children'}`;
  }
  try {
    const json = JSON.stringify(value);
    if (json !== undefined) return json.length > 200 ? `${json.slice(0, 199)}…` : json;
  } catch {
    // Circular, or not plain: said by what it is.
  }
  return 'an object';
}

// ---------------------------------------------------------------- naming entities (Docs/mcp.md §6)

/** An entity's own segment of a path: its name, or `#<ref>` with none (or a name a path cannot hold: one with a `/`). */
export function segmentOf(world: World, e: Entity): string {
  const name = world.has(e, Name) ? ((world.rawStore(Name) as { value: (string | null)[] }).value[e] ?? null) : null;
  return name !== null && name !== '' && !name.includes('/') && !name.startsWith('#') ? name : `#${world.ref(e)}`;
}

/** An entity's path of names from its root: `big crate/rider`. */
export function pathOf(world: World, e: Entity): string {
  const parent = (world.rawStore(Hierarchy) as { parent: ArrayLike<number> }).parent;
  const out: string[] = [];
  for (let at = e, n = 0; at !== NONE && n < 4096; at = parent[at]! as Entity, n++) out.unshift(segmentOf(world, at));
  return out.join('/');
}

/** An entity as an answer names it: its ref, id, path and name. */
export function rowOf(world: World, e: Entity): EntityRow {
  const name = world.has(e, Name) ? ((world.rawStore(Name) as { value: (string | null)[] }).value[e] ?? null) : null;
  return { ref: world.ref(e), id: e, path: pathOf(world, e), name };
}

/** `e`'s children, in order. */
export function childrenOf(world: World, e: Entity): Entity[] {
  const links = world.rawStore(Hierarchy) as { firstChild: ArrayLike<number>; nextSibling: ArrayLike<number> };
  const out: Entity[] = [];
  for (let c = links.firstChild[e]!; c !== NONE && out.length < 100_000; c = links.nextSibling[c]!) out.push(c as Entity);
  return out;
}

/** The first few of a list, and how many more. */
const some = (list: readonly string[]): string => (list.length === 0 ? 'none' : `${list.slice(0, 10).join(', ')}${list.length > 10 ? ` and ${list.length - 10} more` : ''}`);

/**
 * The entity a call names (Docs/mcp.md §6): an `EntityRef` -- held to its generation, so one destroyed since names
 * nothing, never whatever took its place -- or a path of names from a root (`big crate/rider`, `#<ref>` for a part
 * with no name), each step one child of that name. Refused, with what there is, if it names none, or several.
 */
export function entityOf(world: World, given: unknown, what = 'entity'): Entity {
  if (typeof given === 'number') {
    if (!Number.isInteger(given) || given <= 0) return no(`${what}: ${given} is no entity's ref`);
    const e = world.deref(given as EntityRef);
    if (e === NONE || !world.alive(e)) return no(`${what}: the entity ${given} named is gone -- destroyed since, or never was (a ref holds its generation: one made in its place is another). Read scene_query again`);
    return e;
  }
  if (typeof given !== 'string' || given === '') return no(`${what} is an entity's ref (a number) or its path of names (big crate/rider)`);
  const steps = given.split('/');
  let at: readonly Entity[] = rootsOf(world).filter((e) => world.alive(e));
  let found: Entity = NONE;
  for (let i = 0; i < steps.length; i++) {
    const step = steps[i]!;
    const matches = at.filter((e) => segmentOf(world, e) === step || `#${world.ref(e)}` === step);
    const where = i === 0 ? 'among the roots' : `under ${steps.slice(0, i).join('/')}`;
    if (matches.length === 0) return no(`${what}: no ${step} ${where} -- there are ${some(at.map((e) => segmentOf(world, e)))}`);
    if (matches.length > 1) return no(`${what}: ${matches.length} entities are called ${step} ${where} -- name one by its ref: ${matches.map((e) => world.ref(e)).join(', ')}`);
    found = matches[0]!;
    at = childrenOf(world, found);
  }
  return found;
}

/** The entities a call names: each a ref or a path, none twice; `none` said when the list is empty. */
export function entitiesOf(world: World, given: unknown, what = 'entities'): Entity[] {
  if (!Array.isArray(given) || given.length === 0) return no(`${what} is a list of entities, each a ref or a path: name at least one`);
  const out: Entity[] = [];
  for (const one of given) {
    const e = entityOf(world, one, what);
    if (out.includes(e)) return no(`${what}: ${pathOf(world, e)} is named twice`);
    out.push(e);
  }
  return out;
}

/** An override as the agent names it: `<at>: <handle>` -- `rider: Transform.px` -- or the handle alone at the root. */
export const handleOf = (i: Item): string => (i.path ? `${i.path}: ${i.what}` : i.what);

/**
 * One entity, whole, as `studio_state` answers it. `opened`: is it of the opened prefab's own instance, whose
 * overrides are its file's edits -- none said of it (the page's `PageContext.opened`); left out, none is.
 */
export function entityFacts(world: World, e: Entity, opened: (world: World, e: Entity) => boolean = () => false): EntityFacts {
  const slots = (component: AnyComponent): unknown[] => (world.rawStore(component) as { value: unknown[] }).value;
  const made = madeFrom(world, e);
  const facts: EntityFacts = {
    id: e,
    ref: world.ref(e),
    path: pathOf(world, e),
    name: world.has(e, Name) ? ((slots(Name)[e] as string | null) ?? null) : null,
    prefab: made?.prefab ?? null,
    node: made?.node ?? null,
    instance: made !== null && world.instanceRoot(e) === e,
    labels: world.has(e, Labels) ? [...((slots(Labels)[e] as string[] | null) ?? [])] : [],
    parent: null,
    layer: world.layerOfEntity(e),
    models: world.has(e, View) ? modelKeysOf(slots(View)[e] as Parameters<typeof modelKeysOf>[0]) : [],
    tags: [],
    off: [],
    components: {},
    objects: {},
    links: {},
  };
  const parent = (world.rawStore(Hierarchy) as { parent: ArrayLike<number> }).parent[e]!;
  if (parent !== NONE) facts.parent = parent;
  const all = made !== null && !opened(world, e) ? itemsOf(world, world.instanceRoot(e)) : null;
  // On a root, every item of the instance, each by `<at>: <handle>` -- what scene_override on it acts on, left to itself.
  const root = world.instanceRoot(e) === e;
  if (all) facts.overrides = (root ? all.items : itemsAt(world, all, e)).map((i): OverrideFacts => ({ at: i.path, what: root ? handleOf(i) : i.what, prefab: i.was, here: i.now, to: [...i.owners] }));
  for (const component of componentsOn(world, e)) {
    if (!world.enabled(e, component)) facts.off.push(component.name);
    if (component.kind === 'tag') facts.tags.push(component.name);
    else if (component.kind === 'object') {
      // View is the engine's own, drawn from Render (whose fields say the model): its keys are `models`, never an object of the entity's.
      if (component !== Name && component !== Labels && component !== View) facts.objects[component.name] = summarise(slots(component)[e]);
    } else if (component.kind === 'data') {
      const columns = world.rawStore(component) as Record<string, ArrayLike<number>>;
      const values: EntityFacts['components'][string] = {};
      for (const f of fileFields(component)) {
        // A vector under its one name, its numbers; flags their names, a list -- as a file writes them.
        if (f.field.vec !== undefined) {
          values[f.name] = f.columns.map((c) => columns[c.name]![e]!);
          continue;
        }
        if (f.field.flags) {
          values[f.name] = flagNames(f.field.flags, columns[f.name]![e]!);
          continue;
        }
        const field = f.columns[0]!;
        const value = columns[field.name]![e]!;
        if (component.schema[field.name]?.ref) {
          const to = value === NO_REF ? NONE : world.deref(value as EntityRef);
          values[field.name] = { ref: to !== NONE && world.alive(to) ? to : null };
          // A key field (`Render.model`) by its text -- the id is this page's alone -- with its uid where the asset has one:
          // `{ key, uid }`, as a file names it (Docs/asset-ids.md §3).
        } else {
          const kind = keyKindOf(component, field.name);
          const uid = kind === null ? undefined : uidOfField(kind, value, component, field.name).uid;
          const text = fieldPlain(component, field.name, value);
          // A mesh's `{ key, part, uid }`: the model, its part on its own (left out for the whole model), as its file writes it.
          const hash = typeof text === 'string' && component.schema[field.name]?.mesh ? text.indexOf('#') : -1;
          if (hash >= 0) values[field.name] = { key: (text as string).slice(0, hash), part: (text as string).slice(hash + 1), ...(uid === undefined ? {} : { uid }) };
          else values[field.name] = uid === undefined ? text : { key: text as string, uid };
        }
      }
      facts.components[component.name] = values;
    } else {
      const out = linksOf(world, e, component).out;
      if (out.length > 0) facts.links[component.name] = out.map((link) => ({ to: link.other, data: link.data }));
    }
  }
  return facts;
}
