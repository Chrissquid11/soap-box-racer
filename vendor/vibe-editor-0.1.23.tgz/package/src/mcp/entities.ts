/**
 * The scene's entities as tools (Docs/mcp.md §4, M2): each what the tree's menu, the inspector or the state line
 * does, through the same pieces of the editor -- `spawn.ts`' `duplicate`, `reparent.ts`' `moveRowsInPlace`, `multi.ts`'
 * `numbered`, `switches.ts`' switches and steps, the blocks' `switchable` -- with the same refusals, each ONE world
 * step labelled as the person's would be, prefixed `Claude: ` (`ctx.step`, which a `batch` puts off to its own).
 *
 * - **Reads**: `scene_query` (an AND of what is given, in the tree's order, paged) and `scene_entity` (one whole).
 * - **Entities are named by ref or path** everywhere (`facts.ts`' `entityOf`): a ref holds its generation, so one
 *   destroyed since names nothing -- the optimistic check every write makes.
 * - **The person's selection is never moved** by a write here (Docs/mcp.md §2 rule 5): `scene_select` alone sets it.
 * - **In an opened prefab** as the tree is there: nothing made or moved beside its root, where its Save could not keep it.
 */
import type { ComponentResult, CopyResult, DestroyResult, DuplicateResult, EntityResult, EntityRow, FlagsResult, MainCameraResult, McpCall, PasteResult, QueryResult, QueryRow, RelateResult, RenameResult, ReparentResult, SelectResult, UnrelateResult } from '@vibe/pipeline/agent-types';
import { allLayers, type AnyComponent, caseKey, Camera, componentsOn, dataSchema, isData, type Entity, fieldSchema, Hierarchy, inTreeOrder, Labels, layerName, linksOf, madeFrom, Name, NONE, type Relation, rootsOf, type Tag, View, WorldTransform } from '@vibe/engine';
import { internal, STATE, switchable } from '../blocks.ts';
import { moveRowsInPlace } from '../reparent.ts';
import { setMainCamera } from '../camera-entity.ts';
import { addLabels, labelRefusal, labelsOf, removeLabel } from '../labels.ts';
import { times } from '../multi.ts';
import { nameOf, renameAll } from '../names.ts';
import { openedParent } from '../opened.ts';
import { duplicate } from '../spawn.ts';
import { clipMiddle, copyRootsOf, readClip, type Clip } from '../clip.ts';
import { clipHandles, clipOf, copyHere, keepClip, pasteHere } from '../paste.ts';
import { SWITCHES, switchStep, tagsOf, type Switch } from '../switches.ts';
import { PENDING } from '../world-steps.ts';
import { childrenOf, entitiesOf, entityFacts, entityOf, no, pathOf, rowOf } from './facts.ts';
import type { PageContext } from './host.ts';

/** `scene_query`'s page, unless it asks for another: and at most. */
export const QUERY_PAGE = 50;
export const QUERY_MAX = 200;

/** An edit about to be made: one under way a step of its own first (not inside a batch, which did that once). */
const begin = (ctx: PageContext): void => {
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
};

/** An edit done: drawn, and the transcript told (a batch does that once, at its end). */
const done = (ctx: PageContext): void => {
  if (ctx.batching) return;
  ctx.host.changed();
  ctx.tell();
};

const parentOf = (ctx: PageContext, e: Entity): Entity => (ctx.world.rawStore(Hierarchy) as { parent: ArrayLike<number> }).parent[e]! as Entity;

/** The opened prefab's root, or NONE in the scene. */
const openedRoot = (ctx: PageContext): Entity => (ctx.host.opened?.() ? (ctx.host.openedRoot?.() ?? NONE) : NONE);

/** A component by its name, or refused with the names there are. */
function componentNamed(ctx: PageContext, name: unknown): AnyComponent {
  const found = ctx.world.allComponents.find((c) => c.name === name);
  if (!found) return no(`There is no component called ${String(name)}: scene_describe lists them`);
  return found;
}

/** Every entity alive, in the tree's order. */
function everyEntity(ctx: PageContext): Entity[] {
  const { world } = ctx;
  const out: Entity[] = [];
  const walk = (e: Entity): void => {
    out.push(e);
    for (const c of childrenOf(world, e)) walk(c);
  };
  for (const root of rootsOf(world)) if (world.alive(root)) walk(root);
  return out;
}

// ---------------------------------------------------------------- reads

/**
 * `scene_query`: entities by `name` (a part of it, any case; `exact` for the whole), `path` (exact, or everything
 * under it ending in `/`), `component`, `prefab`, `label`, `tag`, `layer` (number or name), `parent` (its children;
 * null, the roots) -- an AND of what is given -- in the tree's order, `limit` a page from `cursor`.
 */
export function sceneQuery(ctx: PageContext, call: McpCall): QueryResult {
  const { world } = ctx;
  const a = call.args;
  const tests: ((e: Entity) => boolean)[] = [];
  const nameOf = (e: Entity): string | null => (world.has(e, Name) ? ((world.rawStore(Name) as { value: (string | null)[] }).value[e] ?? null) : null);
  if (a.name !== undefined) {
    if (typeof a.name !== 'string') return no('name is text');
    const want = a.exact === true ? a.name : a.name.toLowerCase();
    tests.push((e) => {
      const n = nameOf(e);
      return n !== null && (a.exact === true ? n === want : n.toLowerCase().includes(want));
    });
  }
  if (a.path !== undefined) {
    if (typeof a.path !== 'string' || a.path === '') return no('path is names joined by /: big crate/rider, or big crate/ for all under it');
    const under = a.path.endsWith('/');
    tests.push((e) => (under ? pathOf(world, e).startsWith(a.path as string) : pathOf(world, e) === a.path));
  }
  if (a.component !== undefined) {
    const c = componentNamed(ctx, a.component);
    tests.push((e) => world.has(e, c));
  }
  if (a.prefab !== undefined) {
    if (typeof a.prefab !== 'string') return no('prefab is a prefab\'s key');
    const key = caseKey(a.prefab);
    tests.push((e) => madeFrom(world, e)?.prefab === key);
  }
  if (a.label !== undefined) {
    if (typeof a.label !== 'string') return no('label is text');
    tests.push((e) => world.has(e, Labels) && ((world.rawStore(Labels) as { value: (string[] | null)[] }).value[e] ?? []).includes(a.label as string));
  }
  if (a.tag !== undefined) {
    const tag = tagsOf(world).find((t) => t.name === a.tag);
    if (!tag) return no(`There is no tag ${String(a.tag)}: the tags are ${tagsOf(world).map((t) => t.name).join(', ') || 'none'}`);
    tests.push((e) => world.has(e, tag));
  }
  if (a.layer !== undefined) {
    const layer = layerOf(a.layer);
    tests.push((e) => world.layerOfEntity(e) === layer);
  }
  if (a.parent !== undefined) {
    const p = a.parent === null ? NONE : entityOf(world, a.parent, 'parent');
    tests.push((e) => parentOf(ctx, e) === p);
  }
  const limit = a.limit === undefined ? QUERY_PAGE : Number(a.limit);
  if (!Number.isInteger(limit) || limit < 1 || limit > QUERY_MAX) return no(`limit is 1 to ${QUERY_MAX}`);
  const from = a.cursor === undefined ? 0 : Number(a.cursor);
  if (!Number.isInteger(from) || from < 0) return no('cursor is the next an answer gave');
  const all = everyEntity(ctx).filter((e) => tests.every((t) => t(e)));
  const page = all.slice(from, from + limit);
  return {
    tool: 'scene_query',
    total: all.length,
    entities: page.map((e): QueryRow => {
      const made = madeFrom(world, e);
      return { ...rowOf(world, e), prefab: made?.prefab ?? null, node: made?.node ?? null, components: componentsOn(world, e).filter((c) => c !== WorldTransform && c !== Hierarchy && c.bit >= 0).map((c) => c.name) };
    }),
    next: from + limit < all.length ? String(from + limit) : null,
  };
}

/** A layer by number or name. */
function layerOf(given: unknown): number {
  if (typeof given === 'number' && Number.isInteger(given) && given >= 0 && given < 32) return given;
  if (typeof given === 'string') {
    const names = allLayers();
    const at = names.findIndex((n) => n !== undefined && n !== null && n.toLowerCase() === given.toLowerCase());
    if (at >= 0) return at;
    if (/^\d+$/.test(given) && Number(given) < 32) return Number(given);
  }
  const named = allLayers().map((n, i) => (n ? `${i} ${n}` : null)).filter((n) => n !== null);
  return no(`layer is 0 to 31, or a layer's name${named.length > 0 ? `: ${named.join(', ')}` : ''} -- not ${JSON.stringify(given)}`);
}

/** `scene_entity`: one entity whole -- `studio_state`'s row, its children, its links both ways, object components by their save shape. */
export function sceneEntity(ctx: PageContext, call: McpCall): EntityResult {
  const { world } = ctx;
  const e = entityOf(world, call.args.entity);
  const facts = entityFacts(world, e, ctx.opened);
  const saved: Record<string, unknown> = {};
  const relations: EntityResult['entity']['relations'] = {};
  for (const component of world.allComponents) {
    if (component.kind === 'object' && world.has(e, component) && component !== View && component.save) {
      try {
        saved[component.name] = component.save((world.rawStore(component) as { value: unknown[] }).value[e]);
      } catch {
        // Not saved as it is: summarised in `objects` alone.
      }
    }
    if (component.kind !== 'relation') continue;
    const links = linksOf(world, e, component);
    if (links.out.length === 0 && links.into.length === 0) continue;
    relations[component.name] = {
      out: links.out.map((l) => ({ to: rowOf(world, l.other), data: l.data })),
      into: links.into.map((l) => ({ from: rowOf(world, l.other), data: l.data })),
    };
  }
  // Each numeric component's fields' schema: what scene_set takes for each (Docs/properties.md §4).
  const schema: EntityResult['entity']['schema'] = {};
  for (const component of componentsOn(world, e)) {
    if (component.kind === 'data') schema[component.name] = fieldSchema(component);
    else if (isData(component)) schema[component.name] = dataSchema(component);
  }
  return { tool: 'scene_entity', entity: { ...facts, children: childrenOf(world, e).map((c) => rowOf(world, c)), saved, relations, schema } };
}

// ---------------------------------------------------------------- writes

/** `scene_destroy`: each named, and everything under it -- as the tree's Destroy. Never the opened prefab's root. */
export function sceneDestroy(ctx: PageContext, call: McpCall): DestroyResult {
  const { world } = ctx;
  const es = entitiesOf(world, call.args.entities);
  const root = openedRoot(ctx);
  if (es.includes(root)) return no(`${pathOf(world, root)} is the root of the prefab open: Back (scene_close_prefab) instead`);
  const rows = es.map((e) => rowOf(world, e));
  begin(ctx);
  const before = everyEntity(ctx).length;
  // One under another goes with it either way: destroying it twice is nothing.
  for (const e of es) if (world.alive(e)) world.destroy(e);
  world.flush();
  const count = before - everyEntity(ctx).length;
  const step = ctx.step(call, es.length > 1 ? `Destroy ${es.length}` : 'Destroy') ?? 'none';
  done(ctx);
  return { tool: 'scene_destroy', destroyed: rows, count, step };
}

/** `scene_duplicate`: a copy of the entity where it is -- an instance's root a whole instance again -- as the tree's Duplicate. */
export function sceneDuplicate(ctx: PageContext, call: McpCall): DuplicateResult {
  const { world } = ctx;
  const e = entityOf(world, call.args.entity);
  if (e === openedRoot(ctx)) return no(`${pathOf(world, e)} is the root of the prefab open: a copy would be beside it, where its Save could not keep it`);
  begin(ctx);
  const copy = duplicate(world, e);
  if (copy === NONE) return no('The world is full: nothing was made');
  const step = ctx.step(call, 'Duplicate') ?? 'none';
  done(ctx);
  return { tool: 'scene_duplicate', of: rowOf(world, e), copy: rowOf(world, copy), step };
}

/** The clip's text in `scene_copy`'s answer, at most: past it, the handle alone -- a tool's answer is cut at 88,000 characters. */
export const CLIP_TEXT_MAX = 40_000;

/**
 * `scene_copy`: the entities, each with everything under it, as the tree's Copy makes its clip -- nothing changed. The
 * clip kept page-side (`paste.ts`' `keepClip`), the person's clipboard untouched: its handle, for `scene_paste`; its
 * text too while it is short enough to answer whole.
 */
export function sceneCopy(ctx: PageContext, call: McpCall): CopyResult {
  const { world } = ctx;
  const roots = copyRootsOf(world, entitiesOf(world, call.args.entities));
  const clip = copyHere(world, roots);
  const text = JSON.stringify(clip);
  const handle = keepClip(clip);
  return { tool: 'scene_copy', roots: roots.map((e) => rowOf(world, e)), count: clip.entities.length, handle, size: text.length, ...(text.length <= CLIP_TEXT_MAX ? { clip: text } : {}) };
}

/** The clip `scene_paste` names: a handle `scene_copy` answered, or a clip's text (what the person copied and handed over). */
function clipAsked(call: McpCall): Clip {
  const { handle, clip: text } = call.args;
  if (typeof handle === 'string' && text !== undefined) return no('Give handle or clip, not both');
  if (typeof handle === 'string') {
    const kept = clipOf(handle);
    if (kept === undefined) {
      const there = clipHandles();
      return no(`There is no clip ${handle}${there.length > 0 ? `: the clips kept are ${there.join(', ')}` : ': none is kept -- the page reloaded since, or scene_copy made none'}. Copy again with scene_copy`);
    }
    return kept;
  }
  if (typeof text !== 'string') return no('handle is what scene_copy answered; or clip, the JSON the editor\'s Copy puts on the clipboard');
  const read = readClip(text);
  if (typeof read === 'string') return no(`Nothing to paste: ${read.replace(/^the clipboard holds/, 'clip holds')}`);
  return read;
}

/**
 * `scene_paste`: a clip made in the world, as the tree's Paste (`edits.ts`' `pasteClip`): through the same
 * `pasteHere` -- its middle at `at`, else where it was copied; its refs out kept if it came from this world; under the
 * opened prefab's root, as a `scene_create` with no parent goes. One step.
 */
export function scenePaste(ctx: PageContext, call: McpCall): PasteResult {
  const { world } = ctx;
  const clip = clipAsked(call);
  const asked = call.args.at as { x?: unknown; z?: unknown } | undefined;
  if (asked !== undefined && (typeof asked !== 'object' || asked === null || typeof asked.x !== 'number' || typeof asked.z !== 'number')) return no('at is { x, z }: where the clip\'s middle goes across the ground');
  const at = asked !== undefined ? { x: asked.x as number, z: asked.z as number } : clipMiddle(clip);
  begin(ctx);
  const pasted = pasteHere(world, clip, at, openedRoot(ctx));
  if (pasted.all.length === 0) return no(`Nothing was pasted${pasted.skipped.length > 0 ? `: this build lacks ${pasted.skipped.join(', ')}` : ': the world is full'}`);
  const step = ctx.step(call, pasted.all.length === 1 ? 'Paste' : `Paste ${pasted.all.length}`) ?? 'none';
  done(ctx);
  return { tool: 'scene_paste', roots: pasted.roots.map((e) => rowOf(world, e)), count: pasted.all.length, skipped: pasted.skipped, step };
}

/**
 * `scene_reparent`: the entities under `parent` (null: the roots -- in an opened prefab, under its root) in front of
 * `before` (left out: last), together in the tree's order, as a drag in the tree: `Reparent`, `Unparent`, `Reorder`.
 */
export function sceneReparent(ctx: PageContext, call: McpCall): ReparentResult {
  const { world } = ctx;
  const es = entitiesOf(world, call.args.entities);
  const root = openedRoot(ctx);
  if (es.includes(root)) return no(`${pathOf(world, root)} is the root of the prefab open: it stays where it is`);
  const asked = call.args.parent;
  let parent = asked === undefined || asked === null ? NONE : entityOf(world, asked, 'parent');
  // Beside the opened prefab's root it would be in no prefab: under it, as the tree puts what is dropped there.
  if (parent === NONE && root !== NONE) parent = openedParent(world, root, []);
  const before = call.args.before === undefined || call.args.before === null ? NONE : entityOf(world, call.args.before, 'before');
  if (before !== NONE && parentOf(ctx, before) !== parent) return no(`before: ${pathOf(world, before)} is not ${parent === NONE ? 'a root' : `a child of ${pathOf(world, parent)}`}`);
  for (const e of es) {
    for (let a = parent; a !== NONE; a = parentOf(ctx, a)) if (a === e) return no(`${pathOf(world, e)} cannot go under ${pathOf(world, parent)}: it is under it`);
  }
  begin(ctx);
  const already = es.every((c) => parentOf(ctx, c) === parent);
  // Each where it is in the world unless `keepWorld: false` (its Transform kept, now under the new parent).
  const moving = moveRowsInPlace(world, es, parent, before, call.args.keepWorld !== false);
  if (moving.length === 0) return no('Nothing to move: they are where they would go');
  const what = already ? 'Reorder' : parent === NONE ? 'Unparent' : 'Reparent';
  const step = ctx.step(call, moving.length > 1 ? `${what} ${moving.length}` : what) ?? 'none';
  done(ctx);
  return { tool: 'scene_reparent', moved: moving.map((e) => rowOf(world, e)), parent: parent === NONE ? null : rowOf(world, parent), before: before === NONE ? null : rowOf(world, before), step };
}

/** `scene_rename`: one name -- several numbered in the order named (`wall`, `wall 2`), as the inspector's title; "" takes it off. */
export function sceneRename(ctx: PageContext, call: McpCall): RenameResult {
  const { world } = ctx;
  const es = entitiesOf(world, call.args.entities);
  const text = call.args.name;
  if (typeof text !== 'string' || text.length > 200) return no('name is text ("" takes the name off)');
  const was = es.map((e) => (world.has(e, Name) ? nameOf(world, e) : null));
  begin(ctx);
  // The title's own rename (`names.ts`): trimmed, numbered, nothing written when every name is so already.
  if (!renameAll(world, es, text)) return { tool: 'scene_rename', renamed: es.map((e, i) => ({ ...rowOf(world, e), was: was[i]! })), step: null };
  const step = ctx.step(call, times('Rename', es.length));
  done(ctx);
  return { tool: 'scene_rename', renamed: es.map((e, i) => ({ ...rowOf(world, e), was: was[i]! })), step };
}

/**
 * `scene_component`: `add`, `remove`, `enable` or `disable` a component on the entities -- as the inspector's adder,
 * its × and its box -- with their refusals: a tag (scene_flags), a relation (scene_relate), the world's own (View,
 * Hierarchy, WorldTransform, anything transient), the switches and labels (scene_flags); one the box cannot switch.
 */
export function sceneComponent(ctx: PageContext, call: McpCall): ComponentResult {
  const { world } = ctx;
  const es = entitiesOf(world, call.args.entities);
  const verb = call.args.verb;
  if (verb !== 'add' && verb !== 'remove' && verb !== 'enable' && verb !== 'disable') return no('verb is add, remove, enable or disable');
  const c = componentNamed(ctx, call.args.component);
  if (c.kind === 'tag') return no(`${c.name} is a tag: scene_flags puts it on or takes it off`);
  if (c.kind === 'relation') return no(`${c.name} is a relation: scene_relate and scene_unrelate make and cut its links`);
  if (c === View) return no('View is the engine\'s own, drawn from Render: add Render, and set Render.model');
  if (c.bit < 0 || internal(c) || c === Hierarchy || c === WorldTransform) return no(`${c.name} is the world's own: every entity has it, or the world works it out`);
  if (STATE.includes(c)) return no(`${c.name} is the state line's: scene_flags (hidden, disabled, labels)`);
  let did: Entity[];
  if (verb === 'add') {
    did = es.filter((e) => !world.has(e, c));
    begin(ctx);
    for (const e of did) world.add(e, c);
  } else if (verb === 'remove') {
    did = es.filter((e) => world.has(e, c));
    begin(ctx);
    for (const e of did) world.remove(e, c);
  } else {
    if (!switchable(world, c, es)) return no(`${c.name} cannot be switched ${verb === 'enable' ? 'on' : 'off'} here, as the inspector has no box for it: ${c.kind === 'object' ? 'an object with no save shape -- switched off, it would not last' : 'it is the world\'s own'}`);
    const want = verb === 'enable';
    const having = es.filter((e) => world.has(e, c));
    if (having.length === 0) return no(`None of them has ${c.name}: scene_component add puts it on`);
    did = having.filter((e) => world.enabled(e, c) !== want);
    begin(ctx);
    for (const e of did) world.enable(e, c, want);
  }
  const label = `${verb === 'add' ? 'Add' : verb === 'remove' ? 'Remove' : verb === 'enable' ? 'Enable' : 'Disable'} ${c.name}`;
  const step = did.length === 0 ? null : ctx.step(call, times(label, did.length));
  done(ctx);
  return { tool: 'scene_component', verb, component: c.name, done: did.map((e) => rowOf(world, e)), step };
}

/**
 * `scene_flags`: the state line, for every entity named -- `hidden`, `disabled`, `unpickable` set (true or false, not
 * flipped), the `layer` (number or name), tags and labels added or taken off -- ONE step.
 */
export function sceneFlags(ctx: PageContext, call: McpCall): FlagsResult {
  const { world } = ctx;
  const es = entitiesOf(world, call.args.entities);
  const a = call.args;
  const changed: string[] = [];
  const plan: (() => void)[] = [];
  for (const which of ['hidden', 'disabled', 'unpickable'] as const satisfies readonly Switch[]) {
    const v = a[which];
    if (v === undefined) continue;
    if (typeof v !== 'boolean') return no(`${which} is true or false`);
    const { tag } = SWITCHES[which];
    const flip = es.filter((e) => world.has(e, tag) !== v);
    if (flip.length === 0) continue;
    changed.push(switchStep(which, v, flip.length));
    plan.push(() => {
      for (const e of flip) (v ? world.add(e, tag) : world.remove(e, tag));
    });
  }
  if (a.layer !== undefined) {
    const layer = layerOf(a.layer);
    const moved = es.filter((e) => world.layerOfEntity(e) !== layer);
    if (moved.length > 0) {
      changed.push(times(`Layer → ${layerName(layer)}`, moved.length));
      plan.push(() => {
        for (const e of moved) world.setLayer(e, layer);
      });
    }
  }
  const lists = (field: 'tags' | 'labels'): { add: string[]; remove: string[] } => {
    const v = a[field];
    if (v === undefined) return { add: [], remove: [] };
    const o = v as { add?: unknown; remove?: unknown };
    const strings = (x: unknown, w: string): string[] => {
      if (x === undefined) return [];
      if (!Array.isArray(x) || x.some((s) => typeof s !== 'string' || s === '')) return no(`${field}.${w} is a list of names`);
      return x as string[];
    };
    if (typeof v !== 'object' || v === null) return no(`${field} is { add, remove }, lists of names`);
    return { add: strings(o.add, 'add'), remove: strings(o.remove, 'remove') };
  };
  const tags = lists('tags');
  const all = tagsOf(world);
  const tagNamed = (n: string): Tag => (all.find((t) => t.name === n) as Tag | undefined) ?? no(`There is no tag ${n}: the tags are ${all.map((t) => t.name).join(', ') || 'none'} (hidden, disabled, unpickable are their own)`);
  for (const n of tags.add) {
    const tag = tagNamed(n);
    const on = es.filter((e) => !world.has(e, tag));
    if (on.length === 0) continue;
    changed.push(times(`Add ${tag.name}`, on.length));
    plan.push(() => {
      for (const e of on) world.add(e, tag);
    });
  }
  for (const n of tags.remove) {
    const tag = tagNamed(n);
    const off = es.filter((e) => world.has(e, tag));
    if (off.length === 0) continue;
    changed.push(times(`Remove ${tag.name}`, off.length));
    plan.push(() => {
      for (const e of off) world.remove(e, tag);
    });
  }
  const labels = lists('labels');
  // What the labels' field would make, and nothing else: trimmed, not empty, no comma (`labels.ts`).
  for (const l of labels.add) {
    const why = labelRefusal(l);
    if (why !== null) return no(`labels.add: ${why}`);
  }
  for (const l of labels.add) {
    const on = es.filter((e) => !labelsOf(world, e).includes(l));
    if (on.length === 0) continue;
    changed.push(times(`Add label ${l}`, on.length));
    plan.push(() => addLabels(world, on, [l]));
  }
  for (const l of labels.remove) {
    const off = es.filter((e) => labelsOf(world, e).includes(l));
    if (off.length === 0) continue;
    changed.push(times(`Remove label ${l}`, off.length));
    plan.push(() => removeLabel(world, off, l));
  }
  if (plan.length === 0) return { tool: 'scene_flags', entities: es.map((e) => rowOf(world, e)), changed: [], step: null };
  begin(ctx);
  for (const run of plan) run();
  const step = ctx.step(call, changed.length === 1 ? changed[0]! : changed.join(', '));
  done(ctx);
  return { tool: 'scene_flags', entities: es.map((e) => rowOf(world, e)), changed, step };
}

/** A relation by its name, or refused with those there are. */
function relationNamed(ctx: PageContext, name: unknown): Relation<any> {
  const all = ctx.world.allComponents.filter((c) => c.kind === 'relation');
  const found = all.find((c) => c.name === name);
  if (!found) return no(`There is no relation ${String(name)}: the relations are ${all.map((r) => r.name).join(', ') || 'none'}`);
  return found as Relation<any>;
}

/** `scene_relate`: a link from `entity` to `target` -- as "Link to…" then a click -- its data set as the link's fields. */
export function sceneRelate(ctx: PageContext, call: McpCall): RelateResult {
  const { world } = ctx;
  const e = entityOf(world, call.args.entity);
  const relation = relationNamed(ctx, call.args.relation);
  const target = entityOf(world, call.args.target, 'target');
  if (target === e) return no('An entity is not linked to itself: name another target');
  const data = call.args.data;
  if (data !== undefined && (typeof data !== 'object' || data === null || Array.isArray(data))) return no('data is { field: number }');
  const fields = Object.entries((data ?? {}) as Record<string, unknown>);
  for (const [f, v] of fields) {
    if (!relation.fields.some((x) => x.name === f)) return no(`${relation.name} has no field ${f}: it has ${relation.fields.map((x) => x.name).join(', ') || 'none'}`);
    if (typeof v !== 'number' || !Number.isFinite(v)) return no(`${relation.name}.${f} is a number`);
  }
  if (linksOf(world, e, relation).out.some((l) => l.other === target)) return no(`${pathOf(world, e)} is linked to ${pathOf(world, target)} by ${relation.name} already: scene_entity shows the link's data`);
  begin(ctx);
  const row = world.relate(e, relation, target);
  if (row === 0) return no(`${relation.name} would not take the link`);
  const rows = world.rawStore(relation) as Record<string, { [i: number]: number }>;
  for (const [f, v] of fields) rows[f]![row] = v as number;
  const step = ctx.step(call, `Link ${relation.name}`) ?? 'none';
  done(ctx);
  const link = linksOf(world, e, relation).out.find((l) => l.other === target);
  return { tool: 'scene_relate', relation: relation.name, from: rowOf(world, e), to: rowOf(world, target), data: link?.data ?? {}, step };
}

/** `scene_unrelate`: the link from `entity` to `target` cut -- the inspector's ×. */
export function sceneUnrelate(ctx: PageContext, call: McpCall): UnrelateResult {
  const { world } = ctx;
  const e = entityOf(world, call.args.entity);
  const relation = relationNamed(ctx, call.args.relation);
  const target = entityOf(world, call.args.target, 'target');
  if (!linksOf(world, e, relation).out.some((l) => l.other === target)) return no(`${pathOf(world, e)} has no ${relation.name} link to ${pathOf(world, target)}`);
  const from = rowOf(world, e);
  const to = rowOf(world, target);
  begin(ctx);
  world.unrelate(e, relation, target);
  const step = ctx.step(call, `Cut ${relation.name}`) ?? 'none';
  done(ctx);
  return { tool: 'scene_unrelate', relation: relation.name, from, to, step };
}

/**
 * `scene_main_camera`: the camera the game draws through -- its `main` on, as the notice's "Make <name> main" -- and
 * every other camera's off, so there is one: ONE step.
 */
export function sceneMainCamera(ctx: PageContext, call: McpCall): MainCameraResult {
  const { world } = ctx;
  const e = entityOf(world, call.args.entity);
  if (!world.has(e, Camera)) return no(`${pathOf(world, e)} has no Camera: scene_create kind camera makes one`);
  begin(ctx);
  // The notice's Make <name> main, without its selecting (`camera-entity.ts`): every other camera's off with it.
  const was = setMainCamera(world, e).map((x) => rowOf(world, x));
  const step = ctx.step(call, 'Set Camera.main');
  done(ctx);
  return { tool: 'scene_main_camera', camera: rowOf(world, e), was, step };
}

/** `scene_select`: the person's selection, set -- only when they asked for it; an empty list clears it. */
export function sceneSelect(ctx: PageContext, call: McpCall): SelectResult {
  const { world, host } = ctx;
  if (!host.select) return no('The editor here has no selection to set');
  const given = call.args.entities;
  if (!Array.isArray(given)) return no('entities is a list of refs or paths ([] clears the selection)');
  const es = given.length === 0 ? [] : entitiesOf(world, given);
  host.select(inTreeOrder(world, es));
  host.changed();
  return { tool: 'scene_select', selected: host.selection().filter((x) => world.alive(x)).map((x) => rowOf(world, x)) };
}

/** Each entity of a list as answers name it. */
export const rowsOf = (ctx: PageContext, es: readonly Entity[]): EntityRow[] => es.map((e) => rowOf(ctx.world, e));
