/**
 * The studio area's page tool (Docs/mcp.md §4): `studio_state` -- what is open in this tab, the editor's tab shown,
 * the scene and whether it is saved, the prefab open to edit, the playtest -- and the selection, each entity whole
 * (the first `SELECTION_MAX`). The server adds the problems count and the jobs. A read: it answers in a playtest too.
 */
import type { McpCall, SelectionResult, StudioContextResult } from '@vibe/pipeline/agent-types';
import { entityFacts, no, SELECTION_MAX } from './facts.ts';
import type { PageContext } from './host.ts';

/** `studio_state`: what is open, and the selection whole. */
export function studioState(ctx: PageContext, _call?: McpCall): SelectionResult {
  const { world, host } = ctx;
  const alive = host.selection().filter((e) => world.alive(e));
  const playtest = host.playtest?.() ?? (host.state() === 'playtest' ? 'running' : 'none');
  return {
    tool: 'studio_state',
    tab: host.tab?.() ?? null,
    scene: host.scene(),
    prefab: host.opened?.() ?? null,
    playtest,
    selected: alive.length,
    entities: alive.slice(0, SELECTION_MAX).map((e) => entityFacts(world, e, ctx.opened)),
  };
}

/** `studio_context` (Docs/terminal.md D8): what a column turn is told of the editor, the host's `gather(true)` -- the server words it. */
export function studioContext(ctx: PageContext, _call?: McpCall): StudioContextResult {
  const context = ctx.host.context?.();
  if (!context) return no('this editor does not say its context');
  return { tool: 'studio_context', context };
}
