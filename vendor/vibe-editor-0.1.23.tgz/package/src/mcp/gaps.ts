/**
 * The actions a person has in the editor that no MCP tool does (Docs/skills.md §9 S2): each a `{ none }` declaration
 * (`declare.ts`), named here once so every place that offers it says the same, and the list S5 gives tools to is this
 * file. `GAPS` are actions still to get a tool (none since S5); `NOT_FOR_CLAUDE` are none by design -- the person's
 * own control of Claude, their drawing for it, their debugging -- and stay so.
 *
 * Nothing at module level but constants.
 */

/**
 * Actions on the project with no tool yet: S5 gave each of its list a tool, and it is empty (Docs/skills.md §9 S5). A
 * new action with no tool is a gap here, named at its site and written in §9 -- until its tool lands.
 */
export const GAPS = {} as const;

/** None by design: the person's own, never Claude's. */
export const NOT_FOR_CLAUDE = {
  askClaude: { none: 'asks Claude itself (a turn of Claude\'s): Claude does the work in that turn, it never asks itself' },
  codeFiles: { none: 'makes a file anew -- New File, New Folder, Duplicate, Save As, a copy dragged -- in the Code card\'s tree: Claude\'s own Write makes a file (an asset\'s copy is asset_copy); moving and deleting are code_move and code_delete' },
  codeEdit: { none: 'writes a file\'s text (the code, CLAUDE.md, a skill): Claude\'s own Edit and Write do it, no studio tool' },
  claudeControl: { none: 'the person\'s own control of Claude -- Send, Stop, the permission level, a conversation: never Claude\'s to take' },
  paintCanvas: { none: 'paints a canvas, the person\'s drawing for Claude: Claude reads canvases, never paints them' },
  debugger: { none: 'the person\'s debugging -- a breakpoint set, the Debugger window opened, the game stopped and stepped there: a breakpoint stops the game for the person, in a window of its own, and a stopped game answers no tool; Claude reads the code, runs the tests and reads the console instead' },
} as const;
