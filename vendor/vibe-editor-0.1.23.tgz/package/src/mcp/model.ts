/**
 * The Model tab's tools, the page's half (Docs/mcp.md §4's Model tab, M6): each through the tab's own doings, handed
 * over on the host (`PageHost.model`, `model/model-agent.ts`) -- Open in Model tab, the Parameters block's drag, let
 * go and Bake, the Materials block's let go, K, Build -- each write one step of the tab's own history, its files the
 * turn's. `model_preview`'s image is `view_shot`'s model target (`PageHost.views`), the preview put away after.
 *
 * Pure over the host: node tests it (`model/model-tools.test.ts`).
 */
import type { McpCall, ModelFacts, ModelExportResult, ModelInfoResult, ModelMaterialsSetResult, ModelOpenResult, ModelParamsSetResult, ModelPoseResult, ModelPreviewResult } from '@vibe/pipeline/agent-types';
import { no } from './facts.ts';
import type { ModelFieldValue, ModelJoint, PageContext, PageModel } from './host.ts';
import { SHOT_MAX } from '../view-shot.ts';

const modelOf = (ctx: PageContext): PageModel => ctx.host.model?.() ?? no('This studio has no Model tab');
/** A tool's answer from the agent's: its problem refused, in its words. */
const done = <T extends object>(r: T | { problem: string }): T => ('problem' in r ? no(r.problem) : r);

/** Values as text, as the blocks write them: a number or a yes or no said as its text; null kept where allowed. */
function valuesOf(raw: unknown, nulls: boolean): Record<string, string | null> {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) return no('values is an object of parameter names and their values');
  const out: Record<string, string | null> = {};
  for (const [name, v] of Object.entries(raw as Record<string, unknown>)) {
    if (v === null && nulls) out[name] = null;
    else if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') out[name] = String(v);
    else return no(`values.${name} is a number, a string, true or false${nulls ? ', or null for its default' : ''}`);
  }
  return out;
}

/** `model_open`. */
export async function modelOpen(ctx: PageContext, call: McpCall): Promise<ModelOpenResult> {
  const model = modelOf(ctx);
  if (typeof call.args.script !== 'string') return no('script is a .lua under AssetsSource/models/');
  const r = done(await model.open(call.args.script, call.args.discard === true));
  const facts = await model.facts();
  if (!facts) return no(`${call.args.script} did not open`);
  return { tool: 'model_open', model: facts, discarded: r.discarded };
}

/** `model_info`. */
export async function modelInfo(ctx: PageContext, _call?: McpCall): Promise<ModelInfoResult> {
  return { tool: 'model_info', model: await modelOf(ctx).facts() };
}

/** `model_params_set`: the drag and its let go, or Bake -- one step of the tab's history. */
export async function modelParamsSet(ctx: PageContext, call: McpCall): Promise<ModelParamsSetResult> {
  const model = modelOf(ctx);
  const values = valuesOf(call.args.values, true);
  if (Object.keys(values).length === 0) return no('values names no parameter');
  const bake = call.args.bake === true;
  const r = done(await model.setParams(values, bake));
  const after = await settledParams(model, values, bake);
  return { tool: 'model_params_set', step: r.label, baked: r.baked, skipped: r.skipped, params: after?.params ?? null, files: r.files };
}

/**
 * The parameters after a write, once `GET params` says it: the index sees the record's write a moment after the step,
 * so they are read again until each value written reads back -- set (or back to its default), or baked -- for a second
 * or two at most; then as they read.
 */
async function settledParams(model: PageModel, values: Readonly<Record<string, string | null>>, bake: boolean): Promise<ModelFacts | null> {
  const same = (a: unknown, b: string): boolean => String(a) === b || Number(a) === Number(b);
  let facts: ModelFacts | null = null;
  for (let i = 0; i < 15; i++) {
    facts = await model.facts();
    const params = facts?.params ?? [];
    const landed = Object.entries(values).every(([name, v]) => {
      const p = params.find((x) => x.name === name);
      if (!p) return true;
      if (bake) return !p.set && (v === null || same(p.default, v));
      return v === null ? !p.set : p.set && same(p.value, v);
    });
    if (landed) return facts;
    await new Promise((resolve) => setTimeout(resolve, 150));
  }
  return facts;
}

/** `model_preview`: a preview build at these values shown, its image taken, the export shown again -- nothing written. */
export async function modelPreview(ctx: PageContext, call: McpCall): Promise<ModelPreviewResult> {
  const model = modelOf(ctx);
  const views = ctx.host.views ?? no('This studio has no view to draw an image of');
  if (model.path() === null) return no('No model is open in the Model tab: model_open opens one');
  const values = call.args.values === undefined ? {} : (valuesOf(call.args.values, false) as Record<string, string>);
  const width = call.args.width;
  if (width !== undefined && (typeof width !== 'number' || !Number.isInteger(width) || width < 16 || width > SHOT_MAX)) return no(`width is a whole number of pixels, 16 to ${SHOT_MAX}`);
  const format = call.args.format ?? 'webp';
  if (format !== 'webp' && format !== 'png') return no('format is webp or png');
  const why = await model.preview(values);
  if (why !== null) return no(`No preview: ${why}`);
  try {
    const shot = await views.shot({ target: 'model', camera: null, width: (width as number | undefined) ?? null, height: null, overlays: false, format });
    return { tool: 'model_preview', params: values, width: shot.width, height: shot.height, mimeType: shot.mimeType, data: shot.data, notes: shot.notes };
  } finally {
    model.unpreview();
  }
}

/** `model_export`: Build, its jobs queued; the server follows them as one studio job. */
export async function modelExport(ctx: PageContext, _call?: McpCall): Promise<ModelExportResult> {
  const model = modelOf(ctx);
  const r = done(await model.export());
  return { tool: 'model_export', script: model.path()!, jobs: r.jobs, job: null };
}

/** `model_materials_set`: the Materials block's let go -- one step. */
export async function modelMaterialsSet(ctx: PageContext, call: McpCall): Promise<ModelMaterialsSetResult> {
  const model = modelOf(ctx);
  const name = call.args.material;
  if (typeof name !== 'string' || name === '') return no('material names a material{} of the script');
  const fields = call.args.fields;
  if (typeof fields !== 'object' || fields === null || Array.isArray(fields) || Object.keys(fields).length === 0) return no('fields is an object of the fields to set');
  const set: Record<string, ModelFieldValue> = {};
  for (const [field, v] of Object.entries(fields as Record<string, unknown>)) {
    const colour = Array.isArray(v) && v.length === 3 && v.every((n) => typeof n === 'number' && Number.isFinite(n));
    if (v !== null && typeof v !== 'number' && typeof v !== 'string' && !colour) return no(`fields.${field} is a number, a word or a path, [r, g, b], or null to take it out`);
    set[field] = colour ? [(v as number[])[0]!, (v as number[])[1]!, (v as number[])[2]!] : (v as ModelFieldValue);
  }
  const r = done(await model.setMaterial(name, set));
  return { tool: 'model_materials_set', step: r.label, material: name, files: r.files };
}

/** `model_pose`: K -- the joints keyed into the clip's action, one step. */
export async function modelPose(ctx: PageContext, call: McpCall): Promise<ModelPoseResult> {
  const model = modelOf(ctx);
  const { clip, time, frame, joints } = call.args as { clip?: unknown; time?: unknown; frame?: unknown; joints?: unknown };
  if (typeof clip !== 'string' || clip === '') return no('clip names an action{} of the script');
  if (time !== undefined && (typeof time !== 'number' || !Number.isFinite(time) || time < 0)) return no('time is seconds, 0 or more');
  if (frame !== undefined && (typeof frame !== 'number' || !Number.isInteger(frame) || frame < 0)) return no('frame is a whole number, 0 or more');
  if (typeof joints !== 'object' || joints === null || Array.isArray(joints)) return no('joints is an object of joint names and their pose');
  const list: Record<string, ModelJoint> = {};
  const num = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
  for (const [joint, raw] of Object.entries(joints as Record<string, unknown>)) {
    const j = raw as Record<string, unknown> | null;
    if (typeof j !== 'object' || j === null) return no(`joints.${joint} is { forward, left, twist, translate }`);
    const one: ModelJoint = {};
    for (const k of ['forward', 'left', 'twist'] as const) {
      if (j[k] === undefined) continue;
      if (!num(j[k])) return no(`joints.${joint}.${k} is degrees, a number`);
      one[k] = j[k];
    }
    if (j.translate !== undefined) {
      if (!Array.isArray(j.translate) || j.translate.length !== 3 || !j.translate.every(num)) return no(`joints.${joint}.translate is [x, y, z] in metres`);
      one.translate = [j.translate[0], j.translate[1], j.translate[2]];
    }
    list[joint] = one;
  }
  const r = done(await model.pose(clip, { ...(time !== undefined ? { time: time as number } : {}), ...(frame !== undefined ? { frame: frame as number } : {}) }, list));
  return { tool: 'model_pose', step: r.label, note: r.note, clip, time: r.time, files: r.files };
}
