/**
 * The asset tools' page half (Docs/mcp.md §4's assets, D2, M3): each asset write run as the Assets panel's own step
 * (`assets/ui/agent-assets.ts`' `AgentAssets`, which the panel sets as it is made) -- the same flow as its menu, drag
 * or block, on the same history, so Z in the panel undoes Claude's change -- and answered with what it did and the
 * files it touched (`files`, which Undo this turn puts back).
 *
 * - **No panel made in this tab** (`NoPanel`): the dispatcher answers `nopanel`, and the dev server runs the tool instead
 *   (the routes' work in-process): one tool, two paths, chosen as it is called.
 * - **A refusal is the panel's words**, as its bar would say them.
 */
import type {
  AssetCopyResult, AssetDeleteResult, AssetExportResult, AssetMoveResult, AssetNewResult, AssetOptionsResult, AssetRestoreResult, McpCall, MaterialSetResult, PhysmatSetResult, ModelAdoptResult,
  PrefabEditResult,
} from '@vibe/pipeline/agent-types';
import { caseKey } from '@vibe/engine';
import { assetsForAgent, type AgentAssets } from '../assets/ui/agent-assets.ts';
import { no } from './facts.ts';

/** This tab has no Assets panel made: the dispatcher answers `nopanel` (before any step), and the dev server runs the call. */
export class NoPanel extends Error {}

/** The panel's edits, or `NoPanel`. */
function panel(): AgentAssets {
  const a = assetsForAgent();
  if (!a) throw new NoPanel('no Assets panel in this tab');
  return a;
}

/** The panel's flow run, its refusal the tool's in the panel's words. */
async function refusing<T>(run: () => Promise<T>): Promise<T> {
  try {
    return await run();
  } catch (err) {
    if (err instanceof NoPanel) throw err;
    return no(err instanceof Error ? err.message : String(err));
  }
}

/** A project-relative path as given: `/` between parts, no leading `./` or trailing `/`. */
function pathOf(raw: unknown, what = 'path'): string {
  if (typeof raw !== 'string' || raw.trim() === '') return no(`${what} is a project-relative path: src/assets/models/props/crate.glb`);
  const path = raw.trim().replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '');
  if (path.startsWith('/') || path.split('/').includes('..')) return no(`${what}: ${raw} -- a path in the project, relative to its root`);
  return path;
}

/** One path or several, as given. */
const pathsOf = (raw: unknown, what = 'paths'): string[] => [...new Set((Array.isArray(raw) ? raw : [raw]).map((p) => pathOf(p, what)))];

/** The paths an answer moved, from and to. */
const movedIn = (answers: readonly unknown[]): Array<[string, string]> => answers.flatMap((a) => (a as { moved?: Array<[string, string]> } | null)?.moved ?? []);

/** `asset_new`: as the New menu makes it. */
export function assetNew(_ctx: unknown, call: McpCall): Promise<AssetNewResult> {
  const a = panel();
  const args = call.args;
  const kind = String(args.kind);
  return refusing(async () => {
    const done = await a.make(kind, args.in === undefined ? null : pathOf(args.in, 'in'), typeof args.name === 'string' ? args.name.trim() : null, typeof args.of === 'string' ? args.of : null);
    return { tool: 'asset_new', via: 'panel', step: done.step, kind, path: done.path, key: done.key, jobs: done.jobs, files: kind === 'folder' || kind === 'pack' ? [] : [done.path] };
  });
}

/** `asset_move`: as the drag, Move to… and rename -- the files naming it rewritten in the same move. */
export function assetMove(_ctx: unknown, call: McpCall): Promise<AssetMoveResult> {
  const a = panel();
  const paths = pathsOf(call.args.paths);
  const to = call.args.to === undefined ? null : pathOf(call.args.to, 'to');
  const name = typeof call.args.name === 'string' ? call.args.name.trim() : null;
  return refusing(async () => {
    const done = await a.move(paths, to, name);
    const moved = movedIn(done.answers);
    const rewritten = done.answers.flatMap((x) => ((x as { rewritten?: Array<{ path: string }> } | null)?.rewritten ?? []).map((r) => r.path));
    return { tool: 'asset_move', via: 'panel', step: done.step, moved, rewritten, files: [...new Set([...moved.flat(), ...rewritten])] };
  });
}

/** `asset_copy`: Copy to…, or Duplicate. */
export function assetCopy(_ctx: unknown, call: McpCall): Promise<AssetCopyResult> {
  const a = panel();
  const paths = pathsOf(call.args.paths);
  const to = call.args.to === undefined ? null : pathOf(call.args.to, 'to');
  return refusing(async () => {
    const done = await a.copy(paths, to);
    const copies = done.answers.flatMap((x) => (x as { paths?: string[] } | null)?.paths ?? []);
    return { tool: 'asset_copy', via: 'panel', step: done.step, copies, files: copies };
  });
}

/** `asset_delete`: Delete, to the trash -- refused while a data file names any of it. */
export function assetDelete(_ctx: unknown, call: McpCall): Promise<AssetDeleteResult> {
  const a = panel();
  const paths = pathsOf(call.args.paths);
  return refusing(async () => {
    const done = await a.remove(paths);
    const slot = done.answers.map((x) => (x as { slot?: string } | null)?.slot).find((s): s is string => typeof s === 'string') ?? null;
    return { tool: 'asset_delete', via: 'panel', step: done.step, removed: done.removed, slot, files: done.removed };
  });
}

/** `asset_restore`: Restore, or Restore here. */
export function assetRestore(_ctx: unknown, call: McpCall): Promise<AssetRestoreResult> {
  const a = panel();
  const slot = typeof call.args.slot === 'string' && call.args.slot !== '' ? call.args.slot : no('slot is a trash slot, as asset_list with trash: true lists them');
  const paths = call.args.paths === undefined ? null : pathsOf(call.args.paths);
  const to = call.args.to === undefined ? null : pathOf(call.args.to, 'to');
  return refusing(async () => {
    const done = await a.restore(slot, paths, to);
    return { tool: 'asset_restore', via: 'panel', step: done.step, restored: done.restored, files: done.restored };
  });
}

/** `asset_options`: the Options block, and the tick. */
export function assetOptions(_ctx: unknown, call: McpCall): Promise<AssetOptionsResult> {
  const a = panel();
  const path = pathOf(call.args.path);
  // The export's name: its own call, as the menu's Rename the export… is its own step.
  if (call.args.as !== undefined) {
    const as = call.args.as;
    if (as !== null && (typeof as !== 'string' || as === '')) return no('as is the name the export ships as (no extension), or null for the source\'s own');
    if (call.args.set !== undefined || call.args.reset !== undefined || call.args.include !== undefined) return no('as is its own call: name the export, then set the options in another');
    return refusing(async () => {
      const done = await a.exportAs(path, as);
      return { tool: 'asset_options', via: 'panel', step: done.step, path, jobs: done.jobs, files: done.step !== null ? [done.record, ...done.moved.map(([, to]) => to)] : [], exportAs: { as: done.as, moved: done.moved } };
    });
  }
  const set = call.args.set;
  if (set !== undefined && (set === null || typeof set !== 'object' || Array.isArray(set))) return no('set is an object of options by name');
  const include = typeof call.args.include === 'boolean' ? call.args.include : null;
  const reset = call.args.reset === true;
  if (set === undefined && !reset && include === null) return no('Nothing to set: give set (options by name), reset, or include');
  return refusing(async () => {
    const done = await a.options(path, (set as Record<string, unknown> | undefined) ?? null, reset, include);
    return { tool: 'asset_options', via: 'panel', step: done.step, path, jobs: done.jobs, files: done.step !== null ? [done.record] : [] };
  });
}

/** `model_adopt`: the panel's Make a script for it -- one step, answered once its build ends. */
export function modelAdopt(_ctx: unknown, call: McpCall): Promise<ModelAdoptResult> {
  const a = panel();
  const path = pathOf(call.args.path);
  return refusing(async () => {
    const done = await a.adopt(path);
    return { tool: 'model_adopt', via: 'panel', step: done.step, path, script: done.script, copied: done.copied, decoded: done.decoded, built: done.built, jobs: done.jobs, files: done.step !== null ? [done.script, ...(done.copied !== null ? [done.copied] : [])] : [] };
  });
}

/** `material_set`: the Material block's write. */
export function materialSetTool(_ctx: unknown, call: McpCall): Promise<MaterialSetResult> {
  const a = panel();
  const set = call.args.set;
  if (set === null || typeof set !== 'object' || Array.isArray(set) || Object.keys(set).length === 0) return no('set is an object of fields: { "color": "#ff8800", "roughness": 0.4 }');
  const key = typeof call.args.key === 'string' && call.args.key !== '' ? caseKey(call.args.key) : keyOfMaterial(call.args.path);
  return refusing(async () => {
    const done = await a.material(key, set as Record<string, unknown>);
    return { tool: 'material_set', via: 'panel', step: done.step, key, path: done.path, set: set as Record<string, unknown>, files: done.step !== null ? [done.path] : [] };
  });
}

/** `physmat_set`: a physics material's fields, as the Physics material block writes them. */
export function physmatSetTool(_ctx: unknown, call: McpCall): Promise<PhysmatSetResult> {
  const a = panel();
  const { key, ...set } = call.args;
  if (typeof key !== 'string' || key === '') return no('key is the physics material\'s key: ice');
  if (Object.keys(set).length === 0) return no('nothing to set: any of friction, rollingFriction, restitution, frictionCombine, restitutionCombine');
  return refusing(async () => {
    const done = await a.physmat(key, set);
    return { tool: 'physmat_set', via: 'panel', step: done.step, key: caseKey(key), path: done.path, values: { ...done.values }, files: done.step !== null ? [done.path] : [] };
  });
}

/** A material's key from its path: `src/assets/materials/props/rust.material` is `props/rust`. */
function keyOfMaterial(raw: unknown): string {
  const path = pathOf(raw);
  const m = /^src\/assets\/materials\/(.+)\.material$/i.exec(path);
  return m ? caseKey(m[1]!) : no(`${path} is no material file: src/assets/materials/<key>.material`);
}

/** `prefab_edit`: the Prefab block's write -- its pool, its root. */
export function prefabEdit(_ctx: unknown, call: McpCall): Promise<PrefabEditResult> {
  const a = panel();
  const args = call.args;
  if (typeof args.key !== 'string' || args.key === '') return no('key is the prefab\'s key: crates/big');
  const key = caseKey(args.key);
  const pool = args.pool as { warm: number; max: number } | null | undefined;
  if (pool !== undefined && pool !== null && (typeof pool.warm !== 'number' || typeof pool.max !== 'number' || pool.max < 1 || pool.warm > pool.max)) return no('pool is { warm, max }, warm at most max, or null for none');
  const list = (v: unknown, what: string): string[] | undefined => (v === undefined ? undefined : Array.isArray(v) && v.every((x) => typeof x === 'string') ? (v as string[]) : no(`${what} is a list of component names`));
  const set = args.set as Record<string, Record<string, unknown>> | undefined;
  if (set !== undefined && (set === null || typeof set !== 'object')) return no('set is { Component: { field: value } }');
  const add = list(args.add, 'add');
  const remove = list(args.remove, 'remove');
  if (pool === undefined && !set && !add && !remove) return no('Nothing to edit: give pool, set, add or remove');
  return refusing(async () => {
    const done = await a.prefab(key, { ...(pool !== undefined ? { pool } : {}), ...(set ? { set } : {}), ...(add ? { add } : {}), ...(remove ? { remove } : {}) });
    return { tool: 'prefab_edit', via: 'panel', step: done.step, key, path: done.path, changed: done.changed, files: done.step !== null ? [done.path] : [] };
  });
}

/** `asset_export`: E and Export all stale -- answered as soon as the jobs are queued; the server follows them. */
export function assetExport(_ctx: unknown, call: McpCall): Promise<AssetExportResult> {
  const a = panel();
  const force = call.args.force === true;
  const what = call.args.under !== undefined ? { under: pathOf(call.args.under, 'under') } : call.args.paths !== undefined ? { paths: pathsOf(call.args.paths) } : no('paths (sources or their exports) or under (a folder: every stale source in it)');
  return refusing(async () => {
    const done = await a.exportSources(what, force);
    return { tool: 'asset_export', via: 'panel', step: done.step, jobs: done.jobs, job: null, files: [] };
  });
}
