/**
 * Scenes and the prefab open as tools (Docs/mcp.md §4, M2), each the editor's own control through the host: the tree's
 * Open prefab and the scene header's Back (`editor.ts`' opened mode), the Scenes page's Open, New scene, Save as… and
 * start pick (`config/scenes.ts`). None is a step: another world is another history, as when the person does it.
 *
 * - **What nobody saved is never lost unasked**: Open and New scene refuse while the world has changes nobody saved,
 *   unless `discard` -- which the catalogue marks destructive; Back from a prefab with changes asks for `save`.
 * - **Save as never writes over another scene**: replacing one is the person's to say.
 */
import type { ClosePrefabResult, McpCall, OpenPrefabResult, SceneImportResult, SceneNewResult, SceneOpenResult, SceneSaveAsResult, SceneStartResult } from '@vibe/pipeline/agent-types';
import { caseKey, NONE } from '@vibe/engine';
import { no, refOrKey, rowOf } from './facts.ts';
import type { PageContext } from './host.ts';

/** `scene_open_prefab`: `key` opened to edit, over the scene, as the tree's Open prefab -- the scene put aside until Back. */
export function sceneOpenPrefab(ctx: PageContext, call: McpCall): OpenPrefabResult {
  const { host, world } = ctx;
  if (!host.openPrefab) return no('The editor here opens no prefab');
  const ref = refOrKey('prefabs', call.args.key);
  if ('error' in ref) return no(`key: ${ref.error}`);
  if (ref.key === null) return no('key is a prefab\'s key: crates/big');
  const key = caseKey(ref.key);
  const opened = host.openPrefab(key);
  if ('error' in opened) return no(`${key} not opened: ${opened.error}`);
  ctx.tell();
  const root = host.openedRoot?.() ?? NONE;
  return { tool: 'scene_open_prefab', key, root: root !== NONE && world.alive(root) ? rowOf(world, root) : null, readOnly: opened.readOnly, said: `${key} opened${opened.readOnly ? ` read-only (${opened.readOnly})` : ''}: every scene tool edits it now; scene_close_prefab saves it (save: true) and goes back` };
}

/** `scene_close_prefab`: Back from the prefab open -- `save` true saves it first, false drops its changes; left out, only with none. */
export function sceneClosePrefab(ctx: PageContext, call: McpCall): Promise<ClosePrefabResult> {
  const { host } = ctx;
  if (!host.closePrefab) return no('The editor here opens no prefab');
  if (!host.opened?.()) return no('No prefab is open: the scene is');
  const save = call.args.save;
  if (save !== undefined && typeof save !== 'boolean') return no('save is true (save it, then back) or false (drop its changes)');
  return host.closePrefab(save ?? null).then((done) => {
    if ('error' in done) return no(done.error);
    ctx.tell();
    return { tool: 'scene_close_prefab', ...done };
  });
}

/** `scene_open`: the scene `key` in place of the world -- refused over changes nobody saved, unless `discard`. */
export function sceneOpen(ctx: PageContext, call: McpCall): SceneOpenResult {
  const { host } = ctx;
  if (!host.openScene) return no('The editor here opens no scene');
  const key = call.args.key;
  if (typeof key !== 'string' || key === '') return no('key is a scene\'s key: forest/camp');
  const discard = call.args.discard === true;
  const done = host.openScene(caseKey(key), discard);
  if ('error' in done) return no(done.error);
  ctx.tell();
  return { tool: 'scene_open', key: caseKey(key), ...done };
}

/** `scene_new`: the world emptied for a new scene, but for its `Main Camera` -- refused over changes nobody saved, unless `discard`. */
export function sceneNew(ctx: PageContext, call: McpCall): SceneNewResult {
  const { host } = ctx;
  if (!host.newScene) return no('The editor here makes no new scene');
  const done = host.newScene(call.args.discard === true);
  if ('error' in done) return no(done.error);
  ctx.tell();
  return { tool: 'scene_new', ...done };
}

/** `scene_import`: a world save's text written as a new scene and opened, as Import… -- refused over what nobody saved, unless `discard`. */
export function sceneImport(ctx: PageContext, call: McpCall): Promise<SceneImportResult> {
  const { host } = ctx;
  if (!host.importScene) return no('The editor here imports no scene');
  const { save, name } = call.args;
  if (typeof save !== 'string' || save === '') return no('save is the world save\'s JSON text');
  if (typeof name !== 'string' || name === '') return no('name is the new scene\'s name: forest-camp');
  return host.importScene(save, name, call.args.discard === true).then((done) => {
    if ('error' in done) return no(done.error);
    ctx.tell();
    return { tool: 'scene_import', key: done.key, file: done.file, discarded: done.discarded, skipped: done.skipped };
  });
}

/** `scene_save_as`: the world written as a new scene file -- never over another. */
export function sceneSaveAs(ctx: PageContext, call: McpCall): Promise<SceneSaveAsResult> {
  const { host } = ctx;
  if (!host.saveSceneAs) return no('The editor here saves no scene');
  const name = call.args.name;
  if (typeof name !== 'string' || name === '') return no('name is the new scene\'s name: my-camp, or forest/camp in a folder');
  return host.saveSceneAs(name).then((done) => ('error' in done ? no(done.error) : { tool: 'scene_save_as', name: done.name, key: done.key }));
}

/** `scene_start`: the scene the game opens on start -- its file says `"start": true` -- or null, the game's own world. */
export function sceneStart(ctx: PageContext, call: McpCall): Promise<SceneStartResult> {
  const { host } = ctx;
  if (!host.setStart) return no('The editor here picks no start scene');
  const key = call.args.key;
  if (key !== null && (typeof key !== 'string' || key === '')) return no('key is a scene\'s key, or null for the game\'s own world');
  return host.setStart(key === null ? null : caseKey(key)).then((done) => ('error' in done ? no(done.error) : { tool: 'scene_start', start: done.start }));
}

// ---------------------------------------------------------------- the rules the Scenes page's agent hooks keep (pure: tested here)

/** Where the editor stands, for putting the world aside for another. */
export interface LeaveState {
  /** A playtest on, running or paused. */
  playtest: boolean;
  /** The prefab open to edit, or null. */
  prefab: string | null;
  /** An Apply landing. */
  holding: boolean;
  /** The world as its file has it (history at its save mark). */
  saved: boolean;
  /** The scene's key, or null for a world with no file. */
  current: string | null;
}

/**
 * Why `what` (Open, New scene) may not put the world aside now, or null: a playtest, a prefab open, an Apply landing --
 * and what nobody saved, unless the call says `discard`.
 */
export function leaveRefusal(what: string, state: LeaveState, discard: boolean): string | null {
  if (state.playtest) return `${what}: not now -- a playtest is on; stop it first`;
  if (state.prefab !== null) return `${what}: ${state.prefab} is open -- scene_close_prefab first`;
  if (state.holding) return `${what}: not now -- an Apply is landing; try again in a moment`;
  if (!state.saved && !discard) {
    return `${what}: the world has changes nobody saved${state.current !== null ? ` (${state.current})` : ''} -- scene_save them first, or give discard: true to drop them (ask the person: it cannot be undone)`;
  }
  return null;
}

/**
 * The world put aside for another (Open, New scene): an edit under way made a step of its own first (`commit`), then
 * the rule (`leaveRefusal`) on the state read AFTER it -- so an edit that was under way counts as unsaved, and is said
 * dropped. Refused, or whether going on drops anything.
 */
export function leave(what: string, discard: boolean, commit: () => void, state: () => LeaveState): { error: string } | { discarded: boolean } {
  commit();
  const now = state();
  const no = leaveRefusal(what, now, discard);
  return no !== null ? { error: no } : { discarded: !now.saved };
}

/** Why Save as may not write `key` (a new scene's, lowercased), or null: never over another scene -- its own file is Save. */
export function saveAsRefusal(key: string, current: string | null, exists: (key: string) => boolean): string | null {
  if (key !== current && exists(key)) return `There is a scene ${key} already: a new name -- writing over it is the person's to choose, in Config ▸ Scenes`;
  return null;
}
