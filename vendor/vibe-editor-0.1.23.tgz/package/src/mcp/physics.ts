/**
 * The physics tools' page half (Docs/physics.md §7): Config ▸ Physics' file read and written through the host
 * (`physics_state`, `physics_settings_set`), a ray or a shape put to the world as it stands -- the bodies brought up to
 * the components first (`sync`), so they answer while stopped -- and Fit to model (`physics_fit`, one step).
 */
import type { McpCall, PhysicsFitResult, PhysicsHitFacts, PhysicsOverlapResult, PhysicsRaycastResult, PhysicsSettingsFacts, PhysicsSettingsSetResult, PhysicsStateResult } from '@vibe/pipeline/agent-types';
import { boxProbe, type Entity, physicsOf, RayHits, sphereProbe, type PhysicsSettings, type World } from '@vibe/engine';
import { PENDING } from '../world-steps.ts';
import { collides } from '../physics/matrix.ts';
import { applyFit } from '../physics/fit-apply.ts';
import type { PhysicsChange } from '../physics/settings-client.ts';
import { entityOf, no, pathOf, rowOf } from './facts.ts';
import type { PageContext, PagePhysics } from './host.ts';

const physicsOfHost = (ctx: PageContext): PagePhysics => ctx.host.physics ?? no('This studio has no physics page');

/** The settings as the answers say them. */
export const settingsFacts = (s: PhysicsSettings): PhysicsSettingsFacts => ({
  enabled: s.enabled,
  gravity: [s.gravity[0], s.gravity[1], s.gravity[2]],
  substeps: s.substeps,
  iterations: s.iterations,
  sleep: { linear: s.sleep.linear, angular: s.sleep.angular },
  defaultMaterial: { friction: s.defaultMaterial.friction, restitution: s.defaultMaterial.restitution },
  layers: [...s.layers],
  ignore: s.ignore.map(([a, b]) => [a, b] as [string, string]),
});

/** `physics_state`. */
export async function physicsState(ctx: PageContext, _call: McpCall): Promise<PhysicsStateResult> {
  const host = physicsOfHost(ctx);
  const { settings } = await host.read();
  const physics = physicsOf(ctx.world);
  const matrix: Record<string, string[]> = {};
  settings.layers.forEach((a, i) => void (matrix[a] = settings.layers.filter((_, j) => collides(settings.layers, settings.ignore, i, j))));
  const s = physics.ready ? physics.stats() : null;
  return {
    tool: 'physics_state',
    enabled: settings.enabled,
    running: physics.ready,
    settings: settingsFacts(settings),
    matrix,
    stats: s === null ? null : { dynamic: s.dynamic, kinematic: s.kinematic, static: s.static, awake: s.awake, triggers: s.triggers, contacts: s.contacts, stepMs: s.stepMs, maxStepMs: s.maxStepMs },
    colliders: host.colliders(),
  };
}

const CHANGE_KEYS = ['enabled', 'gravity', 'substeps', 'iterations', 'sleep', 'defaultMaterial', 'layers', 'ignore'] as const;

/** `physics_settings_set`: any of the file's fields, as Config ▸ Physics writes them. */
export async function physicsSettingsSet(ctx: PageContext, call: McpCall): Promise<PhysicsSettingsSetResult> {
  const host = physicsOfHost(ctx);
  const given = Object.keys(call.args);
  const unknown = given.filter((k) => !(CHANGE_KEYS as readonly string[]).includes(k));
  if (unknown.length > 0) return no(`${unknown.join(', ')}: no setting -- ${CHANGE_KEYS.join(', ')}`);
  if (given.length === 0) return no(`nothing to set: any of ${CHANGE_KEYS.join(', ')}`);
  const done = await host.write(call.args as PhysicsChange);
  if ('error' in done) return no(done.error);
  return { tool: 'physics_settings_set', settings: settingsFacts(done.settings), restart: done.restart };
}

/** Three numbers, or refused naming the argument. */
function vec(v: unknown, what: string): [number, number, number] {
  if (!Array.isArray(v) || v.length !== 3 || !v.every((n) => typeof n === 'number' && Number.isFinite(n))) return no(`${what} is three numbers: [x, y, z]`);
  return [v[0], v[1], v[2]];
}

/** The physics running here, its bodies brought up to the components: or refused, saying why not. */
function liveWorld(world: World): ReturnType<typeof physicsOf> {
  const physics = physicsOf(world);
  if (!physics.ready) return no('Physics does not run here: it is off in physics.json, or Ammo did not load (physics_state says which)');
  physics.sync();
  return physics;
}

/** A mask from layer names, or refused naming the unknown one. */
function maskOf(physics: ReturnType<typeof physicsOf>, layers: unknown): number {
  if (layers === undefined) return physics.layers();
  if (!Array.isArray(layers) || !layers.every((l) => typeof l === 'string')) return no('layers is a list of layer names: ["Default", "Props"]');
  try {
    return physics.layers(...(layers as string[]));
  } catch (err) {
    return no((err as Error).message);
  }
}

/** Every body along a ray at most: a tool's answer, not a game's. */
const HITS_MAX = 64;

/** `physics_raycast`. */
export function physicsRaycast(ctx: PageContext, call: McpCall): PhysicsRaycastResult {
  const { world } = ctx;
  const physics = liveWorld(world);
  const from = vec(call.args.from, 'from');
  const dir = vec(call.args.direction, 'direction');
  if (dir.every((n) => n === 0)) return no('direction is no direction: [0, 0, 0]');
  const max = call.args.max === undefined ? 100 : Number(call.args.max);
  if (!Number.isFinite(max) || max <= 0) return no('max is metres, more than 0');
  const mask = maskOf(physics, call.args.layers);
  const triggers = call.args.triggers === true;
  const hits = new RayHits(HITS_MAX);
  const count = physics.raycastAll(from[0], from[1], from[2], dir[0], dir[1], dir[2], max, mask, hits, triggers);
  const out: PhysicsHitFacts[] = [];
  for (let i = 0; i < count && (call.args.all === true || i < 1); i++) {
    const e = hits.entity[i]! as Entity;
    out.push({
      entity: rowOf(world, e),
      point: [hits.point[i * 3]!, hits.point[i * 3 + 1]!, hits.point[i * 3 + 2]!],
      normal: [hits.normal[i * 3]!, hits.normal[i * 3 + 1]!, hits.normal[i * 3 + 2]!],
      distance: hits.distance[i]!,
    });
  }
  return { tool: 'physics_raycast', hits: out };
}

/** `physics_overlap`. */
export function physicsOverlap(ctx: PageContext, call: McpCall): PhysicsOverlapResult {
  const { world } = ctx;
  const physics = liveWorld(world);
  const at = vec(call.args.at, 'at');
  let probe;
  if (call.args.shape === 'sphere') {
    const r = Number(call.args.radius);
    if (!Number.isFinite(r) || r <= 0) return no('radius is metres, more than 0');
    probe = sphereProbe(r);
  } else if (call.args.shape === 'box') {
    const half = vec(call.args.half, 'half');
    if (half.some((n) => n <= 0)) return no('half is the box\'s half extents, each more than 0');
    probe = boxProbe(half[0], half[1], half[2]);
  } else return no('shape is sphere (with radius) or box (with half)');
  const out = new Uint32Array(256);
  const count = physics.overlap(probe, at[0], at[1], at[2], maskOf(physics, call.args.layers), out, call.args.triggers === true);
  const es = [...out.subarray(0, count)].sort((a, b) => a - b) as Entity[];
  return { tool: 'physics_overlap', entities: es.filter((e) => world.alive(e)).map((e) => rowOf(world, e)) };
}

/** `physics_fit`: one step, as the Fit button. */
export function physicsFit(ctx: PageContext, call: McpCall): PhysicsFitResult {
  const { world } = ctx;
  const host = physicsOfHost(ctx);
  const e = entityOf(world, call.args.entity);
  const collider = call.args.collider === undefined ? null : String(call.args.collider);
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
  const done = applyFit(world, e, collider, host.bounds(e));
  if ('error' in done) return no(`${pathOf(world, e)}: ${done.error}`);
  const step = done.changed ? ctx.step(call, `Fit ${done.collider} to its model`) : null;
  if (!ctx.batching) {
    ctx.host.changed();
    ctx.tell();
  }
  return { tool: 'physics_fit', entity: rowOf(world, e), collider: done.collider, set: done.set, step };
}
