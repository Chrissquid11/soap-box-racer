/**
 * A data component through the studio's tools (Docs/properties.md §4, P4), each what the inspector's list and
 * dictionary do:
 *
 * - **`scene_set` with a path** (`field: "waypoints[2]"`, `"loot.sword"`, `"stats.speed"`, or a top-level field
 *   whole; no `field`, the component's fields it names -- a partial set, the rest left as they are, a read-only one
 *   refused); one value for all, or `values`, one an entity: the value in its plain form -- an enum's name, a key's text or
 *   `{ uid, key }`, a ref an entity's ref or path (null for nobody) -- checked against the schema at every step, the
 *   path of what does not fit in the refusal; a number held to its `min`/`max` and a string to its `maxLength`, said.
 * - **`scene_list_insert`, `scene_list_remove`, `scene_list_move`**: a list's +, × and grip -- and a dictionary's
 *   too, its entry by `key`: insert adds one (a key it has refused), remove takes one out, move puts one elsewhere in
 *   its order, or with `rename` gives it another key in its place. `min`/`max` refuse what would leave a list with too few or too many.
 *
 * Each ONE step on the editor's undo stack, as every scene edit; an edit under way a step of its own first.
 */
import type { ListResult, McpCall, SetResult } from '@vibe/pipeline/agent-types';
import {
  clampTo, countMisfit, type DataComponentOf, dataDefault, dataPlain, DataError, type DictElement, elementAt, type Entity, type EntityRef, type Field, freeKey,
  fromPlain, isData, label, type ListElement, moveEntry, moveItem, NO_REF, parsePath, putAt, rawOut, type ReadOptions, refMisfit,
} from '@vibe/engine';
import { renameKey } from '../data-edit.ts';
import { times } from '../multi.ts';
import { PENDING } from '../world-steps.ts';
import { entitiesOf, entityOf, no, pathOf } from './facts.ts';
import type { PageContext } from './host.ts';
import { settable, unknownKey } from './scene.ts';

/** How a tool's value is read: refs by an entity's ref or path, each typed one checked; keys the project has; bounds held, said. */
function toolReading(ctx: PageContext, key: string, held: string[]): ReadOptions {
  const { world } = ctx;
  return {
    ref(json: unknown, path: string, field: Field): EntityRef {
      if (json === null || json === 0 || json === '') return NO_REF;
      const to = entityOf(world, json, `${key}.${path}`);
      const misfit = refMisfit(field, (name) => {
        const c = world.allComponents.find((x) => x.name === name);
        return c !== undefined && world.has(to, c);
      }, label(world, to));
      if (misfit !== null) throw new DataError(path, misfit);
      return world.ref(to);
    },
    key: (kind, text) => unknownKey(ctx, kind, text),
    number(n, field, path) {
      const kept = clampTo(field, n);
      if (kept !== n) held.push(`${key}.${path} ${n} clamped to ${kept}, its ${kept === field.min ? 'min' : 'max'}`);
      return kept;
    },
    text(s, el, path) {
      if (el.maxLength === undefined || s.length <= el.maxLength) return s;
      held.push(`${key}.${path}: ${s.length} characters cut to ${el.maxLength}, its maxLength`);
      return s.slice(0, el.maxLength);
    },
  };
}

/** A data component's value as an answer says it: its plain form, refs as entity refs, as JSON text. */
export const dataShown = (c: DataComponentOf, value: unknown, path: string | null): string => {
  if (path === null) return JSON.stringify(dataPlain({ shape: 'record', fields: c.data }, value, rawOut));
  const at = elementAt(c.data, value as Record<string, unknown>, parsePath(path)!);
  return JSON.stringify(dataPlain(at.el, at.value, rawOut));
};

/** A refusal for a `DataError`, the path in it; anything else as it is. */
function said<T>(key: string, run: () => T): T {
  try {
    return run();
  } catch (err) {
    if (err instanceof DataError) return no(`${key}.${err.message}`);
    throw err;
  }
}

/** The entities a call names (`entities`, else the selection), each alive with `c`. */
function targets(ctx: PageContext, given: unknown, c: DataComponentOf): Entity[] {
  const { world, host } = ctx;
  const ids: Entity[] = given === undefined ? [...host.selection()].filter((e) => world.alive(e)) : entitiesOf(world, given);
  if (ids.length === 0) return no('Nothing is selected: name the entities by ref or path, or ask the person to select them');
  for (const e of ids) if (!world.has(e, c)) return no(`${pathOf(world, e)} has no ${c.name}: scene_component adds it`);
  return ids;
}

const slotOf = (ctx: PageContext, c: DataComponentOf, e: Entity): Record<string, unknown> => (ctx.world.rawStore(c) as { value: Record<string, unknown>[] }).value[e]!;

/** A step made for an edit, the page told: the one way every tool here ends. */
function stepped(ctx: PageContext, call: McpCall, label: string): string | null {
  const step = ctx.step(call, label);
  if (!ctx.batching) {
    ctx.host.changed();
    ctx.tell();
  }
  return step;
}

/**
 * `scene_set` on a data component: `field` a path into it (or left out: the whole component), `value` one for all
 * or one per entity, in its plain form. `was`, given, compared by that form.
 */
export function dataSet(ctx: PageContext, call: McpCall, c: DataComponentOf): SetResult {
  const { world } = ctx;
  const args = call.args;
  const path = typeof args.field === 'string' ? args.field : null;
  const steps = path === null ? null : parsePath(path);
  if (path !== null && steps === null) return no(`${c.name}: ${JSON.stringify(path)} is no path -- a field (waypoints), an element ([2]), a key or a record's field (.sword, .speed): waypoints[2], loot.sword`);
  if (steps !== null && !(steps[0]! as { name: string }).name) return no(`${c.name}: a path starts with a field`);
  const top = steps === null ? null : c.data[(steps[0] as { name: string }).name];
  if (steps !== null && !top) return no(`${c.name} has no field ${(steps[0] as { name: string }).name}: it has ${Object.keys(c.data).join(', ')}`);
  const ids = targets(ctx, args.entities, c);
  const key = path === null ? c.name : `${c.name}.${path}`;
  // One value for all (`value`), or one an entity, in order (`values`): never guessed from an array's length -- a list,
  // a dict's pairs, a path ["b7", "m3"] are one value.
  if (args.values !== undefined && (!Array.isArray(args.values) || args.values.length !== ids.length)) return no(`values is one value an entity, in order: ${ids.length} for ${ids.length === 1 ? 'the one' : `the ${ids.length}`} named -- or give value, one for all`);
  if (args.values === undefined && args.value === undefined) return no('value (one for all) or values (one an entity) is needed');
  const one = args.values !== undefined ? (args.values as unknown[]) : ids.map(() => args.value);
  // The component whole (no field): a partial set -- each field it names written, every other left as it is.
  if (steps === null) {
    for (const v of one) {
      if (typeof v !== 'object' || v === null || Array.isArray(v)) return no(`${c.name} whole is its fields, { "waypoints": [...], ... }: only those named are written, the rest left as they are -- not ${JSON.stringify(v)}`);
      for (const f of Object.keys(v)) {
        if (!(f in c.data)) return no(`${c.name} has no field ${f}: it has ${Object.keys(c.data).join(', ')}`);
        if (c.data[f]!.readonly) return no(`${c.name}.${f} is read only (readonly: true in its maker): the game's code sets it -- leave it out`);
      }
    }
  }
  const now = (e: Entity): string => said(c.name, () => dataShown(c, slotOf(ctx, c, e), path));
  if (args.was !== undefined) {
    const moved = ids.filter((e) => now(e) !== JSON.stringify(args.was));
    if (moved.length > 0) return { tool: 'scene_set', component: c.name, field: path ?? 'value', step: null, written: [], changed: moved.map((e) => ({ ref: world.ref(e), id: e, name: null, now: now(e) })) };
  }
  const held: string[] = [];
  const reading = toolReading(ctx, c.name, held);
  // Each read in full first: a refusal changes nothing.
  const values = ids.map((e, i) => said(c.name, (): (() => void) => {
    const slot = slotOf(ctx, c, e);
    if (steps === null) {
      const given = one[i] as Record<string, unknown>;
      const read = Object.keys(given).map((f) => [f, fromPlain(c.data[f]!, given[f], f, reading)] as const);
      return () => {
        for (const [f, v] of read) slot[f] = v;
      };
    }
    // Read only anywhere along the path: the record or list it is inside too.
    for (let k = 1; k <= steps.length; k++) {
      const up = elementAt(c.data, slot, steps.slice(0, k), reading.ref);
      if (up.el.readonly) return no(`${c.name}.${up.path} is read only (readonly: true in its maker): the game's code sets it`);
    }
    const at = elementAt(c.data, slot, steps, reading.ref);
    const v = fromPlain(at.el, one[i], at.path, reading);
    return () => putAt(at, v);
  }));
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
  const was = ids.map(now);
  for (const write of values) write();
  world.flush();
  const after = ids.map(now);
  const changed = after.some((x, i) => x !== was[i]);
  const step = changed ? stepped(ctx, call, times(`${key}`, ids.length)) : null;
  return {
    tool: 'scene_set', component: c.name, field: path ?? 'value', step, object: path === null ? true : undefined,
    written: ids.map((e, i) => ({ id: e, ref: world.ref(e), name: null, was: was[i]!, now: after[i]! })),
    ...(held.length > 0 ? { clamped: [...new Set(held)] } : {}),
  } as SetResult;
}

/** The list or dictionary a list tool's `path` names, on one entity: its element, and what holds it. */
function collection(ctx: PageContext, c: DataComponentOf, e: Entity, path: string): { el: ListElement | DictElement; value: unknown[] | Map<unknown, unknown>; path: string } {
  const steps = parsePath(path);
  if (steps === null) return no(`${c.name}: ${JSON.stringify(path)} is no path -- waypoints, crew[0].stops, loot`);
  const at = said(c.name, () => elementAt(c.data, slotOf(ctx, c, e), steps, toolReading(ctx, c.name, []).ref));
  if (!('shape' in at.el) || (at.el.shape !== 'list' && at.el.shape !== 'dict')) return no(`${c.name}.${at.path} is no list nor dictionary: scene_set writes it`);
  return { el: at.el, value: at.value as unknown[] | Map<unknown, unknown>, path: at.path };
}

/** A dict's key as a tool gives it: read as its kind reads one. */
function dictKey(ctx: PageContext, c: DataComponentOf, el: DictElement, given: unknown, path: string): unknown {
  if (given === undefined) return no(`${c.name}.${path} is a dictionary: name the entry by its key`);
  const probe = new Map<unknown, unknown>();
  const read = said(c.name, () => fromPlain({ shape: 'dict', keyOf: el.keyOf, valueOf: { type: 'u8', initial: 0 } }, [[given, 0]], path, toolReading(ctx, c.name, [])) as Map<unknown, unknown>);
  for (const k of read.keys()) probe.set(k, 0);
  return [...probe.keys()][0];
}

/** A list tool's answer for each entity: the list or dictionary after, as JSON text. */
function listResult<T extends ListResult['tool']>(ctx: PageContext, call: McpCall, c: DataComponentOf, tool: T, path: string, ids: readonly Entity[], was: readonly string[], verb: string): ListResult<T> {
  const { world } = ctx;
  world.flush();
  const now = ids.map((e) => dataShown(c, slotOf(ctx, c, e), path));
  const changed = now.some((x, i) => x !== was[i]);
  const step = changed ? stepped(ctx, call, times(`${verb} ${c.name}.${path}`, ids.length)) : null;
  return { tool, component: c.name, path, step, written: ids.map((e, i) => ({ id: e, ref: world.ref(e), was: was[i]!, now: now[i]! })) };
}

/** The data component a list tool names. */
function dataNamed(ctx: PageContext, name: unknown): DataComponentOf {
  const c = settable(ctx, String(name));
  if (!isData(c)) return no(`${String(name)} is no data component: the list tools edit a dataComponent's lists and dictionaries`);
  return c;
}

/**
 * `scene_list_insert`: an element into a list -- at `index` (left out: the end), `value` its plain form (left out: the
 * element's default, a record's its defaults) -- or an entry into a dictionary, by `key` (left out: the first key it
 * has not, as +), `value` its value. `max` refuses one too many; a key the dictionary has, refused.
 */
export function sceneListInsert(ctx: PageContext, call: McpCall): ListResult<'scene_list_insert'> {
  const args = call.args;
  const c = dataNamed(ctx, args.component);
  const path = String(args.path ?? '');
  const ids = targets(ctx, args.entities, c);
  const reading = toolReading(ctx, c.name, []);
  const plans = ids.map((e) => {
    const { el, value, path: at } = collection(ctx, c, e, path);
    if (el.shape === 'list') {
      const list = value as unknown[];
      const index = args.index === undefined ? list.length : Number(args.index);
      if (!Number.isInteger(index) || index < 0 || index > list.length) return no(`${c.name}.${at}: index ${String(args.index)} is outside it -- 0 to ${list.length} (${list.length} the end)`);
      const misfit = countMisfit(el, list.length + 1);
      if (misfit !== null) return no(`${c.name}.${at} holds ${misfit}: nothing added`);
      const item = args.value === undefined ? dataDefault(el.of) : said(c.name, () => fromPlain(el.of, args.value, `${at}[${index}]`, reading));
      return () => void list.splice(index, 0, item);
    }
    const map = value as Map<unknown, unknown>;
    const k = args.key === undefined ? freeKey(el, map) : dictKey(ctx, c, el, args.key, at);
    if (k === null) return no(`${c.name}.${at}: every key it can have, it has${!('shape' in el.keyOf) && el.keyOf.ref ? ' -- an entity\'s entry is named by its key: give key' : ''}`);
    if (map.has(k)) return no(`${c.name}.${at} has the key ${JSON.stringify(args.key ?? k)} already: a key is in a dictionary once -- scene_set ${at}${typeof args.key === 'string' ? `.${args.key}` : `[${String(args.key ?? k)}]`} changes its value`);
    const item = args.value === undefined ? dataDefault(el.valueOf) : said(c.name, () => fromPlain(el.valueOf, args.value, at, reading));
    return () => void map.set(k, item);
  });
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
  const was = ids.map((e) => dataShown(c, slotOf(ctx, c, e), path));
  for (const run of plans) run();
  return listResult(ctx, call, c, 'scene_list_insert', path, ids, was, 'Add to');
}

/** `scene_list_remove`: a list's element at `index`, or a dictionary's entry by `key`, taken out. `min` refuses one too few. */
export function sceneListRemove(ctx: PageContext, call: McpCall): ListResult<'scene_list_remove'> {
  const args = call.args;
  const c = dataNamed(ctx, args.component);
  const path = String(args.path ?? '');
  const ids = targets(ctx, args.entities, c);
  const plans = ids.map((e) => {
    const { el, value, path: at } = collection(ctx, c, e, path);
    if (el.shape === 'list') {
      const list = value as unknown[];
      const index = Number(args.index);
      if (args.index === undefined || !Number.isInteger(index) || index < 0 || index >= list.length) return no(`${c.name}.${at}: no element ${String(args.index)} -- it has ${list.length}${list.length > 0 ? `, 0 to ${list.length - 1}` : ''}`);
      const misfit = countMisfit(el, list.length - 1);
      if (misfit !== null) return no(`${c.name}.${at} holds ${misfit}: nothing removed`);
      return () => void list.splice(index, 1);
    }
    const map = value as Map<unknown, unknown>;
    const k = dictKey(ctx, c, el, args.key, at);
    if (!map.has(k)) return no(`${c.name}.${at} has no key ${JSON.stringify(args.key)}`);
    return () => void map.delete(k);
  });
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
  const was = ids.map((e) => dataShown(c, slotOf(ctx, c, e), path));
  for (const run of plans) run();
  return listResult(ctx, call, c, 'scene_list_remove', path, ids, was, 'Remove from');
}

/**
 * `scene_list_move`: a list's element (or a dictionary's entry, by `key` or its place) from `from` to `to`, the rest in
 * order: the grip -- or, with `rename`, a dictionary's entry `key` given that key in its place (a key it has refused).
 */
export function sceneListMove(ctx: PageContext, call: McpCall): ListResult<'scene_list_move'> {
  const args = call.args;
  const c = dataNamed(ctx, args.component);
  const path = String(args.path ?? '');
  const ids = targets(ctx, args.entities, c);
  const plans = ids.map((e) => {
    const { el, value, path: at } = collection(ctx, c, e, path);
    const size = Array.isArray(value) ? value.length : value.size;
    // A dictionary's entry given another key, in its place: the inspector's key typed anew.
    if (args.rename !== undefined) {
      if (el.shape !== 'dict') return no(`${c.name}.${at} is a list: rename is a dictionary's key's`);
      const k = dictKey(ctx, c, el, args.key, at);
      const map = value as Map<unknown, unknown>;
      if (!map.has(k)) return no(`${c.name}.${at} has no key ${JSON.stringify(args.key)}`);
      const to = dictKey(ctx, c, el, args.rename, at);
      if (to !== k && map.has(to)) return no(`${c.name}.${at}: ${JSON.stringify(args.rename)} is a key already: a key is in a dictionary once -- nothing renamed`);
      return () => void renameKey(map, k, to);
    }
    let from = Number(args.from);
    if (el.shape === 'dict' && args.key !== undefined) {
      const k = dictKey(ctx, c, el, args.key, at);
      from = [...(value as Map<unknown, unknown>).keys()].indexOf(k);
      if (from < 0) return no(`${c.name}.${at} has no key ${JSON.stringify(args.key)}`);
    }
    const to = Number(args.to);
    if (!Number.isInteger(from) || from < 0 || from >= size) return no(`${c.name}.${at}: from ${String(args.from)} is outside it -- 0 to ${size - 1}`);
    if (!Number.isInteger(to) || to < 0 || to >= size) return no(`${c.name}.${at}: to ${String(args.to)} is outside it -- 0 to ${size - 1}`);
    return () => (Array.isArray(value) ? moveItem(value, from, to) : moveEntry(value, from, to));
  });
  if (!ctx.batching) ctx.worldSteps.commit(PENDING);
  const was = ids.map((e) => dataShown(c, slotOf(ctx, c, e), path));
  for (const run of plans) run();
  return listResult(ctx, call, c, 'scene_list_move', path, ids, was, args.rename !== undefined ? 'Rename in' : 'Move in');
}
