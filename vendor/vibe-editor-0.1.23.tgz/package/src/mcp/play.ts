/**
 * The play, view and history tools' page half (Docs/mcp.md §4's play and view, M4): each through the editor's own
 * functions, handed over on the host (`PageHost.play`, `views`, `undo`, `redo`) -- the playtest's keys (F5, F6, F10,
 * Shift+F5), the view's (F, the cube, the numpad) and the history's (Z, Y).
 *
 * - **The playtest**: `play_start` is F5 (a playtest begun, or a paused one run on), `play_pause` F6, `play_step` F10
 *   `n` times, `play_stop` Shift+F5 -- the offer of what was changed while paused answered by `keep` (`keepTicks`'
 *   ids, `editId`), else the person's preference. A key that did nothing (a card with the keys, an Apply landing, the
 *   wrong state) is refused, saying why.
 * - **The view** moves as F and the cube move it: no step. `view_shot` draws a view into an image (the host's
 *   `shot`, `view-shot.ts`) without moving it.
 * - **History**: an agent's own steps -- Claude's in the panel (`Claude: …`) or an outside client's (`MCP: …`),
 *   `agentStep`, each said by whom (`stepBy`) -- undone or redone, the person's only with `any`.
 *
 * Pure over the host: node tests it (`play.test.ts`).
 */
import type {
  GameViewResult, HistoryListResult, HistoryMoveResult, McpCall, PlayFacts, PlayResult, PlayStateResult, PlayStopResult, ViewGetResult, ViewShotResult,
} from '@vibe/pipeline/agent-types';
import { type Entity, NONE } from '@vibe/engine';
import { PENDING } from '../world-steps.ts';
import { entitiesOf, entityOf, no, rowOf, stepPrefix } from './facts.ts';
import type { PageContext, PageGameView, PagePlay, PageView } from './host.ts';
import { DIRECTIONS, presetOf, type Vec3 } from '../view/views.ts';
import { SHOT_MAX } from '../view-shot.ts';
import { SCALE_FILTERS, SCALE_MODES } from '../game-view.ts';

/** Whose a step is, by its label (`stepPrefix`): Claude's -- `Claude: …`, or `Claude (<conversation>): …` while several are open -- an outside client's `MCP: …`, else the person's. */
export const stepBy = (label: string): 'person' | 'Claude' | 'MCP' => (/^Claude(?: \([^)]*\))?: /.test(label) ? 'Claude' : label.startsWith('MCP: ') ? 'MCP' : 'person');

/** A step of an agent's -- Claude's or an outside client's, which `history_undo` takes without `any` -- not the person's. */
export const agentStep = (label: string): boolean => stepBy(label) !== 'person';

/** Ticks one `play_step` runs, at most: ten seconds at 60 Hz. */
export const STEPS_MAX = 600;


const playOf = (ctx: PageContext): PagePlay => ctx.host.play ?? no('This studio has no playtest to drive');
const viewOf = (ctx: PageContext): PageView => ctx.host.views ?? no('This studio has no view to move');

/** The playtest's facts now. */
function facts(play: PagePlay): PlayFacts {
  const state = play.state();
  const { tick, ticks } = play.ticks();
  return { state, tick, ticks: state === 'none' ? 0 : ticks, seconds: state === 'none' ? 0 : Math.round((ticks / 60) * 10) / 10, changes: state === 'none' ? [] : play.offered() };
}

/** Why a key did nothing: a card or a question has the editor's keys, or an Apply lands. */
const BUSY = 'the editor did not take it -- a card or a question has its keys, or an Apply is landing: ask the person, or try again in a moment';

/** `play_state`. */
export function playState(ctx: PageContext, _call?: McpCall): PlayStateResult {
  return { tool: 'play_state', ...facts(playOf(ctx)) };
}

/** `play_start`: F5 -- a playtest begun, or a paused one run on. */
export function playStart(ctx: PageContext, _call?: McpCall): PlayResult<'play_start'> {
  const play = playOf(ctx);
  const was = play.state();
  if (was === 'running') return no('A playtest is running already: play_pause pauses it, play_stop ends it');
  ctx.worldSteps.commit(PENDING);
  play.press('F5');
  if (play.state() !== 'running') return no(`Not started: ${BUSY}`);
  return { tool: 'play_start', did: was === 'paused' ? 'resumed' : 'started', ...facts(play) };
}

/** `play_pause`: F6. */
export function playPause(ctx: PageContext, _call?: McpCall): PlayResult<'play_pause'> {
  const play = playOf(ctx);
  const was = play.state();
  if (was !== 'running') return no(was === 'paused' ? 'The playtest is paused already' : 'No playtest runs: play_start begins one');
  play.press('F6');
  if (play.state() !== 'paused') return no(`Not paused: ${BUSY}`);
  return { tool: 'play_pause', did: 'paused', ...facts(play) };
}

/** `play_step`: F10, `n` times. */
export function playStep(ctx: PageContext, call: McpCall): PlayResult<'play_step'> {
  const play = playOf(ctx);
  if (play.state() !== 'paused') return no(play.state() === 'running' ? 'The playtest is running: play_pause first, then step it' : 'No playtest: play_start begins one, play_pause pauses it');
  const n = call.args.n === undefined ? 1 : Number(call.args.n);
  if (!Number.isInteger(n) || n < 1 || n > STEPS_MAX) return no(`n is a whole number of ticks, 1 to ${STEPS_MAX}`);
  let stepped = 0;
  for (let i = 0; i < n; i++) {
    const before = play.ticks().tick;
    play.press('step');
    if (play.ticks().tick === before) break;
    stepped++;
  }
  if (stepped === 0) return no(`Not stepped: ${BUSY}`);
  return { tool: 'play_step', did: 'stepped', stepped, ...facts(play) };
}

/** `play_stop`: Shift+F5, the offer answered by `keep`, or the person's preference. */
export function playStop(ctx: PageContext, call: McpCall): PlayStopResult {
  const play = playOf(ctx);
  if (play.state() === 'none') return no('No playtest to stop');
  const keep = call.args.keep;
  if (keep !== undefined && keep !== 'all' && keep !== 'none' && !(Array.isArray(keep) && keep.every((k) => typeof k === 'string'))) return no('keep is all, none, or a list of change ids (play_state lists them)');
  if (Array.isArray(keep)) {
    // Checked before anything stops: an id that names nothing is a mistake to say, not a change dropped unsaid.
    const ids = new Set(play.offered().map((c) => c.id));
    const unknown = (keep as string[]).filter((k) => !ids.has(k));
    if (unknown.length > 0) return no(`No change has the id ${unknown.join(', ')}: play_state lists them -- nothing was stopped`);
  }
  ctx.worldSteps.commit(PENDING);
  const done = play.stop(keep as 'all' | 'none' | string[] | undefined, stepPrefix(call));
  if (play.state() !== 'none') return no(`Not stopped: ${BUSY}`);
  return { tool: 'play_stop', ...facts(play), ...done };
}

// ---------------------------------------------------------------- the view

const round = (n: number): number => Math.round(n * 1000) / 1000;

/** The view's facts, as `view_get` answers them. */
function viewFacts<T extends 'view_get' | 'view_set' | 'view_focus'>(view: PageView, tool: T): ViewGetResult<T> {
  const { pose, room, canvas } = view.get();
  const direction: Vec3 = [pose.position[0] - pose.target[0], pose.position[1] - pose.target[1], pose.position[2] - pose.target[2]];
  return {
    tool,
    view: {
      position: [round(pose.position[0]), round(pose.position[1]), round(pose.position[2])],
      target: [round(pose.target[0]), round(pose.target[1]), round(pose.target[2])],
      projection: pose.projection,
      fov: pose.projection === 'perspective' ? pose.fov : null,
      height: pose.projection === 'orthographic' ? pose.height : null,
      preset: presetOf(direction),
    },
    room,
    canvas,
  };
}

/** `view_get`. */
export const viewGet = (ctx: PageContext, _call?: McpCall): ViewGetResult<'view_get'> => viewFacts(viewOf(ctx), 'view_get');

// ---------------------------------------------------------------- the game view (Docs/game-view.md D7)

const gameViewOf = (ctx: PageContext): PageGameView => ctx.host.gameView ?? no('This studio has no game view');

/** The game view's facts. */
function gameViewFacts<T extends 'game_view_state' | 'game_view_set' | 'game_view_preset'>(view: PageGameView, tool: T, did?: GameViewResult['did']): GameViewResult<T> {
  const got = view.get();
  return {
    tool, frame: { ...got.frame }, canvas: { ...got.canvas }, fills: got.fills, maximizeOnPlay: got.maximizeOnPlay,
    preset: got.preset, applies: got.applies, pixels: { ...got.pixels }, scale: got.scale, look: got.look, presets: got.presets.map((p) => ({ ...p })),
    ...(did ? { did } : {}),
  };
}

/** `game_view_state`. */
export const gameViewState = (ctx: PageContext, _call?: McpCall): GameViewResult<'game_view_state'> => gameViewFacts(gameViewOf(ctx), 'game_view_state');

/** `game_view_set`: the preset, the Game look and Maximize on Play, as the play strip's dropdown and toggle -- any of them, checked first. */
export function gameViewSet(ctx: PageContext, call: McpCall): GameViewResult<'game_view_set'> {
  const view = gameViewOf(ctx);
  const { preset, look, maximizeOnPlay: on } = call.args;
  if (preset === undefined && look === undefined && on === undefined) return no('give a preset (by its name), a look (scene or game) or maximizeOnPlay (true or false)');
  if (preset !== undefined && typeof preset !== 'string') return no('preset is a preset\'s name, as game_view_state lists them');
  if (look !== undefined && look !== 'scene' && look !== 'game') return no('look is scene (the editor\'s camera) or game (the game\'s cameras and the preset)');
  if (on !== undefined && typeof on !== 'boolean') return no('maximizeOnPlay is true (a playtest fills the window) or false (docked in the scene\'s room)');
  if (typeof preset === 'string') {
    const why = view.choose(preset);
    if (why !== null) return no(why);
  }
  if (look !== undefined) view.setLook(look === 'game');
  if (typeof on === 'boolean') view.setMaximize(on);
  return gameViewFacts(view, 'game_view_set');
}

/** `game_view_preset`: one of the project's presets added, changed, moved or removed, as Add… and Config ▸ Game view. */
export function gameViewPreset(ctx: PageContext, call: McpCall): GameViewResult<'game_view_preset'> {
  const view = gameViewOf(ctx);
  const { name, size, mode, filter, rename, remove, move } = call.args;
  if (typeof name !== 'string' || name.trim() === '') return no('name is the preset\'s: a new one adds it, one of the project\'s changes it');
  if (size !== undefined && typeof size !== 'string') return no('size is an aspect, 16:9, or pixels, 640x360');
  if (mode !== undefined && !SCALE_MODES.includes(mode as never)) return no('mode is fit, pixel or stretch');
  if (filter !== undefined && !SCALE_FILTERS.includes(filter as never)) return no('filter is nearest or linear');
  if (rename !== undefined && typeof rename !== 'string') return no('rename is the new name');
  const mine = view.get().presets.find((p) => p.own && p.name.toLowerCase() === name.trim().toLowerCase()) ?? null;
  if (remove === true) {
    const why = view.remove(name);
    return why === null ? gameViewFacts(view, 'game_view_preset', 'removed') : no(why);
  }
  if (move !== undefined) {
    if (typeof move !== 'number' || !Number.isInteger(move)) return no('move is a whole number of places: -1 up, 1 down');
    if (!mine) return no(`no preset of the project's is called ${name}`);
    view.move(mine.name, move);
    return gameViewFacts(view, 'game_view_preset', 'moved');
  }
  if (!mine && size === undefined) return no(`no preset of the project's is called ${name}: to add it, give its size (16:9 or 640x360)`);
  const made = view.put({
    name: typeof rename === 'string' ? rename : mine?.name ?? name,
    size: typeof size === 'string' ? size : mine!.size!,
    // A change keeps every part it is not given.
    mode: (mode as GameViewResult['presets'][number]['mode'] | undefined) ?? mine?.mode,
    filter: (filter as GameViewResult['presets'][number]['filter'] | undefined) ?? mine?.filter,
  }, mine?.name ?? null);
  if (typeof made === 'string') return no(made);
  return gameViewFacts(view, 'game_view_preset', mine ? 'changed' : 'added');
}

/** A point as three finite numbers, or why not. */
function pointOf(given: unknown, what: string): [number, number, number] {
  if (!Array.isArray(given) || given.length !== 3 || !given.every((n) => typeof n === 'number' && Number.isFinite(n))) return no(`${what} is [x, y, z] in metres`);
  return [given[0], given[1], given[2]];
}

/** `view_set`: a pose, a side, or a projection -- one of them. */
export function viewSet(ctx: PageContext, call: McpCall): ViewGetResult<'view_set'> {
  const view = viewOf(ctx);
  const { pose, numpad, projection, colliders } = call.args as { pose?: { position?: unknown; target?: unknown }; numpad?: unknown; projection?: unknown; colliders?: unknown };
  const given = [pose, numpad, projection, colliders].filter((x) => x !== undefined).length;
  if (given !== 1) return no('view_set takes one of pose, numpad, projection or colliders');
  if (colliders !== undefined) {
    if (colliders !== 'none' && colliders !== 'selected' && colliders !== 'all') return no('colliders is none, selected or all');
    const physics = ctx.host.physics ?? no('This studio draws no colliders');
    physics.setColliders(colliders);
    return { ...viewFacts(view, 'view_set'), colliders: physics.colliders() };
  }
  if (pose !== undefined) {
    const position = pointOf(pose.position, 'pose.position');
    const target = pointOf(pose.target, 'pose.target');
    if (position.every((n, i) => n === target[i])) return no('pose.position and pose.target are the same point: the camera needs something to look at');
    view.setPose(position, target);
  } else if (numpad !== undefined) {
    if (typeof numpad !== 'string' || numpad === 'free' || !Object.hasOwn(DIRECTIONS, numpad)) return no('numpad is front, back, left, right, top or bottom');
    view.look(numpad as 'front');
  } else {
    if (projection !== 'perspective' && projection !== 'orthographic') return no('projection is perspective or orthographic');
    view.setProjection(projection);
  }
  return viewFacts(view, 'view_set');
}

/** `view_focus`: these entities framed, as F frames the selection. */
export function viewFocus(ctx: PageContext, call: McpCall): ViewGetResult<'view_focus'> {
  const view = viewOf(ctx);
  const list = entitiesOf(ctx.world, call.args.entities);
  if (!view.frame(list)) return no('None of them is anywhere to frame: no view, no transform');
  return { ...viewFacts(view, 'view_focus'), framed: list.map((e) => rowOf(ctx.world, e)) };
}

/** `view_shot`: an image of a view, the person's unmoved. */
export async function viewShot(ctx: PageContext, call: McpCall): Promise<ViewShotResult> {
  const view = viewOf(ctx);
  const args = call.args;
  const target = (args.target ?? 'scene') as ViewShotResult['target'];
  if (!['scene', 'camera', 'main', 'model'].includes(target)) return no('target is scene, camera, main or model');
  let camera: Entity | null = null;
  if (target === 'camera') {
    if (args.camera === undefined) return no('target camera names the camera entity: camera, by ref or path');
    camera = entityOf(ctx.world, args.camera, 'camera');
  } else if (args.camera !== undefined) return no('camera is for target camera');
  const size = (v: unknown, what: string): number | null => {
    if (v === undefined) return null;
    if (typeof v !== 'number' || !Number.isInteger(v) || v < 16 || v > SHOT_MAX) return no(`${what} is a whole number of pixels, 16 to ${SHOT_MAX}`);
    return v;
  };
  const format = args.format ?? 'webp';
  if (format !== 'webp' && format !== 'png') return no('format is webp or png');
  if (args.overlays !== undefined && typeof args.overlays !== 'boolean') return no('overlays is true or false');
  const overlays = typeof args.overlays === 'boolean' ? args.overlays : target === 'scene';
  const shot = await view.shot({ target, camera, width: size(args.width, 'width'), height: size(args.height, 'height'), overlays, format });
  const seen = shot.camera !== null && shot.camera !== NONE && ctx.world.alive(shot.camera) ? rowOf(ctx.world, shot.camera) : null;
  return { tool: 'view_shot', target, camera: seen, width: shot.width, height: shot.height, overlays: target === 'model' ? false : overlays, mimeType: shot.mimeType, data: shot.data, notes: shot.notes };
}

// ---------------------------------------------------------------- history

/** `history_list`: the world's steps, each said by whom, where the person is. */
export function historyList(ctx: PageContext, _call?: McpCall): HistoryListResult {
  const { history } = ctx;
  return {
    tool: 'history_list',
    steps: history.labels.map((label, i) => ({ n: i + 1, label, by: stepBy(label), done: i < history.done })),
    done: history.done,
    saved: history.saved,
  };
}

/** How many steps, 1 by default. */
function countOf(given: unknown): number {
  if (given === undefined) return 1;
  if (typeof given !== 'number' || !Number.isInteger(given) || given < 1 || given > 100) return no('n is a whole number of steps, 1 to 100');
  return given;
}

/** `history_undo` and `history_redo`: an agent's own steps -- the person's only with `any`. */
function move<T extends 'history_undo' | 'history_redo'>(ctx: PageContext, call: McpCall, tool: T): HistoryMoveResult<T> {
  const { history, host } = ctx;
  const undo = tool === 'history_undo';
  const n = countOf(call.args.n);
  // An edit under way is a step first, as Z makes it.
  ctx.worldSteps.commit(PENDING);
  const labels = history.labels;
  const at = history.done;
  const steps = undo ? labels.slice(Math.max(0, at - n), at).reverse() : labels.slice(at, at + n);
  if (steps.length === 0) return no(undo ? 'Nothing to undo' : 'Nothing to redo');
  if (steps.length < n) return no(`Only ${steps.length} ${steps.length === 1 ? 'step' : 'steps'} to ${undo ? 'undo' : 'redo'}: ${steps.map((l) => `"${l}"`).join(', ')}`);
  const theirs = steps.filter((l) => !agentStep(l));
  if (theirs.length > 0 && call.args.any !== true) {
    return no(`${theirs.map((l) => `"${l}"`).join(', ')} ${theirs.length === 1 ? 'is' : 'are'} the person's, not Claude's or an outside client's: ${undo ? 'undone' : 'redone'} only with any: true -- ask them first`);
  }
  if (undo) host.undo(n);
  else if (host.redo) host.redo(n);
  else return no('This studio cannot redo here');
  const moved = Math.abs(history.done - at);
  if (moved === 0) return no(`Not ${undo ? 'undone' : 'redone'}: an Apply is landing, or a step could not be taken back -- try again in a moment`);
  host.changed();
  ctx.tell();
  return { tool, moved: steps.slice(0, moved), done: history.done };
}

export const historyUndo = (ctx: PageContext, call: McpCall): HistoryMoveResult<'history_undo'> => move(ctx, call, 'history_undo');
export const historyRedo = (ctx: PageContext, call: McpCall): HistoryMoveResult<'history_redo'> => move(ctx, call, 'history_redo');
