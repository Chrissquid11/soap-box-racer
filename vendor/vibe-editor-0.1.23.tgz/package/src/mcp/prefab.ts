/**
 * The prefab area's page tool (Docs/mcp.md §4): `prefab_info` -- every prefab compiled now in a line (its file, its
 * names, a variant's base, what it nests and what nests it, its pool with what is parked and out, its instances) and
 * the files that do not compile, with why; by `key`, one whole: each entity by path, what it is made of (what `init`
 * may fill in), its model, the nested prefab that makes it, and its instances' roots. A read.
 */
import type { McpCall, PrefabFacts, PrefabsResult } from '@vibe/pipeline/agent-types';
import { caseKey, compiledPrefab, type CompiledPrefab, compiledPrefabs, type Entity, isKeyRef, keyRef, Name, untypedPrefab as prefab } from '@vibe/engine';
import { prefabPathOf } from '../assets/ui/prefab-steps.ts';
import { no, OWN, refOrKey, ROOTS_MAX } from './facts.ts';
import type { PageContext } from './host.ts';

/** Each prefab compiled now, by key: one whose file went keeps its row for the instances still out, not its key. */
const current = (): CompiledPrefab[] => compiledPrefabs().flatMap((p) => (p && compiledPrefab(p.key) === p ? [p] : [])).sort((a, b) => a.key.localeCompare(b.key));

/** `prefab_info`: every prefab in a line, or `key`'s whole -- its entities, its instances out. */
export function prefabInfo(ctx: PageContext, call: McpCall): PrefabsResult | Promise<PrefabsResult> {
  const { world, host } = ctx;
  // A key, or a reference `{ uid, key }` read by its uid.
  let key: string | undefined;
  if (call.args.key !== undefined) {
    const ref = refOrKey('prefabs', call.args.key);
    if ('error' in ref) return no(`key: ${ref.error}`);
    if (ref.key === null) return no('key is a prefab key, as text: crates/big');
    key = caseKey(ref.key);
  }
  const all = current();
  const problems = host.prefabProblems?.() ?? new Map<string, string>();
  if (typeof key === 'string' && !all.some((p) => p.key === key)) {
    const why = problems.get(key);
    return no(why !== undefined ? `${key} does not compile: ${why}` : `There is no prefab ${key}: the prefabs are ${all.map((p) => p.key).join(', ') || 'none'}`);
  }
  /** What each prefab nests directly: the prefab just inside it, of each entity another's file makes. */
  const nests = new Map<string, string[]>();
  for (const p of all) {
    const inner = new Set<string>();
    for (const owners of p.owners) {
      const next = owners.at(-2);
      if (next && next.key !== p.key) inner.add(next.key);
    }
    nests.set(p.key, [...inner].sort());
  }
  // Instances out, by root: alive, made by that prefab (a recompile's older row too, by its key).
  const roots = new Map<string, Entity[]>();
  for (let e = 1 as Entity; e < world.extent; e++) {
    if (!world.alive(e) || world.instanceRoot(e) !== e) continue;
    const p = world.prefabOf(e);
    if (!p) continue;
    const list = roots.get(p.key) ?? [];
    list.push(e);
    roots.set(p.key, list);
  }
  const names = (world.rawStore(Name) as { value: (string | null)[] }).value;
  const facts = (p: CompiledPrefab, whole: boolean): PrefabFacts => {
    const out = roots.get(p.key) ?? [];
    const pool = p.pool ? world.pool(prefab(p.key)) : null;
    const rootOwners = p.owners[0] ?? [];
    const ref = keyRef('prefabs', p.key);
    const f: PrefabFacts = {
      key: p.key,
      ...(isKeyRef(ref) ? { uid: ref.uid } : {}),
      file: prefabPathOf(p.key),
      entities: p.count,
      names: p.names.filter((n): n is string => !!n),
      variantOf: rootOwners.length > 1 ? rootOwners.at(-2)!.key : null,
      nests: nests.get(p.key) ?? [],
      nestedBy: all.filter((q) => nests.get(q.key)?.includes(p.key)).map((q) => q.key),
      pool: p.pool && pool ? { warm: p.pool.warm, max: p.pool.max, parked: pool.parked, out: pool.out } : null,
      instances: out.length,
      problem: problems.get(p.key) ?? null,
    };
    if (!whole) return f;
    f.nodes = p.paths.map((path, n) => ({
      path,
      name: p.names[n] ?? null,
      parent: p.parents[n]! < 0 ? null : p.paths[p.parents[n]!]!,
      components: p.kinds[n]!.components.filter((c) => !OWN.has(c.name)).map((c) => c.name),
      view: p.views[n] ?? null,
      from: p.owners[n]?.[0] && p.owners[n]![0]!.key !== p.key ? p.owners[n]![0]!.key : null,
    }));
    f.roots = out.slice(0, ROOTS_MAX).map((e) => ({ id: e, name: world.has(e, Name) ? (names[e] ?? null) : null }));
    return f;
  };
  const list = typeof key === 'string' ? all.filter((p) => p.key === key).map((p) => facts(p, true)) : all.map((p) => facts(p, false));
  const known = new Set(all.map((p) => p.key));
  // A file that does not compile is not in the list: said apart, with why. Asked for one by key, only it.
  const broken = typeof key === 'string' ? [] : [...problems].filter(([k]) => !known.has(k)).map(([k, problem]) => ({ key: k, problem })).sort((a, b) => a.key.localeCompare(b.key));
  // And a file that is no prefab -- a .json under prefabs/ -- never compiled, so in no list but the dev server's tree.
  if (typeof key === 'string' || !host.prefabStrays) return { tool: 'prefab_info', prefabs: list, broken };
  return host.prefabStrays().then((strays) => ({ tool: 'prefab_info', prefabs: list, broken: [...broken, ...strays] }));
}
