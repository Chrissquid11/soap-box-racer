/**
 * The inspector's blocks, one a component, and what each is built with
 * (`Blocks`, `head`, `valuesField`, `columnField`): a numeric component's
 * fields, a `ref()` field, a `key()` field's picker and a `color()` field's
 * swatch (`key-field.ts`), an object component, `Render` -- the editor's own
 * items on the inspector's list of blocks (`BUILT_IN_BLOCKS`, `blocks.ts`),
 * which a project's join (`createEditor({ blocks })`). Transform has its own
 * (`inspector-transform.ts`), and so do relations (`inspector-relations.ts`);
 * the tags are a drop-down on the state line (`tags-drop.ts`). Every block
 * folds (`foldable`), the Assets tool's inspector's too.
 *
 * - **A block is for every entity selected** -- one, or several that all have
 *   the component. A field shows the value they share, or `—` with the values
 *   on hover (`multi.ts`); typed, it is every one's; scrubbed or stepped, each
 *   moves by as much from its own. With one selected it is that one's, as ever.
 * - **A value is written as it changes** -- each pixel of a scrub -- and drawn;
 *   the end of it is one step of history, called for what it did:
 *   `Set Health.hp`, or `Set Health.hp × 3`.
 * - **A `ref()` field is an entity, not a number**: whom it points at, "Pick…"
 *   for another -- the next entity clicked -- and × for nobody.
 * - **A `key()` field is an asset's key, not a number**: picked from the keys
 *   of its kind loaded now, a model's with its thumbnail (`key-field.ts`);
 *   a `color()` field a swatch. Each pick one step, as a number's edit.
 * - **`Render` is the component block with its title saying what it is drawn
 *   as** (`renderBlock`: `Group, 3 children`) and its model's part beside the
 *   model. `View` -- the three object the engine's `render` system attaches --
 *   has no block: it is the engine's own (Docs/render.md §1).
 * - **A component can be switched off** where it has a box on its title row
 *   (`switchable`: what a save keeps, so the switch is a step and lasts): its
 *   data stays, the entity leaves the systems that need it, and the block is
 *   dimmed. Of several, the box is neither ticked nor clear while only some
 *   have it on; a click switches it on for all. One step, `Disable Health × 3`.
 */
import * as THREE from 'three';
import { type AnyComponent, caseKey, isData, type Component, type Entity, type EntityRef, fileFieldOf, fileFields, keyText, label, labelOf, NO_REF, NONE, refMisfit, refTakes, Render, splitModel, View, type World } from '@vibe/engine';
import { factsOf, fits } from './drag-record.ts';
import { dragSource, dropRefused, dropTarget } from './drop-target.ts';
import { Assets, Audio, url, type Kind } from '@vibe/engine/assets';
import { decodeSound } from './assets/preview/audio.ts';
import { textField, type NumberField } from './fields.ts';
import { checkLine, colorLine, keyLine, titled, type KeySources, type LineOptions } from './key-field.ts';
import { keyLooks, type LookPage } from './key-looks.ts';
import { enumLine, fieldLayout, flagsLine, groupEnd, groupHead, numberLine, valuesField, vectorLine } from './inspector-fields.ts';
import type { InspectorHost } from './inspector.ts';
import { agreed, eachOwn, spread, times } from './multi.ts';
import { builtInBlocks, drawnAs, internal, switchable, type BlockItem } from './blocks.ts';
import { cameraBlock } from './inspector-camera.ts';
import { dataComponentBlock } from './inspector-data.ts';
import type { TransformBlocks } from './inspector-transform.ts';
import { keepPref, loadPrefs } from './prefs.ts';
import { button, el } from './shell.ts';

export { eachOwn, internal };

/** A column as the inspector writes it: any numeric store's field. */
export type Columns = Record<string, { [i: number]: number }>;

/** What every block is built with: the world, the tool's host, and the inspector's way of keeping its numbers up. */
export interface Blocks {
  readonly world: World;
  readonly host: InspectorHost;
  /** Read again by `showValues` -- while the gizmo drags -- all but the field being typed in. */
  live(update: () => void): void;
  /** After a value is written in place: drawn, and the numbers that follow from it -- the world transform, the other scale axes -- read again. */
  wrote(): void;
  /** The Transform block's maker, which keeps the angles shown: what the built-in `transform` item draws with (`entityBlocks` hands it in). */
  readonly transform?: TransformBlocks;
}

/** Each integer type's range, so a scrub stops at the end rather than wrapping round. */
const RANGE: Partial<Record<string, [number, number]>> = {
  i8: [-128, 127], u8: [0, 255], i16: [-32768, 32767], u16: [0, 65535],
  i32: [-2147483648, 2147483647], u32: [0, 4294967295],
};


// `switchable` lives in `blocks.ts` (no DOM: the studio's page tools ask it too); said from here as ever.
export { switchable } from './blocks.ts';

/**
 * The box that switches `component` on or off for every one of `es` that has
 * it: ticked when all have it on, clear when none, neither between -- a click
 * then switches it on for all. One step, `Disable Health × 3`.
 */
function switchBox({ world, host }: Pick<Blocks, 'world' | 'host'>, component: AnyComponent, es: readonly Entity[]): HTMLInputElement {
  const having = es.filter((e) => world.has(e, component));
  const on = having.filter((e) => world.enabled(e, component)).length;
  const box = el('input', 'ed-check ed-switch');
  box.type = 'checkbox';
  box.checked = on === having.length;
  box.indeterminate = on > 0 && on < having.length;
  box.title = box.indeterminate
    ? `${component.name} is on for ${on} of ${having.length}: a click switches it on for all`
    : `${component.name} switched ${box.checked ? 'on' : 'off'}${having.length > 1 ? ` for all ${having.length}` : ''}: `
      + (box.checked ? 'a click switches it off -- its data stays, and the systems that need it leave it' : 'a click switches it on again');
  box.addEventListener('change', () => {
    const want = box.checked;
    const flipped = having.filter((e) => world.enabled(e, component) !== want);
    for (const e of flipped) world.enable(e, component, want);
    host.changed(times(`${want ? 'Enable' : 'Disable'} ${component.name}`, flipped.length));
  });
  return box;
}

/** A block's name, after its box if it has one; the row says when it is off for every one, so the block is dimmed. */
function named(blocks: Pick<Blocks, 'world' | 'host'>, line: HTMLElement, component: AnyComponent, es: readonly Entity[]): HTMLElement {
  const name = el('span', 'ed-head-name');
  if (switchable(blocks.world, component, es)) {
    const box = switchBox(blocks, component, es);
    name.append(box);
    line.classList.toggle('ed-off', !box.checked && !box.indeterminate);
  }
  name.append(el('b', undefined, component.name));
  return name;
}

/** A block's title row: the component's box and name, and the button that takes it off every one -- none for what the world keeps for itself. */
export function head({ world, host }: Blocks, component: AnyComponent, es: readonly Entity[]): HTMLElement {
  const line = el('div', 'ed-component-head');
  line.dataset.component = component.name;
  // One entity's: dragged onto a ref field it is that entity, as this component (`ref(Health)` takes Health's header).
  if (es.length === 1 && component.kind !== 'relation') {
    line.draggable = true;
    line.title = `Drag onto a ref field: ${label(world, es[0]!)}, as its ${component.name}`;
    line.addEventListener('dragstart', (event) => {
      event.dataTransfer?.setData('text/plain', `${component.name} on ${label(world, es[0]!)}`);
      if (event.dataTransfer) event.dataTransfer.effectAllowed = 'copy';
    });
    dragSource(line, () => (world.alive(es[0]!) ? { what: 'component', entity: es[0]!, component: component.name } : null));
  }
  line.append(named({ world, host }, line, component, es));
  if (!internal(component)) line.append(removeButton({ world, host }, component, es));
  return line;
}

/** × for `component`, off every one of `es` that has it: one step, `Remove Health × 3`. */
function removeButton({ world, host }: Pick<Blocks, 'world' | 'host'>, component: AnyComponent, es: readonly Entity[]): HTMLButtonElement {
  return button('scene_component', '×', es.length > 1 ? `Remove ${component.name} from all ${es.length}` : `Remove ${component.name}`, () => {
    const on = es.filter((e) => world.has(e, component));
    for (const e of on) world.remove(e, component);
    host.changed(times(`Remove ${component.name}`, on.length));
  }, 'ed-quiet');
}

// `valuesField` lives in `inspector-fields.ts` (no stylesheet: node tests the widgets); said from here as ever.
export { valuesField, type ValuesOptions } from './inspector-fields.ts';

/** A number field on one column, at these rows -- an entity's, a link's -- written live, one step called `did` when done. */
export function columnField(blocks: Blocks, name: string, type: string, did: string, column: () => { [i: number]: number }, rows: readonly number[], fixed = false): NumberField {
  const range = RANGE[type];
  return valuesField(blocks, {
    fixed,
    label: name,
    // Its type on hover, the range of a whole one: what a prefab's component is made of, said where it is edited.
    title: `${name}: ${type}${range ? `, a whole number from ${range[0]} to ${range[1]}` : ', a number'} -- drag the name to scrub`,
    step: range ? 1 : 0.1,
    integer: !!range,
    min: range?.[0],
    max: range?.[1],
    did,
    read: () => rows.map((row) => column()[row]!),
    write: (i, value) => void (column()[rows[i]!] = value),
  });
}

/**
 * Any other numeric component: a field a field, each as its maker declares it (`inspector-fields.ts`) -- labelled, its
 * help on hover, under its group's heading, left out when `hidden`, shown only when `readonly`.
 */
export function dataBlock(blocks: Blocks, es: readonly Entity[], component: Component): HTMLElement {
  const section = el('div', 'ed-component');
  section.append(head(blocks, component, es));
  const grid = el('div', 'ed-fields');
  const store = (): Columns => blocks.world.rawStore(component) as Columns;
  for (const laid of fieldLayout(fileFields(component))) {
    if ('group' in laid) {
      grid.append(groupHead(laid.group));
      continue;
    }
    if ('end' in laid) {
      grid.append(groupEnd());
      continue;
    }
    const f = laid.field;
    const d = f.field;
    // Set by systems as the game runs, on an opened prefab: dimmed, shown only, and why -- a Save never writes it, so an
    // edit to it would mark the prefab unsaved with nothing to save.
    const runtime = f.runtime && blocks.host.opened?.() === true;
    const options = { fixed: runtime || d.readonly === true, label: labelOf(f), ...(d.help !== undefined ? { help: d.help } : {}) };
    // A ref is whom it points at, a key the asset it names, a colour a swatch, a yes or no a tick, an enum a drop-down,
    // flags ticks, a vector a row -- not the numbers that say so.
    const shown = d.ref ? refField(blocks, es, component, f.name, () => store()[f.name]!, options)
      : d.key !== undefined ? keyLine(blocks, keySources(blocks.world, blocks.host), component, f.name, es, { ...options, parts: d.mesh === true || (component === Render && f.name === 'model') })
        : d.color ? colorLine(blocks, component, f.name, es, options)
          : d.bool ? checkLine(blocks, component, f.name, es, options)
            : d.enum ? enumLine(blocks, component, f, es, options)
              : d.flags ? flagsLine(blocks, component, f, es, options)
                : d.vec !== undefined ? vectorLine(blocks, component, f, es, options)
                  : numberLine(blocks, component, f, es, options);
    // What the overrides' marks find it by (`inspector-overrides.ts`).
    shown.dataset.field = `${component.name}.${f.name}`;
    if (runtime) {
      shown.classList.add('ed-runtime');
      shown.title = `${shown.title ? `${shown.title}\n` : ''}Runtime: systems set ${f.name} as the game runs, so the prefab never keeps it -- shown here, not edited`;
    } else if (d.readonly) {
      shown.classList.add('ed-readonly');
      shown.title = `${shown.title ? `${shown.title}\n` : ''}Read only: shown here, set by code`;
    }
    grid.append(shown);
  }
  section.append(grid);
  return section;
}

/** Whom a ref points at, as a line says it: their label, `nobody`, or `gone`. */
function whom(world: World, held: EntityRef): string {
  if (held === NO_REF) return 'nobody';
  const e = world.deref(held);
  return e !== NONE && world.alive(e) ? label(world, e) : 'gone';
}

/**
 * A `ref()` field: whom it points at -- "→ goblin 3", or "→ Health on goblin 3" for a ref of one component
 * (`ref(Health)`), selected with a click -- or nobody, or `mixed` for several that point at others; Pick… for
 * another, × for nobody, each for every one. One that holds an entity without what it needs says so, amber, its
 * reason on hover; one whose entity is gone, red. A tree row, or a component's header, dropped on it points it
 * there if it fits (`drop-target.ts`): while any drag is under way it lights if it would take it, and dims with
 * the reason if not.
 */
function refField({ world, host }: Blocks, es: readonly Entity[], component: Component, field: string, column: () => { [i: number]: number }, options: LineOptions = {}): HTMLElement {
  const key = `${component.name}.${field}`;
  const many = es.length > 1;
  const needs = fileFieldOf(component, field)?.field.needs ?? [];
  const line = el('div', 'ed-ref');
  const name = el('span', 'ed-dim', options.label ?? field);
  name.title = titled(options, `${key}: a reference to ${refTakes({ needs })}`);
  line.append(name);
  const helds = es.map((e) => column()[e]! as EntityRef);
  const held = agreed(helds);
  const target = held === null ? NONE : world.deref(held);
  const facts = factsOf(world);
  if (held === null) {
    const mixed = el('span', 'ed-dim ed-ref-none', 'mixed');
    mixed.title = `${key} points at: ${spread(helds.map((h) => whom(world, h)))}`;
    line.append(mixed);
  } else if (target !== NONE && world.alive(target)) {
    const named = label(world, target);
    const shown = needs.length === 1 ? `${needs[0]} on ${named}` : named;
    const misfit = refMisfit({ needs }, (c) => facts.has(target, c), named);
    const end = button('scene_select', `→ ${shown}`, misfit ?? `Select ${named}, whom ${key} points at`, () => host.select(target), 'ed-quiet ed-link-end');
    if (misfit) end.classList.add('ed-ref-misfit');
    line.append(end);
  } else {
    const gone = held !== NO_REF;
    const nobody = el('span', gone ? 'ed-ref-none ed-ref-gone' : 'ed-dim ed-ref-none', gone ? 'gone' : 'nobody');
    // Set once, to someone since destroyed: worth knowing it was not always empty.
    nobody.title = gone ? `${key} pointed at an entity that is gone` : `${key} points at nobody`;
    line.append(nobody);
  }
  const picking = host.picking === key;
  if (options.fixed) return line;
  // An entity dropped on it: every one of `es` that has the component pointed there, one step, as a pick would.
  // mcp: scene_set -- a drop on a ref field is scene_set's ref
  // Through the pick's own write (`host.dropRef`): a drop and a pick never disagree -- itself alone refused, as a pick.
  if (host.dropRef) dropTarget(line, (record) => {
    const fit = fits({ kind: 'ref', needs }, record, facts);
    return fit.ok && 'entity' in fit && es.every((e) => e === fit.entity) ? { ok: false, why: `${label(world, fit.entity)} is the entity it would be set on` } : fit;
  }, (fit) => {
    if (!('entity' in fit)) return;
    const why = host.dropRef!(component, field, fit.entity);
    if (why !== null) dropRefused(why);
  });
  const pick = button(
    'scene_set', picking ? 'Click an entity…  Esc' : 'Pick…',
    picking
      ? `Click whom it should point at -- ${refTakes({ needs })} -- in the scene or the tree; Esc stops`
      : `Point ${key} at another entity${many ? `, for all ${es.length}` : ''}: then click it, in the scene or the tree -- or drop a row of the tree${needs.length > 0 ? ', or a component\'s header,' : ''} on this line`,
    () => host.pickRef(component, field),
    'ed-quiet ed-pick',
  );
  pick.setAttribute('aria-pressed', String(picking));
  line.append(pick);
  const pointing = es.filter((_, i) => helds[i] !== NO_REF);
  if (pointing.length > 0) {
    line.append(
      button('scene_set', '×', many ? `Point ${key} at nobody, for all ${es.length}` : `Point ${key} at nobody`, () => {
        for (const e of pointing) column()[e] = NO_REF;
        host.changed(times(`Set ${key}`, pointing.length));
      }, 'ed-quiet'),
    );
  }
  return line;
}

/** An object component: a bare slot holding a string, a number or a yes-or-no is a field -- every one's, for several; anything else, text. */
export function objectBlock(blocks: Blocks, es: readonly Entity[], component: AnyComponent): HTMLElement {
  const { world, host } = blocks;
  // A data component: its fields as its schema declares them, each element its own widget (`inspector-data.ts`).
  if (isData(component)) return dataComponentBlock(blocks, es, component, keySources(world, host), head(blocks, component, es));
  const section = el('div', 'ed-component');
  section.append(head(blocks, component, es));
  const slots = world.rawStore(component) as { value: unknown[] };
  const values = es.map((e) => slots.value[e]);
  const n = es.length;
  const bare = component.kind === 'object' && !component.create;
  const all = (type: 'string' | 'number' | 'boolean'): boolean => values.every((v) => typeof v === type);
  const did = times(`Set ${component.name}`, n);
  if (bare && all('string')) {
    const same = agreed(values as string[]);
    section.append(textField(same ?? '', (text) => {
      for (const e of es) slots.value[e] = text;
      host.changed(did);
    }, same === null ? { note: eachOwn(values as string[]) } : undefined));
  } else if (bare && all('number')) {
    const field = valuesField(blocks, {
      label: 'value', step: 0.1, did: `Set ${component.name}`,
      read: () => es.map((e) => slots.value[e] as number),
      write: (i, value) => void (slots.value[es[i]!] = value),
    });
    const grid = el('div', 'ed-fields');
    grid.append(field.label);
    section.append(grid);
  } else if (bare && all('boolean')) {
    const same = agreed(values);
    const box = el('input', 'ed-check');
    box.type = 'checkbox';
    box.checked = same === true;
    // Some yes, some no: neither, until clicked -- then every one is what it says.
    if (same === null) box.indeterminate = true;
    box.addEventListener('change', () => {
      for (const e of es) slots.value[e] = box.checked;
      host.changed(did);
    });
    const line = el('label', 'ed-line ed-check-line');
    line.append(el('span', 'ed-dim', 'value'), box);
    if (same === null) line.title = `${values.filter(Boolean).length} of ${n} yes`;
    section.append(line);
  } else {
    const texts = values.map(describeObject);
    section.append(el('pre', 'ed-object', agreed(texts) ?? eachOwn(texts)));
  }
  return section;
}

/** What a key picker offers in this page: the assets loaded now, an entity's model's clips, and the Assets panel's thumbnails (its one queue, through the host). */
const keySources = (world: World, host: InspectorHost): KeySources => {
  let looks = LOOKS.get(host);
  if (!looks) {
    looks = keyLooks(PAGE, host.thumb ? (key, type) => host.thumb!(key, type) : undefined);
    LOOKS.set(host, looks);
  }
  return {
    keysOf: (kind) => Assets.keysOf(kind),
    partsOf: (model) => Assets.partsOf(model),
    clips: (e) => clipsOf(world, e) ?? [],
    thumb: host.thumb ? (model) => host.thumb!(model) : undefined,
    ...looks,
  };
};

/** What the keys' looks ask of this page (`key-looks.ts`' `LookPage`): the game's assets and mixer, a fetch, a font face. */
const PAGE: LookPage = {
  assets: {
    fontUrl: (key) => Assets.fontUrl(key as never),
    iconUrl: (key) => Assets.iconUrl(key as never),
    materialIfPresent: (key) => Assets.materialIfPresent(key) as { color?: { getHexString(): string } } | null,
  },
  audio: Audio,
  decode: (kind, key) => fetch(url(kind as Kind, key)).then((r) => r.arrayBuffer()).then(decodeSound),
  async loadFont(key, href) {
    const family = `vibe-key ${key}`;
    const face = new FontFace(family, `url(${JSON.stringify(href)})`);
    await face.load();
    document.fonts.add(face);
    return family;
  },
};

/** Each inspector's looks (`key-looks.ts`): its fonts and decoded track kept across its rebuilds. */
const LOOKS = new WeakMap<InspectorHost, ReturnType<typeof keyLooks>>();

/**
 * The names of the clips of the model `e` is drawn with, lowercased as a key is (`Animation.clip`'s
 * choices, Docs/render.md §6): its `Render.model`'s model (a part's whole glb), else its view's
 * (`assetKey`, a view a tool attached); none (`[]`) for a model with no clips; `undefined` for no
 * model, or one the store has not loaded -- not known, where the picker offers none and Claude's
 * `scene_set`, which checks a clip against the same list, takes any.
 */
export function clipsOf(world: World, e: Entity): string[] | undefined {
  let key: string | null = null;
  if (world.alive(e) && world.has(e, Render)) {
    const text = keyText('Model', world.store(Render).model[e]!);
    if (text !== null) key = splitModel(text).model;
  }
  if (key === null) key = (world.store(View).value[e]?.userData.assetKey as string | undefined) ?? null;
  const model = key === null ? null : Assets.modelIfPresent(key);
  if (model === null) return undefined;
  return model.animations.map((clip) => caseKey(clip.name));
}

/**
 * `Render`: its fields as any component's -- the model and its part picked, the
 * material, the tint a swatch, the shadows -- and on its title what it is drawn
 * as now (`Group, 3 children`), the `View` the engine's `render` system put there.
 */
export function renderBlock(blocks: Blocks, es: readonly Entity[]): HTMLElement {
  const { world } = blocks;
  const section = dataBlock(blocks, es, Render);
  const line = section.querySelector<HTMLElement>(':scope > .ed-component-head');
  const drawn = el('span', 'ed-dim ed-view');
  // Read again with the numbers: a model picked is drawn by the render system after the edit, so the words follow it.
  const say = (): void => {
    const words = drawnAs(es.map((e) => (world.has(e, View) ? (world.rawStore(View) as { value: unknown[] }).value[e] : null)));
    drawn.textContent = words.text;
    drawn.title = words.title;
  };
  say();
  blocks.live(say);
  // After the name, before the × that takes Render off.
  line?.querySelector(':scope > .ed-head-name')?.after(drawn);
  return section;
}

/** An object component's value as text: JSON where it has any, a three.js object by its type and name. */
function describeObject(value: unknown): string {
  if (value === null || value === undefined) return 'empty';
  if (typeof value === 'string') return value;
  if (value instanceof THREE.Object3D) return `${value.type}${value.name ? ` "${value.name}"` : ''}, ${value.children.length} children`;
  try {
    return JSON.stringify(value, null, 1) ?? String(value);
  } catch {
    return String(value);
  }
}

/**
 * Every block of `panel` made to fold: a caret before its name, and a click on
 * the title row's name shuts it to that row, kept by `prefix` and the block's
 * name for every one to come -- the entity inspector's with no prefix
 * (`Transform`), the asset inspector's with its own (`assets:Stats`), so the
 * one never folds the other's. The folds are read from the store as the
 * blocks are made and written back through it on each click, whole: two
 * inspectors never write over each other's. A block that folds its own way
 * already (`<details>`, `WorldTransform`'s) is left to it.
 */
export function foldable(panel: HTMLElement, prefix: string): void {
  const folds = loadPrefs().folds;
  for (const section of panel.querySelectorAll<HTMLElement>('.ed-component')) {
    if (section.tagName === 'DETAILS') continue;
    const head = section.querySelector<HTMLElement>(':scope > .ed-component-head');
    if (!head || section.childElementCount < 2 || head.querySelector('.ed-caret')) continue;
    let name = head.querySelector<HTMLElement>('.ed-head-name');
    if (!name) {
      // A title row that is only words ("Systems"): the words become the name, so the caret sits with them.
      name = el('span', 'ed-head-name');
      name.append(...head.childNodes);
      head.append(name);
    }
    const words = (name.querySelector('b') ?? name).textContent?.trim() ?? '';
    if (!words) continue;
    const key = prefix + words;
    const caret = el('span', 'ed-caret', '▾');
    caret.title = 'Fold this block';
    name.prepend(caret);
    name.classList.add('ed-foldable');
    const shut = (on: boolean): void => {
      section.classList.toggle('ed-shut', on);
      caret.textContent = on ? '▸' : '▾';
      caret.title = on ? 'Unfold this block' : 'Fold this block';
    };
    shut(folds[key] === true);
    // The name, not the whole row: the row's box and buttons do their own things.
    // mcp: ui -- a block folded
    name.addEventListener('click', (event) => {
      if ((event.target as HTMLElement).closest('input, button')) return;
      const on = !section.classList.contains('ed-shut');
      shut(on);
      const now = { ...loadPrefs().folds };
      if (on) now[key] = true;
      else delete now[key];
      keepPref('folds', now);
    });
  }
}

/**
 * The editor's own blocks, as items on the inspector's list (`blocks.ts`): Transform (its maker handed
 * in on `Blocks.transform`), Render, then each numeric or object component's fields.
 */
export const BUILT_IN_BLOCKS: readonly BlockItem[] = builtInBlocks({
  transform(blocks, es) {
    if (!blocks.transform) throw new Error('[editor] the Transform block needs its maker: entityBlocks hands it in');
    return blocks.transform.transform(es);
  },
  render: (blocks, es) => renderBlock(blocks, es),
  camera: (blocks, es) => cameraBlock(blocks, es, blocks.host.camera),
  data: (blocks, es, component) => dataBlock(blocks, es, component as Component),
  object: (blocks, es, component) => objectBlock(blocks, es, component!),
});
