/**
 * What a camera entity is drawn as in the Scene view (Docs/camera.md §3), as
 * numbers: Blender's camera object -- a pyramid from where the camera is to its
 * image plane a fixed `DISPLAY_DEPTH` in front, the rectangle at its viewport's
 * aspect and its fov (orthographic: the rectangle its size, the sides parallel),
 * and a triangle over the rectangle's top edge that says which way is up -- and
 * the selected camera's whole frustum, near to far. Pure: no three, no DOM, so
 * `camera-shape.test.ts` holds every rule; `camera-view.ts` draws them.
 *
 * Every point is the camera's own space: it looks down -Z, +Y up, +X right --
 * three's, so the drawing is the camera's `matrixWorld` over these.
 */

/** How far in front of the camera its image plane is drawn, in metres: Blender's display size. */
export const DISPLAY_DEPTH = 1;

/** A camera's lens as the drawing needs it: what its rectangle is. */
export interface ShapeLens {
  orthographic: boolean;
  /** Perspective: the vertical field of view, in degrees. */
  fov: number;
  /** Orthographic: half the view's height, in metres (three's `top / zoom`). */
  size: number;
  /** The viewport's width over its height. */
  aspect: number;
}

/** The narrowest and widest a perspective fov is drawn at: a lens of 0° or 180° would draw nothing or forever. */
const FOV_MIN = 0.1;
const FOV_MAX = 179;

/** An aspect fit to draw: a viewport of no size is drawn square. */
const aspectOf = (aspect: number): number => (aspect > 0 && Number.isFinite(aspect) ? aspect : 1);

/** Half the rectangle's width and height at `distance` in front of the camera, into `out` ([halfWidth, halfHeight]). */
export function rectAt(lens: ShapeLens, distance: number, out: number[] = [0, 0]): number[] {
  const half = lens.orthographic
    ? Math.max(0, Number.isFinite(lens.size) ? Math.abs(lens.size) : 0)
    : distance * Math.tan((Math.min(FOV_MAX, Math.max(FOV_MIN, Number.isFinite(lens.fov) ? lens.fov : 50)) * Math.PI) / 360);
  out[0] = half * aspectOf(lens.aspect);
  out[1] = half;
  return out;
}

/** The up triangle over a rectangle of these halves, at depth `z`: its three corners (left, right, apex), nine numbers. */
export function upTriangle(halfWidth: number, halfHeight: number, z: number): number[] {
  // Blender's proportions: a squat triangle a little above the top edge, as wide as most of the shorter side.
  const unit = Math.min(halfWidth, halfHeight);
  const base = halfHeight + 0.1 * unit;
  const t = 0.7 * unit;
  return [-t, base, z, t, base, z, 0, base + t, z];
}

/** Push the segment from (ax, ay, az) to (bx, by, bz). */
function segment(out: number[], ax: number, ay: number, az: number, bx: number, by: number, bz: number): void {
  out.push(ax, ay, az, bx, by, bz);
}

/** The rectangle of these halves at depth `z`: four segments. */
function rect(out: number[], w: number, h: number, z: number): void {
  segment(out, -w, -h, z, w, -h, z);
  segment(out, w, -h, z, w, h, z);
  segment(out, w, h, z, -w, h, z);
  segment(out, -w, h, z, -w, -h, z);
}

/** The four corners of one rectangle joined to the other's: four segments. */
function sides(out: number[], w0: number, h0: number, z0: number, w1: number, h1: number, z1: number): void {
  segment(out, -w0, -h0, z0, -w1, -h1, z1);
  segment(out, w0, -h0, z0, w1, -h1, z1);
  segment(out, w0, h0, z0, w1, h1, z1);
  segment(out, -w0, h0, z0, -w1, h1, z1);
}

const halves = [0, 0];

/**
 * The camera drawn as Blender draws one, as line segments -- six numbers each, from and to: perspective, the four
 * edges from where the camera is to the image plane's corners `depth` in front, that rectangle, and the up triangle's
 * outline (11 segments); orthographic, the rectangle at the camera and again `depth` in front, joined by four
 * parallel sides, and the triangle (15).
 */
export function pyramidLines(lens: ShapeLens, depth = DISPLAY_DEPTH): number[] {
  const out: number[] = [];
  const [w, h] = rectAt(lens, depth, halves) as [number, number];
  const z = -depth;
  if (lens.orthographic) {
    rect(out, w, h, 0);
    sides(out, w, h, 0, w, h, z);
  } else {
    sides(out, 0, 0, 0, w, h, z);
  }
  rect(out, w, h, z);
  const [lx, ly, lz, rx, ry, rz, ax, ay, az] = upTriangle(w, h, z) as [number, number, number, number, number, number, number, number, number];
  segment(out, lx, ly, lz, rx, ry, rz);
  segment(out, rx, ry, rz, ax, ay, az);
  segment(out, ax, ay, az, lx, ly, lz);
  return out;
}

/** The whole frustum, `near` to `far`, as line segments: both rectangles and the four edges joining them (12). */
export function frustumLines(lens: ShapeLens, near: number, far: number): number[] {
  const out: number[] = [];
  const n = Math.max(0, near);
  const f = Math.max(n, far);
  const [wn, hn] = rectAt(lens, n, [0, 0]) as [number, number];
  const [wf, hf] = rectAt(lens, f, [0, 0]) as [number, number];
  rect(out, wn, hn, -n);
  rect(out, wf, hf, -f);
  sides(out, wn, hn, -n, wf, hf, -f);
  return out;
}

/** Do two lenses draw the same: what decides whether a camera's lines are built again. */
export function sameLens(a: ShapeLens, b: ShapeLens): boolean {
  return a.orthographic === b.orthographic && a.aspect === b.aspect && (a.orthographic ? a.size === b.size : a.fov === b.fov);
}
