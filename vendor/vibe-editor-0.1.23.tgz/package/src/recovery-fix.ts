/**
 * Studio mode's recovery, Claude's try first (Docs/studio.md §1, "Claude tries first"): the game could not load, the
 * editor is up over a stand-in with the boot notice (`notices.ts`), and -- with `fixBoot` on (Claude's settings,
 * Config ▸ Claude ▸ Settings) -- Claude is sent the error and asked to fix it, a few times at most.
 *
 * - **When** (`shouldSend`): `fixBoot` on (the project's, every conversation's), the host available, no turn of any
 *   conversation running, fewer than `MAX_TRIES` tries made, none stopped since the last good boot, and none sent on
 *   this page already -- and `FIX_SETTLE_MS` after the editor is up, so Vite's own words have named the file. The boot
 *   notice is read at that send, never before: `namedByVite`'s rewrite of it needs no telling (no `poke`).
 * - **The tries are counted across reloads** in `sessionStorage` (`TRIES_KEY`, `ERROR_KEY`: `countTry`, once the turn
 *   is sent -- a try that never reached Claude is none); a boot that succeeds clears them (`clearTries`). A tab with no
 *   `sessionStorage` sends nothing (`UNCOUNTED_LINE`): its count would start again at each reload, a loop with no cap. The same error twice in a row still counts: the cap is what stops a
 *   loop. At the cap nothing is sent and the boot notice's line says it is the person's (`CAPPED_LINE`); Stop is a
 *   cap too (`STOPPED_KEY`, `STOPPED_LINE`), kept across the reloads until a good boot.
 * - **The turn** (`sendFix`): in the conversation titled `RECOVERY_TITLE` (found by its kept id or its title, else
 *   made and renamed: `titledConversation`, as the Git card's), Auto on for it, the prompt `fixPrompt` -- the boot
 *   error, a project tool's failure after it, and on a later try that the last did not fix it (the same error, or
 *   another). Its entries are read until its own result, `FIX_MS` at most; the result's files say whether it changed
 *   anything.
 * - **The page's side** (`createRecoveryFix`, as `createRecoveryReload` is `recovery.ts`'): when to try, the boot
 *   notice's line, Stop, and the turns' ends -- the try's own answered by its result (no files, no reload), every
 *   other handed to the reload rule (`heard`). The owned turn is let go when its result has not come a poll after
 *   no turn runs, or after `FIX_MS`.
 *
 * No DOM: the agent API, the storage, the clock and the card are handed in -- a node test runs all of it.
 */
import { projectKey } from '@vibe/engine/project-key';
import type { AgentState, ConversationsAnswer, Entry, StateAnswer, TurnRequest, Unavailable } from '@vibe/pipeline/agent-types';
import { isUnavailable } from './agent/api.ts';
import { bootText, type Notices } from './notices.ts';
import type { FixLine } from './notices-strip.ts';
import { titledConversation } from './studio/git/draft.ts';

/** The conversation Claude's tries are made in: listed in the Claude card as any other. */
export const RECOVERY_TITLE = 'Recovery';

/** At most this many tries in a row, across the reloads between them. */
export const MAX_TRIES = 3;

/** `sessionStorage`'s count of the tries made since the last good boot. */
export const TRIES_KEY = 'vibe:recovery:tries';

/** `sessionStorage`'s words of the last error a try was sent for. */
export const ERROR_KEY = 'vibe:recovery:error';

/** `sessionStorage`'s mark of a Stop: no try until a good boot clears it. */
export const STOPPED_KEY = 'vibe:recovery:stopped';

/** The conversation's id once found or made, kept for the next recovery page. */
export const CONVERSATION_KEY = 'vibe:recovery:conversation';

/** A turn's result entry: its files say whether it changed anything. */
export type ResultEntry = Extract<Entry, { kind: 'result' }>;

/** How often the turn's entries are read while it runs. */
export const FIX_POLL_MS = 1000;

/** How long after the editor is up a try waits: Vite's own words (`vite:error`) have named the file by then. */
export const FIX_SETTLE_MS = 1500;

/** How long after its turn's end the try's result may still come (a poll, and its answer): later, the turn is let go. */
export const FIX_END_MS = 2 * FIX_POLL_MS;

/** How long a try's result is waited for at most (as the Git card's `DRAFT_MS`): then it is let go, said failed. */
export const FIX_MS = 180_000;

/** The storage the count is kept in: `sessionStorage`, or a test's stand-in. */
export interface TryStore {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

/** The tries made since the last good boot. */
export function triesOf(store: TryStore): number {
  const n = Number(store.getItem(TRIES_KEY) ?? '0');
  return Number.isInteger(n) && n > 0 ? n : 0;
}

/** The error the last try was sent for, or null. */
export const lastError = (store: TryStore): string | null => store.getItem(ERROR_KEY);

/** A try sent for `error`: the count one more, the error kept. Answers the count now. */
export function countTry(store: TryStore, error: string): number {
  const n = triesOf(store) + 1;
  store.setItem(TRIES_KEY, String(n));
  store.setItem(ERROR_KEY, error);
  return n;
}

/** A good boot: the count, the error and a Stop gone. */
export function clearTries(store: TryStore): void {
  store.removeItem(TRIES_KEY);
  store.removeItem(ERROR_KEY);
  store.removeItem(STOPPED_KEY);
}

/** Stop pressed: no try until a good boot. */
export const markStopped = (store: TryStore): void => store.setItem(STOPPED_KEY, '1');

/** Was a try stopped since the last good boot? */
export const wasStopped = (store: TryStore): boolean => store.getItem(STOPPED_KEY) !== null;

/** What decides a send. */
export interface SendState {
  /** Claude's `fixBoot` setting. */
  fixBoot: boolean;
  /** The host can take a turn: Claude Code up. */
  available: boolean;
  /** A turn of any conversation running. */
  running: boolean;
  /** The tries made so far (before this one). */
  tries: number;
}

/** Is a try sent now? */
export const shouldSend = (s: SendState): boolean => s.fixBoot && s.available && !s.running && s.tries < MAX_TRIES;

/** The boot notice's error words: `bootText`'s middle -- Vite's file:line when it named one (`namedByVite`). */
export function bootError(noticeText: string): string {
  const [before, after] = bootText('\u0000').split('\u0000') as [string, string];
  const start = noticeText.startsWith(before) ? before.length : 0;
  const end = noticeText.endsWith(after) ? noticeText.length - after.length : noticeText.length;
  return noticeText.slice(start, Math.max(start, end)).trim();
}

/** A sentence's words with no full stop of their own at the end: the prompt puts one. */
const unstopped = (text: string): string => text.trim().replace(/[.\s]+$/, '');

/**
 * The prompt of a try: the error (and a project tool's failure, when there is one), what to do and not to. `again`,
 * a try after one that did not fix it; `last`, the error that try was sent for (`lastError`) -- the same words, said so.
 */
export function fixPrompt(error: string, tools: string | null, again: boolean, last: string | null = null): string {
  const what = !again
    ? `The error: ${unstopped(error)}.`
    : last === error
      ? `The last try did not fix it; the same error as the last try: ${unstopped(error)}.`
      : `The last try did not fix it; the error now is: ${unstopped(error)}.`;
  const also = tools ? ` A project tool module failed too: ${unstopped(tools)}.` : '';
  return `The game could not load in studio mode. ${what}${also} Find the cause and fix it so the page boots; change only what the error needs; do not run tests. Say in one line what was wrong.`;
}

/** The boot notice's line while a try runs. */
export const tryingLine = (n: number): string => `Claude is fixing it (try ${n} of ${MAX_TRIES})`;

/** The boot notice's line at the cap. */
export const CAPPED_LINE = `Claude tried ${MAX_TRIES} times: fix it here (Code, Claude), then Reload`;

/** The boot notice's line after a try that changed no file. */
export const NOTHING_LINE = 'Claude found nothing to change: fix it here';

/** The boot notice's line after Stop. */
export const STOPPED_LINE = 'Stopped: fix it here (Code, Claude), then Reload';

/** The boot notice's line where the tries cannot be counted across reloads: nothing sent. */
export const UNCOUNTED_LINE = 'This tab cannot keep the count of Claude\'s tries (no sessionStorage): fix it here (Code, Claude), then Reload';

/** The boot notice's line after a try that failed. */
export const failedLine = (why: string): string => `Claude's try did not finish -- ${unstopped(why)}: fix it here`;

/** The agent API's calls a try makes (`AgentApi`'s, or a test's). */
export interface FixApi {
  conversations(): Promise<ConversationsAnswer | Unavailable>;
  create(from: string | null): Promise<ConversationsAnswer>;
  rename(id: string, title: string): Promise<ConversationsAnswer>;
  of(id: string | null): {
    state(since?: number): Promise<StateAnswer | Unavailable>;
    turn(request: TurnRequest): Promise<{ uuid: string }>;
    settings(request: { level: 'auto' }): Promise<AgentState>;
    stop(): Promise<unknown>;
  };
}

export interface FixOptions {
  /** The conversation kept from the page before; null for none. */
  conversation: string | null;
  /** Told once the turn is sent, with the id of the conversation it went in (for Stop). */
  sent(conversation: string): void;
  /** A pause between reads: a test's at once. */
  wait?: (ms: number) => Promise<void>;
  /** True once nobody waits for the answer (the editor gone): the reading ends. */
  stopped?: () => boolean;
  /** How long the result is waited for: `FIX_MS`. */
  timeoutMs?: number;
}

/** A try's end as `sendFix` answers it. */
export type FixOutcome = { result: ResultEntry } | { failed: string; late?: true } | { gone: true };

/**
 * A try: its turn's result, or the server's words of why there was none -- or, its result not come in `FIX_MS` of
 * reading (the pauses counted), that it was not waited for longer.
 */
export async function sendFix(api: FixApi, prompt: string, options: FixOptions): Promise<FixOutcome> {
  const wait = options.wait ?? ((ms: number) => new Promise<void>((done) => setTimeout(done, ms)));
  const stopped = options.stopped ?? (() => false);
  const limit = options.timeoutMs ?? FIX_MS;
  const conversation = await titledConversation(api, options.conversation, RECOVERY_TITLE);
  const c = api.of(conversation);
  // Auto, never Unsafe auto: the recovery's edits go ahead, what can lose work still asks.
  await c.settings({ level: 'auto' });
  const first = await c.state(0);
  if (isUnavailable(first)) return { failed: first.why };
  let since = first.entries.reduce((n, e) => Math.max(n, e.seq), 0);
  const { uuid } = await c.turn({ prompt });
  options.sent(conversation);
  const heard: Entry[] = [];
  let waited = 0;
  for (;;) {
    if (waited >= limit) return { failed: `no answer in ${Math.round(limit / 1000)} s: see the Recovery conversation in the Claude card`, late: true };
    await wait(FIX_POLL_MS);
    waited += FIX_POLL_MS;
    if (stopped()) return { gone: true };
    const answer = await c.state(since);
    if (isUnavailable(answer)) return { failed: answer.why };
    for (const e of answer.entries) {
      heard.push(e);
      since = Math.max(since, e.seq);
    }
    const end = heard.find((e): e is ResultEntry => e.kind === 'result' && e.turn === uuid);
    if (end) return { result: end };
    const failed = heard.find((e) => e.kind === 'error');
    if (failed && failed.kind === 'error' && answer.state.running === null) return { failed: failed.text };
  }
}

/** The agent card's settings, as a try reads them (`AgentCard.settings`'s). */
export interface FixSettings {
  state(): AgentState | null;
  /** The session up: a turn can be sent. */
  up(): boolean;
  /** Told after each draw of the card's. Returns the undo. */
  on(fn: () => void): () => void;
}

/** What the page hands `createRecoveryFix`: the editor's, or a test's stand-ins. */
export interface RecoveryFixHost {
  api: FixApi;
  /** The tries' count across reloads (`tabTries`); null where the tab has none: then nothing is sent, said so. */
  store: TryStore | null;
  /** The notices up: the boot notice's words, a tools notice's. */
  notices: Pick<Notices, 'has' | 'list'>;
  /** The boot notice's line of the try (`NoticesStrip.fixLine`). */
  fixLine(line: FixLine | null): void;
  /** A turn of any conversation running (the agent card's). */
  running(): boolean;
  /** Told each time that changes (`AgentCard.onTurns`). Returns the undo. */
  onTurns(fn: (running: boolean) => void): () => void;
  settings: FixSettings;
  /** A turn's end the try does not answer itself, to the reload rule (`RecoveryReload.heard`). */
  heard(event: { kind: 'turn-ended' }): void;
  later(run: () => void, ms: number): unknown;
  cancel(timer: unknown): void;
}

export interface RecoveryFix {
  dispose(): void;
}

/**
 * The try on the page: `FIX_SETTLE_MS` after it is made, and at each change of the card's settings or turns after,
 * one try sent if `shouldSend` says so (none at the cap, or after a Stop since the last good boot: said); the boot
 * notice's line kept saying what it does; its turn's end answered by its result, every other turn's end handed on.
 */
export function createRecoveryFix(host: RecoveryFixHost): RecoveryFix {
  /** `idle` until a try is sent or found capped; then this page sends no other. */
  let phase: 'idle' | 'sent' | 'done' = 'idle';
  let due = false;
  /** The try's turn is this page's to answer: its end reloads only when it changed files. */
  let owned = false;
  /** The next turn's end heard reloads nothing: a try that changed nothing, failed or was stopped, its end not heard yet. */
  let swallow = false;
  let stopped = false;
  let gone = false;
  let conversation: string | null = null;
  let turnRan = host.running();
  /** The owned turn ended with no result read yet: let go a poll on, if it still has not come. */
  let endCheck: unknown = null;
  const store = host.store;
  const wait = (ms: number): Promise<void> => new Promise<void>((done) => void host.later(done, ms));
  const stopTurn = (id: string): void => void host.api.of(id).stop().catch(() => undefined);

  const stop = (): void => {
    stopped = true;
    if (store) markStopped(store);
    host.fixLine({ text: 'Stopping…' });
    if (conversation !== null) stopTurn(conversation);
  };
  /** The owned turn let go: its end, heard or to come, is the reload rule's to judge. */
  const letGo = (): void => {
    owned = false;
    if (endCheck !== null) host.cancel(endCheck);
    endCheck = null;
  };
  /** A try ended without a fix to land: said on the boot notice, its turn's end reloading nothing. */
  const ended = (text: string): void => {
    host.fixLine({ text });
    if (owned && host.running()) swallow = true;
    letGo();
  };
  const answered = (outcome: FixOutcome): void => {
    if (gone || 'gone' in outcome) return;
    if ('failed' in outcome) {
      // Not waited for longer: the turn let go, its end (if it ever comes) the reload rule's.
      if (outcome.late) {
        host.fixLine({ text: failedLine(outcome.failed) });
        return letGo();
      }
      return ended(failedLine(outcome.failed));
    }
    const { result } = outcome;
    if (stopped || result.how === 'stopped') {
      // The Claude card's own Stop as much as the line's: no try until a good boot.
      if (store) markStopped(store);
      return ended(STOPPED_LINE);
    }
    if (!result.ok) return ended(failedLine(result.why ?? 'the turn failed'));
    if (result.files.length === 0) return ended(NOTHING_LINE);
    // Files changed: the reload rule takes over -- a second after the turn's end (now, or when the list says so).
    host.fixLine({ text: `Claude changed ${result.files.length === 1 ? 'a file' : `${result.files.length} files`}: the page reloads to try it` });
    letGo();
    host.heard({ kind: 'turn-ended' });
  };

  const tryFix = (): void => {
    if (gone || !due || phase !== 'idle' || !host.notices.has('boot')) return;
    const state = host.settings.state();
    if (state === null) return;
    if (store === null) {
      phase = 'done';
      if (state.settings.fixBoot) host.fixLine({ text: UNCOUNTED_LINE });
      return;
    }
    const tries = triesOf(store);
    const capped = tries >= MAX_TRIES ? CAPPED_LINE : wasStopped(store) ? STOPPED_LINE : null;
    if (capped !== null) {
      phase = 'done';
      if (state.settings.fixBoot) host.fixLine({ text: capped });
      return;
    }
    if (!shouldSend({ fixBoot: state.settings.fixBoot, available: host.settings.up(), running: host.running(), tries })) return;
    const boot = host.notices.list.find((n) => n.kind === 'boot');
    if (!boot) return;
    phase = 'sent';
    owned = true;
    const error = bootError(boot.text);
    const tools = host.notices.list.filter((n) => n.kind === 'tools').map((n) => n.text).join(' ') || null;
    const last = lastError(store);
    host.fixLine({ text: tryingLine(tries + 1), stop });
    sendFix(host.api, fixPrompt(error, tools, tries > 0, last), {
      conversation: store.getItem(CONVERSATION_KEY),
      sent: (id) => {
        // Counted once Claude has it: a rejection before (no conversation made, the host gone) burns no try.
        countTry(store, error);
        conversation = id;
        store.setItem(CONVERSATION_KEY, id);
        if (stopped) stopTurn(id);
      },
      wait,
      stopped: () => gone,
    }).then(answered, (err: unknown) => {
      if (!gone) ended(failedLine(err instanceof Error ? err.message : String(err)));
    });
  };

  const settle = host.later(() => {
    due = true;
    tryFix();
  }, FIX_SETTLE_MS);
  const offTurns = host.onTurns((running) => {
    /** Another turn's end, to hand on -- after `tryFix`, which may send in this same tick. */
    let foreign = false;
    if (turnRan && !running) {
      if (swallow) swallow = false;
      else if (!owned) foreign = true;
      else if (endCheck === null) {
        // The try's own end: its result answers it -- read within a poll; not come by then (no result entry, the reading
        // gone wrong), the turn is let go and its end handed on.
        endCheck = host.later(() => {
          endCheck = null;
          if (!owned || host.running()) return;
          letGo();
          host.heard({ kind: 'turn-ended' });
        }, FIX_END_MS);
      }
    }
    turnRan = running;
    const was = phase;
    tryFix();
    // A try sent now: the other turn's end reloads nothing -- the reload a second away would cut the try off; the
    // try's own end decides.
    if (foreign && !(was === 'idle' && phase === 'sent')) host.heard({ kind: 'turn-ended' });
  });
  const offSettings = host.settings.on(tryFix);
  return {
    dispose() {
      gone = true;
      host.cancel(settle);
      if (endCheck !== null) host.cancel(endCheck);
      offTurns();
      offSettings();
    },
  };
}

/**
 * This tab's `sessionStorage` as a `TryStore`, each call kept from throwing; null where there is none, or where it
 * takes no write (blocked storage, a full quota): a count that is not kept would start again at each reload. Every
 * key at the project's id (`projectKey`): another project on the same port -- the same origin -- counts its own
 * tries and keeps its own conversation.
 */
export function tabTries(): TryStore | null {
  let s: Storage;
  const at = (key: string): string => projectKey(key);
  try {
    s = globalThis.sessionStorage;
    if (!s) return null;
    s.setItem(at(TRIES_KEY), s.getItem(at(TRIES_KEY)) ?? '0');
  } catch {
    return null;
  }
  return {
    getItem(key) {
      try {
        return s.getItem(at(key));
      } catch {
        return null;
      }
    },
    setItem(key, value) {
      try {
        s.setItem(at(key), value);
      } catch {
        // Not kept: a write it took a moment ago (the probe above) it should take again; the cap is per page meanwhile.
      }
    },
    removeItem(key) {
      try {
        s.removeItem(at(key));
      } catch {
        // Nothing to do.
      }
    },
  };
}
