/**
 * The editor's chrome, CrabParty's look: the top bar, the tool strip down the
 * left edge, the card a playtest leaves, a side card made resizable and
 * foldable (`sidePanel`), and the parts every card is built of (`el`, `icon`,
 * `button`, `iconButton`, `withKey`, `tip`, from `dom.ts`, which node can
 * import).
 *
 * - **One top bar, one row, icons only, in three parts** (a grid: the sides
 *   `minmax(min-content, 1fr)`, the centre `auto`): at the left the editor's
 *   mark, then the host's gizmo, toggles and status line (`controls`, filled by
 *   `top-bar.ts`); in the bar's centre Save and the play strip -- Play, Pause,
 *   Stop, Step, each on when it applies, and a pill in the accent while there
 *   is a playtest (`PAUSED · tick 740`; `setPlaytest`, `playtest-state.ts`);
 *   right after it the tools' own (`middle`, filled through
 *   `EditorContext.control`: the Studio tab's problems count, spinner and
 *   Build); at the right end AI -- Claude's card shown or hidden, lit while
 *   it shows (`setAi`) -- Undo and Redo. The centre is the bar's centre
 *   while both sides fit their half; a side that does not (the gizmo's snap
 *   steps on, a narrow window) pushes it over rather than under. Each icon's
 *   name and key are its tooltip (`tip`). It never wraps: the status line
 *   gives way first.
 * - **The scene's header** (`head`): `Scene`, the scene's name and its unsaved
 *   dot -- or, a prefab open, `Prefab`, its key, its Save and Back, which never
 *   give way -- and under it Back's question and why a prefab is read-only
 *   (`under`). Built here, placed at the top of the Scene tab's left panel by
 *   the tool whose card that is (the tree, `EditorContext.head`).
 * - **Docked side panels** (`sidePanel`): each fills its side flush, from
 *   under the top bar to the window's foot -- the left one from the strip's
 *   edge, the right one to the window's or to Claude's column docked there --
 *   one hairline on its inner side, its inner edge a handle (`dragGrip`).
 * - **Claude's column** (`aiColumn`, Docs/ai-panel.md §3): the agent's card at
 *   the window's right edge, right of the inspector, full height, its width
 *   dragged by the same handle and kept (`panels.ai`). Docked (`.ed-ai-docked`
 *   on the root) it takes its width from everything to its left
 *   (`--ed-ai-room`: the inspector, the Assets panel, a page card, the room);
 *   on a room too narrow for both (`.ed-ai-over`) it lies over the scene
 *   beside the inspector and takes nothing. Hidden, neither class.
 * - **The tabs down the left edge**: an icon each, the current one lit --
 *   the current tool is the most important piece of state in an editor --
 *   in the tools' order from the top, but one placed at the foot (`place:
 *   'bottom'`, the Config tab), pinned there (`.ed-strip-foot`). A
 *   tool shown within another's tab (the Assets panel, in Scene) has none:
 *   that tab's icon is its way in, its key the other.
 * - **A playtest docked** (`.ed-docked`, Docs/game-view.md §3): every card
 *   where it is, the game in the scene's room between them; what edits --
 *   the side cards, the tool strip, the Assets panel, the top bar but its
 *   play strip and AI button -- shown but `inert` while it runs.
 * - **The pill over the game** (`.ed-play`), the one card left while a
 *   playtest runs maximized (Maximize on Play, the play strip's toggle): the
 *   same four buttons and words (`PLAYING · 12.3 s`), and the agent's badge
 *   beside them.
 * - **The paused tint** (`.ed-paused`): a playtest paused, a 2 px edge in the
 *   accent round the scene's part of the window.
 * - **DOM, not the canvas UI**: an editor is for the person making the game,
 *   never in a recording, and it wants real inputs. Its stylesheet comes in
 *   as a string with this module, so a release, which has no editor, has none;
 *   a tool's own goes in the same way (`addSheet`).
 */
import css from './shell.css?inline';
import { button, control, el, icon, iconButton, tip, withKey } from './dom.ts';
import { playtestBar, type PlayButton, type PlaytestState } from './playtest-state.ts';
import type { IconName } from './icons.ts';
import { keepPref, loadPrefs, PANEL, panelWidthFor } from './prefs.ts';
import { AI_WIDTH } from './room.ts';
import { ENTITIES_DRAG, MATERIAL_DRAG, MODEL_DRAG, PREFAB_DRAG } from './prefab-drop.ts';
import { keyLabel } from '@vibe/engine/debug';
import { LOCK_KEY, LOCK_WORDS, type LockHost } from './inspector-lock.ts';
import type { Mcp } from './mcp/declare.ts';

/** How long a prefab drag is held over a tool's icon before that tool comes up. */
const SPRING_MS = 600;

export { button, control, el, icon, iconButton, keepsBrowserMenu, mcpText, tip, withKey } from './dom.ts';

/**
 * A button of the host's that lets go of the focus once a pointer has used it
 * (a click with `event.detail > 0`; Enter and Space give 0): Chrome focuses a
 * button pressed, and the next key would be its own. A tool's card keys stand
 * still while a control of the editor's is focused (the Assets tool's guard,
 * Docs/assets-tool.md §8) -- so the tab clicked, the bar's Keys clicked and
 * its card closed, or Save pressed, would leave every card key dead until a
 * click inside a card. Reached by Tab, a button keeps the focus, and its ring.
 */
/** How long the editor's cards take to slide out when it is put away (`.ed-shut` in shell.css: 0.22 s, the last a 0.06 s lag behind): the root hides after. */
const OUT_MS = 320;

export function letGo<T extends HTMLElement>(b: T): T {
  // mcp: typed: letGo's argument -- a control declared where it was made; this lets the focus go
  b.addEventListener('click', (event) => {
    if (event.detail > 0) queueMicrotask(() => document.activeElement === b && b.blur());
  });
  return b;
}

/**
 * The scene's header (`Shell.head`): its own block, for the card that shows
 * the scene's entities to put at its top -- and `end`, the end of its row, for
 * that card's own controls (its fold).
 */
export interface PanelHead {
  readonly root: HTMLElement;
  readonly end: HTMLElement;
}

/** A side panel made foldable and resizable (`sidePanel`). */
export interface SidePanel {
  /** The control that folds it away: for the panel's title row, wherever that is built. */
  readonly fold: HTMLButtonElement;
  readonly folded: boolean;
  setFolded(folded: boolean): void;
  /**
   * Its width and fold on screen again -- `--ed-<side>`, `--ed-<side>-room` --
   * from its preference as kept now: called from its tool's `setVisible(true)`,
   * as another tool's card on the same side has set them to its own, or one
   * kept under the same preference (the entity and Assets inspectors share
   * `right`) has changed them.
   */
  refresh(): void;
  /**
   * A glyph after its name on the folded tab, written up the spine as the name
   * is -- `''` for none -- and what it means on hover: what needs a look in a
   * card folded away (the Assets tool's `⚠`).
   */
  mark(text: string, title?: string): void;
  dispose(): void;
}

export interface SidePanelOptions {
  /** On the edge tab while it is folded, and in the controls' titles: `Entities`, `Inspector`. */
  name: string;
  /**
   * The preference its width and fold are kept under (`panels[pref]`): its
   * side's by default -- the tree's `left`, the inspector's `right` -- or a
   * name of its own, `assets-folders`, so two tools' cards on one side keep
   * theirs apart. A new one starts as wide as its side's.
   */
  pref?: string;
  /** Told after it folds or unfolds: a list drawn only where it is seen draws again. */
  changed?(folded: boolean): void;
}

/**
 * A panel's inner edge made a handle (`sidePanel`'s, `aiColumn`'s): dragged, the panel's width follows the pointer --
 * `wider` the way that widens it -- written as `variable` on the editor's root; let go, `keep` keeps it; a double-click
 * puts back `usual`. The width is held by `panelWidthFor` as it is set, the stylesheet's own clamp (`--ed-*-w`) worked
 * out for this window: the stylesheet's holds a panel as the window changes with nothing dragged, this one makes
 * the width kept the one that was seen. `set` says each width set, held; the returned `set` sets one.
 */
function dragGrip(
  root: HTMLElement,
  grip: HTMLElement,
  panel: HTMLElement,
  options: { variable: string; wider: 1 | -1; usual: number; set(width: number): void; keep(): void },
): { set(to: number): number } {
  const set = (to: number): number => {
    const width = panelWidthFor(to, innerWidth);
    root.style.setProperty(options.variable, `${width}px`);
    options.set(width);
    return width;
  };
  let press: { id: number; x: number; from: number } | null = null;
  grip.addEventListener('pointerdown', (event) => {
    if (event.button !== 0) return;
    event.preventDefault();
    // From the width it has, as the stylesheet holds it, border and all.
    press = { id: event.pointerId, x: event.clientX, from: panel.getBoundingClientRect().width };
    grip.setPointerCapture(event.pointerId);
    grip.classList.add('ed-dragging');
  });
  grip.addEventListener('pointermove', (event) => {
    if (!press || press.id !== event.pointerId) return;
    set(press.from + options.wider * (event.clientX - press.x));
  });
  const release = (event: PointerEvent): void => {
    if (!press || press.id !== event.pointerId) return;
    press = null;
    grip.classList.remove('ed-dragging');
    if (grip.hasPointerCapture(event.pointerId)) grip.releasePointerCapture(event.pointerId);
    options.keep();
  };
  grip.addEventListener('pointerup', release);
  grip.addEventListener('pointercancel', release);
  // mcp: ui -- the panel's width put back
  grip.addEventListener('dblclick', () => {
    set(options.usual);
    options.keep();
  });
  return { set };
}

/**
 * A side card of a tool's -- the tree, the inspector -- given what a side panel
 * has in an editor, both kept with the editor's preferences (`panels.left`,
 * `panels.right`, or `panels[pref]` for a card of its own):
 *
 * - **Docked**: flush to its side, from under the top bar to the window's
 *   foot -- the left one from the tool strip's edge, the right one to the
 *   window's -- square-edged, a hairline on its inner side (`.ed-side`,
 *   shell.css). The card along the bottom fills what is between them.
 * - **A width, dragged**: the card's inner edge is a handle. The width goes
 *   into a CSS variable on the editor's root (`--ed-left`, `--ed-right`), which
 *   the card and the bottom card read, and which the stylesheet holds between
 *   `PANEL_MIN` and a cap that leaves the scene its room as the window
 *   changes. A double-click on the edge puts it back to `PANEL`.
 * - **Folded away**: `fold`, a control for the card's title row, folds it to a
 *   tab at the screen's edge, its name written up it; the tab, clicked, brings
 *   it back. Clicked, not hovered: a card that springs out under a pointer on
 *   its way to the scene's edge would be in the way of the scene. Folded, the
 *   room is the scene's -- the card along the bottom spreads into it
 *   (`--ed-left-room`).
 *
 * The handle and the tab are elements of their own beside the card, not in it
 * -- the card scrolls, and they would scroll away -- right after it, so they go
 * where it goes: hidden with it (`.ed-side[hidden] + …`), and the tab only
 * while it is folded and would otherwise be shown. The card's own `hidden`
 * stays its tool's: folded is a class (`ed-folded`).
 *
 * Two tools' cards on one side share the variables: each tool calls
 * `refresh()` as it comes up, so the side is its card's again.
 */
export function sidePanel(root: HTMLElement, panel: HTMLElement, side: 'left' | 'right', { name, changed, pref = side }: SidePanelOptions): SidePanel {
  const prefs = loadPrefs().panels;
  const kept = prefs[pref] ?? prefs[side];
  let width = kept.width;
  let folded = false;
  const keep = (): void => keepPref('panels', { ...loadPrefs().panels, [pref]: { width, folded } });

  const grip = el('div', `ed-grip ed-grip-${side}`);
  grip.title = 'Drag to make the panel wider or narrower; double-click for its usual width';
  // Toward the edge it folds to, and back out from it.
  const away: IconName = side === 'left' ? 'foldLeft' : 'foldRight';
  const back: IconName = side === 'left' ? 'foldRight' : 'foldLeft';
  const fold = letGo(iconButton(
    'ui', away,
    `Fold the ${name.toLowerCase()} away to the side: a tab at the edge brings it back`,
    () => setFolded(true),
    'ed-icon-button ed-fold',
  ));
  const tab = letGo(control('ui', `ed-card ed-tab ed-tab-${side}`));
  tab.title = `Show the ${name.toLowerCase()} again`;
  const marked = el('span', 'ed-tab-mark');
  marked.hidden = true;
  tab.append(icon(back), el('span', undefined, name), marked);
  tab.addEventListener('click', () => setFolded(false));
  panel.classList.add(`ed-sized-${side}`);
  panel.after(grip, tab);

  const drag = dragGrip(root, grip, panel, {
    variable: `--ed-${side}`,
    wider: side === 'left' ? 1 : -1,
    usual: PANEL,
    set: (to) => void (width = to),
    keep: () => keep(),
  });
  const set = (to: number): void => void (width = drag.set(to));
  set(width);

  /** Folded or not, on screen. */
  const show = (): void => {
    panel.classList.toggle('ed-folded', folded);
    // Its room the scene's while it is away: the dock spreads into it.
    if (folded) root.style.setProperty(`--ed-${side}-room`, '0px');
    else root.style.removeProperty(`--ed-${side}-room`);
  };
  // As it was left: told nobody, as nothing has been drawn yet.
  folded = kept.folded;
  show();

  function setFolded(next: boolean): void {
    if (next === folded) return;
    folded = next;
    show();
    keep();
    changed?.(folded);
  }

  return {
    fold,
    get folded() {
      return folded;
    },
    setFolded,
    refresh() {
      // As kept: another card under the same preference -- the two inspectors of the Scene tab -- may have changed it.
      const now = loadPrefs().panels;
      const kept = now[pref] ?? now[side];
      width = kept.width;
      folded = kept.folded;
      set(width);
      show();
    },
    mark(text, title = '') {
      marked.textContent = text;
      marked.hidden = text === '';
      marked.title = title;
      tab.title = title ? `Show the ${name.toLowerCase()} again: ${title}` : `Show the ${name.toLowerCase()} again`;
    },
    dispose() {
      grip.remove();
      tab.remove();
      fold.remove();
      root.style.removeProperty(`--ed-${side}`);
      root.style.removeProperty(`--ed-${side}-room`);
    },
  };
}

/** Claude's column placed (`aiColumn`): docked at the window's edge, or over the scene beside the inspector. */
export interface AiColumn {
  /** Docked (the room the column's width narrower) or over the scene (D5), as the host measured -- while it is shown. */
  readonly docked: boolean;
  /** Placed as the host measured: docked or over the scene; hidden (the card's own `hidden`), neither. */
  place(docked: boolean): void;
  /** Its width as drawn, border and all: what the room loses while it docks. */
  width(): number;
  dispose(): void;
}

/**
 * Claude's column (Docs/ai-panel.md §3, D1, D5): the agent's card made a docked column of the host's, at the window's
 * right edge, right of the inspector -- from under the top bar to the foot, flush, a hairline on its inner side, its
 * width dragged by the grip on that side and kept (`panels.ai`, `AI_WIDTH` to start; double-click puts it back),
 * held as a side panel's is (`--ed-ai`, `--ed-ai-w`). Shown or hidden is the card's own `hidden` (D2).
 *
 * `place` says where: **docked**, the root's `.ed-ai-docked` gives the inspector, the Assets panel, a page card and
 * the room its width (`--ed-ai-room`); **over the scene** (the room too narrow for both, D5), `.ed-ai-over` lays it
 * beside the inspector with a shadow on its inner edge and the room keeps the window's edge. Hidden: neither.
 */
export function aiColumn(root: HTMLElement, card: HTMLElement): AiColumn {
  let width = loadPrefs().panels.ai?.width ?? AI_WIDTH;
  let docked = true;
  card.classList.add('ed-ai-column');
  const grip = el('div', 'ed-grip ed-grip-ai');
  grip.title = 'Drag to make Claude\'s column wider or narrower; double-click for its usual width';
  card.prepend(grip);
  const keep = (): void => keepPref('panels', { ...loadPrefs().panels, ai: { width, folded: false } });
  width = dragGrip(root, grip, card, {
    variable: '--ed-ai',
    wider: -1,
    usual: AI_WIDTH,
    set: (to) => void (width = to),
    keep: () => keep(),
  }).set(width);
  return {
    get docked() {
      return docked;
    },
    place(next) {
      docked = next;
      root.classList.toggle('ed-ai-docked', !card.hidden && docked);
      root.classList.toggle('ed-ai-over', !card.hidden && !docked);
    },
    width: () => card.getBoundingClientRect().width,
    dispose() {
      grip.remove();
      card.classList.remove('ed-ai-column');
      root.classList.remove('ed-ai-docked', 'ed-ai-over');
      root.style.removeProperty('--ed-ai');
    },
  };
}

export interface ToolSpec {
  id: string;
  name: string;
  icon: IconName;
  /** The key that picks it, as a person reads it (`1`): in its tooltip, so it is discoverable. */
  key?: string;
  /** Shown within another tool's tab -- the Assets panel, along the bottom of Scene -- so no tab of its own, and no icon. */
  within?: boolean;
  /** Its tab pinned to the strip's foot (`EditorTool.place`: the Config tab's); else at the top, in order. */
  place?: 'bottom';
}

export interface ShellOptions {
  /** What it is editing -- the scene's name, an opened prefab's key -- in the scene's header (`head`). Read every refresh. */
  name(): string;
  /** Changed since it was saved: a dot after the name. Read every refresh. */
  unsaved(): boolean;
  /** The name's hover text -- when it was saved -- read every refresh and as the pointer comes onto it. */
  nameNote(): string;
  tools: ToolSpec[];
  /** Told after the shell has switched tool. */
  onTool(id: string): void;
  undo(): void;
  redo(): void;
  canUndo(): boolean;
  canRedo(): boolean;
  /** What they would take back or do again, in their tooltips: 'Undo Move · ⌘Z'. */
  undoLabel(): string | null;
  redoLabel(): string | null;
  /** The keys as a person reads them, in the tooltips: `⌘Z`, `⇧⌘Z`, `⌘S`, `T`, `P`. */
  undoKey: string;
  redoKey: string;
  save(): void;
  saveKey: string;
  /** One of the play strip's or the pill's buttons clicked: Play, Pause, Stop, Step -- the event its key sends (`playtest-state.ts`). */
  play(button: PlayButton): void;
  /** Their keys as a person reads them, for the tooltips: `F5`, `F6`, `⇧F5`, `F10`. */
  playKeys: Record<PlayButton, string>;
  /** The play strip's Maximize on Play toggle clicked: turned over (Docs/game-view.md §3). */
  maximize(): void;
  /** The play strip's game view dropdown clicked: its menu of presets under `button` (Docs/game-view.md §4). */
  gameView(button: HTMLElement): void;
  /** The AI button clicked: Claude's card shown, or minimized (Docs/agent.md §4). */
  ai(): void;
  /** Its key as a person reads it: `⌘I`. */
  aiKey: string;
  /** The prefab open (Docs/prefabs.md §7): written to its file, and the world it was opened from put back. */
  prefabSave(): void;
  prefabBack(): void;
  /** Back's key, for its tooltip. */
  backKey: string;
}

/** What the scene's header says of a prefab opened to edit: its Save and Back, and why it cannot be saved. */
export interface OpenedLine {
  /** What Back returns to: the scene, or the prefab it was opened from. */
  back: string;
  /** Why Save is off: its compile error; null if it can be saved. */
  readOnly: string | null;
  /** Edited since opened or saved: Save is off while nothing is. */
  unsaved: boolean;
}

export interface Shell {
  readonly root: HTMLElement;
  /** The bar across the top, one row: what bounds the dock and the side cards from above (`--ed-top-h`). */
  readonly top: HTMLElement;
  /**
   * The scene's header: `Scene` and its name and unsaved dot, or `Prefab`, the
   * prefab open, its Save and Back -- and under it `under`. Placed at the top of
   * the Scene tab's left panel by the card that is (`EditorContext.head`).
   */
  readonly head: PanelHead;
  /** The tools' icons down the left edge, under the top bar: what the left cards and framing stay right of. */
  readonly strip: HTMLElement;
  /**
   * The top bar's middle, between the scene's name and the actions -- free
   * while an Apply lands, as it changes neither the world nor its history
   * (`.ed-hint`, `hold.ts`): the host's gizmo, toggles and status line go in
   * it (`top-bar.ts`).
   */
  readonly controls: HTMLElement;
  /**
   * The tools' own controls in the top bar (`EditorContext.control`, the
   * Studio tab's problems count, spinner and Build), in their order: right
   * after Save and the play strip in the bar's centre, at the start of its
   * right part, before Undo and Redo at its end. Empty, it takes no room.
   */
  readonly middle: HTMLElement;
  /**
   * Under the scene's header, shown while it has something in it: an opened
   * prefab's read-only line, and Back's question (`createAsk`).
   */
  readonly under: HTMLElement;
  readonly tool: string;
  select(id: string): void;
  /** Re-read everything the bar shows: the name, whether Undo and Redo can, which tool within a tab has the keys. */
  refresh(): void;
  /**
   * The editor shown or put away, its cards sliding in or out as the key left
   * of `1` slides them (`.ed-shut`, the same rules as `.ed-away`): hidden, the
   * root goes once they are gone (`OUT_MS`); the first hide, before it was ever
   * shown, is at once.
   */
  setHidden(hidden: boolean): void;
  /** Shown, or on its way in: false the moment `setHidden(true)` is called, while its cards still slide out. */
  readonly shown: boolean;
  /**
   * A playtest running or not. Maximized (Maximize on Play): everything but the card that says so out of the way, or
   * back. Docked: every card where it is, what edits inert (Docs/game-view.md §3).
   */
  setPlaying(playing: boolean, maximized: boolean): void;
  /** The play strip's Maximize on Play toggle lit, or not. */
  setMaximize(on: boolean): void;
  /** The play strip's game view dropdown: the preset's name on it, and its tooltip (Docs/game-view.md §4). */
  setGameView(label: string, title: string): void;
  /**
   * The AI button as the agent's card is: lit (`aria-pressed`) while it shows, unlit while it is minimized -- or,
   * with `null`, hidden: no card to show (a build without a dev server). The host says which once, as its card is made
   * or not, and the card after. `mark` (Docs/ai-panel.md §8): a dot at its corner (`data-mark`) for a conversation not
   * looked at -- `waiting` the warning colour (Claude is waiting for you), `failed` the danger colour (a turn ended in an
   * error), `done` the accent (a turn finished); none, none.
   */
  setAi(shown: boolean | null, mark?: 'waiting' | 'failed' | 'done' | null, running?: boolean): void;
  /** A word on the playtest's card, while the dock is hidden under it: "Claude is waiting for you"; null for none. */
  setBadge(text: string | null): void;
  /**
   * The play strip and the pill as `state` has them (`playtestBar`): each button on when it applies, the words
   * (`ticks` the playtest's so far), the paused tint. Called again each second while one runs, for the time.
   */
  setPlaytest(state: PlaytestState, ticks?: number): void;
  /**
   * Every card put away, the scene alone, or brought back: each block slides
   * off the edge it lives on and back again (`.ed-away`, shell.css) -- the top
   * bar up, the strip left. Still open -- the scene is worked in as before --
   * only nothing is in front of it.
   */
  setAway(away: boolean): void;
  /** A prefab opened to edit, or none: the header `Prefab`, its key, Save and Back, in place of `Scene` and its name (`name`). */
  setOpened(line: OpenedLine | null): void;
  dispose(): void;
}

/** Each stylesheet in the page once, however many use it, by its text: counted, so the last one done with it takes it away. */
const sheets = new Map<string, { style: HTMLStyleElement; users: number }>();

/**
 * A stylesheet in the page -- the shell's own, a tool's (`assets.css?inline`)
 * -- as a `<style>` made once however many ask for it. Returns the way to say
 * it is not needed any more: the last of them takes it out.
 */
export function addSheet(text: string): () => void {
  let sheet = sheets.get(text);
  if (!sheet) {
    const style = el('style');
    style.textContent = text;
    document.head.append(style);
    sheets.set(text, (sheet = { style, users: 0 }));
  }
  sheet.users++;
  let dropped = false;
  return () => {
    if (dropped) return;
    dropped = true;
    const now = sheets.get(text);
    if (!now || --now.users > 0) return;
    now.style.remove();
    sheets.delete(text);
  };
}

/**
 * The four in their order, each by the event it sends, with its icon, its tooltip and the `PlaytestBar` field that
 * turns it on. Play's tooltip is the state's (`PlaytestBar.playTip`): Play, or Resume while paused.
 */
const PLAY_ORDER: readonly PlayButton[] = ['F5', 'F6', 'stop', 'step'];
const PLAY_ICON: Record<PlayButton, IconName> = { F5: 'play', F6: 'pause', stop: 'stop', step: 'step' };
/** Each play button's tool: F5 plays, or runs a paused playtest on. */
export const PLAY_MCP: Record<PlayButton, Mcp> = { F5: 'play_start', F6: 'play_pause', stop: 'play_stop', step: 'play_step' };
const PLAY_TIP: Record<Exclude<PlayButton, 'F5'>, string> = {
  F6: 'Pause the playtest: the editor over its world as it is now',
  stop: 'Stop the playtest: the world put back as it found it',
  step: 'Step: one tick of the game, then paused again',
};
const PLAY_FIELD = { F5: 'play', F6: 'pause', stop: 'stop', step: 'step' } as const satisfies Record<PlayButton, keyof ReturnType<typeof playtestBar>>;

/**
 * Play, Pause, Stop and Step into `into`, as the bar's buttons are: an icon each, its key in its tooltip, letting go
 * of the focus after a click (`letGo`) -- the keys stay the game's, or the tool's. All off until `setPlaytest`.
 */
function playButtons(options: ShellOptions, into: HTMLElement): Record<PlayButton, HTMLButtonElement> {
  const made = {} as Record<PlayButton, HTMLButtonElement>;
  for (const b of PLAY_ORDER) {
    const name = b === 'F5' ? (playtestBar('none').playTip ?? '') : PLAY_TIP[b];
    made[b] = barButton(PLAY_MCP[b], into, name, options.playKeys[b], PLAY_ICON[b], () => options.play(b), b === 'F5' ? 'ed-go' : undefined);
  }
  return made;
}

/** One of the top bar's icon buttons into `into`: its name and key in its tooltip, letting go of the focus after a click (`letGo`) -- the tool up has the keys. */
const AI_TIP = 'AI: show or hide Claude\'s card';
const MAXIMIZE_TIP = 'Maximize on Play';
/** The cards a docked playtest leaves in sight but inert: everything that edits (Docs/game-view.md §3). */
const DOCKED_INERT = '.ed-left, .ed-right, .ed-tab-left, .ed-tab-right, .ed-grip-left, .ed-grip-right, .ed-strip, .ed-bottom-card';

function barButton(mcp: Mcp, into: HTMLElement, name: string, key: string, glyph: IconName, run: () => void, extra?: string): HTMLButtonElement {
  const b = letGo(control(mcp, extra ? `ed-bar-button ${extra}` : 'ed-bar-button'));
  tip(b, name, key);
  b.append(icon(glyph));
  b.addEventListener('click', run);
  into.append(b);
  return b;
}

export function createShell(options: ShellOptions): Shell {
  const dropSheet = addSheet(css);

  const root = el('div', 'ed');
  let tool = options.tools.find((t) => !t.within)?.id ?? '';

  // ---------------------------------------------------------------- the scene's header

  // `Scene`, the scene's name and its unsaved dot -- or `Prefab`, its key, Save and Back, which never give way.
  const head = el('div', 'ed-scene-head');
  const headRow = el('div', 'ed-panel-head ed-panel-bar');
  const kind = el('span', 'ed-side-title ed-head-kind', 'Scene');
  const nameText = el('span', 'ed-head-name');
  // Text, not a span: the dot is the one element in it, with a hover of its own.
  const subtitleName = document.createTextNode('');
  const dot = el('i', 'ed-unsaved', ' •');
  dot.title = 'Changed since it was saved: Save writes it';
  nameText.append(subtitleName, dot);
  const openedRow = el('div', 'ed-opened');
  openedRow.hidden = true;
  const prefabSave = letGo(button('scene_save', 'Save', '', () => options.prefabSave(), 'ed-small ed-accent'));
  const prefabBack = letGo(button('scene_close_prefab', 'Back', '', () => options.prefabBack(), 'ed-small'));
  for (const b of [prefabSave, prefabBack]) b.removeAttribute('title');
  openedRow.append(prefabSave, prefabBack);
  /** The card's own controls, at the row's end: the tree's fold. */
  const headEnd = el('span', 'ed-head-end');
  headRow.append(kind, nameText, openedRow, headEnd);
  // Read as the pointer comes: "saved 3 min ago" is out of date a minute later.
  const note = (): void => void (nameText.title = options.nameNote());
  nameText.addEventListener('pointerenter', note);

  // Under the header: why an opened prefab cannot be saved, and Back's question (`createAsk`).
  const under = el('div', 'ed-under');
  const readOnly = el('div', 'ed-opened-why');
  readOnly.hidden = true;
  under.append(readOnly);
  head.append(headRow, under);

  // The top bar's left end: the editor's mark alone, over the tool strip.
  const title = el('div', 'ed-title');
  title.append(icon('props'));

  // ---------------------------------------------------------------- the bar's three parts

  // The left: the mark, then the host's gizmo, toggles and status line.
  const controls = el('div', 'ed-hint');
  const left = el('div', 'ed-top-left');
  left.append(title, el('i', 'ed-hint-gap'), controls);
  // The centre: Save, then the play strip -- Play, Pause, Stop, Step -- and the pill saying what the playtest is doing.
  const centre = el('div', 'ed-top-centre');
  const saveButton = barButton('scene_save', centre, 'Save', options.saveKey, 'save', () => options.save());
  const strip4 = playButtons(options, centre);
  // Maximize on Play: where the next playtest plays -- the whole window, or the scene's room (lit while on).
  const maximizeButton = barButton('game_view_set', centre, MAXIMIZE_TIP, '', 'maximize', () => options.maximize(), 'ed-maximize');
  maximizeButton.setAttribute('aria-pressed', 'false');
  // The game view's dropdown: the preset the game's cameras are shaped by -- Free Aspect, 16:9, 320×180 Pixel -- its menu the host's.
  const gameViewButton = letGo(control('ui', 'ed-bar-button ed-game-view'));
  gameViewButton.setAttribute('aria-haspopup', 'menu');
  const gameViewLabel = el('span', 'ed-game-view-name', 'Free Aspect');
  gameViewButton.append(gameViewLabel, el('span', 'ed-menu-more', '▾'));
  gameViewButton.addEventListener('click', () => options.gameView(gameViewButton));
  centre.append(gameViewButton);
  const stripWords = el('span', 'ed-play-pill');
  stripWords.hidden = true;
  centre.append(stripWords);
  // The right: the tools' own right after the centre, then AI, Undo and Redo at the end.
  const middle = el('div', 'ed-top-middle');
  const actions = el('div', 'ed-actions');
  const { undoKey, redoKey } = options;
  // Free while an Apply lands (`hold.ts`' FREE): it shows or hides a card, as the card itself is free. Hidden until `setAi`.
  const aiButton = barButton('ui', actions, AI_TIP, options.aiKey, 'sparkle', () => options.ai(), 'ed-ai');
  aiButton.hidden = true;
  const undoButton = barButton('history_undo', actions, 'Undo', undoKey, 'undo', () => options.undo());
  const redoButton = barButton('history_redo', actions, 'Redo', redoKey, 'redo', () => options.redo());
  const right = el('div', 'ed-top-right');
  right.append(middle, actions);

  const top = el('div', 'ed-top');
  top.append(left, centre, right);

  // ---------------------------------------------------------------- the tool strip

  const strip = el('div', 'ed-strip ed-tools');
  // A tab placed at the foot (the Config tab's): pinned there, the others from the top in their order.
  const foot = el('div', 'ed-strip-foot');
  // Each of the strip's icons lets go of the focus after a click (`letGo`): the tool it brings up has the keys.
  const toolButtons = options.tools.filter((spec) => !spec.within).map((spec) => {
    const button = letGo(control('ui', 'ed-tool'));
    tip(button, spec.name, spec.key);
    button.append(icon(spec.icon));
    const pick = (): void => select(spec.id);
    button.addEventListener('click', pick);
    // A prefab, a model or a material dragged from the Assets panel, or the tree's rows, held over a tab's icon: that
    // tab comes up -- Scene, whose scene, tree and Assets panel take them.
    let spring: ReturnType<typeof setTimeout> | undefined;
    button.addEventListener('dragenter', (event) => {
      const types = event.dataTransfer?.types ?? [];
      if (![PREFAB_DRAG, MODEL_DRAG, MATERIAL_DRAG, ENTITIES_DRAG].some((type) => types.includes(type)) || spec.id === tool) return;
      clearTimeout(spring);
      spring = setTimeout(pick, SPRING_MS);
    });
    button.addEventListener('dragleave', () => clearTimeout(spring));
    button.addEventListener('drop', () => clearTimeout(spring));
    (spec.place === 'bottom' ? foot : strip).append(button);
    return { button, spec };
  });
  if (foot.childElementCount > 0) strip.append(foot);

  root.append(top, strip);

  // ---------------------------------------------------------------- playing

  // The one card left while the game runs: the four buttons, what is going on -- its time -- and the agent's badge,
  // in the strip's order.
  const playing = el('div', 'ed-card ed-play');
  const pill4 = playButtons(options, playing);
  const said = el('span', 'ed-play-pill');
  playing.append(said);
  const badge = el('span', 'ed-play-badge');
  badge.hidden = true;
  playing.append(badge);
  root.append(playing);
  document.body.append(root);

  // ---------------------------------------------------------------- wiring

  function select(id: string): void {
    if (!options.tools.some((t) => t.id === id && !t.within)) return;
    tool = id;
    options.onTool(id);
    refresh();
  }

  function refresh(): void {
    subtitleName.data = options.name();
    dot.hidden = !options.unsaved();
    note();
    for (const { button, spec } of toolButtons) button.setAttribute('aria-pressed', String(spec.id === tool));
    undoButton.disabled = !options.canUndo();
    redoButton.disabled = !options.canRedo();
    const undoing = options.undoLabel();
    const redoing = options.redoLabel();
    tip(undoButton, undoing ? `Undo ${undoing}` : 'Undo', undoKey);
    tip(redoButton, redoing ? `Redo ${redoing}` : 'Redo', redoKey);
  }

  select(tool);

  /** Shown or on its way in (`setHidden`); the slide out's timer, and the frame the slide in starts on. */
  let shown = !root.hidden;
  let everShown = shown;
  let leaving: ReturnType<typeof setTimeout> | null = null;
  let entering = 0;

  const shell: Shell = {
    root,
    top,
    head: { root: head, end: headEnd },
    strip,
    controls,
    middle,
    under,
    get tool() {
      return tool;
    },
    select,
    refresh,
    setHidden(hidden) {
      if (leaving !== null) clearTimeout(leaving);
      leaving = null;
      cancelAnimationFrame(entering);
      shown = !hidden;
      if (hidden) {
        if (root.hidden) return;
        // Never shown yet (as the editor is made): gone at once, nothing to slide.
        if (!everShown) {
          root.hidden = true;
          return;
        }
        root.classList.add('ed-shut');
        leaving = setTimeout(() => {
          leaving = null;
          root.hidden = true;
          root.classList.remove('ed-shut');
        }, OUT_MS);
        return;
      }
      everShown = true;
      if (root.hidden) {
        // In from where the slide-out leaves them: put away, shown, laid out once, then let go.
        root.classList.add('ed-shut');
        root.hidden = false;
        void root.offsetWidth;
      }
      entering = requestAnimationFrame(() => root.classList.remove('ed-shut'));
    },
    get shown() {
      return shown;
    },
    setPlaying(on, maximized) {
      root.classList.toggle('ed-playing', on && maximized);
      root.classList.toggle('ed-docked', on && !maximized);
      // Docked, what edits stays in sight but takes nothing while the game runs: no click, no focus, no key.
      const still = on && !maximized;
      for (const part of [left, middle, saveButton, undoButton, redoButton]) part.inert = still;
      for (const card of root.children) {
        if (card instanceof HTMLElement && card.matches(DOCKED_INERT)) card.inert = still;
      }
    },
    setMaximize(on) {
      maximizeButton.setAttribute('aria-pressed', String(on));
      tip(maximizeButton, on ? `${MAXIMIZE_TIP}: on -- a playtest fills the window` : `${MAXIMIZE_TIP}: off -- a playtest plays in the scene's room`, '');
    },
    setGameView(label, title) {
      gameViewLabel.textContent = label;
      tip(gameViewButton, title, '');
    },
    setPlaytest(state, ticks = 0) {
      const bar = playtestBar(state, ticks);
      for (const set of [strip4, pill4]) {
        for (const b of PLAY_ORDER) set[b].disabled = !bar[PLAY_FIELD[b]];
        if (bar.playTip !== undefined) tip(set.F5, bar.playTip, options.playKeys.F5);
      }
      stripWords.hidden = bar.words === null;
      stripWords.textContent = bar.words ?? '';
      said.textContent = bar.words ?? '';
      root.classList.toggle('ed-paused', state === 'paused');
    },
    setAi(shown, mark = null, running = false) {
      aiButton.hidden = shown === null;
      aiButton.setAttribute('aria-pressed', String(shown === true));
      if (mark === null) aiButton.removeAttribute('data-mark');
      else aiButton.dataset.mark = mark;
      // A turn running (Docs/ai-panel.md D8): the sparkle turns, seen with the column hidden too.
      aiButton.toggleAttribute('data-running', running);
      const marked = mark === 'waiting' ? 'AI: Claude is waiting for you' : mark === 'failed' ? 'AI: a turn ended in an error -- show Claude\'s column' : mark === 'done' ? 'AI: a turn finished -- show Claude\'s column' : null;
      tip(aiButton, marked ?? (running ? 'AI: Claude is working -- show or hide Claude\'s column' : AI_TIP), options.aiKey);
    },
    setBadge(text) {
      badge.hidden = text === null;
      badge.textContent = text ?? '';
    },
    setAway(away) {
      root.classList.toggle('ed-away', away);
    },
    setOpened(line) {
      openedRow.hidden = line === null;
      kind.textContent = line === null ? 'Scene' : 'Prefab';
      head.classList.toggle('ed-has-prefab', line !== null);
      readOnly.hidden = line?.readOnly == null;
      readOnly.textContent = line?.readOnly ? `Read-only: ${line.readOnly}` : '';
      if (!line) return;
      prefabSave.disabled = line.readOnly !== null || !line.unsaved;
      if (line.readOnly) tip(prefabSave, `Read-only: ${line.readOnly}`);
      else if (line.unsaved) tip(prefabSave, 'Save the prefab to its file: new instances and the parked take it at once', options.saveKey);
      else tip(prefabSave, 'Nothing to save: the file says this already');
      tip(prefabBack, `Back to ${line.back}: asks first if what changed is not saved`, options.backKey);
    },
    dispose() {
      root.remove();
      head.remove();
      dropSheet();
    },
  };
  // No playtest yet: Play alone on, no pill.
  shell.setPlaytest('none');
  return shell;
}

/**
 * The inspector's lock, in its header beside the fold (Docs/ecs.md §13): the
 * Scale lock's icon, shut and pressed while locked, its words what a click
 * does. Both sides' inspectors have one, on the host's one state; `show` draws
 * it again as that changes -- hidden where the tab has no lock (the Model tab).
 */
export function lockButton(lock: LockHost): { readonly button: HTMLButtonElement; show(): void } {
  const button = letGo(iconButton('ui', 'unlock', '', () => lock.toggle(), 'ed-icon-button ed-inspector-lock'));
  const show = (): void => {
    button.hidden = !lock.lockable;
    const on = lock.lockable && lock.locked;
    button.replaceChildren(icon(on ? 'lock' : 'unlock'));
    button.title = withKey(on ? LOCK_WORDS.locked : LOCK_WORDS.open, keyLabel(LOCK_KEY));
    button.setAttribute('aria-label', on ? LOCK_WORDS.locked : LOCK_WORDS.open);
    button.setAttribute('aria-pressed', String(on));
  };
  show();
  return { button, show };
}
