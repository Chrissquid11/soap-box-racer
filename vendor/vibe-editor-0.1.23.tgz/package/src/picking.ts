/**
 * Pointers on the scene: a click picks the entity drawn under it, a left-drag
 * from nothing draws a box that selects (`marquee.ts`), a right-click is a
 * tool's menu, and the entity under a mouse is the one hovered.
 *
 * - **A click is a press that lifts where it went down**, never 4 px or more
 *   from it on the way (`pastSlop`, the editor's one slop): one that went further is a drag -- the camera's,
 *   or a box -- even if it came back. A press the gizmo took is the gizmo's.
 * - **What a click does to the selection is its modifiers'** (`clickHow`):
 *   alone it selects one, Shift adds, Mod -- Cmd on a Mac -- puts in or takes out.
 * - **A box is a left-drag from anywhere** (Docs/navigation.md D3: on an
 *   entity too; the camera is the middle button's), while no tool has the
 *   scene's clicks (`setBoxAway`) and the gizmo does not take it: Shift adds
 *   what it takes, Mod turns each over -- held as it began or as it is let go,
 *   so either way round counts. Alt with it is the orbit under Emulate 3
 *   Button Mouse (`view/navigation.ts`).
 * - **Only views are picked**: never the gizmo, the grid, the lines, the ground
 *   or anything else a tool adds to the scene -- and only views drawn: one
 *   hidden or switched off (`object.visible` false, `view.ts`) is clicked
 *   through, and selected in the tree. three's raycast would find it: it minds
 *   layers, not `visible`. Every layer is tried, as the editor's camera sees them all.
 *   One locked against picking (`Unpickable`, the tree's arrow), itself or
 *   above, is clicked through too, and boxed past, though drawn.
 */
import * as THREE from 'three';
import { type Entity, entityOf, NONE } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import type { EditorCamera } from './camera.ts';
import type { Gizmo } from './gizmo.ts';
import { createMarquee } from './marquee.ts';
import { boxHow, clickHow, clickOn, combined, type Selection } from './selection.ts';
import { isOut } from './switches.ts';
import { isMac } from '@vibe/engine/debug';
import { loadPrefs } from './prefs.ts';
import { navigates, pastSlop, pressAction } from './view/navigation.ts';
import { buttonMask } from './view/navigator.ts';


export type PickHandler = (e: Entity, add: boolean, pointer: PointerEvent) => boolean;
export type ContextHandler = (e: Entity, pointer: PointerEvent) => boolean;

export interface PickingOptions {
  game: Game;
  camera: EditorCamera;
  gizmo: Gizmo;
  /** What a click no tool takes chooses, and a box. */
  selection: Selection;
  /** The editor's root: the box's rectangle is drawn in it. */
  root: HTMLElement;
  /** Does the tool up work in the scene: clicks, boxes and hovering are its only then. */
  active(): boolean;
  /** What is hovered changed: the frame to be drawn soon. */
  changed(): void;
  /**
   * The editor's own stand-ins for entities with nothing drawn of their own --
   * the camera icons (`camera-view.ts`) -- each with its entity as
   * `userData.entity`: picked and boxed as that entity's view would be.
   */
  standIns?(): readonly THREE.Object3D[];
}

export interface Picking {
  /** The entity drawn under the mouse, NONE for none. */
  readonly hovered: Entity;
  /** The entity drawn under a point of the page, nearest first, as a click picks it; NONE for none. A drop's target (a material dragged in). */
  at(x: number, y: number): Entity;
  /** Nothing hovered, without drawing: the editor closed, or the tool up changed. */
  forget(): void;
  /** A click in the scene, before the selection gets it: the handler added last first, one that returns true has taken it. Returns the undo. */
  onPick(handler: PickHandler): () => void;
  /** A right-click, not a right drag: the handler added last first, as `onPick`. Returns the undo. */
  onContext(handler: ContextHandler): () => void;
  /** Would a left press here draw a box: the tool up working in the scene, no tool taking the clicks, the gizmo not taking it. */
  boxes(event: PointerEvent): boolean;
  /** No box for a while -- a tool's clicks are its own: placing, picking an entity -- and back. */
  setBoxAway(away: boolean): void;
  /** Its listeners on the canvas, and off: after the gizmo's and the camera's, so it knows whether the gizmo took a press. */
  connect(): void;
  disconnect(): void;
  dispose(): void;
}

const NO_STAND_INS: readonly THREE.Object3D[] = [];

export function createPicking({ game, camera, gizmo, selection, root, active, changed, standIns }: PickingOptions): Picking {
  const canvas = game.renderer.domElement;
  let hovered: Entity = NONE;
  const pickers: PickHandler[] = [];
  const menus: ContextHandler[] = [];
  const views: THREE.Object3D[] = [];
  const marquee = createMarquee(game, root, () => camera.object, standIns);
  let boxAway = false;

  /** The entity drawn under the pointer, nearest first; NONE for none. */
  const under = (event: PointerEvent): Entity => at(event.clientX, event.clientY);
  /** The entity drawn under a point of the page, nearest first; NONE for none. */
  function at(x: number, y: number): Entity {
    const ray = camera.aim(x, y);
    // Views only: every one is a child of the scene (view.ts), and nothing of the editor's is a view -- but its stand-ins
    // for one (a camera's icon), each its entity's. Drawn ones only.
    views.length = 0;
    for (const child of game.scene.children) if (child.userData.entity && child.visible) views.push(child);
    const extra = standIns?.() ?? NO_STAND_INS;
    for (let i = 0; i < extra.length; i++) if (extra[i]!.visible) views.push(extra[i]!);
    for (const hit of ray.intersectObjects(views, true)) {
      const e = entityOf(hit.object);
      // Locked against picking, itself or above: the click goes through to what is behind.
      if (e !== NONE && !isOut(game.world, e, 'unpickable')) return e;
    }
    return NONE;
  }

  /** Would this press draw a box: the rule's left button (Docs/navigation.md D3) -- from anywhere, on an entity too -- the gizmo not taking it, the tool up working in the scene, no tool taking its clicks. */
  function boxes(event: PointerEvent): boolean {
    return active() && !boxAway && pressAction(event, loadPrefs().nav, { mac: isMac(), taken: gizmo.dragging || gizmo.axis !== null }) === 'box';
  }

  const hover = (e: Entity): void => {
    if (e === hovered) return;
    hovered = e;
    changed();
  };

  /**
   * A press on the scene: where it went down, whether the gizmo took it,
   * whether it draws a box and with what held, and whether it has travelled far
   * enough to be a drag.
   */
  let press: { id: number; x: number; y: number; gizmo: boolean; box: boolean; held: PointerEvent; dragged: boolean; navigates: boolean } | null = null;
  const down = (event: PointerEvent): void => {
    // After the gizmo has heard it: `dragging` says whether this press was on a handle. One the view's driver takes
    // (Industry's Alt+left and Alt+right, Emulate 3 Button Mouse's Alt+left) is neither a pick nor a menu, moved or not.
    const nav = navigates(pressAction(event, loadPrefs().nav, { mac: isMac(), taken: gizmo.dragging || gizmo.axis !== null }));
    press = { id: event.pointerId, x: event.clientX, y: event.clientY, gizmo: gizmo.dragging, box: boxes(event), held: event, dragged: false, navigates: nav };
    hover(NONE);
  };
  const up = (event: PointerEvent): void => {
    const was = press;
    press = null;
    if (!was || was.id !== event.pointerId) return;
    if (was.box) marquee.hide();
    if (was.gizmo || !active()) return;
    const far = was.dragged || pastSlop(event.clientX - was.x, event.clientY - was.y);
    // A box let go: what it holds, by the modifiers held as it began or now.
    if (was.box && far) {
      const these = marquee.inside({ x0: was.x, y0: was.y, x1: event.clientX, y1: event.clientY });
      const { held } = was;
      const how = boxHow({ shiftKey: held.shiftKey || event.shiftKey, ctrlKey: held.ctrlKey || event.ctrlKey, metaKey: held.metaKey || event.metaKey });
      const list = combined(selection.list, these, how);
      return selection.chooseAll(list, list[0]);
    }
    // A drag that came back to where it began is still a drag: an orbit, or a pan, never a pick or a menu.
    if (far || was.navigates) return;
    // The left button picks; the right, let go where it went down, is a tool's menu -- a right drag is nothing.
    if (event.button === 0) {
      const e = under(event);
      for (let i = pickers.length - 1; i >= 0; i--) if (pickers[i]!(e, event.shiftKey, event)) return;
      clickOn(selection, e, clickHow(event, false));
    } else if (event.button === 2) {
      const e = under(event);
      for (let i = menus.length - 1; i >= 0; i--) if (menus[i]!(e, event)) return;
    }
  };
  const move = (event: PointerEvent): void => {
    if (press) {
      if (press.id !== event.pointerId) return;
      // Its button found up -- the release went elsewhere (a walk begun): dropped, no box left following the pointer.
      if ((event.buttons & buttonMask(press.held.button)) === 0) return cancel();
      if (pastSlop(event.clientX - press.x, event.clientY - press.y)) press.dragged = true;
      if (press.box && press.dragged) marquee.show({ x0: press.x, y0: press.y, x1: event.clientX, y1: event.clientY });
      return;
    }
    // A mouse over the world, no button down: a finger has nothing to hover.
    if (!active() || event.pointerType === 'touch') return;
    hover(gizmo.axis !== null ? NONE : under(event));
  };
  const leave = (): void => hover(NONE);
  // The press lost -- the window left mid-drag, the page hidden: no box left behind.
  const cancel = (): void => {
    if (press?.box) marquee.hide();
    press = null;
  };

  return {
    get hovered() {
      return hovered;
    },
    at,
    forget() {
      hovered = NONE;
    },
    onPick(handler) {
      pickers.push(handler);
      return () => {
        const i = pickers.indexOf(handler);
        if (i >= 0) pickers.splice(i, 1);
      };
    },
    onContext(handler) {
      menus.push(handler);
      return () => {
        const i = menus.indexOf(handler);
        if (i >= 0) menus.splice(i, 1);
      };
    },
    boxes,
    setBoxAway(away) {
      boxAway = away;
      if (away) cancel();
    },
    connect() {
      canvas.addEventListener('pointerdown', down);
      canvas.addEventListener('pointerup', up);
      canvas.addEventListener('pointermove', move);
      canvas.addEventListener('pointerleave', leave);
      canvas.addEventListener('pointercancel', cancel);
    },
    disconnect() {
      canvas.removeEventListener('pointerdown', down);
      canvas.removeEventListener('pointerup', up);
      canvas.removeEventListener('pointermove', move);
      canvas.removeEventListener('pointerleave', leave);
      canvas.removeEventListener('pointercancel', cancel);
      cancel();
    },
    dispose() {
      marquee.dispose();
    },
  };
}
