/**
 * Box selection in the scene: a left-drag that starts on nothing draws a
 * rectangle over the world (`picking.ts` says when, `camera.ts` keeps the
 * orbit off it), and let go, every entity whose view's middle -- the centre of
 * its bounds, as the camera sees it -- is inside is what the box selects.
 *
 * - **A view's middle, not any of it**: a box round the edge of a big crate
 *   does not take it, one round its middle does, whatever is in front.
 * - **Nearest where the drag began first**: the one shown, and moved by the
 *   gizmo, is the one the box was drawn from.
 * - **The rectangle is the editor's**, an element in its root over the canvas,
 *   taking no pointer.
 */
import * as THREE from 'three';
import { type Entity, entityOf, NONE } from '@vibe/engine';
import type { Game } from '@vibe/engine/boot';
import { el } from './shell.ts';
import { isOut } from './switches.ts';

/** A rectangle on the page, from where a drag began (`x0`, `y0`) to where it is. */
export interface Rect {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

export interface Marquee {
  /** The rectangle drawn, or moved. */
  show(rect: Rect): void;
  hide(): void;
  /** Every entity whose view's middle is inside, nearest where the drag began first. */
  inside(rect: Rect): Entity[];
  dispose(): void;
}

/**
 * `camera`: the one the scene is seen through now -- the editor's, perspective
 * or orthographic. `standIns`: the editor's own objects standing for an entity
 * with nothing drawn (a camera's icon, its entity its `userData.entity`), boxed
 * as that entity's view.
 */
export function createMarquee(game: Game, root: HTMLElement, camera: () => THREE.Camera, standIns?: () => readonly THREE.Object3D[]): Marquee {
  const canvas = game.renderer.domElement;
  const box = el('div', 'ed-marquee');
  box.hidden = true;
  root.append(box);
  const bounds = new THREE.Box3();
  const middle = new THREE.Vector3();

  return {
    show({ x0, y0, x1, y1 }) {
      box.hidden = false;
      box.style.left = `${Math.min(x0, x1)}px`;
      box.style.top = `${Math.min(y0, y1)}px`;
      box.style.width = `${Math.abs(x1 - x0)}px`;
      box.style.height = `${Math.abs(y1 - y0)}px`;
    },
    hide() {
      box.hidden = true;
    },
    inside({ x0, y0, x1, y1 }) {
      // The view is drawn into the game's frame (`Game.frame`): projected points are measured across it.
      const r = canvas.getBoundingClientRect();
      const f = game.frame;
      const page = { left: r.left + f.x, top: r.top + f.y, width: f.width, height: f.height };
      const [left, right, top, bottom] = [Math.min(x0, x1), Math.max(x0, x1), Math.min(y0, y1), Math.max(y0, y1)];
      const found: { e: Entity; d: number }[] = [];
      const seen = new Set<Entity>();
      const eye = camera();
      eye.updateMatrixWorld();
      /** `view`, if its entity's middle is inside: found. */
      const take = (view: THREE.Object3D): void => {
        const e = entityOf(view);
        // Not drawn -- hidden, switched off -- is not boxed, as it is not clicked.
        if (e === NONE || !view.visible || seen.has(e) || !game.world.alive(e) || isOut(game.world, e, 'unpickable')) return;
        view.updateMatrixWorld(true);
        bounds.setFromObject(view);
        if (bounds.isEmpty()) return;
        bounds.getCenter(middle).project(eye);
        // Behind the camera, or past its far plane: not in the view, so not in the box.
        if (middle.z < -1 || middle.z > 1) return;
        const x = page.left + ((middle.x + 1) / 2) * page.width;
        const y = page.top + ((1 - middle.y) / 2) * page.height;
        if (x < left || x > right || y < top || y > bottom) return;
        seen.add(e);
        found.push({ e, d: Math.hypot(x - x0, y - y0) });
      };
      // Views only, as a click picks: every one a child of the scene, and nothing of the editor's is one -- but its stand-ins.
      for (const view of game.scene.children) take(view);
      for (const view of standIns?.() ?? []) take(view);
      return found.sort((a, b) => a.d - b.d).map((f) => f.e);
    },
    dispose() {
      box.remove();
    },
  };
}
