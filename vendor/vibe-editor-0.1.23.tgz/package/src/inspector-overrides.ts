/**
 * An instance's overrides in the inspector (Docs/prefabs.md §7): the marks on
 * an entity of an instance, its instance line, and the Overrides list on its
 * root -- each worked out from `overridesOf` as the inspector is built
 * (`overrides-edit.ts`' `itemsOf`), and worked out again as each step commits
 * (`marksOf`: the panel built again only when they differ), so never stale
 * after a typed value, a scrub, a gizmo drag, an undo, a live update or a
 * recompile.
 *
 * - **The marks**: an overridden field has a bar in the editor's accent at the
 *   left of its label, in the margin beside it, taking no room -- the label
 *   never moves as it becomes or stops being one (`labelOf`: a number field's name, which
 *   scrubs, a ref's name -- never the pair, which is no box of its own); a
 *   component added, removed or switched against the prefab marks its block's
 *   title (a removed one has a line of its own at the end). A
 *   right-click on what is marked, or a click on its bar, is its menu:
 *   **Revert** -- back to what the prefab gives -- and **Apply to `<prefab>`**,
 *   one per prefab that could hold it, innermost first (`Apply to
 *   crates/rider`, `Apply to crates/big`), as Unity does.
 * - **The instance line**, under the title: the prefab it is of; on its root
 *   **Overrides (n)**, which opens the list, and a menu with Unpack and Unpack
 *   completely; on an entity inside one, the root to go to.
 * - **The list**: every difference by entity -- fields by their name under
 *   their component, with the prefab's value and the instance's, components
 *   added and removed, entities added and
 *   removed -- each with Revert and Apply (per prefab that could hold it),
 *   Apply all (to the prefab chosen, when more than one could hold them) and
 *   Revert all at the top; what no override can say, said under it.
 */
import { label, type Entity, type World } from '@vibe/engine';
import { button, control, el } from './dom.ts';
import type { MenuItem } from './menu.ts';
import { itemsAt, shownAngle, type InstanceItems, type Item } from './overrides-edit.ts';

/** What the marks and the list need of the entity tool. */
export interface OverridesHost {
  /** The items of `e`'s instance now; null for none, or for one whose overrides are not shown (the opened prefab's own). */
  of(e: Entity): InstanceItems | null;
  revert(root: Entity, items: readonly Item[]): void;
  apply(root: Entity, items: readonly Item[], target: string): void;
  unpack(root: Entity, completely: boolean): void;
  /** Select `e` (the instance's root). */
  select(e: Entity): void;
  menu(at: { x: number; y: number } | HTMLElement, items: readonly MenuItem[], title: string): void;
  /** Why Apply cannot be used just now (a prefab open: its Save writes it), or null. */
  applyBlocked(): string | null;
  /** Prefab `key`'s file shown chosen in the Assets tool, as Unity's ping on an instance's prefab does. */
  showPrefab(key: string): void;
}

/** The prefabs every one of `items` could be applied to, innermost first. */
const sharedOwners = (items: readonly Item[]): string[] => (items[0]?.owners ?? []).filter((k) => items.every((i) => i.owners.includes(k)));

/** Revert, then Apply to each prefab that could hold `items`, innermost first. */
export function itemMenu(host: OverridesHost, root: Entity, items: readonly Item[]): MenuItem[] {
  const blocked = host.applyBlocked();
  const what = items.length === 1 ? items[0]!.what : `${items.length} overrides`;
  const out: MenuItem[] = [{ mcp: 'scene_override', label: 'Revert', title: `${what} back to what the prefab gives`, run: () => host.revert(root, items) }];
  sharedOwners(items).forEach((key, i) => {
    out.push({
      mcp: 'scene_override',
      label: `Apply to ${key}`,
      rule: i === 0,
      title: blocked ?? `${what} written into ${key}'s file: every instance of it takes it where it holds no override of its own`,
      run: () => (blocked ? undefined : host.apply(root, items, key)),
    });
  });
  return out;
}

/**
 * What the marks of an instance say, as one string: a step that leaves it the
 * same leaves the panel as it is (the field typed in keeps its focus); one
 * that changes it -- an override made, gone, or its value changed -- builds it
 * again. '' for no instance.
 */
export const marksOf = (all: InstanceItems | null): string =>
  all ? `${all.root}\n${all.items.map((i) => `${i.path}\t${i.what}\t${i.was}\t${i.now}\t${i.owners.join(',')}`).join('\n')}\n${all.notes.join('\n')}` : '';

/** What `labelOf` needs of an element: enough for node to test it with a stand-in. */
interface Labelled {
  readonly classList: { contains(name: string): boolean };
  readonly firstElementChild: Element | null;
  querySelector(selector: string): Element | null;
}

/**
 * The label of the field element `target` -- where its bar goes, in the margin at its left:
 * a number field's pair (`display: contents`, no box of its own) its name
 * that scrubs, a ref's line or a key's, colour's or tick's (`key-field.ts`) its name;
 * anything else, a block's title, itself.
 */
export function labelOf<T extends Labelled>(target: T): T {
  if (target.classList.contains('ed-pair')) return (target.querySelector(':scope > .ed-scrub') as T | null) ?? target;
  // A data component's list, dictionary or record (`inspector-data.ts`): its head's name.
  if (target.classList.contains('ed-data-group')) return (target.querySelector(':scope > .ed-data-head > .ed-data-name') as T | null) ?? target;
  if (target.classList.contains('ed-ref') || target.classList.contains('ed-keyline')) {
    // A slider's line begins with its number's pair: the bar on the pair's scrub, as on any number.
    const first = target.firstElementChild as T | null;
    return first === null ? target : first.classList.contains('ed-pair') ? labelOf(first) : first;
  }
  return target;
}

/** The fields of `e`'s marked in `panel`: `data-field` holds the `Component.field`s an element shows. */
function marked(panel: HTMLElement, selector: string, attribute: 'field' | 'component', keys: Set<string>): HTMLElement[] {
  return [...panel.querySelectorAll<HTMLElement>(selector)].filter((x) => (x.dataset[attribute] ?? '').split(' ').some((k) => keys.has(k)));
}

/** A bar in the editor's accent in the margin left of `target`'s label, taking no room: what is overridden; a click is its menu, as a right-click anywhere on it. */
function bar(host: OverridesHost, root: Entity, items: readonly Item[], target: HTMLElement): void {
  const at = labelOf(target);
  at.classList.add('ed-overridden');
  const said = items.map((i) => `${i.what}: ${i.was} in the prefab, ${i.now} here`).join('\n');
  const b = control('ui', 'ed-ov-bar');
  b.title = `Overridden -- ${said}\nClick, or right-click it, to Revert or Apply`;
  // Not a scrub of the label it is in, nor a fold of the block's title.
  b.addEventListener('pointerdown', (event) => event.stopPropagation());
  b.addEventListener('click', (event) => {
    event.stopPropagation();
    host.menu(b, itemMenu(host, root, items), items.length === 1 ? items[0]!.what : 'Overrides');
  });
  at.prepend(b);
  target.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    event.stopPropagation();
    host.menu({ x: event.clientX, y: event.clientY }, itemMenu(host, root, items), items.length === 1 ? items[0]!.what : 'Overrides');
  });
}

/**
 * `e`'s overrides marked in the inspector's `panel` as built: each field
 * element with `data-field`, each block's title with `data-component`; a line
 * a removed component, at the end.
 */
export function markOverrides(panel: HTMLElement, world: World, e: Entity, all: InstanceItems, host: OverridesHost): void {
  const own = itemsAt(world, all, e).filter((i) => i.part.kind !== 'added' && i.part.kind !== 'removed');
  const byField = new Map<string, Item[]>();
  const byComponent = new Map<string, Item[]>();
  for (const i of own) {
    const p = i.part;
    // A rotation by the axes of its angles that differ (`Transform.rotation.y`), and as a whole (the row's name, in World).
    const keys = p.kind === 'set' && p.axes ? [`${p.component}.${p.field}`, ...p.axes.map((a) => `${p.component}.${p.field}.${a.axis}`)]
      : p.kind === 'set' || p.kind === 'refs' || (p.kind === 'objects' && 'field' in p) ? [`${p.component}.${p.field}`] : [];
    for (const k of keys) byField.set(k, [...(byField.get(k) ?? []), i]);
    // A data component's field is marked on its own line (D9); any other object's data on its block's title.
    if (p.kind === 'add' || p.kind === 'off' || p.kind === 'on' || (p.kind === 'objects' && !('field' in p))) byComponent.set(p.component, [...(byComponent.get(p.component) ?? []), i]);
  }
  // A field's element is marked by what it shows: a number, or an axis of the rotation.
  for (const target of marked(panel, '[data-field]', 'field', new Set(byField.keys()))) {
    const items = (target.dataset.field ?? '').split(' ').flatMap((k) => byField.get(k) ?? []);
    bar(host, all.root, items, target);
  }
  for (const target of marked(panel, '[data-component]', 'component', new Set(byComponent.keys()))) {
    bar(host, all.root, byComponent.get(target.dataset.component!)!, target);
  }
  // Components it has not, which the prefab gives: a line each.
  for (const i of own.filter((x) => x.part.kind === 'remove')) {
    const line = el('div', 'ed-line ed-ov-removed');
    line.append(el('span', 'ed-dim', `${(i.part as { component: string }).component} -- removed here; the prefab gives it`));
    bar(host, all.root, [i], line);
    panel.append(line);
  }
  // The rest -- layer, name, parent, a link's data -- are the list's: counted on the instance line.
}

/** Kept across the inspector being built again: whether the list is open. */
export interface OverridesState {
  open: boolean;
  /** The target Apply all writes to, by the root it was chosen for. */
  target: Map<Entity, string>;
}

/** An entity of an instance's line under the title: its prefab, and on its root the Overrides list and Unpack. */
export function instanceLine(world: World, e: Entity, all: InstanceItems, host: OverridesHost, state: OverridesState, rebuild: () => void): HTMLElement {
  const block = el('div', 'ed-instance');
  const line = el('div', 'ed-line ed-instance-line');
  const mark = el('span', 'ed-instance-mark', '◆');
  // A link: its file shown chosen in the Assets tool.
  const key = button('ui', all.prefab.key, `An instance of ${all.prefab.key}: click to show its file in the Assets tool. What it changes from the prefab is marked, Revert or Apply on each`, () => host.showPrefab(all.prefab.key), 'ed-instance-key ed-instance-link');
  line.append(mark, key);
  block.append(line);
  if (e !== all.root) {
    line.append(button('scene_select', `in ${label(world, all.root)}`, `Select ${label(world, all.root)}, the root of its instance: its Overrides list`, () => host.select(all.root), 'ed-quiet ed-small'));
    return block;
  }
  const count = all.items.length;
  const list = button('ui', `Overrides (${count})`, count === 0 ? 'It changes nothing of its prefab' : 'Every difference from its prefab, by entity: Revert or Apply each, or all', () => {
    state.open = !state.open;
    rebuild();
  }, 'ed-quiet ed-small ed-ov-toggle');
  list.setAttribute('aria-expanded', String(state.open && count > 0));
  list.disabled = count === 0;
  const nested = all.prefab.owners.some((o) => o.length > 1);
  const more = button('ui', '⋯', 'Unpack: plain entities, the link to the prefab broken', () => {
    host.menu(more, [
      { mcp: 'scene_override', label: 'Unpack', title: nested ? `Plain entities, its own no longer linked to ${all.prefab.key}; what it nests stays an instance of its own prefab` : `Plain entities, no longer linked to ${all.prefab.key}`, run: () => host.unpack(all.root, false) },
      ...(nested ? [{ mcp: 'scene_override' as const, label: 'Unpack completely', title: 'Plain entities all through: every prefab it nests unlinked too', run: () => host.unpack(all.root, true) }] : []),
    ], all.prefab.key);
  }, 'ed-quiet ed-small');
  line.append(list, more);
  if (state.open && count > 0) block.append(overridesList(world, all, host, state, rebuild));
  return block;
}

/** The Overrides list: Apply all and Revert all, then every difference by entity with its own Revert and Apply. */
function overridesList(world: World, all: InstanceItems, host: OverridesHost, state: OverridesState, rebuild: () => void): HTMLElement {
  const box = el('div', 'ed-ov-list');
  const blocked = host.applyBlocked();
  // Every prefab that could hold any of them, outermost first: the instance's own the first choice.
  const targets = [...new Set(all.items.flatMap((i) => i.owners))].sort((a, b) => depthOf(all, a) - depthOf(all, b));
  // None at all (every difference a ref outside the instance): Apply all has nothing to write, and says so.
  const target = targets.includes(state.target.get(all.root) ?? '') ? state.target.get(all.root)! : (targets[0] ?? '');
  const top = el('div', 'ed-line ed-ov-top');
  const holds = all.items.filter((i) => i.owners.includes(target));
  const applyAll = button('scene_override', `Apply all to`, blocked ?? (target === '' ? 'No prefab can hold any of them: they stay the scene\'s' : `${holds.length} of ${all.items.length} written into ${target}'s file${holds.length < all.items.length ? ` -- the rest it cannot hold stay overrides` : ''}`), () => {
    if (!blocked) host.apply(all.root, holds, target);
  }, 'ed-quiet ed-small');
  applyAll.disabled = blocked !== null || holds.length === 0;
  top.append(applyAll);
  // One layout whether one prefab or several could hold them: the same box, shut with one, so Revert all never moves under the pointer.
  const pick = el('select', 'ed-input ed-small');
  for (const k of targets) pick.append(new Option(k, k, false, k === target));
  pick.disabled = targets.length < 2;
  pick.title = targets.length < 2 ? `The prefab Apply all writes to: ${target}, the only one that could hold them` : 'The prefab Apply all writes to';
  pick.addEventListener('change', () => {
    state.target.set(all.root, pick.value);
    rebuild();
  });
  top.append(pick);
  top.append(button('scene_override', 'Revert all', 'Every difference back to what the prefab gives; what was added under it destroyed', () => host.revert(all.root, all.items), 'ed-quiet ed-small'));
  box.append(top);
  // By entity: its path, in node order, then what was added; a field by its name under its component's.
  let at: string | null = null;
  let under: string | null = null;
  for (const i of all.items) {
    const group = i.part.kind === 'added' ? `${i.path} +` : i.path;
    if (group !== at) {
      at = group;
      under = null;
      const who = i.part.kind === 'removed' ? `${i.was}` : i.part.kind === 'added' ? `under ${i.path || 'its root'}` : i.entity !== 0 ? label(world, i.entity) : i.path;
      box.append(el('div', 'ed-ov-entity', who));
    }
    const field = i.part.kind === 'set' || i.part.kind === 'refs' ? i.part : null;
    if (field && field.component !== under) box.append(el('div', 'ed-ov-component', field.component));
    under = field ? field.component : null;
    const row = el('div', 'ed-line ed-ov-row');
    const words = el('span', 'ed-ov-what', i.part.kind === 'removed' ? 'removed' : i.part.kind === 'added' ? `added: ${i.now}` : field ? field.field : i.what);
    // A rotation in degrees, by the axes that differ -- `y 0 → 92.6°` -- on a line of its own under the row, each axis
    // whole and wrapping: three of them never fit beside the name and the buttons.
    const turned = i.part.kind === 'set' && i.part.axes ? i.part.axes.map((a) => `${a.axis} ${shownAngle(a.was)} → ${shownAngle(a.now)}°`) : null;
    const values = el('span', 'ed-dim ed-ov-values', turned ? '' : i.part.kind === 'set' || i.part.kind === 'layer' || i.part.kind === 'name' ? `${i.was} → ${i.now}` : i.part.kind === 'added' || i.part.kind === 'removed' ? '' : i.now);
    row.title = `${i.what}: ${i.was} in the prefab, ${i.now} here · ${i.owners.length > 0 ? `could be applied to ${i.owners.join(', ')}` : `applied to no prefab: ${i.why ?? 'none can hold it'}`}`;
    const revert = button('scene_override', 'Revert', 'Back to what the prefab gives', () => host.revert(all.root, [i]), 'ed-quiet ed-small');
    // None can hold it (a ref outside the instance): Apply refused, and why, on the button.
    const unheld = i.owners.length === 0 ? `No prefab can hold it: ${i.why ?? 'none of them has it'}` : null;
    const apply = button('scene_override', 'Apply', blocked ?? unheld ?? (i.owners.length === 1 ? `Into ${i.owners[0]}'s file` : `Into one of ${i.owners.join(', ')}`), () => {
      if (blocked || unheld) return;
      if (i.owners.length === 1) host.apply(all.root, [i], i.owners[0]!);
      else host.menu(apply, itemMenu(host, all.root, [i]).slice(1), i.what);
    }, 'ed-quiet ed-small');
    apply.disabled = blocked !== null || unheld !== null;
    row.append(words, values, revert, apply);
    box.append(row);
    if (turned) {
      const axes = el('div', 'ed-dim ed-ov-turn');
      axes.append(...turned.map((said) => el('span', '', said)));
      box.append(axes);
    }
  }
  for (const note of all.notes) box.append(el('div', 'ed-dim ed-ov-note', note));
  return box;
}

/** How far in `key` is, for this instance: 0 its own prefab, more for one it nests. */
function depthOf(all: InstanceItems, key: string): number {
  let best = Infinity;
  for (const chain of all.prefab.owners) {
    const at = chain.findIndex((o) => o.key === key);
    if (at >= 0) best = Math.min(best, chain.length - 1 - at);
  }
  return best;
}
