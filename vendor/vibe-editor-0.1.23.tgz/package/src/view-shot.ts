/**
 * `view_shot`'s image (Docs/mcp.md §4, M4): a view drawn the way the screen draws it -- the same renderer, scene,
 * tone mapping and colour space, into the canvas's own drawing buffer -- copied off in the same task, and the frame
 * put back before the browser can show anything: the person's view never moves, and never flickers.
 *
 * - **The size** (`shotSize`, pure): asked, or the view's own shape about `SHOT_WIDTH` wide; at most `SHOT_MAX` on
 *   the long side, and never more than the drawing buffer holds -- made smaller, the shape kept, and said.
 * - **The camera** is a copy of the one looked through, its aspect the image's (`shotCamera`): the view's own is
 *   never touched. A perspective camera's field of view is kept (the height seen); an orthographic one's height.
 * - **Drawn by the game's own draw** (`Game.drawOnce`): the whole canvas as a frame draws it -- the cameras' plan,
 *   their rects and clears, what is drawn over the world, the HUD for the main camera -- copied with `drawImage` in
 *   the same task (the buffer is not kept between frames: `still.ts`), and the frame put back by the game, running or
 *   stopped. A camera of the shot's is drawn whole canvas at the image's aspect, and scaled back to it.
 * - **A lost WebGL context** is refused before anything is drawn (`checkContext`): look again once it is back.
 * - **Encoded** as WebP (or PNG), smaller and coarser until its base64 is under `SHOT_BYTES` -- the relay's answer
 *   carries it -- else refused.
 * - **A canvas of a view's own** (the Model tab's stage): drawn by its owner, then scaled into the image (`fromCanvas`).
 */
import * as THREE from 'three';

/** An image's width by default, before the view's shape gives its height. */
export const SHOT_WIDTH = 1024;
/** The long side, at most. */
export const SHOT_MAX = 2048;
/** Base64 characters at most: under the relay's 4 MB answer, with room for its JSON. */
export const SHOT_BYTES = 3_500_000;

/** The image's size: asked (one side giving the other by the view's shape), else ~1024 wide; within the max and the buffer. */
export function shotSize(view: { width: number; height: number }, buffer: { width: number; height: number }, width: number | null, height: number | null): { width: number; height: number; note: string | null } {
  const aspect = view.width > 0 && view.height > 0 ? view.width / view.height : 16 / 9;
  let w = width ?? (height !== null ? Math.round(height * aspect) : SHOT_WIDTH);
  let h = height ?? Math.round(w / aspect);
  const asked = { w, h };
  const scale = Math.min(1, SHOT_MAX / Math.max(w, h), buffer.width / w, buffer.height / h);
  w = Math.max(1, Math.floor(w * scale));
  h = Math.max(1, Math.floor(h * scale));
  const note = w !== asked.w || h !== asked.h ? `Drawn ${w}×${h}, not the ${asked.w}×${asked.h} asked: ${scale * Math.max(asked.w, asked.h) >= SHOT_MAX - 1 ? `at most ${SHOT_MAX} on the long side` : 'the canvas holds no more'}.` : null;
  return { width: w, height: h, note };
}

/** A copy of `camera` where it is, looking as it looks, its aspect `aspect`: what the image is seen through. */
export function shotCamera(camera: THREE.Camera, aspect: number): THREE.Camera {
  camera.updateMatrixWorld(true);
  const copy = camera.clone();
  copy.clear();
  copy.matrixAutoUpdate = false;
  copy.matrixWorldAutoUpdate = false;
  copy.matrixWorld.copy(camera.matrixWorld);
  copy.matrixWorldInverse.copy(camera.matrixWorld).invert();
  const p = copy as THREE.PerspectiveCamera;
  const o = copy as THREE.OrthographicCamera;
  if (p.isPerspectiveCamera) {
    p.aspect = aspect;
    p.updateProjectionMatrix();
  } else if (o.isOrthographicCamera) {
    const high = o.top - o.bottom;
    const mid = (o.left + o.right) / 2;
    o.left = mid - (high * aspect) / 2;
    o.right = mid + (high * aspect) / 2;
    o.updateProjectionMatrix();
  }
  return copy;
}

/** A canvas as base64 of `format`, under `SHOT_BYTES`: WebP coarser until it fits (a browser with no WebP gives PNG). */
export async function encode(canvas: HTMLCanvasElement, format: 'webp' | 'png'): Promise<{ data: string; mimeType: string }> {
  const blobOf = (type: string, quality?: number): Promise<Blob> =>
    new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('the image could not be encoded'))), type, quality));
  for (const quality of format === 'webp' ? [0.9, 0.75, 0.5] : [undefined]) {
    const blob = await blobOf(`image/${format}`, quality);
    const data = await base64Of(blob);
    if (data.length <= SHOT_BYTES) return { data, mimeType: blob.type || `image/${format}` };
  }
  throw new Error(`the image is over ${Math.round(SHOT_BYTES / 1e6)} MB even made coarser: ask for it smaller (width)`);
}

async function base64Of(blob: Blob): Promise<string> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}

/** What a shot says when the WebGL context is lost: nothing can be drawn until the browser gives it back. */
export const CONTEXT_LOST = 'the WebGL context is lost: look again once it is back';

/** Refused, before anything is drawn, while `gl` -- a renderer's context, a canvas's -- is lost. */
export function checkContext(gl: { isContextLost(): boolean } | null | undefined): void {
  if (gl?.isContextLost()) throw new Error(CONTEXT_LOST);
}

/** A rect of the canvas, CSS pixels from its top left (`FrameRect`). */
export interface ShotRect {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

/** What `drawShot` draws with: the game's renderer and its one-frame draw (`Game.drawOnce`). */
export interface ShotGame {
  readonly renderer: THREE.WebGLRenderer;
  /** `copy` given the rect of the canvas it drew in, CSS pixels: the frame (`Game.frame`), or the room for a camera given. */
  drawOnce<T>(camera: THREE.Camera | null, over: boolean, ui: boolean, copy: (rect: Readonly<ShotRect>) => T): T;
}

/**
 * A frame drawn as the screen draws it -- the game's own draw (`Game.drawOnce`: its cameras' plan and clears, what is
 * drawn over the world, the UI if `ui`) -- through `camera`, a copy with the image's aspect (`shotCamera`), or null for
 * the game's own cameras; the part of the canvas drawn -- the game's frame (`Game.frame`, the whole canvas but in studio
 * mode), or the whole room through a camera given, never a preview's box or its low-resolution target -- copied off scaled to `size` in the same task, and the frame put back by the
 * game. `hide` is called around it (the editor's overlays out of the scene, and back); `over` draws what the editor
 * draws over the world (the view cube, a camera's preview). Refused on a lost context.
 */
export function drawShot(game: ShotGame, camera: THREE.Camera | null, size: { width: number; height: number }, options: { over: boolean; ui: boolean }, hide: ((hidden: boolean) => void) | null): HTMLCanvasElement {
  checkContext(game.renderer.getContext());
  const canvas = game.renderer.domElement;
  const out = document.createElement('canvas');
  out.width = size.width;
  out.height = size.height;
  const g = out.getContext('2d');
  if (!g) throw new Error('no 2D canvas to copy the image onto');
  const seen = camera === null ? null : shotCamera(camera, size.width / size.height);
  hide?.(true);
  try {
    // Drawn over the whole canvas at the image's aspect, then scaled back to it: the shape comes out right.
    // The drawn part of the drawing buffer: its rect in CSS pixels, at the buffer's own scale.
    const scale = canvas.width / Math.max(1, canvas.clientWidth || canvas.width);
    game.drawOnce(seen, options.over, options.ui, (f) => {
      const sx = Math.round(f.x * scale);
      const sy = Math.round(f.y * scale);
      const sw = Math.max(1, Math.min(canvas.width - sx, Math.round(f.width * scale)));
      const sh = Math.max(1, Math.min(canvas.height - sy, Math.round(f.height * scale)));
      g.drawImage(canvas, sx, sy, sw, sh, 0, 0, size.width, size.height);
    });
  } finally {
    hide?.(false);
  }
  return out;
}

/** A view's own canvas (the Model tab's), drawn just now by its owner, scaled into an image of `size`; refused on a lost context. */
export function fromCanvas(source: HTMLCanvasElement, size: { width: number; height: number }): HTMLCanvasElement {
  checkContext(source.getContext('webgl2'));
  const out = document.createElement('canvas');
  out.width = size.width;
  out.height = size.height;
  const g = out.getContext('2d');
  if (!g) throw new Error('no 2D canvas to copy the image onto');
  g.drawImage(source, 0, 0, source.width, source.height, 0, 0, size.width, size.height);
  return out;
}
