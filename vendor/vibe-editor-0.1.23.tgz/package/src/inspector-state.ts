/**
 * The inspector's line for what every entity has (Docs/ecs.md §21): under the
 * facts, its switches -- shown or hidden, in play or switched off -- its layer,
 * its tags and its labels. Of several, each says how many: a
 * switch set on some, the layer `—` where they differ, a tag on some "Wanderer
 * (some)", a label only some have "2 of 3".
 *
 * - **A switch flips the selection** (the tool's `toggle`, `edits.ts`): one
 *   step, `Hide 3`. One set by an ancestor is said -- "Hidden by big crate" --
 *   and stays the ancestor's: a click sets the entity's own.
 * - **The layer** is a list of the named ones (`layers([...])`), then the rest
 *   by number; one chosen moves every one, `Layer → Enemies × 3`. The tree's
 *   rows have the same list (`layerSelect`).
 * - **The tags** are a drop-down of ticks (`tags-drop.ts`), as on the tree's rows.
 * - **The labels** are a drop-down of ticks too, with a field at the bottom to
 *   add one (`labels-drop.ts`).
 */
import { keyLabel } from '@vibe/engine/debug';
import { allLayers, label as labelOf, layerName, NONE, type Entity, type World } from '@vibe/engine';
import type { Blocks } from './inspector-blocks.ts';
import { agreed, MIXED, spread, times } from './multi.ts';
import { control, el, icon } from './shell.ts';
import { labelsDrop, type LabelsState } from './labels-drop.ts';
import { causeOf, isOut, SWITCHES, why, type Switch } from './switches.ts';
import { tagsDrop, type TagsState } from './tags-drop.ts';

/** What each switch is called on its button: set, not set. */
const WORDS: Record<Switch, { on: string; off: string }> = {
  hidden: { on: 'Hidden', off: 'Visible' },
  disabled: { on: 'Disabled', off: 'Enabled' },
  unpickable: { on: 'Unpickable', off: 'Pickable' },
};

/** The switches, the layer, the tags and the labels of every one of `es`: a line under the facts. `tags` and `labels` say which drop-down is down, kept across builds. */
export function stateLine(blocks: Blocks, es: readonly Entity[], tags: TagsState, labels: LabelsState): HTMLElement {
  const { world, host } = blocks;
  const line = el('div', 'ed-line ed-state');
  // Enabled only: hiding is the tree's eye and ⇧H, where it can be seen at a glance down the list.
  const switches = el('span', 'ed-switches');
  switches.append(switchButton(blocks, es, 'disabled'));
  // The layer and the tags kept together, wrapping under the switches as one where the panel is narrow.
  const picks = el('span', 'ed-picks');
  const layer = el('label', 'ed-pick');
  layer.append(el('span', 'ed-dim', 'layer'), layerSelect(world, es, (label) => host.changed(label)));
  picks.append(layer);
  const drop = tagsDrop({ world, changed: (label) => host.changed(label) }, es, tags);
  if (drop) {
    const pick = el('label', 'ed-pick');
    pick.append(el('span', 'ed-dim', 'tags'), drop.button);
    picks.append(pick);
  }
  const labelPick = el('label', 'ed-pick');
  labelPick.append(el('span', 'ed-dim', 'labels'), labelsDrop({ world, changed: (label) => host.changed(label) }, es, labels));
  picks.append(labelPick);
  line.append(switches, picks);
  return line;
}

/**
 * One switch of the selection's as an icon: lit while the selection is in --
 * enabled, or shown -- dim while it is out, half while some are. Its title
 * says which, and who set it where an ancestor did. A click flips the
 * selection, one step.
 */
function switchButton({ world, host }: Blocks, es: readonly Entity[], which: Switch): HTMLButtonElement {
  const { tag, key, set, unset } = SWITCHES[which];
  const own = es.filter((e) => world.has(e, tag)).length;
  const out = es.filter((e) => isOut(world, e, which)).length;
  const many = es.length;
  const words = WORDS[which];
  const b = control('scene_flags', 'ed-switch-icon');
  // Pressed is "in": enabled, or shown.
  b.setAttribute('aria-pressed', out === 0 ? 'true' : out === many ? 'false' : 'mixed');
  b.classList.toggle('ed-out', out > 0 && own < out);
  b.append(icon(which === 'hidden' ? (out > 0 ? 'eyeOff' : 'eye') : 'power'));
  // Who set it, if not itself: an ancestor's, and so not this button's to clear.
  const by = many === 1 && own === 0 && out === 1 ? causeOf(world, es[0]!, tag) : NONE;
  const state = out === 0 ? words.off
    : by !== NONE ? `${words.on} by ${labelOf(world, by)}`
    : out < many ? `${words.on}: ${out} of ${many}`
    : words.on;
  const all = many > 1 ? ` all ${many}` : '';
  const flips = own === many ? `${unset}${all || ' it'} again` : `${set}${all || ' it'}: ${SWITCHES[which].means}`;
  b.title = `${state}. ${many === 1 && out > 0 ? `${why(world, es[0]!)}. ` : ''}${flips} (${keyLabel(key)})`;
  b.setAttribute('aria-label', state);
  b.addEventListener('click', () => host.toggle(which, es));
  return b;
}

/**
 * The layer of every one of `es` -- or of `shows`, a tree row's own, while the
 * list moves the whole selection -- as a list: the named ones by name, the
 * rest by number, `—` while they differ. Chosen, every one of `es` goes onto
 * it, one step. `lazy`, for a tree row, which is drawn again with every
 * scroll: only what it says, the rest made as it is pressed or tabbed to.
 */
export function layerSelect(
  world: World,
  es: readonly Entity[],
  changed: (label: string) => void,
  { shows = es, lazy = false }: { shows?: readonly Entity[]; lazy?: boolean } = {},
): HTMLSelectElement {
  const pick = el('select', 'ed-input');
  const now = shows.map((e) => world.layerOfEntity(e));
  const same = agreed(now);
  const names = allLayers();
  const mixed = (): HTMLOptionElement => {
    const option = new Option(MIXED, '', true, true);
    option.disabled = true;
    return option;
  };
  let filled = false;
  const fill = (): void => {
    if (filled) return;
    filled = true;
    pick.replaceChildren();
    const unnamed = el('optgroup');
    unnamed.label = 'Unnamed';
    if (same === null) pick.append(mixed());
    for (let layer = 0; layer < 32; layer++) {
      const option = new Option(names[layer] ? names[layer] : String(layer), String(layer), false, layer === same);
      if (names[layer]) pick.append(option);
      else unnamed.append(option);
    }
    pick.append(unnamed);
  };
  if (lazy) {
    pick.append(same === null ? mixed() : new Option(layerName(same), String(same), true, true));
    pick.addEventListener('pointerdown', fill);
    pick.addEventListener('focus', fill);
  } else fill();
  const goes = es.length > 1 ? `all ${es.length} selected go` : 'it goes';
  pick.title = same === null
    ? `Layers differ: ${spread(now.map((layer) => layerName(layer)))}. Chosen, every one goes onto it`
    : `Layer ${same}${names[same] ? `, ${names[same]}` : ''}: what systems and queries filter by, and the three.js layer it is drawn on. Chosen, ${goes} onto it`;
  pick.addEventListener('change', () => {
    const layer = Number(pick.value);
    const moved = es.filter((e) => world.layerOfEntity(e) !== layer);
    for (const e of moved) world.setLayer(e, layer);
    changed(times(`Layer → ${layerName(layer)}`, moved.length));
  });
  return pick;
}
