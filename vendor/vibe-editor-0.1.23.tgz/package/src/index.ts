/**
 * The editor as a library, and where a reader starts (Docs/ecs.md §13): the host
 * (`createEditor`), the tool contract (`tool.ts`), the tools -- Scene, Config,
 * Model, the Assets panel -- the Config tab's pages, and the parts a game's own tool or
 * page is built of. The files, by what they are:
 *
 *   editor.ts      the host: the top bar, the tool strip, the docked side panels (sidePanel) and the
 *                  scene's header -- Scene or Prefab, Save and Back -- at the tree's top (shell.ts), the bar's middle --
 *                  gizmo, toggles, status line -- what was said a moment ago (top-bar.ts) -- history-card.ts,
 *                  keys-card.ts, the agent's card (agent/), playtest, the host's keys, and no browser menu
 *                  over the editor but in a field of text (keepsBrowserMenu, dom.ts);
 *                  resume.ts, the record of a reload the editor survives (prepareReload, resume)
 *                  and the pass past the leave guard (createReloadPass);
 *                  rebuild-follow.ts, the game's code swapped under it (Game.rebuild's two hooks): a
 *                  playtest ended and an edit committed before, the world read again after
 *                  notices.ts and notices-strip.ts, what went wrong under the top bar (Docs/studio.md §1);
 *                  recovery.ts and recovery-fix.ts, the game that could not load at boot; code-notices.ts, the
 *                  project's code broken mid-session -- a module the dev server cannot serve, a failed swap, a system
 *                  that threw, a module that threw as the dev server's probe page evaluated it -- each at its
 *                  TypeScript line, with Open; studio/probe-frames.ts, that probe page as a hidden frame
 *   tool.ts        what a tool is, and what the editor hands it; what a Config page is (ConfigPage, ctx.pages)
 *   sides.ts       the tabs and what each shows -- a tool `within` another's, the Assets panel in
 *                  Scene -- which side has the keys and the bars' history, whose card the right
 *                  panel is (the one inspector, whoever chose last)
 *   entities.ts    the entity tool, the Scene tab (id `entities`): tree.ts (filter.ts; columns.ts, which a row shows;
 *                  drop-zone.ts, where a drop on a row goes), its right-click menu's Create (prefab-groups.ts, the
 *                  prefabs by folder),
 *                  inspector.ts (-blocks, -transform, -relations, -state; multi.ts, several
 *                  selected at once; blocks.ts, the blocks as a list a project adds to; key-field.ts, a key()
 *                  field's picker of any kind (a mesh()'s part too), a color() field's swatch and a bool() field's tick;
 *                  key-looks.ts, each key's look -- a thumbnail the Assets tool's (EditorContext.modelThumb), a swatch, a
 *                  glyph, a font -- and a sound's play button through Audio), drop.ts (a list floated under its button, `dropUnder`: every drop-down's), tags-drop.ts (the tags as ticks, a row's and the
 *                  inspector's), labels-drop.ts (the labels as ticks, and a field to add one; labels.ts, their writes, pure), add-component.ts (the inspector's Add Component button and its card: a search, categories opened in place; component-menu.ts, its grouping by `menu` and its search ranking, pure), names.ts (the title's rename, pure), edits.ts (spawn.ts, clip.ts; prefab-views.ts, a copy drawn as the prefab draws it), save-prefab.ts and prefab-write.ts (Save as prefab, entities as a prefab file), switches.ts (Hidden and Disabled,
 *                  shown and flipped), link-lines.ts
 *   config/        the Config tab (key 2): config.ts, its tree of pages on the left and the page on the rest
 *                  of the screen; pages.ts, the pages' registry and the tree's rules (groups, folds, the page
 *                  kept, the arrows -- tested); a page each: systems.ts (Game ▸ Systems), scenes.ts (Game ▸
 *                  Scenes: the scene files under src/assets/scenes/, written through PUT prefab, the start
 *                  scene, the browser's old scenes moved in once; with when.ts and ../assets/scene-files.ts), tools.ts (Assets ▸ Tools, the Assets tool's Tools block),
 *                  preferences.ts (Editor ▸ Preferences), keys.ts (Editor ▸ Keys), claude.ts (Claude ▸
 *                  Settings, agent/settings-picks.ts)
 *   view/          a view of a scene, the Model tab's and the Scene tab's: views.ts (where a camera looks
 *                  from and its name, a rect, the cube's box; pure), view-camera.ts (a camera in both
 *                  projections: orbit, pan, zoom to a point, centre, framing, the clip planes, the floor's
 *                  polar limit), cube.ts (the orientation cube); Blender's navigation (Docs/navigation.md):
 *                  navigation.ts (the rule: a press or a wheel event to orbit, pan, zoom, snap, box, menu;
 *                  pure), navigator.ts (the one driver of every view's camera), nav-keys.ts (the numpad's
 *                  table, Emulate Numpad's twins; pure), over-view.ts (the pointer over a 3D view),
 *                  alt-through.ts (a gizmo standing aside for Emulate 3 Button Mouse's Alt+left), walk.ts
 *                  (walk's numbers and its key gate; pure), walker.ts (walk, its pointer lock and listeners)
 *   model/         the Model tab (key 3, Docs/modeler.md): a Gladius script's export in 1, 2 or 4 views of
 *                  its own renderer -- model-tool.ts (the tab: panels, banner, empty state, openModel),
 *                  model-keys.ts (its keys: which wins where two share one, Esc's order), model-room.ts (the
 *                  Assets panel folded for the views' room), export-row.ts (the model card's cull, clean, merge),
 *                  source.ts (the open model: its own client index, its build, GET model), stage.ts (the
 *                  canvas, the views, the pointer), views.ts (layouts, the grid's scale), grid.ts,
 *                  shading.ts (the polygons from the kernel), outline.ts,
 *                  parts.ts and stats.ts (the outliner's and the overlay's rules, pure), outliner.ts,
 *                  inspector.ts; phase 2's editing.ts (parameters, previews, materials, the tab's undo),
 *                  per-model.ts (one reset), param-panel.ts, params.ts and param-reader.ts, preview-client.ts, material-panel.ts and materials.ts,
 *                  lua-table.ts and script-edits.ts (the script's material{} and params{} written),
 *                  script-steps.ts (whole-file steps, outside edits); phase 3's canvases.ts (drawings over a view,
 *                  each with its camera, the paint mode), canvas-math.ts (pure), anchors.ts (marks raycast),
 *                  canvas-panel.ts (the Canvases pane), canvas-books.ts (each script's canvases, pure),
 *                  history-switch.ts (a canvas's own undo); phase 4's
 *                  animating.ts (clips, bones, weights, a pose keyed), animation.ts (the player), bones.ts (the
 *                  bones overlay), animation-panel.ts (the strip, the Animation block), clips.ts (pure), weights.ts,
 *                  posing.ts (the gizmo), pose-math.ts (Gladius's pose numbers), pose-keys.ts (the key
 *                  written, pure); phase 5's tracing.ts (the build trace: traced, shown, played), trace-view.ts
 *                  (its steps drawn, their moves), trace-panel.ts (the block, the strip), trace-steps.ts (pure);
 *                  model.css
 *   studio/        the Studio tab (key 5), among the editor's tabs always (the editor is studio mode's, `?studio`):
 *                  studio-tool.ts (the tab: its left panel, the strip's six
 *                  cards -- Console, Problems, Tests, Build, Code (code-card.ts, code/: its tree's menu, names and
 *                  drags' rules code/file-names.ts, pure), Git (git-card.ts; git/, its
 *                  rows, commit plan, log and ask bar, and the Draft with Claude turn) -- and the bar's controls
 *                  through ctx.control), strip.ts (a tab strip over one body, Mod+Alt+1-6), state.ts (StudioState: the problems pill and the
 *                  running task's spinner in the top bar's middle), app-shell.ts (the Squidwright app's
 *                  window.squidwright: the Build card's Reveal, the Code card's Delete to the Trash, the Game menu's commands)
 *   viewport.ts    the scene: camera.ts (view/navigator.ts, wheel.ts; walk), gizmo.ts (gesture.ts), picking.ts
 *                  (marquee.ts, the box that selects), overlays.ts, scene-cube.ts (the view cube),
 *                  camera-view.ts (camera entities' icons and shapes, the frustum, the preview; view/draw-into.ts),
 *                  camera-shape.ts (the shapes' and the frustum's lines; pure), pick-lines.ts (fat lines a click takes);
 *                  inspector-camera.ts (the Camera block), camera-notice.ts (no main camera, said),
 *                  camera-entity.ts (their numbers: isometric, align, the preview's rect, the rule; pure)
 *   history.ts world-steps.ts selection.ts prefs.ts   what the tools share and the editor keeps
 *   opened.ts          a prefab opened to edit (Docs/prefabs.md §7): the world and its history put aside, Save, Back,
 *                      every level asked before it is left; every instance in it -- its file's, and one placed in
 *                      since -- kept against the compile it was made from (`made`) and followed;
 *                      bring-up.ts, what it nests compiled anew brought up where it holds no edit (the live update's rule),
 *                      its entities gained and lost followed (`structureOf`), and runtime state carried (`takeRuntime`);
 *                      on-disk.ts, a prefab file changed on disk since it was read or written (Save's check, and Apply's)
 *   prefabs-live.ts    prefabs compiled live as their files change, the live update of every instance out, the
 *                      compile's problems (`livePrefabs`); prefab-drop.ts, a prefab dragged into the scene, onto a
 *                      tree row or between two
 *   root-edit.ts       a prefab's root edited without opening it (the Assets tool's Root block): a scratch instance,
 *                      the file written from it, what refuses an edit
 *   overrides-edit.ts  an instance's overrides as items a person settles (itemsOf, planApply, revertItems, unpack);
 *                      overrides-steps.ts, Revert, Apply and Unpack as steps -- Apply one step with its files, its
 *                      undo and redo landing; inspector-overrides.ts, the marks, their menus and the Overrides list;
 *                      hold.ts, every way in held while an Apply lands -- the one list of what is held;
 *                      level-keys.ts, a prefab's key rewritten in the level and scene files that hold its instances
 *   active-history.ts  whose Undo: the focused tool's own stack (`ToolInstance.history`), else the
 *                  world's -- in Scene, by the side with the keys; nothing while that tool is `busy()`
 *   shell.ts fields.ts menu.ts icons.ts shell.css     the parts every card is made of -- menu.ts with
 *                  submenus (menu-place.ts, where a card goes); dom.ts the plain ones (el, icon, button,
 *                  keepsBrowserMenu) without the stylesheet, for what node imports
 *   ask.ts         a question in a panel, never prompt/confirm/alert (Scenes', the Assets tool's)
 *   dialog.ts      the one modal dialog, centred on a dimmed backdrop, its keys MrDebug's (registered
 *                  first, the editor's others resting while it is up): "lose what changed?" (askUnsaved)
 *                  -- a scene opened, imported or New over unsaved changes, Back from a prefab with them
 *   skipped.ts     what a load or a paste skipped, as sentences (Scenes, Paste, a reload)
 *   markdown.ts    Markdown read into blocks (parseMarkdown, node-tested) and drawn as elements,
 *                  never markup (renderMarkdown): the Assets tool's .md preview, the agent's words
 *   virtual.ts     long lists drawn only where scrolled to: range() (the tree's), and mount(),
 *                  elements kept by key (the Assets tool's folders and files)
 *   assets/        the Assets tool's client library (Docs/assets.md §8): api.ts (the dev
 *                  server's API, `online`), live.ts (the push channel), model.ts (the client
 *                  index, folderTree, the project above the roots), steps.ts (asynchronous steps on a tool's own stack),
 *                  bundle.ts (bundle view); strays.ts (files that are no prefab, for prefab_info); boot.ts (watchAssets, from boot: reload.ts and
 *                  swap.ts, a re-export swapped into the game; convert.ts, the browser's
 *                  conversion); preview/ -- previewers.ts (three's loader for each source
 *                  format), scratch.ts (a file decoded for a preview alone, the export when its
 *                  source is current), renderer.ts (the one preview renderer: a model or a
 *                  texture shown, its controls, thumbnails captured), audio.ts (a sound's
 *                  peaks, decoded offline, played through Audio.preview), thumbs.ts (the
 *                  thumbnail queue and its LRU); ui/ -- the Assets tool, the panel along the bottom of
 *                  the Scene tab (Docs/assets-tool.md):
 *                  assets-tool.ts (createAssetsTool, assetsTool: the panel, its fold, the focus, the keys,
 *                  the hint, the steps), assets-keys.ts (its keys as data, by scope),
 *                  prefab-steps.ts (a prefab's New, Rename, Duplicate, Make variant, pool and
 *                  Delete as steps through PUT prefab; prefabText, the one layout), prefab-block.ts
 *                  (a prefab's block: problems, root, entities, pool, used by), prefab-root-block.ts (its
 *                  root's components edited there, the Entities inspector's blocks on ../../root-edit.ts:
 *                  a scratch instance written back through prefab-write.ts), scene-block.ts (a scene
 *                  file's block: name, entities, size, modified, on start, Open), ../scene-files.ts (a
 *                  scene's key from a name, its path, its text, the browser's old scenes' move -- tested),
 *                  folders.ts (the panel's left column: the project, the roots and folders, marks, twins), naming.ts
 *                  (ROOT_TITLES, a slot by when, a path as said, a breadcrumb from the project), tools-block.ts (Config ▸ Tools' block), files.ts
 *                  (the panel's right column, its height and grip: list and grid, breadcrumb, search, Issues, sort), files-columns.ts
 *                  (FILE_COLUMNS, sortEntries, the grid's geometry), file-filter.ts (the
 *                  search), files-selection.ts (paths chosen; folderTakes; folderOf and
 *                  nearestFolder, only folders that are), marks.ts (the status vocabulary,
 *                  folder counts, issuesOf), export-step.ts (an export as one step, undone through its
 *                  slots), file-steps.ts (every other edit as a step: import, move, rename,
 *                  delete, new folder, copy, keep, restore), code-naming.ts (the keys a move or a rename changes,
 *                  and game code naming them: the refusal, rule 5), model-steps.ts (New model and Make a
 *                  script for a .glb as steps, Docs/modeler.md M38, M39), import-plan.ts (a drop planned:
 *                  names, roles, parts, what PUT import gets), parts-browser.ts (a dropped
 *                  model read for its parts), import-sheet.ts (the sheet over the files card),
 *                  dnd.ts (a desktop drop read, targets, the window's guard, a tile's drag),
 *                  rename-field.ts (a name made a field where it is), trash-actions.ts
 *                  (Restore and what comes back as -2), budget.ts (the boot set's bytes),
 *                  assets-inspector.ts (the right panel), assets-preview.ts (PREVIEWS and the
 *                  preview block: a model, a texture or KTX2, an atlas, a sound, a font, an
 *                  icon, text, Markdown as a page (../markdown.ts),
 *                  a source by its export or the server's thumbnail, a pointer),
 *                  waveform.ts (a sound's peaks drawn: the preview's and a tile's strip),
 *                  assets-stats.ts (STATS, the bytes, GET stats asked once a content),
 *                  warnings.ts (WARNINGS and their thresholds), assets-options.ts (a recipe's
 *                  options as fields, folder defaults, a change one step through PUT sidecar),
 *                  jobs-strip.ts, banners.ts, assets.css (`ed-as-` classes, through addSheet)
 *   agent/         the agent's card (Docs/agent.md §4), Claude Code hosted by the dev server's
 *                  packages/pipeline/src/agent/ (its contract: packages/pipeline/src/agent/api-types.ts, types only):
 *                  agent-card.ts (the card: its tab row -- a conversation a tab, several at
 *                  once -- head, transcript, prompt bar; folded; its keys' handles), hub.ts (the
 *                  push channel the tabs share: each conversation's messages to its own live,
 *                  the list, the editor tools' calls, the hello), transcript.ts (the entries drawn; the head's words and the model,
 *                  pure), prompt-box.ts (the box, the history ring and caret rule, images, the
 *                  draft), context.ts (the editor's facts as a TurnContext, pure), shot.ts (the
 *                  screenshot, images made fit), live.ts (the push by seq and epoch, the tab's
 *                  hello), api.ts (the routes under /__agent/, a conversation's by its id), mcp/page.ts (the editor's half
 *                  of the agent's editor tools, §8: a relayed call run against the world, pure --
 *                  the selection, describe, the prefabs, set, instantiate, overrides, Save as
 *                  prefab, the scene saved; its edits as values -- a row's Undo, Undo this
 *                  turn's, carried across a reload), tab.ts (this tab's id, one per live tab), agent.css (`ed-ag-` classes,
 *                  through addSheet); mcp/declare.ts (`Mcp`: what every action of the editor's says of its MCP tool,
 *                  Docs/skills.md §9 S2 -- an argument of button, iconButton and control, a field of MenuItem, ToolKey
 *                  and NoticeAction) and mcp/gaps.ts (the actions no tool does: GAPS still to get one -- none since S5 -- NOT_FOR_CLAUDE by design)
 *   (examples)     a game's own Assets tool -- a preview, a column, a warning, a stat, a menu item, a
 *                  title, a budget and a key in one file -- and the tile tool are examples/tools/
 *                  (`@vibe/example-tools`), run by the sandbox and typechecked with the workspace
 *   panel.ts       the debug panel and the stats (boot's PanelModule), the package's other entry
 *                  (`@vibe/editor/panel`): a lazy chunk of its own in a debug build
 *   testing.ts     what the editor's tests share (WORKSPACE, standInDocument); fixtures/, the prefabs they open
 *   asset-keys.d.ts  AssetKeys as strings, for this package's own typecheck alone
 *
 * The editor is the package `@vibe/editor`; a project reaches it through its main.ts' one
 * `DEBUG`-gated `import('@vibe/editor')`, so a release drops it whole. A game's tools go in the
 * list `createEditor` is given; `boot` makes the editor with that list's default, `editor.ts`'s, and a
 * project's own after it -- its `src/tools/index.ts` (`BootOptions.tools`: tools, pages, inspector blocks,
 * `createEditor`'s `extensions`). `examples/tools/` (`@vibe/example-tools`) has a tool that uses
 * every point: a card, a key, a fact, a block, a data kind and a dev-server route.
 *
 * A tool with one card, one key and one world step -- the selection dropped onto
 * the ground:
 *
 * ```ts
 * import { Transform } from '@vibe/engine';
 * import { button, el, type EditorTool } from './index.ts';
 *
 * export const groundTool: EditorTool = {
 *   id: 'ground', name: 'Ground', icon: 'move', key: 'Digit6',
 *   create(ctx) {
 *     const drop = (): void => {
 *       const t = ctx.world.store(Transform);
 *       for (const e of ctx.selection.list) {
 *         t.py[e] = 0;
 *         ctx.world.moved(e);
 *       }
 *       // One step however many moved, called what it did; then the other tools read the world again.
 *       if (ctx.worldSteps.commit('Drop')) ctx.emit('changed');
 *       ctx.draw();
 *     };
 *     // Docked on the left, from the strip's edge, as the tree is; its header a bar across its top.
 *     const card = el('div', 'ed-card ed-side ed-left');
 *     const bar = el('div', 'ed-panel-head ed-panel-bar');
 *     bar.append(el('div', 'ed-side-title', 'Ground'));
 *     card.append(bar, button('Drop the selection', 'Every selected entity onto the ground (G)', drop));
 *     ctx.root.append(card);
 *     // Live while this tool is up and the editor is editing: `editor: drop` in the debug panel.
 *     ctx.keys.add({ name: 'drop', key: 'KeyG', help: 'Drop the selection onto the ground', run: drop });
 *     return {
 *       setVisible: (visible) => void (card.hidden = !visible),
 *       dispose: () => card.remove(),
 *     };
 *   },
 * };
 *
 * createEditor({ name, game, onClose, onPlaytest, tools: [entitiesTool, groundTool, configTool, assetsTool] });
 * ```
 *
 * A setting, or a table to look at, is a page of the Config tab rather than a
 * tab: a row in its tree under a group -- one of the editor's (Game, Assets,
 * Editor, Claude) or the game's own, after them -- and the rest of the screen
 * while it is chosen. Given to `createEditor`, or added by a tool whose state it
 * shows with `ctx.pages.add(page)` as it is made (`ctx.pages.show(id)` brings
 * it up):
 *
 * ```ts
 * import { button, el, type ConfigPage } from './index.ts';
 *
 * let gravity = 9.8;
 * export const levelPage: ConfigPage = {
 *   id: 'level', title: 'Level', group: 'Game', help: 'This level\'s gravity',
 *   create(ctx) {
 *     const root = el('div');
 *     const line = el('div', 'ed-dim');
 *     const draw = (): void => void (line.textContent = `Gravity ${gravity} m/s²`);
 *     // A change that is no world edit is a step of its own: Z undoes it on this tab, as anywhere.
 *     const set = (to: number): void => {
 *       const from = gravity;
 *       ctx.history.push({ label: 'Gravity', undo: () => ((gravity = from), draw()), redo: () => ((gravity = to), draw()) });
 *       gravity = to;
 *       draw();
 *     };
 *     root.append(line, button('Moon', 'Gravity as on the Moon', () => set(1.6)));
 *     return {
 *       root,
 *       // Read afresh as it is shown: the Config tab puts `root` in its page, under the title.
 *       setVisible: (visible) => void (visible && draw()),
 *       refresh: draw,
 *       dispose: () => root.remove(),
 *     };
 *   },
 * };
 *
 * createEditor({ name, game, onClose, onPlaytest, pages: [levelPage] });
 * ```
 *
 * A key may be a chord, or several: `key: ['KeyG', 'Mod+KeyG']` (`Mod` is Cmd
 * on a Mac, Ctrl elsewhere); the keys card (`?`) lists it under the tool's name
 * while it is live. A side card that should resize and fold away like the tree
 * and the inspector is `sidePanel(ctx.root, card, 'left', { name })`, its `fold`
 * put on the card's header (`.ed-panel-bar`).
 *
 * A step that is not the world's -- the tool's own state, a palette, a spline
 * kept outside the ECS -- is pushed once it is done, and undoes with the rest:
 * `ctx.history.push({ label: 'Paint', undo: () => ..., redo: () => ... })`.
 * Several as one: `ctx.history.group('Fill', () => ...)`.
 */
// What boot asks of the editor (@vibe/engine/boot's EditorModule): createEditor, openedOnStart, resume here,
// watchAssets with the Assets tool's client below. A project hands `() => import('@vibe/editor')` to
// boot's `editor`, typed `() => Promise<EditorModule>`: its typecheck holds this module to the contract.
export { createEditor, openedOnStart, resume, type Editor, type EditorOptions } from './editor.ts';
export { entitiesTool } from './entities.ts';
export { TAB_PAGES, tabId, type TabId } from './tab-pages.ts';
export { configTool, CONFIG_ID } from './config/config.ts';
export { studioTool, STUDIO_CARDS, STUDIO_ID, type StudioInstance, type StudioState } from './studio/studio-tool.ts';
export { createStrip, STRIP_KEYS, type Strip, type StripOptions, type StripTab } from './studio/strip.ts';
export { createPages, GROUPS, rowsOf, type PageRow } from './config/pages.ts';
export { systemsPage } from './config/systems.ts';
export { scenesPage } from './config/scenes.ts';
export { PREFERENCES_PAGE, preferencesPage, type PreferencesPageOptions } from './config/preferences.ts';
export { keysPage, type KeysPageOptions } from './config/keys.ts';
export { toolsPage, TOOLS_PAGE } from './config/tools.ts';
export { assetsTool, createAssetsTool, type AssetsKeyAt, type AssetsToolKey, type AssetsToolOptions } from './assets/ui/assets-tool.ts';
export type { ConfigPage, ConfigPages, EditorContext, EditorEvent, EditorExtensions, EditorTab, EditorTool, PageInstance, PagesTab, ProjectMcpTool, ProjectToolAnswer, ProjectToolContext, ToolFact, ToolInstance, ToolKey } from './tool.ts';
export { BLOCK_ORDER, blockList, blocksFor, fielded, type BlockItem, type BlockUse } from './blocks.ts';
export { createHistory, type History, type HistoryEvent, type HistoryOptions, type Step } from './history.ts';
export { createHistoryHost, type HistoryHolder, type HistoryHost } from './active-history.ts';
export { createWorldSteps, type WorldSteps } from './world-steps.ts';
export { boxHow, clickHow, clickOn, combined, rangeOf, type ClickHow, type Combine, type Selection } from './selection.ts';
export type { GizmoMode, GizmoSpace, Viewport, ViewportEvent } from './viewport.ts';
export type { AssetsPrefs, NavPrefs, Snap } from './prefs.ts';
export { numberField, onCloseRequest, textEdit, textField, textInput, type NumberField, type NumberOptions, type TextOptions } from './fields.ts';
export { createMenu, type Menu, type MenuItem, type MenuOptions } from './menu.ts';
export type { Gap, Mcp, McpTool, ProjectNone } from './mcp/declare.ts';
export { projectNone } from './mcp/declare.ts';
export { addSheet, button, control, el, icon, iconButton, letGo, mcpText, sidePanel, type SidePanel, type SidePanelOptions } from './shell.ts';
export { dropUnder, type DropOptions, type Dropped } from './drop.ts';
export { agreed, spread, times } from './multi.ts';
export { BUILT_IN_BLOCKS, dataBlock, foldable, head, objectBlock, renderBlock, type Blocks } from './inspector-blocks.ts';
export { colorLine, keyLine, picker, type KeyLook, type KeySources, type Picker, type PickerOptions } from './key-field.ts';
export { createAsk, type Ask } from './ask.ts';
export { askUnsaved, closeDialog, dialogNote, dialogOpen, showDialog, type DialogButton, type DialogSpec, type UnsavedQuestion } from './dialog.ts';
export { itemsOf, mount, perRowOf, range, revealTop, type MountOptions, type Mounted, type Span } from './virtual.ts';
export type { IconName } from './icons.ts';
export { API_BASE, ApiRefused, createApi, type AnswerSink, type Api, type ImportQuery, type Online, type ThumbAnswer } from './assets/api.ts';
export { createLive, type HotChannel, type Live, type LiveEvents } from './assets/live.ts';
export { createIndex, folderTree, PROJECT, slotFolder, type Applied, type Children, type ClientIndex, type FolderTree, type Shown } from './assets/model.ts';
export { createSteps, type Answered, type Doing, type Steps } from './assets/steps.ts';
export { bundleIndex, type BundleFile, type BundleIndex } from './assets/bundle.ts';
export { assetApi, onReloaded, shippedFiles, useDraw, watchAssets } from './assets/boot.ts';
export type { Reloaded } from './assets/reload.ts';
export { swap } from './assets/swap.ts';
export { PREVIEWERS, type Loaded, type Previewer } from './assets/preview/previewers.ts';
export { createScratchStore, decodeScratch, decodingOf, previewPath, type Scratch, type ScratchOptions, type ScratchStore } from './assets/preview/scratch.ts';
export { createPreviewRenderer, type ClipOptions, type PreviewInfo, type PreviewRenderer } from './assets/preview/renderer.ts';
export { createSoundPlayer, decodeSound, NOTE_WORDS, peaks, soundNote, type Peaks, type SoundNote, type SoundPlayer } from './assets/preview/audio.ts';
export { createThumbs, STRIP_COLUMNS, type Thumbs, type ThumbsOptions, type ThumbWant } from './assets/preview/thumbs.ts';
export { PREVIEWS, PREVIEW_ROWS, previewFor, type PreviewContext, type PreviewRow, type PreviewShown } from './assets/ui/assets-preview.ts';
export { STATS, type StatLine, type StatsRow } from './assets/ui/assets-stats.ts';
export { FILE_COLUMNS, NOTHING, type Cell, type FileColumn } from './assets/ui/files-columns.ts';
export { ROOT_TITLES } from './assets/ui/naming.ts';
export { SFX_SECONDS, TEXTURE_MAX, TRIANGLES_MAX, WARNINGS, type Warning } from './assets/ui/warnings.ts';
export { waveStrip } from './assets/ui/waveform.ts';
