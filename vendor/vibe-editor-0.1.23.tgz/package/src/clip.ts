/**
 * Entities as a clip: copied out of a world as plain data, and pasted into one
 * -- the same world, another scene, or the game after a reload, through the
 * clipboard as JSON (Docs/ecs.md §13). Pure ECS, no three and no page: node
 * tests it.
 *
 * - **What a clip holds**: each entity copied, with everything under it -- its
 *   kind, its numeric components, its tags (`Hidden` and `Disabled` among
 *   them), its plain object slots (`Name`) and any object with a `save` and
 *   `load` of its own (`Labels`), its layer, which of its components are
 *   switched off -- and the relations' links between entities of the clip; a
 *   link to one left out is left out. Not
 *   `View` -- the game dresses what it makes -- nor what the world works out
 *   (`WorldTransform`, anything transient).
 * - **Roots as they were in the world**: an entity copied without its parent
 *   is a root of the clip, its `Transform` its pose in the world, so it pastes
 *   where it looked; under it, children keep their own.
 * - **Refs**: a `ref()` field pointing into the clip points at the copy once
 *   pasted. One pointing out of it is kept only in the world it was copied from
 *   (`keepRefs`): anywhere else the same number is somebody else, so it is
 *   `NO_REF` there.
 * - **Pasted at a point**: the roots keep their offsets across the ground from
 *   the middle of them, and their heights.
 * - **Names** are kept where free, and otherwise made fresh: `little crate 3`
 *   pasted beside itself is `little crate 17` (`freshName`) -- but an entity
 *   inside an instance keeps its name, its prefab's: the rider of every big
 *   crate is `rider`, and a fresh one would be an override.
 * - **An instance stays an instance** (Docs/prefabs.md §7): each entity a
 *   prefab made carries its `Instance` row -- the prefab's key, which entity of
 *   it, and the place in the clip of its instance's root -- and the paste
 *   writes it back (`restoreInstance`), so `world.prefabOf` and
 *   `world.part` work on the copy as on the original.
 * - **A copy is an instance to the hooks**: its entities are spawned bare, and
 *   at the boundary the world's `onInstance` hooks run for its root, as for one
 *   `instantiate` made or `load` brought back -- so its views come the one way
 *   every instance's do (the `render` system, `installRender`). Only with its root: an entity of
 *   an instance copied without the instance's root is a partial copy -- unless
 *   it is inside an instance nested there whose root is copied (a big crate's
 *   rider alone is a `crates/rider`, of that prefab's kinds, what the big crate
 *   changed in it copied as values: its overrides once pasted; Unpack makes
 *   one plain on purpose) -- and pastes as a plain entity of the same make,
 *   drawn by `make`; so does a clip from before prefabs, and an instance of a prefab this
 *   build has not (said in `skipped`).
 * - **A prefab changed since the copy** pastes as `world.load` loads it: each
 *   entity found again by its kind's name, the node's path, the instance an
 *   instance still; what the prefab no longer has plain under it, a node it
 *   gained not made, each said once (`refindNodes`).
 */
import {
  allKinds, Bare, compiledPrefab, componentsOn, fillFrom, isData, mapFields, strayFields, fieldPlain, fieldValue, Hierarchy, inTreeOrder, Instance, keyKindOf, label, linksOf, Name, NO_REF, NONE, pathInOwner, refindNodes, Transform, WorldTransform,
  type AnyComponent, type CompiledPrefab, type Component, type Entity, type EntityRef, type Kind, type World,
} from '@vibe/engine';

import { movers } from './gesture.ts';

/**
 * What Copy copies of `selected`: the topmost of them (one under another goes with it), in the tree's order -- the
 * roots `copyOut` walks. The tree's Copy and `scene_copy` both.
 */
export function copyRootsOf(world: World, selected: readonly Entity[]): Entity[] {
  const links = world.store(Hierarchy);
  return inTreeOrder(world, movers(selected, (e) => links.parent[e]! as Entity));
}

/** The middle of a clip's roots across the ground, as copied: where a paste that keeps its places puts them. */
export function clipMiddle(clip: Clip): { x: number; z: number } {
  let x = 0;
  let z = 0;
  let n = 0;
  for (const c of clip.entities) {
    const t = c.parent < 0 ? c.data[Transform.name] : undefined;
    if (!t) continue;
    x += t.px ?? 0;
    z += t.pz ?? 0;
    n++;
  }
  return n > 0 ? { x: x / n, z: z / n } : { x: 0, z: 0 };
}

/** A data component's ref into the clip, as a clip holds it: the place in `entities` of what it points at. */
export interface ClipRef {
  clip: number;
}
export const isClipRef = (v: unknown): v is ClipRef => typeof v === 'object' && v !== null && !Array.isArray(v) && typeof (v as ClipRef).clip === 'number';

/** What a clip says it is, so a paste of any other text is told apart. */
export const CLIP = 'vibebase.entities';

export interface ClipEntity {
  kind: string;
  /** Its parent's place in `entities`, before it; -1 for a root of the clip. */
  parent: number;
  /** Numeric components by name: each field's value. */
  data: Record<string, Record<string, number>>;
  tags: string[];
  /** Object components by name: a plain slot's value, or what its own `save` made of it -- a data component's refs into the clip `{ clip }`. */
  objects: Record<string, unknown>;
  /** `ref()` fields that point into the clip, as `Component.field`: the place in `entities` of what they point at. */
  refs: Record<string, number>;
  /**
   * Key fields (`key()`, `Render.model`) as their text, as `Component.field`: the id in `data` is the
   * copying page's alone (`ecs/keys.ts`), so a paste -- after a reload, in another tab -- interns this.
   * None in a clip from before keys.
   */
  keys?: Record<string, string>;
  /** Its layer, 0 to 31; none in a clip from before layers is 0. */
  layer?: number;
  /** The components switched off on it (`world.enable(e, C, false)`), by name. */
  off?: string[];
  /** The prefab that made it, which entity of it, and its instance's root's place in `entities` (its own, for the root); none for an entity no prefab made, or whose root was left out. */
  instance?: ClipInstance;
  /**
   * What of it points out of the clip -- a ref field (`PwAim.who`) or a link
   * (`PwLikes`) at an entity alive but not copied -- and that entity, said
   * (`label`): what a prefab written from the clip leaves out, and says so.
   */
  outside?: { what: string; to: string }[];
}

export interface ClipInstance {
  prefab: string;
  /** Its index in the compiled prefab (`world.nodeOf`). */
  node: number;
  root: number;
}

export interface ClipLink {
  relation: string;
  /** Places in `entities`. */
  source: number;
  target: number;
  data: Record<string, number>;
}

export interface Clip {
  format: typeof CLIP;
  version: 1;
  /** Parents before their children. */
  entities: ClipEntity[];
  links: ClipLink[];
  /** Each prefab with an instance in the clip: its nodes' kinds when copied, in node order. What tells a node added to it since; none in a clip from before. */
  prefabs?: Record<string, string[]>;
  /** The same prefabs' nodes' names, in node order: what finds a node whose id was renamed since (`refindNodes`). None in a clip from before. */
  prefabNames?: Record<string, (string | null)[]>;
  /** The world it was copied from, as it was then (`paste.ts`' `worldId`): pasted where that is still the world's, its refs out are kept. None in a clip from before, or made elsewhere. */
  from?: string;
}

/** A column as this file reads and writes it. */
type Columns = Record<string, { [i: number]: number }>;

const plain = (v: unknown): boolean => v === null || ['string', 'number', 'boolean'].includes(typeof v);

/**
 * A name nobody has: `name` itself if it is free, else its stem and the first
 * number from 2 that is -- `little crate 3` copied is `little crate 17`, a
 * second `big crate` is `big crate 2`. `also`: names given already that the
 * world does not have yet, made since its last boundary.
 */
export function freshName(world: World, name: string, also: ReadonlySet<string> = new Set()): string {
  const names = (world.rawStore(Name) as { value: (string | null)[] }).value;
  const taken = new Set<string>(also);
  for (let i = 1; i < world.extent; i++) {
    const e = i as Entity;
    if (world.alive(e) && world.has(e, Name)) taken.add(names[e] ?? '');
  }
  if (!taken.has(name)) return name;
  const stem = name.replace(/\s+\d+$/, '');
  let n = 2;
  while (taken.has(`${stem} ${n}`)) n++;
  return `${stem} ${n}`;
}

/**
 * `roots` and everything under each, as a clip. One under another of them goes
 * once, with its ancestor. The world flushed, so its world transforms are
 * worked out. `order`, if given, gets the entities copied, in the clip's order.
 */
export function copyOut(world: World, roots: readonly Entity[], order: Entity[] = []): Clip {
  const tree = world.store(Hierarchy);
  const at = new Map<Entity, number>();
  const walk = (e: Entity): void => {
    if (at.has(e) || !world.alive(e)) return;
    at.set(e, order.length);
    order.push(e);
    for (let c = tree.firstChild[e]! as Entity; c !== NONE; c = tree.nextSibling[c]! as Entity) walk(c);
  };
  // Those under another root first out: they go with it, in its place.
  const chosen = new Set(roots);
  for (const e of roots) {
    let under = false;
    for (let a = tree.parent[e]! as Entity; a !== NONE; a = tree.parent[a]! as Entity) if (chosen.has(a)) under = true;
    if (!under) walk(e);
  }

  const w = world.store(WorldTransform);
  const prefabs: Record<string, string[]> = {};
  const prefabNames: Record<string, (string | null)[]> = {};
  const entities = order.map((e): ClipEntity => {
    const parent = at.get(tree.parent[e]! as Entity) ?? -1;
    const out: ClipEntity = { kind: world.kindOfEntity(e).name, parent, data: {}, tags: [], objects: {}, refs: {}, layer: world.layerOfEntity(e), off: [] };
    // From a prefab, with its instance's root in the clip: an instance once pasted. Without it, a plain entity.
    const p = world.prefabOf(e);
    const root = p ? at.get(world.instanceRoot(e)) : undefined;
    if (p && root !== undefined) {
      out.instance = { prefab: p.key, node: world.nodeOf(e), root };
      prefabs[p.key] ??= p.kinds.map((k) => k.name);
      prefabNames[p.key] ??= [...p.names];
    } else if (p) {
      // Inside an instance whose root is left out, but in a nested one whose root is copied: an instance of that
      // prefab, of its own kind -- what its outer prefab changed in it copied as values (Docs/prefabs.md §7).
      const nested = nestedOf(world, p, e, at);
      if (nested) {
        out.kind = nested.inner.kinds[nested.node]!.name;
        out.instance = { prefab: nested.inner.key, node: nested.node, root: nested.root };
        prefabs[nested.inner.key] ??= nested.inner.kinds.map((k) => k.name);
        prefabNames[nested.inner.key] ??= [...nested.inner.names];
      }
    }
    for (const component of componentsOn(world, e)) {
      if (!world.enabled(e, component)) out.off!.push(component.name);
      if (component.kind === 'tag') out.tags.push(component.name);
      else if (component.kind === 'data') {
        if (component.transient) continue;
        const columns = world.rawStore(component) as Columns;
        const fields: Record<string, number> = {};
        for (const field of component.fields) {
          fields[field.name] = columns[field.name]![e]!;
          if (keyKindOf(component, field.name) !== null) (out.keys ??= {})[`${component.name}.${field.name}`] = String(fieldPlain(component, field.name, columns[field.name]![e]!));
          // A ref into the clip: where it points, by place, to point at the copy.
          if (!component.schema[field.name]?.ref) continue;
          const to = world.deref(columns[field.name]![e]! as EntityRef);
          const target = at.get(to);
          if (target !== undefined) out.refs[`${component.name}.${field.name}`] = target;
          else if (to !== NONE && world.alive(to)) (out.outside ??= []).push({ what: `${component.name}.${field.name}`, to: label(world, to) });
        }
        out.data[component.name] = fields;
      } else if (isData(component)) {
        // A data component's refs as a ref field's: one into the clip by its place (`{ clip }`), to point at the copy; one
        // out of it its raw ref, kept only where `keepRefs` says (and said, as a field's).
        const value = (world.rawStore(component) as { value: unknown[] }).value[e];
        out.objects[component.name] = mapFields(component.data, component.save!(value as never), (r, path) => {
          const to = typeof r === 'number' ? world.deref(r as EntityRef) : NONE;
          if (to === NONE) return null;
          const target = at.get(to);
          if (target !== undefined) return { clip: target };
          if (world.alive(to)) (out.outside ??= []).push({ what: `${component.name}.${path}`, to: label(world, to) });
          return r;
        });
      } else if (component.kind === 'object') {
        const value = (world.rawStore(component) as { value: unknown[] }).value[e];
        if (component.save && component.load) out.objects[component.name] = component.save(value);
        else if (!component.create && plain(value)) out.objects[component.name] = value;
      }
    }
    // A root of the clip as it was in the world, whatever it hung from.
    const t = out.data[Transform.name];
    if (parent < 0 && t) {
      for (const field of ['px', 'py', 'pz', 'qx', 'qy', 'qz', 'qw', 'sx', 'sy', 'sz'] as const) t[field] = w[field][e]!;
    }
    return out;
  });

  const links: ClipLink[] = [];
  for (const relation of world.allComponents) {
    if (relation.kind !== 'relation') continue;
    order.forEach((e, source) => {
      for (const link of linksOf(world, e, relation).out) {
        const target = at.get(link.other);
        if (target !== undefined) links.push({ relation: relation.name, source, target, data: link.data });
        else (entities[source]!.outside ??= []).push({ what: relation.name, to: label(world, link.other) });
      }
    });
  }
  return { format: CLIP, version: 1, entities, links, prefabs, prefabNames };
}

/**
 * `e` (of an instance of `p` whose root is not copied) as an entity of the
 * outermost instance nested in it whose root is (`at`): that prefab, `e`'s
 * node in it, and its root's place in the clip -- or null for none.
 */
function nestedOf(world: World, p: CompiledPrefab, e: Entity, at: ReadonlyMap<Entity, number>): { inner: CompiledPrefab; node: number; root: number } | null {
  const path = p.paths[world.nodeOf(e)]!;
  const chain = p.owners[world.nodeOf(e)] ?? [];
  const inst = world.rawStore(Instance) as Record<'node' | 'next', { [i: number]: number }>;
  // Outermost first: the largest instance copied whole.
  for (let k = chain.length - 2; k >= 0; k--) {
    const owner = chain[k]!;
    const inner = compiledPrefab(owner.key);
    if (!inner || owner.at === '') continue;
    const topNode = p.paths.indexOf(owner.at);
    let top = 0;
    for (let x = world.instanceRoot(e) as number; x !== 0 && top === 0; x = inst.next[x]!) if (inst.node[x] === topNode) top = x;
    const root = at.get(top as Entity);
    if (root === undefined) continue;
    const rel = pathInOwner(owner, path);
    const node = rel === null ? -1 : inner.paths.indexOf(rel);
    if (node >= 0) return { inner, node, root };
  }
  return null;
}

export interface PasteOptions {
  /**
   * A new entity of a kind that pastes as a plain entity, drawn as the prefab
   * node of that kind is (the editor's `spawnDressed`). An instance's own
   * entities are spawned bare: the `onInstance` hooks draw them.
   */
  make(world: World, kind: Kind): Entity;
  /** Pasted into the world it was copied from: a ref out of the clip still means what it did, and is kept. */
  keepRefs: boolean;
}

export interface Pasted {
  /** Every entity made, in the clip's order. */
  all: Entity[];
  /** Those with no parent: what to select. */
  roots: Entity[];
  /** What the clip names that this build has not -- a prefab, an entity's make, a component -- each once. */
  skipped: string[];
}

/**
 * `clip` made in `world`, its roots round `at` across the ground. Queued, as
 * any edit outside a tick: flush to see them.
 */
export function pasteIn(world: World, clip: Clip, at: { x: number; z: number }, { make, keepRefs }: PasteOptions): Pasted {
  const kinds = new Map(allKinds().map((k) => [k.name, k]));
  const components = new Map(world.allComponents.map((c) => [c.name, c]));
  const skipped: string[] = [];
  const skip = (what: string): void => {
    if (!skipped.includes(what)) skipped.push(what);
  };
  const made: Entity[] = [];
  /** Names given in this paste: the world has none of them until it flushes. */
  const named = new Set<string>();
  /** Each data component's value, filled once every entity is made: its refs into the clip point at the copies. */
  const later: (() => void)[] = [];

  // The middle of the roots across the ground, to keep each one's offset from.
  const { x: cx, z: cz } = clipMiddle(clip);

  const instances = instancesIn(clip, skip);
  /** The places in the clip of every entity an instance there will have: spawned bare, drawn by the hooks. */
  const own = new Set(instances.flatMap((i) => i.members));

  for (const c of clip.entities) {
    let kind = kinds.get(c.kind);
    if (!kind) {
      // An instance's entity is said as its prefab -- gone, or what changed in it (`instancesIn`) --
      // and an entity of what this build no longer makes as an entity: never the kind's own name for it.
      if (!c.instance) skip(`entity ${c.kind}`);
      kind = Bare;
    }
    const e = own.has(made.length) ? world.spawn(kind) : make(world, kind);
    // The world is full: what came before stands.
    if (e === NONE) break;
    made.push(e);
    const has = kind.components;
    const storeOf = (component: AnyComponent): unknown => (has.includes(component) ? world.init(e, component) : world.add(e, component));

    for (const [name, fields] of Object.entries(c.data)) {
      const component = components.get(name);
      if (!component || component.kind !== 'data' || component.transient) {
        skip(`component ${name}`);
        continue;
      }
      const columns = storeOf(component) as Columns;
      for (const field of component.fields) {
        // A key by its text, interned here; the id beside it was the copying page's.
        const text = c.keys?.[`${name}.${field.name}`];
        const value = typeof text === 'string' ? fieldValue(component, field.name, text) : fields[field.name];
        if (typeof value !== 'number') continue;
        // A ref out of the clip: kept in its own world, nobody in any other. Into it: set below, once all are made.
        columns[field.name]![e] = (component as Component).schema[field.name]?.ref && !keepRefs ? NO_REF : value;
      }
      if (component === Transform && c.parent < 0) {
        columns.px![e] = at.x + (fields.px ?? 0) - cx;
        columns.pz![e] = at.z + (fields.pz ?? 0) - cz;
      }
    }
    for (const name of c.tags) {
      const component = components.get(name);
      if (!component || component.kind !== 'tag') skip(`tag ${name}`);
      else if (!has.includes(component)) world.add(e, component);
    }
    for (const [name, value] of Object.entries(c.objects)) {
      const component = components.get(name);
      if (!component || component.kind !== 'object') {
        skip(`component ${name}`);
        continue;
      }
      const slot = storeOf(component) as { value: unknown[] };
      // An entity inside an instance keeps its prefab's name -- the rider of a big crate is `rider` in every one -- or
      // each copy would differ from its prefab there; anything else is named afresh.
      if (component === Name && typeof value === 'string' && c.instance !== undefined && c.instance.root !== made.length - 1) {
        slot.value[e] = value;
      } else if (component === Name && typeof value === 'string') {
        const fresh = freshName(world, value, named);
        named.add(fresh);
        slot.value[e] = fresh;
      } else if (isData(component)) {
        // A field this build's schema has not: left out, said, as a component it has not is.
        for (const f of strayFields(component.data, value)) skip(`${name}.${f}: no such field`);
        // Once every copy is made: its refs into the clip point at them (below).
        later.push(() => fillFrom(component.data, value, slot.value[e] as Record<string, unknown>, {
          lenient: true,
          ref: (r) => (isClipRef(r) ? (made[r.clip] !== undefined ? world.ref(made[r.clip]!) : NO_REF) : typeof r === 'number' && keepRefs ? (r as EntityRef) : NO_REF),
        }));
      } else if (component.save && component.load) {
        const loaded = component.load(value, slot.value[e]);
        if (loaded !== undefined) slot.value[e] = loaded;
      } else if (!component.create) {
        slot.value[e] = value;
      }
    }
    // An instance's entity is spawned of its node's kind: what the clip says it lost -- a component its outer prefab
    // or an override took off -- taken off again.
    if (c.instance) {
      for (const component of has) {
        const kept = component.kind === 'tag' ? c.tags.includes(component.name) : component.kind === 'data' ? component.transient || component.name in c.data
          : component.kind === 'object' ? !(component.save && component.load) || component.name in c.objects : true;
        if (!kept && component !== Name) world.remove(e, component);
      }
    }
    // Commands, as the adds above are: so after them, onto what they put there.
    if (c.layer) world.setLayer(e, c.layer);
    for (const name of c.off ?? []) {
      const component = components.get(name);
      if (component && component.kind !== 'relation') world.enable(e, component, false);
    }
  }

  // Now that each copy is there to point at: the data components' refs, the tree, the refs into the clip, the links.
  for (const fill of later) fill();
  clip.entities.forEach((c, i) => {
    const e = made[i];
    if (e === undefined) return;
    const parent = c.parent >= 0 ? made[c.parent] : undefined;
    if (parent !== undefined) world.setParent(e, parent);
    for (const [key, place] of Object.entries(c.refs)) {
      const [name, field] = key.split('.');
      const component = components.get(name!);
      const target = made[place];
      if (component?.kind !== 'data' || target === undefined || !component.schema[field!]?.ref) continue;
      (world.rawStore(component) as Columns)[field!]![e] = world.ref(target);
    }
  });
  for (const link of clip.links) {
    const relation = components.get(link.relation);
    const source = made[link.source];
    const target = made[link.target];
    if (!relation || relation.kind !== 'relation') {
      skip(`relation ${link.relation}`);
      continue;
    }
    if (source === undefined || target === undefined) continue;
    const p = world.relate(source, relation, target);
    const columns = world.rawStore(relation) as Columns;
    if (p !== 0) for (const field of relation.fields) if (typeof link.data[field.name] === 'number') columns[field.name]![p] = link.data[field.name]!;
  }
  // Each instance whose root was made, an instance again: its rows written, its hooks at the boundary.
  for (const { prefab, members, nodes } of instances) {
    const kept = members.flatMap((j, m) => (made[j] === undefined ? [] : [m]));
    if (kept.length === 0) continue;
    restoreInstance(world, prefab, kept.map((m) => made[members[m]!]!), kept.map((m) => nodes[m]!));
  }
  return { all: made, roots: made.filter((_, i) => clip.entities[i]!.parent < 0), skipped };
}

/**
 * Entities spawned one by one since the last boundary made an instance of
 * `prefab` again. `entities` in node order, the root first; `nodes[i]` the node
 * `entities[i]` is. Their `Instance` rows are written now, chained as
 * `instantiate` chains them, so `part` and `prefabOf` work at once; at the
 * boundary the `onInstance` hooks run for the root (`world.announceInstance`),
 * so its views come the one way every instance's do. The editor's alone: a
 * release never writes an instance back.
 */
export function restoreInstance(world: World, prefab: CompiledPrefab, entities: readonly Entity[], nodes: readonly number[]): void {
  const root = entities[0];
  if (root === undefined || nodes[0] !== 0 || nodes.length !== entities.length) throw new Error(`[editor] restoreInstance(${prefab.key}): the entities and their nodes, the root first at node 0`);
  const inst = world.rawStore(Instance) as Record<'prefab' | 'node' | 'root' | 'next', number[]>;
  for (let i = 0; i < entities.length; i++) {
    const e = entities[i]!;
    if (world.alive(e)) throw new Error(`[editor] restoreInstance(${prefab.key}): entity ${e} was not spawned since the last boundary`);
    inst.prefab[e] = prefab.id;
    inst.node[e] = nodes[i]!;
    inst.root[e] = root;
    inst.next[e] = entities[i + 1] ?? 0;
  }
  world.announceInstance(root);
}

/**
 * Each instance in the clip of a prefab this build has: the prefab, the places
 * of its entities in node order, the root first, and the node each is now.
 * The one rule `world.load` follows (`refindNodes`, Docs/prefabs.md §6): each
 * entity is the node of its kind's name in the prefab as compiled now, wherever
 * that node is; one the prefab no longer has pastes plain, where the copy had
 * it, and a node added since is not made. What changed is said in `skip`, once
 * per prefab, as a prefab gone is.
 */
function instancesIn(clip: Clip, skip: (what: string) => void): { prefab: CompiledPrefab; members: number[]; nodes: number[] }[] {
  const node = new Array<number>(clip.entities.length).fill(-1);
  const ofPrefab = new Map<string, number[]>();
  clip.entities.forEach((c, i) => {
    if (!c.instance) return;
    const list = ofPrefab.get(c.instance.prefab) ?? [];
    list.push(i);
    ofPrefab.set(c.instance.prefab, list);
  });
  for (const [key, list] of ofPrefab) {
    const p = compiledPrefab(key);
    if (!p) {
      skip(`prefab ${key}`);
      continue;
    }
    const kinds = clip.prefabs?.[key];
    const then = kinds ? { kinds, names: clip.prefabNames?.[key] } : undefined;
    refindNodes(p, list.map((i) => clip.entities[i]!.kind), then, skip).forEach((n, j) => (node[list[j]!] = n));
  }
  const out: { prefab: CompiledPrefab; members: number[]; nodes: number[] }[] = [];
  clip.entities.forEach((c, i) => {
    const own = c.instance;
    if (!own || own.root !== i || node[i] !== 0) return;
    const p = compiledPrefab(own.prefab)!;
    // The root first, then by node; a node twice (a clip written by hand), the second plain.
    const all = clip.entities.flatMap((m, j) => (j !== i && m.instance?.root === i && m.instance.prefab === own.prefab && node[j]! > 0 ? [j] : []));
    all.sort((a, b) => node[a]! - node[b]!);
    const members = [i];
    for (const j of all) if (node[j] !== node[members[members.length - 1]!]) members.push(j);
    out.push({ prefab: p, members, nodes: members.map((j) => node[j]!) });
  });
  return out;
}

/** Text off the clipboard as a clip; or, if it is not one this build reads, why not. */
export function readClip(text: string): Clip | string {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return 'the clipboard holds no entities: what is on it is not JSON';
  }
  const clip = data as Partial<Clip> | null;
  if (typeof clip !== 'object' || clip === null || clip.format !== CLIP) return 'the clipboard holds no entities copied in the editor';
  if (clip.version !== 1) return `the entities on the clipboard are of version ${String(clip.version)}, and this build reads version 1`;
  const object = (v: unknown): boolean => typeof v === 'object' && v !== null && !Array.isArray(v);
  const within = (n: unknown, length: number): boolean => Number.isInteger(n) && (n as number) >= 0 && (n as number) < length;
  const entities = Array.isArray(clip.entities) ? clip.entities : null;
  const shaped =
    entities !== null && entities.length > 0 && Array.isArray(clip.links) &&
    entities.every((c, i) =>
      object(c) && typeof c.kind === 'string' && Number.isInteger(c.parent) && c.parent >= -1 && c.parent < i &&
      object(c.data) && Array.isArray(c.tags) && object(c.objects) && object(c.refs) &&
      (c.layer === undefined || within(c.layer, 32)) && (c.off === undefined || (Array.isArray(c.off) && c.off.every((n) => typeof n === 'string'))) &&
      (c.instance === undefined || (object(c.instance) && typeof c.instance.prefab === 'string' && within(c.instance.node, 0x10000) && within(c.instance.root, i + 1)))) &&
    clip.links.every((l) =>
      object(l) && typeof l.relation === 'string' && within(l.source, entities.length) && within(l.target, entities.length) && object(l.data)) &&
    (clip.prefabs === undefined || (object(clip.prefabs) && Object.values(clip.prefabs).every((k) => Array.isArray(k) && k.every((n) => typeof n === 'string')))) &&
    (clip.from === undefined || typeof clip.from === 'string') &&
    (clip.prefabNames === undefined || (object(clip.prefabNames) && Object.values(clip.prefabNames).every((k) => Array.isArray(k) && k.every((n) => n === null || typeof n === 'string'))));
  return shaped ? (clip as Clip) : 'the entities on the clipboard are not whole';
}
