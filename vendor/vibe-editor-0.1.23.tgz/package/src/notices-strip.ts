/**
 * The notices drawn (`notices.ts`, Docs/studio.md §1 "Recovery"): a strip under the top bar, right of the tool
 * strip (`.ed-notices`, `shell.css`) -- a row each, its words (whole on hover, the error's stack under them) and
 * Dismiss; Reload on the strip while a `boot` notice is up (the page in recovery), which has no Dismiss of its own:
 * the game is still the stand-in, and Reload is the way out. Hidden with none. The boot notice's row has a second
 * line for what Claude's try is doing (`fixLine`, `recovery-fix.ts`): "Claude is fixing it (try 1 of 3)" with Stop, or
 * how it ended.
 */
import { button, el } from './dom.ts';
import type { Notices } from './notices.ts';
import { NOT_FOR_CLAUDE } from './mcp/gaps.ts';

/** The boot notice's line under its words: Claude's try (`recovery-fix.ts`), Stop while it runs. */
export interface FixLine {
  text: string;
  stop?: () => void;
}

export interface NoticesStrip {
  readonly root: HTMLElement;
  /** The boot notice's line of Claude's try; null, none. */
  fixLine(line: FixLine | null): void;
  dispose(): void;
}

export function createNoticesStrip(notices: Notices, reload: () => void): NoticesStrip {
  const root = el('div', 'ed-notices');
  root.hidden = true;
  let fix: FixLine | null = null;
  const draw = (): void => {
    const list = notices.list;
    root.hidden = list.length === 0;
    const rows = list.map((n) => {
      const row = el('div', `ed-notice ed-notice-${n.kind}`);
      const words = el('span', 'ed-notice-text', n.text);
      const stack = n.stack ? `\n\n${n.stack}` : n.error instanceof Error && n.error.stack ? `\n\n${n.error.stack}` : '';
      words.title = `${n.text}${stack}`;
      if (n.kind === 'boot' && fix) {
        const said = el('div', 'ed-notice-fix', fix.text);
        if (fix.stop) said.append(button(NOT_FOR_CLAUDE.claudeControl, 'Stop', 'Stop Claude\'s try: the turn stopped, as the Claude card\'s Stop does, and no further try until the game boots', fix.stop, 'ed-small ed-quiet'));
        const both = el('div', 'ed-notice-body');
        both.append(words, said);
        row.append(both);
      } else row.append(words);
      for (const action of n.actions ?? []) row.append(button(action.mcp, action.label, action.title, action.run, 'ed-small'));
      if (n.kind !== 'boot') row.append(button('ui', 'Dismiss', 'Put this notice away', () => notices.dismiss(n.id), 'ed-small ed-quiet'));
      return row;
    });
    const ends: HTMLElement[] = [];
    if (notices.has('boot')) ends.push(button('ui', 'Reload', 'Reload the page: the game booted again, from the files as they are now', reload, 'ed-small'));
    if (list.filter((n) => n.kind !== 'boot').length > 1) ends.push(button('ui', 'Dismiss all', 'Put every notice away', () => notices.dismissAll(), 'ed-small ed-quiet'));
    const bar = el('div', 'ed-notices-end');
    bar.append(...ends);
    root.replaceChildren(...rows, ...(ends.length > 0 ? [bar] : []));
  };
  const off = notices.on(draw);
  draw();
  return {
    root,
    fixLine(line) {
      fix = line;
      draw();
    },
    dispose() {
      off();
      root.remove();
    },
  };
}
