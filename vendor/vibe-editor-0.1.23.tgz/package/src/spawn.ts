/**
 * The entities the editor makes: an instance of any prefab, an Empty, an
 * entity drawn as a model, and a copy of one there is.
 *
 * - **Made as the game makes them**, from the prefabs (Docs/prefabs.md §7):
 *   `world.instantiate`, drawn by the engine's `render` system from each
 *   entity's `Render` -- and so is a pasted or duplicated instance, which the
 *   clip writes back with `restoreInstance`, and a plain copy of one entity of
 *   an instance (Duplicate on a crate's rider, a partial paste), whose `Render`
 *   is copied with the rest of its data.
 *   Nothing of `src/game/` is the editor's.
 * - **What the person sees is the prefab**: its key in the tree's Create menu
 *   and the undo step, every entity of it placed as its file places them. The
 *   kind the ECS groups an entity by is never shown.
 *
 * Called with the game paused; the caller flushes.
 */
import { type AnyComponent, compiledPrefab, type CompiledPrefab, componentsOn, type Entity, Hierarchy, internKey, type Kind, label, linksOf, Name, NONE, type PrefabToken, type Relation, Render, Transform, View, type World, WorldTransform } from '@vibe/engine';
import { copyOut, freshName, pasteIn } from './clip.ts';

/** A column as this file writes it: any numeric store's field. */
type Columns = Record<string, { [i: number]: number }>;


/**
 * What the editor makes: a prefab, `EMPTY` -- a bare entity with a `Transform`, for code to fill in -- or a model's
 * entity (`modelSpawn`), what a model dragged from the Assets panel places.
 */
export type Spawnable = PrefabToken | typeof EMPTY | ModelSpawn;
export const EMPTY = 'Empty';

/** An entity drawn as the model `model` (a key): a `Transform`, `Render { model }`, a `Name` its file's stem. */
export interface ModelSpawn {
  readonly model: string;
}

/** The entity a model's key makes, as a `Spawnable`. */
export const modelSpawn = (key: string): ModelSpawn => ({ model: key });

const isModel = (what: Spawnable): what is ModelSpawn => typeof what === 'object' && 'model' in what;

/** What the person is told one is: the prefab's key, the model's, or Empty. */
export const spawnLabel = (what: Spawnable): string => (what === EMPTY ? EMPTY : isModel(what) ? what.model : what.key);

/** The compiled prefab a token names. Throws for one the compile has not: the Create menu lists only compiled ones. */
const compiledOf = (token: PrefabToken): CompiledPrefab => {
  const p = compiledPrefab(token.key);
  if (!p) throw new Error(`[editor] ${token.key}: no such prefab was compiled`);
  return p;
};

/**
 * One of `what` at `at` in the world (it has no parent), named afresh for the
 * tree: a prefab's whole instance, nested ones in it, its root at the point and
 * named as the file names it -- `big crate`, then `big crate 2` -- an Empty, or
 * a model's entity, `Render { model }` -- drawn by the engine's `render` system
 * at the boundary -- named for its file (`crate`, then `crate 2`; a pack's
 * `reef:props/crate` too). NONE if the world is full.
 */
export function spawnAt(world: World, what: Spawnable, at: { x: number; y: number; z: number }): Entity {
  if (isModel(what)) {
    const e = spawnAt(world, EMPTY, at);
    if (e === NONE) return NONE;
    world.add(e, Render).model[e] = internKey('Model', what.model);
    world.store(Name).value[e] = freshName(world, what.model.slice(what.model.lastIndexOf('/') + 1).replace(/^[^:]*:/, ''));
    return e;
  }
  const p = what === EMPTY ? null : compiledOf(what);
  const e = what === EMPTY ? world.spawn() : world.instantiate(what);
  if (e === NONE) return NONE;
  const comes = (component: AnyComponent): boolean => p !== null && p.kinds[0]!.components.includes(component);
  if (!p || comes(Transform)) {
    const t = comes(Transform) ? world.init(e, Transform) : world.add(e, Transform);
    t.px[e] = at.x;
    t.py[e] = at.y;
    t.pz[e] = at.z;
  }
  const name = comes(Name) ? world.init(e, Name) : world.add(e, Name);
  name.value[e] = freshName(world, p ? (p.names[0] ?? p.key.slice(p.key.lastIndexOf('/') + 1)) : 'entity');
  return e;
}

/** A new entity of `kind`: how a paste makes each plain entity (`clip.ts`). Its `Render`, filled in by the paste, draws it. */
export function spawnDressed(world: World, kind: Kind): Entity {
  return world.spawn(kind);
}

/**
 * A copy of `e`, where it is. An instance's root goes whole, an instance again
 * (`duplicateInstance`). Anything else: its kind, every numeric component's values, its
 * tags -- `Hidden` and `Disabled` with them -- its plain object components and
 * labels, its layer, which of its components are switched off, its parent,
 * and its links out -- what it points at. Not its children, and not the links
 * into it: those are the other entities' to make. Its own model, if the
 * original has one. NONE if the world is full.
 */
export function duplicate(world: World, e: Entity): Entity {
  if (world.instanceRoot(e) === e) return duplicateInstance(world, e);
  const kind = world.kindOfEntity(e);
  const copy = world.spawn(kind);
  if (copy === NONE) return NONE;
  // A component the kind brings is already on the copy, at its defaults: filled
  // in. Any other is added first.
  const storeOn = (component: AnyComponent): unknown => (kind.components.includes(component) ? world.init(copy, component) : world.add(copy, component));

  for (const component of componentsOn(world, e)) {
    // Worked out by the world (`WorldTransform`, anything transient), the copy's own, or named below.
    if (component === View || component === Name || component.kind === 'relation') continue;
    if (component.kind === 'data' && component.transient) continue;
    if (component.kind === 'tag') {
      if (!kind.components.includes(component)) world.add(copy, component);
    } else if (component.kind === 'data') {
      const from = world.rawStore(component) as Columns;
      const to = storeOn(component) as Columns;
      for (const field of component.fields) to[field.name]![copy] = from[field.name]![e]!;
    } else {
      // An object: through its own save and load, else as it is if it is plain
      // data; a pooled object that cannot be copied stays at its defaults.
      const value = (world.rawStore(component) as { value: unknown[] }).value[e];
      const to = storeOn(component) as { value: unknown[] };
      if (component.save && component.load) {
        const loaded = component.load(component.save(value), to.value[copy]);
        if (loaded !== undefined) to.value[copy] = loaded;
      } else if (!component.create && (value === null || ['string', 'number', 'boolean'].includes(typeof value))) {
        to.value[copy] = value;
      }
    }
  }

  linkLikeIt(world, e, copy, () => true);
  const parent = world.store(Hierarchy).parent[e]! as Entity;
  if (parent !== NONE) world.setParent(copy, parent);
  // Its layer, and what is switched off on it: commands, so after what they act on.
  world.setLayer(copy, world.layerOfEntity(e));
  for (const component of componentsOn(world, e)) if (!world.enabled(e, component)) world.enable(copy, component, false);
  // Named after the original; one with no name of its own after its prefab, not its id.
  const name = storeOn(Name) as { value: unknown[] };
  name.value[copy] = freshName(world, label(world, e));
  return copy;
}

/** `copy` linked out to what `e` is linked out to, of those `to` takes: each link with its data. */
function linkLikeIt(world: World, e: Entity, copy: Entity, to: (other: Entity) => boolean): void {
  for (const relation of world.allComponents) {
    if (relation.kind !== 'relation') continue;
    const rows = world.store(relation as Relation<any>) as unknown as Columns;
    for (const link of linksOf(world, e, relation).out) {
      if (!to(link.other)) continue;
      const p = world.relate(copy, relation, link.other);
      if (p !== 0) for (const [field, value] of Object.entries(link.data)) rows[field]![p] = value;
    }
  }
}

/**
 * An instance's root duplicated: the whole instance and everything else under
 * it, an instance again -- through a clip (`clip.ts`), which keeps the link to
 * the prefab and points refs inside it at the copy's own -- where it is, under
 * the same parent, with the root's links out of it. NONE if the world is full.
 */
function duplicateInstance(world: World, e: Entity): Entity {
  const clip = copyOut(world, [e]);
  // The clip's root holds its pose in the world: pasted round that, it lands where it is.
  const w = world.store(WorldTransform);
  const done = pasteIn(world, clip, { x: w.px[e]!, z: w.pz[e]! }, { make: spawnDressed, keepRefs: true });
  const copy = done.roots[0] ?? NONE;
  if (copy === NONE) return NONE;
  const tree = world.store(Hierarchy);
  const parent = tree.parent[e]! as Entity;
  if (parent !== NONE) {
    // Under the same parent, at its own pose there rather than the world's.
    world.setParent(copy, parent);
    if (world.has(e, Transform)) {
      const t = world.store(Transform) as unknown as Columns;
      for (const field of Transform.fields) t[field.name]![copy] = t[field.name]![e]!;
    }
  }
  // Links out to what was not copied with it: those inside were made by the paste.
  const inside = (other: Entity): boolean => {
    for (let a = other; a !== NONE; a = tree.parent[a]! as Entity) if (a === e) return true;
    return false;
  };
  linkLikeIt(world, e, copy, (other) => !inside(other));
  return copy;
}
