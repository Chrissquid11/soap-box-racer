/**
 * The inspector's physics items (Docs/physics.md §7), on its list of blocks (`blocks.ts`) right under each component's
 * own fields -- every physics component is shown by the generic blocks, through the property kinds (a layer is a
 * dropdown of the project's names, a body's type an enum, a joint's other body a typed ref); these add:
 *
 * - **Fit to model** under each collider it takes (a box, sphere, capsule, cylinder, cone, hull or mesh): sized from
 *   the model the entity draws, for every one selected, one step (`physics_fit` does the same).
 * - **A body's state** under `RigidBody` while it moves: awake or asleep, and its speed -- read four times a second
 *   while the block is on the page.
 */
import { type AnyComponent, COLLIDERS, type Entity, RigidBody } from '@vibe/engine';
import { BLOCK_ORDER, type BlockItem } from '../blocks.ts';
import { button, el } from '../shell.ts';
import { shown } from '../fields.ts';
import { FITTABLE } from './fit.ts';
import { applyFit } from './fit-apply.ts';
import { modelBounds } from './model-bounds.ts';

/** The items: one Fit row for each collider Fit takes, and the body's state. */
export function physicsBlocks(): BlockItem[] {
  const fittable = COLLIDERS.filter((c) => (FITTABLE as readonly string[]).includes(c.name)) as readonly AnyComponent[];
  const fits: BlockItem[] = fittable.map((C) => ({
    id: `physics-fit:${C.name}`,
    for: C,
    order: BLOCK_ORDER.components,
    make(blocks, es) {
      const line = el('div', 'ed-physics-fit');
      const hull = C.name === 'HullCollider' || C.name === 'MeshCollider';
      const said = el('span', 'ed-dim');
      const fit = button('physics_fit', 'Fit to model', hull
        ? `The model its Render draws, as it is: mesh none, centred, unturned${es.length > 1 ? ` -- all ${es.length}` : ''}`
        : `Sized to the model its Render draws, in its own space: ${C.name.replace('Collider', '').toLowerCase()} round its bounds, centred on them${es.length > 1 ? ` -- all ${es.length}` : ''}`, () => {
        const why: string[] = [];
        let done = 0;
        for (const e of es) {
          const r = applyFit(blocks.world, e, C.name, modelBounds(blocks.world, e as Entity));
          if ('error' in r) why.push(r.error);
          else if (r.changed) done++;
        }
        if (done > 0) blocks.host.changed(`Fit ${C.name} to its model${done > 1 ? ` × ${done}` : ''}`);
        said.textContent = why.length > 0 ? why[0]! : done === 0 ? 'It fits already' : '';
      }, 'ed-small');
      line.append(fit, said);
      return line;
    },
  }));
  const body: BlockItem = {
    id: 'physics-body-state',
    for: RigidBody,
    order: BLOCK_ORDER.components,
    make(blocks, es) {
      const line = el('div', 'ed-physics-state ed-dim');
      const e = es[0]!;
      const read = (): void => {
        if (!blocks.world.alive(e) || !blocks.world.has(e, RigidBody)) return;
        const rb = blocks.world.store(RigidBody);
        const speed = Math.hypot(rb.velocityX[e]!, rb.velocityY[e]!, rb.velocityZ[e]!);
        const spin = Math.hypot(rb.angularVelocityX[e]!, rb.angularVelocityY[e]!, rb.angularVelocityZ[e]!);
        line.textContent = es.length > 1 ? `${es.length} bodies` : `${rb.sleeping[e] === 1 ? 'Asleep' : 'Awake'} · ${shown(speed, 2)} m/s · ${shown(spin, 2)} rad/s`;
        line.title = 'What the physics wrote of it after the last step: asleep or awake, its speed and its spin -- live while it runs';
      };
      read();
      const timer = setInterval(() => {
        if (!line.isConnected) return void clearInterval(timer);
        read();
      }, 250);
      return line;
    },
  };
  return [...fits, body];
}
