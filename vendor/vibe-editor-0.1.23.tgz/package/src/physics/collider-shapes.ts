/**
 * A collider's wireframe as line segments (Docs/physics.md §7), from its component's numbers -- never from Bullet, so
 * it is right while stopped and with physics off: in the entity's turned frame (its world rotation and position are
 * the overlay's to put on), its world scale applied as the stage applies it (D11) -- a box, a hull or a mesh exactly
 * per axis, a sphere by the largest axis, a capsule, cylinder or cone by the larger of the two across it for the radius
 * and the one along it for the length; `center` scaled per axis, `turn` (degrees, three's XYZ) about it.
 *
 * Primitives are drawn analytically; a hull or a mesh as the box of its model's bounds (`bounds`, the editor's from
 * the model drawn), a height field as the box its heights fill, a plane as a square of it round the entity with its
 * normal.
 *
 * Pure: node tests it (`collider-shapes.test.ts`). Each segment is six numbers, from and to.
 */

/** A circle's segments: enough that a metre-wide one reads round. */
const ROUND = 24;
/** A plane's square, metres across: a ground has no edge, so a patch of it round the entity. */
const PLANE_SIZE = 10;

export interface ShapeAsk {
  /** The component's name: `BoxCollider` … `HeightfieldCollider`. */
  kind: string;
  /** Its numbers by field name (`sizeX`, `radius`, `axis`: ShapeAxis' number, y 0, x 1, z 2; `centerX`, `turnY` …). */
  fields: Readonly<Record<string, number>>;
  /** The entity's world scale. */
  scale: readonly [number, number, number];
  /** A hull's or a mesh's model bounds in the entity's space, unscaled; null where not known (no model loaded): a small box. */
  bounds?: { min: readonly [number, number, number]; max: readonly [number, number, number] } | null;
}

/** `(x, y, z)` turned by the XYZ Euler of `(ax, ay, az)` degrees. */
function turner(ax: number, ay: number, az: number): (x: number, y: number, z: number) => [number, number, number] {
  const r = Math.PI / 180;
  const cx = Math.cos(ax * r), sx = Math.sin(ax * r), cy = Math.cos(ay * r), sy = Math.sin(ay * r), cz = Math.cos(az * r), sz = Math.sin(az * r);
  // three's 'XYZ': R = Rx · Ry · Rz.
  const m = [
    cy * cz, -cy * sz, sy,
    cx * sz + sx * sy * cz, cx * cz - sx * sy * sz, -sx * cy,
    sx * sz - cx * sy * cz, sx * cz + cx * sy * sz, cx * cy,
  ];
  return (x, y, z) => [m[0]! * x + m[1]! * y + m[2]! * z, m[3]! * x + m[4]! * y + m[5]! * z, m[6]! * x + m[7]! * y + m[8]! * z];
}

/** Segments of a box from `lo` to `hi`, its twelve edges. */
function boxEdges(lo: readonly number[], hi: readonly number[], out: number[]): void {
  const c = (i: number): [number, number, number] => [i & 1 ? hi[0]! : lo[0]!, i & 2 ? hi[1]! : lo[1]!, i & 4 ? hi[2]! : lo[2]!];
  const EDGES = [0, 1, 2, 3, 4, 5, 6, 7, 0, 2, 1, 3, 4, 6, 5, 7, 0, 4, 1, 5, 2, 6, 3, 7];
  for (let i = 0; i < EDGES.length; i += 2) out.push(...c(EDGES[i]!), ...c(EDGES[i + 1]!));
}

/** A circle of radius `r` about the axis `along` (0 x, 1 y, 2 z) at `at` along it, from angle `from` for `span` radians. */
function circle(r: number, along: number, at: number, out: number[], from = 0, span = Math.PI * 2): void {
  const steps = Math.max(4, Math.round((ROUND * span) / (Math.PI * 2)));
  const point = (a: number): [number, number, number] => {
    const u = Math.cos(a) * r, v = Math.sin(a) * r;
    return along === 0 ? [at, u, v] : along === 1 ? [u, at, v] : [u, v, at];
  };
  for (let i = 0; i < steps; i++) out.push(...point(from + (span * i) / steps), ...point(from + (span * (i + 1)) / steps));
}

/** A point `a` along the axis and `(u, v)` across it, as x, y, z. */
const place = (along: number, a: number, u: number, v: number): [number, number, number] => (along === 0 ? [a, u, v] : along === 1 ? [u, a, v] : [u, v, a]);

/** The axis number of ShapeAxis (y 0, x 1, z 2) as x 0, y 1, z 2. */
const axisOf = (n: number): number => (n === 1 ? 0 : n === 2 ? 2 : 1);

/** `ask`'s wireframe: segments, six numbers each, in the entity's turned frame. Empty for a kind it does not know. */
export function colliderSegments(ask: ShapeAsk): Float32Array {
  const f = ask.fields;
  const [sx, sy, sz] = ask.scale.map(Math.abs) as [number, number, number];
  const local: number[] = [];
  let exact = false;
  const along = axisOf(f.axis ?? 0);
  const acrossScale = along === 0 ? Math.max(sy, sz) : along === 1 ? Math.max(sx, sz) : Math.max(sx, sy);
  const alongScale = along === 0 ? sx : along === 1 ? sy : sz;
  switch (ask.kind) {
    case 'BoxCollider': {
      const h = [(f.sizeX ?? 1) / 2, (f.sizeY ?? 1) / 2, (f.sizeZ ?? 1) / 2];
      boxEdges(h.map((n) => -n), h, local);
      exact = true;
      break;
    }
    case 'SphereCollider': {
      const r = (f.radius ?? 0.5) * Math.max(sx, sy, sz);
      for (let a = 0; a < 3; a++) circle(r, a, 0, local);
      break;
    }
    case 'CapsuleCollider': {
      const r = (f.radius ?? 0.5) * acrossScale;
      const half = Math.max((f.height ?? 2) * alongScale, 2 * r) / 2 - r;
      circle(r, along, half, local);
      circle(r, along, -half, local);
      for (const [u, v] of [[r, 0], [-r, 0], [0, r], [0, -r]] as const) local.push(...place(along, -half, u, v), ...place(along, half, u, v));
      // The two half spheres, in the two planes through the axis.
      for (const end of [1, -1]) {
        const arc = (u: number, v: number): void => {
          const steps = ROUND / 2;
          for (let i = 0; i < steps; i++) {
            const a0 = (Math.PI * i) / steps, a1 = (Math.PI * (i + 1)) / steps;
            local.push(...place(along, end * (half + Math.sin(a0) * r), Math.cos(a0) * r * u, Math.cos(a0) * r * v), ...place(along, end * (half + Math.sin(a1) * r), Math.cos(a1) * r * u, Math.cos(a1) * r * v));
          }
        };
        arc(1, 0);
        arc(0, 1);
      }
      break;
    }
    case 'CylinderCollider': {
      const r = (f.radius ?? 0.5) * acrossScale;
      const half = ((f.height ?? 1) * alongScale) / 2;
      circle(r, along, half, local);
      circle(r, along, -half, local);
      for (const [u, v] of [[r, 0], [-r, 0], [0, r], [0, -r]] as const) local.push(...place(along, -half, u, v), ...place(along, half, u, v));
      break;
    }
    case 'ConeCollider': {
      const r = (f.radius ?? 0.5) * acrossScale;
      const half = ((f.height ?? 1) * alongScale) / 2;
      circle(r, along, -half, local);
      for (const [u, v] of [[r, 0], [-r, 0], [0, r], [0, -r]] as const) local.push(...place(along, -half, u, v), ...place(along, half, 0, 0));
      break;
    }
    case 'HullCollider':
    case 'MeshCollider': {
      const b = ask.bounds ?? { min: [-0.25, -0.25, -0.25], max: [0.25, 0.25, 0.25] };
      boxEdges(b.min, b.max, local);
      exact = true;
      break;
    }
    case 'HeightfieldCollider': {
      const w = (f.sizeX ?? 10) / 2, d = (f.sizeY ?? 10) / 2;
      boxEdges([-w, 0, -d], [w, f.heightScale ?? 1, d], local);
      exact = true;
      break;
    }
    case 'PlaneCollider': {
      // Its normal (in the entity's space), a square across it at `offset`, and a stroke a metre out along it.
      let nx = f.normalX ?? 0, ny = f.normalY ?? 1, nz = f.normalZ ?? 0;
      const l = Math.hypot(nx, ny, nz) || 1;
      nx /= l; ny /= l; nz /= l;
      // Two directions across it.
      const ux0 = Math.abs(ny) < 0.9 ? 0 : 1, uy0 = Math.abs(ny) < 0.9 ? 1 : 0;
      let ux = uy0 * nz - 0 * ny, uy = 0 * nx - ux0 * nz, uz = ux0 * ny - uy0 * nx;
      const ul = Math.hypot(ux, uy, uz) || 1;
      ux /= ul; uy /= ul; uz /= ul;
      const vx = ny * uz - nz * uy, vy = nz * ux - nx * uz, vz = nx * uy - ny * ux;
      const o = f.offset ?? 0;
      const half = PLANE_SIZE / 2;
      const at = (a: number, b: number): [number, number, number] => [nx * o + ux * a + vx * b, ny * o + uy * a + vy * b, nz * o + uz * a + vz * b];
      for (let i = -half; i <= half; i += 1) {
        local.push(...at(i, -half), ...at(i, half));
        local.push(...at(-half, i), ...at(half, i));
      }
      local.push(...at(0, 0), nx * (o + 1), ny * (o + 1), nz * (o + 1));
      return new Float32Array(local);
    }
    default:
      return new Float32Array(0);
  }
  // Turned about its centre, then the centre (and an exact shape's every point) scaled per axis.
  const turn = turner(f.turnX ?? 0, f.turnY ?? 0, f.turnZ ?? 0);
  const cx = f.centerX ?? 0, cy = f.centerY ?? 0, cz = f.centerZ ?? 0;
  const out = new Float32Array(local.length);
  for (let i = 0; i < local.length; i += 3) {
    const [x, y, z] = turn(local[i]!, local[i + 1]!, local[i + 2]!);
    out[i] = exact ? (cx + x) * sx : cx * sx + x;
    out[i + 1] = exact ? (cy + y) * sy : cy * sy + y;
    out[i + 2] = exact ? (cz + z) * sz : cz * sz + z;
  }
  return out;
}
