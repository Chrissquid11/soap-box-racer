/**
 * Fit to model written (Docs/physics.md §7): `fitCollider`'s numbers into an entity's collider -- the inspector's
 * Fit button and `physics_fit` alike. The caller makes the step. No DOM: node tests it with the page tools.
 */
import { type AnyComponent, type Entity, type World } from '@vibe/engine';
import { FITTABLE, fitCollider, type Bounds, type Fitted } from './fit.ts';

/** The fittable colliders `e` has, by name, in `FITTABLE`'s order. */
export function fittableOn(world: World, e: Entity): string[] {
  return FITTABLE.filter((name) => {
    const c = world.allComponents.find((x) => x.name === name);
    return c !== undefined && world.has(e, c);
  });
}

/**
 * `collider` (a name; none: the one fittable collider `e` has) fitted to `bounds` and written: the fields set, or why
 * not -- no such collider, several to choose from, a plane or height field, no model bounds.
 */
export function applyFit(world: World, e: Entity, collider: string | null, bounds: Bounds | null): { collider: string; set: Fitted; changed: boolean } | { error: string } {
  const on = fittableOn(world, e);
  const name = collider ?? (on.length === 1 ? on[0]! : null);
  if (name === null) return { error: on.length === 0 ? 'it has no collider Fit takes (a box, sphere, capsule, cylinder, cone, hull or mesh)' : `it has ${on.join(', ')}: say which (collider)` };
  if (!on.includes(name)) return { error: (FITTABLE as readonly string[]).includes(name) ? `it has no ${name}` : `${name} is no collider Fit takes: ${FITTABLE.join(', ')}` };
  if (bounds === null && name !== 'HullCollider' && name !== 'MeshCollider') return { error: 'it draws no model to fit to: give it a Render.model first' };
  const set = fitCollider(name, bounds ?? { min: [0, 0, 0], max: [0, 0, 0] });
  if (set === null) return { error: `nothing to fit: its model has no size` };
  const component = world.allComponents.find((x) => x.name === name)! as AnyComponent;
  const store = world.store(component as never) as unknown as Record<string, { [i: number]: number } | undefined>;
  let changed = false;
  for (const [field, value] of Object.entries(set)) {
    const column = store[field];
    if (column === undefined) continue;
    if (Math.fround(value) !== column[e]) changed = true;
    column[e] = value;
  }
  return { collider: name, set, changed };
}
