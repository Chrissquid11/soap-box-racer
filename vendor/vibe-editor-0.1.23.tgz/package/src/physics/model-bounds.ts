/**
 * A model's bounds in its entity's own space, before the entity's scale (Docs/physics.md §7): what Fit to model sizes
 * a collider from, and what a hull's or a mesh's outline is drawn as -- from the view the engine attached for its
 * `Render` (`View`), every mesh under it brought into the view's frame. Null where nothing is drawn.
 */
import * as THREE from 'three';
import { type Entity, View, type World } from '@vibe/engine';
import type { Bounds } from './fit.ts';

const inverse = new THREE.Matrix4();
const into = new THREE.Matrix4();
const box = new THREE.Box3();
const all = new THREE.Box3();

/** `e`'s view's meshes, bounded in the view's own frame (its scale taken out); null with no view or no mesh. */
export function modelBounds(world: World, e: Entity): Bounds | null {
  if (!world.alive(e) || !world.has(e, View)) return null;
  const view = world.store(View).value[e] as THREE.Object3D | null | undefined;
  if (!view) return null;
  view.updateMatrixWorld(true);
  inverse.copy(view.matrixWorld).invert();
  all.makeEmpty();
  view.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh || !mesh.geometry) return;
    if (!mesh.geometry.boundingBox) mesh.geometry.computeBoundingBox();
    const b = mesh.geometry.boundingBox;
    if (!b || b.isEmpty()) return;
    into.multiplyMatrices(inverse, mesh.matrixWorld);
    all.union(box.copy(b).applyMatrix4(into));
  });
  if (all.isEmpty()) return null;
  return { min: [all.min.x, all.min.y, all.min.z], max: [all.max.x, all.max.y, all.max.z] };
}
