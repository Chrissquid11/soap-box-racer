/**
 * A physics material edited in the Assets panel's inspector (Docs/physics.md §7): a `.physmat` chosen shows its
 * friction, rolling friction and bounce as fields, and the two combine modes -- how two colliders' values meet, the
 * higher of the two modes winning (`average` < `min` < `multiply` < `max`). Each change is the file written whole
 * (`physmatText`), one step of the panel's history (Z writes the text back); the game takes it live. `physmat_set` is the
 * same write, by the panel's same writer.
 */
import { COMBINES, type Combine, dataIfPresent, parsePhysicsMaterial, PHYSICS_MATERIAL_DEFAULTS, type PhysicsMaterialFile } from '@vibe/engine';
import { el } from '../shell.ts';
import { numberField } from '../fields.ts';

export interface PhysmatBlockHost {
  /** May this page write files: the dev server's, on this machine. */
  writes(): boolean;
  /** `path` written as `file`, one step called `label`. */
  write(path: string, file: PhysicsMaterialFile, label: string): void;
  /** The file's last write by this block, standing in for the page's until it says the same; null for none. */
  draft(key: string): PhysicsMaterialFile | null;
}

const COMBINE_HELP: Record<Combine, string> = {
  average: 'the two averaged',
  min: 'the smaller: ice on anything is slippery',
  multiply: 'the two multiplied',
  max: 'the larger: a ball on anything bounces',
};

/** The block for the physics material `key` at `path`. */
export function physmatBlock(path: string, key: string, host: PhysmatBlockHost): HTMLElement {
  const section = el('div', 'ed-component ed-physmat');
  const head = el('div', 'ed-component-head');
  head.append(el('span', 'ed-head-name', 'Physics material'));
  section.append(head);
  const raw = dataIfPresent('physicsmaterials', key);
  // Not loaded yet (a file just made): the defaults, which a new one is.
  const parsed = raw === undefined || raw === null ? PHYSICS_MATERIAL_DEFAULTS : parsePhysicsMaterial(raw);
  if (typeof parsed === 'string') {
    section.append(el('div', 'ed-warning', `This file does not read: ${parsed} -- every collider wearing it takes the default`));
    return section;
  }
  const now: PhysicsMaterialFile = { ...(host.draft(key) ?? parsed) };
  const fixed = !host.writes();
  const grid = el('div', 'ed-physmat-fields');
  const number = (field: 'friction' | 'rollingFriction' | 'restitution', label: string, title: string): void => {
    let value = now[field];
    // mcp: physmat_set -- the same write, by the tool
    const f = numberField({ label, value, step: 0.05, min: 0, title, fixed, set: (v) => void (value = v), commit: () => {
      if (value === now[field]) return;
      now[field] = value;
      host.write(path, { ...now }, `${key}: ${label} ${value}`);
    } });
    const row = el('div', 'ed-physmat-row');
    row.append(f.label, f.input.form ?? f.input);
    grid.append(row);
  };
  number('friction', 'Friction', 'Sliding friction: 0 ice, 0.5 wood, 1 rubber');
  number('rollingFriction', 'Rolling', 'Friction against rolling: 0, a ball rolls on forever');
  number('restitution', 'Bounce', 'Restitution: 0 dead, 1 back as high as it fell');
  const combine = (field: 'frictionCombine' | 'restitutionCombine', label: string): void => {
    const pick = el('select', 'ed-input ed-small'); // mcp: physmat_set -- the same write, by the tool
    pick.setAttribute('aria-label', label);
    pick.title = `${label}: how two colliders' values meet -- the higher of the two modes wins`;
    for (const c of COMBINES) pick.append(Object.assign(el('option', undefined, `${c} -- ${COMBINE_HELP[c]}`), { value: c }));
    pick.value = now[field];
    pick.disabled = fixed;
    pick.addEventListener('change', () => {
      now[field] = pick.value as Combine;
      host.write(path, { ...now }, `${key}: ${label} ${pick.value}`);
    });
    const row = el('div', 'ed-physmat-row');
    row.append(el('span', 'ed-physmat-name', label), pick);
    grid.append(row);
  };
  combine('frictionCombine', 'Friction combine');
  combine('restitutionCombine', 'Bounce combine');
  section.append(grid, el('div', 'ed-dim ed-physmat-help', `A collider wears it by its material field (${key}); one with none wears the project's default material (Config ▸ Physics).`));
  return section;
}
