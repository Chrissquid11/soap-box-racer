---
skill: studio
title: Physics in the studio
when: Before reading or changing the project's physics settings (physics.json, layers, the matrix), asking the physics world what a ray or a shape meets, fitting a collider to its model, or showing the colliders
covers:
  tools:
    - physics_state
    - physics_settings_set
    - physics_raycast
    - physics_overlap
    - physics_fit
    - physmat_set
order: 55
---
# Physics in the studio

The game's physics is Bullet through Ammo, one stage of every tick (the engine skill's
[physics page](../engine/physics.md) says how a game uses it). In the studio it is three things a person sees:

- **Config ▸ Game ▸ Physics** -- the project's `physics.json`: physics on or off, gravity, substeps, solver
  iterations, sleep thresholds, the default material, the layer names and the matrix of which layers collide (a
  triangle of checkboxes), and the stats while it runs. `physics_state` reads it all; `physics_settings_set` writes it.
- **The inspector** -- every physics component (`RigidBody`, the colliders, the joints, `CharacterController`) is
  edited as any component is (`scene_set`, `scene_component`, [the scene](scene.md)): a layer by its name, a body's
  type by its word, a joint's `other` a ref to an entity with a `RigidBody`. Under a collider, **Fit to model**
  (`physics_fit`); under a body, its state while it moves.
- **The colliders drawn** over the scene -- the top bar's Colliders button, or `view_set` with `colliders`: none, the
  selection's (the default), or every one. Green a dynamic body's, blue a kinematic's, grey a static's, cyan a
  trigger, a body's colour dimmed while it sleeps, amber the selection's; a joint is a cross at its pivot, its axis,
  and a line to the other body. They are drawn from the components, so they are right while stopped and with physics
  off, and a playtest shows them too: `view_shot` then has them.

## The settings

- **`physics_state`** -- `enabled` (the file's), `running` (Ammo loaded in this page: false where physics is off or
  failed to load), `settings` (gravity, substeps, iterations, sleep, defaultMaterial, layers, ignore), `matrix` (each
  layer's list of the layers it collides with), `stats` (bodies by type and awake, triggers, contacts, the step's
  milliseconds; null where it does not run), `colliders` (the overlay's choice).
- **`physics_settings_set`** -- any of those fields; `sleep` and `defaultMaterial` field by field. Checked as the
  file is: a wrong one is refused naming it, nothing written. It is the file's change, not the world's: no step, `Z`
  does not take it back -- read `physics_state` first to put a value back. The running game takes it at once.
  - **Layers**: `layers` is every name in order, 1 to 15, the first every collider's to begin with; a collider names
    its layer by name in a file. Renaming one without `ignore` carries its pairs off; give both to keep them.
  - **The matrix**: `ignore` is every pair of layers that pass through each other, `[["Ghost", "Default"]]` --
    each pair once, either order.
  - **On or off**: `enabled: false` leaves Ammo out of every build (the components still load, and do nothing); the
    dev server restarts for it, and the page with it -- so it is refused while the scene has unsaved changes
    (`scene_save` first, [the scene](scene.md)), and asked of the person first: it is theirs to decide.
  - Refused while a playtest is on: `play_stop` first ([play](play.md)).

## Asking the physics world

Both bring the bodies up to the components first, so they answer while stopped, paused and running alike, as the
world stands now. Both are refused where physics does not run (`physics_state`'s `running`).

- **`physics_raycast`** -- `from` and `direction` (any length), `max` metres (100), `layers` by name (every one),
  `triggers` to meet triggers too, `all` for every body along it: hits nearest first, each its entity, the point, the
  surface's normal and the distance. "What is under the crate", "how high is the floor here".
- **`physics_overlap`** -- a `sphere` (`radius`) or a `box` (`half` extents) at `at`: the entities it overlaps. "Is
  anything in the doorway", "what does this trigger zone hold now".

## Physics materials

A collider's `material` names a physics material: a `.physmat` file under `src/assets/physics-materials/` -- friction,
rolling friction, bounce and how two meet (`frictionCombine`, `restitutionCombine`: `average`, `min`, `multiply`,
`max`, the higher of the two colliders' winning). `asset_new` with `kind: "physicsmaterial"` makes one with the
defaults ([the assets](assets.md)).

- **`physmat_set`** -- `key` (its path under `physics-materials/`, lowercased: `ice`) and any of `friction`,
  `rollingFriction`, `restitution`, `frictionCombine`, `restitutionCombine`: written as the Assets inspector's Physics
  material block writes it, one step in the Assets panel's history (`Z` there takes it back). The game takes it live;
  a collider wears it by its `material` field (`scene_set`).

## Fitting a collider

- **`physics_fit`** -- `entity`, and `collider` where it has several fittable ones: the collider sized from the model
  its `Render` draws, in its own space before its scale -- a box to the model's bounds, a sphere round them, a capsule,
  cylinder or cone along their longest axis, its centre their middle; a hull or a mesh set to the model itself (mesh
  none). One step, `Z` undoes. Refused for a plane or a height field, or an entity that draws no model.

To give a crate a body that fits it:

1. `scene_component` add `RigidBody` and `BoxCollider` on it ([the scene](scene.md)).
2. `physics_fit` with `entity: "crate"`.
3. `view_set` with `colliders: "selected"`, `scene_select` it, then `view_shot` to see the box round it.
4. `play_start`, a moment, `view_shot`, `play_stop` ([play](play.md)): it falls and lands.
