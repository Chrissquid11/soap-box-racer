/**
 * The colliders drawn (Docs/physics.md §7): every collider's wireframe from the components (`collider-shapes.ts`) --
 * never from Bullet, so it is right while stopped and with physics off -- in three's fat lines, over the world:
 *
 * - **The colours**: green a dynamic body's, blue a kinematic's, grey a static's (a collider with no body above it,
 *   too), cyan a trigger, the body's colour dimmed while it sleeps, and the accent amber for the selection's.
 * - **Joints**: a cross at the pivot, the axis through it, and a line to the other body's (none: the world).
 * - **What is drawn** (`setShown`, the top bar's Colliders and `view_set`'s `colliders`): none, the selection's -- the
 *   colliders on what is selected and under it, walked from the selection alone -- or every one.
 *
 * In the scene, not the viewport's own: a playtest shows them too. Built again before a frame is drawn only when
 * something may have moved (`stale`: an edit, the selection, a load, a gizmo step) -- and every frame while a playtest
 * runs. A frame allocates nothing once warm: each collider's shape is cached by the numbers it was made from (its
 * fields and scale) and only placed again, into a growing buffer a colour. Never picked.
 */
import * as THREE from 'three';
import { LineMaterial } from 'three/addons/lines/LineMaterial.js';
import { LineSegments2 } from 'three/addons/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/addons/lines/LineSegmentsGeometry.js';
import { BodyType, COLLIDERS, type AnyComponent, type Entity, Hierarchy, JOINTS, onModelReplaced, Render, RigidBody, type World, WorldTransform } from '@vibe/engine';
import { fitResolution } from '../pick-lines.ts';
import { ACCENT } from '../overlays.ts';
import type { CollidersShown } from '../mcp/host.ts';
import { colliderSegments } from './collider-shapes.ts';
import { modelBounds } from './model-bounds.ts';

/** CSS pixels. */
const WIDTH = 1.5;

/** The colours, by what a collider is. */
export const COLLIDER_COLOURS = {
  dynamic: '#4fd16b',
  kinematic: '#4f9df0',
  static: '#9aa3ad',
  trigger: '#3fe0e6',
  asleep: '#2f6b3b',
  selected: ACCENT,
  joint: '#f2d25c',
} as const;
type Look = keyof typeof COLLIDER_COLOURS;
const LOOKS = Object.keys(COLLIDER_COLOURS) as Look[];

export interface ColliderLines {
  /** In the scene: the game's own, so a playtest draws it too. */
  readonly object: THREE.Object3D;
  readonly shown: CollidersShown;
  setShown(shown: CollidersShown): void;
  /** Something may have moved: built again at the next `update`. */
  stale(): void;
  /** Another world (a load): every shape made afresh. */
  forget(): void;
  /** Shapes kept now, for a test: one a live collider, none of a dead entity's after an `all` build. */
  readonly kept: number;
  /** Shapes made (not found kept) so far, for a test. */
  readonly made: number;
  /** Before a frame is drawn: built again from the world if stale, or `always` (a playtest running). */
  update(always?: boolean): void;
  dispose(): void;
}

/** One colour's lines: a buffer written in place, grown when it must be. */
class LineSet {
  readonly lines: LineSegments2;
  private readonly geometry = new LineSegmentsGeometry();
  private readonly material: LineMaterial;
  /** Floats written this build, and room. */
  count = 0;
  buffer = new Float32Array(0);
  constructor(look: Look) {
    this.material = new LineMaterial({ color: COLLIDER_COLOURS[look], linewidth: look === 'selected' ? WIDTH + 1 : WIDTH, transparent: true, opacity: 0.9, depthTest: false, depthWrite: false });
    this.lines = new LineSegments2(this.geometry, this.material);
    this.lines.name = `editor: colliders, ${look}`;
    this.lines.renderOrder = look === 'selected' ? 995 : 994;
    this.lines.frustumCulled = false;
    this.lines.visible = false;
    const material = this.material;
    this.lines.onBeforeRender = (renderer) => fitResolution(material, renderer);
  }
  /** Room for `more` floats past what is written. */
  room(more: number): void {
    if (this.count + more <= this.buffer.length) return;
    // A whole number of segments (six floats each): the geometry's interleaved buffer is read so.
    const next = new Float32Array(6 * Math.max(64, 2 ** Math.ceil(Math.log2((this.count + more) / 6 + 1))));
    next.set(this.buffer.subarray(0, this.count));
    this.buffer = next;
  }
  push(x: number, y: number, z: number): void {
    const b = this.buffer;
    b[this.count++] = x;
    b[this.count++] = y;
    b[this.count++] = z;
  }
  /** The build done: handed to the geometry (a new buffer only when it grew). */
  flush(): void {
    const n = this.count / 6;
    const g = this.geometry;
    const start = g.getAttribute('instanceStart') as THREE.InterleavedBufferAttribute | undefined;
    if (start === undefined || start.data.array !== this.buffer) g.setPositions(this.buffer);
    else start.data.needsUpdate = true;
    g.instanceCount = n;
    this.lines.visible = n > 0;
  }
  dispose(): void {
    this.geometry.dispose();
    this.material.dispose();
  }
}

/** A collider's shape as last made: the numbers it was made from, and its segments in the entity's turned frame. */
interface Slot {
  inputs: Float64Array;
  segments: Float32Array;
  /** The build that last drew it: one an `all` build did not reach is a dead entity's, let go. */
  built: number;
}

const EMPTY_F32 = new Float32Array(0);
const EMPTY_U8 = new Uint8Array(0);

/** The most numbers a collider is made from: its fields, the entity's scale, its model. */
const INPUTS = 48;

export function createColliderLines(world: () => World, selection: () => readonly Entity[], initial: CollidersShown = 'selected'): ColliderLines {
  const group = new THREE.Group();
  group.name = 'editor: colliders';
  const sets = LOOKS.map((look) => new LineSet(look));
  const setOf = (look: Look): LineSet => sets[LOOKS.indexOf(look)]!;
  for (const set of sets) group.add(set.lines);
  let shown = initial;
  let dirty = true;
  /** Builds so far, and the shapes the last drew. */
  let builds = 0;
  let drawn = 0;
  let made = 0;
  /** Bumped as a model is re-exported (`onModelReplaced`): a hull's or a mesh's bounds made again. */
  let models = 0;
  const offModels = onModelReplaced(() => {
    models++;
    dirty = true;
  });
  const q = new THREE.Quaternion();
  const v = new THREE.Vector3();
  /** Each component's numeric columns by name, read once a component (its fields in order). */
  /**
   * Each collider's numeric fields, the float ones first, then the whole ones -- read each frame in two loops of their
   * own, so the load from a `Float32Array` is never a generic one (which boxes every number it reads) -- and their
   * columns, taken from the store once a build (a column may be replaced as the world grows).
   */
  const fieldsOf = COLLIDERS.map((C) => {
    const floats = C.fields.filter((f) => f.type === 'f32').map((f) => f.name);
    const wholes = C.fields.filter((f) => f.type !== 'f32').map((f) => f.name);
    return { names: [...floats, ...wholes], floats, wholes, floatCols: floats.map((): Float32Array<ArrayBufferLike> => new Float32Array(0)), wholeCols: wholes.map((): ArrayLike<number> => new Uint8Array(0)) };
  });
  /** Every collider's columns from `w`'s stores, into `fieldsOf`: at the start of each build. */
  function takeColumns(w: World): void {
    for (let ci = 0; ci < COLLIDERS.length; ci++) {
      const f = fieldsOf[ci]!;
      const store = w.store(COLLIDERS[ci]! as never) as unknown as Record<string, unknown>;
      for (let i = 0; i < f.floats.length; i++) f.floatCols[i] = (store[f.floats[i]!] as Float32Array | undefined) ?? EMPTY_F32;
      for (let i = 0; i < f.wholes.length; i++) f.wholeCols[i] = (store[f.wholes[i]!] as ArrayLike<number> | undefined) ?? EMPTY_U8;
    }
  }
  const slots = new Map<number, Slot>();
  const inputs = new Float64Array(INPUTS);
  /** Marks of the selected, by entity index: what `picked` walks up to. */
  let marks = new Uint8Array(0);
  /** The entities marked now, to clear at the next build (the selection's list may change under it). */
  let marked = new Int32Array(16);
  let markedCount = 0;
  /** The walk from the selection: a stack of entities, grown. */
  let stack = new Int32Array(64);

  function mark(list: readonly Entity[], extent: number): void {
    for (let i = 0; i < markedCount; i++) if (marked[i]! < marks.length) marks[marked[i]!] = 0;
    if (marks.length < extent) marks = new Uint8Array(Math.max(extent, marks.length * 2));
    if (marked.length < list.length) marked = new Int32Array(list.length * 2);
    for (let i = 0; i < list.length; i++) {
      marks[list[i]!] = 1;
      marked[i] = list[i]!;
    }
    markedCount = list.length;
  }

  /** Is `e` selected, or under one that is? */
  function picked(parent: ArrayLike<number>, e: number): boolean {
    for (let x = e; x !== 0; x = parent[x]!) if (marks[x] === 1) return true;
    return false;
  }

  /** `e`'s body: its own `RigidBody`, else its nearest ancestor's; 0 for none. */
  function bodyOf(w: World, parent: ArrayLike<number>, e: number): number {
    for (let x = e; x !== 0; x = parent[x]!) if (w.has(x as Entity, RigidBody)) return x;
    return 0;
  }

  /** `e`'s collider `C` (its index `ci`), its segments: made again only when its numbers changed. */
  /** The entity's world scale for `shapeOf`, in a field: numbers handed to a call that is not inlined are boxed. */
  const scale = new Float64Array(3);
  function shapeOf(w: World, e: number, C: AnyComponent, ci: number): Float32Array {
    const sx = scale[0]!, sy = scale[1]!, sz = scale[2]!;
    const f = fieldsOf[ci]!;
    let n = 0;
    const floats = f.floatCols;
    for (let i = 0; i < floats.length && n < INPUTS - 5; i++) inputs[n++] = floats[i]![e] ?? 0;
    const wholes = f.wholeCols;
    for (let i = 0; i < wholes.length && n < INPUTS - 5; i++) inputs[n++] = wholes[i]![e] ?? 0;
    inputs[n++] = sx; inputs[n++] = sy; inputs[n++] = sz;
    // A hull or a mesh is drawn as its model: which one, by the key its Render draws.
    inputs[n++] = w.has(e as Entity, Render) ? w.store(Render).model[e]! : 0;
    inputs[n++] = models;
    const key = e * 16 + ci;
    let slot = slots.get(key);
    let same = slot !== undefined;
    if (slot !== undefined) for (let i = 0; i < n && same; i++) if (slot.inputs[i] !== inputs[i]) same = false;
    drawn++;
    if (same) {
      slot!.built = builds;
      return slot!.segments;
    }
    filled = n;
    return remake(w, e, C, ci, key);
  }

  /** How many of `inputs` the last `shapeOf` filled: `remake`'s. */
  let filled = 0;
  /**
   * A shape made again, from `inputs` as `shapeOf` left them -- a function of its own, so the rare path (a model's
   * bounds, a new record) never weighs on the hot one: what changed is worth what this allocates.
   */
  function remake(w: World, e: number, C: AnyComponent, ci: number, key: number): Float32Array {
    made++;
    const columns = fieldsOf[ci]!.names;
    const fields: Record<string, number> = {};
    for (let i = 0; i < columns.length; i++) fields[columns[i]!] = inputs[i]!;
    const bounds = C.name === 'HullCollider' || C.name === 'MeshCollider' ? modelBounds(w, e as Entity) : null;
    const segments = colliderSegments({ kind: C.name, fields, scale: [scale[0]!, scale[1]!, scale[2]!], bounds });
    let slot = slots.get(key);
    if (slot === undefined) slots.set(key, (slot = { inputs: new Float64Array(INPUTS), segments, built: builds }));
    slot.built = builds;
    slot.inputs.set(inputs.subarray(0, filled));
    slot.segments = segments;
    return segments;
  }

  /** `e`'s colliders and joints, into the colours' buffers. */
  function draw(w: World, e: number, parent: ArrayLike<number>, isPicked: boolean): void {
    if (!w.alive(e as Entity) || !w.has(e as Entity, WorldTransform) || !w.active(e as Entity)) return;
    const wt = w.store(WorldTransform);
    q.set(wt.qx[e]!, wt.qy[e]!, wt.qz[e]!, wt.qw[e]!);
    const px = wt.px[e]!, py = wt.py[e]!, pz = wt.pz[e]!;
    const sx = wt.sx[e]!, sy = wt.sy[e]!, sz = wt.sz[e]!;
    scale[0] = sx; scale[1] = sy; scale[2] = sz;
    let body = -1;
    for (let ci = 0; ci < COLLIDERS.length; ci++) {
      const C = COLLIDERS[ci]!;
      if (!w.has(e as Entity, C) || !w.enabled(e as Entity, C)) continue;
      let look: Look = 'selected';
      if (!isPicked) {
        const trigger = (w.store(C as never) as unknown as { trigger: ArrayLike<number> }).trigger[e];
        if (body < 0) body = bodyOf(w, parent, e);
        if (trigger === 1) look = 'trigger';
        else if (body === 0) look = 'static';
        else {
          const rb = w.store(RigidBody);
          const type = rb.type[body]!;
          look = type === BodyType.kinematic ? 'kinematic' : type === BodyType.static ? 'static' : rb.sleeping[body] === 1 ? 'asleep' : 'dynamic';
        }
      }
      const s = shapeOf(w, e, C, ci);
      const set = setOf(look);
      set.room(s.length);
      // Turned by the entity's rotation and moved to it, written straight into the colour's buffer.
      const out = set.buffer;
      let at = set.count;
      const qx = q.x, qy = q.y, qz = q.z, qw = q.w;
      for (let k = 0; k < s.length; k += 3) {
        const x = s[k]!, y = s[k + 1]!, z = s[k + 2]!;
        const tx = 2 * (qy * z - qz * y), ty = 2 * (qz * x - qx * z), tz = 2 * (qx * y - qy * x);
        out[at++] = x + qw * tx + (qy * tz - qz * ty) + px;
        out[at++] = y + qw * ty + (qz * tx - qx * tz) + py;
        out[at++] = z + qw * tz + (qx * ty - qy * tx) + pz;
      }
      set.count = at;
    }
    for (let ji = 0; ji < JOINTS.length; ji++) {
      const J = JOINTS[ji]!;
      if (!w.has(e as Entity, J) || !w.enabled(e as Entity, J)) continue;
      const js = w.store(J as never) as unknown as Record<string, ArrayLike<number>>;
      v.set(js.anchorX![e]! * sx, js.anchorY![e]! * sy, js.anchorZ![e]! * sz).applyQuaternion(q);
      const ax = v.x + px, ay = v.y + py, az = v.z + pz;
      const set = setOf(isPicked ? 'selected' : 'joint');
      set.room(24);
      const c = 0.08;
      set.push(ax - c, ay, az); set.push(ax + c, ay, az);
      set.push(ax, ay - c, az); set.push(ax, ay + c, az);
      set.push(ax, ay, az - c); set.push(ax, ay, az + c);
      v.set(js.axisX![e]!, js.axisY![e]!, js.axisZ![e]!).normalize().multiplyScalar(0.35).applyQuaternion(q);
      set.push(ax - v.x, ay - v.y, az - v.z); set.push(ax + v.x, ay + v.y, az + v.z);
      const other = w.deref(js.other![e]! as never) as number;
      if (other !== 0 && w.alive(other as Entity) && w.has(other as Entity, WorldTransform)) {
        set.push(ax, ay, az);
        set.push(wt.px[other]!, wt.py[other]!, wt.pz[other]!);
      }
    }
  }

  function build(): void {
    builds++;
    drawn = 0;
    for (let i = 0; i < sets.length; i++) sets[i]!.count = 0;
    if (shown !== 'none') {
      const w = world();
      takeColumns(w);
      const h = w.rawStore(Hierarchy) as { parent: ArrayLike<number>; firstChild: ArrayLike<number>; nextSibling: ArrayLike<number> };
      const chosen = selection();
      mark(chosen, w.extent);
      if (shown === 'all') {
        for (let e = 1; e < w.extent; e++) draw(w, e, h.parent, markedCount > 0 && picked(h.parent, e));
        // Shapes kept past what this build drew: a dead entity's (or a collider taken off) -- let go. Only then: the
        // walk over the map is what allocates.
        if (slots.size > drawn) for (const [key, slot] of slots) if (slot.built !== builds) slots.delete(key);
      } else {
        // The selection and what is under it, each once (one selected under another is walked with its parent).
        let top = 0;
        for (let i = 0; i < chosen.length; i++) {
          const e = chosen[i]!;
          if (!w.alive(e) || picked(h.parent, h.parent[e]!)) continue;
          if (top >= stack.length) stack = growStack(stack);
          stack[top++] = e;
        }
        while (top > 0) {
          const e = stack[--top]!;
          draw(w, e, h.parent, true);
          for (let c = h.firstChild[e]!; c !== 0; c = h.nextSibling[c]!) {
            if (top >= stack.length) stack = growStack(stack);
            stack[top++] = c;
          }
        }
      }
    }
    for (let i = 0; i < sets.length; i++) sets[i]!.flush();
  }

  return {
    object: group,
    get shown() {
      return shown;
    },
    setShown(next) {
      shown = next;
      dirty = false;
      build();
    },
    stale() {
      dirty = true;
    },
    forget() {
      slots.clear();
      dirty = true;
    },
    get kept() {
      return slots.size;
    },
    get made() {
      return made;
    },
    update(always = false) {
      if (!dirty && !always) return;
      dirty = false;
      build();
    },
    dispose() {
      for (const set of sets) set.dispose();
      offModels();
      slots.clear();
      group.removeFromParent();
    },
  };
}

/** A stack twice as deep, what it held kept. */
function growStack(stack: Int32Array<ArrayBuffer>): Int32Array<ArrayBuffer> {
  const next = new Int32Array(stack.length * 2);
  next.set(stack);
  return next;
}
