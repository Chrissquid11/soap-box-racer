/**
 * The project's `physics.json` from the page (Docs/physics.md §7): read and written through the dev server's
 * `/__physics/settings` (the pipeline's `physics/route.ts`) -- what Config ▸ Physics and `physics_settings_set` share,
 * with the one rule they keep alike: **no change while a playtest runs**, and **physics turned on or off only with
 * the world saved** -- the dev server restarts for it, and the page with it.
 *
 * A change reaches the running game through the dev server's watch of the file (`usePhysicsSettings`), not from here.
 */
import { physicsSettings, type PhysicsSettings } from '@vibe/engine';

/** The route's path (the pipeline's `PHYSICS_ROUTE`). */
const ROUTE = '/__physics/settings';

/** A change: any field of the file, the two pairs field by field (the pipeline's `PhysicsSettingsPatch`). */
export interface PhysicsChange {
  enabled?: boolean;
  gravity?: readonly [number, number, number];
  substeps?: number;
  iterations?: number;
  sleep?: { linear?: number; angular?: number };
  defaultMaterial?: { friction?: number; restitution?: number };
  layers?: readonly string[];
  ignore?: readonly (readonly [string, string])[];
}

/** Where the editor stands, for the rule. */
export interface PhysicsGuard {
  /** A playtest on, running or paused. */
  playing(): boolean;
  /** The world has changes nobody saved: a restart would ask about them. */
  unsaved(): boolean;
}

/** Why `change` may not be made now, or null. Pure. */
export function physicsRefusal(change: PhysicsChange, guard: PhysicsGuard, now: PhysicsSettings): string | null {
  if (guard.playing()) return 'Not while a playtest is on: stop it first';
  if (change.enabled !== undefined && change.enabled !== now.enabled && guard.unsaved()) {
    return `Turning physics ${change.enabled ? 'on' : 'off'} restarts the dev server and the page: save the scene first`;
  }
  return null;
}

/** The file's settings and whether there is one; the page's own (the last the dev server served) where there is no route. */
export async function readPhysics(): Promise<{ settings: PhysicsSettings; file: boolean; live: boolean }> {
  try {
    const res = await fetch(ROUTE);
    if (res.ok) {
      const body = (await res.json()) as { settings: PhysicsSettings; file: boolean };
      return { ...body, live: true };
    }
  } catch {
    // No dev server: the page's own below.
  }
  return { settings: physicsSettings(), file: false, live: false };
}

/** `change` written to the file: the settings it made, and whether the dev server restarts for it; or why not. */
export async function writePhysics(change: PhysicsChange, guard: PhysicsGuard): Promise<{ settings: PhysicsSettings; restart: boolean } | { error: string }> {
  const why = physicsRefusal(change, guard, physicsSettings());
  if (why !== null) return { error: why };
  let res: Response;
  try {
    res = await fetch(ROUTE, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ set: change }) });
  } catch (err) {
    return { error: `The dev server did not answer: ${(err as Error).message}` };
  }
  const body = (await res.json().catch(() => ({}))) as { settings?: PhysicsSettings; restart?: boolean; refused?: string };
  if (!res.ok || !body.settings) return { error: body.refused ?? `physics.json not written (${res.status})` };
  return { settings: body.settings, restart: body.restart === true };
}
