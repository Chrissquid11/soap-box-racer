/**
 * Fit to model (Docs/physics.md §7): a collider sized from its entity's model, the numbers alone -- the bounds of
 * `Render.model` in the entity's own space (before its scale: a collider's numbers are, D11) to the fields that shape
 * each collider:
 *
 * - **A box** to the bounds: `size` their extents, `center` their middle.
 * - **A sphere** round them: `radius` their largest half extent, `center` their middle.
 * - **A capsule, a cylinder or a cone** along their longest axis (`axis`): `height` that extent (a capsule's at least
 *   its two radii), `radius` the larger half extent across it, `center` their middle.
 * - **A hull or a mesh** to the model itself: `mesh` none (the one its Render draws), `center` and `turn` nought.
 * - **A plane or a height field**: nothing to fit (null).
 *
 * `turn` is set to nought for every shape fitted: the bounds are the entity's axes.
 *
 * Pure: node tests it (`fit.test.ts`).
 */

/** An axis-aligned box in the entity's space. */
export interface Bounds {
  min: readonly [number, number, number];
  max: readonly [number, number, number];
}

/** The fields Fit writes, by name (`sizeX`, `radius`, `axis` -- `ShapeAxis`' number: y 0, x 1, z 2): every one of them the collider has. */
export type Fitted = Record<string, number>;

/** `ShapeAxis`' values, in its order: what an `axis` field's number means. */
const AXES = ['y', 'x', 'z'] as const;
const INDEX = { x: 0, y: 1, z: 2 } as const;

/** The colliders Fit takes, by component name. */
export const FITTABLE = ['BoxCollider', 'SphereCollider', 'CapsuleCollider', 'CylinderCollider', 'ConeCollider', 'HullCollider', 'MeshCollider'] as const;

/** `collider`'s fields fitted to `bounds`, or null: a plane or a height field, or empty bounds. */
export function fitCollider(collider: string, bounds: Bounds): Fitted | null {
  const { min, max } = bounds;
  const size = [max[0] - min[0], max[1] - min[1], max[2] - min[2]] as const;
  if (!(FITTABLE as readonly string[]).includes(collider)) return null;
  const centre = { centerX: 0, centerY: 0, centerZ: 0, turnX: 0, turnY: 0, turnZ: 0 };
  if (collider === 'HullCollider' || collider === 'MeshCollider') return { mesh: 0, ...centre };
  if (!size.every((s) => Number.isFinite(s) && s >= 0) || size.every((s) => s === 0)) return null;
  centre.centerX = (min[0] + max[0]) / 2;
  centre.centerY = (min[1] + max[1]) / 2;
  centre.centerZ = (min[2] + max[2]) / 2;
  const least = 0.001;
  if (collider === 'BoxCollider') return { sizeX: Math.max(size[0], least), sizeY: Math.max(size[1], least), sizeZ: Math.max(size[2], least), ...centre };
  if (collider === 'SphereCollider') return { radius: Math.max(Math.max(...size) / 2, least), ...centre };
  // Along the longest: y first among equals (ShapeAxis' default), then x, then z.
  let along: 'x' | 'y' | 'z' = 'y';
  for (const a of ['x', 'z'] as const) if (size[INDEX[a]] > size[INDEX[along]]) along = a;
  const across = (['x', 'y', 'z'] as const).filter((a) => a !== along).map((a) => size[INDEX[a]]);
  const radius = Math.max(Math.max(...across) / 2, least);
  let height = Math.max(size[INDEX[along]], least);
  if (collider === 'CapsuleCollider') height = Math.max(height, 2 * radius);
  return { radius, height, axis: AXES.indexOf(along), ...centre };
}
