/**
 * The layer matrix as Config ▸ Physics draws it (Docs/physics.md §7, D9): Unity's triangle of checkboxes over the
 * project's layer names, ticked where two layers collide, from `physics.json`'s `ignore` pairs and back. Symmetric by
 * making -- a pair is one cell, A with B the same as B with A -- and written canonically: each pair once, the lower
 * layer first, in the layers' order, so a file edited here diffs by the pair that changed.
 *
 * Pure: node tests it (`matrix.test.ts`).
 */

/** A pair of layers by name that pass through each other: `physics.json`'s `ignore`. */
export type LayerPair = readonly [string, string];

/** Do layers `a` and `b` (by index into `layers`) collide, by `ignore`? Each way the same. */
export function collides(layers: readonly string[], ignore: readonly LayerPair[], a: number, b: number): boolean {
  const na = layers[a], nb = layers[b];
  if (na === undefined || nb === undefined) return false;
  return !ignore.some(([x, y]) => (x === na && y === nb) || (x === nb && y === na));
}

/** The whole matrix: `grid[a][b]`, `layers.length` square, the same both ways. */
export function collisionGrid(layers: readonly string[], ignore: readonly LayerPair[]): boolean[][] {
  return layers.map((_, a) => layers.map((__, b) => collides(layers, ignore, a, b)));
}

/** The pairs a grid ignores, canonically: each once, lower layer first, row by row. Reads `grid[a][b]` with `b >= a` (the triangle). */
export function ignoreOf(layers: readonly string[], grid: readonly (readonly boolean[])[]): LayerPair[] {
  const out: LayerPair[] = [];
  for (let a = 0; a < layers.length; a++) for (let b = a; b < layers.length; b++) if (grid[a]?.[b] === false) out.push([layers[a]!, layers[b]!]);
  return out;
}

/** `ignore` with the cell of `a` and `b` set to collide or not -- the triangle's checkbox -- written canonically. */
export function setCollides(layers: readonly string[], ignore: readonly LayerPair[], a: number, b: number, on: boolean): LayerPair[] {
  const grid = collisionGrid(layers, ignore);
  if (grid[a] === undefined || grid[b] === undefined) return ignoreOf(layers, grid);
  grid[a]![b] = on;
  grid[b]![a] = on;
  return ignoreOf(layers, grid);
}

/**
 * The layer names after one is renamed, added or taken out -- why not, or the names: 1 to 15 of them, none empty, none
 * twice (in any case). The matrix's pairs follow a rename by `renamePairs`.
 */
export function checkLayers(names: readonly string[]): string | null {
  if (names.length === 0) return 'at least one layer: the first is every collider\'s to begin with';
  if (names.length > 15) return 'at most 15 layers: Ammo\'s filters are 16 bits, and the last is the queries\'';
  const blank = names.findIndex((n) => n.trim() === '');
  if (blank >= 0) return `layer ${blank} has no name`;
  const seen = new Set<string>();
  for (const n of names) {
    const k = n.trim().toLowerCase();
    if (seen.has(k)) return `"${n}" is two layers' name: a file names a layer by it`;
    seen.add(k);
  }
  return null;
}

/** `ignore` with the layer `from` called `to`: its pairs kept under the new name. */
export function renamePairs(ignore: readonly LayerPair[], from: string, to: string): LayerPair[] {
  return ignore.map(([a, b]) => [a === from ? to : a, b === from ? to : b] as const);
}
