/**
 * Config ▸ Game ▸ Physics (`physicsPage`, Docs/physics.md §7): the project's `physics.json` as rows, each written
 * through the dev server as it is changed (`settings-client.ts`; `physics_settings_set` does the same) --
 *
 * - **Physics**: the switch. Off, the components still load and do nothing, and Ammo is left out of every build; the
 *   dev server restarts for it (a build define cannot change under it), so only with the scene saved.
 * - **The world**: gravity, substeps (1-8), the solver's iterations (1-50); **Sleep**'s thresholds; **The default
 *   material**: what a collider with none of its own is made of.
 * - **Layers**: the names (1 to 15, the first every collider's to begin with), renamed in place -- the matrix's pairs
 *   kept under the new name -- added at the foot, the last taken away; and **Collisions**, Unity's triangle of
 *   checkboxes, ticked where two layers meet.
 * - **Stats**, read twice a second while the page is shown: bodies by type and awake, triggers, contacts, the step's
 *   milliseconds (the last, and the most of the last second -- measurement, not simulation).
 *
 * No change while a playtest runs. Read again each time the page is shown: the file may have been edited by hand.
 */
import { physicsOf, type PhysicsSettings } from '@vibe/engine';
import { button, el } from '../shell.ts';
import { numberField, shown, textInput } from '../fields.ts';
import type { ConfigPage, EditorContext, PageInstance } from '../tool.ts';
import { checkLayers, collides, renamePairs, setCollides } from './matrix.ts';
import { readPhysics, writePhysics, type PhysicsChange, type PhysicsGuard } from './settings-client.ts';

export const PHYSICS_PAGE = 'physics';

/** The page's word on the stats, from `stats()`: a line, or why there are none. */
export function statsWords(ready: boolean, s: ReturnType<ReturnType<typeof physicsOf>['stats']> | null): string {
  if (!ready || s === null) return 'No physics running here: it is off, or Ammo did not load.';
  return `${s.dynamic} dynamic, ${s.kinematic} kinematic, ${s.static} static (${s.awake} awake) · ${s.triggers} triggers · ${s.contacts} contacts · step ${shown(s.stepMs, 2)} ms, at most ${shown(s.maxStepMs, 2)} ms`;
}

export function physicsPage(guard: PhysicsGuard): ConfigPage {
  return {
    id: PHYSICS_PAGE,
    title: 'Physics',
    group: 'Game',
    help: 'The project\'s physics.json: physics on or off, gravity, substeps, iterations, sleep, the default material, the layers and which collide, and the stats while it runs',
    create: (ctx) => createPhysicsPage(ctx, guard),
  };
}

function createPhysicsPage(ctx: EditorContext, guard: PhysicsGuard): PageInstance {
  const root = el('div', 'ed-prefs ed-physics-page');
  const said = el('div', 'ed-dim');
  const stats = el('div', 'ed-pref-help ed-physics-stats');
  let settings: PhysicsSettings | null = null;
  let live = false;
  let timer: ReturnType<typeof setInterval> | undefined;
  const head = (text: string): HTMLElement => el('div', 'ed-component-head', text);
  const row = (name: string, help: string, ...controls: HTMLElement[]): HTMLElement => {
    const line = el('div', 'ed-pref');
    const box = el('div', 'ed-pref-controls');
    box.append(...controls);
    line.append(el('div', 'ed-pref-name', name), box, el('div', 'ed-pref-help', help));
    return line;
  };

  /** A change written, then the page read again; what went wrong, or what it means, said under it. */
  async function change(set: PhysicsChange, after?: string): Promise<void> {
    if (!live) return void (said.textContent = 'No dev server here: physics.json is written by `vibe dev`');
    const done = await writePhysics(set, guard);
    if ('error' in done) {
      said.textContent = done.error;
      draw();
      return;
    }
    settings = done.settings;
    said.textContent = done.restart ? 'physics.json written: the dev server restarts, and the page with it' : after ?? 'physics.json written: the game has it now';
    draw();
  }

  /** A number row's field: shown, kept as typed or scrubbed, written as it is let go. */
  function number(label: string, value: number, options: { step: number; integer?: boolean; min?: number; max?: number; title: string }, write: (v: number) => PhysicsChange): HTMLElement {
    let now = value;
    const field = numberField({ label, value, step: options.step, integer: options.integer, min: options.min, max: options.max, title: options.title, set: (v) => void (now = v), commit: () => void change(write(now)) });
    const pair = el('span', 'ed-physics-number');
    pair.append(field.label, field.input);
    return pair;
  }

  function layerRows(s: PhysicsSettings): HTMLElement[] {
    const rows = s.layers.map((name, i) => {
      const field = textInput(name, `Layer ${i}`);
      field.title = i === 0 ? 'Layer 0: every collider\'s to begin with' : `Layer ${i}: a collider's layer by this name in a file`;
      field.addEventListener('change', () => {
        const next = s.layers.map((n, k) => (k === i ? field.value.trim() : n));
        const why = checkLayers(next);
        if (why !== null) {
          said.textContent = why;
          field.value = name;
          return;
        }
        void change({ layers: next, ignore: renamePairs(s.ignore, name, field.value.trim()) }, `Layer ${i} is ${field.value.trim()} now: a file naming ${name} names a layer no longer there`);
      });
      const controls: HTMLElement[] = [field];
      if (i === s.layers.length - 1 && i > 0) {
        controls.push(button('physics_settings_set', 'Remove', `Take ${name} away: a collider on it falls back to Default`, () => void change({ layers: s.layers.slice(0, -1) }), 'ed-small ed-danger'));
      }
      return row(String(i), i === 0 ? 'Every collider\'s layer to begin with' : '', ...controls);
    });
    if (s.layers.length < 15) {
      const name = textInput('', 'A new layer');
      const add = button('physics_settings_set', 'Add', 'A layer at the end, colliding with every other until the matrix says not', () => {
        const next = [...s.layers, name.value.trim()];
        const why = checkLayers(next);
        if (why !== null) return void (said.textContent = why);
        void change({ layers: next });
      }, 'ed-small ed-accent');
      rows.push(row(String(s.layers.length), 'At most 15: Ammo\'s filters are 16 bits, and the last is the queries\'', name, add));
    }
    return rows;
  }

  /** Unity's triangle: a row a layer, a column a layer from the last back to it, ticked where they collide. */
  function matrix(s: PhysicsSettings): HTMLElement {
    const table = el('table', 'ed-physics-matrix');
    const top = el('tr');
    top.append(el('th'));
    const cols = s.layers.map((_, i) => s.layers.length - 1 - i);
    for (const b of cols) {
      const th = el('th', 'ed-physics-matrix-col');
      th.append(el('span', undefined, s.layers[b]!));
      top.append(th);
    }
    table.append(top);
    s.layers.forEach((name, a) => {
      const tr = el('tr');
      tr.append(el('th', 'ed-physics-matrix-row', name));
      for (const b of cols) {
        const td = el('td');
        if (b >= a) {
          const box = el('input', 'ed-check');
          box.type = 'checkbox';
          box.checked = collides(s.layers, s.ignore, a, b);
          box.title = `${name} with ${s.layers[b]}: ${box.checked ? 'they collide -- a click lets them pass through each other' : 'they pass through each other -- a click makes them collide'}`;
          box.setAttribute('aria-label', `${name} with ${s.layers[b]}`);
          box.addEventListener('change', () => void change({ ignore: setCollides(s.layers, s.ignore, a, b, box.checked) }));
          td.append(box);
        }
        tr.append(td);
      }
      table.append(tr);
    });
    return table;
  }

  function draw(): void {
    const s = settings;
    if (s === null) return void root.replaceChildren(el('div', 'ed-dim', 'Reading physics.json…'));
    const on = el('input', 'ed-check');
    on.type = 'checkbox';
    on.checked = s.enabled;
    on.disabled = !live;
    on.addEventListener('change', () => void change({ enabled: on.checked }));
    const onLine = el('label', 'ed-check-line');
    onLine.append(on, el('span', undefined, s.enabled ? 'On' : 'Off'));
    const g = s.gravity;
    const gravity = (i: 0 | 1 | 2, axis: string): HTMLElement => number(axis, g[i], { step: 0.1, title: `Gravity along ${axis}, metres a second squared` }, (v) => ({ gravity: [i === 0 ? v : g[0], i === 1 ? v : g[1], i === 2 ? v : g[2]] }));
    root.replaceChildren(
      head('Physics'),
      row('Physics', s.enabled
        ? 'On: Ammo (Bullet) steps every tick and moves every body. Off, the components still load and do nothing, and Ammo -- about 1 MB of wasm -- is left out of every build; the dev server restarts for it'
        : 'Off: the components load and do nothing; Ammo is out of every build. On again, the dev server restarts and the bodies move', onLine),
      head('The world'),
      row('Gravity', 'Metres a second squared, world space: [0, -9.81, 0] is Earth\'s', gravity(0, 'x'), gravity(1, 'y'), gravity(2, 'z')),
      row('Substeps', 'Steps a tick, 1 to 8: more for fast or small things, each 1/(60 × substeps) s', number('', s.substeps, { step: 1, integer: true, min: 1, max: 8, title: 'Substeps' }, (v) => ({ substeps: v }))),
      row('Iterations', 'The solver\'s a step, 1 to 50: more for stacks and chains that sag', number('', s.iterations, { step: 1, integer: true, min: 1, max: 50, title: 'Iterations' }, (v) => ({ iterations: v }))),
      head('Sleep'),
      row('Below', 'A body slower than these for a while sleeps until something touches it: metres and radians a second',
        number('m/s', s.sleep.linear, { step: 0.05, min: 0, title: 'Linear sleep threshold' }, (v) => ({ sleep: { linear: v } })),
        number('rad/s', s.sleep.angular, { step: 0.05, min: 0, title: 'Angular sleep threshold' }, (v) => ({ sleep: { angular: v } }))),
      head('The default material'),
      row('Friction', 'What a collider with no physics material of its own slides with: 0 ice', number('', s.defaultMaterial.friction, { step: 0.05, min: 0, title: 'Default friction' }, (v) => ({ defaultMaterial: { friction: v } }))),
      row('Bounce', 'Its restitution: 0 dead, 1 back as high', number('', s.defaultMaterial.restitution, { step: 0.05, min: 0, title: 'Default restitution' }, (v) => ({ defaultMaterial: { restitution: v } }))),
      head('Layers'),
      ...layerRows(s),
      head('Collisions'),
      row('', 'Ticked: the two layers collide. Clear: they pass through each other, and the queries see each as asked', matrix(s)),
      head('Stats'),
      stats,
      said,
    );
    tick();
  }

  function tick(): void {
    const physics = physicsOf(ctx.world);
    stats.textContent = statsWords(physics.ready, physics.ready ? physics.stats() : null);
  }

  return {
    root,
    setVisible(visible) {
      clearInterval(timer);
      if (!visible) return void root.replaceChildren();
      said.textContent = '';
      settings = null;
      draw();
      void readPhysics().then((read) => {
        settings = read.settings;
        live = read.live;
        if (!live) said.textContent = 'No dev server here: these are the settings the page was served, read only';
        draw();
      });
      timer = setInterval(tick, 500);
    },
    refresh() {
      if (settings !== null && !root.contains(document.activeElement)) tick();
    },
    dispose() {
      clearInterval(timer);
      root.remove();
    },
  };
}
